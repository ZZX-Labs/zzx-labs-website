SET NAMES utf8mb4;
CREATE TABLE IF NOT EXISTS worldfactbook_chunks (
  chunk_id CHAR(64) NOT NULL,
  edition_year SMALLINT UNSIGNED NOT NULL,
  entity_code VARCHAR(24) NOT NULL DEFAULT '',
  entity_name VARCHAR(160) NOT NULL DEFAULT '',
  category VARCHAR(96) NOT NULL,
  ordinal INT UNSIGNED NOT NULL,
  content MEDIUMTEXT NOT NULL,
  content_sha256 CHAR(64) NOT NULL,
  source_provider VARCHAR(64) NOT NULL,
  source_identifier VARCHAR(255) NOT NULL,
  source_format VARCHAR(32) NOT NULL,
  source_sha256 CHAR(64) NOT NULL,
  source_url TEXT NOT NULL,
  extractor VARCHAR(64) NOT NULL,
  PRIMARY KEY (chunk_id),
  KEY idx_wfb_year_category (edition_year, category),
  KEY idx_wfb_entity_year (entity_code, edition_year),
  KEY idx_wfb_source_sha (source_sha256)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4fa43bc87762a122f468b6b1ce6cc21553642a1ecdeae7e2f9d65e4474dbddc4',1977,'AF','Afghanistan','government',5,'Legal name: Republic of Afghanistan
Type: republic
Capital: Kabul
Political subdivisions: 26 provinces with centrally
appointed governors
Legal system: based on Islamic law; constitution
nullified July 1973; independent judiciary also
abolished and powers transferred to the Council of
Justice, chaired by Minister of Justice; legal education
at University of Kabul; has not accepted compulsory
IC] jurisdiction
Branches: Parliament abolished July 1978; all
powers of the parliament and the monarchy
transferred to the President
Government leaders: President Mohammad
Daoud who also serves as Prime Minister, Foreign
Minister, and Defense Minister; Mohammad Naim,
Daoud’s brother and personal adviser
Suffrage: universal from age 20
Elections: promised but no date set
Political parties and leaders: no political parties
permitted
Communists: there are two pro-Moscow Com-
munist groups, Parcham and Khalq, believed to have
several hundred active members, and a smaller pro-
Peking group, Sholaye-Jaweid
Other political or pressure groups: most military
officers support the government; no known organized
opposition
Member of: ADB, Colombo Plan, FAO, IAEA,
IBRD, ICAO, IDA, IFC, ILO, IMF, ITU, U.N.,
UNESCO, UPU, WHO, WMO, WSG','46255a389fa760a1b041209eee9461e12609e8083fc9c36200deffb0dd12165a','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f2256105f7e354b34d5b40f9a746ca240120f4240985894c5142cc429ae4ea07',1977,'AL','Albania','government',10,'Legal name: Peoples Republic of Albania
Type: Communist state
Capital: Tirane
Political subdivisons: 27 rethet (districts),
including capital, 200 localities, 2,600 villages
Legal system: based on Soviet law; constitution
adopted 1950; judicial review of legislative acts only
in the Presidium of the People’s Assembly, which is
not a true court; legal education at State University of
Tirane; has not accepted compulsory IC] jurisdiction
Branches: People’s Assembly, Council of Ministers,
judiciary
Government leaders: Chairman of Council of
Ministers, Mehmet Shehu; President, Presidium of the
People’s Assembly, Haxhi Lleshi
Suffrage: universal and compulsory over age 18
Elections: national elections theoretically held
every 4 years; last elections 6 October 1974; 99.9% of
electorate voted
Political parties and leaders: Albanian Workers
Party only; First Secretary, Enver Hoxha
Communists: 87,000 party members (1971)
Member of: CEMA, IAEA, IPU, ITU, U.N.,
UNESCO, UPU, WFTU, WHO, WMO; has not
participated in CEMA since rift with U.S.S.R. in
1961; officially withdrew from Warsaw Pact 13
September 1968','a4ea04130b8bd60152db0e74a695962a3e1ac635540ed1418a91b1c16788c916','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d4eeb30838167f82dc826a3f20ff9ccdf3e3580c32753083df7be9191897e199',1977,'DZ','Algeria','government',14,'Legal name: Democratic and Popular Republic of
Type: republic
Capital: Algiers
Political subdivisions: 31 Wilayas (departments or
provinces)
Legal system: based on French and Islamic law,
with socialist principles; new constitution adopted by
referendum November 1976; judicial review of
legislative acts in ad hoc Constitutional Council
composed of various public officials, including several
Supreme Court justices; Supreme Court divided into 4
chambers; legal education at Universities of Algiers,
Oran and Constantine; has not accepted compulsory
ICJ jurisdiction
Branches: executive dominant; unicameral
legislature will be reconvened in February 1976;
judiciary
Government leader: Houari Boumediene, Presi-
dent of State and President of Council of the
Revolution, overthrew elected President Ahmed Ben
Bella 19 June 1965
Suffrage: universal over age 19
Elections (latest): presidential December 10, 1976;
departmental assemblies 2 June 1974; local assemblies
30 March 1975; legislative elections scheduled for
February 4, 1977
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
January 1977
ALGERIA/ANDORRA
Political parties and leaders: National Liberation
Front (FLN)
Communists: 400 (est.); Communist Party illegal
(banned 1962)
Member of: AFDB, AIOEC, Arab League,
ASSIMER, FAO, GATT (de facto), IAEA, IBRD,
ICAO, IDA, ILO, International Lead and Zinc Study
Group, IMCO, IMF, IOOC, ITU, OAPEC, OAU,
OPEC, U.N., UNESCO, UPU, WHO, WMO','7b15a69adcf3ca926bc588446ac46d38fbd43519249594967926b72717aaf061','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1ac346f9fd9a6c34b0932ba3cdc3af0e816c254c3c23bea71123d74cff9fc552',1977,'AD','Andorra','government',18,'Legal name: The Valleys of Andorra
Type: unique coprincipality under formal
sovereignty of President of France and Spanish Bishop
of Seo de Urgel, who are represented locally by
officials called veguers
Capital: Andorra
Political subdivisions: 6 districts—Andorra la
Vella, Sant Julia de Loria, Encamp, Canillo, La
Massana, and Ordino
Legal system: based on French and Spanish civil
codes; Plan of Reform adopted 1866 serves as
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
January 1977
ANDORRA/ANGOLA
constitution; no judicial review of legislative acts; has
not accepted compulsory ICJ jurisdiction
Branches: legislature (General Council) of 24
members with one-half elected every 2 years for 4-year
term; executive—syndic and a deputy sub-syndic
chosen by General Council for 3-year terms; judiciary
chosen by coprinces who appoint 2 civil judges, a
judge of appeals, and 2 Batles (court prosecutors)
Suffrage: males of 21 or over who are third
generation Andorrans vote for General Council
members; same right granted to women in April 1970
Elections: half of General Council chosen every 2
years, last election December 1975
Political parties and leaders: no political parties
but only partisans for particular independent
candidates for the General Council, on the basis of
competence, personality and orientation toward Spain
or France; various small pressure groups developed in
1972
Communists: negligible','72f645cc94b2115baa6f8bc328a3850d7827f3a4b3034de84dd69c812d970730','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b9d6aced9fec64d996170926735b73a6c3e46f8fedb4d272ccae2f28360b75c1',1977,'AO','Angola','government',22,'Legal name: Peoples Republic of Angola
Type: republic; achieved independence from
Portugal in November 1975; constitution promul-
gated 1975; government formed after civil war which
ended in early 1976
Capital: Luanda
Political subdivisions: 16 administrative districts
including the coastal enclave of Cabinda
Legal system: to be determined
Branches: the official party is the supreme political
institution
Government leaders: Agostinho Neto, president
Suffrage: to be determined
Elections: none held to date
CIA-RDP79-01051A000800010006-3
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
January 1977
ANGOLA/ANTIGUA
Political parties.and leaders: Popular Movement
for the Liberation of Angola (MPLA), led by
Agostinho Neto, only legal party; National Front for
the Liberation of Angola (FNLA) and National Union
for the Total Independence of Angola (UNITA)
defeated in civil war carrying out limited insurgencies
Member of: UN
Legal name: State of Antigua
Type: dependent territory with full internal
autonomy as a British “Associated State”
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
January 1977
ANTIGUA/ARGENTINA
Capital: St. John’s
Political subdivisions: 6 parishes, 2 dependencies
(Barbuda, Redonda)
Legal system: based on English law; British
Caribbean Court of Appeal has exclusive original
jurisdiction and an appellate jurisdiction, consists of
Chief Justice and 5 justices
Branches: legislative, 21-member popularly elected
House of Representatives; executive, Prime Minister
and Cabinet
Government leaders: Premier Vere C. Bird, Sr.;
Deputy Premier Lester Bird; Governor Sir Wilfred
Ebenezer Jacobs
Suffrage: universal suffrage age 18 and over
Elections: every 5 years; last general election 11
February 1976
Political parties and leaders: Antigua Labor Party
(ALP), Vere C. Bird, Sr., Lester Bird; Progressive
Labor Movement (PLM), George Herbert Walter;
Antigua People’s Party (APP), J. Rowan Henry
Voting strength: 1976 election—House of
Representative seats—ALP 10, PLM 5, independent
1, tie 1
Communists: negligible
Other political or pressure groups: Afro-
Caribbean Liberation Movement (ACLM), a small
black nationalist group led by Timothy Hector;
Antigua Freedom Fighters (AFF), a small black
radical group, leaders unknown
Member of; CARICOM, ISO','f97fbaef01381f953ecdae4637714385cdc1425cee5845029995cffe9843141a','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a2e43ddd88dc85831f58fbb49312a6a391036cf1e777f1cae9aec56b1676852b',1977,'AR','Argentina','government',26,'Legal name: Argentine Republic
Type: republic
Capital: Buenos Aires
Political subdivisions: 22 provinces, 1 district
(Federal Capital), and 1 territory
Legal system: based on Spanish and French civil
codes; constitution adopted 1853 partially superseded
in 1966 by the Statute of the Revolution which takes
precedence over the constitution when the two are in
conflict, further changes may be made by new
government; judicial review of legislative acts; legal
education at University of Buenos Aires and other
public and private universities; has not accepted
compulsory ICJ jurisdiction
Branches: Presidency; legislature; national
judiciary
Government leader: President, Lt. General Jorge
Rafael Videla, Commander in Chief of the Army,
chosen by the three-man junta that took power on
March 24, 1976
Government structure: the junta, composed of the
chiefs of the three armed services, retains supreme
authority; active duty or retired officers fill all’but two
cabinet posts and administer all provincial and many
local governments; in addition, the military now
oversee the nation’s principal labor confederation and
unions, as well as other civilian pressure groups;
Congress has been disbanded and all political activity
suspended; a nine-man Legislative Council,
composed of senior officers, advises the junta on
lawmaking
Political parties: a number of civilian political
groupings remain potentially influential, despite the
suspension of all partisan activity; these include
Justicialist Party (Peronist coalition that formerly
governed) and the Radical Civic Union, center-left
party providing the chief civilian opposition to the
Peronists; the Moscow-oriented Communist Party
remains legal, but extreme leftist splinter groups have
been outlawed
Communists: some 70,000 members in various
party organizations, including a small nucleus of
activists
Other political or pressure groups: Peronist-
dominated labor movement, General Economic
Confederation (Peronist-leaning association of small
businessmen), Argentine Industrial Union (manufac-
turer''s association), Argentine Rural Society (large
landowner’s association), business organizations,
students, and the Catholic Church
Member of: FAO, GATT, IADB, IAEA, IBRD,
ICAC, ICAO, IDA, IDB, IFC, IHO, ILO, IMCO,
IMF, IOOC, ISO, ITU, IWC—International
Whaling Commission, IWC—International Wheat
Council, LAFTA, OAS, SELA, U.N., UNESCO,
UPU, WCL, WFTU, WHO, WMO, WSG, Non-
Aligned Nations Group','454d741efd5acd2976f4b5b29cbc4be8707f3c60924df6909d71600cf157115e','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cd8dc862f1cbb8fd1c38269d57a572bc7b163e075a23b2b9e32ed713cb364c3d',1977,'AU','Australia','government',30,'Legal name: Commonwealth of Australia
Type: federal state recognizing Elizabeth II as
sovereign or head of state
Capital: Canberra
Political subdivisions: 6 states and 2 territories
(Australian Capital Territory (Canberra) and
Northern Territory)
Legal system: based on English common law;
constitution adopted 1900; High Court has
jurisdiction over cases involving interpretation of the
constitution; accepts compulsory ICJ jurisdiction,
with reservations
Branches: Parliament (House of Representatives
and Senate); Prime Minister and Cabinet responsible
to House; independent judiciary
Government leaders: Governor General Sir John
Kerr; Prime Minister John Malcolm Fraser
Suffrage: universal over age 18
Elections: held at 3-year intervals, or sooner if
Parliament is dissolved by Prime Minister; last
election December 1975
Political parties and leaders: Government—
Liberal Party (Malcolm Fraser) and National Country
Party (Douglas Anthony); opposition—Labour Party
(Gough Whitlam)
Voting strength (1975 Parliamentary election):
lower house: Liberal-Country Coalition, 92 seats;
Labour Party, 35 seats; Senate: Liberal Country
Coalition, 35 seats; Labour, 27 seats; Independents, 2
seats
Communists: 3,900 members (est.)
Other political or pressure groups: Democratic
Labour Party (anti-Communist Labour Party splinter
group)
Member of: ADB, AIOEC, ANZUS, CIPEC
(associate), Colombo Plan, Commonwealth, DAC,
ELDO, ESCAP, FAO, GATT, IAEA, IATP, IBA,
IBRD, ICAC, ICAO, IDA, IEA, IFC, IHO, ILO,
International Lead and Zinc Study Group, IMCO,
IMF, 100C, IPU, ISO, ITC, ITU, IWC—
International Whaling Commission, IWC—lInter-
national Wheat Council, U.N., UNESCO, UPU,
WHO, WMO, WSG','d693a02a48281009e484d89a8a6609ca8bf1d56894fe9323470fe9f895d5bf11','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('21401aa997ef121f667b26849aaca5915cfa0cc1b9bc933adb3d0b58bc1a3192',1977,'AT','Austria','government',36,'Legal name: Republic of Austria
Type: federal republic
Capital: Vienna
Political subdivisions: 9 states (Laender) including
the capital
Legal system: civil law system with Roman law
origin; constitution adopted 1920, repromulgated in
1945; judicial review of legislative acts by a
Constitutional Court; separate administrative and
civil/penal supreme courts; legal education at
Universities of Vienna, Graz, Innsbruck, Salzburg,
and Linz; has not accepted compulsory ICJ
jurisdiction
Branches: bicameral parliament, directly elected
President whose functions are largely representational,
independent federal judiciary
Government leaders: President Rudolf Kirch-
schlaeger, Chancellor Bruno Kreisky leads a one-party
Socialist government
Suffrage: universal over age 19; compulsory for
presidential elections
Elections: presidential, every 6 years (next 1980);
parliamentary, every 4 years (next 1979)
Political parties and leaders: Socialist Party of
Austria (SPOe), Bruno Kreisky, Chairman; Austrian
People’s Party (OeVP), Josef Taus, Chairman; Liberal
Party (FPOe), Friedrich Peter, Chairman; Communist
Party, Franz Muhri, Chairman
Voting strength (1975 election): 50.6% SPOe,
42.7% OeVP, 5.3% FPOe, 1.2% Communist
Communists: membership 25,000 est.; activists
7,000-8,000
Other political or pressure groups: Federal
Chamber of Commerce and Industry; Austrian Trade
Union Federation (primarily socialist); three
composite leagues of the Austrian Peoples Party
(OeVP) representing business, labor, and farmers; the
OeVP-oriented League of Austrian Industrialists;
Roman Catholic Church, including its chief lay
organization, Catholic Action
Member of: ADB, Council of Europe, DAC, ECE,
EFTA, EMA, ESRO (observer), FAO, GATT, IAEA,
IBRD, ICAC, ICAO, IDA, IEA, IFC, ILO,
International Lead and Zinc Study Group, IMF, ITC,
ITU, IWC—International Wheat Council, OECD,
U.N., UNESCO, UPU, WCL, WFTU, WHO, WMO,
WSG
Legal name: The Commonwealth of The Bahamas
Type: independent commonwealth since July 1973,
recognizing Elizabeth II as Chief of State
Capital: Nassau (New Providence Island)
Legal system: based on English law
Branches: bicameral legislature (appointed Senate,
elected House); executive (Prime Minister and
cabinet); judiciary
12
Approved For Release 2005/04/22
Government leaders: Prime Minister Lynden O.
Pindling
Suffrage: universal over age 18; registered voters
(April 1976) 55,452
Elections: House of Assembly (9 September 1972);
next election due constitutionally by late 1977, but
may be called in 1976
Political parties and leaders: Progressive Liberal
Party (PLP), predominantly black, Lynden O.
Pindling; Free National Movement (FNM) formed by
a merger of United Bahamian Party (UBP),
predominantly white, and Free Progressive Liberal
Party (Free PLP), Cecil Wallace-Whitfield
Voting strength (1972 election): PLP 29 seats,
FNM 6 seats, Independents 3 seats; in early 1976 one
PLP member switched to Independent, and one
Independent switched to FNM
Communists: none known
Member of: ILO, IMCO, IMF, U.N., WHO,
WMO
Legal name: State of Bahrain
Type: traditional monarchy; independence
declared in 1971
Capital: Al Manama
Legal system: based on Islamic law and English
common law; constitution went into effect December
1973
Branches: Emir rules with help of a cabinet led by
Prime Minister; a National Assembly, made up of
cabinet and 30 directly elected members, was formed
Approved For Release 2005/04/22
in early 1974; Emir dissolved assembly in August 1975
and suspended the constitutional provision for
election of the assembly
Government leader: Emir ‘Isa ibn Salman Al-
Khalifah
Political parties and pressure groups: political
parties prohibited; no significant pressure groups
although numerous small clandestine groups are
active
Communists: negligible
Member of: Arab League, FAO, GATT (de facto),
IBRD, ICAO, IMF, OAPEC, U.N., UNESCO, WHO','e1096c4408c473fb3c5e283c68844457674a378beeaf7640e4b78ef41d8cf5de','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6fc518dba7107c2e4fd8e66a82becab684078ec7d73fa9d95b045b24073815e0',1977,'BD','Bangladesh','government',41,'Legal name: Peoples Republic of Bangladesh
Type: independent republic since December 1971;
Government of President Sheikh Mujibur Rahman
overthrown in August 1975; two other coups followed;
country currently governed by military-backed
martial law administration with civilian figurehead
president and three military service chiefs as deputy
martial law administrators
Capital: Dacca
Political subdivisions: 19 districts, 413 thanas
(counties), 4,053 unions (village groupings)
Legal system: based on English common law;
constitution adopted December 1972; amended
January 1975 to more authoritarian presidential
system
Branches: constitution provides for unicameral
legislature, strong president: controlled judiciary;
parliament dissolved by current regime
Government leader: President A. M. Sayem; real
power exercised by Deputy Martial Law Administra-
tor General Zia ur-Rahman
Suffrage: universal over age 18
Elections: First Parliament (House of the Nation)
elected in March 1978; elections every 5 years;
Government has lifted previous ban on political
activity and announced its intention to hold elections
in 1977
Communists: 2,500 members (est.)
Other political or pressure groups: 15 political
parties legalized by government as of October 1976,
student groups, bands of former guerrillas
Member of: ADB, Afro-Asian People’s Solidarity
Organization, Colombo Plan, Commonwealth,
ESCAP, GATT, IAEA, IBRD, ICAO, IDA, IMF,
ILO, U.N., UNCTAD, UNESCO, UPU, WHO','aed5e511b37a23d6f220aa37fe0ebcb21d422dba549edde134a1c4b0e5172b53','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('688dc221b78d45af725172b9965c346ddf9330610add0b78017c9e0106959e99',1977,'BB','Barbados','government',45,'Legal name: Barbados
Type: independent sovereign state within the
Commonwealth since November 1966, recognizing
Elizabeth II as Chief of State
Capital: Bridgetown
Political subdivisions: 11 parishes
Legal system: English common law; constitution
came into effect upon independence in 1966; no
judicial review of legislative acts; has not accepted
compulsory ICJ jurisdiction
Branches: legislature consisting of a 21-member
appointed Senate and a 24-member elected House of
Assembly; cabinet headed by Prime Minister
Government leader: Prime Minister J. M. G.
“Tom” Adams
Suffrage: universal over age 18
Elections: House of Assembly members have terms
no longer than 5 years; last general election held 2
September 1976
Political parties and leaders: Democratic Labor
Party (DLP), Errol Barrow; Barbados Labor Party
(BLP), J. M. G. “Tom” Adams
Voting strength (1976 election): Barbados Labor
Party (BLP), 53% Democratic Labor Party, 46% ;
Independent, negligible; House of Assembly seats—
BLP 17, DLP 7
Communists: negligible
Other political or pressure groups: People’s
Progressive Movement (PPM), a small black-
nationalist group led by Calvin Alleyne
Member of: CARICOM, Commonwealth, FAO,
GATT, IADB, ICAO, IDB, ILO, IMCO, IMF, ISO,
ITU, [WC—International Wheat Council, OAS,
SELA, U.N., UNESCO, UPU, WHO, WMO','dc9f1d328203b48b7e22fc5a254a8683416f3d86c53306351c192f672c22cc13','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('21d22c6b5732c15a8888cfc8fffeaeb40703a45ad3c4cdc68bc63560a867267b',1977,'BE','Belgium','government',49,'Legal name: Kingdom of Belgium
Type: constitutional monarchy
Capital: Brussels
Political subdivisions: 9 provinces
Legal system: civil law system influenced by
English constitutional theory; constitution adopted
1831, since amended; judicial review of legislative
acts; legal education at 4 law schools; accepts
compulsory ICJ jurisdiction, with reservations
Branches: executive branch consists of King and
cabinet; cabinet responsible to bicameral parliament;
independent judiciary; coalition governments are
usual
Government leader: Head of State, King
Baudouin; Prime Minister Leo Tindemans
Suffrage: universal over age 21
Elections: held 10 March 1974 (held at least once
every 4 years)
Political parties and leaders: Social Christian,
Charles-Ferdinand Nothomb and Wilfred Martens,
co-presidents; Socialist, Andre Cools and Willy Claes,
co-presidents; Liberty and Progress, Senator P.
Deschamps, national president; Liberal Democratic
: CIA-RDP79-01051A000800010006-3
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
January 1977
BELGIUM/BELIZE
and Pluralist Party, Rolland Gillet, party president;
Francophone Democratic Front-Walloon Rally
(Walloon nationalist), Leo Defosset, national
president; Volksunie (Flemish Nationalist), Hugo
Schlitz, party president; Communist, Louis Van Gent,
president of political bureau
Voting strength (1974 election): 72 seats Social
Christian, 59 seats Socialist, 30 seats Liberty and
Progress, 22 seats Volksunie, 22 seats Francophone
Democratic Front-Walloon Rally, 4 seats Communist,
3 seats Democratic and Pluralist
Communists: 10,000 members (est. )
Other political or pressure groups: Christian and
Socialist Trade Unions; the Federation of Belgium
Industries; numerous other associations representing
bankers, manufacturers, middle-class artisans, and the
legal and medical professions; two major organiza-
tions represent the cultural interests of Flanders and
Wallonia
Member of: ADB, Benelux, BLEU, Council of
Europe, DAC, EC, ECE, ECOSOC, ECSC, EEC,
EIB, ELDO, EMA, ESRO, EURATOM, FAO,
GATT, IAEA, IBRD, ICAC, ICAO, IDA, IEA, IFC,
ILO, International Lead and Zinc Study Group,
IMCO, IMF, IOOC, IPU, ITU, NATO, OAS
(observer), OECD, U.N., UNESCO, UPU, WCL,
WEU, WHO, WMO, WSG','670c42e4ec30d13efcb51630423bd87071b6874d9ff5415fce2b142f3b43bf33','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('dd86332c24c735dc53eec1ae1f578856a387b11b6c18c78de285f2201a7afd07',1977,'BZ','Belize','government',53,'Legal name: Belize
Type: internal self-governing British colony
Capital: Belmopan
Legal system: English law; constitution came into
force in 1964, although country remains a British
colony
Branches: 18-member elected National Assembly
and 8-member Senate (either house may choose its
speaker or president, respectively, from outside its
elected membership); cabinet; judiciary
Government leader: Premier George Price
Suffrage: universal adult (probably 21)
Elections: must be held within 5 years of last
elections held in October 1974
18
Political parties and leaders: People’s United
Party (PUP), George Price; United Democratic Party
(UDP), a coalition comprised of the National
Independence Party (NIP) led by Philip Goldson, the
People’s Democratic Union (PDM) led by Dean
Lindo, and the Liberal Party (LP) led by Harry
Lawrence; Corozal United Front (CUF), Santiago
Ricalde; United Black Association for Development
(UBAD), Evan X. Hyde
Voting strength (National Assembly): PUP 12
seats, UDP 6 seats
Communists: negligible
Other political or pressure groups: Christian
Workers’ Union (CWU) which is connected with PUP
Member of: CARICOM, ISO, WCL','64f29ebd4fb4872f6e95a0313acbf03dac38c01db62ef56d91f2aa726afd79c4','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4b83753e805f7b45bfd7b78366e6195fe7a6ad68f758b83b3cfe96cd294ac86a',1977,'BJ','Benin','government',57,'Legal name: Peoples Republic of Benin
Type: party state, under military rule since 26
October 1972
Capital: Porto-Novo (official), Cotonou (de facto)
Political subdivisions: 6 provinces, 46 districts
Legal system: based on French civil law and
customary law; legal education generally obtained in
France; has not accepted compulsory ICJ jurisdiction
Branches: National Revolutionary Council,
Council of Ministers, Central Committee of Party
Government leader: Lt. Col. Mathieu Kerekou,
President and chief of government, charged with
national defense, planning, coordination of external
aid, information, and national orientation
Suffrage: suspended
Elections: current government has held no
elections and none are scheduled
Political parties: People’s Revolutionary Party of
Benin established in 1975
Communists: sole party espouses Marxism-
Leninism
Member of: AFDB, CEAO, EAMA, ECA,
ECOWAS, Entente, FAO, GATT, IBRD, ICAO, IDA,
ILO, IMF, ITU, Niger River Commission, OAU,
OCAM, U.N., UNESCO, UPU, WCL, WFTU,
WHO, WMO','1a26d8b0aab8eae6bed0df60bd0446a01b3e8271cdf70240bd3c6b6ba4502ea5','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a51036a61e49ccbbf22ba9264d7cb6a5f4534dc07ab8820aae17405b14f1eeeb',1977,'BM','Bermuda','government',61,'Legal name: Colony of Bermuda
Type: British colony
Capital: Hamilton
Political subdivisions: 9 parishes
Legal system: English law
Branches: Executive Council (cabinet) appointed
by governor, led by government leader; bicameral
legislature with an appointed Legislative Council,
and a 40-member directly elected House of Assembly
Government leaders: Governor Sir Edwin Leather;
Government Leader (equivalent to Premier) Sir
Edward Richards
Suffrage: universal over age 21
Elections: at least once every 5 years: last general
election, June 1972
Political parties and leaders: United Bermuda
Party (UBP), John Henry Sharpe; Progressive Labor
Party (PLP), Walter N.H. Robinson
Voting strength (1972 elections): UBP 61.2%, PLP
38.8%; House of Assembly seats—UBP 30, PLP 10
Communists: negligible
Other political or pressure groups: Bermuda
Industrial Union (BIU)','5bab0e7a02cbebc9aeced8dba5ce80c330309e8e88ef224e91a8dca86eba8ae8','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d17b9371149c88dc83c407357a5550ec4e421ad44900518d0fea23c777068a7d',1977,'BT','Bhutan','government',65,'Legal name: Kingdom of Bhutan
Approved For Release 2005/04/22 :
Type: monarchy; special treaty relationship with','37d5fb91305965d16d5a7b0e854728a491dfbb51df90160e49f28ba3583c00b4','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b5e8c3118c1fd473f828a1399fc57c3286155f5185a6665ea2f0ff619de664f0',1977,'IN','India','government',66,'Capital; Thimphu
Political subdivisions: 4 regions (east, central,
west, south), further divided into 15-18 subdivisions
Legal ‘system: based on Indian law and English
common law; in 1964 the monarch assumed full
power—no constitution existed beforehand; a
Supreme Court hears appeals from district ad-
ministrators; has not accepted compulsory IC]
jurisdiction
Branches: appointed Minister and indirectly
elected Assembly consisting of village elders, monastic
representatives, and all district and senior government
administrators
Government leader: King Jigme Singhi Wangchuk
Suffrage: each family has one vote
Elections: popular elections on village level held
every 3 years
Political parties: all parties illegal
Communists: no overt Communist presence
Other political or pressure groups: Buddhist
clergy
Member of: Colombo Plan, UPU, U.N.
Legal name: Republic of Bolivia
Type: republic; de facto military dictatorship
Capital: La Paz (seat of government); Sucre
(judicial capital)
Political subdivisions: 9 departments with limited
autonomy
Legal system: based on Spanish law and Code
Napoleon; constitution adopted 1967; constitution in
force except where contrary to dispositions dictated by
governments since 1969; legal education at University
of San Andres and several others; has not accepted
compulsory ICJ jurisdiction
Branches: executive; congress of two chambers
(Senate and Chamber of Deputies), congress
22
disbanded after 26 September 1969 ouster of President
Siles; judiciary
Government leaders: President Hugo Banzer
Suarez
Suffrage: universal and compulsory at age 18 if
married, 21 if single
Elections: postponed indefinitely
Political parties and leaders: political activities are
proscribed indefinitely; most party leaders are in exile
Voting strength (1966 elections): Frente de la
Revolucion Boliviana (a coalition composed of the
MPC, PIR, PRA, PSD, and two interest groups, the
campesinos and Chaco War Veterans) 61%, FSB 12%,
MNR 10%, other 17%
Communists: three parties (all proscribed);
PCB/Soviet led by Jorge Kolle Cueto, about 300
members; PCB/Chinese led by Oscar Zamora, 150
(including 100 in exile); POR (Trotskyist), about 50
members divided between three factions led by Hugo
Gonzalez Moscoso, Guillermo Lora Escobar, and
Amadeo Arze
Member of: FAO, IAEA, IADB, IATP, IBRD,
ICAO, IDA, IDB, IFC, ILO, IMF, ISO, ITC, ITU,
IWC—International Wheat Council, LAFTA and
Andean Sub-Regional Group (created in May 1969
within LAFTA), OAS, SELA, U.N., UNESCO, WCL,
WHO, WMO
Legal name: Republic of India
Type: federal republic
Capital: New Delhi
Political subdivisions: 22 states, 9 union territories
Legal system: based on English common law;
constitution adopted 1950; limited judicial review of
legislative acts; accepts compulsory ICJ jurisdiction,
with reservations
Branches: parliamentary government, national and
state; relatively independent judiciary
Government leader: Prime Minister Indira
Gandhi
Suffrage: universal over age 21
Elections: national and state elections ordinarily
held every 5 years; may be postponed in emergency
and may be held more frequently if government loses
confidence vote; posponed general election due in
March 1977 but may be further delayed because of a
national emergency declared on June 26, 1975; most
states due to hold state elections in 1977
Political parties and leaders: Indian National
Congress split into two factions in 1969, largest faction
(the Ruling Congress) loyal to Prime Minister Gandhi
led by D. K. Barooah, and dwindling faction (the
Organization Congress) led by Ashoka Mehta;
Communist Party of India (CPI), S. A. Dange,
chairman; Communist Party of India/ Marxist
(CPI/M), P. Sundarayya, general secretary;
Communist Party of India/Marxist-Leninist (CPI/
ML); Bharatiya Jana Sangh, U. L. Patil, acting
president; the Socialist Party, George Fernandes,
chairman; Dravida Munnetra Kazhagam (DMK),
N. Karunanidhi, president; Bharatiya Lok Dal
(BLD), Charan Singh, chairman
Voting strength (1971 election): 43.7% Ruling
Congress, 10.5% Organization Congress, 7.4%
Bharatiya Jana Sangh, 3.1% Swatantra, 4.8% CPI,
5.2% CPI/M, 3.5% Socialist Parties, 3.7% DMK,
18.1% other
Communists: 90,000 members of CPI (est.), 85,000
members of CPI/M (est.); Communist sympathizers,
13 million
Other political or pressure groups: Anna Dravida
Munnetra Kazhagam (ADMK), M. G. Rama-
chandran, president, opposing DMK in Tamil Nadu;
splintered Akali Dal representing Sikh religious
community in the Punjab; various separatist groups
seeking reorganization of states; numerous “senas’’ or
militant/chauvinistic organizations, including Shiv
Sena and Dalit Panthers in Bombay, the Anand Marg,
and the Rashtriya Swayamserak Sangh
Member of: ADB, AIOEC, Colombo Plan,
Commonwealth, FAO, GATT, IAEA, IBRD, ICAC,
ICAO, IDA, IFC, IHO, ILO, International Lead and
Zinc Study Group, IMCO, IMF, IPU, ITC, ITU,
IWC—lInternational Wheat Council, U.N., UNES-
CO, UPU, WCL, WFTU, WHO, WMO, WSG','636ef45c528847019b6432fa149a8d880faed49a14e41877fccbd4e228f1f7de','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('80c7c6740875de22897a77adbbfb6ca9be542974936de3aba12ff96eddc90dd0',1977,'BW','Botswana','government',72,'Legal name: Republic of Botswana
Type: parliamentary republic; independent
member of Commonwealth since 1966
Capital: Gaborone
Political subdivisions: 12 administrative districts
Legal system: based on Roman-Dutch law and
local customary law; constitution came into effect
1966; judicial review limited to matters of
interpretation; legal education at University of
Botswana, Lesotho and Swaziland (2% years) and
University of Edinburgh (2 years); has not accepted
compulsory ICJ jurisdiction
Branches: executive—President appoints and
presides over the cabinet which is responsible to
Legislative Assembly; legislative—Legislative Assem-
bly with 82 popularly elected members and 4
members elected by the 82 representatives, House of
Chiefs with deliberative powers only; judicial—local
courts administer customary law, High Court and
subordinate courts have criminal jurisdiction over all
residents, Court of Appeal has appellate jurisdiction
Government leader: President Seretse Khama
Suffrage: universal, age 21 and over
Elections: general elections held 26 October 1974
Political parties and leaders: Botswana Demo-
cratic Party (BDP), Seretse Khama; Bechuanaland
People’s Party (BPP), Philip Matante; Botswana
Independence Party (BIP), Motsamai Mpho;
Botswana National Front (BNF), Kenneth Koma
23
CIA-RDP79-01051A000800010006-3
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
January 1977
BOTSWANA/BRAZIL
Voting strength: (October 1974 election) BDP (27
seats); BPP (2 seats); BNF (2 seats); BIP (1 seat)
Communists: no known Communist organization;
Koma of BNF has long history of Communist contacts
Member of: AFDB, Commonwealth, FAO, GATT
(de facto), IBRD, IDA, IMF, ITU, OAU, U.N., UPU,
WMO','a5325054dad27f36164d8c0087b0c6188fcf9b9316c632c33f5de6cfabcc7610','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d4e2c829e9d53ad88f5fb20cdb03ca13f2999b9f2a70fbc2be6545c7bbff661e',1977,'BR','Brazil','government',76,'Legal name: Federative Republic of Brazil
Type: federal republic; military-backed presiden-
tial regime since April 1964
Capital: Brasilia
Political subdivisions: 21 states, 4 territories,
federal district (Brasilia)
Legal system: based on Latin codes; dual system of
courts, state and federal; constitution adopted 1967
and extensively amended in 1969; has not accepted
compulsory ICJ jurisdiction
Branches: strong executive with very broad powers;
bicameral legislature (powers of the two bodies have
been sharply reduced); 11-man Supreme Court
Government leader: President Ernesto Geisel
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
January 1977
BRAZIL/BRITISH SOLOMON ISLANDS
Suffrage: compulsory over age 18, except illiterates
and those stripped of their political rights;
approximately 30 million registered voters in October
1970
Elections: President Medici’s successor was chosen
by a 505-member electoral college, composed of the
members of Congress and delegates selected from the
state legislatures, on 15 January 1974 and took office
on 15 March 1974; Geisel was the choice of Medici
and top military chiefs
Voting strength: (November 1974 congressional
elections) 33.6% ARENA, 31.9% MDB, 35.5% blank
and void
Political parties and leaders: National Renewal
Alliance (ARENA), pro-government Francelino
Pereira, president; Brazilian Democratic Movement
(MDB), opposition, Ulisses Guimaraes, president
Communists: 6,000, 1,000 militants
Other political or pressure groups: excepting the
military, the Catholic Church is the only active
nationwide pressure group, however, divisions within
the Church often prevent it from speaking with one
voice; labor and student groups have almost no
influence on the government
Member of: FAO, GATT, IADB, IAEA, IBRD,
ICAC, ICAO, IDA, IDB, IFC, THO, ILO, IMCO,
IMF, IPU, ISO, ITU, IWC—International Wheat
Council, LAFTA, OAS, SELA, U.N., UNESCO,
UPU, WCL, WFTU, WHO, WMO
Legal name: British Solomon Islands Protectorate
Type: British protectorate administered as crown
colony, became self-governing January 1976
Capital: Honiara
Political subdivisions: 4 administrative districts
Legal system: a High Court plus Magistrates
Courts, also a system of native courts throughout the
islands
Branches: executive authority in High Commis-
sioner; a legislative assembly of 24 elected members, a
few appointed members
Government leaders: Governor D.C.C. Ludding-
ton and Chief Minister Kenilorea
Suffrage: universal age 21 and over
Elections: every 4 years, latest June 1976
Political parties and leaders: United Solomon
Islands Party
Member of: ADB
Legal name: State of Brunei
Type: British protectorate; constitutional sultanate
Capital: Bandar Seri Begawan
Political subdivisions: 4 administrative districts
Legal system: based on Islamic law; constitution
promulgated by the Sultan in 1959
Branches: Chief of State is Sultan (advised by
appointed Privy Council) who appoints Executive
Council and Legislative Council
Government leader: Sultan Hassanal Bolkiah
Suffrage: universal age 21 and over; 3-tiered system
of indirect elections; popular vote cast for lowest level
(district councilors)
Elections: last elections—March 1965; further
elections postponed indefinitely
Political parties and leaders: antigovernment,
exiled Brunei People’s Party, Chairman A. M. N.
Azahari
Communists: information not available','7df5b22e4e9d2696ac1116755d92a01b169f94ef69e5bf7607c67465ae711bbd','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('820dca8c8400f519226881c3ab8157f04cad4bc69256dbe782d03d421f3a0797',1977,'BG','Bulgaria','government',80,'Legal name: Peoples Republic of Bulgaria
Type: Communist state
Capital: Sofiya
Political subdivisions: 28 okrugs (districts),
including capital city of Sofia
Legal system: based on civil law system, with
Soviet law influence; new constitution adopted in
1971; judicial review of legislative acts in the: State
Council; legal education at University of Sofiya; has
accepted compulsory ICJ jurisdiction
Branches: legislative, National Assembly; judici-
ary, Council of Ministers
Government leaders: Todor Zhivkov, Chairman,
State Council (President and chief of state); Stanko
Todorov, Chairman, Council of Ministers (premier)
Suffrage: universal and compulsory over age 18
Elections: theoretically held every 5 years for
National Assembly; last elections held on 20 May
1976; 99.85% of the electorate voted
Political parties and leaders: Bulgarian Com-
munist Party, Todor Zhivkov, First Secretary;
Bulgarian National Agrarian Union, a puppet party,
Petur Tanchev, secretary
Communists: 788,211 party members (December
1975)
Mass organizations and front groups: Fatherland
Front, Dimitrov Communist Youth League, Central
Council of Trade Unions, National Committee for
Defense of Peace, Union of Fighters Against Fascism
and Capitalism, Committee of Bulgarian Women,
All-National Committee for Bulgarian-Soviet
Friendship
Member of: CEMA, FAO, IAEA, ICAO, ILO,
International Lead and Zinc Study Group, IMCO,
IPU, ITU, !WC—International Wheat Council,
U.N., UNESCO, UPU, WFTU, WHO, WMO,
Warsaw Pact, International Organization of
Journalists, International Medical Association,
International Radio and Television Organization
Legal name: Socialist Republic of the Union of
Burma
Type: republic under 1974 constitution
Capital: Rangoon
Political subdivisions: seven divisions and seven
constituent states; subdivided into townships, villages,
and wards
Legal system: People’s Justice system and People’s
Courts instituted under 1974 constitution; legal
education at Universities of Rangoon and Mandalay;
has not accepted compulsory IC] jurisdiction
Branches: State Council rules through a Council of
Ministers; People’s Assembly has legislative power
Government leader: Chairman of State Council
and President, Gen. U. Ne Win
Suffrage: universal over age 18
Elections: People’s Assembly and local People’s
Councils elected in 1974
Political parties and leaders: government-
sponsored Burma Socialist Program Party only legal
party
Communists: estimated 5,000-8,000
Other political or pressure groups: People’s
Patriotic Party; Kachin Independence Army; Karen
Nationalist Union, several Shan factions
Member of: ADB, Colombo Plan, FAO, GATT,
IAEA, IBRD, ICAO, IDA, IFC, IHO, ILO, IMCO,
IMF, ITU, U.N., UNESCO, UPU, WHO, WMO','8e3a979eb716e2c5559b94d8d23a6f6a3c6571c78301777e6b031ed985103c7e','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d410254e098533fd4b63537aa0006c5a09fb95aff722aecc290c774a801f3070',1977,'BI','Burundi','government',85,'Legal name: Republic of Burundi
Type: republic; military government overthrown
by military coup, November 1976; constitution
abolished
Capital: Bujumbura
Political subdivisions: 8 provinces, subdivided into
18 arrondissements and 78 communes; Bujumbura
city (population est. 60,000) has status equal to a
province
Legal system: based on German and French civil
codes and customary law; has not accepted
compulsory ICJ jurisdiction
Branches: Supreme Revolutionary Council js
governing body
Government leader: Col. Jean Bagaza, Chairman
of Supreme Revolutionary Council, established
November 1976
Elections: last legislative election May 1965;
legislature dissolved in 1966
Political parties and leaders: National Party of
Unity and Progress (UPRONA), a predominantly
Tutsi party, declared sole legitimate party in 1966,
was abolished in November 1976
Communists: no Communist party; resumed
diplomatic relations with the Peoples Republic of
China in October 1971 following a_ six-year
suspension; U.S.S.R., North Korea, and Romania also
have diplomatic missions in Burundi
Member of: AFDB, EAMA, ECA, FAO, GATT,
IBRD, ICAO, IDA, ILO, IMF, ITU, OAU, U.N.,
UNESCO, UPU, WHO, WMO','e7961e3e580a8abcd1af2187aa48d7e5a214abc834502c5bdeb1a2140e1c228f','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bbec28f6a65ae0df3ed56400123c734dbc7cad35b37b73750241cca2872fbc5a',1977,'KH','Cambodia','government',89,'Legal name: Democratic Cambodia
Type: republic
Capital: Phnom Penh
Legal system: Tribunal Committee chosen by
People’s Representative Assembly
Branches: State Presidium, composed of chairman
and two vice chairmen; nine-member cabinet, totally
Communist, announced on 14 April; 250-member
People’s Representative Assembly elected 20 March
for 5-year term; ten-member Assembly Standing
Committee
Government leader: Presidium Chairman, Khieu
Samphan; Prime Minister, Pol Pot; Deputy Prime
Ministers, Ieng Sary, Vorn Vet, Son Sen; Assembly
Standing Committee Chairman, Nuon Chea; “high
counselor,” Penn Nouth, is only remaining symbol of
non-Communist participation in government
Suffrage: universal over age 18
Political parties and leaders: political life
dominated by Khmer Communist Party and panoply
of mass front organizations
Communists: party strength about 10,000
Other political or pressure groups: none
Member of: U.N.','30594df50b09b9c2b79b695431391c978e13ad6467e2d409a4d975c4d08e08fb','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('44feca42ff0d660119a23b5c829b40191e2c13fb4175e1a78988ecee210b4149',1977,'GN','Guinea','government',92,'Legal name: United Republic of Cameroon
Type: unitary republic; one-party presidential
regime
Capital: Yaounde
Political subdivisions: 7 provinces divided into 39
departments
Legal system: based on French civil law system,
with common law influence; new unitary constitution
adopted 1972; judicial review in Supreme Court,
when a question of constitutionality is referred to it by
the President of the Republic; has not accepted
compulsory ICJ jurisdiction
Branches: executive, legislative, and judicial
Government leader: President Ahmadou Ahidjo
Suffrage: universal over age 21
Elections: presidential elections held 5 April 1975;
parliamentary elections last held 18 May 1973
Political parties and leaders: single party,
Cameroonian National Union (UNC), President
Ahmadou Ahidjo
Communists: no Communist Party or significant
number of sympathizers
Other political or pressure groups: Cameroon
Peoples Union (UPC), an illegal terrorist group now
reduced to scattered acts of banditry with its factional
leaders in exile
Member of: AFBD, EAMA, ECA, EIB (associate),
FAO, GATT, IAEA, IBRD, ICAC, ICAO, IDA, IFC,
ILO, IMCO, IMF, IPU, ISO, ITU, Lake Chad Basin
Commission, Niger River Commission, OAU, OCAM,
UDEAC, U.N., UNESCO, UPU, WHO, WMO
Legal name: Republic of Guinea
Type: republic; under one-party presidential
regime
Capital: Conakry
Political subdivisions: 29 administrative regions,
209 arrondissements, about 8,000 local entities at
village level
Legal system: based on French civil law system,
customary law, and presidential decree; constitution
adopted 1958; no constitutional provision for judicial
review of legislative acts; has not accepted compulsory
IC] jurisdiction
Branches: executive branch dominant, with power
concentrated in President’s hands and a small group
who are both ministers and members of the party''s
politburo; unicameral National Assembly and
judiciary have little independence
Government leader: President Ahmed Sekou
Toure, whe has been designated ‘““The Supreme
Leader of the Revolution”’
Suffrage: universal over age 18
Elections: approximate schedule—5 years par-
liamentary, latest in 1975; 7 years presidential, latest
in 1975
Political parties and leaders: only party is
Democratic Party of Guinea (PDG), headed by Sekou
Toure
85
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
January 1977
GUINEA/GUINEA-BISSAU
Communists: no Communist party, although there
are some sympathizers
Member of: AFDB, ECA, ECOWAS, FAO, IBA,
IBRD, ICAO, IDA, ILO, IMF, ITU, Niger River
Commission, OAU, U.N., UNESCO, UPU, WCL,
WHO, WMO
Legal name: Republic of Ivory Coast
Type: republic, one-party presidential regime
established 1960
Capital: Abidjan
Political subdivisions: 24 departments subdivided
into 127 subprefectures
Legal system: based on French civil law system
and customary law; constitution adopted 1960;
judicial review in the Constitutional Chamber of the
Supreme Court; legal education at Abidjan School of
Law; has not accepted compulsory ICJ jurisdiction
Branches: President has sweeping powers,
unicameral legislature, separate judiciary
Government leader: President Felix Houphouet-
Boigny
Suffrage: universal over age 21
Elections: uncontested Presidential and legislative
elections held in November 1975 for 5-year term
Political parties and leaders: Parti Democratique
de la Cote d‘Ivoire (PDCI), (only party); official party
leader is Secretary General Philippe Yace, but
Houphouet-Boigny is in control
Communists: no Communist party; possibly some
sympathizers
Member of: AFDB, CEAO, EAMA, ECA,
ECOWAS, EIB (associate), Entente, FAO, GATT,
IAEA, IBRD, ICAO, IDA, IFC, ILO, IMCO, IMF,
IPU, ITU, Niger River Commission, OAU, OCAM,
U.N., UNESCO, UPU, WHO, WMO','5d56a58f1f1e7afe0c00b817da0cbe529397b3cdefa6ae0f6e50404038ffe484','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4399b12181506cc78104fb4d3290c39d849321405d06d443f78fee1a16f7d7dd',1977,'CA','Canada','government',95,'Legal name: Canada
Type: federal state recognizing Elizabeth II as
sovereign
Capital: Ottawa
Political subdivisions: 10 provinces and 2
territories
Legal system: based on English common law,
except in Quebec, where civil law system based on
French law prevails; constitution is British North
America Act of 1867 and various amendments;
accepts compulsory ICJ jurisdiction, with reservations
Branches: federal executive power vested in cabinet
collectively responsible to House of Commons, and
headed by Prime Minister; federal legislative
authority resides in Parliament consisting of Queen
represented by Governor-General, Senate, and
Commons; judges appointed by Governor-General on
the advice of the government; Supreme Court is
highest tribunal
Government leader: Pierre Elliott Trudeau
Suffrage: universal over age 18
Elections: legal limit of 5 years but in practice held
at least every 4 years, last election July 1974
33
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
January 1977
CANADA/CAPE VERDE
Political parties and leaders: Liberal, Pierre
Trudeau; Progressive-Conservatives, Joe Clark: New
Democratic, Edward Broadbent; Social Credit, Real
Caouette
Voting strength (1974 election): Liberal 43% (139
seats), Progressive Conservative 35% (96 seats), New
Democratic Party 16% (16 seats), Social Credit 5% (11
seats), other 1%, Independents hold 1 seat, 2 seats
unoccupied
Communists: 2,000 approx.
Member of: ADB, Colombo Plan, Common-
wealth, DAC, FAO, GATT, IAEA, IBRD, ICAO,
ICRC, IDA, IDB, IEA, IFC, IHO, ILO, International
Lead and Zinc Study Group, IMCO, IMF, IPU, ISO,
ITU, IWC—International Whaling Commission,
IWC—International Wheat Council, NATO, OAS
(observer), OECD, U.N., UNCTAD, UNESCO, :
UPU, WCL, WHO, WMO, WSG
Legal name: Republic of Cape Verde
Type: republic; achieved independence from
Portugal in July 1975
Capital: Praia
Political subdivisions: 10 islands
Legal system: to be determined
Branches: National Assembly, 56 members; the
official party is the supreme political institution
Government leaders: President, Aristides Pereira;
Prime Minister, Pedro Pires; Minister of Foreign
Affairs, Abilio Duarte
Suffrage: universal over age 18
Elections: to be determined
Political parties and leaders: Partido Africano da
Independencia da Guinee e Cabo Verde (PAIGC), led
by Aristide Pereira, only legal party
Communists: none known
Member of: OAU, U.N.
Legal name: Central African Empire
Type: parliamentary monarchy—founded on a
single party
Capital: Bangui
Political subdivisions: 14 prefectures, 47 subpre-
fectures
Legal system: based on French, Islamic, and tribal
law; in 1966 the Chief of State assumed all power and
abrogated the existing constitution; has not accepted
compulsory ICJ jurisdiction
Branches: Marshall Bokassa heads government and
rules by decree; assisted by cabinet called Council of
Ministers; judiciary, including Supreme Court, court
of appeals, criminal court, and numerous lower courts
Government leader: Emperor Salah Ad-Din
Ahmad Bokassa I
Suffrage: universal over age 21
Elections: none have been held under Bokassa
regime
Political parties and leaders: Movement for the
Social Evolution of Black Africa (MESAN), ruling
party under former regime, still in existence but plays
little role, led by Emperor Salah Ad-Din Ahmad
Bokassa
Communists: no Communist Party or significant
number of sympathizers
Member of; AFDB, Conference of East and
Central African States, EAMA, ECA, FAO, GATT,
IBRD, ICAO, IDA, ILO, IMF, ITU, OAU, OCAM,
UDEAC, U.N., UNESCO, UPU, WCL, WHO,
WMO','5c2d519434f83918c4479528809e147db3ecfae67b1e3912d106cf5af3a13ff0','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4a4c057042447848faa4eaf9f7c5ba8b15ece5dbcf53243b7f82014b13153878',1977,'TD','Chad','government',99,'Legal name: Republic of Chad
Type: republic; military regime in power since
April 1975
Capital: N''Djamena
Political subdivisions: 14 prefectures
Legal system: based on French civil law system
and Chadian customary law; constitution adopted
1962; constitution suspended and national assembly
dissolved April 1975; judicial review of legislative acts
in theory a power of the Supreme Court; has not
accepted compulsory ICJ jurisdiction
Approved For Release 2005/04/22 :
Branches: executive authority exercised by
Supreme Military Council composed of 9 officers
Government leader: President of Supreme Military
Council, General Felix Malloum
Suffrage: universal over age 20
Elections: all political activity banned
Political parties and leaders: political parties
banned
Communists: no front organizations or un-
derground party; probably a few Communists and
some sympathizers
Other political or pressure groups: lightly armed
Muslim rebel bands have been opposing the
government since October 1965 in east-central and
since August 1969 in northern Chad
Member of: AFDB, Conference of East and
Central African States, EAMA, ECA, FAO, GATT,
ICAC, ICAO, IBRD, IDA, IMF, ITU, Lake Chad
Basin Commission, OAU, UEAC, U.N., UNESCO,
UPU, WCL, WHO, WMO','346b0a7a411a97e39a1c99b0d744e3d76a6155a58c71193948154bb536cde8ab','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ce3ffd0267d4eb61582bda671cd9bff9d3a4618861a4fd49394c5dc6f3fb6488',1977,'CL','Chile','government',103,'Legal name: Republic of Chile
Type: republic
Capital: Santiago
Political subdivisions: reorganization of regional
structure in progress
Legal system: based on Code 1857 derived from
Spanish law and subsequent codes influenced by
French and Austrian law; constitution adopted 1925,
amended since then, currently being revised; judicial
review of legislative acts in the Supreme Court; legal
education at University of Chile, Catholic University,
and several others; has not accepted compulsory IC]
jurisdiction
Branches: President and 4-man Military-Police
Junta; bicameral legislature currently dissolved;
independent judiciary
Government leader: President, Gen. Augusto
PINOCHET Ugarte; other Junta members, Adm. Jose
Toribio MERINO Castro, Gen. Gustavo LEIGH
Guzman, Gen. Cesar MENDOZA Duran
Suffrage: universal (except enlisted military and
police) and compulsory at age 18
Elections: none scheduled
Political parties and leaders: Christian Demo-
cratic Party (PDC), Patricio Aylwin and Eduardo
Frei; National Party (PN), Sergio Onofre Jarpa; PDC
and PN are officially in “recess”; Popular Unity
coalition parties (outlawed)—Communist Party
(PCCh), Luis Corvalan (in prison); Socialist Party
(PS), Clodomiro Almeyda and Carlos Altamirano
(both in exile); Radical Party (PR); Christian Left
(IC); United Popular Action Movement (MAPU);
Independent Popular Action (API)
Voting strength (1970 presidential election):
36.6% Popular Unity coalition, 35.3% conservative
independent, 28.1% Christian Democrat; (1973
Congressional election) 44% Popular Unity coalition,
56% Democratic Confederation (PDC and PN)
Communists: 200,000
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
January 1977
CHILE/CHINA, PEOPLES REPUBLIC OF
Other political or pressure groups: organized
labor; business organizations; landowners’ associa-
tions (SNA—Sociedad Nacional de Agricultura);
extreme leftist, Movement of Revolutionary Left
(MIR), outlawed; rightist, Patria y Libertad (PyL),
outlawed
Member of: AJOEC, CIPEC, ECOSOC, FAO,
GATT, IADB, IAEA, IBRD, ICAO, IDA, IDB, IFC,
IHO, ILO, IMCO, IMF, IPU, ITU, LAFTA, OAS,
SELA, U.N., UNESCO, UPU, WCL, WHO, WMO,
WSG
Legal name: Peoples Republic of China
Type: Communist state; real authority lies with
Communist party’s political bureau; the National
People’s Congress, in theory the highest organ of
government, in reality merely rubber stamps the
party''s programs; the State Council is the actual
governing organism
Capital: Peking
Political subdivisions: 21 provinces, 3 centrally
governed municipalities, and 5 autonomous regions
Legal system: before 1966, a complex amalgam of
custom and statute, largely criminal; little ostensible
development of uniform code of administrative and
civil law; highest judicial organ is Supreme People’s
Court although legal activity centered in parallel
network of Public Security organs; laws and legal
procedure clearly subordinated to priorities of party
policy; whole system largely suspended during
Cultural Revolution, but gradually being revived
Branches: prior to 1966 control was exercised by
Chinese Communist Party, through State Council,
which supervised more than 50 ministries, commis-
sions, bureaus, etc., all technically under the standing
committee of the National People’s Congress; this
system broke down under “Cultural Revolution”
pressures but has been reconsolidated and streamlined
to 29 ministries
Government leader: Premier of State Council,
Hua Kuo-feng; government subordinate to central
committee of CCP, under Chairman Hua Kuo-feng
Suffrage: universal over age 18, though this is
academic
40
Elections: no meaningful elections
Political parties and leaders: Chinese Communist
Party (CCP), headed by Hua Kuo-feng; Hua is
Chairman of Central Committee; a new central
committee was formed at the 10th Party Congress
held in August 1973
Voting strength: 100% Communist for practical
purposes; no political nonconformity permitted
Communists: about 380 million party members in
1973 ;
Other political or pressure groups: army (PLA)
remains a major force, although many soldiers who
acquired a wide range of civil political-administrative
duties during the Cultural Revolution have been
removed; many veteran civilian officials, in eclipse
since the Cultural Revolution, have been reinstated;
mass organizations, such as the trade unions and the
youth league, have been rebuilt in the provinces;
plans are underway to rebuild the national
organizations
Member of: FAO, IAEA, IBRD, ICAO, IDA, IFC,
IHO, ILO, IMCO, IMF, ITU, Red Cross, U.N.,
UNESCO, UPU, WFTU, WHO, WMO, other
international bodies','a427d579de8f874c7b81acd6004c7e3aaefda9bfe20830ebab347941e2204af7','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('817dc5663f3aba342a43263a62d99f580ad0a63010a155198003e6ba9ff06039',1977,'CN','China','government',107,'Legal name: Republic of China
Type: republic; one-party presidential regime
Capital: Taipei
Political subdivisions: 16 counties, 4 cities, 1
special municipality (Taipei)
Legal system: based on civil law system;
constitution adopted 1947, amended 1960 to permit _
Chiang Kai-shek to be reelected, and amended 1972
to permit President to restructure certain government
organs; accepts compulsory ICJ jurisdiction, with
reservations
Branches: 5 independent branches (executive,
legislative, judicial, plus traditional Chinese functions
of examination and control), dominated by executive
branch; President and Vice President elected by
National Assembly
Government leaders: President Yen Chia-kan;
Premier Chiang Ching-kuo
Suffrage: universal over age 20
Elections: national level—legislative yuan every 3
years but no general election held since 1948 election
on mainland (partial elections for Taiwan province
representatives December 1969, December 1972, and
December 1975); local level—provincial assembly,
county and municipal executives every 4 years;
county and municipal assemblies every 4 years
Political parties and leaders: Kuomintang, or
National Party, led by Chairman Chiang Ching-kuo,
has no real opposition; 2 insignificant parties are
Democratic Socialist Party, Young China Party
Voting strength (1972 provincial assembly
election): 58 seats Kuomintang, 13 seats in-
dependents
Other political or pressure groups: none
Member of: expelled from U.N. General Assembly
and Security Council’ on 25 October 1971 and
4)
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
January 1977
CHINA, REPUBLIC OF/COLOMBIA
withdrew on same date from other charter-designated
subsidiary organs; attempting to retain membership in
international financial institutions; ICAC, ISO, IWC-
International Wheat Council','df51f30e5bd2e13c6ba32e0f02057f6f92f68f447e4a963c871bc67952dbe5d0','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7c9ec8dbda519b7248c2272ebb410fb45ffc85d81f927b69a357bc85ec3bd9c6',1977,'CO','Colombia','government',111,'Legal name: Republic of Colombia
Type: republic; executive branch dominates
government structure
Capital: Bogota
Political subdivisions: 22 departments, 4 territorial
districts, 4 special districts, 1 federal district
Legal system: based on Spanish law; religious
courts regulate marriage and divorce; constitution
decreed in 1886, amendments codified in 1946 and
1968; judicial review of legislative acts in the Supreme
Court; accepts compulsory ICJ jurisdiction, with
reservations
Branches: President, bicameral legislature,
judiciary
Government leader: President Alfonso Lopez
Michelsen
Suffrage: universal over age 21
Elections: every fourth year; last presidential and
congressional elections April 1974; municipal and
departmental elections, April 1976
Political parties and leaders: Liberal Party,
President Alfonso Lopez Michelsen; Conservative
Party, Alvaro Gomez Hurtado
Voting strength: 1974 presidential election—
Alfonso Lopez Michelsen 55%, Alvaro Gomez
Hurtado 32%, Maria Eujenia Rojas de Moreno 9.5%;
1976 municipal election, 52% Liberal Party, 40%
Conservative Party, 7% combined far left parties; 70%
abstention of eligible voters
Communists: 10,000-12,000 members est.
Other political or pressure groups: Communist
Party (PCC), Gilberto Vieira White; PCC/ML,
Chinese Line Communist Party, led by Pedro Lupo
Leon Arboleda Roldan
Member of: FAO, IADB, IAEA, IBRD, ICAC,
ICAO, IDA, IDB, IFC, IHO, ILO, IMF, ISO, ITU,
LAFTA and Andean Sub-Regional Group (created in
May 1969 within LAFTA), OAS, SELA, U.N.,
UNESCO, UPEB, UPU, WCL, WFTU, WHO,
WMO, WSG','c75106ae07260ec82fc7e4ff5715a57ddb1adee26161c0efe712c626ee9f38a9','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fba877a07d3c9c9b2370bf18f7d980e4e541aeb7398816c0b37ffcb99c55e8b3',1977,'KM','Comoros','government',115,'Legal name: Republic of the Comoros
Type: three of the four islands comprise an
independent republic, following local government''s
unilateral declaration of independence from France in
July 1975; other island disallowed declaration and its
status is undecided
Capital: Moroni
Political subdivisions: 3 prefectures, 3 district
councils
Legal system: French and Muslim law
Branches: supreme authority exercised by the
President and an 1l-member National Executive
Council; Prime Minister heads nine-man cabinet
Government leader: Ali Soilih, President of
National Executive Council
Suffrage: universal adult
Elections: at discretion of Council of Ministers, on
advice of President; must be held before expiration of
5-year electoral mandate
44
Political parties and leaders: Comoran Demo-
cratic Union, Mohammed Dahlani; Democratic
Assembly of Comoros People, Said Mohamed Jaffar;
Comoros Socialist Party; Umma, Prince Said Ibrahim;
Mahorais Movement, Marcel Henry
Voting strength: in elections for Chamber of
Deputies in 1972, independence coalition of CDU
and DACP won 34 seats, Mahorais Movement won 5
Communists: information not available
Member of; OAU','2f83956397db3af48551848b7defd48205f1ac90757dda89ded83527a7ed2459','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('533a91c7b887dfacfb0c3ff86c3a0f7b49a3aa6c24b7cc03d3608c122029bfa5',1977,'CG','Congo','government',119,'Legal name: Peoples Republic of the Congo
Type: republic; military regime established
September 1968
Capital: Brazzaville
Political subdivisions: 9 regions divided into
districts
Legal system: based on French civil law system
and customary law; constitution adopted 1973
Branches: President, Prime Minister, Council of
State; National Assembly; judiciary; all policy made
by Congolese Worker: Party Central Committee and
Politburo
Government leaders: President, Major Marien
Ngouabi; Prime Minister Louis Goma
Suffrage: universal over age 18
Elections: last legislative elections June 1973
Political parties and leaders: Congolese Workers
Party (PCT) is only legal party; president, Marien
Ngouabi
Communists: unknown number of Communists
and sympathizers
Other political or pressure groups: Union of
Congolese Socialist Youth (UJSC), Congolese Trade
Union Congress (CSC), Revolutionary Union of
Congolese Union (URFC), General Union of
Congolese Pupils and Students (UGEEC)
Member of: AFDB, Conference of East and
Central African States, EAMA, ECA, EIB (associate),
FAO, GATT, IBRD, ICAO, IDA, ILO, IMF, ITU,
OAU, OCAM, UDEAC, UEAC, U.N., UNESCO,
UPU, WFTU, WHO, WMO','3119c21e68ed7d90b263e52ff11fd8d9603a3f1e167a693c217d0c7b46700251','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4e72e132b9b12e43b9e4c7580d6e3638d390bab9a0b18130f8c375a6546f4ce0',1977,'CK','Cook Islands','government',123,'Legal name: Cook Islands
Type: self-governing in “free association” with
New Zealand; Cook Islands government fully
responsible for internal affairs and has right at any
time to move to full independence by unilateral
action; New Zealand retains responsibility for external
affairs, in consultation with Cook Islands government
Capital: Rarotonga
46
Branches: New Zealand Governor General appoints
Representative to Cook Islands, who represents the
Queen and the New Zealand government; Repre-
sentative appoints the Premier; Legislative Assembly
of 22 members, popularly elected; House of Arikis
(chiefs), 15 members, appointed by Representative, an
advisory body only
Government leader: Premier Albert Henry
Suffrage: universal adult
Elections: every 4 years, latest in December 1975
Political parties and leaders: Cook Islands Party,
Sir Albert Henry; Democratic Party, Dr. Thomas
Davis
Voting strength (1974): Cook Islands Party, 18
seats; Democratic Party, 9 seats','79a0876336166f0bb486ab172f460682285d0348f257748a69443481ec8ea081','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cb75484ef43ba4bf2a6398a45ed12329b7ea2fd16dd22c7098ca8e240f646b6f',1977,'CR','Costa Rica','government',127,'Legal name: Republic of Costa Rica
Type: unitary republic
Capital: San Jose
Political subdivisions: 7 provinces
Legal system: based on Spanish civil law system;
constitution adopted 1949; judicial review of
legislative acts in the Supreme Court; legal education
at University of Costa Rica; has not accepted
compulsory ICJ jurisdiction
Branches: President, unicameral legislature,
Supreme Court elected by legislature
Government leader: President Daniel Oduber
Suffrage: universal and compulsory age 18 and
over
Elections: every 4 years; next, February 1978
Political parties and leaders: National Liberation
Party (PLN), temporarily unfilled; National
Unification Party (PUN), Francisco Calderon
Guardia; Democratic Renovation Party (PRD),
Rodrigo Carazo; Christian Democratic Party (PDC),
Jorge Monge Zamora; National Independence Party
Approved For Release 2005/04/22
(PNI), Jorge Gonzalez Marten; Popular Vanguard
Party (PVP, Communist), Manuel Mora Valverde
Voting strength (1974 election): National
Unification (coalition of PUN, PR, and PURA)
30.4%, 16 seats; PLN 43.5%, 27 seats; PNI 11%, 6
seats; PRD 9%, 3 seats; PASO 2.3%, 2 seats
Communists: 3,200 members, 10,000 sympathizers
Other political or pressure groups: Costa Rican
Confederation of Democratic Workers (CCTD),
General Confederation of Workers (CGT), Chamber
of Coffee Growers, National Association for Economic
Development (ANFE)
Member of: CACM, FAO, IADB, IAEA, IBRD,
ICAO, IDA, IDB, IFC, ILO, IMF, IPU, ITU, IWC—
International Wheat Council, NAMUCAR (Carib-
bean Multinational Shipping Line—Naviera Mul-
tinacional del Caribe), OAS, ODECA, SELA, U.N.,
UNESCO, UPEB, UPU, WCL, WFTU, WHO,
WMO
Legal name: Republic of Cuba
Type: Communist state
Capital: Havana
Political subdivisions: 14 provinces and 169
municipalities
Legal system: based on Spanish and American law,
with large elements of Communist legal theory;
Fundamental Law of 1959 replaced Constitution of
1940; a new constitution was approved at the Cuban
Communist Party’s First Party Congress in December
1975 and by a popular referendum which took place
on February 15,1976; portions of the new constitution
were put into effect on February 24, 1976, by means
of a Constitutional Transition Law, and the entire
constitution became effective on December 2, 1976;
legal education at Universities of Havana, Oriente,
and Las Villas; does not accept compulsory ICJ
jurisdiction
Branches: executive; legislature (National People’s
Assembly); controlled judiciary
Government leader: President Fidel Castro Ruz
Suffrage: universal, but not compulsory, over age
16
Elections: National People’s Assembly (indirect
election) every five years; election held November
1976
Political parties and leaders: Cuban Communist
Party (PCC), First''Secretary Fidel Castro Ruz, Second
Secretary Raul Castro Ruz
Communists: approx. 200,000 party members
Member of; CEMA, ECLA, FAO, GATT, IADB
(nonparticipant), ICAO, IHO, ILO, IMCO,
International Rice Commission, ISO, IWC—
International Wheat Council, ITU, NAMUCAR
(Caribbean Multinational Shipping Line—Naviera
Multinactonal del Caribe), OAS (nonparticipant),
Permanent Court of Arbitration, Postal Union of the
Americas and Spain, SELA, U.N., UNESCO, UPU,
WCL, WFTU, WHO, WMO, WSG','562e8c5046ee712a79aa5c2e9f655ee2e7f68ac79c2b47fb5609b184870c3b29','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('20b730620db790615e213059618f4267dc144ab53271e734b318a434dd50ff96',1977,'CY','Cyprus','government',131,'Legal name: Republic of Cyprus
Type: republic since August 1960; separate de facto
Greek Cypriot, and Turkish Cypriot governments
have evolved since outbreak of communal strife in
1968; this separation was further solidified following
the Turkish invasion of the island in July 1974;
negotiations, which have been going on since January
1975, have focused on the creation of a federal system
of government with substantial autonomy for each of
the two communities
Capital: Nicosia
Political subdivisions: 6 administrative districts
Legal system: based on common law, with civil
law modifications; negotiations to create the basis for
49
CIA-RDP79-01051A000800010006-3
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
January 1977
a new or revised constitution to govern the island and
relations between Greek and Turkish Cypriots have
been going on intermittently
Branches: currently a rump government with
effective authority only over the Greek Cypriot
community, consisting basically of Greek Cypriot
parts of bodies provided for by constitution; headed
by President of the Republic and comprised of
Council of Ministers, House of Representatives, and
Supreme Court; Turkish Cypriots have their own
“Constitution’” and governing bodies within the
“Federated Turkish State of Cyprus”
Government leaders: President, Archbishop
Makarios III (Greek); Vice President, Rauf Denktash
(Turk)
Suffrage: universal age 21 and over
Elections: officially every 5 years; Turkish Cypriot
‘Presidential’ and “Parliamentary” elections held
June 1976; Greek Cypriot parliamentary elections
held in September 1976
Political parties and leaders: Reform Party of the
Working People (AKEL) (Communist Party), Ezekias
Papaioannou; Democratic Rally (DR), Glafkos
Clerides; Democratic Front (DF) (pro-Makarios),
Spyros Kyprianou; United Democratic Union of the
Center (EDEK), Vassos Lyssarides; National Unity
Party, Rauf Denktash; Populist Party, Alper Orhon;
Republican Turkish Cypriot Party, Ahmet Ber-
beroglou; Communal Salvation Party
Voting strength: Rauf Denktash won the 1976
Presidential’ contest in the Turkish Cypriot zone
with 76% of the vote and his party won 30 of 40 seats
in the “Assembly” with 54% of the vote; a pro-
Makarios coalition composed of AREL, EDER, and
the DF received 75% of the vote in the September
1976 Greek Cypriot parliamentary election and 34 of
35 seats while Clerides’ DM won 25% of the vote and
no seats; the remaining seat was given to an
independent
Communists: 12,000; sympathizers estimated to
number 60,000
Other political or pressure groups: United
Democratic Youth Organization (EDON) (Com-
munist-controlled); Pan Cyprian Confederation of
Labor (PEO) (Communist-controlled); Cyprus
Confederation of Labor (SEK) (pro-West); Cyprus
Turkish Federation of Trade Unions (KTBIF)
Member of: Commonwealth, Council of Europe,
FAO, GATT, IAEA, IBRD, ICAO, IDA, IFC, ILO,
IMF, ITU, U.N., UNESCO, UPU, WCL, WFTU,
WHO, WMO','39ccee679605809e3d20d5526ce0a6028ce6c2d36d5bd2ef95fc6b5f7c4a297b','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('75ace6b5064aa4e94e524fd0f4277f916e8803b3fee91652baff0aa687af4fdb',1977,'NL','Netherlands','government',136,'Legal name: Czechoslovak Socialist Republic
(C.S.S.R.)
Type: Communist state
Capital: Prague
Political subdivisions: 2 ostensibly separate and
nominally autonomous republics (Czech Socialist
Republic and Slovak Socialist Republic); 7 regions
(kraj) in Czech lands, three regions in Slovakia;
national capitals of Prague and Bratislava have
regional status
Legal system: civil law system based on Austrian-
Hungarian codes, modified by Communist legal
theory; revised constitution adopted 1960, amended
in 1968 and 1970; no judicial review of legislative
acts; legal education at Karlova University School of
Law; has not accepted compulsory ICJ jurisdiction
Branches: executive—President (elected by
Federal Assembly), cabinet (appointed by President);
legislative—Federal Assembly (elected directly),
Czech and Slovak National Councils (also elected
directly) legislate on limited area of regional matters;
judiciary—Supreme Court (elected by Federal
Assembly); entire governmental structure dominated
by Communist Party
Government leaders: President Gustav Husak
(elected May 1975), Premier Lubomir Strougal
Suffrage: universal over age 18
Elections: governmental bodies every 5 years (last
election, November 1971); President every 5 years
Dominant political party and leader: Communist
Party of Czechoslovakia (KSC), Gustav Husak,
General Secretary; Communist Party of Slovakia
(KSS) has status of “provincial KSC organization”
Voting strength (1976 election): 99.7% for
Communist-sponsored single slate
Communists: 1.38 million party members
Other political groups: puppet parties—Czech-
oslovak Socialist Party, Czechoslovak People’s Party,
Slovak Freedom Party, Slovak Revival Party
Member of: CEMA, FAO, GATT, IAEA, IBRD,
ICAO, IDA, IFC, ILO, International Lead and Zinc
Study Group, IMCO, IMF, IPU, ISO, ITC, ITU,
U.N., UNESCO, UPU, Warsaw Pact, WFTU, WHO,
WMO, WSG
Legal name: Gilbert Islands Colony
Type: British crown colony with large measure of
self-government
Capital: Tarawa
Branches: 20-member House of Assembly elects a
Chief Minister
Government leader: Governor John H. Smith;
Chief Minister, Naboua Ratieva
Political parties and leaders: Gilbertese National
Party, Christian Democratic Party
Member of: ADB
Legal name: Kingdom of the Netherlands
Type: constitutional monarchy
Capital: Amsterdam, but government resides at
The Hague
Political subdivisions: 11 provinces governed by
centrally appointed commissioners of Queen
Legal system: civil law system incorporating
French penal theory; constitution of 1815 frequently
amended, reissued 1947; judicial review in the
Supreme Court of legislation of lower order than Acts
of Parliament; legal education at six law schools;
accepts compulsory ICJ jurisdiction, with reservations
Branches: executive, (Queen and Cabinet of
Ministers), which is responsible to bicameral states
general (parliament); independent judiciary
Government leader: Head of State, Queen
Juliana; Johannes den Uyl, Prime Minister
Suffrage: universal over age 21
Elections: must be held at least every 4 years for
lower house (next elections scheduled for May 25,
1977), and every 3 years for upper house (most recent
March 1974)
Political parties and leaders: Catholic People’s
Party (KVP), Dr. D. de Zeeuw; Antirevolutionary
(ARP), A. Veerman; Labor (PvdA), Mrs. Ien Van Den
Heuvel; Liberal (VVD), Mrs. H. van Sommeren-
Downer; Christian Historical Union (CHU), Otto W.
A, Barou Van Verschuer; Democrats ’66 (D-66), Jan
ter Brink; Communist (CPN), Henk Hoekstra; Pacifist
Socialist (PSP), P. A. Burggraff; Political Reformed
(SGP), H. G. Abma; Reformed Political Union (GVP),
G. Veurink; Radical Party (PPR), Marcel Van Dam;
Democratic Socialist ’70 (DS-70), Fred L. Polak;
Farmers’ Party (BP), Hendrik Koekoek; Roman
Catholic Party (RKPN), leader unknown
Voting strength (1972 election): 17.7% KVP,
14.4% VVD, 8.8% ARP, 4.8% CHU, 27.4% PvdA,
4,2% D-66, 4.1% DS-70, 4.5% CPN, 1.5% PSP, 4.8%
PRP, 2.2% SGP, 1.8% GVP, 1.9% BP, .9% RKP
Communists: 9,000 members; 329,973 votes in
1972 election
Other political or pressure groups: great
multinational firms; Socialist, Catholic, and
Protestant trade unions; Federation of Catholic and
Protestant Employers Associations; the non-
denominational Federation of Netherlands Enter-
prises
Member of: ADB, Benelux, Council of Europe,
DAC, EC, ECE, EEC, EIB, ELDO, EMA, ESRO,
145
CIA-RDP79-01051A000800010006-3
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
January 1977
NETHERLANDS/NETHERLANDS ANTILLES
EURATOM, FAO, GATT, IAEA, IBRD, ICAC,
ICAO, IDA, IEA, IFC, IHO, ILO, International
Lead and Zinc Study Group, IMCO, IMF, IPU, ITC,
ITU, IWC—lInternational Wheat Council (with
respect to interests of the Netherlands Antilles and
Surinam), NATO, OAS (observer), OECD, U.N.,
UNESCO, UPU, WCL, WEU, WHO, WMO, WSG
Legal name: Netherlands Antilles
Type: territory within Kingdom of the Netherlands,
enjoying complete domestic autonomy
Capital: Willemstad, Curacao
Political subdivisions: 4 island territories—Aruba,
Bonaire, Curacao, and the Windward Islands—St.
Eustatius, southern part of St. Martin (northern part is
French), Saba
Legal system: based on Dutch civil law system,
with some English common law influence; Consti-
tution adopted 1954
Branches: federal executive power rests nominally
with Governor (appointed by the Crown), actual
power exercised by 8-member Council of Ministers or
Cabinet presided over by Minister-President;
legislative power rests with 22-member Legislative
Council; independent court system under control of
Chief Justice of Supreme Court of Justice (administra-
tive functions under Minister of Justice); each island
territory has island council headed by Lieutenant
Governor
Government leaders: Minister-President Juan
Evertsz
Suffrage: universal age 18 and over
Elections: Federal elections held every 4 years, last
held August 1973; Island council elections every 4
years, last held April and May 1975
Political parties and leaders: political parties are
indigenous to each island:
Curacao: National People’s Party-United (NVP-
U), Juan Evertsz; Frente Obrero de Liberation’ 30 di
Mayo (FOL), Wilson ‘‘Papa’’ Godett; Social
Democratic Party (PSD), R. J. Isa; Democratic Party
(DP), S. G. M. Rozendaal
Approved For Release 2005/04/22 :
Aruba: People’s Electoral Movement (MEP), G.
F, “‘Betico’’ Croes; Aruban Patriotic Party (PPA), L.
O. Chance; Aruban People’s Party (AVP), D. G. Croes
Bonaire: Labor Party (POB); Democratic Party
Bonaire (UPB); New Democratic Action (ADEN)
Windward Islands: Windward Islands Demo-
cratic Party (DPWI); United Federation of Antillean
Workers (UFA); Windward Islands Political
Movement (WIPM); and others
Voting strength: (1973 federal election) NVP-U, 5
seats; MEP, 5 seats; FOL, 3 seats; PPA, 3 seats; PSD, 3
seats; DP, 1 seat; DPB, 1 seat; DPWI, 1 seat
Communists: no Communist Party
Member of: EC (associate), WCL, WHO','25c1e33faf9adfec779a6631d29e0130b05c966a0bc17ddeef433b25c8e9cd52','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0732324ad1d71f66234ced79e8707bc5cfab2a254f4760938a3f2d69ccb24b00',1977,'DK','Denmark','government',139,'Legal name: Kingdom of Denmark
Type: constitutional monarchy
Capital: Copenhagen
Political subdivisions: 14 counties, 277 communes,
88 towns
Legal system: civil law system; constitution
adopted 1953; judicial review of legislative acts; legal
education at Universities of Copenhagen and Arhus;
accepts compulsory ICJ jurisdiction, with reservations
Branches: legislative authority rests jointly with
Crown and parliament (Folketing); executive power
vested in Crown but exercised by cabinet responsible
to parliament; Supreme Court, 2 superior courts, 106
lower courts
Government leaders: Queen Margrethe II; Prime
Minister, Anker Jorgensen
: CIA-RDP79-01051A000800010006-3
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
January 1977
DENMARK.
Suffrage: universal, but not compulsory, over age
21
Flections: on call of prime minister but at least
every four years (last election 9 January 1975)
Political parties and leaders: Social Democratic,
Anker Jorgensen; Moderate Liberal, Poul Hartling;
Conservative, Poul Schluter; Radical Liberal, Kristen
Helveg Petersen; Socialist Peoples, Gert Petersen;
Communist, Knud Jespersen; Left Socialist, Preben
Wilhjelm and Steen Folke; Center Democratic,
Erhard Jakobsen; Progressive, Mogens Glistrup;
Christian People’s, Jens Miller; Justice, Ib Chris-
tensen; Communist League Marxist-Leninest, Benito
Scocozza
Voting strength (1975 election): 30.0% Social
Democratic, 23.3% Moderate Liberals, 13.6%
Progressive, 7.1% Radical Liberal, 5.5% Conservative,
5.3% Christian Peoples, 4.9% Socialist Peoples, 4.2%
Communist, 2.2% Center Democratic, 3.9% other
Communists: 7,500-8,000; a number of sympa-
thizers, as indicated by 110,809 Communist votes cast
in 1978 elections
Member of: ADB, Council of Europe, DAC, EC,
EEC, ELDO (observer), EMA, ESRD, EURATOM,
FAO, GATT, IAEA, IBRD, ICAC, ICAO, IDA, IEA,
IFC, IHO, ILO, International Lead and Zinc Study
Group, IMCO, IMF, IPU, ISO, ITC, ITU, WC—
International Wheat Council, NATO, Nordic
Council, OECD, U.N., UNESCO, UPU, WHO,
WMO, WSG
Legal name: Colony of the Falkland Islands
Type: British crown colony
Capital: Stanley
1The possession of the Falkland Islands has been disputed
by the U.K. and Argentina (which refers to them as the
Malvinas) since 1833.
63
: CIA-RDP79-01051A000800010006-3
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
January 1977
FALKLAND ISLANDS (MALVINAS)/FIJ1
Political subdivisions: local government is
confined to capital
Legal system: English common law
Branches: Governor, Executive Council, Legisla-
tive Council
Government leader: Governor and Commander in
Chief Ernest G. Lewis (also High Commissioner for
British Antarctic Colony)
Suffrage: universal','e16a0e3855a655b772d1e2239387a7869a453d7c47d33ae6633dca63cc92eafd','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('16b3301a01c992b35ccc250f6ed0f812779c88d1468f9d872bdfc55608473b5c',1977,'DM','Dominica','government',143,'Legal name: State of Dominica
Type: dependent territory with full internal
autonomy as a British ‘Associated State”
Capital: Roseau
Political subdivisions: 10 parishes
Legal system: based on English common law; three
local magistrate courts and the British Caribbean
Court of Appeals
Branches: legislature, 11 member popularly elected
House of Assembly; executive, cabinet headed by
Premier
Government leaders: Premier Patrick Roland
John; U.K. Governor Sir Louis Cools-Lartigue
Suffrage: universal adult suffrage over age 18
Elections: every 5 years; most recent March 1975
Political parties and leaders: Dominica Labor
Party (DLP), Patrick John; Dominica Freedom Party
(DFP), Miss M. Eugenia Charles (unofficial)
54
Voting strength: House of Assembly seats—DFP 3
seats, DLP 16 seats, independent 2 seats
Communists: negligible
Member of: CARICOM, WCL','956a22d69aa3de6a7800e26a85b610f37d1fe02c4550be16c1f7d4910f4eddf4','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c8f814e3f1ccaf6d622bbf4f70b0d7c5c339c5b1f855e7862aaa9ef92a74e069',1977,'DO','Dominican Republic','government',147,'Legal name: Dominican Republic
Type: republic
Capital: Santo Domingo
Political subdivisions: 26 provinces and the
National District
Legal system: based on French civil codes; 1966
constitution
Branches: President popularly elected for a 4-year
term; bicameral legislature consisting of Senate (27
seats) and Chamber of Deputies (91 seats) elected for
4-year terms; Supreme Court
Government leader: President Joaquin Balaguer
Suffrage: universal and compulsory, over age 18 or
married, except members of the armed forces and
police, who cannot vote
Elections: national, last election May 1974, next
election May 1978
Political parties and leaders: Reformist Party
(PR), Joaquin Balaguer; Dominican Revolutionary
Party (PRD), Francisco Pena Gomez, Secundino Gil
Morales; Dominican Liberation Party (PLD), Juan
Bosch, Democratic Quisqueyan Party (PQD), Elias
Wessin y Wessin; Revolutionary Social Christian
Party (PRSC), Rogelio Delgado Bogaert; Movement
for National Conciliation (MNC), Jaime Manuel
Fernandez Gonzalez; Anti-reelection Movement of
Democratic Integration (MIDA), Francisco Augusto
Lora; National Civic Union (UCN), Guillermo
Delmonte Urraca; Popular Democratic Party (PDP),
Homero Lajara Burgos; Fourteenth of June
Revolutionary Movement (MR-1J4), split into several
factions, illegal; Dominican Communist Party (PCD),
central committee, illegal; Dominican Popular
Movement (MPD), illegal; 12th of January National
Liberation Movement (ML-12E), Plinio Matos
Mogquete, illegal; Communist Party of the Dominican
Republic (PACOREDO), Luis Montas Gonzalez,
illegal; Popular Socialist Party (PSP), illegal
Voting strength (1974 election): 85% PR, 15%
PDP, all other parties abstained
Communists: an estimated 1,500 to 1,800 members
in six different factions; effectiveness limited by
ideological differences and organizational inade-
quacies
Member of: FAO, GATT, IADB, IAEA, IBA,
IBRD, ICAO, IDA, IDB, IFC, IHO, ILO, IMCO,
IMF, IOOC, ISO, ITU, OAS, SELA, ULN.,
UNESCO, UPU, WCL, WHO, WMO','b434f468295fed33d934061398686b15021a8b56f3f72dde3e771d4e564ad298','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8bae0452b5acbc97534a22965494ba0c31c1a7f7b1f5d592c8a40052ae0a5668',1977,'EC','Ecuador','government',151,'Legal name: Republic of Ecuador
Type: republic; under military regime since
February 1972
Capital: Quito
Political subdivisions: 20 provinces including
Galapagos Islands
Legal system: based on civil law system; modified
1945 constitution re-instituted in February 1972; legal
education at 4 state and 2 private universities; has not
accepted compulsory ICJ jurisdiction
Branches: Supreme Council of Government, made
up of the three military chiefs, assumed power
January 1976; judiciary system supervised by Supreme
Court; six special tribunals established in July 1972
Government leader: President of Supreme Council
Admiral Alfredo POVEDA Burbano
Suffrage: universal for literates over age 18
Elections: none scheduled
Political parties and leaders: National Velasquista
Front, Jose Maria Velasco Ibarra, personalistic;
Radical Liberal Party, Ignacio Hidalgo Villavicencio;
Social Christian Party, Camilo Ponce, generally
conservative; Conservative Party, Galo Pico Mantilla;
Concentration of Popular Forces, Assad Bucaram,
populist; National Revolutionary Party, Carlos Julio
Arosemena, leftist
Voting strength: in June 1968 national elections,
Velasquistas, a center-left coalition, and a rightist
coalition each got approximately one-third
Communists: Communist Party of Ecuador (PCE,
pro-Moscow, Pedro Saad—secretary-general), 500
members plus an estimated 3,000 sympathizers;
Communist Party of Ecuador (PCE/ML, pro-Peking),
100 members; Revolutionary Socialist Party of
Ecuador (PSRE), 200 members
Member of: ECOSOC, FAO, IADB, IAEA, IBRD,
ICAO, IDA, IDB, IFC, IHO, ILO, IMCO, IMF,
ITU, LAFTA and Andean Sub-Regional Group
(formed in May 1969 within LAFTA), OAS, OPEC,
SELA, U.N., UNESCO, UPEB, UPU, WCL, WFTU,
WHO, WMO','1cd1defafb0ccff5078d816f4f91c7e6ce1f9e0bfff669513c5fb8ae39ea350e','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fc88bc5ea6222c221b48cf12cb6272247a8e6bb150ff6f9b8f4e6820cce3c542',1977,'EG','Egypt','government',155,'Legal name: Arab Republic of Egypt
Type: republic; under presidential rule since June
1956
Capital: Cairo
Political subdivisions: 25 governorates
Legal system: based on English common law,
Islamic Law, and Napoleonic codes; permanent
constitution written in 1971; judicial review of limited
nature in Supreme Court, also in Council of State
which oversees validity of administrative decisions,
legal education at Cairo University; accepts
compulsory ICJ jurisdiction, with reservations
Branches: executive power vested in President, who
appoints cabinet; People’s Assembly has little actual
57
CIA-RDP79-01051A000800010006-3
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
January 1977
EGYPT/EL SALVADOR
power (serves mainly for discussion and automatic
approval); independent judiciary administered by
Minister of Justice
Government leader: President Anwar Sadat
Suffrage: universal over age 18
Elections: elections to People’s Assembly every 5
years (most recent October 1976); presidential
elections every 6 years (most recent September 1976)
Political parties and leaders: political parties
banned except for the government-sponsored
sociopolitical grouping, Arab Socialist Union (ASU)
Communists: approximately 500, party members
Member of: AAPSO, AFDB, Arab League, FAO,
GATT, IAEA, IBRD, ICAC, ICAO, IDA, IFC, IHO,
ILO, IMCO, IMF, IOOC, IPU, ITU, Iwc—
International Wheat Council, OAPEC, OAU, U.N.,
UNESCO, UPU, WHO, WMO, WPC, WSG','010fbed9cf97d150d4dd1333e801db5fa0c531457746d59e2c09437a743e631d','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('96a5b6b49555bcdeb637eeb4826860c675a290945eb225484dc3e177478a877a',1977,'SV','El Salvador','government',159,'Legal name: Republic of El Salvador
Type: republic
Capital: San Salvador
Political subdivisions: 14 departments
Legal system: based on Spanish law, with traces of
common law; constitution adopted 1962; judicial
review of legislative acts in the Supreme Court; legal
education at University of El Salvador; accepts
compulsory 1CJ jurisdiction, with reservations
Branches: traditionally dominant executive,
unicameral legislature, Supreme Court
Government leader: President Arturo Armando
Molina
Suffrage: universal over age 18
Elections: legislative elections every 2 years;
presidential elections every 5 years; presidential
elections March 1977, legislative and municipal
elections March 1978
Political parties and leaders: National Concilia-
tion Party (PCN), President Arturo A. Molina;
Christian Democratic Party (PDC), Juan Ramirez
Rauda, Dr. Pablo Mauricio Alvergue, Jose Napoleon
Duarte; Salvadoran Popular Party (PPS), Benjamin
Wilfredo Navarrete, Roberto Quinonez Meza, Dr.
Jose Antonio Guzman; Communist Party of El
Salvador (PCES), illegal, Jorge Shafick Handal;
National Revolutionary Movement (MNR), Dr.
Guillermo Manuel Ungo; National Democratic
Union Party (PUDN), Communist Front, Jorge
Shafisk Handal, Francisco Roberto Lima, Julio
Ernesto Contreras, Julio Castro Belloso; Independent
Democratic United Front (FUDI), Gen. Jose A.
Medrano, Raul Salaverria
Voting strength: February 1972 presidential
election—PCN 43.4%, PDC, PUDN, and MNR
coalition, 42.1%; FUDI, 12.3%; PPS 2.2%; March
1976 legislative election—PCN, 54 seats; opposition
parties boycotted the election
Communists: 100 to 200 active members;
sympathizers, 5,000
Other political or pressure groups: the military;
about 100 prominent families; General Confederation
of Trade Unions (CGS); Unifying Federation of
Salvadoran Trade Unions (FUSS), Communist
Approved For Release 2005/04/22 :
dominated; Federation of Construction and Transport
Workers Unions (FESINCONSTRANS), independ-
ent; Catholic Church; Salvadoran National Associa-
tion of Educators (ANDES)
Member of: Central American Common Market
(CACM), FAO, IADB, IAEA, IBRD, ICAC, ICAO,
IDA, IDB, IFC, ILO, IMF, ITU, IWC—Interna-
tional Wheat Council, OAS, ODECA, SELA, UN,,
UNESCO, UPU, WCL, WFTU, WHO, WMO','1464fea542a76cd99ea71e6ad0e21a87c4bc28ef6c997b24c67f6250ca4131d1','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e80d43f82c5d4da4dfd3c669ce7b306f5602a6c40fd4ad6aa9a6d5a4e6fbb710',1977,'GQ','Equatorial Guinea','government',163,'Legal name: Republic of Equatorial Guinea
Type: republic, one-party presidential regime since
1968
Capital: Malabo, Province Francisco Macias
Nguema
Political subdivisions: 2 provinces (Province
Francisco Macias Nguema and Rio Muni)
Legal system: based on Spanish civil law system
and customary law, new constitution adopted August
1973; has not accepted compulsory ICJ jurisdiction
Branches: there are legislative and judicial
branches but President exercises virtually unlimited
power
Government leader: President for life, Francisco
Macias Nguema
Suffrage: universal age 21 and over
Elections: parliamentary elections held December
1978
Political parties and leaders: National Unity Party
of Workers (PUNT) is the sole legal party, led by
President Macias
Communists: no significant number of Com-
munists or sympathizers
Member of: Conference of East and Central
African States, ECA, IBRD, ICAO, IDA, IMCO,
IMF, ITU, OAU, U.N., UPU','450611f57bd96123854d086995086c1574dce3cfcff6a72708ec3b7f6a0954f6','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('894e7e3e127238c2a21b3f938973ef578a40b7ea9e0f871e57994e324c7a3bed',1977,'ET','Ethiopia','government',167,'Organized labor: government lists 273,000
registered trade union members
Legal name: Ethiopia
Type: under military tule since mid-1974;
monarchy abolished in March 1975, but republic not
yet declared
Capital: Addis Ababa
Political subdivisions: 14 provinces (also referred
to as regional administrations)
Legal system: complex structure with civil, Islamic,
common and customary law influences; constitution
suspended September 1974; military leaders have
promised a new constitution but established no time
frame for its adoption; legal education at Addis
Ababa University; has not accepted compulsory IC]
jurisdiction
Branches: effective power exercised by Provisional
Military Administrative Council (PMAC), a group
estimated at 40-100 officers and enlisted men which
operates on committee system; predominantly civilian
cabinet is ineffectual and holds office at suffrance of
military; legislature dissolved September 1974;
judiciary at higher levels based on Western pattern, at
lower levels on traditional pattern, without jury
system in either
Government leader: Brigadier General Teferi
Benti, Chairman of the Military Administrative
Council is titular head of government; Major
Mengistu Haile Mariam, Ist Vice Chairman, is
probably primus inter pares
Suffrage: universal over age 2]
Elections: lower house of Parliament June 1973
Political parties and leaders: All-Ethiopian
Socialist Organization, a quasi-official group that
supports the military government
Communists: Ethiopian Communist Party is a
small group opposed to military government
Other political or pressure groups: important
dissident groups include Eritrean Liberation front
61
: CIA-RDP79-01051A000800010006-3
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
January 1977
ETHIOPIA/FAROE ISLANDS
(ELF) and Popular Liberation Front (PLF) in Eritrea;
Ethiopian People’s Revolutionary Party (EPRP), a
socialist underground movement in central and
northern Ethiopia; and Ethiopian Democratic Union
(EDU), primarily an exile group; several other
dissident groups with ethnic or provincial bases of
support
Member of: AFDB, ECA, FAO, IAEA, IBRD,
ICAO, IDA, IFC, ILO, IMF, IPU, ITU, OAU, U.N.,
UNESCO, UPU, WCL, WHO, WMO -','13b30903240a11dddc937aa70d5cce241b0adcb6b3ed0b95c706102959f7ef2d','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a1cf4534311b1fe5a80df0262812714b181cf5eabbfef16bf2196fe54444ec89',1977,'FO','Faroe Islands','government',171,'Legal name: The Faroe Islands
Type: self-governing province within the Kingdom
of Denmark; 2 representatives in Danish parliament
: CIA-RDP79-01051A000800010006-3
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
January 1977
FAROE ISLANDS/FALKLAND ISLANDS (MALVINAS)
Capital: Torshavn on the island of Streymoy
Political subdivisions: 7 districts, 49 communes, 1
town
Legal system: based on Danish law; Home Rule
Act enacted 1948
Branches: legislative authority rests jointly with
Crown, acting through appointed High Commis-
sioner, and provincial parliament (Lagting) in matters
of strictly Faroese concern; executive power vested in
Crown, acting through High Commissioner, but
exercised by provincial cabinet responsible. to
provincial parliament
Government leaders: Queen Margrethe II; Prime
Minister, Atli Dam; Danish Governor, Leif Groth
Suffrage: universal, but not compulsory, over age
21
Elections: held every 4 years; next election 1979
Political parties and leaders: Peoples, Hakun
Djurhuus; Republican, Erlendur Patursson; Home
Rule, Samuel Petersen; Progressive, Kjartan Mohr;
Social Democratic, Atli Dam; Union, Kristian
Djurhuus
Voting strength (1975 election): Social Demo-
cratic 25.8%, Republican 22.5%, Peoples 20.5%,
Union 19.1%, Home Rule 7.2%, Progressive 2.5%
Communists: insignificant number
Member of: Nordic Council','94d91e7ff9802b94db36169b0aa397c535d3e52f48c62d7212482082f3fa3768','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('072bed68693c61f040a60615955a711bfe44a0b2c3cc33f0d82ae1efd8976340',1977,'FJ','Fiji','government',175,'Legal name: Dominion of Fiji
Type: independent state within Commonwealth;
Elizabeth II recognized as head of state
Capital: Suva
Political subdivisions: 14 provinces
Legal system: based on British
Branches: executive—Prime Minister; legislative—
52-member House of Representatives; Alliance Party
33 seats, National Federation Party 19 seats
Government leader: Prime Minister Ratu Sir
Kamisese Mara
Suffrage: universal adult
Elections: every 5 years unless House dissolves
earlier, last held March-April 1972
Political parties: Alliance, primarily Fijian, headed
by Ratu Mara; National Federation, primarily
Indian, headed by S. M. Koya
Communists: few, no figures available
Member of: ADB, Colombo Plan, Commonwealth,
FAO, GATT (de facto), IBRD, ICAO, IDA, IMF,
ISO, ITU, U.N., UPU, WHO
: CIA-RDP79-01051A000800010006-3
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
January 1977
FIJI/FINLAND','822e454cb1aa82d79c613dd33f7cb8a0fb6071b268cf2ee19d5be4d61101726c','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7377dfcbe2a98613307cd91be8d4717d8e4ced898a8217e7e3117bb14abd175b',1977,'FI','Finland','government',179,'Legal name: Republic of Finland
Type: republic
Capital: Helsinki
Political subdivisions: 12 provinces; 448 com-
munes, 78 towns
Legal system: civil law system based on Swedish
law; constitution adopted 1919; Supreme Court may
request legislation interpreting or modifying laws;
legal education at Universities of Helsinki and Turku;
accepts compulsory IC] jurisdiction, with reservations
Branches: legislative authority rests jointly with
President and parliament (Eduskunta); executive
power vested in President and exercised through
cabinet responsible to parliament; Supreme Court, 4
superior courts, 193 lower courts
Government leader: President Urho K. Kekkonen;
Prime Minister Martti Miettunen
Suffrage: universal, over age 20; not compulsory
65
CIA-RDP79-01051A000800010006-3
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
January 1977
FINLAND/ FRANCE
Elections: parliamentary, every 4 years (next in
1979); presidential, every 6 years (extraordinary
parliamentary legislation extended President Kek-
konens term, which normally expires in 1974, to 1978)
Political parties and leaders: Social Democratic,
Rafael Paasio; Center, Johannes Virolainen; Peoples
Democratic League (Communist front), Ele Alenius;
Conservative, Harri Holker; Liberal, Pekka Tarjanne;
Swedish Peoples Party, Kristan Gestrin; Rural, Veikko
Vennamo; Finnish People’s Unity Party, Eino
Haikala; Communist, Aarne Saarinen
Voting strength (1975 election): 25% Social
Democratic, 18.4% Conservative, 19.0% Peoples
Democratic League, 17.7% Center, 3.6% Rural, 4.7%
Swedish Peoples, 4.4% Liberals, 3.3% Christian
Peoples
Communists: 47,000; an additional 65,000 Persons
belong to Peoples Democratic League; a further
number of sympathizers, as indicated by 421,000
votes cast for Peoples Democratic League in 1970
elections
Member of: ADB, CEMA (special cooperation
agreement), DAC, EC (free trade agreement), EFTA
(associate), FAO, GATT, IAEA, IBRD, ICAC, ICAO,
IDA, IFC, IHO, ILO, International Lead and Zinc
Study Group, IMCO, IMF, IPU, ITU, IWC—
International Wheat Council, Nordic Council,
OECD, U.N., UNESCO, UPU, WFTU, WHO,
WMO, WSG','61b629c118fc8c14b9dc33af34cea9284e94069edd5c66f1b74326e70d21c821','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7c3500c29167d61b8c2e8cc4e5528b67b6e4d16060291ebcbce892e10a4f0f66',1977,'FR','France','government',183,'Legal name: French Republic
Type: republic, with president having wide powers
Capital: Paris
Political subdivisions: 95 metropolitan depart-
ments, 21 regional economic districts
Legal system: civil law system with indigenous
concepts; new constitution adopted 1958, amended
concerning election of President in 1962; judicial
review of administrative but not legislative acts; legal
education at over 25 schools of law
Branches: presidentially appointed Prime Minister
heads Council of Ministers, which is formally
responsible to National Assembly; bicameral
legislature—National Assembly (490 members),
Senate (283 members) restricted to a delaying action;
judiciary independent in principle
Government leader: President Valery Giscard
d Estaing
Suffrage: universal over age 18; not compulsory
Approved For Release 2005/04/22 :
Elections: National Assembly—every 5 years, last
election March 1978, direct universal suffrage, 2
ballots; Senate—indirect collegiate system for 9 years,
renewable by one-third every 3 years; President—
direct, universal suffrage every 7 years, 2 ballots, last
election May 1974
Political parties and leaders: Union of Democrats
for the Republic (UDR), Jacques Chirac; Independent
Republicans (IR), Valery Giscard d’Estaing;
Communist (PCF), George Marchais, Progress and
Modern Democracy (PDM), Jacques Duhamel; Left
Radical Party, Robert Fabre; Center Democratic
Party, Jean Lecanuet, Radical Socialists and
Reformers, Gabriel Peronnet; Socialist Party, Francois
Mitterrand; Unified Socialist Party (PSU), Michel
Mousel
Voting strength (first ballot, 1974 election):
43.2% Communist/Socialist Alliance, 32.6% IR,
15.1% UDR, 9.1% other
Communists: 500,000 claimed; Communist voters,
5 million average
Other political or pressure groups: Communist-
controlled labor union (Confederation Generale du
Travail) nearly 2.4 million members (claimed);
Socialist leaning labor union (Confederation Francais
du Travail) about 800,000 members est; National
Council of French Employers (Conseil National du
Patronat Francais—CNPF or Patronat)
Member of: ADB, Council of Europe, DAC, EC,
ECSC, EEC, EIB, ELDO, EMA, ESRO, EURA-
TOM, FAO, GATT, IAEA, IATP, IBRD, ICAC,
ICAO, IDA, IFC, THO, ILO, International Lead and
Zine Study Group, IMCO, IMF, IOOC, IPU, ISO,
ITC, ITU, [WC—International Whaling Commis-
sion, NATO (signatory), OAS (observer), OECD,
South Pacific Commission, U.N., UNESCO, UPU,
WCL, WEU, WFTU, WHO, WMO, WSG','5dab3384ea02559dbc3f5efe57451d3cbf6314b1df9dc1cebbcef4628d6b1cb2','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('029ccdca7b1cef06e3b15a09a075d43a07e6c5396fa289f3766eeb0d38800463',1977,'GF','French Guiana','government',187,'Legal name: Overseas Department of French
Guiana
Type: overseas department and region of France;
represented by one deputy in French National
Assembly and one senator in French Senate
Capital: Cayenne
Political subdivisions: 2 arrondissements, 19
communes each with a locally elected municipal
council
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
Eh gebe
ee er
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
January 1977
FRENCH GUIANA/FRENCH POLYNESIA
Legal system: French legal system; highest court is
Court of Appeal based in Martinique with jurisdiction
over Martinique, Guadeloupe, and French Guiana
Branches: executive: prefect appointed by Paris;
legislative: popularly elected 16-member General
Council and a Regional Council composed of
members of the local General Council and of the
locally elected deputy and senator to the French
parliament; judicial, under jurisdiction of French
judicial system
Government leader: Prefect Herve Bourseiller
Suffrage: universal over age 18
Elections: General Council elections coincide with
those for the French National Assembly, normally
every 5 years; last election March 1973; local elections
last held March 1976; last French presidential election
in May 1974
Political parties and leaders: Parti Socialiste
Guyanais (PSG), Leopold Heder, Senator; Union du
Peuple Guyanaise (UPG), weak leftist allied with, but
also reported, to have been absorbed by the PSG;
Union of Democrats for the Republic (UDR), Hector
Rivierez, delegate to French National Assembly
Communists: Communist party membership
negligible
Member of: WCL, WFTU','e4798ca6a58c98bb99a348b02a0a5a53fe010435bd30a95b81416b01b73ece4f','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9d7ff22e23a1dc165a5d3c54922e4867727a2f01ec00ada7d2dca4642214b72c',1977,'PF','French Polynesia','government',191,'Legal name: Territory of French Polynesia
Type: overseas territory of France, administered by
French Ministry for Overseas Territories
Capital: Papeete
Political subdivisions: 5 districts
Legal system: based on French; lower and higher
courts
Branches: 30-member Territorial Assembly,
popularly elected; 5-member Council of Government,
69
CIA-RDP79-01051A000800010006-3
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
January 1977
FRENCH POLYNESIA/FRENCH TERRITORY OF THE AFARS AND ISSAS
elected by Assembly; popular election of one deputy
to National Assembly in Paris, also one Senator
Government leader: Charles Schmitt, Governor,
appointed by French government
Suffrage: universal adult
Elections: every 5 years
Political parties and leaders: Pupu Here Ai’a,
Senator Pouvanna a Oopa, John Teariki; Te E’a Api,
Francis Sanford; Union Tahitienne-Union pour la
Defense de la Republique, Te Autahoera’a
Legal name: Overseas Territory of Afars and Issas
Type: overseas territory of France; represented by
one deputy in French National Assembly and by one
senator in French Senate
Capital: Djibouti
Legal system: based on French civil law system,
traditional practices and Islamic law
Branches: President of Council of Government; 8-
member Council of Government appointed by 40-
member Chamber of Deputies; ultimate political
authority exercised by Paris-appointed High
Commissioner
Government leader: Abdallah Mohammed Kamil
Suffrage: universal
Elections: Chamber of Deputies election held
November 1973
Political parties and leaders: National Independ-
ence Union (UNI), Ali Aref Bourhan; African People’s
Independence League (LPAI), Hassan Gouled and
Ahmed Dini; Popular Liberation Movement, Kamil
Ali; governing coalition consists of the LPAI and a
parliamentary group headed by Barkat Courat
Communists: possibly a few sympathizers
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
January 1977
FRENCH TERRITORY OF THE AFARS AND ISSAS/GABON
Legal name: Overseas Territory of New Caledonia
Type: French overseas territory; represented in
French parliament by one deputy and one Senator
Capital: Noumea
Political subdivisions: 4 islands or island group
dependencies—Isle of Pines, Loyalty Islands, Huon
Islands, Island of New Caledonia
Legal system: French law
Branches: administered by Governor, who is also
High Commissioner for France in the Pacific;
responsible to French Ministry for Overseas France
and Governing Council; Assemblee Territoriale
148
Government leader: Jean Risterucci, Governor and
French High Commissioner
Suffrage: restricted (1957 election roll listed 32,370
males and females over 21 years of age, of whom
18,964 were classed as indigenous inhabitants)
Elections: Assembly elections in 1972
Political parties: Union Caledonienne, Entente
Democratique et sociale, Union Multiraciale,
Mouvement Liberal Caledonien, Union Democra-
tique, Mouvement Populaire Caledonien
Voting strength (1972 election): 12 seats Union
Caledonienne; 6 seats Entente Sociale et Democra-
tique; 5 seats Union Multiraciale; 5 seats Mouvement
Liberal Caledonien; 4.seats Union Democratique; 2
seats Mouvement Populaire Caledonien; 1 seat
Caledonie Francaise
Communists: number unknown; Union Caledoni-
enne strongly leftist; some politically active
Communists were deported during 1950''s; small
number of North Vietnamese
Other political parties and pressure groups:
several lesser parties
Member of: EIB (associate), WFTU
Legal name: New Hebrides Condominium
Type: Anglo-French condominium
Capital: Vila
Political subdivisions: 4 administrative districts
Legal system: 3 sets of courts; one each for French
and British subjects, one for New Hebrides native
affairs
Branches; Representative Assembly, 42 members,
elected November 1975, has not met
Government leader: two resident commissioners,
one French, Robert Gaugier; one British, John
Champion
Political parties and leaders: National Party,
chairman Walter Lini; NA Griamel Party, leader
Jimmy Stevens; Mouvement d’Action des Nouvelles
Hebrides (MANH)','a3e0984d9201fde208a2efd40953694d10e34ee37bd7e997f4d746c32c7ac021','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('64e813e513f7d5978e857bae7ad2ef7eb289349e77f78b85b6f917cb95732a96',1977,'GA','Gabon','government',195,'Legal name: Gabonese Republic
Type: republic; one-party presidential regime since
1964
Capital: Libreville
Political subdivisions: 9 provinces subdivided into
36 prefectures
Legal system: based on French civil law system
and customary law; constitution adopted 1961;
judicial review of legislative acts in Constitutional
Chamber of the Supreme Court; legal education at
Center of Higher and Legal Studies at Libreville;
compulsory ICJ jurisdiction not accepted
Branches: power centralized in President, elected
by universal suffrage for 7-year term; unicameral 70-
member National Assembly has limited powers;
judiciary
Government leader: President Omar Bongo
Suffrage: universal over age 21
Elections: Presidential and parliamentary elections
last held February 1978
Political parties and leaders: Gabonese Demo-
cratic Party (PDG) led by President Bongo is only legal
party
Communists: no organized party; probably some
Communist sympathizers
71
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
January 1977
GABON/THE GAMBIA
Member of; AFDB, Conference of East and
Central African States, EAMA, EIB (associate), FAO,
GATT, IAEA, IBRD, ICAO, IDA, IFC, ILO, IMF,
IPU, ITU, OAU, OPEC, UDEAC, U.N., UNESCO,
UPU, WHO, WMO
Legal name: Republic of The Gambia
Type: republic; independent since February 1965
Capital: Banjul
Political subdivisions: Banjul and 5 divisions
Legal system: based on English common law and
customary law; constitution came into force upon
independence in 1965, new republican constitution
adopted in April 1970; accepts compulsory ICJ
jurisdiction, with reservations
Branches: cabinet of 10 members; 41-member
House of Representatives, in which 4 seats are reserved
for chiefs, 4 are appointed, 32 are filled by election for
5-year terms, a Speaker is elected by the House, and
the Attorney General is an ex officio member;
independent judiciary
Government leader; Dawda K. Jawara, President
Political parties and leaders: People’s Progressive
Party (PPP), Secretary General Dawda K. Jawara, and
United Party (UP), John Forster
Suffrage: universal adult
Elections: general elections held March 1972; PPP
28 seats, UP 3 seats, 1 independent seat
Communists: insignificant number
Member of: AFBD, APC, Commonwealth, ECA,
ECOWAS, FAO, GATT, IBRD, IDA, IMF, OAU,
U.N., WCL, WFTU, WHO
Legal name: German Democratic Republic
Type: Communist state
Capital: East Berlin (not officially recognized by
U.S., U.K., and France, which together with the
U.S.S.R. have special rights and responsibilities in
Berlin)
Political subdivisions: (excluding East Berlin) 14
districts (Bezirke), 218 counties (Kreise), 7,643
communities (Gemeinden)
Legal system: civil law system modified by
Communist legal theory; new constitution adopted
1974; court system parallels administrative divisions;
no judicial review of legislative acts; legal education
at Universities of Berlin, Leipzig, Halle and Jena; has
not accepted compulsory IC] jurisdiction; more
stringent penal.code adopted 1968
Branches: legislative—Volkskammer (elected
directly); executive—Chairman of Council of State,
Chairman of Council of Ministers, Cabinet (approved
by Volkskammer); judiciary—Supreme Court; entire
structure dominated by Socialist Unity (Communist)
Party
Government leaders: Chairman, Council of State,
Willi Stoph (Head of State); Chairman, Council of
Ministers, Horst Sindermann (Head of Government)
Suffrage: all citizens age 18 and over
Elections: national every 5 years; prepared by an
electoral commission of the National Front; ballot
supposed to be secret and voters permitted to strike
names off ballot; more candidates than offices
available; parliamentary elections held 14 November
1971
Political parties and leaders: Socialist Unity
(Communist) Party (SED), headed by First Secretary
Erich Honecker, dominates the regime; 4 token
parties (Christian Democratic Union, National
Democratic Party, Liberal Democratic Party, and
Democratic Peasant’s Party) and an amalgam of
special interest organizations participate with the SED
in National Front
Voting strength: 1976 parliamentary elections:
98.58% voted the regime slate; 1970 local elections:
99.85% voted the regime slate
Communists: 1.9 million party members
Other special interest groups: Free German Youth,
Free German Trade Union Federation, Democratic
Women’s Federation of Germany, German Cultural
Federation (all Communist dominated)
Member of: CEMA, IPU, ITU, U.N., UNESCO,
UPU, Warsaw Pact, WFTU, WHO
74
Approved For Release 2005/04/22
Legal name: Federal Republic of Germany
Type: federal republic
Capital: Bonn
Political subdivisions: 10 Laender (states);
Western sectors of Berlin are ultimately controlled by
U.S., U.K., and France which, together with the
U.S.S.R., have special rights and responsibilities in
Berlin
Legal system: civil law system with indigenous
concepts; constitution adopted 1949; judicial review
of legislative acts in the Supreme Federal constitu-
tional Court; has not accepted compulsory ICJ
jurisdiction
Branches: bicameral parliament—Bundersrat
(upper house), Bundestag (lower house); President
(titular head), Chancellor (executive head);
independent judiciary
Government leaders: President, Walter Scheel;
Chancellor, Helmut Schmidt leads coalition of Social
Democrats and Free Democrats
Suffrage: universal over age 18
Elections: next national election scheduled for fall
of 1980
Political parties and leaders: Christian Demo-
cratic Union/Christian Social Union (CDU/CSU),
Helmut Kohl, Franz-Josef Strauss, Karl Carstens, Kurt
Biedenkopf; Social Democratic Party (SPD), Willy
Brandt, Hans Koschnick, Helmut Schmidt; Free
Democratic Party (FDP), Hans-Dietrich Genscher,
Hans Friderichs, Wolfgang Mischnick; National
Democratic Party (NPD), Martin Mussgnug;
Communist Party (DKP), Herbert Mies
Voting strength (1976 election): 42.6% SPD,
48.6% CDU/CSU, 7.9% FDP, 0.9% Splinter groups of
left and right (no parliamentary representation)
Communists: about 40,000 members and sup-
porters
Other political or pressure groups: expellee,
refugee, and veterans groups
Member of: ADB, Council of Europe, DAC, EC,
ECSC, EIB, ELDO, EMA, ESRO, EURATOM,
FAO, GATT, IAEA, IBRD, ICAC, ICAO, IDA, IBA,
IFC, IHO, International Lead and Zinc Study Group,
IMCO, IMF, IPU, ITC, ITU, NATO, OAS
(observer), OECD, U.N., UNESCO, UPU, WCL,
WEU, WHO, WMO, WSG','738f3ebb2c1250c9fdcf6194342fe2b6969c6dbfc886d8850d226c14705892fa','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('07f2fbb1cf682af1e6230c66bf1d81773437769d01b43594ab16404b8af63fe6',1977,'GH','Ghana','government',199,'Legal name: Republic of Ghana
Type: republic; independent since March 1957;
Military regime since January 1972
Capital: Accra
Political subdivisions: 8 administrative regions and
separate Greater Accra Area; regions subdivided into
58 districts and 267 local administrative districts
Legal system: based on English common law and
customary law; constitution suspended January 1972;
legal education at University of Ghana (Legon); has
not accepted compulsory ICJ jurisdiction
Branches: executive and legislative authority
vested in Supreme Military Council (SMC);
independent judiciary
Government leaders: Chief of State, Chairman of
SMC General Ignatius Kutu Acheampong
Suffrage: universal over 21 under previous
constitution, now suspended
Elections: no elections since 1969; none scheduled
Political parties and leaders: parties banned by
military junta which took power 13 January 1972
Communists: a small number of Communists and
sympathizers
Member of: AFDB, Commonwealth, ECA,
ECOWAS, FAO, GATT, IAEA, IBA, IBRD, ICAO,
IDA, IFC, ILO, IMCO, IMF, ISO, ITU, OAU, U.N,
UNESCO, UPU, WCL, WHO, WMO','696f151c14b62f81a1942539e23bdd9442cdc0be781773f138cecdd51627df14','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('45c8912388419b106aa0f230c3c644dc8c1e2c0ad6300d44420383ac7e62661e',1977,'GI','Gibraltar','government',203,'Legal name: Colony of Gibraltar
Type: U.K. colony
Capital: none
Legal system: English law; constitutional talks in
July 1968; new system effected in 1969 after electoral
enquiry
Branches: parliamentary system comprised of the
Gibraltar House of the Assembly (15 elected members
and 8 ex officio members), the Council of Ministers
headed by the Chief Minister, and the Gibraltar
Council; the Governor is appointed by the Crown
Government leaders: Governor and Commander
in Chief, Marshall of the RAF Sir John Grandy, Chief
Minister, Sir Joshua Hassan
Suffrage: all adult Gibraltarians, plus other U.K.
subjects resident 6 months or more
Elections: every 5 years; last held in September
1976 :
Political parties and leaders: Labor, Sir Joshua
Hassan; Democratic Movement, Joe Boscano
Voting strengths: (September 1976) Labor, 8 seats;
Democratic Movement, 4 seats; independents, 3 seats
Communists: negligible
Other political or pressure groups: the House-
wives Association; the Chamber of Commerce;
Gibraltar Representatives Organization','51d51314b65bb63b77a5538e10ddfa79e2edd8877e5fd8ff0e7820700c44a527','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3e2fd3110ef75b768c29fa57e8fe5eac8a960516eb12df6bcdac5052120875d7',1977,'GR','Greece','government',207,'Legal name: Hellenic Republic
Type: presidential parliamentary government;
monarchy rejected by referendum December 8, 1974
79
CIA-RDP79-01051A000800010006-3
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
January 1977
Capital: Athens
Political subdivisions: 52 departments (nomoi)
constitute basic administrative units for country; each
nomos headed by officials appointed by central
government and policy and programs tend to be
formulated by central ministries; degree of flexibility
each nomos may have in altering or avoiding
programs imposed by Athens depends upon tradition
(Thessaloniki and other areas exercise considerable
traditional autonomy in local administrative
decisions) and influence which prominent local
leaders and citizens may exercise vis-a-vis key figures
in central government
Legal system: new constitution enacted in June
1975
Branches: executive consisting of a President (to be
elected by Parliament) and a Prime Minister and
cabinet; legislative comprising the 800-member
Parliament; independent judiciary
Government leaders: President Constantine
Tsatsos; Prime Minister Constantine Caramanlis
Suffrage: universal age 21 and over
Elections: every 4 years; latest November 17, 1974
Political parties and leaders: Union of the
Democratic Center, George Mavros; New Democracy,
Constantine Caramanlis; Panhellenic Socialist
Movement, Andreas Papandreou; Communist
Party—Exterior, Harilaos Florakis; Communist
Party—Interior, Haralambos Drakopoulos; and the
United Democratic Left, Ilias Iliou
Voting strength: New Democracy, 215 seats;
Union of the Democratic Center, 57 seats; Panhellenic
Socialist Movement, 15 seats; Communists, 8 seats;
independent, 5 seats
Communists: an estimated 25,000-30,000 members
and sympathizers
Member of; EC (associate), EIB (associate), EMA,
GATT, FAO, IAEA, IBRD, ICAO, IDA, IFC, IHO,
ILO, IMCO, IMF, IOOC, ITU, [WC—Intemational
Wheat Council, NATO, OECD, U.N., UNESCO,
UPU, WCL, WHO, WMO, WSG','e73072ccf88a54fda942c1ce92ba2c973b445b841c69bf087dee02930eab37c5','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cb6c4eb9d41ad13f07c4a11a03ef495169cc835c7695043d46a3edfacfe580a4',1977,'GL','Greenland','government',211,'Legal name: Greenland
Type: province of Kingdom of Denmark; 2
representatives in Danish parliament; separate
Minister for Greenland in the Danish cabinet
Capital: Godthaab (administrative center)
Approved For Release 2005/04/22 :
Political subdivisions: 3 counties, 19 communes
Legal system: Danish law; transformed from
colony to province in 1953
Branches: legislative authority rests jointly with
Crown and Danish parliament; executive power
vested in Crown, acting through provincial governor
responsible to Minister for Greenland; local affairs
handled by provincial council (Landsrad) subject to
approval of provincial governor; 19 lower courts
Government leader: Queen Margrethe II,
Governor N. O. Christensen
Suffrage: universal, but not compulsory, over age
21
Elections: held every 4 years (next 1979)
Political parties: Inuit (advocating close ties with
Denmark); Sukaq (moderate socialist, advocating
more distinct Greenland identity)
Legal name: Republic of Iceland
Type: republic
Capital: Reykjavik
Political subdivisions: 23 rural districts, 215
parishes, 14 incorporated towns
Legal system: civil law system based on Danish
law; constitution adopted 1944; legal education at
University of Iceland; does not accept compulsory IC]
jurisdiction
Branches: legislative authority rests jointly with
President and parliament (Althing); executive power
vested in President but exercised by cabinet
responsible to parliament; Supreme Court and 29
lower courts
Government leaders: President Kristjan Eldjarn;
Prime Minister Geir Hallgrimsson
Suffrage: universal, over age 20; not compulsory
Elections: parliamentary, every 4 years (next in
(1978); presidential, every 4 years (next in 1976)
Political parties and leaders: Independence
(conservative), Geir Hallgrimsson; Progressive, Olafur
Johannesson; Social Democratic, Benedikt Grondal:
People’s Alliance (Communist front), Ragnar Arnalds;
Organization of Liberals and Leftists, Magnus Torfi
Olafsson
Voting strength (1974 election): 42.7% Independ-
ence, 24.9% Progressive, 9.1% Social Democratic,
18.3% People’s Alliance, organization of leftists and
liberals 4.6%
Communists: est. 2,200; a number of sympathizers,
as indicated by 20,922 votes cast for People’s Alliance
in 1974 election
Member of: Council of Europe, EC (free trade
agreement pending resolution of fishing limits issue),
EFTA, FAO, GATT, IAEA, IBRD, ICAO, IDA, IFG-
IHO, ILO, IMCO, IMF, IPU, ITU, IWC —
International Whaling Commission, NATO, Nordic
Council, OECD, U.N., UNESCO, UPU, WHO
WMO, WSG','a4c81a4ca3e100b43f3615d3fec715ea737897454b9caa901526038fa3c01bd1','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1f83ce03b101c3ea76d47d9ebf725bc35c656e11125cb528dfd5f0190bd01a23',1977,'GD','Grenada','government',215,'Legal name: Grenada
Type: independent state since February 1974,
recognizes Elizabeth II as Chief of State
Capital: St. Georges
Political subdivisions: 6 parishes
Legal system: based on English common law
Branches: legislative branch consists of 10-member
elected House of Representatives and 13-member
Senate appointed by the Governor; executive branch
is cabinet led by Prime Minister
Government leaders: Prime Minister Eric
Matthew Gairy; U.K. Governor General Leo de Gale
Suffrage: universal adult suffrage
Elections: every 5 years; most recent general
election 28 February 1972
82
Political parties and leaders: Grenada United
Labor Party (GULP), Eric Matthew Gairy; Grenada
National Party (GNP), Herbert A. Blaize
Voting strength (1972 election): GULP 58.7%,
GNP 41.8%; Legislative Council seats, GULP 14,
GNP 1
Communists: negligible
Member of: CARICOM, IMF, OAS, SELA, U.N.','6cd220e5feaf3373868519ff72c7ed0a1f51f9bdce7cbc463eea3cdfca15624b','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b0d4d08b44e048ac4a9030cc4bfdaf55aacffc1ab6fbeba35073b498a00d6a3d',1977,'GP','Guadeloupe','government',219,'Legal name: Overseas Department of Guadeloupe
Type: overseas department and region of France;
represented by 3 deputies in the French National
Assembly and 2 Senators in the Senate
Capital: Basse-Terre
Political subdivisions: 3 arrondissements; 34
communes, each with a locally elected municipal
council
Legal system: French legal system; highest court is
a court of appeal based in Martinique with
jurisdiction over Guadeloupe, French Guiana, and','2d1a7448d43da146e9198e8455f43892de502e1711c9000c8ea366991f89792b','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('52e902320ab7adde93d2de5523b0531ee4cd1e0f5a96168de978e0d40c630414',1977,'MQ','Martinique','government',220,'Branches: executive, Prefect appointed by Paris;
legislative, popularly elected General Council of 36
members and a Regional Council composed of
members of the local General Council and the locally
elected deputies and senators to the French
parliament; judicial, under jurisdiction of French
judicial system
Government leader: Prefect Jacques Le Cornec
Suffrage: universal over age 18
Elections: General Council elections coincide with
those for the French National Assembly, normally
every 5 years; last General Council election took place
in March 1976; local election last held September
1978; last French presidential election in May 1974
Political parties and leaders: Union of Democrats
for the Republic (UDR), Gabriel Lisette; Communist
Party of Guadeloupe (PCG), Henri Bangou; Socialist
Party (MSG), leader unknown; Progressive Party of
Guadeloupe (PPG), Henri Rodes; Independent
Republicans; Federation of the Left
Voting strength: MSG, 1 seat in French National
Assembly; UDG, 2 seats; (1973 election)
Communists: 3,000 est.
Other political or pressure groups: Group of
National Organization of Guadeloupe (GONG)
Member of; WFTU
Legal name: Overseas Department of Martinique
Type: overseas department of France; represented
by 8 deputies in the French National Assembly and 2
Senators in the Senate
Capital: Fort-de-France
Political subdivisions: 2 arrondissements; 34
communes, each with a locally elected municipal
council
Legal system: French legal system; highest court is
a court of appeal based in Martinique with
jurisdiction over Guadeloupe, French Guiana, and
133
CIA-RDP79-01051A000800010006-3
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
January 1977
MARTINIQUE/MAURITANIA
Branches: executive, Prefect appointed by Paris;
legislative, popularly elected council of 36 members
and a Regional Council including all members of the
local general council and the locally elected deputies
and senators to the French parliament; judicial, under
jurisdiction of French judicial system
Government leader: Prefect Herve Bourseilleur
Suffrage: universal over age 18
Elections: General Council elections coincide with
those for the French National Assembly, normally
every five years; last General Council election took
place in March 1978; last local election held
March 1976, last French Presidential election May
1974
Political parties and leaders: Union of Democrats
for the Republic (UDR), Emile Maurice; Progressive
Party of Martinique (PPM), Aime Cesaire;
Communist Party of Martinique (PCM), Armand
Nicolas; Democratic Union of Martinique (UDM),
Leon-Laurent Valere; Socialist Party, leader
unknown; Federation of the Left, leader unknown
Voting strength: UDR, 2 seats in French National
Assembly; PPM, 1 seat (1973 election)
Communists: 1,000 estimated
Other political or pressure groups: Proletarian
Action Group (GAP), Socialist Revolution Group
(GRS)
Member of: WFTU','d8b5518b1b979f55af70b93e4f79be6c0ab000e95bc03fdeaa737709e04f0714','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('044e8ac8cc3a2e07d5e7cc6d62fb9eac916e6fb4804dd99d6344e076eec9c3f7',1977,'MX','Mexico','government',226,'Legal name: Republic of Guatemala
Type: republic
Capital: Guatemala
Political subdivisions: 22 departments
Legal system: civil law system; constitution came
into effect 1966; judicial review of legislative acts,
legal education at University of San Carlos of
Guatemala; has not accepted compulsory ICJ
jurisdiction
Branches: traditionally dominant executive;
elected unicameral legislature; 7-member (minimum)
Supreme Court
Government leader: President Kjell Laugerud
Suffrage: universal over age 18, compulsory for
literates, optional for illiterates
84
Elections: next elections (President and Congress)
1978; President cannot succeed himself
Political parties and leaders: Democratic
Institutional Party (PID), Donaldo Alvarez Ruiz;
Revolutionary Party (PR), Jorge Garcia-Granados
Quinonez (secretary general); National Liberation
Movement (MLN), Mario Sandoval Alarcon;
Guatemalan Christian Democratic Party (DCG),
Vinicio Cerezo Arevalo (sec. gen.)
Voting strength: for President—MLN-PID 298,953
(44.6%), DCG 228,067 (34.0%), PR 143,111 (21.4%);
for congressional seats—MLN-PID 36, DCG 15, PR
10
Communists: Communist party outlawed; under-
ground membership estimated at 750
Other political or pressure groups: outlawed
(Communist) Guatemalan Labor Party (PGT)
Eleuterio Cabrera Mejia (provisional secretary
general)
Member of: CACM, FAO, IADB, IAEA, IBRD,
ICAC, ICAO, IDA, IDB, IFC, IHO, ILO, IMF, ISO,
ITU, IWC—International Wheat Council, OAS,
ODECA, SELA, U.N., UNESCO, UPEB, UPU,
WCL, WHO, WMO','09c5365a268e5845a22d13949b051a37a5d7eda7aaad66e13f96482543f8b6b4','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b5e85a7034bc088acd249099456638f84004044b30e48734d65de7dff43f2ac2',1977,'GW','Guinea-Bissau','government',230,'Legal name: Republic of Guinea-Bissau
Type: republic; achieved independence from
Portugal in September 1974; constitution promul-
gated 1974
Capital: Bissau
Political subdivisions: 9 municipalities, 3
circumscriptions (predominantly indigenous popula-
tion)
Legal system: to be determined
Branches: National Popular Assembly to be elected
for three-year term; Council of State Commissars, 16
members; the official party is the supreme political
institution.
Government leaders: President of Council of State
and Chief of State is Luis Cabral; Principal
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
January 1977
GUINEA-BISSAU/GUYANA
Commissar and Head of Government, Francisco
Mendes; Secretary General of the Official party,
Aristides Pereira
Suffrage: universal over age 18
Elections: none held to date
Political parties and leaders: Partido Africano da
Independencia da Guinee e Cabo Verde (PAIGC), led
by Aristide Pereira, only legal party; Front de Lutte
pour I’Independence Nationale de la Guinea
(FLING), a largely dormant, loose coalition of
nationalist elements opposed the PAIGC, leadership
fragmented
Communists: none known
Member of: OAU, U.N., UPU','be22376a32fb869640633795e8aadb089ead7b7f8de6af9e465caec39399ea21','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a2c8f58bbebf42d0aa3be54ab6d90b8475cd1c10c1f515bb2c75e7d774988f55',1977,'GY','Guyana','government',234,'Legal name: Cooperative Republic of Guyana
Type: republic within Commonwealth
Capital; Georgetown
Political subdivisions: 9 administrative districts
Legal system: based on English common law with
certain admixtures of Roman-Dutch law; has not
accepted compulsory ICJ jurisdiction
Branches: Council of Ministers presided over by
Prime Minister; 53-member unicameral legislative
National Assembly (elected); Supreme Court
Government leader: Prime Minister L.F.S.
Burnham
Suffrage: universal over age 18 as of constitutional
amendment August 1973
Elections: last held in July 1973; next election must
be called within 5 years
Political parties and leaders: People’s National
Congress (PNC), L.F.S. Burnham; People’s Progres-
sive Party (PPP), Cheddi Jagan; United Force (UF),
Feilden Singh
87
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
January 1977
GUYANA/HAITI
Voting strength (1973 election): 70.2% PNO,
26.2% PPP, 3.6% other
Communists: est. 100 hard-core within PPP; top
echelons of PPP and PYO (Progressive Youth
Organization, militant wing of the PPP) include many
Communists, but rank and file is conservative and
non-Communist
Other political or pressure groups: Guyana
National Liberation Front (GNLF), People’s
Democratic Movement (PDM), African Society for
Cultural Relations with Independent Africa
(ASCRIA), Afro-Asian-American Association (AAAA)
Member of: CARICOM, FAO, GATT, IBA, IBRD,
ICAO, IDA, IFC, ILO, IMF, ISO, ITU, OAS
(observer), SELA, U.N., UNESCO, UPU, WCL,
WHO, WMO','c69be96fcc8efcf0d8ea2e3e0ff1783cb6d447e580e909fa0e507d940e0b14ee','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2045cfc2d50b7c313ace81c14e5afd1d8fcc593d42ea813fd29581bef185e279',1977,'HT','Haiti','government',238,'Legal name: Republic of Haiti
Type: republic under the 14-year dictatorship of
Francois Duvalier who was succeeded upon his death
on 21 April 1971 by his son, Jean-Claude
Capital: Port-au-Prince
Political subdivisions: 5 departments (despite
constitutional provision for 9)
Legal system: based on Roman civil law system; ,,
constitution adopted 1964 and amended 1971; legal
education at State University in Port-au-Prince and
private law colleges in Cap-Haitien, Les Cayes,
Gonaives, and Jeremie; accepts compulsory IC]
jurisdiction
Branches: lifetime President, unicameral 58-
member legislature of very limited powers, judiciary
appointed by President
Government leader: President-for-life Jean-Claude
Duvalier
Suffrage: universal over age 18
Elections: constitution as amended in 1971
provides for lifetime president to be designated by his
predecessor and ratified by electorate in plebiscite;
legislative elections, which are held every 6 years, last
held February 1973
Political parties: National Unity Party, only legal
party; United Haitian Communist Party (PUCH),
illegal (Communist)
Voting strength (1967 legislative elections): 100%
National Unity Party (Duvalier)
Communists: strength unknown; party leaders
believed in exile
Other political or pressure groups: none
Member of: FAO, GATT, IADB, IAEA, IBA,
IBRD, ICAO, IDA, IDB, IFC, ILO, IMCO, IMF,
ITU, OAS, SELA, U.N., UNESCO, UPU, WCL,
WHO, WMO','c9e782e373a50c3dd830fe267dbb47c458ca0277dd393745e79e30a1741b8d6b','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('66c1d17af2945e19d96f3c9faf353b879e038ef4816406abda018ece01e5fc00',1977,'HN','Honduras','government',242,'Legal name: Republic of Honduras
Type: republic
Capital: Tegucigalpa
Political subdivisions: 18 departments
Legal system: based on Roman and Spanish civil
law; some influence of English common law;
constitution adopted 1965; judicial review of
legislative acts in Supreme Court; legal education at
University of Honduras in Tegucigalpa; accepts
compulsory ICJ jurisdiction, with reservations
Branches: constitution provides for elected
President, unicameral legislature, and national
judicial branch
Government leader: Juan Alberto Melgar Castro
Suffrage: universal and compulsory over age 18
Elections: government leaders have indicated an
intention to hold elections in 1979
Political parties and leaders: all parties, even legal
ones, are dormant at present; Liberal Party (PLH),
Modesto Rodas Alvarado, Carlos Roberto Reina
Idiaguez, Jorge Bueso Arias; National Party (PNH),
Alejandro Lopez Cantarero, Ricardo Zuniga
Augustinus; Mario Rivera Lopez, Martin Aquero;
Popular Progressive Party (PPP) (uninscribed),
Gonzalo Carias Castillo; National Innovation and
90
Approved For Release 2005/04/22
Unity Party (PINU) (uninscribed), Miguel Andonie
Fernandez; Workers Party of Honduras (PTH)
(Communist) (uninscribed), Rogue Ochoa; Com-
munist Party of Honduras/Soviet (PCH/S-outlawed),
Dionisio Ramos Bejarano; Communist Party of
Honduras/China (PCH/C-outlawed), Agapito
Robledo Castro
Voting strength (1971 elections); National Party
(PNH) 306,028; Liberal Party (PLH) 276,777
Communists: about 650; 500 sympathizers
Other political or pressure groups: National
Association of Honduran Campesinos (ANACH);
Council of Honduran Private Enterprise (COHEP);
Confederation of Honduran Workers (CTH)
Member of: CACM, FAO, IADB, IBRD, ICAO,
IDA, IDB, IFC, ILO, IMCO, IMF, ISO, ITU, OAS,
U.N., UNESCO, UPEB, UPU, WCL, WHO, WMO','5109830243326965b49497201600e3745549de9f99761b995b1f5cb5ebdb443c','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f2c927782f5d8f7664e9ef840924aebec3d64611ad20736f6e476b417c8d41cd',1977,'PH','Philippines','government',246,'Legal name: Colony of Hong Kong
Type: U.K. crown colony
Capital: Victoria
Political subdivisions: Hong Kong, Kowloon, and
New Territories
Legal system: English common law
Branches: Governor assisted by advisory Executive
Council; he legislates with advice and consent of
Legislative Council; Urban Council which alone
includes elected representatives, responsible for
health, recreation, and resettlement; independent
judiciary
Government leader: C. M. MacLehose, Governor
and Commander in Chief
Suffrage: limited to 200,000 to 300,000 professional
or skilled persons
Elections: every 2 years to select one-half of elected
membership of Urban Council; other Urban Council
members appointed by the Governor
Political parties: Civic Association; Reform Club;
Socialist Democratic Party; Hong Kong Labour Party
Voting strength: (elected Urban Council members)
Civie Association 4, Reform Club 8, and 1
independent
Communists: an estimated 2,000 hard core cadres
affiliated with Communist Party of China
Other political or pressure groups: Federation of
Trade Unions (Communist controlled), Hong Kong
and Kowloon Trade Union Council (Nationalist
Chinese dominated), Hong Kong General Chamber of
Commerce, Chinese General Chamber of Commerce
(Communist controlled), Federation of Hong Kong
Industries, Chinese Manufacturers’ Association of
Legal name: Republic of the Philippines
Type: republic
Capital: Manila
Political subdivisions; 72 provinces
Legal system: based on Spanish, Islamic, and
Anglo-American law; parliamentary constitution
passed 1973; judicial review of legislative acts in the
Supreme Court; legal education at University of the
Philippines, Ateneo de Manila University, and 71
other law schools; accepts compulsory ICJ jurisdic-
tion, with reservations; currently being ruled under
martial law
Branches: new constitution (currently suspended)
provides for unicameral National Assembly, and a
strong executive branch under a Prime Minister;
judicial branch headed by Supreme Court with
descending authority in a Court of Appeals, courts of
First Instance in various provinces, municipal courts
in chartered cities, and justices of the peace in towns
and municipalities; these justices have considerably
more authority than do justices of the peace in the
USS.
Government leader:
Marcos
Suffrage: universal over age 18
Elections: elections suspended for the indefinite
future
Political parties and leaders: political parties
currently in limbo because of martial law
Communists: about 1,600 armed insurgents
Member of: ADB, ASEAN, ASPAC, Colombo
Plan, ESCAP, FAO, IAEA, IBRD, ICAO, IDA, IFC,
President Ferdinand E.
164
IHO, ILO, IMCO, IMF, IPU, ISO, ITU, U.N.,
UNESCO, UPU, WCL, WFTU, WHO, WMO','98b98e82f1db9be68451986ffc22f3d54927b7832cc135aeb970a788866cf8f6','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a6cba88e61f86acf137d65262ae9ff620a312666224199694b0e9ebda60b7988',1977,'HU','Hungary','government',251,'Legal name: Hungarian Peoples Republic
Type: Communist state
Capital: Budapest
Political subdivisions: 19 megyes (counties), 5
autonomous cities in county status, 97 jaras (districts)
Legal system: based on Communist legal theory,
with both civil law system (civil code of 1960) and
common law elements; constitution adopted 1949
amended 1972; Supreme Court renders decisions of
principle that sometimes have the effect of declaring
legislative acts unconstitutional; legal education at
Lorand Eotvos Tudomanyegyetem School of Law in
Budapest and 2 other schools of law; has not accepted
compulsory ICJ jurisdiction
Branches: executive—Presidential Council (elected
by Parliament); legislative—Parliament (elected by
direct suffrage); judicial—Supreme Court (elected by
Parliament)
Government leaders: Gyorgy Lazar, Chairman,
Council of Ministers; Pal Losonczi, President,
Presidential Council
Suffrage: universal over age 18
Elections: every 5 years; national and local
elections are held separately
Political parties and leaders: Hungarian Socialist
(Communist) Workers Party (sole party); Janos Kadar
is First Secretary of Central Committee
Voting strength (1975 election): 7,497,061 (99.6% )
for Communist-approved candidates; 30,108 (0.4%)
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
January 1977
HUNGARY/ICELAND
invalid and negative votes; total eligible electorate
about 7.76 million; next elections will be held in 1980
Communists: about 754,000 party members
(March 1975)
Member of: CEMA, Danube Commission, FAO,
GATT, IAEA, ICAG, ICAO, ILO, International Lead
and Zine Study Group, IMCO, IPU, ISO, ITC, ITU,
U.N., UNESCO, UPU, Warsaw Pact, WFTU, WHO,
WMO','28bb666f3cd73563555f4f05b8842ebeb60007592a38591f2b983cbb75032369','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b9c4a5a52b5852c25053f7bab531d1e5a61a3979ab5f31d0ed3905f40f4daafc',1977,'ID','Indonesia','government',255,'Legal name: Republic of Indonesia
Type: republic
Capital: Jakarta
Political subdivisions: 27 first-level administrative
subdivisions or provinces which are further subdivided
into 282 second-level areas
Legal system: based on Roman-Dutch law,
substantially modified by indigenous concepts;
constitution of 1945 is legal basis of government; legal
education at University of Indonesia, Jakarta; has not
accepted compulsory IC] jurisdiction
Branches: executive headed by President who is
chief of state and head of cabinet; cabinet selected by
President; unicameral legislature (Parliament), of 460
members (100 appointed, 360 elected); second and
larger body (Congress) of 920 members and includes
the legislature and 460 other members (chosen by
several processes, but not directly elected) elects
President and Vice President, and theoretically
determines national policy
Government leader: President Suharto (elected by
Congress March 1973)
Suffrage: universal over age 17 and married persons
regardless of age
Political parties and leaders: Golkar (quasi-official
“party” based on functional groups), Amir Moertono;
Indonesian Democratic Party (federation of former
Nationalist and Christian parties), Mohammed
Isnaeni; Unity Development Party (federation of
former Islamic parties), Idham Chalid
Voting strength (1971 election): Golkar 236 seats,
Indonesian Democratic 30, Unity Development 94
Communists: Communist Party (PKI) was
officially banned in March 1966; current strength est.
at 1,000, with less than 10% engaged in organized
activity; pre-October 1965 hard-core membership has
been estimated at 1.5 million
Member of: ADB, ANRPC, ASEAN, CIPEC,
ESCAP, FAO, IAEA, IBA, IBRD, ICAO, IDA, IFC,
IHO, ILO, IMCO, IMF, IPU, ISO, ITC, ITU,
OPEC, U.N., UNESCO, UPU, WCL, WFTU, WHO,
WMO
Legal name: Empire of Iran
Type: constitutional monarchy, controlled by the
Shah
Capital: Tehran
Political subdivisions: 21 provinces and 2 chief-
governorates, subdivided into districts, sub-districts,
counties, and villages
Legal system: based largely on French law, with
elements drawn from other continental systems;
personal law based on Islamic practice generally with
residual traces of Roman law; constitution adopted
1906 and constitutional law of 1907; High Court of
Appeal may judge disputes relating to government
departments acting according to law; legal education
at University of Teheran; has not accepted com-
pulsory ICJ jurisdication
Branches: executive power rests in Shah who
appoints a Prime Minister; Prime Minister must be
approved by lower house (Majlis); while Cabinet
theoretically responsibility of Prime Minister, Shah
usually exerts strong influence over its selection;
bicameral legislature; Majlis has 268 members elected
to 4-year terms, and Senate 60 members serving 4-year
98
terms; half of Senate members appointed by Shah,
other half elected; no provision for judicial review of
constitutionality of legislative acts
Government leaders: Shah Mohammad Reza
Pahlavi and Prime Minister Amir Abas Hoveyda
Suffrage: universal over age 20
Elections: Majlis every 4 years; Senate every 4
years; latest national elections June 1975, last district
and municipal October 1976
Political parties and leaders: a single party
system, designated The Resurgence Party of the
People of Iran (RPPI} with Prime Minister Amir
Abbas Hoveyda as Secretary-General, was formed by
Shah in March 1975; all other political parties
disbanded
Voting strength: all candidates government
approved and members of the RPPI
Communists: 1,000-2,000 (hard-core, est.); sympa-
thizers (15,000-20,000 est. ); mostly pro-U.S.S.R. but
pro-Chinese faction developing
Other political or pressure groups: Tudeh Party
(Communist, illegal); National Front (coalition of
neutralist urban elements virtually discredited
because of opposition to Shah’s reform program);
Confederation of Iranian Students (illegal)
Member of: CENTO, Colombo Plan, FAO, IAEA,
IBRD, ICAC, ICAO, IDA, IFC, IHO, ILO, IMCO,
IMF, IPU, ITU, OPEC, RCD, U.N., UNESCO,
UPU, WFTU, WHO, WMO, WSG','7f10a06417fa7ffd2fc4121249f17a268ad04909ef97adb66259487ace890b2f','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cf96dccade6b0b39c79d5a11e50a8374869d7c31901a6b30c61574fcdb0a37da',1977,'IQ','Iraq','government',259,'Legal name: Republic of Iraq
Type: republic; National Front Government
consisting of Baath Party (BPI), and Iraq Communist
Party (CPI) formed in July 1973 (Kurds invited to join
National Front government but have refused pending
solution of Kurdish autonomy issue; Communists play
nominal role in government)
Capital: Baghdad
Political subdivisions: 16 provinces under centrally
appointed officials
Legal system: based on Islamic law in special
religious courts, civil law system elsewhere;
provisional constitution adopted in 1968; judicial
review was suspended; legal education at University
of Baghdad; has not accepted compulsory IC]
jurisdiction
Branches: Baath Party of Iraq has been in power
since 1968 coup
Government leaders: President Ahmad Hasan al-
Bakr; Deputy Chairman of the Revolutionary
Command Council Saddam Husayn ’ Abd-al-Majid
al-Tikriti
Suffrage: no elective bodies exist
Elections: no national elections since overthrow of
monarchy in 1958
Communists: Communist Party allowed token
representation in cabinet; est. 2,000 hard-core
members
Political or pressure groups: political parties
banned, possibly some opposition to regime from
disaffected members of the regime and army officers
Member of: Arab League, FAO, IAEA, IBRD,
ICAO, IDA, IFC, ILO, IMF, ITU, OAPEC, OPEC,
U.N., UNESCO, UPU, WFTU, WHO, WMO, WSG','d35bbef69973cdcc5d013f5cce6f7c099a4ad783b96e62fc509403057f5e0d7a','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a9f34d89d0519e0bfd9bbec4e5ff6a086e65b2d7a750f5403f47cb3fd07e1827',1977,'IE','Ireland','government',263,'Legal name: Ireland, Eire (Gaelic)
Type: republic
Capital: Dublin
Political subdivisions: 26 counties
Legal system: based on English common law,
substantially modified by indigenous concepts;
constitution adopted 1937; judicial review of
legislative acts in Supreme Court; has not accepted
compulsory ICJ jurisdiction
Branches: elected President; bicameral parliament
reflecting proportional and vocational representation;
judiciary appointed by President on advice of
Government leaders: President Patrick Hillary;
Prime Minister (Taoiseach) Liam Cosgrave; Deputy
Prime Minister (Tanaiste) Brendan Corish
: CIA-RDP79-01051A000800010006-3
fa
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
January 1977
IRELAND/ISRAEL
Suffrage: universal over age 18
Elections: Dail (lower house) elected every 5
years—last election February 1973; President elected
for 7-year term—last election December 1974
Political parties and leaders: Fianna Fail, John
(Jack) Lynch; Labor Party, Brendan Corish; Fine
Gael, Liam Cosgrave; Communist Party of Ireland,
Michael O’ Riordan
Voting strength: (1973 election) Fianna Fail 46%
(69 seats), Fine Gael 35% (54 seats), Labor Party 14%
(19 seats), other 5%; Independents hold 2 seats
Communists: approximately 600
Member of: Council of Europe, EC, EEC, ESRO
(observer), EURATOM, FAO, GATT, IBRD, ICAO,
IDA, IEA, IFC, ILO, IMCO, IMF, IPU, ISO, ITU,
[WC—International Wheat Council, OECD, UN.,,
UNESCO, UPU, WHO, WMO, WSG','45be3ca6d4563e9aa97677df44d1403b7b1e54b50d1343a883243fc3a1218f8c','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4dd5863fe33f3e5dd32d39f890c882f480026f1498efd663b571426a54040bd7',1977,'IL','Israel','government',267,'Legal name: State of Israel
Type: republic
Capital: Jerusalem; not recognized by U.S. which
maintains Embassy in Tel Aviv
Political subdivisions: 6 administrative districts
Legal system: mixture of English common law
and, in personal area, Jewish, Christian and Muslim
legal systems; commercial matters regulated
substantially by codes adopted since 1948; no formal
constitution; some of the functions of a constitution
are filled by the Declaration of Establishment (1948),
the basic laws of the Knesset (legislature) relating to
the Knesset, Israeli lands, the president, the
government and the Israel citizenship law; no judicial
review of legislative acts; legal education at Hebrew
University in Jerusalem; accepts compulsory ICJ
jurisdiction, with reservations
Branches: President Ephraim Katzir has largely
ceremonial functions; executive power vested in
cabinet; unicameral parliament (Knesset) of 120
members elected under a system of proportional
representation; legislation provides fundamental laws
in absence of a written constitution; 2 distinct court
systems (secular and religious)
Government leader: Prime Minister Yitzhak Rabin
Suffrage: universal over age 18
Elections: held every 4 years unless required by
dissolution of Knesset; last election held in December
1973
102
Principal political parties and leaders: Israel
Labor Party, Prime Minister Yitzhak Rabin, Golda
Meir, Haim Zadok, Moshe Dayan, Yigal Allon,
Shimon Peres; United Workers Party (MAPAM) in
alignment with Israel Labor Party, Meir Talmi;
National Religious Party, Minister of Interior Dr.
Joseph Burg; Independent Liberal Party, Minister of
Tourism Moshe Kol; Herut (Freedom) Party,
Menahem Begin; Liberal Party, Simha Ehrlich;
La’am, Yigal Hurwitz; Herut and the Liberal Party
are called the GAHAL bloc and, together with La’am
and Free Center, they form the Likud bloc led by
Menahem Begin; AKI (Israel! Communist Opposition
Party—predominantly Jewish), leader Esther Wil-
enska; RAKAH (Communist Party—predominantly
Arab), Secretary General Meir Wilner
Voting strength: out of 120 seats, Israel Labor
Party-MAPAM-Arab List Alignment 53 seats; Likud
bloc 88 seats; National Religious Party 10 seats;
Independent Liberal Party 4 seats; Agudat Religious
Front 5 seats; RAKAH 4 seats; Citizens’ Rights
Movement 2 seats; Independent Socialist 2 seats;
Moked 1 seat; independents 1 seat
Communists: divided between AKI (Jewish party),
a new splinter group with at most a few hundred
members, and RAKAH (Arab party) with some 1,500
members; neither constitutes a subversive threat
Other political or pressure groups: right-wing
Jewish Defense League led by Rabbi Meir Kahane;
Black Panthers, a loosely organized youth group
seeking more benefits for oriental Jews; Gush
Emunim, Jewish religious zealots pushing for freedom
for Jews to settle anywhere on the West Bank
Member of: FAO, GATT, IAEA, IBRD, ICAC,
ICAO, IDA, IFC, ILO, IMCO, IMF, IOOC, IPU,
ITU, IWC—International Wheat Council, OAS
(observer), U.N., UNESCO, UPU, WFTU, WHO,
WMO, WSG','90f49edf6032e6a258d211855c18b51e925373b7f0e028b7395e0be56ddfed61','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a65fb9f80429c2c895a03bc5a4de98f134290750c4e21cadc30fed547010e57b',1977,'IT','Italy','government',271,'Legal name: Italian Republic
Type: republic
Capital: Rome
Political subdivisions: constitution provides for
establishment of 20 regions; 5 (Sicilia, Sardegna,
Trentino-Alto Adige, Friuli-Venezia Giulia, and Valle
d’ Aosta) have been functioning for some time and the
remaining 15 regions were instituted on 1 April 1972;
94 provinces
Legal system: based on civil law system, with
ecclesiastical law influence; constitution came into
effect 1 January 1948; judicial review under certain
conditions in Constitutional Court; has not accepted
compulsory ICJ jurisdiction
103
CIA-RDP79-01051A000800010006-3
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
January 1977
Branches: executive—President empowered to
dissolve Parliament and call national election; he is
also Commander of the Armed Forces and presides
over the Supreme Defense Council; otherwise,
authority to govern invested in Council of Ministers;
legislative power invested in bicameral, popularly
elected Parliament; Italy has an independent judicial
establishment
Government leaders: President Giovanni Leone;
Premier Guilio Andreotti
Suffrage: universal over age 18 (except in
Senatorial elections where minimum age of voter is
25)
Elections: national elections for Parliament held
every 5 years (most recent, June 1976); provincial and
municipal elections held every 5 years with some out
of phase; regional elections every 5 years (held June
1975)
Political parties and leaders: Christian Demo-
cratic Party (DC), Benigno Zaccagnini (secretary
general), Aldo Moro (party president); Communist
Party (PCI), Enrico Berlinguer (secretary general),
Luigi Longo (party president); Socialist Party (PSI),
Bettino Craxi (secretary general), Pietro Nenni (party
president); Social Democratic Party (PSDI), Pierluigi
Romita (secretary general); Liberal Party (PLI),
Valerio Zanone (party secretary); Italian Social
Movement (MSI), Giorgio Almirante; Republican
Party (PRI), Oddo Biasini (party secretary); Ugo La
Malfa (party president)
Voting strength (1976 election): 38.7% DC, 34.4%
PCI, 9.6% PSI, 6.1% MSI, 3.4% PSDI, 3.1% PRI,
1.8% PLI, 3.4% other
Communists: 1,726,350 members (as of October
1975)
Other political or pressure groups: the Vatican;
three major trade union confederations (CGIL—
Communist dominated, CISL—Christian Democra-
tic, and UIL—Social Democratic, Socialist, and
Republican); Italian manufacturers association
(Confindustria); organized farm groups
Member of: ADB, ASSIMER, Council of Europe,
DAC, EC, ECOWAS, ECSC, EEC, EIB, ELDO,
ESRO, EURATOM, FAO, GATT, IAEA, IBRD,
ICAC, ICAO, IDA, IEA, IFC, IHO, ILO,
International Lead and Zinc Study Group, IMCO,
IMF, IOOC, IPU, ITC, ITU, NATO, OAS (observer),
OECD, U.N., UNESCO, UPU, WCL, WEU, WFTU,
WHO, WMO, WSG','55aa60bc4babe711d4e5e98f1a05c88fd30d9ee05367bded15bced13bc04da54','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6da564072576e5c4f9f43475f7f98cd77570aaf92fd50119fbf24d413431ca6d',1977,'JM','Jamaica','government',275,'Legal name: Jamaica
Type: independent state within Commonwealth
since August 1962, recognizing Elizabeth II as head of
state
Capital: Kingston
Political subdivisions: 12 parishes and the
Kingston-St. Andrew corporate area
: CIA-RDP79-01051A000800010006-3
ly tl
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
January 1977
JAMAICA/JAPAN
Legal system: based on English common law; has
not accepted compulsory IC] jurisdiction
Branches: cabinet headed by Prime Minister; 60-
member elected House of Representatives; 21-
member Senate (13 nominated by the Prime Minister,
8 by opposition leader); judiciary follows British
tradition under a Chief Justice
Government leader: Prime Minister Michael
Manley
Suffrage: universal, age 18 and over
Elections: at discretion of Governor-General upon
advice of Prime Minister but within 5 years; latest
held 29 February 1972
Political parties and leaders: People’s National
Party (PNP), Michael Manley; Jamaica Labor Party
(JLP), Edward Seaga
Voting strength: (1972 general elections) 56.55%
PNP, 43.21% JLP, 0.24% other
Communists: a few hundred Marxist and
Communist sympathizers
Other political or pressure groups: New World
Group (Caribbean regionalists, nationalists, and leftist
intellectual fraternity); Rastafarians (Negro religious /
racial cultists, pan-Africanists); New Creation
International Peacemakers Tabernacle (leftist group);
Workers Liberation League (a Marxist coalition of
students /labor)
Member of: CARICOM, FAO, GATT, IADB,
IAEA, IBA, IBRD, ICAO, IDB, IFC, ILO, IMF, ISO,
ITU, OAS, Pan American Health Organization,
SELA, U.N., UNESCO, UPU, WCL, WHO, WMO','392584d8ee9487409c231625a37e49a7d7ed64feee3fe0d17917eb4495b1a8c0','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('64a2a1810125c7bc267cdb8ad3b7531b79b72c4fd3b643fbe6b38f3b0eab99d4',1977,'JP','Japan','government',279,'Legal name: Japan
Type: constitutional monarchy
Capital: Tokyo
Political subdivisions: 47 prefectures (Ryukyus
became 47th prefecture on 15 May 1972)
Legal system: civil law system with English-
American influence; constitution promulgated in
1946; judicial review of legislative acts in the Supreme
Court; accepts compulsory ICJ jurisdiction, with
reservations
Branches: Emperor is merely symbol of state;
executive power is vested in cabinet dominated by the
Prime Minister, chosen by the Lower House of the
bicameral, elective legislature (Diet); judiciary is
independent
Government leader: Prime Minister Takeo Fukuda
Suffrage: universal over age 20
Elections: general elections held every 4 years or
upon dissolution of Lower House, triennially for one-
half of Upper House
Political parties and leaders: Liberal Democratic
Party (LDP), T. Fukuda, President; Japan Socialist
Party (JSP), T. Narita, Chairman; Democratic
Socialist Party (DSP), I. Kasuga, Chairman; Japan
Communist Party (JCP), K. Miyamoto, Presidium
Chairman; Komeito (CGP), Y. Takeiri, Chairman;
New Liberal Club (NLC), Y. Kono
Voting strength (1976 election): 41.8% LDP,
20.7% JSP, 10.9% GCP, 10.4% JCP, 6.3% DSP, 4.2%
NLC, 5.7% independents
108
Approved For Release 2005/04/22
Communists: 350,000; 3,000,000 sympathizers
Member of: ADB, ASPAC, Colombo Plan, DAC,
ESCAP, FAO, GATT, IAEA, IBRD, ICAC, ICAO,
IDA, IEA, IFC, IHO, ILO, International Lead and
Zine Study Group, IMCO, IMF, IPU, IRC, ISO, ITC,
ITU, IWC—International Whaling Commission,
IWC—International Wheat Council, OECD, ULN,,
UNESCO, UPU, WCL, WFTU, WHO, WMO, WSG
Legal name: Democratic Peoples Republic of
Korea
Type: Communist state; one-man rule
Capital: P’yongyang
Political subdivisions: 9 provinces, 3 special cities
(Pyongyang, Hamhung, Ch’ongjin), and 1 special
district (Kaesong)
Legal system: based on German civil law system
with Japanese influences and Communist legal
theory; constitution adopted 1948 and revised 1972;
no judicial review of legislative acts; has not accepted
compulsory ICJ jurisdiction
Branches: Supreme Peoples Assembly theoretically
supervises Legislative and Judicial function
Government and party leaders: Kim Il-song,
President DPRK, and General Secretary of the Korean
Workers Party; Pak Song-chol, Premier
Suffrage: universal at age 17
Elections: election to SPA every 4 years, but this
constitutional provision not necessarily followed—
last election December 1972
Political party: Korean Workers (Communist)
Party; claimed membership of about 1.6 million, or
about 12% of population
Member of: IPU, U.N. (observer status only),
UNCTAD, WFTU, WHO
Legal name: Republic of Korea
Type: republic; power centralized in a strong
executive
Capital: Seoul
Political subdivisions: 9 provinces, 2 special cities;
heads centrally appointed
Legal system: combines elements of continental
European civil law systems, Anglo-American law, and
Chinese classical thought; constitution approved
1972; has not accepted compulsory IC] jurisdiction
Branches: executive, legislative (unicameral),
judiciary, National Conference of Unification
Government leaders: President Pak Chong-hui;
Prime Minister Choe Kyu-ha
Suffrage: universal over age 20
Elections: presidential every 6 years indirectly by
the National Conference of Unification, last election
December 1972; two-thirds of the 219-member
National Assembly is elected directly for the same
period within six months of the presidential election,
remaining third nominated by the President and
elected by the National Conference for a three-year
term; last election February 1973, Revitalization
Group—73 seats, Democratic Republican Party—73
seats, New Democratic Party—52 seats, Democratic
Unification Party—2 seats, Independents—19 seats
Political parties and leaders: pro-government—
Revitalization Group (appointed) (Chairman, Pak
Tu-Chin) and Democratic Republican Party (Acting
Chairman, Yi Hyo-sang); New Democratic Party
(Chairman, Yi Chol-sung); Democratic Unification
(Chairman, Yang Il-tong)
Voting strength: (1973 election) popular vote
11,896,484; DRP 38.8%, NDP 32.8%, DUP 10.2%,
Independent 18.1%, 0.1% invalid
Communists: Communist activity banned by
government; an estimated 37,000-50,000 former
members and supporters
Other political or pressure groups: Federation of
Korean Trade Unions; Korean Veterans Association;
large potentially volatile student population
concentrated in Seoul
Member of: ADB, Asian Parliamentary Union,
Asian People’s Anti-Communist League (APACL),
ASPAC, Colombo Plan, ESCAP, FAO, GATT,
Geneva Conventions of 1949 for the protection of war
victims, IAEA, IBRD, ICAC, ICAO, IDA, IFC, IHO,
IMCO, IMF, INTELSAT, INTERPOL, IPU, ITC,
ITU, {WC—International Wheat Council, UNES-
CO, U.N. Special Fund, UPU, WCL, WHO, WMO,
World Anti-Communist League (WACL); official
observer at U.N., does not hold U.N. membership
Legal name: Peoples Democratic Republic of','6074a390aba7e45e2b44b462b3d66219cda759d1910772625600c07992d41259','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('09f8c926abb67c6ad961889ae686aefce0aacdb3fbcbaf59287ad2b70d280f22',1977,'JO','Jordan','government',283,'Legal name: Hashemite Kingdom of Jordan
Type: constitutional monarchy
Capital; ‘Amman
Political subdivisions: 8 governorates (3 are under
Israeli occupation) under centrally appointed officials
Legal system: based on Islamic law and French
codes; constitution adopted 1952; judicial review of
legislative acts in a specially »rovided High Tribunal;
has not accepted compulsory IC] jurisdiction
Branches: King holds balance of power; Prime
Minister exercises executive authority in name of
King; Cabinet appointed by King and responsible to
parliament; bicameral parliament with House of
Representatives last chosen by national elections in
April 1967, and dissolved by King in February 1976;
Senate last appointed by King in November 1974; met
briefly in February 1976 to amend constitution
allowing King to postpone elections; present
parliament subservient to executive; secular court
system based on differing legal systems of the former
Transjordan and Palestine; law Western in concept
and structure; Sharia (religious) courts for Muslims,
and religious community council courts for non-
Muslim communities; desert police carry out quasi-
judicial functions in desert areas
Government leader: King Husayn ibn Talal al-
Hashimi
Suffrage: all citizens over age 20
Political parties and leaders: political party
activity illegal since 1957; Palestine Liberation
Organization and various smaller fedayeen groups
clandestinely active on West Bank; Muslim
Brotherhood
109
: CIA-RDP79-01051A000800010006-3
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
January 1977
JORDAN/KENYA
Communists: party actively repressed, membership
estimated at less than 500
Member of: Arab League, FAO, IAEA, IBRD,
ICAO, IDA, IFC, ILO, IMF, IPU, ITU, U.LN.,
UNESCO, UPU, WHO, WMO
Legal name: Republic of Kenya
Type: republic within Commonwealth since
December 1963
Capital: Nairobi
Political subdivisions: 7 provinces plus Nairobi
Area
Legal system: based on English common law,
tribal law and Islamic law; constitution enacted 1963;
judicial review in Supreme Court; legal education at
University Kenya School of Law in Nairobi; accepts
compulsory ICJ jurisdiction, with reservations
Branches: President and Cabinet responsible to
unicameral legislature (National Assembly) of 170
CIA-RDP79-01051A000800010006-3
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
January 1977
seats, 158 directly elected by constituencies and 12
appointed by the President; Assembly must be
reelected at least every 5 years; High Court, with
Chief Justice and at least 11 justices, has unlimited
original jurisdiction to hear and determine any civil or
criminal proceeding; provision for systems of courts of
appeal with ultimate appeal to East African Court of
Appeals
Government leader: President Jomo Kenyatta
Suffrage: universal over age 21
Elections: general election (October 1974) elected
present National Assembly; next elections due 1979
Political party and leaders: Kenya Africa National
Union (KANU), president, Jomo Kenyatta
Voting strength: KANU holds all seats in the
National Assembly
Communists: may be a few Communists and
sympathizers
Other political or pressure groups: labor unions
Member of: AFDB, EAC, FAO, GATT, IAEA,
IBRD, ICAO, IDA, IFC, ILO, IMF, ISO, ITU,
{WC—International Wheat Council, OAU, UN.,
UNESCO, UPU, WHO, WMO','acf83487501baae29b3ee910e70024e22ab13d36751a48a9c3579632d03e34f7','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a8d5840de03c6207caea00a4c502ea7e60c543073d57c6d968d01a64b000ccd6',1977,'KW','Kuwait','government',287,'Legal name: State of Kuwait
Type: nominal constitutional monarchy
Capital: Kuwait
Political subdivisions: 3 governorates, 10 voting
constituencies
Legal system: civil law system with Islamic law
significant in personal matters; constitution took
effect 1968; key provisions regarding election of
National Assembly suspended in August 1976;
judicial review of legislative acts not yet determined;
has not accepted compulsory ICJ jurisdiction
Branches: Council of Ministers
Government leader: Emir Sabah al-Salim Al
Sabah
Suffrage: native born and naturalized males age 21
or over
Elections: National Assembly dissolved by Emir’s
decree in August 1976
Political parties and leaders: political parties
prohibited, some small clandestine groups are active
Communists: insignificant
Other political or pressure groups: none
Member of: Arab League, FAO, GATT, IAEA,
IBRD, ICAO, IDA, IFC, ILO, IMCO, IMF, IPU,
ITU, OAPEC, OPEC, U.N., UNESCO, UPU, WHO,
WMO
Legal name: Lao People’s Democratic Republic
Type: republic
Capital: Vientiane
Political subdivisions: 13 provinces subdivided
into districts, cantons, and villages
Legal system: based on civil law system; has not
accepted compulsory IC] jurisdiction
Branches: President; 45-member Supreme Council;
39-member cabinet formed on 4 December 1975;
cabinet is totally Communist but council contains a
few nominal neutralists and non-Communists,
Supreme People’s Assembly, a quasi-legislature tasked
with drafting constitution and election law
Government leaders: President, Souphanouvong;
Prime Minister, Kaysone Phomvihan; Deputy Prime
Ministers, Nouhak Phoumsavan, Phoumi Vongvichit,
Phoun Sipaseut, and Khamtai Siphandone
Suffrage: universal over age 18
Elections: elections for new National Assembly,
scheduled for April 1, 1976, have been postponed
Political parties and leaders: Lao People’s
Revolutionary Party (Communist) includes Lao
Patriotic Front and Alliance Committee of Patriotic
Neutralist Forces; other parties are moribund
Communists: Lao People’s Revolutionary Party;
membership unknown
Other political or pressure groups: non-
Communist political groups are moribund; most
leaders have fled the country
Member of: ADB, Colombo Plan, ESCAP, FAO,
IBRD, ICAO, IDA, ILO, IMF, IPU, ITU, Mekong
Committee, SEAMES, U.N., UNCTAD, UNESCO,
UPU, WFTU, WHO, WMO','da0cb796256f5178cf018db0729efe0bec2e0bc925f4f5111c96d62539b00ed4','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b3fd41f6ee4a7e403d49372eeef79578fe20374edfc64ffb43bd63ce276a0964',1977,'LB','Lebanon','government',291,'NOTE: Civil strife between Lebanese Christians
aided by Syrian troops on the one hand, and Lebanese
Muslims and their Palestinian allies on the other
hand, has plagued Lebanon since early 1975, causing
the near-collapse of central governmental authority.
Much of the country is now under Syrian occupation;
Damascus is trying to force the Palestinians to return
to their refugee camps and keep out of Lebanon’s
internal affairs, and to preserve a unitary Lebanese
state—under a modified constitution—that will be
responsive to Syria’s influence. At issue in the fighting
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
January 1977
LEBANON/LESOTHO
have been the structure of Lebanon’s parliamentary
government and the country’s traditional political
practices, which have favored the Christian minority.
The following description is based on the present
constitutional and customary practices of the
Lebanese system.
Legal name: Republic of Lebanon
Type: republic
Capital: Beirut
Political subdivisions: 5 provinces
Legal system: mixture of Ottoman law, canon law,
and civil law system; constitution mandated in 1920,
no judicial review of legislative acts; legal education
at University of Lebanon; has not accepted
compulsory ICJ jurisdiction
Branches: power lies with President elected by
parliament (Chamber of Deputies); cabinet appoint-
ed by President, approved by parliament, independ-
ent secular courts on French pattern; religious courts
for matters of marriage, divorce, inheritance, ete.; by
custom, President is a Maronite Christian, Prime
Minister a Sunni Muslim, and president of parliament
a Shia Muslim; each of 9 religious communities
represented in parliament in proportion to national
numerical strength
Government leader: President Ilyas Sarkis
Suffrage: compulsory for all males over 21;
authorized for women over 21 with elementary
education
Elections: Chamber of Deputies held every 4 years
or within 3 months of dissolution of Chamber; latest
April 1972
Political parties and leaders: political party
activity is organized along sectarian lines, numerous
political groupings exist, consisting of individual
political figures and followers motivated by religious,
clan, and economic considerations; political stability
dependent on maintenance of balance between
religious communities
Communists: only legal Communist party in
Middle East; legalized in 1970; members and
sympathizers estimated at 2,000-3,000
Other political or pressure groups: Palestinian
guerrilla organizations
Member of: Arab League, FAO, IAEA, IBRD,
ICAO, IDA, IFC, ILO, IMCO, IMF, IPU, ITU,
[WC—International Wheat Council, U.N., UNES-
CO, UPU, WFTU, WHO, WMO, WSG','1752013215cf0f674d5acd69f400631ba6fefedbffd8f218462dd72d191ac029','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d2639e0e275245b5b3acf856939e348ce5c93b9ff48e9d3e149e68e3ef3d7aa2',1977,'LS','Lesotho','government',295,'Legal name: Kingdom of Lesotho
Type: constitutional monarchy under King
Moshoeshoe II; independent member of com-
monwealth since 1966
Capital: Maseru
Political subdivisions: 9 administrative districts
Legal system: based on English common law and
Roman-Dutch law; constitution came into effect
1966; judicial review of legislative acts in High Court
and Court of Appeal; legal education at University of
Botswana, Lesotho, and Swaziland (located in
Lesotho); has not accepted compulsory IC]
jurisdiction
Branches: executive, divided between a largely
ceremonial King and a Prime Minister who leads
cabinet of at least 7 members; Prime Minister
dismissed bicameral legislature in early 1970 and
subsequently has ruled by decree; Prime Minister
appointed Interim National Assembly in April 1973;
judicial—63 Lesotho courts administer customary law
for Africans, High Court and subordinate courts have
criminal jurisdiction over all residents, Court of
Appeal at Maseru has appellate jurisdiction
Government leader: Prime Minister Chief Leabua
Jonathan
Suffrage: universal for adults
118
Elections: elections held in January 1970; nullified
allegedly because of election irregularities; subsequent
elections promised at unspecified date
Political parties and leaders: National Party
(BNP), Chief Leabua Jonathan; Basutoland Congress
Party (BCP), Ntsu Mokhele
Voting strength: in 1970 elections for National
Assembly, BNP won 82 seats; BCP, 22 seats; minor
parties, 4 seats
Communists: negligible, Communist Party of
Lesotho banned in early 1970
Member of: Commonwealth, FAO, GATT (de
facto), IBRD, IDA, IFC, IMF, ITU, OAU, U.N.,
UNESCO, UPU, WHO','9229c5113d1e3ddb938522208abe532abbf557dabbc83327317bef813de78c56','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1a68536d00dad852fd7b6d7a6c95792be7e2d1384d9dd5d06cc424756fdedd11',1977,'LR','Liberia','government',299,'Legal name: Republic of Liberia
Approved For Release 2005/04/22
Type: republic in form; strong executive dominates,
with few constraints
Capital: Monrovia
Political subdivisions: country divided into 9
counties; President appoints all officials of
significance
Legal system: based on U.S. constitutional theory;
recent codes drawn up by Cornell University;
constitution adopted 1847; amended 1907, 1926,
1934, 1955, and 1975; no constitutional provision for
judicial review of legislative acts; legal education at
Louis Arthur Grimes School of Law, University of
Liberia; accepts compulsory ICJ jurisdiction, with
reservations
Branches: President, elected by popular vote,
limited to a single eight-year term, controls through
appointive powers, authority over national expendi-
tures, and a variety of informal sanctions; 2-house
legislature elected by popular vote; judiciary
consisting of Supreme Court and variety of lower
courts
Government leader: President William R. Tolbert,
Jr.
Suffrage: universal 18 years and over
Elections: members of House of Representatives
elected for 4-year terms, most recently in October
1975; Senate members elected for 6-year terms, one-
half elected in May 1973, President Tolbert,
constitutional successor to President Tubman who
died in July 1971, completed the four year term to
which Tubman was elected and was then elected in
October 1975 for an eight-year term beginning in
January 1976
Political parties and leaders: True Whig Party, in
power since 1878, only political party; President
Tolbert is leader
Voting strength: 1975 elections uncontested; True
Whig Party won all but a handful of votes
Communists: no Communist Party and only a few
sympathizers
Member of: AFDB, ECA, ECOWAS, FAO, JAEA,
IBRD, ICAO, IDA, IFC, ILO, IMCO] IMF, IPU,
ITU, OAU, U.N., UNESCO, UPU, WHO','02f33a2b9a85297975d3d724d2f0279f1418347fc2c9f4762c719041e56cf6e1','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('829e2393a771b5cb0f2f49c5d0902ee473ff99c047213fb03c7f5de0b488ff39',1977,'LY','Libya','government',303,'Legal name: Libyan Arab Republic
Type: republic; under military control following
ouster of king on 1 September 1969; provisional
constitution promulgated December 1969; loosely
confederated with Egypt and Syria in Confederation
of Arab Republics (CAR) on 1 September 1971
Capital: Tripoli
Political subdivisions: 10 administrative provinces
closely controlled by central government; district
commissioners appointed by revolutionary Command
Council
Legal system: based on Italian civil law system and
Islamic law; separate religious courts; no constitu-
tional provision for judicial review of legislative acts;
legal education at Law School, at University of Libya
at Benghazi; has not accepted compulsory IC]
jurisdiction
Branches: paramount political power and
authority rests with the 10-man Revolutionary
Command Council (RCC); cabinet; parliament has
been dissolved
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
dream
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
January 1977
LIBYA/LIECHTENSTEIN
Government leaders: Revolutionary Command
Council Chairman Colonel Mu’ammar Qadhafi;
Prime Minister, Major Abd al-Salam Jallud
Suffrage: universal
Elections: parliamentary elections last held in May
1965; election for CAR assembly in March 1972
Political parties and leaders: Libyan Arab
Socjalist Union, RCC member Major Abd al-Salam
Jallud, Secretary General; Mu’ammar Qadhafi,
President
Communists: no organized party, negligible
membership
Other political or pressure groups: various Arab
nationalist movements and the Arab Socialist
Resurrection (Bath) party with small, almost
negligible memberships may be functioning
clandestinely
Member of: AFDB, Arab League, FAO, IAEA,
IBRD, ICAO, IDA, IFC, ILO, IMCO, IMF, IOOC,
ITU, OAPEC, OAU, OPEC, U.N., UNESCO, UPU,
WHO, WMO, WSG','49c8022e987c23510149748afc1f2e38993a9611ebdaba94f3167bea6ff66a9e','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d2d0c1bf7fb01c7fc8784a6e98438b2e03b2402da29b7fb66e6aa9c57f930b8a',1977,'LI','Liechtenstein','government',307,'Legal name: Principality of Liechtenstein
Type: hereditary constitutional monarchy
Capital: Vaduz
Political subdivisions: 11 districts
Legal system: based on Swiss law; constitution
adopted 1921; judicial review of legislative acts in a
special Constitutional Court; accepts compulsory ICJ
jurisdiction, with reservations
Branches: unicameral Parliament, hereditary
Prince, independent judiciary
Government leaders: Head of State, Prince Franz
Joseph II; Chief of Government, Dr. Walter Kieber
Suffrage: males age 20 and over
Elections: every 4 years; next elections 1978
Political parties and leaders: Fatherland Union
Party (VU), Dr. Alfred Hilbe; Progressive Citizens
Party (FBP), Dr. Gerard Batliner
Voting strength (1974 election): FBP over 50%
Communists: none
Member of: IAEA, ITU, UPU, WCL; considering
U.N. membership; desires affiliation with The
Council of Europe; under a 1928 treaty, Switzerland
handles Liechtenstein’s post and telegraph systems,
customs, and foreign relations','34f5e1a6655783e6e2c3760dfae83cc93dbaf0c61d64737decebdc59038b8860','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a8b216d75a0d31c429c0b033cff3e8596e9e7657bea3b0abaad86ea6a28c2d8e',1977,'LU','Luxembourg','government',312,'Legal name: Grand Duchy of Luxembourg
Type: constitutional monarchy
Capital: Luxembourg
Political subdivisions: unitary state, but for
administrative purposes has 3 districts (Luxembourg,
Diekirch, Grevenmacher) and 12 cantons
Legal system: based on civil law system;
constitution adopted 1868; judicial review of
legislative acts in the Cassation Court only; accepts
compulsory ICJ jurisdiction
Branches: parliamentary democracy; seven
ministers comprise Council of Government headed by
President, which constitutes the executive; it is
responsible to the unicameral legislature, the
Chamber of Deputies; the Council of State, appointed
for indefinite term, exercises some powers of an upper
house; judicial power exercised by independent courts
Government leaders: Grand Duke Jean, Head of
State; Gaston Thorn, Prime Minister
Suffrage: universal and compulsory over age 18
Elections: every 5 years for entire Chamber of
Deputies; latest elections May 1974
Political parties and leaders: Christian Social
Union, Pierre Werner and Jacques Santer (Party
President); Socialist, Lydie Schmit (Party President);
Social Democrat, Henry Cravatte (Party President);
Democratic, Gaston Thorn (Party President and Prime
Minister); Communist, Dominique Urbany
Voting strength in Chamber of Deputies
(1974): Christian Socialist, 18; Socialist Workers, 17;
Democrats, 14; Social Democrats, 5; Communists, 5
Communists: 500 party members (1974)
Other political or pressure groups: group of steel
industries representing iron and steel industry,
Centrale Paysanne representing agricultural pro-
ducers; Christian and Socialist labor unions,
Federation of Industrialists; Artisans and Shopkeepers
Federation
Member of: Benelux, BLEU, Council of Europe,
EC, ECSC, EEC, EIB, EURATOM, FAO, GATT,
IAEA, IBRD, ICAO, IDA, IEA, IFC, ILO, IMF,
{OOC, IPU, ITU, NATO, OECD, U.N., UNESCO,
UPU, WCL, WEU, WHO, WMO','d41f2a81c198d59e79b5c0f9a5d604923619138941c63ba07f6655970153d62f','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cf43402325597699abf2fec028bc3ce5a393e56cb1b85c11d207c49abf38ffe3',1977,'MO','Macao','government',316,'Legal name: Province of Macao
Type: overseas province of Portugal
Capital: Lisbon (Portugal)
Political subdivisions: municipality of Macao, and
2 islands
Legal system: Portuguese civil law system
Branches: 17-member Legislative Assembly, with
Governor and 5 appointed, 1 specially nominated,
and 10 elected representatives
Government leader: Col. Eduardo Garcia Leandro
Suffrage: Portuguese, Chinese and foreign residents
over 18
Elections: conducted every 4 years; last held
December 1972
Political parties and leaders: Association to
Defend the Interests of Macao; Macao Democratic
Center; Group to Study the Development of Macao;
Macao Independent Group
Communists: numbers unknown
124
Approved For Release 2005/04/22
Other political or pressure groups: wealthy
Macanese and Chinese representing local interests,
wealthy pro-Communist merchants representing
China’s interests; in January 1967 Macao Govern-
ment acceded to Chinese demands which gave
Chinese veto power over administration of the enclave','f97cedc31fe48f8f5a38367670dd7eddaa79e92b8b543596c79e835b35f54f63','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b55d5f53429d02edf205238e8caa6aa178282abf9d9e7b23f419317d2506776c',1977,'MG','Madagascar','government',320,'Legal name: Democratic Republic of Madagascar
Type: republic; military has wielded real authority
since May 1972
Capital: Tananarive
Political subdivisions: 6 provinces
Legal system: based on French civil law system
and traditional Malagasy law; constitution of 1959
modified in October 1972 by law establishing
provisional government institutions; new constitution
accepted by referendum in December 1975; legal
education at National School of Law, University of
Madagascar; has not accepted compulsory ICJ
jurisdiction
Branches: executive—a 12-member Supreme
Revolutionary Council; assisted by cabinet called
Approved For Release 2005/04/22
Council of Ministers; National Popular Development
Council created to replace the legislature in October
1972 (dissolved in April 1976, to be replaced by
elected People’s National Assembly); Military
Committee for Development; regular courts are
patterned after French system, and a High Council of
Institutions reviews all legislation to determine its
constitutional validity
Government leader: President Didier Ratsiraka
Suffrage: universal for adults
Elections: referendum held in December 1975 gave
overwhelming approval to government and new
constitution; legislative elections to be held sometime
in 1977
Political parties and leaders: Malagasy Socialist
Party (PSM), led by Philibert Tsiranana and Andre
Resampa, formed in 1974 asa result of union of Social
Democratic Party (PSD) and Malagasy Socialist
Union (USM); Congress Party for the Independence
of Madagascar (AKFM), led by Richard Andriaman-
jato; National Movement for the Independence of
Madagascar (MONIMA), led by Monja Jaona;
parties are permitted to exist but are barred from
positions of political authority because of postpone-
ment of elections
Voting strength: number of registered voters
(1972)—8.5 million; (in 1973 elections) non-party
candidates won 81% of seats in National Popular
Development Council; AKFM won 33 seats, PSD 5,
USM 1, MONIMA 14
Communists: Communist party of virtually no
importance; small and vocal group of Communists
has gained strong position in leadership of AKFM, the
rank and file of which is non-Communist
Other political or pressure groups: Joint Struggle
Committee (KIM), association of students, teachers,
workers, and unemployed youth
Member of; EAMA, FAO, GATT, IAEA, IBRD,
IFC, ILO, IMF, ISO, ITU, OAU, OCAM, U.N.,
UNESCO, WCL, WFTU, WHO, WMO','565104d139740442ac3e4f78025bd87a085eadc4154d1955eb3ab49ac8068d01','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7bf8ba25bd7b5424c9ce410bacc2ad9dc23f3f9b0409b6e34a33168500b5f5c7',1977,'MW','Malawi','government',324,'Legal name: Republic of Malawi
Type: republic since July 1966; independent
member of Commonwealth since July 1964
Capital: Lilongwe
Political subdivisions: 3 administrative regions and
23 districts
Legal system: based on English common law and
customary law; constitution adopted 1964; judicial
review of legislative acts in the Supreme Court of
Appeal; has not accepted compulsory ICJ jurisdiction
Branches: strong presidential system with cabinet
appointed by President; unicameral National
Assembly of 60 elected and 15 nominated members;
High Court with Chief Justice and at least 2 justices
Government leader: Life President H. Kamuzu
Banda
: CIA-RDP79-01051A000800010006-3
wie:
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
January 1977
MALAWI/MALAYSIA
Suffrage: universal adult
Elections: scheduled for 1976 but MCP candidates
unopposed and polling apparently will not take place
Political parties and leaders: Malawi Congress
Party (MCP), Dr. H. Kamuzu Banda
Communists: no Communist Party; Malawi
maintains no foreign relations with Communist
governments
Member of: AFDB, EEC (associate member),
FAO, GATT, IBRD, ICAO, IDA, IFC, ILO, IMF,
IPU, ISO, ITU, OAU, U.N., UNESCO, WHO,
WMO','ca3b11855ca1259b531e7590c6ce355fc131d1a0b556939ac120778d4e9115b3','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('84c1d9e08ea40e46581c9ccd4586e332b030f7dba1370c2f90612a0c9c456e1f',1977,'MY','Malaysia','government',328,'Legal name: Malaysia
Type:
Malaysia: constitutional monarchy nominally
headed by Paramount Ruler (King); a bicameral
Parliament consisting of a 58-member Senate and a
154-member House of Representatives
Peninsular Malaysian states: hereditary rulers in
all but Penang and Malacca where Governors
128
appointed by Malaysian Government; powers of state
governments limited by federal constitution
Sabah: self-governing state within Malaysia in
which it holds 16 seats in House of Representatives;
foreign affairs, defense, internal security, and other
powers delegated to federal government
Sarawak: self-governing state within Malaysia in
which it holds 24 seats in House of Representatives;
foreign affairs, defense, and internal security, and
other powers are delegated to federal government
Capital:
Peninsular Malaysia: Kuala Lumpur
Sabah: Kota Kinabalu
Sarawak: Kuching
Political subdivisions: 18 states (including Sabah
and Sarawak)
Legal system: based on English common law;
constitution came into force 1963; judicial review of
legislative acts in the Supreme Court at request of
Supreme Head of the Federation; has not accepted
compulsory ICJ jurisdiction
Branches: 9 state rulers alternate as Paramount
Ruler for 5-year terms; locus of executive power vested
in Prime Minister-‘and cabinet, who are responsible to
bicameral parliament; following communal rioting in
May 1969, government imposed state of emergency
and suspended constitutional rights of all parlia-
mentary bodies; parliamentary democracy resumed in
February 1971
Peninsular Malaysia: executive branches of 11
states vary in detail but are similar in design; a Chief
Minister, appointed by hereditary ruler or Governor,
heads an executive council (cabinet) which is
responsible to an elected, unicameral legislature
Sarawak and Sabah: executive branch headed by
Governor appointed by central government, largely
ceremonial role; executive power exercised by Chief
Minister who heads parliamentary cabinet responsible
to unicameral legislature; judiciary part of Malaysian
judicial system
Government leader: Head of State, Hussein Onn
Suffrage: universal over age 20
Elections: minimum of every 5 years, last elections
August 1974
Political parties and leaders:
Peninsular Malaysia: National Front, a
confederation of 9 political parties dominated by
United Malays National Organization (UMNO),
Hussein Onn; only opposition party of consequence—
Democratic Action Party (DAP)
Sabah: Berjaya Party, Tun Mohammad Fuad;
United Sabah National Organization (USNO), Tan
Sri Haji Moho Said Keruak; Sabah Chinese
Association (SCA), Khoo Siak Chiew
Sarawak: coalition Sarawak Alliance composed
of the Pesaka/Bumipatra Party, the United People’s
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
January 1977
Party (SUPP), Ong Kee Hui and Sarawak Chinese
Association; opposition Sarawak National Party
(SNAP), Stephen Ningkan
Voting strength:
Peninsular Malaysia: (1974 election) National
Front controls 135 of 154 seats in lower house of
parliament
Sabah: (April 1976 Assembly Elections) Berjaya
Party controls 34 of 54 seats in State Assembly, USNO
controls 20 remaining seats
Sarawak: (1974 elections) National Front 30 out
of 48 State Assembly seats
Communists:
Peninsular Malaysia: approx. 1,700 armed
insurgents on Thailand side of Thai/ Malaysia border;
approx. 300 on Malaysian side
Sarawak: 170 armed insurgents in Sarawak
Sabah: insignificant
Member of: ADB, ANRPC, ASEAN, Colombo
Plan, Commonwealth, FAO, GATT, IAEA, IBRD,
ICAO, IDA, IFC, ILO, IMCO, IMF, IPU, ITC, ITU,
U.N., UNESCO, UPU, WHO, WMO','1a596ad14506b2dbc3bc528c51600c54ca632b7ee0815990fac75b5c60f6c1be','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4f5b3539f618629a4d3f13975cbe50c03a2cd336fa87bc323692e07b1cbb4bd7',1977,'MV','Maldives','government',332,'Legal name: Republic of Maldives
Type: republic
Capital: Male
Political subdivisions: 19 administrative districts
corresponding to atolls
Legal system: based on Islamic law with
admixtures of English common law primarily
in commercial matters; has not accepted compulsory
ICJ jurisdiction
Branches: popularly elected unicameral national
legislature (Majlis) (members elected for 5-year
terms); elected President, chief executive; appointed
Chief Justice responsible for administration of Islamic
law
Government leader: President Ibrahim Nasir
Suffrage: universal over age 21
Political parties and leaders: no organized
political parties; country governed by the Didi clan
for the past eight centuries
Communists: negligible number
Member of: Colombo Plan, FAO, GATT (de
facto), IMCO, ITU, U.N., UPU, WHO
Legal name: Republic of Mali
Type: republic; under military regime since
November 1968
Capital; Bamako
Political subdivisions: 6 administrative regions; 42
administrative districts (cercles), arrondissements,
villages; all subordinate to central government
Legal system: based on French civil law system
and customary law; constitution adopted 1974 but
not scheduled to come into full effect until 1980;
judicial review of legislative acts in Constitutional
Section of Court of State; has not accepted
compulsory ICJ jurisdiction
Branches: executive authority exercised by Military
Committee of National Liberation (MCNL) com-
posed of 11 army officers; under MCNL functional
cabinet composed of civilians and army officers;
judiciary
Government leaders: Col. Moussa Traore,
President of MCNL, Chief of State and head of
Suffrage: universal over age 21
Political parties and leaders: political activity
proscribed by military government but government in
process of forming new single party called the
Democratic Union of Malian People (UDPM)
Elections: MCNL promises elections at unspecified
date
Communists: a few Communists and some
sympathizers
Member of: AFDB, APC, CEAO, ECA, ECOWAS,
FAO, GATT (de facto), IAEA, IBRD, ICAO, IDA,
ILO, IMF, ITU, Niger River Commission, OAU,
OMVS (Organization for the Development of the
Senegal River Valley), U.N., UNESCO, UPU, WCL,
WHO, WMO
Legal name: Republic of Malta
Type: parliamentary democracy, independent
republic within the Commonwealth since December
1974
Capital: Valletta
Political subdivisions: 2 main populated islands,
Malta and Gozo, divided into 13 electoral districts
(divisions)
Legal system: based on English common law;
constitution adopted 1961, came into force 1964; has
accepted compulsory ICJ jurisdiction, with reser-
vations
Branches: executive, consisting of Prime Minister
and cabinet; legislative, comprising 65-member
House of Representatives; independent judiciary
Government leader: Prime Minister Dom Mintoff
Suffrage: universal over age 18; registration
required
Elections: at the discretion of the Prime Minister,
but must be held before the expiration of a 5-year
electoral mandate; last election September 1976
Political parties and leaders: Nationalist Party,
Georgio Borg Olivier; Malta Labor Party, Dom
Mintoff
Voting strength (1976 election): Labor, 34 seats
(51.54%); Nationalist, 31 seats (48.43%)
Communists: less than 100 (est. )
Member of: Commonwealth, Council of Europe,
FAO, GATT, IBRD, ICAO, ILO, IMCO, IMF, ITU,
U.N., UNESCO, UPU, WCL, WHO','01b75d2e77a63494845339d502f57fef0c1523c790fccf94c411781a3b4fd375','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e2aab27a372199e4a16dc77a0ec8a1d3717b7916b10192fd6e3ffb37199faec4',1977,'MR','Mauritania','government',337,'Legal name: Islamic Republic of Mauritania
Type: republic; one-party presidential rule since
1960
Capital: Nouakchott
Political subdivisions: 12 regions and a capital
district
NOTE: Mauritania has acquired administrative
control of the southern third of Western (formerly
Spanish) Sahara under an agreement with Morocco,
but the legal question of sovereignty over the area has
yet to be determined. Spain’s role as co-administrator
of the disputed territory ended last February. The
newly acquired region, which lies below the 24th
parallel, becomes the district of Tiris el Gharbia—a
territorial division of the state. The district''s
headquarters is Dakhla, formerly Villa Cisneros. Tiris
el Gharbia is subdivided into three departments—
Dakhla, Ausert, and Aurgub.
Legal system: based on French civil law system
and Islamic law; constitution adopted 1961; judicial
review of legislative acts in the Supreme Court; has
not accepted compulsory ICJ jurisdiction
Branches: executive, President; separate judiciary
(appointed by president)
Government leader: President Moktar Ould
Daddah
Suffrage: universal for adults
Elections: presidential and parliamentary election
every 5 years; most recent October 1975
Political parties and leaders: Mauritanian Peoples
Party is only legal party, Secretary General Moktar
Ould Daddah
Communists: no Communist Party, but there is a
scattering of Maoist sympathizers
Member of: AFDB, AIOEC, Arab League, CEAO,
CIPEC (associate), EAMA, EIB (associate), FAO,
GATT, IBRD, ICAO, IDA, IFC, ILO, IMCO, IMF,
IPU, ITU, OAU, OMVS (Organization for the
Development of the Senegal River Valley), U.N.,
UNESCO, UPU, WHO, WMO','d33a9a3def0cab4d91270973a8775ce400f2a83c2835a22093e8711f895fbce6','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('634e06129de84b38226923004b96958fb4db7c6ab49c3b63f5064324707ccc98',1977,'MU','Mauritius','government',342,'Legal name: Mauritius
Type: independent state since 1968, recognizing
Elizabeth II as Chief of State
Capital: Port Louis
Political subdivisions: 5 organized municipalities
and various island dependencies
Legal system: based on French civil law system
with elements of English common law in certain
areas; constitution adopted 6 March 1968
Branches: executive power exercised by Prime
Minister and 2l-man Council of Ministers;
unicameral legislature (National Assembly) with 62
members elected by direct suffrage, 8 specially
elected, and one nominated
Government leader: Prime Minister Dr. Seewoosa-
gur Ramgoolam
136
Suffrage: universal over age 18
Elections: last held in August 1967; next scheduled
in 1972 postponed at least 4 years by constitutional
amendment, election now expected to be held in late
1976
Political parties and leaders: a loose government
coalition consisting of Labor Party (S. Ramgoolam)
and Muslim Committee of Action (A. R. Mohamed);
opposition parties—Parti Mauricien Social Democrate
(G. Duval), Independent Forward Bloc (S. Bissoon-
doyal), Mauritius Democratic Union (M. Lesage),
Mouvement Militant Mauritian (P. Berenger),
Mouvement Militant Mauritian Socialiste Progressist
(D. Virahsawmy)
Voting strength: Muslim Committee of Action, 4
seats; Independent Forward Bloc, 4 seats; Mauritius
Labor Party, 41 seats; Mauritius Democratic Union, 5
seats; Parti Mauricien Social Democrate, 15 seats;
Mouvement Militant Mauritian Socialiste Progressist,
1 seat; 1 seat vacant
Communists: may be 2,000 sympathizers; several
Communist organizations; Mauritius Lenin Youth
Organization, Mauritius Women’s Committee,
Mauritius Communist Party, Mauritius People’s
Progressive Party, Mauritius Young Communist
League, Mauritius Liberation Front, Chinese Middle
School Friendly Association, Mauritius/USSR
Friendship Society
Other political or pressure groups: Tamil United
Party, Mauritius Workers Party
Member of: Commonwealth, FAO, GATT, IBRD,
ICAO, IDA, IFC, ILO, IMF, ISO, ITU, IWC—
Inernational Wheat Council, OAU, OCAM, U.N.,
UNESCO, UPU, WCL, WFTU, WHO, WMO
Legal name: Overseas Department of Reunion
Type: overseas department of France; represented
in French Parliament by three Deputies and two
Senators
Capital: Saint-Denis
Legal system: French law
Branches: Reunion is administered by a Prefect
appointed by the French Minister of Interior, assisted
by a Secretary-General and an elected 86-man
General Council
Government leader: Prefect Paul Cousseran
Suffrage: universal adult
Elections: last municipal elections in 1971;
parliamentary election March 1973; some General
Council seats up for election in March 1976
Approved For Release 2005/04/22
REUNION
Political parties and leaders: Reunion Communist
Party (RCP) led by Paul Verges, only organized
political movement on island; other political
candidates affiliated with metropolitan French
parties, which do not maintain permanent organiza-
tions on Reunion
Voting strength (parliamentary election 1973):
Union of Democrats for the Republic elected, one
senator and two deputies; Centrist Union, one
deputy; one Senator independent
Communists: Communist Party small—probably
only 15-20 hard-line Communists—but has support
among sugarcane cutters and in Le Port district
Member of: EC, WFTU
Legal name: Colony of Southern Rhodesia
Type: self-proclaimed independent state since 1965
(not recognized by U.S.); provisional settlement with
U.K. in November 1971 cancelled by U.K. in May
1972 in response to Pearce Commission’s conclusion
that its terms were unacceptable to the majority of
black Rhodesians; a conference currently underway in
Geneva is designed to set up a new multiracial interim
government in Rhodesia which is to govern the
country during a transition to black majority rule
Capital: Salisbury
Political subdivisions: 11 magisterial districts
Legal system: Smith government implemented a
republican constitution on 2 March 1970 which
institutionalized white rule
Branches: President Wrathall is ceremonial head of
state; executive council (cabinet) lead by Prime
Minister Smith; National Assembly gives highly
disproportionate representation to white minority—
50 white constituency seats and 16 black constituency
seats
Government leaders: Prime Minister Ian Smith
and President John Wrathall
Suffrage: franchise is based on income, property
holdings, and education; there are separate rolls for
Africans and non-Africans
Elections: must be held every 5 years
Political parties and leaders: Rhodesian Front,
Prime Minister Smith; Rhodesia Party, Tim Gibbs;
Rhodesia National Party, Leonard Idensohn; African
Progressive Party, Chad Chipunza
Voting strength (1974 elections): Rhodesian Front
won all 50 white constituency seats in Parliament in
July 1974 elections
Communists: negligible
Other pressure groups and leaders: black
nationalists are badly divided—Abel Muzorewa and
Joshua Nkomo are leading rival factions of the African
National Council; the Zimbabwe African National
Union is also split between a group heaed by
Ndabaningi Sithole, and a faction whose spokesman is
Robert Mugabe
Member of; ITU','7d01f89d334421845df168ca76dc7b1f298d7c29c7f2d3b4cd42ca55eaa27c88','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('364794a5cea8377e4fef6e5552274093b9b5a1778fa0055b81cb8159263efc82',1977,'US','United States','government',346,'Legal name: United Mexican States
Type: federal republic operating in fact under a
centralized government
Capital: Mexico
Political subdivisions: 31 states, Federal District
Legal system: mixture of U.S. constitutional theory
and civil law system; constitution established in 1917;
judicial review of legislative acts; accepts compulsory
ICJ jurisdiction, with reservations
Branches: dominant executive, bicameral legisla-
ture, Supreme Court
Government leader: President Jose Lopez-Portillo
Suffrage: universal over age 18; compulsory but
unenforced
Elections: congressional elections July 1979
Political parties and leaders: Institutional
Revolutionary Party (PRI), Porfirio Munoz Ledo;
National Action Party (PAN), Manuel Gonzalez
Hinojosa; Popular Socialist Party (PPS), Jorge
Cruickshank Garcia; Authentic Party of the
Revolution (PARM), Pedro Gonzalez Azcuaga
Voting strength: 1976 presidential election: 98.7%
PRI (unopposed), 1.3% other; 1976 congressional
election: 80.2% PRI; 8.5% PAN; 5.8% other
opposition (votes cast for PPS, PARM, and
unregistered candidates), 5.4% annulled
Communists: estimated 5,000 in Communist Party
Other political or pressure groups: Roman
Catholic Church, Confederation of Mexican Workers
(CTM), Confederation of Industrial Chambers
(CONCAMIN), Confederation of National Chambers
of Commerce (CONCANACO), National Confedera-
137
CIA-RDP79-01051A000800010006-3
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
January 1977
MEXICO/MONACO
tion of Campesinos (CNC), National Confederation
of Popular Organizatic is (CNOP), Revolutionary
Confederation of Workers and Peasants (CROC)
Member of: FAO, IADB, IAEA, IBRD, ICAC,
ICAO, IDA, IDB, IFC, ILO, International Lead and
Zine Study Group, IMCO, IMF, ISO, ITU, Iwc—
International Whaling Commission, LAFTA,
NAMUCAR (Carribean Multinational Shipping
Line—Naviera Multinacional del Caribe), OAS,
SELA, U.N., UNESCO, UPU, WCL, WFTU, WHO,
WMO, WSG
Legal name: United States of America
Legal system: based on English common law; dual
system of courts, state and federal; constitution
adopted 1789; judicial review of legislative acts;
accepts compulsory ICJ jurisdiction, with reservations
Voting strength (1976 presidential election):
Democratic Party (Carter), 40,291,626 (51%);
Republican Party (Ford), 38,563,089 (48%); minor
parties, 826,258 (preliminary figures)
Communists: party membership, 10,000-11,000
(est.); General Secretary, Gus Hall
Member of: ADB, ANZUS, CENTO, Colombo
Plan, DAC, FAO, GATT, IADB, IAEA, IBRD, ICAC,
ICAO, IDA, IDB, IEA, IFC, IHO, ILO, International
Lead and Zine Study Group, IMCO, IMF, IPU, ITC,
ITU, IWC—International Whaling Commission,
IWC—International Wheat Council, NATO, OAS,
OECD, U.N., UNESCO, UPU, WHO, WMO, WSG','9cbfa2c0b84e7ddc4e163a48180ac0922772a951cfcab4ea7a0b713dfa53f718','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('45a61037ed61f82e10f300379b6fb1b52088aa830a6a9019fdfd267bd707c181',1977,'MC','Monaco','government',350,'Legal name: Principality of Monaco
Type: constitutional monarchy
Capital: Monaco
Political subdivisions: 4 sections
Legal system: based on French law; new
constitution adopted 1962; has not accepted
compulsory ICJ jurisdiction
Branches: National Council (18 members);
Communal Council (15 members, headed by a
mayor)
Government leader: Prince Rainier III
Suffrage: universal
Elections: National Council every 5 years; most
recent 1973
Political parties and leaders: National Democratic
Entente, Democratic Union Movement, Monegasque
Actionist (1973)
Voting strength: figures for 1973: National
Democratic Entente, 16 seats; Democratic Union
Movement and Monegasque Actionist, 1 seat each
Member of: IAEA, IHO, IPU, ITU, UN.,
UNESCO, UPU, WHO','acd4a86aa9a004cd08713883e94acb5753803574d247ba355d0f54cf21f96195','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('74346fedc6e05148a84a7cf5a20603fe71f1285cef5ee1da73d6a2dc8095044a',1977,'MN','Mongolia','government',354,'Legal name: Mongolian Peoples Republic
Type: Communist state
Capital; Ulaanbaatar
Political subdivisions: 18 provinces and 2
autonomous municipalities (Ulaanbaatar and
Darhan)
Legal system: blend of Russian, Chinese, and
Turkish systems of law; new constitution adopted
189
CIA-RDP79-01051A000800010006-3
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
January 1977
MONGOLIA/MOROCCO
1960; no constitutional provision for judicial review of
legislative acts; legal education at Ulaanbaatar State
University; has not accepted compulsory ICJ
jurisdiction
Branches: constitution provides for a People’s
Great Hural (national assembly) and a_ highly
centralized administration
Party and government leaders: Y. Tsedenbal,. First
Secretary of the MPRP and Chairman of the People’s
Great Hural; J. Batmunh, Chairman of the Council of
Ministers
Suffrage: universal; age 18 and over
Elections: national assembly elections held every 4
years; last elections held in June 1973
Political party: Mongolian People’s Revolutionary
(Communist) Party (MPRP); estimated membership,
58,000 (claimed 1972)
Member of: CEMA, ESCAP, IAEA, ILO, IPU,
ITU, U.N., UNESCO, UPU, WFTU, WHO, WMO','f96322d7fa135618443ac20960fccb3cab9aa562be509f28cbbb941b67095756','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bb410d40a50d82b06f8de574a39021da5bcb1da3de16e6524b9cba2d478afc13',1977,'MA','Morocco','government',358,'Legal name: Kingdom of Morocco
Type: constitutional monarchy (constitution
adopted 1972)
Capital: Rabat
Political subdivisions: 28 provinces and 2
prefectures
NOTE: Morocco has acquired the northern two-
thirds of the former Spanish Sahara under an
agreement with Mauritania, but the legal question of
sovereignty over the area has yet to be determined.
Spain’s role as co-administrator of the disputed
territory ended last February. Rabat has established
three provinces in its area of control, with
headquarters at El Aaiun, Semara, and Cabo Bojador.
Legal system: based on Islamic law and French
and Spanish civil law system; judicial review of
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
January 1977
MOROCCO/MOZAMBIQUE
legislative acts in Constitutional Chamber of Supreme
Court; modern legal education at branches of
Mohamed V University in Rabat and Casablanca and
Karaouine University in Fes; has not accepted
compulsory ICJ jurisdiction
Branches: constitution provides for Prime Minister
and ministers named by and responsible to King; King
has paramount executive powers; unicameral
legislature in abeyance until elections are held (two-
thirds to be directly elected, one third indirectly);
judiciary independent of other branches
Government leaders: King Hassan II; Prime
Minister Ahmed Osman
Suffrage: universal over age 20
Elections: last parliamentary elections held 21 and
28 August 1970 for Council of Representatives which
was dissolved in March 1972; elections for new
parliament created by Constitution adopted 15
March 1972 have not been held
Political parties and leaders: Istiqlal Party,
M’hamed Boucetta; Popular Movement (MP),
Mahjoubi Aherdan; Constitutional and Democratic
Popular Movement (MPCD), Dr. Abdelkrim Khatib;
National Union of Popular Forces (UNFP), split into
competitive factions under Abdallah Ibrahim and
Mahjoub Ben Seddik of Casablanca-based faction
and Abderrahim Bouabid of Rabat-based faction with
latter becoming Socialist Union of Popular Forces
(USFP) in September 1974; Democratic Constitu-
tional Party (PDC), Mohamed Hassan Ouazzani;
Party for Progress and Socialism (PPS), legalized in
August 1974, successor to Party for Progress and
Socialisim (PPS), is front for Moroccan Communist
Party (MCP), which was proscribed in 1959, Ali Yata;
Istiqlal and the UNFP formed a National Front in
July 1970 to oppose the new constitution, boycotted
the parliamentary elections and the 1972 constitu-
tional referendum
Voting strength: August 1970 elections were
nonpolitical; 1 March 1972 constitutional referendum
tallied 98.7% for new constitution, 1.25% opposed
and National Front abstained from voting
Communists: 300 est.
Member of: AFDB, Arab League, EC (association
until 1974), FAO, GATT, IBRD, ICAO, IDA, IFC,
ILO, International Lead and Zine Study Group,
IMCO, IMF, IOOC, IPU, ITU, OAU, UN.,
UNESCO, UPU, WHO, WMO','56acd136965584a03b5d6e1738e48817d7a3287f56c5e92fa6f0ae610768a3a3','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f80d4edd97a73b855707b1c9bca890e3c18bb5fa2574716ed994baa7c40ec648',1977,'MZ','Mozambique','government',362,'Legal name: Peoples Republic of Mozambique
Type: peoples republic; achieved independence
from Portugal in June 1975
Capital: Maputo
Political subdivisions: 10 districts administered by
district governors; municipalities governed by:
appointed official
Legal system: based on Portuguese civil law system
and customary law
Branches: none established
142
Approved For Release 2005/04/22
Government leader: President Samora Machel;
Vice-President Marcelino dos Santos
Suffrage: not yet established
Elections: information not available on future
election schedule
Political parties and leaders: the Mozambique
Liberation Front (FRELIMO), led by Samora
Machel, is only legal party
Communists: none known
Member of: OAU, U.N.','9dea7db64819a034c185e2aeb5ab3a766101e041b954d43dd875d0ec661ff229','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('271269523d512229d1b686b38cd0ceaaa3a052e3932c8d805236052a1b8caef4',1977,'PT','Portugal','government',368,'Legal name: Republic of Nauru
Type: republic; independent since January 1968
Capital: no capital city per se; government offices
in Uaboe District
Political subdivisions: 14 districts
Branches: President elected from and by
Parliament for an unfixed term; popularly elected
unicameral legislature, the Parliament; Cabinet to
assist the President, four members, appointed by
President from Parliament members
Government leader: President Hammer De Roburt
Suffrage: universal adult
Elections: last held in January 1971
Political parties and leaders: there are no political
parties; De Roburt is only significant political figure
Member of: no present plans to join U.N.; enjoys
“special membership’ in Commonwealth; South
Pacific Commission, ESCAP, INTERPOL, ITU, UPU
Legal name: Republic of Portugal
Type: republic, first government under new
constitution formed July 1976; major political parties
and officers of all-military Revolutionary Council
signed document in December 1975 agreeing to
multiparty parliamentary democracy with military
oversight for period of four years following
presidential elections in June 1976
Capital: Lisbon
Political subdivisions: 18 districts in mainland
Portugal and 4 ‘“‘autonomous districts” in Azores and
Madeira Islands; Macao, Portugal''s remaining
overseas territory, was granted broad executive and
legislative autonomy in February 1976; Portugal has
not officially recognized the unilateral annexation of
Portuguese Timor by Indonesia
Legal system: civil law system; new constitution
adopted April 1976; for next four years, legislative
assembly acts to be reviewed for constitutionality by
Revolutionary Council; vetoes of laws by the Council,
through the agency of the presidency, may be
appealed to a Constitutional Commission as a court of
last resort; legal education at Universities of Lisbon
and Coimbra; accepts compulsory ICJ jurisdiction,
with reservations
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
January 1977
Branches: executive with President and Prime
Minister, with 18-member Revolutionary Council as
advisory body to the President; popularly elected
Assembly of the Republic; independent judiciary
Government leaders: President Antonio Ramalho
Eanes; Prime Minister Mario Soares
Suffrage: universal over age 18, except for those
barred by law for participation in “undemocratic”
institutions prior to April 25, 1974
Flections: national elections for Assembly of the
Republic to be held every 4 years, last election April
1976; national election for president to be held every 5
years, term of first constitutional president—elected in
June 1976—will end with 4 year transitional period;
local elections to be held every 3 years, local elections
scheduled for December 12, 1976
Political parties and leaders: the Portuguese
Socialist Party (PS) is led by Mario Soares, the Social
Democratic Party (PSD), formerly the Popular
Democratic Party (PPD), by Francisco Sa Carneiro,
the Social Democratic Center (CDS) by Diego Freitas
do Amaral, and the Communist Party by Alvaro
Cunhal
Voting strength: (1976 parliamentary election) the
Socialists polled 35% of the vote; the PSD received
24%, the CDS 16%, and the Communists 15%
Communists: Portuguese Communist Party claims
membership of approximately 120,000
Member of: Council of Europe, EFTA, FAO,
GATT, IAEA, IATP, IBRD, ICAC, ICAO (restricted
membership), IFC, IHO, ILO, IMF, 100C, ISO,
ITU, IWC—International Wheat Council, NATO,
OECD, U.N., UNESCO, UPU, WHO, WMO, WSG','d0aa4bcd9e97fffc900ea2b659bb62d2037b02170cde126ba6837afb0c2a6a51','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('698f819e54e94b565ded5a9fdac63f2fd6a4ddf92cacd934a9862b9d600adbf5',1977,'NP','Nepal','government',372,'Legal name: Kingdom of Nepal
Type: constitutional monarchy; King Birendra
exercises autocratic control over multitiered
panchayat system of government
Capital: Kathmandu
Political subdivisions: 75 districts, 14 zones
Legal system: based on Hindu legal concepts and
English common law; legal education at Nepal Law
College in Kathmandu; has not accepted compulsory
IC] jurisdiction
Branches: Council of Ministers appointed by the
King; indirectly elected National Panchayat
(Assembly)
Government leader: King Birendra Bir Bikram
Shah Deva; Prime Minister Tulsi Giri
Suffrage: universal over age 21
Elections: village and town councils (panchayats)
elected by universal suffrage; district, zonal, and
144
National Panchayat members indirectly elected, most
for 6-year terms; 15 National Panchayat members
elected from five class and professional organizations
(women, workers, peasants, youth, and ex-serv-
icemen), four directly elected by all voters possessing a
B.A. or its equivalent, and 16 are appointed by the
King
Political parties and leaders: all political parties
outlawed
Communists: the combined membership of the two
wings of the Communist Party of Nepal (CPN) about
6,500, the majority (perhaps 5,000) in the pro-Chinese
wing; the CPN continues to operate more or less
openly, but internal dissension has greatly hindered its
effectiveness
Other political or pressure groups: proscribed
Nepali Congress Party led by B.P. Koirala from exile
in India
Member of: ADB, Colombo Plan, FAO, IBRD,
ICAO, IDA, IFC, ILO, IMF, IPU, ITU, U.N.,
UNESCO, UPU, WHO, WMO','2c879ce8c4df030c920cf2462ce1fcf757087dc74ff8058d43157b457ee8e626','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8dfd67be171457ee13e1a0fd4a52804f4492241f50f93c447913cad2097fbce9',1977,'NZ','New Zealand','government',378,'Legal name: Dominion of New Zealand (rarely
used )
Type: independent state within Commonwealth,
recognizing Elizabeth II as head of state
Capital: Wellington
Political subdivisions: 112 counties
Legal system: based on English law, with special
land legislation and land courts for Maori tribesmen;
constitution consists of various documents, including
certain acts of the U.K. and New Zealand
Parliaments; legal education at Victoria, Auckland,
Canterbury, and Otago Universities; accepts
compulsory IC] jurisdiction, with reservations
Branches: unicameral legislature (General As-
sembly, commonly called Parliament); Cabinet
responsible to Parliament; 3-level court system
(Magistrates’ Courts, Supreme Court, and Court of
Appeal)
Government leader: Prime Minister Robert D.
Muldoon
Suffrage: universal age 18 and over
Elections: held at 3 year intervals or sooner if
parliament is disolved by Prime Minister; last election
November 1975
Political parties and leaders: National Party
(Government), Robert D. Muldoon; Labour Party
(Opposition), Wallace E. Rowling; Social Credit
Political League, Bruce Beetham; Communist Party,
George Victor Wilcox; pro-Soviet Socialist Unity
Party, George Edward Jackson
Voting strength (1975 election): National Party 55
seats, Labour Party 32 seats
Communists: CPNZ about 300, SUP about 100
Member of: ADB, ANZUS, ASPAC, Colombo
Plan, DAC, ESCAP, FAO, GATT, IAEA, IBRD,
ICAO, IEA, IFC, IHO, ILO, IMCO, IMF, IPU, ISO,
ITU, OECD, U.N., UNESCO, UPU, WHO, WMO,
WSG','7b387755f3aa14eedce34867f0e996448e42d854b1e13d0241a7eebd88cfd315','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e3a40c2f23d98c790f1ac53bfd2c53ffa6e32684113fa8bfb3818d4337e5d502',1977,'NI','Nicaragua','government',382,'Legal name: Republic of Nicaragua
Type: republic
Capital: Managua
Political subdivisions; 1 national district and 16
departments
Legal system: based on Spanish civil law system;
constitution adopted in 1974; legal education at
Universidad Nacional de Nicaragua and Universidad
Centroamericana; accepts compulsory IC] jurisdic-
tion
Approved For Release 2005/04/22 :
Branches: President (traditionally dominant)
bicameral legislature, judiciary elected by legislature,
and Supreme Electoral Tribunal (4th branch)
Government leaders: President Anastasio Somoza
Suffrage: universal over age 18 if married or
literate, otherwise 21
Elections: every 6 years; municipal elections every
3 years
Political parties and leaders: Nationalist Liberal
Party (PLN), Anastasio Somoza; Nicaraguan
Conservative Party (PCN), Edmundo Paguaga
Voting strength (1974 elections): PLN, 95% of
votes; 5% of votes; PCN will, however, occupy 40% of
legislative seats by constitutional provision
Communists; Communist movement split into
hard-line Nicaraguan Socialist Party (PSN) illegal, 60
members; soft-line Nicaraguan Communist Party
(PCN) illegal, 40 members, and small pro-Castro
Sandinist National Liberation Front (FSLN) activist,
50-150 members; about 1,000 sympathizers
Other political or pressure groups: Democratic
Union of Liberation (UDEL), an opposition front
lacking legal status of a political party, composed of
anti-Somoza political movements and labor groups
with orientations ranging from conservative to
Christian Democrat to Communist, leadership
includes Pedro J. Chamorro, Ramiro Sacasa, Ignacio
Zelaya, Domingo Sanchez; Nicaraguan Development
Institute (INDE), a private sector pressure group with
two operative arms: FUNDE and EDUCREDITO
which, respectively, promote cooperatives and
disburse educational loans
Member of: CACM, FAO, GATT, IADB, IBRD,
ICAC, ICAO, IDA, IDB, IFC, ILO, IMF,
INTELSAT, IPU, ISO, ITU, NAMUCAR (Caribbean
Multinational Ship-ping Line—Naviera Multi-
nacional del Caribe), OAS, ODECA, SELA, U.N.,
UNESCO, UPEB, UPU, WCL, WHO, WMO','3d1c500c60c61474bc316031c44aa1533f134414368b02edfe85853d5d52887d','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a425f2f049648a850f47de7834770ec068e851a99cb7b525312b0fa07e227091',1977,'NE','Niger','government',386,'Legal name: Republic of Niger
Type: republic; military regime in power since
April 1974
Capital: Niamey
Political subdivisions: 7 departments, 32
arrondissements
Legal system: based on French civil law system
and customary law; constitution adopted 1960,
suspended 1974; judicial review of legislative acts in
Constitutional Chamber of the Supreme Court; has
not accepted compulsory ICJ jurisdiction
Branches: executive authority exercised by
Supreme Military Council (SMC) composed of army
officers; cabinet includes civilians
Government leader: Lt. Col. Seyni Kountche,
President of Supreme Military Council and Chief of
State
Suffrage: suspended
Elections: political activity banned
Political parties and leaders: political parties
banned
Communists: no Communist party; some sympa-
thizers in outlawed Sawaba party
Member of: AFDB, APC, CEAO, EAMA, ECA,
ECOWAS, Entente, FAO, GATT, IAEA, IBRD,
ICAO, IDA, ILO, IMF, IPU, ITU, Lake Chad Basin
Commission, Niger River Commission, O0AU, OCAM,
U.N., UNESCO, UPU, WHO, WMO
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
aay
he
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
January 1977
NIGER/NIGERIA','8cb51c04da08b8eb474a0f56d92a9c9d7e135f3271c2a2ee1acea707138201e0','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('15c758bbf0e68939e57865cb6696d3ed59e526d6ef9f201160413d62dd40aae6',1977,'NG','Nigeria','government',390,'Legal name: The Federal Republic of Nigeria
Type: federal republic since 1963; under military
rule since January 1966
Capital: Lagos
Political subdivisions: 19 states, headed by
military governors
Legal system: based on English common law,
tribal law, and Islamic law; draft of proposed new
153
CIA-RDP79-01051A000800010006-3
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
January 1977
NIGERIA/NORWAY
constitution, made public in October 1976, to be
considered by a constituent assembly in October 1977;
accepts compulsory ICJ jurisdiction with reservations
Branches: Federal Military Government; decrees
issued by Supreme Military Council, advised by
largely civilian Federal Executive Council
Government leader: Lieutenant General Olusegun
Obasanjo, Head of Federal Military Government and
Commander in Chief of Nigerian Armed Forces
Suffrage: universal adult suffrage
Elections: nonpartisan elections for local govern-
ment councils scheduled for late 1976; the military
has promised to restore power to an elected civilian
regime when state and federal legislative elections are
held between October 1978 and October 1979
Political parties and leaders: political parties and
politically active tribal societies were dissolved by
decree on 24 May 1966; some sub rosa political
activity continues
Communists: the banned Socialist Workers and
Farmers Party and the Nigerian Trade Union
Congress have a limited political following, no
influence on government
Member of: AFDB, APC, Commonwealth, ECA,
ECOWAS, FAO, IAEA, IBRD, ICAO, IDA, IFC,
ILO, IMCO, IMF, ISO, ITC, ITU, [IWC —
International Wheat Council, Lake Chad Basin
Commission, Niger River Commission, OAU, OPEC,
U.N., UNESCO, UPU, WCL, WHO, WMO','d679ec2c3e3edc3d808008dbc4ba7faf350af7b8af7248bb0cf440c8f9e2e923','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1a68b04611c35e1030d693344c996605fb1b40ef83c7d1ce396860c802cbf256',1977,'NO','Norway','government',394,'Legal name: Kingdom of Norway
Type: constitutional monarchy
Capital: Oslo
Political subdivisions: 19 counties, 404 communes,
A7 towns
Legal system: mixture of customary law, civil law
system, and common law traditions; constitution
adopted 1814, modified 1884; Supreme Court renders
advisory opinions to legislature when asked; legal
education at University of Oslo; accepts compulsory
IC] jurisdiction, with reservations
Branches: legislative authority rests jointly with
Crown and parliament (Storting); executive power
vested in Crown but exercised by cabinet responsible
to parliament; Supreme Court, 5 superior courts, 104
lower courts
Government leaders: King Olav V; Prime Minister
Odvar Nordli
Suffrage: universal, but not compulsory, over age
20
Elections: held every 4 years (next in September
1977)
Political parties and leaders: Anti-Tax Party,
Arve Loennum; Conservative, Kaare Willoch;
Christian People’s, Lars Korvald; Center, Erland
Steenberg, Dagfinn Vaarvik; Liberal, Hans H.
Rossbach, Eva Kolstad; New Liberal People’s, Ole
Myrvoll, Magne Lerheim; Labor, Reiulf Steen;
combined Socialist Left Party, Berit Aas, chairman
Voting strength (1973 election): 5% Anti-tax;
17.5% Conservative; 12.2% Christian Peoples; 11%
Center; 3.5% Liberal; 3.4% New Liberal Peoples;
35.3% Labor; 11.2% Socialist Electoral Alliance
(includes Democratic Socialist, Socialist People’s, and
Communist Party)
Communists: 2,500 est.; a number of sympathizers
as indicated by the 22,500 Communist votes cast in
the 1969 election
Member of: ADB, Council of Europe, DAC, EC
(Free Trade Agreement), EFTA, ESRO (observer),
FAO, GATT, IAEA, IBRD, ICAC, ICAO, IDA, IEA
(associate member), IFC, IHO, ILO, International
Lead and Zinc Study Group, IMCO, IMF, IPU, ITU,
IWC—International Whaling Commission, [WC—
International Wheat Council, NATO, Nordic
Council, OECD, U.N., UNESCO, UPU, WHO,
WMO, WSG','3bad242ff07a8aa14361ce7ba7dcc3df916dd80da03cd1575311b37fdbe1d511','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e9ac99691449a2a0b503b196e64e3fe75ce34fd531020b6bf8d8e312ac0cb4fc',1977,'OM','Oman','government',398,'Legal name: Sultanate of Oman
Type: absolute monarchy; nominally independent
but under strong U.K. influence
Capital: Muscat
Legal system: based on English common law and
Islamic law; no constitution; ultimate appeal to the
Sultan; has not accepted compulsory IC] jurisdiction
Government leader: Sultan Qabus ibn Sa‘id Al Bu
Sa‘id
Other political or pressure groups: Popular Front
for the Liberation of Oman (PFLO)
Member of: Arab League, FAO, IBRD, ICAO,
IDA, IFC, IMF, U.N., UNESCO, UPU, WHO','c32f7416939bf4b96f24666701414143d813a81824c026f335f8361027285060','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8d6b5386c25245e2e1e9eb40a65061c52fbb4716b1cedeaf607e5e9b8e3ef5ab',1977,'PK','Pakistan','government',402,'Legal name: Islamic Republic of Pakistan
Type: parliamentary, federal republic; constitution
adopted April 1973, effective August 1973, provides
for bi-cameral legislature, strong prime minister
Capital: Islamabad
Political subdivisions: 4 provinces—Punjab, Sind,
Baluchistan, and Northwest Frontier—with the
capital territory of Islamabad and certain tribal areas
centrally administered; Pakistan claims that Azad
Kashmir is independent pending a settlement of the
dispute with India, but it is in fact under Pakistani
control
Legal system: based on English common law;
accepts compulsory ICJ jurisdiction, with reservations
Government leaders: President Fazal Elahi
Chaudhry; Prime Minister Z. A. Bhutto
Suffrage: universal from age 21
Elections: elections for National Assembly, based
on one-man/one-vote formula, and for provincial
assemblies were held in December 1970; under 1973
Constitution, next National Assembly elections must
be held no later than summer of 1977
Political parties and leaders: Pakistan People’s
Party (PPP), Z. A. Bhutto; Pakistan Muslim League
(QML), Abdul Qaiyum Khan; Pakistan Muslim
League—Pir of Pagaro group (PML); Tehrik-i-
Istiqulal, Asqhar Khan; National Awami Party
(NAP), Abdul Wali Khan (party outlawed in
February 1975); National Democratic Party (NDP),
Sherbaz Mazari (formed in 1975 by members of
outlawed NAP); Jamaat-i-Islami (JI), Tofail
Mohammed; Jamiat-ul-Ulema-i-Pakistan (JUP),
Maulana Shah Ahmed Noorani; Jamiat-ul-Ulema-i-
Islam (JUI), Mufti Mahmud; Pakistan Jamhoori
Party (PJP), Nasrullah Khan; several of these parties
belong to United Democratic Front (UDF), an
opposition coalition
Communists: party membership very small;
sympathizers estimated at several thousand
Other political or pressure groups: military
remains potentially strong political force
Member of: ADB, CENTO, Colombo Plan, FAO,
GATT, IAEA, IBRD, ICAC, ICAO, IDA, IFC, IHO,
ILO, IMCO, IMF, ITU, I[WC—International Wheat
Council, RCD, U.N., UNESCO, UPU, WHO,
WMO, WSG
157
: CIA-RDP79-01051A000800010006-3
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
January 1977
PAKISTAN/PANAMA','c176aef66752236366545863017f979779946ac9258a4f4493b461102a39a7a8','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6dc30691ec18272586118d1aabd73083252b3dfb37abcc98d6a2e075c54a6925',1977,'PA','Panama','government',406,'Legal name: Republic of Panama
Type: republic
Capital: Panama
Political subdivisions: 9 provinces, 1 intendancy
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
January 1977
PANAMA/PAPUA NEW GUINEA
Legal system: based on civil law system;
constitution adopted in 1972; judicial review of
legislative acts in the Supreme Court; legal education
at University of Panama; accepts compulsory ICJ
jurisdiction, with reservations
Branches: President (figurehead, subordinate to
National Guard Commandant, General Omar
Torrijos, who was granted special powers for 6 years
by the Constitutional Assembly in 1972); popularly
elected unicameral legislature (Correqimiento), which
elects the President but which exercises few, if any,
legislative powers and meets for one month each year;
during the remainder of the year the National
Legislative Council, the President, Vice President,
Cabinet, and selected members of the Corregimiento
exercise legislative functions; presidentially appointed
Supreme Court
Government leaders: Demetrio Lakas is Constitu-
tional President and Chief of State, but subordinate to
Gen. Omar Torrijos, the National Guard Comman-
dant
Suffrage: universal and compulsory over age 21
Elections: elections for assembly of corregimientos
Political parties and leaders: political parties
suspended; Communist Party illegal but allowed to
operate
Voting strength: no parties were active in the 1972
elections
Communists: 600 active and several hundred
inactive members People’s Party (PdP); 2,500
sympathizers
Other political or pressure groups: National
Council of Private Enterprise (CONEP)
Member of: FAO, IADB, IAEA, IBRD, ICAO,
IDA, IDB, IFC, ILO, IMCO, IMF, ITU, IWC—
International Whaling Commission, IWC—Interna-
* tional Wheat council, OAS, SELA, U.N., UNESCO,
UPEB, UPU, WCL, WFTU, WHO, WMO','0ba5bbb271e23eca4020fae25bfded13f90a0a3b127ea6150563323233315c68','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('94b74ad7da9fff94e84ae6c59db6c2a089123f8144401e9138e23eb25e749b0d',1977,'PG','Papua New Guinea','government',410,'Legal name: Papua New Guinea
Type: independent state within Commonwealth
recognizing Elizabeth II as head of state
Capital: Port Moresby
Political subdivisions: 18 administrative districts
(12 in New Guinea, 6 in Papua)
Legal system: based on English common law
Branches: executive—Executive Council; legisla-
ture—House of Assembly (100 members, plus 4
appointed); judiciary—court system consists of
Supreme Court of Papua New Guinea and various
inferior courts (District Courts, Local Courts,
Children’s Courts, Wardens’ Courts)
Government leader: Governor General, Sir John
Guise; Prime Minister, Michael Somare
Suffrage: universal adult suffrage
Elections: preferential-type elections for 100-
member House of Assembly every 4 years
160
Political parties: Pangu Party is principal political
group; 5 or 6 other small parties and numerous
independents
Voting strength (1972 election): Pangu Party and
Allies won 52 seats, United Party 42 seats,
Independence 6 seats
Communists: no significant strength
Member of: ADB, CIPEC (associate), Common-
wealth, ESCAP (associate), IBRD, IMF, U.N., WHO
(associate)','3853d2a068614b394b5dc45c49fb4f060588767b0dd6d46e5636f104fc063fe2','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cf80d5a7d799cbc5469e6d8673fa4c4f931ddca8502af7a3c8dd964a42153c1c',1977,'PY','Paraguay','government',414,'Legal name: Republic of Paraguay
Type: republic; under authoritarian rule
Capital: Asuncion
Political subdivisions: 16 departments and the
national capital, 154 municipalities
Approved For Release 2005/04/22 :
Legal system: based on Argentine codes, Roman
law, and French codes; constitution promulgated
1967; judicial review of legislative acts in Supreme
Court; legal education at National University of
Asuncion and Catholic University of Our Lady of the
Assumption; does not accept compulsory ICJ
jurisdiction
Branches: President heads executive; bicameral
legislature; judiciary headed by Supreme Court
Government leader: President (General) Alfredo
Stroessner
Suffrage: universal; compulsory between ages of
18-60
Elections: President and Congress elected together
every 5 years; last election held in February 1973
Political parties and leaders: Colorado Party, Juan
Ramon Chavez; Liberal Party (Levi-Liberal Party),
Carlos Levi Ruffinelli; Febrerista Party, Roque
Gaona; Radical Liberal Party (regular Liberal Party),
Domingo Laino; Christian Democratic Party (not
officially inscribed), Livis Resck
Voting strength (February 1973 general elec-
tion): 84% Colorado Party, 13% Radical Liberal
Party, 3% Liberal Party, Febrerista Party boycotted
elections
Communists: Oscar Creydt faction and Miguel
Angel Soler faction (both illegal); est. 3,000 to 4,000
party members and sympathizers in Paraguay, very
few are hard core; party in exile is small and deeply
divided
Other political or pressure groups: Popular
Colorado Movement (MoPoCo) led by Epifanio
Mendez Fleitas, in exile
Member of: FAO, IADB, IAEA, IBRD, ICAO,
IDA, IDB, IFC, ILO, IMF, IPU, ITU, LAFTA, OAS,
SELA, U.N., UNESCO, UPU, WCL, WHO, WMO,
WSG','a104c6583681e3c56700d4213a8e30474714810a1443880a00ef53b6d1565f97','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('dd6f9ef1952134416f0caa69dc6c62c57cc4e86c33bac6ab3fd04ca4f86dc264',1977,'PE','Peru','government',418,'Legal name: Republic of Peru
Type: republic; under military regime since
October 1968
Capital: Lima
Political subdivisions: 23 departments with limited
autonomy plus constitutional Province of Callao
Legal system: based on civil law system; military
government rules by decree and functions under
Revolutionary Statute which supersedes 1933
constitution; legal education at the National
Universities in Lima, Trujillo, Arequipa, and Cuzco;
has not accepted compulsory ICJ jurisdiction
Branches: executive, legislative, judicial; congress
disbanded after 8 October 1968 ouster of President
Fernando Belaunde Terry
Government leader: President, General Francisco
Morales Bermudez Cerrutti
Suffrage: obligatory for citizens (defined as adult
men and women and married persons over age 18)
until age 60
Elections: none scheduled
Political parties and leaders: Christian Demo-
cratic Party (PDC), Juan Lituma Portocarrero,
President, supports the government; opposition parties
include the Popular Action Party (AP), Fernando
Belaunde Terry; American Popular Revolutionary
Alliance (APRA), Victor Raul Haya de la Torre; and
Popular Christian Party (PPC), Luis Bedoya Reyes
Voting strength (1963 election): 89% AP-PDC,
34% APRA, 25% UNO, 1% Communist, 1% other
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
January 1977
PERU/ PHILIPPINES
Communists: pro-Soviet (PCP/S) 2,000; pro-
Chinese (2 factions) 1,200
Other political or pressure groups: government-
sponsored social mobilization system (SINAMOS)
which is being restructured; a pro-government
political organization is currently in the formative
stage
Member of: AIOEC, ASSIMER, CIPEC, FAO,
GATT, IADB, IAEA, IATP, IBRD, CIPEC, ICAO,
IDA, IDB, IFC, ILO, International Lead and Zinc
Study Group, IMCO, IMF, ISO, ITU, IWC—
International Wheat Council, LAFTA and Andean
Pact, OAS, U.N., UNESCO, UPU, WCL, WFTU,
WHO, WMO, WSG','ce3e7310a2f7576533aeaf5b3b25365c55352551efc7e7d41275e91a0cf910a8','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('19385e3a9f6e227d558c4f1c645290c2de281be6b47d45b0c32e031842a27f8e',1977,'PL','Poland','government',423,'Legal name: Polish Peoples Republic (PRL)
Type: Communist state
Capital: Warsaw ,
Political subdivisions: 49 provinces
Legal system: mixture of Continental (Napoleonic)
civil law and Communist legal theory; constitution
Approved For Release 2005/04/22
PHILIPPINES/POLAND
adopted 1952; court system parallels administrative
divisions with Supreme Court, composed of 104
justices, at apex; no judicial review of legislative acts;
legal education at 7 law schools; has not accepted
compulsory ICJ jurisdiction
Branches: legislative, executive, judicial system
dominated by parallel Communist party apparatus
Government leader: Piotr Jaroszewicz, Premier;
Henryk Jablonski, chairman of Council of State
(President)
Suffrage: universal and compulsory over age 18
Elections: parliamentary and local government
every 4 years
Dominant political party and leader: Polish
United Workers’ Party (PZPR) (Communist), Edward
Gierek, First Secretary
Voting strength (1975 election): 99% voted for
Communist-approved single slate
Communists: 2,359,000 party members (October
1975)
Other political or pressure groups: National Unity
Front (FJN), including United Peasant Party (ZSL),
Democratic Party (SD), progovernment pseudo-
Catholic Pax Association and Christian Social
Association, Catholic independent Znak group;
powerful Roman Catholic Church, Stefan Cardinal
Wyszynski, Primate
Member of: CEMA, GATT, ICAO, IHO,
Indochina Truce Commission, International Lead
and Zine Study Group, IPU, ISO, ITC, Korea Truce
Commission, U.N. and all specialized agencies except
IMF and IBRD, Warsaw Pact, WFTU','0b53f94756295e884ce6a417ec51b48104d414c2d02a8926d4c3e29f42d718b6','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('84463dd343fcb86db9291d0e75c1a515938996c50c71bca6a361db4faed5fcf0',1977,'QA','Qatar','government',427,'Legal name: State of Qatar
Type: traditional monarchy; independence
declared in 1971
Capital: Doha
Legal system: discretionary system of law
controlled by the ruler, although new civil codes are
being implemented; Islamic law is significant in
personal matters; a constitution was promulgated in
1970
Government leader: Amir Khalifa ibn Hamad Al-
Thani
Suffrage: no specific provisions for suffrage laid
down
Elections: constitution calls for elections for part of
State Advisory Council, semi-legislative body, but
none have been held
Political parties and pressure groups: none; a few
small clandestine organizations are active
168
Branches: Council of Ministers; appointive 30-
member Advisory Council
Member of: Arab League, FAO, GATT (de facto),
IBRD, ICAO, ILO, IMF, OAPEC, OPEC, U.N.,
UNESCO, UPU, WHO','d1674647f3f3272be16c01f9b816defc03825e4c18080c014a2a71319fb2b1de','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('663d1525ed341833094fab82d168397469d0f0f59d0b9e555e03e68a59ceae53',1977,'RO','Romania','government',431,'Legal name: Socialist Republic of Romania
Type: Communist state
Capital: Bucharest
Political subdivisions: 39 counties and 46
municipalities, including Bucharest that has
administrative status equal to a county
Legal system: mixture of civil law system and
Communist legal theory which increasingly reflects
Romanian traditions; constitution adopted 1965;
legal education at University of Bucharest and two
other law schools; has not accepted compulsory IC]
jurisdiction
Branches: Presidency; Council of Ministers; the
Grand National Assembly, under which is Office of
Prosecutor General and Supreme Court; Council of
State
Government leaders: Manea Manescu, President
of the Council of Ministers, head of government;
Nicolae Ceausescu, President of the Socialist
Republic, head of state
Suffrage: universal over age 18, compulsory
Elections: elections in Romania held every 4 years
for the local people’s councils and every 5 years for
Grand National Assembly deputies
Political parties and leaders: Communist Party of
Romania only functioning party, Nicolae Ceausescu,
Secretary General
Voting strength (1975 election): overall participa-
tion reached 99.96%; of those registered to vote
(14,900,032), 98.8% voted for party candidates
Communists: 2,480,000 party members (December
1974)
171
: CIA-RDP79-01051A000800010006-3
~
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
January 1977
ROMANIA/RWANDA
Member of: CEMA, FAO, GATT, IAEA, IBRD,
ICAO, ILO, IMF, IPU, ITU, U.N,, UNESCO, UPU,
Warsaw Pact, WFTU, WHO, WMO','01688417bb54d0a3cbbbddcf5710590da79b7914cd2b4fd1586c6e5def13595b','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3980f6968e047fe2c79ce90104a5020953d2375fafb2293610c8d09472ead746',1977,'RW','Rwanda','government',435,'Legal name: Republic of Rwanda
Type: republic, presidential system in which
military leaders hold key offices; 1962 constitution
still in force except for Title V on the National
Assembly
Capital: Kigali
Political subdivisions: 10 prefectures, subdivided
into 142 communes
Legal system: based on German and Belgian civil
law systems and customary law; constitution adopted
1962; judicial review of legislative acts in the Supreme
Court; has not accepted compulsory ICJ jurisdiction
Branches: President, Committee for Peace and
National Unity (composed of high military
command), and 12-member cabinet
Government leader: General Juvenal Hab-
yarimana, Head of State
Suffrage: universal
Elections: last legislative election September 1969;
none allowed by present government; elections of
Communal Counsellors held November 1974
: CIA-RDP79-01051A000800010006-3
lp
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
January 1977
RWANDA/ST, CHRISTOPHER-NEVIS-ANGUILLIA
Political parties and leaders: National Revo-
lutionary Movement for Development, General
Hybyarimana
Communists: no Communist party; U.S.S.R. and
People’s Republic of China have diplomatic missions
in Rwanda
Member of: AFDB, EAMA, FAO, GATT, IBRD,
ICAO, IDA, ILO, IMF, IPU, ITU, OAU, OCAM,
U.N., UNESCO] UPU, WCL, WHO, WMO','b9965316e4f9eb31a40cb39731599f7083eb09f521c9a45475e375574afbe7a0','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f53373b502c3e166f01078c44a697763f0434322719c002703cf0a58f129a6ff',1977,'AI','Anguilla','government',439,'Legal name:
Type: dependent territory with full internal
autonomy as a British “‘Associated State’; Anguilla
formally seceded in May 1967 but has not been
recognized as an independent state by any
government; in July 1968 a legislative council headed
by Ronald Webster was elected to govern Anguilla; in
March 1969 the U.K. sent troops to Anguilla, placing
the island again under colonial rule; in 1971, Anguilla
reverted to its former colonial relationship with the
U.K. although nominally remaining part of the
Associated state of St. Christopher-Nevis-Anguilla;
Webster became leader of Anguillan Council after
constitutionally held elections (1972); in February
State of St. Christopher-Nevis-
173
CIA-RDP79-01051A000800010006-3
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
January 1977
ST. CHRISTOPHER-NEVIS-ANGUILLA/ST. LUCIA
1976, the U.K. granted a new constitution to Anguilla
which changed its status to that of a crown colony
Capital: Basseterre
Political subdivisions: 10 districts
Legal system: based on English common law;
constitution of 1960; highest judicial organ is Court of
Appeal of Leeward and Windward Islands
Branches: legislative, 10-member popularly elected
House of Assembly; executive, cabinet headed by
Premier
Government leaders: Premier, Robert L. Brad-
shaw; U.K. Governor, Probyn Inniss
Suffrage: universal adult suffrage
Elections: at least every 5 years; most recent 10
May 1971
Political parties and leaders: St. Christopher-
Nevis-Anguilla Labor Party, Robert L. Bradshaw;
People’s Action Movement (PAM), William Herbert;
Nevis Reformation Party (NRP), Ivor Stevens
Voting strength (May 1971 election): St.
Christopher-Nevis-Anguilla Labor Party won 7 seats
in the House of Assembly, PAM won 1, NRP won 1,
and | seat remains open for Anguilla which did not
participate in the election
Communists: none known
Member of: CARICOM, ISO
Legal name: State of St. Lucia
Type: dependent territory with full internal
autonomy as a British ‘Associated State”
Capital: Castries
Political subdivisions: 16 parishes
Legal system: based on English common law;
constitution of 1960; highest judicial body is Court of
Appeal of Leeward and Windward Islands
Branches: legislative, 17-member popularly elected
House of Assembly; executive, cabinet headed by
Premier
Government leaders: Premier John Compton;
U.K. Governor Sir Allen Lewis
Suffrage: universal adult suffrage
Elections: every 5 years; most recent May 1974
Political parties and leaders: United Worker''s
Party (UWP), John Compton; St. Lucia Labor Party
(SLP), Allan Louisy
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
January 1977
ST. LUCIA/ST. VINCENT
Voting strength (1974 election): UWP (53%) won
10 of the 17 elected seats in House of Assembly; SLP
(45%) won 7 seats; independents (2%) no seats
Communists: negligible
Member of: CARICOM
Legal name: State of St. Vincent
Type: dependent territory with full internal
autonomy as a British “Associated State”
Capital: Kingstown
Legal system: based on English common law;
constitution of 1960; highest judicial body is Court of
Appeal of Leeward and Windward Islands
Government leader: Premier R. Milton Cato,
Governor General (U.K.) Sir Rupert G. John
Suffrage: universal adult suffrage (18 years old and
over)
Elections: every 5 years; most recent December 9,
1974
Political parties and leaders: People’s Political
Party (PPP), Ebenezer Joshua; St. Vincent Labor
Party (LP), R. Milton Cato; Democratic Freedom
Movement, Parnell Campbell and Kenneth John
Voting strength (1974 election): LP 10 seats, PPP 2
seats, independent 1 seat in the Legislature
Communists: negligible
Member of: CARICOM','8afc8f47ab06f7b82e801c5be5e599683ed0c3dac2b3ceebb17ad45237bb277e','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3b3430c59e5f84582a433a081ecfae94d685d8c7c0e1ce0313521d665706ccf9',1977,'SM','San Marino','government',443,'Legal name: Republic of San Marino
Type: republic (dates from 4th century A.D.); in
1862 the Kingdom of Italy concluded a treaty
guaranteeing the independence of San Marino;
although legally sovereign, San Marino is vulnerable
to pressure from the Italian Government
Capital: San Marino
Political subdivisions: San Marino is divided into 9
castelli: Acquaviva, Borgo Maggiore, Chiesanuova,
Dogmanano, Faetano, Fiorentino, Monte Giardino,
San Marino, Serravalle
Legal system: based on civil law system with
Italian law influences; electoral law of 1926 serves
some of the functions of a constitution; has not
accepted compulsory ICJ jurisdiction
Branches: the Grand and General Council is the
legislative body elected by popular vote; its 60
members serve 5-year terms; Council in turn elects
two Captains-Regent who exercise executive power for
term of 6 months, the Council of State whose
members head government administrative depart-
ments and the Council of Twelve, the supreme
judicial body; actual executive power is wielded by
the Secretary of State for Foreign Affairs and the
Secretary of State for. Internal Affairs
Government leaders: Secretary of State for Foreign
and Political Affairs and for Information, Giancarlo
Ghironzi (Christian Democratic party); Secretary of
State for Internal Affairs and Justice, Clara Boscaglia
(Christian Democratic party); Secretary of State for
Budget, Finance, and Planning, Remy Giacomini
(Socialist Party)
Suffrage: universal (since 1960)
Elections: elections to the Grand and General
Council required at least every 5 years; next elections
1979
Political parties and leaders: Christian Demo-
cratic party (DCS), Gian Luigi Berti; Social
Democratic Party (PSDSM), Alvaro Casali; Socialist
Party (PSS), Remy Giacomini; Communist Party
(PCS), Umberto Barulli; People’s Democratic Party
(PDP), leader unknown; Committee for the Defense
of the Republic (CDR), leader unknown
Voting strength (1974 election): 39.6% DCS,
23.7% PCS, 15.4% PSDIS, 13.9% PSS, 1.9% PDP,
2.9% CDR
Communists: approx. 300 members (number of
sympathizers cannot be determined); PSS, in
government with Christian Democrats since March
: CIA-RDP79-01051A000800010006-3
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
January 1977
SAN MARINO/SAO TOME AND PRINCIPE
1973, formed a government with the PCS from the
end of World War II to 1957
Other political parties or pressure groups:
political parties influenced by policies of their
counterparts in Italy, the two Socialist parties are not
united
Member of: ICJ, International Institute for
Unification of Private Law, International Relief
Union, IRC, UPU, WFTU','c888006d1912556f85ffd58fcf4ccf6ad6bedda04ce01db1554a580e32c54a15','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('538d1bfb55f767f4d391482c10553e2584b3b5c80e3f5f3b7032c452680e7a0a',1977,'ST','Sao Tome and Principe','government',447,'Legal name: Democratic Republic of Sao Tome
and Principe
Type: republic established when independence
received from Portugal on July 1975; constitution
adopted December 1975
Capital: Sao Tome
Legal system: based on Portuguese law system and
customary law; has not accepted compulsory ICJ
jurisdiction
Branches: Da Costa heads the government assisted
by a cabinet of ministers
Government leader: President Manuel Pinto Da
Costa, Prime Minister Miguel Anjos da Cuna Lisboa
Trovoada
177
CIA-RDP79-01051A000800010006-3
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
January 1977
SAO TOME AND PRINCIPE/SAUDI ARABIA
Suffrage: universal for age 18 and over
Elections: elections were held July 1975 for the
President
Political parties and leaders: Movement for the
Liberation of Sao Tome and Principe (MLSTP),
Secretary-General Manuel Pinto Da Costa
Communists: no Communist party, probably a few
Communist sympathizers
Member of: OAU, U.N.','7cedc3e256ccfdc7f57b3b36268dd0e653b34736202a9e8b50582ddf579fe718','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e967c89f7490a5ed5deff89a969f74c9bf810c7b63f8c6760c21d7bd8c29e1c1',1977,'SA','Saudi Arabia','government',451,'Legal name: Kingdom of Saudi Arabia
Type: monarchy
Capital: Riyadh; foreign ministry and foreign
diplomatic representatives located in Jiddah
Political subdivisions: 18 amirates
Legal system: largely based on Islamic law, several
secular codes have been introduced; commercial
disputes handled by special committees; has not
accepted compulsory ICJ jurisdiction
Branches: King Khalid (Al Saud, Khalid ibn Abd
al-Aziz) rules in consultation with royal family
(especially Crown Prince Fahd), and Council of
Ministers
Government leader: King Khalid
Communists: negligible
Member of: Arab League, FAO, IAEA, IBRD,
ICAO, IDA, IFC, IMF, ITU, IWC—International
Wheat Council, OAPEC, OPEC, U.N., UNESCO,
UPU, WHO, WMO','8c067811e9babffced6840c6c27493fc8aec1dd1bfa735d4b09bcd5954df6eac','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a728212ab0d631c520c5cc07582b1569749020c07afad937883483974b386ee8',1977,'SN','Senegal','government',455,'Legal name: Republic of Senegal
Type: republic
Capital: Dakar
Political subdivisions: 7 regions, each subdivided
into 18 departments, 90 districts, and 34 communes
179
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
January 1977
SENEGAL/SEYCHELLES
Legal system: based on French civil law system;
constitution adopted 1960, revised 1963 and 1970;
judicial review of legislative acts in Supreme Court
(which also audits the government''s accounting
office); legal education at University of Dakar; has
not accepted compulsory ICJ jurisdiction
Branches: government dominated by President
who is assisted by Prime Minister, appointed by
President and subject to dismissal by President or
censure by National Assembly; 80-member National
Assembly, elected for 5 years (effective 1973);
President elected for 5-year term (effective 1973) by
universal suffrage; judiciary headed by Supreme
Court, with members appointed by President
Government leaders: Leopold Sedar Senghor,
President; Abdou Diouf, Prime Minister
Suffrage: universal adult
Elections: uncontested presidential and legislative
elections held February 1973 for 5-year term
Political parties and leaders: Union Progressiste
Senegalaise (UPS), ruling party led by President
Leopold Senghor; Parti Democratique Senegalaise
(PDS), legal “liberal democratic’ party founded July
1974, and illegal parties include Communist-backed
““Marxist-Leninist’’ African Independence Party
legalized in August 1976 and Parti Communiste
Senegalais (PCS), a splinter group
Communists: a few Communists and sympa-
thizers; PAI is pro-Moscow; PCS in pro-Peking
Other political or pressure groups: labor unions
are controlled by party; students and_ teachers
occasionally strike
Member of: AFDB, APC, CEAO, EAMA, ECA,
ECOWAS, EIB (associate), FAO, GATT, IAEA,
IBRD, ICAO, IDA, IFC, ILO, IMCO, IMF, ITU,
OAU, OCAM, OMVS (Organization for the
Development of the Senegal River Valley), U.N.,
UNESCO, UPU, WCL, WHO, WMO','f13b446ae2634194036bce2613c8b19fa5b71daca704c76cec5b60c186d22f2e','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7748d0d30629b6a76c57f124b66b391ece7109f722e53a4b6a40aa8a90b20157',1977,'SC','Seychelles','government',459,'Legal name: Seychelles
Type: republic; member of the Commonwealth
Capital: Victoria, Mahe Island
Legal system: based on English common law,
French civil law system, and customary law
Branches: President, Council of Ministers,
Legislative Assembly
Government leaders: President, James Mancham;
Prime Minister, France Albert Rene
Suffrage: universal adult
Elections: April 1974, held every 5 years
Political parties and leaders: Seychelles Demo-
cratic Party (SDP), James R. Mancham, President;
Seychelles Peoples United Party (SPUP), France
Albert Rene, President
Voting strength: SDP won 13 seats in Legislative
Assembly with 52.4% popular vote in 1974 election;
SPUP won 2 seats with 47.6% of votes; under
agreement reached in March 1975, each party named
five new members to the legislature
Communists: negligible
Other political or pressure groups: trade unions
which are appendages of political parties
Member of: OAU, WCL','9c87b8c3200987672e564c8b611a0af1ee281af17a41cf2ec0c00802fcd4a638','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e6e1069347131bd3cecc2022ed61ca367c1da06c20c971aeb8f6490560fa7881',1977,'SL','Sierra Leone','government',463,'Legal name: Republic of Sierra Leone
Type: republic under presidential regime since
April 1971
Capital: Freetown
Political subdivisions: 8 provinces; divided into 12
districts with 146 chiefdoms, where paramount chief
and council of elders constitute basic unit of
government; plus western area, which comprises
Freetown and other coastal areas of the former colony
Legal system: based on English law and customary
laws indigenous to local tribes; constitution adopted
April 1971; highest court of appeal is the Sierra Leone
Court of Appeals; has not accepted compulsory ICJ
jurisdiction
Branches: executive authority exercised by
President; parliament consists of 100 authorized seats,
85 of which are filled by elected representatives of
constituencies and 12 by Paramount Chiefs elected by
fellow Paramount Chiefs in each district; President
authorized to appoint three members, of which two,
182
currently, are filled by the heads of the Army and the
Police independent judiciary
Government leader: Siaka Stevens, President,
heads APC government composed of members of his
political party
Suffrage: universal over age 21
Elections: the maximum life of an elected
parliament is 5 years, but it may be dissolved earlier
by the President; parliamentary election held in May
1978; President is elected by parliament for 5 year
term; next presidential election 1981
Political parties and leaders: All People’s Congress
(APC), headed by Stevens; Sierra Leone People’s
Party (SLPP) is the opposition party
Communists: no party, although there are a few
Communists and a slightly larger number of
sympathizers
Member of: AFDB, AIOEC, Commonwealth,
ECA, ECOWAS, FAO, GATT, IAEA, IBA, IBRD,
ICAO, IDA, IFC, ILO, IMF, IPU, ITU, OAU, U.N.,
UNESCO, UPU, WCL, WHO, WMO','a862f8b5914182c04996bc0d07b78d0c37c7469af98fb478e610435332e81690','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('dd85aa68444fe8fcab6ee070b999ba48c2c572a440054bfbc7dff35a601ceffb',1977,'SG','Singapore','government',467,'Legal name: Republic of Singapore
Type: republic within Commonwealth since
separation from Malaysia in August 1965
Capital: Singapore
Legal system: based on English common law;
constitution based on preindependence State of
Singapore constitution; legal education at University
of Singapore; has not accepted compulsory ICJ
jurisdiction
Branches: ceremonial President; executive power
exercised by Prime Minister and cabinet responsible to
unitary legislature
Government leaders: President, Dr. Benjamin
Sheares; Prime Minister, Lee Kuan Yew
Suffrage: universal over age 20; voting compulsory
Elections: normally every 5 years
Political parties and leaders: government—
People’s Action Party (PAP), Lee Kuan Yew;
opposition—Barisan Sosialis Party (BSP), Dr. Lee Siew
Choh; Workers’ Party, J.B. Jeyaretnam; Communist
Party illegal
Voting strength (1972 election): PAP won all 65
seats in parliament and received 70% of vote;
remaining 30% to four opposition parties
Communists: 200-500; Barisan Sosialis Party
infiltrated by Communists
Member of: ADB, ANRPC, ASEAN, Colombo
Plan, GATT, IBRD, ICAO, IFC, IHO, ILO, IMCO,
IMF, IPU, ISO, ITU, U.N., UNESCO, UPU, WHO,
WMO','f9784d0f048591b9010d649ded245471c63c2f2dfb035dcef9b2305a4469c03f','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cf07f83c91fcfdbac1d7529539475d182f25bd349d578b221033f6df66348eda',1977,'SO','Somalia','government',471,'Legal name: Somali Democratic Republic
Type: republic
Capital: Mogadiscio
Political subdivisions: 16 regions, 60 districts
Organization: the Somali Socialist Revolutionary
Party, created on July 1, 1976, has become the new
executive body in the country; party has 74-man
central committee and 5-man politburo headed by
President Siad
Government leader: President and Prime Minister,
Gen. Mohamed Siad Barre
Communists: possibly some Communist sympa-
thizers in the government hierarchy
Member of: AFDB, EAMA, FAO, IBRD, ICAO,
IDA, IFC, ILO, IMF, ITU, OAU, U.N., UNESCO,
UPU, WFTU, WHO, WMO','70d704fff06a43abb5bcc101c45ac3e71ac59e23ec97d1dddbfb7d5c5c8cdee4','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8d1ef5c606be5b0e320b4a7a67dec3141e75614160ba8c47edf3b535433410f1',1977,'ZA','South Africa','government',475,'Legal name: Republic of South Africa
Type: republic
Capital: administrative, Pretoria; legislative, Cape
Town; judicial, Bloemfontein
Political subdivisions: 4 provinces, each headed by
centrally appointed administrator; provincial
councils, elected by white electorate, retain limited
powers
Legal system: based on Roman-Dutch law and
English common law; constitution enacted 1961,
changing the Union of South Africa into a Republic;
possibility of judicial review of Acts of Parliament
concerning dual official languages; accepts compul-
sory ICJ jurisdiction, with reservations
Branches: President as formal chief of state; Prime
Minister as head of government; Cabinet responsible
to bicameral legislature; lower house elected directly
by white electorate; upper house indirectly elected
and appointed; judiciary maintains substantial
independence of government influence
Government leader: Prime Minister Balthazar
Johannes Vorster
Suffrage: general suffrage limited to whites over 18
(17 in Natal Province)
185
CIA-RDP79-01051A000800010006-3
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
January 1977
Elections: must be held at least every 5 years; last
elections April 1974
Political parties and leaders: National Party, B. J.
Vorster, P. W. Botha, C. Mulder, M. C. Botha, Jan De
Klerk; United Party, Sir De Villiers Graaff;
Progressive-Reform Party, Colin Eglin, Harry
Schwarz, Helen Suzman; Herstigte Nasionale party,
Albert Hertzog
Voting strength: (1974 general elections) parlia-
mentary seats: 122 National Party, 4] United Party, 6
Progressive Party
Communists: small Communist Party illegal since
1950; party in exile maintains headquarters in
London; Dr. Yasuf Dadoo, Moses Kotane, Joe Slovo
Other political groups: (insurgent groups in exile)
African National Congress (ANC), Oliver Tambo;
Pan-Africanist Congress (PAC), leadership in dispute
Member of: GATT, IAEA, IBRD, ICAO, IDA,
IFC, IHO, International Lead and Zinc Study Group,
IMF, ISO, ITU, IWC—International Whaling
Commission, IWC—International Wheat Council,
U.N., UPU, WFTU, WHO, WMO, WSG
Legal name: Republic of Transkei
Type: republic
Capital: Umtata
Political subdivisions: 28 administrative districts
Legal system: based on English common law and
African customary law; decisions of Transkei Supreme
Court can be appealed to South African Supreme
Court
Branches: President as formal chief of state; Prime
Minister as head of government; Cabinet responsible
to National Assembly, which has 75 seats for
hereditary tribal chiefs and 75 seats for popularly
elected members
Government leader: Prime Minister Kaiser
Matanzima
Suffrage: Transkeian citizens over 21 years of age
Elections: must be held at least every 5 years; last
general election October 1976
Political parties and leaders: Transkei National
Independence Party, Chief Kaiser Matanzima;
Transkei People’s Freedom Party, Cromwell Diko;
Democratic Party, Hector Ncokazi; New Democratic
Party, Knowledge Guzana
Voting strength: (1976 general election) National
Assembly seats; 142 Transkei National Independence
Party, 4 Transkei People’s Freedom Party, 2
Democratic Party, 2 New Democratic Party
Communists: no Communist Party
Legal name: Territory of South-West Africa
Type: former German colony of South-West Africa
mandated to South Africa by League of Nations in
1920; U.N. formally ended South Africa’s mandate on
October 27, 1966, but South Africa has retained
administrative control
Capital: Windhoek
Political subdivisions: 10 tribal homelands, mostly
in northern sector, and zone open to white settlement
with administrative subdivisions similar to a province
of South Africa
Legal system: based on Roman-Dutch law and
customary law
Branches: administrator, appointee of South
African Government, has jurisdiction over zone of
white settlement with white-elected Legislative
Assembly handling some local matters; white residents
also elect representatives in South African Parliament;
tribal homelands are under South African Department
of Bantu Administration and Development with tribal
ch''efs exercising limited autonomy; popularly elected
legislative councils for Ovamboland and Kavango-
land established in August 1973
Government leader: B. J. van der Walt,
Administrator
Suffrage: limited to white adults
Elections: last general election, 1974
Political parties and leaders: white parties—
National Party (NP), led in South-West Africa by A.
H. du Plessis; United National South-West Party
(UNSWP), J. P. Niehaus
Voting strength: NP (1974 election) won 5 of 6
seats in Republic legislature
Communists: no Communist Party, but some
influence by South African Communists and other
Communists on South-West African blacks outside
territory
Other political or pressure groups: nonwhite—
South-West Africa People’s Organization (SWAPO),
almost exclusively based on Ovambo tribe led by Sam
Nujoma, in exile; South-West Africa National Union
(SWANU), primarily based on Herero tribe, leaders in
exile; National Unity Democratic Organization
(NUDO), primarily based on Herero tribe led by
Clements Kapuuo; Namibian National Convention,
an alliance of non-white groups that oppose separate
development for tribal homelands','bd0e34c0c3f9b33ef03884cc0cbb5f4279df2f1b32be6d20addbcb851252d437','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e36e52e1752103be73b897b92d1a2473e8a75f4280efa694f061df2ad38e5c85',1977,'ES','Spain','government',478,'Legal name: (The) Spanish State
Type: a monarchy facing the problem of how to
liberalize the authoritarian regime of the late
Generalissimo Franco; proclaimed Juan Carlos King,
on November 22, 1975
Capital: Madrid
Political subdivisions: metropolitan, Spain,
including the Canaries and Balearics, divided into 50
provinces with governors appointed by the central
government; also 5 places of sovereignty (presidios) on
the Mediterranean coast of Morocco; transferred
administration of Spanish Sahara to Morocco and
Mauritania on February 26, 1976
Legal system: civil law system, with regional
applications of customary law; 7 basic laws including
Organic Law of the State of January 1967 serve as a
constitution; judges decide cases, no jury system; does
not accept compulsory ICJ jurisdiction
Branches: executive, with King’s acts subject to
counter-signature, Prime Minister likely to dominate
all branches of government through his position as
chief of government; legislative with unicameral
Cortes dominated by executive (constitutional reform
underway to establish bicameral legislature); judicial,
independent in principle but generally limited to
interpretation of laws
Government leaders: King Juan Carlos I—Chief of
State, Commander in Chief of the armed forces, and
titular head of the National Movement (formerly
called the Falange), Prime Minister Adolfo Suarez
Gonzalez
Suffrage: universal in national referendums, over
age 21
Elections: only two types of direct election other
than referendum provided: heads of families and
married women choose one-third of the municipal
councilors for 6-year term with one-half of councils
chosen every three years (latest election November
1973) and, under new constitutional law of 1967, 104
members of the Cortes elected by heads of households
and married women for a 4-year term (last election
September 1971; September 1975 election postponed
probably until early 1977 after referendum on reform
of legislature is held)
Political parties and leaders: National Movement
lost its position as the unitary party when the law of
June 1976 authorized political parties; a number of
rightist parties have been approved; various
semiclandestine opposition groups who have thus far
refused to apply for legislation include—Christian
Democratic factions under Jose Maria Gil Robles and
Joaquin Ruiz Gimenez; the Socialists include the
Spanish Socialist Workers Party (PSOE), led by
“Young Turk” Felipe Gonzalez, the Popular Socialist
189
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
January 1977
Party under Enrique Tierno Galvan, and the small
new Spanish Social Democratic Union; the
Anarchists; Monarchists; smaller regional and
national splinter groups; the Spanish Communist
Party, whose secretary general, Santiago Carrillo
Solares, is in exile, as well as a small dissident pro-
Soviet faction led by exiled Enrique Lister Forjan; and _
some small radical Communist groups which appear
and disappear under varying names; most of the
opposition groups joined one of two loosely-knit
coalitions—the Communist-dominated Democratic
Junta, formed in July 1974, and the Socialist-
Christian Democratic Platform of Democratic
convergence, established June 1975; these two groups
agreed in March 1976 to merge under name of the
Democratic Coordination or “Plata-Junta”
Voting strength: 561 seats, but somewhat fewer
members as some hold more than one seat—19%
representing the family elected directly; 45%
representing municipalities, syndicates, and profes-
sions elected indirectly under close regime control;
and 86% are appointed by regime or are ex officio
Communists: (est.) 50,000; sympathizers formerly
estimated at 20,000, probably have increased in
political activity since death of Franco; Communist
Party claims its newspaper has circulation of more
than 100,000
Other political or pressure groups: on the extreme
left, the illegal Basque Fatherland and Liberty (ETA)
and the Anti-Fascist and Patriotic Revolutionary
Front (FRAP) use terrorism to oppose the government;
on the extreme right, the Guerrillas of Christ the King
carry out vigilante attacks on ETA members and other
leftists; the state-controlled organization of syndi-
cates, comprising representatives of management and
labor, is to be reorganized to permit free labor unions;
among several illegal but increasingly tolerated labor
groups are the Communist-dominated Workers’
Commissions; the Catholic Church; business and land
owning interests; Opus Dei; Catholic Action;
university students
Member of: ASSIMER, ESRO, FAO, GATT,
IAEA, IBRD, ICAC, ICAO, IDA, IEA, IFC, IHO,
ILO, International Lead and Zinc Study Group,
IMCO, IMF, IO0C, IPU, ITC, ITU, IWCc—
International Wheat Council, OAS (observer),
OECD, U.N., UNESCO, UPU, WCL, WHO, WMO,
WSG','6880196a8e6697d824863a94eaa737068299e9f67f3dd7b067193f10735f2e27','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('832e4507e93c9ffc3c21c5b40f4334de087c4317efef1dc8a773b1f5ba0ae8b4',1977,'LK','Sri Lanka','government',482,'Legal name: Republic of Sri Lanka
Type: independent state since 1948
Capital: Colombo
Political subdivisions: 9 provinces, 22 administra-
tive districts, and four categories of semiautonomous
elected local governments
Legal system: a highly complex mixture of English
common law, Roman-Dutch, Muslim and customary
law; new constitution 22 May 1972; no judicial
review of legislative acts; legal education at Sri Lanka
Law College and University of Sri Lanka, Peradeniya;
has not accepted compulsory ICJ jurisdiction
Branches: unitary parliamentary form of govern-
ment; unicameral legislature and independent
judiciary
Government leader: Prime Minister Sirimavo
Bandaranaike
Suffrage: universal over age 18, but most Indian
Tamils, who comprise 10.6% of population, are not
enfranchised
Elections: national elections, ordinarily held every
6 years; must be held more frequently if government
loses confidence vote; last election held May 1970,
but new constitution postpones deadline for next
election until May 1977
Political parties and leaders: Sri Lanka Freedom
Party, Sirimavo Ratwatte Dias Bandaranaike,
President; Lanka Sama Samaja Party (Trotskyite),
N. M. Perera, President; Tamil United Front, S. J. V.
Chelvanayakam, leader; United National Party, J. R.
Jayewardene; Communist Party/Moscow, Pieter
Keuneman, General Secretary; Communist Party/
Peking, N. Shanmugathasan, General Secretary;
Mahajana Eksath Peramuna (People’s United Front),
M. B. Ratnayaka, President
Voting strength (1970 election): 37% Sri Lanka
Freedom Party, 38% United National Party, 9%
Lanka Sama Samaja Party, 3.5% Communist
Party/Moscow, 5% Federal Party, minor parties and
independents accounted for remainder
191
: CIA-RDP79-01051A000800010006-3
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
January 1977
SRI LANKA/SUDAN
Communists: approximately 169,000 voted for the
Communist Party in the May 1970 general election;
Communist Party/Moscow approximately 5,000
members (1975), Communist Party/Peking 1,000
members (1970 est.)
Other political or pressure groups: Buddhist
clergy, Sinhalese Buddhist lay groups; far-left violent
revolutionary groups; labor unions
Member of: ADB, ANRPC, Colombo Plan,
Commonwealth, FAO, IAEA, IBRD, ICAO, IDA,
IFC, ILO, IMCO, IMF, IPU, U.N., UNESCO, UPU,
WCL, WHO, WMO','94a920eda648db5647dc284594c96c24f65e35475a538b957d02b931fe58071e','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0bba5dee6b9986d95fe41dcef82f8778a675b321b585023c4845a0eb9973ac57',1977,'SD','Sudan','government',486,'Legal name: Democratic Republic of the Sudan
Type: republic under military control since coup in
May 1969
Capital: Khartoum
Political subdivisions: 18 provinces, provincial and
local administrations controlled by central govern-
ment; limited regional autonomy in 6 southern
provinces
Legal system: based on English common law and
Islamic law; some separate religious courts;
permanent constitution promulgated April 1973;
Revolutionary Command Council established in 1969
dissolved in October 1971 with the installation
stallation of Ja’ far al-Numayri as president and chief
executive; Numayri has reorganized government
through a series of Republican decrees; legal
education at University of Khartoum and Khartoum
extension of Cairo University at Khartoum, accepts
compulsory ICJ jurisdiction, with reservations
Government leader: President Ja’ far al-Numayri
Suffrage: universal adult
Elections: most recent parliamentary elections held
in April 1968; presidential plebescite held in
September 1971; elections to constituent assembly
held in September-October 1972; elections for
southern regional assembly held in November 1973;
elections for People’s Assembly held May 1974; next
scheduled presidential election is in October 1977
Political parties and leaders: all parliamentary
political parties outlawed since May 1969; the ban on
the Sudan Communist Party was not enforced until
after abortive coup in July 1971; the government''s
mass political organization, the Sudan Socialist
Union, was formed in January 1972
Communists: party decimated following July 1971
coup and counter-coup, several top leaders executed;
actual hard-core membership down to lowest point in
years; party control over labor unions, professional
groups and university student groups ended;
Communists purged from government; party is being
reorganized underground under leadership of
Secretary-General Muhammad Nujud, 3,500 CP
members
Other political or pressure groups: Muslim
Brotherhood; Ansar Muslim sect, at odds with the
military regime since the May coup, defeated in
fighting in spring 1970; Sudan Opposition Front,
composed of former political party elements and other
disgruntled conservative interests, operates in exile
Approved For Release 2005/04/22 :
Member of: AFDB, APC, Arab League, FAO,
IAEA, IBRD, ICAC, ICAO, IDA, IFC, ILO, IMF,
ITU, OAU, U.N., UNESCO, UPU, WFTU, WHO,
WMO
Legal name: Surinam
Type: Parliamentary Democracy
Capital: Paramaribo
Political subdivisions: 9 districts, each headed by
district commissioner responsible to Minister of
Internal Affairs
194
Legal system: Dutch civil law system; constitution
adopted November 1975
Branches: Council of Ministers headed by a
Prime Minister constitutes the Cabinet; 39-member
Parliament popularly elected for 4-year term; court
system administered by Attorney-General under
Minister of Justice and Police
Government leaders: President, Johan H. E,
Ferrier; Prime Minister, Henck A. E. Arron
Suffrage: universal over age 23
Elections: every 4 years or earlier upon request of
Prime Minister; latest held November 1978 won by
National. Party Combination (NPK), a creole-based
election coalition in which the National Party of
Surinam (NPS) is the largest party; new elections will
probably be held in 1977
Political parties and leaders: National Party of
Surinam (NPS), Henck A. E. Arron; Nationalist
Republic Party (PNR), Edward Bruma (principal
leftist party); United Hindustani Party (VHP), J.
Lachmon; Progressive National Party (PNP), Frank E.
Essed; Surinam Democratic Party (SDP), B. F. J.
Oostburg; United Indonesian People’s Party (SRI), F.
Karsowidijojo; Javanese Farmers’ Party (KTPI), H. I.
Soemita; United People’s Party (VVP), led by
apolitical or Chinese businessmen
Voting strength (1973); NPK 22 seats, Opposition
17; the NPK had a two-vote margin as of early
September 1976 following defection from both
coastlines
Communists: small Democratic Peoples Front
(DVF) headed by H. Keerveld; PNP has some
Communist sympathizers
Member of: EC (associate), ECLA, IBA, ILO,
ITU, U.N., UNESCO, UPU, WCL, WMO
Legal name: Kingdom of Swaziland
Type: monarchy, under King Sobhuza II;
independent member of Commonwealth since
September 1968
Capital: Mbabane (administrative), Lobamba
(royal and legislative)
Political subdivisions: 4 administrative districts
Legal system: based on South African Roman-
Dutch law in statutory courts, Swazi traditional law
and custom in traditional courts; legal education at
University of Botswana, Lesotho, and Swaziland
(located in Lesotho); has not accepted compulsory
ICJ jurisdiction
Branches: in April 1973 King abolished the
constitution, dismissed parliament, and assumed
personal rule; he has ruled under a King-in-Council
arrangement with the cabinet being retained as an
advisory council; a constitutional commission
submitted recommendations in June 1975, but King
has not authorized further action toward a new
constitution
Government leader: Head of State and govern-
ment King Sobhuza II; Prime Minister Maphevu
Diamini
Suffrage: universal for adults
Elections: first elections for Legislative Council
held in June 1964; latest for House of Assembly in
May 1972
Political parties and leaders: Imbokodvo, the
traditionalist party, controlled by King Sobhuza II;
the opposition Ngwane National Liberatory Congress
(NNLC), led by Dr. Ambrose Zwane, has been
dissolved
Voting strength: in 1972 elections, Imbokodvo won
21 seats, NNLC won 8 seats in the House of Assembly
Communists: no Communist Party
Member of: AFDB, FAO, GATT (de facto), IBRD,
ICAO, IDA, IFC, IMF, ISO, ITU, OAU, U.N., UPU','e78875dc54fea370b5d935281a4b46cad4ae0ccba1019625e8ab6bbebe158e43','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3c89664c6e14736e77863693e76919ed3b27aeb0c5a350579e2ed701305572aa',1977,'SE','Sweden','government',490,'Legal name: Kingdom of Sweden
Type: constitutional monarchy
Capital: Stockholm
Political subdivisions: 24 provinces, 624 com-
munes, 224 towns
Legal system: civil law system influenced by
customary law; Acts of 1809, 1810, 1866, and 1949
serve as constitution; legal education at Universities of
Lund, Stockholm, and Uppsala; accepts compulsory
ICJ jurisdiction, with reservations
Branches: legislative authority rests with parlia-
ment (Riksdag); executive power vested in cabinet,
responsible to parliament; Supreme Court, 6 superior
courts, 108 lower courts
Government leaders: King Carl XVI Gustaf; Prime
Minister Thorbjorn Falldin
Suffrage: universal, but not compulsory, over age
20
Elections: every 3 years (next in September 1979)
Political parties and leaders: Moderate Coalition
(conservative), Gosta Bohman; Center, Thorbjorn
Falldin; Liberal, Per Ahlmark; Social Democratic,
: CIA-RDP79-01051A000800010006-3
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
January 1977
SWEDEN/SWITZERLAND
Olof Palme; Left Party Communist, Lars Werner;
Swedish Communist Party, Gunnar Bylin; Com-
munist League of Marxist Leninists-Revolutionary
(KFML-R), Frank Baude
Voting strength (1976 election): 15.6% Moderate
Coalition, 24.1% Center, 11.0% Liberal, 42.9% Social
Democratic, 4.7% Communist, 1.7% other
Communists: 17,000; a number of sympathizers as
indicated by the 257,967 Communist votes cast in
1973 elections; an additional 17,274 votes cast for
Maoist KFML
Member of: ADB, Council of Europe, DAC, EC
(Free Trade Agreement), EFTA, ESRO, FAO, GATT,
IAEA, IBRD, ICAC, ICAO, IDA, IEA, IFC, IHO,
ILO, International Lead and Zinc Study Group,
IMCO, IMF, IPU, ISO, ITU, IWC—International
Whaling Commission, IWC—lInternational Wheat
Council, Nordic Council, OECD, U.N., UNESCO,
UPU, WHO, WMO, WSG','730a8b54baff1c2a8287a0150504f4f4813e7186a00265eafb4245d36ebc16a8','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2ab324edcd284ed9532a1f34a5a0e51be30af8d7df903839b78b6c099d13edf9',1977,'CH','Switzerland','government',493,'Legal name: Swiss Confederation
Type: federal republic
Capital: Bern
Political subdivisions: 22 cantons (3 divided into
half cantons); a local referendum held in Bern Canton
in 1975 indicated that three districts wished to form a
separate canton for a portion of the French-speaking
Jura region
Legal system: civil law system influenced by
customary law; constitution adopted 1874, amended
since; judicial review of legislative acts, except with
respect to Federal decrees of general obligatory
character; legal education at Universities of Bern,
Geneva and Lausanne, and four other university
schools of law; accepts compulsory ICJ jurisdiction,
with reservations
Branches: bicameral parliament has legislative
authority; federal council (Bundesrat) has executive
authority; justice left chiefly to cantons
Government leader: Rudolph Gnaegi (1-year term
as President began on January 1976), President
198
Suffrage: universal over age 20
Elections: held every 4 years; next elections 1979
Political parties and leaders: Social Democratic
Party (SPS), Arthur Schmid, president; Radical
Democratic Party (FDP), Henri Schmitt, president;
Christian Conservative People’s Party (CVP), Franz
Josef Kurmann, president; Swiss People’s Party (SVP),
Hans Conzett, president; Communist Party (PdA),
Jean Vincent, leading Secretariat member; National
Action Party (N.A.), James Schwarzenbach
Voting strength (1975 election): 22.2% FDP,
20.6% CVP, 25.4% SPS, 10.2% BGB, 2.2% PdA, 2.5%
N.A., 8.0% Rep, 6.2% LdU, 2.3% Lidus, 2.0% EvP,
1.3% POSH, 2.2% other
Communists: less than 60,000 votes in 1975
election
Other parties: Landesring (LdU); Republican
Movement (Rep); Liberal Democratic Union (Lidus);
Evangelical Party (EvP); Maoist Party (POSH /PSA)
Member of: ADB, Council of Europe, DAC,
EFTA, ELDO (observer), ESRO, FAO, GATT, IAEA,
ICAC, ICAO, IEA, ILO, IMCO, IPU, ITU, IWC—
International Wheat Council, OECD, U.N. (perma-
nent observer), UNESCO, UPU, WCL, WHO,
WMO, WSG
Legal name: Syrian Arab Republic
Type: republic; under left-wing military regime
since March 1963
Capital: Damascus
Political subdivisions: 18 provinces and city of
Damascus administered as separate unit
Legal system: based on Islamic law and civil law
system; special religious courts; constitution
promulgated in 1978; legal education at Damascus
University and University of Aleppo; has not accepted
compulsory ICJ jurisdiction
Branches: executive powers vested in President and
Council of Ministers; legislative power rests in the
People’s Assembly; seat of power is the Ba’th Party
Regional (Syrian) Command
Government leaders: President Hafiz Al-Asad
Suffrage: universal at age 18
Elections: no electoral laws being drafted; last
elections in December 1961; presidential referendum
in 1971; local councils elected in March 1972
Political parties and leaders: ruling party is the
Arab Socialist Resurrectionist (Ba’th) party; the
199
CIA-RDP79-01051A000800010006-3
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
January 1977
SYRIA/TANZANIA
“national front” cabinet is dominated by Ba’ thists,
but includes independents and members of the Syrian
Arab Socialist Party (ASP), Arab Socialist Union
(ASU), and Syrian Communist Party (SCP)
Communists: mostly sympathizers, numbering
about 5,000
Other political or pressure groups: non-Ba’th
parties have little effective political influence;
Communist Party ineffective; greatest threat to
Ba’thist regime lies in factionalism in Ba’th Party
itself; conservative religious leaders
Member of: Arab League, FAO, IAEA, IBRD,
ICAO, IDA, IFC, ILO, IMCO, IMF, IOOC, IPU,
ITU, IWC—International Wheat Council, OAPEC,
U.N., UNESCO, UPU, WFTU, WHO, WMO, WSG
Legal name: United Republic of Tanzania
Type: republic; single parties dominate both on the
mainland and on Zanzibar; government campaign to
unite two parties moving slowly
Capital: Dar es Salaam
Political subdivisions: 25 regions—20 on main-
land, 5 on Zanzibar islands
Legal system: based on English common law,
Islamic law, customary law, and German civil law
system; interim constitution adopted 1965; judicial
review of legislative acts limited to matters of
interpretation; legal education at University of Dar es
Salaam; has not accepted compulsory IC] jurisdiction
Branches: President Julius Nyerere has full
executive authority on the mainland; National
Assembly dominated by Nyerere and the Tanganyika
African National Union (TANU); newly restructured
National Assembly consists of 218 members, including
57 appointed from Zanzibar, 65 appointed from the
mainland, plus 96 directly elected from the mainland;
First Vice President Aboud Jumbe and the
Revolutionary Council still run Zanzibar despite the
efforts of Nyerere to integrate the islands into the
political system of the mainland
Government leader: President Julius Nyerere
Suffrage: universal adult
Political party and leaders: Tanganyika African
National Union (TANU), only mainland political
party, dominated by Nyerere with Prime Minister and
Second Vice President Rashidi Kawawa as his top
lieutenant; Afro-Shirazi Party, the only party in
Zanzibar
Voting strength (October 1975 national elec-
tions): over 5 million registered voters; Nyerere
received 95% of about 4 million votes cast; general
parliamentary elections scheduled for Fall of 1980
Communists: a few Communist sympathizers,
especially on Zanzibar
Member of: AFDB, Commonwealth, EAC, FAO,
GATT, IBRD, ICAC, ICAO, IDA, IFC, ILO, IMF,
ITU, OAU, U.N., UNESCO, UPU, WHO, WMO
Legal name: Kingdom of Thailand
Type: constitutional monarchy
Capital: Bangkok
Political subdivisions: 71 centrally controlled
provinces
Legal system: based on civil law system, with
influences of common law; new constitution
promulgated 7 October 1974; legal education at
Thammasat University; has not accepted compulsory
IC] jurisdiction
Branches: King is head of state with nominal
powers; Prime Minister heads an 18-man cabinet;
unicameral legislature appointed by King; military-
staffed Prime Minister''s office; judiciary relatively
independent except in important political subversive
cases
Government leaders: King Phumiphon Adundet;
Thanin Kraiwichian, Prime Minister; Chan Thrawichit,
Deputy Prime Minister for Civilian Affairs; Bunchai
Bamrung Phong, Deputy Prime Minister for Military
Affairs
Elections: suspended
Political parties: suspended
Communists: strength of illegal Communist Party
is about 1,000; Thai Communist insurgents
throughout Thailand total about 8,000
Member of: ADB, ANRPC, ASEAN, ASPAC,
Colombo Plan, ESCAP, FAO, IAEA, IBRD, ICAO,
IDA, IFC, IHO, ILO, IMF, IPU, ITC, ITU,
SEAMES, U.N., UNESCO, UPU, WCL, WHO,
WMO','8473f6651496dd5924edfdff49718d98cae53874028b639db48a9da1a977a4d2','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d2eec2113b1d81f98f6293bf78407aecc33a7f155fe8fd592d9761e305a1b1eb',1977,'TG','Togo','government',497,'Legal name: Togolese Republic
Type: republic; under military rule since January
1967
Capital: Lome
Political subdivisions: 21 circumscriptions
Legal system: based on French civil law and
customary practice; no constitution; has not accepted
compulsory ICJ jurisdiction
Branches: military government, with civilian-
dominated cabinet, took over on 14 April 1967,
replacing provisional government created after
January coup; no legislature; separate judiciary
including State Security Court established 1970
Government leader: General Gnassingbeé
Eyadéma, President, Minister of National Defense,
and Armed Forces Chief of Staff
Suffrage: universal adult
Elections: presidential referendum of January 1972
elected Gen. Eyadéma for indefinite period
Political parties: single party formed by President
Eyadéma in September 1969, Rassemblement du
203
CIA-RDP79-01051A000800010006-3
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
January 1977
TOGO/TONGA
Peuple Togolais, structure and staffing of party closely
controlled by government
Communists: no Communist Party; possibly some
sympathizers
Member of: AFDB, CEAO (observer), EAMA,
ECA, ECOWAS, ENTENTE, FAO, GATT, IBRD,
ICAO, IDA, IFC, ILO, IMF, ITU, OAU, OCAM,
U.N., UNESCO, UPU, WCL, WHO, WMO','ef6f1c61a7b308af6a974abef7bd527ce402ead4c831afd55bfcb534352be04c','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bb496c908b5eb0db3cccea1e480461cfdefc574b515db91877013d95bd897a08',1977,'TO','Tonga','government',501,'Legal name: Kingdom of Tonga
Type: constitutional monarchy
Capital: Nukualofa
Political subdivisions: 3 main island groups
(Tongatapu, Haapi, Vavau)
Legal system: based on English law
Branches: Executive (King and Privy Council);
Legislative (Legislative Assembly composed of 7
nobles elected by their peers, 7 elected representatives
of the people, 7 Ministers of the Crown; the King
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
January 1977
TONGA/TRINIDAD AND TOBAGO
appoints one of the 7 nobles to be the speaker);
Judiciary (Supreme Court, magistrate courts, Land
Court)
Government leaders: King Taufa’ahau Tupou IV;
Premier, Prince Tu ipelehake (younger brother of the
King)
Suffrage: granted to all literate adults over 21 years
of age who pay taxes
Elections: held perennially
Communists: none known
Member of: ADB, Commonwealth','00457d4a34005d35fed9092ee0e103ac1ea124a3eeb5544a682f9edf4ff35f12','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('20bb1ca81de868ec5a04ebd8516743fd104b36b2729cf0e24a0b7d6c0aadc722',1977,'TT','Trinidad and Tobago','government',505,'Legal name: Trinidad and Tobago
Type: independent state since August 1962;
in August country officially became a republic
severing legal ties with British crown
Capital: Port-of-Spain
Political subdivisions: 8 counties (29 wards,
Tobago is 30th)
Legal system: based on English common law;
constitution came into effect 1962; judicial review of
legislative acts in the Supreme Court; has not
accepted compulsory ICJ jurisdiction
Branches: legislative branch consists of 836-member
elected House of Representatives and 24-member
appointed Senate; executive is cabinet led by the
Prime Minister; judiciary is headed by the Chief
Justice and includes a Court of Appeal, High Court,
and lower courts
Government leader: Prime Minister, Dr. Eric
Williams
Suffrage: universal over age 21; to be lowered to 18
under new constitution
Elections: elections to be held at intervals of not
more than five years; last election held 13 September
1976
205
: CIA-RDP79-01051A000800010006-3
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
January 1977
TRINIDAD AND TOBAGO/TUNISIA
Political parties and leaders: People’s National
Movement (PNM), Dr. Eric Williams: United Labor
Front (ULF), Baseo Panday; Democratic Labor Party
(DLP), Vernon Jamadar; Democratic Action Congress
(DAC), Arthur Napoleon Raymond Robinson; West
Indian National Party (WINP), Ashford Sinanani;
Tapia House Group, Lloyd Best
Voting strength (1976 election): 56% of registered
voters cast ballots; PNM captured 24 seats in House of
Representatives, ULF 10, and DAC the two Tobago
seats
Communists: not significant
Other political pressure groups: National Youth
Congress (NYC); Oilfield Workers Trade Union
(OWTU); National Joint Action Committee (NJAC),
antigovernment, ex-tremist organization; United
Revolutionary Organization (URO), Marxist-led
amalgam; United Labour Front (ULF), loose
coalition of oilfield and sugar workers
Member of: CARICOM, Commonwealth, FAO,
GATT, IADB, IBRD, International Coffee Agree-
ment, ICAO, IDA, IDB, IFC, ILO, IMCO, IMF,
ISO, ITU, I[WC—International Wheat Council, OAS,
SELA, U.N., UNESCO, UPU, WHO, WMO','8c1b52da2c9c3e31bec7fa2ce0073f75fa99331c015ebff31ca1057fc1b7a176','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a091f802fddd0e9da0d09da56b61e1a6e25d8354613d81a120997fdca867f873',1977,'TN','Tunisia','government',509,'Legal name: Republic of Tunisia
Type: republic
Capital: Tunis
Political subdivisions: 17 governorates (provinces)
Legal system: based on French civil law system
and Islamic law; constitution patterned on Turkish
and U.S. constitutions adopted 1959; some judicial
review of legislative acts in the Supreme Court in joint
session; legal education at Institute of Higher Studies
and Ecole Superieure de Droit of the University of
Tunis; has not accepted compulsory ICJ jurisdiction
Branches: executive dominant; unicameral
legislative largely advisory; judicial, patterned on
French system and Koranic law
Government leader: President Habib Bourguiba;
Prime Minister Hedi Nouira
Suffrage: universal over age 21
Elections: national elections held every 5 years; last
elections 2 November 1974
Political party and leader: Destourian Socialist
Party, Habib Bourguiba
Voting strength (1974 election): 100% Destourian
Socialist Party
Communists: 1,000 (1960''s est.); Tunisian
Communist Party proscribed in January 1963
Member of: AFDB, Arab League, AIOEC, EC
(association until 1974), FAO, IAEA, IBRD, ICAO,
IDA, IFC, ILO, International Lead and Zinc Study
Group, IMCO, IMF, IOOC, ITU, [WC—Interna-
tional Wheat Council, OAU, U.N., UNESCO, UPU,
WHO, WMO
Legal name: Republic of Turkey
Type: republic
Capital: Ankara
Political subdivisions: 67 provinces
Legal system: derived from various continental
legal systems; constitution adopted 1961; judicial
review of legislative acts by Constitutional Court;
legal education at Universities of Ankara and
Istanbul; accepts compulsory ICJ jurisdiction, with
reservations
Branches: President elected by parliament; Prime
Minister appointed by President from members of
parliament; Prime Minister is effective executive;
cabinet, selected by Prime Minister and approved by
President, must command majority support in lower
house; parliament bicameral under constitution
promulgated in 1961; National Assembly has 450
members serving 4 years; Senate has 150 elected
members, one-third elected every 2 years, 15
appointed by the President to 6-year terms (one-third
appointed every. 2 years), and 18 life members; highest
court for ordinary criminal and civil cases is Court of
Cassation, which hears appeals directly from criminal,
commercial, basic, and peace courts
Government leaders: President Fahri Koruturk;
Prime Minister Suleyman Demirel heads four-party
coalition government
Suffrage: universal over age 21
Elections: National Assembly and Senate (1/3 of
seats), Republican People’s Party won a_ plurality
October 1973, new elections must be held by October
1977; Presidential (1980)
Political parties and leaders: Justice Party (JP),
Suleyman Demirel; Republican People’s Party (RPP),
Bulent Ecevit; Nationalist Salvation Party (NSP),
Necmettin Erbakan; Democratic Party (DP), Ferruh
Bozbeyli; Republican Reliance Party (RRP), Turhan
Feyzioglu; Natlionalist Action Party (NAP), Alpaslan
Turkes; Unity Party (UP), Mustafa Timisi;
Communist Party illegal
Communists: strength and support negligible
Other political or pressure groups: military forced
resignation of Demirel government in March 1971
and remains an influential force in government
Member of: ASSIMER, CENTO, Council of
Europe, EC (associate member), ECOSOC, FAO,
GATT, IAEA, IBRD, ICAC, ICAO, IDA, IEA, IFC,
IHO, ILO, IMCO, IMF, IOOC, IPU, ITU, NATO,
OECD, Regional Cooperation for Development,
U.N., UNESCO, UPU, WHO, WMO, WSG','73fb1acfc945a9036221976131aebe1e93650f2e30298583f51c7d845c847475','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('90ec142094bc936ec9b0fd03c37c2e0cc1d7b379a2daf895cb040f8b46dfe67c',1977,'TV','Tuvalu','government',513,'Legal name: Tuvalu
Type: British crown colony with a large measure of
self-government
Capital: Funafuti
House of Assembly: eight members
Chief minister: Toalipi Lauti
Her Majesty’s Commissioner (Governor):
Thomas Layng','96ed6918a3203ced75d8235589bd7bbd7c2c60840c42e5f4437672de3a15c78a','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d0fbcd8c6f7198d1f640d0ee45a9852481d8c95bec20ab3bc8b3d3f2d2df91a6',1977,'UG','Uganda','government',516,'Legal name: Republic of Uganda
Type: republic independent since October 1962
Capital: Kampala
Political subdivisions: 10 provinces and 34 districts
Legal system: based on English common law and
customary law; constitution adopted 1967; present
government rules despotically, has intimidated
judicial officials and has made constitution of no
consequence; legal education at Makerere University,
Kampala; accepts compulsory IC] jurisdiction, with
reservations
Branches: Field Marshall Amin rules by decree;
assisted by Council of Ministers and Defense Council,
a group of military officers
Government leader: Field Marshall Idi Amin,
President for life
Suffrage: universal adult
Elections: none scheduled by military government
Political parties: none
Communists: possibly a few sympathizers
Member of: AFDB, Commonwealth, EAC, FAO,
GATT, IAEA, IBRD, ICAC, ICAO, IDA, IFC, ILO,
210
IME, ISO, ITU, OAU, U.N., UNESCO, UPU, WHO,
WMO
Legal name: Union of Soviet Socialist Republics
Type: Communist state
Capital: Moscow
Political subdivisions: 15 union republics, 20
autonomous republics, 6 krays, 120 oblasts, and 8
autonomous oblasts
Legal system: civil law system as modified by
Communist legal theory; constitution adopted 1936;
no judicial review of legislative acts; legal education
at 18 universities and 4 law institutes; has not
accepted compulsory IC] jurisdiction
Branches: Council of Ministers (executive),
Supreme Soviet (legislative), Supreme Court of
U.S.S.R. (judicial)
Government leaders: Leonid I. Brezhnev, General
Secretary of the Central Committee of the Communist
Party; Aleksey N. Kosygin, Chairman of the Council
of Ministers; Nikolay V. Podgornyy, Chairman of the
Presidium of the U.S.S.R. Supreme Soviet
Suffrage: universal over age 18; direct, equal
Elections: to Supreme Soviet every 4 years; 1,517
deputies elected in 1974; 72.2% party members
Political parties and leaders: Communist Party of
the Soviet Union (CPSU) only party permitted
Voting strength (1974 election): 153,237,112
persons over 18; allegedly 99.98% voted
Communists: 15,694,000 party members
Other political or pressure groups: Komsomol,
trade unions, and other organizations which facilitate
Communist control
Member of: CEMA, Geneva Disarmament
Conference, IAEA, ICAC, ICAO, ILO, International
Lead and Zinc Study Group, IMCO, IPU, ISO, ITC,
ITU, IWC—lInternational Whaling Commission,
IWC—International Wheat Council, U.N., UNES-
CO, UPU, Warsaw Pact, WFTU, WHO, WMO,
Universal Copyright Convention','639e056ad7f2f3d0ed96b57dec923dea72554ce61f61ab742cb398d3514c3071','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8b688bfbe34fb891b26ecd9da83abde26dd1d7ef1bbd1076a99a8b11ad9e1dcc',1977,'AE','United Arab Emirates','government',519,'Legal name: United Arab Emirates (composed of
former Trucial States)
Member states: Abu Dhabi; Ajman; Dubai;
Fujairah; Ras al Khaimah; Sharjah; Umm al Qaiwain
Type: federation; constitution signed December
1971, which delegated specified powers to the United
Arab Emirates central government and reserved other
powers to member sheikhdoms
Capital: Abu Dhabi
Legal system: secular codes are being introduced
by the U.A.E. government and in several member
sheikhdoms; Islamic law remains very influential
Branches: Supreme Council of Rulers (7 members),
from which a President and Vice President are elected;
Prime Minister and Council of Ministers; National
Consultative Council; federal Supreme Court
Government leaders: Sheikh Zayid of Abu Dhabi,
President; Sheikh Rashid of Dubai, Vice President;
Sheikh Maktum of Dubai, Prime Minister
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
aan
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
January 1977
UNITED ARAB EMIRATES/UNITED KINGDOM
Suffrage: none
Elections: none
Political or pressure groups: none; a few small
clandestine groups are active
Member of: Arab League, IBRD, ICAO, ILO,
IMF, OAPEC, OPEC, U.N., UNESCO, UPU, WHO','1da66fe8f654b88d45b2aa362ec885da63dfda05d6ac2ac309bb97b4e09729a5','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('66eaabc4a1cbd16e9ccfde34c6937cdd0392ccacb00a13d3686c906be8145c79',1977,'GB','United Kingdom','government',523,'Legal name: United Kingdom of Great Britain and
Northern Ireland
Type: constitutional monarchy
Capital: London
Political subdivisions: 635 parliamentary constitu-
encies
213
: CIA-RDP79-01051A000800010006-3
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
January 1977
Legal system: common law tradition with early
Roman and modern continental influences; no
judicial review of Acts of Parliament; accepts
compulsory ICJ jurisdiction, with reservations
Branches: legislative authority resides in Parlia-
ment; executive authority lies with collectively
responsible cabinet led by Prime Minister; House of
Lords is supreme judicial authority and highest court
of appeal .
Government leader: Prime Minister James
Callaghan
Suffrage: universal over age 18
Elections: at discretion of Prime Minister, but must
be held before expiration of a 5-year electoral
mandate; last election 10 October 1974
Political parties and leaders: Conservative,
Margaret Thatcher; Labor, James Callaghan;
Liberal, David Steel; Communist, Gordan Mc-
Lennan; Scottish National, William Wolfe
Voting strength (1974 election); Conservative 277
seats (35.9%): Labor 319 seats (39.3%); Liberal 13
seats (18.3%); Scottish National 11 seats (2.8%); Plaid
Cymru 8 seats (0.6%); other 12 seats (3.2%)
Communists: 29,000
Other political or pressure groups: Trades Union
Congress, Confederation of British Industry, National
Farmers’ Union
Member of: ADB, CENTO, Colombo Plan,
Council of Europe, DAC, EC, EEC, ELDO, ESRO,
EURATOM, FAO, GATT, IAEA, IBRD, ICAC,
ICAO, IDA, IEA, IFC, IHO, ILO, International
Lead and Zinc Study Group, IMCO, IMF, IOOC,
IPU, ISO, ITC, ITU, IWC—International Whaling
Commission, IWC—International Wheat Council,
NATO, OECD, UN., UNESCO, UPU, WEU, WHO,
WMO, WSG
Legal name: Republic of Upper Volta
Type: republic; military regime in power since
January 1966
Capital: Ouagadougou
Political subdivisions: 10 departments, composed
of 44 cercles, headed by civilian prefects
Legal system: based on French civil law system
and customary law; constitution adopted 1970,
suspended February 1974; a special commission to
draft a new constitution was appointed in May 1976;
Approved For Release 2005/04/22
judicial review of legislative acts in Supreme Court,
has not accepted compulsory ICJ jurisdiction
Branches: President is an army officer; 57-man
National Assembly was elected in December 1970,
suspended February 1974
Government leader: Gen. Sangoule Lamizana,
President and Prime Minister
Suffrage: universal for adults
Elections: all political activity has been banned
Political parties and leaders: political parties
banned February 1974
Communists: no Communist party; some sympa-
thizers
Other political or pressure groups: labor
organizations are badly splintered, students and
teachers occasionally strike
Member of: AFDB, CEAO, EAMA, ECA, EIB
(associate), Entente, FAO, IBRD, ICAO, IDA, ILO,
IMF, IPU, ITU, Niger River Commission, OAU,
OCAM, U.N., UNESCO, UPU, WCL, WHO, WMO','4d8c4cf2eafb7d646951cb37f8c0665495934805723d48e0aed90b787ba89afc','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7e7797047bd55607dcee800ffb0d41cf9520687c6227e2417240923cdc479727',1977,'UY','Uruguay','government',527,'Legal name: Oriental Republic of Uruguay
Type: republic, government under strong military
influence
Capital: Montevideo
Political subdivisions: 19 departments with limited
autonomy
Legal system: based on Spanish civil law system;
new constitution implemented 1967; judicial review
of legislative acts in Supreme Court, legal education
at University of the Republic at Montevideo; accepts
compulsory ICJ jurisdiction
Branches: executive, headed by President; since
1973 the military has had considerable influence in
policymaking; bicameral legislature (closed
indefinitely by presidential decree in June 1973),
Council of State set up to act as legislature; national
judiciary headed by Supreme Court
Government leader: President Aparecio Mendez
Suffrage: universal over age 18
Elections: projected for 1980
Political parties and leaders: political activities are
proscribed
Voting strength (1971 elections): 40.8% Colorado,
40.1% Blanco, 18.6% Frente Amplio, 0.5% Radical
Christian Union
Communists: 35,000-40,000 including Communist
youth group and sympathizers
Other political or pressure groups: Communist
Party (PCU), Rodney Arismendi (in exile in the
U.S.S.R.); Christian Democratic Party (PDC);
Socialist Party of Uruguay (PSU); Revolutionary
Movement of Uruguay (MRO) pro-Cuban Commu-
nist Party; National Liberation Movement (MLN-
Tupamaros) Marxist revolutionary terrorist group
Member of: FAO, GATT, IADB, IAEA, IBRD,
ICAO, IDB, IFC, ILO, IMCO, IMF, ITU, LAFTA,
OAS, SELA, U.N., UNESCO, UPU, WCL, WFTU,
WHO, WMO, WSG
Legal name: State of the Vatican City
Type: monarchical-sacerdotal state
Capital: Vatican City
Political subdivisions: Vatican City includes St.
Peter''s, the Vatican Palace and Museum and
neighboring buildings covering more than 18 acres; 13
buildings in Rome, although outside the boundaries,
enjoy extraterritorial rights
Legal system: Canon law; constitutional laws of
1929 serve some of the functions of a constitution
Branches: the Pope possesses full executive,
legislative, and judicial powers; he delegates these
powers to the governor of Vatican City, who is subject
to pontifical appointment and recall; high Vatican
offices include the Secretariat of State, the College of
Cardinals (chief papal advisers), the Roman Curia
(which carries on the central administration of the
Roman Catholic Church) the Presidence of the
Prefecture for the Economy, and the synod of bishops
(created in 1965)
217
CIA-RDP79-01051A000800010006-3
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
January 1977
VATICAN CITY/VENEZUELA
Government leader: Supreme Pontiff, Paul VI,
(Giovanni Battista Montini, born 26 September 1897,
elected Pope 21 June 1963)
Suffrage: limited to cardinals less than 80 in age
Elections: Supreme Pontiff elected for life by
College of Cardinals
Communists: none known
Other political or pressure groups: none (exclusive
of influence exercised by other church officers in
universal Roman Catholic Church)
Member: IAEA, IWC—International Wheat
Council
Legal name: Republic of Venezuela
Type: republic
Capital: Caracas
Political subdivisions: 20 states, | federal district, 2
federal territories
Legal system: based on Spanish civil law system
with influence of U.S. law; constitution promulgated
1961; judicial review of legislative acts in Cassation
Court only; dual court system, state and federal; legal
education at Central University of Venezuela; has not
accepted compulsory IC] jurisdiction
Branches: executive (President), bicameral
legislature, judiciary
Government leader: President Carlos Andres Perez
Suffrage: universal and compulsory over age 18
Elections: every 5 years; last held 9 December 1973
Political parties and leaders: Accion Democratica
(AD), Carlos Andres Perez, and Gonzalo Barrios;
Social Christian Party (COPE]), Rafael Caldera and
Herrera Campins; People’s Electoral Movement
(MEP), Jesus Angel Paz Galarraga; Union Repub-
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
sel ce an
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
January 1977
VENEZUELA/ VIETNAM
licana Democratica (URD), Jovito Villalba; Partido
Comunista de Venezuela (PCV), Secretary-General
Jesus Faria; Movement to Socialism (MAS), Teodoro
Petkoff, and Pompey Marquez
Voting strength (1973 election): 49% AD, 37%
COPEI, 5% New Force (MEP & PCV), 4% MAS, 3%
URD, 2% others
Communists: 4,000-6,000 members (est.)
Other political or pressure groups: Fedecamaras
(a conservative business group); PRO VENEZUELA
(leftist, nationalist economic group); DESARROL-
LISTAS (group of wealthy, independent businessmen
led by former finance minister Pedro Tinoco and
historian Guillermo Moron)
Member of: Andean Pact, AIOEC, FAO, IADB,
IAEA, IBRD, ICAO, IDB, IFC, 1HO, ILO, IMF,
IPU, ITU, IWC—lInternational Wheat Council,
LAFTA, NAMUCAR (Caribbean Multinational
Shipping Line—Naviera Multinacional del Caribe),
OAS, OPEC, SELA, U.N., UNESCO, UPU, WCL,
WFETU, WHO, WMO
Legal name: Socialist Republic of Vietnam
Type: Communist state
Capital: Hanoi
Political subdivisions: 38 provinces
Legal system: based on Communist legal theory
and French civil law system; constitution enacted
1960
Branches: constitution provides for a National
Assembly and highly centralized executive nominally
subordinate to it
Party and government leaders: Ton Duc Thang,
President of DRV; Le Duan, First Secretary; Truong
Chinh, Chairman, Standing Committee of National
Assembly; Pham Van Dong, Premier; Vo Nguyen
Giap, Minister of National Defense; Nguyen Duy
Trinh, Minister for Foreign Affairs
Suffrage: over age 18
Elections: pro forma elections held for national and
local assemblies; lastest election for National
Assembly held on April 25, 1976
Political parties: ruled by Lao Dong Party
(Communist) with membership of approximately
900,000; minor subordinate parties
Member of: WHO
FONOMY
GNP: $4.6 billion (1975), approximately $100 per
capita; growth stagnant in recent years, but could
reach a moderate 5% in 1976
Agriculture: main crops—rice, rubber, fruits and
vegetables, mainly in the south; some corn, manioc,
220
Approved For Release 2005/04/22
and sugarcane; major food imports—wheat, dairy
products
Fishing: catch 728,000 metric tons (1974); dropped
in 1975 but should recover to near 1974 levels in 1976
Major industries: food processing, textiles,
machine building, mining, cement, chemical
fertilizer, glass, tires
Shortages: petroleum, capital goods and machin-
ery, fertilizer
Major trade partners: exports—Japan, Hong
Kong, Singapore, Franch; imports—U.S., Japan,
France to April 1975; thereafter most trade with
Communist countries, primarily U.S.S.R. and China
Monetary conversion rate (nominal): 2.9
dong = US$1 (March 1976)
Fiscal year: calendar year','e2a9da838f6c9a67dac271016eaea9b6fa34237ae9a04ca19111d6220ef2e005','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f4a45eb341519015cc7ba78e4b92f9b10a82ff16d31f8fff3e46f0d9a225a112',1977,'WF','Wallis and Futuna','government',531,'Legal name: Territory of the Wallis and Futuna
Islands
Type: overseas territory of France
Capital: Matu Utu
Political subdivisions: 3 districts
Branches: territorial assembly of 20 members;
popular election of one deputy to National Assembly
in Paris, and one Senator
Government leader: Superior Administrator
Jacques de Agostini
Suffrage: universal adult
Elections: every 5 years','05a6a7f83a72eba0d2ff6e86c56c98963d4432800888c252d89e889c9dd9af60','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3a5fb31cb1e5c1057f46c0ad1e55225f4b025624f1352b25e04fd7c393678c28',1977,'EH','Western Sahara','government',535,'Type: legal status of territory unresolved; territory
partitioned between Morocco and Mauritania; the
legal question of sovereignty over the area has yet to
be determined; both countries have established
political administration within their own zones of
influence; the line of partition begins at a point on the
coast where the Atlantic Ocean intersects the 24th
parallel, and extends in a southeasterly direction until
it intersects the 18th meridian
Legal name: The Independent State of Western','dfd8bcf78c7b4376446ba642a13890a2a5fc8da15f456aa74a09ceb5e49be108','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8b0f5031b6126f287f36c28c3ab8f295afa8b02e66fdc1165ae7eb92021cb1bf',1977,'WS','Samoa','government',537,'Type: constitutional monarchy under native chief;
special treaty relationship with New Zealand
Capital: Apia
Legal system: based on English common law and
local customs; constitution came into effect upon
independence in 1962; judicial review of legislative
acts with respect to fundamental rights of the citizen;
has not accepted compulsory ICJ jurisdiction
Branches: Head of State and Executive Council;
Legislative Assembly; Supreme Court, Court of
Appeal, Land and Titles Court, village courts
Government leaders: Head of State, Malietoa
Tanumafili II; Prime Minister, Tupuola Efi
Suffrage: 45 Samoan members of Legislative
Assembly are elected by holders of matai (heads of
family) titles (about 5,000); 2 European members are
elected by universal adult suffrage
Elections: held triennially, last in February 1976
Political parties and leaders: no clearly defined
political party structure
Communists: unknown
Member of: ADB, Commonwealth, ESCAP, IBRD,
IFC, IMF, WHO','cadd09ca148815f4889338898e0531b898904044c36ef99d79995ff89f605161','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a6b176d716e507eb1325f4b5f30800d28b1fd2c3f133a1486d0de9fd1c40351d',1977,'YE','Yemen','government',539,'Type: republic; power centered in ruling National
Front Party
Capital: Aden; Madinat ash Sha’b, administrative
capital
Political subdivisions: 6 provinces
Legal system: based on Islamic law (for personal
matters) and English common law (for commercial
matters); highest judicial organ, Federal High Court,
interprets constitution and determines disputes
between states
Branches: Presidential Council; cabinet; Supreme
People’s Council
Government leaders: Chairman of Presidential
Council, Salim Rubayyi Ali; Prime Minister Ali Nasir
Muhammed al-Hasani; NF Secretary General Abd
Al-Fattah Ismail
Suffrage: granted by constitution to all citizens 18
and over
Elections: elections for legislative body, Supreme
People’s Council, called for in constitution; none have
been held
Political parties and leaders: National Front
(NF), only legal party
Communists: few known
Member of: FAO, GATT (de facto), IBRD, ICAO,
IDA, ILO, IMF, ITU, U.N., UNESCO, UPU,
WFTU, WHO, WMO
Legal name: Yemen Arab Republic
Type: republic; military regime assumed power in
June 1974
Capital: Sana
Political subdivisions: 8 provinces
Legal system: based on Turkish law, Islamic law,
and local customary law; first constitution
promulgated December 1970, suspended June 1974:
has not accepted compulsory ICJ jurisdiction
Branches: Military Command Council, Prime
Minister, cabinet
Government leaders: Head of Military Command
Council, Col. Ibrahim Hamdi; Prime Minister
Abd al-Ghani
Communists: few known
Political parties or pressure groups: Yemeni
Union, a small inactive government party formed in
February 1978; some pro-Iraqi Baathists, other small
clandestine groups supported by Yemen (Aden)
Member of: Arab League, FAO, IBRD, ICAO,
IDA, IFC, ILO, IMF, ITU, U.N., UNESCO, UPU,
WFTU, WHO, WMO
Legal name: Socialist Federal Republic of
Yugoslavia
Type: Communist state, federal republic in form
Capital: Belgrade
Political subdivisions: 6 republics with 2
autonomous provinces (within the Republic of Serbia)
Legal system: mixture of civil law system and
Communist legal theory; constitution adopted 1974;
legal education at several law schools; has not
accepted compulsory ICJ jurisdiction
Branches: parliament (Federal Assembly) constitu-
tionally supreme; executive includes cabinet (Federal
Executive Council) and the federal administration;
independent judiciary; the State Presidency is a
collective policymaking body composed of a
representative from each republic and province, Tito
presides as President of the Republic
Government leader: Josip Broz Tito, President of
Republic and President of League of Communists of
Yugoslavia
Suffrage: universal over age 18
Elections: Federal Assembly elected every 4 years
by a complicated, indirect system of voting
Political parties and leaders: League of
Communists of Yugoslavia (LCY) only; leaders are
President Tito and influential presidium members
Edvard Kardelj, Vladimir Bakaric, and Stane Dolanc
Voting strength: voter participation in national
elections has declined, as follows—19638, 95.5%; 1965,
98.6%; 1967, 89%; 1969, 88%; 1974, no data
available
Communists: 1,119,000 party members (January
1975)
225
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
Approved For Release 2005/04/22 : CIA-RDP79-01051A000800010006-3
January 1977
YUGOSLAVIA/ZAIRE
Other political or pressure groups: Socialist
Alliance of Working People of Yugoslavia (SAWPY),
the major mass front organization for the LCY;
Confederation of Trade Unions of Yugoslavia
(CTUY), Union of Youth of Yugoslavia (UYY),
Federation of Yugoslav War Veterans (SUBNOR)
Member of: ASSIMER, CEMA (observer but
participates in certain commissions), EC (5-year non-
preferential trade agreement signed in May 1978),
FAO, GATT, IAEA, IBA, IBRD, ICAC, ICAO, IDA,
IFC, IHO, ILO, International Lead and Zinc Study
Group, IMCO, IMF, IPU, ITC, ITU, OECD
(participant in some activities), U.N., UNESCO,
UPU, WHO, WMO
Legal name: Republic of Zaire (until October 1971
known as Democratic Republic of the Congo)
Type: republic; constitution establishes strong
presidential system
Capital: Kinshasa
Political subdivisions: 8 regions and federal district
of Kinshasa
Legal system: based on Belgian civil law system
and tribal law; new constitution promulgated 1967,
revised 1974; legal education at National University
of Zaire; has not accepted compulsory IC] jurisdiction
Branches: president elected 1970 for seven-year
term limited to two five-year terms, thereafter;
National Legislative Council of 210 members elected
for five-year term; the official party is the supreme
political institution
Government leaders: Lt. Gen. Mobutu Sese Seko,
President
Suffrage: universal and compulsory over age 18
Elections: presidential and legislative elections in
October and November 1970
Political parties and leaders: Mouvement
Populaire de la Revolution (MPR), only legal party,
organized from above with actual grassroots
popularity not clearly definable
Voting strength: MPR slate polled 96.3% of vote in
1970 elections
Communists: no Communist Party; U.S.S.R. and
People’s Peoples Republic of China have diplomatic
missions in Zaire
Member of: AFDB, APC, CIPEC, EAMA, EIB
(associate), FAO, GATT, IAEA, IBRD, ICAO, IDA,
IFC, IHO, ILO, IMF, IPU, ITC, ITU, OAU, OCAM,
UDEAC, U.N., UNESCO, UPU, WFTU, WHO,
WMO','dc5e36db15a4efc9cbf49158e925f263b2879aff6818902989fe23d7629ba27f','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9cdc46f17381e401a8fec26c6263e55b67337fa744b818b7303dd216528053d2',1977,'ZM','Zambia','government',545,'Legal name: Republic of Zambia
Type: republic since October 1964
Capital: Lusaka
Political subdivisions: 9 provinces
Legal system: based on English common law and
customary law; new constitution adopted September
1978; judicial review of legislative acts in an ad hoc
constitutional council; legal education at University
of Zambia in Lusaka; has not accepted compulsory
IC] jurisdiction
Branches: modified presidential system; unicam-
eral legislature; judiciary
228
Government leader: President Kenneth Kaunda;
Prime Minister Elijah Mudenda
Suffrage: universal adult
Elections: last general election December 1973
Political parties and leaders: United National
Independence Party (UNIP), Kenneth Kaunda;
former opposition party banned in December 1972
when 1 party state proclaimed
Voting strength (1973 election): in first
presidential and parliamentary elections under single-
party system, 43% of eligible voters went to polls;
Kaunda was only candidate for President; National
Assembly seats were contested by members of UNIP
Communists: no Communist Party, but sympa-
thizers of socialism in upper levels of government,
UNIP, and labor unions
Member of: AFDB, Commonwealth, FAO, GATT
(de facto), IAEA, IBRD, ICAO, IDA, IDB, IEA, IFC,
ILO, International Lead and Zinc Study Group, IMF,
IPU, ITU, OAU, U.N., UNESCO, UPU, WHO,
WMO','d715a978f874c73372381c74f07e75b25bd52dfc93618e4e7261583dc445312a','internet-archive','cia-readingroom-document-cia-rdp79-01051a000800010006-3','txt','948d8a4825a26c1800aee017f92e123c7b090b9765f1ba480d8263ff9ddbdae5','https://archive.org/download/cia-readingroom-document-cia-rdp79-01051a000800010006-3/cia-rdp79-01051a000800010006-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);

SET NAMES utf8mb4;
CREATE TABLE IF NOT EXISTS worldfactbook_chunks (
  chunk_id CHAR(64) NOT NULL,
  edition_year SMALLINT UNSIGNED NOT NULL,
  entity_code VARCHAR(24) NOT NULL DEFAULT '',
  entity_name VARCHAR(160) NOT NULL DEFAULT '',
  category VARCHAR(96) NOT NULL,
  ordinal INT UNSIGNED NOT NULL,
  content MEDIUMTEXT NOT NULL,
  content_sha256 CHAR(64) NOT NULL,
  source_provider VARCHAR(64) NOT NULL,
  source_identifier VARCHAR(255) NOT NULL,
  source_format VARCHAR(32) NOT NULL,
  source_sha256 CHAR(64) NOT NULL,
  source_url TEXT NOT NULL,
  extractor VARCHAR(64) NOT NULL,
  PRIMARY KEY (chunk_id),
  KEY idx_wfb_year_category (edition_year, category),
  KEY idx_wfb_entity_year (entity_code, edition_year),
  KEY idx_wfb_source_sha (source_sha256)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fd7f87638abb61660e1fcfc357b351bfa8985cdf32e75b908f26bea31f59cf9d',2025,'ZW','Zimbabwe','transnational-issues',21,'Disputes—international
Refugees and internally displaced
persons `
refugees
IDPs
Trafficking in persons
current situation
tier rating
Illicit drugs
Disputes—international: in 2004, Zimbabwe
dropped objections to plans between Botswana
and Zambia to build a, bridge over the Zambezi
_ River, thereby de facto recognizing a short, but not
clearly delimited, Botswana-Zambia boundary in
the river
Refugees and internally displaced persons:
refugees (country of origin): 23,500 (Angola);
5,559 (Rwanda) (2011); 9,835
Republic of the Congo) (2012)
Illicit drugs: transshipment point for moder-
ate amounts of methaqualone, small amounts of
heroin, and cocaine bound for southern Africa
and possibly Europe; a poorly developed financial
infrastructure coupled with a government commit-
ment to combating money laundering make it an
unattractive venue for money launderers; major
(Democratic
consumer of cannabis
| ZIMBABWE
HARA
ii Chqungwral
. invangare $
F,
Mutareg~
Suaway fagwengo 4
r 4
i į
sorswawe N. 3
Tn
™ AAD eg 8
A
a,
owen:
Pa
£
Disputes—international: Namibia has sup-
ported, and in 2004 Zimbabwe dropped objections
to, plans between Botswana and Zambia to build
a bridge over the Zambezi River, thereby de facto
recognizing a short, but not clearly delimited, Bot-
swana-Zambia boundary in the river; South Africa
has placed military units to assist police opera-
tions along the border of Lesotho, Zimbabwe, and
Mozambique to control smuggling, poaching, and
illegal migration
Refugees and internally displaced persons:
IDPs: undetermined (political violence, human
rights violations, land reform, and economic col-
lapse) (2012)
Trafficking in persons: current situation:
Zimbabwe is a source, transit, and destination
country for men, women, and children traf-
fickéd for the purposes of forced labor and sexual
exploitation; some victims of forced prostitution
are subsequently transported across the border
to South Africa where they suffer continued
exploitation; Zimbabwean men, women, and
children are subjected to forced labor in agricul-
ture and domestic service in rural areas, as well
as domestic servitude and sex trafficking in cities
and towns; children are also utilized in the com-
mission of illegal activities, including gambling
and drug smuggling
tier rating: Tier 3—the Government of Zimbabwe
does not fully comply with the minimum standards
for the elimination of trafficking and is not mak-
ing significant efforts to do so; the government did
not report investigations, prosecutions, or convic-
tions of trafficking cases and continued to rely
on an international organization to provide law
enforcement training, coordinate victim care and
repatriation, and te lead prevention efforts (2009)
lliicit drugs: transit point for cannabis and South
Asian heroin, mandrax, and methamphetamines
en route to South Africa
821
APPENDIX A
ABBREVIATIONS
ABEDA l -Arab Bank for Economic Development in Africa
ACP Group f African, Caribbean, and Pacific Group of States
ADB l ‘Asian Development Bank
AfDB African Development Bank
AFESD ; - Arab Fund for Economic and Social Development
AG E Australia Group
Air Pollution $ Convention on Long-Range Transboundary Air Pollution
Air Pollution-Nitrogen Oxides Protocol to the 1979 Convention on Long-Range Transboundary Air Pollution Con-
cerning the Control of Emissions of Nitrogen Oxides or Their Transboundary Fluxes
Air Pollution-Persistent Organic Pollutants Protocol to the 1979 Convention on Long-Range Transboundary Air Pollution on Per-
sistent Organic Pollutants
Air Pollution-Sulphur 85 . Protocol to the 1979 Convention on Long-Range Transboundary Air Pollution on the
Reduction of Sulphur Emissions or Their Transboundary Fluxes by at Least 30%
Air Pollution-Sulphur 94 Protocol to the 1979 Convention on Long-Range Transboundary Air Pollution on Fur-
ther Reduction of Sulphur Emissions
Air Pollution-Volatile Organic Compounds Protocol to the 1979 Convention on Long-Range Transboundary Air Pollution
Concerning the Control of Emissions of Volatile Organic Compounds or Their
Transboundary Fluxes
AMF “R Arab Monetary Fund
AMU : q Arab Maghreb Union
Antarctic Marine Living Resources Convention on the Conservation of Antarctic Marine Living Resources
Antarctic Seals Convention for the Conservation of Antarctic Seals
Antarctic-Environmental Protocol Protocol on Environmental Protection to the Antarctic Treaty
ANZUS Australia-New Zealand-United States Security Treaty
AOSIS » Alliance of Small Island States
APEC 3 ` Asia-Pacific Economic Cooperation
Arabsat l Arab Satellite Communications Organization
ARF . i ASEAN Regional Forum
ASEAN l Association of Southeast Asian Nations
AU African Union
Autodin f ; l Automatic Digital Network
BA , Baltic Assembly
bbl/day i barrels per day
BCIE . : Central American Bank for Economic Integration
BDEAC i Central African States Development Bank
Benelux l P Benelux Union
BGN š Í United States Board on Geographic Names
BIMSTEC : Bay of Bengal Initiative for Multi-sectoral Technical and Economic Cooperation
Biodiversity Convention on Biological Diversity
BIS . Bank for International Settlements
BRICS (Brazil, Russia, India, China, and South Africa)
BSEC Black Sea Economic Cooperation Zone
c : Commonwealth
cD : . Community of Democracies
c.i.f. cost, insurance, and freight
CACM } Central American Common Market
CAEU ; : Council of Arab Economic Unity
CAN ’ Andean Community
Caricom Caribbean Community and Common Market
CB citizen’s band mobile radio communications
CBSS i Council of the Baltic Sea States
ccc Customs Cooperation Council
CDB ; Caribbean Development Bank
CE. - Council of Europe _
CEI Central European Initiative `
CELAC . ’ Community of Latin America and Caribbean States
CEMA Council for Mutual Economic Assistance
CEMAC Economic and Monetary Community of Central Africa
CEPGL
CERN
TIA
CICA
cis
CITES
Climate Change
Climate Change-Kyoto Protocol
COCOM
COMESA
Comsat
CP
CPLP
Endangered Species
Entente
Environmental! Modification
ESCWA
est.
EU
Euratom
Eutelsat
Ex-Im
ABBREVIATIONS
Economic Community of the Great Lakes Countries
European Organization for Nuclear Research
Central Intelligence Agency
Conference of Interaction and Confidence-Building Measures in Asia
Commonwealth of Independent States
see Endangered Species
United Nations Framework Convention on Climate Change
Kyoto Protocol to the United Nations Framework Convention on Climate Change
Coordinating Committee on Export Controls
Common Market for Eastern and Southern Africa
Communications Satellite Corporation
Colombo Plan
Comunidade dos Paises de Lingua Portuguesa
South American Community of Nations became UNASUL—Union of South Ameri
can Nations
Collective Security Treaty Organization
Preparatory Commission for the Nuclear-Test-Ban Treaty Organization
calendar year
Developing Eight -
developed country
dichloro-diphenyl-trichloro-ethane
United Nations Convention to Combat Desertification in Those Countries Experienc-
ing Serious Drought and/or Desertification, Particularly in Africa
United States Defense Intelligence Agency
Defense Switched Network
daylight savings time
deadweight ton
East African Community
East African Development Bank
Eurasian Economic Community
Euro-Atlantic Partnership Council
East Asia Summit
European Bank for Reconstruction and Development
European Community or European Commission
Economic Commission for Africa
European Central Bank
Economic Commission for Europe ;
Economic Commission for Latin America and the Caribbean
Economic Cooperation Organization
Economic and Social Council
Economic Community of West African States
European Coal and Steel Community
Eastern Europe
European Economic Community
exclusive economic zone
European Free Trade Association
European Investment Bank
Extractive Industry Trnsparency Iniative
European Monetary Union
Convention on the International Trade in Endangered Species of Wild Flora and Fauna
(CITES)
Council of the Entente
Convention on the Prohibition of Military or Any Other Hostile Use of Environmental
Modification Techniques
European Space Agency
Economic and Social Commission for Asia and the Pacific
Economic and Social Commission. for Western Asia
estimate
European Union
European Atomic Energy Community
European Telecommunications Satellite Organization
Export-Import Bank of the United States
823
GWP
Hazardous Wastes
HF
HIV/AIDS
IADB
THE CIA WORLD FACTBOOK
free on board
Food and Agriculture Organization
Financial Action Task Force
facsimile
Front Line States
flags of convenience
former Soviet Union
fiscal year
Franc Zone
Group of 3
Group of 5
Group of 6
Group of 7
Group of 8
Group of 9
Group of 10
Group of 15
Group of 11
Group of 20 i
Group of 24
Group of 77
General Agreement on Tariffs and Trade; now WTO
Gulf Cooperation Council
Global Caribbean Network
General Confederation of Trade Unions
gross domestic product
Greenwich Mean Time
gross national product
gross register ton
global system for mobile cellular communications
Organization for Democracy and Economic Development; acronym for member states—
Georgia, Ukraine, Azerbaijan, Moldova
gross world product
Basel Convention on the Control of Transboundary Movements of Hazardous Wastes
and Their Disposal
high-frequency
human immunodeficiency virus/acquired immune deficiency syndrome
Inter-American Development Bank
International Atomic Energy Agency
Internet Assigned Numbers Authority
International Bank for Reconstruction and Development (World Bank)
International Civil Aviation Organization
International Chamber of Commerce
International Criminal Court
International Court of Justice (World Court)
International Committee of the Red Cross
International Red Cross and Red Crescent Movement
International Center for Settlement of Investment Disputes
International Criminal Tribunal for Rwanda
International Criminal Tribunal for the former Yugoslavia
International Development Association
Islamic Development Bank
Internally Displaced Person
International Energy Agency
International Fund for Agricultural Development
International Finance Corporation
International Federation of Red Cross and Red Crescent Societies
Inter-Governmental Authority on Development
International Hydrographic Organization
International Labor Organization
International Monetary Fund
International Maritime Organization
IMSO
inmarsat
Inot
Intelsat
Interpol
Intersputnik
loc
IOM
IFU
ISO
EEFET:
LAIA
LAS
Law of the Sea
LDC
LLDC
London Convention
LOS
m
Marecs
Marine Dumping
Marine Life Conservation
MARPOL
Madarabiel
Mercosur
MHz
MICAH
MIGA
MINURGAT
MINURSO
MINUSTAH
MONUSCO
NMT
NSG
Nuclear Test Ban
+
ABBREVIATIONS
International Mobile Satellite Organization
International Maritime Satellite Organization
Indian Ocean Commission
International Telecommunications Satellite Organization
International Criminal Police Organization
International Organization of Space Communications
International Olympic Committee
International Organization for Migration
Inter-Parliamentary Union
International Organization for Standardization
Internet Service Provider
International Trade Center
International Telecommunications Satellite Organization
International Telecommunication Union
International Trade Union Confederation, the successor to ICFTU (International
Confederation of Free Trade Unions) and the WCL (World Confederation of Labor)
kilohertz
kilometer
kilowatt
kilowatt-hour
Latin American and Caribbean Economic System
Latin American Integration Association
League of Arab States
United Nations Convention on the Law of the Sea (LOS)
less developed country
least developed country
see Marine Dumping
see Law of the Sea
meter
Maritime European Communications Satellite
Convention on the Prevention of Marine Pollution by Dumping Wastes and Other
Matter
Convention on Fishing and Conservation of Living Resources of the High Seas
see Ship Pollution
Middle East Telecommunications Project of the Thverational Telecommunications
Union
Southern Cone Common Market
megahertz
International Civilian Support Mission in Haiti
Multilateral Investment Guarantee Agency
United Nations Mission in the Central African Republic and Chad
United Nations Mission for the Referendum in Western Sahara
United Nations Stabilization Mission in Haiti ‘
United Nations Organization Stabilization Mission in the Democratic Republic of the
African Union/United Nations Hybrid Operation in Darfur (UNAMID)
established—31 July 2007
aim—to contribute to the restoration of security conditions which will allow safe humanitarian assistance throughout Darfur, to contribute
to the protection of civilian populations under imminent threat of physical attack, to monitor, observe compliance with, and verify the
implementation of various ceasefire agreements
members—(41) Bangladesh, Burkina Faso, Burundi, Cameroon, Canada, China, Ecuador, Egypt, Ethiopia, The Gambia, Germany, Ghana,
Guatemala, Indonesia, Iran, Italy, Jordan, Kenya, South Korea, Lesotho, Malawi, Malaysia, Mali, Mongolia, Namibia, Nepal, Netherlands,
Nigeria, Pakistan, Palau, Rwanda, Senegal, Sierra Leone, South Africa, Tanzania, Thailand, Togo, Uganda, Yemen, Zambia, Zimbabwe
African, Caribbean, and Pacific Group of States (ACP Group)
established—6 June 1975
aim—to manage their preferential economic and aid relationship with the EU
members—(79) Angola, Antigua and Barbuda, The Bahamas, Barbados, Belize, Benin, Botswana, Burkina Faso, Burundi, Cameroon,
Cape Verde, Central African Republic, Chad, Comoros, Democratic Republic of the Congo, Republic of the Congo, Cook Islands, Cote
d''Ivoire, Cuba, Djibouti, Dominica, Dominican Republic, Equatorial Guinea, Eritrea, Ethiopia, Fiji, Gabon, The Gambia, Ghana, Grenada,
Guinea, Guinea-Bissau, Guyana, Haiti, Jamaica, Kenya, Kiribati, Lesotho, Liberia, Madagascar, Malawi, Mali, Marshall Islands, Maurita-
nia, Mauritius, Federated States of Micronesia, Mozambique, Namibia, Nauru, Niger, Nigeria, Niue, Palau, Papua New Guinea, Rwanda,
Saint Kitts and Nevis, Saint Lucia, Saint Vincent and the Grenadines, Samoa, Sao Tome and Principe, Senegal, Seychelles, Sierra Leone,
Solomon Islands, Somalia, South Africa, Sudan, Suriname, Swaziland, Tanzania, Timor-Leste, Togo, Tonga, Trinidad and Tobago, Tuvalu,
Uganda, Vanuatu, Zambia, Zimbabwe
Agency for the Prohibition of Nuclear Weapons in Latin America and the Caribbean (OPANAL)
note—acronym from Organismo para la Proseripeion de las Armas Nucleares en la America Latina y el Caribe (OPANAL)
established—14 February 1967 under the Treaty of Tlatelolco; effective—25 April 1969 on the 11th ratification
aim—to encourage the peaceful uses of atomic enérgy and prohibit nuclear weapons
members—(33) Antigua and Barbuda, Argentina, The Bahamas, Barbados, Belize, Bolivia, Brazil, Chile, Colombia, Costa Rica, Cuba,
Dominica, Dominican Republic, Ecuador, El Salvador, Grenada, Guatemala, Guyana, Haiti, Honduras, Jamaica, Mexico, Nicaragua,
eet. Patan Peru, Saint Kitts and Nevis, Saint Lucia, Saint Vincent and the Grenadines, Suriname, Trinidad and Tobago, Uruguay,
Venezuela
Alliance of Small Island States (AOSIS)
established—November 1990
828
INTERNATIONAL ORGANIZATIONS AND GROUPS
aim—to call attention to threats of sea-level rise and coral bleaching to small islands and low lying coastal developing states from global
warming; to emphasize the importance of information and information technology in the process of achieving sustainable development
members—(39) Antigua and Barbuda, The Bahamas, Barbados, Belize, Cape Verde, Comoros, Cook Islands, Cuba, Dominica, Dominican
Republic, Fiji, Grenada, Guinea-Bissau, Guyana, Haiti, Jamaica, Kiribati, Maldives, Marshall Islands, Mauritius, Federated States of Micro-
nesia, Nauru, Niue, Palau, Papua New Guinea, St. Kitts and Nevis, St. Lucia, St. Vincent and the Grenadines, Samoa, Sao Tome and
Principe, Seychelles, Singapore, Solomon Islands, Suriname, Timor-Leste, Tonga, Trinidad and Tobago, Tuvalu, Vanuatu
observers—(4) American Samoa, Guam, Netherlands Antilles, U.S. Virgin Islands
Andean Community (CAN)
note—formerly known as the Andean Group (AG) and the Andean Common Market (Ancom)
established—-26 May 1969; present name established 1 October 1992; effective—16 October 1969
aim—to promote harmonious development through economic integration
members—(4) Bolivia, Colombia, Ecuador, Peru
associate members—(5) Argentina, Brazil,-Chile, Paraguay, Uruguay
observers—(4) Mexico, Panama, Sahrawi Arab Democratic Republic (Western Sahara), Spain
Arab Bank for Economic Development in Africa (ABEDA)
note—also known as Banque Arabe de Developpement Economique en Afrique (BADEA)
established—18 February 1974; effective—16 September 1974
aim—to promote economic development
members—(17 plus the Palestine Liberation Organization) Algeria, Bahrain, Egypt, Iraq, Jordan, Kuwait, Lebanon, Libya, Mauritania,
Morocco, Oman, Qatar, Saudi Arabia, Sudan, Syria, Tunisia, UAE, Palestine Liberation Organization; note—these are all the members of
the Arab League excluding Comoros, Djibouti, Somalia, Yemen ; a
Arab Fund for Economic and Social Development (AFESD)
established—16 May 1968
aim—to promote economic and social development
members—(20 plus the Palestine Liberation Organization) Algeria, Bahrain, Djibouti, Egypt, Iraq, Jordan, Kuwait, Lebanon, Libya,
Mauritania, Morocco, Oman, Qatar, Saudi Arabia, Somalia (suspended 1993), Sudan, Syria, Tunisia, UAE, Yemen, Palestine Liberation
Organization - —_ is i
Arab Maghreb Union (AMU)
established—17 February 1989
aim—to promote cooperation and integration among the Arab states of northern Africa
members—(5) Algeria, Libya, Mauritania, Morocco, Tunisia
Arab Monetary Fund (AMF)
established—27 April 1976; effective—2 February 1977
aim—to promote Arab cooperation, development, and integration in monetary and economic affairs cll
members—(21 plus the Palestine Liberation Organization) Algeria, Bahrain, Comoros, Djibouti, Egypt, Iraq, Jordan, Kuwait, Lebanon,
Libya, Mauritania, Morocco, Oman, Qatar, Saudi Arabia, Somalia, Sudan, Syria, Tunisia, UAE, Yemen, Palestine Liberation Organization
Arctic Council
established—18 September 1996
aim—to address the common concerns and challenges faced by Arctic governments and the people of the Arctic; to protect the Arctic','8fbffa5587668757530505c8efe50751f066cac3658c63a646874b7dda7db6fb','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5cf1af47a86f723a12499a47dbb80336ccb5c5731ef939a9ccdb38f6c0b74dc5',2025,'AF','Afghanistan','transnational-issues',22,'Morb teats
~~ 2
ee
TURKMENISTAN i P -i a mun a
A gg noe
Sa
Toraghondi
“Herat KABUL*
Bagram,
Ghazm*
"Shindand
Kandahar a 7
t :
ew. p Zarary S "i
É PAX iS TAN
A
> mee j
E
Disputes—international: Afghan, Coalition,
and Pakistan military meet periodically to clarify
the alignment of the boundary on the ground and
on maps; Afghan and Iranian commissioners have
discussed boundary monument densification and
resurvey; Iran protests Afghanistan’s restricting
flow of dammed Helmand River tributaries during
drought; Pakistan has sent troops across and built
fences along some remote tribal areas of its treaty-
defined Durand Line border with Afghanistan
which serve as bases for foreign terrorists and other
illegal activities; Russia remains concerned about
the smuggling of poppy derivatives from Afghani-
stan through Central Asian countries
Refugees and internally displaced persons:
IDPs: 492,777 (mostly Pashtuns and Kuchis dis-
placed in the south and west due to drought and
instability) (2013)
illicit drugs: world’s largest producer of opium;
while poppy cultivation was relatively stable at
119,000 hectares in 2010, a poppy blight affecting
the high cultivation areas in 2010 reduced poten-
tial opium production to 3,200 metric tons, down
over 40 percent from 2009; the Taliban and other
antigovernment groups participate in and profit
from the opiate trade, which is a key source of
revenue for the Taliban inside Afghanistan; wide-
spread corruption and instability impede coun-
terdrug efforts; most of the heroin consumed in
Europe and Eurasia is derived from Afghan opium;
vulnerable to drug money laundering through
informal financial networks; regional source of
hashish (2008)
AKROTIRI','e148d40083fe320c8c5c0bbc3b964d02913c73cba6eec715b6ed6e3e36a31895','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ea5596fed05289473c2b917aabdc0d26eebe0b8bd024d2635c939e69590ac85a',2025,'AL','Albania','transnational-issues',47,'Disputes—international: none
Illicit drugs: increasingly active transshipment
point for Southwest Asian opiates, hashish, and
cannabis transiting the Balkan route and—to
a lesser extent—cocaine from South America
destined for Western Europe; limited opium and
expanding cannabis production; ethnic Albanian
narcotrafficking organizations active and expand-
ing in Europe; vulnerable to money laundering
associated with regional trafficking in narcotics,
arms, contraband, and illegal aliens','3a722f72ad15d4f4e701c88d0052b7c5acf719f5064de7afffd50294158cb8f2','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c4cd10aee25e8951974046154e9c0a5e276f4b07d350613b9f1c4d8a54bf4072',2025,'DZ','Algeria','transnational-issues',54,'Disputes—international: Algeria and many
other states rejéct Moroccan administration of
Western Sahara; the Polisario Front, exiled in
Algeria, represents the Sahraw i Arab Democratic
Republic; Algeria’s border with Morocco remains
an irritant to bilateral relations, each nation
accusing the other of harboring militants and arms
smuggling; dormant disputes include Libyan claims
of about 32,000 sq km still reflected on its maps of
southeastern Algeria and the National Liberation
Front’s (FLN) assertions of a claim to Chirac Pas- `
tures in southeastern Morocco
Refugees and internally displaced persons:
refugees (country of origin): 90,000 (Western
Saharan Sahrawi, mostly living in Algerian-spon-
sored camps in the southwestern Algerian town of
Tindouf); 1,000 (Mali) (2013)
IDPs: undetermined (civil war during 1990s)
(2012)
Trafficking in persons: current situation: Alge-
ria is a transit and, to a lesser extent, a destination
and source country for men, women, and chil-
dren subjected to forced labor and sex trafficking;
criminal networks which sometimes extend to sub-
Saharan Africa and to Europe are involved in both
human smuggling and trafficking
tier rating: Tier 3—the Government of Algeria
does not fully comply with the minimum standards
for the elimination of trafficking and is not mak-
ing significant efforts to do so; the government
made no discemible effort to enforce its 2009
anti-trafficking law; it also failed to identify and
protect trafficking victims and continued to lack
adequate measures to protect victims and prevent
trafficking (2012) ft','477a07ffbb658c21136d08c6b926a88dcc46637dd716d2ffed75cb52e0e5d830','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a7e79b64465f66135bfa44ad7f1135b8302474dfce33c90310cd500622b24d3d',2025,'AS','American Samoa','transnational-issues',55,'PAGO PAGO se
Aunu''u
Tutuila
Disputes—international: Tokelau included
American Samoa’s Swains Island (Olosega) in its
2006 draft independence constitution','52ef4b0585111045e997b6ef17240ead4dec007e580088b20ac706cb7261e17b','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('23eba63727815778cf5bdaef6ccbc7cb583584895cb92252191b24ef5cce62d2',2025,'AD','Andorra','transnational-issues',67,'—_
—" ° Encamp ie
.
Esewices
? Engey
LA VELLA
Sant ya m
de T aa
p=
a
Disputes—international: none
Elevation extremes: lowest point: Atlantic
Ocean 0 m
highest point: Morro de Moco 2,620 m
Natural resources: petroleum, diamonds, iron
ore, phosphates, copper, feldspar, gold, bauxite,
uranium
Land use: arable land: 3.29%
permanent crops: 0.23%
other: 96.48% (2011)
Irrigated jand: 855.3 sq km (2005)
Tota! renewable water resources: 148 cu km
(2011)
Freshwater withdrawal (domestic/indus-
triaVagricultural): total: 0.71 cu km/yr
(45%/34%/21%)
per capita: 40.27 cu m/yr (2005)
Natural hazards: locally heavy rainfall causes
periodic flooding on the plateau
Environment—current issues: overuse of pas-
tures and subsequent soil erosion attributable to
population pressures; desertification; deforestation
of tropical rain forest, in response to both interna-
tional demand for tropical timber and to domestic
use as fuel, resulting in loss of biodiversity; soil ero-
sion contributing to water pollution and siltation
of rivers and dams; inadequate supplies of potable
water
Environment—international agreements:
party to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Law of
the Sea, Marine Dumping, Ozone Layer Protec-
tion, Ship Pollution
17
signed, but not ratified: none of the selected
agreements
Geography—note: the province of Cabinda is an
exclave, separated from the rest of the country by
the Democratic Republic of the Congo','0faf22c4fdb17c1e63b8f483589cd65e0fb72835b30f70dad41306a6af1785a6','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1233b22d48b9021bdd0cc32da325e0be1828f7c6107cd10d54bf8c5f9cd9fa3d',2025,'AO','Angola','transnational-issues',80,'Disputes—International: Democratic Republic
of Congo accuses Angola of shifting monuments
Refugees and Internally displaced persons:
refugees (country of origin): 13,364 (Democratic
Republic of Congo) (2012)
IDPs: 19,500 (27-year civil war ending in 2002)
(2005)
ilicit drugs: used as a transshipment point for
cocaine destined for Western Europe and other
African states, particularly South Africa
NORTH ATLANTIC
OGEAN
Oshakat* m:
Tsumab,
+
zA
i *Otywaron''
ato gor ý gO
Swakopmund, WINDHOEK. f5 saaana
Walvis Says
Rehoboth xquauant
a
Marienta!
Luderitz
fy
Oranjamund ~','40cae0cf9f0e2786347771a3f74894f256186ff3b21a6a39f9f248c98370af08','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('49f57e7a08d2f711389f9ed4a4085ac50a56885484a6c5aef45f5bbf4e61437d',2025,'AI','Anguilla','transnational-issues',91,'|
Disputes—international: none
illicit drugs: transshipment point for South
American narcotics destined for the US and
Europe','682e3a1f94f66d2fdede0159942f120050dc5348a8cdb9a1e2f14ffb5eab5fc9','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e43d05d629ef092d7c821a469e6664251d744b88ba8c1afb652875bdabc43656',2025,'AQ','Antarctica','transnational-issues',99,'Disputes—international: the Antarctic Treaty
freezes, and most states do not recognize, the land
and maritime territorial claims made by Argen-
tina, Australia, Chile, France, New Zealand,
Norway, and the United Kingdom (some over:
lapping) for three-fourths of the continent; the
US and Russia reserve the right to make claims;
no formal claims have been made in the sector
between 90 degrees west and 150 degrees west;
the International Whaling Commission created
a sanctuary around the entire continent to deter
catches by countries claiming to conduct scien-
tific whaling; Australia has established a similar
preserve in the waters around its territorial claim','ab962b1359840c7ec0107dd2c0d00820b01608ab8cd94b5764445063142e791a','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b18be80b3d83564b7e5525262a79c67b4861a60a96a145e2c6ed229031f7fd23',2025,'AG','Antigua and Barbuda','transnational-issues',108,'Disputes—international: none
illicit drugs: considered a minor transshipment
point for narcotics bound for the US and Europe;
more significant as an offshore financial center
27
Sm
Route
Disputes—international: Canada and the
United States dispute how to divide the Beau-
fort Sea and the status of the Northwest Passage
but continue to work cooperatively to survey the
Arctic continental shelf; Denmark (Greenland)
and Norway have made submissions to the Com-
mission on the Limits of the Continental shelf
(CLCS) and Russia is collecting additional data to
augment its 2001 CLCS submission; record sum-
mer melting of sea ice in the Arctic has renew ed
interest in maritime shipping lanes and sea floor
exploration; Norway and Russia signed a compre-
hensive maritime boundary agreement in 2010','4942ae16226441e9a043216ceb2c69d25621decc94aa3f4724e30ae0d0538716','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b15baa95584be832981b10a5f33c01b34d55f08263c2b3769984b43466667ad3',2025,'AR','Argentina','transnational-issues',117,'Disputes—international: Argentina continues to
assert its claims to the UK-administered Falkland
Islands (Islas Malvinas), South Georgia, and the
South Sandw ich Islands in its constitution, forci-
bly occupying the Falklands in 1982, but in 1995
agreed to no longer seek settlement by force; UK
continues to reject*Argentine requests for sover-
eignty talks; territorial claim in Antarctica partially
overlaps UK and Chilean claims; uncontested dis-
pute between Brazil and Uruguay over Braziliera/
Brasiliera Island in the Quarai/Cuareim River
leaves the tripoint with Argentina in question; in
2010, the ICJ ruled in favor of Uruguay''s operation
of two paper mills on the Uruguay River, which
forms the border with Argentina; the two coun-
tries formed a joint pollution monitoring regime;
the joint boundary commission, established by
Chile and Argentina in 2001 has yet to map and
demarcate the delimited boundary in the inhospi-
table Andean Southern Ice Field (Campo de Hielo
Sur); contraband smuggling, human trafficking,
and illegal narcotic trafficking are problems in the
porous areas of the border with Bolivia
lilicit drugs: a transshipment country for cocaine
headed for Europe, heroin headed for the US, and
ephedrine and pseudoephedrine headed for Mex-
'' ico; some money-laundering activity, especially
in the TriBorder Area; law enforcement corrup-
tion; a source for precursor chemicals; increasing
domestic consumption of drugs in urban centers,
especially cocaine base and synthetic drugs (2008)
Alaverdty
° \\
Vanadzor
a? “Hrasdan
z Ejmiatsin, , Adovyan
a ee Ae
Armavir YEREVAN
*Artasnal
eVardenis
uon
NEET
CANAAN Z
Talcahuano,
Con
Temuco*
h
Puerto
Mont,
_®
nm
ATLANTIC
OCEAN
FALALAND SLAND >
EAn Mtg a PIA >
treet,
stait Ray BOSE ENNA','32c729a19955abf1979266e21bcb021401a7b5d546cb42a3cc15b6bdb73bd4cb','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('aa0a028d8896f8f2dce9bd41aa627c3aa3aaa97280dfbc18727ae51dfc1a588c',2025,'AM','Armenia','transnational-issues',124,'Disputes—international: the dispute over the
break-away Nagorno-Karabakh region and the
Armenian military occupation of surrounding
lands in Azerbaijan remains the primary focus
of regional instability; residents have evacuated
the former Soviet-era small ethnic enclaves in
Armenia and Azerbaijan; Turkish authorities have
complained that blasting from quarries in Arme-
nia might be damaging the medieval ruins of Ani,
on the other side of the Arpacay valley; in 2009,
Sw iss mediators facilitated an accord reestablish-
ing diplomatic ties between Armenia and Turkey,
but neither side has ratified the agreement and
the rapprochement effort has faltered; local bor-
der forces struggle to control the illegal transit of
goods and people across the porous, undemarcated
Armenian, Azerbaijani, and Georgian borders;
ethnic Armenian groups in the Javakheti region of
Georgia seek greater autonomy from the Georgian','02ea370fa8d4c8e9e43ef9f6f87aa3653b4cbb9c5e3775cd1791673400a25f8f','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4aee6cec0335f409c9f10a4dcc7e7d497a04c1d72bd992f4e9d29ec93f1924a3',2025,'AW','Aruba','transnational-issues',134,'Disputes—international: none
Illicit drugs: transit point for US-and Europe-bound
narcotics with some accompanying money-launder-
ing activity; relatively high percentage of population
consumes cocaine
ASHMORE AND CARTIER ISLANDS
INDONESIA ~
Map Area
ALSTHALIA
ore
pn wan
Disputes—international: some maritime dis-
putes (see littoral states)','f476a2edf9086d810f2746a509ab6c92587aa2aa7937b448ef50ddc507f78f60','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9cd490fb2d2e7e2de90a7c38881c2331da7f18fa52e1d347142c63e3476c891c',2025,'AU','Australia','transnational-issues',135,'i AUSTRALIA
T INDONESIA |
e, *Port Hedana
Damypuer
Akce Spangs”
Giadstone®
Brisbane,
p ie
Sorina Anese Sydney *
.
CANBERRA®
d p :
Launceston,
Peyma pronn
es
Disputes—international: In 2007, Australia and
Timor-Leste agreed to a 50-year development zone
and revenue sharing arrangement and deferred
a maritime boundary; Australia asserts land and
maritime claims to Antarctica; Australia’s 2004
submission to the Commission on the Limits of the
Continental Shelf (CLCS) extends its continen-
tal margins over 3.37 million square kilometers,
expanding its seabed roughly 30 percent beyond
its claimed exclusive economic zone; all borders
between Indonesia and Australia have been agreed
upon bilaterally, but a 1997 treaty that would set-
tle the last of their maritime and Exclusive Eco-
nomic Zone (EEZ) boundary has yet to be ratified
by Indonesia’s legislature; Indonesian groups chal-
lenge Australia’s claim to Ashmore Reef; Australia
closed parts of the Ashmore and Cartier reserve to
Indonesian traditional fishing
Illicit drugs: Tasmania is one of the world’s major
suppliers of licit opiate products; government
maintains strict controls ovér areas of opium poppy
cultivation and output of poppy straw concentrate;
major consumer of cocaine and amphetamines
Disputes—international: none
West
isiat
Bird thet
Calo tsini”
Disputes—international: none
Disputes—international: none
Fanion de
Paaris
MALG ISE ANOS','86c9938e8a9c4532a911418dbd4af46354e794b62b6311f3d2eb3b976ebec4b8','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2dfac8e87d1a2faf03a19d1026af353d32fdd827478b4f4d24eab0e92f7904a8',2025,'AT','Austria','transnational-issues',145,'. AUSTRIA
aonana
S
“~ eslagenturt, aes
:
ae
Disputes—international: none
Refugees and internally displaced persons:
refugees (country of origin): 18,473 (Russia);
8,636 (Afghanistan) (2011)
Iicit drugs: transshipment point for Southwest
Asian heroin and South American cocaine des-
tined for Western Europe; increasing consumption
of European-produced synthetic drugs
Disputes—international: while threats of inter-
national legal action never materialized in 2007,
915,220 Austrians, with the support of the popular
198
THE CIA WORLD FACTBOOK
Freedom Party, signed a petition in January 2008,
demanding that Austria block the Czech Repub-
lic’s accession to the EU unless Prague closes its
controversial Soviet-style nuclear plant in Teme-
lin, bordering Austria
Illicit drugs: transshipment point for Southwest
Asian heroin and minor transit point for Latin
American cocaine to Western Europe; producer
of synthetic drugs for local and regional markets;
susceptible to money laundering related to drug
trafficking, organized crime; significant consumer
of ecstasy (2008)
SWEDEK
` Rog
mi PA a ` 2 ipoPennhaen
a
*Esnyerg Rosida
- givens
thes
Background: Once the seat of Viking raiders and
later a major north European power, Denmark has
evolved into a modern, prosperous nation that is
participating in the general political and economic
integration of Europe. It joined NATO in 1949
and the EEC (now the EU) in 1973. How ever,
the country has opted out of certain elements of
the European Union”s Maastricht Treaty, includ-
ing the European Economic and Monetary Union
(EMU), European defense cooperation, and issues
concerning certain justice and home affairs.
:
S È
Sin','359e192ad7200ef41024e0d0a63f9b7d5bdfeb9efb316d1840856188b5b578a2','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5082e565afd39dd3921bd9ded98df5298e8919ad5827574c45c84b89edc17ec9',2025,'AZ','Azerbaijan','transnational-issues',164,'Disputes—international: Azerbaijan, Kazakh-
stan, and Russia ratified the Caspian seabed
delimitation treaties based on equidistance, while
Iran continues to insist on a one-fifth slice of the
sea; the dispute over the break-away Nagorno-
Karabakh region and the Armenian military occu-
pation of surrounding lands in Azerbaijan remains
the primary focus of regional instability; residents
have evacuated the former Soviet-era small ethnic
enclaves in Armenia and Azerbaijan; local bor-
der forces struggle to control the illegal transit of
goods and people across the porous, undemarcated
Armenian, Azerbaijani, and Georgian borders;
bilateral talks continue with Turkmenistan on
dividing the seabed and contested. oilfields in the
middle of the Caspian
Refugees and internally displaced persons:
IDPs: 600,000 (conflict with Armenia over
Nagorno-Karabakh) (2013)
Trafficking in persons: current situation: Azer-
baijan is a source, transit, and destination country
for men, women, and children subjected to forced
labor, and women and children subjected to sex
trafficking; women and some children from Azer-
baijan are trafficked to Turkey, the UAE, Russia,
and Iran for the purpose of sexual exploitation;
men and boys are trafficked to Russia and Moldova
for thé purpose of forced labor; Azerbaijan serves as
a transit country for victims from Uzbekistan and
Kazakhstan trafficked to Turkey and the UAE for
sexual exploitation; Azerbaijan is also a destina-
tion country for men from Turkey and Afghani-
stan, and Chinese men and women for forced labor
tier rating: Tier 2 Watch List—Azerbaijan is on
the Tier 2 Watch List for not fully complying
with the minimum standards for the elimination
of trafficking; the Government of Azerbaijan
has not made sufficient progress in investigat-
ing, prosecuting, or convicting labor trafficking
offenses or in identifying victims of forced labor
(2008)
Illicit drugs: limited illicit cultivation of cannabis
and opium poppy, mostly for CIS consumption;
small government eradication program; transit
point for Southwest Asian opiates bound for Rus-
sia and to a lesser extent the rest of Europe
© © 10km
6 D tom
tirana
Bahama
*
Freeport South
Puing Abace
ie, Pat
Aa
NASSAU. m
Na
Power
toeytvesa
DR Sat
Disputes—international: disagrees with the US
on the alignment of the northern axis of a poten-
tial maritime boundary
illicit drugs: transshipment point for cocaine
and marijuana bound for US and Europe; offshore
financial center
55
THE CIA WORLD FACTBOOK','4624a4d9a3d98383cc02fa1c75505cde543dd0e30ebdbeba88b0150471420966','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a836e32f7002eef174dd3305d1cebe5f878b40504796b2f89aefa05ba0955ac1',2025,'BH','Bahrain','transnational-issues',166,'Ai Muhareagy © Bahrain
MANAMA Seem
M adinat Mina’ Saiman
Ar Rite eotleah
J meg
Hamad
A —
Day
Durrat
a! Bahrain
` unter
Disputes—international: none','a60ab6245679df84ac1d525ac2506aa20ae401037f5ee0d225803beed77cb641','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cc5162758f28c752ed651e6b31d8ccd90a9ab826c97bdb7f53ffd1b97d8f850b',2025,'BD','Bangladesh','transnational-issues',183,'Disputes—international: Bangladesh referred
its maritime boundary claims with Burma and
India to the International Tribunal on the Law
of the Sea; Indian Prime Minister Singh''s Sep-
tember 2011 visit to Bangladesh resulted in the
signing of a Protocol to the 1974 Land Bound-
ary Agreement between India and Bangladesh,
which had called for the settlement of longstand-
ing boundary disputes over undemarcated areas
and the exchange of territorial enclaves, but
which had never been implemented; Bangladesh
struggles to accommodate 29,000 Rohingya,
Burmese Muslim minority from Arakan State,
living as refugees in Cox’s Bazar; Burmese border
authorities are constructing a 200 km (124 mi)
wire fence designed to deter illegal cross-border
transit and tensions from the military build-up
along border
Refugees and internally displaced persons:
refugees (country of origin): 229,644 (Burma)
(2011)
IDPs: undetermined (land conflicts, religious per-
secution) (2012)
illicit drugs: transit country for illegal drugs pro-
duced in neighboring countries','0a222b4d443e2b6ea02c721dcc58c092675a426ee9b8245000cc45ba2effb51c','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5211b465b18e8bd0b8774a814b6425f4fba83cf4340d62f47b14c3153529c50f',2025,'BB','Barbados','transnational-issues',184,'BRIDGETOWN ‘The Grane,
as “ n a >
genes are,
Disputes—international: Barbados and Trinidad
and Tobago abide by the April 2006 Permanent
Court of Arbitration decision delimiting a mari-
time boundary and limiting catches of flying fish
in Trinidad and Tobago''s exclusive economic zone;
joins other Caribbean states to counter Venezuela''s
claim that Aves Island sustains human habitation,
a criterion under the UN Convention on the Law
of the Sea, which permits Venezuela to extend its
Economic Exclusion Zone/continental shelf over a
large portion of the eastern Caribbean Sea
liHicit drugs: one of many Caribbean transship-
ment points for narcotics bound for Europe and
the US; offshore financial center
65
THE CIA WORLD FACTBOOK','b8401952e53dcc7383e52c3b1e6ae1b6aa829c593f6df8364943e8aef0f57d22','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('483375747a196e05396f1d545a2e28d184df40ae76f46e61eb7e302ed5180463',2025,'BY','Belarus','transnational-issues',194,'eee,
Pattie,
Potatsh,
Vitsyabat?
$
RUSSIA
a Mahilyow
“ *MINSK
Babruysk,
“Saranavichy
Disputes—international: boundary demar-
cated with Latvia and Lithuania; Poland seeks
enhanced demarcation and security along this
Schengen hard border with financial assistance
from the EU
Illicit drugs: limited cultivation of opium poppy
and cannabis, mostly for the domestic market;
transshipment point for illicit drugs to and via
Russia, and to the Baltics and Western Europe;
a small and lightly regulated financial center;
anti-money-laundering legislation does not meet
international standards and was weakened further
when know-your-customer requirements were cur-
tailed in 2008; few investigations or prosecutions
of money-laundering activities (2008)
69
Pa
RS $
NETHERLANDS h
Zapoa pS
Antwerp
<8
sty * n NER.
BRUSSELS
W “Lege
Mons = a
ee Chagerol ey Tamur Boang
r m; WAKLON?
ge
= Al sg cueg
~','be7d751db392b795e4b07f4c6252ba43fcb1594d1929356e37a0249fcace076c','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1582ba5b863c249d2e53c309f999fe4e04f81ffc45d1ccb905be40ca78adf414',2025,'FR','France','transnational-issues',204,'- 20 km
20 am
Disputes—international: none
i
s PNGOLD
Vanua Levu nts
Lambasa y 7"
x 94 ÄER + NORTHERN
Savisavu pees _ LAU GAOU?
Lautoka, “2 * yf
Yorke, Cain
Viti Levu k
SUVA ps
AAAI Z
tim
Disputes—international: Madagascar claims
the French territories of Bassas da India, Europa
Island, Glorioso Islands, and Juan de Nova Island;
Comoros claims Mayotte; Mauritius claims Trome-
lin Island; territorial dispute between Suriname
and the French overseas department of French
Guiana; France asserts a territorial claim in
Antarctica (Adelie Land); France and Vanuatu
claim Matthew and Hunter Islands, east of New
Caledonia
Refugees and internally displaced persons:
refugees (country of origin): 22,719 Sri Lanka;
12,818 Cambodia; 11,931 Democratic Republic
of the Congo; 10,891 Serbia; 10,885 Turkey;
10,882 Russia; 8,654 Vietnam; 7,382 Laos
(2011)
Illicit drugs: metropolitan France: transshipment
point for South American cocaine, Southwest
Asian heroin, and European synthetics
French Guiana: small amount of marijuana grown
for local consumption; minor transshipment point
to Europe
Martinique: transshipment point for cocaine and
marijuana bound for the US and Europe
Disputes—international: none
FRENCH SOUTHERN AND ANTARCTIC LANDS
262
Disputes—international: French
“Adelie Land” in Antarctica is not recognized
by the US Bassas da India, Europa Island, Glo-
rioso Islands, Juan de Nova Island (Iles Eparses):
claimed by Madagascar; the vegetated drying cays
of Banc du Geyser, which were claimed by Mada-
gascar in 1976, also fall within the EEZ claims of
the Comoros and France (Glorioso Islands)
Tromelin Island (Iles Eparses): claimed by
Disputes—international: none
INTROUCTION
Background: The Mongols gained fame in the
13th century when under Chinggis KHAAN
they established a huge Eurasian empire through
conquest. After his death the empire was divided
into several powerful Mongol states, but these
broke apart in the 14th century. The Mongols
eventually retired to their original steppe home-
lands and in the late 17th century came under
Chinese rule. Mongolia won its independence
in 1921 with Soviet backing and a Communist
regime was installed in 1924. The modern coun-
try of Mongolia, however, represents only part of
the Mongols’ historical homeland; more ethnic
Mongolians live in the Inner Mongolia Autono-
mous Region in the People’s Republic of China
than in Mongolia. Following a peaceful demo-
cratic revolution, the ex-Communist Mongolian
People’s Revolutionary Party (MPRP) won elec-
tions in 1990 and 1992, but was defeated by the
Democratic Union Coalition (DUC) in the 1996
parliamentary election. The MPRP won an over-
whelming majority in the 2000 parliamentary
election, but the party lost seats in the 2004 elec-
tion and shared power with democratic coalition
parties from 2004-08. The MPRP regained a solid
majority in the 2008 parliamentary elections but
nevertheless formed a coalition government with
the Democratic Party that lasted until January
2012. In 2009, current President ELBEGDOR)J
of the Democratic Party was-elected to office. In
2010, the MPRP voted to retake the name of the
Mongolian People’s Party (MPP), a name it used
in the early 1920s. Shortly thereafter, a new party
was formed by former president ENKHBAYAR,
which adopted the MPRP name. In the 2012 Par-
liamentary elections, a coalition of four political
parties led by the Democratic Party, gained con-
trol of the Parliament.
Location: Northem Asia, between China and
Russia =
Geographic coordinates: 46 00 N, 105 00 E
Map references: Asia
Area: total: 1,564,116 sq km
country comparison to the world: 19
land: 1,553,556 sq km
water: 10,560 sq km
Area—comparative: slightly smaller than Alaska
Land boundaries: total: 8,220 km
border countries: China 4,677 km, Russia 3,543
km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
Climate: desert; continental (large daily and sea-
sonal temperature ranges)
Terrain: vast semidesert and desert plains, grassy
steppe, mountains in west and southwest; Gobi
Desert in south-central
Elevation extremes: lowest point: Hoh Nuur
560 m
highest point: Nayramadlin Orgil (Huyten Orgil)
4,374 m Natural resources: oil, coal, copper,
molybdenum, tungsten, phosphates, tin, nickel,
zinc, fluorspar, gold, silver, iron
Land use: arable land:0.39%
permanent crops: 0%
other: 99.61% (2011)
Irrigated land: 843 sq km (2003)
Total renewable water resources: 34.8 cu km
(2011)
Freshwater withdrawal (domestic/indus-
triaVagricultural): total: 0.55 cu km/yr
(13%/43%/44%)
per capita: 196.8 cu m/yr (2009)
Natural hazards: dust storms; grassland and for-
est fires; drought; “zud,” which is harsh winter
conditions
Environment—currem issues: limited natural
freshwater resources in some areas; the policies
of former Communist regimes promoted rapid
urbanization and industrial growth that had nega-
tive effects on the environment; the burning of soft
coal in power plants and the lack of enforcement
of environmental laws severely polluted the air in
Ulaanbaatar; deforestation, overgrazing, and the
converting of virgin land to agricultural production
increased soil erosion from wind and rain; desertifi-
cation and mining activities had a deleterious effect
on the environment
Environment—international agreements:
party to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Endan-
gered Species, Environmental Modification,
Hazardous Wastes, Law of the Sea, Ozone Layer
Protection, Ship Pollution, Wetlands, Whaling
signed, but not ratified: none of the selected
agreements
Geography—note:; landlocked; strategic location
between China and Russia
Disputes—international: Matthew and Hunter
Islands east of New Caledonia claimed by France
and Vanuatu
INTHODUCTION
Background: The Polynesian Maori reached
New Zealand in about A.D. 800. In 1840, their
chieftains entered into a compact with Britain,
the Treaty of Waitangi, in which they ceded sov-
ereignty to Queen Victoria while retaining ter-
ritorial rights. That same year, the British began
the first organized colonial settlement. A series of
land wars between 1843 and 1872 ended with the
defeat of the native peoples. The British colony of
New Zealand became an independent dominion
in 1907 and supported the UK militarily in both
world wars. New Zealand’s full participation in a
number of defense alliances lapsed by the 1980s. In
recent years, the government has sought to address
longstanding Maori grievances
Disputes—international: none
Disputes—international: none
Disputes—international: None','7c7f0a15b08f691b8a3c9c1118c13fd434aa223c54610bd1151f5a379595bade','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d3fd75b5dedb76f08c66bb585430c7aca95b0b8b6d4cd17dcf193f5895065859',2025,'BE','Belgium','transnational-issues',214,'Disputes—international: none
Iticit drugs: growing producer of synthetic drugs
and cannabis; transit point for US-bound ecstasy;
source of precursor chemicals for South Ameri-
can cocaine processors; transshipment point for
cocaine, heroin, hashish, and marijuana entering
Western Europe; despite a strengthening of legis-
lation, the country remains vulnerable to money
laundering related to narcotics, automobiles, alco-
hol, and tobacco; significant domestic consump-
tion of ecstasy
73
THE CIA WORLD FACTBOOK
a Pù 4h
Corofai, 1——s
MENTO f if
"Orange
A
a Wilks "San Podre
TURNEFFE
p ISLANDS
z
i
coe |
i
i
+
Spa! ad P
a ee d E
Í *San Ignacio
] Dangngae 7
Victoria Poak a, Poe
creeks A ae
A
GUATEMALA { Oes Oeon pm
poets S
Disputes—international: Guatemala persists in
its territorial claim to half of Belize, but agrees
to the Line of Adjacency to keep Guatemalan
squatters out of Belize’s forested interior; both
countries agreed in April 2012 to hold simultane-
ous referenda, scheduled for 6 October 2013, to
decide whether to refer the dispute to the IC] for
binding resolution; Belize and Mexico are work-
ing to solve minor border demarcation discrepan-
cies arising from inaccuracies in the 1898 border
treaty
illicit drugs: transshipment point for’ cocaine;
small-scale illicit producer of cannabis, primarily
for local consumption; offshore sector money-
laundering activity related to narcotics trafficking
and other crimes (2008)','1937e2161a97998899b604fa4a92f9e628c6befb827673eb80697b02b3b32fe7','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0a39cc3b309047816bd42aaa9f8a19084cb6de2265c144cb42a105fe8448cb3d',2025,'BJ','Benin','transnational-issues',227,'Disputes—international: talks continue between
Benin and Togo on funding the Adjrala hydroelec-
tric dam on the Mona River; Benin retains a bor-
der dispute with Burkina Faso around the town of
Koualou; location of Benin-Niger-Nigeria tripoint
is unresolved
Refugees and internally displaced persons:
refugees (country of origin): 5,883 (Togo) (2011)
illicit drugs: transshipment point used by traf-
fickers for cocaine destined for Western Europe;
vulnerable to money laundering due to poorly
enforced financial regulations (2008)','44a2f0b232e9837278eaa18f518ad1a191473bb9d8a754cca0c30a9aa93c050d','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0f8c1cb524c221ce39466dc30ad0b5e70a584728d207c03c6912a2b54d65f0ae',2025,'BT','Bhutan','transnational-issues',237,'- Yan
THIMPHU Trongsa Tati
“Wangdue
Phodrang M .
Teimasham å o
` 5 lephu gone
I a Ol
Disputes—international: lacking any treaty
describing the boundary, Bhutan and China con-
tinue negotiations to establish a common bound-
ary alignment to resolve territorial disputes arising
from substantial cartographic discrepancies, the
largest of which lie in Bhutan’s northwest and
along the Chumbi salient
BOLIVIA
BOLIVIA','47b6a784f726ac3222db7261abe015958aded7611102b9acf70656971e3d378f','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('660cb0dffafc4d88fb6d23b2dbf9abb4ed787c658f36e2aa72ab49625ff2c7ac',2025,'PY','Paraguay','transnational-issues',257,'Disputes— international: Chile and Peru rebuff
Bolivia’s reactivated claim to restore the Atacama
corridor, ceded to Chile in 1884, but Chile offers
instead unrestricted but not sovereign maritime
access through Chile for Bolivian natural gas; con-
traband smuggling, human trafficking, and illegal
narcotic trafficking are problems in the porous
areas of the border with Argentina
Illicit drugs: world’s third-largest cultivator of
coca (after Colombia and Peru) with an esti-
mated 35,000 hectares under cultivation in 2009,
an increase of ten percent over 2008; third larg-
est producer of cocaine, estimated at 195 metric
tons potential pure cocaine in 2009, a 70 percent
increase over 2006; transit country for Peruvian
and Colombian cocaine destined for Brazil,
Argentina, Chile, Paraguay, and Europe; weak
border controls; some money-laundering activity
related to narcotics trade; major cocaine con-
sumption (2008)
—
— ~~
Pregn
.
a
Bosansa Brod i 7
.
Banja
voka
INTEN PUSR
AA
ACA /
5
——— Fi :
p BRAZIL
Fortin Olimpo
Bn SA
Estigarribia
treme
pianoa
''
a eee a T
"o Filadelfia © Pedro Jua
\\ , Caballero
a "tae
oy
y =, Colorado
af x
ASUNCIONS Cagua
J vivacned Adel Este
i Pero
ofiar
{a Encarnacon
Disputes—international: unruly region at con-
vergence of Argentina-Brazil-Paraguay borders is
locus of money laundering, smuggling, arms and
illegal narcotics trafficking, and fundraising for
extremist organizations
illicit drugs: major illicit producer of canna-
bis, most or all of which is consumed in Brazil,
Argentina, and Chile; transshipment country for
Andean cocaine headed for Brazil, other Southern
Cone markets, and Europe; weak border controls,
extensive corruption and money-laundering activ-
ity, especially in the Tri-Border Area; weak anti-
money-laundering laws and enforcement
Background: Ancient Peru was the seat of several
prominent Andean civilizations, most notably that
of the Incas whose empire was captured by Span-
ish conquistadors in 1533. Peruvian independence
was declared in 1821, and remaining Spanish
forces were defeated in 1824. After a dozen years of
military rule, Peru returned to democratic leader-
ship in 1980, but experienced economic problems
and the growth of a violent insurgency. President
Alberto FUJIMORI’s election in 1990 ushered in
a decade that saw a dramafic turnaround in the
economy and significant progress in curtailing
guerrilla activity. Nevertheless, the president’s
increasing reliance on authoritarian measures and
an economic slump in the late 1990s generated
mounting dissatisfaction with his regime, which
led to his ouster in 2000. A caretaker government
oversaw new elections in the spring of 2001, which
installed Alejandro TOLEDO Manrique as the
new head of government—Peru''s first democrati-
cally elected president of indigenous Quechuan
ethnicity. The presidential election of 2006 saw
the return of Alan GARCIA Perez who, after a
disappointing presidential term from 1985 to 1990,
oversaw a robust economic rebound. In June 2011,
former army officer Ollanta HUMALA Tasso was
elected president, defeating Keiko FUJIMORI
Higuchi, the daughter of Alberto FUJIMORI.
Since his election, HUMALA has carried on the
sound, market-oriented economic policies of the
three preceding administrations.','bf3fbd5a3dae24f6af62b6e00132de8a9d652135c266fb2d3cb1bc96ae1be49d','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('faee5fb9e44550174c5bcafdce016b77023d65dbc09f3bb75f7a908e0e1f4c50',2025,'BA','Bosnia and Herzegovina','transnational-issues',266,'Disputes—international: Serbia delimited about
half of the boundary with Bosnia and Herzegovina,
but sections along the Drina River remain in dispute
Refugees and internally displaced persons:
refugees (country of origin): 6,769 (Croatia)
(2011)
IDPs: 113,000 (Bosnian Croats, Serbs, and Bos-
niaks displaced in 1992-95 war) (2011)
illicit drugs: increasingly a transit point for heroin
being trafficked to Western Europe; minor transit
point for marijuana; remains highly vulnerable
to money-laundering activity given a primarily
cash-based and unregulated economy, weak law
enforcement, and instances of corruption','80fdef01f089d544f2f1e6edcbc6e17d878dca96136b8a6e6e25b6c99cc999a0','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('98cf87b47a771773573b4be9a6fcb3419c4615cc9ae211de63123898531de3f1',2025,'BW','Botswana','transnational-issues',267,'KALAHARI
DESEAT
Morenaiote a
GABORONE t"
Kanye” 4
pea
\\
\\renavong
fad
Disputes—international: none','9eea6dd7428033f2956e85d53c85bdbdb636d397ac09a303a0e3d53ff60d7614','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f4cd15b70a3f133850886fc6a1f9e2126da4bbbf0f663975b417b5720ef18d98',2025,'NO','Norway','transnational-issues',281,'Disputes—international: none
Disputes—international: none
RIND AND
Mesing l
Be oee
perar Hana,
} OSLO
* Drammenyw ,
Fredrikstad, |
"havangern Mi
oe Kristansand
Disputes—international: Norway asserts a ter-
ritorial claim in Antarctica (Queen Maud Land
and its continental shelf); Denmark (Greenland)
and Norway have made submissions to the Com-
mission on the Limits of the Continental shelf
(CLCS) and Russia is collecting additional data to
augment its 2001 CLCS submission; Norway and
Russia signed a comprehensive maritime boundary
agreement in 2010
Refugees and internally displaced persons:
refugees (country of origin): 7,981 Somalia; 6,257
Iraq; 5,846 Eritrea; 5,733 Afghanistan (2011)','9d5b88f717d886a4da4632ae34492edd4ba921fac25fa02ea33a6e69fb961355','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e63aa0e5e8d89360edef38e9b4492e66f00a0693395034e6f8068a5cc2eb292f',2025,'BR','Brazil','transnational-issues',282,'>
ae Re
` { ARGENTINA #4).
x f ->
Disputes—international: uncontested boundary
dispute between Brazil and Uruguay over Brazili-
era/Brasiliera Island in the Quarai/Cuareim River
leaves the tripoint with Argentina in question;
smuggling of firearms and narcotics continues
to be an issue along the Uruguay-Brazil border;
Colombian-organized illegal narcotics and para-
military activities penetrate Brazil’s border region
with Venezuela
Illicit drugs: second-largest consumer of cocaine
in the world; illicit producer of cannabis; trace
amounts of coca cultivation in the Amazon region,
used for domestic consumption; government has a
large-scale eradication program to control canna-
bis; important, transshipment country for Boliv-
ian, Colombian, and Peruvian cocaine headed for
Europe; also used by traffickers as a way station
for narcotics air transshipments betw een Peru
and Colombia; upsurge in drug-related violence
and weapons smuggling; important market for
Colombian, Bolivian, and Peruvian cocaine; illicit
narcotics proceeds are often laundered.through the
financial system; significant illicit financial activ-
ity in the Tri-Border Area (2008)','46c1cb2d43f85c809a7331d57bbc6e14be9207b4695d2daaa454e0482a8ac801','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2b8d43bd7d7f091cbf971d8dadfbea5f63b33472e85aae599f2a7e88af420b08',2025,'ID','Indonesia','transnational-issues',293,'Disputes—international: Mauritius and Sey-
chelles claim the Chagos Islands; Negotiations
between 1971 and 1982 resulted in the estab-
lishment of a trust fund by the British Govern-
ment as compensation for the displaced islanders,
known as Chagossians, who were evicted between
1967-73; in 2001, the former inhabitants of the ;
archipelago were granted UK citizenship and
the right of return; in 2006 and 2007, British
court rulings invalidated the immigration poli-
cies contained in the 2004 BIOT Constitution
Order that had excluded the islanders from the
archipelago; in 2008 a House of Lords’ decision
overturned lower court rulings, once again deny-
ing the right of return to Chagossians; in addi-
tion, the United Kingdom created the world’s
largest marine protection area around the Chagos
islands prohibiting the extraction of any natural
resources therein
BRITISH VIRGIN ISLANDS
van Oko. ROAD
TOWN
Torna
ers
à Msa
)
Virgen talands
Disputes—international: none
Illicit drugs: transshipment point for South
American narcotics destined for the US and
Europe; large offshore financial center makes it
vulnerable to money laundering
Jerudong
e
BANDAR SERI%
BEDAWAN 8
Tutong»
Lumut,
Kuala »
Belat S08
Kampong} j Paoa
Lamunin |
.
l Lab
Disputes—international: per Letters of Exchange
signed in 2009, Malaysia in 2010 ceded two hydro-
carbon concession blocks to Brunei in exchange
for Brunei’s sultan dropping claims to the Limbang
corridor, which divides Brunei; nonetheless, Bru-
nei claims a maritime boundary extending as far as
a median with Vietnam, thus asserting an implicit
claim to Louisa Reef
Illicit drugs: drug trafficking and illegally import-
ing controlled substances are serious offenses in
Brunei and carry a mandatory death penalty
Disputes—internatlonal: Indonesia has a stated
foreign policy objective of establishing stable fixed
land and maritime boundaries with all of its neigh-
bors; three stretches of land borders with Timor-
Leste have yet to be delimited, two of which are
in the Oecussi exclave area, and no maritime or
Exclusive Economic Zone (EEZ) boundaries have
been established between the countries; many
refugees from Timor-Leste who left in 2003 still
reside in Indonesia and refuse repatriation; all bor-
ders between Indonesia and Australia have been
agreed upon bilaterally, but a 1997 treaty that
345
would settle- the last of their maritime and EEZ
boundary has yet to be ratified by Indonesia’s leg-
islature; Indonesian groups challenge Australia’s
claim to Ashmore Reef; Australia has closed parts
of the Ashmore and Cartier Reserve to Indonesian
traditional fishing and placed restrictions on cer-
tain catches; land and maritime negotiations with
Malaysia are ongoing, and disputed areas include
the controversial Tanjung Datu and Camar Wulan
border area in Borneo and the maritime bound-
ary in the Ambalat oil block in the Celebes Sea;
Tabriz
Now Shane
TEHRAN, a eee
Qom
« .
Kermanshah
Disputes—international: Iran protests Afghani-
stan’s limiting flow of dammed Helmand River
tributaries during drought; Iraq’s lack of a mari-
'' time boundary with Iran prompts jurisdiction
disputes beyond the mouth of the Shatt al Arab
in the Persian Gulf; Iran and UAE dispute Tunb
Islands and Abu Musa Island, which are occupied
by Iran; Azerbaijan, Kazakhstan, and Russia rati-
fied Caspian seabed delimitation treaties based on
equidistance, while Iran continues to insist on a
one-fifth slice of the sea; Afghan and Iranian com-
missioners have discussed boundary monument
densification and resurvey
Refugees ond internally displaced persons:
refugees (country of origin): 2.4 million (1 million
registered, 1.4 million undocumented) (Afghani-
stan); 42,500 (Iraq) (2013)
Trafficking in persons: current situation: Iran
is a source, transit, and destination country for
men, women, and children trafficked for the pur-
poses of sexual exploitation and involuntary servi-
tude; Iranian women are trafficked internally for
the purpose of forced prostitution and for forced
marriages to settle debts; Iranian and Afghan
children living in Iran are trafficked internally
for the purpose of forced marriages, commercial
sexual exploitation and involuntary servitude as
beggars or laborers to pay debts, provide income,
or support drug addiction of their families; press
reports indicate that criminal organizations play a
significant role in human trafficking to and from
Iran, in connection with smuggling of migrants,
drugs, and arms; Iranian women and children
are also subjected to sex trafficking in Pakistan,
Turkey, Qatar, Kuwait, the United Arab Emirates,
Bahrain, Iraq, France, Germany, and the United
Kingdom
tier rating: Tier 3—Iran did not report any law
enforcement efforts to punish trafficking offenders
and continues to lack any semblance of victim pro-
tection measures; victims of trafficking are, by gov-
ernment policy, detained and deported if foreign,
or simply jailed or turned away if Iranian; lack of
access to Iran by US Government officials impedes
the collection of information on the country''s
human trafficking problem and the government’s
efforts to curb it (2009)
licit drugs: despite substantial interdiction
efforts and considerable control measures along
the border with Afghanistan, Iran remains one
of the primary transshipment routes for South-
west Asian heroin to Europe; suffers one of the
highest opiate addiction rates in the world, and
has an increasing problem with synthetic drugs;
lacks anti-money laundering laws; has reached
out to neighboring countries to share counter-drug
intelligence
Putin: Mate
taquica, p iu
Ernera®
Pante A
Makasar, ,
“Manatuto id
Viqueques 2°" oo
ee
À “Suai','067ad28bd0d2eff16533c5c01949f2f540329382e15396a916400ea3402085cd','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('758be1ebb1ab34db09e7e1b6be5f509ce16a371dfe2b0a87511747903dd29777',2025,'BG','Bulgaria','transnational-issues',298,'—_ oes)
.
7 Rae obne n
Varna,
SOF IA
Stara Zagora,
Sneen,
Burgas,
howl
a Plovan
S *Biagoevaras
Kurdzhah,
sine
TURKEY
Disputes—international: none
illicit drugs: major European transshipment point
for Southwest Asian heroin and, to a lesser degree,
South American cocaine for the European market;
limited producer of precursor chemicals; vulnerable
to money laundering because of corruption, organ-
ized crime; some money laundering of drug-related
proceeds through financial institutions (2008)','5fc739f54a7083794810c6482769c7d56c24ce672971a984bddc6b371f58913b','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bd468c13faad165c510ce6f1eed7698809354c281bf0c490c291b5056e98a9aa',2025,'BF','Burkina Faso','transnational-issues',307,'| BURKINA FASO
GIVOIRE
Disputes—international: adding to illicit cross-
border activities, Burkina Faso has issues con-
cerning unresolved boundary alignments with
its neighbors; demarcation is currently underway
with Mali, the dispute with Niger was referred to
the IC] in 2010, and a dispute over several vil-
lages with Benin persists; Benin retains a border
dispute with Burkina Faso around the town of
Koualou
Refugees and internally displaced persons:
refugees (country of origin): 49,975 (Mali) (2013)
Trafficking in persons:
Burkina Faso is a country of origin, transit, and
destination for women and children subjected
to forced labor and sex trafficking; children are
forced to work as farm hands, gold panners and
washers, street vendors, domestic servants, and
beggars; girls are exploited in the commercial sex
trade; women from Burkina Faso are recruited for
legitimate jobs in Europe and are subsequently
forced into prostitution; West African women
are lured to Burkina Faso for legal work and are
forced into domestic servitude, prostitution, or
current situation:
forced labor
tier rating: Tier 2—Burkina Faso does not fully
comply with the minimum standards for the elimi-
nation of trafficking; however, it is making signifi-
cant efforts to do so; the government recognizes
that sex trafficking and forced labor are problems
and continued efforts to identify child victims;
steps have not been taken to identify adult victims
among vulnerable populations; the government
sustained anti-trafficking law enforcement efforts
but struggled to compile complete data on these
efforts (2012)
BURMA
Disputes—international: over half of Burma’s
population consists of diverse ethnic groups who
have substantial numbers of kin in neighbor-
ing countries; the Naf River on the border with
Bangladesh serves as a smuggling and illegal
transit route; Bangladesh struggles to accom-
modate 29,000 Rohingya, Burmese Muslim
minority from Arakan State, living as refugees
in Cox’s Bazar; Burmese border authorities are
constructing a 200 km (124 mi) wire fence
designed to deter illegal cross-border transit and
tensions from the military build-up along border
with Bangladesh in 2010; Bangladesh referred its
maritime boundary claims with Burma and India
to the International Tribunal on the Law of the
Sea; Burmese forces attempting to dig in to the
largely autonomous Shan State to rout local
militias tied to the drug trade, prompts local
residents to periodically flee into neighboring
Yunnan Province in China; fencing along the
India-Burma international border at Maniput’s
Moreh town is in progress to check illegal drug
trafficking and movement of militants; 140,000
mostly Karen refugees fleeing civil strife, politi-
cal upheaval and economic stagnation in Burma
live in remote camps in Thailand near the
border
Refugees and internally displaced persons:
IDPs: more than 454,200 (government offensives
against armed ethnic minority groups near its bor-
ders with China and Thailand) (2012)
Trafficking in persons: current situation:
Burma is a source country for women, children,
and men trafficked for the purpose of forced labor
and commercial sexual exploitation; Burmese
women and children are trafficked to East and
Southeast Asia for commercial sexual exploi-
tation, domestic servitude, and forced labor;
Burmese children are subjected to conditions of
forced labor in Thailand as haw kers and beg-
gats; women are trafficked for commercial sexual
exploitation to Malaysia and China; some traf-
ficking victims transit Burma from Bangladesh to
Malaysia and from China to Thailand; Burma''s
internal trafficking remains the most serious con-
cern occurring primarily from villages to urban
centers and economic hubs for labor in industrial
zones, agricultural estates, and commercial sexual
exploitation; the Burmese military continues to
engage in the unlawful conscription vf child sol-
diers, and continues to be the main perpetrator
of forced labor inside Burma; a small number of
foreign pedophiles occasionally exploit Burmese
children in the country l
tier rating: Tier 3—the driving factors behind
Burma’s significant trafficking problem are the
regime’s gross economic mismanagement and
human rights abuses, the military’s continued
widespread use of forced and child labor, and the
recruitment of child soldiers; although the govern-
ment of Burma has taken some steps to address
cross-border sex trafficking, it has not demon-
strated serious and sustained efforts to clamp down
on military and local authorities who are them-
selves deriving economic benefit from forced labor
practices (2010)
illicit drugs: world’s third largest producer of
illicit opium with an estimated production in 2009
of 250 metric tons, a decrease of 27%, and poppy
cultivation in 2009 totaled 17,000 hectares, a 24%
decrease from 2008; production in the United Wa
State Army’s areas of greatest control remains low;
Shan state is the source of 94.5% of Burma’s poppy
cultivation; lack of government will to take on
major narcotrafficking groups and lack of serious
commitment against money laundering continues
to hinder the overall antidrug effort; major source
of methamphetamine and heroin for regional con-
sumption (2008)','e87f83eede3cbb0412fe7b1f5c7a24525fb34ac043ff29b3fd2ceb39e9d2a550','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a7490f6faf9d5d93449e1114bd5953672cc9e018a653161ba826d6752aec5e5c',2025,'BI','Burundi','transnational-issues',321,'a
BYIGNDA
r=
T aoe Muy 7
*Cibroke . mon, d
Ngozi
-Bubanza
i „BUJUMBURA
Disputes—international: Burundi and Rwanda
dispute two sq km (0.8 sq mi) of Sabanerwa, a
farmed area in the Rukurazi Valley where the
Akanyaru/Kanyaru River shifted its course south-
ward after heavy rains in 1965; cross-border con-
flicts persist among Tutsi, Hutu, other ethnic
groups, associated political rebels, armed gangs,
and various government forces in the Great Lakes
region
Refugees and internally displaced persons:
refugees (country of origin): 39,713 (Democratic
Republic of the Congo) (2012)
IDPs: 78,800 (the majority are ethnic Tutsi dis-
placed by inter-communal violence that broke out
after the 1993 coup and fighting between govern-
ment forces and rebel groups; no new displace-
ments since 2008 when the last rebel group laid
down its arms) (2012)
*Stoeng Tréng
.
. =, Kampong rachen
, s 3
Background: Most Cambodians consider them-
selves to be Khmers, descendants of the Angkor
Empire that extended over much of Southeast
Asia and reached its zenith between the 10th
and 13th centuries. Attacks by the Thai and
Chami (from present-day Vietnam) weakened the
empite, ushering in a long period of decline. The
king placed the country under French protection
in 1863, and it became part of French Indochina
in 1887. Following Japanese occupation in World
War II, Cambodia gained full independence from
France in 1953. In April 1975, after a five-year
struggle, Communist Khmer Rouge forces cap-
tured Phnom Penh and evacuated all cities and
towns. At least 1.5 million Cambodians died from
execution, forced hardships, or starvation dur-
ing the Khmer Rouge regime under POL POT.
A December 1978 Vietnamese invasion drove
the Khmer Rouge into the countryside, began
a 10-year Vietnamese occupation, and touched
off almost 13 years of civil war. The 1991 Paris
Peace Accords mandated democratic elections
and a ceasefire, which was not fully respected by
the Khmer Rouge. UN-sponsored elections in
1993 helped restore some semblance of normalcy
under a coalition government. Factional fighting
in 1997 ended the first coalition government, but
a second round of national elections in 1998 led
to the formation of another coalition government
and renewed political stability. The remaining ele-
ments of the Khmer Rouge surrendered in early
1999. Some of the surviving Khmer Rouge lead-
ers have been tried or are awaiting trial for crimes
against humanity by a hybrid UN-Cambodian tri-
bunal supported by international assistance. Elec-
tions, in July 2003 were relatively peaceful, but it
took one year of negotiations between contending
political parties before a coalition government was
formed. In October 2004, King Norodom SIHA-
NOUK abdicated the throne and his son, Prince
Norodom SIHAMONI, was selected to succeed
him. Local elections were held in Cambodia in
April 2007, with little of the pre-election violence
that preceded prior elections. National elections
in July 2008 were relatively peaceful, as were com-
mune council elections in June 2012.','568d8eae6d279926a653d3f6c224b687c8ed077e53186b222b7be85003c5ebc8','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('dba9b0138094510afff1f7f68d85d2b8204b7fbd6b8564f27462154052a1ff05',2025,'KH','Cambodia','transnational-issues',339,'Disputes—international: Cambodia is con-
cerned about Laos’ extensive upstream dam
construction; Cambodia and Thailand dispute
sections of boundary; in 2011 Thailand and
Cambodia resorted to arms in the dispute over
the location of the boundary on the precipice
surmounted by Preah Vihear temple ruins,
awarded to Cambodia by IC] decision in 1962
and part of a planned UN World Heritage site;
Cambodia accuses Vietnam of a wide variety of
illicit cross-border activities; progress on a joint
development area with Vietnam is hampered by
an unresolved dispute over sovereignty of off-
shore islands
Wlicit drugs:
reportedly involving some in the government,
narcotics-related corruption
military, and police; limited methamphetamine
launder-
ing due to its cash-based economy and porous
borders
production; vulnerable to: money','9885cd68cc3f0f47df8eae01da37f729d5987545847c3a677ba38344c976b701','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('25c3a4bb94086ab5b641ee1c7afff0db7cecfacd41a5fe503c4ec87d66a08505',2025,'NG','Nigeria','transnational-issues',340,'s
on 3 if
Bamenda
# A Aar
? aNkunguamiba
Limboh eta Pòuala YAOUNDÉ
Torrinal oa
128
y iW
A “ig
MALABO, “TE CAMEROON
Lube 4 aaa
ista da bhon
224
Disputes—international: Joint Border Commis-
sion with Cameroon reviewed 2002 ICJ ruling
on the entire boundary and bilaterally resolved
differences, including June 2006 Greentree Agree-
ment that immediately cedes sovereignty of the
Bakassi Peninsula to Cameroon with a phase-
out of Nigerian control within two years while
resolving patriation issues; the IC] ruled on an
equidistance settlement of Cameroon-Equatorial
Guinea-Nigeria maritime boundary in the Gulf
of Guinea, but imprecisely defined coordinates in
the ICJ decision and a sovereignty dispute between
Equatorial Guinea and Cameroon over an island at
the mouth of the Ntem River all contribute to the
delay in implementation; only Nigeria and Cam-
eroon have heeded the Lake Chad Commission''s
admonition to ratify the delimitation treaty which
also includes the Chad-Niger and Niger-Nigeria
boundaries; location of Benin-Niger-Nigeria
tripoint is unresolved
Refugees and internally displaced persons:
refugees (country of origin): 5,299 (Liberia) (2011)
IDPs: undetermined (communal violence between
Christians and Muslims, political violence; flood-
ing; forced evictions; competition for resources;
displacement is mostly short-term) (2012)
Mlicit drugs: a transit point for heroin and cocaine
intended for European, East Asian, and North
American markets; consumer of amphetamines;
safe haven for Nigerian narcotraffickers operating
worldwide; major money-laundering center; mas-
sive corruption and criminal: activity; Nigeria has
improved some anti-money-laundering controls,
resulting in its removal from the Financial Action
Task Force’s (FATF’s) Noncooperative Countries
and Territories List in June 2006; Nigeria’s anti-
money-laundering regime continues to be moni-
tored by FATF','fa126670ec5b292e1ed068bc977cd4a98003cd76a5d636caa8c987a58e169ae0','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3ede0d51dc888b4940fcd229a83ac9aec41d7e44d2b62299e69de4ceb8108332',2025,'CA','Canada','transnational-issues',356,'Disputes—international: managed maritime
boundary disputes with the US at Dixon Entrance,
Beaufort Sea, Strait of Juan de Fuca, and the Gulf
of Maine including the disputed Machias Seal
Island and North Rock; Canada and the United
States dispute how to divide the Beaufort Sea and
the status of the Northwest Passage but continue to
work cooperatively to survey the Arctic continental
shelf; US works closely with Canada to intensify
security measures for monitoring and controlling
legal and illegal movement of people, transport,
and commodities across the international border;
sovereignty dispute with Denmark over Hans Island
in the Kennedy Channel between Ellesmere Island
and Greenland; commencing the collection of tech-
nical evidence for submission to the Commission
on the Limits of the Continental Shelf in support
of claims for continental shelf beyond 200 nautical
miles from its declared baselines in the Arctic, as
stipulated in Article 76, paragraph 8, of the United
Nations Convention on the Law of the Sea
Illicit drugs: illicit producer of cannabis for the
domestic drug market and export to US; use of
hydroponics technology permits growers to plant
large quantities of high-quality marijuana indoors;
increasing ecstasy production, some of which
is destined for the US; vulnerable to narcotics
money laundering because of its mature financial
services sector
135
THE CIA WORLD FACTBOOK
o SOTAVENTO
Séo
Tarratal ¢ » Tiago
Disputes—international: none
illicit drugs: used as a transshipment point
for Latin American cocaine destined for West-
ern Europe, particularly -because of Lusophone
links to Brazil, Portugal, and Guinea-Bissau;
has taken steps to deter drug money launder-
ing, including a 2002 anti-money laundering
reform that criminalizes laundering, the pro-
ceeds of narcotics trafficking and other crimes
and the establishment in 2008 of a Financial
Intelligence Unit (2008)','0c4993d70212b7c10b76e9b9c9fcdf7115bd4e0323e669ad196f85f698252113','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('516686f10ba69361fa012a8a09f2247048b4be96c7052d4210fdfdc89f6d9cf1',2025,'KY','Cayman Islands','transnational-issues',358,'Cayman
*
GEORGE TOWN
Disputes—international: none
Illicit drugs: major offshore financial center;
vulnerable to drug transshipment to the US and
Europe (2008)','7c68a55f5acdcb28f0b3cced58eabbb85550ada9c744a23c7909381321c4817c','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a989fb70be851719d1bf1bee6bc1767f77a251f8f601840fd894f6cb843d3e58',2025,'CF','Central African Republic','transnational-issues',368,'BDN w à
Nolav«.,.... BANGUI
—_—
W
wqo_..DEM. REP.
OF THE CONGO
Disputes— international: periodic skirmishes
over water and grazing rights among related pas-
toral populations along the border with southern
Sudan persist . ‘
Refugees and internally displaced persons:
refugees (country of origin): 14,910 (Democratic
Republic of the Congo) (2012)
IDPs: 224,953 (clashes between army and rebel
groups since 2005) (2013)
Trafficking in persons: current situation: Cen-
tral African Republic is a source, transit, and desti-
nation country for men, women, and children traf-
ficked for the purposes of forced labor and sexual
exploitation; the majority of victims are children
trafficked within the country for sexual exploita-
tion, domestic servitude, street vending, and forced
agricultural, mine, market and restaurant labor; to
a lesser extent, children are trafficked from the
Central African Republic to Cameroon, Nigeria,
Chad, Republic of the Congo, Sudan, and the
Democratic Republic of Congo; rebels continue to
abduct and exploit enslaved Sudanese, Congolese,
Central African, and Ugandan children for use as
cooks, porters, concubines, and combatants
tier rating: Tier 3—Central African Republic
does not fully comply with the minimum stand-
ards for the elimination of trafficking; the govern-
ment, which has limited human and physical cap-
ital, did not investigate and prosecute trafficking
offenses, identify or provide protective services to
trafficking victims, or take steps to raise public
awareness about the dangers of human trafficking;
the revised Central African penal code, enacted
in January 2010, outlaw s all forms of trafficking
in persons, but awareness of this statute remains
low (2008)','b03b49eab6d50d25cd93b6c3f417eb480e7280c5b8a74aeced867f933013ed79','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0ca5eeff66617da217d84d5f58a9039c24451e98f8b375931b8e42f4a7abbc0a',2025,'TD','Chad','transnational-issues',385,'Disputes—international: since 2003, ad hoc
armed militia groups and the Sudanese military have
driven hundreds of thousands of Darfur residents
into Chad; Chad wishes to be a helpful mediator
in resolving the Darfur conflict, and in 2010 estab-
lished a joint border monitoring force with Sudan,
147
which has helped to reduce cross-border banditry
and violence; only Nigeria and Cameroon have
heeded the Lake Chad Commission’s admonition
to ratify the delimitation treaty, which also includes
the Chad-Niger and Niger-Nigeria boundaries
Refugees and internally displaced persons: refu-
gees (country of origin): 298,311 (Sudan) (2011);
70,664 (Central African Republic) (2013)
IDPs: 90,000 (majority are in the east) (2012)
Trafficking in persons: current situation: Chad
is a source, transit, and destination country for
children trafficked for the purposes of forced:
THE CIA WORLD FACTBOOK
labor and commercial sexual exploitation; the
majority of children are trafficked within Chad
for involuntary domestic servitude, forced cattle
herding, forced begging, involuntary agricul-
tural labor, or for commercial sexual exploita-
tion; to a lesser extent, Chadian children are
also trafficked to Cameroon, the Central Afri-
can Republic, and Nigeria for cattle herding
tier rating: Tier 2 Watch List—the Government
of Chad does not fully comply with the minimum
standards for the elimination of trafficking; how-
ever, it is making significant efforts to do so; by
2011 the Government of Chad reportedly ended','fe235f40fb83550f651211049c74553be318e6fc37838a55e6097791a9ee3fd4','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a783b1b554180b0cc25b04bda7ff7f8695311f39a389501bfbcd6c5e656eee4b',2025,'CL','Chile','transnational-issues',386,'all child conscription into its national army and
continued to engage in efforts to demobilize
remaining child soldiers from rebel forces; fewer
efforts were made to address the forced labor of
children in cattle herding, domestic service, and
begging, or to combat the commercial sexual
exploitation of Chadian children; the government
did not enact legislation prohibiting trafficking
in persons and undertook limited anti-trafficking
law enforcement and victim protection activities
(2009)
* BOLIVIA
valparaiso, SANTIAGO
San Antonio» „» Rancagua
Sdn Vicente
Disputes—International: Chile and Peru rebuff
Bolivia''s reactivated claim to restore the Atacama
corridor, ceded to Chile in 1884, but Chile has
* offered instead unrestricted but not sovereign mari-
time access through Chile to Bolivian natural gas;
Chile rejects Peru’s unilateral legislation to change
its latitudinal maritime boundary with Chile to an
equidistance line with a southwestern axis favor-
ing Peru; in October 2007, Peru took its maritime
complaint with Chile to the JC); territorial claim in
Antarctica (Chilean Antarctic Territory) partially
overlaps Argentine and British claims; the joint
boundary commission, established by Chile and
Argentina in 2001, has yet to map and demarcate
the delimited boundary in the inhospitable Andean
Southern Ice Field (Campo de Hielo Sur)
illicit drugs: transshipment country for cocaine des-
tined for Europe and the region; some money laun-
dering activity, especially through the Iquique Free
Trade Zone; imported precursors passed on to Bolivia;
domestic cocaine consumption is rising, making
Chile a significant consumer of cocaine (2008)','77d37ba26e4e33579fbda4fdcb3c59d31437e7d6561e33482092418fc4654b84','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5c141024910137a3db75b6f7d12b31ea4c156093c66c2873a91dfb84591a11c4',2025,'CN','China','transnational-issues',399,'Disputes—international: continuing talks
and ‘confidence-building measures work toward
reducing tensions over Kashmir that nonetheless
remains militarized with portions under the de
facto administration of China (Aksai Chin), India
(Jammu and Kashmir), and Pakistan (Azad Kash-
mir and Northem Areas); India does not recognize
Pakistan’s ceding historic Kashmir lands to China
in 1964; China and India continue their security
and foreign policy dialogue started in 2005 related
to the dispute over most of their rugged, milita-
tized boundary, regional nuclear proliferation,
and other matters; China claims most of India’s
Arunachal Pradesh to the base of the Himalayas;
lacking any treaty describing the boundary, Bhu-
tan and China continue negotiations to establish
a common boundary alignment to resolve territo-
rial disputes arising from substantial cartographic
discrepancies, the largest of which lie in Bhutan’s
northwest and along the Chumbi salient; Burmese
forces attempting to dig in to the largely autono-
mous Shan State to rout local militias tied to the
drug trade, prompts local residents to periodically
flee into neighboring Yunnan Province in China;
Chinese maps show an international boundary
symbol off the coasts of the littoral states of the
South China Seas, where China has interrupted
Vietnamese hydrocarbon exploration; China
asserts sovereignty over Scarborough Reef along
with the Philippines and Taiwan, and over the
Spratly Islands together with Malaysia, the Phil-
ippines, Taiwan, Vietnam, and Brunei; the 2002
Declaration on the Conduct of Parties in the
South China Sea eased tensions in the Spratlys
but is not the legally binding code of conduct
sought by some parties; Vietnam and China con-
tinue to expand construction of facilities in the
Spratlys and in March 2005, the national oil com-
panies of China, the Philippines, and Vietnam
signed a joint accord on marine seismic activities
in the Spratly Islands; China occupies some of
the Paracel Islands also claimed by Vietnam and
Taiwan; China and Taiwan continue to reject
both Japan’s claims to the uninhabited islands of
Senkaku-shoto (Diaoyu Tai) and Japan’s unilater-
ally declared equidistance line in the East China
Sea, the site of intensive hydrocarbon exploration
and exploitation; certain islands in the Yalu and
Tumen rivers are in dispute with North Korea;
North Korea and China seek to stem illegal migra-
tion to China by North Koreans, fleeing priva-
tions and oppression, by building a fence along
portions of the border and imprisoning North
Koreans deported by China; China and Russia
have demarcated the once disputed islands at the
Amur and Ussuri confluence and in the Argun
River in accordance with their 2004 Agreement;
China and Tajikistan have begun demarcating the
revised boundary agreed to in the delimitation of
2002; the decade-long demarcation of the China-
Vietnam land boundary was completed in 2009;
citing environmental, cultural, and social con-
cerns, China has reconsidered construction of 13
dams on the Salw een River, but energy-starved
Burma, with backing from Thailand, remains
intent on building five hydro-electric dams down-
stream despite regional and international protests;
Chinese and Hong Kong authorities met in March
2008 to resolve ownership and use of lands recov-
ered in Shenzhen River channelization, including
96-hectare Lok Ma Chau Loop; Hong Kong devel-
oping plans to reduce 2,000 out of 2,800 hectares
of its restricted Closed Area by 2010
Refugees and internally displaced persons:
refugees (country of origin): 300,897 (Vietnam)
(2011); estimated 30,000-50,000 (North Korea)
IDPs: 90,000 (2010)
Trafficking in persons: current situation:
China is a source, transit, and.destination coun-
try for men, women, and children trafficked for
the purposes of sexual exploitation and forced
labor; the majority of trafficking in China occurs
within the country’s borders, there are reports
in recent years that Chinese men, women, and
children may be subjected to conditions of sex
trafficking and forced labor in numerous coun-
tries and territories worldwide; women and
children are trafficked to China from Burma,
Vietnam, Laos, Mongolia, Russia, North Korea,
Romania, and Zimbabwe for forced labor, mar-
tiage, and prostitution; some Chinese children
are forced into prostitution, and various forms
of forced labor, including begging, stealing, and
work in brick kilns and factories tier rating: Tier
2 Watch List—China does not fully comply with
the minimum standards for the elimination of
trafficking and did not demonstrate evidence
of significant efforts to address all forms of traf-
ficking or effectively protect victims; however,
China has increased its attention to trafficking
of women and children nationwide; China con-
tinues to lack a formal, nationwide procedure
to systematically identify victims of trafficking
(2008)
Illicit drugs: major transshipment point for her-
oin produced in the Golden Triangle region of
Southeast Asia; growing domestic consumption
of synthetic drugs, and heroin from Southeast
and Southwest Asia; source country for meth-
amphetamine and heroin chemical precursors,
despite new regulations on its large chemical
industry (2008)
Disputes—international: none
Iliclt drugs: despite strenuous law enforcement
efforts, faces difficult challenges in controlling tran-
sit of heroin and methamphetamine to regional and
world markets; modern banking system provides
conduit for money laundering; rising indigenous use
of synthetic drugs, especially among young people
from the Warsaw Pact were met with a massive
military intervention by Moscow. Under the lead-
ership of Janos KADAR in 1968, Hungary began
liberalizing its economy, introducing so-called
“Goulash Communism.” Hungary held its first
multiparty elections in 1990 and initiated a free
market economy. It joined NATO in 1999 and the
EU five years later. In 2011, Hungary assumed
the six-month rotating presidency of the EU for
the first time.
Disputes—international: none
Illicit drugs: transshipment point for drugs going
into mainland China; consumer of opiates and
amphetamines
443
THE CIA WORLD FACTBOOK
MACEDONIA
I Wim
2% a0 mm
KOSOVO
—"*
ee
7 N, BULGARIA
r
p
py
Golem - Gostwar
ean
¿Kumanovo
po KOPJE
Sto
v
Kievo
Prilep
pm
Bitola
Ue 5
nu pA GREECE
Disputes—international: Kosovo and Mac-
edonia completed demarcation of their boundary
in September 2008; Greece continues to reject
the use of the name Macedonia or Republic of
Macedonia
Illicit drugs: major transshipment point for
Southwest Asian heroin and hashish; minor tran-
sit point for South American cocaine destined for
Europe; although not a financial center and most
criminal activity is thought to be domestic, money
laundering is a problem due to a mostly cash-based
economy and weak enforcement','012bf69a724435dc0a898927e8c7c9e9ba91fad349e3e5a8b932054665cedb1d','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9e74761f38b4202ca010f892e0220d0fb0997b7e7fcb0ff017ec200f2785fd76',2025,'CO','Colombia','transnational-issues',412,'mavens e ‘
-i Klubo Cucuta
f Bucaramanga,
\\Medelin %
VENEZUELA
e
‘Pereira, “Rogota
R Ibaguesg *
Disputes—international: in December 2007,
ICJ allocated San Andres, Providencia, and Santa
Catalina islands to Colombia under 1928 Treaty
but did not rule on 82 degrees W meridian as
maritime boundary with Nicaragua; managed dis-
pute with Venezuela over maritime boundary and
Venezuelan-administered Los Monjes Islands near
the Gulf of Venezuela; Colombian-organized ille-
gal narcotics, guerrilla, and paramilitary activities
penetrate all neighboring borders and have caused
Colombian citizens to flee mostly into neighbor-
ing countries; Colombia, Honduras, Nicaragua,
Jamaica, and the US assert various claims to Bajo
Nuevo and Serranilla Bank
Refugees and internally displaced per-
sons: IDPs: 3.9-5.5 million (conflict between
government and illegal armed groups and drug
traffickers since 1985) (2011)
Iticit drugs: illicit producer of coca, opium poppy,
and cannabis; world’s leading coca cultivator with
116,000 hectares in coca cultivation in 2009, a 3%
decrease over 2008, producing a potential of 270
mt of pure cocaine; the world’s largest producer
of coca derivatives; supplies cocaine to nearly all
of the US market and the great majority of other
international drug markets; in 2010, aerial eradica-
tion dispensed herbicide to treat over 101,000 hec-
tares combined with manual eradication of 61,000
hectares; a significant portion of narcotics pro-
ceeds are either laundered or invested in Colombia
through the black market peso exchange; impor-
tant supplier of heroin to the US market; opium
poppy cultivation is estimated to have fallen to
1,100 hectares in 2009 while pure heroin produc-
tion declined to 2.1 mt; most Colombian heroin is
destined for the US market (2008)
Disputes—international: claims all of the area
west of the Essequibo River in Guyana, preventing
any discussion of a maritime boundary; Guyana has
expressed its intention to join Barbados in assert-
ing claims before the United Nations Convention
on the Law of the Sea that Trinidad and Tobago’s
maritime boundary with Venezuela extends into
their waters; dispute with Colombia over mari-
time boundary and Venezuelan administered Los
Monjes islands near the Gulf of Venezuela; Colom-
bian organized illegal narcotics and paramilitary
activities penetrate Venezuela’s shared border
region; in 2006, an estimated 139,000 Colombians
sought protection in 150 communities along the
border in Venezuela; US, France, and the Nether-
lands recognize Vénezuela’s granting full effect to
VENEZUELA
Aves Island, thereby claiming a Venezuelan Eco-
nomic Exclusion Zone/continental shelf extending
over a large portion of the eastern Caribbean Sea;
Dominica, Saint Kitts and Nevis, Saint Lucia, and
Saint Vincent and the Grenadines protest Ven-
ezuela’s full effect claim
Refugees and internally displaced persons:
refugees (country of origin): 201,941 (Colombia)
(2011)
Trafficking in persons: current situation: Ven-
ezuela is a source, transit, and destination country
for men, women, and children trafficked for the
purposes of commercial sexual exploitation and
forced labor; Venezuelan women and girls are traf-
ficked within the country for sexual exploitation,
lured from the nation’s interior to urban and tour-
ist areas; to a lesser extent, Brazilian women and
Colombian women are subjected to forced prosti-
tution; some Venezuelan women are transported
to Caribbean islands, particularly Aruba, Curacao,
and Trinidad & Tobago, where they are subjected
to forced prostitution
tier rating: Tier 3—the government investigated
potential cases of suspected human trafficking and
arrested at least 12 people for trafficking crimes
during the reporting period; however, there was no
further publicly available information regarding
those cases; Venezuela is not making significant
efforts to comply with the minimum standards for
the elimination of trafficking (2008)
Illicit drugs: small-scale illicit producer of opium
and coca for the processing of opiates and coca
derivatives; however, large quantities of cocaine,
heroin, and marijuana transit the country from
Colombia bound for US and Europe; significant
narcotics-related money-laundering activity, espe-
cially along the border with Colombia and on Mar-
garita Island; active eradication program primarily
targeting opium; increasing signs of drug-related
activities by Colombian insurgents on border
VIETNAM
Ch: Mirr
Cry','1a75c54cfc22b2946b2fcce9879c7b41711d294ea63814ab46190f42bd262f96','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('09fe8f7b81b7e1b575dd460842df74b3e27c8bdb995898b1d11d32973eba1cd5',2025,'KM','Comoros','transnational-issues',422,'G
* Grande Comore
(N gaziga)
MORDM
Pe
Ania
NAT MAY
Moutsamoudou, Tsimbeo
«Formoon Domon
Minyotie
A&rinistores by FRANCE
Gamod vy CON ISS
Disputes—international: claims French-admin-
istered Mayotte and challenges France''s and Mada-
gascar''s claims to’ Banc du Geyser, a drying reef in
the Mozambique Channel; in May 2008, African
Union forces were called in to assist the Comoros
military recapture Anjouan Island from rebels who
seized it in 2001
Li
CONGO, DEMOCRATIC REPUBLIC OFTHE
. Mbdup 1
Kikwit Kananga, „Mayi
Tshikapa','abf24cfefe5f9325097598251deaf2f611dc7b8d8d73fa5f510f07c7379fdbc5','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0ef61efbec5d0916197849901c3f008dcafae139df1e8b755df844595443bf55',2025,'ZM','Zambia','transnational-issues',438,'Disputes—Iinternational: heads of the Great
Lakes states and UN pledged in 2004 to abate
CONGO, DEMOCRATIC REPUBLIC OF THE
tribal, rebel, and militia fighting in the region,
including northeast Congo, where the UN Organ-
ization Mission in the Democratic Republic of the
Congo (MONUC), organized in 1999, maintains
over 16,500 uniformed peacekeepers; members of
Uganda''s Lords Resistance Army forces continue
to seek refuge in Congo’s Garamba National
Park as peace talks with the Uganda government
evolve; the location of the boundary in the broad
Congo River with the Republic of the Congo is
indefinite except in the Pool Malebo/Stanley Pool
area; Uganda and DRC dispute Rukw anzi Island
in Lake Albert and other areas on the Semliki
River with hydrocarbon potential; boundary com-
mission continues discussions over Congolese-
administered triangle of land on the right bank of
the Lunkinda River claimed by Zambia near the
DRC village of Pwet o; DRC accuses Angola of
shifting monuments
Refugees and internally displaced persons:
refugees (country of origin): 71,815 (Angola);
52,443 (Rwanda); 9,376 (Burundi) (2012); (Cen-
tral African Republic) (2013)
IDPs: 2,665,021 (fighting between government
forces and rebels since mid-1990s; most IDPs are
in eastern provinces) (2012)
Trafficking In persons: current situation:
Democratic Republic of the Congo is a source and
destination country for men, women, and children
subjected to trafficking for the purposes of forced
labor and forced -prostitution; the majority of
this trafficking is internal, and much of it is per-
petrated by armed groups and government forces
outside government control within the country’s
unstable eastern provinces; Congolese women
and children are exploited in forced prostitution,
domestic servitude, and forced agricultural labor
in Angola, South Africa, Republic of the Congo,
as well as East African, Middle’ Eastern, and Euro-
pean nations 5
tier rating: Tier 3—the Government of the Demo-
cratic Republic of the Congo does not fully comply
with the minimum standards for the elimination of
trafficking and is not making significant efforts to
do so; the government did not show evidence of
progress in prosecuting and punishing labor or sex
trafficking offenders, including members of its own
armed forces, in providing protective services for
the vast majority of trafficking victims, or in rais-
ing public awareness of human trafficking (2010)
Illicit drugs: one of Africa’s biggest producers of
cannabis, but mostly for domestic consumption;
traffickers exploit lax shipping controls to transit
pseudoephedrine through the capital; while ram-
pant corruption and inadequate supervision leaves
the banking system vulnerable to money launder-
ing, the lack of a well-developed financial system
limits the country’s utility as a money-laundering
center (2008)','41d83bb112f86a2975bf5ee2d501b03d2448ce48e0634407c21223013578cac8','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('dec01e46d98404891bd856657bc3339c9f0c7066d10fd9dd19d810e7f068486b',2025,'CK','Cook Islands','transnational-issues',439,'cS o
Kunn (A
or
nof‘ wall
eer A we bok
Background: Named after Captain COOK, who
sighted them in 1770, the islands became a British pro-
tectorate in 1888. By 1900, administrative control was
transferred to New Zealand; in 1965, residents chose
self-government in free association with New Zealand.
The emigration of skilled workers to New Zealand and
government deficits are continuing problems.
Disputes—international: none
173
THE CIA WORLD FACTBOOK
CORAL SEA ISLANDS
LELET
700
Wits {stats
7 Magociaine Cays
—Connga isieis
Ue oh islets
Herald Cays-—!
Townsville a
K Mackaye','4f6e2e7de1ac3e7a3883554fdbdb784ef3fde8fcb97f8389d8317d9e72bdb695','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('77024f58b4af5e926569ef3686a2bd7d0193eb3daf3fdee5fefc3c53e47ac29b',2025,'CR','Costa Rica','transnational-issues',447,'Alajue ia Peony
r A
SAN “Canago
JOSE Goro
a
.
San Isidro}
Puntarenas,
Caldera
Galtito 4
.
174
Disputes—international: the IC) had given
Costa Rica until January 2008 to reply and
Nicaragua until July 2008 to rejoin before ren-
dering its decision on the navigation, security,
and commercial rights of Costa Rican vessels on
the Rio San Juan over which Nicaragua retains
sovereignty
Refugees and internally dispiaced persons:
refugees (country of origin): 10,297 (Colombia)
(2011)
Illicit drugs: transshipment country for cocaine
and heroin from South America; illicit pro-
duction of cannabis in remote areas; domes-
tic cocaine consumption, particularly crack
cocaine, is rising; significant consumption of
amphetamines; seizures of smuggled cash in
Costa Rica and at the main border crossing to
enter Costa Rica from Nicaragua have risen in
recent years (2008)
COTE D''IVOIRE
UHRINA PAD
‘,
ae
u
Ns
5
g
=
= N i
7 "> ,Katiola 7 Bondoukou ¢
ve Toube: Séguéla g” * y
a. „Buake d
Milam Man in j l
I (Dai0g WAMOUSSOVKRO
y * Abengouro, ANA
‘Dimbokréi
Adzopé,
“Aghovity a
iy Acoso,
z Abian
& Srita?
Gagnea,
Die?
E thorn','58804dce275b985e4caed7b0e2835f2a45a7c5e4d2e588aa468285536290d2da','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f5f794254253bd83286754e22f7f10051d0d2f774718f9d387dc627bd64df5fc',2025,'MX','Mexico','transnational-issues',463,'Disputes—international: dispured maritime bor-
der between Cote d''Ivoire and Ghana
Refugees and internally displaced persons: refu-
gees (country of origin): 9,126 (Liberia) (2012)
IDPs: 40,000—80,000 (post-election conflict in
2010-2011, as well as civil war from 2002-2004;
most pronounced in westem and southwestern
regions) (2011)
Illicit drugs: illicit producer of cannabis, mostly
for local consumption; utility as a narcotic trans-
shipment point to Europe reduced by ongoing
political instability; while rampant corruption
and inadequate supervision leave the banking sys-
tem vulnerable to money laundering, the lack of
a developed financial system limits the country''s
utility as a major money-laundering center (2008)
Disputes—intemational: abundant rainfall in
recent years along much of the Mexico-US border
region has ameliorated periodically strained water-
sharing arrangements; the US has intensified secu-
rity measures to monitor and control legal and illegal
personnel, transport, and commodities across its bor-
der with Mexico; Mexico must deal with thousands
of impoverished Guatemalans and other Central
Americans who cross the porous border looking for
work in Mexico and the United States; Belize and
Mexico are working to solve minor border demarca-
tion discrepancies arising from in accuracies in the
1898 border treaty
Refugees and internally displaced persons:
IDPs: 160,000 (government’s quashing of Zapatista
uprising in 1994 in eastern Chiapas Region; drug
cartel violence and government''s military response
since 2007; violence between and within indig-
enous groups) (2011)
illicit drugs: major drug-producing and transit
nation; world’s second largest opium poppy culti-
vator; opium poppy cultivation in 2009 rose 31%
over 2008 to 19,500 hectares yielding a potential
production of 50 metric tons of pure heroin, or 125
metric tons of “black tar” heroin, the dominant form
of Mexican heroin in the western United States;
marijuana cultivation increased 45% to 17,500
hectares in 2009; government conducts the larg-
est independent illicit-crop eradication program
in the world; continues as the primary transship-
ment country for US-bound cocaine from South
America, with an estimated 95% of annual cocaine
movements toward the US stopping in Mexico;
major drug syndicates control the majority of drug
trafficking throughout the country; producer and
distributor of ecstasy; significant money-laundering
center; major supplier of heroin and largest foreign
supplier of marijuana and methamphetamine to the
US market (2007)
Disputes—international: none
Illicit drugs: major consumer of cannabis
a
| MOLDOVA','051e8f42277a2706ba98c2f1cc80be3631068b10213ae5cea41d3c45ff4223a3','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f9cf32813607162b381c35566066e43bac411b7e48bad07a4efa672fc6bd3b52',2025,'HR','Croatia','transnational-issues',464,'„ ae ena
rons N namaa d
i ZAGREB re
T y Cy Osijek, Pais
ee” ep Sisak
eaea MA š
SAA
fi
Vukovar **
*Gumsal A m
a = f 4 eS
>
k BOSNIA AND }
Zoa N HERZEGOVINA
Anas N
> Senki
smy
Y
Plates ~^
By
n MUNI
TAN
Dubrovnik®™ i
Disputes—international: dispute remains with
Bosnia and Herzegovina over several small sec-
tions of the boundary related to maritime access
that hinders ratification of the 1999 border
THE CIA WORLD FACTBOOK
agreement; the Croatia-Slovenia land and mari-
time boundary agreement, which would have
ceded most of Pirin Bay and maritime access to
Slovenia and several villages to Croatia, remains
unratified and in dispute; Slovenia also protests
Croatia’s 2003 claim to an exclusive economic
zone in the Adriatic; as a European Union
peripheral state, Slovenia imposed a hard border
Schengen regime with non-member Croatia in
December 2007
Illicit drugs: transit point along the Balkan route
for Southw est Asian heroin to Western Europe;
has been used as a transit point for maritime ship-
ments of South American cocaine bound for West-
em Europe (2008)','a25ce7b11645d9e1e9ef437d801c89e785466ac511d92c6550afd1f429f334fd','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8271ee8a3c388c4ffa6f1ce684b90dd19a54c4d62025da1341e99173806861b2',2025,'CU','Cuba','transnational-issues',482,'Disputes—international: US Naval Base at
Guantanamo Bay is leased to US and only mutual
agreement or US abandonment of the facility can
terminate the lease z
Trafficking in persons: current situation: Cuba
is a source country for adults and some chil-
dren subjected to forced labor and sex traffick-
ing; prostitution of children reportedly occurs
in Cuba as prostitution is not criminalized for
anyone above 16 years old; the scope of traffick-
ing within Cuba is particularly difficult to gauge
due to the closed nature of the government
and sparse non-governmental or independent
reporting
tier rating: Tier 3—Cuba does not fully comply
with the minimum standards for the elimination
of trafficking and is not making significant efforts
to do so; the government did not publicize infor-
mation about government measures to address
human trafficking through prosecution, protec-
tion, or prevention efforts during the reporting
period (2010)
Hlicit drugs: territorial waters and air space serve
as transshipment zone for US-and European-
bound drugs; established the death penalty for cer-
tain drug-related crimes in 1999 (2008)
189','083f248a15ed16d21d28adaf8dcbee78f65924b7eb5b3ff4fcdf4725d66d76b3','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('06a6f4a3955fb2959c3a0a1de339bd3ea422a31d04fbc1f427c2c4bf57876601',2025,'DK','Denmark','transnational-issues',501,'Disputes—international: Iceland, the UK, and
Ireland dispute Denmark’s claim that the Faroe
Islands’ continental shelf extends beyond 200 nm;
Faroese continue to study proposals for full inde-
pendence; sovereignty dispute with Canada over
Hans Island in the Kennedy Channel between
Ellesmere Island and Greenland; Denmark
(Greenland) and Norway have made submissions
to the Commission on the Limits of the Conti-
nental Shelf (CLCS) and Russia is collecting addi-
tional data to augment its 2001 CLCS submission
Disputes—international: because anticipated
offshore hydrocarbon resources have not been real-
ized, earlier Faroese proposals for full independ-
ence have been deferred; Iceland, the UK, and
Ireland dispute Denmark’s claim’ that the Faroe
Islands’ continental shelf extends beyond 200 nm','2d8acd0779847663d324a8cf43ea9d63a914f81c9f0c51e48d2724e4b4be29c0','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0724fee3da26174b0570ab7a732c21c879a78ecb0604bffa67300612a5587b34',2025,'DJ','Djibouti','transnational-issues',514,'Disputes—international: Djibouti maintains
economic ties and border accords with “Somali-
land” leadership while maintaining some political
ties to various factions in Somalia; Kuwait is chief
investor in the 2008 restoration and upgrade of
the Ethiopian-Djibouti rail link; in Z008, Eritrean
troops moved across the border on Ras Doumera
peninsula and occupied Doumera Island with
undefined sovereignty in the Red Sea
Refugees and internally displaced persons:
refugees (country of origin): 18,725 (Somalia)
(2013)','411985c59dd19724ecce47b875e026ae8d60a265c82e4d4b63746c312d4fd8b4','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a52de73c8f10cd79672cbfb5b08344254f338c1a17a193bea70f486726d2f9f9',2025,'DM','Dominica','transnational-issues',515,'*Partsmouth
Marigot,
x
Morne Oabionay
Saint
-Jusept
La Plane,
„ROSEAU
Berekua
>
Disputes—international: Dominica is the only
Caribbean state to challenge Venezuela’s sover-
eignty claim over Aves Island and joins the other
island nations in challenging whether the feature
sustains human habitation, a criterion under the UN
Convention on the Law of the Sea (UNCLOS),
which permits Venezuela to extend its Exclusive
Economic Zone (EEZ) and continental shelf claims
over a large portion of the eastern Caribbean Sea
Illicit drugs: transshipment point for narcotics
bound for the US and Europe; minor cannabis
producer (2008)','7e44fee1acbfd712d6aa99a927a8a741400acbb2c363a13b4c240ea3d56479fc','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f1712062bac0dd2c2e7b54e0a1019ae738ff28013439e0dbdaa63f9077632a2e',2025,'DO','Dominican Republic','transnational-issues',525,'Hispaniola
~
Disputes—international: Haitian migrants cross
the porous border into the Dominican Republic
to find work; illegal migrants from the Domini-
can Republic cross the Mona Passage each year to
Puerto Rico to find better work
illicit drugs: transshipment point for South
American drugs destined for the US and Europe;
has become a transshipment point for ecstasy from
the Netherlands and Belgium destined for US and
Canada; substantial money laundering activity in
particular by Colombian narcotics traffickers; sig-
nificant amphetamine consumption (2008)','852c258611dd99e10ea784a856fa9bb05b985db6dd3208af95db622ce5642a54','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d428a15cb60b6faa0a97538afa12f379bfa9ff405986888beaef7c994a64be4f',2025,'EC','Ecuador','transnational-issues',539,'Disputes—international: organized illegal nar-
cotics operations in Colombia pénetrate across
Ecuador’s shared border, which thousands of
Colombians also cross to escape the violence in
their home country
Refugees and internally displaced persons:
refugees (country of origin): 122,587 (Colombia)
(2011)
Illicit drugs: significant transit country for
cocaine originating in Colombia and Peru, with
much of the US-bound cocaine passing through
Ecuadorian Pacific waters; importer of precursor
chemicals used in production of illicit narcotics;
attractive location for cash-placement by drug
traffickers laundering money because of dollari-
zation and weak anti-meney-laundering regime;
increased activity on the northern frontier by
trafficking groups. and Colombian insurgents
(2008)
Satajan
AlKhamah, . Uara','3900679f45aed28a19fbd08d530b2e7454a08803518b8d63463d4ac5f7fb3f39','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e79ef1e166df89162659cfa8aa25b626b77a775911b12f30a059d09f98a2e150',2025,'EG','Egypt','transnational-issues',550,'Disputes—international: Sudan claims but
Egypt de facto administers security and economic
development of Halaib region north of the 22nd
parallel boundary; Egypt no longer shows its
administration of the Bir Tawil trapezoid in Sudan
on its maps; Gazan breaches in the security wall
with Egypt in January 2008 highlight difficulties in
monitoring the Sinai border; Saudi Arabia claims
Egyptian-administered islands of Tiran and Sanafir
Refugees and internally displaced persons:
refugees (country of origin): 70,029 (West Bank
and Gaza Strip); 10,324 (Sudan); 6,037 (Iraq)
(2011); 71,812 (Syria); 7,702 (Somalia) (2013)
Wlicit drugs: transit point for cannabis, heroin,
and opium moving to Europe, Israel, and North
Africa; transit stop for Nigerian drug couriers; con-
cern as money laundering site due to lax enforce-
ment of financial regulations','f4a1ca4c1c4d662ca0215b867f8fb1111a2c5a448e5a02e9191f9ba4e0700d63','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e22987c1f65dac769f71c04258d44f2fdc663e059ee231b72b5f9a20dc3369a0',2025,'SV','El Salvador','transnational-issues',551,'l EL SALVADOR
ta
Disputes—international: International Court
of Justice (ICJ) ruled on the delimitation of “bol-
sones” (disputed areas) along the El Salvador-
Honduras boundary, in 1992, with final agreement
by the parties in 2006 after an Organization of
American States survey and a further ICJ ruling in
2003; the 1992 IC] ruling advised a tripartite reso-
lution to a maritime boundary in the Gulf of Fon-
seca advocating Honduran access to the Pacific; El
Salvador continues to claim tiny Conejo Island,
not identified in the IC] decision, off Honduras in
the Gulf of Fonseca
illicit drugs: transshipment point for cocaine;
small amounts of marijuana produced for local
consumption; significant use of cocaine','e6c40a14802b569a9429e8c4baefb04b645af5bb5c89b4c2d2ee77597ec2626b','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('58871598b08dece94ddf83bf18a991fac10c6009e395e8c4487ebbe3d78e23dc',2025,'GT','Guatemala','transnational-issues',552,'r HONDURAS
Came Et Pital
a
BELIZE .
MERO
Puero e
Coban, Pana Tomas
Huehuetenango
vaer
a
Quetzaltenango
«Coatepeque GUATEMALA
s Muxcoe® CITY
Mazatenango
Quetzal
Disputes—international: annual ministerial
meetings under the Organization of American
States-initiated Agreement on the Framework
for Negotiations and Confidence Building Meas-
ures continue to address Guatemalan land and
maritime claims in Belize and the Caribbean Sea;
Guatemala persists in its territorial claim to half
of Belize, but agrees to Line of Adjacency to keep
Guatemalan squatters out of Belize’s forested inte-
rior; both countries agreed in April 2012 to hold
simultaneous referenda, schéduled for 6 October
2013, to decide whether to refer the dispute to the
IC) for binding resolution; Mexico must deal with
thousands of impoverished Guatemalans and other
Central Americans who cross the porous border
looking for work in Mexico and the United States
Refugees and internally displaced persons:
IDPs: undetermined (more than three decades
of internal conflict that ended in 1996 displaced
mainly the. indigenous Maya population and rural
peasants; ongoing drug cartel and gang violence)
(2011)
illicit drugs: major transit country for cocaine
and heroin; in ~2005, cultivated 100 hectares
of opium poppy after ‘reemerging as a potential
source of opium in 2004; potential production of
less than 1 metric ton of pure heroin; marijuana
cultivation for mostly domestic consumption;
proximity to Mexico makes Guatemala a major
staging area for drugs (particularly for cocaine);
money laundering is a serious problem; corruption
is a major problem','03ae5145ad1fed85244d226c5fd289f307d2f79b36c5e35cfc6776cff48a238e','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8b6af937b012bbf306f9d142c89f72c74db437e69dde55e19643db5a6cdbf795',2025,'GQ','Equatorial Guinea','transnational-issues',568,'Disputes—intemational: in 2002, ICJ ruled on an
equidistance settlement of Cameroon-Equatorial
Guinea-Nigeria maritime boundary in the Gulf of
Guinea, but a dispute between Equatorial Guinea
and Cameroon over an island at the mouth of the
Ntem River and imprecisely defined maritime coor-
dinates in the IC] decision delayed final delimita-
tion; UN urged Equatorial Guinea and Gabon to
resolve the sovereignty dispute over Gabon-occu-
pied Mbane and lesser islands and to create a mari-
time boundary in the hydrocarbon-rich Corisco Bay
Trafficking in persons: current situation: Equa-
torial Guinea is primarily a destination country for
children trafficked for the purpose of forced labor
and possibly for the purpose of sexual exploita-
tion; children have been trafficked from nearby
countries for domestic servitude, market labor,
ambulant vending, and possibly sexual exploita-
tion; women may also be trafficked to Equatorial
Guinea from Cameroon, Benin, other neighboring
countries, and China for sexual exploitation
tier rating: Tier 3—Equatorial Guinea is not mak-
ing significant efforts to comply with the minimum
standards on the elimination of trafficking; despite
limited law enforcement action against suspected
human smugglers and traffickers, including com-
plicit public officials, the government has made
no tangible efforts to provide victims of taffick-
ing with the protective services mandated in its
2004 anti-trafficking law; prevention efforts have
decreased, as the government did not hold any
public awareness campaigns and its interagency
commission on human trafficking took little, if any,
action; the government''s response to human traf-
ficking has been inadequate, particularly given the
government''s substantial financial resources (2008)
227
THE CIA WORLD FACTBOOK
z
sunas arnt
i
f Nakfa,
aa
t
Ak''ordate
at DURAN
ZE ARCHIPELAGO
ETHIOPIA a
Depa FoF
wama A
0 50 IMam
np
C] 60 100 mi','78766f5356a39377819cb33222d069ce370bc88fb0042ca3e702b4e97c83f2a2','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ec207493da60c3a076cd7d7c43e0a86bb6eb4cc1715f11ccc687aff158ec262a',2025,'ER','Eritrea','transnational-issues',576,'Disputes—international: Eritrea and Ethiopia
agreed to abide by 2002 Ethiopia-Eritrea Bound-
ary Commission’s (EEBC) delimitation decision
but, neither party responded to the revised line
detailed in the November 2006 EEBC Demarca-
tion Statement; Sudan accuses Eritrea of sup-
porting eastern Sudanese rebel groups; in 2008
Eritrean troops moved across the border on Ras
Doumera peninsula and occupied Doumera Island
with undefined sovereignty in the Red Sea
Refugees and internally displaced persons: `
IDPs: 10,000 (border war with Ethiopia from
1998-2000; it has not been possible to confirm
whether remaining IDPs are still living with hosts
or have been returned or resettled) (2009)
Trafficking in persons: current situation: Eri-
trea is a source country for men, women, and
children trafficked for the purposes of forced labor
and commercial sexual exploitation; each year,
large numbers of migrant workers depart Eritrea
in search of work, particularly in the Gulf States,
where some are likely to become victims of forced
labor, including in domestic servitude, or com-
mercial sexual exploitation; Eritrean children
also work in various economic sectors, including
domestic service, street vending, small-scale fac-
tories, and agriculture; child laborers frequently
suffer abuse from their employers and some may be
subjected to conditions of forced labor
tier rating: Tier 3—the Government of Eritrea
does not fylly comply with the minimum stand-
ards for the elimination of trafficking and is not
making significant efforts to do so; the Eritrean
Government does not operate with transparency
and published neither data nor statistics regarding
its efforts to combat human trafficking; the gov-
ernment made no known progress in prosecuting
and punishing trafficking crimes over the reporting
period and did not appear to provide any signifi-
cant assistance to victims of trafficking (2009)
-P 7 e
— il
ae
i
Mauga Kunda Nan
g Maug unda entis ‘>
Pariski
“* TALLINN ake
Pane
“Haapsalu s','1a770792e59d157d82f9dd5ff06e816aefa41ee70a36e9bafcfe1801913cb58c','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('905bd53728b4e373f2d6e83d50b8fc294100262dcf925dec2e326ed4b7e335fb',2025,'EE','Estonia','transnational-issues',586,'Disputes—international: Russia and Estonia in
May 2005 signed a technical border agreement,
bur Russia in June 2005 recalled its signature after
the Estonian parliament added to its domestic rati-
fication act a historical preamble referencing the
Soviet occupation and Estonia’s pre-war borders
under the 1920 Treaty of Tartu; Russia contends
that the preamble allows Estonia to make territo-
rial claims on Russia in the future, while Estonian
officials deny that the preamble has any legal
impact on the treaty text; Russia demands better
treatment of the Russian-speaking population in
Estonia; as a member state that forms part of the
EU’s external border, Estonia implements strict
Schengen border rules with Russia
Illicit drugs: growing producer of synthetic drugs;
increasingly important transshipment zone for
cannabis, cocaine, opiates, and synthetic drugs
since joining the European Union and the Schen-
gen Accord; potential money laundering related to
organized crime and drug trafficking is a concern,
as is possible use of the gambling sector to launder
funds; major use of opiates and ecstasy','91a2b6e5e7fd36d10af9e93c9251ee9394e90f188b6d4c6aa456ed4aa046880f','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8303c9c634cf3bd6f21995cb280c1bde0f36b7c90593a63973b65ebd1bbd7777',2025,'SO','Somalia','transnational-issues',592,'Disputes—international: Eritrea and Ethiopia
agreed to abide by the 2002 Eritrea-Ethiopia
Boundary Commission''s (EEBC) delimitation
decision, but neither party responded to the
revised line detailed in the November 2006
EEBC Demarcation Statement; the undemar-
cated former British administrative line has
little meaning as a political separation to rival
clans within Ethiopia''s Ogaden and south-
em Somalia’s Oromo region; Ethiopian forces
invaded southern Somalia and routed Islam-
ist Courts from Mogadishu in January 2007;
“Somaliland” secessionists provide port facilities
in Berbera and trade ties to landlocked Ethio-
pia; civil unrest in eastern Sudan has hampered
efforts to demarcate the porous boundary with
Disputes—international: Ethiopian forces
invaded southern Somalia and routed Islamist
Courts from Mogadishu in January 2007; “Somali-
land” secessionists provide port facilities in Ber-
bera to landlocked Ethiopia and have established
commercial ties with other regional states; “Punt-
land” and “Somaliland” “governments” seek inter-
national support in their secessionist aspirations
and overlapping border claims; the undemarcated
fotmer British administrative line has little mean-
ing as a political separation to rival clans within
Ethiopia’s Ogaden and southern Somalia’s Oromo
region; Kenya works hard to prevent the clan and
militia fighting in Somalia from spreading south
across the border, which has long been open to
nomadic pastoralists
Refugees and internally displaced persons:
IDPs: 1.1 million (civil war since 1988, clan-based
competition for resources; 2011 famine; insecurity
because of fighting between al-Shabaab and TFG
allied forces) (2012)
a republic in 1961 after a whites-only referendum.
In 1948, the National Party was voted into power
and instituted a policy of apartheid—the separate
development of the races—which favored the
white minority at the expense of the black major-
ity. The African National Congress (ANC) led
the opposition to apartheid and many top ANC
leaders, such as Nelson MANDELA, spent decades
in South Africa’s prisons. Internal protests and
insurgency, as well as boycotts by some Western
nations and institutions, led to the regime’s even-
` tual willingness to negotiate a peaceful transition
to majority rule. The first multi-racial elections
in 1994 brought an end to apartheid and ushered
in majority rule under an ANC-led government.
South Africa since then has struggled to address
apartheid-era imbalances in decent housing,
education, and health care. ANC infighting,
which has grown in recent years, came to a head
in September 2008 when President Thabo MBEKI
resigned, and Kgalema MOTLANTHE, the party’s
General-Secretary, succeeded him as interim presi-
dent. Jacob ZUMA became president after the
ANC won general elections in April 2009.','f4ad0a0cd02504540f6a60e38c7b28e373603f6971d5aeeb2d89800fb6a7add3','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8b2472f3add93d8fbaea8b1a9f1c919e15546d5f7f26d1df718a4f5ac9485d80',2025,'ET','Ethiopia','transnational-issues',593,'Refugees and internally displaced persons:
refugees (country of origin): 238,845 (Somalia);
88,462 (Sudan); 62,996 (Eritrea) (2013)
IDPs: 200,000-300,000 (border war with Eritrea
from 1998-2000, ethnic clashes in Gambela, and
ongoing Ethiopian military counterinsurgency in
Somali region; most IDPs are in Tigray and Gamb-
ela Provinces) (2008)
illicit drugs: transit hub for heroin originating
in Southwest and Southeast Asia and destined
for Europe, as well as cocaine destined for mar-
kets in southern Africa; cultivates gat (khat) for
local use and regional export, principally to Dji-
bouti and Somalia (legal in all three countries);
the lack of a well-developed financial system
limits the country’s utility as a money launder-
ing center
EUROPEAN UNION
EUROPEAN UNION
Disputes—international: as a political union,
the EU has no border disputes with neighboring
EUROPEAN UNION
countries, but Estonia has no land boundary
agreements with Russia, Slovenia disputes its
land and maritime boundaries with Croatia, and
Spain has territorial and maritime disputes with
Morocco and with the UK over Gibraltar; the
EU has set up a Schengen area—consisting of 22
EU member states that have signed the conven-
tion implementing the Schengen agreements
or “acquis” (1985 and 1990) on the free move-
ment of persons and the harmonization of bor-
der controls in Europe; these agreements became
incorporated into EU law with the implemen-
tation of the 1997 Treaty of Amsterdam on 1
May 1999; in addition, non-EU states Iceland
and Norway (as part of the Nordic Union) have
been included in the Schengen area since 1996
(full members in 2001), Switzerland since 2008,
and Liechtenstein since 2011 bringing the total
current membership to 26; the UK (since 2000)
and Ireland (since 2002) take part in only some
aspects of the Schengen area, especially with
respect to police and criminal matters; nine of
the 12 new member states that joined the EU
since 2004 joined Schengen on 21 December
2007; of the three remaining EU states, Roma-
nia and Bulgaria may join in 2013 or 2014, while
Cyprus’ entry is held up by the ongoing Cyprus
dispute
243
FALKLAND ISLANDS (ISLAS MALVINAS)
West
Faikiand por Howard, í. &
bount ^
Ustawa
& *
\\ STANLEY
Goose Green
Settlement
Weddett
eoettiomant
East
Arkninvgtered by 1 K
damed by BPGENTNA
Q 2 kn
C an
Disputes—international:. Argentina, which
claims the islands in its constitution and briefly
occupied them by force in 1982, agreed in 1995
to no longer seek settlement by force; UK contin-
ues to reject Argentine requests for sovereignty
talks
245
THE CIA WORLD FACTBOOK
ae“ gaor
w“ (6 SOMALIA
ger.
- ,Beledweyne
„Baydhabo
MOGADISHU A','a14eb8b6bfe4a246f3df7dd8c93d4b26c5c1bcb0bce8c97b8209780a1c9985a0','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('991e6a15e2507e0b496b02e46e7de75228fc632bc1d296d92855d842d1055365',2025,'FO','Faroe Islands','transnational-issues',596,'rans R VY
Fugoy
Streymoy: >£- Siena Siny
Fugtationynur®
¿Klaksvik
Borpoy
Eysturoy
ATÓRSHAVN','b0027c885c2852466b924e7827760bd5e4bfb61f77795213fa8cb9756b465b6b','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9a614c965354435562f5583ac3b17489f4b20453299a5334dc9c7837a30a6705',2025,'FI','Finland','transnational-issues',617,'Disputes—international: various groups in Fin-
land advocate restoration of Karelia and other
areas ceded to the Soviet Union, but the Finnish
Government asserts no territorial demands
| FRANCE
Ounxerque,
p GERMANY
| GF
Ag aoe pa.
aen i Ne:
Steasboue
PARIS? © nany 4
<Ongans O
Dion gr E
We 3
T e
Cremourge
Brest
m Fours
* z a
- Nantes 5
Fs
igs)
au.
x
Marseite
Background: France today is one of the most mod-
em countries in the world and is a leader among
European nations. It plays an influential global
role as a permanent member of the United Nations
Security Council, NATO, the G-8, the G-20, the
EU and other multilateral organizations. France
rejoined NATO”s integrated military command
structure in 2009, reversing de Gaulle”s 1966 deci-
sion to take French forces out of NATO. Since
1958, it has constructed a: hybrid presidential-
parliamentary governing system resistant to the
instabilities experienced in earlier, more purely
parliamentary administrations. In recent decades,
its reconciliation and cooperation with Germany
have proved central to the economic integra-
tion of Europe, including the introduction of a
common currency, the euro, in January 1999. In
the early 21st century, five French overseas enti-
ties—French Guiana, Guadeloupe, Martinique,
Mayotte, and Reunion—became French regions
and were made part of France proper.','1b84090e62a849100c251bececb71727c9b8b77b1d70412468119da7da3c01d3','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('87bbb92d772ff3c2613efc887d4ca9dc2774bd3260a53258eb58d55f46048a88',2025,'MU','Mauritius','transnational-issues',634,'claim to
aS
LIBREVILLE
Riwu to
P3: Gente
dastoursyil
7 * ambarene
Koala Oto
oi 4 =
Gs wine
THE CONGO
SO 100km
EJ 300 mi
Disputes—international: Mauritius and Sey-
chelles claim the Chagos Islands; claims French-
administered Tromelin Island
Illicit drugs: consumer and transshipment point
for heroin from South Asia; small amounts of
cannabis produced and consumed locally; signifi-
cant offshore financial industry creates potential
for money laundering, but cormuption levels are
relatively low and the government appears gen-
erally to be committed to regulating its banking
industry
Mexicos powerful drug-trafficking organizations
have engaged in bloody feuding, resulting in tens
of thousands of drug-related homicides.','5c5692a55659bbbb31b2dd0d56951ef24176cd3c8fb6f686d92a4c88218f9505','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bc60e4f062f94d5109188305a8dc13c8388cb4bf3b8cf5e6c1775e59d634c303',2025,'GA','Gabon','transnational-issues',644,'Disputes—international: UN urges Equato-
rial Guinea and Gabon to resolve the sover-
eignty dispute over Gabon-occupied Mbane
Island and lesser islands and to establish a mar-
itime boundary .in hydrocarbon-rich Corisco
Bay
GAMBIA, THE
e','28b00d4c5e353226a0a431296427d85d2b5929f6f8036beca0e1430534247328','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('19edd10552fa311568db5a2ff67fd69b3764ce2cc2e933177a61da425f319182',2025,'SN','Senegal','transnational-issues',645,'ot WAR I
Disputes—international: attempts to stem refu-
gees, cross-border raids, arms smuggling, and other
illegal activities by separatists from southern Sen-
egal’s Casamance region, as well as from conflicts
in other west African states
Refugees and internally displaced persons:
refugees’ (country of origin): 8,359 (Senegal)
(2011)
GAZA STRIP
The state at the Gaza Sing =
e RPE Te te
Disputes—international: the current status of
Gaza Strip is subject to the Israeli-Palestinian
Interim Agreement with permanent status to be
determined through further negotiation; Israel
removed settlers and military personnel from Gaza
Strip in August 2005
Refugees and internally displaced persons:
refugees (country of origin): 1.167 million (Pal-
estinian refugees (UNRWA) (2012)
IDPs: 160,000 (persons displaced within both the
Gaza strip and the West Bank since 1967; as esti-
mated by unofficial sources) (2011)
in river valley flood plains, foothills of Kolkhida
Low land
Elevation extremes: lowest point: Black Sea 0 m
highest point: Mt’a Shkhara 5,201 m
Natural resources: timber, hydropower, manga-
nese deposits, iron ore, copper, minor coal and oil
deposits; coastal climate and soils allow for impor-
tant tea and citrus growth
Land use: arable land:5.94%
permanent crops: 1.65%
other: 92.41% (2011)
Irrigated iand: 4,328 sq km (2007)
Total renewable water resources: 63.33 cu km
(2011)
Freshwater withdrawal (domestic/indus-
triaW/agricultural): total: 1.81 cu kmj/yr
(20%/22%/58%)
per capita: 410.6 cu m/yr (2005)
Natural hazards: earthquakes
Environment—current issues: air pollution, par-
ticularly in Rust''avi; heavy pollution of Mtkvari
River and the Black Sea; inadequate supplies of
potable water; soil pollution from toxic chemicals
Environment—international X agreements:
party to: Air Pollution, Biodiversity, Climate
Change, Climate Change-Kyoto Protocol, Deser-
tification, Endangered Species, Hazardous Wastes,
Law of the Sea, Ozone Layer Protection, Ship Pol-
lution, Wetlands
signed, but not ratified: none of the selected
agreements
Geography—note: strategically located east of
the Black Sea; Georgia controls much of the Cau-
casus Mountains and the routes through them
Disputes—international: The Gambia and
Guinea-Bissau attempt to stem separatist vio-
lence, cross border raids, and arms smuggling into
their countries from Senegal’s Casamance region,
and in 2006, respectively accepted 6,000 and
10,000 Casamance residents fleeing the conflict;
2,500 Guinea-Bissau residents fled into Senegal
in 2006 to escape armed confrontations along the
border
Refugees and internally displaced persons:
refugees (country of origin): 19,917 (Mauritania)
(2011)
IDPs: 10,000-40,000 (clashes between govern-
ment troops and separatists in Casamance region)
(2012)
ilicit drugs: transshipment point for Southwest
and Southeast Asian heroin and South American
cocaine moving to Europe and North America;
illicit cultivator of cannabis','fe0fbdeb2055b777d60016854214ed531dc2c445e6260d674230dce02136d962','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('97e5735d33a1752b2a81c545912b2671d08f9fb7079a0d554e74e048c633808b',2025,'GE','Georgia','transnational-issues',662,'Disputes—international: Russia’s military sup-
port and subsequent recognition of Abkhazia and
South Ossetia independence in’ 2008 continue to
sour relations with Georgia
Map references: Europe
Area: total: 357,022 sq km
country comparison to the world: 63 land:
348,672 sq km water: 8,350 sq km
Area—comparative:
Montana
Land boundaries: total: 3,790 km
border countries: Austria 784 km, Belgium 167
km, Czech Republic 815 km, Denmark 68 km,
France 451 km, Luxembourg 138 km, Netherlands
577 km, Poland 456 km, Switzerland 334 km
Coastline: 2,389 km
Maritime claims: territorial sea: 12 nm
exclusive economic zone: 200 nm
continental shelf: 200 m depth or to the depth of
exploitation
slightly smaller than
Climate: temperate and marine; cool, cloudy, wet
winters and summers; occasional warm mountain
(foehn) wind
Terrain:
Bavarian Alps in south
Elevation extremes: lowest point: Neuendorf bei
Wilster-3.54 m
highest point: Zugspitze 2,963 m
Natural resources: coal, lignite, natural gas, iron
ore, copper, nickel, uranium, potash, salt, con-
struction materials, timber, arable land
Land use: arable land: 33.25%
permanent crops: 0.56%
other: 66.19% (2011)
irrigated land: 5,157 sq km (2006)
Total renewable water resources: 154 cu km
(2011)
Freshwater withdrawal (domestic/industrial/
agricultural): tocal: 32.3 cu km/yr (16%/84%/0%)
per capita: 391.4 cu m/yr (2007)
Natural hazards: flooding
Environment—current issues: emissions from
coal-burning utilities and industries contribute
to air pollution; acid rain, resulting from sulfur
dioxide emissions, is damaging forests; pollution
in the Baltic Sea from raw sewage and industrial
effluents from rivers in eastern Germany; haz-
ardous waste disposal; government established a
mechanism for ending the use of nuclear power
over the next 15 years; government working to
meet EU commitment to identify nature preserva-
tion areas in line. with the EU’s Flora, Fauna, and
Habitat directive
lowlands in north, uplands in center,
Refugees and internally displaced persons:
IDPs: 261,400—274,000 (displaced in the 1990s
and 2008 from Abkhazia and South Ossetia)
(2011)
Illicit drugs: limited cultivation of cannabis
and opium poppy, mostly for domestic con-
sumption; used as transshipment point for opi-
ates via Central Asia to Western Europe and
Russia
Environment—international agreements:
party to: Air Pollution, Air Pollution-Nitrogen
Oxides, Air Pollution-Persistent Organic Pollut-
ants, Air Pollution-Sulfur 85, Air Pollution-Sulfur
94, Air Pollution-Volatile Organic Compounds,
Antarctic-Environmental Protocol, Antarctic-
Marine Living Resources, Antarctic Seals, Ant-
arctic Treaty, Biodiversity, Climate Change,
Climate Change-Kyoto Protocol, Desertification,
Endangered Species, Environmental Modifica-
tion, Hazardous Wastes, Law of the Sea, Marine
Dumping, Ozone Layer Protection, Ship Pollution,
Tropical Timber 83, Tropical Timber 94, Wetlands,
Whaling
signed, but not ratified: none of the selected
agreements
Geography—note: strategic location on North
European Plain and along the entrance to the
Baltic Sea','07989a628c644dacbfcf54d495c7b4b3d3f0cb79397fcf00d3944d8b981e640e','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('29ad6783c87cea771d6e24c84f30a506546ad37f8c02457f0ee3bde62ee2af43',2025,'DE','Germany','transnational-issues',669,'Disputes—intermational: none
Refugees and internally displaced persons:
refugees (country of origin): 110,455 Serbia;
92,986 Turkey; 48,976 Iraq; 39,816 Russia;
30,425 Afghanistan; 24,261 Vietnam; 24,016
Bosnia and Herzegovina; 20,462 Iran; 19,922
Ukraine; 11,724 Sri Lanka; 11,697 Lebanon;
10,155 Syria; 6,368 Azerbaijan; 5,982 Macedo-
nia; 5,146 Democratic Republic of the Congo
(2011)
lilicit drugs: source of precursor chemicals
for South American cocaine processors; trans-
shipment point for and consumer of South-
west Asian heroin, Latin American cocaine,
and European-produced synthetic drugs; major
financial center','0014e1f96ce9dbe8b8d79ca137c4c8917a62e2df7d92b01590e3e27c65d8b008','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('991ac3f14ec32384f6db5456e2bcd178215469505073a9826cc50391cffd1d4a',2025,'GH','Ghana','transnational-issues',679,'Disputes—international: disputed ‘maritime bor-
der between Ghana and Cote d''Ivoire
Refugees and Internally displaced persons:
refugees (country of origin): 11,295 (Liberia)
(2012); 8,532 (Cote d''lvoire; flight from 2010
post-election fighting) (2013)
Uticlt drugs: illicit producer of cannabis for the
international drug trade; major transit hub for
Southwest and Southeast Asian heroin and, to a
lesser extent, South American cocaine destined
for Europe and the US; widespread crime and
money laundering problem, but the lack of a well-
` developed financial infrastructure limits the coun-
try’s utility as a money laundering center; signifi-
cant domestic cocaine and cannabis use','14fcf6c45a0856695bc216411d63735ebf7d0486e01e42569e2319d555458bc7','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2213000d39d2447a71295227e4cc3588af4a5410d69634c429f515bd27fdaf2c',2025,'GI','Gibraltar','transnational-issues',689,'Disputes—international: in 2002, Gibraltar
residents voted overwhelmingly by referendum to
reject any “shared sovereignty” arrangement; the
government of Gibraltar insists on equal partici-
pation in talks between the UK and Spain; Spain
disapproves of UK plans to grant Gibraltar even
greater autonomy','6027107747ba9d7afa9fdc621d22414b2f7ad3b683a17f28de110bd655678bd6','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4ff51ee44209efa2f6b01278b69039ac47333ab421f2caa8b073a99037a00d4b',2025,'GR','Greece','transnational-issues',690,'Nanai pami 5
pm Kavala,
Thessaloniki
Crew
seer Ap HO und
Sireanapytt ave: mst Sten”
Disputes—international: Greece and Turkey
continue discussions to resolve their complex mar-
itime, air, territorial, and boundary disputes in the
Aegean Sea; Greece rejects the use of the name
Macedonia or Republic of Macedonia; the mass
migration of unemployed Albanians still remains
a problem for developed countries, chiefly Greece
and Italy
itlicit drugs: a gateway to Europe for traffickers
smuggling cannabis and heroin from the Middle
East and Southwest Asia to the West and precur-
sor chemicals to the East; some South American
cocaine transits or is consumed in Greece; money
laundering related to drug trafficking and organ-
ized crime
Area—comparative: slightly more than three
times the size of Texas
Land boundaries: 0 km
Coastline: 44,087 km
Maritime claims: territorial sea: 3 nm
exclusive fishing zone: 200 nm or agreed bounda-
ries or median line
continental shelf: 200 nm or agreed boundaries or «
median line
Climate: arctic to subarctic; cool summers, cold
winters
Terrain: flat to gradually sloping icecap covers all
but a narrow, mountainous, barren, rocky coast
Elevation extremes:
Ocean 0 m
highest point: Gunnbjom Fjeld 3,700 m
Natural resources: coal, iron ore, lead, zinc,
molybdenum, diamonds, gold, platinum, niobium,
tantalite, uranium, fish, seals, whales, hydropower,
lowest point: Atlantic
possible oil and gas
Land use: arable land:0%
permanent crops: 0%
other: 100% (2011)
irrigated land: NA
Natural hazards: continuous permafrost over
northern two-thirds of the island
Environment—current issues: protection of
the arctic environment; preservation of the Inuit
traditional way of life, including whaling and seal
hunting
291
Geography—note: dominates North Atlantit
Ocean between North America and Europe; sparse
population confined to small settlements along
coast; close to one-quarter of the population lives
in the capital, Nuuk; world’s second largest ice cap','6b6ae61bc1c457f8c0551ac884aef4fa086c871024a4e65479e0589b65bb4cd8','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d5eaaa26cbfdacf6b3dc8a92f16f99f78e56a76c079d7dfd42b79d5367e34f58',2025,'GD','Grenada','transnational-issues',710,'Disputes—international: none
Illicit drugs: small-scale cannabis cultivation;
lesser transshipment point for marijuana and
cocaine to US
Disputes—international: none','dbce972c8fc32451c5072b2779ceabad7f68f4fc5dffadc5ebcb7ddd56069a18','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('987d0913db45410514004a8a821570a53a6253dc29d20584f850d9225b86eb0f',2025,'SL','Sierra Leone','transnational-issues',728,'Disputes—international: none
Natural resources: bauxite, iron ore, diamonds,
gold, uranium, hydropower, fish, salt
Land use: arable land: 11.59%
permanent crops: 2.81%
other: 85.6% (2011)
Irrigated land: 949.2 sq km (2003)
Total renewable water resources: 226 cu km
(2011)
Freshwater withdrawal (domestic/indus-
trial/agricultural): total: 0.55 cu km/yr
(39%/10%/51%)
per capita: 64.3 cu m/yr (2005)
Natural hazards: hot, dry, dusty harmattan haze
may reduce visibility during dry season
Environment—current issues: deforestation;
inadequate supplies of potable water; desertifica-
tion; soil contamination and erosion; overfishing,
overpopulation in forest region; poor mining prac-
tices have led to environmental damage
Environment—international agreements:
party to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Endan-
gered Species, Hazardous Wastes, Law of the Sea,
Ozone Layer Protection, Ship Pollution, Wet-
lands, Whaling
signed, but not ratified: none of the selected
agreements Geography—note: the Niger and its
important tributary the Milo have their sources in
the Guinean highlands
„Kabala
bith
rors
a
bung: a
*Papel
FREETOWN
epee
"Shenge
runt ~~ Momaligt
IST AN Gamhe,. *
Sherbro
Suma <
Disputes—international: as domestic fighting
among disparate ethnic groups, rebel groups, war-
lords, and youth gangs in Cote d''Ivoire, Guinea,
Liberia, and Sierra Leone gradually abates, the
number of refugees in border areas has begun to
slowly dwindle; Sierra Leone considers exces-
sive Guinea’s definition of the flood plain limits
to define the left bank boundary of the Makona
and Moa rivers and protests Guinea’s continued
occupation of these lands including the hamlet of
Yenga occupied since 1998
Refugees and internally displaced persons:
refugees (country of origin): 8,046 (Liberia) (2011)','e4bb7e4095d95f323e1e1119a294856e9047c6af839b9ece1411f255d24e3115','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('15346ab8c80628386146980d099ebe06a4f5f7baf8260ce6b3bc887fc37e3bf8',2025,'GN','Guinea','transnational-issues',736,'Disputes—international: conflicts among rebel
groups, warlords, and youth gangs in neighboring
states have spilled over into Guinea resulting in
domestic instability; Sierra Leone considers Guin-
ea’s definition of the flood plain limits to define
the left bank boundary of the Makona and Moa
rivers excessive and protests Guinea''s continued
occupation of these lands, including the hamlet of
Yenga, occupied since 1998
Refugees and internally displaced persons:
refugees (country of origin: 6,552 (Cote
d''Ivoire); 5,400 (Liberia) (2011)','9d412cade2b39f02653f9af3c15d126ce93b94f76056686ea09d8a48e8c987fb','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2e983a40f7842049356eff5e79680b3b0bd108d27203bd896ed1229e58cbe984',2025,'GW','Guinea-Bissau','transnational-issues',737,'pores
=” arin
T pataa S
agheu la
Sirens Mansòa *
„BISSAU
¿Buba
gus (C
sts . GUINEA
Bolama,
308
Disputes—international: in 2006, political insta-
bility within Senegal’s Casamance region resulted
in thousands of Senegalese refugees, cross-border
raids, and arms smuggling into Guinea-Bissau
Refugees and internally displaced persons:
refugees (country of origin): 7,658 (Senegal)
(2011)
Trafficking in persons: current situation:
Guinea-Bissau is a country of origin and destina-
tion for children subjected to forced labor and sex
trafficking; the scope of the problem of trafficking
women or men for forced labor or forced prostitu-
tion is unknown; boys reportedly were transported to
southern Senegal for forced manual and agricultural
labor; girls may be subjected to forced domestic ser-
vice and child prostitution in Senegal and Guinea;
both boys and girls are forced to work as street ven-
dors in cities in Guinea-Bissau and Senegal
tier rating: Tier 2 Watch List—the government
of Guinea-Bissau does not fully comply with the
minimum standards for the elimination of traf-
ficking; however, it is making significant efforts to
do so; the government acknowledged human traf-
ficking is a problem and enacted a comprehensive
anti-trafficking law in June 2011, followed by a
national plan of action for implementing the law;
the government facilitated the repatriation of 120
trafficking victims from Senegal and gave a small
amount of funding to NGO shelters that provided
victim care but did not pursue criminal action
against trafficking offenders during the year (2012)
Mlicit drugs: increasingly important transit
country for South American cocaine enroute to
Europe; enabling environment for trafficker opera-
tions thanks to pervasive corruption; archipelago-
like geography arourid the capital facilitates drug
smuggling
311
THE CIA WORLD FACTBOOK','f0441bc8cc8907f9cf5c411fba038f0eff2115ca81b8b42ea6dace32b20fccdb','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('059f32961bb5af9ce0d2650c8544914c90bdb5c610199be43ec812a5bf9b0055',2025,'GY','Guyana','transnational-issues',746,'0 x Noam
FO) me
Disputes—international: all of the area west of
the Essequibo River is claimed by Venezuela pre-
venting any discussion of a maritime boundary;
Guyana has expressed its intention to join Bar-
bados in asserting claims before UN Convention
on the Law of the Sea (UNCLOS) that Trinidad
and Tobago’s maritime boundary with Venezuela
extends into their waters; Suriname claims a tri-
angle of land between the New and Kutari/Koetari
tivers in a historic dispute over the headwaters of
the Courantyne; Guyana seeks arbitration under
provisions of the UNCLOS to resolve the long-
standing dispute with Suriname over the axis of
the territorial sea boundary in potentially oil-rich
waters
Illicit drugs: transshipment point for narcotics
from South America—primarily Venezuela—to
Europe and the US; producer of cannabis; rising
money laundering related to drug trafficking and
human smuggling
315
ie de la
eg
R sò
Port-dè~. f e
Pais Harien,
» „Gonaives \\
Sant
Marc hincha
“Verrattos s£
PORT-AU- Hispaniola
PRINCE, fom
‘yi ” Chefne S
Miragoåne'' rokada 3','c601745161d3d299bda1c3bbc13c011228bd0294bd291b5820d89e4c85294131','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cb95b14d9940d24d51622bc684ddef4b88f5b70728cd04347ed231784ade8548',2025,'HT','Haiti','transnational-issues',761,'Disputes—international: since 2004, peacekeep-
ers from the UN Stabilization Mission in Haiti
have assisted in maintaining civil order in Haiti;
the mission currently includes 6,685 military,
2,607 police, and 443 civilian personnel; despite
~ efforts to control illegal migration, Haitians cross
into the Dominican Republic and sail to neigh-
boring countries; Haiti claims US-administered
Navassa Island
Refugees and internally displaced persons:
IDPs: 357,785 (includes only IDPs from the 2010
earthquake living in camps or camp-like situa-
tions; information is lacking about IDPs living
outside camps or who have left camps) (2012)
Illicit drugs: Caribbean transshipment point for
cocaine enroute to the US and Europe; substantial
bulk cash smuggling activity; Colombian narcotics
traffickers favor Haiti for illicit financial transac-
tions; pervasive corruption; significant consumer
of cannabis','8d446ef31039b29a1abcd6247b295a74b6a3f7615714e9a6ac064671b119483b','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('43aa0254f73bc9e8b3e7701bb958c60d5d5d898c574e104dd6801b8172797c21',2025,'HM','Heard Island and McDonald Islands','transnational-issues',762,'Indian Ocean
Disputes— international: none
over 23 sites in Rome and five outside of Rome,
including the Pontifical Palace at Castel Gandolfo
(the Pope’s summer residence)','383d17a660dc401ac2f802734d9afe3a0a8c445dc350cf551b5ede0a901a1e7d','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0e6f20b410cf7119f1aa6a9d48c5ac22768fbd6cf038529331d6956d58b296dd',2025,'HN','Honduras','transnational-issues',782,'Disputes—international: International Court of
Justice (ICJ) ruled on the delimitation of “bolsones”
(disputed areas) along the El Salvador-Honduras
border in 1992 with final settlement by the par-
ties in 2006 after an Organization of American
States survey and a further IC} ruling in 2003; the
1992 ICJ ruling advised a tripartite resolution to
a maritime boundary in the Gulf of Fonseca with
consideration of Honduran access to the Pacific;
El Salvador continues to claim tiny Conejo Island,
not mentioned in the IC} ruling, off Honduras in
the Gulf of Fonseca; Honduras claims the Belizean-
administered Sapodilla Cays off the coast of Belize
in its constitution, but agreed to a joint ecological
park around the cays should Guatemala consent to a
maritime corridor in the Caribbean under the OAS-
sponsored 2002 Belize-Guatemala Differendum
tilicit drugs: transshipment point for drugs and
narcotics; illicit producer of cannabis, cultivated
on small plots and used principally for local con-
sumption; corruption is a major problem; some
money-laundering activity','55a9ba52738c9cf5679f4e26ede03897cc5cc221561a8992567ccdfb4c27eda4','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6666a9f9b52c49beeee969f7814890c4cb70e2b636199c5aba7333a1c8de3ad4',2025,'HU','Hungary','transnational-issues',799,'Disputes—international: bilateral govern-
ment, legal, technical and economic working
group negotiations continue in 2006 with Slova-
kia over Hungary’s failure to complete its portion
of the Gabcikovo-Nagymaros hydroelectric dam
project along the Danube; as a member state that
forms part of the EU’s external border, Hungary
has implemented the strict Schengen border
rules
Illicit drugs: transshipment point for Southwest
Asian heroin and cannabis and for South Ameri-
can cocaine destined for Western. Europe; limited
producer of precursor chemicals, particularly for
amphetamine and methamphetamine; efforts
to counter money laundering, related to organ-
ized crime and drug trafficking are improving
but remain vulnerable; significant consumer of
ecstasy
“Grunaararg
HatnariorOur REYKJAVÍK
mannaa A
š te
Suter HOC)','5aebb64bdb7cc055d984f3c4e5e9ec274e6dc4fd2d6c52765225a57979d5941a','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('993c96b37fe12d8c5083db319be82e0e884ba54e5ca8410f809a908b18491dfe',2025,'IS','Iceland','transnational-issues',806,'Disputes—international: Iceland, the UK, and
Ireland dispute Denmark’s claim that the Faroe
Islands’ continental shelf extends beyond 200 nm;
the European Free Trade Association Surveillance
Authority filed a suit against Iceland, claiming the
country violated the European Economic Area
agreement in failing to pay minimum compensa-
tion to Icesave depositors
at Inno
9 260 400m
oeo
pil 0 200 400m','9e7949cbcd2081c6fd0f4406c553bef555a1a9ff8df6ef15990ed2ae34d173a7','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ff106e51bf3b1091231673e2a1157b955824c0563bc2409a22f70ca392db0abc',2025,'IN','India','transnational-issues',817,'Disputes—international: some maritime dis-
putes (see littoral states)
341
THE CIA WORLD FACTBOOK','3587732dd24dbd1cb83f80c84a4d7a5f6bc6671eac32424996c0465cce78b26b','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a3cc9ab46488830a03eac5f566e74c50b55038a80a55efd246a4761a436b6b68',2025,'IQ','Iraq','transnational-issues',818,'As $ulaymèniyah,
Kirkuk
Disputes—international: approximately two mil-
lion Iraqis have fled the conflict in Iraq, with the
z
man Northern
4 iræand
< :
Siga ^ ¢ Monaghan
be ? i
Castied& .
Dragneda,
DUBLIN, .
“Tukamare
Yack ow,
Areow,
Saway
i
Sannen
umenck New
,Rass
Waterford?» ¢ -~
Milarney
Cansa COM
es','f870f83074f4a422fd5be27d9705ac026ee8cc2fdb21fd53cf41463d648e8a54','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('57fcba2357cf7057839b23ab36f07a965919d413888199661cce5c63c4d43505',2025,'IE','Ireland','transnational-issues',833,'Disputes—international: Ireland, Iceland, and
the UK dispute Denmark''s claim that the Faroe
Islands’ continental shelf extends beyond 200 nm
illicit drugs: transshipment point for and con-
sumer of hashish from North Africa to the UK and
Netherlands and of European-produced synthetic
drugs; increasing consumption of South American
cocaine; minor transshipment point for heroin
and cocaine destined for Western Europe; despite
recent legislation, narcotics-related money laun-
dering—using bureaux de change, trusts, and shell
companies involving the offshore financial com-
munity—temains a concern','0fcbe66b76742cffe283191a65df65e1c15b53baa9fe8acced73ffee93dec322','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a7149ea66acafefe05ec19eb8535341b53184550952b8c56c18575f6040a207f',2025,'IL','Israel','transnational-issues',850,'Disputes—international: West Bank and Gaza
Strip are Israeli-occupied with current, status
subject to the Israeli-Palestinian Interim Agree-
ment—permanent status to be determined through
further negotiation; Israel continues construction of
a “seam line” separation barrier along parts of the
Green Line and within the West Bank; Israel with-
drew its settlers and military from the Gaza Strip and
from four settlements in the West Bank in August
2005; Golan Heights is Israeli-occupied (Lebanon
claims the Shab’a Farms area of Golan Heights);
since 1948, about 350 peacekeepers from the UN
Truce Supervision Organization headquartered in
Jerusalem monitor ceasefires, supervise armistice
agreements, prevent isolated incidents from esca-
lating, and assist oțher UN personnel in the region
Refugees and internally displaced persons:
refugees (country of origin): 31,119 (Eritrea);
9,000 (Sudan) (2011)
illicit drugs: increasingly concerned about
ecstasy, cocaine, and heroin abuse; drugs arrive
in country from Lebanon and, increasingly, from
Jordan; money-laundering center
Disputes—international: The current status of
the West Bank is subject to the Israeli-Palestinian
Interim Agreement—permanent status to be
determined through further negotiation; Israel
continues construction of a “seamline” separation
barrier along parts of the Green Line and within
the West Bank; Israel withdrew from four settle-
ments in the northern West Bank in August 2005;
since 1948, about 350 peacekeepers from the UN
Truce Supervision Organization (UNTSO),
headquartered in Jerusalem, monitor ceasefires,
supervise armistice agreements, prevent isolated
incidents from escalating, and assist other UN per-
sonnel in the region
Refugees and internally displaced persons:
refugees (country of origin): 727,471 (Palestinian
refugees (UNRWA)) (2012)
IDPs: 160,000 (persons displaced within both the
Gaza strip and the West Bank since 1967; as esti-
mated by unofficial sources) (2011)','d326efa16aed0eb28ddc79787d1b088de4a598a43a8ccba415b2cde7b1eb6dc4','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('424133719fd30d586386f19615af80254f728edff44b6e477d776b23b307c60d',2025,'IT','Italy','transnational-issues',860,'Disputes—international: Italy''s long coastline
and developed economy entices tens of thousands
of illegal immigrants from southeastern Europe and
northern Africa
Refugees and internally displaced persons:
refugees (country of origin): 11,206 Eritrea; 8,497
Somalia (2011)
illicit drugs: important gateway for and consumer
of Latin American cocaine and Southwest Asian
heroin entering the European market; money
laundering by organized crime and from smuggling
Poggio di
Ctyesanyova
adusi
Disputes—international: none','17491e20c42db87425147ebb74b95cacc65039db0f328a9e40a0433aae6388e2','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d2071db1e48e51bbb24640582fe26d72e1ebdf22f153432319231da343ecc937',2025,'JM','Jamaica','transnational-issues',867,'Disputes—international: none
Illicit drugs: transshipment point for cocaine
from South America tó North America and
Europe; illicit cultivation and consumptign of
cannabis; government has an active manual can-
nabis eradication program; corruption is a major
concern; substantial money-laundering activity;
Colombian narcotics traffickers favor Jamaica for
illicit financial transactions
JAN MAYEN
a
Haakon ve Tuone
P © netoorological station
* oran-c
station','d16abb1f23bfeb0f715bf342b74d68a331f0c1c716514759f3a4effdc3732367','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e98f77311b8c9c32c3d9078fd6022890fe91a7b1b9ecde048860e76b1c900b88',2025,'JP','Japan','transnational-issues',882,'Disputes—international: the sovereignty
dispute over the islands of Etorofu, Kunashiri,
and Shikotan, and the Habomai group, known
in Japan as the “Northern Territories” and in
Russia as the “Southern Kuril Islands,” occupied
by the Soviet Union in 1945, now adminis-
tered by Russia and claimed by Japan, remains
the primary sticking point to signing a peace
treaty formally ending World War II hostilities;
Japan and South Korea claim Liancourt Rocks
(Take-shima/Tok-do) occupied by South Korea
since 1954; China and Taiwan dispute both
Japan''s claims to the uninhabited islands of the
Senkaku-shoro (Diaoyu Tai) and Japan’s unilat-
erally declared exclusive economic zone in the
East China Sea, the site of intensive hydrocar-
bon prospecting','7377277c7e115d0426315bb9800d8851c70b2f126a84e5b4011dd729ac9532c1','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6f136c08b3d2abac8ffbe455c16be78ac379599fc929a61be0d71574d2d0c226',2025,'JE','Jersey','transnational-issues',883,'Gorey,
SAINT
a HELIER
376
Disputes—international: none
Disputes—international: despite recent discus-
sions, Russia and Norway dispute their maritime
limits in the Barents Sea and Russia’s fishing rights
beyond Svalbard’s territorial limits within the
Svalbard Treaty zone
higher infant mortality, higher death rates, lower
population growth rates, and changes in the dis-
tribution of population by age and sex than would
otherwise be expected
Age structure: 0-14 years: 36.9% (male 261,954/
female 256,144)
15-24 years: 22.4% (male 158,947/female 155,421)
25-54 years: 32.7% (male 234,805/female
224,703)
55-64 years: 4.2% (male 23,287/female 35,900)
65 years and over: 3.7% (male 21,042/female
31,159) (2013 est.)
Median age: total: 20.7 years
male: 20.4 years
female: 21.1 years (2013 est.)
Population growth rate: 1.17% (2013 est.)
country comparison to the world: 98
Birth rate: 25.68 births/1,000 population (2013
est.)
country comparison to the world: 53
Death rate: 13.95 deaths/1,000 population (2013 est.)
country comparison to the world: 11
Net migration rate: 0 migrant(s)/1,000 popula-
tion (2013 esr.) ‘
country comparison to the world: 103
Urbanization: urban population: 21% of total
population (2010)
rate of urbanization: 1.5% annual rate of change
(2010-15 est.)
Major cities—population: MBABANE (capital)
74,000 (2009)
Sex ratio: at birth: 1.03 male(s)/female
0-14 years: 1.02 male(s)/female
15-24 years: 1.02 male(s)/female
25-54 years: 1.03 male(s)/female
55-64 years: 0.65 male(s)/female
65 years and over: 0.69 male(s)/female
total population: 0.99 male(s)/female (2013 est.)
Maternal mortality rate: 320 deaths/100,000 live
births (2010)
country comparison to the world: 35
Infant mortality rate: total: 57.19 deaths/1,000
live births
country comparison to the world: 32
male: 61.21 deaths/1,000 live births
female: 53.04 deaths/1,000 live births (2013 est.)
Life expectancy at birth: total population: 50.01
years
country comparison to the world: 220
male: 50.44 years
female: 49.56 years (2013 est.)
Total fertility rate: 2.96 children born/woman
(2013 est.) 4
country comparison to the world: 61
Health expenditures: 6.6% of GDP (2010)
country comparison to the world: 95
Physicians density: 0.16 physicians/1,000 popu-
lation (2004)
Hospital bed density: 2.1 beds/1,000 population
(2011)
Drinking water source:
Improved:
urban:91% of population
rural: 65% of population
total: 71% of population
Unimproved:
urban:9% of population
rural: 35% of population
total: 29% of population (2010 est.)
Sanitation facility access:
Improved:
urban: 64% of population
rural: 55% of population
total: 57% of population
Unimproved:
urban: 36% of population
rural: 45% of population
total: 43% of population (2010 est.)
HIV/AiDS—adult prevalence rate: 25.9% (2009
est.)
country comparison to the world: 1
HIV/AIDS—people living with HIV/AIDS:
180,000 (2009 est.)
country comparison to the world: 30
HIV/AIDS—deaths: 7,000 (2009 est.)
country comparison to the world: 31
Major infectious diseases: degree of risk: high
food or waterborne diseases: bacterial diarrhea,
hepatitis A, and typhoid fever
vectorborne disease: malaria
water contact disease: schistosomiasis (2009)
Obesity—adult prevalence rate: 19.7% (2008)
country comparison to the world: 98
Children under the age of 5 years under-
weight: 6.1% (2007)
country comparison to the world: 81
- Education expenditures: 8.2% of GDP (2011)
country comparison to the world: 11
Literacy: definition: age 15 and over can read and
write
total population: 81.6%
male: 82.6%
female: 80.8% (2003 est.)
School life expectancy (primary to tertiary
education): total: 11 years
male: 11 years
female: 10 years (2007)
Disputes—international: in 2006, Swazi king
advocated resorting to ICJ to claim. parts of
Mpumalanga and KwaZulu-Natal from South
Africa
Natural hazards: ice floes in the surrounding
waters, especially in the Gulf of Bothnia, can
interfere with maritime traffic
Environment—current issues: acid rain damage
to soils and lakes; pollution of the North Sea and
the Baltic Sea
Environment—international agreements:
party to: Air Pollution, Air Pollution-Nitrogen
Oxides, Air Pollution-Persistent Organic Pollut-
ants, Air Pollution-Sulfur 85, Air Pollution-Sulfur
94, Air Pollution-Volatile Organic Compounds,
Antrarctic-Environmental Protocol,
Marine Living Resources, Antarctic Treaty, Biodi-
versity, Climate Change, Climate Change-Kyoto
Protocol, Desertification, Endangered Species,
Antarctic-
Environmental Modification, Hazardous Wastes,
Law of the Sea, Marine Dumping, Ozone Layer
Protection, ‘Ship Pollution, Tropical Timber 83,
Tropical Timber 94, Wetlands, Whaling signed,
but not ratified: none of the selected agreements
Geography—note: strategic location along Dan-
ish Straits linking Baltic and North Seas','7a5dc2e07ea6d7e90b461644d86111bc7ffccb0a13bd2f7619f6610a9fc7f404','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0ab148dc5c9a94f9cab5d53cca75f694f018d6a3cc8b1f56485ce90b9dfe9ebe',2025,'JO','Jordan','transnational-issues',891,'> ARABIA
( A
7
at
\\
$
i
IAI A
qabsh Wi “terest cocupled wlth current sasis
pour botia t to he isvaatt Pitesti uan danm
Tinta, hla Apera eta nta
M,
amparan heag Auts nogan
Disputes—international: 2004 Agreement
settles border dispute with Syria’ pending
demarcation
Refugees and internally displaced persons:
refugees (country of origin): 1,979,580 (Pales-
tinian refugees (UNRWA)) (2011); 29,191 (Iraq)
(2012); 491,912 (Syria) (2013)','3c96c7db4986a7eaaa45733d322a94957f97fc044b932f4ecc76d0d0c8f10f80','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e6d634e65613a41938d8ce59a8a31f9d3fac866f14c69140ff32e82668f822a8',2025,'KZ','Kazakhstan','transnational-issues',905,'Disputes—international: Kyrgyzstan has yet
to ratify the 2001 boundary delimitation with
Kazakhstan; field demarcation of the boundaries
commenced with Uzbekistan in 2004 and with
Turkmenistan in 2005; ongoing demarcation with
Russia began in 2007; demarcation with China
was completed in 2002; creation of a seabed
boundary with Turkmenistan in the Caspian Sea
remains under discussion; Azerbaijan, Kazakhstan,
and Russia ratified Caspian seabed delimitation
treaties based on equidistance, while Iran contin-
ues to insist on a one-fifth slice of the sea
Illicit drugs: significant illicit cultivation of can-
nabis for CIS markets, as well as limited cultiva-
tion of opium poppy and ephedra (for the drug
ephedrine); limited government eradication of
illicit crops; transit point for Southwest Asian
narcotics bound for Russia and the rest of Europe;
significant consumer of opiates
`','a779daad9ca8813a30e976289f078e8cadfdba918f5558816614ffcbfd8d5789','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a918c0d39be3c8b0c6c4c916fd237665dd7030723dc15d29ac37c5eb57bd585d',2025,'KE','Kenya','transnational-issues',906,'Ea
rrangie.
HIGH ANS
„NAIROBI
"Machakos
ANATS
Fe
- Disputes—international: Kenya served as an
important mediator in brokering Sudan''s north-
south separation in February 2005; Kenya pro-
vides shelter to almost a quarter million refugees,
including Ugandans who flee across the border
periodically to seek protection from Lord''s Resist-‘
ance Army rebels; Kenya works hard to prevent the
clan and militia fighting in Somalia from spread-
ing across the border, which has long been open to
nomadic pastoralists; the boundary that separates
Kenya’s and Sudan’s sovereignty is unclear in the
“Ilemi Triangle,” which Kenya has administered
since colonial times
Refugees and internally displaced persons:
refugees (country of origin): 34,800 (South
Sudan); 34,000 (Ethiopia); 11,500 (Democratic
Republic of Congo); 6,000 (Sudan) (2012);
492,905 (Somalia) (2013)
IDPs: at least 300,000 (2007-2008 post-election
violence; the status of the estimated 300,000 IDPs
from the 2007-08 post-election violence who
found refuge in host communities rather than.
camps—and IDPs displaced through natural dis-
asters, drought, development and environmental
projects, land disputes, cattle rustling, and inter-
communal violence—is not captured in Kenya’s
national database; in 2012, inter-communal vio-
lence displaced approximately 118,000 people and
floods displaced an estimated 100,000) (2012)
ilicit drugs: widespread harvesting of small plots
of marijuana; transit country for South Asian
heroin destined for Europe and North America;
Indian methaqualone also transits on way to
South Africa; significant potential for money-
laundering activity given the country’s status as
a regional financial center; massive corruption, ''
and relatively high levels of narcotics-associated
activities','3b23afa71924d25995ca16cd844e07c9403ba10945f493912c56331d3e7d772a','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fe1b66e75b64a2263194f3e9c15d6dc43ade90d3e57ee7f94e9e6d2d6f7b644d',2025,'KI','Kiribati','transnational-issues',924,'Disputes—international: risking arrest, impris-
onment, and deportation, tens of thousands of
North Koreans cross into China to escape fam-
ine, economic privation, and political oppression;
North Korea and China dispute the sovereignty of
cestain islands in Yalu and Tumen rivers; Military
Demarcation Line within the 4-km-wide Demili-
tarized Zone has separated North from South
Korea since 1953; periodic incidents in the Yellow
Sea with South Korea which claims the North-
em Limiting Line as a maritime boundary; North
Korea supports South Korea in rejecting Japan’s
claim to Liancourt Rocks (Tok-do/Take-shima)
Refugees and internally displaced persons:
IDPs: undetermined (periodic flooding and fam-
ine during mid-1990s) (2007)
Trafficking in persons: current situation:
North Korea is a source country for men, women,
and children trafficked for the purposes of forced
labor and commercial sexual exploitation; the
most common form of trafficking involves North
Korean women and girls who cross the border
into China voluntarily; additionally, North
Korean women and girls are lured out of North
Korea to escape poor social and economic condi-
tions by the promise of food, jobs, and freedom,
only to be forced into prostitution, marriage, or
exploitative labor arrangements once in China;
within the country, North Koreans do not have a
choice in the work the government assigns them
and are not free to change jobs at will
tier rating: Tier 3—North Korea does not fully
comply with minimum standards for the elimina-
tion of trafficking and is not making significant
efforts to dé so; the government does not acknowl-
edge the existence of human rights abuses in the
country or recognize trafficking, either within the
country or transnationally (2008)
Hliclt drugs: for years, from the 1970s into the
2000s, citizens-of the Democratic People’s Repub-
lic of (North) Korea (DPRK), many of them
diplomatic employees of the government, were
KOREA, NORTH
apprehended abroad while trafficking in narcot-
ics, including two in Turkey in December 2004;
police investigations in Taiwan and Japan in
recent years have linked North Korea to large
illicit shipments of heroin and methampheta-
mine, including an attempt by the North Korean
merchant ship Pong Su to deliver 150 kg of heroin
to Australia in April 2003
KOREA, SOUTH
Disputes—intemational: Military Demarcation
Line within the 4-km-wide Demilitarized Zone has
separated North from South Korea since 1953; peri-
odic incidents with North Korea in the Yellow Sea
over the Northern Limit Line, which South Korea
claims as a maritime boundary; South Korea and
Japan claim Liancourt Rocks (Tok-do/Take-shima),
occupied by South Korea since 1954
KOSOVO','372bea350b215da29108420840be70a3357736e4fbcf65b55b4a3ae8f0c339a1','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d8c3cf6ef45a30a8b398cf43ca9002c1e0a674532eef1950348bbedb2a78c0e2',2025,'RS','Serbia','transnational-issues',932,'Disputes—international: Serbia with several
other states protest the US and other states’
recognition of Kosovo''s declaration of its status
as a sovereign and independent state in Febru-
ary 2008; ethnic Serbian municipalities along
Kosovo''s northern border challenge final status
of Kosovo-Serbia boundary; several thousand
NATO-led Kosovo Force peacekeepers under
United Nations Interim Administration Mission
in Kosovo authority continue to keep the peace
within Kosovo between the ethnic Albanian
majority and the Serb minority in Kosovo; Kosovo
and Macedonia completed demarcation of their
boundary in September 2008
Refugees and internally displaced persons:
IDPs: 17,853 (primarily ethnic Serbs displaced
during the 1998-1999 war; IDPs consist of an esti-
mated 04% Serbs, 40% Albanians, and 0% Roma,
Ashkalis, and Egyptians) (2012)
person from four to one. The opposition, led by
a coalition of Sunni Islamists, tribalists, some
liberals, and myriad youth groups, boycotted the
December 2012 legislative election, resulting in a
historic number of Shia candidates winning seats.
Since 2006, the Amir has dissolved the National
Assembly on five occasions (the Constitutional
Court annulled the Assembly once in June 2012)
and reshuffled the cabinet 12 times, usually cit-
ing political stagnation and gridlock between the
legislature and the government.
Disputes—international: Serbia with several
other states protest the US and other states’ rec-
ognition of Kosovo''s declaration of its status as a
sovereign and independent state in February 2008;
ethnic Serbian. municipalities along Kosovo''s
northern border challenge final status of Kosovo-
Serbia boundary; several thousand NATO-led
Kosovo Force peacekeepers under United Nations
Interim Administration Mission in Kosovo
authority continue to keep the peace within Kos-
ovo between the ethnic Albanian majority and the
Serb minority in Kosovo; Serbia delimited about
half of the boundary with Bosnia and Herzego-
vina, but sections along the Drina River remain
in dispute
Refugees and Internally displaced persons:
refugees (country of origin): 49,946 (Croatia);
20,673 (Bosnia and Herzegovina) (2011)
IDPs: 228,215 (most are Kosovar Serbs some are
Roma, Ashkalis, and Egyptian (RAE); some RAE
IDPs are unregistered) (2011)
illicit drugs: transshipment point for Southwest
Asian heroin moving to Western Europe on the
Balkan route; economy vulnerable to money
laundering.
VICTORIA,
Mare
wes Inai
UARARTES
Amhonse Isand','6918b46ddb354de4617176ec92b5f06453eed26a13f50b48a81edaa414824217','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c755909f1704acc80aed0c7214425736a953c2d45bb3113d6c96381ffcac55ff',2025,'KW','Kuwait','transnational-issues',939,'Disputes—international: Kuwait and Saudi Ara-
bia continue negotiating a joint maritime boundary
with Iran; no maritime boundary exists with Iraq in
the Persian Gulf
Trafficking in persons: current situation: Kuwait
is a destination country for men and women sub-
jected to forced labor and, to a lesser degree, forced
prostitution; men and women migrate from India,
Egypt, Bangladesh, Syria, Pakistan, the Philip-
pines, Sri Lanka, Indonesia, Nepal, Iran, Jordan,
Ethiopia, and Iraq to work in Kuwait, most of
them in the domestic service, construction, and
sanitation sectors; although most of these migrants
enter Kuwait voluntarily, upon arrival some are
subjected to conditions of forced labor by their
sponsors and labor agents, including nonpayment
of wages, long working hours without rest, depriva-
tion of food, threats, physical or sexual abuse, and
restrictions on movement, such as the withholding
of passports or confinement to the workplace
tier rating: Tier 3—Kuwait does not fully comply
with the minimum standards for the elimination
of trafficking and is not making sufficient efforts
to do so; the government did not enact its draft
comprehensive anti-trafficking law; Kuwait’s vic-
tim-protection measures remain weak, particularly
due to its lack of proactive victim-identification
procedures and continued reliance on the sponsor-
ship system, which causes victims of trafficking to
be punished for immigration violations rather than
protected (2009)','a0625f022662057cab572dac8170f929b12d4143ca2d8228d1f8d3fb999421e8','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cbbb0c5e567f172749f5413318b983a72bff54916fdc534a80bd4db70f78d2c6',2025,'KG','Kyrgyzstan','transnational-issues',950,'Disputes—international: Kyrgyzstan has yet
to ratify the 2001 boundary delimitation with
Kazakhstan; disputes in Isfara Valley delay com-
pletion of delimitation with Tajikistan; delimi-
tation of 130 km of border with Uzbekistan is
hampered by serious disputes over enclaves and
other areas
Refugees and internally displaced persons:
refugees (country of origin): 5,660 (Uzbekistan)
(2011)
IDPs: 172,000 (June 2010 violence in southem
Kyrgyzstan between the Kyrgyz majority and the
Uzbek minority) (2012)
lilicit drugs: limited illicit cultivation of cannabis
and opium poppy for CIS markets; limited govern-
ment eradication of illicit crops; transit point for
Southwest Asian narcotics bound for Russia and
the rest of Europe; major consumer of opiates
Disputes—international: southeast Asian states
have enhanced border surveillance to check the
spread of avian flu; talks continue on completion
of demarcation with Thailand but disputes remain
over islands in the Mekong River; concern among
Mekong River Commission members that China’s
construction of dams on the Mekong River and
its tributaries will affect water levels; Cambodia
and Vietnam are concerned about Laos’ extensive
upstream dam construction
Illicit drugs: estimated opium poppy cultivation
in 2008 was 1,900 hectares, about a 73% increase
from 2007; estimated potential opium produc-
tion in 2008 more than tripled to 17 metric tons;
unsubstantiated reports of domestic methampheta-
mine production; growing domestic methamphet-
amine problem (2007)','c05cb86c987dcf289782842b3c21bd224f099535d312520c28b56b880fa8bf72','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d3647b0b1ea8b09e14a46173517aff8160b3668b3025a89b16ece59988d9d453',2025,'LV','Latvia','transnational-issues',952,'“Vontepite
qepaja Jelgava”
Oa
>a W f
Disputes—international: Russia demands better
Latvian treatment of ethnic Russians in Latvia;
boundary demarcated with Latvia and Lithuania;
the Latvian parliament has not ratified its 1998
maritime boundary treaty with Lithuania, primar-
ily due to concerns over oil exploration rights; as a
member state that forms part of the EU’s external
border, Latvia has implemented the strict Schen-
gen border rules with Russia
Illicit drugs: transshipment and destination point
for cocaine, synthetic drugs, opiates, and canna-
bis from Southwest Asia, Western Europe, Latin
America, and neighboring Balkan countries;
despite improved legislation, vulnerable to money
laundering due to nascent enforcement capabili-
ties and comparatively weak regulation of offshore
companies and the gaming industry; CIS organized
crime (including counterfeiting, corruption, extor-
tion, stolen cars, and prostitution) accounts for
most laundered proceeds','947364bd91ddf0d1b0d2b547d157899e8da1574c3431f1666714eafd0fc6d616','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8036d4520c0bfc325c05e067a456b701780bf0d0c151a921aa6c96cf74f4be50',2025,'LT','Lithuania','transnational-issues',953,'A BELARUS
a
Omi
VILNIUS Y
*
Background: Lithuanian lands were united
under MINDAUGAS in* 1236; over the next
century, through alliances and conquest, Lithuania
extended its territory to include most of present-day
Belarus and Ukraine. By the end of the 14th cen-
tury Lithuania was the largest state in Europe. An
alliance with Poland in 1386 led the two countries
into a union through the person of a common ruler.
In 1569, Lithuania and Poland formally united into
a single dual state, the Polish-Lithuanian Com-
monwealth. This entity survived until 1795 when
its remnants were partitioned by surrounding coun-
tries. Lithuania regained its independence follow-
ing World War I but was annexed by the USSR in
1940—an action never recognized by the US and
many other countries. On 11 March 1990, Lithu-
ania became the first of the Soviet republics to
declare its independence, but Moscow did not rec-
ognize this proclamation until September of 1991
(following the abortive coup in Moscow). The last
Russian troops withdrew in 1993. Lithuania sub-
sequently restructured its economy for integration
into Western European institutions; it joined both
NATO and the EU in the spring of 2004.
Disputes—international: Lithuania and Russia
committed to demarcating their boundary in 2006
v7 LUXEMBOURG
j *
H Petange
a p
Te a, Derange i
E m nn,
a A aa ~~
rater \\ un Budetange™ == “~~,','0484d51c78d53565711e7006c064e05acc75a31f94c5d08b44e58901ea102ccb','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4722b891ce78b4f261fe627ca7100e3933082303bb6f8f1c45af3f8fa745873f',2025,'LB','Lebanon','transnational-issues',974,'Disputes—international: lacking a treaty or
other documentation describing the boundary,
government—the first in the country’s history—
that ousted the 14 year incumbent, Pakalitha
MOSISILI, who peacefully transferred power the
following month.','6782ef12fb15144aa412a7138b1f36829002c0e69b5d6ad05e4a1ad176099c96','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1c03df63fb850134f7c74ebe0bd95117e1cc4ce0ee7a2508200bd8397f23695d',2025,'LS','Lesotho','transnational-issues',981,'Disputes—international: South Africa has
placed military units to assist police operations
along the border of Lesotho, Zimbabwe, and
Mozambique to control smuggling, poaching, and
illegal migration','10d2ede7deba420aa999f25fcaabad9862e2b2ae22c8c4d1887dde2edb821882','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8a7f26ff50605a733eaeb214e4ec9cd0c4566431fb96a4584c833ad82ebcf735',2025,'LR','Liberia','transnational-issues',982,'I
i or
oe 5 oman
5
N
HBE A A
Soga » pA
ftese { 2
h rab
„Gbara pran
A DEMARE
MONROVIA dy
»Harbel
euchanan
n a VbMmanburg
eRaberisport
Leene
Disputes—international: although
unrest continues to abate with the assistance of
18,000 UN Mission in, Liberia peacekeepers, as
of January 2007, Liberian refugees still remain
in Guinea, Cote d''Ivoire, Sierra Leone, and
Ghana; Liberia, in turn, shelters refugees flee-
ing turmoil in Cote d''Ivoire; despite the pres-
ence of over 9,000 UN forces in Cote d''Ivoire
since 2004, ethnic conflict continues to spread
into neighboring states who can no longer send
civil
their migrant workers to Ivorian cocoa planta-
tions; UN sanctions ban Liberia from exporting
diamonds and timber
Refugees and internally displaced persons:
refugees (country of origin): 61,153 (Cote
d''Ivoire) (2013)
IDPs: undetermined (civil war from 1990-2004;
unclear how many have found durable solutions;
many dwell in slums in Monrovia) (2012)
Uticit drugs: transshipment point for Southeast
and Southwest Asian heroin and South American
cocaine for the European and US markets; corrup-
tion, criminal activity, arms-dealing, and diamond
trade provide significant potential for money
laundering, but the lack of well-developed finan-
cial system limits the country’s utility as a major
money-laundering center
427
THE CIA WORLD FACTBOOK','1a46a57049e3eb242c1d21c45f93405b462140b154e9ca338b5dbf75d0a4d48f','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0edf328ffce9c7fd38b9ef411cbc5a0b745306c4605a56e3ed14132df7d3203b',2025,'LY','Libya','transnational-issues',991,'., TRIPOLI
l 1 omer
y Zuwaran "a eMigrâtah
4 Khums
Yrsa
Sha
Al Kutrah
Al Jawi,
SAMA RA ae
a pre
AS
ca i
Sey mw.
aa
X
|
|
|
|
|
"A
Disputes—international: dormant disputes
include Libyan claims of about 32,000 sq km still
reflected on its maps of southeastern Algeria and
the FLN’s assertions of a claim to Chirac Pas-
tures in southeastern Morocco; various Chadian
rebels from the Aozou region reside in southern
Refugees and internally displaced per- .
sons: IDPs: 74,000 (conflict between ‘pro-
Qadhafi and anti-Qadhafi forces; figure does
not include displaced chird-country nationals)
(2012)
Trafficking in persons: current situation:
Libya is a transit and destination country for
men and women from sub-Saharan Africa and
Asia trafficked for the purposes-of forced labor
and commercial sexual exploitation; migrants
seek employment in Libya as laborers and
domestic workers or transit Libya enroute to
Europe; most of the estimated 1.5 to 2 million
foreigners fled Libya during its 2011 revolution
and many who stayed, especially those from
sub-Saharan Africa, were detained as suspected
mercenaries
tier rating: Tier 3—tħe Libyan Government does
not fully comply with the minimum standards for
the elimination of trafficking and is not making
significant efforts to do so; the TNC has failed
to demonstrate significant efforts to investigate
and prosecute trafficking offenses or to protect
trafficking victims; the government''s policies and
practices with respect to undocumented migrant
workers resulted in Libyan authorities detaining
and punishing trafficking victims for unlawful acts
that were committed as a result of being trafficked
(2012)','1b4e75f7ac2bde680848d5bbcf61567226eed5ffb1251fad537963fd473faf51','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('be5612161ce1d2462eef4e62aa76a0b6da7a1e15caf33ffe7e358dcaf58b5331',2025,'LI','Liechtenstein','transnational-issues',1009,'Disputes—international: none
Illicit drugs: has strengthened money laundering
controls, but money laundering remains a concern
due to Liechtenstein’s sophisticated offshore finan-
cial services sector','17fb625b6d9087a165d56f1890f5ff2c77c9641501fba5b89b94b0bc0665f402','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b2f41365be13fbf13db1f9040d67c06ad867b26dfe62a46a024eb18b1261f03a',2025,'MG','Madagascar','transnational-issues',1034,'Disputes—international: claims Bassas da India,
Europa Island, Glorioso Islands, and Juan de Nova
Island (all administered by France); the vegetated
drying cays of Banc du Geyser, which were claimed
by Madagascar in 1976, also fall within the EEZ
claims of the Comoros and France (Glorioso Islands,
part of the French Southern and Antarctic Lands)
Wlicit drugs: illicit producer of cannabis (culti- _,
vated and wild varieties) used mostly for domestic
consumption; transshipment point for heroin
TARZANA','54cc6a503e0af688eacb85829c320b54f757b2caccd28eb53a936ff9478b503e','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9429ae07a6b85d1ca2b9f02c8f79e9e359113e48b6d2a441e6cb2c760f4ebda4',2025,'MW','Malawi','transnational-issues',1045,'Disputes—international: disputes with Tanzania
over the boundary in Lake Nyasa (Lake Malawi)
and the meandering Songwe River remain
dormant','5b0715a48925e6a209538b36d09d81e1c20390cce38baa27ff58dd6930d70855','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d26480f08197b26826bd0419e47c97b3badf919d8e77b76a2eb1a482493fb2e6',2025,'MY','Malaysia','transnational-issues',1046,'KUALA vows UE
Lume ut
ADONESIA
Disputes—international: while the 2002 “Dec-
laration on the Conduct of Parties in the South
China Sea” has eased tensions over the Spratly
Islands, it is not the legally binding “code of con-
duct” sought by some parties; Malaysia was not
party to the March 2005 joint accord among the
national oil companies of China, the Philippines,
and Vietnam on conducting marine seismic activi-
ties in the Spratly Islands; disputes continue over
deliveries of fresh water to Singapore, Singapore''s
land reclamation, bridge construction, and mari-
time boundaries in the Johor and Singapore Straits;
in 2008, IC} awarded sovereignty of Pedra Branca
(Pulau Batu Puteh/Horsburgh Island) to Singapore,
and Middle Rocks to Malaysia, but did not rule
on maritime regimes, boundaries, or disposition of
South Ledge; land and maritime negotiations with
Indonesia are ongoing, and disputed areas include
the controversial Tanjung Datu and Camar Wulan
border area in Borneo and the maritime boundary
in the Ambalat oil block in the Celebes Sea; sepa-
ratist violence in Thailand’s predominantly Mus-
lim southern provinces prompts measures to close
and monitor border with Malaysia to stem terror-
ist activities; Philippines retains a dormant claim
to Malaysia’s Sabah State in northern Bomeo; Per
Letters of Exchange signed in 2009, Malaysia in
2010 ceded two hydrocarbon concession blocks
to Brunei in exchange for Brunei’s sultan dropping
claims to the Limbang corridor, which divides Bru-
nei; piracy remains a problem in the Malacca Strait
Refugees and internally displaced persons: ref-
ugees (country of origin): 81,146 (Burma) (2011)
Trafficking in persons: current situation: Malaysia
is a destination and, to a lesser extent, 2 source and
transit country for women and children trafficked for
the purpose of commercial sexual exploitation, and
men, women, and children for forced labor; Malay-
sia is mainly a destination country for men, women,
and children who migrate willingly from countries
including Indonesia, Nepal, India, Thailand, China,
the Philippines, Burma, Cambodia, Bangladesh,
Pakistan, and Vietnam to work, some of whom are
subjected to conditions of involuntary servitude by
Malaysian employers in the domestic, agricultural,
construction, plantation, and industrial sectors; a
small number of Malaysian citizens were reportedly
trafficked internally and abroad to Singapore, China,
and Japan for commercial sexual exploitation
tier rating: Tier 2 Watch List—the Govemment
of Malaysia does not fully comply with the mini-
mum standards for the elimination of trafficking;
however, it is making significant efforts to do so;
while the government increased the number of .
convictions obtained under the Anti-Trafficking
in Persons and Anti-Smuggling of Migrants Act
during the year and continued public awareness
efforts on trafficking, it did not effectively inves-
tigate and prosecute labor trafficking cases, and
failed to address problems of government complic-
ity in trafficking and lack of effective victim care
and counseling by authorities (2009)
illicit drugs: drug trafficking prosecuted vigor-
ously and carries severe penalties; heroin still
primary drug of abuse, but synthetic drug demand
remains strong; continued ecstasy and metham-
phetamine producer for domestic users and, to a
lesser extent, the regional drug market
a
k ANDONESIA
Deng Tits >
Background: Singapore was founded as a British
trading colony in 1819. It joined the Malaysian
Federation in 1963 but separated two years later
and became independent. Singapore subsequently
became one of the world’s most prosperous coun-
tries with strong international trading links (its
port is one of the world’s busiest in terms of ton-
nage handled) and with per capita GDP equal to
that of the leading nations of Western Europe.','a744a080c3445788589937c9fa76171ea76e7ffacc667f89e0750b88eb61cde4','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9bb5bdf74747c072017c67997568b19af7663407933bd0f11c4b2159003eb104',2025,'ML','Mali','transnational-issues',1074,'Disputes—international: demarcation is under-
way with Burkina Faso
Refugees and internally dispiaced persons:
tefugees (country of origin): 12,442 (Mauritania)
(2011)
IDPs: 228,918 (Tuareg rebellion since 2012)
(2013)
Trafficking in persons: current situation:
Mali is a source, transit, and destination coun-
try for men, women, and children subjected to
forced labor and sex trafficking; women and
girls are forced into domestic servitude, agri-
cultural labor, and support roles in gold mines,
as well as subjected to sex trafficking; Malian
boys are found in conditions of forced labor in
agricultural settings, gold mines, and the infor-
mal commercial sector, as well as forced beg-
ging both within Mali and neighboring coun-
tries; Malians and other Africans who travel
through Mali to Mauritania, Algeria, or Libya,
in hopes of reaching Europe are particularly at
tisk of becoming victims of human trafficking;
men and boys, primarily of Songhai ethnicity,
are subjected to the longstanding practice of
debr bondage in the salt mines of Taoudenni
in northern Mali; some members of Mali’s
black Tamachek community are subjected to
traditional slavery-related practices, and this
involuntary servitude reportedly has extended
to their children
tier rating: Tier 2—the Government of Mali
does not fully comply with the minimum
standards for the elimination of trafficking;
how ever, it is making significant efforts to do
so; the government acknowledged that human
trafficking is a problem in Mali, but it did not
demonstrate significant efforts to prosecute
and convict trafficking offenders; Mali was not
placed on Tier 3 because the government has a
written plan that, if implemented, would con-
stitute making significant efforts to bring itself
into compliance with the minimum standards
for the elimination of trafficking and is devot-
ing sufficient resources to implement that plan
(2012)
465
THE CIA WORLD FACTBOOK
Keown','8e4cd8977483ff4f21912661e3d4a387529a6bcdac812adb53c94078970d432c','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c438d0698f6b61d00ebe8ec3c181bd210c0e91f13582a180c024ea8f9ec41489',2025,'MT','Malta','transnational-issues',1083,'Disputes—international: None
illicit drugs: minor transshipment point for hash-
ish from North Africa to Western Europe
\\','4e389bc22afe272b819ac87aed55f77385c13b2c8219dd89088d6593adab3f2b','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d6be2dcbb9bf27b0341a40e2c39b14f3686f2ed5fd404153487638f78989afbe',2025,'MH','Marshall Islands','transnational-issues',1084,'E
Disputes—international: claims US territory of
Wake Island z
471
THE CIA WORLD FACTBOOK
| SAL MA
pose ed SS
} „Bir Moghrein
Western | °
Sahara ;
$
“Novaddhibou
Ata
Sumner ion
vi res
*NOUAKCHOTT
R itta
j Kaédt “
Tdjikdja
m
Y
SENEGAL 2','8c179ef8e8a1f02d442d59e90135cb07c8f2aea65a3e06c6c7bc7bceafaa55b4','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('79989eca5bc25403485fba044ab8ba51538cfbe34501fed1382302e22d997f32',2025,'MR','Mauritania','transnational-issues',1095,'Disputes—international: Mauritanian claims to
Western Sahara remain dormant
Refugees and internally displaced persons: refu-
gees (country of origin): 74,108 (Mali); 26,000 (West-
em Saharan Sahrawi) (2013)
Independence from the UK was attained in 1968.
A stable democracy with regular free elections and
a positive human rights record, the country has
attracted considerable foreign investment and has
earned one of Africa''s highest per capita incomes.','1cdd7525a1f7f0ace2303df3b99f27a28fd887119f556cc4d65fbf9eacc0c3b4','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4be2ee53d8a346712369f9c04fbe3c7b95416981dc90e0612f4a55ec1f5e97d3',2025,'UA','Ukraine','transnational-issues',1105,'SRA Aon.
Disputes—international: 1997 boundary delimi-
tation treaty with Belarus remains unratified due
to unresolved financial claims, stalling demarca-
tion and reducing border security; delimitation of
land boundary with Russia is complete with prepa-
rations for demarcation underway; the dispute over
the boundary between Russia and Ukraine through
the Kerch Strait and Sea of Azov remains unre-
solved despite a December 2003 framework agree-
ment and ongoing expert-level discussions; Mol-
dova and Ukraine operate joint customs posts to
monitor transit of people and commodities through
Moldova''s break-away Transnistria Region, which
remains under the auspices of an Organization for
Security and Cooperation in Europe-mandated
peacekeeping mission comprised of Moldovan,
Transnistrian, Russian, and Ukrainian troops; the
ICJ ruled largely in favor of Romania in its dispute
submitted in 2004 over Ukrainian-administered
Zmiyinyy/Serpilor (Snake) Island and Black Sea
maritime boundary delimitation; Romania opposes
Ukraine’s reopening of a navigation canal from the
Danube border through Ukraine to the Black Sea
ilicit drugs: limited cultivation of cannabis and
opium poppy, mostly for CIS consumption; some
synthetic drug production for export to the West;
limited government eradication program; used as
transshipment point for opiates and other illicit
drugs from Africa, Latin America, and Turkey to
Europe and Russia; Ukraine has improved anti-
money-laundering controls, resulting in its removal
from the Financial Action Task Force’s (FATF''s)
Noncooperative Countries and Territories List: in
February 2004; Ukraine’s anti-money-laundering
tegime continues to be monitored by FATF','d86c03ecf1656d385b3051e4babe7d3d40c4976a1c7330b2f3028c2cff4aea93','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('28c93fa4e64bf99253a97e4027685f2c7dda2b0294c7328e4d93143b94dc955e',2025,'RO','Romania','transnational-issues',1106,'J
J
?
}
(isana
4
i
$
Disputes—international: Moldova and Ukraine
operate joint customs posts to monitor the tran-
sit of people and commodities through Moldova’s
break-away Transnistria region, which remains
under the auspices of an Organization for Security
and Cooperation in Europe-mandated peacekeep-
ing mission comprised of Moldovan, Transnistrian,
Russian, and Ukrainian troops
ilicit drugs: limited cultivation of.opium poppy
and cannabis, mostly for CIS consumption; trans-
shipment point for illicit drugs from Southwest
Asia via Central Asia to Russia, Western Europe,
and possibly the US; widespread crime and under-
ground economic activity
ca ea
f ke
| Condamine
. MONACO
L @ palace
NS Fontvieille ` | ©
”
Disputes—international: the IC) ruled largely in
favor of Romania in its dispute submitted in 2004
over Ukrainian-administered Zmiyinyy/Serpilor
(Snake) Island and Black Sea maritime boundary
delimitation; Romania opposes Ukraine''s reopen-
ing of a navigation canal from the Danube border
through Ukraine to the Black Sea
Wticit drugs: major transshipment point for South-
west Asian heroin transiting the Balkan route and
small amounts of Latin American cocaine bound for
Western Europe; although not a significant financial
center, role as a narcotics conduit leaves it vulner-
able to laundering, which occurs via the banking
system, currency exchange houses, and casinos
Disputes—international: Russia remains con-
cerned about the smuggling of poppy derivatives
from Afghanistan through Central Asian coun-
tries; China and Russia have demarcated the once
disputed islands at the Amur and Ussuri conflu-
ence and in the Argun River in accordance with
the 2004 Agreement, ending their centuries-long
border disputes; the sovereignty dispute over the
islands of Etorofu, Kunashiri, Shikotan, and the
Habomai group, known in Japan as the “North-
ern Territories” and in Russia as the “Southern
Kurils,” occupied bythe Soviet Union in 1 945,
now administered by Russia, and claimed by
Japan, remains the primary sticking point to sign-
ing a peace treaty formally ending World War II
hostilities; Russia’s military support and subse-
quent recognition of Abkhazia-and South Ossetia
independence in 2008 continue to sour relations
with Georgia; Azerbaijan, Kazakhstan, and Russia
ratified Caspian seabed delimitation treaties based
on equidistance, while Iran continues to insist on
a one-fifth slice of the sea; Norway and Russia
signed a comprehensive maritime boundary agree-
ment in 2010; various groups in Finland advocate
restoration of Karelia (Kareliya) and other areas
ceded to the Soviet Union following World War
II but the Finnish Government asserts no territo-
rial demands; Russia and Estonia signed a tech-
nical border agreement in May 2005, but Russia
recalled its signature in June 2005 after the Esto-
nian parliament added to its domestic ratification
act a historical preamble referencing the Soviet
occupation and Estonia''s pre-war borders under
the 1920 Treaty of Tartu; Russia contends that the
preamble allows Estonia to make territorial claims
on Russia in the future, while Estonian officials
deny that the preamble has any legal impact on
the treaty text; Russia demands better treatment
of the Russian-speaking population in Estonia
and Latvia; Lithuania and Russia committed to
demarcating their boundary in 2006 in accord-
ance with the land and maritime treaty ratified
by Russia in May 2003 and by Lithuania in 1999;
Lithuania operates a simplified transit regime for
Russian nationals traveling from the Kaliningrad
coastal exclave into Russia, while still conform-
ing, as an EU member state with an EU external
border, where strict Schengen border rules apply;
preparations for the demarcation delimitation of
land boundary with Ukraine have commenced;
the dispute over the boundary between Russia
and Ukraine through the Kerch Strait and Sea
of Azov remains unresolved despite a December
2003 framework agreement and on-going expert-
level discussions; Kazakhstan and Russia bound-
ary delimitation was ratified on November 2005
and field demarcation should commence in 2007;
Russian Duma has not yet ratified 1990 Bering
Sea Maritime Boundary Agreement with the US;
Denmark (Greenland) and Norway have made
submissions to the Commission on the Limits of
the Continental shelf (CLCS) and Russia is col-
lecting additional data to augment its 2001 CLCS °
submission
Refugees and internally displaced persons:
IDPs: 8,500-28,450 (displacement from Chechnya
and North Ossetia-Alania) (2011)
Trafficking in persons: current situation: Rus-
sia is a source, transit, and destination country for
men, women, and children trafficked for various
purposes; people from Russia and other countries,
including Belarus, Tajikistan, and Uzbekistan, are
subjected to conditions of forced labor in Russia;
children are subjected to prostitution in large Rus-
sian cities and to forced begging; Russian women
were reported to be victims of sex trafficking in
many countries, including in Northeast Asia,
Europe, and throughout the Middle East
tier rating: Tier 2 Watch List—Russia failed to
show evidence of increased efforts to combat
trafficking; victim protection in Russia remains
very weak, as the government allocated scant
funding for victim shelters and little funding
for anti-trafficking efforts by governmental or
non-governmental organizations; the govern-
ment did not make discernible efforts to fund
a national awareness campaign, although some
local efforts were assisted by local government
funding (2008)
lilicit drugs: limited cultivation of illicit cannabis
and opium poppy and producer of methampheta-
mine, mostly for domestic consumption; govern-
ment has active illicit crop eradication program;
used as transshipment point for Asian opiates,
cannabis, and Latin American cocaine bound:for
growing domestic markets, to a lesser extent West-
ern and Central Europe, and occasionally to the
US; major source of heroin precursor chemicals;
corruption and organized crime are key concerns;
major consumer of opiates','abf280d54e911f832c738523856c246ebf1040b0446cc1fce43c42b1b5323cd5','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c2e8d873b069354a8185fd326fcc29da7dd337d81568bf1b6e40e2d197ebf8e3',2025,'ME','Montenegro','transnational-issues',1136,'Disputes—international: Refugees and inter-
nally displaced persons: refugees {country of ori-
gin): 9,367 (Kosovo) (2011)
497
THE CIA WORLD FACTBOOK','c4efd3b95d863e19666135a0fe16dac42024f8248ac069993db8f82337f61857','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4ec05137d0b112f2ca264e76aafaa226e00d1ec0baadf50e77ec5eda4ab1b254',2025,'MS','Montserrat','transnational-issues',1137,'Plymouth
ofiarne capital, & y
Tsara -"
pm Poss
Disputes—international: none
illicit drugs: transshipment point for South Amer-
ican narcotics destined for the US and Europe','7294bab497a3955aa67010ecacf726d2f2928e2307e51fe7737616ae7f131a6f','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7132cfc44af6ec99418c4a0d4e0b364764bedefdfbf307eb6daefc35a11efef8',2025,'MA','Morocco','transnational-issues',1146,'Western Sahara `~
Matgr
a
Disputes—international: claims and adminis-
ters Western Sahara whose sovereignty remains
unresolved; Morocco protests Spain’s control over
the coastal enclaves of Ceuta, Melilla, and Penon
de Velez de la Gomera, the islands of Penon de
Alhucemas and Islas Chafarinas, and surround-
ing waters; both countries claim Isla Perejil (Leila
Island); discussions have not progressed on a com-
prehensive maritime delimitation, setting limits
on resource exploration and refugee interdiction,
since Morocco’s 2002 rejection of Spain’s unilat-
eral designation of a median line from the Canary
Islands; Morocco serves as one of the primary
launching areas of illegal migration into Spain
from North Africa; Algeria’s border with Morocco
remains an irritant to bilateral relations, each
nation accusing the other of harboring militants
and arms smuggling; the National Liberation
Front’s assertions of a claim to Chirac Pastures in
southeastern Morocco is a dormant dispute
Illicit drugs: one of the world’s largest produc-
ers of illicit hashish; shipments of hashish mostly
directed to Western Europe; transit point for
cocaine from South America destined for Western
Europe; significant consumer of cannabis','337e075f7b4b2c842217a28a138533abf3aee9fb2c7c13896fd1d41f8cfda6df','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7e522feb2aed5759dff9e71b6a5d9b6af89454b57c53b7f334a7083f7147bf68',2025,'MZ','Mozambique','transnational-issues',1155,'MOD
f ems = SBewa
teen,
i Eduardo
\\ Mondlane
\\
inhambanegs
Disputes—international: South Africa has placed
military units to assist police operations along the
border of Lesotho, Zimbabwe, and Mozambique to
control smuggling, poaching, and illegal migration
Uliclt drugs: southern African transit point
for South Asian hashish and heroin, and South
American cocaine probably destined for the Euro-
pean and South African markets; producer of can-
nabis (for local consumption) and methaqualone
(for export to South Africa); corruption and poor
regulatory capability make the banking system
vulnerable to money laundering, but the lack of
a well-developed financial infrastructure limits the
country’s utility as a money-laundering center
507','e5dabebafa09e5dab1b8ccd2f7f793dac227fe3267527b7f5d6a10bed9e48e5d','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('507880297dc49d9cd072e96179af3b1afe7edddd567b4d02317a7434f243548b',2025,'NA','Namibia','transnational-issues',1173,'Disputes—international: concerns from interna-
tional experts and local populations over the Oka-
vango Delta ecology in Botswana and human dis-
placement scuttled Namibian plans to construct a
hydroelectric dam on Popa Falls along the Angola-
Namibia border; the governments of South Africa
and Namibia have not signed or ratified the text
of the 1994 Surveyor’s General agreement placing
the boundary in the middle of the Orange River;
Namibia has supported, and in 2004 Zimbabwe
dropped objections to, plans between Botswana
and Zambia to build a bridge over the Zambezi
River, thereby de facto recognizing a short, but not
clearly delimited, Botswana-Zambia boundary in
the river
Change-Kyoto Protocol, Desertification, Hazard-
ous Wastes, Law of the Sea, Marine Dumping,
Ozone Layer Protection, Whaling
signed, but not ratified: none of the selected
agreements
Geography—note: Nauru is one of the three great
phosphate rock islands in the Pacific Ocean—the
others are Banaba (Ocean Island) in Kiribati and
Makatea in French Polynesia; only 53 km south
of Equator','71c9ee52ce3d71361bf3a9eaf69ecf2796addcf789de6a32d995ffca94363f2e','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ac02856e01006e897f684205c209a3ecc07a17b77e4bfa9cec1c4320b6831693',2025,'NR','Nauru','transnational-issues',1179,'Disputes—international: none
513
THE CIA WORLD FACTBOOK
NAVASSA ISLAND
Au erat
Disputes—international: claimed by Haiti,
source of subsistence fishing
failed to produce a new election date. Finally, in
March 2013, the chief justice of Nepal’s Supreme
Court, Khil Raj REGMI, was sworn in as Chair-
man of the Interim Council of Ministers for Elec-
tions to lead an interim government and charged
with holding Constituent Assembly elections by
December 2013.','681a96309e7b620d3f4fb1af3d4c8d8791742bd0520ad9e040a9e852238d4488','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ae387e46db7493b0f3d8c72630704657ee4aca6b008eb4c755ae678323672bd9',2025,'NP','Nepal','transnational-issues',1190,'Disputes—international: joint border commis-
sion continues to work on contested sections of
boundary with India, including the 400 square
kilometer dispute over the source of the Kalapani
River; India has instituted a stricter border regime
to restrict transit of Maoist insurgents and illegal
cross-border activities
Refugees and internally displaced persons: ref-
ugees (country of origin): 15,0000-20,000(Tibet/
China) (2011); about 43,000(Bhutan) (2012)
IDPs: 50,000 (remaining from ten-year Maoist
insurgency that officially ended in 2006; figure
does not include people displaced since 2007 by
inter-communal violence and insecurity in the
Terai region) (2012)
illicit drugs: illicit producer of cannabis and hash-
ish for the domestic and international drug mar-
kets; transit point for opiates from Southeast Asia
to the West','11f232293c5614171eb1bafce7edc80388126a3c8003dbf31d43d5ae56ba6c7f','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7d5e94da43d446cb88f774fb7142ea64fba6c892a3d09a2d492c777c2905347d',2025,'NL','Netherlands','transnational-issues',1191,'at ANCS
Delfzy)
Groningen
Leeuwarden
wd
¿Zwolle £
~~
Nmuiden, gennai
Haateme P merg a
AMSTERDAM S93 Apoldoom sas
The Hague, k '' Precht ima m
Eur A Patines PY b
eok suh. ‘GERMANY
: x ae
y Endhoven j}
Neg &
BELGIUM po
x Mtaagtecnt
sae enai á amoron
sors
Disputes—international: none
THE CIA WORLD FACTBOOK
Refugees and internally displaced persons:
refugees (country of origin): 18,255 Iraq; 15,715
Somalia (2011)
Hlicit drugs: major European producer of syn-
thetic drugs, including ecstasy, and cannabis
cultivator; important gateway for cocaine, heroin,
and hashish entering Europe; major source of US-
bound ecstasy; large financial sector vulnerable to
money laundering; significant consumer of ecstasy
: NEW CALEDONIA
Éfata
TATA
Erromango
les
*Poindimié yee, Loyauté
ie
Muine
New ~œ. Thios.
Caledonia =="
NOUMEA" ~> e des Pins
ile Huon and Hes Chesturfakt
att fot See','867e0b95bb8ecf3aa97970af449c257603eca70df75824fce1800f81b803fd9b','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e2ead8ca3f1b3845e88b7442dd2189acb09ec8872c4f3c6e54f4ad9a2ff2c49c',2025,'NZ','New Zealand','transnational-issues',1212,'Disputes—international: asserts a territorial
claim in Antarctica (Ross Dependency)
illicit drugs:
amphetamines
significant consumer of
Disputes—international: none
Disputes—international: Tokelau included
American Samoa’s Swains Island (Olosega) in its
2006 draft independence constitution
continental shelf: 200 m depth or to the depth of
exploitation Climate: tropical; modified by trade
winds; warm season (December to May), cool sea-
son (May to December)
Terrain: most islands have limestone base formed
from uplifted coral formation; others have lime-
stone ovenyiny volcanic base
Elevation extremes: lowest point: Pacific Ocean
Om
highest point: unnamed elevation on Kao Island
1,033 m
Natural resources: fish, fertile soil
Land use: arable land: 21.33%
permanent crops: 14.67%
other: 64% (2011)
Irrigated land: NA
Natural hazards: cyclones (October to April);
earthquakes and volcanic activity on Fonuafo''ou
volcanism: moderate volcanic activity; Fonualei
(elev. 180 m) has shown frequent activity in recent
years, while Niuafo’ou (elev. 260 m), which last
erupted in 1985, has forced evacuations; other his-
torically active volcanoes include Late and Tofua
Environment—current issues: deforestation
results as more and more land is beiny cleared for
ayriculture and settlement; some damaye to coral
reefs from starfish and indiscriminate coral and
shell collectors; overhuntiny threatens native sea
turtle populations - Şi a
Environment—international agreements:
partý to: Biodiversity, Climate Change, Climate
Chanye-Kyoto Protocol, Desertification, Law of
the Sea, Marine Dumping, Marine Life Conserva-
tion, Ozone Layer Protection, Ship Pollution
signed, but not ratified: none of the selected
agreements
Geography—note: archipelago of 169 islands (36
inhabited)
PEOPLE AND
Nationality: noun: Tongan(s)
adjective: Tongan
Ethnic groups: Polynesian, Europeans
Languages: Tongan (official), English (official)
Religions: Christian (Free Wesleyan Church
claims over 30,000 adherents)
_ Poputation: 106,322 (July 2013 est.)
country comparison to the world: 191
Age structure: 0-14 years: 36.2% (male 19,545/
female 18,927)
15-24 years: 19.2% (male 10,432/female 9,935)
25-54 years: 33% (male 17,549/female 17,562)
55-64 years: 5.4% (male 2,779/female 2,994)
65 years and over: 6.2% (male 3,034/female
3,565) (2013 est.)
Median age: total: 21.8 years
male: 21.3 years
female: 22.2 years (2013 est.)
Population growth rate: 0.14% (2013 est.)
. country comparison to the world: 183
Birth rate: 24.12 births/1,000 population (2013
est.)
country comparison to the world: 64
Death rate: 4.87 deaths/1,000 population (2013
est.)
country comparison to the world: 190
Net migration rate: -17.87 migrant(s)/1,000
population (2013 est.)
country comparison to the world: 217
Urbanization: urban population: 23% of total
population (2010)
rate of urbanization: 0.8% annual rate of change
(2010-15 est.)
Sex ratio: at birth: 1.03 male(s)/female
0-14 years: 1.03 male(s)/female
15-24 years: 1.05 male(s)/female
25-54 years: | male(s)/female
55-64 years: 0.91 male(s)/female
65 years and over: 0.86 male(s)/female
total population: 1.01 male(s)/female (2013 est.)
Maternal mortality rate: 110 deaths/100,000 live
births (2010)
country comparison to the world: 65
Infant mortality rate: total: 12.78 deaths/1,000
live births
country comparison to the world: 127
male: 13.2 deaths/1,000 live births
female: 12.34 deaths/1,000 live births (2013 est.)
Life expectancy at birth: total population: 75.6
years
country comparison to the world: 90
male: 74.16 years s
Organization of Arab Petroleum Exporting Countries
Organization of American States
Organization of African Unity; see African Union
official development assistance
Organization for Economic Cooperation and Development
Organization of Eastern Caribbean States
Office of the United Nations High Commissioner for Human Rights
Organization of the Islamic Conference
International Organization of the French-speaking World
other official flows
Agency for the Prohibition of Nuclear Weapons in Latin America and the Caribbean
Organization for the Prohibition of Chemical Weapons
Organization of Petroleum Exporting Countries
Organization for Security and Cooperation in Europe
Montreal Protocol on Substances That Deplete the Ozone Layer
Permanent Court of Arbitration
Partnership for Peace
Pacific Islands Forum
purchasing power parity
see Wetlands
Rio Group
South Asian Association for Regional Cooperation
South Asia Co-operative Environment Program
Southern African Customs Union
Southern African Development Community
South African Far East Cable
Shanghai Cooperation Organization
Southeast European Cooperative Initiative
Convention of the Southeast European Law Enforcement Centers (successor to SECI)
super-high-frequency
Protocol of 1978 Relating to the International Convention for the Prevention of Pollu-
tion From Ships, 1973 (MARPOL)
Central American Integration System
South Pacific Regional Trade and Economic Cooperation Agreement
Secretariat of the Pacific Communities
South Pacific Forum
square kilometer
square mile
Trans-Atlantic Telephone
Twenty-Foot Equivalent Unit, a unit of measure for containerized cargo capacity
International Tropical Timber Agreement, 1983
International Tropical Timber Agreement, 1994','5028888918e4aeb6abdb9f29b8581dc62dbd90a0a3b07edb0bedc623dcd848d7','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fcce3f4b10ecb377421945674c382b4a3d798d675a6d9a420cc7a5ee7d3d98ee',2025,'NI','Nicaragua','transnational-issues',1213,'"o ry i
ë heroin
2
Est
?
et
Matagalpa
. Phinandega
Corin EN fo, . $ E
T Jk istas peL
ay p te
‘a MANAGUA
Sr Bluefield $E! Blutt
Granada :
ane yO
oN
fe. A
=-
COSTA MICA
Disputes—international: the 1992 IC} ruling for
El Salvador and Honduras advised a tripartite reso-
lution to establish a maritime boundary in the Gulf
of Fonseca, which considers Honduran access to
the Pacific; legal dispute over navigational rights
of San Juan River on border with Costa Rica
ltlicit drugs: transshipment point for cocaine
destined for the US and transshipment point for
arms-for-drugs dealing
531
ALGERIA }
TZ A
A
Arlt
S A
KATAS- Taghna
Agadez,
4
Sa
NIAMEY Maradi Zinder
-Doaso $ n oS
3
foes
0 109 200m Z
SO 100 200m °°','d814761d97594dbfe9c4d1835085ebf70b37de28e92309f30d345a47ce214d85','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('aec2d485dfc74ab407072e4f67bd92db16061a0cb8cb54b0b859fa98485ed52f',2025,'NE','Niger','transnational-issues',1229,'Disputes—international: Libya claims about
25,000 sq km in a currently dormant dispute in the
Tommo region; location of Benin-Niger-Nigeria
tripoint is unresolved; only Nigeria and Cam-
eroon have heeded the Lake Chad Commission''s
admonition to ratify the delimitation treaty that
also includes the Chad-Niger and Niger-Nigeria
boundaries; the dispute with Burkina Faso was
referred to the IC] in 2010
Refugees and internally displaced persons:
refugees (country of origin): 50,000 (Mali) (2013)
,ı IDPs: undetermined (unknown how many of the
11,000 people displaced by clashes between gov-
ernment forces and the Tuareg militant group,
Niger Movement for Justice; in 2007 are still dis-
placed; inter-communal violence) (2012)
Trafficking in persons: current situation: Niger
is a source, transit, and destination country for
children and women trafficked for forced labor
and sexual exploitation; caste-based slavery prac-
tices, rooted in ancestral master-slave relation-
ships, continue in isolated areas ‘of the country;
children are trafficked within Niger for forced
begging, forced labor in gold mines, domestic ser-
vitude, sexual exploitation, and possibly for forced
labor in agriculture and stone quarries; women and
children from neighboring states are trafficked to
and through Niger for domestic servitude, sexual
exploitation, forced labor in mines and on farms;
and as mechanics and welders; to a lesser extent,
Nigerien women and children are recruited from
Niger and transported to Nigeria, North Africa,
the Middle East, and Europe for domestic servitude
and sex trafficking
tier rating: Tier 2 Watch List—the Government
of Niger does not fully comply with the mini-
mum standards for the elimination of traffick-
ing; the government has not shown evidence of
increasing efforts to address human trafficking;
however, Niger was granted a waiver from an
otherwise required downgrade to Tier 3 because
its government has a written plan that, if imple-
mented, would constitute making significant
efforts to meet the minimum standards for the
elimination of trafficking and is devoting suf-
ficient resources to that plan; during the year,
the government took some ‘steps to finalize a
national legal framework to combat trafficking
and the president spoke publicly about the gov-
ernment’s commitment to pursue vigorous law
enforcement action against slavery, child prosti-
tution, exploitive child begging, and other forms
of human trafficking (2012)
Harcourt
a.','f42306f77d71a90f16dc4b8e7a11cc5bab68f3fe94066f401948c3998019b8b4','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ac35f66db7680fdedc5bd8f906241d135962ffc59abb6fae387c08ec3c1adf3a',2025,'OM','Oman','transnational-issues',1263,'Disputes—international: boundary agreement
reportedly signed and ratified with UAE in 2003
for entire border, including Oman’s Musandam
Peninsula and Al Madhah exclave, but details of
the alignment have not been made public
PACIFIC OCEAN
wee Tsuen
Stat
Pasama +
Ca
Disputes—international: some maritime dis-
putes (see littoral states)','98bcd810d57b4e913384832aeb76412c6a36d5da9a0f4ed1488b6a9870091a67','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e0c921d1d708153b91ba2017f2763046cfaa8016cb747f7eda3127719d4d7d4b',2025,'PK','Pakistan','transnational-issues',1274,'Disputes—international: various talks and confi-
dence-building measures cautiously have begun to
defuse tensions over Kashmir, particularly since the
October 2005 earthquake in the region; Kashmir
nevertheless remains the site of the world’s largest
and most militarized territorial dispute with por-
tions under the de facto administration of China
(Aksai Chin), India (Jammu and Kashmir), and
Pakistan (Azad Kashmir and Northern Areas); UN
Military Observer Group in India and Pakistan has
maintained a small group of peacekeepers since
1949; India does not recognize Pakistan’s ceding
historic Kashmir lands to China in 1964; India and
Pakistan have maintained their 2004 cease-fire in
Kashmir and initiated discussions on defusing the
‘armed standoff in the Siachen glacier region; Paki-
stan protests India’s fencing the highly militarized
Line of Control and construction of the Baglihar
Dam on the Chenab River in Jammu and Kashmir,
which is part of the larger dispute on water shar-
ing of the Indus River and its tributaries; to defuse
tensions and prepare for discussions on a maritime
boundary, India and Pakistan seek technical resolu-
tion of the disputed boundary in Sir Creek estuary
at the mouth of the Rann of Kutch in the Arabian
Sea; Pakistani maps continue to show the Junagadh
claim in India’s Gujarat State; by 2005, Pakistan,
with UN assistance, repatriated 2.3 million Afghan
refugees leaving slightly more than a million, many
of whom remain at their own choosing; Pakistan
has sent troops across and built fences along some
remote tribal areas of its treaty-defined Durand
Line border with Afghanistan, which serve as bases
for foreign terrorists and other illegal activities;
Afghan, Coalition, and Pakistan military meet peri-
odically to clarify the alignment of the boundary on
the ground and on maps
Refugees and internally displaced persons:
refugees (country of origin): 2.9 million (1.9
million registered, 1 million undocumented)
(Afghanistan) (2013)
IDPs: 758,000 (primarily includes IDPs who
remain displaced by conflict in the Federally
Administered Tribal Areas (FATA) and Khyber-
Paktunkwa Province that peaked in 2009) (2013)
illicit drugs: significant transit area for Afghan
drugs, including heroin, opium, morphine, and `
hashish, bound for Iran, Western markets, the Gult
States, Africa, and Asia; financial crimes related to
drug trafficking, terrorism, corruption, and smug-
gling remain problems; opium poppy cultivation
estimated to be 2,300 hectares in 2007 with 600
of those hectares eradicated; federal and provin-
cial authorities continue to conduct anti-poppy
campaigns that utilizes forced ¢radication, fines,
and arrests
557
PALAU ISLANDS <9 uout
Agere tertu
MELEKEOK SE yore
x .
L REGROMD Koror
Pombo
Angar
SONSORAL
ISLANDS !
BiG Bari
‘Ware
Hansa Heer','731683a26d227e14ce029966d3138920f155c0edb3ce719dfea4e570ba722778','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fa962d4c0a1c799ac3d585edd39569467070223418f8d987be604f9479b1b2f6',2025,'PW','Palau','transnational-issues',1281,'Disputes—international: maritime delineation
negotiations continue with Philippines, Indonesia
Refugees and internally displaced persons:
IDPs: at least 843,000 (government troops fight-
ing the Moro Islamic Liberation Front, the Abu
Sayyaf Group, and the New People’s Army; clan
feuds; natural disasters (December 2012 Typhoon
Bopha) (2013)
illicit drugs: domestic methamphetamine produc-
tion has been a growing problem in recent years
despite government crackdowns; major consumer
of amphetamines; longstanding marijuana pro-
ducer mainly in rural areas where Manila’s control
is limited
PITCAIRN ISLANDS
Poeun
IRIA
Miano
ADATASTOWN,
a
aravwres ovea
Bn AA
Disputes—international: none','83073e8be2d28e86ac3dc703e802910f2764a2c1ab6147fd8d0615ebe51882e4','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8ce974ff7bb89a4960ac9137cb3acf19e24cde2260c3713ca814a76d7ff5a603',2025,'PA','Panama','transnational-issues',1291,'Disputes—international: organized illegal nar-
cotics operations in Colombia operate within the
remote border region with Panama
Refugees and internally displaced persons:
refugees (country of origin): 15,598 (Colombia)
(2011)
illicit drugs: major cocaine transshipment point
and primary money-laundering center for narcotics
revenue; money-laundering activity is especially
heavy in the Colon Free Zone; offshore financial
center; negligible signs ot coca cultivation; moni-
toring of financial transactions is improving; offi-
cial corruption remains a major problem
563
THE CIA WORLD FACTBOOK','1da276c52f1b20287ab797f0ec591bf697155b8d4514a71e2624021acd7a0a8b','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1ba604629f0b2e6f0a1cb0eb1e7c8012195bc7c21637a7bb200cd4145f558529',2025,'PG','Papua New Guinea','transnational-issues',1301,'Disputes—tinternational: relies on assistance
from Australia to keep out illegal cross-border
activities from primarily Indonesia, including
goods smuggling, illegal narcotics trafficking, and
squatters and secessionists
Refugees and internally displaced persons:
refugees (country of origin): 9,368 (Indonesia)
(2011)
Trafficking in persons: current situation: Papua
New Guinea is a source, destination, and transit
country for men, women, and children subjected
to sex trafficking and forced labor; women and
children are subjected to sex trafficking and
domestic servitude; trafficked men are forced
to labor in logging and mining camps; migrant
women and teenage girls from Malaysia, Thailand,
China, and the Philippines are subjected to sex
trafficking; men from China are transported to the
country for forced labor
tier rating: Tier 3—Papua New Guinea does not
fully comply with the minimum standards for the
elimination of trafficking and is not making sig-
nificant efforts to do so; despite the government''s
acknowledgement of trafficking as a problem in the
country, the government did not investigate any
suspected trafficking offenses, prosecute or con-
vict any trafficking offenders under existing laws,
address allegations of officials complicit in human
trafficking crimes, or identify or assist any traffick-
ing victims (2008)
Illicit drugs: major consumer of cannabis
PARACEL ISLANDS
vesaer Means
ene
Ake TATE —
joa yao
iina VAG n
pog
am
PINEA
4.
a
fate ventory
Denese
Disputes—international: occupied by China,
also claimed by Taiwan and Vietnam','10a87f0a07b21ce01647753910317a993ca903f77ad0c2f922cb733cf6e4a552','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4d6d1f73541ef1c50deb4d75e428548337e7389bcc38a7a278744e439f8853c0',2025,'PE','Peru','transnational-issues',1313,'Disputes—international: Chile and Ecuador
rejected Peru’s November 2005 unilateral legisla-
tion to shift the axis of their joint treaty-defined
maritime boundaries along the parallels of latitude
to equidistance lines which favor Peru; organized
illegal narcotics operations in Colombia have pen-
etrated Peru’s shared border; Peru rejects Bolivia''s
claim to restore maritime access through a sover-
eign corridor through Chile along the Peruvian
border
Refugees and internally displaced persons:
IDPs: 150,000 (civil war from 1980-2000; most
IDPs are indigenous peasants in Andean and Ama-
zonian regions; as of 2011, no new information on
the situation of these IDPs) (2007)
Illicit drugs: until 1996 the world’s largest coca
leaf producer, Peru is now the world’s second larg-
est producer of coca leaf, though it lags far behind
Colombia; cultivation of coca in Peru was esti-
mated at 40,000 hectares in 2009, a slight decrease
over 2008; second largest producer of cocaine, esti-
mated at 225 metric tons of potential pure cocaine
in 2009; finished cocaine is shipped out from
Pacific ports to the international drug market;
increasing amounts of base and finished cocaine,
however, are being moved to Brazil, Chile, Argen-
tina, and Bolivia for use in the Southern Cone or
trafsshipment to Europe and Africa; increasing
domestic drug consumption
575
| * CHINA
Baturigos®
Mindoro
Palawan
b,
Puerto
Princgesa','305e8bf36344eedb3f9afd19991daaf7c88bb41ddf0b94a3357a21399881334c','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d506801bb989071f9e5b480b9bd98760001d60ea8e58cd3b22cd7c11b3db884e',2025,'PH','Philippines','transnational-issues',1324,'Disputes—international: Philippines
sovereignty over Scarborough Reef (also claimed
by China together with Taiwan) and over cer-
tain of the Spratly Islands, known locally as
the Kalayaan (Freedom) Islands, also claimed
by China, Malaysia, Taiwan, and Vietnam; the
2002 “Declaration on the Conduct of Parties in
the South China Sea,” has eased tensions in the
claims
Spratly Islands but falls short of a legally binding
“code of conduct” desired by several of the dispu-
tants; in March 2005, the national oil companies
of China, the Philippines, and Vietnam signed a
joint accord to conduct marine seismic activities
in the Spratly Islands; Philippines retains a dor-
mant claim to Malaysia’s Sabah State in northern
Borneo based on the Sultanate of Sulu’s granting
the Philippines Government power of attorney to
pursue a sovereignty claim on his behalf; mari-
time delimitation negotiations continue with
Disputes—international: all of the Spratly
Islands are claimed by China (including Tai-
wan) and Vietnam; parts of them are claimed
by Brunei, Malaysia and the Philippines; despite
no public territorial claim to Louisa Reef, Brunei
implicitly lays claim by including it within the
natural prolongation of its continental shelf and
basis for a seabed median with Vietnam; claim-
ants in November 2002 signed the “Declaration
on the Conduct of Parties in the South China
Sea,” which has eased tensions but falls short of
a legally binding “code of conduct”; in March
2005, the national oil companies of China, the
Philippines, and Vietnam signed a joint accord to
conduct marine seismic activities in the Spratly
Islands
679
THE CIA WORLD FACTBOOK
Jarina
.
"Mannar
iomaire
"Anuradhapura
erettaam
Polonnaruwe’ +
5
> Batticaloa
-Matale
Negombo, oKandy
COLOMBO, ——
S
i
F . Ao P Badulia
Jayawardenepura *Ratnapura
Kotte *Beruwala
= Kalmunar
Galle','88aed2979eebe85953e804448c813ad083306e03a8d0de5b473844fdc5c5154d','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6db77c2dc3ca90dc0dee936283cc061b2e713a36b9ca595c4b2416726a4ddbaa',2025,'PL','Poland','transnational-issues',1328,'berraet
Kolobrzeg
gpm
*Szezecin
K
Disputes—international: as a member state that
forms part of the EU’s external border, Poland has
implemented the strict Schengen border rules to
restrict illegal immigration and trade along its east-
ern borders with Belarus and Ukraine
Refugees and internally displaced persons:
refugees (country of origin): 14,897 (Russia)
(2011)
Illicit drugs: despite diligent counternarcotics
measures and international information sharing
on cross-border crimes, a major illicit producer
of synthetic drugs for the international market;
minor transshipment point for Southwest Asian
heroin and Latin American cocaine to Western
Europe
, PORTUGAL','419102246c3d51670ecde6dc084fd59bf4072ae286be9629e10333bc23cb7b90','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c307f8d3247da9b79f4ce44ce3c66779d4e2fc55156889954c0e4bd1842a8bf9',2025,'PT','Portugal','transnational-issues',1343,'Disputes—international: Portugal does not rec-
ognize Spanish sovereignty over the territory of
Olivenza based on a difference of interpretation of
the 1815 Congress of Vienna and the 1801 Treaty
of Badajoz
illicit drugs: seizing record amounts of Latin
American cocaine destined for Europe; a Euro-
pean gateway for Southwest Asian heroin; trans-
shipment point for hashish from North Africa to
Europe; consumer of Southwest Asian heroin','58813d5fad7847929139d9f7aee8e6936643076be8558cc5782eaf8af02581a9','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c5b2a7cb776e3d5b7bdab966d8f75edf2170dfe033c34e7cc45648521e55399e',2025,'PR','Puerto Rico','transnational-issues',1350,'Disputes—international: increasing numbers
of illegal migrants from the Dominican Republic
cross the Mona Passage to Puerto Rico each year
looking for work
591
Madinat p
ash Shamal, ~
+ T''AI Khuwayt
Ras Laffan *
industnal City
Umm
Salal “Afi,
Umm Selft®
Muhammed ia
Ar Rayyan® x
Al Wakrāh¿
Umm Sa''id,
SAUDI
ARABIA
10
‘The alin ot MUS y “et iEn
Disputes—international: none
797
WAKE ISLAND
Pomo
istand
Wilkes
island','4322aa94c942ca99d265b0b95c8b9284b5c779d9d5b667d192d3f6d8cbce5a7a','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9cd6ea846dbceb077471b61c2f2e2138dfd7b60052a2fd5f0d51d069c5a1db31',2025,'QA','Qatar','transnational-issues',1359,'Disputes—international: none
595
/Oradea Clup
) N
d bone: ania
aa «Tarqu-
Mutes
Sibu
Manwan, &
3 6 +'' 2m
En TRANSYLVANIAN AL” Braias -g ''
Ploegh Tuten
HAREST //
f Arad
N
. glimigoara
t
Brasov
RULGARIA
ao uae
e __4
D pai','d1800d1bcf9dc1b8ca1e06db58dba5f7eb6b26ddac00b3ec7aa4f07b2569eda2','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0437d7ef58099e5148ef6c4c2071e10829becf6be6643908777f3ec12c583431',2025,'RW','Rwanda','transnational-issues',1363,'| | RWANDA
. *Gisenyt
+
to 3 eXibuye
ny
s”
seyangugu
Disputes—international: Burundi and Rwanda
dispute two sq km (0.8 sq mi) of Sabanerwa, a
farmed area in the Rukurazi Valley where the
Akanyaru/Kanyaru River shifted its course south-
ward after heavy rains in 1965; fighting among
ethnic groups—loosely associated political rebels,
armed gangs, and various government forces in
Great Lakes region transcending the boundaries
of Burundi, Democratic Republic of the Congo
(DROC), Rwanda, and Uganda—abated substan-
tially from a decade ago due largely to UN peace-
keeping, international mediation, and efforts
by local governments to create civil societies;
nonetheless, 57,000 Rwandan refugees still reside
in 21 African states, including Zambia, Gabon,
and 20,000 who fled to Burundi in 2005 and 2006
to escape drought and recriminations from tradi-
tional courts investigating the 1994 massacres;
the 2005 DROC and Rwanda border verification
mechanism to stem rebel actions on both sides of
the border remains in place
Refugees and internally displaced persons:
refugees (country of origin): 57,641 (Democratic
Republic of the Congo) (2012)
IDPs: undetermined (fighting between govern-
ment and insurgency in 1998-99; returning refu-
gees) (2012)
SAINT BARTHELEMY
sy Femgione
v hetan
Wie Tar teers
GUSTAVA sore
me * du vaia
ve
OC ete
le Sawt
Barthereny','e82bd5ee36f4da66d9c39d73808d9d5536707af4c7d23891327da58d990cc0db','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('91d2db9b6c83c7d96708fa10bfe12005c6ab6f287a4e34bacc372673d20ebce6',2025,'TT','Trinidad and Tobago','transnational-issues',1383,'Disputes—international: joins other Carib-
bean states to counter Venezuela’s claim that
Aves Island sustains human habitation, a crite-
rion under United Nations Convention on the
Law of the Sea, which permits Venezuela to
extend its Economic Exclusion Zone/continental
shelf over a large portion of the eastern Carib-
bean Sea
lilicit drugs: transshipment point for South
American drugs destined for the US and Europe;
some money-laundering activity
Geographic coordinates: 13 53 N, 60 58 W
Map references: Central America and the
Caribbean
Area: total:616 sq km
country comparison to the world: 193
land: 606 sq km
water: 10 sq km
Area—comparative: three and a half times the
size of Washington, DC
Land boundaries: 0 km
Coastline: 158 km
Maritime claims: territorial sea: 12 nm
contiguous zone: 24 nm
exclusive economic zone: 200 nm
continental shelf: 200 nm or to the edge of the
continental margin
615
Climate: tropical, moderated by northeast trade
winds; dry season January to April, rainy season
May to August
Terrain: volcanic and mountainous with some
broad, fertile valleys
Elevation extremes: lowest point: Caribbean
Sea 0 m
highest point: Mount Gimie 950 m
Natural resources: forests, sandy beaches, miner-
als (pumice), mineral springs, geothermal potential
Land use: arable land: 4.84%
permanent crops:11.29% . »
other: 83.87% (2011)
Irrigated land: 30 sq km (2007)
Freshwater withdrawal (domestic/industrial/
agricultural): total: 0.02 cu km/yr (NA)
per capita: 98.22 cu m/yr (2005)
Natural hazards: hurricanes; volcanic activity
Environment—current issues: deforestation;
soil erosion, particularly in the northern region
Environment—international agreements:
party to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Endan-
gered Species, Environmental Modification, Haz-
ardous Wastes, Law of the Sea, Marine Dumping,
Ozone Layer Protection, Ship Pollution, Wet-
lands, Whaling signed, but not ratified: none of
the selected agreements
Geography—note: the twin Pitons (Gros Piton
and Perit Piton), striking cone-shaped peaks south
of Soufriere, are one of the scenic natural high-
lights of the Caribbean
PORT OF
SPAIN ~“
Sangre”
Grando
Leas
Ponte -&-Piro, Trinidad
Point “San Femando
Fortin, © F
Chequenes,
¿Spana
Disputes—international: Barbados and Trinidad
and Tobago abide by the April 2006 Permanent
Court of Arbitration decision delimiting a mari-
time boundary and limiting catches of flying fish in
Trinidad and Tobago''s exclusive economic zone; in
2005, Barbados and Trinidad and Tobago agreed to
compulsory international arbitration under United
Nations Convention on the Law of the Sea chal-
lenging whether the northern limit of Trinidad
and Tobago''s and Venezuela’s maritime boundary
extends into Barbadian waters; Guyana has also
expressed its intention to include itself in the arbi-
tration as the Trinidad and Tobago- Venezuela mari-
time boundary may extend into its waters as well
illicit drugs: transshipment point for South
American drugs destined for the US and Europe;
producer of cannabis
Nate en
pea hea)
“kassenne
td
g Skhira,
=
v
i
kenit
Kena NAH
at
lana
lozeur Be ctr
Gaves,','75b66b50bd80b877c8bc25d8f65fc8d3d3c4c83b76515d4ce2a7c3d897325217','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7ee75395b57cc0c09b93bcf299ef947eb2fd09859791b8d08c7783c94b728178',2025,'LC','Saint Lucia','transnational-issues',1392,'Disputes—international: joins other Carib-
bean’ states to counter Venezuela’s claim that
Aves Island sustains human habitation, a crite-
rion under United Nations Convention on the
Law of the Sea, which permits Venezuela to
extend its Economic Exclusion Zone/continental
shelf over a large portion of the eastern Carib-
bean Sea
Illicit drugs: transit point for South American
drugs destined for the US and Europe
of Saint Martin in the Caribbean Sea: Saint Mar-
tin lies east of the US Virgin Islands
Geographic coordinates: 18 05 N, 63 57 W
Map references: Central America and the
Caribbean
Area: total: 54.4 sq km
country comparison to the world: 231
land: 54.4 sq km
water: NEGL
Ared—comparative: more than one-third the
size of Washington, DC
Land boundaries: coral: 15 kin
border countries: Sint Maarten 15 km
Coostline: 58.9 km (for entire island)
Climate: temperature averages 80-85 degrees all
year long; low humidity, gentle trade winds, brief,
intense rain showers; hurricane season stretches
from July to November
Elevation extremes: lowest point: Caribbean
Ocean 0m
highest point: Pic du Paradis 424 m
Natural resources: salt
Natura! hazards: subject to hurricanes from July
to November
Environment—current issues: freshwater supply
is dependent on desalinization of sea water
Geography—note: the island of Saint Martin
is the smallest landmass in the world shared by
two independent states, the French territory of
Saint Martin and the Dutch territory of Sint
Maarten','2660bef50a21ca5d86b0f8ec29319d8465b8b6367b768d51ccd3c48513e1bfa5','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('36ed8fd7dda32dae296a01cf8a312035a7d87f557c901e32cf852c83faac7138',2025,'VC','Saint Vincent and the Grenadines','transnational-issues',1404,'a! a Gondra
Chateaubelan,
e
Gaorgetown
Saati
Vincen KINGSTOWN
Cian
Mayread ~ . TOBAGO CAYS
Ie sate
Limon sian
Disputes—international: joins other Caribbean
states to counter Venezuela''s claim that Aves
Island sustains human habitation, a criterion
under United Nations Convention on the Law
of the Sea, which permits Venezuela to extend its
Economic Exclusion Zone/continental shelf over a
large portion of the eastern Caribbean Sea
illicit drugs: transshipment point for South
American drugs destined for the US and Europe;
small-scale cannabis cultivation
Sava
Matavai
pareto
Sawiooge,
*Faleasju Weitere
AP
mac “Multan E
Upoly','fc27f3ac193831f7e9e573da5a25f61bd81752cdac32127a57cf33145c011770','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b39fb8902fdd686f9926712ddeb4617e7ebdaaf99f28b6f710535e9f4324a713',2025,'WS','Samoa','transnational-issues',1418,'Disputes—international: none
system: general assessment:
627
THE CIA WORLD FACTBOOK','8886095661bdb3d22e1527e1fe50e78efbb78c2a185343946d9cbe63e6f1a4ec','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('35f84da5b84a4e7996fecdc400449515a3a1eff1e370eaf57b2803a86fa1c1ec',2025,'SM','San Marino','transnational-issues',1419,'Domano
e Borgo Maggiore
«SAN MARINO
Acquaviva
ee
a Faetano, /
y
Moate
e Giardino F
i.
Fiorentino -/','52bd646ba3adecada3c8b2175e0a53cdd5e3c1dcea16c4d95c3c70b71a1de530','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a39bc5b6a37c3e1347bafa89c10c93ea67d6cf681e37f5310f1413e2c137fdd2',2025,'ST','Sao Tome and Principe','transnational-issues',1425,'comm Wide Bambon
ithe do ,, * Santo
Principe Anténio
equ 4
Loisa
Gravis
Neves,
Tandados * SÃO TOMÉ
ihade & æ ‘Sant''Ana
Sdo Tome
l INTRODUCTION
Background: Discovered and claimed by Portugal
in the late 15th century, the islands’ sugar-based
'' economy gave way to coffee and cocoa in the 19th
century—all grown with African plantation slave
labor, a form of which lingered into the 20th cen-
tury. While independence was achieved in 1975,
democratic reforms were not instituted until the
late 1980s. The country held its first free elections
in 1991, but frequent internal wrangling between
the various political parties precipitated repeated
changes in leadership and two failed coup attempts
in 1995 and 2003. In 2012, three opposition par-
ties combined in a no confidence vote to bring
down the majority government of former Prime
Minister Patrice TROVOADA. The new govern-
ment of Prime Minister Gabriel Arcanjo Ferreira
DA COSTA is entirely composed of opposition
party members with limited experience in govern-
ance. The recent discovery of oil in the Gulf of
Guinea promises to attract increased attention to
the small island nation.
i GEOGRAPHY
Location: Central Africa, islands in the Gulf of
Guinea, straddling the Equator, west of Gabon
630
Geographic coordinates: 1 00 N, 7 00 E
Map references: Africa
Area: total:964 sq km
country comparison to the world: 185
land: 964 sq km
water: 0 sq km
Area—comparative: more than five times the
size of Washington, DC
Land boundaries: km
Coastline: 209 km
Maritime ciaims: measured from claimed archi-
pelagic baselines
territorial sea: 12 nm
exclusive economic zone: 200 nm
Climate: tropical; not, numia; one rainy season
(October to May)
Terrain: volcanic, mountainous
Elevation extremes: lowest point: Atlantic
Ocean 0 m
highest point: Pico de Sao Tome 2,024 m
Natural resources: fish, hydropower
Land use: arable land:9.06%
permanent crops: 40.62%
other: 50.31% (2011)
Irrigated land: 97 sq km (2003)
Natural hazards: NA
Environment—current Issues: deforestation;
soil erosion and exhaustion
Environment—international agreements: party
to: Biodiversity, Climate Change, Climate Change-
Kyoto Protocol, Desertification, Endangered Spe-
cies, Environmental Modification, Law of the Sea,
Ozone Layer Protection, Ship Pollution, Wetlands
signed, but not ratified: none of the selected
ayreements
Geography—note: the smallest country in Africa;
the two main islands form part of a chain of extinct
volcanoes and both are mountainous
Disputes—international: none','95a80c3a7d686d32f8c0acecdf08fa6d1e18fbc4e6fcb8b26e67b583e6666cc5','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7ce055fd7661780bfe67cfeabc9744c91d798138afe8dec3846c54a7e0b2ae48',2025,'SA','Saudi Arabia','transnational-issues',1437,'iG
Disputes—international: Saudi Arabia has rein-
forced its concrete-filled security barrier along
sections of the now fully demarcated border with
Yemen to stem illegal cross-border activities;
Kuwait and Saudi Arabia continue discussions
on a maritime boundary with Iran; Saudi Arabia
claims Egyptian-administered islands of Tiran and
Sanafir
km of
Refugees and internally displaced persons:
refugees (country of origin): 291,000 (Palestinian
Territories) (2009)
Trafficking in persons: current situation: Saudi
Arabia is a destination country for men and
women subjected to forced labor and to a much
lesser extent, forced prostitution; men and women
from Bangladesh, India, Sri Lanka, Nepal, Paki-
stan, the Philippines, Indonesia, Sudan, Ethio-
pia, Kenya, and many other countries voluntarily
travel to Saudi Arabia as domestic servants or
other low-skilled laborers, but some subsequently
face conditions indicative of involuntary servi-
tude; women, primarily from Asian and African
et ae tg
© “RecharaiTot
*Saimt-Lours
“Louga
er"
Matam ,
`
Tries „Touba
KDAKAR *Diourve!
a _— "*Kaolack
te. 3 Jamvacounda *
. ¢
n n R)
ASAMANCE','fe8a364290dc2b68786179ff5668602bf4c2df5739493001818ee87fb5846488','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f6a486c84a18752ee0ba4789110597dbf5888a8840b8e4006462542a53afe8a9',2025,'SC','Seychelles','transnational-issues',1446,'Disputes—international: Mauritius and Sey-
chelles claim the Chagos Islands (UK-adminis-
tered British Indian Ocean Territory)','126c1a26be8cce6088900e2fdaffb90acbe814bf4cd1f7c53ea3c836e831f150','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('61c397a792c3196a3c6f7347b1331fc739592ce1a58475c26c7414c459357353',2025,'SG','Singapore','transnational-issues',1452,'0 6 tm
o 6 ‘ow
Disputes—international: disputes persist with
Malaysia over deliveries of fresh water to Sin-
gapore, Singapore''s extensive land reclamation
works, bridge construction, and maritime bounda-
ties in the Johor and Singapore Straits; in 2008,
ICJ awarded sovereignty of Pedra Branca (Pulau
Batu Puteh/Horsburgh Island) to Singapore, and
Middle Rocks to Malaysia, but did not rule on
maritime regimes, boundaries, or disposition of
South Ledge; Indonesia and Singapore continue
to work on finalization of their 1973 maritime
boundary agreement by defining unresolved areas
north of Indonesia’s Batam Island; piracy remains
a problem in the Malacca Strait
illicit drugs: drug abuse limited because of aggres-
sive law enforcement efforts; as a transportation
and financial services hub, Singapore is vulnera-
ble, despite strict laws and enforcement, as a venue
for money laundering','15458d8c2c74913749102218d27c29d312ae7dba17e80db81a9ce6cbd7ebe6cc','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9f24ab0bcc94e60e2654febefc4a3f18b9d318beea4c12a35fcd54248319c0f1',2025,'SK','Slovakia','transnational-issues',1465,'Disputes—international: bilateral government,
legal, technical and economic working group
negotiations continued in 2006 between Slovakia
and Hungary over Hungary’s completion of its por-
tion of the Gabcikovo-Nagymaros hydroelectric
dam project along the Danube; as a member state
that forms part of the EU’s external border, Slo-
vakia has implemented the strict Schengen border
tules
Illicit drugs: transshipment point for Southwest
Asian heroin bound for Westem Europe; producer
of synthetic drugs for regional market; consumer
of ecstasy','fad1c37f4beeaac911dd79dcb96076608458ace8f90471bcc10ed734277b22a6','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('97e2ad4cad91eb8f4df0d80e71caac151189a337a78dc90d53716d1df24bae48',2025,'SI','Slovenia','transnational-issues',1471,'Disputes—international: the Croatia-Slovenia
land and maritime boundary agreement, which
would have ceded most of Piran Bay and maritime
access to Slovenia and several villages to Croatia,
remains unratified and in dispute; Slovenia also
protests Croatia''s 2003 claim to an exclusive eco-
nomic zone in the Adriatic; as a member state that
forms part of the EU’s external border, Slovenia
has implemented the strict Schengen border rules
to curb illegal migration and commerce through
southeastern Europe while’ encouraging close
cross-border ties with Croatia
illicit drugs: minor transit point for cocaine
and Southwest Asian heroin bound for Westem
Europe, and for precursor chemicals','e8032fd24d531483dce4ef051474a376c453868b22d57fb1ff29a34ab4796779','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('faf1d47289c229f9661ab762b14e32a338af4a05515527ecb6441520d8c301d3',2025,'SB','Solomon Islands','transnational-issues',1479,'Disputes—international: since 2003, the
Regional Assistance Mission to Solomon Islands,
consisting of police, military, and civilian advi-
sors drawn from 15 countries, has assisted in
reestablishing and maintaining civil and politi-
cal order while reinforcing regional stability and
security','02b9fa342a5da72cf4cc9fee8797528ab8e8566fbe6cd2a81584b200bec8147d','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('816d9b98b698dfbbe62462ed025cc32c1ba5017f826e2cc389948303e75603ec',2025,'ZA','South Africa','transnational-issues',1489,'Disputes—international: South Africa has
placed military units to assist police operations
along the border of Lesotho, Zimbabwe, and
Mozambique to control smuggling, poaching,
and illegal migration; the governments of South
Africa and Namibia have not signed or ratified
the text of the 1994 Surveyor’s General agree-
ment placing the boundary in the middle of the
Orange River
Refugees and internally displaced persons:
refugees (country of origin): 15,186 (Somalia);
12,973 (Democratic Republic of Congo); 5,808
(Angola) (2011)
Illicit drugs: transshipment center for heroin,
hashish, and cocaine, as well as a major cultiva-
tor of marijuana in its own right; cocaine and
heroin consumption on the rise; world’s largest
market for illicit methaqualone, usually imported
illegally from India through various east African
countries, but increasingly producing its own syn-
thetic drugs for domestic consumption; attractive
venue for money launderers given the increasing
level of organized criminal and narcotics activity
in the region and the size of the South African
Disputes—international: Argentina, which
claims the islands in its constitution and briefly
occupied them by force in 1982, agreed in 1995 to
no longer seek settlement by force
SOUTHERN OCEAN
Disputes—international: Antarctic Treaty
defers claims (see Antarctica entry), but Argen-
tina, Australia, Chile, France, NZ, Norway, and
UK assert claims (some overlapping), including
the continental shelf in the Southern Ocean; sev-
eral states have expressed an interest in extending
those continental shelf claims under the United
Nations Convention on the Law of the Sea to
include undersea ridges; the US and most other
states do not recognize the land or maritime
claims of other states and have made no claims
themselves (the US and Russia have reserved
the right to do so); no formal claims exist in the
waters in the sector between 90 degrees west and
150 degrees west
f FRANCE
„Sion Santander
Leon Bibao a e AN
Ewe, Es
Zaragoza,
ve, om
A
MADRID,
Tatragonae
Casteiten
de la Plana,','9955c1e8d7391a08fc167c253453f7108e0d79ea9ac6f226d0b3b6dacf6a9741','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bf602bc5ae557f77d96b54b11ce81b2755dd0b05ea7838054492da3904b8eda4',2025,'ES','Spain','transnational-issues',1495,'Disputes—international: in 2002, Gibraltar
residents voted overwhelmingly by referendum to
reject any “shared sovereignty” arrangement; the
government of Gibraltar insists on equal partici-
pation in talks between the UK and Spain; Spain
disapproves of UK plans to grant Gibraltar greater
autonomy; Morocco protests Spain''s control over
the coastal enclaves of Ceuta, Melilla, and the
islands of Penon de Velez de la Gomera, Penon de
Alhucemas, and Islas Chafarinas, and surround-
ing waters; both countries claim Ista Perejil (Leila
Island); Morocco serves as the primary launching
site of illegal migration into Spain from North
Africa; Portugal does not recognize Spanish sov-
ereignty over the territory of Olivenza based on a
difference of interpretation of the 1815 Congress
of Vienna and the 1801 Treaty of Badajoz
Illicit drugs: despite rigorous law enforcement
efforts, North African, Latin American, Galician,
and other European traffickers take advantage of
Spain’s long coastline to land large shipments
of cocaine and hashish for distribution to the
European market; consumer for Latin American
cocaine and North African hashish; destination
and minor transshipment point for, Southwest
Asian heroin; money-laundering site for Colom-
bian narcotics trafficking organizations and
organized crime
l SPRATLY ISLANDS','eb73f7fb267ecb182669ea92b0bead960a56d26aee307698cc9e7b70655d42bf','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('56075f5b7b7e20ccdf550f2599b853a87bec76e60b731797f4fa955b605f3240',2025,'LK','Sri Lanka','transnational-issues',1505,'Disputes—international: none
Refugees and internally displaced persons:
IDPs: 118,376 (civil war; more than half displaced
prior to 2008; many of the more than 470,000 IDPs
registered as returnees had not reached durable
solutions as of September 2012) (2012)
Omdurman Kassaia/ =
M w
KHARTOU =a','824a79b0013f6a6ace244aed2bb931161546d0c18036666c5bb0946beb3be3fe','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b2cb20f0af03cdcaad0ec6f60b910ffae7feb4bf2a8f4889ee93a59acac96637',2025,'SD','Sudan','transnational-issues',1512,'Disputes—international: the effects of Sudan''s
almost constant ethnic and rebel militia fighting
since the mid-20th century have penetrated all of
the neighboring states; Chad wishes to be a helpful
mediator in resolving the Darfur conflict, and in
2010 established a joint border monitoring force
with Sudan, which has helped to reduce cross-bor-
der banditry and violence; as of 2006, Chad, Ethio-
pia, Kenya, Central African Republic, Democratic
Republic of the Congo, and Uganda provided shel-
ter for over a half million Sudanese refugees, which
include 240,000 Darfur residents driven from their
homes by Janjawid armed militia and Sudanese
military forces; as of January 2011, Sudan, in tum,
hosted about 138,700 Eritreans, 43,000 Chadians,
and smaller numbers of Ethiopians; Sudan accuses
Eritrea of supporting Sudanese rebel groups; efforts
to demarcate the porous boundary with Ethiopia
proceed slowly due to civil and ethnic fighting in
eastern Sudan; Sydan claims but Egypt de facto
administers security and economic development of
Halaib region north of the 22nd parallel bound-
ary; periodic violent skirmishes with Sudanese
residents over water and grazing rights persist
among related pastoral populations along the
border with the Central African Republic; South
Sudan-Sudan boundary represents 1 January 1956
alignment, final alignment pending negotiations
and demarcation; final sovereignty status of Abyei
Area pending negotiations between South Sudan
and Sudan
Refugees and internally displaced persons:
refugees (country of origin): 100,464 (Eritrea);
31,871 (Chad); 4,421 (Ethiopia) (2011)
IDPs: more than 2.4 million (civil war 1983-2005;
ongoing conflict in Darfur region; government and
rebel fighting along South Sudan border) (2011)
Trafficking in persons: current situation: Sudan
is a source, transit, and destination country for
men, women, and children who are subjected to
forced labor and sex trafficking; Sudanese women
and girls, particularly those from rural areas or who
are internally displaced, are vulnerable to forced
labor as domestic workers in homes throughout
the country; some of these women and girls are
subsequently sexually abused by male occupants of
the household or forced to engage in commercial
sex acts; Sudanese women and girls are subjected
to domestic servitude in Middle Eastern countries,
such as Bahrain, Saudi Arabia, and Qatar, and to
forced sex trafficking in European countries; some
Sudanese men who voluntarily migrate to the
Middle East as low-skilled laborers face conditions
indicative of forced labor; Sudanese children tran-
sit Yemen en route to Saudi Arabia, where they
are used in forced begging and street vending, and
reportedly work in exploitative labor situations for
Sudanese traders in the Central African Republic;
Sudan is a transit and destination country for Ethi-
opian and Eritrean women’ subjected to domestic
servitude in Sudan and Middle Eastern countries;
Sudan is a destination for Ethiopian, Somali, and
possibly Thai women subjected to forced prostitu-
tion; Sudanese children in Darfur were forcibly
conscripted, at times through abduction, and used
by armed groups
tier rating: Tier 3—Sudan does not fully comply
with the minimum standards for the elimination
of trafficking and is not making significant efforts
to do so; while the government took some initial
steps to acknowledge the existence of traffick-
ing, draft anti-trafficking legislation, prosecute
suspected traffickers, demobilize and reintegrate
child soldiers, and waive overstay fines for foreign
domestic workers, its efforts to combat human traf-
ficking through law enforcement, protection, or
prevention measures were undertaken in an ad hoc
fashion, rather than as the result of strategic plan-
ning; the government convicted three traffickers,
but did not officially identify trafficking victims or
make public data regarding its efforts to combat
human trafficking; its proxy militias reportedly
unlawfully recruited and used child soldiers during
the reporting period, and it did not take action to
conclude a proposed action plan with the UN to
address the problem (2012)
terdam
ye PARAMARIBO As
7) Nickerie Latydorp” ¢ © y
z ) Abbing
Brokopondo, z
aiiim aeii','a10232d49610b1815410ecf7fc0a3d3139367a488e55d4ae086a5dd9bd80995c','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c93990339dfb7e0d90d1af8c7a41e0b34aee3787db1c251baf258edaa99625b6',2025,'SR','Suriname','transnational-issues',1521,'Disputes—international: area claimed by
French Guiana between Riviere Litani and
Riviere Marouini (both headwaters of the Law
a); Suriname claims a triangle of land between
the New and Kutari/Koetari rivers in a historic
dispute over the headwaters of the Courantyne;
Guyana seeks United Nations Convention on the
Law of the Sea arbitration to resolve the long-
standing dispute with Suriname over the axis of
the territorial sea boundary in potentially oil-rich
waters
illicit drugs: growing transshipment point for
South American drugs destined for Europe via the
Netherlands and Brazil; transshipment point for
arms-for-drugs dealing
SVALBARD
| SVALBARD l
Ny-
Aiesund
>
SRE Ra,
Fonand
pew ek
Spitsbergen
- LONGYEARBYEN
Barentsburg, *
__ Sveapiuyas
“7
ae
—
Hornsund’” `','42217658d188233701d44f89003f47ff02919ebf64d32cc73bc678b182c76037','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9c963ba39e055541741d1a550a48680d7e5ed5f460f2ef3629844954675a58d2',2025,'SE','Sweden','transnational-issues',1530,'Disputes—international: none
Refugees and internally displaced persons:
refugees (country of origin): 27,367 Iraq; 17,602
Somalia; 6,620 Afghanistan; 5,529 Serbia: 5,123
Eritrea (2011)','14d41fbcb770f6ce79bb1404d7285eac7029c3198199f9cf3390daf4eab3feb7','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ce380fce9f66498fb0cb4b1eec3663fe1b124c8444303bf4a2e73644c0d3c5ee',2025,'CH','Switzerland','transnational-issues',1531,'SWITZERLAND i
wee pti BESMARY
- mn ee RN
= i j
ron
Disputes—international: none
Refugees and internally displaced persons:
refugees {country of origin): 9,592 Eritrea (2011)
illicit drugs: a major international financial
center vulnerable to the layering and integration
stages of money laundering; despite significant
legislation and reporting requirements, secrecy
rules persist and nonresidents are permitted to
conduct business through offshore entities and
various intermediaries; transit country for and
consumer of South American cocaine, Southwest
Asian heroin, and Western European synthetics;
domestic cannabis cultivation and limited ecstasy
production
Disputes—international: Golan Heights is
Israeli-occupied with the almost 1,000-strong
UN Disengagement Observer Force patrolling a
buffer zone since 1964; lacking a treaty or other
documentation describing the boundary, portions
of the Lebanon-Syria boundary are unclear with
several sections in dispute; since 2000, Lebanon
has claimed Shab’a Farms in the Golan Heights;
2004 Agreement and pending demarcation settles
border dispute with Jordan
Refugees and internally displaced persons:
refugees (country of origin): 486,946 (Palestinian
Refugees (UNRWA)); 87,741 (Lraq)
IDPs: more than 2 million (ongoing civil war since
2011) (2012)
Trafficking in persons: current situation: Prior
to the ongoing political uprising and violent
unrest, Syria was principally a destination coun-
try for women and children subjected to forced
labor or sex trafficking; women from Indonesia,
the Philippines, Somalia, and Ethiopia were
recruited by employment agencies to work in
Syria as domestic servants, but are subsequently
subjected to conditions of forced labor; some
economically desperate Syrian children are sub-
jected to conditions of. forced labor within the
country, particularly by organized street begging
rings; undocumented Filipina domestic work-
ers continue to be sent to Syria; the daughters
of some Iraqi refugees are reportedly contracted
to work as maids but made to be prostitutes or
forced laborers; some Syrian women in Lebanon
may be forced to engage in street prostitution
and small numbers of Syrian girls are report-
edly brought to Lebanon: for the purpose of
prostitution
tier rating: Tier 3—the government does not
fully comply with the minimum standards for
the elimination of trafficking and is not making
significant efforts to do so; the government did
not demonstrate evidence of increasing efforts
to investigate and punish trafficking offenses
provide protective services to victims, widely
inform the public about human trafficking, or
provice much-needed anti-trafficking training
to law enforcement and social welfare officials
(2012)
Wlicit drugs: a transit point for opiates, hash-
ish, and cocaine bound for regional and Western
markets; weak anti-money-laundering controls
and bank privatization may leave it vulnerable to
money laundering
TAIPEI Koeli
Zhong, % -à
Janan
Tatung,
Disputes—international: involved in com-
plex dispute with Brunei, China, Malaysia,
the Philippines, and Vietnam over the Spratly
Islands, and with China and the Philippines
over Scarborough Reef; the 2002 “Declara-
tion on the Conduct of Parties in the South
China Sea” has eased tensions but falls short
of a legally binding “code of conduct” desired
by several of the disputants; Paracel Islands are
occupied by China, but claimed by Taiwan and
Vietnam; in 2003, China and Taiwan became
more vocal in rejecting both Japan’s claims to
the uninhabited islands of the Senkaku-shoto
(Diaoyu Tai) and Japan’s unilaterally declared
exclusive economic zone in the East China
Sea where all parties engage in hydrocarbon
prospecting
Illicit drugs: regional transit point for heroin,
methamphetamine, and precursor chemicals;
transshipment point for drugs to Japan; major
problem with domestic consumption of metham-
phetamine and heroin; rising problems with use of
ketamine and club drugs','393f580341af3767126abb86a29d854e545f3150c7fa32de722dea96f57cdf2f','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('60f6efab0b19e3a707ea186eabac019920eba64b42c02a01650c1ecd0657891d',2025,'TJ','Tajikistan','transnational-issues',1545,'Disputes—international; in 2006, China and
Tajikistan pledged to commence demarcation of
the revised boundary agreed to in the delimitation
of 2002; talks continue with Uzbekistan to delimit
THE CIA WORLD FACTBOOK
border and remove minefields; disputes in Isfara
Valley delay delimitation with Kyrgyzstan
lilicit drugs: major transit country for Afghan
narcotics bound for Russian and, to a lesser extent,
Western European markets; limited illicit cultiva-
tion of opium poppy for domestic consumption;
Tajikistan seizes roughly 80% of all drugs captured
in Central Asia and stands third worldwide in sei-
zures of opiates (heroin and raw opium); signifi-
cant consumer of opiates
TANZANIA
* os
BURUD e
Muyusoma a P
» P
Mwanza?
7
. 3
f migorna
\\
t
£
N
Innga,
\\
= a "Sumbawanga
i n ¿Mbeya
Disputes—international: Tanzania still hosts
more than a half million refugees, more than any
other African country, mainly from Burundi and
the Democratic Republic of the Congo, despite
the international community''s efforts at repa-
triation; disputes with Malawi over the boundary
in Lake Nyasa (Lake Malawi) and the meander-
ing Songwe River remain dormant
Refugees and internally displaced persons:
refugees (country of origin): 67,549 (Burundi)
(2011); 62,978 (Democratic Republic of the
Congo) (2012)
Illicit drugs: targeted by traffickers moving hashish,
Afghan heroin, and South American cocaine trans-
ported down the East African coastline, through air-
ports, or overland through Central Africa; Zanzibar
likely used by traffickers for drug smuggling; traffick-
ets in the past have recruited Tanzanian couriers to
move drugs through Iran into East Asia
717
THE CIA WORLD FACTBOOK
i ae
Thani
hon Kaen f
Khorat
Plateau
Phitsanulok
y
| Nakhon”
P Sawan /<
Surai” Nakhon Si
Thani = Shammarat
Phuket"
a ppongania
Rat Yai"
MALAYSIA *','14c5563da4049b61a70eed9f34b593ce27c1065f09f3737f1f0bf0c519df961a','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('794ad5dca5d18d0f96d5c9f57832ee02bb7c2c56d925a70f35e70ee41146cdc6',2025,'TH','Thailand','transnational-issues',1554,'Disputes—international: separatist violence in
Thailand’s predominantly Malay-Muslim southern
provinces prompt border closures and controls with
Malaysia to stem insurgent activities; Southeast
Asian states have enhanced border surveillance to
check the spread of avian flu; talks continue on com-
pletion of demarcation with Laos but disputes remain
over several islands in the Mekong River; despite
continuing border committee talks, Thailand must
THE CIA WORLD FACTBOOK
deal with Karen and other ethnic rebels, refugees,
and illegal cross-border activities; Cambodia and
Thailand dispute sections of boundary; in 2011 Thai-
larid and Cambodia resorted to arms in the dispute
over the location of the boundary on the precipice
surmounted by Preah Vihear temple ruins, awarded
to Cambodia by ICJ decision in 1962 and part of a
planned UN World Heritage site; Thailand is study-
ing the feasibility of jointly constructing the Hatgyi
Dam on the Salween river near the border with
Burma; in 2004, international environmentalist pres-
sure prompted China to halt construction of 13 dams
on the Salween River that flows through China,
Burma, and Thailand; 140,000 mostly Karen refugees
fleeing civil strife, political upheaval and economic
stagnation in Burma live in remote camps in Thai-
land near the border
Refugees and internally displaced persons:
refugees (country of origin): 88,148 (Burma)
(2011)
IDPs: undetermined (resurgence in ethno-national-
ist violence in south of country since 2004) (2011)
Illicit drugs: a minor producer of opium, heroin,
and marijuana; transit point for illicit heroin en
route to the international drug market from Burma
and Laos; eradication efforts have reduced the area
of cannabis cultivation and shifted some production
to neighboring countries; opium poppy cultivation
has been reduced by eradication efforts; also a drug
money-laundering center; minor role in metham-
phetamine production for regional consumption;
major consumer of methamphetamine since the
1990s despite a series of government crackdowns','43345325d44c26613324c3c1711b4d9588eb57d508681f14bf4cb24cff41c93d','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5ab3aff1e8192adfbd03dfe82d0064462c6cbb3ce050136f98c6b2970552735b',2025,'TL','Timor-Leste','transnational-issues',1562,'Disputes—international: three stretches of land
borders with Timor-Leste have yet to be delim-
ited, two of which are in the Oecussi exclave
area, and no maritime or’ Economic Exclusion
Zone boundaries have been established between
the countries; maritime boundaries with Indone-
sia remain unresolved; many refugees w ho left
Timor-Leste in 2003 still reside in Indonesia and
refuse repatriation; in 2007, Australia and Timor-
Leste signed a 50-year development zone and
revenue sharing agreement in lieu of a maritime
boundary
illicit drugs: NA','53da28d0d4e2b68a16e45c0e620a87a67e6fb693a6fe7951fc87dc48cbb3dc43','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('21ea8368409d7206e32dc048bcdc52b583036a7f67d51663cdb9400678c23466',2025,'TG','Togo','transnational-issues',1569,'Disputes—international: in 2001, Benin claimed
Togo moved boundary monuments—joint com-
mission continues to resurvey the boundary; in
2006, 14,000 Togolese refugees remain in Benin
and Ghana out of the 40,000 who fled there in
2005; talks continue between Benin and Togo
on funding the Adjrala hydroelectric damon the
Mona River _ ’
Refugees and internally displaced persons:
refugees (country of origin): 13,676 (Ghana);
5,151 (Cote d''Ivoire) (2011)
IDPs: undetermined (2012)
illicit drugs: transit hub for Nigerian heroin and
cocaine traffickers; money laundering not a signifi-
cant problem','fa970097fbc8a8d4853fcb5d75f46f1736b88338e924ec4845655b213c5a1b60','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6ee5d8db4ddd49977274ba6297663fb4c9bc11b0b9e0f66d8b2bb56fd35b69a6',2025,'TO','Tonga','transnational-issues',1577,'female: 77.09 years (2013 est.)
Total fertility rate: 3.46 children born/woman
(2013 est.) i
country comparison to the world: 48
Health expenditures: 5.1% of GDP (2010)
country comparison to the world: 135
Physicians density: 0.29 physicians/1,000 popu-
lation (2002)
Hospital bed density: 2.6 beds/1,000 population
(2010)
Drinking water source:
Improved:
urban: 100% of population
rural: 100% of population
total: 100% of population (2010 est.)
Sanitation facility access:
Improved:
urban: 98% of population
rural: 96% of population
total: 96% of population
Unimproved:
urban: 2% of population
rural: 4% of population
total: 4% of population (2010 est.)
HIV/AIDS—adult prevalence rate: NA
HIV/AIDS—people living with HIV/AIDS: NA
HIV/AIDS—deaths: NA
Obesity—adult prevalence rate: 57.6% (2008)
country comparison to the world: 5
Education expenditures: 3.9% of GDP (2004)
country comparison to the world: 116
Literacy: definition: can read and write Tongan
and/or English total population: 98.9%
male: 98.8% ai-
female: 99% (1999 est.)
School life expectancy (primary to tertiary
education): total: 14 years
male: 14 years
female: 14 years (2007)
Unemployment, youth ages 15-24: total: 11.9%
country comparison to the world: 98
male: 9.9%
+ female: 15.1% (2003)
Country name: conventional long form: King-
dom of Tonga
conventional short form: Tonga
local long form: Pule’anga Tonga
local short form: Tonga
former: Friendly Islands
Government type: constitutional monarchy
Capital: name: Nuku''alofa
geographic coordinates: 21 08 S, 175 12 W
time difference: UTC+13 (18 hours ahead of
Washington, DC during Standard Time)
Administrative divisions: 3 island groups;
Ha''apai, Tongatapu, Vava’u
Independence: 4 June 1970 (from UK
protectorate)
National holiday: National Day, 4 November
(1875)
Constitution: 4 November 1875; revised 1967
Legal system: English common law
International law organization participation:
has not submitted an IC] jurisdiction declaration;
non-party state to the ICCt
Suffrage: 21 years of age; universal
Executive branch: chief of state: King TUPOU
VI (since 18 March 2012); note—King George
TUPOU V died on 18 March 2012 in Hong Kong;
he was succeeded by his brother Crown Prince
TUPOUTO’A Lavaka, who took the throne name
TUPOU VI
head of government: Prime Minister Lord
Siale’ataonga TU''IVAKANO (since 22 December
2010)
cabinet: Cabinet is nominated by the prime minis-
ter and appointed by the monarch (For more infor-
mation visit the World Leaders website
note: there is also a Privy Council that advises the
monarch
elections: the monarchy is hereditary; prime minister
and deputy prime minister elected by and from the
members of parliament and appointed by the monarch
election results: - Lord Siale’ataonga
TU''IVAKANO elected by parliament on 21
December 2010 with 14 of 26 votes
Legistative branch: unicameral Legislative Assem-
bly or Fale Alea (26 seats—9 for nobles elected from
among the country’s 29 nobles, 17 members elected
by popular vote to serve four-year terms)
elections: last held on 25 November 2010 (next to
be held in 2014)
election results: Peoples Representatives: per-
cent of vote—independents 67.3%, Democratic
Party 28.5%, other 4.2%; seats—Democratic
Party 12, independents 5
Judicial branch: Supreme Court (judges are
appointed by the monarch); Court of Appeal
(Chief Justice and high court justices from over-
seas chosen and approved by Privy Council)
Political parties and leaders: Democratic
Party of the Friendly Islands [Samuela ‘Akilisi
POHIVA]; People’s Democratic Party or PDP
[Tesina FUKO]; Sustainable Nation-Building
Party [Sione FONUA]; Tonga Democratic Labor
Party [NA]; Tonga Human Rights and Democracy
Movement or THRDM [NA]
Political pressure groups and leaders: Human
Rights and Democracy Movement Tonga or
HRDMT [Rev. Simote VEA, chairman]; Public
Servant’s Association [Finau TUTONE]
International organization participation: ACP,
ADB, AOSIS, C, FAO, G-77, IAEA, IBRD,
ICAO, ICRM, IDA, IFAD, IFC, IFRCS, IHO,
IME IMO, IMSO, Interpol, IOC, ITU, ITUC
(NGOs), OPCW, PIF Sparteca, SPC, UN,
UNCTAD, UNESCO, UNIDO, UPU, WCO,
WHO, WIPO, WMO, WTO
Diplomatic representation in the US: chief of
mission: Ambassador Sonatane Tu’akinamolahi
TAUMOEPEAU-TUPOU
chancery: 800 Second Avenue, Suite 400B, New
York, NY 10017
telephone: [1] (800) 345-654
consulate(s) general: San Francisco
Diplomatic representation from the US: the US
does not have an embassy in Tonga; the US ambas-
sador to Fiji is accredited to Tonga
Flag description: red with a bold red cross on
a white rectangle in the upper hoist-side corner;
the cross reflects the deep-rooted Christianity in
Tonga; red represents the blood of Christ and his
sacrifice; white signifies purity
National symbol(s): red cross on white field;
arms equal length
` 731
National anthem: name: “Ko e fasi ʻo e tu”i ʻo
e ‘Otu Tonga” (Song of the King of the Tonga
Islands)
lyrics/music: Uelingatoni Ngu TUPOUM-
ALOHI/Karl Gustavus SCHMITT
note: in use since 1875; the anthem is more
commonly known as “Fasi Fakafonua” (National
Song)
Disputes—international: None','73d881f17d8f728298bc65d9648ab42da34c0bf0da8dea1b4dfe6e9f1e6b7a5e','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0a6328b29f8c63b6ec3e92b51c148473e736d61381e53c013ad61944230bc23e',2025,'TN','Tunisia','transnational-issues',1593,'Disputes—international: none
and attacks attributed to the KGK increased. Turkey
joined the UN in 1945 and in 1952 it became a mem-
ber of NATO. In 1964, Turkey became an associate
member of the European Community. Over the past
devade, it has undertaken many reforms to strengthen
its democracy and economy; it began accession mem-
bership talks with the European Union in 2005,
Disputes—international: complex maritime, air,
and territorial disputes with Greece in the Aegean
Sea; status of north Cyprus question remains;
Syria and Iraq protest Turkish hydrological pro-
‘jects to control upper Euphrates waters; Turkey
has expressed concern over the status of Kurds in
Iraq; in 2009, Swiss mediators facilitated an accord
reestablishing diplomatic ties between Armenia
and Turkey, but neither side has ratified the agree-
ment and the rapprochement effort has faltered;
Turkish authorities have complained that blasting
from quarries in Armenia might be damaging the
medieval ruins of Ani, on the other side of the
Arpacay valley;
Refugees and internally displaced persons:
refugees (country of origin): 11,322 (Iraq) (2012);
377,154 (Syria) (2013)
IDPs: 954,000-1.2 million (displaced from 1984-
2005 because of fighting between Kurdish PKK
and Turkish military; most IDPs are Kurds from
eastern and southeastern provinces; no informa-
tion available on persons displaced by develop-
ment projects) (2006)
illicit drugs: key transit route for Southwest
Asian heroin to Western Europe and, to a lesser
extent, the US—via air, land, and sea routes;
major Turkish and other international trafficking
organizations operate out of Istanbul; laboratories
to convert imported morphine base‘into heroin
exist in remote regions of Turkey and near Istan-
bul; government maintains strict controls over
areas of legal opium poppy cultivation and over
output of poppy straw concentrate; lax enforce-
ment of money-laundering controls','2121d2b42ae8a73fd5a30de40d6657d20cf3cac1beea9651888830a516591a2b','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fe6475367a21980f0414d65917a6af679e7f86f4bc0c52634bc16d481ece790a',2025,'TM','Turkmenistan','transnational-issues',1594,'. TURKMENISTAN
gio
RAPANHSTAH
MATAKHS™ AN
=
ká
Pi urkmenbasy
Paikanabat
<Gyzylarbat Turk °
ASHGABAT nat
Mary, ,Bayramaly -_
.
Disputes—international: cotton monoculture
.in Uzbekistan and Turkmenistan creates water-
sharing difficulties for Amu Darya river states; field
demarcation of the boundaries with Kazakhstan
commenced in 2005, but Caspian seabed delimi-
tation remains stalled with Azerbaijan, Iran, and
Kazakhstan due to Turkmenistan’s indecision over
how to allocate the sea’s waters and seabed; bilat-
eral talks continue with Azerbaijan on dividing
the seabed and contested oilfields in the middle of
the Caspian
Illicit drugs: transit country for Afghan narcotics
bound for Russian and Western European markets;
transit point for heroin precursor chemicals bound
for Afghanistan','20a3b28fb956c911ddeb6a9a78414aa4634e07ff84483476ddf3d94e70ad1b24','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('779e302c08530def16eb8f51975f7fb4599b515aa43c577ab1d3ab98d3088362',2025,'TC','Turks and Caicos Islands','transnational-issues',1601,'Background: The islands were part of the UK’s
Jamaican colony until 1962, when they assumed
the status of a separate crown colony upon
Jamaica''s independence. The governor’of The
Bahamas oversaw affairs from 1965 to 1973. With
Bahamian independence, the islands received a
separate governor in 1973. Although independ-
ence was agreed upon for 1982, the policy was
reversed and the islands remain a British overseas
territory.
Disputes—international: have received Haitians
fleeing economic and civil disorder
Illicit drugs: transshipment point for South
American narcotics destined for the US and
Europe
* Vatupu
oia ao
FUNAFUT} ,
Funatist
Fangaus a
Nukulaelae
Nunaxita','fe53fc460b3a27c8c9d925ffdbd40b52d1c508c46922b0bb7bbd944e07a58db1','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7c025c58be22b045d6b063503934494fd7f7273a77943a7424fef8ed84951f74',2025,'TV','Tuvalu','transnational-issues',1617,'Disputes—international: None
SGUTH SUDAN
i
i (Fort Portal
KAMPALA por sine
Pin Ent » 4
~ Enebos,
Masaka,
Manabe in [KEN NA
TANZANIA
| yoan TANZANIA: OS
g
5 100m Y >','4da710f051bd78f851d4d4f502a215819b7cb7ffcdfd5b048d4f07bf1b9373e1','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('635ad140c65def8775bffe6e5b00b43ae86e29ab3c169da00b02bad511349ae1',2025,'UG','Uganda','transnational-issues',1626,'Disputes—international: Uganda is subject
to armed fighting among hostile ethnic groups,
rebels, armed gangs, militias, and various gov-
ernment forces that extend across-its borders;
Uganda hosts 209,860 Sudanese, 27,560 Con-
golese, and 19,710 Rwandan refugees, while
Ugandan refugees as well as members of the
Lord’s Resistance Army (LRA) seek shelter in
southern Sudan and the Democratic Republic
of the Congo’s Garamba National Park; LRA
forces have also attacked Kenyan villages across
the border
Refugees and internally displaced persons: ref-
ugees (country of origin): 18,268 (Sudan); 12,998
(Rwanda) (2011); 111,107 (Democratic Republic
of Congo) (2012); 29,355 (Somalia) (2013)
IDPs: 30,000 (displacement in northern Uganda
because of fighting between government forces
and the Lord’s Resistance Army; as of 2011, most
of the 1.8 million people displaced to IDP camps
at the height of the conflict had returned home
or resettled, but many had not found durable solu-
tions) (2011)
assessed as meeting most international standards,
The following month, Ukraine’s parliament, the
Rada, approved a vote of no-confidence prompt-
ing Yuliya TYMOSHENKO to resign from her
post as prime minister. In October 2012; Ukraine
held Rada elections, widely criticized by West-
ern observers as flawed due to use of government
resources to favor ruling party candidates, interfer-
ence with media access, and harassment of opposi-
tion candidates.','ac88cbc1cfb3ee73594f9333b5f14012be29f47ca67b85646ad7774e2ed0cd28','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('31039f2dbdb39c5021f3fdd65856a88e793a28348b34043f776fff3c9b043d34',2025,'AE','United Arab Emirates','transnational-issues',1644,'Disputes—international: boundary agreement
was signed and ratified with Oman in 2003 for
entire border, including Oman’s Musandam Pen-
insula and Al Madhah enclaves, but contents of
the agreement and detailed maps showing the
alignment have not been published; Iran and UAE
dispute Tunb Islands and Abu Musa Island, which
Iran occupies
Illicit drugs: the UAE is a drug transshipment point
for traffickers given its proximity to Southwest Asian
drug-producing countries; the UAE''s position as a
major financial center makes it vulnerable to money
laundering; anti-money-laundering controls improv-
ing, but informal banking remains unregulated
Central African Customs and Economic Union
ultra-high-frequency','5b89320bd1417a553a9a05ac88dff6dd1999536ad1942b68b60938aba5495c98','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('671b0d6d07debb721df15993c7f5d0e060ad08af303c6816e80451b42a0213e1',2025,'GB','United Kingdom','transnational-issues',1653,'Disputes—international: in 2002, Gibraltar
residents voted overwhelmingly by referendum
to reject any “shared sovereignty” arrangement
between the UK and Spain; the Government of
Gibraltar insisted on equal participation in talks
between the two countries; Spain disapproved of
UK plans to grant Gibraltar greater autonomy;
Mauritius and Seychelles claim the Chagos Archi-
pelago (British Indian Ocean Territory); in 2001,
the former inhabitants of the archipelago, evicted
1967—1973, were granted U.K. citizenship and
the right of return, followed by Orders in Coun-
cil in 2004 that banned rehabitation, a High
Court ruling reversed the ban, a Court of Appeal
refusal to hear the case, and a Law Lords’ decision
in 2008 denied the right of return; in addition,
the United Kingdom created the world’s largest
marine protection area around the Chagos islands
prohibiting the extraction of any natural resources
therein; UK rejects sovereignty talks requested by
Argentina, which still claims the Falkland Islands
{Islas Malvinas) and South Georgia and the South
Sandwich Islands; territorial claim in Antarctica
(British Antarctic Territory) overlaps Argentine
claim and partially overlaps Chilean claim; Ice-
land, the UK, and Ireland dispute Denmark’s claim
that the Faroe Islands’ continental shelf extends
beyond 200 nm
Refugees and internally displaced persons: ref-
ugees (country of origin): 19,668 Somalia; 15,652
Iraq; 14,424 Afghanistan; 11,632 fran; 9,851 Eri-
trea; 5,776 Turkey; 5,737 Sri Lanka (2011)
llticit drugs: producer of limited amounts of syn-
thetic drugs and synthetic precursor chemicals;
major consumer ot Southwest Asian heroin, Latin
American cocaine, and synthetic drugs; money-
laundering center
United Nations
Joint United Nations Program on HIV/AIDS
United Nations Assistance Mission in Afghanistan
African Union/United Nations Hybrid Operation in Darfur
Union of South American Nations
United Nations Convention on the Law of the Sea, also know as LOS
United Nations Conference on Trade and Development
United Nations Drug Control Program
United Nations Democracy Fund
United Nations Disengagement Observer Force
United Nations Development Program
United Nations Environment Program
United Nations Educational, Scientific, and Cultural Organization
United Nations Peace-keeping Force in Cyprus
United Nations Population Fund
UN-Habitat
UNHGR
UNICEF
UNICRI
UNIDIR
UNIDO
UNIFIL
UNISFA
WETU
Whaling
ABBREVIATIONS
United Nations Center for Human Settlements
United Nations High Commissioner for Refugees
United Nations Children’s Fund
United Nations Interregional Crime and Justice Research Institute
United Nations Institute for Disarmament Research
United Nations Industrial Development Organization
United Nations Interim Force in Lebanon
United Nations Interim Force for Abyei
United Nations Institute for Training and Research
United Nations Interim Administration Mission in Kosovo
United Nations Mission in Liberia
United Nations Mission in the Sudan
United Nations Mission in South Sudan
United Nations Integrated Mission in Timor-Leste
United Nations Military Observer Group in India and Pakistan
United Nations Operation in Cote d''Ivoire
United Nations Office of Drugs and Crime
United Nations Office of Project Services
United Nations Research Institute for Social Development
United Nations Relief and Works Agency for Palestine Refugees in the Near East
United Nations Security Council
Untied Nations System Staff College
United Nations Truce Supervision Organization
United Nations University
World Tourism Organization
Universal Postal Union','f1e221fd6cb890456982191dfb1b2da33905f6d91dc8d412a32b51f8c104d59d','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b54ded3f8dbc62727049c7576bf9f5038ab082a497a92eebc1911c00ad350550',2025,'US','United States','transnational-issues',1662,'Disputes—international: the US has intensified
domestic security measures and is collaborating
closely with its neighbors, Canada and Mexico,
to monitor and control legal and illegal person-
nel, transport, and commodities across the inter-
national borders; abundant rainfall in recent years
along much of the Mexico-US border region has
ameliorated periodically strained water-sharing
arrangements; 1990 Maritime Boundary Agree-
ment in the Bering Sea still awaits Russian Duma
ratification; Canada and the United States dispute
how to divide the Beaufort Sea and the status of
the Northwest Passage but continue to work coop-
eratively to survey the Arctic continental shelf;
The Bahamas and US have not been able to agree
on a maritime boundary; US Naval Base at Guan-
tanamo Bay is leased from Cuba and only mutual
agreement or US abandonment of the area can
terminate the lease; Haiti claims US-administered
Navassa Island; US has made no territorial claim
in Antarctica (but has reserved the right to do so)
and does not recognize the claims of any other
states; Marshall Islands claims Wake Island; lokelau
included American Samoa’s Swains Island*among
the islands listed in its 2006 draft constitution
Refugees and Internally displaced persons: ref-
ugees (country of origin): the US admitted 76,000
refugees during FY2012 including 15,070 (Bhutan);
14,160 (Burma); 12,163 (Iraq); 4,911 (Somalia);
1,948 (Cuba); 1,758 (Iran); 1,346 (Eritrea)
Ilicit drugs: world’s largest consumer of cocaine
(shipped from Colombia through Mexico and
the Caribbean), Colombian heroin, and Mexican
heroin and marijuana; major consumer of ecstasy
and Mexican methamphetamine; minor consumer
of high-quality Southeast Asian heroin; illicit
producer of cannabis, marijuana, depressants,
stimulants, hallucinogens, and methamphetamine;
money-laundering center
773
THE CIA WORLD FACTBOOK
UNITED STATES PACIFIC ISLAND WILDLIFE REFUGES
Disputes—international: none
Background: Montevideo, founded by the Spanish
in 1726 as a military stronghold, soon took advantage
of its natural harbor to become an important com-
mercial center. Claimed by Argentina but annexed
by Brazil in 1821, Uruguay declared its independence
four years later and secured its freedom in 1828 after a
three-year struggle. The administrations of President
Jose BATLLE in the early 20th century established
widespread political, social, and economic reforms
that established a statist tradition. A violent Marx-
ist urban guerrilla movement named the Tupamaros,
launched in the late 1960s, leg Uruguay''s president
to cede control of the government to the military in
1973. By yearend, the rebels had been crushed, but
the military continued to expand its hold over the
povernment. Civilian rule was not réstored until
1985. In 2004, the left-of-center Frente Amplio
Coalition won national elections that effectively
ended 170 years of political contro! previously held
by the Colorado and Blanco parties. Uruguay''s politi-
cal and labor conditions are among the freest on the
conunent.
Union of Soviet Socialist Republics (Soviet Union); used for information dated before
25 December 1991
Coordinated Universal Time
ultra violet
very-high-frequency
very small aperture terminal `
West African Development Bank
West African Economic and Monetary Union
World Confederation of Labor
World Customs Organization
Convention on Wetlands of International Importance Especially As Waterfowl Habitat
Western European Union
World Food Program
World Federation of Trade Unions
International Convention for the Regulation of Whaling
World Health Organization
World Intellectual Property Organization
World Meteorological Organization
Warsaw Pact
World Trade Organization
Zangger Committee
827
APPENDIX B
INTERNATIONAL ORGANIZATIONS AND GROUPS |
advanced developing countries a
another term for those less developed countries (LDCs) with particularly rapid industrial development; see newly industrializing economies
(NIEs)
advanced economies
a term used by the International Monetary FUND (IMF) for the top group in its hierarchy of advanced.economies, countries in transi-
tion, and developing countries; it includes the following 33 advanced economies: Australia, Austria, Belgium, Canada, Cyprus, Czech
Republic, Denmark, Finland, France, Germany, Greece, Hong Kong, Iceland, Ireland, Israel, Italy, Japan, South Korea, Luxembourg, Malta,
Netherlands, NZ, Norway, Portugal, Singapore, Slovak Republic, Slovenia, Spain, Sweden, Switzerland, Taiwan, UK, US; note—this group
would presumably also cover the following nine smaller countries of Andorra, Bermuda, Faroe Islands, Guernsey, Holy See, Jersey, Liechten-
stein, Monaco, and San Marino that are included in the more comprehensive group of “developed countries”
African Development Bank Group (AfDB)
note—tregional multilateral development finance institution temporarily located in Tunis, Tunisia; the Bank Group consists of the African
Development Bank, the African Development Fund, and the Nigerian Trust Fund
established—10 September 1964
aim—to promote economic development and social progress
regional members—(53) Algeria, Angola, Benin, Botswana, Burkina Faso, Burundi, Cameroon, Cape Verde, Central African Republic,
Chad, Comoros, Democratic Republic of the Congo, Republic of the Congo, Cote d''Ivoire, Djibouti, Egypt, Equatorial Guinea, Eritrea,
Ethiopia, Gabon, The Gambia, Ghana, Guinea, Guinea-Bissau, Kenya, Lesotho, Liberia, Libya, Madagascar, Malawi, Mali, Mauritania,
Mauritius, Morocco, Mozambique, Namibia, Niger, Nigeria, Rwanda, Sao Tome and Principe, Senegal, Seychelles, Sierra Leone, Somalia,
South Africa, Sudan, Swaziland, Tanzania, Togo, Tunisia, Uganda, Zambia, Zimbabwe
nonregional members—(25) Argentina, Austria, Belgium, Brazil, Canada, China, Denmark, Finland, France, Germany, India, Italy, Japan,
South Korea, Kuwait, Netherlands, Norway, Portugal, Saudi Arabia, Spain, Sweden, Switzerland, UAE(ADF members only), UK, US
African Union (AU) a!
note—replaces Organization of African Unity (OAU) established—8 July 2001
aim—to achieve greater unity among African States; to defend states’ integrity and independence; to accelerate political, social, and eco-
nomic integration; to encourage international cooperation; to promote democratic principles and institutions
members—(54) Algeria, Angola, Benin, Botswana, Burkina Faso, Burundi, Cameroon, Cape Verde, Central African Republic, Chad,
Comoros, Democratic Republic of the Congo, Republic of the Congo, Cote d''Ivoire, Djibouti, Egypt, Equatorial Guinea, Eritrea, Ethiopia,
Gabon, The Gambia, Ghana, Guinea (suspended), Guinea-Bissau, Kenya, Lesotho, Liberia, Libya, Madagascar, Malawi, Mali, Mauritania,
Mauritius, Mozambique, Namibia, Niger, Nigeria, Rwanda, Sahrawi Arab Democratic Republic (Western Sahara), Sao Tome and Principe,
Senegal, Seychelles, Sierra Leone, Somalia, South Africa, South Sudan, Sudan, Swaziland, Tanzania, Togo, Tunisia, Uganda, Zambia, ©','55d92836964978dd5c685f03ee463794ffb07007bdc34ec21c17bb83e98f996d','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2ba070a74547a2fc35f432311abad82d58a6f84eaab55b41bb2ca0e643b6d805',2025,'UY','Uruguay','transnational-issues',1669,'Disputes—international: in 2010, the IC] ruled
in favor of Uruguay’s operation of two paper mills
on the Uruguay River, which forms the border
with Argentina; the two countries formed a joint
pollution monitoring regime; uncontested bound-
ary dispute between Brazil and Uruguay over Bra-
ziliera/Brasiliera Island in the Quarai/Cuareim
River leaves the tripoint with Argentina in ques-
tion; smuggling of firearms and narcotics continues
to be an issue along the Uruguay-Brazil border
IWicit drugs: small-scale transit country for drugs
mainly bound for Europe, often through sea-borne
containers; law enforcement corruption; money
laundering because of strict banking secrecy laws;
weak border control along Brazilian frontier; increas-
ing consumption of cocaine base and synthetic drugs','84bda7795a03a2ed175abb577f4f5bbf0325e298b86901fd3c8d3f405f0556b9','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('41e8ada0b6c0d1426b4e3892c89dfaa40689b60df2050ec28444d54c164f0a6e',2025,'UZ','Uzbekistan','transnational-issues',1678,'Disputes—international: prolonged drought and
cotton monoculture in Uzbekistan and Turkmeni-
stan created water-sharing difficulties for Amu
Darya river states; field demarcation of the bound-
aries with Kazakhstan commenced in 2004; border
delimitation of 130 km of border with Kyrgyzstan
is hampered by serious disputes around enclaves
and other areas
Refugees and internally displaced persons:
IDPs: undetermined (government forcibly relo-
cated an estimated 3,400 people from villages near
the Tajikistan border in 2000-2001; no new data is
available) (2012) 1
Trafficking in persons: current situation:
Uzbekistan is a source country for women and
girls trafficked to Kazakhstan, Russia, the Mid-
dle East, and Asia for the purpose of commercial
sexual exploitation; mėn are trafficked to Kazakh-
stan and Russia for purposes of forced labor in the
construction, cotton, and tobacco industries; men
and women are also trafficked internally for the
purposes of domestic servitude, forced labor in the
agricultural and construction industries, and for
commercial sexual exploitation
tier rating: Tier 2 Watch List—Uzbekistan is on
the Tier 2 Watch List for its negligible progress in
ending forced labor, including forced child labor,
in the annual cotton harvest, and did not make
efforts to investigate or prosecute povernment offi-
cials suspected to be complicit in forced labor; the
government did not conduct any awareness cam-
paigns regarding forced labor in the annual cotton
harvest or other internal trafficking, but did con-
tinue its previous awareness campaigns about the
dangers of transnational trafficking (2008)
Illicit drugs: transit country for Afghan narcotics
„bound for Russian and, to a lesser extent, West-
ern European markets; limited illicit cultivation
of cannabis and small amounts of opium poppy for
domestic consumption; poppy cultivation almost
wiped out by government crop eradication pro-
gram; transit point for heroin precursor chemicals
bound for Afghanistan
783
TORRES
We Ws
Fae BANKS
hes ISLANDS
ee)
. Espiritu
Santo
Maw
Ta MURA
a
Logane. Aoba Pantecosi
Aminan
Malakuta
ty? SHEPHERD
~ ISLANDS
Z
o me
ca
Foran
PORT-VILA
Erromango
ANKA
Futuna
. ©
© Tanne j
S
Anata
. New
Caledonia
Pmt
Malthe
Yate
iginn clarmod by
ASUA sana AANT','4b50070797414e427208cfa6084c4069f3c37511012096226770c36da3177a42','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b662386f7d9b4b36b60e9680f4bf584956bb001bc446f105477986c78122e524',2025,'VU','Vanuatu','transnational-issues',1688,'Disputes—international: Matthew and Hunter
Islands east of New Caledonia claimed by Vanuatu
and France
PMaracaibo Casei gé ARAG è
+
*
* Vaipnara''
Barquiaimeto® > ~ "Matacay
Barcelone -~','1b28f739dad0906f92db829b18ad64ebf21a68cd85ed01534f41facdefb5b7a8','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bb114927e23334c0591c1196dc8d1da5169d348755942e63b86bfefd39c88cca',2025,'VN','Viet Nam','transnational-issues',1695,'Disputes—international: southeast Asian states
have enhanced border surveillance to check the
spread of avian flu; Cambodia and Laos protest
Vietnamese squatters and armed encroachments
along border; Cambodia accuses Vietnam of a
wide variety of illicit cross-border activities; pro-
gress on a joint development area with Cambodia
is hampered by an unresolved dispute over sover-
eignty of offshore islands; an estimated 300,000
Vietnamese refugees reside in China; establish-
ment of a maritime boundary with Cambodia is
hampered by unresolved dispute over the sover-
eignty of offshore islands; the decade-long demar-
cation of the China-Vietnam land boundary was
completed in 2009; China occupies the Paracel
Islands also claimed by Vietnam and Taiwan; Bru-
nei claims a maritime boundary extending beyond
as far as a median with Vietnam, thus asserting
an implicit claim to Lousia Reef; the 2002 “Dec-
laration on the Conduct of Parties in the South
China Sea” has eased tensions but falls short of
a legally binding “code of conduct” desired by
several of the disputants; Vietnam continues to
expand construction of facilities in the Spratly
Islands; in March 2005, the national oil com-
panies of China, the Philippines, and Vietnam
signed a joint accord to conduct marine seismic
activities in the Spratly Islands; Economic Exclu-
sion Zone negotiations with Indonesia are ongo-
ing, and the two countries in Fall 2011 agreed to
work together to reduce illegal fishing along their
maritime boundary
Illicit drugs: minor producer of opium poppy;
probable minor transit point for Southeast Asian
heroin; government continues to face domestic
opium/heroin/methamphetamine addiction prob-
lems despite longstanding crackdowns
VIRGIN ISLANDS |
Saint Crom
Chrisnansted,-
Lmetree Bay, _
Ger','6850ca7f7c52d9aa6c358adab1435bc89d343ddb01dd8f5f23bc07f0f0d9c307','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bbba60a612457ca895f9c582fb22b8d5933db5fd4dd9cf86454f4b329c14a1df',2025,'EH','Western Sahara','transnational-issues',1709,': WESTERN SAHARA
Patian
“
f Pl —
H
|
Í
“ad Dakhla , |
Ausert ee
z j C, Has FE WTS
i
Disputes—international: many neighboring
states reject Moroccan administration of Western
Sahara; several states have extended diplomatic
relations to the “Sahrawi Arab Democratic Repub-
lic” represented by the Polisario Front in exile in
Algeria, while others recognize Moroccan sover-
eignty over Western Sahara; most of the approxi-
mately 102,000 Sahrawi refugees are sheltered in
camps in Tindouf, Algeria
Disputes—-international: stretching over
250,000 km, the world’s 322 international land
boundaries separate 195 independent states and
Wortd
71 dependéncies, areas of special sovereignty, and
other miscellaneous entities; ethnicity, culture,
race, religion, and language have divided states
into separate political entities as much as history,
physical terrain, political fiat, or conquest, result-
ing in sometimes arbitrary and imposed bounda-
ries; most maritime states have claimed limits that
include territorial seas and exclusive economic
zones; overlapping limits due to adjacent or oppo-
site coasts create the potential for 430 bilateral
maritime boundaries of which 209 have agree-
ments that include contiguous and non-contigu-
ous segments; boundary, borderland/resource, and
territorial disputes vary in intensity from managed
or dormant to violent or militarized; undemar-
cated, indefinite, porous, and unmanaged bounda-
ties tend to encourage illegal cross-border activi-
ties, uncontrolled migration, and confrontation;
territorial disputes may evolve from historical and/
or cultural claims, or they may be brought on by
resource competition; ethnic and cultural clashes
continue to be responsible for much of the terri-
torial fragmentation and internal displacement of
the estimated 6.6 million people and cross-border
displacements of 8.6 million refugees around the
world as of early 2006; just over one million refu-
gees were repatriated in the same period; other
sources of contention include access to water
and mineral (especially hydrocarbon) resources,
fisheries, and arable land; armed conflict prevails
not so much between the uniformed armed forces
of independent states as between stateless armed
entities that detract from the sustenance and wel-
fare of local populations, leaving the community
of nations to cope with resultant refugees, hun-
ger, disease, impoverishment, and environmental
degradation .
Refugees and internally displaced persons:
the United Nations High Commissioner for
Refugees { UNHCR) estimated in June 2011 that
there were 43.7 million people forcibly displaced
worldwide; this includes 15.1 million refugees and
as many as 27.5 million IDPs in more than 40
countries (2011)
Trafficking in persons: current situation:
approximately 800,000 people, mostly women and
children, are trafficked annually across national
borders, not including millions trafficked within
their own countries; at least 80% of the victims
are female and up to 50% are minors; 75% of all
victims are trafficked into commercial sexual
exploitation; almost two-thirds of the global vic-
tims are trafficked intra-regionally within East
Asia and the Pacific (260,000 to 280,000 peo-
ple) and Europe and Eurasia (170,000 to 210,000','f5e69e7c54568eda4cd64dcb76e078788109ed39e26d0185111c1f7e3147f551','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bd5d14f6a880f1dd0c61cd48edb9d45a3f4239f85edaeecf761b3a9f497244a3',2025,'CG','Congo','transnational-issues',1730,'not available
North American Free Trade Agreement
Nonaligned Movement
North Atlantic Treaty Organization
Nordic Council
Nuclear Energy Agency
negligible
National Geospatial-Intelligence Agency
nongovernmentat organization
Nordic Investment Bank
newly industrializing country
newly industrializing economy :
new independent states
nautical mile
Nordic Mobile Telephone
Nuclear Suppliers Group
Treaty Banning Nuclear Weapons Tests in the Atmosphere, in Outer Space, and Under
Water
825
SHF
Ship Pollution
SICA
Sparteca
SPC
TEU
Tropical Timber 83
Tropical Timber 94
UN-AIDS
UNAMA
UNAMID
UNASUR
UNCLOS
UNCTAD
UNDCP
UNDEF
UNDOF
UNDP
UNEP
UNESCO
UNFICYP
UNFPA
826
THE CIA WORLD FACTBOOK','3aaf5a1bb468c95dab5b6f4732a80696c1052f2c7693e1fc0a746a204c77d824','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);

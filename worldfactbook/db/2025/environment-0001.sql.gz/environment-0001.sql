SET NAMES utf8mb4;
CREATE TABLE IF NOT EXISTS worldfactbook_chunks (
  chunk_id CHAR(64) NOT NULL,
  edition_year SMALLINT UNSIGNED NOT NULL,
  entity_code VARCHAR(24) NOT NULL DEFAULT '',
  entity_name VARCHAR(160) NOT NULL DEFAULT '',
  category VARCHAR(96) NOT NULL,
  ordinal INT UNSIGNED NOT NULL,
  content MEDIUMTEXT NOT NULL,
  content_sha256 CHAR(64) NOT NULL,
  source_provider VARCHAR(64) NOT NULL,
  source_identifier VARCHAR(255) NOT NULL,
  source_format VARCHAR(32) NOT NULL,
  source_sha256 CHAR(64) NOT NULL,
  source_url TEXT NOT NULL,
  extractor VARCHAR(64) NOT NULL,
  PRIMARY KEY (chunk_id),
  KEY idx_wfb_year_category (edition_year, category),
  KEY idx_wfb_entity_year (entity_code, edition_year),
  KEY idx_wfb_source_sha (source_sha256)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('75e9b0f49a017bbf617f047bb2c4fa068d1298c5d02a02c107c5dc71e0313972',2025,'AF','Afghanistan','environment',4,'Environment - current issues:
limited natural freshwater resources; inadequate supplies of potable water; soil degradation; overgrazing; deforestation (much of the remaining forests are being cut down for fuel and building materials); desertification; air and water pollution in overcrowded urban areas
Environment - international agreements:
party to:
Biodiversity, Climate Change, Climate Change-Kyoto Protocol, Climate Change-Paris Agreement, Comprehensive Nuclear Test Ban, Desertification, Endangered Species, Environmental Modification, Hazardous Wastes, Marine Dumping-London Convention, Nuclear Test Ban, Ozone Layer Protection
signed, but not ratified:
Law of the Sea, Marine Life Conservation
Climate:
arid to semiarid; cold winters and hot summers
Land use:
agricultural land:
58.1% (2018 est.)
arable land:
11.8% (2018)
permanent crops:
0.3% (2018)
permanent pasture:
46% (2018)
forest:
1.8% (2018 est.)
other:
40.1% (2018)
Urbanization:
urban population:
26.9% of total population (2023)
rate of urbanization:
3.34% annual rate of change (2020-25 est.)
Food insecurity:
severe localized food insecurity: due to civil conflict, population displacement, and economic slowdown -
between November 2021 and March 2022, during the winter lean season, the food insecurity situation was expected to deteriorate and the number of people in “Crisis” or above was likely to increase to 22.8 million, about 35% more than during the same season in 2020/21; following the developments of August 2021 in the country, the international aid flows, an important element of public spending, were halted; the food security situation and agricultural livelihoods in the country is likely to significantly deteriorate in the coming months due to cumulative and cascading impact of multiple shocks, including weather, conflict, economic crisis and the lingering effects of the COVID-19 pandemic (2022)
Revenue from forest resources:
0.2% of GDP (2018 est.)
comparison ranking:
94
Revenue from coal:
0.45% of GDP (2018 est.)
comparison ranking:
12
Air pollutants:
particulate matter emissions:
62.49 micrograms per cubic meter (2019 est.)
carbon dioxide emissions:
8.67 megatons (2016 est.)
methane emissions:
90.98 megatons (2020 est.)
Waste and recycling:
municipal solid waste generated annually:
5,628,525 tons (2016 est.)
Major lakes (area sq km):
salt water lake(s):
Ab-e Istadah-ye Muqur (endorheic basin) - 520 sq km
Major rivers (by length in km):
Amu Darya (shared with Tajikistan [s], Turkmenistan, and Uzbekistan [m]) - 2,620 km; Helmand river source (shared with Iran) - 1,130 km
note
– [s] after country name indicates river source; [m] after country name indicates river mouth
Major watersheds (area sq km):
Indian Ocean drainage:
Indus (1,081,718 sq km)
Internal
(endorheic basin)
drainage:
Amu Darya (534,739 sq km); Tarim Basin (1,152,448 sq km)
Total water withdrawal:
municipal:
200 million cubic meters (2020 est.)
industrial:
170 million cubic meters (2020 est.)
agricultural:
20 billion cubic meters (2020 est.)
Total renewable water resources:
65.33 billion cubic meters (2020 est.)','8653bd9760d3b2398fc59f5c6185d03a9107f2c3606de25198d09844a9e90018','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('90642bfe0a8facace2025b5cbfef75af5a80e5e002827eaa3b4b33fa0b25d7f0',2025,'AF','Afghanistan','environment',16,'Environment - current issues:
hunting around the salt lake; note - breeding place for loggerhead and green turtles; only remaining colony of griffon vultures is on the base
Climate:
temperate; Mediterranean with hot, dry summers and cool winters','86f2086701d39aaf6b87caae87e9d1978d535d029a1434a49f5436cfa53e109a','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a9d171b4337e8f84fa6af14244a1e44d32aa04dff028b5817778147a8c497d53',2025,'AL','Albania','environment',25,'Environment - current issues:
deforestation; soil erosion; water pollution from industrial and domestic effluents; air pollution from industrial and power plants; loss of biodiversity due to lack of resources for sound environmental management
Environment - international agreements:
party to:
Air Pollution, Air Pollution-Nitrogen Oxides, Air Pollution-Sulphur 85, Biodiversity, Climate Change, Climate Change-Kyoto Protocol, Climate Change-Paris Agreement, Comprehensive Nuclear Test Ban, Desertification, Endangered Species, Hazardous Wastes, Law of the Sea, Ozone Layer Protection, Ship Pollution, Tropical Timber 2006, Wetlands
signed, but not ratified:
none of the selected agreements
Climate:
mild temperate; cool, cloudy, wet winters; hot, clear, dry summers; interior is cooler and wetter
Land use:
agricultural land:
42.8% (2018 est.)
arable land:
22.3% (2018 est.)
permanent crops:
3% (2018 est.)
permanent pasture:
17.4% (2018 est.)
forest:
28.8% (2018 est.)
other:
28.2% (2018 est.)
Urbanization:
urban population:
64.6% of total population (2023)
rate of urbanization:
1.29% annual rate of change (2020-25 est.)
Revenue from forest resources:
0.18% of GDP (2018 est.)
comparison ranking:
95
Revenue from coal:
0.03% of GDP (2018 est.)
comparison ranking:
40
Air pollutants:
particulate matter emissions:
16.28 micrograms per cubic meter (2019 est.)
carbon dioxide emissions:
4.54 megatons (2016 est.)
methane emissions:
2.55 megatons (2020 est.)
Waste and recycling:
municipal solid waste generated annually:
1,142,964 tons (2015 est.)
Major lakes (area sq km):
fresh water lake(s):
Lake Scutari (shared with Montenegro) - 400 sq km
note - largest lake in the Balkans
Major watersheds (area sq km): Atlantic Ocean drainage:
(Black Sea)
Danube (795,656 sq km)
Total water withdrawal:
municipal:
230 million cubic meters (2020 est.)
industrial:
20 million cubic meters (2020 est.)
agricultural:
550 million cubic meters (2020 est.)
Total renewable water resources:
30.2 billion cubic meters (2020 est.)','af044bcbfdea5856fbb1e1b9e8ff19b4cb4cfcd6638e945e4b3e40e534b8c220','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('53a6e37e1a28a59c5d6175494aeb7855e75e4e0052686947fa186dfb63ead786',2025,'DZ','Algeria','environment',37,'Environment - current issues:
air pollution in major cities; soil erosion from overgrazing and other poor farming practices; desertification; dumping of raw sewage, petroleum refining wastes, and other industrial effluents is leading to the pollution of rivers and coastal waters; Mediterranean Sea, in particular, becoming polluted from oil wastes, soil erosion, and fertilizer runoff; inadequate supplies of potable water
Environment - international agreements:
party to:
Biodiversity, Climate Change, Climate Change-Kyoto Protocol, Climate Change-Paris Agreement, Comprehensive Nuclear Test Ban, Desertification, Endangered Species, Environmental Modification, Hazardous Wastes, Law of the Sea, Ozone Layer Protection, Ship Pollution, Wetlands
signed, but not ratified:
Nuclear Test Ban
Climate:
arid to semiarid; mild, wet winters with hot, dry summers along coast; drier with cold winters and hot summers on high plateau; sirocco is a hot, dust/sand-laden wind especially common in summer
Land use:
agricultural land:
17.4% (2018 est.)
arable land:
3.2% (2018 est.)
permanent crops:
0.4% (2018 est.)
permanent pasture:
13.8% (2018 est.)
forest:
0.8% (2018 est.)
other:
81.8% (2018 est.)
Urbanization:
urban population:
75.3% of total population (2023)
rate of urbanization:
1.99% annual rate of change (2020-25 est.)
Revenue from forest resources:
0.1% of GDP (2018 est.)
comparison ranking:
113
Revenue from coal:
0% of GDP (2018 est.)
comparison ranking:
159
Air pollutants:
particulate matter emissions:
22.68 micrograms per cubic meter (2019 est.)
carbon dioxide emissions:
150.01 megatons (2016 est.)
methane emissions:
49.94 megatons (2020 est.)
Waste and recycling:
municipal solid waste generated annually:
12,378,740 tons (2016 est.)
municipal solid waste recycled annually:
990,299 tons (2013 est.)
percent of municipal solid waste recycled:
8% (2013 est.)
Major watersheds (area sq km):
Atlantic Ocean drainage:
Niger (2,261,741 sq km)
Internal
(endorheic basin)
drainage:
Lake Chad (2,497,738 sq km)
Major aquifers:
Lullemeden-Irhazer Aquifer System, Murzuk-Djado Basin, North Western Sahara Aquifer, Taoudeni-Tanezrouft Basin
Total water withdrawal:
municipal:
3.6 billion cubic meters (2020 est.)
industrial:
190 million cubic meters (2020 est.)
agricultural:
6.67 billion cubic meters (2020 est.)
Total renewable water resources:
11.67 billion cubic meters (2020 est.)','b204eaac72e17960555d0eefb2e5936276ca9cc16393b8256f6a831ef5c150ef','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2826382df858ecc60b4bd447b3789b75a233edf152f8912a028909b4d4353e6e',2025,'AS','American Samoa','environment',50,'Environment - current issues:
limited supply of drinking water; pollution; waste disposal; coastal and stream alteration; soil erosion
Climate:
tropical marine, moderated by southeast trade winds; annual rainfall averages about 3 m; rainy season (November to April), dry season (May to October); little seasonal temperature variation
Land use:
agricultural land:
24.5% (2018 est.)
arable land:
15% (2018 est.)
permanent crops:
9.5% (2018 est.)
permanent pasture:
0% (2018 est.)
forest:
75.5% (2018 est.)
other:
0% (2018 est.)
Urbanization:
urban population:
87.2% of total population (2023)
rate of urbanization:
0.26% annual rate of change (2020-25 est.)
Revenue from forest resources:
0% of GDP (2018 est.)
comparison ranking:
167
Revenue from coal:
0% of GDP (2018 est.)
comparison ranking:
83
Waste and recycling:
municipal solid waste generated annually:
18,989 tons (2016 est.)','55cbd92971037ac5f85d8b7f2ed4021ff6d14b77668b9244e823144a4322de80','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9b7e14d9f4e2031ffe3fcf96fbc3b89f7dd1127cd44866759faaa2a3ac469b9f',2025,'AD','Andorra','environment',61,'Environment - current issues:
deforestation; overgrazing of mountain meadows contributes to soil erosion; air pollution; wastewater treatment and solid waste disposal
Environment - international agreements:
party to:
Biodiversity, Climate Change, Climate Change-Paris Agreement, Comprehensive Nuclear Test Ban, Desertification, Hazardous Wastes, Ozone Layer Protection, Wetlands
signed, but not ratified:
none of the selected agreements
Climate:
temperate; snowy, cold winters and warm, dry summers
Land use:
agricultural land:
40% (2018 est.)
arable land:
1.7% (2018 est.)
permanent crops:
0% (2018 est.)
permanent pasture:
38.3% (2018 est.)
forest:
34% (2018 est.)
other:
26% (2018 est.)
Urbanization:
urban population:
87.8% of total population (2023)
rate of urbanization:
0.11% annual rate of change (2020-25 est.)
Revenue from forest resources:
0% of GDP (2018 est.)
comparison ranking:
191
Air pollutants:
particulate matter emissions:
8.52 micrograms per cubic meter (2019 est.)
carbon dioxide emissions:
0.47 megatons (2016 est.)
methane emissions:
0.05 megatons (2020 est.)
Waste and recycling:
municipal solid waste generated annually:
43,000 tons (2012 est.)
Total renewable water resources:
320 million cubic meters (2020 est.)','efdee80a6538487abedc7f37c3597e941e9b45178e60a3f8bd12cea1ae761635','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6bca2bde9954c50083476f626216665ef50270dcdca4a1fa82f2d1f1c0fc2d5d',2025,'AO','Angola','environment',4,'Environment - current issues:
overuse of pastures and subsequent soil erosion attributable to population pressures; desertification; deforestation of tropical rain forest, in response to both international demand for tropical timber and to domestic use as fuel, resulting in loss of biodiversity; soil erosion contributing to water pollution and siltation of rivers and dams; inadequate supplies of potable water
Environment - international agreements:
party to:
Biodiversity, Climate Change, Climate Change-Kyoto Protocol, Climate Change-Paris Agreement, Comprehensive Nuclear Test Ban, Desertification, Endangered Species, Hazardous Wastes, Law of the Sea, Marine Dumping-London Protocol, Ozone Layer Protection, Ship Pollution
signed, but not ratified:
none of the selected agreements
Climate:
semiarid in south and along coast to Luanda; north has cool, dry season (May to October) and hot, rainy season (November to April)
Land use:
agricultural land:
45.7% (2018 est.)
arable land:
3.9% (2018 est.)
permanent crops:
0.3% (2018 est.)
permanent pasture:
41.5% (2018 est.)
forest:
54.3% (2018 est.)
Urbanization:
urban population:
68.7% of total population (2023)
rate of urbanization:
4.04% annual rate of change (2020-25 est.)
Revenue from forest resources:
0.36% of GDP (2018 est.)
comparison ranking:
75
Revenue from coal:
0% of GDP (2018 est.)
comparison ranking:
75
Air pollutants:
particulate matter emissions:
27.16 micrograms per cubic meter (2019 est.)
carbon dioxide emissions:
34.69 megatons (2016 est.)
methane emissions:
23.28 megatons (2020 est.)
Waste and recycling:
municipal solid waste generated annually:
4,213,644 tons (2012 est.)
Major rivers (by length in km):
Rio Zambeze (Zambezi) (shared with Zambia [s], Namibia, Botswana, Zimbabwe, and Mozambique [m]) - 2,740 km; Rio Cubango (Okavango) river source (shared with Namibia and Botswana [m]) - 1,600 km
note
– [s] after country name indicates river source; [m] after country name indicates river mouth
Major watersheds (area sq km):
Atlantic Ocean drainage:
Congo (3,730,881 sq km)
Indian Ocean drainage:
Zambezi (1,332,412 sq km)
Internal (endorheic basin) drainage:
Okavango Basin (863,866 sq km)
Major aquifers:
Congo Basin, Upper Kalahari-Cuvelai-Upper Zambezi Basin
Total water withdrawal:
municipal:
320 million cubic meters (2020 est.)
industrial:
240 million cubic meters (2020 est.)
agricultural:
150 million cubic meters (2020 est.)
Total renewable water resources:
148.4 billion cubic meters (2020 est.)','dce619640f54af47231b484ea87b75f6bd39df1bae98042b291a2d4b80b6ce46','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('43fb0c093da14e67a0cf4dc24c6406ca6db7c936cfad9ee0d5969aa3cb13a54f',2025,'AI','Anguilla','environment',16,'Environment - current issues:
supplies of potable water sometimes cannot meet increasing demand largely because of poor distribution system
Climate:
tropical; moderated by northeast trade winds
Land use:
agricultural land:
0% (2018 est.)
forest:
61.1% (2018 est.)
other:
38.9% (2018 est.)
Urbanization:
urban population:
100% of total population (2023)
rate of urbanization:
0.47% annual rate of change (2020-25 est.)','cc84b67984440ac6ac2e599f60dce6068c34b1be263f266a987635a51a5d33c7','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0056d3c6705f7d839216e4e2c84f58e1cb0275e4b8f0b5356b29d5ab6f9a9237',2025,'AQ','Antarctica','environment',27,'Environment - current issues:
the discovery of a large Antarctic ozone hole in the earth’s stratosphere (the ozone layer) - first announced in 1985 - spurred the signing of the Montreal Protocol in 1987, an international agreement phasing out the use of ozone-depleting chemicals; the ozone layer prevents most harmful wavelengths of ultra-violet (UV) light from passing through the earth’s atmosphere; ozone depletion has been shown to harm a variety of Antarctic marine plants and animals (plankton); in 2016, a gradual trend toward “healing” of the ozone hole was reported; since the 1990s, satellites have shown accelerating ice loss driven by ocean change; although considerable uncertainty remains, scientists are increasing our understanding and ability to model potential impacts of ice loss
Climate:
the coldest, windiest, and driest continent on Earth; severe low temperatures vary with latitude, elevation, and distance from the ocean; East Antarctica is colder than West Antarctica because of its higher elevation; Antarctic Peninsula has the most moderate climate; higher temperatures occur in January along the coast and average slightly below freezing; summers characterized by continuous daylight, while winters bring continuous darkness; persistent high pressure over the interior brings dry, subsiding air that results in very little cloud cover
Land use:
agricultural land:
0% (2018 est.)','458464d92c35be821c7887867be855cdf57336aaa68eea78718a46121a60e18b','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2566d037565cbb4cf2abf481cc43fcb9fbd1bcf8a8afa60ba0d2af301072f394',2025,'AG','Antigua and Barbuda','environment',37,'Environment - current issues:
water management - a major concern because of limited natural freshwater resources - is further hampered by the clearing of trees to increase crop production, causing rainfall to run off quickly
Environment - international agreements:
party to:
Biodiversity, Climate Change, Climate Change-Kyoto Protocol, Climate Change-Paris Agreement, Comprehensive Nuclear Test Ban, Desertification, Endangered Species, Environmental Modification, Hazardous Wastes, Law of the Sea, Marine Dumping-London Convention, Marine Dumping-London Protocol, Nuclear Test Ban, Ozone Layer Protection, Ship Pollution, Wetlands, Whaling
signed, but not ratified:
none of the selected agreements
Climate:
tropical maritime; little seasonal temperature variation
Land use:
agricultural land:
20.5% (2018 est.)
arable land:
9% (2018 est.)
permanent crops:
2.3% (2018 est.)
permanent pasture:
9% (2018 est.)
forest:
18.8% (2018 est.)
other:
60.8% (2018 est.)
Urbanization:
urban population:
24.3% of total population (2023)
rate of urbanization:
0.87% annual rate of change (2020-25 est.)
Revenue from forest resources:
0% of GDP (2018 est.)
comparison ranking:
163
Revenue from coal:
0% of GDP (2018 est.)
comparison ranking:
117
Air pollutants:
particulate matter emissions:
8.3 micrograms per cubic meter (2019 est.)
carbon dioxide emissions:
0.56 megatons (2016 est.)
methane emissions:
0.22 megatons (2020 est.)
Waste and recycling:
municipal solid waste generated annually:
30,585 tons (2012 est.)
Total water withdrawal:
municipal:
10 million cubic meters (2020 est.)
industrial:
2.5 million cubic meters (2017 est.)
agricultural:
1.8 million cubic meters (2017 est.)
Total renewable water resources:
50 million cubic meters (2020 est.)','784e3dddf8115f91c5172a39ff08861ad4b2055e27268458274f7ab0d502753c','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b0bd48d26a6eaa030c406bf541292ba73c45d58780a460756e424b0c050e5d24',2025,'AG','Antigua and Barbuda','environment',47,'Environment - current issues:
climate change; changes in biodiversity; water pollution from use of toxic chemicals; endangered marine species include walruses and whales; fragile ecosystem slow to change and slow to recover from disruptions or damage; thinning polar icepack
Climate:
polar climate characterized by persistent cold and relatively narrow annual temperature range; winters characterized by continuous darkness, cold and stable weather conditions, and clear skies; summers characterized by continuous daylight, damp and foggy weather, and weak cyclones with rain or snow
Marine fisheries:
the Arctic fishery region (Region 18) is the smallest in the world with a catch of only 708 mt in 2019, although the Food and Agriculture Organization assesses that some Arctic catches are reported in adjacent regions; Russia and Canada were historically the major producers; in 2017, Canada, Denmark (Greenland), Iceland, Norway, Russia, and the US, along with the People’s Republic of China, the European Union, Japan, and the Republic of Korea, agreed to a 16 year ban on fishing in the Central Arctic Ocean to allow for time to study the ecological system of these waters
Regional fisheries bodies:
International Council for the Exploration of the Seas','2c906fd0304a33fd9354f16888a2b664a36327fc52ea7c48c30de9157275b481','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('06c3232bb6e1ca02d1eb158b1231f9543b4a6b4c4dbb2c090ae0633492563c77',2025,'AR','Argentina','environment',54,'Environment - current issues:
environmental problems (urban and rural) typical of an industrializing economy such as deforestation, soil degradation (erosion, salinization), desertification, air pollution, and water pollution
Environment - international agreements:
party to:
Antarctic-Environmental Protection, Antarctic-Marine Living Resources, Antarctic Seals, Antarctic Treaty, Biodiversity, Climate Change, Climate Change-Kyoto Protocol, Climate Change-Paris Agreement, Comprehensive Nuclear Test Ban, Desertification, Endangered Species, Environmental Modification, Hazardous Wastes, Law of the Sea, Marine Dumping-London Convention, Nuclear Test Ban, Ozone Layer Protection, Ship Pollution, Wetlands, Whaling
signed, but not ratified:
Marine Dumping-London Protocol, Marine Life Conservation
Climate:
mostly temperate; arid in southeast; subantarctic in southwest
Land use:
agricultural land:
53.9% (2018 est.)
arable land:
13.9% (2018 est.)
permanent crops:
0.4% (2018 est.)
permanent pasture:
39.6% (2018 est.)
forest:
10.7% (2018 est.)
other:
35.4% (2018 est.)
Urbanization:
urban population:
92.5% of total population (2023)
rate of urbanization:
0.97% annual rate of change (2020-25 est.)
Revenue from forest resources:
0.09% of GDP (2018 est.)
comparison ranking:
115
Revenue from coal:
0% of GDP (2018 est.)
comparison ranking:
72
Air pollutants:
particulate matter emissions:
12.04 micrograms per cubic meter (2019 est.)
carbon dioxide emissions:
201.35 megatons (2016 est.)
methane emissions:
120.66 megatons (2020 est.)
Waste and recycling:
municipal solid waste generated annually:
17,910,550 tons (2014 est.)
municipal solid waste recycled annually:
1,074,633 tons (2010 est.)
percent of municipal solid waste recycled:
6% (2010 est.)
Major lakes (area sq km):
fresh water lake(s):
Lago Buenos Aires (shared with Chile) - 2,240 sq km; Lago Argentino - 1,410 sq km; Lago Viedma - 1,090 sq km; Lago San Martín (shared with Chile) - 1,010 sq km; Lago Colhué Huapi - 800 sq km; Lago Fagnano (shared with Chile) - 590 sq km; Lago Nahuel Huapi - 550 sq km
salt water lake(s):
Laguna Mar Chiquita - 1,850 sq km;
Major rivers (by length in km):
Río de la Plata/Paraná river mouth (shared with Brazil [s], Paraguay, and Uruguay) - 4,880 km; Paraguay (shared with Brazil [s], and Paraguay [m]) - 2,549 km; Uruguay (shared with Brazil [s] and Uruguay [m]) - 1,610 km
note
– [s] after country name indicates river source; [m] after country name indicates river mouth
Major watersheds (area sq km): Atlantic Ocean drainage:
Paraná (2,582,704 sq km)
Major aquifers:
Guaraní Aquifer System
Total water withdrawal:
municipal:
5.85 billion cubic meters (2020 est.)
industrial:
4 billion cubic meters (2020 est.)
agricultural:
27.93 billion cubic meters (2020 est.)
Total renewable water resources:
876.24 billion cubic meters (2020 est.)','3d1567e692ad2e9db1d87d522dcd71b9f598465b849a87b1a4c2fc83b085f3cb','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c6f4edb0a9546eef12797cc98c81789a55c94c77fd004b475ad37d510cd3cf68',2025,'AM','Armenia','environment',67,'Environment - current issues:
soil pollution from toxic chemicals such as DDT; deforestation; pollution of Hrazdan and Aras Rivers; the draining of Sevana Lich (Lake Sevan), a result of its use as a source for hydropower, threatens drinking water supplies; restart of Metsamor nuclear power plant in spite of its location in a seismically active zone
Environment - international agreements:
party to:
Air Pollution, Biodiversity, Climate Change, Climate Change-Kyoto Protocol, Climate Change-Paris Agreement, Comprehensive Nuclear Test Ban, Desertification, Endangered Species, Environmental Modification, Hazardous Wastes, Law of the Sea, Nuclear Test Ban, Ozone Layer Protection, Wetlands
signed, but not ratified:
Air Pollution-Heavy Metals, Air Pollution-Multi-effect Protocol, Air Pollution-Persistent Organic Pollutants
Climate:
highland continental, hot summers, cold winters
Land use:
agricultural land:
59.7% (2018 est.)
arable land:
15.8% (2018 est.)
permanent crops:
1.9% (2018 est.)
permanent pasture:
42% (2018 est.)
forest:
9.1% (2018 est.)
other:
31.2% (2018 est.)
Urbanization:
urban population:
63.7% of total population (2023)
rate of urbanization:
0.23% annual rate of change (2020-25 est.)
Revenue from forest resources:
0.28% of GDP (2018 est.)
comparison ranking:
82
Revenue from coal:
0% of GDP (2018 est.)
comparison ranking:
101
Air pollutants:
particulate matter emissions:
34.13 micrograms per cubic meter (2019 est.)
carbon dioxide emissions:
5.16 megatons (2016 est.)
methane emissions:
2.91 megatons (2020 est.)
Waste and recycling:
municipal solid waste generated annually:
492,800 tons (2014 est.)
Major lakes (area sq km):
fresh water lake(s):
Lake Sevan - 1,360 sq km
Total water withdrawal:
municipal:
650 million cubic meters (2020 est.)
industrial:
190 million cubic meters (2020 est.)
agricultural:
1.99 billion cubic meters (2020 est.)
Total renewable water resources:
7.77 billion cubic meters (2020 est.)','0f8b9987973a9e82963740e0b7a4235d576fb0ad4fceb2dfdda7192b1a650090','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1fbc6c68f1cd05276f0cae4e37a1ecf7448df07f598deab0fcad74797bd6128f',2025,'AW','Aruba','environment',4,'Environment - current issues:
difficulty in properly disposing of waste produced by large numbers of tourists; waste burning that occurs in the landfill causes air pollution and poses an environmental and health risk; ocean environmental damage due to plastic pollution
Climate:
tropical marine; little seasonal temperature variation
Land use:
agricultural land:
11.1% (2018 est.)
arable land:
11.1% (2018 est.)
permanent crops:
0% (2018 est.)
permanent pasture:
0% (2018 est.)
forest:
2.3% (2018 est.)
other:
86.6% (2018 est.)
Urbanization:
urban population:
44.3% of total population (2023)
rate of urbanization:
0.77% annual rate of change (2020-25 est.)
Revenue from forest resources:
0% of GDP (2017 est.)
comparison ranking:
202
Air pollutants:
carbon dioxide emissions:
0.88 megatons (2016 est.)
Waste and recycling:
municipal solid waste generated annually:
88,132 tons (2013 est.)
municipal solid waste recycled annually:
9,695 tons (2013 est.)
percent of municipal solid waste recycled:
11% (2013 est.)','e9c8dc44b75e6f216ea41b5439306a6e841f39f62a7661c9016dcab5ccb0c3b3','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('585aba25ad3ec99dd4a893b19722487fd68b943e5bb44fd0415e888fa8d8e466',2025,'AW','Aruba','environment',15,'Environment - current issues:
illegal killing of protected wildlife by traditional Indonesian fisherman, as well as fishing by non-traditional Indonesian vessels, are ongoing problems; sea level rise, changes in sea temperature, and ocean acidification are concerns; marine debris
Climate:
tropical
Land use:
agricultural land:
0% (2018 est.)','8d30e670c74a8413dac711c90703a670ba2c155fbb30a8a52d739672d65fc858','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('38372d23ce5af454334a03144c2be977b0f64f059a3a6f65a506af6b4e7a0062',2025,'AW','Aruba','environment',22,'Environment - current issues:
endangered marine species include the manatee, seals, sea lions, turtles, and whales; unsustainable exploitation of fisheries (over fishing, bottom trawling, drift net fishing, discards, catch of non-target species); pollution (maritime transport, discharges, offshore drilling, oil spills); municipal sludge pollution off eastern US, southern Brazil, and eastern Argentina; oil pollution in Caribbean Sea, Gulf of Mexico, Lake Maracaibo, Mediterranean Sea, and North Sea; industrial waste and municipal sewage pollution in Baltic Sea, North Sea, and Mediterranean Sea
Climate:
tropical cyclones (hurricanes) develop off the coast of Africa near Cabo Verde and move westward into the Caribbean Sea; hurricanes can occur from May to December but are most frequent from August to November
Marine fisheries:
the Atlantic Ocean fisheries are the second most important in the world accounting for 25.8%, or 20,300,000 mt, of the global catch in 2020; of the seven regions delineated by the Food and Agriculture Organization in the Atlantic basin, the most important include the following:
Northeast Atlantic
region (Region 27) is the fourth most important in the world producing 10.5% of the global catch or 8,310,000 mt in 2020; the region encompasses the waters north of 36° North latitude and east of 40° West longitude with the major producers including Norway (3,528,240 mt), Russia (1,044,153 mt), Iceland (933,019 mt), UK (823,669 mt), and Denmark (641,927 mt); the region includes the historically important fishing grounds of the North Sea, the Baltic Sea, and the Atlantic waters between Greenland, Iceland, and the British Isles; the principal catches include Atlantic cod, haddock, saithe (pollock), Blue Whiting, herring, and mackerel; not all fish caught are for human consumption, half of fish catches in the North Sea are processed as fish oil or fish meal, which are used in animal fodder
Eastern Central Atlantic
region (Region 34) is the second most important Atlantic fishery, and seventh largest in the world producing more than 6.3% of the global catch or 4,950,000 mt in 2020; the region encompasses the waters between 36° North and 6° South latitude and east of 40° West longitude off the west coast of Africa with the major producers including Morocco (1,419,872 mt), Mauritania (705,850 mt), Senegal (472,571 mt), Nigeria (451,768 mt), Ghana (303,001 mt), Cameroon (265,969 mt), and Sierra Leone (200,000 mt); the principal catches include pilchard, sardinellas, shad, and mackerel
Northwest Atlantic
region (Region 21) is the fourth most important Atlantic fishery and eleventh in the world producing 1.9% of the global catch and 1,540,000 mt in 2020; it encompasses the waters north of 35° North latitude and west of 42° West longitude including the important fishing grounds over the continental shelf of North America such as the Grand Banks, the Georges Bank, and the Flemish Cap, as well as Baffin Bay with the major producers including the US (927,777 mt), Canada (615,651 mt), and Greenland (179,990 mt); the principal catches include sea scallops, prawns, lobster, herring, and menhaden
Mediterranean and Black Sea
region (Region 37) is a minor fishing region representing 1.5% or 1,190,000 mt of the world’s total capture in 2020; the region encompasses all waters east of the Strait of Gibraltar with the major producers including Turkey (686,650 mt), Italy (281,212 mt), Tunisia (129,325 mt), Spain (119,759 mt), and Russia (72,279 mt); the principal catches include European anchovy, European pilchard, Gobies, and clams
Regional fisheries bodies:
Commission for the Conservation of Southern Bluefin Tuna, Fishery Committee for the Eastern Central Atlantic, Fisheries Committee for the West Central Gulf of Guinea, General Fisheries Commission for the Mediterranean, International Commission for the Conservation of Atlantic Tunas, International Council for the Exploration of the Seas, Northwest Atlantic Fisheries Organization, North Atlantic Salmon Conservation Organization, North East Atlantic Fisheries Commission, Southeast Atlantic Fisheries Organization, Western Central Atlantic Fishery Commission','e6598a7cd8261cf42c0027adbfffa71361a1185737e0f13f08bab29370f4c27e','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('53a45c95ed825df01b93d780ad1a82ab568bb6b9771f5ea2a34aec86fd83044a',2025,'AU','Australia','environment',30,'Environment - current issues:
soil erosion from overgrazing, deforestation, industrial development, urbanization, and poor farming practices; limited natural freshwater resources; soil salinity rising due to the use of poor quality water; drought, desertification; clearing for agricultural purposes threatens the natural habitat of many unique animal and plant species; disruption of the fragile ecosystem has resulted in significant floral extinctions; the Great Barrier Reef off the northeast coast, the largest coral reef in the world, is threatened by increased shipping and its popularity as a tourist site; overfishing, pollution, and invasive species are also problems
Environment - international agreements:
party to:
Antarctic-Environmental Protection, Antarctic-Marine Living Resources, Antarctic Seals, Antarctic Treaty, Biodiversity, Climate Change, Climate Change-Kyoto Protocol, Climate Change-Paris Agreement, Comprehensive Nuclear Test Ban, Desertification, Endangered Species, Environmental Modification, Hazardous Wastes, Law of the Sea, Marine Dumping-London Convention, Marine Dumping-London Protocol, Marine Life Conservation, Nuclear Test Ban, Ozone Layer Protection, Ship Pollution, Tropical Timber 2006, Wetlands, Whaling
signed, but not ratified:
none of the selected agreements
Climate:
generally arid to semiarid; temperate in south and east; tropical in north
Land use:
agricultural land:
46.65% (2018 est.)
arable land:
4.03% (2018 est.)
permanent crops:
0.04% (2018 est.)
permanent pasture:
42.58% (2018 est.)
forest:
17.42% (2018 est.)
other:
33.42% (2018 est.)
Urbanization:
urban population:
86.6% of total population (2023)
rate of urbanization:
1.27% annual rate of change (2020-25 est.)
note:
data include Christmas Island, Cocos Islands, and Norfolk Island
Revenue from forest resources:
0.13% of GDP (2018 est.)
comparison ranking:
105
Revenue from coal:
0.78% of GDP (2018 est.)
comparison ranking:
7
Air pollutants:
particulate matter emissions:
8.93 micrograms per cubic meter (2019 est.)
carbon dioxide emissions:
375.91 megatons (2016 est.)
methane emissions:
105.01 megatons (2020 est.)
Waste and recycling:
municipal solid waste generated annually:
13.345 million tons (2015 est.)
municipal solid waste recycled annually:
5,618,245 tons (2015 est.)
percent of municipal solid waste recycled:
42.1% (2015 est.)
Major lakes (area sq km):
fresh water lake(s):
Lake Alexandrina - 570 sq km
salt water lake(s):
Lake Eyre - 9,690 sq km; Lake Torrens (ephemeral) - 5,780 sq km; Lake Gairdner - 4,470 sq km; Lake Mackay (ephemeral) - 3,494 sq km; Lake Frome - 2,410 sq km; Lake Amadeus (ephemeral) - 1,032 sq km
Major rivers (by length in km):
River Murray - 2,508 km; Darling River - 1,545 km; Murrumbidgee River - 1,485 km; Lachlan River - 1,339 km; Cooper Creek - 1,113 km; Flinders River - 1,004 km
Major watersheds (area sq km):
Indian Ocean drainage:
(Great Australian Bight)
Murray-Darling (1,050,116 sq km)
Internal (endorheic basin) drainage:
Lake Eyre (1,212,198 sq km)
Major aquifers:
Great Artesian Basin, Canning Basin
Total water withdrawal:
municipal:
2.29 billion cubic meters (2020 est.)
industrial:
2.89 billion cubic meters (2020 est.)
agricultural:
8.57 billion cubic meters (2020 est.)
Total renewable water resources:
492 billion cubic meters (2020 est.)','8f09d3ae82487e12ac347be3f4e01fd18ad904975da827c3d0cbd7beb82c8b82','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('59c724b7008a1f6073dd67c1fff152caa45558dd5b909f8e05f1e0992502f38b',2025,'AT','Austria','environment',43,'Environment - current issues:
some forest degradation caused by air and soil pollution; soil pollution results from the use of agricultural chemicals; air pollution results from emissions by coal- and oil-fired power stations and industrial plants and from trucks transiting Austria between northern and southern Europe; water pollution; the Danube, as well as some of Austria’s other rivers and lakes, are threatened by pollution
Environment - international agreements:
party to:
Air Pollution, Air Pollution-Heavy Metals, Air Pollution-Nitrogen Oxides, Air Pollution-Persistent Organic Pollutants, Air Pollution-Sulphur 85, Air Pollution-Sulphur 94, Air Pollution-Volatile Organic Compounds, Antarctic Treaty, Biodiversity, Climate Change, Climate Change-Kyoto Protocol, Climate Change-Paris Agreement, Comprehensive Nuclear Test Ban, Desertification, Endangered Species, Environmental Modification, Hazardous Wastes, Law of the Sea, Nuclear Test Ban, Ozone Layer Protection, Ship Pollution, Tropical Timber 2006, Wetlands, Whaling
signed, but not ratified:
Air Pollution-Multi-effect Protocol, Antarctic-Environmental Protection
Climate:
temperate; continental, cloudy; cold winters with frequent rain and some snow in lowlands and snow in mountains; moderate summers with occasional showers
Land use:
agricultural land:
38.4% (2018 est.)
arable land:
16.5% (2018 est.)
permanent crops:
0.8% (2018 est.)
permanent pasture:
21.1% (2018 est.)
forest:
47.2% (2018 est.)
other:
14.4% (2018 est.)
Urbanization:
urban population:
59.5% of total population (2023)
rate of urbanization:
0.68% annual rate of change (2020-25 est.)
Revenue from forest resources:
0.07% of GDP (2018 est.)
comparison ranking:
123
Revenue from coal:
0% of GDP (2018 est.)
comparison ranking:
100
Air pollutants:
particulate matter emissions:
11.51 micrograms per cubic meter (2019 est.)
carbon dioxide emissions:
61.45 megatons (2016 est.)
methane emissions:
6.34 megatons (2020 est.)
Waste and recycling:
municipal solid waste generated annually:
4.836 million tons (2015 est.)
municipal solid waste recycled annually:
1,240,918 tons (2015 est.)
percent of municipal solid waste recycled:
25.7% (2015 est.)
Major lakes (area sq km):
fresh water lake(s):
Lake Constance (shared with Switzerland and Germany) - 540 sq km
Major rivers (by length in km):
Donau (Danube) (shared with Germany [s], Slovakia, Czechia, Hungary, Croatia, Serbia, Bulgaria, Ukraine, Moldova, and Romania [m]) - 2,888 km
note
– [s] after country name indicates river source; [m] after country name indicates river mouth
Major watersheds (area sq km): Atlantic Ocean drainage:
Rhine-Maas (198,735 sq km),
(Black Sea)
Danube (795,656 sq km)
Total water withdrawal:
municipal:
720 million cubic meters (2020 est.)
industrial:
2.7 billion cubic meters (2020 est.)
agricultural:
720 million cubic meters (2020 est.)
Total renewable water resources:
77.7 billion cubic meters (2020 est.)','d2172b90add72f19fde769a292391ee83d13f47d1bbf2cf116180a7855378c69','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('536a9a80e7062b47ffd914f7e9a3be18851cbe4773d3d3402f920290ac7ae922',2025,'AZ','Azerbaijan','environment',56,'Environment - current issues:
local scientists consider the Abseron Yasaqligi (Apsheron Peninsula) (including Baku and Sumqayit) and the Caspian Sea to be the ecologically most devastated area in the world because of severe air, soil, and water pollution; soil pollution results from oil spills, from the use of DDT pesticide, and from toxic defoliants used in the production of cotton; surface and underground water are polluted by untreated municipal and industrial wastewater and agricultural run-off
Environment - international agreements:
party to:
Air Pollution, Biodiversity, Climate Change, Climate Change-Kyoto Protocol, Climate Change-Paris Agreement, Comprehensive Nuclear Test Ban, Desertification, Endangered Species, Hazardous Wastes, Law of the Sea, Marine Dumping-London Convention, Ozone Layer Protection, Ship Pollution, Wetlands
signed, but not ratified:
none of the selected agreements
Climate:
dry, semiarid steppe
Land use:
agricultural land:
57.6% (2018 est.)
arable land:
22.8% (2018 est.)
permanent crops:
2.7% (2018 est.)
permanent pasture:
32.1% (2018 est.)
forest:
11.3% (2018 est.)
other:
31.1% (2018 est.)
Urbanization:
urban population:
57.6% of total population (2023)
rate of urbanization:
1.38% annual rate of change (2020-25 est.)
note:
data include Nagorno-Karabakh
Revenue from forest resources:
0.02% of GDP (2018 est.)
comparison ranking:
139
Revenue from coal:
0% of GDP (2018 est.)
comparison ranking:
123
Air pollutants:
particulate matter emissions:
24.64 micrograms per cubic meter (2019 est.)
carbon dioxide emissions:
37.62 megatons (2016 est.)
methane emissions:
44.87 megatons (2020 est.)
Waste and recycling:
municipal solid waste generated annually:
2,930,349 tons (2015 est.)
Major lakes (area sq km):
salt water lake(s):
Caspian Sea (shared with Iran, Russia, Turkmenistan, and Kazakhstan) - 374,000 sq km
Total water withdrawal:
municipal:
400 million cubic meters (2020 est.)
industrial:
570 million cubic meters (2020 est.)
agricultural:
11.6 billion cubic meters (2020 est.)
Total renewable water resources:
34.68 billion cubic meters (2020 est.)','4fa78b752716f5e2dc229c4d11db3ab708afc532f4ecae9af61445b33d6cc779','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8ae7dea32991824743b9cd66393ce6f7c534d45355a5a1ac5032460562b587e3',2025,'BH','Bahrain','environment',6,'Environment - current issues:
desertification resulting from the degradation of limited arable land, periods of drought, and dust storms; coastal degradation (damage to coastlines, coral reefs, and sea vegetation) resulting from oil spills and other discharges from large tankers, oil refineries, and distribution stations; lack of freshwater resources (groundwater and seawater are the only sources for all water needs); lowered water table leaves aquifers vulnerable to saline contamination; desalinization provides some 90% of the country’s freshwater
Environment - international agreements:
party to:
Biodiversity, Climate Change, Climate Change-Kyoto Protocol, Climate Change-Paris Agreement, Comprehensive Nuclear Test Ban, Desertification, Endangered Species, Hazardous Wastes, Law of the Sea, Ozone Layer Protection, Ship Pollution, Wetlands
signed, but not ratified:
none of the selected agreements
Climate:
arid; mild, pleasant winters; very hot, humid summers
Land use:
agricultural land:
11.3% (2018 est.)
arable land:
2.1% (2018 est.)
permanent crops:
3.9% (2018 est.)
permanent pasture:
5.3% (2018 est.)
forest:
0.7% (2018 est.)
other:
88% (2018 est.)
Urbanization:
urban population:
89.9% of total population (2023)
rate of urbanization:
1.99% annual rate of change (2020-25 est.)
Revenue from forest resources:
0% of GDP (2018 est.)
comparison ranking:
160
Revenue from coal:
0% of GDP (2018 est.)
comparison ranking:
69
Air pollutants:
particulate matter emissions:
51.82 micrograms per cubic meter (2019 est.)
carbon dioxide emissions:
31.69 megatons (2016 est.)
methane emissions:
15.47 megatons (2020 est.)
Waste and recycling:
municipal solid waste generated annually:
951,943 tons (2016 est.)
municipal solid waste recycled annually:
76,155 tons (2012 est.)
percent of municipal solid waste recycled:
8% (2012 est.)
Major aquifers:
Arabian Aquifer System
Total water withdrawal:
municipal:
280 million cubic meters (2020 est.)
industrial:
10 million cubic meters (2020 est.)
agricultural:
140 million cubic meters (2020 est.)
Total renewable water resources:
120 million cubic meters (2020 est.)','e79cf9ecb248961249faf55c521d310330da0e0a3749d56833228389193b96a5','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('57c4573fd754c154f9b4cf5c96b07257fa11ced94825d7da96eb53d0aa1cbdc5',2025,'BD','Bangladesh','environment',19,'Environment - current issues:
many people are landless and forced to live on and cultivate flood-prone land; waterborne diseases prevalent in surface water; water pollution, especially of fishing areas, results from the use of commercial pesticides; ground water contaminated by naturally occurring arsenic; intermittent water shortages because of falling water tables in the northern and central parts of the country; soil degradation and erosion; deforestation; destruction of wetlands; severe overpopulation with noise pollution
Environment - international agreements:
party to:
Biodiversity, Climate Change, Climate Change-Kyoto Protocol, Climate Change-Paris Agreement, Comprehensive Nuclear Test Ban, Desertification, Endangered Species, Environmental Modification, Hazardous Wastes, Law of the Sea, Nuclear Test Ban, Ozone Layer Protection, Ship Pollution, Wetlands
signed, but not ratified:
none of the selected agreements
Climate:
tropical; mild winter (October to March); hot, humid summer (March to June); humid, warm rainy monsoon (June to October)
Land use:
agricultural land:
70.1% (2018 est.)
arable land:
59% (2018 est.)
permanent crops:
6.5% (2018 est.)
permanent pasture:
4.6% (2018 est.)
forest:
11.1% (2018 est.)
other:
18.8% (2018 est.)
Urbanization:
urban population:
40.5% of total population (2023)
rate of urbanization:
2.88% annual rate of change (2020-25 est.)
Food insecurity:
severe localized food insecurity:
due to economic constraints and high prices of important food items - food insecurity is expected to remain fragile, given persisting economic constraints; domestic prices of wheat flour and palm oil, important food items, were at high levels in January 2023; the result of elevated international prices of energy, fuel and food, having been transmitted to the domestic markets (2023)
Revenue from forest resources:
0.08% of GDP (2018 est.)
comparison ranking:
120
Revenue from coal:
0.02% of GDP (2018 est.)
comparison ranking:
43
Air pollutants:
particulate matter emissions:
45.99 micrograms per cubic meter (2019 est.)
carbon dioxide emissions:
84.25 megatons (2016 est.)
methane emissions:
59.3 megatons (2020 est.)
Waste and recycling:
municipal solid waste generated annually:
14,778,497 tons (2012 est.)
Major rivers (by length in km):
Brahmaputra river mouth (shared with China [s] and India) - 3,969 km; Ganges river mouth (shared with India [s]) - 2,704 km
note
– [s] after country name indicates river source; [m] after country name indicates river mouth
Major watersheds (area sq km): Indian Ocean drainage:
Brahmaputra (651,335 sq km), Ganges (1,016,124 sq km)
Major aquifers:
Indus-Ganges-Brahmaputra Basin
Total water withdrawal:
municipal:
3.6 billion cubic meters (2020 est.)
industrial:
770 million cubic meters (2020 est.)
agricultural:
31.5 billion cubic meters (2020 est.)
Total renewable water resources:
1.23 trillion cubic meters (2020 est.)','e3eb23a61b58ffbc8a53bf146be3810b3b83f8d852b30f4d42abadc6a9f2e1a5','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('06b38da75cf197494619b1f5e47271883165b1f4acec2573447370549b788fa2',2025,'BB','Barbados','environment',32,'party to:
Biodiversity, Climate Change, Climate Change-Kyoto Protocol, Climate Change-Paris Agreement, Comprehensive Nuclear Test Ban, Desertification, Endangered Species, Hazardous Wastes, Law of the Sea, Marine Dumping-London Convention, Marine Dumping-London Protocol, Ozone Layer Protection, Ship Pollution, Wetlands signed, but not ratified: none of the selected agreements
Climate:
tropical; rainy season (June to October)
Land use:
agricultural land:
32.6% (2018 est.)
arable land:
25.6% (2018 est.)
permanent crops:
2.3% (2018 est.)
permanent pasture:
4.7% (2018 est.)
forest:
19.4% (2018 est.)
other:
48% (2018 est.)
Urbanization:
urban population:
31.4% of total population (2023)
rate of urbanization:
0.46% annual rate of change (2020-25 est.)
Revenue from forest resources:
0.01% of GDP (2018 est.)
comparison ranking:
158
Revenue from coal:
0% of GDP (2018 est.)
comparison ranking:
58
Air pollutants:
particulate matter emissions:
9.79 micrograms per cubic meter (2019 est.)
carbon dioxide emissions:
1.28 megatons (2016 est.)
methane emissions:
2.35 megatons (2020 est.)
Waste and recycling:
municipal solid waste generated annually:
174,815 tons (2011 est.)
municipal solid waste recycled annually:
15,733 tons (2015 est.)
percent of municipal solid waste recycled:
9% (2015 est.)
Total water withdrawal:
municipal:
20 million cubic meters (2020 est.)
industrial:
10 million cubic meters (2020 est.)
agricultural:
5 million cubic meters (2020 est.)
Total renewable water resources:
80 million cubic meters (2020 est.)','cda928cd98cc85e296a465f336cc4d742b751b67e74a795977bf23dc0f29b82b','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('72c8eb7962245797ffa440a02b0dc3a1214b01989325f4fb8b7b0a57fab7a29b',2025,'BY','Belarus','environment',43,'Environment - current issues:
soil pollution from pesticide use; southern part of the country contaminated with fallout from 1986 nuclear reactor accident at Chornobyl’ in northern Ukraine
Environment - international agreements:
party to:
Air Pollution, Air Pollution-Nitrogen Oxides, Air Pollution-Sulphur 85, Antarctic-Environmental Protection, Antarctic Treaty, Biodiversity, Climate Change, Climate Change-Kyoto Protocol, Climate Change-Paris Agreement, Comprehensive Nuclear Test Ban, Desertification, Endangered Species, Environmental Modification, Hazardous Wastes, Law of the Sea, Marine Dumping-London Convention, Nuclear Test Ban, Ozone Layer Protection, Ship Pollution, Wetlands
signed, but not ratified:
none of the selected agreements
Climate:
cold winters, cool and moist summers; transitional between continental and maritime
Land use:
agricultural land:
43.7% (2018 est.)
arable land:
27.2% (2018 est.)
permanent crops:
0.6% (2018 est.)
permanent pasture:
15.9% (2018 est.)
forest:
42.7% (2018 est.)
other:
13.6% (2018 est.)
Urbanization:
urban population:
80.7% of total population (2023)
rate of urbanization:
0.28% annual rate of change (2020-25 est.)
Revenue from forest resources:
1.02% of GDP (2018 est.)
comparison ranking:
52
Revenue from coal:
0% of GDP (2018 est.)
comparison ranking:
121
Air pollutants:
particulate matter emissions:
15.48 micrograms per cubic meter (2019 est.)
carbon dioxide emissions:
58.28 megatons (2016 est.)
methane emissions:
17.19 megatons (2020 est.)
Waste and recycling:
municipal solid waste generated annually:
4.28 million tons (2015 est.)
municipal solid waste recycled annually:
684,800 tons (2016 est.)
percent of municipal solid waste recycled:
16% (2016 est.)
Major rivers (by length in km):
Dnyapro (Dnieper) (shared with Russia [s] and Ukraine [m]) - 2,287 km
note
– [s] after country name indicates river source; [m] after country name indicates river mouth
Major watersheds (area sq km): Atlantic Ocean drainage:
(Black Sea) Dnieper (533,966 sq km)
Total water withdrawal:
municipal:
550 million cubic meters (2020 est.)
industrial:
410 million cubic meters (2020 est.)
agricultural:
370 million cubic meters (2020 est.)
Total renewable water resources:
57.9 billion cubic meters (2020 est.)','69127ece7a76f751cd966b17e625ada44ee9fd066f6bce5bdd25fc7b38acfc9f','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e4206e61f509089857ac03d1d0b45f8178c3c6029ef4b0359375dedbe1644965',2025,'BE','Belgium','environment',55,'Environment - current issues:
intense pressures from human activities: urbanization, dense transportation network, industry, extensive animal breeding and crop cultivation; air and water pollution also have repercussions for neighboring countries
Environment - international agreements:
party to:
Air Pollution, Air Pollution-Heavy Metals, Air Pollution-Multi-effect Protocol, Air Pollution-Nitrogen Oxides, Air Pollution-Persistent Organic Pollutants, Air Pollution-Sulphur 85, Air Pollution-Sulphur 94, Air Pollution-Volatile Organic Compounds, Antarctic-Environmental Protection, Antarctic-Marine Living Resources, Antarctic Seals, Antarctic Treaty, Biodiversity, Climate Change, Climate Change-Kyoto Protocol, Climate Change-Paris Agreement, Comprehensive Nuclear Test Ban, Desertification, Endangered Species, Environmental Modification, Hazardous Wastes, Law of the Sea, Marine Dumping-London Convention, Marine Dumping-London Protocol, Marine Life Conservation, Nuclear Test Ban, Ozone Layer Protection, Ship Pollution, Tropical Timber 2006, Wetlands, Whaling
signed, but not ratified:
none of the selected agreements
Climate:
temperate; mild winters, cool summers; rainy, humid, cloudy
Land use:
agricultural land:
44.1% (2018 est.)
arable land:
27.2% (2018 est.)
permanent crops:
0.8% (2018 est.)
permanent pasture:
16.1% (2018 est.)
forest:
22.4% (2018 est.)
other:
33.5% (2018 est.)
Urbanization:
urban population:
98.2% of total population (2023)
rate of urbanization:
0.38% annual rate of change (2020-25 est.)
Revenue from forest resources:
0.02% of GDP (2018 est.)
comparison ranking:
143
Revenue from coal:
0% of GDP (2018 est.)
comparison ranking:
132
Air pollutants:
particulate matter emissions:
11.26 micrograms per cubic meter (2019 est.)
carbon dioxide emissions:
96.89 megatons (2016 est.)
methane emissions:
7.78 megatons (2020 est.)
Waste and recycling:
municipal solid waste generated annually:
4.708 million tons (2015 est.)
municipal solid waste recycled annually:
1,614,985 tons (2015 est.)
percent of municipal solid waste recycled:
34.3% (2015 est.)
Major watersheds (area sq km): Atlantic Ocean drainage:
Seine (78,919 sq km), Rhine-Maas (198,735 sq km)
Total water withdrawal:
municipal:
740 million cubic meters (2020 est.)
industrial:
3.47 billion cubic meters (2020 est.)
agricultural:
50 million cubic meters (2020 est.)
Total renewable water resources:
18.3 billion cubic meters (2020 est.)','d9c83353b97b8c11ee5924a7a630544555bef2de5d64ed0d1fbf1998377571d5','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b828b30b0db0423a8f1c2258cf86a2c79f1e8fe6481ccadad20bd6625c649d8b',2025,'BZ','Belize','environment',4,'Environment - current issues:
deforestation; water pollution, including pollution of Belize’s Barrier Reef System, from sewage, industrial effluents, agricultural runoff; inability to properly dispose of solid waste
Environment - international agreements:
party to:
Biodiversity, Climate Change, Climate Change-Kyoto Protocol, Climate Change-Paris Agreement, Comprehensive Nuclear Test Ban, Desertification, Endangered Species, Hazardous Wastes, Law of the Sea, Ozone Layer Protection, Ship Pollution, Wetlands, Whaling
signed, but not ratified:
none of the selected agreements
Climate:
tropical; very hot and humid; rainy season (May to November); dry season (February to May)
Land use:
agricultural land:
6.9% (2018 est.)
arable land:
3.3% (2018 est.)
permanent crops:
1.4% (2018 est.)
permanent pasture:
2.2% (2018 est.)
forest:
60.6% (2018 est.)
other:
32.5% (2018 est.)
Urbanization:
urban population:
46.6% of total population (2023)
rate of urbanization:
2.3% annual rate of change (2020-25 est.)
Revenue from forest resources:
0.31% of GDP (2018 est.)
comparison ranking:
79
Revenue from coal:
0% of GDP (2018 est.)
comparison ranking:
107
Air pollutants:
particulate matter emissions:
10.51 micrograms per cubic meter (2019 est.)
carbon dioxide emissions:
0.57 megatons (2016 est.)
methane emissions:
0.55 megatons (2020 est.)
Waste and recycling:
municipal solid waste generated annually:
101,379 tons (2015 est.)
Total water withdrawal:
municipal:
10 million cubic meters (2020 est.)
industrial:
20 million cubic meters (2020 est.)
agricultural:
70 million cubic meters (2020 est.)
Total renewable water resources:
21.73 billion cubic meters (2020 est.)','7720f81d1efed70e0a6fb176e733422a6957c350cc2b4e95c6fc9d85c766f09e','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1da800c0b3232bef10c3e121a8bb465f6482f3891b037cc23799caed8bd07733',2025,'BJ','Benin','environment',15,'Environment - current issues:
inadequate supplies of potable water; water pollution; poaching threatens wildlife populations; deforestation; desertification (the spread of the desert into agricultural lands in the north is accelerated by regular droughts)
Environment - international agreements:
party to:
Biodiversity, Climate Change, Climate Change-Kyoto Protocol, Climate Change-Paris Agreement, Comprehensive Nuclear Test Ban, Desertification, Endangered Species, Environmental Modification, Hazardous Wastes, Law of the Sea, Marine Dumping-London Convention, Nuclear Test Ban, Ozone Layer Protection, Ship Pollution, Tropical Timber 2006, Wetlands, Whaling
signed, but not ratified:
none of the selected agreements
Climate:
tropical; hot, humid in south; semiarid in north
Land use:
agricultural land:
31.3% (2018 est.)
arable land:
22.9% (2018 est.)
permanent crops:
3.5% (2018 est.)
permanent pasture:
4.9% (2018 est.)
forest:
40% (2018 est.)
other:
28.7% (2018 est.)
Urbanization:
urban population:
50.1% of total population (2023)
rate of urbanization:
3.74% annual rate of change (2020-25 est.)
Revenue from forest resources:
2.24% of GDP (2018 est.)
comparison ranking:
31
Revenue from coal:
0% of GDP (2018 est.)
comparison ranking:
54
Air pollutants:
particulate matter emissions:
31.51 micrograms per cubic meter (2019 est.)
carbon dioxide emissions:
6.48 megatons (2016 est.)
methane emissions:
5.8 megatons (2020 est.)
Waste and recycling:
municipal solid waste generated annually:
685,936 tons (1993 est.)
municipal solid waste recycled annually:
171,484 tons (2005 est.)
percent of municipal solid waste recycled:
25% (2005 est.)
Major watersheds (area sq km): Atlantic Ocean drainage:
Niger (2,261,741 sq km), Volta (410,991 sq km)
Total water withdrawal:
municipal:
150 million cubic meters (2020 est.)
industrial:
30 million cubic meters (2020 est.)
agricultural:
60 million cubic meters (2020 est.)
Total renewable water resources:
26.39 billion cubic meters (2020 est.)','d1e6e27a57747912e67fe5caa9a6fac6baa9ba4e49596d3b1d1d8d2f551ce79a','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2ca7b7f463b9dac11d0725ba8633b1711d2b848fd95540567aa693d730eb982b',2025,'BM','Bermuda','environment',27,'Environment - current issues:
dense population and heavy vehicle traffic create serious congestion and air pollution problems; water resources scarce (most obtained as rainwater or from wells); solid waste disposal; hazardous waste disposal; sewage disposal; overfishing; oil spills
Climate:
subtropical; mild, humid; gales, strong winds common in winter
Land use:
agricultural land:
14.8% (2018 est.)
arable land:
14.8% (2018 est.)
permanent crops:
0% (2018 est.)
permanent pasture:
0% (2018 est.)
forest:
20% (2018 est.)
other:
65.2% (2018 est.)
Urbanization:
urban population:
100% of total population (2023)
rate of urbanization:
-0.2% annual rate of change (2020-25 est.)
Air pollutants:
carbon dioxide emissions:
0.61 megatons (2016 est.)
Waste and recycling:
municipal solid waste generated annually:
82,000 tons (2012 est.)
municipal solid waste recycled annually:
1,640 tons (2012 est.)
percent of municipal solid waste recycled:
2% (2012 est.)','dc5d8a729ccdca5ab8f444fa5f8ad2be29c41f6be786b8951b2ca7cc44534e06','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3245b120c0d87943621614aa679762dfe1465cfb673e39360cdcc079f25f48cc',2025,'BT','Bhutan','environment',38,'Environment - current issues:
soil erosion; limited access to potable water; wildlife conservation; industrial pollution; waste disposal
Environment - international agreements:
party to:
Biodiversity, Climate Change, Climate Change-Kyoto Protocol, Climate Change-Paris Agreement, Desertification, Endangered Species, Hazardous Wastes, Nuclear Test Ban, Ozone Layer Protection, Wetlands
signed, but not ratified:
Law of the Sea
Climate:
varies; tropical in southern plains; cool winters and hot summers in central valleys; severe winters and cool summers in Himalayas
Land use:
agricultural land:
13.6% (2018 est.)
arable land:
2.6% (2018 est.)
permanent crops:
0.3% (2018 est.)
permanent pasture:
10.7% (2018 est.)
forest:
85.5% (2018 est.)
other:
0.9% (2018 est.)
Urbanization:
urban population:
44.4% of total population (2023)
rate of urbanization:
2.52% annual rate of change (2020-25 est.)
Revenue from forest resources:
1.89% of GDP (2018 est.)
comparison ranking:
37
Revenue from coal:
0% of GDP (2018 est.)
comparison ranking:
64
Air pollutants:
particulate matter emissions:
26.1 micrograms per cubic meter (2019 est.)
carbon dioxide emissions:
1.26 megatons (2016 est.)
methane emissions:
1.11 megatons (2020 est.)
Waste and recycling:
municipal solid waste generated annually:
111,314 tons (2007 est.)
municipal solid waste recycled annually:
957 tons (2016 est.)
percent of municipal solid waste recycled:
0.9% (2016 est.)
Total water withdrawal:
municipal:
20 million cubic meters (2020 est.)
industrial:
3 million cubic meters (2019 est.)
agricultural:
320 million cubic meters (2020 est.)
Total renewable water resources:
78 billion cubic meters (2020 est.)','7be1d23c56970eb82ea97356069a01c3ee87cae6f02b6c76bb4bfc6469d19087','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ef3eaf1e5b4357e85d339088d9b7718e5300e0920aa10b07f9e22b32d80ce170',2025,'BT','Bhutan','environment',50,'Environment - current issues:
the clearing of land for agricultural purposes and the international demand for tropical timber are contributing to deforestation; soil erosion from overgrazing and poor cultivation methods (including slash-and-burn agriculture); desertification; loss of biodiversity; industrial pollution of water supplies used for drinking and irrigation
Environment - international agreements:
party to:
Biodiversity, Climate Change, Climate Change-Kyoto Protocol, Climate Change-Paris Agreement, Comprehensive Nuclear Test Ban, Desertification, Endangered Species, Hazardous Wastes, Law of the Sea, Marine Dumping-London Convention, Nuclear Test Ban, Ozone Layer Protection, Ship Pollution, Wetlands,
signed, but not ratified:
Environmental Modification, Marine Life Conservation
Climate:
varies with altitude; humid and tropical to cold and semiarid
Land use:
agricultural land:
34.3% (2018 est.)
arable land:
3.6% (2018 est.)
permanent crops:
0.2% (2018 est.)
permanent pasture:
30.5% (2018 est.)
forest:
52.5% (2018 est.)
other:
13.2% (2018 est.)
Urbanization:
urban population:
71.2% of total population (2023)
rate of urbanization:
1.87% annual rate of change (2020-25 est.)
Revenue from forest resources:
0.33% of GDP (2018 est.)
comparison ranking:
78
Revenue from coal:
0% of GDP (2018 est.)
comparison ranking:
171
Air pollutants:
particulate matter emissions:
25.23 micrograms per cubic meter (2019 est.)
carbon dioxide emissions:
21.61 megatons (2016 est.)
methane emissions:
21.01 megatons (2020 est.)
Waste and recycling:
municipal solid waste generated annually:
2,219,052 tons (2015 est.)
municipal solid waste recycled annually:
268,727 tons (2015 est.)
percent of municipal solid waste recycled:
12.1% (2015 est.)
Major lakes (area sq km):
fresh water lake(s):
Lago Titicaca (shared with Peru) - 8,030 sq km
salt water lake(s):
Lago Poopo - 1,340 sq km
Major watersheds (area sq km): Atlantic Ocean drainage:
Amazon (6,145,186 sq km), Paraná (2,582,704 sq km)
Major aquifers:
Amazon Basin
Total water withdrawal:
municipal:
140 million cubic meters (2020 est.)
industrial:
30 million cubic meters (2020 est.)
agricultural:
1.92 billion cubic meters (2020 est.)
Total renewable water resources:
574 billion cubic meters (2020 est.)','5f60660f360e2da03d918e680509eebb5361028247cbafb1894dc6e0a3270e90','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bc41f748543187b5a5e864f75b95553ec702eb00aa8f59a2d8c361c9107e0275',2025,'BA','Bosnia and Herzegovina','environment',62,'Environment - current issues:
air pollution; deforestation and illegal logging; inadequate wastewater treatment and flood management facilities; sites for disposing of urban waste are limited; land mines left over from the 1992-95 civil strife are a hazard in some areas
Environment - international agreements:
party to:
Air Pollution, Biodiversity, Climate Change, Climate Change-Kyoto Protocol, Climate Change-Paris Agreement, Comprehensive Nuclear Test Ban, Desertification, Endangered Species, Hazardous Wastes, Law of the Sea, Marine Life Conservation, Nuclear Test Ban, Ozone Layer Protection, Wetlands
signed, but not ratified:
none of the selected agreements
Climate:
hot summers and cold winters; areas of high elevation have short, cool summers and long, severe winters; mild, rainy winters along coast
Land use:
agricultural land:
42.2% (2018 est.)
arable land:
19.7% (2018 est.)
permanent crops:
2% (2018 est.)
permanent pasture:
20.5% (2018 est.)
forest:
42.8% (2018 est.)
other:
15% (2018 est.)
Urbanization:
urban population:
50.3% of total population (2023)
rate of urbanization:
0.61% annual rate of change (2020-25 est.)
Revenue from forest resources:
0.49% of GDP (2018 est.)
comparison ranking:
66
Revenue from coal:
0.34% of GDP (2018 est.)
comparison ranking:
17
Air pollutants:
particulate matter emissions:
26.19 micrograms per cubic meter (2019 est.)
carbon dioxide emissions:
21.85 megatons (2016 est.)
methane emissions:
2.92 megatons (2020 est.)
Waste and recycling:
municipal solid waste generated annually:
1,248,718 tons (2015 est.)
municipal solid waste recycled annually:
12 tons (2015 est.)
percent of municipal solid waste recycled:
0% (2015 est.)
Major watersheds (area sq km): Atlantic Ocean drainage:
(Black Sea) Danube (795,656 sq km)
Total water withdrawal:
municipal:
310 million cubic meters (2020 est.)
industrial:
60 million cubic meters (2020 est.)
Total renewable water resources:
37.5 billion cubic meters (2020 est.)','469f60450aae7c30abbb09f8e25aff428e7f96c0283c3f4f3387642ea5eb6b13','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('267f97c49234d997f9023d4e5198d92cdd2e89c44eecc8faf7b3a527c52f4ed5',2025,'BW','Botswana','environment',4,'Environment - current issues:
overgrazing; desertification; limited freshwater resources; air pollution
Environment - international agreements:
party to:
Biodiversity, Climate Change, Climate Change-Kyoto Protocol, Climate Change-Paris Agreement, Desertification, Endangered Species, Hazardous Wastes, Law of the Sea, Nuclear Test Ban, Ozone Layer Protection, Wetlands
signed, but not ratified:
none of the selected agreements
Climate:
semiarid; warm winters and hot summers
Land use:
agricultural land:
45.8% (2018 est.)
arable land:
0.6% (2018 est.)
permanent crops:
0% (2018 est.)
permanent pasture:
45.2% (2018 est.)
forest:
19.8% (2018 est.)
other:
34.4% (2018 est.)
Urbanization:
urban population:
72.9% of total population (2023)
rate of urbanization:
2.47% annual rate of change (2020-25 est.)
Revenue from forest resources:
0.23% of GDP (2018 est.)
comparison ranking:
88
Revenue from coal:
0.45% of GDP (2018 est.)
comparison ranking:
13
Air pollutants:
particulate matter emissions:
12.82 micrograms per cubic meter (2019 est.)
carbon dioxide emissions:
6.34 megatons (2016 est.)
methane emissions:
5.73 megatons (2020 est.)
Waste and recycling:
municipal solid waste generated annually:
210,854 tons (2010 est.)
municipal solid waste recycled annually:
2,109 tons (2005 est.)
percent of municipal solid waste recycled:
1% (2005 est.)
Major rivers (by length in km):
Zambezi (shared with Zambia [s]), Angola, Namibia, Zimbabwe, and Mozambique [m]) - 2,740 km; Limpopo (shared with South Africa [s], Zimbabwe, and Mozambique [m]) - 1,800 km; Okavango river mouth (shared with Angola [s], and Namibia) - 1,600 km
note
– [s] after country name indicates river source; [m] after country name indicates river mouth
Major watersheds (area sq km): Atlantic Ocean drainage:
Orange (941,351 sq km)
Indian Ocean drainage:
Zambezi (1,332,412 sq km)
Internal
(endorheic basin)
drainage:
Okavango Basin (863,866 sq km)
Major aquifers:
Lower Kalahari-Stampriet Basin, Upper Kalahari-Cuvelai-Upper Zambezi Basin
Total water withdrawal:
municipal:
110 million cubic meters (2020 est.)
industrial:
30 million cubic meters (2020 est.)
agricultural:
80 million cubic meters (2020 est.)
Total renewable water resources:
12.24 billion cubic meters (2020 est.)','28f8c9d287066b08c0dba935b00f725e9c6a495e164b0471cba8fb4350378070','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('511598ec0b3402b9822bff370e1f0a1ce0b821393a4775efa3e155d98b470678',2025,'BV','Bouvet Island','environment',16,'Environment - current issues:
none; almost entirely ice covered
Climate:
antarctic
Land use:
agricultural land:
0% (2018 est.)
arable land:
0% (2018 est.)
permanent crops:
0% (2018 est.)
permanent pasture:
0% (2018 est.)
forest:
0% (2018 est.)
other:
100% (2018 est.)','a9589a7fd40d33f6bb8d87126ea38f8bd91944c30f125f8f4503a6d8aa020a6e','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('32a929d979a96976a69f5c4107301fb3ee2ed442eeffde2560b3c95689b96b47',2025,'BR','Brazil','environment',25,'Environment - current issues:
deforestation in Amazon Basin destroys the habitat and endangers a multitude of plant and animal species indigenous to the area; illegal wildlife trade; illegal poaching; air and water pollution in Rio de Janeiro, Sao Paulo, and several other large cities; land degradation and water pollution caused by improper mining activities; wetland degradation; severe oil spills
Environment - international agreements:
party to:
Antarctic-Environmental Protection, Antarctic-Marine Living Resources, Antarctic Seals, Antarctic Treaty, Biodiversity, Climate Change, Climate Change-Kyoto Protocol, Climate Change-Paris Agreement, Comprehensive Nuclear Test Ban, Desertification, Endangered Species, Environmental Modification, Hazardous Wastes, Law of the Sea, Marine Dumping-London Convention, Nuclear Test Ban, Ozone Layer Protection, Ship Pollution, Tropical Timber 2006, Wetlands, Whaling
signed, but not ratified:
Marine Dumping-London Protocol
Climate:
mostly tropical, but temperate in south
Land use:
agricultural land:
32.9% (2018 est.)
arable land:
8.6% (2018 est.)
permanent crops:
0.8% (2018 est.)
permanent pasture:
23.5% (2018 est.)
forest:
61.9% (2018 est.)
other:
5.2% (2018 est.)
Urbanization:
urban population:
87.8% of total population (2023)
rate of urbanization:
0.87% annual rate of change (2020-25 est.)
Revenue from forest resources:
0.62% of GDP (2018 est.)
comparison ranking:
61
Revenue from coal:
0.01% of GDP (2018 est.)
comparison ranking:
51
Air pollutants:
particulate matter emissions:
10.94 micrograms per cubic meter (2019 est.)
carbon dioxide emissions:
462.3 megatons (2016 est.)
methane emissions:
401.83 megatons (2020 est.)
Waste and recycling:
municipal solid waste generated annually:
79,889,010 tons (2015 est.)
municipal solid waste recycled annually:
1,118,446 tons (2014 est.)
percent of municipal solid waste recycled:
1.4% (2014 est.)
Major lakes (area sq km):
fresh water lake(s):
Lagoa dos Patos - 10,140 sq km
salt water lake(s):
Lagoa Mirim (shared with Uruguay) - 2,970 sq km
Major rivers (by length in km):
Amazon river mouth (shared with Peru [s]) - 6,400 km; Río de la Plata/Paraná river source (shared with Paraguay, Argentina, and Uruguay [m]) - 4,880 km; Tocantins - 3,650 km; São Francisco - 3,180 km; Paraguay river source (shared with Argentina and Paraguay [m]) - 2,549 km; Rio Negro river mouth (shared with Colombia [s] and Venezuela) - 2,250 km; Uruguay river source (shared with Argentina and Uruguay [m]) - 1,610 km
note
– [s] after country name indicates river source; [m] after country name indicates river mouth
Major watersheds (area sq km): Atlantic Ocean drainage:
Amazon (6,145,186 sq km), Orinoco (953,675 sq km), Paraná (2,582,704 sq km), São Francisco (617,814 sq km), Tocantins (764,213 sq km)
Major aquifers:
Amazon Basin, Guarani Aquifer System, Maranhao Basin
Total water withdrawal:
municipal:
16.13 billion cubic meters (2020 est.)
industrial:
9.51 billion cubic meters (2020 est.)
agricultural:
41.42 billion cubic meters (2020 est.)
Total renewable water resources:
8.65 trillion cubic meters (2020 est.)','6abdff51c1863fac45d2b54d5e674e7f8fa1a7e2db23f08f10049f094f68ad10','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d3d9fc2fe1714aa9ab9348ebfa558fe776f547bef1450e12bec853d32dac9e03',2025,'IO','British Indian Ocean Territory','environment',38,'Environment - current issues:
wastewater discharge into the lagoon on Diego Garcia
Climate:
tropical marine; hot, humid, moderated by trade winds
Land use:
agricultural land:
0% (2018 est.)
arable land:
0% (2018 est.)
permanent crops:
0% (2018 est.)
permanent pasture:
0% (2018 est.)
forest:
0% (2018 est.)
other:
100% (2018 est.)','b5381af60a15a08d8bc14a2d4d0039c15d46cf55b55e56f2dc933d39e9d9a2cd','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0fe0fe07d29ce7c139e92d695740b5b5e8a466f364293a4ec6b580259ff44f29',2025,'IO','British Indian Ocean Territory','environment',48,'Environment - current issues:
limited natural freshwater resources except for a few seasonal streams and springs on Tortola; most of the islands’ water supply comes from desalination plants; sewage and mining/industry waste contribute to water pollution, threatening coral reefs
Climate:
subtropical; humid; temperatures moderated by trade winds
Land use:
agricultural land:
46.7% (2018 est.)
arable land:
6.7% (2018 est.)
permanent crops:
6.7% (2018 est.)
permanent pasture:
33.3% (2018 est.)
forest:
24.3% (2018 est.)
other:
29% (2018 est.)
Urbanization:
urban population:
49.7% of total population (2023)
rate of urbanization:
1.73% annual rate of change (2020-25 est.)
Air pollutants:
carbon dioxide emissions:
0.21 megatons (2016 est.)
Waste and recycling:
municipal solid waste generated annually:
21,099 tons (2000 est.)','67d24400f9e33d898f03a96105041cf33b7972f2503fee2600e383c67986582e','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e97a36fe7ac30104ec2667974b0bbfe2e38b319cf090a35c9534e385174284d8',2025,'IO','British Indian Ocean Territory','environment',59,'Environment - current issues:
no major environmental problems, but air pollution control is becoming a concern; seasonal trans-boundary haze from forest fires in Indonesia
Environment - international agreements:
party to:
Biodiversity, Climate Change, Climate Change-Kyoto Protocol, Climate Change-Paris Agreement, Comprehensive Nuclear Test Ban, Desertification, Endangered Species, Hazardous Wastes, Law of the Sea, Ozone Layer Protection, Ship Pollution
signed, but not ratified:
none of the selected agreements
Climate:
tropical; hot, humid, rainy
Land use:
agricultural land:
2.5% (2018 est.)
arable land:
0.8% (2018 est.)
permanent crops:
1.1% (2018 est.)
permanent pasture:
0.6% (2018 est.)
forest:
71.8% (2018 est.)
other:
25.7% (2018 est.)
Urbanization:
urban population:
79.1% of total population (2023)
rate of urbanization:
1.44% annual rate of change (2020-25 est.)
Revenue from forest resources:
0.05% of GDP (2018 est.)
comparison ranking:
129
Revenue from coal:
0% of GDP (2018 est.)
comparison ranking:
106
Air pollutants:
particulate matter emissions:
6.86 micrograms per cubic meter (2019 est.)
carbon dioxide emissions:
7.66 megatons (2016 est.)
methane emissions:
8.4 megatons (2020 est.)
Waste and recycling:
municipal solid waste generated annually:
216,253 tons (2016 est.)
Total water withdrawal:
municipal:
150 million cubic meters (2020 est.)
agricultural:
10 million cubic meters (2020 est.)
Total renewable water resources:
8.5 billion cubic meters (2020 est.)','9d6e229253ad1f239035da9af99cb5477431183bbe855429669f27e34f6edae2','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d6e9972f0b13b1d45bb1e2bb5f481aeebd3d0826cbcc788775137b00865ad2d1',2025,'BG','Bulgaria','environment',4,'Environment - current issues:
air pollution from industrial emissions; rivers polluted from raw sewage, heavy metals, detergents; deforestation; forest damage from air pollution and resulting acid rain; soil contamination from heavy metals from metallurgical plants and industrial wastes
Environment - international agreements:
party to:
Air Pollution, Air Pollution-Heavy Metals, Air Pollution-Multi-effect Protocol, Air Pollution-Nitrogen Oxides, Air Pollution-Persistent Organic Pollutants, Air Pollution-Sulphur 85, Air Pollution-Sulphur 94, Air Pollution-Volatile Organic Compounds, Antarctic-Environmental Protection, Antarctic-Marine Living Resources, Antarctic Treaty, Biodiversity, Climate Change, Climate Change-Kyoto Protocol, Climate Change-Paris Agreement, Comprehensive Nuclear Test Ban, Desertification, Endangered Species, Environmental Modification, Hazardous Wastes, Law of the Sea, Marine Dumping-London Convention, Marine Dumping-London Protocol, Nuclear Test Ban, Ozone Layer Protection, Ship Pollution, Tropical Timber 2006, Wetlands, Whaling
signed, but not ratified:
none of the selected agreements
Climate:
temperate; cold, damp winters; hot, dry summers
Land use:
agricultural land:
46.9% (2018 est.)
arable land:
29.9% (2018 est.)
permanent crops:
1.5% (2018 est.)
permanent pasture:
15.5% (2018 est.)
forest:
36.7% (2018 est.)
other:
16.4% (2018 est.)
Urbanization:
urban population:
76.7% of total population (2023)
rate of urbanization:
-0.28% annual rate of change (2020-25 est.)
Revenue from forest resources:
0.22% of GDP (2018 est.)
comparison ranking:
90
Revenue from coal:
0.14% of GDP (2018 est.)
comparison ranking:
24
Air pollutants:
particulate matter emissions:
17.29 micrograms per cubic meter (2019 est.)
carbon dioxide emissions:
41.71 megatons (2016 est.)
methane emissions:
6.77 megatons (2020 est.)
Waste and recycling:
municipal solid waste generated annually:
3.011 million tons (2015 est.)
municipal solid waste recycled annually:
572,993 tons (2015 est.)
percent of municipal solid waste recycled:
19% (2015 est.)
Major rivers (by length in km):
Dunav (Danube) (shared with Germany [s], Austria, Slovakia, Czechia, Hungary, Croatia, Serbia, Ukraine, Moldova, and Romania [m]) - 2,888 km
note
– [s] after country name indicates river source; [m] after country name indicates river mouth
Major watersheds (area sq km): Atlantic Ocean drainage:
(Black Sea)
Danube (795,656 sq km)
Total water withdrawal:
municipal:
840 million cubic meters (2020 est.)
industrial:
3.48 billion cubic meters (2020 est.)
agricultural:
760 million cubic meters (2020 est.)
Total renewable water resources:
21.3 billion cubic meters (2020 est.)','ec21b9fa65bf3b18abbb437b5a8021673225c38ddd7af7ff94cb1c97ca65368b','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('29a2051f1ad54e50428c67442b52cb3bee325fd493ca45230572bac0e914f6af',2025,'BF','Burkina Faso','environment',17,'Environment - current issues:
recent droughts and desertification severely affecting agricultural activities, population distribution, and the economy; overgrazing; soil degradation; deforestation (2019)
Environment - international agreements:
party to:
Biodiversity, Climate Change, Climate Change-Kyoto Protocol, Climate Change-Paris Agreement, Comprehensive Nuclear Test Ban, Desertification, Endangered Species, Hazardous Wastes, Law of the Sea, Marine Life Conservation, Ozone Layer Protection, Wetlands
signed, but not ratified:
Nuclear Test Ban
Climate:
three climate zones including a hot tropical savanna with a short rainy season in the southern half, a tropical hot semi-arid steppe climate typical of the Sahel region in the northern half, and small area of hot desert in the very north of the country bordering the Sahara Desert
Land use:
agricultural land:
44.2% (2018 est.)
arable land:
22% (2018 est.)
permanent crops:
37% (2018 est.)
permanent pasture:
21.93% (2018 est.)
forest:
19.3% (2018 est.)
other:
36.5% (2018 est.)
Urbanization:
urban population:
32.5% of total population (2023)
rate of urbanization:
4.75% annual rate of change (2020-25 est.)
Food insecurity:
severe localized food insecurity:
due to civil insecurity in the north and high food prices - according to the latest analysis, about 3.53 million people are projected to face acute food insecurity during the June to August 2023 lean season period; this would be a slight increase compared to the preceding year; food insecurity is primarily underpinned by worsening insecurity in Centre-Nord and Sahel regions, which, as of December 2022 (the latest data available), had displaced about 1.88 million people; high food prices further aggravate conditions of the most vulnerable households (2023)
Revenue from forest resources:
4.54% of GDP (2018 est.)
comparison ranking:
14
Revenue from coal:
0% of GDP (2018 est.)
comparison ranking:
165
Air pollutants:
particulate matter emissions:
40.74 micrograms per cubic meter (2019 est.)
carbon dioxide emissions:
3.42 megatons (2016 est.)
methane emissions:
12.85 megatons (2020 est.)
Waste and recycling:
municipal solid waste generated annually:
2,575,251 tons (2015 est.)
municipal solid waste recycled annually:
309,030 tons (2005 est.)
percent of municipal solid waste recycled:
12% (2005 est.)
Major rivers (by length in km):
Volta river source (shared with Ghana [m]) - 1,600 km
note
– [s] after country name indicates river source; [m] after country name indicates river mouth
Major watersheds (area sq km): Atlantic Ocean drainage:
Niger (2,261,741 sq km), Volta (410,991 sq km)
Total water withdrawal:
municipal:
380 million cubic meters (2020 est.)
industrial:
20 million cubic meters (2020 est.)
agricultural:
420 million cubic meters (2020 est.)
Total renewable water resources:
13.5 billion cubic meters (2020 est.)','e97f28c9c122610ee2c3466054c58a16471376c42fa2442b6bee06e6047f7e42','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ce9b9006ebefbfe28b9d2efd1afcab9da1c4e34cbed73b2d315eeb8402c9c9e8',2025,'BF','Burkina Faso','environment',29,'Environment - current issues:
deforestation; industrial pollution of air, soil, and water; inadequate sanitation and water treatment contribute to disease; rapid depletion of the country’s natural resources
Environment - international agreements:
party to:
Biodiversity, Climate Change, Climate Change-Kyoto Protocol, Climate Change-Paris Agreement, Comprehensive Nuclear Test Ban, Desertification, Endangered Species, Hazardous Wastes, Law of the Sea, Nuclear Test Ban, Ozone Layer Protection, Ship Pollution, Tropical Timber 2006, Wetlands
signed, but not ratified:
none of the selected agreements
Climate:
tropical monsoon; cloudy, rainy, hot, humid summers (southwest monsoon, June to September); less cloudy, scant rainfall, mild temperatures, lower humidity during winter (northeast monsoon, December to April)
Land use:
agricultural land:
19.2% (2018 est.)
arable land:
16.5% (2018 est.)
permanent crops:
2.2% (2018 est.)
permanent pasture:
0.5% (2018 est.)
forest:
48.2% (2018 est.)
other:
32.6% (2018 est.)
Urbanization:
urban population:
32.1% of total population (2023)
rate of urbanization:
1.85% annual rate of change (2020-25 est.)
Food insecurity:
severe localized food insecurity:
due to conflict, political instability, and economic constraints - the political crisis, following the military takeover on 1 February 2021, resulted in increased tensions and unrest throughout the country; the current uncertain political situation may further compromise the fragile situation of vulnerable households and the Rohingya IDPs residing in the country; armed conflict between the military and non-state armed groups led to population displacements, disrupted agricultural activities and limited access for humanitarian support especially in Rakhine, Chin, Kachin, Kayin, Kayah and Shan states; income losses and a decline in remittances, due to the impact of the COVID-19 pandemic, have affected the food security situation of vulnerable households; domestic prices of Emata rice, the most consumed variety in the country, were at high levels in May 2022, constraining access to a key staple food (2022)
Revenue from forest resources:
1.69% of GDP (2018 est.)
comparison ranking:
38
Revenue from coal:
0.01% of GDP (2018 est.)
comparison ranking:
50
Air pollutants:
particulate matter emissions:
27.16 micrograms per cubic meter (2019 est.)
carbon dioxide emissions:
25.28 megatons (2016 est.)
methane emissions:
42.2 megatons (2020 est.)
Waste and recycling:
municipal solid waste generated annually:
4,677,307 tons (2000 est.)
Major rivers (by length in km):
Mekong (shared with China [s], Laos, Thailand, Cambodia, and Vietnam [m]) - 4,350 km; Salween river mouth (shared with China [s] and Thailand) - 3,060 km; Irrawaddy river mouth (shared with China [s]) - 2,809 km; Chindwin - 1,158 km
note
– [s] after country name indicates river source; [m] after country name indicates river mouth
Major watersheds (area sq km): Indian Ocean drainage:
Brahmaputra (651,335 sq km), Ganges (1,016,124 sq km), Irrawaddy (413,710 sq km), Salween (271,914 sq km)
Pacific Ocean drainage:
Mekong (805,604 sq km)
Total water withdrawal:
municipal:
3.32 billion cubic meters (2019 est.)
industrial:
500 million cubic meters (2019 est.)
agricultural:
29.57 billion cubic meters (2019 est.)
Total renewable water resources:
1.2 trillion cubic meters (2020 est.)','c38eae26ea006f830c6df2c1837c271d80709d177e4d4fd3ec566daa58c3fd10','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a00358d4f499f8679e3f67bb1d7377d29be2edc158a842c7e4c4e53e5d11e4dd',2025,'BI','Burundi','environment',40,'Environment - current issues:
soil erosion as a result of overgrazing and the expansion of agriculture into marginal lands; deforestation (little forested land remains because of uncontrolled cutting of trees for fuel); habitat loss threatens wildlife populations
Environment - international agreements:
party to:
Biodiversity, Climate Change, Climate Change-Kyoto Protocol, Climate Change-Paris Agreement, Comprehensive Nuclear Test Ban, Desertification, Endangered Species, Hazardous Wastes, Ozone Layer Protection, Wetlands
signed, but not ratified:
Law of the Sea, Nuclear Test Ban
Climate:
equatorial; high plateau with considerable altitude variation (772 m to 2,670 m above sea level); average annual temperature varies with altitude from 23 to 17 degrees Celsius but is generally moderate as the average altitude is about 1,700 m; average annual rainfall is about 150 cm; two wet seasons (February to May and September to November), and two dry seasons (June to August and December to January)
Land use:
agricultural land:
73.3% (2018 est.)
arable land:
38.9% (2018 est.)
permanent crops:
15.6% (2018 est.)
permanent pasture:
18.8% (2018 est.)
forest:
6.6% (2018 est.)
other:
20.1% (2018 est.)
Urbanization:
urban population:
14.8% of total population (2023)
rate of urbanization:
5.43% annual rate of change (2020-25 est.)
Food insecurity:
widespread lack of access:
due to the effects of weather - according to the latest estimates, about 1.2 million people are estimated to be facing Crisis levels of acute food insecurity between June and September 2023, unchanged year on year; the main drivers are the lingering impact of floods in northern areas in late 2022 and high food prices due, in part, to the depreciation of the local currency (2022)
Revenue from forest resources:
10.31% of GDP (2018 est.)
comparison ranking:
3
Revenue from coal:
0% of GDP (2018 est.)
comparison ranking:
126
Air pollutants:
particulate matter emissions:
28 micrograms per cubic meter (2019 est.)
carbon dioxide emissions:
0.5 megatons (2016 est.)
methane emissions:
1.42 megatons (2020 est.)
Waste and recycling:
municipal solid waste generated annually:
1,872,016 tons (2002 est.)
Major lakes (area sq km):
fresh water lake(s):
Lake Tanganyika (shared with Democratic Republic of Congo, Tanzania, and Zambia) - 32,000 sq km
Major watersheds (area sq km): Atlantic Ocean drainage:
Congo (3,730,881 sq km), (Mediterranean Sea) Nile (3,254,853 sq km)
Total water withdrawal:
municipal:
40 million cubic meters (2020 est.)
industrial:
20 million cubic meters (2020 est.)
agricultural:
220 million cubic meters (2020 est.)
Total renewable water resources:
12.54 billion cubic meters (2020 est.)','566579b3866cb7c787608db88f3bedfbdd8addad49a53a03021b2bdd63e36cc3','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('38d93103d0bbc2a3029d99f122782d67650c7b33e5895992198b4039cec31ef2',2025,'CV','Cabo Verde','environment',4,'Environment - current issues:
deforestation due to demand for firewood; water shortages; prolonged droughts and improper use of land (overgrazing, crop cultivation on hillsides lead to desertification and erosion); environmental damage has threatened several species of birds and reptiles; illegal beach sand extraction; overfishing
Environment - international agreements:
party to:
Biodiversity, Climate Change, Climate Change-Kyoto Protocol, Climate Change-Paris Agreement, Comprehensive Nuclear Test Ban, Desertification, Endangered Species, Environmental Modification, Hazardous Wastes, Law of the Sea, Marine Dumping-London Convention, Nuclear Test Ban, Ozone Layer Protection, Ship Pollution, Wetlands
signed, but not ratified:
none of the selected agreements
Climate:
temperate; warm, dry summer; precipitation meager and erratic
Land use:
agricultural land:
18.6% (2018 est.)
arable land:
11.7% (2018 est.)
permanent crops:
0.7% (2018 est.)
permanent pasture:
6.2% (2018 est.)
forest:
21% (2018 est.)
other:
60.4% (2018 est.)
Urbanization:
urban population:
68% of total population (2023)
rate of urbanization:
1.83% annual rate of change (2020-25 est.)
Revenue from forest resources:
0.38% of GDP (2018 est.)
comparison ranking:
72
Revenue from coal:
0% of GDP (2018 est.)
comparison ranking:
125
Air pollutants:
particulate matter emissions:
31.08 micrograms per cubic meter (2019 est.)
carbon dioxide emissions:
0.54 megatons (2016 est.)
methane emissions:
0.13 megatons (2020 est.)
Waste and recycling:
municipal solid waste generated annually:
132,555 tons (2012 est.)
Total water withdrawal:
municipal:
1.6 million cubic meters (2017 est.)
industrial:
400,000 cubic meters (2017 est.)
agricultural:
30 million cubic meters (2020 est.)
Total renewable water resources:
300 million cubic meters (2020 est.)','b8dcfc777aaa02287c5a9712818e5278ba99e48192ea96242e2f551a7c22ed69','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f0305f7994c51051b26d4bcb96dd338266b8ec44e8856c8bbfb9e72fbc05f445',2025,'KH','Cambodia','environment',15,'Environment - current issues:
illegal logging activities throughout the country and strip mining for gems in the western region along the border with Thailand have resulted in habitat loss and declining biodiversity (in particular, destruction of mangrove swamps threatens natural fisheries); soil erosion; in rural areas, most of the population does not have access to potable water; declining fish stocks because of illegal fishing and overfishing; coastal ecosystems choked by sediment washed loose from deforested areas inland
Environment - international agreements:
party to:
Biodiversity, Climate Change, Climate Change-Kyoto Protocol, Climate Change-Paris Agreement, Comprehensive Nuclear Test Ban, Desertification, Endangered Species, Hazardous Wastes, Marine Life Conservation, Ozone Layer Protection, Ship Pollution, Tropical Timber 2006, Wetlands, Whaling
signed, but not ratified:
Law of the Sea
Climate:
tropical; rainy, monsoon season (May to November); dry season (December to April); little seasonal temperature variation
Land use:
agricultural land:
32.1% (2018 est.)
arable land:
22.7% (2018 est.)
permanent crops:
0.9% (2018 est.)
permanent pasture:
8.5% (2018 est.)
forest:
56.5% (2018 est.)
other:
11.4% (2018 est.)
Urbanization:
urban population:
25.6% of total population (2023)
rate of urbanization:
3.06% annual rate of change (2020-25 est.)
Revenue from forest resources:
0.84% of GDP (2018 est.)
comparison ranking:
57
Revenue from coal:
0% of GDP (2018 est.)
comparison ranking:
87
Air pollutants:
particulate matter emissions:
17.8 micrograms per cubic meter (2019 est.)
carbon dioxide emissions:
9.92 megatons (2016 est.)
methane emissions:
14.88 megatons (2020 est.)
Waste and recycling:
municipal solid waste generated annually:
1.089 million tons (2014 est.)
Major lakes (area sq km):
fresh water lake(s):
Tonle Sap - 2,700-16,000 sq km
Major rivers (by length in km):
Mekong (shared with China [s], Burma, Thailand, Laos, and Vietnam [m]) - 4,350 km
note – [s] after country name indicates river source; [m] after country name indicates river mouth
Major watersheds (area sq km): Pacific Ocean drainage:
Mekong (805,604 sq km)
Total water withdrawal:
municipal:
100 million cubic meters (2020 est.)
industrial:
30 million cubic meters (2020 est.)
agricultural:
2.05 billion cubic meters (2020 est.)
Total renewable water resources:
476.1 billion cubic meters (2020 est.)','f6bbc92c34762e1272f60fad4ebee85ae3ecc2bb0c452001273e841e463b893a','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8fc20dbdebc5feb72afe73f18bac98cb8c1d264438ad8aa416d9e8dd327bbc98',2025,'CM','Cameroon','environment',26,'Environment - current issues:
waterborne diseases are prevalent; deforestation and overgrazing result in erosion, desertification, and reduced quality of pastureland; poaching; overfishing; overhunting
Environment - international agreements:
party to:
Biodiversity, Climate Change, Climate Change-Kyoto Protocol, Climate Change-Paris Agreement, Comprehensive Nuclear Test Ban, Desertification, Endangered Species, Environmental Modification, Hazardous Wastes, Law of the Sea, Ozone Layer Protection, Ship Pollution, Tropical Timber 2006, Wetlands, Whaling
signed, but not ratified:
Nuclear Test Ban
Climate:
varies with terrain, from tropical along coast to semiarid and hot in north
Land use:
agricultural land:
20.6% (2018 est.)
arable land:
13.1% (2018 est.)
permanent crops:
3.3% (2018 est.)
permanent pasture:
4.2% (2018 est.)
forest:
41.7% (2018 est.)
other:
37.7% (2018 est.)
Urbanization:
urban population:
59.3% of total population (2023)
rate of urbanization:
3.43% annual rate of change (2020-25 est.)
Food insecurity:
severe localized food insecurity: due to civil insecurity, high food prices, and floods -
according to a November 2022 analysis (the latest available), about 3.6 million people were estimated to be acutely food insecure between October and December 2022, as a result of conflict, sociopolitical unrest and high food prices, as well as floods that caused people displacements, damaged standing crops and prevented access to fields (2023)
Revenue from forest resources:
2.5% of GDP (2018 est.)
comparison ranking:
27
Revenue from coal:
0% of GDP (2018 est.)
comparison ranking:
183
Air pollutants:
particulate matter emissions:
56.37 micrograms per cubic meter (2019 est.)
carbon dioxide emissions:
8.29 megatons (2016 est.)
methane emissions:
30.71 megatons (2020 est.)
Waste and recycling:
municipal solid waste generated annually:
3,270,617 tons (2013 est.)
municipal solid waste recycled annually:
13,082 tons (2009 est.)
percent of municipal solid waste recycled:
0.4% (2009 est.)
Major lakes (area sq km):
fresh water lake(s):
Lake Chad (endorheic lake shared with Niger, Nigeria, and Chad) - 10,360-25,900 sq km note - area varies by season and year to year
Major watersheds (area sq km): Atlantic Ocean drainage:
Congo (3,730,881 sq km), Niger (2,261,741 sq km)
Internal
(endorheic basin)
drainage:
Lake Chad (2,497,738 sq km)
Major aquifers:
Lake Chad Basin
Total water withdrawal:
municipal:
250 million cubic meters (2020 est.)
industrial:
100 million cubic meters (2020 est.)
agricultural:
740 million cubic meters (2020 est.)
Total renewable water resources:
283.15 billion cubic meters (2020 est.)','9b07550fa93672dbf8fcce5be7f509862bd061a8d1b1f1284b59d572897f60b4','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b417d4281c3d543d3a5841b170b1fdc1551eda5f60fd049327a0e8c2d6cc85f9',2025,'CA','Canada','environment',38,'Environment - current issues:
metal smelting, coal-burning utilities, and vehicle emissions impacting agricultural and forest productivity; air pollution and resulting acid rain severely affecting lakes and damaging forests; ocean waters becoming contaminated due to agricultural, industrial, mining, and forestry activities
Environment - international agreements:
party to:
Air Pollution, Air Pollution-Heavy Metals, Air Pollution-Multi-effect Protocol, Air Pollution-Nitrogen Oxides, Air Pollution-Persistent Organic Pollutants, Air Pollution-Sulphur 85, Air Pollution-Sulphur 94, Antarctic-Environmental Protection, Antarctic-Marine Living Resources, Antarctic Treaty, Biodiversity, Climate Change, Climate Change-Paris Agreement, Comprehensive Nuclear Test Ban, Desertification, Endangered Species, Environmental Modification, Hazardous Wastes, Law of the Sea, Marine Dumping-London Convention, Marine Dumping-London Protocol, Nuclear Test Ban, Ozone Layer Protection, Ship Pollution, Wetlands
signed, but not ratified:
Air Pollution-Volatile Organic Compounds, Marine Life Conservation
Climate:
varies from temperate in south to subarctic and arctic in north
Land use:
agricultural land:
6.8% (2018 est.)
arable land:
4.7% (2018 est.)
permanent crops:
0.5% (2018 est.)
permanent pasture:
1.6% (2018 est.)
forest:
34.1% (2018 est.)
other:
59.1% (2018 est.)
Urbanization:
urban population:
81.9% of total population (2023)
rate of urbanization:
0.95% annual rate of change (2020-25 est.)
Revenue from forest resources:
0.08% of GDP (2018 est.)
comparison ranking:
119
Revenue from coal:
0.08% of GDP (2018 est.)
comparison ranking:
27
Air pollutants:
particulate matter emissions:
6.39 micrograms per cubic meter (2019 est.)
carbon dioxide emissions:
544.89 megatons (2016 est.)
methane emissions:
101.82 megatons (2020 est.)
Waste and recycling:
municipal solid waste generated annually:
25,103,034 tons (2014 est.)
municipal solid waste recycled annually:
5,168,715 tons (2008 est.)
percent of municipal solid waste recycled:
20.6% (2008 est.)
Major lakes (area sq km):
fresh water lake(s):
Huron* - 35,972 sq km; Great Bear Lake - 31,328 sq km; Superior* - 28,754 sq km; Great Slave Lake - 28,568 sq km; Lake Winnipeg - 24,387 sq km; Erie* - 12,776 sq km; Ontario* - 9,790 sq km; Lake Athabasca - 7,935 sq km; Reindeer Lake - 6,650 sq km; Nettilling Lake - 5,542 sq km
note - Great Lakes* area shown as Canadian waters
Major rivers (by length in km):
Mackenzie - 4, 241 km; Yukon river source (shared with the US [m]) - 3,185 km; Saint Lawrence river mouth (shared with US) - 3,058 km; Nelson - 2,570 km; Columbia river source (shared with the US [m]) - 1,953 km; Churchill - 1,600 km; Fraser - 1,368 km; Ottawa - 1,271 km; Athabasca - 1,231 km; North Saskatchewan - 1,220 km; Liard - 1,115 km
note – [s] after country name indicates river source; [m] after country name indicates river mouth
Major watersheds (area sq km): Atlantic Ocean drainage:
Mississippi*
(Gulf of Mexico)
(3,202,185 sq km, Canada only 32,000 sq km), Nelson
(Hudson Bay)
(1,093,141 sq km), Saint Lawrence* (1,049,636 sq km, Canada only 839,200 sq km)
Arctic Ocean drainage:
Mackenzie (1,706,388 sq km)
Pacific Ocean drainage:
Yukon* (847,620 sq km, Canada only 823,800 sq km), Columbia* (657,501 sq km, Canada only 103,000 sq km)
note - watersheds shared with the US shown with *
Major aquifers:
Northern Great Plains Aquifer
Total water withdrawal:
municipal:
4.87 billion cubic meters (2020 est.)
industrial:
27.51 billion cubic meters (2020 est.)
agricultural:
3.86 billion cubic meters (2020 est.)
Total renewable water resources:
2.9 trillion cubic meters (2020 est.)','1acccff098729b898907784dd937c8e61ad44ff343d059f550a333f237db50d7','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('942e30df45b9557fd2207736859531e80c85a198c3c33f93889b8e3869f97d39',2025,'KY','Cayman Islands','environment',51,'Environment - current issues:
no natural freshwater resources; drinking water supplies are met by reverse osmosis desalination plants and rainwater catchment; trash washing up on the beaches or being deposited there by residents; no recycling or waste treatment facilities; deforestation (trees being cut down to create space for commercial use)
Climate:
tropical marine; warm, rainy summers (May to October) and cool, relatively dry winters (November to April)
Land use:
agricultural land:
11.2% (2018 est.)
arable land:
0.8% (2018 est.)
permanent crops:
2.1% (2018 est.)
permanent pasture:
8.3% (2018 est.)
forest:
52.9% (2018 est.)
other:
35.9% (2018 est.)
Urbanization:
urban population:
100% of total population (2023)
rate of urbanization:
1.13% annual rate of change (2020-25 est.)
Revenue from forest resources:
0% of GDP (2018 est.)
comparison ranking:
199
Revenue from coal:
0% of GDP (2018 est.)
comparison ranking:
127
Air pollutants:
carbon dioxide emissions:
0.55 megatons (2016 est.)
Waste and recycling:
municipal solid waste generated annually:
60,000 tons (2014 est.)
municipal solid waste recycled annually:
12,600 tons (2013 est.)
percent of municipal solid waste recycled:
21% (2013 est.)','931d29c709b875cd84b3c687d0efc5f96d3419d999252f3591c2a2327ce321d1','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('30ea1d5a09691cfb37c872e0b3494bede93ce0abf8ea63a924954fa2d87f2826',2025,'CF','Central African Republic','environment',62,'Environment - current issues:
water pollution; tap water is not potable; poaching and mismanagement have diminished the country’s reputation as one of the last great wildlife refuges; desertification; deforestation; soil erosion
Environment - international agreements:
party to:
Biodiversity, Climate Change, Climate Change-Kyoto Protocol, Climate Change-Paris Agreement, Comprehensive Nuclear Test Ban, Desertification, Endangered Species, Hazardous Wastes, Nuclear Test Ban, Ozone Layer Protection, Tropical Timber 2006, Wetlands
signed, but not ratified:
Law of the Sea
Climate:
tropical; hot, dry winters; mild to hot, wet summers
Land use:
agricultural land:
8.1% (2018 est.)
arable land:
2.9% (2018 est.)
permanent crops:
0.1% (2018 est.)
permanent pasture:
5.1% (2018 est.)
forest:
36.2% (2018 est.)
other:
55.7% (2018 est.)
Urbanization:
urban population:
43.6% of total population (2023)
rate of urbanization:
3.32% annual rate of change (2020-25 est.)
Food insecurity:
exceptional shortfall in aggregate food production/supplies:
due to internal conflict and high food prices -
according to the latest analysis, issued in November 2022, the number of people in Crisis and above is estimated at 2.7 million between September 2022 and March 2023; this is mainly attributed to the impact of civil insecurity and high food prices; persisting insecurity and population displacements continue to affect agricultural activities and limit farmers’ access to crop growing areas and agricultural inputs; elevated international prices of fuel and fertilizers, largely imported, have reportedly led to a lower use of agricultural inputs in 2022, especially among smallholder farmers, with a negative impact on yields (2023)
Revenue from forest resources:
8.99% of GDP (2018 est.)
comparison ranking:
5
Revenue from coal:
0% of GDP (2018 est.)
comparison ranking:
71
Air pollutants:
particulate matter emissions:
27.2 micrograms per cubic meter (2019 est.)
carbon dioxide emissions:
0.3 megatons (2016 est.)
methane emissions:
22.44 megatons (2020 est.)
Waste and recycling:
municipal solid waste generated annually:
1,105,983 tons (2014 est.)
Major rivers (by length in km):
Oubangui (Ubangi) river [s] (shared with Democratic Republic of Congo and Republic of Congo [m]) - 2,270 km
note – [s] after country name indicates river source; [m] after country name indicates river mouth
Major watersheds (area sq km):
Atlantic Ocean drainage: Congo (3,730,881 sq km), (Mediterranean Sea) Nile (3,254,853 sq km) Internal (endorheic basin) drainage: Lake Chad (2,497,738 sq km)
Major aquifers:
Congo Basin, Lake Chad Basin
Total water withdrawal:
municipal:
60 million cubic meters (2020 est.)
industrial:
10 million cubic meters (2020 est.)
agricultural:
400,000 cubic meters (2017 est.)
Total renewable water resources:
141 billion cubic meters (2020 est.)','048edc5e249820047920007ebf2feb9c7caf7a1bd5d2f820db63f9b5934d4200','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b7191f504fa7603a3c443607152c954d4d9d829efa38eaad962c81196e191cca',2025,'TD','Chad','environment',4,'Environment - current issues:
inadequate supplies of potable water; improper waste disposal in rural areas and poor farming practices contribute to soil and water pollution; desertification
Environment - international agreements:
party to:
Biodiversity, Climate Change, Climate Change-Kyoto Protocol, Climate Change-Paris Agreement, Comprehensive Nuclear Test Ban, Desertification, Endangered Species, Hazardous Wastes, Law of the Sea, Nuclear Test Ban, Ozone Layer Protection, Wetlands
signed, but not ratified:
Marine Dumping-London Convention
Climate:
tropical in south, desert in north
Land use:
agricultural land:
39.6% (2018 est.)
arable land:
3.9% (2018 est.)
permanent crops:
0% (2018 est.)
permanent pasture:
35.7% (2018 est.)
forest:
9.1% (2018 est.)
other:
51.3% (2018 est.)
Urbanization:
urban population:
24.4% of total population (2023)
rate of urbanization:
4.1% annual rate of change (2020-25 est.)
Food insecurity:
widespread lack of access: due to civil insecurity and shortfall in cereal production -
according to the latest analysis, about 1.86 million people are projected to experience acute food insecurity during the June to August 2023 lean season period; this would be an improvement compared to the previous year, mostly due to the higher year-on-year cereal output in 2022 after the below average 2021 production; acute food insecurity is underpinned by persisting insecurity in the Lac and Tibesti regions, which had displaced over 380 000 people by April 2023; furthermore, elevated food prices due to high fuel costs and localized crop losses during the 2022 floods are aggravating food insecurity (2023)
Revenue from forest resources:
3.81% of GDP (2018 est.)
comparison ranking:
19
Revenue from coal:
0% of GDP (2018 est.)
comparison ranking:
73
Air pollutants:
particulate matter emissions:
41.15 micrograms per cubic meter (2019 est.)
carbon dioxide emissions:
1.02 megatons (2016 est.)
methane emissions:
30.69 megatons (2020 est.)
Waste and recycling:
municipal solid waste generated annually:
1,358,851 tons (2010 est.)
Major lakes (area sq km):
fresh water lake(s):
Lake Chad (endorheic lake shared with Niger, Nigeria, and Cameroon) - 10,360-25,900 sq km note - area varies by season and year to year
Major watersheds (area sq km): Atlantic Ocean drainage:
Niger (2,261,741 sq km)
Internal
(endorheic basin)
drainage:
Lake Chad (2,497,738 sq km)
Major aquifers:
Lake Chad Basin, Nubian Aquifer System
Total water withdrawal:
municipal:
100 million cubic meters (2020 est.)
industrial:
100 million cubic meters (2020 est.)
agricultural:
670 million cubic meters (2020 est.)
Total renewable water resources:
45.7 billion cubic meters (2020 est.)','cec60a9f2a99e934de3d45c16eff9728cf78c7c6348e6916c19e8e8e153e7574','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('095e1f6ccfd895f38b4fbf2a047b9590714ddac637e3b881c1e844396366c3b0',2025,'CL','Chile','environment',16,'Environment - current issues:
air pollution from industrial and vehicle emissions; water pollution from raw sewage; noise pollution; improper garbage disposal; soil degradation; widespread deforestation and mining threaten the environment; wildlife conservation
Environment - international agreements:
party to:
Antarctic-Environmental Protection, Antarctic-Marine Living Resources, Antarctic Seals, Antarctic Treaty, Biodiversity, Climate Change, Climate Change-Kyoto Protocol, Climate Change-Paris Agreement, Comprehensive Nuclear Test Ban, Desertification, Endangered Species, Environmental Modification, Hazardous Wastes, Law of the Sea, Marine Dumping-London Convention, Marine Dumping-London Protocol, Nuclear Test Ban, Ozone Layer Protection, Ship Pollution, Wetlands, Whaling
signed, but not ratified:
none of the selected agreements
Climate:
temperate; desert in north; Mediterranean in central region; cool and damp in south
Land use:
agricultural land:
21.1% (2018 est.)
arable land:
1.7% (2018 est.)
permanent crops:
0.6% (2018 est.)
permanent pasture:
18.8% (2018 est.)
forest:
21.9% (2018 est.)
other:
57% (2018 est.)
Urbanization:
urban population:
88% of total population (2023)
rate of urbanization:
0.78% annual rate of change (2020-25 est.)
Revenue from forest resources:
0.49% of GDP (2018 est.)
comparison ranking:
67
Revenue from coal:
0.01% of GDP (2018 est.)
comparison ranking:
46
Air pollutants:
particulate matter emissions:
20.49 micrograms per cubic meter (2019 est.)
carbon dioxide emissions:
85.82 megatons (2016 est.)
methane emissions:
15.97 megatons (2020 est.)
Waste and recycling:
municipal solid waste generated annually:
6.517 million tons (2009 est.)
municipal solid waste recycled annually:
24,113 tons (2009 est.)
percent of municipal solid waste recycled:
0.4% (2009 est.)
Major lakes (area sq km):
fresh water lake(s):
Lago General Carrera (shared with Argentina) - 2,240 sq km; Lago O’Higgins (shared with Argentina) - 1,010 sq km; Lago Llanquihue - 800 sq km; Lago Fagnano (shared with Argentina) - 590 sq km
Total water withdrawal:
municipal:
1.29 billion cubic meters (2020 est.)
industrial:
1.66 billion cubic meters (2020 est.)
agricultural:
29.42 billion cubic meters (2020 est.)
Total renewable water resources:
923.1 billion cubic meters (2020 est.)','8d8db63680a8ea05ea808c535e4a05a3741ec4fea235b58f71f75ba39bc4af4d','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('577cd2f6fe58f18d29d74f990cf9174bc2dbbf8ce69bdb1921bf15bdf928acad',2025,'CN','China','environment',28,'Environment - current issues:
air pollution (greenhouse gases, sulfur dioxide particulates) from reliance on coal produces acid rain; China is the world’s largest single emitter of carbon dioxide from the burning of fossil fuels; water shortages, particularly in the north; water pollution from untreated wastes; coastal destruction due to land reclamation, industrial development, and aquaculture; deforestation and habitat destruction; poor land management leads to soil erosion, landslides, floods, droughts, dust storms, and desertification; trade in endangered species
Environment - international agreements:
party to:
Antarctic-Environmental Protection, Antarctic-Marine Living Resources, Antarctic Treaty, Biodiversity, Climate Change, Climate Change-Kyoto Protocol, Climate Change-Paris Agreement, Desertification, Endangered Species, Environmental Modification, Hazardous Wastes, Law of the Sea, Marine Dumping-London Convention, Marine DumpingLondon Protocol, Ozone Layer Protection, Ship Pollution, Tropical Timber 2006, Wetlands, Whaling
signed, but not ratified:
Comprehensive Nuclear Test Ban
Climate:
extremely diverse; tropical in south to subarctic in north
Land use:
agricultural land:
54.7% (2018 est.)
arable land:
11.3% (2018 est.)
permanent crops:
1.6% (2018 est.)
permanent pasture:
41.8% (2018 est.)
forest:
22.3% (2018 est.)
other:
23% (2018 est.)
Urbanization:
urban population:
64.6% of total population (2023)
rate of urbanization:
1.78% annual rate of change (2020-25 est.)
note:
data do not include Hong Kong and Macau
Revenue from forest resources:
0.08% of GDP (2018 est.)
comparison ranking:
117
Revenue from coal:
0.57% of GDP (2018 est.)
comparison ranking:
9
Air pollutants:
particulate matter emissions:
38.15 micrograms per cubic meter (2019 est.)
carbon dioxide emissions:
9,893.04 megatons (2016 est.)
methane emissions:
1,490.24 megatons (2020 est.)
Waste and recycling:
municipal solid waste generated annually:
210 million tons (2015 est.)
Major lakes (area sq km):
fresh water lake(s):
Dongting Hu - 3,100 sq km; Poyang Hu - 3,350 sq km; Hongze Hu - 2,700 sq km; Tai Hu - 2,210 sq km; Hulun Nur - 1,590
salt water lake(s):
Quinghai Hu - 4,460 sq km; Nam Co - 2,500 sq km; Siling Co - 1,860 sq km; Tangra Yumco - 1,400 sq km; Bosten Hu 1,380 sq km
Major rivers (by length in km):
Yangtze - 6,300 km; Huang He - 5,464 km; Amur river source (shared with Mongolia and Russia [m]) - 4,444 km; Lancang Jiang (Mekong) river source (shared with Burma, Laos, Thailand, Cambodia, and Vietnam [m]) - 4,350 km; Yarlung Zangbo Jiang (Brahmaputra) river source (shared with India and Bangladesh [m]) - 3,969 km; Yin-tu Ho (Indus) river source (shared with India and Pakistan [m]) - 3,610 km; Nu Jiang (Salween) river source (shared with Thailand and Burma [m]) - 3,060 km; Irrawaddy river source (shared with Burma [m]) - 2,809 km; Zhu Jiang (Pearl) (shared with Vietnam [s]) - 2,200 km; Yuan Jiang (Red river) source (shared with Vietnam [m]) - 1,149 km
note – [s] after country name indicates river source; [m] after country name indicates river mouth
Major watersheds (area sq km): Pacific Ocean drainage:
Amur (1,929,955 sq km), Huang He (944,970 sq km), Mekong (805,604 sq km), Yangtze (1,722,193 sq km)
Indian Ocean drainage:
Brahmaputra (651,335 sq km), Ganges (1,016,124 sq km), Indus (1,081,718 sq km), Irrawaddy (413,710 sq km), Salween (271,914 sq km)
Arctic Ocean drainage:
Ob (2,972,493 sq km)
Internal
(endorheic basin)
drainage:
Tarim Basin (1,152,448 sq km), Amu Darya (534,739 sq km), Syr Darya (782,617 sq km), Lake Balkash (510,015 sq km)
Major aquifers:
North China Aquifer System (Huang Huai Hai Plain), Song-Liao Plain, Tarim Basin
Total water withdrawal:
municipal:
117.01 billion cubic meters (2020 est.)
industrial:
103.04 billion cubic meters (2020 est.)
agricultural:
361.24 billion cubic meters (2020 est.)
Total renewable water resources:
2.84 trillion cubic meters (2020 est.)','ce6a193e0ef96330aa11dd9f48a4f6dfae34a8150065f0a613cbe2b35efe0b34','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9876964dfce64ff16e04c97153876183c3e826e7a75f73952360298d7cda50b5',2025,'CX','Christmas Island','environment',40,'Environment - current issues:
loss of rainforest; impact of phosphate mining
Climate:
tropical with a wet season (December to April) and dry season; heat and humidity moderated by trade winds','2cff2ba01bff1b9538f64a2a9b35eaeee148a5957f17b3d57e19d472eefb9a09','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fbcddb31144469112895c84a14cdfc033696e8dc1827f406c4c694cff25bd3fc',2025,'CX','Christmas Island','environment',50,'Environment - current issues:
no natural resources, guano deposits depleted; the ring-shaped atoll encloses a stagnant fresh-water lagoon
Climate:
tropical; humid, average temperature 20-32 degrees Celsius, wet season (May to October)
Land use:
agricultural land:
0% (2018 est.)
forest:
0% (2018 est.)
other:
100% (2018 est.)','66c9955bb8ec322f2e6c78778273837a69b24981935cbf2f41a2e53fed444042','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('80c6dccecaec7a46f09fa21948227dea67ee76f3b50f1cf750152fb2f83d4237',2025,'CC','Cocos (Keeling) Islands','environment',58,'Environment - current issues:
freshwater resources are limited to rainwater accumulations in natural underground reservoirs; illegal fishing a concern
Climate:
tropical with high humidity, moderated by the southeast trade winds for about nine months of the year
Land use:
agricultural land:
0% (2018 est.)
forest:
0% (2018 est.)
other:
100% (2018 est.)','8d702e78ed862ca2aeb0329f23f4fd769c9a4c6250da613ef3d32b4d5d730154','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('187b5f4a4906337a3599726cc71766d75cfe47f79e3d2c76aec3070dea3e4b7b',2025,'CO','Colombia','environment',68,'Environment - current issues:
deforestation resulting from timber exploitation in the jungles of the Amazon and the region of Chocó; illicit drug crops grown by peasants in the national parks; soil erosion; soil and water quality damage from overuse of pesticides; air pollution, especially in Bogota, from vehicle emissions
Environment - international agreements:
party to:
Antarctic-Environmental Protection, Antarctic Treaty, Biodiversity, Climate Change, Climate Change-Kyoto Protocol, Climate Change-Paris Agreement, Comprehensive Nuclear Test Ban, Desertification, Endangered Species, Hazardous Wastes, Marine Life Conservation, Nuclear Test Ban, Ozone Layer Protection, Ship Pollution, Tropical Timber 2006, Wetlands, Whaling
signed, but not ratified:
Law of the Sea
Climate:
tropical along coast and eastern plains; cooler in highlands
Land use:
agricultural land:
37.5% (2018 est.)
arable land:
1.4% (2018 est.)
permanent crops:
1.6% (2018 est.)
permanent pasture:
34.5% (2018 est.)
forest:
54.4% (2018 est.)
other:
8.1% (2018 est.)
Urbanization:
urban population:
82.4% of total population (2023)
rate of urbanization:
1.01% annual rate of change (2020-25 est.)
Revenue from forest resources:
0.1% of GDP (2018 est.)
comparison ranking:
110
Revenue from coal:
0.75% of GDP (2018 est.)
comparison ranking:
8
Air pollutants:
particulate matter emissions:
14.04 micrograms per cubic meter (2019 est.)
carbon dioxide emissions:
97.81 megatons (2016 est.)
methane emissions:
81.52 megatons (2020 est.)
Waste and recycling:
municipal solid waste generated annually:
12,150,120 tons (2011 est.)
municipal solid waste recycled annually:
2,089,821 tons (2013 est.)
percent of municipal solid waste recycled:
17.2% (2013 est.)
Major rivers (by length in km):
Rio Negro river source (shared with Venezuela and Brazil [m]) - 2,250 km; Orinoco (shared with Venezuela [s]) - 2,101 km
note – [s] after country name indicates river source; [m] after country name indicates river mouth
Major watersheds (area sq km): Atlantic Ocean drainage:
Amazon (6,145,186 sq km), Orinoco (953,675 sq km)
Major aquifers:
Amazon Basin
Total water withdrawal:
municipal:
3.72 billion cubic meters (2020 est.)
industrial:
360 million cubic meters (2020 est.)
agricultural:
25.04 billion cubic meters (2020 est.)
Total renewable water resources:
2.36 trillion cubic meters (2020 est.)','627e267de0cdf71ecb5913bc64c5af3dc9df2931d22609551944baa84bab3607','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f3f897fd3eaf87cb8f045e18b8fcf5f3cff747b44d63b9aa6e78b87d3f15e543',2025,'KM','Comoros','environment',4,'Environment - current issues:
deforestation; soil degradation and erosion results from forest loss and from crop cultivation on slopes without proper terracing; marine biodiversity affected as soil erosion leads to the silting of coral reefs
Environment - international agreements:
party to:
Biodiversity, Climate Change, Climate Change-Kyoto Protocol, Climate Change-Paris Agreement, Comprehensive Nuclear Test Ban, Desertification, Endangered Species, Hazardous Wastes, Law of the Sea, Ozone Layer Protection, Ship Pollution, Wetlands
signed, but not ratified:
none of the selected agreements
Climate:
tropical marine; rainy season (November to May)
Land use:
agricultural land:
84.4% (2018 est.)
arable land:
46.7% (2018 est.)
permanent crops:
29.6% (2018 est.)
permanent pasture:
8.1% (2018 est.)
forest:
1.4% (2018 est.)
other:
14.2% (2018 est.)
Urbanization:
urban population:
30.1% of total population (2023)
rate of urbanization:
2.97% annual rate of change (2020-25 est.)
Revenue from forest resources:
1.39% of GDP (2018 est.)
comparison ranking:
46
Revenue from coal:
0% of GDP (2018 est.)
comparison ranking:
182
Air pollutants:
particulate matter emissions:
14.37 micrograms per cubic meter (2019 est.)
carbon dioxide emissions:
0.2 megatons (2016 est.)
methane emissions:
0.19 megatons (2020 est.)
Waste and recycling:
municipal solid waste generated annually:
91,013 tons (2015 est.)
Total water withdrawal:
municipal:
4.8 million cubic meters (2017 est.)
industrial:
500,000 cubic meters (2017 est.)
agricultural:
4.7 million cubic meters (2017 est.)
Total renewable water resources:
1.2 billion cubic meters (2020 est.)','fbfd4136ba5d924cd24df244b90e2d2d98b8ea5fa2c120e9a9e2d8790ae70db9','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('02a3551c36885dcbe52b2cf71a75a41af8bf1c6a533124dd3f569afac5af8a8b',2025,'KM','Comoros','environment',15,'Environment - current issues:
poaching threatens wildlife populations; water pollution; deforestation (forests endangered by fires set to clear the land for agricultural purposes; forests also used as a source of fuel); soil erosion; mining (diamonds, gold, coltan - a mineral used in creating capacitors for electronic devices) causing environmental damage
Environment - international agreements:
party to:
Biodiversity, Climate Change, Climate Change-Kyoto Protocol, Climate Change-Paris Agreement, Comprehensive Nuclear Test Ban, Desertification, Endangered Species, Hazardous Wastes, Law of the Sea, Marine Dumping-London Convention, Nuclear Test Ban, Ozone Layer Protection, Tropical Timber 2006, Wetlands
signed, but not ratified:
Environmental Modification
Climate:
tropical; hot and humid in equatorial river basin; cooler and drier in southern highlands; cooler and wetter in eastern highlands; north of Equator - wet season (April to October), dry season (December to February); south of Equator - wet season (November to March), dry season (April to October)
Land use:
agricultural land:
11.4% (2018 est.)
arable land:
3.1% (2018 est.)
permanent crops:
0.3% (2018 est.)
permanent pasture:
8% (2018 est.)
forest:
67.9% (2018 est.)
other:
20.7% (2018 est.)
Urbanization:
urban population:
47.4% of total population (2023)
rate of urbanization:
4.33% annual rate of change (2020-25 est.)
Food insecurity:
widespread lack of access: due to internal conflict in eastern regions and high food prices -
according to an October 2022 analysis, 24.5 million people were projected to experience acute food insecurity between January and June 2023; this is due to the intensification of the conflict in the northeastern provinces, which, among other factors, has prevented completion of the harvests and likely will reduce food availability in the months to come (2023)
Revenue from forest resources:
8.72% of GDP (2018 est.)
comparison ranking:
6
Revenue from coal:
0% of GDP (2018 est.)
comparison ranking:
90
Air pollutants:
particulate matter emissions:
31.58 micrograms per cubic meter (2019 est.)
carbon dioxide emissions:
2.02 megatons (2016 est.)
methane emissions:
61.24 megatons (2020 est.)
Waste and recycling:
municipal solid waste generated annually:
14,385,226 tons (2016 est.)
municipal solid waste recycled annually:
704,876 tons (2005 est.)
percent of municipal solid waste recycled:
4.9% (2005 est.)
Major lakes (area sq km):
fresh water lake(s):
Lake Tanganyika (shared with Burundi, Tanzania, and Zambia) - 32,000 sq km; Lake Albert (shared with Uganda) - 5,590 sq km; Lake Mweru (shared with Zambia) - 4,350 sq km; Lac Mai-Ndombe - 2,300 sq km; Lake Kivu (shared with Rwanda) - 2,220 sq km; Lake Edward (shared with Uganda) - 2,150 sq km; Lac Tumba - 500 sq km; Lac Upemba - 530 sq km
Major rivers (by length in km):
Zaïre (Congo) river mouth (shared with Zambia [s], Angola, and Republic of Congo) - 4,700 km; Ubangi river mouth (shared with Central African Republic [s] and Republic of Congo) - 2,270 km note – [s] after country name indicates river source; [m] after country name indicates river mouth
Major watersheds (area sq km): Atlantic Ocean drainage:
Congo (3,730,881 sq km),
(Mediterranean Sea)
Nile (3,254,853 sq km)
Indian Ocean drainage:
Zambezi (1,332,412 sq km)
Major aquifers:
Congo Basin
Total water withdrawal:
municipal:
460 million cubic meters (2020 est.)
industrial:
150 million cubic meters (2020 est.)
agricultural:
70 million cubic meters (2020 est.)
Total renewable water resources:
1.29 trillion cubic meters (2020 est.)','03bbaeb51c25c9d553ef3badc7c45daf0c4ac2ef8682db893f89f5ba8b808fc3','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b919baacbecdd4938135160c9fbc2f2461b2dabdbd63ef6d9aac4a324f30d3ac',2025,'KM','Comoros','environment',27,'Environment - current issues:
air pollution from vehicle emissions; water pollution from raw sewage; tap water is not potable; deforestation; wildlife protection
Environment - international agreements:
party to:
Biodiversity, Climate Change, Climate Change-Kyoto Protocol, Climate Change-Paris Agreement, Desertification, Endangered Species, Hazardous Wastes, Law of the Sea, Marine Dumping-London Protocol, Ozone Layer Protection, Ship Pollution, Tropical Timber 2006, Wetlands
signed, but not ratified:
none of the selected agreements
Climate:
tropical; rainy season (March to June); dry season (June to October); persistent high temperatures and humidity; particularly enervating climate astride the Equator
Land use:
agricultural land:
31.1% (2018 est.)
arable land:
1.6% (2018 est.)
permanent crops:
0.2% (2018 est.)
permanent pasture:
29.3% (2018 est.)
forest:
65.6% (2018 est.)
other:
3.3% (2018 est.)
Urbanization:
urban population:
69.2% of total population (2023)
rate of urbanization:
3.19% annual rate of change (2020-25 est.)
Food insecurity:
severe localized food insecurity: due to floods -
above average rainfall amounts since November 2022 triggered flooding in December 2022 and January 2023 in central and northern parts of the country, displacing people; according to damage assessment reports, about 165,000 people have been affected in 23 districts in the departments of Cuvette, Likouala, Plateaux and Sangha (2023)
Revenue from forest resources:
3.17% of GDP (2018 est.)
comparison ranking:
23
Revenue from coal:
0% of GDP (2018 est.)
comparison ranking:
70
Air pollutants:
particulate matter emissions:
29.48 micrograms per cubic meter (2019 est.)
carbon dioxide emissions:
3.28 megatons (2016 est.)
methane emissions:
2.24 megatons (2020 est.)
Waste and recycling:
municipal solid waste generated annually:
451,200 tons (1993 est.)
municipal solid waste recycled annually:
118,214 tons (2005 est.)
percent of municipal solid waste recycled:
26.2% (2005 est.)
Major rivers (by length in km):
Oubangui (Ubangi) (shared with Central African Republic [s] and Democratic Republic of Congo [m]) - 2,270 km
note
– [s] after country name indicates river source; [m] after country name indicates river mouth
Major watersheds (area sq km): Atlantic Ocean drainage:
Congo (3,730,881 sq km)
Major aquifers:
Congo Basin
Total water withdrawal:
municipal:
60 million cubic meters (2020 est.)
industrial:
20 million cubic meters (2020 est.)
agricultural:
4 million cubic meters (2017 est.)
Total renewable water resources:
832 billion cubic meters (2020 est.)','68817194d8c14bf6a9a9b0da3c11084019fce2e566247aae8e0fe26f84c50094','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5505a04665e096f338936889bd024665684f6e059e83750f06121ec540d9bd85',2025,'CK','Cook Islands','environment',38,'Environment - current issues:
limited land presents solid and liquid waste disposal problems; soil destruction and deforestation; environmental degradation due to indiscriminate use of pesticides; improper disposal of pollutants; overfishing and destructive fishing practices; over dredging of lagoons and coral rubble beds; unregulated building
Environment - international agreements:
party to:
Antarctic-Marine Living Resources, Biodiversity, Climate Change, Climate Change-Kyoto Protocol, Climate Change-Paris Agreement, Comprehensive Nuclear Test Ban, Desertification, Hazardous Wastes, Law of the Sea, Ozone Layer Protection, Ship Pollution
signed, but not ratified:
none of the selected agreements
Climate:
tropical oceanic; moderated by trade winds; a dry season from April to November and a more humid season from December to March
Land use:
agricultural land:
8.4% (2018 est.)
arable land:
4.2% (2018 est.)
permanent crops:
4.2% (2018 est.)
permanent pasture:
0% (2018 est.)
forest:
64.6% (2018 est.)
other:
27% (2018 est.)
Urbanization:
urban population:
76.2% of total population (2023)
rate of urbanization:
0.52% annual rate of change (2020-25 est.)
Air pollutants:
particulate matter emissions:
7.8 micrograms per cubic meter (2019 est.)
Total renewable water resources:
0 cubic meters (2017 est.)','d1382141bd743842bb65d0532965093771bbc4eef3214e7ca6a13bdeb2980885','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cf0445abd87e113e75f4a2141921a4e0bfbbdaf0f16fd919f678013fc20416ed',2025,'CK','Cook Islands','environment',49,'Environment - current issues:
no permanent freshwater resources; damaging activities include coral mining, destructive fishing practices (overfishing, blast fishing)
Climate:
tropical
Land use:
agricultural land:
0% (2018 est.)
other:
100% (2018 est.)','bc27c797526591442d3a852d47b9649341981066d5426fe05a8ed5ae8b166d42','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('dbd9ef845e3e142c9de9bc7ead593c533d22d09a11f5e8ba2dcc928c35d87adb',2025,'CR','Costa Rica','environment',58,'Environment - current issues:
deforestation and land use change, largely a result of the clearing of land for cattle ranching and agriculture; soil erosion; coastal marine pollution; fisheries protection; solid waste management; air pollution
Environment - international agreements:
party to:
Biodiversity, Climate Change, Climate Change-Kyoto Protocol, Climate Change-Paris Agreement, Comprehensive Nuclear Test Ban, Desertification, Endangered Species, Environmental Modification, Hazardous Wastes, Law of the Sea, Marine Dumping-London Convention, Nuclear Test Ban, Ozone Layer Protection, Tropical Timber 2006, Wetlands, Whaling
signed, but not ratified:
Marine Life Conservation
Climate:
tropical and subtropical; dry season (December to April); rainy season (May to November); cooler in highlands
Land use:
agricultural land:
37.1% (2018 est.)
arable land:
4.9% (2018 est.)
permanent crops:
6.7% (2018 est.)
permanent pasture:
25.5% (2018 est.)
forest:
51.5% (2018 est.)
other:
11.4% (2018 est.)
Urbanization:
urban population:
82.6% of total population (2023)
rate of urbanization:
1.5% annual rate of change (2020-25 est.)
Revenue from forest resources:
0.82% of GDP (2018 est.)
comparison ranking:
58
Revenue from coal:
0% of GDP (2018 est.)
comparison ranking:
152
Air pollutants:
particulate matter emissions:
14.7 micrograms per cubic meter (2019 est.)
carbon dioxide emissions:
8.02 megatons (2016 est.)
methane emissions:
5.61 megatons (2020 est.)
Waste and recycling:
municipal solid waste generated annually:
1.46 million tons (2014 est.)
municipal solid waste recycled annually:
18,396 tons (2014 est.)
percent of municipal solid waste recycled:
1.3% (2014 est.)
Total water withdrawal:
municipal:
830 million cubic meters (2020 est.)
industrial:
230 million cubic meters (2020 est.)
agricultural:
2.08 billion cubic meters (2020 est.)
Total renewable water resources:
113 billion cubic meters (2020 est.)','b977e95988d39fb7cb279a1b2f6e70c16158b21b87ffbf4a67affdb7c082499f','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('03388f5a2f04ca30917056f0da9f2ebf38494518caad7b155c15ac563e5c5fc4',2025,'CR','Costa Rica','environment',70,'Environment - current issues:
deforestation (most of the country’s forests - once the largest in West Africa - have been heavily logged); water pollution from sewage, and from industrial, mining, and agricultural effluents
Environment - international agreements:
party to:
Biodiversity, Climate Change, Climate Change-Kyoto Protocol, Climate Change-Paris Agreement, Comprehensive Nuclear Test Ban, Desertification, Endangered Species, Hazardous Wastes, Law of the Sea, Marine Dumping-London Convention, Nuclear Test Ban, Ozone Layer Protection, Ship Pollution, Tropical Timber 2006, Wetlands, Whaling
signed, but not ratified:
none of the selected agreements
Climate:
tropical along coast, semiarid in far north; three seasons - warm and dry (November to March), hot and dry (March to May), hot and wet (June to October)
Land use:
agricultural land:
64.8% (2018 est.)
arable land:
9.1% (2018 est.)
permanent crops:
14.2% (2018 est.)
permanent pasture:
41.5% (2018 est.)
forest:
32.7% (2018 est.)
other:
2.5% (2018 est.)
Urbanization:
urban population:
53.1% of total population (2023)
rate of urbanization:
3.38% annual rate of change (2020-25 est.)
Revenue from forest resources:
2.04% of GDP (2016 est.)
comparison ranking:
34
Revenue from coal:
0% of GDP (2018 est.)
comparison ranking:
166
Air pollutants:
particulate matter emissions:
40.41 micrograms per cubic meter (2019 est.)
carbon dioxide emissions:
9.67 megatons (2016 est.)
methane emissions:
10.3 megatons (2020 est.)
Waste and recycling:
municipal solid waste generated annually:
4,440,814 tons (2010 est.)
municipal solid waste recycled annually:
133,224 tons (2005 est.)
percent of municipal solid waste recycled:
3% (2005 est.)
Major lakes (area sq km):
salt water lake(s):
Lagune Aby - 780 sq km
Major watersheds (area sq km): Atlantic Ocean drainage:
Niger (2,261,741 sq km), Volta (410,991 sq km)
Total water withdrawal:
municipal:
320 million cubic meters (2020 est.)
industrial:
240 million cubic meters (2020 est.)
agricultural:
600 million cubic meters (2020 est.)
Total renewable water resources:
84.14 billion cubic meters (2020 est.)','fd7822c6fb40dc9d7aaa1e13e7c04aaa0c3c74a56fe3a81b981646d975cda0ab','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4ca62e371f37bb388fa0a179bae4accffe08a0807dd20d6e32907c530a1e0048',2025,'HR','Croatia','environment',4,'Environment - current issues:
air pollution improving but still a concern in urban settings and in emissions arriving from neighboring countries; surface water pollution in the Danube River Basin
Environment - international agreements:
party to:
Air Pollution, Air Pollution-Heavy Metals, Air Pollution-Multi-effect Protocol, Air Pollution-Nitrogen Oxides, Air Pollution-Persistent Organic Pollutants, Air Pollution-Sulphur 94, Air Pollution-Volatile Organic Compounds, Biodiversity, Climate Change, Climate Change-Kyoto Protocol, Climate Change-Paris Agreement, Comprehensive Nuclear Test Ban, Desertification, Endangered Species, Hazardous Wastes, Law of the Sea, Marine Dumping-London Convention, Nuclear Test Ban, Ozone Layer Protection, Ship Pollution, Tropical Timber 2006, Wetlands, Whaling
signed, but not ratified:
none of the selected agreements
Climate:
Mediterranean and continental; continental climate predominant with hot summers and cold winters; mild winters, dry summers along coast
Land use:
agricultural land:
23.7% (2018 est.)
arable land:
16% (2018 est.)
permanent crops:
1.5% (2018 est.)
permanent pasture:
6.2% (2018 est.)
forest:
34.4% (2018 est.)
other:
41.9% (2018 est.)
Urbanization:
urban population:
58.6% of total population (2023)
rate of urbanization:
0.05% annual rate of change (2020-25 est.)
Revenue from forest resources:
0.26% of GDP (2018 est.)
comparison ranking:
87
Revenue from coal:
0% of GDP (2018 est.)
comparison ranking:
129
Air pollutants:
particulate matter emissions:
15.29 micrograms per cubic meter (2019 est.)
carbon dioxide emissions:
17.49 megatons (2016 est.)
methane emissions:
3.98 megatons (2020 est.)
Waste and recycling:
municipal solid waste generated annually:
1.654 million tons (2015 est.)
municipal solid waste recycled annually:
269,933 tons (2015 est.)
percent of municipal solid waste recycled:
16.3% (2015 est.)
Major rivers (by length in km):
Dunav (Danube) (shared with Germany [s], Austria, Slovakia, Czechia, Hungary, Serbia, Bulgaria, Ukraine, Moldova, and Romania [m]) - 2,888 km
note – [s] after country name indicates river source; [m] after country name indicates river mouth
Major watersheds (area sq km): Atlantic Ocean drainage:
(Black Sea)
Danube (795,656 sq km)
Total water withdrawal:
municipal:
460 million cubic meters (2020 est.)
industrial:
700 million cubic meters (2020 est.)
agricultural:
80 million cubic meters (2020 est.)
Total renewable water resources:
105.5 billion cubic meters (2020 est.)','712245eed25c60720e4aed5c498ff45227265e958fd85fc88d90a95ddde5f735','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4e5649851d87ad3acf445d552624941d91a3aafbfbc7579f8007a4c917c71375',2025,'CU','Cuba','environment',15,'Environment - current issues:
soil degradation and desertification (brought on by poor farming techniques and natural disasters) are the main environmental problems; biodiversity loss; deforestation; air and water pollution
Environment - international agreements:
party to:
Antarctic Treaty, Biodiversity, Climate Change, Climate Change-Kyoto Protocol, Climate Change-Paris Agreement, Comprehensive Nuclear Test Ban, Desertification, Endangered Species, Environmental Modification, Hazardous Wastes, Law of the Sea, Marine Dumping-London Convention, Ozone Layer Protection, Ship Pollution, Wetlands
signed, but not ratified:
Marine Life Conservation
Climate:
tropical; moderated by trade winds; dry season (November to April); rainy season (May to October)
Land use:
agricultural land:
60.3% (2018 est.)
arable land:
33.8% (2018 est.)
permanent crops:
3.6% (2018 est.)
permanent pasture:
22.9% (2018 est.)
forest:
27.3% (2018 est.)
other:
12.4% (2018 est.)
Urbanization:
urban population:
77.5% of total population (2023)
rate of urbanization:
0.19% annual rate of change (2020-25 est.)
Revenue from forest resources:
0.06% of GDP (2018 est.)
comparison ranking:
125
Revenue from coal:
0% of GDP (2018 est.)
comparison ranking:
60
Air pollutants:
particulate matter emissions:
13.32 micrograms per cubic meter (2019 est.)
carbon dioxide emissions:
28.28 megatons (2016 est.)
methane emissions:
9.3 megatons (2020 est.)
Waste and recycling:
municipal solid waste generated annually:
2,692,692 tons (2007 est.)
municipal solid waste recycled annually:
255,536 tons (2015 est.)
percent of municipal solid waste recycled:
9.5% (2015 est.)
Total water withdrawal:
municipal:
1.7 billion cubic meters (2020 est.)
industrial:
740 million cubic meters (2020 est.)
agricultural:
4.52 billion cubic meters (2020 est.)
Total renewable water resources:
38.12 billion cubic meters (2020 est.)','14ba8615fd2579748d897a1da386036efcfd5d47b1ae3e7d089fb2033c5bfce4','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('79653ba3d434b77824d201f8eb560eaf036cca9cc2d992f81a432b6450e3a68c',2025,'CU','Cuba','environment',26,'Environment - current issues:
problems in waste management that threaten environmental sustainability on the island include pollution of marine areas from domestic sewage, inadequate sewage treatment facilities, industrial effluents and agricultural runoff, the mismanagement of toxic substances, and ineffective regulations; the refinery in Sint Anna Bay, at the eastern edge of Willemstad’s large natural harbor, processes heavy crude oil from Venezuela; it has caused significant environmental damage to the surrounding area because of neglect and a lack of strict environmental controls; the release of noxious fumes and potentially hazardous particles causes schools downwind to regularly close
Climate:
tropical marine climate, ameliorated by northeast trade winds, results in mild temperatures; semiarid with average rainfall of 60 cm/year
Land use:
agricultural land:
10% (2018 est.)
arable land:
10% (2018)
other:
90% (2018 est.)
Urbanization:
urban population:
89% of total population (2023)
rate of urbanization:
0.57% annual rate of change (2020-25 est.)
Revenue from forest resources:
0% of GDP (2018 est.)
comparison ranking:
182
Revenue from coal:
0% of GDP (2018 est.)
comparison ranking:
116
Air pollutants:
carbon dioxide emissions:
5.39 megatons (2016 est.)
Waste and recycling:
municipal solid waste generated annually:
24,704 tons (2013 est.)
municipal solid waste recycled annually:
494 tons (2013 est.)
percent of municipal solid waste recycled:
2% (2013 est.)','87792014b2db89b7f8243fb476a8fefe2e8c4d8ae14140bf101e4b8e957bf46d','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('265b530ae4a4ddb0dc8c637dc849c8aa598d1c2ca92f7ce473f3a14ad4953b9c',2025,'CY','Cyprus','environment',37,'Environment - current issues:
water resource problems (no natural reservoir catchments, seasonal disparity in rainfall, sea water intrusion to island’s largest aquifer, increased salination in the north); water pollution from sewage, industrial wastes, and pesticides; coastal degradation; erosion; loss of wildlife habitats from urbanization
Environment - international agreements:
party to:
Air Pollution, Air Pollution-Heavy Metals, Air Pollution-Multi-effect Protocol, Air Pollution-Nitrogen Oxides, Air Pollution-Persistent Organic Pollutants, Air Pollution-Sulphur 94, Biodiversity, Climate Change, Climate Change-Kyoto Protocol, Climate Change-Paris Agreement, Comprehensive Nuclear Test Ban, Desertification, Endangered Species, Environmental Modification, Hazardous Wastes, Law of the Sea, Marine Dumping-London Convention, Nuclear Test Ban, Ozone Layer Protection, Ship Pollution, Tropical Timber 2006, Wetlands, Whaling
signed, but not ratified:
none of the selected agreements
Climate:
temperate; Mediterranean with hot, dry summers and cool winters
Land use:
agricultural land:
13.4% (2018 est.)
arable land:
9.8% (2018 est.)
permanent crops:
3.2% (2018 est.)
permanent pasture:
0.4% (2018 est.)
forest:
18.8% (2018 est.)
other:
67.8% (2018 est.)
Urbanization:
urban population:
67% of total population (2023)
rate of urbanization:
0.76% annual rate of change (2020-25 est.)
Revenue from forest resources:
0% of GDP (2018 est.)
comparison ranking:
194
Revenue from coal:
0% of GDP (2018 est.)
comparison ranking:
147
Air pollutants:
particulate matter emissions:
14.52 micrograms per cubic meter (2019 est.)
carbon dioxide emissions:
6.63 megatons (2016 est.)
methane emissions:
0.86 megatons (2020 est.)
Waste and recycling:
municipal solid waste generated annually:
541,000 tons (2015 est.)
municipal solid waste recycled annually:
72,007 tons (2015 est.)
percent of municipal solid waste recycled:
13.3% (2015 est.)
Total water withdrawal:
municipal:
100 million cubic meters (2020 est.)
industrial:
20 million cubic meters (2020 est.)
agricultural:
170 million cubic meters (2020 est.)
Total renewable water resources:
780 million cubic meters (2020 est.)','747faf6341705ee09530271dcd89d7762a1c8b6cc1c8a2baf78bacfea2ba5def','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6cddd5a04643e2631fb4c299debbd80042dc87cb965e47de1fc7337179f69ca4',2025,'CZ','Czechia','environment',49,'Environment - current issues:
air and water pollution in areas of northwest Bohemia and in northern Moravia around Ostrava present health risks; acid rain damaging forests; land pollution caused by industry, mining, and agriculture
Environment - international agreements:
party to:
Air Pollution, Air Pollution-Heavy Metals, Air Pollution-Multi-effect Protocol, Air Pollution-Nitrogen Oxides, Air Pollution-Persistent Organic Pollutants, Air Pollution-Sulphur 85, Air Pollution-Sulphur 94, Air Pollution-Volatile Organic Compounds, Antarctic-Environmental Protection, Antarctic Treaty, Biodiversity, Climate Change, Climate Change-Kyoto Protocol, Climate Change-Paris Agreement, Comprehensive Nuclear Test Ban, Desertification, Endangered Species, Environmental Modification, Hazardous Wastes, Law of the Sea, Nuclear Test Ban, Ozone Layer Protection, Ship Pollution, Tropical Timber 2006, Wetlands, Whaling
signed, but not ratified:
none of the selected agreements
Climate:
temperate; cool summers; cold, cloudy, humid winters
Land use:
agricultural land:
54.8% (2018 est.)
arable land:
41% (2018 est.)
permanent crops:
1% (2018 est.)
permanent pasture:
12.8% (2018 est.)
forest:
34.4% (2018 est.)
other:
10.8% (2018 est.)
Urbanization:
urban population:
74.6% of total population (2023)
rate of urbanization:
0.2% annual rate of change (2020-25 est.)
Revenue from forest resources:
0.17% of GDP (2017 est.)
comparison ranking:
97
Revenue from coal:
0.14% of GDP (2018 est.)
comparison ranking:
23
Air pollutants:
particulate matter emissions:
14.34 micrograms per cubic meter (2019 est.)
carbon dioxide emissions:
102.22 megatons (2016 est.)
methane emissions:
13.11 megatons (2020 est.)
Waste and recycling:
municipal solid waste generated annually:
3.337 million tons (2015 est.)
municipal solid waste recycled annually:
850,935 tons (2015 est.)
percent of municipal solid waste recycled:
25.5% (2015 est.)
Major rivers (by length in km):
Dunaj (Danube) (shared with Germany [s], Austria, Slovakia, Hungary, Croatia, Serbia, Bulgaria, Ukraine, Moldova, and Romania [m]) - 2,888 km; Labe (Elbe) river source (shared with Germany [m]) - 1,252 km
note – [s] after country name indicates river source; [m] after country name indicates river mouth
Major watersheds (area sq km): Atlantic Ocean drainage:
(Black Sea)
Danube (795,656 sq km)
Total water withdrawal:
municipal:
630 million cubic meters (2020 est.)
industrial:
700 million cubic meters (2020 est.)
agricultural:
40 million cubic meters (2020 est.)
Total renewable water resources:
13.5 billion cubic meters (2020 est.)','69fa0ae16992c8c16039a477a9d8c2e6c0af36aa21297d5a887f95e690da69b0','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('11c63c86e09107c2abc8db59edb7f93b88ab23ec6615d018061394237c7e019c',2025,'DK','Denmark','environment',4,'Environment - current issues:
air pollution, principally from vehicle and power plant emissions; nitrogen and phosphorus pollution of the North Sea; drinking and surface water becoming polluted from animal wastes and pesticides; much of country’s household and industrial waste is recycled
Environment - international agreements:
party to:
Air Pollution, Air Pollution-Heavy Metals, Air Pollution-Multi-effect Protocol, Air Pollution-Nitrogen Oxides, Air Pollution-Persistent Organic Pollutants, Air Pollution-Sulphur 85, Air Pollution-Sulphur 94, Air Pollution-Volatile Organic Compounds, Antarctic Treaty, Biodiversity, Climate Change, Climate Change-Kyoto Protocol, Climate Change-Paris Agreement, Comprehensive Nuclear Test Ban, Desertification, Endangered Species, Environmental Modification, Hazardous Wastes, Law of the Sea, Marine Dumping-London Convention, Marine Dumping-London Protocol, Marine Life Conservation, Nuclear Test Ban, Ozone Layer Protection, Ship Pollution, Tropical Timber 2006, Wetlands, Whaling
signed, but not ratified:
Antarctic-Environmental Protection
Climate:
temperate; humid and overcast; mild, windy winters and cool summers
Land use:
agricultural land:
63.4% (2018 est.)
arable land:
58.9% (2018 est.)
permanent crops:
0.1% (2018 est.)
permanent pasture:
4.4% (2018 est.)
forest:
12.9% (2018 est.)
other:
23.7% (2018 est.)
Urbanization:
urban population:
88.5% of total population (2023)
rate of urbanization:
0.54% annual rate of change (2020-25 est.)
Revenue from forest resources:
0.02% of GDP (2018 est.)
comparison ranking:
140
Revenue from coal:
0% of GDP (2018 est.)
comparison ranking:
108
Air pollutants:
particulate matter emissions:
9.66 micrograms per cubic meter (2019 est.)
carbon dioxide emissions:
31.79 megatons (2016 est.)
methane emissions:
6.54 megatons (2020 est.)
Waste and recycling:
municipal solid waste generated annually:
4.485 million tons (2015 est.)
municipal solid waste recycled annually:
1,223,060 tons (2015 est.)
percent of municipal solid waste recycled:
27.3% (2015 est.)
Total water withdrawal:
municipal:
400 million cubic meters (2020 est.)
industrial:
50 million cubic meters (2020 est.)
agricultural:
530 million cubic meters (2020 est.)
Total renewable water resources:
6 billion cubic meters (2020 est.)','503e33d7f869bd17897c637a08a3c4d808eae8817e2f2ca91bfe301cade60a30','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b962cec9312e5476bd3ab20063b8e9f81ad9afb47990729e8ca66a1e169bc819',2025,'DK','Denmark','environment',17,'Environment - current issues:
netting and trapping of small migrant songbirds in the spring and autumn
Climate:
temperate; Mediterranean with hot, dry summers and cool winters','804fdd4959272f35b7f1bb1ad65919f30a2480050a865637b4db7a1c4adc8d3d','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7ae01c2ae96309c9b93291f00630c34cad5fd21a4ea5d0977e78e813557d8720',2025,'DJ','Djibouti','environment',25,'Environment - current issues:
inadequate supplies of potable water; water pollution; limited arable land; deforestation (forests threatened by agriculture and the use of wood for fuel); desertification; endangered species
Environment - international agreements:
party to:
Biodiversity, Climate Change, Climate Change-Kyoto Protocol, Climate Change-Paris Agreement, Comprehensive Nuclear Test Ban, Desertification, Endangered Species, Hazardous Wastes, Law of the Sea, Ozone Layer Protection, Ship Pollution, Wetlands
signed, but not ratified:
none of the selected agreements
Climate:
desert; torrid, dry
Land use:
agricultural land:
73.4% (2018 est.)
arable land:
0.1% (2018 est.)
permanent crops:
0% (2018 est.)
permanent pasture:
73.3% (2018 est.)
forest:
0.2% (2018 est.)
other:
26.4% (2018 est.)
Urbanization:
urban population:
78.6% of total population (2023)
rate of urbanization:
1.56% annual rate of change (2020-25 est.)
Food insecurity:
widespread lack of access: due to unfavorable weather and high food prices
- about 250,000 people were estimated to have faced acute food insecurity between March and June 2023, mainly due to the lingering impact of a prolonged and severe drought between late 2020 and early 2023, and high food prices (2023)
Revenue from forest resources:
0.26% of GDP (2018 est.)
comparison ranking:
85
Revenue from coal:
0% of GDP (2018 est.)
comparison ranking:
62
Air pollutants:
particulate matter emissions:
19.98 micrograms per cubic meter (2019 est.)
carbon dioxide emissions:
0.62 megatons (2016 est.)
methane emissions:
0.52 megatons (2020 est.)
Waste and recycling:
municipal solid waste generated annually:
114,997 tons (2002 est.)
Major lakes (area sq km):
salt water lake(s):
Abhe Bad/Abhe Bid Hayk (shared with Ethiopia) - 780 sq km
Total water withdrawal:
municipal:
20 million cubic meters (2020 est.)
industrial:
0 cubic meters (2017 est.)
agricultural:
3 million cubic meters (2017 est.)
Total renewable water resources:
300 million cubic meters (2020 est.)','176b3770f89cca3f19a3f2a3d5b733192bca2f9fd12e5264c7ced9d5a27d1f86','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3fb67a4a58c006a788c954bf1aff3a29ee823224036f402931a1737622223f3b',2025,'DM','Dominica','environment',37,'Environment - current issues:
water shortages a continuing concern; pollution from agrochemicals and from untreated sewage; forests endangered by the expansion of farming; soil erosion; pollution of the coastal zone by agricultural and industrial chemicals, and untreated sewage
Environment - international agreements:
party to:
Biodiversity, Climate Change, Climate Change-Kyoto Protocol, Climate Change-Paris Agreement, Desertification, Endangered Species, Environmental Modification, Hazardous Wastes, Law of the Sea, Ozone Layer Protection, Ship Pollution, Whaling
signed, but not ratified:
none of the selected agreements
Climate:
tropical; moderated by northeast trade winds; heavy rainfall
Land use:
agricultural land:
34.7% (2018 est.)
arable land:
8% (2018 est.)
permanent crops:
24% (2018 est.)
permanent pasture:
2.7% (2018 est.)
forest:
59.2% (2018 est.)
other:
6.1% (2018 est.)
Urbanization:
urban population:
72% of total population (2023)
rate of urbanization:
0.84% annual rate of change (2020-25 est.)
Revenue from forest resources:
0.03% of GDP (2018 est.)
comparison ranking:
135
Revenue from coal:
0% of GDP (2018 est.)
comparison ranking:
162
Air pollutants:
particulate matter emissions:
8.22 micrograms per cubic meter (2019 est.)
carbon dioxide emissions:
0.18 megatons (2016 est.)
methane emissions:
0.04 megatons (2020 est.)
Waste and recycling:
municipal solid waste generated annually:
13,176 tons (2013 est.)
Total water withdrawal:
municipal:
20 million cubic meters (2020 est.)
industrial:
0 cubic meters (2017 est.)
agricultural:
1 million cubic meters (2017 est.)
Total renewable water resources:
200 million cubic meters (2020 est.)','6cb27a2302fb57985eb25a273ab5575fb8fae744a3a54720942ec859ee439b80','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('56ce54157ffda5db6c451a60fd0e76ce86d6d9de940488296a3202ee77dc421e',2025,'DO','Dominican Republic','environment',48,'Environment - current issues:
water shortages; soil eroding into the sea damages coral reefs; deforestation
Environment - international agreements:
party to:
Biodiversity, Climate Change, Climate Change-Kyoto Protocol, Climate Change-Paris Agreement, Comprehensive Nuclear Test Ban, Desertification, Endangered Species, Hazardous Wastes, Law of the Sea, Marine Dumping-London Convention, Marine Life Conservation, Nuclear Test Ban, Ozone Layer Protection, Ship Pollution, Wetlands, Whaling
signed, but not ratified:
none of the selected agreements
Climate:
tropical maritime; little seasonal temperature variation; seasonal variation in rainfall
Land use:
agricultural land:
51.5% (2018 est.)
arable land:
16.6% (2018 est.)
permanent crops:
10.1% (2018 est.)
permanent pasture:
24.8% (2018 est.)
forest:
40.8% (2018 est.)
other:
7.7% (2018 est.)
Urbanization:
urban population:
84.4% of total population (2023)
rate of urbanization:
1.64% annual rate of change (2020-25 est.)
Revenue from forest resources:
0.03% of GDP (2018 est.)
comparison ranking:
133
Revenue from coal:
0% of GDP (2018 est.)
comparison ranking:
176
Air pollutants:
particulate matter emissions:
7.59 micrograms per cubic meter (2019 est.)
carbon dioxide emissions:
25.26 megatons (2016 est.)
methane emissions:
8.1 megatons (2020 est.)
Waste and recycling:
municipal solid waste generated annually:
4,063,910 tons (2015 est.)
municipal solid waste recycled annually:
333,241 tons (2015 est.)
percent of municipal solid waste recycled:
8.2% (2015 est.)
Major lakes (area sq km):
salt water lake(s):
Lago de Enriquillo - 500 sq km
Total water withdrawal:
municipal:
860 million cubic meters (2020 est.)
industrial:
660 million cubic meters (2020 est.)
agricultural:
7.56 billion cubic meters (2020 est.)
Total renewable water resources:
23.5 billion cubic meters (2020 est.)','823078bcc175f95d7bb47f34f7796c44ac3751a3ef81035b9c556e109f069fa3','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8b32b29b2b1dd5d43e5d9f6769bb5a626343efb30f4b331ee3abbf0c922b341a',2025,'EC','Ecuador','environment',4,'Environment - current issues:
deforestation; soil erosion; desertification; water pollution; pollution from oil production wastes in ecologically sensitive areas of the Amazon Basin and Galapagos Islands
Environment - international agreements:
party to:
Antarctic-Environmental Protection, Antarctic Treaty, Biodiversity, Climate Change, Climate Change-Kyoto Protocol, Climate Change-Paris Agreement, Comprehensive Nuclear Test Ban, Desertification, Endangered Species, Hazardous Wastes, Law of the Sea, Nuclear Test Ban, Ozone Layer Protection, Ship Pollution, Tropical Timber 2006, Wetlands, Whaling
signed, but not ratified:
none of the selected agreements
Climate:
tropical along coast, becoming cooler inland at higher elevations; tropical in Amazonian jungle lowlands
Land use:
agricultural land:
29.7% (2018 est.)
arable land:
4.7% (2018 est.)
permanent crops:
5.6% (2018 est.)
permanent pasture:
19.4% (2018 est.)
forest:
38.9% (2018 est.)
other:
31.4% (2018 est.)
Urbanization:
urban population:
64.8% of total population (2023)
rate of urbanization:
1.62% annual rate of change (2020-25 est.)
Revenue from forest resources:
0.27% of GDP (2018 est.)
comparison ranking:
83
Revenue from coal:
0% of GDP (2018 est.)
comparison ranking:
61
Air pollutants:
particulate matter emissions:
16.55 micrograms per cubic meter (2019 est.)
carbon dioxide emissions:
41.15 megatons (2016 est.)
methane emissions:
23.51 megatons (2020 est.)
Waste and recycling:
municipal solid waste generated annually:
5,297,211 tons (2015 est.)
municipal solid waste recycled annually:
683,340 tons (2015 est.)
percent of municipal solid waste recycled:
12.9% (2015 est.)
Major watersheds (area sq km): Atlantic Ocean drainage:
Amazon (6,145,186 sq km)
Total water withdrawal:
municipal:
1.29 billion cubic meters (2020 est.)
industrial:
550 million cubic meters (2020 est.)
agricultural:
8.8 billion cubic meters (2020 est.)
Total renewable water resources:
442.4 billion cubic meters (2020 est.)','17dcf7a0439497a81bcf0f2a75f1d9ff13a0059fa74def6ed3c9efc34ab31ac3','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cc9df93e59c75f4ac2ee1ff18749fb78f54167dad8cbfcc58e9021fef365138d',2025,'EG','Egypt','environment',16,'Environment - current issues:
agricultural land being lost to urbanization and windblown sands; increasing soil salination below Aswan High Dam; desertification; oil pollution threatening coral reefs, beaches, and marine habitats; other water pollution from agricultural pesticides, raw sewage, and industrial effluents; limited natural freshwater resources away from the Nile, which is the only perennial water source; rapid growth in population overstraining the Nile and natural resources
Environment - international agreements:
party to:
Biodiversity, Climate Change, Climate Change-Kyoto Protocol, Climate Change-Paris Agreement, Desertification, Endangered Species, Environmental Modification, Hazardous Wastes, Law of the Sea, Marine Dumping- London Convention, Marine Dumping-London Protocol, Nuclear Test Ban, Ozone Layer Protection, Ship Pollution, Wetlands
signed, but not ratified:
Comprehensive Nuclear Test Ban
Climate:
desert; hot, dry summers with moderate winters
Land use:
agricultural land:
3.6% (2018 est.)
arable land:
2.8% (2018 est.)
permanent crops:
0.8% (2018 est.)
permanent pasture:
0% (2018 est.)
forest:
0.1% (2018 est.)
other:
96.3% (2018 est.)
Urbanization:
urban population:
43.1% of total population (2023)
rate of urbanization:
1.9% annual rate of change (2020-25 est.)
Revenue from forest resources:
0.15% of GDP (2018 est.)
comparison ranking:
101
Air pollutants:
particulate matter emissions:
63.16 micrograms per cubic meter (2019 est.)
carbon dioxide emissions:
238.56 megatons (2016 est.)
methane emissions:
59.68 megatons (2020 est.)
Waste and recycling:
municipal solid waste generated annually:
21 million tons (2012 est.)
municipal solid waste recycled annually:
2.625 million tons (2013 est.)
percent of municipal solid waste recycled:
12.5% (2013 est.)
Major lakes (area sq km):
salt water lake(s):
Lake Manzala - 1,360 sq km
note - largest of Nile Delta lakes
Major rivers (by length in km):
An Nīl (Nile) river mouth (shared with Rwanda [s], Tanzania, Uganda, South Sudan, and Sudan) - 6,650 km
note
– [s] after country name indicates river source; [m] after country name indicates river mouth
Major watersheds (area sq km): Atlantic Ocean drainage:
(Mediterranean Sea)
Nile (3,254,853 sq km)
Major aquifers:
Nubian Aquifer System
Total water withdrawal:
municipal:
10.75 billion cubic meters (2020 est.)
industrial:
5.4 billion cubic meters (2020 est.)
agricultural:
61.35 billion cubic meters (2020 est.)
Total renewable water resources:
57.5 billion cubic meters (2020 est.)','6d47e0448e9ba110bf5801dfab4cc24cddaabb50b93493836fe14b4ca237d13a','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ccf0283b91c660cf83e99583c1041a27838b8ba9202b7572f336af5da471bfd1',2025,'SV','El Salvador','environment',29,'Environment - current issues:
deforestation; soil erosion; water pollution; contamination of soils from disposal of toxic wastes
Environment - international agreements:
party to:
Biodiversity, Climate Change, Climate Change-Kyoto Protocol, Climate Change-Paris Agreement, Comprehensive Nuclear Test Ban, Desertification, Endangered Species, Hazardous Wastes, Nuclear Test Ban, Ozone Layer Protection, Ship Pollution, Wetlands
signed, but not ratified:
Law of the Sea
Climate:
tropical; rainy season (May to October); dry season (November to April); tropical on coast; temperate in uplands
Land use:
agricultural land:
74.7% (2018 est.)
arable land:
33.1% (2018 est.)
permanent crops:
10.9% (2018 est.)
permanent pasture:
30.7% (2018 est.)
forest:
13.6% (2018 est.)
other:
11.7% (2018 est.)
Urbanization:
urban population:
75.4% of total population (2023)
rate of urbanization:
1.33% annual rate of change (2020-25 est.)
Revenue from forest resources:
0.6% of GDP (2018 est.)
comparison ranking:
62
Revenue from coal:
0% of GDP (2018 est.)
comparison ranking:
158
Air pollutants:
particulate matter emissions:
22.15 micrograms per cubic meter (2019 est.)
carbon dioxide emissions:
7.17 megatons (2016 est.)
methane emissions:
4.71 megatons (2020 est.)
Waste and recycling:
municipal solid waste generated annually:
1,648,996 tons (2010 est.)
Total water withdrawal:
municipal:
470 million cubic meters (2020 est.)
industrial:
210 million cubic meters (2020 est.)
agricultural:
1.43 billion cubic meters (2020 est.)
Total renewable water resources:
26.27 billion cubic meters (2020 est.)','3499ae9aec8c3fadf99d3a1fd1992af7281e754eda68882f13f4b78ffbd00941','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('19bb88e16f1936469fb7fd5d8a4daa2ca6275f970b0760c71cd851cfad3c6168',2025,'GQ','Equatorial Guinea','environment',41,'Environment - current issues:
deforestation (forests are threatened by agricultural expansion, fires, and grazing); desertification; water pollution (tap water is non-potable); wildlife preservation
Environment - international agreements:
party to:
Biodiversity, Climate Change, Climate Change-Kyoto Protocol, Climate Change-Paris Agreement, Desertification, Endangered Species, Hazardous Wastes, Law of the Sea, Marine Dumping-London Convention, Nuclear Test Ban, Ozone Layer Protection, Ship Pollution, Wetlands
signed, but not ratified:
Comprehensive Nuclear Test Ban
Climate:
tropical; always hot, humid
Land use:
agricultural land:
10.1% (2018 est.)
arable land:
4.3% (2018 est.)
permanent crops:
2.1% (2018 est.)
permanent pasture:
3.7% (2018 est.)
forest:
57.5% (2018 est.)
other:
32.4% (2018 est.)
Urbanization:
urban population:
74.4% of total population (2023)
rate of urbanization:
3.62% annual rate of change (2020-25 est.)
Revenue from forest resources:
1.52% of GDP (2018 est.)
comparison ranking:
42
Revenue from coal:
0% of GDP (2018 est.)
comparison ranking:
135
Air pollutants:
particulate matter emissions:
25.67 micrograms per cubic meter (2019 est.)
carbon dioxide emissions:
5.65 megatons (2016 est.)
methane emissions:
11.21 megatons (2020 est.)
Waste and recycling:
municipal solid waste generated annually:
198,443 tons (2016 est.)
Total water withdrawal:
municipal:
20 million cubic meters (2020 est.)
industrial:
3 million cubic meters (2017 est.)
agricultural:
1 million cubic meters (2017 est.)
Total renewable water resources:
26 billion cubic meters (2020 est.)','0df5bec1512bb6cda9da60a4d2cdabf1b3fba683668d19be4544910ee78bc25d','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f44304638e260591af819aa0372be4bfdaf0b33427a6955146bd2683f7b24d55',2025,'ER','Eritrea','environment',52,'Environment - current issues:
deforestation; desertification; soil erosion; overgrazing
Environment - international agreements:
party to:
Biodiversity, Climate Change, Climate Change-Kyoto Protocol, Comprehensive Nuclear Test Ban, Desertification, Endangered Species, Hazardous Wastes, Ozone Layer Protection, Whaling
signed, but not ratified:
Climate Change-Paris Agreement
Climate:
hot, dry desert strip along Red Sea coast; cooler and wetter in the central highlands (up to 61 cm of rainfall annually, heaviest June to September); semiarid in western hills and lowlands
Land use:
agricultural land:
75.1% (2018 est.)
arable land:
6.8% (2018 est.)
permanent crops:
0% (2018 est.)
permanent pasture:
68.3% (2018 est.)
forest:
15.1% (2018 est.)
other:
9.8% (2018 est.)
Urbanization:
urban population:
43.3% of total population (2023)
rate of urbanization:
3.67% annual rate of change (2020-25 est.)
Air pollutants:
particulate matter emissions:
22.74 micrograms per cubic meter (2019 est.)
carbon dioxide emissions:
0.71 megatons (2016 est.)
methane emissions:
4.48 megatons (2020 est.)
Waste and recycling:
municipal solid waste generated annually:
726,957 tons (2011 est.)
Total water withdrawal:
municipal:
30 million cubic meters (2020 est.)
industrial:
1 million cubic meters (2017 est.)
agricultural:
550 million cubic meters (2020 est.)
Total renewable water resources:
7.32 billion cubic meters (2020 est.)','e855e54c7268788c3a08cf3a4f5b640a76626641407fa1851dfe2798a5893162','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b9a9ce1b1ed5332882507e7253b28bb35464b6c71a8427352c485821c31ff2a1',2025,'EE','Estonia','environment',4,'Environment - current issues:
air polluted with sulfur dioxide from oil-shale burning power plants in northeast; however, the amounts of pollutants emitted into the air have fallen dramatically and the pollution load of wastewater at purification plants has decreased substantially due to improved technology and environmental monitoring; Estonia has more than 1,400 natural and manmade lakes, the smaller of which in agricultural areas need to be monitored; coastal seawater is polluted in certain locations
Environment - international agreements:
party to:
Air Pollution, Air Pollution-Heavy Metals, Air Pollution-Nitrogen Oxides, Air Pollution-Persistent Organic Pollutants, Air Pollution-Sulphur 85, Air Pollution-Volatile Organic Compounds, Antarctic Treaty, Biodiversity, Climate Change, Climate Change-Kyoto Protocol, Climate Change-Paris Agreement, Comprehensive Nuclear Test Ban, Desertification, Endangered Species, Environmental Modification, Hazardous Wastes, Law of the Sea, Marine Dumping-London Protocol, Ozone Layer Protection, Ship Pollution, Tropical Timber 2006, Wetlands, Whaling
signed, but not ratified:
none of the selected agreements
Climate:
maritime; wet, moderate winters, cool summers
Land use:
agricultural land:
22.2% (2018 est.)
arable land:
14.9% (2018 est.)
permanent crops:
0.1% (2018 est.)
permanent pasture:
7.2% (2018 est.)
forest:
52.1% (2018 est.)
other:
25.7% (2018 est.)
Urbanization:
urban population:
69.8% of total population (2023)
rate of urbanization:
-0.03% annual rate of change (2020-25 est.)
Revenue from forest resources:
0.85% of GDP (2018 est.)
comparison ranking:
56
Revenue from coal:
0% of GDP (2018 est.)
comparison ranking:
156
Air pollutants:
particulate matter emissions:
6.35 micrograms per cubic meter (2019 est.)
carbon dioxide emissions:
16.59 megatons (2016 est.)
methane emissions:
0.99 megatons (2020 est.)
Waste and recycling:
municipal solid waste generated annually:
473,000 tons (2015 est.)
municipal solid waste recycled annually:
117,020 tons (2015 est.)
percent of municipal solid waste recycled:
24.7% (2015 est.)
Major lakes (area sq km):
fresh water lake(s):
Lake Peipus - 4,300 sq km (shared with Russia); Lake Võrtsjärv - 270 sq km
Total water withdrawal:
municipal:
60 million cubic meters (2020 est.)
industrial:
790 million cubic meters (2020 est.)
agricultural:
4.5 million cubic meters (2017 est.)
Total renewable water resources:
12.81 billion cubic meters (2020 est.)','5ca3e80ffb934b4280e8d55faf3079de2dc8810b438dcf1dbf833799441f4e5c','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d5c7a170cf78053c53ff69d918ba8b8991ca385bd492649339a71dc22dd23982',2025,'SZ','Eswatini','environment',15,'Environment - current issues:
limited supplies of potable water; wildlife populations being depleted because of excessive hunting; population growth, deforestation, and overgrazing lead to soil erosion and soil degradation
Environment - international agreements:
party to:
Biodiversity, Climate Change, Climate Change-Kyoto Protocol, Climate Change-Paris Agreement, Comprehensive Nuclear Test Ban, Desertification, Endangered Species, Hazardous Wastes, Law of the Sea, Nuclear Test Ban, Ozone Layer Protection, Wetlands
signed, but not ratified:
none of the selected agreements
Climate:
varies from tropical to near temperate
Land use:
agricultural land:
68.3% (2018 est.)
arable land:
9.8% (2018 est.)
permanent crops:
0.8% (2018 est.)
permanent pasture:
57.7% (2018 est.)
forest:
31.7% (2018 est.)
other:
0% (2018 est.)
Urbanization:
urban population:
24.8% of total population (2023)
rate of urbanization:
2.42% annual rate of change (2020-25 est.)
Food insecurity:
severe localized food insecurity:
due to higher staple food prices - the price of maize meal, the key food staple, increased in the first five months of 2022 and, as of May 2022, were 3 percent higher on a yearly basis; wheat flour prices were also at record highs in May 2022; this mainly reflects the elevated global prices and the country’s high dependence on imported wheat to satisfy national consumption needs (2022)
Revenue from forest resources:
2.25% of GDP (2018 est.)
comparison ranking:
30
Revenue from coal:
0.1% of GDP (2018 est.)
comparison ranking:
26
Air pollutants:
particulate matter emissions:
15.07 micrograms per cubic meter (2019 est.)
carbon dioxide emissions:
1.16 megatons (2016 est.)
methane emissions:
1.9 megatons (2020 est.)
Waste and recycling:
municipal solid waste generated annually:
218,199 tons (2016 est.)
Total water withdrawal:
municipal:
40 million cubic meters (2020 est.)
industrial:
20 million cubic meters (2020 est.)
agricultural:
1.01 billion cubic meters (2020 est.)
Total renewable water resources:
4.51 billion cubic meters (2020 est.)','6a46113cb4ac5623ae574bcb2cc1fb13f60ce0acc6af871d3a54feded76c46af','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('be18a0d90980bf73d59aefab31c8e0b00626686e90910edf00c4dd739de0ba3e',2025,'ET','Ethiopia','environment',26,'Environment - current issues:
deforestation; overgrazing; soil erosion; desertification; loss of biodiversity; water shortages in some areas from water-intensive farming and poor management; industrial pollution and pesticides contribute to air, water, and soil pollution
Environment - international agreements:
party to:
Biodiversity, Climate Change, Climate Change-Kyoto Protocol, Climate Change-Paris Agreement, Comprehensive Nuclear Test Ban, Desertification, Endangered Species, Hazardous Wastes, Ozone Layer Protection
signed, but not ratified:
Environmental Modification, Law of the Sea, Nuclear Test Ban
Climate:
tropical monsoon with wide topographic-induced variation
Land use:
agricultural land:
36.3% (2018 est.)
arable land:
15.2% (2018 est.)
permanent crops:
1.1% (2018 est.)
permanent pasture:
20% (2018 est.)
forest:
12.2% (2018 est.)
other:
51.5% (2018 est.)
Urbanization:
urban population:
23.2% of total population (2023)
rate of urbanization:
4.4% annual rate of change (2020-25 est.)
Food insecurity:
widespread lack of access:
due to conflict in Tigray Region, drought conditions in southeastern areas, high food prices
- The difficult and worsening food security situation is the result of multiple shocks affecting food availability and access including: the conflict in northern Tigray Region and in adjacent areas of Amhara and Afar regions, which began in November 2020; in Tigray region alone, 5.3 million people are estimated to be severely food insecure; the failure of the March-May 2022 “Gu-Genna” rains in southern pastoral areas of southern Oromiya Region and southern Somali Region, exacerbated drought conditions prevailing since late 2020, causing severe crop and livestock losses; severe macroeconomic challenges including insufficient foreign currency reserves and the continuous depreciation of the national currency, as a result, inflation is at very high levels, with the year-on-year food inflation rate estimated at 35.5 percent in July, one the highest of the last decade; these difficulties are exacerbated by the ripple effects of the Ukraine war, which triggered hikes in international prices of wheat, fuel, and fertilizers (2023)
Revenue from forest resources:
5.81% of GDP (2018 est.)
comparison ranking:
11
Revenue from coal:
0% of GDP (2018 est.)
comparison ranking:
118
Air pollutants:
particulate matter emissions:
21.8 micrograms per cubic meter (2019 est.)
carbon dioxide emissions:
14.87 megatons (2016 est.)
methane emissions:
114.21 megatons (2020 est.)
Waste and recycling:
municipal solid waste generated annually:
6,532,787 tons (2015 est.)
Major lakes (area sq km):
fresh water lake(s):
Lake Tana - 3,600 sq km; Abaya Hayk - 1,160 sq km; Ch’amo Hayk - 550 sq km
salt water lake(s):
Lake Turkana (shared with Kenya) - 6,400 sq km; Abhe Bid Hayk/Abhe Bad (shared with Djibouti) - 780 sq km;
Major rivers (by length in km):
Blue Nile river source (shared with Sudan [m]) - 1,600 km
note
– [s] after country name indicates river source; [m] after country name indicates river mouth
Major watersheds (area sq km): Atlantic Ocean drainage:
(Mediterranean Sea)
Nile (3,254,853 sq km)
Major aquifers:
Ogaden-Juba Basin, Sudd Basin (Umm Ruwaba Aquifer)
Total water withdrawal:
municipal:
810 million cubic meters (2020 est.)
industrial:
50 million cubic meters (2020 est.)
agricultural:
9.69 billion cubic meters (2020 est.)
Total renewable water resources:
122 billion cubic meters (2020 est.)','8a56af096ded9b715530110cc35e3f436a7355d8eceffa6230f1f6dea0907cf0','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f1eb081b21c7da2b18ae94ac681abaf0ccac1a0d0c920d9e80e665359ba759b0',2025,'ET','Ethiopia','environment',39,'Environment - current issues:
various forms of air, soil, and water pollution; see individual country entries
Environment - international agreements:
party to:
Air Pollution, Air Pollution-Heavy Metals, Air Pollution-Multi-effect Protocol, Air Pollution-Nitrogen Oxides, Air Pollution-Persistent Organic Pollutants, Air Pollution-Sulphur 94, Antarctic-Marine Living Resources, Biodiversity, Climate Change, Climate Change-Kyoto Protocol, Climate Change-Paris Agreement, Desertification, Endangered Species, Hazardous Wastes, Law of the Sea, Ozone Layer Protection, Tropical Timber 2006
signed, but not ratified:
Air Pollution-Volatile Organic Compounds
Climate:
cold temperate; potentially subarctic in the north to temperate; mild wet winters; hot dry summers in the south
Revenue from forest resources:
0.05% of GDP (2018 est.)
Revenue from coal:
0.02% of GDP (2018 est.)
Air pollutants:
carbon dioxide emissions:
2,881.62 megatons (2016 est.)
Total renewable water resources:
1.7 trillion cubic meters (2019)','d1a58d9700744ea48a24c57cb67cf107996d0a53ca72541454b95ae1e6d590b9','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0ba73c7eb57d333e4ebb39fd3c413fd0b43e4d469cbe355e62d8f64644aad81d',2025,'FO','Faroe Islands','environment',5,'Environment - current issues:
coastal erosion, landslides and rockfalls, flash flooding, wind storms; oil spills
Climate:
mild winters, cool summers; usually overcast; foggy, windy
Land use:
agricultural land:
2.1% (2018 est.)
arable land:
2.1% (2018 est.)
permanent crops:
0% (2018 est.)
permanent pasture:
0% (2018 est.)
forest:
0.1% (2018 est.)
other:
97.8% (2018 est.)
Urbanization:
urban population:
43% of total population (2023)
rate of urbanization:
0.89% annual rate of change (2020-25 est.)
Revenue from forest resources:
0% of GDP (2017 est.)
comparison ranking:
201
Air pollutants:
carbon dioxide emissions:
0.63 megatons (2016 est.)
Waste and recycling:
municipal solid waste generated annually:
61,000 tons (2014 est.)
municipal solid waste recycled annually:
40,870 tons (2012 est.)
percent of municipal solid waste recycled:
67% (2012 est.)
Total renewable water resources:
0 cubic meters (2017 est.)','be797c54f0537be6fee7cf060f9f4d9a6834c7fb8cba8bc67107940e8d4a42d6','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c330ec87121797a2f9aa6a7cc71c095f05dc37e18706802c251008dab867c03a',2025,'FJ','Fiji','environment',16,'Environment - current issues:
the widespread practice of waste incineration is a major contributor to air pollution in the country, as are vehicle emissions in urban areas; deforestation and soil erosion are significant problems; a contributory factor to erosion is clearing of land by bush burning, a widespread practice that threatens biodiversity
Environment - international agreements:
party to:
Biodiversity, Climate Change, Climate Change-Kyoto Protocol, Climate Change-Paris Agreement, Comprehensive Nuclear Test Ban, Desertification, Endangered Species, Law of the Sea, Marine Life Conservation, Nuclear Test Ban, Ozone Layer Protection, Ship Pollution, Tropical Timber 2006, Wetlands
signed, but not ratified:
none of the selected agreements
Climate:
tropical marine; only slight seasonal temperature variation
Land use:
agricultural land:
23.3% (2018 est.)
arable land:
9% (2018 est.)
permanent crops:
4.7% (2018 est.)
permanent pasture:
9.6% (2018 est.)
forest:
55.7% (2018 est.)
other:
21% (2018 est.)
Urbanization:
urban population:
58.7% of total population (2023)
rate of urbanization:
1.37% annual rate of change (2020-25 est.)
Revenue from forest resources:
0.59% of GDP (2018 est.)
comparison ranking:
63
Revenue from coal:
0% of GDP (2018 est.)
comparison ranking:
185
Air pollutants:
particulate matter emissions:
7.36 micrograms per cubic meter (2019 est.)
carbon dioxide emissions:
2.05 megatons (2016 est.)
methane emissions:
0.95 megatons (2020 est.)
Waste and recycling:
municipal solid waste generated annually:
189,390 tons (2011 est.)
municipal solid waste recycled annually:
10,322 tons (2013 est.)
percent of municipal solid waste recycled:
5.5% (2013 est.)
Total water withdrawal:
municipal:
30 million cubic meters (2020 est.)
industrial:
10 million cubic meters (2020 est.)
agricultural:
50 million cubic meters (2020 est.)
Total renewable water resources:
28.55 billion cubic meters (2020 est.)','cb457e3e032ee32034e151fbe3618a055f58452d9d3b0b24ba2c1a679f0bd638','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bc052bcad9106b6b4570104bf0c97d8621aa47f139a2b98024c5e7e25b1317db',2025,'FI','Finland','environment',27,'Environment - current issues:
limited air pollution in urban centers; some water pollution from industrial wastes, agricultural chemicals; habitat loss threatens wildlife populations
Environment - international agreements:
party to:
Air Pollution, Air Pollution-Heavy Metals, Air Pollution-Multi-effect Protocol, Air Pollution-Nitrogen Oxides, Air Pollution-Persistent Organic Pollutants, Air Pollution-Sulphur 85, Air Pollution-Sulphur 94, Air Pollution-Volatile Organic Compounds, Antarctic-Environmental Protection, Antarctic-Marine Living Resources, Antarctic Treaty, Biodiversity, Climate Change, Climate Change-Kyoto Protocol, Climate Change-Paris Agreement, Comprehensive Nuclear Test Ban, Desertification, Endangered Species, Environmental Modification, Hazardous Wastes, Law of the Sea, Marine Dumping-London Convention, Marine Dumping-London Protocol, Marine Life Conservation, Nuclear Test Ban, Ozone Layer Protection, Ship Pollution, Tropical Timber 2006, Wetlands, Whaling
signed, but not ratified:
none of the selected agreements
Climate:
cold temperate; potentially subarctic but comparatively mild because of moderating influence of the North Atlantic Current, Baltic Sea, and more than 60,000 lakes
Land use:
agricultural land:
7.5% (2018 est.)
arable land:
7.4% (2018 est.)
permanent crops:
0% (2018 est.)
permanent pasture:
0.1% (2018 est.)
forest:
72.9% (2018 est.)
other:
19.6% (2018 est.)
Urbanization:
urban population:
85.8% of total population (2023)
rate of urbanization:
0.42% annual rate of change (2020-25 est.)
Revenue from forest resources:
0.36% of GDP (2018 est.)
comparison ranking:
74
Revenue from coal:
0% of GDP (2018 est.)
comparison ranking:
93
Air pollutants:
particulate matter emissions:
5.47 micrograms per cubic meter (2019 est.)
carbon dioxide emissions:
45.87 megatons (2016 est.)
methane emissions:
4.46 megatons (2020 est.)
Waste and recycling:
municipal solid waste generated annually:
2.738 million tons (2015 est.)
municipal solid waste recycled annually:
769,926 tons (2015 est.)
percent of municipal solid waste recycled:
28.1% (2015 est.)
Major lakes (area sq km):
fresh water lake(s):
Saimaa - 1,760 sq km; Paijanne - 1,090 sq km; Inarijarvi - 1,000 sq km; Oulujarvi - 900 sq km; Pielinen - 850 sq km
Total water withdrawal:
municipal:
1 billion cubic meters (2020 est.)
industrial:
2 billion cubic meters (2020 est.)
agricultural:
500 million cubic meters (2020 est.)
Total renewable water resources:
110 billion cubic meters (2020 est.)','b7dc642738c8017d1dc34a0655abb0107eefe48598f1dc4c760f5a282e99d33e','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('56ce51eb1b4546e0e02582d36a265779f2a7c7e887469687c4d532c2767cf959',2025,'FR','France','environment',38,'Environment - current issues:
some forest damage from acid rain; air pollution from industrial and vehicle emissions; water pollution from urban wastes, agricultural runoff
Environment - international agreements:
party to:
Air Pollution, Air Pollution-Heavy Metals, Air Pollution-Multi-effect Protocol, Air Pollution-Nitrogen Oxides, Air Pollution-Persistent Organic Pollutants, Air Pollution-Sulphur 85, Air Pollution-Sulphur 94, Air Pollution-Volatile Organic Compounds, Antarctic-Environmental Protection, Antarctic-Marine Living Resources, Antarctic Seals, Antarctic Treaty, Biodiversity, Climate Change, Climate Change-Kyoto Protocol, Climate Change-Paris Agreement, Comprehensive Nuclear Test Ban, Desertification, Endangered Species, Hazardous Wastes, Law of the Sea, Marine Dumping-London Convention, Marine Dumping-London Protocol, Marine Life Conservation, Ozone Layer Protection, Ship Pollution, Tropical Timber 2006, Wetlands, Whaling
signed, but not ratified:
none of the selected agreements
Climate:
metropolitan France:
generally cool winters and mild summers, but mild winters and hot summers along the Mediterranean; occasional strong, cold, dry, north-to-northwesterly wind known as the mistral
French Guiana:
tropical; hot, humid; little seasonal temperature variation
Guadeloupe and Martinique:
subtropical tempered by trade winds; moderately high humidity; rainy season (June to October); vulnerable to devastating cyclones (hurricanes) every eight years on average
Mayotte:
tropical; marine; hot, humid, rainy season during northeastern monsoon (November to May); dry season is cooler (May to November)
Reunion:
tropical, but temperature moderates with elevation; cool and dry (May to November), hot and rainy (November to April)
Land use:
agricultural land:
52.7% (2018 est.)
arable land:
33.4% (2018 est.)
permanent crops:
1.8% (2018 est.)
permanent pasture:
17.5% (2018 est.)
forest:
29.2% (2018 est.)
other:
18.1% (2018 est.)
Urbanization:
urban population:
81.8% of total population (2023)
rate of urbanization:
0.67% annual rate of change (2020-25 est.)
Revenue from forest resources:
0.03% of GDP (2018 est.)
comparison ranking:
136
Revenue from coal:
0% of GDP (2018 est.)
comparison ranking:
184
Air pollutants:
particulate matter emissions:
10.46 micrograms per cubic meter (2019 est.)
methane emissions:
55.99 megatons (2020 est.)
Waste and recycling:
municipal solid waste generated annually:
33.399 million tons (2015 est.)
municipal solid waste recycled annually:
7,434,617 tons (2015 est.)
percent of municipal solid waste recycled:
22.3% (2015 est.)
Major lakes (area sq km):
fresh water lake(s):
Lake Geneva (shared with Switzerland) - 580 sq km
Major rivers (by length in km):
Rhin (Rhine) (shared with Switzerland [s], Germany, and Netherlands [m]) - 1,233 km; Loire - 1,012 km
note – [s] after country name indicates river source; [m] after country name indicates river mouth
Major watersheds (area sq km): Atlantic Ocean drainage:
Loire (115,282 sq km), Seine (78,919 sq km), Rhine-Maas (198,735 sq km),
(Adriatic Sea)
Po (76,997 sq km),
(Mediterranean Sea)
Rhone (100,543 sq km)
Major aquifers:
Paris Basin
Total water withdrawal:
municipal:
5.31 billion cubic meters (2020 est.)
industrial:
17.78 billion cubic meters (2020 est.)
agricultural:
3.18 billion cubic meters (2020 est.)
Total renewable water resources:
211 billion cubic meters (2020 est.)','c85cf8a44c19aca2ef8fecf64873c5bdb92dce67bd8a9602932c604235ed3b1a','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1e70cc7a6e2f2fab0e89dcbcd78b6bfd168c5dd7028d879485eb5846e59eb1d4',2025,'PF','French Polynesia','environment',51,'Environment - current issues:
sea level rise; extreme weather events (cyclones, storms, and tsunamis producing floods, landslides, erosion, and reef damage); droughts; fresh water scarcity
Climate:
tropical, but moderate
Land use:
agricultural land:
12.5% (2018 est.)
arable land:
0.7% (2018 est.)
permanent crops:
6.3% (2018 est.)
permanent pasture:
5.5% (2018 est.)
forest:
43.7% (2018 est.)
other:
43.8% (2018 est.)
Urbanization:
urban population:
62.3% of total population (2023)
rate of urbanization:
0.65% annual rate of change (2020-25 est.)
Air pollutants:
carbon dioxide emissions:
0.77 megatons (2016 est.)
Waste and recycling:
municipal solid waste generated annually:
147,000 tons (2013 est.)
municipal solid waste recycled annually:
57,330 tons (2013 est.)
percent of municipal solid waste recycled:
39% (2013 est.)','9972fbc52514283b76ffcc865a9639b19906e9b6cae1dbc57ab7f30701516a03','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bcb6605928c6c2b9862cfcdbcd6b2b0cb8ffa8fdf5f9c09a59373a3a9b8ccefb',2025,'PF','French Polynesia','environment',62,'Environment - current issues:
introduction of foreign species on Iles Crozet has caused severe damage to the original ecosystem; overfishing of Patagonian toothfish around Iles Crozet and Iles Kerguelen
Climate: Ile Amsterdam et Ile Saint-Paul:
oceanic with persistent westerly winds and high humidity;
Iles Crozet:
windy, cold, wet, and cloudy;
Iles Kerguelen:
oceanic, cold, overcast, windy;
Iles Eparses:
tropical','4caeb7c7cfac012631d3658c0b4f2cce53c525e582f1e6068de49649ad3a09a2','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('945bf5d42d7526d471754201f9b41511344c6f003b3af2e64501545860c0fbad',2025,'GA','Gabon','environment',4,'Environment - current issues:
deforestation (the forests that cover three-quarters of the country are threatened by excessive logging); burgeoning population exacerbating disposal of solid waste; oil industry contributing to water pollution; wildlife poaching
Environment - international agreements:
party to:
Biodiversity, Climate Change, Climate Change-Kyoto Protocol, Climate Change-Paris Agreement, Comprehensive Nuclear Test Ban, Desertification, Endangered Species, Hazardous Wastes, Law of the Sea, Marine Dumping-London Convention, Nuclear Test Ban, Ozone Layer Protection, Ship Pollution, Tropical Timber 2006, Wetlands, Whaling
signed, but not ratified:
none of the selected agreements
Climate:
tropical; always hot, humid
Land use:
agricultural land:
19% (2018 est.)
arable land:
1.2% (2018 est.)
permanent crops:
0.6% (2018 est.)
permanent pasture:
17.2% (2018 est.)
forest:
81% (2018 est.)
other:
0% (2018 est.)
Urbanization:
urban population:
91% of total population (2023)
rate of urbanization:
2.27% annual rate of change (2020-25 est.)
Revenue from forest resources:
2.6% of GDP (2018 est.)
comparison ranking:
26
Revenue from coal:
0% of GDP (2018 est.)
comparison ranking:
68
Air pollutants:
particulate matter emissions:
26.29 micrograms per cubic meter (2019 est.)
carbon dioxide emissions:
5.32 megatons (2016 est.)
methane emissions:
1.13 megatons (2020 est.)
Waste and recycling:
municipal solid waste generated annually:
238,102 tons (1995 est.)
Major watersheds (area sq km): Atlantic Ocean drainage:
Congo (3,730,881 sq km)
Major aquifers:
Congo Basin
Total water withdrawal:
municipal:
80 million cubic meters (2020 est.)
industrial:
10 million cubic meters (2020 est.)
agricultural:
40 million cubic meters (2020 est.)
Total renewable water resources:
166 billion cubic meters (2020 est.)','934e91b8efbe16b0494b7cbe9c0d34b4ef13b82baa386b955e6a77c86d4f1e05','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('51188c4ed6a9cfcf0c91c308c5f3def78b0694ce3eeb4e6e8bb561149a46ec0e',2025,'GA','Gabon','environment',16,'Environment - current issues:
deforestation due to slash-and-burn agriculture; desertification; water pollution; water-borne diseases
Environment - international agreements:
party to:
Biodiversity, Climate Change, Climate Change-Kyoto Protocol, Climate Change-Paris Agreement, Desertification, Endangered Species, Hazardous Wastes, Law of the Sea, Nuclear Test Ban, Ozone Layer Protection, Ship Pollution, Wetlands, Whaling
signed, but not ratified:
Comprehensive Nuclear Test Ban
Climate:
tropical; hot, rainy season (June to November); cooler, dry season (November to May)
Land use:
agricultural land:
56.1% (2018 est.)
arable land:
41% (2018 est.)
permanent crops:
0.5% (2018 est.)
permanent pasture:
14.6% (2018 est.)
forest:
43.9% (2018 est.)
other:
0% (2018 est.)
Urbanization:
urban population:
64.5% of total population (2023)
rate of urbanization:
3.75% annual rate of change (2020-25 est.)
Revenue from forest resources:
2.47% of GDP (2018 est.)
comparison ranking:
28
Revenue from coal:
0% of GDP (2018 est.)
comparison ranking:
53
Air pollutants:
particulate matter emissions:
39.1 micrograms per cubic meter (2019 est.)
carbon dioxide emissions:
0.53 megatons (2016 est.)
methane emissions:
1.96 megatons (2020 est.)
Waste and recycling:
municipal solid waste generated annually:
193,441 tons (2002 est.)
Major rivers (by length in km):
Gambia river mouth (shared with Senegal and Guinea [s]) - 1,094 km
note – [s] after country name indicates river source; [m] after country name indicates river mouth
Major aquifers:
Senegalo-Mauritanian Basin
Total water withdrawal:
municipal:
40 million cubic meters (2020 est.)
industrial:
20 million cubic meters (2020 est.)
agricultural:
40 million cubic meters (2020 est.)
Total renewable water resources:
8 billion cubic meters (2020 est.)','1e0fcf5b09d59feba0ef389625833f3ee2a8cfb0c8b79e2aeefa205c690ba04e','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7aaaf780583891297fe790f6113f4cd616a2d697178540901378214fdfbd2014',2025,'GA','Gabon','environment',27,'Environment - current issues:
soil degradation; desertification; water pollution from chemicals and pesticides; salination of fresh water; improper sewage treatment; water-borne disease; depletion and contamination of underground water resources
Climate:
temperate, mild winters, dry and warm to hot summers
Urbanization:
urban population:
77.6% of total population (2023)
rate of urbanization:
2.85% annual rate of change (2020-25 est.)
note:
data represent Gaza Strip and the West Bank
Revenue from forest resources:
0% of GDP (2018 est.)
comparison ranking:
197
Air pollutants:
particulate matter emissions:
30.82 micrograms per cubic meter (2019 est.)
carbon dioxide emissions:
3.23 megatons (2016 est.)
note:
data represent combined total from the Gaza Strip and the West Bank.
Waste and recycling:
municipal solid waste generated annually:
1.387 million tons (2016 est.)
municipal solid waste recycled annually:
6,935 tons (2013 est.)
percent of municipal solid waste recycled:
0.5% (2013 est.)
note:
data represent combined total from the Gaza Strip and the West Bank.
Total water withdrawal:
municipal:
181.2 million cubic meters (2017 est.)
industrial:
32 million cubic meters (2017 est.)
agricultural:
162 million cubic meters (2017 est.)
note:
data represent combined total from the Gaza Strip and the West Bank.
Total renewable water resources:
840 million cubic meters (2020 est.)
note:
data represent combined total from the Gaza Strip and the West Bank.','a8f7f00f5aaee5aaad76165f6d280ff2b175481c3767b25c624fb3b19fd2067b','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b8e4cd2c2454cf0fb5f507770a1d46c2c5ac5e119832bcb32dc92b064af19f39',2025,'GE','Georgia','environment',39,'Environment - current issues:
air pollution, particularly in Rust’avi; heavy water pollution of Mtkvari River and the Black Sea; inadequate supplies of potable water; soil pollution from toxic chemicals; land and forest degradation; biodiversity loss; waste management
Environment - international agreements:
party to:
Air Pollution, Biodiversity, Climate Change, Climate Change-Kyoto Protocol, Climate Change-Paris Agreement, Comprehensive Nuclear Test Ban, Desertification, Endangered Species, Hazardous Wastes, Law of the Sea, Marine Dumping-London Protocol, Ozone Layer Protection, Ship Pollution, Wetlands
signed, but not ratified:
none of the selected agreements
Climate:
warm and pleasant; Mediterranean-like on Black Sea coast
Land use:
agricultural land:
35.5% (2018 est.)
arable land:
5.8% (2018 est.)
permanent crops:
1.8% (2018 est.)
permanent pasture:
27.9% (2018 est.)
forest:
39.4% (2018 est.)
other:
25.1% (2018 est.)
Urbanization:
urban population:
60.7% of total population (2023)
rate of urbanization:
0.35% annual rate of change (2020-25 est.)
note:
data include Abkhazia and South Ossetia
Revenue from forest resources:
0.07% of GDP (2018 est.)
comparison ranking:
122
Revenue from coal:
0.01% of GDP (2018 est.)
comparison ranking:
52
Air pollutants:
particulate matter emissions:
19.06 micrograms per cubic meter (2019 est.)
carbon dioxide emissions:
10.13 megatons (2016 est.)
methane emissions:
6.05 megatons (2020 est.)
Waste and recycling:
municipal solid waste generated annually:
800,000 tons (2015 est.)
Total water withdrawal:
municipal:
610 million cubic meters (2020 est.)
industrial:
340 million cubic meters (2020 est.)
agricultural:
710 million cubic meters (2020 est.)
Total renewable water resources:
63.33 billion cubic meters (2020 est.)','fe31e7e62a1493641bf186920f76f727da49a5ec3fde5d813666d88c96046893','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1865384ff2575ce0fae248c7588866d0b491ffab7e8e475e244c4c1113a28fcb',2025,'DE','Germany','environment',50,'Environment - current issues:
emissions from coal-burning utilities and industries contribute to air pollution; acid rain, resulting from sulfur dioxide emissions, is damaging forests; pollution in the Baltic Sea from raw sewage and industrial effluents from rivers in eastern Germany; hazardous waste disposal; government established a mechanism for ending the use of nuclear power by 2022; government working to meet EU commitment to identify nature preservation areas in line with the EU’s Flora, Fauna, and Habitat directive
Environment - international agreements:
party to:
Air Pollution, Air Pollution-Heavy Metals, Air Pollution-Multi-effect Protocol, Air Pollution-Nitrogen Oxides, Air Pollution-Persistent Organic Pollutants, Air Pollution-Sulphur 85, Air Pollution-Sulphur 94, Air Pollution-Volatile Organic Compounds, Antarctic-Environmental Protection, Antarctic-Marine Living Resources, Antarctic Seals, Antarctic Treaty, Biodiversity, Climate Change, Climate Change-Kyoto Protocol, Climate Change-Paris Agreement, Comprehensive Nuclear Test Ban, Desertification, Endangered Species, Environmental Modification, Hazardous Wastes, Law of the Sea, Marine Dumping-London Convention, Marine Dumping-London Protocol, Nuclear Test Ban, Ozone Layer Protection, Ship Pollution, Tropical Timber 2006, Wetlands, Whaling
signed, but not ratified:
none of the selected agreements
Climate:
temperate and marine; cool, cloudy, wet winters and summers; occasional warm mountain (foehn) wind
Land use:
agricultural land:
48% (2018 est.)
arable land:
34.1% (2018 est.)
permanent crops:
0.6% (2018 est.)
permanent pasture:
13.3% (2018 est.)
forest:
31.8% (2018 est.)
other:
20.2% (2018 est.)
Urbanization:
urban population:
77.8% of total population (2023)
rate of urbanization:
0.13% annual rate of change (2020-25 est.)
Revenue from forest resources:
0.03% of GDP (2018 est.)
comparison ranking:
137
Revenue from coal:
0.02% of GDP (2018 est.)
comparison ranking:
44
Air pollutants:
particulate matter emissions:
10.73 micrograms per cubic meter (2019 est.)
carbon dioxide emissions:
727.97 megatons (2016 est.)
methane emissions:
49.92 megatons (2020 est.)
Waste and recycling:
municipal solid waste generated annually:
51.046 million tons (2015 est.)
municipal solid waste recycled annually:
24,415,302 tons (2015 est.)
percent of municipal solid waste recycled:
47.8% (2015 est.)
Major lakes (area sq km):
fresh water lake(s):
Lake Constance (shared with Switzerland and Austria) - 540 sq km
salt water lake(s):
Stettiner Haff/Zalew Szczecinski (shared with Poland) - 900 sq km
Major rivers (by length in km):
Donau (Danube) river source (shared with Austria, Slovakia, Czechia, Hungary, Croatia, Serbia, Bulgaria, Ukraine, Moldova, and Romania [m]) - 2,888 km; Elbe river mouth (shared with Czechia [s]) - 1,252 km; Rhein (Rhine) (shared with Switzerland [s], France, and Netherlands [m]) - 1,233 km
note – [s] after country name indicates river source; [m] after country name indicates river mouth
Major watersheds (area sq km): Atlantic Ocean drainage:
Rhine-Maas (198,735 sq km), (Black Sea) Danube (795,656 sq km)
Total water withdrawal:
municipal:
10.4 billion cubic meters (2020 est.)
industrial:
17.68 billion cubic meters (2020 est.)
agricultural:
400 million cubic meters (2020 est.)
Total renewable water resources:
154 billion cubic meters (2020 est.)','2690ce56492af0384a6943b47bb8ee3224e0e8223b3ffb5cde1ffa7406a5b0ac','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cb0e7612d8c5839955e850ff6a9b08e0ab20254dc7eb3e8819b8a12cb1c7c27e',2025,'GH','Ghana','environment',63,'Environment - current issues:
recurrent drought in north severely affects agricultural activities; deforestation; overgrazing; soil erosion; poaching and habitat destruction threaten wildlife populations; water pollution; inadequate supplies of potable water
Environment - international agreements:
party to:
Biodiversity, Climate Change, Climate Change-Kyoto Protocol, Climate Change-Paris Agreement, Comprehensive Nuclear Test Ban, Desertification, Endangered Species, Environmental Modification, Hazardous Wastes, Law of the Sea, Marine Dumping-London Protocol, Nuclear Test Ban, Ozone Layer Protection, Ship Pollution, Tropical Timber 2006, Wetlands, Whaling
signed, but not ratified:
Marine Life Conservation
Climate:
tropical; warm and comparatively dry along southeast coast; hot and humid in southwest; hot and dry in north
Land use:
agricultural land:
69.1% (2018 est.)
arable land:
20.7% (2018 est.)
permanent crops:
11.9% (2018 est.)
permanent pasture:
36.5% (2018 est.)
forest:
21.2% (2018 est.)
other:
9.7% (2018 est.)
Urbanization:
urban population:
59.2% of total population (2023)
rate of urbanization:
3.06% annual rate of change (2020-25 est.)
Revenue from forest resources:
3.51% of GDP (2018 est.)
comparison ranking:
21
Revenue from coal:
0% of GDP (2018 est.)
comparison ranking:
139
Air pollutants:
particulate matter emissions:
46.04 micrograms per cubic meter (2019 est.)
carbon dioxide emissions:
16.67 megatons (2016 est.)
methane emissions:
22.75 megatons (2020 est.)
Waste and recycling:
municipal solid waste generated annually:
3,538,275 tons (2005 est.)
Major rivers (by length in km):
Volta river mouth (shared with Burkina Faso [s]) - 1,600 km
note – [s] after country name indicates river source; [m] after country name indicates river mouth
Major watersheds (area sq km): Atlantic Ocean drainage:
Volta (410,991 sq km)
Total water withdrawal:
municipal:
300 million cubic meters (2020 est.)
industrial:
100 million cubic meters (2020 est.)
agricultural:
1.07 billion cubic meters (2020 est.)
Total renewable water resources:
56.2 billion cubic meters (2020 est.)','8c3eaea0a5ad8e8e75c688c470b9e860328d73df94f6cbf8ed1cb13ec4303fd7','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('50928658dee50c3284db5082a7a97bf9f37a50044272fb6f2430183d60d34c7a',2025,'GI','Gibraltar','environment',4,'Environment - current issues:
limited natural freshwater resources:
more than 90% of drinking water supplied by desalination, the remainder from stored rainwater; a separate supply of saltwater used for sanitary services
Climate:
Mediterranean with mild winters and warm summers
Land use:
agricultural land:
0% (2011 est.)
other:
100% (2018 est.)
Urbanization:
urban population: 100% of total population (2023)
rate of urbanization:
0.45% annual rate of change (2015-20 est.)
Air pollutants:
carbon dioxide emissions:
0.63 megatons (2016 est.)
Waste and recycling:
municipal solid waste generated annually:
16,954 tons (2012 est.)','ba0d2231650a80f039d6ff2f1fdd47cb37edf0e3c439740b29fbdee222947476','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8e05bede567c38afe0d3d49894cdc4f96dcff04be4f394b844a5eb52531eaa55',2025,'GR','Greece','environment',15,'Environment - current issues:
air pollution; air emissions from transport and electricity power stations; water pollution; degradation of coastal zones; loss of biodiversity in terrestrial and marine ecosystems; increasing municipal and industrial waste
Environment - international agreements:
party to:
Air Pollution, Air Pollution-Nitrogen Oxides, Air Pollution-Sulphur 94, Antarctic-Environmental Protection, Antarctic-Marine Living Resources, Antarctic Treaty, Biodiversity, Climate Change, Climate Change-Kyoto Protocol, Climate Change-Paris Agreement, Comprehensive Nuclear Test Ban, Desertification, Endangered Species, Environmental Modification, Hazardous Wastes, Law of the Sea, Marine Dumping-London Convention, Nuclear Test Ban, Ozone Layer Protection, Ship Pollution, Tropical Timber 2006, Wetlands
signed, but not ratified:
Air Pollution-Heavy Metals, Air Pollution-Multi-effect Protocol, Air Pollution-Persistent Organic Pollutants, Air Pollution-Volatile Organic Compounds
Climate:
temperate; mild, wet winters; hot, dry summers
Land use:
agricultural land:
63.4% (2018 est.)
arable land:
19.7% (2018 est.)
permanent crops:
8.9% (2018 est.)
permanent pasture:
34.8% (2018 est.)
forest:
30.5% (2018 est.)
other:
6.1% (2018 est.)
Urbanization:
urban population:
80.7% of total population (2023)
rate of urbanization:
0.11% annual rate of change (2020-25 est.)
Revenue from forest resources:
0.01% of GDP (2018 est.)
comparison ranking:
149
Revenue from coal:
0.04% of GDP (2018 est.)
comparison ranking:
32
Air pollutants:
particulate matter emissions:
14.62 micrograms per cubic meter (2019 est.)
carbon dioxide emissions:
62.43 megatons (2016 est.)
methane emissions:
9.8 megatons (2020 est.)
Waste and recycling:
municipal solid waste generated annually:
5,477,424 tons (2014 est.)
municipal solid waste recycled annually:
1,040,711 tons (2014 est.)
percent of municipal solid waste recycled:
19% (2014 est.)
Total water withdrawal:
municipal:
1.69 billion cubic meters (2020 est.)
industrial:
330 million cubic meters (2020 est.)
agricultural:
8.11 billion cubic meters (2020 est.)
Total renewable water resources:
68.4 billion cubic meters (2020 est.)','a64341d0ac1ca75bfed44d4437f22c850110e7532ce36b6da0bab8ddf09b0b3c','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('183f951799e58188ff518aabbcc70db9ae39003b9dd434bdfb101dc935d76872',2025,'GL','Greenland','environment',28,'Environment - current issues:
especially vulnerable to climate change and disruption of the Arctic environment; preservation of the Inuit traditional way of life, including whaling and seal hunting
Climate:
arctic to subarctic; cool summers, cold winters
Land use:
agricultural land:
0.6% (2018 est.)
arable land:
0% (2018 est.)
permanent crops:
0% (2018 est.)
permanent pasture:
0.6% (2018 est.)
forest:
0% (2018 est.)
other:
99.4% (2018 est.)
Urbanization:
urban population:
87.9% of total population (2023)
rate of urbanization:
0.41% annual rate of change (2020-25 est.)
Revenue from forest resources:
0% of GDP (2018 est.)
comparison ranking:
198
Revenue from coal:
0% of GDP (2018 est.)
comparison ranking:
89
Air pollutants:
carbon dioxide emissions:
0.51 megatons (2016 est.)
Waste and recycling:
municipal solid waste generated annually:
50,000 tons (2010 est.)','0da74b383e78d38f4bc249a7c153670b4fe6ead2052eb7f1ea7f83d591849144','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('160cbdc4727917e0e5f3face4f16a9d0759255e03f92b154ff0849888442bdaa',2025,'GD','Grenada','environment',39,'Environment - current issues:
deforestation causing habitat destruction and species loss; coastal erosion and contamination; pollution and sedimentation; inadequate solid waste management
Environment - international agreements:
party to:
Biodiversity, Climate Change, Climate Change-Kyoto Protocol, Climate Change-Paris Agreement, Comprehensive Nuclear Test Ban, Desertification, Endangered Species, Law of the Sea, Ozone Layer Protection, Ship Pollution, Wetlands, Whaling
signed, but not ratified:
none of the selected agreements
Climate:
tropical; tempered by northeast trade winds
Land use:
agricultural land:
32.3% (2018 est.)
arable land:
8.8% (2018 est.)
permanent crops:
20.6% (2018 est.)
permanent pasture:
2.9% (2018 est.)
forest:
50% (2018 est.)
other:
17.7% (2018 est.)
Urbanization:
urban population:
37.1% of total population (2023)
rate of urbanization:
0.86% annual rate of change (2020-25 est.)
Revenue from forest resources:
0% of GDP (2018 est.)
comparison ranking:
161
Revenue from coal:
0% of GDP (2018 est.)
comparison ranking:
74
Air pollutants:
particulate matter emissions:
10.08 micrograms per cubic meter (2019 est.)
carbon dioxide emissions:
0.27 megatons (2016 est.)
methane emissions:
2.04 megatons (2020 est.)
Waste and recycling:
municipal solid waste generated annually:
29,536 tons (2012 est.)
Total water withdrawal:
municipal:
10 million cubic meters (2020 est.)
industrial:
0 cubic meters (2017 est.)
agricultural:
2.1 million cubic meters (2017 est.)
Total renewable water resources:
200 million cubic meters (2020 est.)','2baa873437fc7731b6c3d6a8b0344868bddcb87a9d7bc826368a16393667730d','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('aae419807499f5be13dea08231f1cbec2e3b9bf05fa4dbe23ef9d9d2c82a27f1',2025,'GU','Guam','environment',50,'Environment - current issues:
fresh water scarcity; reef damage; inadequate sewage treatment; extermination of native bird populations by the rapid proliferation of the brown tree snake, an exotic, invasive species
Climate:
tropical marine; generally warm and humid, moderated by northeast trade winds; dry season (January to June), rainy season (July to December); little seasonal temperature variation
Land use:
agricultural land:
33.4% (2018 est.)
arable land:
1.9% (2018 est.)
permanent crops:
16.7% (2018 est.)
permanent pasture:
14.8% (2018 est.)
forest:
47.9% (2018 est.)
other:
18.7% (2018 est.)
Urbanization:
urban population:
95.2% of total population (2022)
rate of urbanization:
0.84% annual rate of change (2020-25 est.)
Revenue from forest resources:
0% of GDP (2018 est.)
comparison ranking:
200
Revenue from coal:
0% of GDP (2018 est.)
comparison ranking:
102
Waste and recycling:
municipal solid waste generated annually:
141,500 tons (2012 est.)
municipal solid waste recycled annually:
25,258 tons (2011 est.)
percent of municipal solid waste recycled:
17.9% (2011 est.)','d18258fe8caf0de6297ec2a3fa1bb0632b2c59d5cec04d3580ad030287c12326','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6010a74f63e505f217f29bdf1b0b74a6a1a4ca521d5df4f78a28ab13a8c51a63',2025,'GT','Guatemala','environment',61,'Environment - current issues:
deforestation in the Peten rainforest; soil erosion; water pollution
Environment - international agreements:
party to:
Antarctic Treaty, Biodiversity, Climate Change, Climate Change-Kyoto Protocol, Climate Change-Paris Agreement, Comprehensive Nuclear Test Ban, Desertification, Endangered Species, Environmental Modification, Hazardous Wastes, Law of the Sea, Marine Dumping-London Convention, Marine Dumping-London Protocol, Nuclear Test Ban, Ozone Layer Protection, Ship Pollution, Tropical Timber 2006, Wetlands
signed, but not ratified:
none of the selected agreements
Climate:
tropical; hot, humid in lowlands; cooler in highlands
Land use:
agricultural land:
41.2% (2018 est.)
arable land:
14.2% (2018 est.)
permanent crops:
8.8% (2018 est.)
permanent pasture:
18.2% (2018 est.)
forest:
33.6% (2018 est.)
other:
25.2% (2018 est.)
Urbanization:
urban population:
53.1% of total population (2023)
rate of urbanization:
2.59% annual rate of change (2020-25 est.)
Revenue from forest resources:
0.78% of GDP (2018 est.)
comparison ranking:
59
Revenue from coal:
0% of GDP (2018 est.)
comparison ranking:
91
Air pollutants:
particulate matter emissions:
20.75 micrograms per cubic meter (2019 est.)
carbon dioxide emissions:
16.78 megatons (2016 est.)
methane emissions:
10.7 megatons (2020 est.)
Waste and recycling:
municipal solid waste generated annually:
2,756,741 tons (2015 est.)
Major lakes (area sq km):
fresh water lake(s):
Lago de Izabal - 590 sq km
Total water withdrawal:
municipal:
840 million cubic meters (2020 est.)
industrial:
600 million cubic meters (2020 est.)
agricultural:
1.89 billion cubic meters (2020 est.)
Total renewable water resources:
127.91 billion cubic meters (2020 est.)','f723f7c97dd03bb86cfb9928e83d7139af7d842ce4fbc64563b11d0af47bca33','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('14d4e76f723239600a30b11a229ab6d76d9b5a0386acec4f7c4a1f87a97faf93',2025,'GG','Guernsey','environment',4,'Environment - current issues:
coastal erosion, coastal flooding; declining biodiversity due to land abandonment and succession to scrub or woodland
Climate:
temperate with mild winters and cool summers; about 50% of days are overcast
Urbanization:
urban population:
31.2% of total population (2023)
rate of urbanization:
0.68% annual rate of change (2020-25 est.)
note:
data include Guernsey and Jersey
Waste and recycling:
municipal solid waste generated annually:
178,933 tons (2016 est.)
municipal solid waste recycled annually:
50,871 tons (2016 est.)
percent of municipal solid waste recycled:
28.4% (2016 est.)
note:
data include combined totals for Guernsey and Jersey.','88a6b86ebac1ad10631589400f3bd19331b911ea7a15555a14d636a631829dd4','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('aae4c6db1f6ffb0cfc1cac30d76f14691ad3896225f550af39c9c20fe145ec61',2025,'GN','Guinea','environment',15,'Environment - current issues:
deforestation; inadequate potable water; desertification; soil contamination and erosion; overfishing, overpopulation in forest region; poor mining practices lead to environmental damage; water pollution; improper waste disposal
Environment - international agreements:
party to:
Biodiversity, Climate Change, Climate Change-Kyoto Protocol, Climate Change-Paris Agreement, Comprehensive Nuclear Test Ban, Desertification, Endangered Species, Hazardous Wastes, Law of the Sea, Ozone Layer Protection, Ship Pollution, Wetlands, Whaling
signed, but not ratified:
none of the selected agreements
Climate:
generally hot and humid; monsoonal-type rainy season (June to November) with southwesterly winds; dry season (December to May) with northeasterly harmattan winds
Land use:
agricultural land:
58.1% (2018 est.)
arable land:
11.8% (2018 est.)
permanent crops:
2.8% (2018 est.)
permanent pasture:
43.5% (2018 est.)
forest:
26.5% (2018 est.)
other:
15.4% (2018 est.)
Urbanization:
urban population:
38.1% of total population (2023)
rate of urbanization:
3.64% annual rate of change (2020-25 est.)
Food insecurity:
severe localized food insecurity:
due to reduced incomes - about 1.22 million people are projected to be in need of food assistance between June and August 2022, primarily due to food access constraints on account of the economic effects of the COVID-19 pandemic (2022)
Revenue from forest resources:
4.81% of GDP (2018 est.)
comparison ranking:
12
Revenue from coal:
0% of GDP (2018 est.)
comparison ranking:
114
Air pollutants:
particulate matter emissions:
37.57 micrograms per cubic meter (2019 est.)
carbon dioxide emissions:
3 megatons (2016 est.)
methane emissions:
11.13 megatons (2020 est.)
Waste and recycling:
municipal solid waste generated annually:
596,911 tons (1996 est.)
municipal solid waste recycled annually:
29,846 tons (2005 est.)
percent of municipal solid waste recycled:
5% (2005 est.)
Major rivers (by length in km):
Niger river source (shared with Mali, and Nigeria [m]) - 4,200 km; Gambie (Gambia) river source (shared with Senegal and The Gambia [m]) - 1,094 km
note – [s] after country name indicates river source; [m] after country name indicates river mouth
Major watersheds (area sq km): Atlantic Ocean drainage:
Niger (2,261,741 sq km), Senegal (456,397 sq km)
Total water withdrawal:
municipal:
230 million cubic meters (2020 est.)
industrial:
60 million cubic meters (2020 est.)
agricultural:
600 million cubic meters (2020 est.)
Total renewable water resources:
226 billion cubic meters (2020 est.)','999654e089e63d6a1a66b00c1598a976ebd180a63504d0b0b274122f6a7477e3','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('286833ab47a22aad54543f0ed7dbeae35211c09d7c80d5a5b6c3e4f12dc0071f',2025,'GW','Guinea-Bissau','environment',26,'Environment - current issues:
deforestation (rampant felling of trees for timber and agricultural purposes); soil erosion; overgrazing; overfishing
Environment - international agreements:
party to:
Biodiversity, Climate Change, Climate Change-Kyoto Protocol, Climate Change-Paris Agreement, Comprehensive Nuclear Test Ban, Desertification, Endangered Species, Hazardous Wastes, Law of the Sea, Nuclear Test Ban, Ozone Layer Protection, Ship Pollution, Wetlands, Whaling
signed, but not ratified:
none of the selected agreements
Climate:
tropical; generally hot and humid; monsoonal-type rainy season (June to November) with southwesterly winds; dry season (December to May) with northeasterly harmattan winds
Land use:
agricultural land:
44.8% (2018 est.)
arable land:
8.2% (2018 est.)
permanent crops:
6.9% (2018 est.)
permanent pasture:
29.7% (2018 est.)
forest:
55.2% (2018 est.)
other:
0% (2018 est.)
Urbanization:
urban population:
45.5% of total population (2023)
rate of urbanization:
3.22% annual rate of change (2020-25 est.)
Revenue from forest resources:
9.24% of GDP (2018 est.)
comparison ranking:
4
Revenue from coal:
0% of GDP (2018 est.)
comparison ranking:
179
Air pollutants:
particulate matter emissions:
34.85 micrograms per cubic meter (2019 est.)
carbon dioxide emissions:
0.29 megatons (2016 est.)
methane emissions:
1.46 megatons (2020 est.)
Waste and recycling:
municipal solid waste generated annually:
289,514 tons (2015 est.)
Major aquifers:
Senegalo-Mauritanian Basin
Total water withdrawal:
municipal:
30 million cubic meters (2020 est.)
industrial:
10 million cubic meters (2020 est.)
agricultural:
140 million cubic meters (2020 est.)
Total renewable water resources:
31.4 billion cubic meters (2020 est.)','50a356ad3f9900ff3867fd6c140160c6006437bda15200e66ffa4c7cee532b72','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a804ed9fb779937db6bd6518d6d26b613fcf09c5f016aac3cea166760288424e',2025,'GY','Guyana','environment',37,'Environment - current issues:
water pollution from sewage and agricultural and industrial chemicals; deforestation
Environment - international agreements:
party to:
Biodiversity, Climate Change, Climate Change-Kyoto Protocol, Climate Change-Paris Agreement, Comprehensive Nuclear Test Ban, Desertification, Endangered Species, Hazardous Wastes, Law of the Sea, Marine Dumping-London Protocol, Ozone Layer Protection, Ship Pollution, Tropical Timber 2006
signed, but not ratified:
none of the selected agreements
Climate:
tropical; hot, humid, moderated by northeast trade winds; two rainy seasons (May to August, November to January)
Land use:
agricultural land:
8.4% (2018 est.)
arable land:
2.1% (2018 est.)
permanent crops:
0.1% (2018 est.)
permanent pasture:
6.2% (2018 est.)
forest:
77.4% (2018 est.)
other:
14.2% (2018 est.)
Urbanization:
urban population:
27.2% of total population (2023)
rate of urbanization:
1.01% annual rate of change (2020-25 est.)
Revenue from forest resources:
4.56% of GDP (2018 est.)
comparison ranking:
13
Revenue from coal:
0% of GDP (2018 est.)
comparison ranking:
175
Air pollutants:
particulate matter emissions:
11.11 micrograms per cubic meter (2019 est.)
carbon dioxide emissions:
2.38 megatons (2016 est.)
methane emissions:
1.81 megatons (2020 est.)
Waste and recycling:
municipal solid waste generated annually:
179,252 tons (2010 est.)
municipal solid waste recycled annually:
968 tons (2010 est.)
percent of municipal solid waste recycled:
0.5% (2010 est.)
Major watersheds (area sq km): Atlantic Ocean drainage:
Amazon (6,145,186 sq km), Orinoco (953,675 sq km)
Total water withdrawal:
municipal:
60 million cubic meters (2020 est.)
industrial:
20 million cubic meters (2020 est.)
agricultural:
1.36 billion cubic meters (2020 est.)
Total renewable water resources:
271 billion cubic meters (2020 est.)','a091212a41f50439cde5f311db1791d76733c74228f808170fcb6e227e85460b','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('dde88c564b171a969740dccbf4b5490dbef4e4da292ee834369b73de86521af7',2025,'HT','Haiti','environment',4,'Environment - current issues:
extensive deforestation (much of the remaining forested land is being cleared for agriculture and used as fuel); soil erosion; overpopulation leads to inadequate supplies of potable water and a lack of sanitation; natural disasters
Environment - international agreements:
party to:
Biodiversity, Climate Change, Climate Change-Kyoto Protocol, Climate Change-Paris Agreement, Desertification, Hazardous Wastes, Law of the Sea, Marine Dumping-London Convention, Marine Life Conservation, Ozone Layer Protection
signed, but not ratified:
Nuclear Test Ban
Climate:
tropical; semiarid where mountains in east cut off trade winds
Land use:
agricultural land:
66.4% (2018 est.)
arable land:
38.5% (2018 est.)
permanent crops:
10.2% (2018 est.)
permanent pasture:
17.7% (2018 est.)
forest:
3.6% (2018 est.)
other:
30% (2018 est.)
Urbanization:
urban population:
59.7% of total population (2023)
rate of urbanization:
2.47% annual rate of change (2020-25 est.)
Food insecurity:
severe localized food insecurity:
due to high food prices, natural disasters, and worsening civil insecurity - about 4.9 million people are estimated to face severe acute food insecurity and were in need of urgent food assistance between March and June 2023; the high levels of food insecurity are the result of sustained economic downturn, reducing domestic food production, elevated food prices, fuel shortage and frequent natural disasters; the situation is exacerbated by worsening insecurity, which has limited access to essential services, including markets, caused population displacements and hampered delivery of humanitarian assistance (2023)
Revenue from forest resources:
0.68% of GDP (2018 est.)
comparison ranking:
60
Revenue from coal:
0% of GDP (2018 est.)
comparison ranking:
78
Air pollutants:
particulate matter emissions:
9.69 micrograms per cubic meter (2019 est.)
carbon dioxide emissions:
2.98 megatons (2016 est.)
methane emissions:
6.12 megatons (2020 est.)
Waste and recycling:
municipal solid waste generated annually:
2,309,852 tons (2015 est.)
Total water withdrawal:
municipal:
190 million cubic meters (2020 est.)
industrial:
50 million cubic meters (2020 est.)
agricultural:
1.21 billion cubic meters (2020 est.)
Total renewable water resources:
14.02 billion cubic meters (2020 est.)','92972379d94a373ce259a08d6b026d41d3281a106cfadb446295bceda2ad413b','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('69435da40e1c05c29d4ded54ebf773a2405aaa6983665fe55f629393c17cca2e',2025,'HM','Heard Island and McDonald Islands','environment',15,'Environment - current issues:
none; uninhabited and mostly ice covered
Climate:
antarctic
Land use:
agricultural land:
0% (2011 est.)
other:
100% (2018 est.)','5603e7e55f94ca0daaa50b295ab2a17e291c37fb4a9557e87ced6a1745e5bbe1','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a844a926838d09d4032cb50a82bdb579812279f4501e0608b28d3ac37ba8e8a7',2025,'HM','Heard Island and McDonald Islands','environment',24,'Environment - current issues:
some air pollution from the surrounding city of Rome
Environment - international agreements:
party to:
Comprehensive Nuclear Test Ban, Ozone Layer Protection
signed, but not ratified:
Air Pollution, Environmental Modification
Climate:
temperate; mild, rainy winters (September to May) with hot, dry summers (May to September)
Land use:
agricultural land:
0% (2018 est.)
other:
100% (2018 est.)
Urbanization:
urban population:
100% of total population (2023)
rate of urbanization:
0% annual rate of change (2020-25 est.)
Air pollutants:
methane emissions:
0 megatons (2020 est.)
Total renewable water resources:
0 cubic meters (2017 est.)','49a4bb8c74b58977b2336db2c1a97794a10dfed91317f8fa5f6c73203ce82708','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2ea6c6f5146422469ab8e4a9a68a63f64ae0cdbf37244b66ffbf7f1a4ea3025b',2025,'HN','Honduras','environment',34,'Environment - current issues:
urban population expanding; deforestation results from logging and the clearing of land for agricultural purposes; further land degradation and soil erosion hastened by uncontrolled development and improper land use practices such as farming of marginal lands; mining activities polluting Lago de Yojoa (the country’s largest source of fresh water), as well as several rivers and streams, with heavy metals
Environment - international agreements:
party to:
Biodiversity, Climate Change, Climate Change-Kyoto Protocol, Climate Change-Paris Agreement, Comprehensive Nuclear Test Ban, Desertification, Endangered Species, Environmental Modification, Hazardous Wastes, Law of the Sea, Marine Dumping-London Convention, Nuclear Test Ban, Ozone Layer Protection, Ship Pollution, Tropical Timber 2006, Wetlands
signed, but not ratified:
none of the selected agreements
Climate:
subtropical in lowlands, temperate in mountains
Land use:
agricultural land:
28.8% (2018 est.)
arable land:
9.1% (2018 est.)
permanent crops:
4% (2018 est.)
permanent pasture:
15.7% (2018 est.)
forest:
45.3% (2018 est.)
other:
25.9% (2018 est.)
Urbanization:
urban population:
60.2% of total population (2023)
rate of urbanization:
2.48% annual rate of change (2020-25 est.)
Revenue from forest resources:
0.91% of GDP (2018 est.)
comparison ranking:
54
Revenue from coal:
0% of GDP (2018 est.)
comparison ranking:
172
Air pollutants:
particulate matter emissions:
18.93 micrograms per cubic meter (2019 est.)
carbon dioxide emissions:
9.81 megatons (2016 est.)
methane emissions:
7.72 megatons (2020 est.)
Waste and recycling:
municipal solid waste generated annually:
2,162,028 tons (2016 est.)
Major lakes (area sq km):
salt water lake(s):
Laguna de Caratasca - 1,110 sq km
Total water withdrawal:
municipal:
320 million cubic meters (2020 est.)
industrial:
111 million cubic meters (2020 est.)
agricultural:
1.18 billion cubic meters (2020 est.)
Total renewable water resources:
92.16 billion cubic meters (2020 est.)','30f4e939f2246d56d197e66ed246c91cabc9af35207d8503d293d85ae78955ea','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('aa7217b4b7ecd86c093c2bc26a3e4e53060da03f9f6402509b9b512572098e8c',2025,'HK','Hong Kong','environment',45,'Environment - current issues:
air and water pollution from rapid urbanization; urban waste pollution; industrial pollution
Climate:
subtropical monsoon; cool and humid in winter, hot and rainy from spring through summer, warm and sunny in fall
Land use:
agricultural land:
5% (2018 est.)
arable land:
3.2% (2018 est.)
permanent crops:
0.9% (2018 est.)
permanent pasture:
0.9% (2018 est.)
forest:
0% (2018 est.)
other:
95% (2018 est.)
Urbanization:
urban population:
100% of total population (2023)
rate of urbanization:
0.58% annual rate of change (2020-25 est.)
Revenue from forest resources:
0% of GDP (2018 est.)
comparison ranking:
179
Revenue from coal:
0% of GDP (2018 est.)
comparison ranking:
177
Air pollutants:
carbon dioxide emissions:
43.64 megatons (2016 est.)
Waste and recycling:
municipal solid waste generated annually:
5,679,816 tons (2015 est.)
municipal solid waste recycled annually:
1,931,138 tons (2016 est.)
percent of municipal solid waste recycled:
34% (2016 est.)','8b5a65f81a5fc447b1e7697f3945544a193373463a148ceb90a342c3f29d51f3','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b99410cb8d3565a399d02d0dcda6aace0b2307e88349943b48f8352ff639a694',2025,'HU','Hungary','environment',57,'Environment - current issues:
air and water pollution are some of Hungary’s most serious environmental problems; water quality in the Hungarian part of the Danube has improved but is still plagued by pollutants from industry and large-scale agriculture; soil pollution
Environment - international agreements:
party to:
Air Pollution, Air Pollution-Heavy Metals, Air Pollution-Multi-effect Protocol, Air Pollution-Nitrogen Oxides, Air Pollution-Persistent Organic Pollutants, Air Pollution-Sulphur 85, Air Pollution-Sulphur 94, Air Pollution-Volatile Organic Compounds, Antarctic Treaty, Biodiversity, Climate Change, Climate Change-Kyoto Protocol, Climate Change-Paris Agreement, Comprehensive Nuclear Test Ban, Desertification, Endangered Species, Environmental Modification, Hazardous Wastes, Law of the Sea, Marine Dumping-London Convention, Nuclear Test Ban, Ozone Layer Protection, Ship Pollution, Tropical Timber 2006, Wetlands, Whaling
signed, but not ratified:
Antarctic-Environmental Protection
Climate:
temperate; cold, cloudy, humid winters; warm summers
Land use:
agricultural land:
58.9% (2018 est.)
arable land:
48.5% (2018 est.)
permanent crops:
2% (2018 est.)
permanent pasture:
8.4% (2018 est.)
forest:
22.5% (2018 est.)
other:
18.6% (2018 est.)
Urbanization:
urban population:
72.9% of total population (2023)
rate of urbanization:
0.05% annual rate of change (2020-25 est.)
Revenue from forest resources:
0.1% of GDP (2018 est.)
comparison ranking:
112
Revenue from coal:
0.01% of GDP (2018 est.)
comparison ranking:
49
Air pollutants:
particulate matter emissions:
14.24 micrograms per cubic meter (2019 est.)
carbon dioxide emissions:
45.54 megatons (2016 est.)
methane emissions:
7.25 megatons (2020 est.)
Waste and recycling:
municipal solid waste generated annually:
3.712 million tons (2015 est.)
municipal solid waste recycled annually:
962,893 tons (2015 est.)
percent of municipal solid waste recycled:
25.9% (2015 est.)
Major lakes (area sq km):
fresh water lake(s):
Lake Balaton - 590 sq km
Major rivers (by length in km):
Duna (Danube) (shared with Germany [s], Austria, Slovakia, Croatia, Serbia, Bulgaria, Ukraine, Moldova, and Romania [m]) - 2,888 km
note –
[s] after country name indicates river source; [m] after country name indicates river mouth
Major watersheds (area sq km): Atlantic Ocean drainage:
(Black Sea) Danube (795,656 sq km)
Total water withdrawal:
municipal:
660 million cubic meters (2020 est.)
industrial:
3.45 billion cubic meters (2020 est.)
agricultural:
550 million cubic meters (2020 est.)
Total renewable water resources:
104 billion cubic meters (2020 est.)','510a1b08c066dff92f512497466604de060f8fb9fe12cad84335f54948d5ab5a','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1a3b352d404f47305b37fc735150c6562301d0915bec79b4f22e31563434b426',2025,'IS','Iceland','environment',4,'Environment - current issues:
water pollution from fertilizer runoff
Environment - international agreements:
party to:
Air Pollution, Air Pollution-Persistent Organic Pollutants, Antarctic Treaty, Biodiversity, Climate Change, Climate Change-Kyoto Protocol, Climate Change-Paris Agreement, Comprehensive Nuclear Test Ban, Desertification, Endangered Species, Hazardous Wastes, Law of the Sea, Marine Dumping-London Convention, Marine Dumping- London Protocol, Nuclear Test Ban, Ozone Layer Protection, Ship Pollution, Wetlands, Whaling
signed, but not ratified:
Air Pollution-Heavy Metals, Environmental Modification, Marine Life Conservation
Climate:
temperate; moderated by North Atlantic Current; mild, windy winters; damp, cool summers
Land use:
agricultural land:
18.7% (2018 est.)
arable land:
1.2% (2018 est.)
permanent crops:
0% (2018 est.)
permanent pasture:
17.5% (2018 est.)
forest:
0.3% (2018 est.)
other:
81% (2018 est.)
Urbanization:
urban population:
94% of total population (2023)
rate of urbanization:
0.74% annual rate of change (2020-25 est.)
Revenue from forest resources:
0% of GDP (2018 est.)
comparison ranking:
164
Revenue from coal:
0% of GDP (2018 est.)
comparison ranking:
153
Air pollutants:
particulate matter emissions:
5.79 micrograms per cubic meter (2019 est.)
carbon dioxide emissions:
2.06 megatons (2016 est.)
methane emissions:
0.59 megatons (2020 est.)
Waste and recycling:
municipal solid waste generated annually:
525,000 tons (2015 est.)
municipal solid waste recycled annually:
293,003 tons (2013 est.)
percent of municipal solid waste recycled:
55.8% (2013 est.)
Total water withdrawal:
municipal:
80 million cubic meters (2020 est.)
industrial:
200 million cubic meters (2020 est.)
agricultural:
300,000 cubic meters (2017 est.)
Total renewable water resources:
170 billion cubic meters (2020 est.)','ff2765c887550f0d7dfd305ac7dcea1e23e18b7ec6f94690d61275b6f305258f','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('daf56e11ac22d89c565ab0acc056983ce14716df6cf24e3ad5072082a8ec0078',2025,'IN','India','environment',15,'Environment - current issues:
deforestation; soil erosion; overgrazing; desertification; air pollution from industrial effluents and vehicle emissions; water pollution from raw sewage and runoff of agricultural pesticides; tap water is not potable throughout the country; huge and growing population is overstraining natural resources; preservation and quality of forests; biodiversity loss
Environment - international agreements:
party to:
Antarctic-Environmental Protection, Antarctic-Marine Living Resources, Antarctic Treaty, Biodiversity, Climate Change, Climate Change-Kyoto Protocol, Climate Change-Paris Agreement, Desertification, Endangered Species, Environmental Modification, Hazardous Wastes, Law of the Sea, Nuclear Test Ban, Ozone Layer Protection, Ship Pollution, Tropical Timber 2006, Wetlands, Whaling
signed, but not ratified:
none of the selected agreements
Climate:
varies from tropical monsoon in south to temperate in north
Land use:
agricultural land:
60.5% (2018 est.)
arable land:
52.8% (2018 est.)
permanent crops:
4.2% (2018 est.)
permanent pasture:
3.5% (2018 est.)
forest:
23.1% (2018 est.)
other:
16.4% (2018 est.)
Urbanization:
urban population:
36.4% of total population (2023)
rate of urbanization:
2.33% annual rate of change (2020-25 est.)
Revenue from forest resources:
0.14% of GDP (2018 est.)
comparison ranking:
103
Revenue from coal:
1.15% of GDP (2018 est.)
comparison ranking:
4
Air pollutants:
particulate matter emissions:
50.17 micrograms per cubic meter (2019 est.)
carbon dioxide emissions:
2,407.67 megatons (2016 est.)
methane emissions:
559.11 megatons (2020 est.)
Waste and recycling:
municipal solid waste generated annually:
168,403,240 tons (2001 est.)
municipal solid waste recycled annually:
8,420,162 tons (2013 est.)
percent of municipal solid waste recycled:
5% (2013 est.)
Major lakes (area sq km):
salt water lake(s):
Chilika Lake - 1,170 sq km
Major rivers (by length in km):
Brahmaputra (shared with China [s] and Bangladesh [m]) - 3,969 km; Indus (shared with China [s] and Pakistan [m]) - 3,610 km; Ganges river source (shared with Bangladesh [m]) - 2,704 km; Godavari - 1,465 km; Sutlej (shared with China [s] and Pakistan [m]) - 1,372 km; Yamuna - 1,370 km; Narmada - 1,289 km; Chenab river source (shared with Pakistan [m]) - 1,086 km; Ghaghara river mouth (shared with China [s] and Nepal) - 1,080 km
note
– [s] after country name indicates river source; [m] after country name indicates river mouth
Major watersheds (area sq km): Indian Ocean drainage:
Brahmaputra (651,335 sq km), Ganges (1,016,124 sq km), Indus (1,081,718 sq km), Irrawaddy (413,710 sq km)
Major aquifers:
Indus-Ganges-Brahmaputra Basin
Total water withdrawal:
municipal:
56 billion cubic meters (2020 est.)
industrial:
17 billion cubic meters (2020 est.)
agricultural:
688 billion cubic meters (2020 est.)
Total renewable water resources:
1.91 trillion cubic meters (2019 est.)','196e204d8542f638d28d175d1ec6f3e0e6c5ac2897c60be1e1de7b507d75cbba','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e4c676bfdca70aa1e3e2692650767e4b8eba0bf7657dff953ea43db54c5be11a',2025,'IN','India','environment',27,'Environment - current issues:
marine pollution caused by ocean dumping, waste disposal, and oil spills; deep sea mining; oil pollution in Arabian Sea, Persian Gulf, and Red Sea; coral reefs threatened due to climate change, direct human pressures, and inadequate governance, awareness, and political will; loss of biodiversity; endangered marine species include the dugong, seals, turtles, and whales
Climate:
northeast monsoon (December to April), southwest monsoon (June to October); tropical cyclones occur during May/June and October/November in the northern Indian Ocean and January/February in the southern Indian Ocean
Marine fisheries:
the Indian Ocean fisheries are the third most important in the world accounting for 15.5%, or 12,220,000 mt of the global catch in 2020; tuna, small pelagic fish, and shrimp are important species in these regions; the Food and Agriculture Organization delineated two fishing regions in the Indian Ocean:
Eastern Indian Ocean region (Region 57) is the most important region and the fifth largest producing region in the world with 8.4%, or 6,590,000 mt, of the global catch in 2020; the region encompasses the waters north of 55° South latitude and east of 80° East longitude including the Bay of Bengal and Andaman Sea with the major producers including India (2,362,481 mt), Indonesia (1,940,558 mt), Burma (1,114,777 mt), Bangladesh (877,837 mt), and Sri Lanka (373,369 mt); the principal catches include shad, Skipjack tuna, mackerel, shrimp, and sardinellas
Western Indian Ocean region (Region 51) is the world’s sixth largest producing region with more than 7.1% or 5,630,000 mt of the global catch in 2020; this region encompasses the waters north of 40° South latitude and west of 80° East longitude including the western Indian Ocean, Arabian Sea, Persian Gulf, and Red Sea as well as the waters along the east coast of Africa and Madagascar, the south coast of the Arabian Peninsula, and the west coast of India with major producers including India (2,207,125 mt), Oman (580,048 mt), Pakistan (341,730 mt), and Mozambique (274,791 mt); the principal catches include Skipjack and Yellowfin tuna, mackerel, sardines, shrimp, and cephalopods
Regional fisheries bodies:
Indian Ocean Tuna Commission, Commission for the Conservation of Southern Bluefin Tuna, Regional Commission for Fisheries (Persian Gulf/Gulf of Oman), Southeast Asia Fisheries Development Center, Southwest Indian Ocean Fisheries Commission, South Indian Ocean Fisheries Agreement','c79cb1dc3f7b3e9f0ce9a7486c9dc2e0ad68f43b2286a1d1cdcca983f09fb410','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2dcf5ad32bc07f0f540cc68e4e63ce9b2b84b131c01c22266b345b22e3f39fd4',2025,'ID','Indonesia','environment',35,'Environment - current issues:
large-scale deforestation (much of it illegal) and related wildfires cause heavy smog; over-exploitation of marine resources; environmental problems associated with rapid urbanization and economic development, including air pollution, traffic congestion, garbage management, and reliable water and waste water services; water pollution from industrial wastes, sewage
Environment - international agreements:
party to:
Biodiversity, Climate Change, Climate Change-Kyoto Protocol, Climate Change-Paris Agreement, Comprehensive Nuclear Test Ban, Desertification, Endangered Species, Hazardous Wastes, Law of the Sea, Nuclear Test Ban, Ozone Layer Protection, Ship Pollution, Tropical Timber 2006, Wetlands
signed, but not ratified:
Marine Life Conservation
Climate:
tropical; hot, humid; more moderate in highlands
Land use:
agricultural land:
31.2% (2018 est.)
arable land:
13% (2018 est.)
permanent crops:
12.1% (2018 est.)
permanent pasture:
6.1% (2018 est.)
forest:
51.7% (2018 est.)
other:
17.1% (2018 est.)
Urbanization:
urban population:
58.6% of total population (2023)
rate of urbanization:
1.99% annual rate of change (2020-25 est.)
Revenue from forest resources:
0.39% of GDP (2018 est.)
comparison ranking:
71
Revenue from coal:
1.06% of GDP (2018 est.)
comparison ranking:
5
Air pollutants:
particulate matter emissions:
19.34 micrograms per cubic meter (2019 est.)
carbon dioxide emissions:
563.32 megatons (2016 est.)
methane emissions:
244.5 megatons (2020 est.)
Waste and recycling:
municipal solid waste generated annually:
65.2 million tons (2016 est.)
municipal solid waste recycled annually:
4.564 million tons (2016 est.)
percent of municipal solid waste recycled:
7% (2016 est.)
Major lakes (area sq km):
fresh water lake(s):
Danau Toba - 1,150 sq km
note
– located in the caldera of a super volcano that erupted more than 70,000 years ago; it is the largest volcanic lake in the World
Major rivers (by length in km):
Sepik (shared with Papua New Guinea [s]) - 1,126 km; Fly (shared with Papua New Guinea [s]) - 1,050 km
note
– [s] after country name indicates river source; [m] after country name indicates river mouth
Total water withdrawal:
municipal:
23.8 billion cubic meters (2020 est.)
industrial:
9.14 billion cubic meters (2020 est.)
agricultural:
189.7 billion cubic meters (2020 est.)
Total renewable water resources:
2.02 trillion cubic meters (2020 est.)','03e78a664359fe59120d199281a861f405d009edc1b7520106011beae2b33520','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('885cc54cbec2e2100f5c19614d3d0edebae82745c01cdad0a8890a80ddf126a4',2025,'ID','Indonesia','environment',48,'Environment - current issues:
air pollution, especially in urban areas, from vehicle emissions, refinery operations, and industrial effluents; deforestation; overgrazing; desertification; oil pollution in the Persian Gulf; wetland losses from drought; soil degradation (salination); inadequate supplies of potable water; water pollution from raw sewage and industrial waste; urbanization
Environment - international agreements:
party to:
Biodiversity, Climate Change, Climate Change-Kyoto Protocol, Desertification, Endangered Species, Hazardous Wastes, Marine Dumping-London Convention, Marine Dumping-London Protocol, Nuclear Test Ban, Ozone Layer Protection, Ship Pollution, Wetlands
signed, but not ratified:
Climate Change-Paris Agreement, Comprehensive Nuclear Test Ban, Environmental Modification, Law of the Sea, Marine Life Conservation
Climate:
mostly arid or semiarid, subtropical along Caspian coast
Land use:
agricultural land:
30.1% (2018 est.)
arable land:
10.8% (2018 est.)
permanent crops:
1.2% (2018 est.)
permanent pasture:
18.1% (2018 est.)
forest:
6.8% (2018 est.)
other:
63.1% (2018 est.)
Urbanization:
urban population:
77.3% of total population (2023)
rate of urbanization:
1.32% annual rate of change (2020-25 est.)
Revenue from forest resources:
0.01% of GDP (2017 est.)
comparison ranking:
152
Revenue from coal:
0.01% of GDP (2017 est.)
comparison ranking:
47
Air pollutants:
particulate matter emissions:
31.62 micrograms per cubic meter (2019 est.)
carbon dioxide emissions:
661.71 megatons (2016 est.)
methane emissions:
158.71 megatons (2020 est.)
Waste and recycling:
municipal solid waste generated annually:
17.885 million tons (2017 est.)
municipal solid waste recycled annually:
894,250 tons (2017 est.)
percent of municipal solid waste recycled:
5% (2017 est.)
Major lakes (area sq km):
salt water lake(s):
Caspian Sea (shared with Russia, Azerbaijan, Turkmenistan, and Kazakhstan) - 374,000 sq km; Lake Urmia - 5,200 sq km; Lake Namak - 750 sq km
Major rivers (by length in km):
Euphrates (shared with Turkey [s], Syria, and Iraq [m]) - 3,596 km; Tigris (shared with Turkey, Syria, and Iraq [m]) - 1,950 km; Helmand (shared with Afghanistan [s]) - 1,130 km
note
– [s] after country name indicates river source; [m] after country name indicates river mouth
Major watersheds (area sq km): Indian Ocean drainage:
(Persian Gulf) Tigris and Euphrates (918,044 sq km)
Total water withdrawal:
municipal:
6.2 billion cubic meters (2020 est.)
industrial:
1.1 billion cubic meters (2020 est.)
agricultural:
86 billion cubic meters (2020 est.)
Total renewable water resources:
137.05 billion cubic meters (2020 est.)','af5daf8e1ba7c592b9f609387e985910b8df5684254ed499f534527a124fd92b','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f05e6f2d93509105eecdf7bcb9ff5e94976244e53dfc3a0bbb3f606931dd1787',2025,'IQ','Iraq','environment',4,'Environment - current issues:
government water control projects drained most of the inhabited marsh areas east of An Nasiriyah by drying up or diverting the feeder streams and rivers; a once sizable population of Marsh Arabs, who inhabited these areas for thousands of years, has been displaced; furthermore, the destruction of the natural habitat poses serious threats to the area’s wildlife populations; inadequate supplies of potable water; soil degradation (salination) and erosion; desertification; military and industrial infrastructure has released heavy metals and other hazardous substances into the air, soil, and groundwater; major sources of environmental damage are effluents from oil refineries, factory and sewage discharges into rivers, fertilizer and chemical contamination of the soil, and industrial air pollution in urban areas
Environment - international agreements:
party to:
Biodiversity, Climate Change, Climate Change-Kyoto Protocol, Comprehensive Nuclear Test Ban, Desertification, Endangered Species, Hazardous Wastes, Law of the Sea, Nuclear Test Ban, Ozone Layer Protection, Ship Pollution, Wetlands
signed, but not ratified:
Climate Change-Paris Agreement, Environmental Modification
Climate:
mostly desert; mild to cool winters with dry, hot, cloudless summers; northern mountainous regions along Iranian and Turkish borders experience cold winters with occasionally heavy snows that melt in early spring, sometimes causing extensive flooding in central and southern Iraq
Land use:
agricultural land:
18.1% (2018 est.)
arable land:
8.4% (2018 est.)
permanent crops:
0.5% (2018 est.)
permanent pasture:
9.2% (2018 est.)
forest:
1.9% (2018 est.)
other:
80% (2018 est.)
Urbanization:
urban population:
71.6% of total population (2023)
rate of urbanization:
2.91% annual rate of change (2020-25 est.)
Food insecurity:
severe localized food insecurity:
due to civil conflict and economic slowdown - the 2022 Humanitarian Needs Overview identified 2.5 million people in need of humanitarian assistance, of which 960,000 have acute humanitarian needs; while the number of people in need remained similar to the previous year, the severity of those needs increased, largely due to the impact of the COVID-19 pandemic on top of an existing humanitarian crisis, leading to a 35% increase in the number of people in acute need; more than half of these are concentrated in the governorates of Nineveh and Anbar; the number of severely food insecure people is estimated at about 435,000, while 731,000 are vulnerable to food insecurity (2022)
Revenue from forest resources:
0% of GDP (2018 est.)
comparison ranking:
188
Revenue from coal:
0% of GDP (2018 est.)
comparison ranking:
136
Air pollutants:
particulate matter emissions:
39.29 micrograms per cubic meter (2019 est.)
carbon dioxide emissions:
190.06 megatons (2016 est.)
methane emissions:
17.44 megatons (2020 est.)
Waste and recycling:
municipal solid waste generated annually:
13.14 million tons (2015 est.)
Major lakes (area sq km):
fresh water lake(s):
Lake Hammar - 1,940 sq km
Major rivers (by length in km):
Euphrates river mouth (shared with Turkey[s], Syria, and Iran) - 3,596 km; Tigris river mouth (shared with Turkey[s], Syria, and Iran) - 1,950 km; the Tigris and Euphrates join to form the Shatt al Arab
note
– [s] after country name indicates river source; [m] after country name indicates river mouth
Major watersheds (area sq km): Indian Ocean drainage:
(Persian Gulf) Tigris and Euphrates (918,044 sq km)
Major aquifers:
Arabian Aquifer System
Total water withdrawal:
municipal:
6.9 billion cubic meters (2020 est.)
industrial:
5.49 billion cubic meters (2020 est.)
agricultural:
44.23 billion cubic meters (2020 est.)
Total renewable water resources:
89.86 billion cubic meters (2020 est.)','579863e76eb2dc6bc942d59e0e4662931a0141d0cb6483a338843be9bbdcba23','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('70c303f47ed9baa8d3fa9f4a3c8e8a45411508323e416f5cdcacb89e97748161',2025,'IE','Ireland','environment',17,'Environment - current issues:
water pollution, especially of lakes, from agricultural runoff; acid rain kills plants, destroys soil fertility, and contributes to deforestation
Environment - international agreements:
party to:
Air Pollution, Air Pollution-Nitrogen Oxides, Air Pollution-Persistent Organic Pollutants, Air Pollution-Sulphur 94, Biodiversity, Climate Change, Climate Change-Kyoto Protocol, Climate Change-Paris Agreement, Comprehensive Nuclear Test Ban, Desertification, Endangered Species, Environmental Modification, Hazardous Wastes, Law of the Sea, Marine Dumping-London Convention, Marine Dumping-London Protocol, Nuclear Test Ban, Ozone Layer Protection, Ship Pollution, Tropical Timber 2006, Wetlands, Whaling
signed, but not ratified:
Air Pollution-Heavy Metals, Air Pollution-Multi-effect Protocol, Marine Life Conservation
Climate:
temperate maritime; modified by North Atlantic Current; mild winters, cool summers; consistently humid; overcast about half the time
Land use:
agricultural land:
66.1% (2018 est.)
arable land:
15.4% (2018 est.)
permanent crops:
0% (2018 est.)
permanent pasture:
50.7% (2018 est.)
forest:
10.9% (2018 est.)
other:
23% (2018 est.)
Urbanization:
urban population:
64.5% of total population (2023)
rate of urbanization:
1.15% annual rate of change (2020-25 est.)
Revenue from forest resources:
0.01% of GDP (2018 est.)
comparison ranking:
157
Revenue from coal:
0% of GDP (2018 est.)
comparison ranking:
128
Air pollutants:
particulate matter emissions:
8.2 micrograms per cubic meter (2019 est.)
carbon dioxide emissions:
37.71 megatons (2016 est.)
methane emissions:
13.67 megatons (2020 est.)
Waste and recycling:
municipal solid waste generated annually:
2,692,537 tons (2012 est.)
municipal solid waste recycled annually:
888,537 tons (2012 est.)
percent of municipal solid waste recycled:
33% (2012 est.)
Total water withdrawal:
municipal:
990 million cubic meters (2020 est.)
industrial:
520 million cubic meters (2020 est.)
agricultural:
40 million cubic meters (2020 est.)
Total renewable water resources:
52 billion cubic meters (2020 est.)','43ddd5d9eeb740d1ca80db97509c4a337cafaa5cb92ab27c00b80d0c3301462a','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ae79f576467fc607d95aafb2ee1ce34491ed626943701388cbc82530c6cc3de5',2025,'IM','Isle of Man','environment',29,'Environment - current issues:
air pollution, marine pollution; waste disposal (both household and industrial)
Climate:
temperate; cool summers and mild winters; overcast about a third of the time
Land use:
agricultural land:
74.7% (2018 est.)
arable land:
43.8% (2018 est.)
permanent crops:
0% (2018 est.)
permanent pasture:
30.9% (2018 est.)
forest:
6.1% (2018 est.)
other:
19.2% (2018 est.)
Urbanization:
urban population:
53.5% of total population (2023)
rate of urbanization:
0.97% annual rate of change (2020-25 est.)
Revenue from forest resources:
0% of GDP (2017 est.)
comparison ranking:
181
Waste and recycling:
municipal solid waste generated annually:
50,551 tons (2011 est.)
municipal solid waste recycled annually:
25,276 tons (2011 est.)
percent of municipal solid waste recycled:
50% (2011 est.)','70c719e78891f2245ca520239611f1edbc3dbf1aa7a04feb9c9015097a6d61bd','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d76a156629cf220cc047aae57f0d48fdcc1682e2f81d5797d9a41099bc02cc7d',2025,'IL','Israel','environment',40,'Environment - current issues:
limited arable land and restricted natural freshwater resources; desertification; air pollution from industrial and vehicle emissions; groundwater pollution from industrial and domestic waste, chemical fertilizers, and pesticides
Environment - international agreements:
party to:
Biodiversity, Climate Change, Climate Change-Kyoto Protocol, Climate Change-Paris Agreement, Desertification, Endangered Species, Hazardous Wastes, Nuclear Test Ban, Ozone Layer Protection, Ship Pollution, Wetlands, Whaling
signed, but not ratified:
Comprehensive Nuclear Test Ban, Marine Life Conservation
Climate:
temperate; hot and dry in southern and eastern desert areas
Land use:
agricultural land:
23.8% (2018 est.)
arable land:
13.7% (2018 est.)
permanent crops:
3.8% (2018 est.)
permanent pasture:
6.3% (2018 est.)
forest:
7.1% (2018 est.)
other:
69.1% (2018 est.)
Urbanization:
urban population:
92.9% of total population (2023)
rate of urbanization:
1.51% annual rate of change (2020-25 est.)
Revenue from forest resources:
0% of GDP (2018 est.)
comparison ranking:
175
Revenue from coal:
0% of GDP (2018 est.)
comparison ranking:
170
Air pollutants:
particulate matter emissions:
19.47 micrograms per cubic meter (2019 est.)
carbon dioxide emissions:
65.17 megatons (2016 est.)
methane emissions:
13.02 megatons (2020 est.)
Waste and recycling:
municipal solid waste generated annually:
5.4 million tons (2015 est.)
municipal solid waste recycled annually:
1.35 million tons (2017 est.)
percent of municipal solid waste recycled:
25% (2017 est.)
Major lakes (area sq km):
salt water lake(s):
Dead Sea (shared with Jordan and West Bank) - 1,020 sq km
note
– endorheic hypersaline lake; 9.6 times saltier than the ocean; lake shore is 431 meters below sea level
Total water withdrawal:
municipal:
1 billion cubic meters (2020 est.)
industrial:
100 million cubic meters (2020 est.)
agricultural:
1.2 billion cubic meters (2020 est.)
Total renewable water resources:
1.78 billion cubic meters (2020 est.)','deb7b262a88008caf6fbdda19eb6c5889882340e5c0ff13519a9b3e5db41c4e6','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('15f54c4edb2eaf5ec87867c227f3f196464f38cfb206a67f017e5c69320aa0b1',2025,'IT','Italy','environment',53,'Environment - current issues:
air pollution from industrial emissions such as sulfur dioxide; coastal and inland rivers polluted from industrial and agricultural effluents; acid rain damaging lakes; inadequate industrial waste treatment and disposal facilities
Environment - international agreements:
party to: Air Pollution, Air Pollution-Nitrogen Oxides, Air Pollution-Persistent Organic Pollutants, Air Pollution-Sulphur 85, Air Pollution-Sulphur 94, Air Pollution-Volatile Organic Compounds, Antarctic-Environmental Protection, Antarctic-Marine Living Resources, Antarctic Seals, Antarctic Treaty, Biodiversity, Climate Change, Climate Change-Kyoto Protocol, Climate Change-Paris Agreement, Comprehensive Nuclear Test Ban, Desertification, Endangered Species, Environmental Modification, Hazardous Wastes, Law of the Sea, Marine Dumping-London Convention, Marine Dumping-London Protocol, Nuclear Test Ban, Ozone Layer Protection, Ship Pollution, Tropical Timber 2006, Wetlands, Whaling
signed, but not ratified:
Air Pollution-Heavy Metals, Air Pollution-Multi-effect Protocol
Climate:
predominantly Mediterranean; alpine in far north; hot, dry in south
Land use:
agricultural land: 47.1% (2018 est.)
arable land:
22.8% (2018 est.)
permanent crops:
8.6% (2018 est.)
permanent pasture:
15.7% (2018 est.)
forest:
31.4% (2018 est.)
other:
21.5% (2018 est.)
Urbanization:
urban population: 72% of total population (2023)
rate of urbanization:
0.27% annual rate of change (2020-25 est.)
Revenue from forest resources:
0.01% of GDP (2018 est.)
comparison ranking:
150
Revenue from coal:
0% of GDP (2018 est.)
comparison ranking:
85
Air pollutants:
particulate matter emissions: 14.22 micrograms per cubic meter (2019 est.)
methane emissions:
41.3 megatons (2020 est.)
Waste and recycling:
municipal solid waste generated annually: 29.524 million tons (2015 est.)
municipal solid waste recycled annually:
7,646,716 tons (2015 est.)
percent of municipal solid waste recycled:
25.9% (2015 est.)
Major watersheds (area sq km): Atlantic Ocean drainage:
Rhine-Maas (198,735 sq km),
(Black Sea)
Danube (795,656 sq km),
(Adriatic Sea)
Po (76,997 sq km),
(Mediterranean Sea)
Rhone (100,543 sq km)
Total water withdrawal:
municipal: 9.19 billion cubic meters (2020 est.)
industrial:
7.7 billion cubic meters (2020 est.)
agricultural:
17 billion cubic meters (2020 est.)
Total renewable water resources:
191.3 billion cubic meters (2020 est.)','aab4d6b28ca4515e818830c7a041410e63b64bd93dd46bd6cecde7b8abb09cba','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('07674c363b4a227713d1bf74f7098c98c551821b3324185ca8b6cccc932702d8',2025,'JM','Jamaica','environment',4,'Environment - current issues:
heavy rates of deforestation; coastal waters polluted by industrial waste, sewage, and oil spills; damage to coral reefs; air pollution in Kingston from vehicle emissions; land erosion
Environment - international agreements:
party to:
Biodiversity, Climate Change, Climate Change-Kyoto Protocol, Climate Change-Paris Agreement, Comprehensive Nuclear Test Ban, Desertification, Endangered Species, Hazardous Wastes, Law of the Sea, Marine Dumping-London Convention, Marine Life Conservation, Nuclear Test Ban, Ozone Layer Protection, Ship Pollution, Wetlands
signed, but not ratified:
none of the selected agreements
Climate:
tropical; hot, humid; temperate interior
Land use:
agricultural land:
41.4% (2018 est.)
arable land:
11.1% (2018 est.)
permanent crops:
9.2% (2018 est.)
permanent pasture:
21.1% (2018 est.)
forest:
31.1% (2018 est.)
other:
27.5% (2018 est.)
Urbanization:
urban population:
57.4% of total population (2023)
rate of urbanization:
0.79% annual rate of change (2020-25 est.)
Revenue from forest resources:
0.15% of GDP (2018 est.)
comparison ranking:
102
Revenue from coal:
0% of GDP (2018 est.)
comparison ranking:
94
Air pollutants:
particulate matter emissions:
14.83 micrograms per cubic meter (2019 est.)
carbon dioxide emissions:
8.23 megatons (2016 est.)
methane emissions:
1.08 megatons (2020 est.)
Waste and recycling:
municipal solid waste generated annually:
1,051,695 tons (2016 est.)
Total water withdrawal:
municipal:
140 million cubic meters (2020 est.)
industrial:
1.1 billion cubic meters (2020 est.)
agricultural:
110 million cubic meters (2020 est.)
Total renewable water resources:
10.82 billion cubic meters (2020 est.)','1095a8ab2f1d8497bd219b185e74c67eafcf5aaa2fc0ce392004976b105c6bc1','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1cdd23c790f885d714080c8e1416db7eac2ef17692638fa54b16bce4a68fab76',2025,'JM','Jamaica','environment',15,'Environment - current issues:
pollutants transported from southerly latitudes by winds, ocean currents, and rivers accumulate in the food chains of native animals; climate change
Climate:
arctic maritime with frequent storms and persistent fog
Land use:
agricultural land:
0% (2011 est.)
other:
100% (2018 est.)','21f6bd38f6c7f898c1f2bc71924c52259080a0f5f262643a2e278337316ac86f','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('341429b9d89203314807c0dbbb0882ca686b31274226c62b9efdb43ce3f4a9e2',2025,'JP','Japan','environment',24,'Environment - current issues:
air pollution from power plant emissions results in acid rain; acidification of lakes and reservoirs degrading water quality and threatening aquatic life; Japan is one of the largest consumers of fish and tropical timber, contributing to the depletion of these resources in Asia and elsewhere; following the 2011 Fukushima nuclear disaster, Japan originally planned to phase out nuclear power, but it has now implemented a new policy of seeking to restart nuclear power plants that meet strict new safety standards; waste management is an ongoing issue; Japanese municipal facilities used to burn high volumes of trash, but air pollution issues forced the government to adopt an aggressive recycling policy
Environment - international agreements:
party to:
Antarctic-Environmental Protection, Antarctic-Marine Living Resources, Antarctic Seals, Antarctic Treaty, Biodiversity, Climate Change, Climate Change-Kyoto Protocol, Climate Change-Paris Agreement, Comprehensive Nuclear Test Ban, Desertification, Endangered Species, Environmental Modification, Hazardous Wastes, Law of the Sea, Marine Dumping-London Convention, Marine Dumping-London Protocol, Nuclear Test Ban, Ozone Layer Protection, Ship Pollution, Tropical Timber 2006, Wetlands
signed, but not ratified:
none of the selected agreements
Climate:
varies from tropical in south to cool temperate in north
Land use:
agricultural land: 12.5% (2018 est.)
arable land:
11.7% (2018 est.)
permanent crops:
0.8% (2018 est.)
permanent pasture:
0% (2018 est.)
forest:
68.5% (2018 est.)
other:
19% (2018 est.)
Urbanization:
urban population: 92% of total population (2023)
rate of urbanization:
-0.25% annual rate of change (2020-25 est.)
Revenue from forest resources:
0.02% of GDP (2018 est.)
comparison ranking:
138
Revenue from coal:
0% of GDP (2018 est.)
comparison ranking:
137
Air pollutants:
particulate matter emissions: 10.84 micrograms per cubic meter (2019 est.)
carbon dioxide emissions:
1,135.89 megatons (2016 est.)
methane emissions:
29.99 megatons (2020 est.)
Waste and recycling:
municipal solid waste generated annually: 43.981 million tons (2015 est.)
municipal solid waste recycled annually:
2,155,069 tons (2015 est.)
percent of municipal solid waste recycled:
4.9% (2015 est.)
Major lakes (area sq km):
fresh water lake(s): Biwa-ko 688 sq km
Total water withdrawal:
municipal: 14.8 billion cubic meters (2020 est.)
industrial:
10.3 billion cubic meters (2020 est.)
agricultural:
53.3 billion cubic meters (2020 est.)
Total renewable water resources:
430 billion cubic meters (2020 est.)','1da29d7a71636f50a02dbbe0d51b34e5a14214d61ff57f0ce9af44d9b274153a','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9b597ce7b5c9c01143f60c03863e2f958c82114a7818a164210235b19162a5f0',2025,'JE','Jersey','environment',36,'Environment - current issues:
habitat and species depletion due to human encroachment; water pollution; improper solid waste disposal
Climate:
temperate; mild winters and cool summers
Land use:
agricultural land:
66% (2018 est.)
arable land:
66% (2018 est.)
other:
34% (2018 est.)
Urbanization:
urban population:
31.2% of total population (2023)
rate of urbanization:
0.68% annual rate of change (2020-25 est.)
note:
data include Guernsey and Jersey
Waste and recycling:
municipal solid waste generated annually:
178,933 tons (2016 est.)
municipal solid waste recycled annually:
50,871 tons (2016 est.)
percent of municipal solid waste recycled:
28.4% (2016 est.)
note:
data include combined totals for Guernsey and Jersey.','e1712be118d2c2e6a5973a60d2a67e18ba36ed5365322e0d51387b4ae8b80d09','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9cc5d60f46f552941876bba50fd4798f1534df8daf6695235ed482fb67fadff9',2025,'JO','Jordan','environment',47,'Environment - current issues:
limited natural freshwater resources; declining water table; salinity; deforestation; overgrazing; soil erosion; desertification; biodiversity and ecosystem damage/loss
Environment - international agreements:
party to:
Biodiversity, Climate Change, Climate Change-Kyoto Protocol, Climate Change-Paris Agreement, Comprehensive Nuclear Test Ban, Desertification, Endangered Species, Hazardous Wastes, Law of the Sea, Marine Dumping-London Convention, Nuclear Test Ban, Ozone Layer Protection, Ship Pollution, Wetlands
signed, but not ratified:
none of the selected agreements
Climate:
mostly arid desert; rainy season in west (November to April)
Land use:
agricultural land:
11.4% (2018 est.)
arable land:
2% (2018 est.)
permanent crops:
1% (2018 est.)
permanent pasture:
8.4% (2018 est.)
forest:
1.1% (2018 est.)
other:
87.5% (2018 est.)
Urbanization:
urban population:
92% of total population (2023)
rate of urbanization:
0.98% annual rate of change (2020-25 est.)
Revenue from forest resources:
0.02% of GDP (2018 est.)
comparison ranking:
142
Revenue from coal:
0% of GDP (2018 est.)
comparison ranking:
149
Air pollutants:
particulate matter emissions:
25.87 micrograms per cubic meter (2019 est.)
carbon dioxide emissions:
25.11 megatons (2016 est.)
methane emissions:
6.04 megatons (2020 est.)
Waste and recycling:
municipal solid waste generated annually:
2,529,997 tons (2013 est.)
municipal solid waste recycled annually:
177,100 tons (2014 est.)
percent of municipal solid waste recycled:
7% (2014 est.)
Major lakes (area sq km):
salt water lake(s):
Dead Sea (shared with Israel and West Bank) - 1,020 sq km
note - endorheic hypersaline lake; 9.6 times saltier than the ocean; lake shore is 431 meters below sea level
Major watersheds (area sq km): Indian Ocean drainage:
(Persian Gulf)
Tigris and Euphrates (918,044 sq km)
Major aquifers:
Arabian Aquifer System
Total water withdrawal:
municipal:
500 million cubic meters (2020 est.)
industrial:
40 million cubic meters (2020 est.)
agricultural:
570 million cubic meters (2020 est.)
Total renewable water resources:
940 million cubic meters (2020 est.)','ddf52b6a6649c5f2eb8ce4aa84c488e87c6441706d77cfa367704c3cc31b5fbf','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5dc6b1a36aec622bf5df761e0b3fa5343568fc4130f4dc6e2be61fcda51275e5',2025,'KZ','Kazakhstan','environment',4,'Environment - current issues:
radioactive or toxic chemical sites associated with former defense industries and test ranges scattered throughout the country pose health risks for humans and animals; industrial pollution is severe in some cities; because the two main rivers that flowed into the Aral Sea have been diverted for irrigation, it is drying up and leaving behind a harmful layer of chemical pesticides and natural salts; these substances are then picked up by the wind and blown into noxious dust storms; pollution in the Caspian Sea; desertification; soil pollution from overuse of agricultural chemicals and salination from poor infrastructure and wasteful irrigation practices
Environment - international agreements:
party to: Air
Pollution, Antarctic Treaty, Biodiversity, Climate Change, Climate Change-Kyoto Protocol, Climate Change-Paris Agreement, Comprehensive Nuclear Test Ban, Desertification, Endangered Species, Environmental Modification, Hazardous Wastes, Ozone Layer Protection, Ship Pollution, Wetlands
signed, but not ratified:
none of the selected agreements
Climate:
continental, cold winters and hot summers, arid and semiarid
Land use:
agricultural land: 77.4%
(2018 est.)
arable land:
8.9% (2018 est.)
permanent crops:
0% (2018 est.)
permanent pasture:
68.5% (2018 est.)
forest:
1.2% (2018 est.)
other:
21.4% (2018 est.)
Urbanization:
urban population: 58.2%
of total population (2023)
rate of urbanization:
1.19% annual rate of change (2020-25 est.)
Revenue from forest resources:
0% of GDP (2018 est.)
comparison ranking:
162
Revenue from coal:
0.99% of GDP (2018 est.)
comparison ranking:
6
Air pollutants:
particulate matter emissions: 26.5
micrograms per cubic meter (2019 est.)
carbon dioxide emissions:
247.21 megatons (2016 est.)
methane emissions:
45.03 megatons (2020 est.)
Waste and recycling:
municipal solid waste generated annually: 4,659,740
tons (2012 est.)
municipal solid waste recycled annually:
136,064 tons (2012 est.)
percent of municipal solid waste recycled:
2.9% (2012 est.)
Major lakes (area sq km):
fresh water lake(s): Ozero
Balkhash - 22,000 sq km; Ozero Zaysan - 1,800 sq km
salt water lake(s):
Caspian Sea (shared with Iran, Azerbaijan, Turkmenistan, and Russia) - 374,000 sq km; Aral Sea (north) - 3,300 sq km; Ozero Alakol - 2,650 sq km; Ozero Teniz 1,590 sq km; Ozero Seletytenzi - 780 sq km; Ozero Sasykkol - 740 sq km
Major rivers (by length in km):
Syr Darya river mouth (shared with Kyrgyzstan [s], Uzbekistan, and Tajikistan) - 3,078 km
note – [s] after country name indicates river source; [m] after country name indicates river mouth
Major watersheds (area sq km): Internal (endorheic basin) drainage:
Tarim Basin (1,152,448 sq km), Amu Darya (534,739 sq km), Syr Darya (782,617 sq km), Lake Balkash (510,015 sq km)
Total water withdrawal:
municipal: 4.62
billion cubic meters (2020 est.)
industrial:
4.54 billion cubic meters (2020 est.)
agricultural:
15.4 billion cubic meters (2020 est.)
Total renewable water resources:
108.41 billion cubic meters (2020 est.)','750b88460de99d4afa89086e039c3e512c778784cb679b9f600d45d64b659df5','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0a512e4903013788ea3d78d34f534771d8b8cbb8e369f174221492bdc4afcf12',2025,'KE','Kenya','environment',16,'Environment - current issues:
water pollution from urban and industrial wastes; water shortage and degraded water quality from increased use of pesticides and fertilizers; flooding; water hyacinth infestation in Lake Victoria; deforestation; soil erosion; desertification; poaching
Environment - international agreements:
party to: Biodiversity,
Climate Change, Climate Change-Kyoto Protocol, Climate Change-Paris Agreement, Comprehensive Nuclear Test Ban, Desertification, Endangered Species, Hazardous Wastes, Law of the Sea, Marine Dumping-London Convention, Marine Dumping-London Protocol, Marine Life Conservation, Nuclear Test Ban, Ozone Layer Protection, Ship Pollution, Wetlands, Whaling
signed, but not ratified:
none of the selected agreements
Climate:
varies from tropical along coast to arid in interior
Land use:
agricultural land: 48.1%
(2018 est.)
arable land:
9.8% (2018 est.)
permanent crops:
0.9% (2018 est.)
permanent pasture:
37.4% (2018 est.)
forest:
6.1% (2018 est.)
other:
45.8% (2018 est.)
Urbanization:
urban population: 29.5%
of total population (2023)
rate of urbanization:
4.09% annual rate of change (2020-25 est.)
Food insecurity:
exceptional shortfall in aggregate food production/supplies: due to drought conditions - about 4.4 million people were projected to be severely acutely food insecure between October and December 2022 reflecting consecutive poor rainy seasons since late 2020 that affected crop and livestock production; prices of maize are at high levels across the country due to reduced availabilities and high fuel prices inflating production and transportation costs (2023)
Revenue from forest resources:
1.3% of GDP (2018 est.)
comparison ranking:
47
Revenue from coal:
0% of GDP (2018 est.)
comparison ranking:
142
Air pollutants:
particulate matter emissions: 12.52
micrograms per cubic meter (2019 est.)
carbon dioxide emissions:
17.91 megatons (2016 est.)
methane emissions:
37.65 megatons (2020 est.)
Waste and recycling:
municipal solid waste generated annually: 5,595,099
tons (2010 est.)
municipal solid waste recycled annually:
447,608 tons (2009 est.)
percent of municipal solid waste recycled:
8% (2009 est.)
Major lakes (area sq km):
fresh water lake(s): Lake
Victoria (shared with Tanzania and Uganda) - 62,940 sq km
salt water lake(s):
Lake Turkana (shared with Ethiopia) - 6,400 sq km
Major watersheds (area sq km): Atlantic Ocean drainage:
(Mediterranean Sea)
Nile (3,254,853 sq km)
Major aquifers:
Ogaden-Juba Basin
Total water withdrawal:
municipal: 500
million cubic meters (2020 est.)
industrial:
300 million cubic meters (2020 est.)
agricultural:
3.23 billion cubic meters (2020 est.)
Total renewable water resources:
30.7 billion cubic meters (2020 est.)','df8773a2c6bc77b6fbad49bb57d32930ff16f915d29bc6c91f48b699cafa3332','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e29141e9f02492b5396717491f5090d88aa0e3e1346cd2790fcde4305c465d18',2025,'KI','Kiribati','environment',29,'Environment - current issues:
heavy pollution in lagoon of south Tarawa atoll due to overcrowding mixed with traditional practices such as lagoon latrines and open-pit dumping; ground water at risk; potential for water shortages, disease; coastal erosion
Environment - international agreements:
party to: Biodiversity,
Climate Change, Climate Change-Kyoto Protocol, Climate Change-Paris Agreement, Comprehensive Nuclear Test Ban, Desertification, Hazardous Wastes, Law of the Sea, Marine Dumping-London Convention, Ozone Layer Protection, Ship Pollution, Wetlands, Whaling
signed, but not ratified:
none of the selected agreements
Climate:
tropical; marine, hot and humid, moderated by trade winds
Land use:
agricultural land: 42%
(2018 est.)
arable land:
2.5% (2018 est.)
permanent crops:
39.5% (2018 est.)
permanent pasture:
0% (2018 est.)
forest:
15% (2018 est.)
other:
43% (2018 est.)
Urbanization:
urban population: 57.8%
of total population (2023)
rate of urbanization:
2.77% annual rate of change (2020-25 est.)
Revenue from forest resources:
0.04% of GDP (2018 est.)
comparison ranking:
131
Revenue from coal:
0% of GDP (2018 est.)
comparison ranking:
169
Air pollutants:
particulate matter emissions: 7.62
micrograms per cubic meter (2019 est.)
carbon dioxide emissions:
0.07 megatons (2016 est.)
methane emissions:
0.02 megatons (2020 est.)
Waste and recycling:
municipal solid waste generated annually: 35,724
tons (2016 est.)
Total renewable water resources:
0 cubic meters (2017 est.)','05840172eb5374e99113fefcf49e02af6937ed5c30ffee1696a1fa634431b1c3','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('312f5c17dfe60899bced2d6da5ecf4f2ab1d9afd5db9403d565d0a168d8d2201',2025,'KI','Kiribati','environment',40,'Environment - current issues:
water pollution; inadequate supplies of potable water; waterborne disease; deforestation; soil erosion and degradation
Environment - international agreements:
party to: Antarctic
Treaty, Biodiversity, Climate Change, Climate Change-Kyoto Protocol, Climate Change-Paris Agreement, Desertification, Environmental Modification, Hazardous Wastes, Ozone Layer Protection, Ship Pollution, Wetlands
signed, but not ratified:
Antarctic-Environmental Protection, Law of the Sea
Climate:
temperate, with rainfall concentrated in summer; long, bitter winters
Land use:
agricultural land: 21.8%
(2018 est.)
arable land:
19.5% (2018 est.)
permanent crops:
1.9% (2018 est.)
permanent pasture:
0.4% (2018 est.)
forest:
46% (2018 est.)
other:
32.2% (2018 est.)
Urbanization:
urban population: 63.2%
of total population (2023)
rate of urbanization:
0.85% annual rate of change (2020-25 est.)
Food insecurity:
widespread lack of access: due to low food consumption levels, poor dietary diversity, and economic downturn -
a large portion of the population suffers from low levels of food consumption and very poor dietary diversity; the economic constraints, particularly resulting from the global impact of the COVID-19 pandemic, have increased the population’s vulnerability to food insecurity; the food gap is estimated at about 860,000 mt, equivalent to approximately 2-3 months of food use, if this gap is not adequately covered through commercial imports and/or food aid, households could experience a harsh lean period (2022)
Air pollutants:
particulate matter emissions: 41.46
micrograms per cubic meter (2019 est.)
carbon dioxide emissions:
28.28 megatons (2016 est.)
methane emissions:
18.68 megatons (2020 est.)
Total water withdrawal:
municipal: 900
million cubic meters (2020 est.)
industrial:
1.15 billion cubic meters (2020 est.)
agricultural:
6.61 billion cubic meters (2020 est.)
Total renewable water resources:
77.15 billion cubic meters (2020 est.)','88e95bc4ed3dbeb1223798b45dd7e5774a89e631b470e4c22f613d5c4fbd346f','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('140ac49197e00c8372950f29090c3b0dc493e9372db0928dd9abb2a426cb2c3e',2025,'KW','Kuwait','environment',8,'Environment - current issues:
limited natural freshwater resources; some of world’s largest and most sophisticated desalination facilities provide much of the water; air and water pollution; desertification; loss of biodiversity
Environment - international agreements:
party to: Biodiversity,
Climate Change, Climate Change-Kyoto Protocol, Climate Change-Paris Agreement, Comprehensive Nuclear Test Ban, Desertification, Endangered Species, Environmental Modification, Hazardous Wastes, Law of the Sea, Nuclear Test Ban, Ozone Layer Protection, Ship Pollution, Wetlands
signed, but not ratified:
Marine Dumping-London Convention
Climate:
dry desert; intensely hot summers; short, cool winters
Land use:
agricultural land: 8.5%
(2018 est.)
arable land:
0.6% (2018 est.)
permanent crops:
0.3% (2018 est.)
permanent pasture:
7.6% (2018 est.)
forest:
0.4% (2018 est.)
other:
91.1% (2018 est.)
Urbanization:
urban population: 100%
of total population (2023)
rate of urbanization:
1.35% annual rate of change (2020-25 est.)
Revenue from forest resources:
0% of GDP (2018 est.)
comparison ranking:
195
Revenue from coal:
0% of GDP (2018 est.)
comparison ranking:
138
Air pollutants:
particulate matter emissions: 64.08
micrograms per cubic meter (2019 est.)
carbon dioxide emissions:
98.73 megatons (2016 est.)
methane emissions:
6.21 megatons (2020 est.)
Waste and recycling:
municipal solid waste generated annually: 1.75
million tons (2010 est.)
Major watersheds (area sq km): Indian Ocean drainage:
(Persian Gulf)
Tigris and Euphrates (918,044 sq km)
Major aquifers:
Arabian Aquifer System
Total water withdrawal:
municipal: 450
million cubic meters (2020 est.)
industrial:
20 million cubic meters (2020 est.)
agricultural:
780 million cubic meters (2020 est.)
Total renewable water resources:
20 million cubic meters (2020 est.)','a073e1e937a7a3dff97a71bf04451dbc87861d1c9d2a9c58c8896c1dc725d2ae','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('19d7a2f4186816118580eb790b9135455a595f1553945b16d977fbc2e00ac08e',2025,'KG','Kyrgyzstan','environment',19,'Environment - current issues:
water pollution; many people get their water directly from contaminated streams and wells; as a result, water-borne diseases are prevalent; increasing soil salinity from faulty irrigation practices; air pollution due to rapid increase of traffic
Environment - international agreements:
party to: Air
Pollution, Biodiversity, Climate Change, Climate Change-Kyoto Protocol, Climate Change-Paris Agreement, Comprehensive Nuclear Test Ban, Desertification, Endangered Species, Environmental Modification, Hazardous Wastes, Ozone Layer Protection, Wetlands
signed, but not ratified:
none of the selected agreements
Climate:
dry continental to polar in high Tien Shan Mountains; subtropical in southwest (Fergana Valley); temperate in northern foothill zone
arable land:
6.7% (2018 est.)
permanent crops:
0.4% (2018 est.)
permanent pasture:
48.3% (2018 est.)
forest:
5.1% (2018 est.)
other:
39.5% (2018 est.)
Urbanization:
urban population: 37.8%
of total population (2023)
rate of urbanization:
2.05% annual rate of change (2020-25 est.)
Revenue from forest resources:
0.01% of GDP (2018 est.)
comparison ranking:
146
Revenue from coal:
0.21% of GDP (2018 est.)
comparison ranking:
21
Air pollutants:
particulate matter emissions: 37.58
micrograms per cubic meter (2019 est.)
carbon dioxide emissions:
9.79 megatons (2016 est.)
methane emissions:
4.47 megatons (2020 est.)
Waste and recycling:
municipal solid waste generated annually: 1,113,300
tons (2015 est.)
Major lakes (area sq km):
salt water lake(s): Ozero
Issyk-Kul 6,240 sq km
note - second largest saline lake after the Caspian Sea; second highest mountain lake after Lake Titicaca; it is an endorheic mountain basin; although surrounded by snow capped mountains it never freezes
Major rivers (by length in km):
Syr Darya river source (shared with Tajikistan, Uzbekistan, and Kazakhstan [m]) - 3,078 km
note –[s] after country name indicates river source; [m] after country name indicates river mouth
Major watersheds (area sq km): Internal (endorheic basin) drainage:
Tarim Basin (1,152,448 sq km),
(Aral Sea basin)
Amu Darya (534,739 sq km), Syr Darya (782,617 sq km)
Total water withdrawal:
municipal: 220
million cubic meters (2020 est.)
industrial:
340 million cubic meters (2020 est.)
agricultural:
7.1 billion cubic meters (2020 est.)
Total renewable water resources:
23.62 billion cubic meters (2020 est.)','1cc68db441048bc3c6067f3bc6d3c36be48bee54c88f3236fb635264088d3a04','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d47ae3ec1a8bd594f7c826921a0b29a6349d3075d5444178887223d9544fd71f',2025,'LV','Latvia','environment',6,'Environment - current issues:
while land, water, and air pollution are evident, Latvia’s environment has benefited from a shift to service industries after the country regained independence; improvements have occurred in drinking water quality, sewage treatment, household and hazardous waste management, as well as reduction of air pollution; concerns include nature protection and the management of water resources and the protection of the Baltic Sea
Environment - international agreements:
party to:
Air Pollution, Air Pollution-Heavy Metals, Air Pollution-Multi-effect Protocol, Air Pollution-Persistent Organic Pollutants, Biodiversity, Climate Change, Climate Change-Kyoto Protocol, Climate Change-Paris Agreement, Comprehensive Nuclear Test Ban, Desertification, Endangered Species, Hazardous Wastes, Law of the Sea, Ozone Layer Protection, Ship Pollution, Tropical Timber 2006, Wetlands
signed, but not ratified:
none of the selected agreements
Climate:
maritime; wet, moderate winters
Land use:
agricultural land:
29.2% (2018 est.)
arable land:
18.6% (2018 est.)
permanent crops:
0.1% (2018 est.)
permanent pasture:
10.5% (2018 est.)
forest:
54.1% (2018 est.)
other:
16.7% (2018 est.)
Urbanization:
urban population:
68.7% of total population (2023)
rate of urbanization:
-0.68% annual rate of change (2020-25 est.)
Revenue from forest resources:
0.85% of GDP (2018 est.)
comparison ranking:
55
Revenue from coal:
0% of GDP (2018 est.)
comparison ranking:
134
Air pollutants:
particulate matter emissions:
12.02 micrograms per cubic meter (2019 est.)
carbon dioxide emissions:
7 megatons (2016 est.)
methane emissions:
1.85 megatons (2020 est.)
Waste and recycling:
municipal solid waste generated annually:
857,000 tons (2015 est.)
municipal solid waste recycled annually:
181,941 tons (2015 est.)
percent of municipal solid waste recycled:
21.2% (2015 est.)
Total water withdrawal:
municipal:
90 million cubic meters (2020 est.)
industrial:
40 million cubic meters (2020 est.)
agricultural:
60 million cubic meters (2020 est.)
Total renewable water resources:
34.94 billion cubic meters (2020 est.)','701e25eee900acf1221b79a064d3f14366840204242a375eb44082f41738fc24','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('343a8bfa3d987cf1aa0eb1f7d975ee7e016559de4c59541ddfc22ed19310286d',2025,'LB','Lebanon','environment',17,'Environment - current issues:
deforestation; soil deterioration, erosion; desertification; species loss; air pollution in Beirut from vehicular traffic and the burning of industrial wastes; pollution of coastal waters from raw sewage and oil spills; waste-water management
Environment - international agreements:
party to:
Biodiversity, Climate Change, Climate Change-Kyoto Protocol, Climate Change-Paris Agreement, Comprehensive Nuclear Test Ban, Desertification, Endangered Species, Hazardous Wastes, Law of the Sea, Nuclear Test Ban, Ozone Layer Protection, Ship Pollution, Wetlands
signed, but not ratified:
Environmental Modification, Marine Life Conservation
Climate:
Mediterranean; mild to cool, wet winters with hot, dry summers; the Lebanon Mountains experience heavy winter snows
Land use:
agricultural land:
63.3% (2018 est.)
arable land:
11.9% (2018 est.)
permanent crops:
12.3% (2018 est.)
permanent pasture:
39.1% (2018 est.)
forest:
13.4% (2018 est.)
other:
23.3% (2018 est.)
Urbanization:
urban population:
89.4% of total population (2023)
rate of urbanization:
-1.23% annual rate of change (2020-25 est.)
Food insecurity:
widespread lack of access: due to the ongoing financial and economic crisis -
in September 2021, the United Nations estimated that, taking into account multiple factors other than income, such as access to health, education and public utilities, 82% of the population lives in multidimensional poverty in 2021, up from 42% in 2019 (2022)
Revenue from forest resources:
0% of GDP (2018 est.)
comparison ranking:
185
Revenue from coal:
0% of GDP (2018 est.)
comparison ranking:
130
Air pollutants:
particulate matter emissions:
24.23 micrograms per cubic meter (2019 est.)
carbon dioxide emissions:
24.8 megatons (2016 est.)
methane emissions:
3.37 megatons (2020 est.)
Waste and recycling:
municipal solid waste generated annually:
2.04 million tons (2014 est.)
municipal solid waste recycled annually:
163,200 tons (2014 est.)
percent of municipal solid waste recycled:
8% (2014 est.)
Total water withdrawal:
municipal:
240 million cubic meters (2020 est.)
industrial:
900 million cubic meters (2020 est.)
agricultural:
700 million cubic meters (2020 est.)
Total renewable water resources:
4.5 billion cubic meters (2020 est.)','ae725ebcc602da2d06cd442d8cf868c76648294232cc344f6e03fa2b93dea895','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9929422ad9434e7bbfd325ccbea62630364146afed09329825849a8098384b89',2025,'LS','Lesotho','environment',29,'Environment - current issues:
population pressure forcing settlement in marginal areas results in overgrazing, severe soil erosion, and soil exhaustion; desertification; Highlands Water Project controls, stores, and redirects water to South Africa
Environment - international agreements:
party to:
Biodiversity, Climate Change, Climate Change-Kyoto Protocol, Climate Change-Paris Agreement, Comprehensive Nuclear Test Ban, Desertification, Endangered Species, Hazardous Wastes, Law of the Sea, Marine Life Conservation, Ozone Layer Protection, Wetlands
signed, but not ratified:
none of the selected agreements
Climate:
temperate; cool to cold, dry winters; hot, wet summers
Land use:
agricultural land:
76.1% (2018 est.)
arable land:
10.1% (2018 est.)
permanent crops:
0.1% (2018 est.)
permanent pasture:
65.9% (2018 est.)
forest:
1.5% (2018 est.)
other:
22.4% (2018 est.)
Urbanization:
urban population:
30.4% of total population (2023)
rate of urbanization:
2.77% annual rate of change (2020-25 est.)
Food insecurity:
severe localized food insecurity: due to poor harvests and increased food prices -
according to the latest national food security assessment, 22% of the rural population are expected to face acute food insecurity between October 2022 and March 2023, compared to 15% between July and September 2022; the forecasted proportion translates into 320,000 people in rural areas, while an additional 201,000 people in urban areas are foreseen to also need assistance; the foreseen increase of acute food insecurity levels is primarily due to the reduced harvest, high food prices in basic food and non-food commodities and a slow recovery of households’ income reflecting a downturn in economic growth; harvesting of the 2022 main-season summer cereal crops, mostly maize and sorghum, is complete; production of maize, the main cereal staple, is about one-third of the average, while the sorghum output is almost negligible; the poor harvest was primarily due to torrential rainfalls during January and February 2022, which caused localized flooding and resulted in crop losses (2022)
Revenue from forest resources:
3.34% of GDP (2018 est.)
comparison ranking:
22
Revenue from coal:
0% of GDP (2018 est.)
comparison ranking:
96
Air pollutants:
particulate matter emissions:
17.6 micrograms per cubic meter (2019 est.)
carbon dioxide emissions:
2.51 megatons (2016 est.)
methane emissions:
2.56 megatons (2020 est.)
Waste and recycling:
municipal solid waste generated annually:
73,457 tons (2006 est.)
Major rivers (by length in km):
Orange river source (shared with South Africa and Namibia [m]) - 2,092 km
note
– [s] after country name indicates river source; [m] after country name indicates river mouth
Major watersheds (area sq km): Atlantic Ocean drainage:
Orange (941,351 sq km)
Total water withdrawal:
municipal:
20 million cubic meters (2020 est.)
industrial:
20 million cubic meters (2020 est.)
agricultural:
3.8 million cubic meters (2017 est.)
Total renewable water resources:
3.02 billion cubic meters (2020 est.)','a591661502506b724405b87768c411085a4cfbb8ce07b79fdd6624733149a642','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c779044a1c39bd881d72b7bce6e981797f9e920c54b69cb27414b1d10cc8741d',2025,'LR','Liberia','environment',40,'Environment - current issues:
tropical rain forest deforestation; soil erosion; loss of biodiversity; hunting of endangered species for bushmeat; pollution of coastal waters from oil residue and raw sewage; pollution of rivers from industrial run-off; burning and dumping of household waste
Environment - international agreements:
party to:
Biodiversity, Climate Change, Climate Change-Kyoto Protocol, Climate Change-Paris Agreement, Comprehensive Nuclear Test Ban, Desertification, Endangered Species, Hazardous Wastes, Law of the Sea, Nuclear Test Ban, Ozone Layer Protection, Ship Pollution, Tropical Timber 2006, Wetlands, Whaling
signed, but not ratified:
Environmental Modification, Marine Life Conservation
Climate:
tropical; hot, humid; dry winters with hot days and cool to cold nights; wet, cloudy summers with frequent heavy showers
Land use:
agricultural land:
28.1% (2018 est.)
arable land:
5.2% (2018 est.)
permanent crops:
2.1% (2018 est.)
permanent pasture:
20.8% (2018 est.)
forest:
44.6% (2018 est.)
other:
27.3% (2018 est.)
Urbanization:
urban population:
53.6% of total population (2023)
rate of urbanization:
3.41% annual rate of change (2015-20 est.)
Food insecurity:
severe localized food insecurity: due to high food prices and economic downturn -
levels of acute food insecurity are expected to increase in 2023 associated with high food prices due to high international commodity prices and elevated transportation costs, exacerbated by the unfolding effects of the war in Ukraine on international trade and commodity prices; food availability and access are likely to remain limited by high food prices and below-average imports; an expected further slowdown in economic domestic growth in 2023 is likely to compound food insecurity conditions for the most vulnerable households; in the June to August 2023 lean season period, over 531,000 people are projected to face acute food insecurity (2023)
Revenue from forest resources:
13.27% of GDP (2018 est.)
comparison ranking:
2
Revenue from coal:
0% of GDP (2018 est.)
comparison ranking:
151
Air pollutants:
particulate matter emissions:
35.8 micrograms per cubic meter (2019 est.)
carbon dioxide emissions:
1.39 megatons (2016 est.)
methane emissions:
6.56 megatons (2020 est.)
Waste and recycling:
municipal solid waste generated annually:
564,467 tons (2007 est.)
Total water withdrawal:
municipal:
80 million cubic meters (2020 est.)
industrial:
50 million cubic meters (2020 est.)
agricultural:
10 million cubic meters (2020 est.)
Total renewable water resources:
232 billion cubic meters (2020 est.)','e5a7f4f96e58d7402a0779b55e6915a3e774f16be0dae5a3d55aacb71dbe8032','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c50d675b616bbac45517d23a79af5a8fe44825b09045a034bfa6d58a2a88bc06',2025,'LY','Libya','environment',4,'Environment - current issues:
desertification; limited natural freshwater resources; the Great Manmade River Project, the largest water development scheme in the world, brings water from large aquifers under the Sahara to coastal cities; water pollution is a significant problem; the combined impact of sewage, oil byproducts, and industrial waste threatens Libya’s coast and the Mediterranean Sea
Environment - international agreements:
party to:
Biodiversity, Climate Change, Climate Change-Kyoto Protocol, Comprehensive Nuclear Test Ban, Desertification, Endangered Species, Hazardous Wastes, Marine Dumping-London Convention, Nuclear Test Ban, Ozone Layer Protection, Ship Pollution, Wetlands
signed, but not ratified:
Climate Change-Paris Agreement, Law of the Sea
Climate:
Mediterranean along coast; dry, extreme desert interior
Land use:
agricultural land:
8.8% (2018 est.)
arable land:
1% (2018 est.)
permanent crops:
0.2% (2018 est.)
permanent pasture:
7.6% (2018 est.)
forest:
0.1% (2018 est.)
other:
91.1% (2018 est.)
Urbanization:
urban population:
81.6% of total population (2023)
rate of urbanization:
1.45% annual rate of change (2020-25 est.)
Food insecurity:
severe localized food insecurity: due to civil insecurity, economic and political instability, and high food prices -
an estimated 800,000 people, 10% of the population, need humanitarian assistance, of which 500,000 require food assistance; the country relies heavily on imports (up to 90%) to cover its cereal consumption requirements (mostly wheat for human consumption and barley for feed); between 2016 and 2020, the country sourced over 30% of its wheat imports from Ukraine, and 20% from the Russian Federation; almost 65% of total maize imports of 650,000 mt, and 50% of total barley imports of 1 million mt originated from Ukraine, making the Libya vulnerable to disruptions in shipments from the Black Sea region (2022)
Revenue from forest resources:
0.06% of GDP (2018 est.)
comparison ranking:
124
Revenue from coal:
0% of GDP (2018 est.)
comparison ranking:
97
Air pollutants:
particulate matter emissions:
29.84 micrograms per cubic meter (2019 est.)
carbon dioxide emissions:
50.56 megatons (2016 est.)
methane emissions:
45.76 megatons (2020 est.)
Waste and recycling:
municipal solid waste generated annually:
2,147,596 tons (2011 est.)
Major watersheds (area sq km): Internal (endorheic basin) drainage:
Lake Chad (2,497,738 sq km)
Major aquifers:
Nubian Aquifer System, North Western Sahara Aquifer System, Murzuk-Djado Basin
Total water withdrawal:
municipal:
700 million cubic meters (2020 est.)
industrial:
280 million cubic meters (2020 est.)
agricultural:
4.85 billion cubic meters (2020 est.)
Total renewable water resources:
700 million cubic meters (2020 est.)','4780bdb9d6b562d73bc755e6419c50acfb3082a04d523e49608e1fe30965b612','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('78cc09fb45da6338b089266012adc3b00f9c963bb28d9758b658ea112054658b',2025,'LI','Liechtenstein','environment',16,'Environment - current issues:
some air pollution generated locally, some carried over from surrounding countries
Environment - international agreements:
party to:
Air Pollution, Air Pollution-Heavy Metals, Air Pollution-Nitrogen Oxides, Air Pollution-Persistent Organic Pollutants, Air Pollution-Sulphur 85, Air Pollution-Sulphur 94, Air Pollution-Volatile Organic Compounds, Biodiversity, Climate Change, Climate Change-Kyoto Protocol, Climate Change-Paris Agreement, Comprehensive Nuclear Test Ban, Desertification, Endangered Species, Hazardous Wastes, Ozone Layer Protection, Wetlands
signed, but not ratified:
Air Pollution-Multi-effect Protocol, Law of the Sea
Climate:
continental; cold, cloudy winters with frequent snow or rain; cool to moderately warm, cloudy, humid summers
Land use:
agricultural land:
37.6% (2018 est.)
arable land:
18.8% (2018 est.)
permanent crops:
0% (2018 est.)
permanent pasture:
18.8% (2018 est.)
forest:
43.1% (2018 est.)
other:
19.3% (2018 est.)
Urbanization:
urban population:
14.6% of total population (2023)
rate of urbanization:
1.15% annual rate of change (2020-25 est.)
Revenue from forest resources:
0% of GDP (2017 est.)
comparison ranking:
184
Air pollutants:
carbon dioxide emissions:
0.05 megatons (2016 est.)
methane emissions:
0.02 megatons (2020 est.)
Waste and recycling:
municipal solid waste generated annually:
32,382 tons (2015 est.)
municipal solid waste recycled annually:
20,919 tons (2015 est.)
percent of municipal solid waste recycled:
64.6% (2015 est.)
Major watersheds (area sq km): Atlantic Ocean drainage:
Rhine-Maas (198,735 sq km)
Total water withdrawal:
municipal:
10 million cubic meters (2020 est.)
Total renewable water resources:
0 cubic meters (2017 est.)','5fc9e143d2c0c62252adb63230114dfde898c962a75ad14bd23d8220625e28fe','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8aa2df7e863c2ab2a1c69ff09e6d62e2f3e689d69a3cc35593fb3d34499854ec',2025,'LT','Lithuania','environment',27,'Environment - current issues:
water pollution; air pollution; deforestation; threatened animal and plant species; chemicals and waste materials released into the environment contaminate soil and groundwater; soil degradation and erosion
Environment - international agreements:
party to:
Air Pollution, Air Pollution-Heavy Metals, Air Pollution-Multi-effect Protocol, Air Pollution-Nitrogen Oxides, Air Pollution-Persistent Organic Pollutants, Air Pollution-Sulphur 85, Air Pollution-Sulphur 94, Air Pollution-Volatile Organic Compounds, Biodiversity, Climate Change, Climate Change-Kyoto Protocol, Climate Change-Paris Agreement, Comprehensive Nuclear Test Ban, Desertification, Endangered Species, Environmental Modification, Hazardous Wastes, Law of the Sea, Ozone Layer Protection, Ship Pollution, Tropical Timber 2006, Wetlands, Whaling
signed, but not ratified:
none of the selected agreements
Climate:
transitional, between maritime and continental; wet, moderate winters and summers
Land use:
agricultural land:
44.8% (2018 est.)
arable land:
34.9% (2018 est.)
permanent crops:
0.5% (2018 est.)
permanent pasture:
9.4% (2018 est.)
forest:
34.6% (2018 est.)
other:
20.6% (2018 est.)
Urbanization:
urban population:
68.7% of total population (2023)
rate of urbanization:
-0.12% annual rate of change (2020-25 est.)
Revenue from forest resources:
0.31% of GDP (2018 est.)
comparison ranking:
80
Revenue from coal:
0% of GDP (2018 est.)
comparison ranking:
141
Air pollutants:
particulate matter emissions:
10.37 micrograms per cubic meter (2019 est.)
carbon dioxide emissions:
12.96 megatons (2016 est.)
methane emissions:
3.15 megatons (2020 est.)
Waste and recycling:
municipal solid waste generated annually:
1.3 million tons (2015 est.)
municipal solid waste recycled annually:
297,960 tons (2015 est.)
percent of municipal solid waste recycled:
22.9% (2015 est.)
Major lakes (area sq km):
salt water lake(s):
Curonian Lagoon (shared with Russia) - 1,620 sq km
Total water withdrawal:
municipal:
140 million cubic meters (2020 est.)
industrial:
60 million cubic meters (2020 est.)
agricultural:
60 million cubic meters (2020 est.)
Total renewable water resources:
24.5 billion cubic meters (2020 est.)','b76bae6b570979219218e193ee02dcf39d69bb62c36e97db8321961de4a88773','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e066c69debc3978f57b55d3a80455d1b577ce1aacce3e64873698db8efb7f720',2025,'LU','Luxembourg','environment',39,'Environment - current issues:
air and water pollution in urban areas, soil pollution of farmland; unsustainable patterns of consumption (transport, energy, recreation, space) threaten biodiversity and landscapes
Environment - international agreements:
party to:
Air Pollution, Air Pollution-Heavy Metals, Air Pollution-Multi-effect Protocol, Air Pollution-Nitrogen Oxides, Air Pollution-Persistent Organic Pollutants, Air Pollution-Sulphur 85, Air Pollution-Sulphur 94, Air Pollution-Volatile Organic Compounds, Biodiversity, Climate Change, Climate Change-Kyoto Protocol, Climate Change-Paris Agreement, Comprehensive Nuclear Test Ban, Desertification, Endangered Species, Hazardous Wastes, Law of the Sea, Marine Dumping-London Convention, Marine Dumping-London Protocol, Nuclear Test Ban, Ozone Layer Protection, Ship Pollution, Tropical Timber 2006, Wetlands, Whaling
signed, but not ratified:
Environmental Modification
Climate:
modified continental with mild winters, cool summers
Land use:
agricultural land:
50.7% (2018 est.)
arable land:
24% (2018 est.)
permanent crops:
0.6% (2018 est.)
permanent pasture:
26.1% (2018 est.)
forest:
33.5% (2018 est.)
other:
15.8% (2018 est.)
Urbanization:
urban population:
92.1% of total population (2023)
rate of urbanization:
1.43% annual rate of change (2020-25 est.)
Revenue from forest resources:
0.01% of GDP (2018 est.)
comparison ranking:
155
Revenue from coal:
0% of GDP (2018 est.)
comparison ranking:
81
Air pollutants:
particulate matter emissions:
8.89 micrograms per cubic meter (2019 est.)
carbon dioxide emissions:
8.99 megatons (2016 est.)
methane emissions:
0.61 megatons (2020 est.)
Waste and recycling:
municipal solid waste generated annually:
356,000 tons (2015 est.)
municipal solid waste recycled annually:
100,997 tons (2015 est.)
percent of municipal solid waste recycled:
28.4% (2015 est.)
Major watersheds (area sq km): Atlantic Ocean drainage:
Rhine-Maas (198,735 sq km)
Total water withdrawal:
municipal:
50 million cubic meters (2020 est.)
industrial:
1.6 million cubic meters (2017 est.)
agricultural:
400,000 cubic meters (2017 est.)
Total renewable water resources:
3.5 billion cubic meters (2020 est.)','056b0b7ee118412bc8f65e24955f7fb5f823a5fbae85b137a1cb202afa49ae3e','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2466545e3b6931c133c73ccb062005a1455180c399a96558fda1713469cd96ff',2025,'MG','Madagascar','environment',6,'Environment - current issues:
erosion and soil degredation results from deforestation and overgrazing; desertification; agricultural fires; surface water contaminated with raw sewage and other organic wastes; wildlife preservation (endangered species of flora and fauna unique to the island)
Environment - international agreements:
party to:
Biodiversity, Climate Change, Climate Change-Kyoto Protocol, Climate Change-Paris Agreement, Comprehensive Nuclear Test Ban, Desertification, Endangered Species, Hazardous Wastes, Law of the Sea, Marine Dumping-London Protocol, Marine Life Conservation, Nuclear Test Ban, Ozone Layer Protection, Ship Pollution, Tropical Timber 2006, Wetlands
signed, but not ratified:
none of the selected agreements
Climate:
tropical along coast, temperate inland, arid in south
Land use:
agricultural land:
71.1% (2018 est.)
arable land:
6% (2018 est.)
permanent crops:
1% (2018 est.)
permanent pasture:
64.1% (2018 est.)
forest:
21.5% (2018 est.)
other:
7.4% (2018 est.)
Urbanization:
urban population:
40.6% of total population (2023)
rate of urbanization:
4.26% annual rate of change (2020-25 est.)
Food insecurity:
severe localized food insecurity: due to the effects of extreme weather events and slow economic recovery -
according to the latest May 2022 analysis, the prevalence of food insecurity in the southern regions is projected to peak at 2.1 million people by December 2022 until at least March 2023; overall, the number of people requiring humanitarian assistance by the end of 2022 is expected to be about 30 percent higher compared to the peak number in 2021; the poor food security situation is mainly the consequence of six consecutive poor agricultural seasons that culminated in very tight food supplies for rural households and curbed incomes from crop sales; high rates of poverty and increased prices of essential food commodities, combined with a high reliance on market supplies due to low harvests for own consumption, are also contributing to the high rates of food insecurity across the southern regions (2022)
Revenue from forest resources:
4.34% of GDP (2018 est.)
comparison ranking:
17
Revenue from coal:
0% of GDP (2018 est.)
comparison ranking:
155
Air pollutants:
particulate matter emissions:
16.02 micrograms per cubic meter (2019 est.)
carbon dioxide emissions:
3.91 megatons (2016 est.)
methane emissions:
10.14 megatons (2020 est.)
Waste and recycling:
municipal solid waste generated annually:
3,768,759 tons (2016 est.)
Total water withdrawal:
municipal:
400 million cubic meters (2020 est.)
industrial:
160 million cubic meters (2020 est.)
agricultural:
13 billion cubic meters (2020 est.)
Total renewable water resources:
337 billion cubic meters (2020 est.)','bca3a981ad1c934d49470b14c18ae635e61e736da3442397f361d3cd1696e4b5','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1858cd64fe2ce967dd1d1e4d3e3ca68d09bdd9843b25b1bed85f4c6284e7c4cb',2025,'MW','Malawi','environment',17,'Environment - current issues:
deforestation; land degradation; water pollution from agricultural runoff, sewage, industrial wastes; siltation of spawning grounds endangers fish populations; negative effects of climate change (extreme high temperatures, changing precipitation patterns)
Environment - international agreements:
party to:
Biodiversity, Climate Change, Climate Change-Kyoto Protocol, Climate Change-Paris Agreement, Comprehensive Nuclear Test Ban, Desertification, Endangered Species, Environmental Modification, Hazardous Wastes, Law of the Sea, Marine Life Conservation, Nuclear Test Ban, Ozone Layer Protection, Ship Pollution, Wetlands
signed, but not ratified:
none of the selected agreements
Climate:
sub-tropical; rainy season (November to May); dry season (May to November)
Land use:
agricultural land:
59.2% (2018 est.)
arable land:
38.2% (2018 est.)
permanent crops:
1.4% (2018 est.)
permanent pasture:
19.6% (2018 est.)
forest:
34% (2018 est.)
other:
6.8% (2018 est.)
Urbanization:
urban population:
18.3% of total population (2023)
rate of urbanization:
4.41% annual rate of change (2020-25 est.)
Food insecurity:
widespread lack of access: due to weather extremes and high food prices -
the latest analysis indicates that about 3.8 million people (20 percent of the population) are estimated to have faced high levels of acute food insecurity between January and March 2023; this figure is more than double the number in the corresponding months of 2022; high food prices are the key reason for the deterioration in food insecurity, which, in the absence of a substantial increase in incomes, are severely constraining households’ economic access to food; production shortfalls in southern districts in 2022, areas that have the highest prevalence of food insecurity, are a further contributing factor; the impact of Cyclone Freddy (February-March 2023) on southern districts, including crop losses and destruction of infrastructure as well as high food prices, are expected to aggravate food insecurity conditions in 2023 (2023)
Revenue from forest resources:
6.19% of GDP (2018 est.)
comparison ranking:
10
Revenue from coal:
0.03% of GDP (2018 est.)
comparison ranking:
37
Air pollutants:
particulate matter emissions:
18.57 micrograms per cubic meter (2019 est.)
carbon dioxide emissions:
1.3 megatons (2016 est.)
methane emissions:
11.12 megatons (2020 est.)
Waste and recycling:
municipal solid waste generated annually:
1,297,844 tons (2013 est.)
Major lakes (area sq km):
fresh water lake(s):
Lake Malawi (shared with Mozambique and Tanzania) - 22,490
salt water lake(s):
Lake Chilwa - 1,040 sq km
Major rivers (by length in km):
Zambezi (shared with Zambia [s], Angola, Zimbabwe, Namibia, Tanzania, and Mozambique [m]) - 2,740 km
note – [s] after country name indicates river source; [m] after country name indicates river mouth
Major watersheds (area sq km): Atlantic Ocean drainage:
Congo (3,730,881 sq km)
Indian Ocean drainage:
Zambezi (1,332,412 sq km)
Total water withdrawal:
municipal:
140 million cubic meters (2020 est.)
industrial:
50 million cubic meters (2020 est.)
agricultural:
1.17 billion cubic meters (2020 est.)
Total renewable water resources:
17.28 billion cubic meters (2020 est.)','91ce1e478da94ec93c8fb83d0c6db96c12ebe86c635ae56afa42e0c0a580a9e8','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7e840f54dfa708778b9482f3223863c8d1f71573d4b69238a1748d04f21ee818',2025,'MY','Malaysia','environment',28,'Environment - current issues:
air pollution from industrial and vehicular emissions; water pollution from raw sewage; deforestation; smoke/haze from Indonesian forest fires; endangered species; coastal reclamation damaging mangroves and turtle nesting sites
Environment - international agreements:
party to:
Antarctic-Environmental Protection, Antarctic Treaty, Biodiversity, Climate Change, Climate Change-Kyoto Protocol, Climate Change-Paris Agreement, Comprehensive Nuclear Test Ban, Desertification, Endangered Species, Hazardous Wastes, Law of the Sea, Marine Life Conservation, Nuclear Test Ban, Ozone Layer Protection, Ship Pollution, Tropical Timber 2006, Wetlands
signed, but not ratified:
none of the selected agreements
Climate:
tropical; annual southwest (April to October) and northeast (October to February) monsoons
Land use:
agricultural land:
23.2% (2018 est.)
arable land:
2.9% (2018 est.)
permanent crops:
19.4% (2018 est.)
permanent pasture:
0.9% (2018 est.)
forest:
62% (2018 est.)
other:
14.8% (2018 est.)
Urbanization:
urban population:
78.7% of total population (2023)
rate of urbanization:
1.87% annual rate of change (2020-25 est.)
Revenue from forest resources:
1.57% of GDP (2018 est.)
comparison ranking:
40
Revenue from coal:
0.02% of GDP (2018 est.)
comparison ranking:
45
Air pollutants:
particulate matter emissions:
21.52 micrograms per cubic meter (2019 est.)
carbon dioxide emissions:
248.29 megatons (2016 est.)
methane emissions:
51.51 megatons (2020 est.)
Waste and recycling:
municipal solid waste generated annually:
12,982,685 tons (2014 est.)
municipal solid waste recycled annually:
2,271,970 tons (2016 est.)
percent of municipal solid waste recycled:
17.5% (2016 est.)
Total water withdrawal:
municipal:
1.34 billion cubic meters (2020 est.)
industrial:
1.64 billion cubic meters (2020 est.)
agricultural:
2.51 billion cubic meters (2020 est.)
Total renewable water resources:
580 billion cubic meters (2020 est.)','aee5df9340bd03d9bf06cba1a1027d5c638830434b9c7ba7ddd66b7fc92175c3','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1d764d629e43dd3282b9fb84cbc48ce7f9090f2faa13ec6020636a81069edffc',2025,'MV','Maldives','environment',41,'Environment - current issues:
rising sea levels threaten land; depletion of freshwater aquifers threatens water supplies; inadequate sewage treatment; coral reef bleaching
Environment - international agreements:
party to:
Biodiversity, Climate Change, Climate Change-Kyoto Protocol, Climate Change-Paris Agreement, Comprehensive Nuclear Test Ban, Desertification, Endangered Species, Hazardous Wastes, Law of the Sea, Ozone Layer Protection, Ship Pollution
signed, but not ratified:
none of the selected agreements
Climate:
tropical; hot, humid; dry, northeast monsoon (November to March); rainy, southwest monsoon (June to August)
Land use:
agricultural land:
23.3% (2018 est.)
arable land:
10% (2018 est.)
permanent crops:
10% (2018 est.)
permanent pasture:
3.3% (2018 est.)
forest:
3% (2018 est.)
other:
73.7% (2018 est.)
Urbanization:
urban population:
42% of total population (2023)
rate of urbanization:
2.34% annual rate of change (2020-25 est.)
Revenue from forest resources:
0% of GDP (2018 est.)
comparison ranking:
183
Revenue from coal:
0% of GDP (2018 est.)
comparison ranking:
79
Air pollutants:
particulate matter emissions:
13 micrograms per cubic meter (2019 est.)
carbon dioxide emissions:
1.44 megatons (2016 est.)
methane emissions:
0.14 megatons (2020 est.)
Waste and recycling:
municipal solid waste generated annually:
211,506 tons (2015 est.)
Total water withdrawal:
municipal:
10 million cubic meters (2020 est.)
industrial:
300,000 cubic meters (2017 est.)
agricultural:
0 cubic meters (2017 est.)
Total renewable water resources:
30 million cubic meters (2020 est.)','3ce419c57a6454182b188a17401af922268d23dffb53469180f064d16ed506bc','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b640e87e8f0c5370ae39c58c9745dc8f5f0f9fd090f4875a1216d32c4e66677d',2025,'ML','Mali','environment',4,'Environment - current issues:
deforestation; soil erosion; desertification; loss of pasture land; inadequate supplies of potable water
Environment - international agreements:
party to:
Biodiversity, Climate Change, Climate Change-Kyoto Protocol, Climate Change-Paris Agreement, Comprehensive Nuclear Test Ban, Desertification, Endangered Species, Hazardous Wastes, Law of the Sea, Ozone Layer Protection, Tropical Timber 2006, Wetlands, Whaling
signed, but not ratified:
Nuclear Test Ban
Climate:
subtropical to arid; hot and dry (February to June); rainy, humid, and mild (June to November); cool and dry (November to February)
Land use:
agricultural land:
34.1% (2018 est.)
arable land:
5.6% (2018 est.)
permanent crops:
0.1% (2018 est.)
permanent pasture:
28.4% (2018 est.)
forest:
10.2% (2018 est.)
other:
55.7% (2018 est.)
Urbanization:
urban population:
46.2% of total population (2023)
rate of urbanization:
4.57% annual rate of change (2020-25 est.)
Food insecurity:
severe localized food insecurity:
due to civil insecurity and high food prices - according to the latest analysis, about 1.26 million people are projected to face acute food insecurity during the June to August 2023 lean season period; in total however, the number of food insecure is lower in 2023 compared to 2022; food insecurity conditions are primarily underpinned by the impact of the conflict in central and northern areas, which has caused the displacement of over 375,000 people, as of April 2023; persistent high food prices affect vulnerable households across the country, but limit in particular the food access of people in conflict-affected areas due to market disruptions and limited access to sources of income and humanitarian assistance
(2023)
Revenue from forest resources:
2.02% of GDP (2018 est.)
comparison ranking:
35
Revenue from coal:
0% of GDP (2018 est.)
comparison ranking:
115
Air pollutants:
particulate matter emissions:
38.55 micrograms per cubic meter (2019 est.)
carbon dioxide emissions:
3.18 megatons (2016 est.)
methane emissions:
19.16 megatons (2020 est.)
Waste and recycling:
municipal solid waste generated annually:
1,937,354 tons (2012 est.)
Major lakes (area sq km):
fresh water lake(s):
Lac Faguibine - 590 sq km
note - the Niger River is the only source of water for the lake; in recent years the lake is dry
Major rivers (by length in km):
Niger (shared with Guinea [s], Niger, and Nigeria [m]) - 4,200 km; Senegal (shared with Guinea [s], Senegal, and Mauritania [m]) - 1,641 km
note – [s] after country name indicates river source; [m] after country name indicates river mouth
Major watersheds (area sq km): Atlantic Ocean drainage:
Niger (2,261,741 sq km), Senegal (456,397 sq km), Volta (410,991 sq km)
Major aquifers:
Lullemeden-Irhazer Basin, Taodeni-Tanezrouft Basin
Total water withdrawal:
municipal:
110 million cubic meters (2020 est.)
industrial:
4 million cubic meters (2020 est.)
agricultural:
5.08 billion cubic meters (2020 est.)
Total renewable water resources:
120 billion cubic meters (2020 est.)','9a12bb77e5299a8b2273ff6407bae0845f81cb75ab39f521b13d8cca0a1e1351','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9f2169dd54338a864a18780543451554eeffffc74851ca5ff95ba0d1cc8777ee',2025,'MT','Malta','environment',16,'Environment - current issues:
limited natural freshwater resources; increasing reliance on desalination; deforestation; wildlife preservation
Environment - international agreements:
party to:
Air Pollution, Biodiversity, Climate Change, Climate Change-Kyoto Protocol, Climate Change-Paris Agreement, Comprehensive Nuclear Test Ban, Desertification, Endangered Species, Hazardous Wastes, Law of the Sea, Marine Dumping-London Convention, Nuclear Test Ban, Ozone Layer Protection, Ship Pollution, Tropical Timber 2006, Wetlands
signed, but not ratified:
none of the selected agreements
Climate:
Mediterranean; mild, rainy winters; hot, dry summers
Land use:
agricultural land:
32.3% (2018 est.)
arable land:
28.4% (2018 est.)
permanent crops:
3.9% (2018 est.)
permanent pasture:
0% (2018 est.)
forest:
0.9% (2018 est.)
other:
66.8% (2018 est.)
Urbanization:
urban population:
94.9% of total population (2023)
rate of urbanization:
0.28% annual rate of change (2020-25 est.)
Air pollutants:
particulate matter emissions:
12.93 micrograms per cubic meter (2019 est.)
carbon dioxide emissions:
1.34 megatons (2016 est.)
methane emissions:
0.2 megatons (2020 est.)
Waste and recycling:
municipal solid waste generated annually:
269,000 tons (2015 est.)
municipal solid waste recycled annually:
17,996 tons (2015 est.)
percent of municipal solid waste recycled:
6.7% (2015 est.)
Total water withdrawal:
municipal:
40 million cubic meters (2020 est.)
industrial:
1 million cubic meters (2020 est.)
agricultural:
20 million cubic meters (2020 est.)
Total renewable water resources:
50 million cubic meters (2020 est.)','5b8ea3ad3835de95fb1421f3cdba6305c89d754352e0e2f34921585e7152255c','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('85f76063c7ee8eadf5ed857a9304a8956296f0f96c357a30dc1c0839065a3d77',2025,'MH','Marshall Islands','environment',28,'Environment - current issues:
inadequate supplies of potable water; pollution of Majuro lagoon from household waste and discharges from fishing vessels; sea level rise
Environment - international agreements:
party to:
Biodiversity, Climate Change, Climate Change-Kyoto Protocol, Climate Change-Paris Agreement, Comprehensive Nuclear Test Ban, Desertification, Hazardous Wastes, Law of the Sea, Marine Dumping-London Protocol, Ozone Layer Protection, Ship Pollution, Wetlands, Whaling
signed, but not ratified:
none of the selected agreements
Climate:
tropical; hot and humid; wet season May to November; islands border typhoon belt
Land use:
agricultural land:
50.7% (2018 est.)
arable land:
7.8% (2018 est.)
permanent crops:
31.2% (2018 est.)
permanent pasture:
11.7% (2018 est.)
forest:
49.3% (2018 est.)
other:
0% (2018 est.)
Urbanization:
urban population:
78.9% of total population (2023)
rate of urbanization:
0.61% annual rate of change (2020-25 est.)
Revenue from forest resources:
0% of GDP (2018 est.)
comparison ranking:
187
Air pollutants:
particulate matter emissions:
7.21 micrograms per cubic meter (2019 est.)
carbon dioxide emissions:
0.14 megatons (2016 est.)
methane emissions:
0.03 megatons (2020 est.)
Waste and recycling:
municipal solid waste generated annually:
8,614 tons (2013 est.)
municipal solid waste recycled annually:
2,653 tons (2007 est.)
percent of municipal solid waste recycled:
30.8% (2007 est.)
Total renewable water resources:
0 cubic meters (2017 est.)','a51b174dd4c67878c350f428c2795fe6fc943c5f3e5c826a0f289c4ebec2c4e7','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b86b45941b3c17be542b8299dab57b11e920840f2211f79a48947a21f4524fa2',2025,'MR','Mauritania','environment',39,'Environment - current issues:
overgrazing, deforestation, and soil erosion aggravated by drought are contributing to desertification; limited natural freshwater resources away from the Senegal, which is the only perennial river; locust infestation
Environment - international agreements:
party to:
Biodiversity, Climate Change, Climate Change-Kyoto Protocol, Climate Change-Paris Agreement, Comprehensive Nuclear Test Ban, Desertification, Endangered Species, Hazardous Wastes, Law of the Sea, Nuclear Test Ban, Ozone Layer Protection, Ship Pollution, Wetlands, Whaling
signed, but not ratified:
none of the selected agreements
Climate:
desert; constantly hot, dry, dusty
Land use:
agricultural land:
38.5% (2018 est.)
arable land:
0.4% (2018 est.)
permanent crops:
0% (2018 est.)
permanent pasture:
38.1% (2018 est.)
forest:
0.2% (2018 est.)
other:
61.3% (2018 est.)
Urbanization:
urban population:
57.7% of total population (2023)
rate of urbanization:
3.84% annual rate of change (2020-25 est.)
Food insecurity:
widespread lack of access: due to high food prices -
according to the latest analysis, nearly 695,000 people are projected to be in need of humanitarian assistance during the June to August 2023 lean season; this would be an improvement compared to the previous year, mostly due to the substantial cereal production increase in 2022; high food prices continue to worsen food security, while flooding in 2022, which affected about 54,000 people, has further aggravated the conditions of vulnerable households (2023)
Revenue from forest resources:
1.3% of GDP (2018 est.)
comparison ranking:
48
Revenue from coal:
0% of GDP (2018 est.)
comparison ranking:
174
Air pollutants:
particulate matter emissions:
41.98 micrograms per cubic meter (2019 est.)
carbon dioxide emissions:
2.74 megatons (2016 est.)
methane emissions:
6.16 megatons (2020 est.)
Waste and recycling:
municipal solid waste generated annually:
454,000 tons (2009 est.)
municipal solid waste recycled annually:
36,320 tons (2009 est.)
percent of municipal solid waste recycled:
8% (2009 est.)
Major rivers (by length in km):
Senegal river mouth (shared with Guinea [s], Senegal and Mali) - 1,641 km
note – [s] after country name indicates river source; [m] after country name indicates river mouth
Major watersheds (area sq km): Atlantic Ocean drainage:
Niger (2,261,741 sq km), Senegal (456,397 sq km)
Major aquifers:
Senegalo-Mauritanian Basin, Taodeni-Tanzerouft Basin
Total water withdrawal:
municipal:
100 million cubic meters (2020 est.)
industrial:
30 million cubic meters (2020 est.)
agricultural:
1.2 billion cubic meters (2020 est.)
Total renewable water resources:
11.4 billion cubic meters (2020 est.)','d7444f17c6f939ddc40fd48514e50266535c9ad75090d8f021ce3cbdf728da0c','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3b2e11084fe29b29bdc0c95cb457a82ac78e58fbad69a0308d2fe996965cb209',2025,'MU','Mauritius','environment',51,'Environment - current issues:
water pollution, degradation of coral reefs; soil erosion; wildlife preservation; solid waste disposal
Environment - international agreements:
party to:
Antarctic-Marine Living Resources, Biodiversity, Climate Change, Climate Change-Kyoto Protocol, Climate Change-Paris Agreement, Desertification, Endangered Species, Environmental Modification, Hazardous Wastes, Law of the Sea, Marine Life Conservation, Nuclear Test Ban, Ozone Layer Protection, Ship Pollution, Wetlands
signed, but not ratified:
none of the selected agreements
Climate:
tropical, modified by southeast trade winds; warm, dry winter (May to November); hot, wet, humid summer (November to May)
Land use:
agricultural land:
43.8% (2018 est.)
arable land:
38.4% (2018 est.)
permanent crops:
2% (2018 est.)
permanent pasture:
3.4% (2018 est.)
forest:
17.3% (2018 est.)
other:
38.9% (2018 est.)
Urbanization:
urban population:
40.9% of total population (2023)
rate of urbanization:
0.28% annual rate of change (2020-25 est.)
Revenue from forest resources:
0% of GDP (2018 est.)
comparison ranking:
171
Revenue from coal:
0% of GDP (2018 est.)
comparison ranking:
77
Air pollutants:
particulate matter emissions:
10.48 micrograms per cubic meter (2019 est.)
carbon dioxide emissions:
4.35 megatons (2016 est.)
methane emissions:
2.06 megatons (2020 est.)
Waste and recycling:
municipal solid waste generated annually:
438,000 tons (2016 est.)
Total water withdrawal:
municipal:
290 million cubic meters (2020 est.)
industrial:
10 million cubic meters (2020 est.)
agricultural:
310 million cubic meters (2020 est.)
Total renewable water resources:
2.75 billion cubic meters (2020 est.)','595b79d5eb63b761fd79cff97c66e0ead441a2142eaa0f946d00842c09b1b79f','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c1e005bb33e6a2ae1714d9abee6c69fd0fd82d71254d264b9d5a108dc6ebceeb',2025,'MX','Mexico','environment',4,'Environment - current issues:
scarcity of hazardous waste disposal facilities; rural to urban migration; natural freshwater resources scarce and polluted in north, inaccessible and poor quality in center and extreme southeast; raw sewage and industrial effluents polluting rivers in urban areas; deforestation; widespread erosion; desertification; deteriorating agricultural lands; serious air and water pollution in the national capital and urban centers along US-Mexico border; land subsidence in Valley of Mexico caused by groundwater depletion
note:
the government considers the lack of clean water and deforestation national security issues
Environment - international agreements:
party to:
Biodiversity, Climate Change, Climate Change-Kyoto Protocol, Climate Change-Paris Agreement, Comprehensive Nuclear Test Ban, Desertification, Endangered Species, Hazardous Wastes, Law of the Sea, Marine Dumping-London Convention, Marine Dumping-London Protocol, Marine Life Conservation, Nuclear Test Ban, Ozone Layer Protection, Ship Pollution, Tropical Timber 2006, Wetlands, Whaling
signed, but not ratified:
none of the selected agreements
Climate:
varies from tropical to desert
Land use:
agricultural land:
54.9% (2018 est.)
arable land:
11.8% (2018 est.)
permanent crops:
1.4% (2018 est.)
permanent pasture:
41.7% (2018 est.)
forest:
33.3% (2018 est.)
other:
11.8% (2018 est.)
Urbanization:
urban population:
81.6% of total population (2023)
rate of urbanization:
1.4% annual rate of change (2020-25 est.)
Revenue from forest resources:
0.1% of GDP (2018 est.)
comparison ranking:
111
Revenue from coal:
0.03% of GDP (2018 est.)
comparison ranking:
36
Air pollutants:
particulate matter emissions:
17.83 micrograms per cubic meter (2019 est.)
carbon dioxide emissions:
486.41 megatons (2016 est.)
methane emissions:
135.77 megatons (2020 est.)
Waste and recycling:
municipal solid waste generated annually:
53.1 million tons (2015 est.)
municipal solid waste recycled annually:
2.655 million tons (2013 est.)
percent of municipal solid waste recycled:
5% (2013 est.)
Major lakes (area sq km):
fresh water lake(s):
Laguna de Chapala - 1,140 sq km
salt water lake(s):
Laguna de Terminos - 1,550 sq km
Major rivers (by length in km):
Rio Grande river mouth (shared with US [s]) - 3,057 km; Colorado river mouth (shared with US [s]) - 2,333 km
note – [s] after country name indicates river source; [m] after country name indicates river mouth
Major watersheds (area sq km): Atlantic Ocean drainage:
(Gulf of Mexico)
Rio Grande/Bravo (607,965 sq km)
Pacific Ocean drainage:
(Gulf of California)
Colorado (703,148 sq km)
Major aquifers:
Atlantic and Gulf Coastal Plains Aquifer
Total water withdrawal:
municipal:
13.17 billion cubic meters (2020 est.)
industrial:
8.56 billion cubic meters (2020 est.)
agricultural:
67.83 billion cubic meters (2020 est.)
Total renewable water resources:
461.89 billion cubic meters (2020 est.)','e84c62dca3eeb756cd95e9f50aef5866fd1b76d6a1aeb8cdddc57de483724ab2','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b341ba6c56353672b8a13355b7aa7eecb7f5209b4f8ad30aa639aad9be8cd3bb',2025,'FM','Micronesia, Federated States of','environment',16,'Environment - current issues:
overfishing; sea level rise due to climate change threatens land; water pollution, toxic pollution from mining; solid waste disposal
Environment - international agreements:
party to:
Biodiversity, Climate Change, Climate Change-Kyoto Protocol, Climate Change-Paris Agreement, Comprehensive Nuclear Test Ban, Desertification, Hazardous Wastes, Law of the Sea, Ozone Layer Protection
signed, but not ratified:
none of the selected agreements
Climate:
tropical; heavy year-round rainfall, especially in the eastern islands; located on southern edge of the typhoon belt with occasionally severe damage
Land use:
agricultural land:
25.5% (2018 est.)
arable land:
2.3% (2018 est.)
permanent crops:
19.7% (2018 est.)
permanent pasture:
3.5% (2018 est.)
forest:
74.5% (2018 est.)
other:
0% (2018 est.)
Urbanization:
urban population:
23.4% of total population (2023)
rate of urbanization:
1.52% annual rate of change (2020-25 est.)
Revenue from forest resources:
0.02% of GDP (2018 est.)
comparison ranking:
141
Air pollutants:
particulate matter emissions:
7.79 micrograms per cubic meter (2019 est.)
carbon dioxide emissions:
0.14 megatons (2016 est.)
methane emissions:
0.02 megatons (2020 est.)
Waste and recycling:
municipal solid waste generated annually:
26,040 tons (2016 est.)
Total renewable water resources:
0 cubic meters (2017 est.)','8a3d8d5b78e34857e179a02d1ccb17540fcc71549b6fbaad95035ec7595a5f92','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('81bfc9aefb289912bbe00c54588546832be40376b5a18a3ae79dfe57e6506f79',2025,'FM','Micronesia, Federated States of','environment',27,'Environment - current issues:
heavy use of agricultural chemicals has contaminated soil and groundwater; extensive soil erosion and declining soil fertility from poor farming methods
Environment - international agreements:
party to:
Air Pollution, Air Pollution-Heavy Metals, Air Pollution-Persistent Organic Pollutants, Biodiversity, Climate Change, Climate Change-Kyoto Protocol, Climate Change-Paris Agreement, Comprehensive Nuclear Test Ban, Desertification, Endangered Species, Hazardous Wastes, Law of the Sea, Ozone Layer Protection, Ship Pollution, Wetlands
signed, but not ratified:
Air Pollution-Multi-effect Protocol
Climate:
moderate winters, warm summers
Land use:
agricultural land:
74.9% (2018 est.)
arable land:
55.1% (2018 est.)
permanent crops:
9.1% (2018 est.)
permanent pasture:
10.7% (2018 est.)
forest:
11.9% (2018 est.)
other:
13.2% (2018 est.)
Urbanization:
urban population:
43.4% of total population (2023)
rate of urbanization:
0.09% annual rate of change (2020-25 est.)
Revenue from forest resources:
0.26% of GDP (2018 est.)
comparison ranking:
86
Revenue from coal:
0% of GDP (2018 est.)
comparison ranking:
146
Air pollutants:
particulate matter emissions:
12.37 micrograms per cubic meter (2019 est.)
carbon dioxide emissions:
5.12 megatons (2016 est.)
methane emissions:
3.29 megatons (2020 est.)
Waste and recycling:
municipal solid waste generated annually:
3,981,200 tons (2015 est.)
municipal solid waste recycled annually:
609,920 tons (2015 est.)
percent of municipal solid waste recycled:
15.3% (2015 est.)
Major rivers (by length in km):
Dunărea (Danube) (shared with Germany [s], Austria, Slovakia, Czechia, Hungary, Croatia, Serbia, Bulgaria, Ukraine, and Romania [m]) - 2,888 km; Nistru (Dniester) (shared with Ukraine [s/m]) - 1,411 km note – [s] after country name indicates river source; [m] after country name indicates river mouth
Major watersheds (area sq km): Atlantic Ocean drainage:
(Black Sea)
Danube (795,656 sq km)
Total water withdrawal:
municipal:
160 million cubic meters (2020 est.)
industrial:
580 million cubic meters (2020 est.)
agricultural:
60 million cubic meters (2020 est.)
Total renewable water resources:
12.27 billion cubic meters (2020 est.)','c9cf8f916442451d2cc87b0a2f04807ee31d019ff103411b4c1e9fb71fb41ae5','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('965b5b63f98c1dfa04337ffa21799ca8547f43c4e720405d724b4f6a80870750',2025,'MC','Monaco','environment',38,'Environment - current issues:
no serious issues; actively monitors pollution levels in air and water
Environment - international agreements:
party to:
Air Pollution, Air Pollution-Heavy Metals, Air Pollution-Sulphur 94, Air Pollution-Volatile Organic Compounds, Antarctic-Environmental Protection, Antarctic Treaty, Biodiversity, Climate Change, Climate Change-Kyoto Protocol, Climate Change-Paris Agreement, Comprehensive Nuclear Test Ban, Desertification, Endangered Species, Hazardous Wastes, Law of the Sea, Marine Dumping-London Convention, Ozone Layer Protection, Ship Pollution, Wetlands, Whaling
signed, but not ratified:
none of the selected agreements
Climate:
Mediterranean with mild, wet winters and hot, dry summers
Land use:
agricultural land:
1% (2018 est.)
arable land:
0% (2018 est.)
permanent crops:
1% (2018 est.)
permanent pasture:
0% (2018 est.)
forest:
0% (2018 est.)
other:
99% (2018 est.)
Urbanization:
urban population:
100% of total population (2023)
rate of urbanization:
0.5% annual rate of change (2020-25 est.)
Revenue from forest resources:
0% of GDP (2018 est.)
comparison ranking:
196
Air pollutants:
particulate matter emissions:
9.21 micrograms per cubic meter (2019 est.)
methane emissions:
0.05 megatons (2020 est.)
Waste and recycling:
municipal solid waste generated annually:
46,000 tons (2012 est.)
municipal solid waste recycled annually:
2,484 tons (2012 est.)
percent of municipal solid waste recycled:
5.4% (2012 est.)
Total water withdrawal:
municipal:
10 million cubic meters (2020 est.)
industrial:
0 cubic meters (2017 est.)
agricultural:
0 cubic meters (2017 est.)','768ed209417904289f76b6172269a2066d80a5f9afec3608f8a8e4bc15f03859','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('999116f7c5d98ffb592101b0e158a274297ab814908b5ca188195c3b3f531435',2025,'MN','Mongolia','environment',49,'Environment - current issues:
limited natural freshwater resources in some areas; the burning of soft coal in power plants and the lack of enforcement of environmental laws leads to air pollution in Ulaanbaatar; deforestation and overgrazing increase soil erosion from wind and rain; water pollution; desertification and mining activities have a deleterious effect on the environment
Environment - international agreements:
party to:
Antarctic Treaty, Biodiversity, Climate Change, Climate Change-Kyoto Protocol, Climate Change-Paris Agreement, Comprehensive Nuclear Test Ban, Desertification, Endangered Species, Environmental Modification, Hazardous Wastes, Law of the Sea, Nuclear Test Ban, Ozone Layer Protection, Ship Pollution, Wetlands, Whaling
signed, but not ratified:
none of the selected agreements
Climate:
desert; continental (large daily and seasonal temperature ranges)
Land use:
agricultural land:
73% (2018 est.)
arable land:
0.4% (2018 est.)
permanent crops:
0% (2018 est.)
permanent pasture:
72.6% (2018 est.)
forest:
7% (2018 est.)
other:
20% (2018 est.)
Urbanization:
urban population:
69.1% of total population (2023)
rate of urbanization:
1.4% annual rate of change (2020-25 est.)
Revenue from forest resources:
0.14% of GDP (2018 est.)
comparison ranking:
104
Revenue from coal:
8.62% of GDP (2018 est.)
comparison ranking:
1
Air pollutants:
particulate matter emissions:
41.3 micrograms per cubic meter (2019 est.)
carbon dioxide emissions:
25.37 megatons (2016 est.)
methane emissions:
13.72 megatons (2020 est.)
Waste and recycling:
municipal solid waste generated annually:
2.9 million tons (2016 est.)
Major lakes (area sq km):
fresh water lake(s):
Hovsgol Nuur - 2,620 sq km; Har Us Nuur - 1,760 sq km;
salt water lake(s):
Uvs Nuur - 3,350 sq km; Hyargas Nuur - 1,360 sq km
Major rivers (by length in km):
Amur (shared with China [s] and Russia [m]) - 4,444 km
note – [s] after country name indicates river source; [m] after country name indicates river mouth
Total water withdrawal:
municipal:
50 million cubic meters (2020 est.)
industrial:
170 million cubic meters (2020 est.)
agricultural:
250 million cubic meters (2020 est.)
Total renewable water resources:
34.8 billion cubic meters (2020 est.)','6f9b652ce5069bbbb6fb1708ea0b809406683545bbf4bac5d7a27393f734bb8b','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('44a6ab233adcd04b3a7c8c2fb2ab28df23103f9ca3e9fd80d6168521af3689d6',2025,'ME','Montenegro','environment',4,'Environment - current issues:
pollution of coastal waters from sewage outlets, especially in tourist-related areas such as Kotor; serious air pollution in Podgorica, Pljevlja and Niksie; air pollution in Pljevlja is caused by the nearby lignite power plant and the domestic use of coal and wood for household heating
Environment - international agreements:
party to:
Air Pollution, Air Pollution-Heavy Metals, Air Pollution-Persistent Organic Pollutants, Biodiversity, Climate Change, Climate Change-Kyoto Protocol, Climate Change-Paris Agreement, Comprehensive Nuclear Test Ban, Desertification, Endangered Species, Hazardous Wastes, Law of the Sea, Marine Dumping-London Convention, Marine Life Conservation, Nuclear Test Ban, Ozone Layer Protection, Ship Pollution, Wetlands
signed, but not ratified:
none of the selected agreements
Climate:
Mediterranean climate, hot dry summers and autumns and relatively cold winters with heavy snowfalls inland
Land use:
agricultural land:
38.2% (2018 est.)
arable land:
12.9% (2018 est.)
permanent crops:
1.2% (2018 est.)
permanent pasture:
24.1% (2018 est.)
forest:
40.4% (2018 est.)
other:
21.4% (2018 est.)
Urbanization:
urban population:
68.5% of total population (2023)
rate of urbanization:
0.45% annual rate of change (2020-25 est.)
Revenue from forest resources:
0.43% of GDP (2018 est.)
comparison ranking:
70
Revenue from coal:
0.12% of GDP (2018 est.)
comparison ranking:
25
Air pollutants:
particulate matter emissions:
19.3 micrograms per cubic meter (2019 est.)
carbon dioxide emissions:
2.02 megatons (2016 est.)
methane emissions:
0.75 megatons (2020 est.)
Waste and recycling:
municipal solid waste generated annually:
332,000 tons (2015 est.)
municipal solid waste recycled annually:
17,994 tons (2015 est.)
percent of municipal solid waste recycled:
5.4% (2015 est.)
Major lakes (area sq km):
fresh water lake(s):
Lake Scutari (shared with Albania) - 400 sq km
note - largest lake in the Balkans
Major watersheds (area sq km): Atlantic Ocean drainage:
(Black Sea)
Danube (795,656 sq km)
Total water withdrawal:
municipal:
100 million cubic meters (2020 est.)
industrial:
60 million cubic meters (2020 est.)
agricultural:
1.7 million cubic meters (2017 est.)','3fb0edfa385b62c02d427b09e6527c9339b55620c907afe670cb99a19964d74f','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('41e5abd3860f3ea31e2a4296beadad7db51eb2e02e419ec6089061dfacdca84d',2025,'MS','Montserrat','environment',15,'Environment - current issues:
land erosion occurs on slopes that have been cleared for cultivation
Climate:
tropical; little daily or seasonal temperature variation
Land use:
agricultural land:
30% (2018 est.)
arable land:
20% (2018 est.)
permanent crops:
0% (2018 est.)
permanent pasture:
10% (2018 est.)
forest:
25% (2018 est.)
other:
45% (2018 est.)
Urbanization:
urban population:
9.3% of total population (2023)
rate of urbanization:
0.94% annual rate of change (2020-25 est.)','986fd4849d23bb5fd9159fdb2f352f58a3e109e923d5a957cd1a26593e5eddc9','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ca81d8d331942f8f06181a65455e79ecb85433181d400fb122196daa0460b0ed',2025,'MA','Morocco','environment',26,'Environment - current issues:
in the north, land degradation/desertification (soil erosion resulting from farming of marginal areas, overgrazing, destruction of vegetation); water and soil pollution due to dumping of industrial wastes into the ocean and inland water sources, and onto the land; in the south, desertification; overgrazing; sparse water and lack of arable land
note:
data does not include former Western Sahara
Environment - international agreements:
party to:
Biodiversity, Climate Change, Climate Change-Kyoto Protocol, Climate Change-Paris Agreement, Comprehensive Nuclear Test Ban, Desertification, Endangered Species, Hazardous Wastes, Law of the Sea, Marine Dumping-London Convention, Marine Dumping-London Protocol, Nuclear Test Ban, Ozone Layer Protection, Ship Pollution, Wetlands, Whaling
signed, but not ratified:
Environmental Modification
Climate:
Mediterranean in the north, becoming more extreme in the interior; in the south, hot, dry desert; rain is rare; cold offshore air currents produce fog and heavy dew
note:
data does not include former Western Sahara
Land use:
agricultural land:
67.5% (2018 est.)
arable land:
17.5% (2018 est.)
permanent crops:
2.9% (2018 est.)
permanent pasture:
47.1% (2018 est.)
forest:
11.5% (2018 est.)
other:
21% (2018 est.)
note:
does not include the area of the former Western Sahara, which is almost exclusively desert
Urbanization:
urban population:
65.1% of total population (2023)
rate of urbanization:
1.88% annual rate of change (2020-25 est.)
note:
data does not include former Western Sahara
Revenue from forest resources:
0.13% of GDP (2018 est.)
comparison ranking:
107
Revenue from coal:
0% of GDP (2018 est.)
comparison ranking:
80
Air pollutants:
particulate matter emissions:
13.44 micrograms per cubic meter (2019 est.)
carbon dioxide emissions:
61.28 megatons (2016 est.)
methane emissions:
17.16 megatons (2020 est.)
note:
data does not include former Western Sahara
Waste and recycling:
municipal solid waste generated annually:
6.852 million tons (2014 est.)
municipal solid waste recycled annually:
548,160 tons (2014 est.)
percent of municipal solid waste recycled:
8% (2014 est.)
note:
data does not include former Western Sahara
Major rivers (by length in km):
Draa - 1,100 km
Total water withdrawal:
municipal:
1.06 billion cubic meters (2020 est.)
industrial:
210 million cubic meters (2020 est.)
agricultural:
9.16 billion cubic meters (2020 est.)
note:
data does not include former Western Sahara
Total renewable water resources:
29 billion cubic meters (2020 est.)
note:
data does not include former Western Sahara','6999f090503dc0a2916d0dae7b15e6a59c27f54212dbb68b6f147747553770f3','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f43b61db8f41ddf290eea30e333f3c7fb4742ba148c8feed501d2721ab859cff',2025,'MZ','Mozambique','environment',39,'Environment - current issues:
increased migration of the population to urban and coastal areas with adverse environmental consequences; desertification; soil erosion; deforestation; water pollution caused by artisanal mining; pollution of surface and coastal waters; wildlife preservation (elephant poaching for ivory)
Environment - international agreements:
party to:
Biodiversity, Climate Change, Climate Change-Kyoto Protocol, Climate Change-Paris Agreement, Comprehensive Nuclear Test Ban, Desertification, Endangered Species, Hazardous Wastes, Law of the Sea, Ozone Layer Protection, Ship Pollution, Tropical Timber 2006, Wetlands
signed, but not ratified:
none of the selected agreements
Climate:
tropical to subtropical
Land use:
agricultural land:
56.3% (2018 est.)
arable land:
6.4% (2018 est.)
permanent crops:
0.3% (2018 est.)
permanent pasture:
49.6% (2018 est.)
forest:
43.7% (2018 est.)
other:
0% (2018 est.)
Urbanization:
urban population:
38.8% of total population (2023)
rate of urbanization:
4.24% annual rate of change (2020-25 est.)
Food insecurity:
severe localized food insecurity:
due to shortfall in agricultural production and economic downturn - the number of people in need of food assistance is expected to rise above the 1.86 million estimated in 2021-2022 because of three key factors; firstly, higher year-on-year prices of food and fuel are reducing households’ purchasing power, worsening their economic access to food, particularly for low-income households; secondly, the impact of extreme weather events on agricultural production in central and southern provinces in 2022 is likely to mean that farming households in the affected areas have both low food supplies from their own production and curtailed income-earning opportunities from crop sales, impinging on their food availability and economic access to food; thirdly, there has been an increase in attacks by non-state armed groups in the northern province of Cabo Delgado in 2022
(2022)
Revenue from forest resources:
6.46% of GDP (2018 est.)
comparison ranking:
9
Revenue from coal:
4.17% of GDP (2018 est.)
comparison ranking:
2
Air pollutants:
particulate matter emissions:
16.45 micrograms per cubic meter (2019 est.)
carbon dioxide emissions:
7.94 megatons (2016 est.)
methane emissions:
16.26 megatons (2020 est.)
Waste and recycling:
municipal solid waste generated annually:
2.5 million tons (2014 est.)
municipal solid waste recycled annually:
25,000 tons (2014 est.)
percent of municipal solid waste recycled:
1% (2014 est.)
Major lakes (area sq km):
fresh water lake(s):
Lake Malawi (shared with Malawi and Tanzania) - 22,490
Major rivers (by length in km):
Rio Zambeze (Zambezi) river mouth (shared with Zambia [s]), Angola, Namibia, Botswana, and Zimbabwe) - 2,740 km; Rio Limpopo river mouth (shared with South Africa [s], Botswana, and Zimbabwe) - 1,800 km
note – [s] after country name indicates river source; [m] after country name indicates river mouth
Major watersheds (area sq km): Indian Ocean drainage:
Zambezi (1,332,412 sq km)
Total water withdrawal:
municipal:
370 million cubic meters (2020 est.)
industrial:
30 million cubic meters (2020 est.)
agricultural:
1.08 billion cubic meters (2020 est.)
Total renewable water resources:
217.1 billion cubic meters (2020 est.)','f430eb4912168973a0e68d49c491cfdcc5f88359f08fe34efdbb27fee535a87e','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7f48a5034b04a4554f0b6800403fdeae597208c66847340d8fdd1a77e2bba559',2025,'NA','Namibia','environment',4,'Environment - current issues:
depletion and degradation of water and aquatic resources; desertification; land degradation; loss of biodiversity and biotic resources; wildlife poaching
Environment - international agreements:
party to:
Antarctic-Marine Living Resources, Biodiversity, Climate Change, Climate Change-Kyoto Protocol, Climate Change-Paris Agreement, Comprehensive Nuclear Test Ban, Desertification, Endangered Species, Hazardous Wastes, Law of the Sea, Ozone Layer Protection, Ship Pollution, Wetlands
signed, but not ratified:
none of the selected agreements
Climate:
desert; hot, dry; rainfall sparse and erratic
Land use:
agricultural land:
47.2% (2018 est.)
arable land:
1% (2018 est.)
permanent crops:
0% (2018 est.)
permanent pasture:
46.2% (2018 est.)
forest:
8.8% (2018 est.)
other:
44% (2018 est.)
Urbanization:
urban population:
54.9% of total population (2023)
rate of urbanization:
3.64% annual rate of change (2020-25 est.)
Food insecurity:
severe localized food insecurity: due to localized shortfalls in cereal production and rising food prices -
cereal production increased in 2022 and this is expected to have a positive impact on food security, however, rising prices of basic foods is likely to limit a more substantial improvement (2022)
Revenue from forest resources:
0.47% of GDP (2018 est.)
comparison ranking:
68
Revenue from coal:
0% of GDP (2018 est.)
comparison ranking:
124
Air pollutants:
particulate matter emissions:
11.81 micrograms per cubic meter (2019 est.)
carbon dioxide emissions:
4.23 megatons (2016 est.)
methane emissions:
10.4 megatons (2020 est.)
Waste and recycling:
municipal solid waste generated annually:
256,729 tons (1993 est.)
municipal solid waste recycled annually:
11,553 tons (2005 est.)
percent of municipal solid waste recycled:
4.5% (2005 est.)
Major rivers (by length in km):
Zambezi (shared with Zambia [s]), Angola, Botswana, Zimbabwe, and Mozambique [m]) - 2,740 km; Orange river mouth (shared with Lesotho [s], and South Africa) - 2,092 km; Okavango (shared with Angola [s], and Botswana [m]) - 1,600 km
note –
[s] after country name indicates river source; [m] after country name indicates river mouth
Major watersheds (area sq km): Atlantic Ocean drainage:
Orange (941,351 sq km)
Indian Ocean drainage:
Zambezi (1,332,412 sq km)
Internal
(endorheic basin)
drainage:
Okavango Basin (863,866 sq km)
Major aquifers:
Lower Kalahari-Stampriet Basin, Upper Kalahari-Cuvelai-Upper Zambezi Basin
Total water withdrawal:
municipal:
70 million cubic meters (2020 est.)
industrial:
10 million cubic meters (2020 est.)
agricultural:
201 million cubic meters (2020 est.)
Total renewable water resources:
39.91 billion cubic meters (2020 est.)','232fa70fb86464d3d8cbb266abd053e2f41446cb4f0d9e00879aba3bf5719262','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('962eb886f78d108fdaf9da0d8253a324ba0918d3b18e427a1dcbddb9861d739c',2025,'NR','Nauru','environment',15,'Environment - current issues:
limited natural freshwater resources, roof storage tanks that collect rainwater and desalination plants provide water; a century of intensive phosphate mining beginning in 1906 left the central 90% of Nauru a wasteland; cadmium residue, phosphate dust, and other contaminants have caused air and water pollution with negative impacts on health; climate change has brought on rising sea levels and inland water shortages
Environment - international agreements:
party to:
Biodiversity, Climate Change, Climate Change-Kyoto Protocol, Climate Change-Paris Agreement, Comprehensive Nuclear Test Ban, Desertification, Hazardous Wastes, Law of the Sea, Marine Dumping-London Convention, Ozone Layer Protection, Whaling
signed, but not ratified:
none of the selected agreements
Climate:
tropical with a monsoonal pattern; rainy season (November to February)
Land use:
agricultural land:
20% (2018 est.)
arable land:
0% (2018 est.)
permanent crops:
20% (2018 est.)
permanent pasture:
0% (2018 est.)
forest:
0% (2018 est.)
other:
80% (2018 est.)
Urbanization:
urban population:
100% of total population (2023)
rate of urbanization:
0.18% annual rate of change (2020-25 est.)
Revenue from forest resources:
0% of GDP (2018 est.)
comparison ranking:
172
Air pollutants:
particulate matter emissions:
7.4 micrograms per cubic meter (2019 est.)
carbon dioxide emissions:
0.05 megatons (2016 est.)
methane emissions:
0.01 megatons (2020 est.)
Waste and recycling:
municipal solid waste generated annually:
6,192 tons (2016 est.)
Total renewable water resources:
10 million cubic meters (2020 est.)','b3f75cee0a05a7718439c4430bdbbd50d0b68d86bf79c54da2e77c68e26078a7','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ce647cc443e5b2bcf557165b6ebe920b683a92a8a082e8e31bfda2c184db28b6',2025,'NR','Nauru','environment',26,'Environment - current issues:
some coral bleaching
Climate:
marine, tropical
Land use:
other:
100% (2018 est.)','92bcdab1adbf05a0e9faf7b605d382e4bf1772cb7b997c5daed576d3cc3c5921','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('61c5ea2be67a5f5663fe0e074f040ef647b7148fabaa9fc543322cfd29cd4825',2025,'NP','Nepal','environment',34,'Environment - current issues:
deforestation (overuse of wood for fuel and lack of alternatives); forest degradation; soil erosion; contaminated water (with human and animal wastes, agricultural runoff, and industrial effluents); unmanaged solid-waste; wildlife conservation; vehicular emissions
Environment - international agreements:
party to:
Biodiversity, Climate Change, Climate Change-Kyoto Protocol, Climate Change-Paris Agreement, Desertification, Endangered Species, Hazardous Wastes, Law of the Sea, Nuclear Test Ban, Ozone Layer Protection, Wetlands
signed, but not ratified:
Comprehensive Nuclear Test Ban, Marine Life Conservation
Climate:
varies from cool summers and severe winters in north to subtropical summers and mild winters in south
Land use:
agricultural land:
28.8% (2018 est.)
arable land:
15.1% (2018 est.)
permanent crops:
1.2% (2018 est.)
permanent pasture:
12.5% (2018 est.)
forest:
25.4% (2018 est.)
other:
45.8% (2018 est.)
Urbanization:
urban population:
21.9% of total population (2023)
rate of urbanization:
3.09% annual rate of change (2020-25 est.)
Revenue from forest resources:
0.45% of GDP (2018 est.)
comparison ranking:
69
Revenue from coal:
0% of GDP (2018 est.)
comparison ranking:
157
Air pollutants:
particulate matter emissions:
36.43 micrograms per cubic meter (2019 est.)
carbon dioxide emissions:
9.11 megatons (2016 est.)
methane emissions:
41.15 megatons (2020 est.)
Waste and recycling:
municipal solid waste generated annually:
1,768,977 tons (2016 est.)
Major watersheds (area sq km): Indian Ocean drainage:
Brahmaputra (651,335 sq km), Ganges (1,016,124 sq km), Indus (1,081,718 sq km)
Major aquifers:
Indus-Ganges-Brahmaputra Basin
Total water withdrawal:
municipal:
150 million cubic meters (2020 est.)
industrial:
30 million cubic meters (2020 est.)
agricultural:
9.32 billion cubic meters (2020 est.)
Total renewable water resources:
210.2 billion cubic meters (2020 est.)','fa291b525b1ea4b5ecbbf6019fcdcd3b5a4e0b6a497c988c660065a605ad89ba','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cdce0f2c03dce0c0d5775182e8d38f92b97679e69ebbe4cc857f3f1b37c95483',2025,'NL','Netherlands','environment',46,'Environment - current issues:
water and air pollution are significant environmental problems; pollution of the country’s rivers from industrial and agricultural chemicals, including heavy metals, organic compounds, nitrates, and phosphates; air pollution from vehicles and refining activities
Environment - international agreements:
party to:
Air Pollution, Air Pollution-Heavy Metals, Air Pollution-Multi-effect Protocol, Air Pollution-Nitrogen Oxides, Air Pollution-Persistent Organic Pollutants, Air Pollution-Sulphur 85, Air Pollution-Sulphur 94, Air Pollution-Volatile Organic Compounds, Antarctic-Environmental Protection, Antarctic-Marine Living Resources, Antarctic Treaty, Biodiversity, Climate Change, Climate Change-Kyoto Protocol, Climate Change-Paris Agreement, Comprehensive Nuclear Test Ban, Desertification, Endangered Species, Environmental Modification, Hazardous Wastes, Law of the Sea, Marine Dumping- London Convention, Marine Dumping-London Protocol, Marine Life Conservation, Nuclear Test Ban, Ozone Layer Protection, Ship Pollution, Tropical Timber 2006, Wetlands, Whaling
signed, but not ratified:
none of the selected agreements
Climate:
temperate; marine; cool summers and mild winters
Land use:
agricultural land:
55.1% (2018 est.)
arable land:
29.8% (2018 est.)
permanent crops:
1.1% (2018 est.)
permanent pasture:
24.2% (2018 est.)
forest:
10.8% (2018 est.)
other:
34.1% (2018 est.)
Urbanization:
urban population:
93.2% of total population (2023)
rate of urbanization:
0.59% annual rate of change (2020-25 est.)
Revenue from forest resources:
0.01% of GDP (2018 est.)
comparison ranking:
156
Revenue from coal:
0% of GDP (2018 est.)
comparison ranking:
160
Air pollutants:
particulate matter emissions:
10.74 micrograms per cubic meter (2019 est.)
carbon dioxide emissions:
170.78 megatons (2016 est.)
methane emissions:
17.79 megatons (2020 est.)
Waste and recycling:
municipal solid waste generated annually:
8.855 million tons (2015 est.)
municipal solid waste recycled annually:
2,179,216 tons (2015 est.)
percent of municipal solid waste recycled:
24.6% (2015 est.)
Major rivers (by length in km):
Rijn (Rhine) river mouth (shared with Switzerland [s], Germany, and France) - 1,233 km
note –
[s] after country name indicates river source; [m] after country name indicates river mouth
Major watersheds (area sq km): Atlantic Ocean drainage:
Rhine-Maas (198,735 sq km)
Total water withdrawal:
municipal:
2.05 billion cubic meters (2020 est.)
industrial:
5.94 billion cubic meters (2020 est.)
agricultural:
31 million cubic meters (2020 est.)
Total renewable water resources:
91 billion cubic meters (2020 est.)','d86fc97d2ff4aa20c52b5934d05307885903ab2c029bf2a9e4531353a545c9d3','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('51c320d32d55e4364e82bfbc77badcfb277f8cfab08f9d18070920b434fb110c',2025,'NC','New Caledonia','environment',59,'Environment - current issues:
preservation of coral reefs; prevention of invasive species; limiting erosion caused by nickel mining and forest fires
Climate:
tropical; modified by southeast trade winds; hot, humid
Land use:
agricultural land:
10.4% (2018 est.)
arable land:
0.4% (2018 est.)
permanent crops:
0.2% (2018 est.)
permanent pasture:
9.8% (2018 est.)
forest:
45.9% (2018 est.)
other:
43.7% (2018 est.)
Urbanization:
urban population:
72.7% of total population (2023)
rate of urbanization:
1.72% annual rate of change (2020-25 est.)
Air pollutants:
carbon dioxide emissions:
5.33 megatons (2016 est.)
Waste and recycling:
municipal solid waste generated annually:
108,157 tons (2016 est.)','b525a7d889b68690d5fc56da433e5448588acef12e84cc17e8b7a86e3870cec9','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('869997572aec157d8a38e7da16ae6f829173278d5f59e8d9ea14030ad0de9a1d',2025,'NZ','New Zealand','environment',4,'Environment - current issues:
water quality and availability; rapid urbanization; deforestation; soil erosion and degradation; native flora and fauna hard-hit by invasive species
Environment - international agreements:
party to:
Antarctic-Environmental Protection, Antarctic-Marine Living Resources, Antarctic Treaty, Biodiversity, Climate Change, Climate Change-Kyoto Protocol, Climate Change-Paris Agreement, Comprehensive Nuclear Test Ban, Desertification, Endangered Species, Environmental Modification, Hazardous Wastes, Law of the Sea, Marine Dumping-London Convention, Marine Dumping-London Protocol, Nuclear Test Ban, Ozone Layer Protection, Ship Pollution, Tropical Timber 2006, Wetlands, Whaling
signed, but not ratified:
Antarctic Seals, Marine Life Conservation
Climate:
temperate with sharp regional contrasts
Land use:
agricultural land:
43.2% (2018 est.)
arable land:
1.8% (2018 est.)
permanent crops:
0.3% (2018 est.)
permanent pasture:
41.1% (2018 est.)
forest:
31.4% (2018 est.)
other:
25.4% (2018 est.)
Urbanization:
urban population:
87% of total population (2023)
rate of urbanization:
0.92% annual rate of change (2020-25 est.)
Revenue from forest resources:
0.5% of GDP (2018 est.)
comparison ranking:
65
Revenue from coal:
0.03% of GDP (2018 est.)
comparison ranking:
38
Air pollutants:
particulate matter emissions:
8.61 micrograms per cubic meter (2019 est.)
carbon dioxide emissions:
34.38 megatons (2016 est.)
methane emissions:
34.3 megatons (2020 est.)
Waste and recycling:
municipal solid waste generated annually:
3.405 million tons (2016 est.)
Major lakes (area sq km):
fresh water lake(s):
Lake Taupo - 610 sq km
Total water withdrawal:
municipal:
500 million cubic meters (2020 est.)
industrial:
1.18 billion cubic meters (2020 est.)
agricultural:
3.2 billion cubic meters (2020 est.)
Total renewable water resources:
327 billion cubic meters (2020 est.)','709dcc8003927eb1d848b7b2d4bdcc9b748675c99ec9b26f07c3b06887eeec01','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b0c77e642b5d34c74b6750738088c0f62e1e19192151aa858451834c45f7e4f8',2025,'NI','Nicaragua','environment',17,'Environment - current issues:
deforestation; soil erosion; water pollution; drought
Environment - international agreements:
party to:
Biodiversity, Climate Change, Climate Change-Kyoto Protocol, Climate Change-Paris Agreement, Comprehensive Nuclear Test Ban, Desertification, Endangered Species, Environmental Modification, Hazardous Wastes, Law of the Sea, Nuclear Test Ban, Ozone Layer Protection, Ship Pollution, Wetlands, Whaling
signed, but not ratified:
none of the selected agreements
Climate:
tropical in lowlands, cooler in highlands
Land use:
agricultural land:
42.2% (2018 est.)
arable land:
12.5% (2018 est.)
permanent crops:
2.5% (2018 est.)
permanent pasture:
27.2% (2018 est.)
forest:
25.3% (2018 est.)
other:
32.5% (2018 est.)
Urbanization:
urban population:
59.8% of total population (2023)
rate of urbanization:
1.45% annual rate of change (2020-25 est.)
Revenue from forest resources:
1.26% of GDP (2018 est.)
comparison ranking:
49
Revenue from coal:
0% of GDP (2018 est.)
comparison ranking:
98
Air pollutants:
particulate matter emissions:
16 micrograms per cubic meter (2019 est.)
carbon dioxide emissions:
5.59 megatons (2016 est.)
methane emissions:
6.46 megatons (2020 est.)
Waste and recycling:
municipal solid waste generated annually:
1,528,816 tons (2010 est.)
Major lakes (area sq km):
fresh water lake(s):
Lago de Nicaragua - 8,150 sq km; Lago de Managua - 1,040 sq km
Total water withdrawal:
municipal:
286 million cubic meters (2020 est.)
industrial:
50 million cubic meters (2020 est.)
agricultural:
1.08 billion cubic meters (2020 est.)
Total renewable water resources:
164.52 billion cubic meters (2020 est.)','44156f9009bd28b0f068e5b3c00d854bc1c9c73b255b6a027db4df6dce0043fc','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b5fe6b684e50faa6d192843867dc2e563987d037540b0d3d80e4239ae6e071b0',2025,'NE','Niger','environment',29,'Environment - current issues:
overgrazing; soil erosion; deforestation; desertification; contaminated water; inadequate potable water; wildlife populations (such as elephant, hippopotamus, giraffe, and lion) threatened because of poaching and habitat destruction
Environment - international agreements:
party to:
Biodiversity, Climate Change, Climate Change-Kyoto Protocol, Climate Change-Paris Agreement, Comprehensive Nuclear Test Ban, Desertification, Endangered Species, Environmental Modification, Hazardous Wastes, Law of the Sea, Nuclear Test Ban, Ozone Layer Protection, Wetlands
signed, but not ratified:
none of the selected agreements
Climate:
desert; mostly hot, dry, dusty; tropical in extreme south
Land use:
agricultural land:
35.1% (2018 est.)
arable land:
12.3% (2018 est.)
permanent crops:
0.1% (2018 est.)
permanent pasture:
22.7% (2018 est.)
forest:
1% (2018 est.)
other:
63.9% (2018 est.)
Urbanization:
urban population:
17.1% of total population (2023)
rate of urbanization:
4.72% annual rate of change (2020-25 est.)
Food insecurity:
widespread lack of access: due to internal conflict, high food prices, and floods -
about 2.87 million people are projected to be acutely food insecure during the June to August 2023 lean season period; this would be an improvement on the situation in 2022, mostly reflecting the sharp upturn in crop yields following the below-average cereal output in 2021; persistent insecurity continues to disrupt livelihoods and has displaced over 360,000 people as of January 2023, mostly in the Diffa, Tahoua and Tillabery regions; high food prices, as well as the floods in 2022 that affected about 327,000 people, are additional factors that have aggravated food insecurity (2023)
Revenue from forest resources:
4.41% of GDP (2018 est.)
comparison ranking:
16
Revenue from coal:
0.03% of GDP (2018 est.)
comparison ranking:
34
Air pollutants:
particulate matter emissions:
50.15 micrograms per cubic meter (2019 est.)
carbon dioxide emissions:
2.02 megatons (2016 est.)
methane emissions:
22.99 megatons (2020 est.)
Waste and recycling:
municipal solid waste generated annually:
1,865,646 tons (1993 est.)
municipal solid waste recycled annually:
74,626 tons (2005 est.)
percent of municipal solid waste recycled:
4% (2005 est.)
Major lakes (area sq km):
fresh water lake(s):
Lake Chad (endorheic lake shared with Chad, Nigeria, and Cameroon) - 10,360-25,900 sq km note - area varies by season and year to year
Major rivers (by length in km):
Niger (shared with Guinea [s], Mali, Benin, and Nigeria [m]) - 4,200 km
note –
[s] after country name indicates river source; [m] after country name indicates river mouth
Major watersheds (area sq km): Atlantic Ocean drainage:
Niger (2,261,741 sq km)
Internal
(endorheic basin)
drainage:
Lake Chad (2,497,738 sq km)
Major aquifers:
Lake Chad Basin, Lullemeden-Irhazer Basin, Murzuk-Djado Basin
Total water withdrawal:
municipal:
190 million cubic meters (2020 est.)
industrial:
40 million cubic meters (2020 est.)
agricultural:
2.35 billion cubic meters (2020 est.)
Total renewable water resources:
34.05 billion cubic meters (2020 est.)','fc56b11d01fd55880a757c63e30a81eec672cbf07d1331022fd2aea36fbcbb57','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bf8cdb0d765611deb28391b0324778b8028c7e124c3ce00ccf1c7b2e7baa4ba0',2025,'NG','Nigeria','environment',41,'Environment - current issues:
serious overpopulation and rapid urbanization have led to numerous environmental problems; urban air and water pollution; rapid deforestation; soil degradation; loss of arable land; oil pollution - water, air, and soil have suffered serious damage from oil spills
Environment - international agreements:
party to:
Biodiversity, Climate Change, Climate Change-Kyoto Protocol, Climate Change-Paris Agreement, Comprehensive Nuclear Test Ban, Desertification, Endangered Species, Hazardous Wastes, Law of the Sea, Marine Dumping-London Convention, Marine Dumping-London Protocol, Marine Life Conservation, Nuclear Test Ban, Ozone Layer Protection, Ship Pollution, Wetlands
signed, but not ratified:
Tropical Timber 2006
Climate:
varies; equatorial in south, tropical in center, arid in north
Land use:
agricultural land:
78% (2018 est.)
arable land:
37.3% (2018 est.)
permanent crops:
7.4% (2018 est.)
permanent pasture:
33.3% (2018 est.)
forest:
9.5% (2018 est.)
other:
12.5% (2018 est.)
Urbanization:
urban population:
54.3% of total population (2023)
rate of urbanization:
3.92% annual rate of change (2020-25 est.)
Food insecurity:
widespread lack of access: due to persistent civil conflict in the northern areas, floods, high food prices, and an economic slowdown -
about 25.3 million people are projected to face acute food insecurity during the June to August 2023 lean season; this would be a significant deterioration compared to last year, when 19.45 million people were estimated to be acutely food insecure; acute food insecurity is mostly driven by the deterioration of security conditions and conflicts in northern states, which have led to the displacement of about 3.17 million people as of March 2022 (the latest data available) and are constraining farmers’ access to their lands; widespread flooding in 2022, affecting about 4.5 million people across the country, has further compounded conditions, particularly in areas already facing high levels of insecurity; high food prices and the expected slowdown in economic growth in 2023 are additional drivers of acute food insecurity (2023)
Revenue from forest resources:
1.02% of GDP (2018 est.)
comparison ranking:
53
Revenue from coal:
0% of GDP (2018 est.)
comparison ranking:
86
Air pollutants:
particulate matter emissions:
55.64 micrograms per cubic meter (2019 est.)
carbon dioxide emissions:
120.37 megatons (2016 est.)
methane emissions:
143.99 megatons (2020 est.)
Waste and recycling:
municipal solid waste generated annually:
27,614,830 tons (2009 est.)
Major lakes (area sq km):
fresh water lake(s):
Lake Chad (endorheic lake shared with Niger, Chad, and Cameroon) - 10,360-25,900 sq km note - area varies by season and year to year
Major rivers (by length in km):
Niger river mouth (shared with Guinea [s], Mali, Benin, and Niger) - 4,200 km
note –
[s] after country name indicates river source; [m] after country name indicates river mouth
Major watersheds (area sq km): Atlantic Ocean drainage:
Niger (2,261,741 sq km)
Internal
(endorheic basin)
drainage:
Lake Chad (2,497,738 sq km)
Major aquifers:
Lake Chad Basin, Lullemeden-Irhazer Aquifer System
Total water withdrawal:
municipal:
5 billion cubic meters (2020 est.)
industrial:
1.97 billion cubic meters (2020 est.)
agricultural:
5.51 billion cubic meters (2020 est.)
Total renewable water resources:
286.2 billion cubic meters (2020 est.)','91f00bb68f5ecf6b53325958871a6f4e19f33b2e915ea307027399ede7316d18','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('90fa107f45a4915b335458518dacf0d7a5769d104f4f3870a765dd1e2b17d607',2025,'NU','Niue','environment',4,'Environment - current issues:
increasing attention to conservationist practices to counter loss of soil fertility from traditional slash and burn agriculture
Environment - international agreements:
party to:
Biodiversity, Climate Change, Climate Change-Kyoto Protocol, Climate Change-Paris Agreement, Comprehensive Nuclear Test Ban, Desertification, Law of the Sea, Ozone Layer Protection, Ship Pollution
signed, but not ratified:
none of the selected agreements
Climate:
tropical; modified by southeast trade winds
Land use:
agricultural land:
19.1% (2018 est.)
arable land:
3.8% (2018 est.)
permanent crops:
11.5% (2018 est.)
permanent pasture:
3.8% (2018 est.)
forest:
71.2% (2018 est.)
other:
9.7% (2018 est.)
Urbanization:
urban population:
48.2% of total population (2023)
rate of urbanization:
1.43% annual rate of change (2020-25 est.)
Air pollutants:
particulate matter emissions:
6.74 micrograms per cubic meter (2019 est.)
Total renewable water resources:
0 cubic meters (2017 est.)','96f2a4a19db4a265a0910eb9348e1f0b7efb228fc73c2ea285767ac55406c160','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5f5d6709b35b9fe1a7f82182776887fb1e087540fef6cdaaef901f6664992fd0',2025,'NF','Norfolk Island','environment',15,'Environment - current issues:
inadequate solid waste management; most freshwater obtained through rainwater catchment; preservation of unique ecosystem
Climate:
subtropical; mild, little seasonal temperature variation
Land use:
agricultural land:
25% (2018 est.)
arable land:
0% (2018 est.)
permanent crops:
0% (2018 est.)
permanent pasture:
25% (2018 est.)
forest:
11.5% (2018 est.)
other:
63.5% (2018 est.)','e2814308f1a0e8947155fb422da89c42549a2e10a659232d3f3419e6015e1124','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('475d5d3772d7cce2acad62f468ea03184101866de8ec8445663b78c79e108b71',2025,'MK','North Macedonia','environment',25,'Environment - current issues:
air pollution from metallurgical plants; Skopje has severe air pollution problems every winter as a result of industrial emissions, smoke from wood-buring stoves, and exhaust fumes from old cars
Environment - international agreements:
party to:
Air Pollution, Air Pollution-Heavy Metals, Air Pollution-Multi-effect Protocol, Air Pollution-Nitrogen Oxides, Air Pollution-Persistent Organic Pollutants, Air Pollution-Sulphur 85, Air Pollution-Sulphur 94, Air Pollution-Volatile Organic Compounds, Biodiversity, Climate Change, Climate Change-Kyoto Protocol, Climate Change-Paris Agreement, Comprehensive Nuclear Test Ban, Desertification, Endangered Species, Hazardous Wastes, Law of the Sea, Ozone Layer Protection, Wetlands
signed, but not ratified:
none of the selected agreements
Climate:
warm, dry summers and autumns; relatively cold winters with heavy snowfall
Land use:
agricultural land:
44.3% (2018 est.)
arable land:
16.4% (2018 est.)
permanent crops:
1.4% (2018 est.)
permanent pasture:
26.5% (2018 est.)
forest:
39.8% (2018 est.)
other:
15.9% (2018 est.)
Urbanization:
urban population:
59.5% of total population (2023)
rate of urbanization:
0.61% annual rate of change (2020-25 est.)
Revenue from forest resources:
0.15% of GDP (2018 est.)
comparison ranking:
100
Revenue from coal:
0% of GDP (2018 est.)
comparison ranking:
119
Air pollutants:
particulate matter emissions:
25.17 micrograms per cubic meter (2019 est.)
carbon dioxide emissions:
7.05 megatons (2016 est.)
methane emissions:
2.28 megatons (2020 est.)
Waste and recycling:
municipal solid waste generated annually:
796,585 tons (2016 est.)
municipal solid waste recycled annually:
1,434 tons (2013 est.)
percent of municipal solid waste recycled:
0.2% (2013 est.)
Major watersheds (area sq km): Atlantic Ocean drainage:
(Black Sea)
Danube (795,656 sq km)
Total water withdrawal:
municipal:
310 million cubic meters (2020 est.)
industrial:
20 million cubic meters (2020 est.)
agricultural:
140 million cubic meters (2020 est.)
Total renewable water resources:
6.4 billion cubic meters (2020 est.)','8a98ddd760a7540359cfb7ce7292d9b6eb6afc57c22c9bff534a93213f94446e','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('201d27179acc520a0d3fc957d7e6b6a47f5f55a289ff252f0d6021ec1d4db4cd',2025,'MP','Northern Mariana Islands','environment',37,'Environment - current issues:
contamination of groundwater on Saipan may contribute to disease; clean-up of landfill; protection of endangered species conflicts with development
Climate:
tropical marine; moderated by northeast trade winds, little seasonal temperature variation; dry season December to June, rainy season July to October
Land use:
agricultural land:
6.6% (2018 est.)
arable land:
2.2% (2018 est.)
permanent crops:
2.2% (2018 est.)
permanent pasture:
2.2% (2018 est.)
forest:
65.5% (2018 est.)
other:
27.9% (2018 est.)
Urbanization:
urban population:
92.1% of total population (2023)
rate of urbanization:
0.36% annual rate of change (2020-25 est.)
Revenue from forest resources:
0% of GDP (2018 est.)
comparison ranking:
177
Waste and recycling:
municipal solid waste generated annually:
32,761 tons (2013 est.)
municipal solid waste recycled annually:
11,794 tons (2016 est.)
percent of municipal solid waste recycled:
36% (2016 est.)','1695e5971cd4633e21b7bae57773ebd65e2fc3232a05f5d09753d7f1496bac45','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('199488d46fcefc6e941a2b9da5dc1e16d8b2746a14367d2853c0e60c2b1ceb45',2025,'NO','Norway','environment',48,'Environment - current issues:
water pollution; acid rain damaging forests and adversely affecting lakes, threatening fish stocks; air pollution from vehicle emissions
Environment - international agreements:
party to:
Air Pollution, Air Pollution-Heavy Metals, Air Pollution-Multi-effect Protocol, Air Pollution-Nitrogen Oxides, Air Pollution-Persistent Organic Pollutants, Air Pollution-Sulphur 85, Air Pollution-Sulphur 94, Air Pollution-Volatile Organic Compounds, Antarctic-Environmental Protection, Antarctic-Marine Living Resources, Antarctic Seals, Antarctic Treaty, Biodiversity, Climate Change, Climate Change-Kyoto Protocol, Climate Change-Paris Agreement, Comprehensive Nuclear Test Ban, Desertification, Endangered Species, Environmental Modification, Hazardous Wastes, Law of the Sea, Marine Dumping-London Convention, Marine Dumping-London Protocol, Nuclear Test Ban, Ozone Layer Protection, Ship Pollution, Tropical Timber 2006, Wetlands, Whaling
signed, but not ratified:
none of the selected agreements
Climate:
temperate along coast, modified by North Atlantic Current; colder interior with increased precipitation and colder summers; rainy year-round on west coast
Land use:
agricultural land:
2.7% (2018 est.)
arable land:
2.2% (2018 est.)
permanent crops:
0% (2018 est.)
permanent pasture:
0.5% (2018 est.)
forest:
27.8% (2018 est.)
other:
69.5% (2018 est.)
Urbanization:
urban population:
84% of total population (2023)
rate of urbanization:
1.32% annual rate of change (2020-25 est.)
note:
data include Svalbard and Jan Mayen Islands
Revenue from forest resources:
0.05% of GDP (2018 est.)
comparison ranking:
128
Revenue from coal:
0% of GDP (2018 est.)
comparison ranking:
56
Air pollutants:
particulate matter emissions:
6.3 micrograms per cubic meter (2019 est.)
carbon dioxide emissions:
41.02 megatons (2016 est.)
methane emissions:
4.81 megatons (2020 est.)
Waste and recycling:
municipal solid waste generated annually:
2.187 million tons (2015 est.)
municipal solid waste recycled annually:
572,119 tons (2015 est.)
percent of municipal solid waste recycled:
26.2% (2015 est.)
Total water withdrawal:
municipal:
780 million cubic meters (2020 est.)
industrial:
1.07 billion cubic meters (2020 est.)
agricultural:
840 million cubic meters (2020 est.)
Total renewable water resources:
393 billion cubic meters (2020 est.)','d6c031c8c4c5434b7e5a564634ee21fbabc21bcc0477dc71542fc54cba1f307e','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('872a79cc5a0557b12c59084e3f8399c5f173c9538d9e0a8f88a55d4502d946d6',2025,'OM','Oman','environment',4,'Environment - current issues:
limited natural freshwater resources; high levels of soil and water salinity in the coastal plains; beach pollution from oil spills; industrial effluents seeping into the water tables and aquifers; desertificaiton due to high winds driving desert sand into arable lands
Environment - international agreements:
party to:
Biodiversity, Climate Change, Climate Change-Kyoto Protocol, Climate Change-Paris Agreement, Comprehensive Nuclear Test Ban, Desertification, Endangered Species, Hazardous Wastes, Law of the Sea, Marine Dumping-London Convention, Ozone Layer Protection, Ship Pollution, Wetlands, Whaling
signed, but not ratified:
none of the selected agreements
Climate:
dry desert; hot, humid along coast; hot, dry interior; strong southwest summer monsoon (May to September) in far south
Land use:
agricultural land:
4.7% (2018 est.)
arable land:
0.1% (2018 est.)
permanent crops:
0.1% (2018 est.)
permanent pasture:
4.5% (2018 est.)
forest:
0% (2018 est.)
other:
95.3% (2018 est.)
Urbanization:
urban population:
88.4% of total population (2023)
rate of urbanization:
2.32% annual rate of change (2020-25 est.)
Revenue from forest resources:
0% of GDP (2018 est.)
comparison ranking:
174
Revenue from coal:
0% of GDP (2018 est.)
comparison ranking:
167
Air pollutants:
particulate matter emissions:
34.88 micrograms per cubic meter (2019 est.)
carbon dioxide emissions:
63.46 megatons (2016 est.)
methane emissions:
5.6 megatons (2020 est.)
Waste and recycling:
municipal solid waste generated annually:
1,734,885 tons (2014 est.)
Major aquifers:
Arabian Aquifer System
Total water withdrawal:
municipal:
130 million cubic meters (2020 est.)
industrial:
240 million cubic meters (2020 est.)
agricultural:
1.55 billion cubic meters (2020 est.)
Total renewable water resources:
1.4 billion cubic meters (2020 est.)','d7354dd61528952845c22406446385b8a09ddd32d1ea21a0781eb4b335d82280','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ab484137b45f24946ac246e55928062f2ce6ac14f59a1491555296b602d0847f',2025,'PK','Pakistan','environment',5,'Environment - current issues:
water pollution from raw sewage, industrial wastes, and agricultural runoff; limited natural freshwater resources; most of the population does not have access to potable water; deforestation; soil erosion; desertification; air pollution and noise pollution in urban areas
Environment - international agreements:
party to:
Antarctic-Environmental Protection, Antarctic-Marine Living Resources, Antarctic Treaty, Biodiversity, Climate Change, Climate Change-Kyoto Protocol, Climate Change-Paris Agreement, Desertification, Endangered Species, Environmental Modification, Hazardous Wastes, Law of the Sea, Marine Dumping-London Convention, Nuclear Test Ban, Ozone Layer Protection, Ship Pollution, Wetlands
signed, but not ratified:
Marine Life Conservation
Climate:
mostly hot, dry desert; temperate in northwest; arctic in north
Land use:
agricultural land:
35.2% (2018 est.)
arable land:
27.6% (2018 est.)
permanent crops:
1.1% (2018 est.)
permanent pasture:
6.5% (2018 est.)
forest:
2.1% (2018 est.)
other:
62.7% (2018 est.)
Urbanization:
urban population:
38% of total population (2023)
rate of urbanization:
2.1% annual rate of change (2020-25 est.)
Food insecurity:
severe localized food insecurity: due to population displacements, economic constraints, and high prices of the main food staple -
according to the latest analysis, about 4.7 million people, 25% of the population, are estimated to be facing high levels of acute food insecurity, between April and June 2022 in 25 districts analyzed in Balochistan, Sindh and Khyber Pakhtunkhwa provinces; prices of wheat flour, the country’s main staple, were at high levels in most markets in May 2022, constraining access to the staple food (2022)
Revenue from forest resources:
0.1% of GDP (2018 est.)
comparison ranking:
114
Revenue from coal:
0.06% of GDP (2018 est.)
comparison ranking:
29
Air pollutants:
particulate matter emissions:
50.13 micrograms per cubic meter (2019 est.)
carbon dioxide emissions:
201.15 megatons (2016 est.)
methane emissions:
142.12 megatons (2020 est.)
Waste and recycling:
municipal solid waste generated annually:
30.76 million tons (2017 est.)
municipal solid waste recycled annually:
2,460,800 tons (2017 est.)
percent of municipal solid waste recycled:
8% (2017 est.)
Major rivers (by length in km):
Indus river mouth (shared with China [s] and India) - 3,610 km; Sutlej river mouth (shared with China [s] and India) - 1,372 km; Chenab river mouth (shared with India [s]) - 1,086 km
note
– [s] after country name indicates river source; [m] after country name indicates river mouth
Major watersheds (area sq km): Indian Ocean drainage:
Indus (1,081,718 sq km)
Internal
(endorheic basin)
drainage:
Tarim Basin (1,152,448 sq km),
(Aral Sea basin)
Amu Darya (534,739 sq km)
Major aquifers:
Indus Basin
Total water withdrawal:
municipal:
9.65 billion cubic meters (2020 est.)
industrial:
1.4 billion cubic meters (2020 est.)
agricultural:
172.4 billion cubic meters (2020 est.)
Total renewable water resources:
246.8 billion cubic meters (2020 est.)','9e7e4bda266efd976834f8974daada4e91c7f3024d505877b72a5b9b3b8f9ffa','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a0f243ca6490a200c0e752017bb95ce60e3536deff818b635a24333627d34c63',2025,'PW','Palau','environment',18,'Environment - current issues:
inadequate facilities for disposal of solid waste; threats to the marine ecosystem from sand and coral dredging, illegal and destructive fishing practices, and overfishing; climate change contributes to rising sea level and coral bleaching; drought
Environment - international agreements:
party to:
Biodiversity, Climate Change, Climate Change-Kyoto Protocol, Climate Change-Paris Agreement, Comprehensive Nuclear Test Ban, Desertification, Endangered Species, Hazardous Wastes, Law of the Sea, Ozone Layer Protection, Ship Pollution, Wetlands, Whaling
signed, but not ratified:
none of the selected agreements
Climate:
tropical; hot and humid; wet season May to November
Land use:
agricultural land:
10.8% (2018 est.)
arable land:
2.2% (2018 est.)
permanent crops:
4.3% (2018 est.)
permanent pasture:
4.3% (2018 est.)
forest:
87.6% (2018 est.)
other:
1.6% (2018 est.)
Urbanization:
urban population:
82.4% of total population (2023)
rate of urbanization:
1.59% annual rate of change (2020-25 est.)
Revenue from forest resources:
0% of GDP (2018 est.)
comparison ranking:
169
Air pollutants:
particulate matter emissions:
7.82 micrograms per cubic meter (2019 est.)
carbon dioxide emissions:
0.22 megatons (2016 est.)
methane emissions:
0.06 megatons (2020 est.)
Waste and recycling:
municipal solid waste generated annually:
9,427 tons (2016 est.)
Total renewable water resources:
0 cubic meters (2017 est.)','9b8944fe9c167e8513b6cae176dce705ee2ee67ca6d34d25275385d3647632ae','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('82cd20b0f2872a04f78bcadabf6c4941a7a1b6d985544c608f443e6adb7bf5af',2025,'PA','Panama','environment',29,'Environment - current issues:
water pollution from agricultural runoff threatens fishery resources; deforestation of tropical rain forest; land degradation and soil erosion threatens siltation of Panama Canal; air pollution in urban areas; mining threatens natural resources
Environment - international agreements:
party to:
Antarctic-Marine Living Resources, Biodiversity, Climate Change, Climate Change-Kyoto Protocol, Climate Change-Paris Agreement, Comprehensive Nuclear Test Ban, Desertification, Endangered Species, Environmental Modification, Hazardous Wastes, Law of the Sea, Marine Dumping-London Convention, Nuclear Test Ban, Ozone Layer Protection, Ship Pollution, Tropical Timber 2006, Wetlands, Whaling
signed, but not ratified:
Marine Life Conservation
Climate:
tropical maritime; hot, humid, cloudy; prolonged rainy season (May to January), short dry season (January to May)
Land use:
agricultural land:
30.5% (2018 est.)
arable land:
7.3% (2018 est.)
permanent crops:
2.5% (2018 est.)
permanent pasture:
20.7% (2018 est.)
forest:
43.6% (2018 est.)
other:
25.9% (2018 est.)
Urbanization:
urban population:
69.5% of total population (2023)
rate of urbanization:
1.92% annual rate of change (2020-25 est.)
Revenue from forest resources:
0.08% of GDP (2018 est.)
comparison ranking:
121
Revenue from coal:
0% of GDP (2018 est.)
comparison ranking:
122
Air pollutants:
particulate matter emissions:
11.78 micrograms per cubic meter (2019 est.)
carbon dioxide emissions:
10.71 megatons (2016 est.)
methane emissions:
5.97 megatons (2020 est.)
Waste and recycling:
municipal solid waste generated annually:
1,472,262 tons (2015 est.)
Major lakes (area sq km):
salt water lake(s):
Laguna de Chiriqui - 900 sq km
Total water withdrawal:
municipal:
760 million cubic meters (2020 est.)
industrial:
10 million cubic meters (2020 est.)
agricultural:
450 million cubic meters (2020 est.)
Total renewable water resources:
139.3 billion cubic meters (2020 est.)','aa3997c095946a6a9f4043e3bdccade8e6916582c6d735210ccaa3144a463d3e','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('657c2335f62432315b222436973d8a53f49b34cea6e441965cb07220f9acaed8',2025,'PG','Papua New Guinea','environment',40,'Environment - current issues:
rain forest loss as a result of growing commercial demand for tropical timber; unsustainable logging practices result in soil erosion, water quality degredation, and loss of habitat and biodiversity; large-scale mining projects cause adverse impacts on forests and water quality (discharge of heavy metals, cyanide, and acids into rivers); severe drought; inappropriate farming practices accelerate land degradion (soil erosion, siltation, loss of soil fertility); destructive fishing practices and coastal pollution due to run-off from land-based activities and oil spills
Environment - international agreements:
party to:
Antarctic Treaty, Biodiversity, Climate Change, Climate Change-Kyoto Protocol, Climate Change-Paris Agreement, Desertification, Endangered Species, Environmental Modification, Hazardous Wastes, Law of the Sea, Marine Dumping-London Convention, Nuclear Test Ban, Ozone Layer Protection, Ship Pollution, Tropical Timber 2006, Wetlands
signed, but not ratified:
Comprehensive Nuclear Test Ban
Climate:
tropical; northwest monsoon (December to March), southeast monsoon (May to October); slight seasonal temperature variation
Land use:
agricultural land:
2.6% (2018 est.)
arable land:
0.7% (2018 est.)
permanent crops:
1.5% (2018 est.)
permanent pasture:
0.4% (2018 est.)
forest:
63.1% (2018 est.)
other:
34.3% (2018 est.)
Urbanization:
urban population:
13.7% of total population (2023)
rate of urbanization:
2.91% annual rate of change (2020-25 est.)
Revenue from forest resources:
2.08% of GDP (2018 est.)
comparison ranking:
33
Revenue from coal:
0% of GDP (2018 est.)
comparison ranking:
95
Air pollutants:
particulate matter emissions:
8.89 micrograms per cubic meter (2019 est.)
carbon dioxide emissions:
7.54 megatons (2016 est.)
methane emissions:
11.05 megatons (2020 est.)
Waste and recycling:
municipal solid waste generated annually:
1 million tons (2014 est.)
municipal solid waste recycled annually:
20,000 tons (2016 est.)
percent of municipal solid waste recycled:
2% (2016 est.)
Major rivers (by length in km):
Sepik river source and mouth (shared with Indonesia) - 1,126 km; Fly river source and mouth (shared with Indonesia) - 1,050 km
Total water withdrawal:
municipal:
220 million cubic meters (2020 est.)
industrial:
170 million cubic meters (2020 est.)
agricultural:
1 million cubic meters (2020 est.)
Total renewable water resources:
801 billion cubic meters (2020 est.)','508e6dda77e4af0b5ec18e790da8cf2f0e9bbc044c31d185100ea2b3108783dc','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4895ee0780167b7b3526dcc96d31da6ce40dd3243b1105d4f9f3ae78f9da5218',2025,'PG','Papua New Guinea','environment',51,'Environment - current issues:
China’s use of dredged sand and coral to build artificial islands harms reef systems; ongoing human activities, including military operations, infrastructure construction, and tourism endangers local ecosystem including birds, fish, marine mammals, and marine reptiles
Climate:
tropical
Land use:
other:
100% (2018 est.)','65566c58a05705c8e188995d54429c60e5baf28d5f3d61dbd734ece935a894d4','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4bc6d1e5b37d765e1549d76cd1cd03a618c9e4f215a0ec7102fb1fbffa0e3ed8',2025,'PY','Paraguay','environment',59,'Environment - current issues:
deforestation; water pollution; rivers suffer from toxic dumping; tanneries release mercury and chromium into rivers and streams; loss of wetlands; inadequate means for waste disposal pose health risks for many urban residents
Environment - international agreements:
party to:
Biodiversity, Climate Change, Climate Change-Kyoto Protocol, Climate Change-Paris Agreement, Comprehensive Nuclear Test Ban, Desertification, Endangered Species, Hazardous Wastes, Law of the Sea, Ozone Layer Protection, Wetlands
signed, but not ratified:
Nuclear Test Ban, Tropical Timber 2006
Climate:
subtropical to temperate; substantial rainfall in the eastern portions, becoming semiarid in the far west
Land use:
agricultural land:
53.8% (2018 est.)
arable land:
10.8% (2018 est.)
permanent crops:
0.2% (2018 est.)
permanent pasture:
42.8% (2018 est.)
forest:
43.8% (2018 est.)
other:
2.4% (2018 est.)
Urbanization:
urban population:
63.1% of total population (2023)
rate of urbanization:
1.64% annual rate of change (2020-25 est.)
Revenue from forest resources:
1.21% of GDP (2018 est.)
comparison ranking:
50
Revenue from coal:
0% of GDP (2018 est.)
comparison ranking:
109
Air pollutants:
particulate matter emissions:
12.31 micrograms per cubic meter (2019 est.)
carbon dioxide emissions:
7.41 megatons (2016 est.)
methane emissions:
27.65 megatons (2020 est.)
Waste and recycling:
municipal solid waste generated annually:
1,818,501 tons (2015 est.)
Major rivers (by length in km):
Río de la Plata/Paraná (shared with Brazil [s], Argentina, and Uruguay [m]) - 4,880 km; Paraguay river mouth (shared with Brazil [s] and Argentina) - 2,549 km
note
– [s] after country name indicates river source; [m] after country name indicates river mouth
Major watersheds (area sq km): Atlantic Ocean drainage:
Paraná (2,582,704 sq km)
Major aquifers:
Guarani Aquifer System
Total water withdrawal:
municipal:
360 million cubic meters (2020 est.)
industrial:
150 million cubic meters (2020 est.)
agricultural:
1.9 billion cubic meters (2020 est.)
Total renewable water resources:
387.77 billion cubic meters (2020 est.)','51b1c38ac918d3e371aa1d3caa90bcc1b21a4658891d2262fcf78e6fdc27c415','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('dad60db5a64175dcaddf8867f92cfaeebdd04f2c177c06e3a8459db29f650fd1',2025,'PE','Peru','environment',4,'Environment - current issues:
deforestation (some the result of illegal logging); overgrazing leading to soil erosion; desertification; air pollution in Lima; pollution of rivers and coastal waters from municipal and mining wastes; overfishing
Environment - international agreements:
party to:
Antarctic-Environmental Protection, Antarctic-Marine Living Resources, Antarctic Treaty, Biodiversity, Climate Change, Climate Change-Kyoto Protocol, Climate Change-Paris Agreement, Desertification, Endangered Species, Hazardous Wastes, Marine Dumping-London Convention, Marine Dumping-London Protocol, Nuclear Test Ban, Ozone Layer Protection, Ship Pollution, Tropical Timber 2006, Wetlands, Whaling
signed, but not ratified:
none of the selected agreements
Climate:
varies from tropical in east to dry desert in west; temperate to frigid in Andes
Land use:
agricultural land:
18.8% (2018 est.)
arable land:
3.1% (2018 est.)
permanent crops:
1.1% (2018 est.)
permanent pasture:
14.6% (2018 est.)
forest:
53% (2018 est.)
other:
28.2% (2018 est.)
Urbanization:
urban population:
78.9% of total population (2023)
rate of urbanization:
1.33% annual rate of change (2020-25 est.)
Revenue from forest resources:
0.12% of GDP (2018 est.)
comparison ranking:
109
Revenue from coal:
0% of GDP (2018 est.)
comparison ranking:
145
Air pollutants:
particulate matter emissions:
29.07 micrograms per cubic meter (2019 est.)
carbon dioxide emissions:
57.41 megatons (2016 est.)
methane emissions:
30.17 megatons (2020 est.)
Waste and recycling:
municipal solid waste generated annually:
8,356,711 tons (2014 est.)
municipal solid waste recycled annually:
334,268 tons (2012 est.)
percent of municipal solid waste recycled:
4% (2012 est.)
Major lakes (area sq km):
fresh water lake(s):
Lago Titicaca (shared with Bolivia) - 8,030 sq km
Major rivers (by length in km):
Amazon river source (shared with Brazil [m]) - 6,400 km
note
– [s] after country name indicates river source; [m] after country name indicates river mouth
Major watersheds (area sq km): Atlantic Ocean drainage:
Amazon (6,145,186 sq km)
Major aquifers:
Amazon Basin
Total water withdrawal:
municipal:
2.24 billion cubic meters (2020 est.)
industrial:
3.51 billion cubic meters (2020 est.)
agricultural:
32.8 billion cubic meters (2020 est.)
Total renewable water resources:
1.88 trillion cubic meters (2020 est.)','c96d22526fe56bd1bc91de541f933528a26532c369129dbb2479fda2b81abc68','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('99ee72a658e0ab5dd1f798a75e49f1766660efda9493481f7fe701943600cf6b',2025,'PH','Philippines','environment',17,'Environment - current issues:
uncontrolled deforestation especially in watershed areas; illegal mining and logging; soil erosion; air and water pollution in major urban centers; coral reef degradation; increasing pollution of coastal mangrove swamps that are important fish breeding grounds; coastal erosion; dynamite fishing; wildlife extinction
Environment - international agreements:
party to:
Biodiversity, Climate Change, Climate Change-Kyoto Protocol, Climate Change-Paris Agreement, Comprehensive Nuclear Test Ban, Desertification, Endangered Species, Hazardous Wastes, Law of the Sea, Marine Dumping-London Convention, Marine Dumping-London Protocol, Nuclear Test Ban, Ozone Layer Protection, Ship Pollution, Tropical Timber 2006, Wetlands
signed, but not ratified:
none of the selected agreements
Climate:
tropical marine; northeast monsoon (November to April); southwest monsoon (May to October)
Land use:
agricultural land:
41% (2018 est.)
arable land:
18.2% (2018 est.)
permanent crops:
17.8% (2018 est.)
permanent pasture:
5% (2018 est.)
forest:
25.9% (2018 est.)
other:
33.1% (2018 est.)
Urbanization:
urban population:
48.3% of total population (2023)
rate of urbanization:
2.04% annual rate of change (2020-25 est.)
Revenue from forest resources:
0.18% of GDP (2018 est.)
comparison ranking:
96
Revenue from coal:
0.07% of GDP (2018 est.)
comparison ranking:
28
Air pollutants:
particulate matter emissions:
22.45 micrograms per cubic meter (2019 est.)
carbon dioxide emissions:
122.29 megatons (2016 est.)
methane emissions:
51.32 megatons (2020 est.)
Waste and recycling:
municipal solid waste generated annually:
14,631,923 tons (2016 est.)
municipal solid waste recycled annually:
4,096,938 tons (2014 est.)
percent of municipal solid waste recycled:
28% (2014 est.)
Major lakes (area sq km):
salt water lake(s):
Laguna de Bay - 890 sq km
Total water withdrawal:
municipal:
8.16 billion cubic meters (2020 est.)
industrial:
9.88 billion cubic meters (2020 est.)
agricultural:
67.83 billion cubic meters (2020 est.)
Total renewable water resources:
479 billion cubic meters (2020 est.)','01a440b4c500e612974501624b402474cd0f991c0a1e9e1715b0c35dca143915','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3aed2d3097f36342187cd69594f8c58a5b7a34737829fd0753d22ddbf17f2d52',2025,'PH','Philippines','environment',30,'Environment - current issues:
deforestation (only a small portion of the original forest remains because of burning and clearing for settlement)
Climate:
tropical; hot and humid; modified by southeast trade winds; rainy season (November to March)
Land use:
agricultural land:
0% (2011 est.)
forest:
74.5% (2018 est.)
other:
25.5% (2018 est.)
Urbanization:
rate of urbanization:
NA','4628f4bbff51262550f1851cb7977df4b8c84da6ec45b9da5367bad243c43aac','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0ab51d99caf852d93204438c68633d9de7037c14e6a10a424d620007219793cd',2025,'PL','Poland','environment',40,'Environment - current issues:
decreased emphasis on heavy industry and increased environmental concern by post-communist governments has improved environment; air pollution remains serious because of emissions from burning low-quality coals in homes and from coal-fired power plants; the resulting acid rain causes forest damage; water pollution from industrial and municipal sources is a problem, as is disposal of hazardous wastes
Environment - international agreements:
party to:
Air Pollution, Air Pollution-Nitrogen Oxides, Air Pollution-Sulphur 94, Antarctic-Environmental Protection, Antarctic- Marine Living Resources, Antarctic Seals, Antarctic Treaty, Biodiversity, Climate Change, Climate Change- Kyoto Protocol, Climate Change-Paris Agreement, Comprehensive Nuclear Test Ban, Desertification, Endangered Species, Environmental Modification, Hazardous Wastes, Law of the Sea, Marine Dumping-London Convention, Nuclear Test Ban, Ozone Layer Protection, Ship Pollution, Tropical Timber 2006, Wetlands, Whaling
signed, but not ratified:
Air Pollution-Heavy Metals, Air Pollution-Multi-effect Protocol, Air Pollution-Persistent Organic Pollutants
Climate:
temperate with cold, cloudy, moderately severe winters with frequent precipitation; mild summers with frequent showers and thundershowers
Land use:
agricultural land:
48.2% (2018 est.)
arable land:
36.2% (2018 est.)
permanent crops:
1.3% (2018 est.)
permanent pasture:
10.7% (2018 est.)
forest:
30.6% (2018 est.)
other:
21.2% (2018 est.)
Urbanization:
urban population:
60.2% of total population (2023)
rate of urbanization:
-0.16% annual rate of change (2020-25 est.)
Revenue from forest resources:
0.17% of GDP (2018 est.)
comparison ranking:
98
Revenue from coal:
0.27% of GDP (2018 est.)
comparison ranking:
19
Air pollutants:
particulate matter emissions:
18.83 micrograms per cubic meter (2019 est.)
carbon dioxide emissions:
299.04 megatons (2016 est.)
methane emissions:
46.62 megatons (2020 est.)
Waste and recycling:
municipal solid waste generated annually:
10.863 million tons (2015 est.)
municipal solid waste recycled annually:
2,866,746 tons (2015 est.)
percent of municipal solid waste recycled:
26.4% (2015 est.)
Major lakes (area sq km):
salt water lake(s):
Zalew Szczecinski/Stettiner Haff (shared with Germany) - 900 sq km
Major rivers (by length in km):
Wisla (Vistula) river source and mouth (shared with Belarus and Ukraine) - 1,213 km
note - longest river in Poland
Major watersheds (area sq km): Atlantic Ocean drainage:
(Black Sea)
Danube (795,656 sq km)
Total water withdrawal:
municipal:
1.96 billion cubic meters (2020 est.)
industrial:
5.87 billion cubic meters (2020 est.)
agricultural:
1.39 billion cubic meters (2020 est.)
Total renewable water resources:
60.5 billion cubic meters (2020 est.)','704b33a2740640452cb5c3ed331ffd89eaa614a34365a05d0c1c1613d8491a97','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d8ed22df6ebddd5e5cf50f0e944cf1b285c3b157acd53e8a911630a49ef30d5c',2025,'PT','Portugal','environment',53,'Environment - current issues:
soil erosion; air pollution caused by industrial and vehicle emissions; water pollution, especially in urban centers and coastal areas
Environment - international agreements:
party to:
Air Pollution, Air Pollution-Heavy Metals, Air Pollution-Multi-effect Protocol, Antarctic-Environmental Protection, Antarctic Treaty, Biodiversity, Climate Change, Climate Change-Kyoto Protocol, Climate Change-Paris Agreement, Comprehensive Nuclear Test Ban, Desertification, Endangered Species, Hazardous Wastes, Law of the Sea, Marine Dumping-London Convention, Marine Life Conservation, Ozone Layer Protection, Ship Pollution, Tropical Timber 2006, Wetlands, Whaling
signed, but not ratified:
Air Pollution-Persistent Organic Pollutants, Air Pollution-Volatile Organic Compounds, Environmental Modification, Nuclear Test Ban
Climate:
maritime temperate; cool and rainy in north, warmer and drier in south
Land use:
agricultural land:
39.7% (2018 est.)
arable land:
11.9% (2018 est.)
permanent crops:
7.8% (2018 est.)
permanent pasture:
20% (2018 est.)
forest:
37.8% (2018 est.)
other:
22.5% (2018 est.)
Urbanization:
urban population:
67.9% of total population (2023)
rate of urbanization:
0.44% annual rate of change (2020-25 est.)
Revenue from forest resources:
0.13% of GDP (2018 est.)
comparison ranking:
108
Revenue from coal:
0% of GDP (2018 est.)
comparison ranking:
82
Air pollutants:
particulate matter emissions:
7.34 micrograms per cubic meter (2019 est.)
carbon dioxide emissions:
48.74 megatons (2016 est.)
methane emissions:
10.93 megatons (2020 est.)
Waste and recycling:
municipal solid waste generated annually:
4.71 million tons (2014 est.)
municipal solid waste recycled annually:
764,433 tons (2014 est.)
percent of municipal solid waste recycled:
16.2% (2014 est.)
Total water withdrawal:
municipal:
880 million cubic meters (2020 est.)
industrial:
1.83 billion cubic meters (2020 est.)
agricultural:
3.42 billion cubic meters (2020 est.)
Total renewable water resources:
77.4 billion cubic meters (2020 est.)','c2561c641a3e04e2441fd697d7834e61d11a6286ca8f7a48c0ee22994b050106','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4da4141fcc89042ace5c7bff9877321e59e67fecc70a721708e2aa25f7a8ca25',2025,'PR','Puerto Rico','environment',66,'Environment - current issues:
soil erosion; occasional droughts cause water shortages; industrial pollution
Climate:
tropical marine, mild; little seasonal temperature variation
Land use:
agricultural land:
22% (2018 est.)
arable land:
6.6% (2018 est.)
permanent crops:
5.6% (2018 est.)
permanent pasture:
9.8% (2018 est.)
forest:
63.2% (2018 est.)
other:
14.8% (2018 est.)
Urbanization:
urban population:
93.6% of total population (2023)
rate of urbanization:
-0.12% annual rate of change (2020-25 est.)
Revenue from forest resources:
0% of GDP (2018 est.)
comparison ranking:
186
Revenue from coal:
0% of GDP (2018 est.)
comparison ranking:
63
Waste and recycling:
municipal solid waste generated annually:
4,170,953 tons (2015 est.)
municipal solid waste recycled annually:
583,933 tons (2013 est.)
percent of municipal solid waste recycled:
14% (2013 est.)
Total water withdrawal:
municipal:
800 million cubic meters (2020 est.)
industrial:
2.37 billion cubic meters (2020 est.)
agricultural:
110 million cubic meters (2020 est.)
Total renewable water resources:
7.1 billion cubic meters (2020 est.)','9642345de9c7ee76af33af8639fb36cef637a13f17f9e155c941b5d996e6ef54','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e800890e1f5e4bd92fe0ba17273b682b7de1cbca592861bd1b731b1f473d7c9c',2025,'QA','Qatar','environment',4,'Environment - current issues:
air, land, and water pollution are significant environmental issues; limited natural freshwater resources are increasing dependence on large-scale desalination facilities; other issues include conservation of oil supplies and preservation of the natural wildlife heritage
Environment - international agreements:
party to:
Biodiversity, Climate Change, Climate Change-Kyoto Protocol, Comprehensive Nuclear Test Ban, Desertification, Endangered Species, Hazardous Wastes, Law of the Sea, Ozone Layer Protection, Ship Pollution
signed, but not ratified:
none of the selected agreements
Climate:
arid; mild, pleasant winters; very hot, humid summers
Land use:
agricultural land:
5.6% (2018 est.)
arable land:
1.1% (2018 est.)
permanent crops:
0.2% (2018 est.)
permanent pasture:
4.3% (2018 est.)
forest:
0% (2018 est.)
other:
94.4% (2018 est.)
Urbanization:
urban population:
99.4% of total population (2023)
rate of urbanization:
1.66% annual rate of change (2020-25 est.)
Revenue from forest resources:
0% of GDP (2018 est.)
comparison ranking:
173
Revenue from coal:
0% of GDP (2018 est.)
comparison ranking:
113
Air pollutants:
particulate matter emissions:
59.04 micrograms per cubic meter (2019 est.)
carbon dioxide emissions:
103.26 megatons (2016 est.)
methane emissions:
8.34 megatons (2020 est.)
Waste and recycling:
municipal solid waste generated annually:
1,000,990 tons (2012 est.)
municipal solid waste recycled annually:
30,030 tons (2014 est.)
percent of municipal solid waste recycled:
3% (2014 est.)
Major aquifers:
Arabian Aquifer System
Total water withdrawal:
municipal:
530 million cubic meters (2020 est.)
industrial:
400 million cubic meters (2020 est.)
agricultural:
320 million cubic meters (2020 est.)
Total renewable water resources:
60 million cubic meters (2020 est.)','472875d62740f97c6cdf0d1889a332cb1e9003fe0ab3a50290486886cf67f510','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a979636032d7ec5e43373866c12e155a8edcca5e6d0b3aadb8bc8a9eecc805c3',2025,'RO','Romania','environment',4,'Environment - current issues:
soil erosion, degradation, and desertification; water pollution; air pollution in south from industrial effluents; contamination of Danube delta wetlands
Environment - international agreements:
party to:
Air Pollution, Air Pollution-Heavy Metals, Air Pollution-Multi-effect Protocol, Air Pollution-Persistent Organic Pollutants, Antarctic-Environmental Protection, Antarctic Treaty, Biodiversity, Climate Change, Climate Change-Kyoto Protocol, Climate Change-Paris Agreement, Comprehensive Nuclear Test Ban, Desertification, Endangered Species, Environmental Modification, Hazardous Wastes, Law of the Sea, Nuclear Test Ban, Ozone Layer Protection, Ship Pollution, Tropical Timber 2006, Wetlands, Whaling
signed, but not ratified:
none of the selected agreements
Climate:
temperate; cold, cloudy winters with frequent snow and fog; sunny summers with frequent showers and thunderstorms
Land use:
agricultural land:
60.7% (2018 est.)
arable land:
39.1% (2018 est.)
permanent crops:
1.9% (2018 est.)
permanent pasture:
19.7% (2018 est.)
forest:
28.7% (2018 est.)
other:
10.6% (2018 est.)
Urbanization:
urban population:
54.7% of total population (2023)
rate of urbanization:
-0.15% annual rate of change (2020-25 est.)
Revenue from forest resources:
0.16% of GDP (2018 est.)
comparison ranking:
99
Revenue from coal:
0.03% of GDP (2018 est.)
comparison ranking:
39
Air pollutants:
particulate matter emissions:
13.3 micrograms per cubic meter (2019 est.)
carbon dioxide emissions:
69.26 megatons (2016 est.)
methane emissions:
27.62 megatons (2020 est.)
Waste and recycling:
municipal solid waste generated annually:
4.895 million tons (2015 est.)
municipal solid waste recycled annually:
277,547 tons (2015 est.)
percent of municipal solid waste recycled:
5.7% (2015 est.)
Major rivers (by length in km):
Dunărea (Danube) river mouth (shared with Germany [s], Austria, Slovakia, Czechia, Hungary, Croatia, Serbia, Bulgaria, Moldova, and Ukraine) - 2,888 km note – [s] after country name indicates river source; [m] after country name indicates river mouth
Major watersheds (area sq km): Atlantic Ocean drainage:
(Black Sea)
Danube (795,656 sq km)
Total water withdrawal:
municipal:
1.09 billion cubic meters (2020 est.)
industrial:
3.9 billion cubic meters (2020 est.)
agricultural:
1.43 billion cubic meters (2020 est.)
Total renewable water resources:
212 billion cubic meters (2020 est.)','ee64d7534d3e16d0d65c032c3cedd1bc68797237a33a285c7f5ab635522539cb','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4280aeb2a0331cc1d1c791382526f75ef996189444f864f2683818c763ddb487',2025,'RO','Romania','environment',17,'Environment - current issues:
air pollution from heavy industry, emissions of coal-fired electric plants, and transportation in major cities; industrial, municipal, and agricultural pollution of inland waterways and seacoasts; deforestation; soil erosion; soil contamination from improper application of agricultural chemicals; nuclear waste disposal; scattered areas of sometimes intense radioactive contamination; groundwater contamination from toxic waste; urban solid waste management; abandoned stocks of obsolete pesticides
Environment - international agreements:
party to:
Air Pollution, Air Pollution-Nitrogen Oxides, Air Pollution-Sulphur 85, Antarctic-Environmental Protection, Antarctic-Marine Living Resources, Antarctic Seals, Antarctic Treaty, Biodiversity, Climate Change, Climate Change- Kyoto Protocol, Climate Change-Paris Agreement, Comprehensive Nuclear Test Ban, Desertification, Endangered Species, Environmental Modification, Hazardous Wastes, Law of the Sea, Marine Dumping-London Convention, Nuclear Test Ban, Ozone Layer Protection, Ship Pollution, Wetlands, Whaling
signed, but not ratified:
Air Pollution-Sulfur 94
Climate:
ranges from steppes in the south through humid continental in much of European Russia; subarctic in Siberia to tundra climate in the polar north; winters vary from cool along Black Sea coast to frigid in Siberia; summers vary from warm in the steppes to cool along Arctic coast
Land use:
agricultural land:
13.1% (2018 est.)
arable land:
7.3% (2018 est.)
permanent crops:
0.1% (2018 est.)
permanent pasture:
5.7% (2018 est.)
forest:
49.4% (2018 est.)
other:
37.5% (2018 est.)
Urbanization:
urban population:
75.3% of total population (2023)
rate of urbanization:
0.11% annual rate of change (2020-25 est.)
Revenue from forest resources:
0.29% of GDP (2018 est.)
comparison ranking:
81
Revenue from coal:
0.53% of GDP (2018 est.)
comparison ranking:
11
Air pollutants:
particulate matter emissions:
8.88 micrograms per cubic meter (2019 est.)
carbon dioxide emissions:
1,732.03 megatons (2016 est.)
methane emissions:
851.52 megatons (2020 est.)
Waste and recycling:
municipal solid waste generated annually:
60 million tons (2012 est.)
municipal solid waste recycled annually:
2.7 million tons (2012 est.)
percent of municipal solid waste recycled:
4.5% (2012 est.)
Major lakes (area sq km):
fresh water lake(s):
Lake Baikal - 31,500 sq km; Lake Ladoga - 18,130 sq km; Lake Onega - 9,720 sq km; Lake Khanka (shared with China) - 5,010 sq km; Lake Peipus - 4,300 sq km (shared with Estonia); Ozero Vygozero - 1,250 sq km; Ozero Beloye - 1,120 sq km
salt water lake(s):
Caspian Sea (shared with Iran, Azerbaijan, Turkmenistan, and Kazakhstan) - 374,000 sq km; Ozero Malyye Chany - 2,500 sq km; Curonian Lagoon (shared with Lithuania) - 1,620 sq km note - the Caspian Sea is the World’s largest lake
Major rivers (by length in km):
Yenisey-Angara - 5,539 km; Ob-Irtysh - 5,410 km; Amur river mouth (shared with China [s] and Mongolia) - 4,444 km; Lena - 4,400 km; Volga - 3,645 km; Kolyma - 2,513 km; Ural river source (shared with Kazakhstan [m]) - 2,428 km; Dnepr (Dnieper) river source (shared with Belarus and Ukraine [m]) - 2,287 km; Don - 1,870 km; Pechora - 1,809 km
note
– [s] after country name indicates river source; [m] after country name indicates river mouth
Major watersheds (area sq km): Arctic Ocean drainage:
Kolyma (679,934 sq km), Lena (2,306,743 sq km), Ob (2,972,493 sq km), Pechora (289,532 sq km), Yenisei (2,554,388 sq km)
Atlantic Ocean drainage:
(Black Sea)
Don (458,694 sq km), Dnieper (533,966 sq km)
Pacific Ocean drainage:
Amur (1,929,955 sq km)
Internal
(endorheic basin)
drainage:
(Caspian Sea basin)
Volga (1,410,951 sq km)
Major aquifers:
Angara-Lena Basin, Pechora Basin, North Caucasus Basin, East European Aquifer System, West Siberian Basin, Tunguss Basin, Yakut Basin
Total water withdrawal:
municipal:
17.15 billion cubic meters (2020 est.)
industrial:
29.03 billion cubic meters (2020 est.)
agricultural:
18.64 billion cubic meters (2020 est.)
Total renewable water resources:
4.53 trillion cubic meters (2020 est.)','ec44b4dfca295525f14b0cb85d791bbd236b2bc976736e1ee689ec72ca459bfa','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('204976b5c34b56b288402f2aaa27ff2e13087b258aff824ddc74fdf6eb3cc9d1',2025,'RW','Rwanda','environment',30,'Environment - current issues:
deforestation results from uncontrolled cutting of trees for fuel; overgrazing; land degradation; soil erosion; a decline in soil fertility (soil exhaustion); wetland degradation and loss of biodiversity; widespread poaching
Environment - international agreements:
party to:
Biodiversity, Climate Change, Climate Change-Kyoto Protocol, Comprehensive Nuclear Test Ban, Desertification, Endangered Species, Hazardous Wastes, Nuclear Test Ban, Ozone Layer Protection, Wetlands
signed, but not ratified:
Law of the Sea
Climate:
temperate; two rainy seasons (February to April, November to January); mild in mountains with frost and snow possible
Land use:
agricultural land:
74.5% (2018 est.)
arable land:
47% (2018 est.)
permanent crops:
10.1% (2018 est.)
permanent pasture:
17.4% (2018 est.)
forest:
18% (2018 est.)
other:
7.5% (2018 est.)
Urbanization:
urban population:
17.9% of total population (2023)
rate of urbanization:
3.07% annual rate of change (2020-25 est.)
Revenue from forest resources:
3.75% of GDP (2018 est.)
comparison ranking:
20
Revenue from coal:
0% of GDP (2018 est.)
comparison ranking:
168
Air pollutants:
particulate matter emissions:
35.66 micrograms per cubic meter (2019 est.)
carbon dioxide emissions:
1.11 megatons (2016 est.)
methane emissions:
2.92 megatons (2020 est.)
Waste and recycling:
municipal solid waste generated annually:
4,384,969 tons (2016 est.)
Major lakes (area sq km):
fresh water lake(s):
Lake Kivu (shared with Democratic Republic of Congo) - 2,220 sq km
Major rivers (by length in km):
Nile river source (shared with Tanzania, Uganda, South Sudan, Sudan, and Egypt [m]) - 6,650 km
note
– [s] after country name indicates river source; [m] after country name indicates river mouth
Major watersheds (area sq km): Atlantic Ocean drainage:
Congo (3,730,881 sq km),
(Mediterranean Sea)
Nile (3,254,853 sq km)
Total water withdrawal:
municipal:
230 million cubic meters (2020 est.)
industrial:
10 million cubic meters (2020 est.)
agricultural:
360 million cubic meters (2020 est.)
Total renewable water resources:
13.3 billion cubic meters (2020 est.)','6f04ec85d902083ca84a5fba042d12b09d480c11a27019f8647ef5895171a8a3','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0865da6ece2cf3785a41a8de1d300bd3e8f1073231632c166062773cfdfa2510',2025,'KN','Saint Kitts and Nevis','environment',6,'Environment - current issues:
deforestation; soil erosion and silting affects marine life on coral reefs; water pollution from uncontrolled dumping of sewage
Environment - international agreements:
party to:
Biodiversity, Climate Change, Climate Change-Kyoto Protocol, Climate Change-Paris Agreement, Comprehensive Nuclear Test Ban, Desertification, Endangered Species, Hazardous Wastes, Law of the Sea, Marine Dumping-London Protocol, Ozone Layer Protection, Ship Pollution, Whaling
signed, but not ratified:
none of the selected agreements
Climate:
tropical, tempered by constant sea breezes; little seasonal temperature variation; rainy season (May to November)
Land use:
agricultural land:
23.1% (2018 est.)
arable land:
19.2% (2018 est.)
permanent crops:
0.4% (2018 est.)
permanent pasture:
3.5% (2018 est.)
forest:
42.3% (2018 est.)
other:
34.6% (2018 est.)
Urbanization:
urban population:
31.1% of total population (2023)
rate of urbanization:
1.06% annual rate of change (2020-25 est.)
Revenue from forest resources:
0% of GDP (2018 est.)
comparison ranking:
193
Revenue from coal:
0% of GDP (2018 est.)
comparison ranking:
111
Air pollutants:
particulate matter emissions:
8.05 micrograms per cubic meter (2019 est.)
carbon dioxide emissions:
0.24 megatons (2016 est.)
methane emissions:
0.1 megatons (2020 est.)
Waste and recycling:
municipal solid waste generated annually:
32,892 tons (2015 est.)
Total water withdrawal:
municipal:
20 million cubic meters (2020 est.)
industrial:
0 cubic meters (2017 est.)
agricultural:
200,000 cubic meters (2017 est.)
Total renewable water resources:
20 million cubic meters (2020 est.)','6c10e6cbd0b4a3089b796687176cdbcaf4df63dd00e5a2f3fb85b6c800c944ff','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('779539192a26ac39c4eeee08a30542e7759c4aaa2268043691bd53d852554ca6',2025,'LC','Saint Lucia','environment',17,'Environment - current issues:
deforestation; soil erosion, particularly in the northern region
Environment - international agreements:
party to:
Biodiversity, Climate Change, Climate Change-Kyoto Protocol, Climate Change-Paris Agreement, Comprehensive Nuclear Test Ban, Desertification, Endangered Species, Environmental Modification, Hazardous Wastes, Law of the Sea, Marine Dumping-London Convention, Ozone Layer Protection, Ship Pollution, Wetlands, Whaling
signed, but not ratified:
none of the selected agreements
Climate:
tropical, moderated by northeast trade winds; dry season January to April, rainy season May to August
Land use:
agricultural land:
17.4% (2018 est.)
arable land:
4.9% (2018 est.)
permanent crops:
11.5% (2018 est.)
permanent pasture:
1% (2018 est.)
forest:
77% (2018 est.)
other:
5.6% (2018 est.)
Urbanization:
urban population:
19.2% of total population (2023)
rate of urbanization:
0.98% annual rate of change (2020-25 est.)
Revenue from forest resources:
0.01% of GDP (2018 est.)
comparison ranking:
153
Revenue from coal:
0% of GDP (2018 est.)
comparison ranking:
66
Air pollutants:
particulate matter emissions:
8.98 micrograms per cubic meter (2019 est.)
carbon dioxide emissions:
0.41 megatons (2016 est.)
methane emissions:
0.27 megatons (2020 est.)
Waste and recycling:
municipal solid waste generated annually:
77,616 tons (2015 est.)
Total water withdrawal:
municipal:
10 million cubic meters (2020 est.)
industrial:
0 cubic meters (2017 est.)
agricultural:
30 million cubic meters (2020 est.)
Total renewable water resources:
300 million cubic meters (2020 est.)','3f4d29f3de216fc88a27414a0e3139a5a382dc2edb3d3b72fe3450335726bd24','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('edffcdb2739e89ec600a45d586d6b50ea14f792f774615d6ab0887b1cb86cb3c',2025,'LC','Saint Lucia','environment',28,'Environment - current issues:
excessive population pressure (increasing settlement); waste management; salinity intrusions into the mainland of the island; fresh water supply is dependent on desalination of sea water; over-exploitation of marine resources (reef fisheries, coral and shell); indiscriminate anchoring of boats damages coral reefs, causing underwater pollution and sedimentation
Climate:
temperature averages 27-29 degrees Celsius all year long; low humidity, gentle trade winds, brief, intense rain showers; hurricane season stretches from July to November
Waste and recycling:
municipal solid waste generated annually:
15,480 tons (2012 est.)','c921062fde0af09003c70f0ce74825c5bd0c192d6e0574af4ea835ff2af47d0c','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('15e49a188c5588b96ee7ab808939354ba5e355030daecbe6bb5664f3eccd49ff',2025,'PM','Saint Pierre and Miquelon','environment',39,'Environment - current issues:
overfishing; recent test drilling for oil in waters around Saint Pierre and Miquelon may bring future development that would impact the environment
Climate:
cold and wet, with considerable mist and fog; spring and autumn are often windy
Land use:
agricultural land:
8.7% (2018 est.)
arable land:
8.7% (2018 est.)
permanent crops:
0% (2018 est.)
permanent pasture:
0% (2018 est.)
forest:
12.5% (2018 est.)
other:
78.8% (2018 est.)
Urbanization:
urban population:
90.1% of total population (2023)
rate of urbanization:
0.75% annual rate of change (2020-25 est.)','9a928c1a1dc1ce1425ac116ed860d7c494ece8f92c117fed08e9eb7d809ce616','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e7788b2558d4ccbcf143c2871123a19a1b309092c94e5c141720aabc88b3b3c1',2025,'VC','Saint Vincent and the Grenadines','environment',50,'Environment - current issues:
pollution of coastal waters and shorelines from discharges by pleasure yachts and other effluents; in some areas, pollution is severe enough to make swimming prohibitive; poor land use planning; deforestation; watershed management and squatter settlement control
Environment - international agreements:
party to:
Biodiversity, Climate Change, Climate Change-Kyoto Protocol, Climate Change-Paris Agreement, Comprehensive Nuclear Test Ban, Desertification, Endangered Species, Environmental Modification, Hazardous Wastes, Law of the Sea, Marine Dumping-London Convention, Ozone Layer Protection, Ship Pollution, Whaling
signed, but not ratified:
none of the selected agreements
Climate:
tropical; little seasonal temperature variation; rainy season (May to November)
Land use:
agricultural land:
25.6% (2018 est.)
arable land:
12.8% (2018 est.)
permanent crops:
7.7% (2018 est.)
permanent pasture:
5.1% (2018 est.)
forest:
68.7% (2018 est.)
other:
5.7% (2018 est.)
Urbanization:
urban population:
54.3% of total population (2023)
rate of urbanization:
0.94% annual rate of change (2020-25 est.)
Revenue from forest resources:
0.02% of GDP (2018 est.)
comparison ranking:
145
Revenue from coal:
0% of GDP (2018 est.)
comparison ranking:
105
Air pollutants:
particulate matter emissions:
9.41 micrograms per cubic meter (2019 est.)
carbon dioxide emissions:
0.22 megatons (2016 est.)
methane emissions:
0.09 megatons (2020 est.)
Waste and recycling:
municipal solid waste generated annually:
31,561 tons (2015 est.)
Total water withdrawal:
municipal:
10 million cubic meters (2020 est.)
industrial:
2,000 cubic meters (2017 est.)
agricultural:
0 cubic meters (2017 est.)
Total renewable water resources:
100 million cubic meters (2020 est.)','9b6429278fbbe82260df1dd90b42c15a482c0e32d26cc7d3ca8f3752ca7e7212','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('50b847b6c11ceccb39031914facc5386b796c8858b20b46b8b5f7329d38d2d72',2025,'WS','Samoa','environment',61,'Environment - current issues:
soil erosion, deforestation, invasive species, overfishing
Environment - international agreements:
party to:
Biodiversity, Climate Change, Climate Change-Kyoto Protocol, Climate Change-Paris Agreement, Comprehensive Nuclear Test Ban, Desertification, Endangered Species, Hazardous Wastes, Law of the Sea, Nuclear Test Ban, Ozone Layer Protection, Ship Pollution, Wetlands
signed, but not ratified:
none of the selected agreements
Climate:
tropical; rainy season (November to April), dry season (May to October)
Land use:
agricultural land:
12.4% (2018 est.)
arable land:
2.8% (2018 est.)
permanent crops:
7.8% (2018 est.)
permanent pasture:
1.8% (2018 est.)
forest:
60.4% (2018 est.)
other:
27.2% (2018 est.)
Urbanization:
urban population:
17.5% of total population (2023)
rate of urbanization:
-0.03% annual rate of change (2020-25 est.)
Revenue from forest resources:
0.27% of GDP (2018 est.)
comparison ranking:
84
Revenue from coal:
0% of GDP (2018 est.)
comparison ranking:
180
Air pollutants:
particulate matter emissions:
7.78 micrograms per cubic meter (2019 est.)
carbon dioxide emissions:
0.25 megatons (2016 est.)
methane emissions:
0.27 megatons (2020 est.)
Waste and recycling:
municipal solid waste generated annually:
27,399 tons (2011 est.)
municipal solid waste recycled annually:
9,864 tons (2013 est.)
percent of municipal solid waste recycled:
36% (2013 est.)
Total renewable water resources:
0 cubic meters (2017 est.)','b83f7d11cab3cc4fd292804f46577bdadc0443f5d597ada691c50708936d59af','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a8a05602c860bb57a90a13044207f65f989cb1992f5c3006812891889e1c6c19',2025,'SM','San Marino','environment',4,'Environment - current issues:
air pollution; urbanization decreasing rural farmlands; water shortage
Environment - international agreements:
party to:
Biodiversity, Climate Change, Climate Change-Kyoto Protocol, Climate Change-Paris Agreement, Comprehensive Nuclear Test Ban, Desertification, Endangered Species, Nuclear Test Ban, Ozone Layer Protection, Whaling
signed, but not ratified:
Air Pollution
Climate:
Mediterranean; mild to cool winters; warm, sunny summers
Land use:
agricultural land:
16.7% (2018 est.)
arable land:
16.7% (2018 est.)
permanent crops:
0% (2018 est.)
permanent pasture:
0% (2018 est.)
forest:
0% (2018 est.)
other:
83.3% (2018 est.)
Urbanization:
urban population:
97.8% of total population (2023)
rate of urbanization:
0.41% annual rate of change (2020-25 est.)
Revenue from forest resources:
0% of GDP (2018 est.)
comparison ranking:
170
Air pollutants:
particulate matter emissions:
9.85 micrograms per cubic meter (2019 est.)
methane emissions:
0.02 megatons (2020 est.)
Waste and recycling:
municipal solid waste generated annually:
17,175 tons (2016 est.)
municipal solid waste recycled annually:
7,737 tons (2016 est.)
percent of municipal solid waste recycled:
45.1% (2016 est.)','8444237a89bbf9e38ff2a52adeb25d0ee8bba9eeffae3de84c7a6e5b1dcf0710','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7dc0df828a5d8777825bec2723c33e2555c5a04b5206c32aca1868fde6d6b4f2',2025,'ST','Sao Tome and Principe','environment',15,'Environment - current issues:
deforestation and illegal logging; soil erosion and exhaustion; inadequate sewage treatment in cities; biodiversity preservation
Environment - international agreements:
party to:
Biodiversity, Climate Change, Climate Change-Kyoto Protocol, Climate Change-Paris Agreement, Desertification, Endangered Species, Environmental Modification, Hazardous Wastes, Law of the Sea, Ozone Layer Protection, Ship Pollution, Wetlands, Whaling
signed, but not ratified:
Comprehensive Nuclear Test Ban
Climate:
tropical; hot, humid; one rainy season (October to May)
Land use:
agricultural land:
50.7% (2018 est.)
arable land:
9.1% (2018 est.)
permanent crops:
40.6% (2018 est.)
permanent pasture:
1% (2018 est.)
forest:
28.1% (2018 est.)
other:
21.2% (2018 est.)
Urbanization:
urban population:
76.4% of total population (2023)
rate of urbanization:
2.96% annual rate of change (2020-25 est.)
Revenue from forest resources:
1.9% of GDP (2018 est.)
comparison ranking:
36
Revenue from coal:
0% of GDP (2018 est.)
comparison ranking:
110
Air pollutants:
particulate matter emissions:
33.75 micrograms per cubic meter (2019 est.)
carbon dioxide emissions:
0.12 megatons (2016 est.)
methane emissions:
0.04 megatons (2020 est.)
Waste and recycling:
municipal solid waste generated annually:
25,587 tons (2014 est.)
Total water withdrawal:
municipal:
10 million cubic meters (2020 est.)
industrial:
600,000 cubic meters (2017 est.)
agricultural:
30 million cubic meters (2020 est.)
Total renewable water resources:
2.18 billion cubic meters (2020 est.)','ab6329cb707c1581efd507688398b56fbb19b87b86c273d1976391806d6fbb1f','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('239243af9944066ed66d0875a02f499ede487d92dc3cbcec08342dbc08a00279',2025,'SA','Saudi Arabia','environment',26,'Environment - current issues:
desertification; depletion of underground water resources; the lack of perennial rivers or permanent water bodies has prompted the development of extensive seawater desalination facilities; coastal pollution from oil spills; air pollution; waste management
Environment - international agreements:
party to:
Biodiversity, Climate Change, Climate Change-Kyoto Protocol, Climate Change-Paris Agreement, Desertification, Endangered Species, Hazardous Wastes, Law of the Sea, Marine Dumping-London Protocol, Ozone Layer Protection, Ship Pollution
signed, but not ratified:
none of the selected agreements
Climate:
harsh, dry desert with great temperature extremes
Land use:
agricultural land:
80.7% (2018 est.)
arable land:
1.5% (2018 est.)
permanent crops:
0.1% (2018 est.)
permanent pasture:
79.1% (2018 est.)
forest:
0.5% (2018 est.)
other:
18.8% (2018 est.)
Urbanization:
urban population:
85% of total population (2023)
rate of urbanization:
1.69% annual rate of change (2020-25 est.)
Revenue from forest resources:
0% of GDP (2018 est.)
comparison ranking:
178
Revenue from coal:
0% of GDP (2018 est.)
comparison ranking:
84
Air pollutants:
particulate matter emissions:
57.16 micrograms per cubic meter (2019 est.)
carbon dioxide emissions:
563.45 megatons (2016 est.)
methane emissions:
45.47 megatons (2020 est.)
Waste and recycling:
municipal solid waste generated annually:
16,125,701 tons (2015 est.)
municipal solid waste recycled annually:
2,418,855 tons (2015 est.)
percent of municipal solid waste recycled:
15% (2015 est.)
Major watersheds (area sq km): Indian Ocean drainage:
(Persian Gulf) Tigris and Euphrates (918,044 sq km)
Major aquifers:
Arabian Aquifer System
Total water withdrawal:
municipal:
3.39 billion cubic meters (2020 est.)
industrial:
1.4 billion cubic meters (2020 est.)
agricultural:
21.2 billion cubic meters (2020 est.)
Total renewable water resources:
2.4 billion cubic meters (2020 est.)','40a8293dc8c1306493d480c073ddea685f07b4f2f0cede8aef88e27f94d02528','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5293819859c6d457dd48fe9759602b2fce46b76ac54673b7f5ed722604843a7e',2025,'SN','Senegal','environment',39,'Environment - current issues:
deforestation; overgrazing; soil erosion; desertification; periodic droughts; seasonal flooding; overfishing; weak environmental protective laws; wildlife populations threatened by poaching
Environment - international agreements:
party to:
Biodiversity, Climate Change, Climate Change-Kyoto Protocol, Climate Change-Paris Agreement, Comprehensive Nuclear Test Ban, Desertification, Endangered Species, Hazardous Wastes, Law of the Sea, Marine Life Conservation, Nuclear Test Ban, Ozone Layer Protection, Ship Pollution, Wetlands, Whaling
signed, but not ratified:
none of the selected agreements
Climate:
tropical; hot, humid; rainy season (May to November) has strong southeast winds; dry season (December to April) dominated by hot, dry, harmattan wind
Land use:
agricultural land:
46.8% (2018 est.)
arable land:
17.4% (2018 est.)
permanent crops:
0.3% (2018 est.)
permanent pasture:
29.1% (2018 est.)
forest:
43.8% (2018 est.)
other:
9.4% (2018 est.)
Urbanization:
urban population:
49.6% of total population (2023)
rate of urbanization:
3.59% annual rate of change (2020-25 est.)
Food insecurity:
severe localized food insecurity: due to localized shortfalls in cereal production and reduced incomes -
according to the latest analysis, about 881,000 people are estimated to be in need of humanitarian assistance between June and August 2022, mostly on account of localized shortfalls in cereal production in 2021 and reduced incomes owing to the impact of the COVID-19 pandemic (2022)
Revenue from forest resources:
1.46% of GDP (2018 est.)
comparison ranking:
45
Revenue from coal:
0% of GDP (2018 est.)
comparison ranking:
76
Air pollutants:
particulate matter emissions:
38.21 micrograms per cubic meter (2019 est.)
carbon dioxide emissions:
10.9 megatons (2016 est.)
methane emissions:
11.74 megatons (2020 est.)
Waste and recycling:
municipal solid waste generated annually:
2,454,059 tons (2016 est.)
Major rivers (by length in km):
Senegal (shared with Guinea [s], Mali, and Mauritania [m]) - 1,641 km; Gambie (Gambia) (shared with Guinea [s] and The Gambia [m]) - 1,094 km
note – [s] after country name indicates river source; [m] after country name indicates river mouth
Major watersheds (area sq km): Atlantic Ocean drainage:
Senegal (456,397 sq km)
Major aquifers:
Senegalo-Mauritanian Basin
Total water withdrawal:
municipal:
260 million cubic meters (2020 est.)
industrial:
58 million cubic meters (2017 est.)
agricultural:
2.76 billion cubic meters (2020 est.)
Total renewable water resources:
38.97 billion cubic meters (2020 est.)','2281aca53ee55fadd65e04767a12f86d7d5e553e09551cfeed135c6b46ad1511','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0e92d5d4576ab74f82d2e880507f5f36dc2e18285cdaa699f1eeceb82542a291',2025,'RS','Serbia','environment',51,'Environment - current issues:
air pollution around Belgrade and other industrial cities; water pollution from industrial wastes dumped into the Sava which flows into the Danube; inadequate management of domestic, industrial, and hazardous waste
Environment - international agreements:
party to:
Air Pollution, Air Pollution-Heavy Metals, Air Pollution-Persistent Organic Pollutants, Biodiversity, Climate Change, Climate Change-Kyoto Protocol, Climate Change-Paris Agreement, Comprehensive Nuclear Test Ban, Desertification, Endangered Species, Hazardous Wastes, Law of the Sea, Marine Dumping-London Convention, Marine Life Conservation, Nuclear Test Ban, Ozone Layer Protection, Ship Pollution, Wetlands
signed, but not ratified:
none of the selected agreements
Climate:
in the north, continental climate (cold winters and hot, humid summers with well-distributed rainfall); in other parts, continental and Mediterranean climate (relatively cold winters with heavy snowfall and hot, dry summers and autumns)
Land use:
agricultural land:
57.9% (2018 est.)
arable land:
37.7% (2018 est.)
permanent crops:
3.4% (2018 est.)
permanent pasture:
16.8% (2018 est.)
forest:
31.6% (2018 est.)
other:
10.5% (2018 est.)
Urbanization:
urban population:
57.1% of total population (2023)
rate of urbanization:
0.04% annual rate of change (2020-25 est.)
note:
data include Kosovo
Revenue from forest resources:
0.38% of GDP (2018 est.)
comparison ranking:
73
Revenue from coal:
0.25% of GDP (2018 est.)
comparison ranking:
20
Air pollutants:
particulate matter emissions:
21.74 micrograms per cubic meter (2019 est.)
carbon dioxide emissions:
45.22 megatons (2016 est.)
methane emissions:
11.96 megatons (2020 est.)
Waste and recycling:
municipal solid waste generated annually:
1.84 million tons (2015 est.)
municipal solid waste recycled annually:
13,984 tons (2015 est.)
percent of municipal solid waste recycled:
0.8% (2015 est.)
Major rivers (by length in km):
Dunav (Danube) (shared with Germany [s], Austria, Slovakia, Czechia, Hungary, Croatia, Bulgaria, Ukraine, Moldova, and Romania [m]) - 2,888 km
note – [s] after country name indicates river source; [m] after country name indicates river mouth
Major watersheds (area sq km): Atlantic Ocean drainage:
(Black Sea) Danube (795,656 sq km)
Total water withdrawal:
municipal:
680 million cubic meters (2020 est.)
industrial:
3.99 billion cubic meters (2020 est.)
agricultural:
660 million cubic meters (2020 est.)
Total renewable water resources:
162.2 billion cubic meters (2020 est.) (note - includes Kosovo)','112a6f66e52a409f0718ae63c6e94ca0c5efe1e54861980b6a6d410c6d080bfb','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('816420ab568e7a4ee66993f3b6de45129d5d3ad598c36a113f0966ee23925aa9',2025,'SC','Seychelles','environment',4,'Environment - current issues:
water supply depends on catchments to collect rainwater; water pollution; biodiversity maintainance
Environment - international agreements:
party to:
Biodiversity, Climate Change, Climate Change-Kyoto Protocol, Climate Change-Paris Agreement, Comprehensive Nuclear Test Ban, Desertification, Endangered Species, Hazardous Wastes, Law of the Sea, Marine Dumping-London Convention, Nuclear Test Ban, Ozone Layer Protection, Ship Pollution, Wetlands
signed, but not ratified:
none of the selected agreements
Climate:
tropical marine; humid; cooler season during southeast monsoon (late May to September); warmer season during northwest monsoon (March to May)
Land use:
agricultural land:
6.5% (2018 est.)
arable land:
2.2% (2018 est.)
permanent crops:
4.3% (2018 est.)
permanent pasture:
0% (2018 est.)
forest:
88.5% (2018 est.)
other:
5% (2018 est.)
Urbanization:
urban population:
58.8% of total population (2023)
rate of urbanization:
0.99% annual rate of change (2020-25 est.)
Revenue from forest resources:
0.09% of GDP (2018 est.)
comparison ranking:
116
Revenue from coal:
0% of GDP (2018 est.)
comparison ranking:
59
Air pollutants:
particulate matter emissions:
16.96 micrograms per cubic meter (2019 est.)
carbon dioxide emissions:
0.61 megatons (2016 est.)
methane emissions:
0.1 megatons (2020 est.)
Waste and recycling:
municipal solid waste generated annually:
48,000 tons (2012 est.)
Total water withdrawal:
municipal:
10 million cubic meters (2020 est.)
industrial:
3.8 million cubic meters (2017 est.)
agricultural:
900,000 cubic meters (2017 est.)
Total renewable water resources:
0 cubic meters (2017 est.)','7f1df5aa4a3fee1c780747dbf77d546e61cad4c96461acb4cce4749bbd43bca8','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('29107a199a29ae0cc398e74afbd07992ceb6d47dbcecfda4ff65aacf2cbdbd2c',2025,'SL','Sierra Leone','environment',15,'Environment - current issues:
rapid population growth pressuring the environment; overharvesting of timber, expansion of cattle grazing, and slash-and-burn agriculture have resulted in deforestation, soil exhaustion, and flooding; loss of biodiversity; air pollution; water pollution; overfishing
Environment - international agreements:
party to:
Biodiversity, Climate Change, Climate Change-Kyoto Protocol, Climate Change-Paris Agreement, Comprehensive Nuclear Test Ban, Desertification, Endangered Species, Hazardous Wastes, Law of the Sea, Marine Dumping-London Convention, Marine Dumping-London Protocol, Marine Life Conservation, Nuclear Test Ban, Ozone Layer Protection, Ship Pollution, Wetlands
signed, but not ratified:
Environmental Modification
Climate:
tropical; hot, humid; summer rainy season (May to December); winter dry season (December to April)
Land use:
agricultural land:
56.2% (2018 est.)
arable land:
23.4% (2018 est.)
permanent crops:
2.3% (2018 est.)
permanent pasture:
30.5% (2018 est.)
forest:
37.5% (2018 est.)
other:
6.3% (2018 est.)
Urbanization:
urban population:
44.3% of total population (2023)
rate of urbanization:
3.02% annual rate of change (2020-25 est.)
Food insecurity:
severe localized food insecurity: due to high food prices and reduced incomes -
according to the latest analysis, about 1.18 million people are projected to be in need of humanitarian assistance between the June to August 2023 lean season; acute food insecurity is underpinned by elevated food prices, in part driven by a weak currency, and low purchasing power of vulnerable households (2023)
Revenue from forest resources:
6.92% of GDP (2018 est.)
comparison ranking:
8
Revenue from coal:
0% of GDP (2018 est.)
comparison ranking:
133
Air pollutants:
particulate matter emissions:
39.42 micrograms per cubic meter (2019 est.)
carbon dioxide emissions:
1.09 megatons (2016 est.)
methane emissions:
3.16 megatons (2020 est.)
Waste and recycling:
municipal solid waste generated annually:
610,222 tons (2004 est.)
Major watersheds (area sq km): Atlantic Ocean drainage:
Niger (2,261,741 sq km)
Total water withdrawal:
municipal:
110 million cubic meters (2020 est.)
industrial:
60 million cubic meters (2020 est.)
agricultural:
50 million cubic meters (2020 est.)
Total renewable water resources:
160 billion cubic meters (2020 est.)','74890431e2ccb715a9109e48e5d27d8e7b4ceb08b74d1b5744726c9c7b25dedc','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f027880caa0d523594ab1319ac9ac291cf0eb426194036be73ca5d7eedd0dca9',2025,'SG','Singapore','environment',26,'Environment - current issues:
water pollution; industrial pollution; limited natural freshwater resources; limited land availability presents waste disposal problems; air pollution; deforestation; seasonal smoke/haze resulting from forest fires in Indonesia
Environment - international agreements:
party to:
Biodiversity, Climate Change, Climate Change-Kyoto Protocol, Climate Change-Paris Agreement, Comprehensive Nuclear Test Ban, Desertification, Endangered Species, Hazardous Wastes, Law of the Sea, Nuclear Test Ban, Ozone Layer Protection, Ship Pollution
signed, but not ratified:
none of the selected agreements
Climate:
tropical; hot, humid, rainy; two distinct monsoon seasons - northeastern monsoon (December to March) and southwestern monsoon (June to September); inter-monsoon - frequent afternoon and early evening thunderstorms
Land use:
agricultural land:
1% (2018 est.)
arable land:
0.9% (2018 est.)
permanent crops:
0.1% (2018 est.)
permanent pasture:
0% (2018 est.)
forest:
3.3% (2018 est.)
other:
95.7% (2018 est.)
Urbanization:
urban population:
100% of total population (2023)
rate of urbanization:
0.74% annual rate of change (2020-25 est.)
Revenue from forest resources:
0% of GDP (2018 est.)
comparison ranking:
190
Revenue from coal:
0% of GDP (2018 est.)
comparison ranking:
131
Air pollutants:
particulate matter emissions:
13.33 micrograms per cubic meter (2019 est.)
carbon dioxide emissions:
37.54 megatons (2016 est.)
methane emissions:
4.4 megatons (2020 est.)
Waste and recycling:
municipal solid waste generated annually:
7,704,300 tons (2017 est.)
municipal solid waste recycled annually:
4,699,623 tons (2015 est.)
percent of municipal solid waste recycled:
61% (2015 est.)
Total water withdrawal:
municipal:
300 million cubic meters (2020 est.)
industrial:
340 million cubic meters (2020 est.)
agricultural:
30 million cubic meters (2020 est.)
Total renewable water resources:
600 million cubic meters (2020 est.)','f601dd770a14215e3a18b63d57bdad28683f82f27406d7c5f830f513efa79f59','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('70fe9f20bd363199addc51f00dd00479d3fa1dd399017f98f3fdf3b7b05026d7',2025,'SG','Singapore','environment',39,'Environment - current issues:
scarcity of potable water (increasing percentage provided by desalination); inadequate solid waste management; pollution from construction, chemical runoff, and sewage harms reefs
Climate:
tropical marine climate, ameliorated by northeast trade winds, results in moderate temperatures; average rainfall of 150 cm/year; hurricane season stretches from July to November
Urbanization:
urban population:
100% of total population (2023)
rate of urbanization:
1.16% annual rate of change (2020-25 est. est.)','bad030f7cc85b3de1a44f14f0368b01f8538237f4ce5e7b6f24b88b44403b92b','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b31a5f71604052a38712e4b444477bf8d0c0665a7431623d776935770f71d342',2025,'SK','Slovakia','environment',50,'Environment - current issues:
air pollution and acid rain present human health risks and damage forests; land erosion caused by agricultural and mining practices; water pollution
Environment - international agreements:
party to:
Air Pollution, Air Pollution-Heavy Metals, Air Pollution-Multi-effect Protocol, Air Pollution-Nitrogen Oxides, Air Pollution-Persistent Organic Pollutants, Air Pollution-Sulphur 85, Air Pollution-Sulphur 94, Air Pollution-Volatile Organic Compounds, Antarctic Treaty, Biodiversity, Climate Change, Climate Change-Kyoto Protocol, Climate Change-Paris Agreement, Comprehensive Nuclear Test Ban, Desertification, Endangered Species, Environmental Modification, Hazardous Wastes, Law of the Sea, Nuclear Test Ban, Ozone Layer Protection, Ship Pollution, Tropical Timber 2006, Wetlands, Whaling
signed, but not ratified:
Antarctic-Environmental Protection
Climate:
temperate; cool summers; cold, cloudy, humid winters
Land use:
agricultural land:
40.1% (2018 est.)
arable land:
28.9% (2018 est.)
permanent crops:
0.4% (2018 est.)
permanent pasture:
10.8% (2018 est.)
forest:
40.2% (2018 est.)
other:
19.7% (2018 est.)
Urbanization:
urban population:
54% of total population (2023)
rate of urbanization:
0.17% annual rate of change (2020-25 est.)
Revenue from forest resources:
0.22% of GDP (2018 est.)
comparison ranking:
89
Revenue from coal:
0.01% of GDP (2018 est.)
comparison ranking:
48
Air pollutants:
particulate matter emissions:
15.89 micrograms per cubic meter (2019 est.)
carbon dioxide emissions:
32.42 megatons (2016 est.)
methane emissions:
4.43 megatons (2020 est.)
Waste and recycling:
municipal solid waste generated annually:
1.784 million tons (2015 est.)
municipal solid waste recycled annually:
135,941 tons (2015 est.)
percent of municipal solid waste recycled:
7.6% (2015 est.)
Major rivers (by length in km):
Dunaj (Danube) (shared with Germany [s], Austria, Hungary, Croatia, Serbia, Bulgaria, Ukraine, Moldova, and Romania [m]) - 2,888 km
note – [s] after country name indicates river source; [m] after country name indicates river mouth
Major watersheds (area sq km): Atlantic Ocean drainage:
(Black Sea) Danube (795,656 sq km)
Total water withdrawal:
municipal:
290 million cubic meters (2020 est.)
industrial:
230 million cubic meters (2020 est.)
agricultural:
30 million cubic meters (2020 est.)
Total renewable water resources:
50.1 billion cubic meters (2020 est.)','1fa192ec8f370b29bf53610ce3fc5eed4a4a3fd497e256e88e33bcbb5839e7d6','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0f1095284bdd78791ff31ff9af9761272d68a7111405d1a92730ae4b32dc3c5c',2025,'SI','Slovenia','environment',4,'Environment - current issues:
air pollution from road traffic, domestic heating (wood buring), power generation, and industry; water pollution; biodiversity protection
Environment - international agreements:
party to:
Air Pollution, Air Pollution-Heavy Metals, Air Pollution-Multi-effect Protocol, Air Pollution-Nitrogen Oxides, Air Pollution-Persistent Organic Pollutants, Air Pollution-Sulphur 94, Antarctic Treaty, Biodiversity, Climate Change, Climate Change-Kyoto Protocol, Climate Change-Paris Agreement, Comprehensive Nuclear Test Ban, Desertification, Endangered Species, Environmental Modification, Hazardous Wastes, Law of the Sea, Marine Dumping-London Convention, Marine Dumping-London Protocol, Nuclear Test Ban, Ozone Layer Protection, Ship Pollution, Tropical Timber 2006, Wetlands, Whaling
signed, but not ratified:
none of the selected agreements
Climate:
Mediterranean climate on the coast, continental climate with mild to hot summers and cold winters in the plateaus and valleys to the east
Land use:
agricultural land:
22.8% (2018 est.)
arable land:
8.4% (2018 est.)
permanent crops:
1.3% (2018 est.)
permanent pasture:
13.1% (2018 est.)
forest:
62.3% (2018 est.)
other:
14.9% (2018 est.)
Urbanization:
urban population:
56.1% of total population (2023)
rate of urbanization:
0.54% annual rate of change (2020-25 est.)
Revenue from forest resources:
0.2% of GDP (2018 est.)
comparison ranking:
93
Revenue from coal:
0.03% of GDP (2018 est.)
comparison ranking:
41
Air pollutants:
particulate matter emissions:
14.08 micrograms per cubic meter (2019 est.)
carbon dioxide emissions:
12.63 megatons (2016 est.)
methane emissions:
2.1 megatons (2020 est.)
Waste and recycling:
municipal solid waste generated annually:
926,000 tons (2015 est.)
municipal solid waste recycled annually:
430,034 tons (2015 est.)
percent of municipal solid waste recycled:
46.4% (2015 est.)
Major watersheds (area sq km): Atlantic Ocean drainage:
(Black Sea) Danube (795,656 sq km)
Total water withdrawal:
municipal:
170 million cubic meters (2020 est.)
industrial:
830 million cubic meters (2020 est.)
agricultural:
3.9 million cubic meters (2017 est.)
Total renewable water resources:
31.87 billion cubic meters (2020 est.)','0e12f0870039024c7e85e62eb5a2b431fbb4dad8901562ab309fff42a6eba785','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('36b36c9d6b7f00fa081a316a5cc715d5990865d51f048d0d32a5a1b9dd7e380d',2025,'SB','Solomon Islands','environment',15,'Environment - current issues:
deforestation; soil erosion; many of the surrounding coral reefs are dead or dying, exhibiting the effects of climate change and rising sea levels
Environment - international agreements:
party to:
Biodiversity, Climate Change, Climate Change-Kyoto Protocol, Climate Change-Paris Agreement, Desertification, Endangered Species, Environmental Modification, Law of the Sea, Marine Dumping-London Convention, Marine Life Conservation, Ozone Layer Protection, Ship Pollution, Whaling
signed, but not ratified:
Comprehensive Nuclear Test Ban
Climate:
tropical monsoon; few temperature and weather extremes
Land use:
agricultural land:
3.9% (2018 est.)
arable land:
0.7% (2018 est.)
permanent crops:
2.9% (2018 est.)
permanent pasture:
0.3% (2018 est.)
forest:
78.9% (2018 est.)
other:
17.2% (2018 est.)
Urbanization:
urban population:
26% of total population (2023)
rate of urbanization:
3.57% annual rate of change (2020-25 est.)
Revenue from forest resources:
20.27% of GDP (2018 est.)
comparison ranking:
1
Revenue from coal:
0% of GDP (2018 est.)
comparison ranking:
150
Air pollutants:
particulate matter emissions:
7.83 micrograms per cubic meter (2019 est.)
carbon dioxide emissions:
0.17 megatons (2016 est.)
methane emissions:
0.43 megatons (2020 est.)
Waste and recycling:
municipal solid waste generated annually:
179,972 tons (2013 est.)
Total renewable water resources:
44.7 billion cubic meters (2020 est.)','f15e24371f895de260ed42747700e5226f674fbae5c5c4493c324b75546da3c4','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('953e486b843c8ee32064fbf032c0ea265f1d73f1b49303aa40c41061493c43ee',2025,'SO','Somalia','environment',26,'Environment - current issues:
water scarcity; contaminated water contributes to human health problems; improper waste disposal; deforestation; land degradation; overgrazing; soil erosion; desertification
Environment - international agreements:
party to:
Biodiversity, Climate Change, Climate Change-Kyoto Protocol, Climate Change-Paris Agreement, Desertification, Endangered Species, Hazardous Wastes, Law of the Sea, Ozone Layer Protection
signed, but not ratified:
Nuclear Test Ban
Climate:
principally desert; northeast monsoon (December to February), moderate temperatures in north and hot in south; southwest monsoon (May to October), torrid in the north and hot in the south, irregular rainfall, hot and humid periods (tangambili) between monsoons
Land use:
agricultural land:
70.3% (2018 est.)
arable land:
1.8% (2018 est.)
permanent crops:
0% (2018 est.)
permanent pasture:
68.5% (2018 est.)
forest:
10.6% (2018 est.)
other:
19.1% (2018 est.)
Urbanization:
urban population:
47.9% of total population (2023)
rate of urbanization:
4.2% annual rate of change (2020-25 est.)
Food insecurity:
exceptional shortfall in aggregate food production/supplies:
due to drought conditions and internal conflict - about 6.5 million people are estimated to face severe acute food insecurity between April and June 2023 as a result of consecutive poor rainy seasons since late 2020 and heightened conflict since early 2021 (2023)
Air pollutants:
particulate matter emissions:
14.28 micrograms per cubic meter (2019 est.)
carbon dioxide emissions:
0.65 megatons (2016 est.)
methane emissions:
20.13 megatons (2020 est.)
Waste and recycling:
municipal solid waste generated annually:
2,326,099 tons (2016 est.)
Major aquifers:
Ogaden-Juba Basin
Total water withdrawal:
municipal:
20 million cubic meters (2020 est.)
industrial:
2 million cubic meters (2017 est.)
agricultural:
3.28 billion cubic meters (2020 est.)
Total renewable water resources:
14.7 billion cubic meters (2020 est.)','70ab9ebbc4a2a2de1b001702a206fb657a885f9e79b47bb34bcfdfbc59f677a4','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('95bcab19f91b901c316639239cec7be2cac05f4b4f3efe646ec30ea67d71474f',2025,'ZA','South Africa','environment',38,'Environment - current issues:
lack of important arterial rivers or lakes requires extensive water conservation and control measures; growth in water usage outpacing supply; pollution of rivers from agricultural runoff and urban discharge; air pollution resulting in acid rain; deforestation; soil erosion; land degradation; desertification; solid waste pollution; disruption of fragile ecosystem has resulted in significant floral extinctions
Environment - international agreements:
party to:
Antarctic-Environmental Protection, Antarctic-Marine Living Resources, Antarctic Seals, Antarctic Treaty, Biodiversity, Climate Change, Climate Change-Kyoto Protocol, Climate Change-Paris Agreement, Comprehensive Nuclear Test Ban, Desertification, Endangered Species, Hazardous Wastes, Law of the Sea, Marine Dumping-London Convention, Marine Dumping-London Protocol, Marine Life Conservation, Nuclear Test Ban, Ozone Layer Protection, Ship Pollution, Wetlands, Whaling
signed, but not ratified:
none of the selected agreements
Climate:
mostly semiarid; subtropical along east coast; sunny days, cool nights
Land use:
agricultural land:
79.4% (2018 est.)
arable land:
9.9% (2018 est.)
permanent crops:
0.3% (2018 est.)
permanent pasture:
69.2% (2018 est.)
forest:
7.6% (2018 est.)
other:
13% (2018 est.)
Urbanization:
urban population:
68.8% of total population (2023)
rate of urbanization:
1.72% annual rate of change (2020-25 est.)
Revenue from coal:
2.4% of GDP (2018 est.)
comparison ranking:
3
Air pollutants:
particulate matter emissions:
19.75 micrograms per cubic meter (2019 est.)
carbon dioxide emissions:
476.64 megatons (2016 est.)
methane emissions:
55.89 megatons (2020 est.)
Waste and recycling:
municipal solid waste generated annually:
18,457,232 tons (2011 est.)
municipal solid waste recycled annually:
5,168,025 tons (2011 est.)
percent of municipal solid waste recycled:
28% (2011 est.)
Major rivers (by length in km):
Orange (shared with Lesotho [s], and Namibia [m]) - 2,092 km; Limpoporivier (Limpopo) river source (shared with Botswana, Zimbabwe, and Mozambique [m]) - 1,800 km; Vaal [s] - 1,210 km
note – [s] after country name indicates river source; [m] after country name indicates river mouth
Major watersheds (area sq km): Atlantic Ocean drainage:
Orange (941,351 sq km)
Major aquifers:
Karoo Basin, Lower Kalahari-Stampriet Basin
Total water withdrawal:
municipal:
3.11 billion cubic meters (2020 est.)
industrial:
4.09 billion cubic meters (2020 est.)
agricultural:
11.99 billion cubic meters (2020 est.)
Total renewable water resources:
51.35 billion cubic meters (2020 est.)','bf30fc611ae297b9c3b23a277b41f27bea6f6ffbaf0465f283ad0bc44dda3919','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('26cb50d4dd4b35b541eb5d702cc69e758b30f98a68e7e77132b2c92555573d65',2025,'SS','South Sudan','environment',5,'Environment - current issues:
water pollution; inadequate supplies of potable water; wildlife conservation and loss of biodiversity; deforestation; soil erosion; desertification; periodic drought
Environment - international agreements:
party to:
Biodiversity, Climate Change, Climate Change-Paris Agreement, Desertification, Ozone Layer Protection, Wetlands
signed, but not ratified:
none of the selected agreements
Climate:
hot with seasonal rainfall influenced by the annual shift of the Inter-Tropical Convergence Zone; rainfall heaviest in upland areas of the south and diminishes to the north
Land use:
agricultural land:
45% (2018)
arable land:
4.4% (2018)
permanent pasture:
40.7% (2018)
forest:
11.3% (2018)
other:
43.5% (2018)
Urbanization:
urban population:
21.2% of total population (2023)
rate of urbanization:
4.12% annual rate of change (2020-25 est.)
Food insecurity:
widespread lack of access:
due to economic downturn, the lingering effects of floods, and prolonged internal conflict - despite sustained humanitarian assistance, food insecurity still affects large segments of the population, owing to rampant inflation and insufficient food supplies due to stagnant agricultural production, the effects of consecutive years with widespread floods, and the escalation of organized violence at the subnational level since 2020; about 7.76 million people, almost two thirds of the total population, are expected to face severe acute food insecurity in the lean season between April and July 2023 (2023)
Revenue from forest resources:
2.65% of GDP (2015 est.)
comparison ranking:
25
Air pollutants:
particulate matter emissions:
20.18 micrograms per cubic meter (2019 est.)
carbon dioxide emissions:
1.73 megatons (2016 est.)
methane emissions:
7.61 megatons (2020 est.)
Waste and recycling:
municipal solid waste generated annually:
2,680,681 tons (2013 est.)
Major rivers (by length in km):
Nile (shared with Rwanda [s], Tanzania, Uganda, Sudan, and Egypt [m]) - 6,650 km
note – [s] after country name indicates river source; [m] after country name indicates river mouth
Major watersheds (area sq km): Atlantic Ocean drainage:
Congo (3,730,881 sq km), (Mediterranean Sea) Nile (3,254,853 sq km)
Total water withdrawal:
municipal:
190 million cubic meters (2020 est.)
industrial:
230 million cubic meters (2020 est.)
agricultural:
240 million cubic meters (2020 est.)
Total renewable water resources:
49.5 billion cubic meters (2020 est.)','c635b0be353616d7663c406cad76cfb6d34def975e09b714cb53cd4d4a3e9012','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4558cd50a07cfe9b975572608533a96d06cfe58b21df76fb1129b0f229c7b1fd',2025,'SS','South Sudan','environment',15,'Environment - current issues:
changes to the ocean’s physical, chemical, and biological systems have taken place because of climate change, ocean acidification, and commercial exploitation
Environment - international agreements:
the Southern Ocean is subject to all international agreements regarding the world’s oceans; in addition, it is subject to these agreements specific to the Antarctic region: International Whaling Commission (prohibits commercial whaling south of 40 degrees south [south of 60 degrees south between 50 degrees and 130 degrees west]); Convention on the Conservation of Antarctic Seals (limits sealing); Convention on the Conservation of Antarctic Marine Living Resources (regulates fishing) note: mineral exploitation except for scientific research is banned by the Environmental Protocol to the Antarctic Treaty; additionally, many nations (including the US) prohibit mineral resource exploration and exploitation south of the fluctuating Polar Front (Antarctic Convergence), which is in the middle of the Antarctic Circumpolar Current and serves as the dividing line between the cold polar surface waters to the south and the warmer waters to the north
Climate:
sea temperatures vary from about 10 degrees Celsius to -2 degrees Celsius; cyclonic storms travel eastward around the continent and frequently are intense because of the temperature contrast between ice and open ocean; the ocean area from about latitude 40 south to the Antarctic Circle has the strongest average winds found anywhere on Earth; in winter the ocean freezes outward to 65 degrees south latitude in the Pacific sector and 55 degrees south latitude in the Atlantic sector, lowering surface temperatures well below 0 degrees Celsius; at some coastal points intense persistent drainage winds from the interior keep the shoreline ice-free throughout the winter
Marine fisheries:
the Southern Ocean fishery is relatively small with a total catch of 388,901 mt in 2021; the Food and Agriculture Organization has delineated three regions in the Southern Ocean (Regions 48, 58, 88) that generally encompass the waters south of 40° to 60° South latitude; the most important producers in these regions include Norway (241,408 mt), China (47,605 mt), and South Korea (39,487 mt); Antarctic Krill made up 95.5% of the total catch in 2021, while other important species include Patagonian and Antarctic toothfish
Regional fisheries bodies:
Commission on the Conservation of Antarctic Marine Living Resources','54545e61e4e08d7358f447c85c2f44d0f50a6bdda41793c129d4028ebf3395ad','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fb9253688748cce2893cbe615c1dcedf6423f910a360451962a14571378b1167',2025,'ES','Spain','environment',22,'Environment - current issues:
pollution of the Mediterranean Sea from raw sewage and effluents from the offshore production of oil and gas and drought are negatively impacting water quality and quantity nationwide; air pollution; deforestation; desertification
Environment - international agreements:
party to:
Air Pollution, Air Pollution-Heavy Metals, Air Pollution-Multi-effect Protocol, Air Pollution-Nitrogen Oxides, Air Pollution-Persistent Organic Pollutants, Air Pollution-Sulphur 94, Air Pollution-Volatile Organic Compounds, Antarctic-Environmental Protection, Antarctic-Marine Living Resources, Antarctic Treaty, Biodiversity, Climate Change, Climate Change-Kyoto Protocol, Climate Change-Paris Agreement, Comprehensive Nuclear Test Ban, Desertification, Endangered Species, Environmental Modification, Hazardous Wastes, Law of the Sea, Marine Dumping-London Convention, Marine Dumping-London Protocol, Marine Life Conservation, Nuclear Test Ban, Ozone Layer Protection, Ship Pollution, Tropical Timber 2006, Wetlands, Whaling
signed, but not ratified:
none of the selected agreements
Climate:
temperate; clear, hot summers in interior, more moderate and cloudy along coast; cloudy, cold winters in interior, partly cloudy and cool along coast
Land use:
agricultural land:
54.1% (2018 est.)
arable land:
24.9% (2018 est.)
permanent crops:
9.1% (2018 est.)
permanent pasture:
20.1% (2018 est.)
forest:
36.8% (2018 est.)
other:
9.1% (2018 est.)
Urbanization:
urban population:
81.6% of total population (2023)
rate of urbanization:
0.24% annual rate of change (2020-25 est.)
note:
data include Canary Islands, Ceuta, and Melilla
Revenue from forest resources:
0.02% of GDP (2018 est.)
comparison ranking:
144
Revenue from coal:
0% of GDP (2018 est.)
comparison ranking:
163
Air pollutants:
particulate matter emissions:
9.34 micrograms per cubic meter (2019 est.)
carbon dioxide emissions:
244 megatons (2016 est.)
methane emissions:
36.94 megatons (2020 est.)
Waste and recycling:
municipal solid waste generated annually:
20.151 million tons (2015 est.)
municipal solid waste recycled annually:
3,393,428 tons (2015 est.)
percent of municipal solid waste recycled:
16.8% (2015 est.)
Major rivers (by length in km):
Tagus river source (shared with Portugal [m]) - 1,006
note – [s] after country name indicates river source; [m] after country name indicates river mouth
Total water withdrawal:
municipal:
4.56 billion cubic meters (2020 est.)
industrial:
5.5 billion cubic meters (2020 est.)
agricultural:
18.96 billion cubic meters (2020 est.)
Total renewable water resources:
111.5 billion cubic meters (2020 est.)','81808f9bfad70eb1f537d155e52a1ac0f50dc5ab8cbfd14f119a215457e72ffa','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('689460312bb4713945c7c176c25c41a9f39f3af5011cab351a9d18b3d17bc260',2025,'ES','Spain','environment',35,'Environment - current issues:
China’s use of dredged sand and coral to build artificial islands harms reef systems; illegal fishing practices indiscriminately harvest endangered species, including sea turtles and giant clams
Climate:
tropical
Land use:
other:
100% (2018 est.)','eabbbed6ae5e13ddb26929f974707b352e9ab05108a3caa2f830b35d4cb84c76','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6defe3f4ff6e25b6052c185983be28e4feee619da7b7cdb3df7fa447bf9448e1',2025,'LK','Sri Lanka','environment',43,'Environment - current issues:
deforestation; soil erosion; wildlife populations threatened by poaching and urbanization; coastal degradation from mining activities and increased pollution; coral reef destruction; freshwater resources being polluted by industrial wastes and sewage runoff; waste disposal; air pollution in Colombo
Environment - international agreements:
party to:
Biodiversity, Climate Change, Climate Change-Kyoto Protocol, Climate Change-Paris Agreement, Desertification, Endangered Species, Environmental Modification, Hazardous Wastes, Law of the Sea, Nuclear Test Ban, Ozone Layer Protection, Ship Pollution, Wetlands
signed, but not ratified:
Comprehensive Nuclear Test Ban, Marine Life Conservation
Climate:
tropical monsoon; northeast monsoon (December to March); southwest monsoon (June to October)
Land use:
agricultural land:
43.5% (2018 est.)
arable land:
20.7% (2018 est.)
permanent crops:
15.8% (2018 est.)
permanent pasture:
7% (2018 est.)
forest:
29.4% (2018 est.)
other:
27.1% (2018 est.)
Urbanization:
urban population:
19.2% of total population (2023)
rate of urbanization:
1.22% annual rate of change (2020-25 est.)
Food insecurity:
widespread lack of access: due to serious macroeconomic challenges, significant reduction in 2022 cereal output, and high food prices
- severe macroeconomic challenges, mostly reflecting dwindling foreign currency reserves after revenues from merchandise exports, remittances, and from the tourist sector declined dramatically over the last year, have had a negative impact on the country’s capacity to import cereals; the 2022 cereal production sharply declined due to a government ordered reduction in the application of chemical fertilizers; unprecedentedly high food prices are constraining economic access to food for a majority of households
Revenue from forest resources:
0.06% of GDP (2018 est.)
comparison ranking:
126
Revenue from coal:
0% of GDP (2018 est.)
comparison ranking:
178
Air pollutants:
particulate matter emissions:
23.88 micrograms per cubic meter (2019 est.)
carbon dioxide emissions:
23.36 megatons (2016 est.)
methane emissions:
10.95 megatons (2020 est.)
Waste and recycling:
municipal solid waste generated annually:
2,631,650 tons (2016 est.)
municipal solid waste recycled annually:
336,588 tons (2016 est.)
percent of municipal solid waste recycled:
12.8% (2016 est.)
Total water withdrawal:
municipal:
810 million cubic meters (2020 est.)
industrial:
830 million cubic meters (2020 est.)
agricultural:
11.31 billion cubic meters (2020 est.)
Total renewable water resources:
52.8 billion cubic meters (2020 est.)','7d656524cd5ee37ca14591cdf715b20ee96f457723db0ba6252c36528cf2e777','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f9a0d03bd8909fc3b82f84d2c99d4edeaafdf04833ff8b7bbd16a07af0e0a897',2025,'SD','Sudan','environment',56,'Environment - current issues:
water pollution; inadequate supplies of potable water; water scarcity and periodic drought; wildlife populations threatened by excessive hunting; soil erosion; desertification; deforestation; loss of biodiversity
Environment - international agreements:
party to:
Biodiversity, Climate Change, Climate Change-Kyoto Protocol, Climate Change-Paris Agreement, Comprehensive Nuclear Test Ban, Desertification, Endangered Species, Hazardous Wastes, Law of the Sea, Nuclear Test Ban, Ozone Layer Protection, Wetlands
signed, but not ratified:
none of the selected agreements
Climate:
hot and dry; arid desert; rainy season varies by region (April to November)
Land use:
agricultural land:
100% (2018 est.)
arable land:
15.7% (2018 est.)
permanent crops:
0.2% (2018 est.)
permanent pasture:
84.2% (2018 est.)
forest:
0% (2018 est.)
other:
0% (2018 est.)
Urbanization:
urban population:
36.3% of total population (2023)
rate of urbanization:
3.43% annual rate of change (2020-25 est.)
Food insecurity:
severe localized food insecurity: due to conflict, civil insecurity, and soaring food prices -
according to the results of the latest analysis, about 11.7 million people (24% of the analyzed population) are estimated to be severely food insecure during June to September 2022; the main drivers are macroeconomic challenges resulting in rampant food and non-food inflation, tight supplies due to a poor 2021 harvest and the escalation of intercommunal violence (2022)
Revenue from forest resources:
3.01% of GDP (2018 est.)
comparison ranking:
24
Revenue from coal:
0% of GDP (2018 est.)
comparison ranking:
173
Air pollutants:
particulate matter emissions:
21.43 micrograms per cubic meter (2019 est.)
carbon dioxide emissions:
20 megatons (2016 est.)
methane emissions:
75.1 megatons (2020 est.)
Waste and recycling:
municipal solid waste generated annually:
2,831,291 tons (2015 est.)
Major rivers (by length in km):
An Nīl (Nile) (shared with Rwanda [s], Tanzania, Uganda, South Sudan, and Egypt [m]) - 6,650 km; Blue Nile river mouth (shared with Ethiopia [s]) - 1,600 km
note – [s] after country name indicates river source; [m] after country name indicates river mouth
Major watersheds (area sq km): Atlantic Ocean drainage:
(Mediterranean Sea) Nile (3,254,853 sq km)
Internal (endorheic basin) drainage:
Lake Chad (2,497,738 sq km)
Major aquifers:
Nubian Aquifer System, Sudd Basin (Umm Ruwaba Aquifer)
Total water withdrawal:
municipal:
950 million cubic meters (2020 est.)
industrial:
80 million cubic meters (2020 est.)
agricultural:
25.91 billion cubic meters (2020 est.)
Total renewable water resources:
37.8 billion cubic meters (2020 est.)','23a527e933b2a798eabff375824a382278b7d42219c4a0ea01bd7efc64b9e55b','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b8abf606b1e359cd853a6d8ed569a2a18c4803f0a1a803185f2905d1c25905e8',2025,'SR','Suriname','environment',4,'Environment - current issues:
deforestation as timber is cut for export; pollution of inland waterways by small-scale mining activities
Environment - international agreements:
party to:
Biodiversity, Climate Change, Climate Change-Kyoto Protocol, Climate Change-Paris Agreement, Comprehensive Nuclear Test Ban, Desertification, Endangered Species, Hazardous Wastes, Law of the Sea, Marine Dumping-London Convention, Marine Dumping-London Protocol, Nuclear Test Ban, Ozone Layer Protection, Ship Pollution, Tropical Timber 2006, Wetlands, Whaling
signed, but not ratified:
none of the selected agreements
Climate:
tropical; moderated by trade winds
Land use:
agricultural land:
0.5% (2018 est.)
arable land:
0.4% (2018 est.)
permanent crops:
0% (2018 est.)
permanent pasture:
0.1% (2018 est.)
forest:
94.6% (2018 est.)
other:
4.9% (2018 est.)
Urbanization:
urban population:
66.4% of total population (2023)
rate of urbanization:
0.88% annual rate of change (2020-25 est.)
Revenue from forest resources:
2.36% of GDP (2018 est.)
comparison ranking:
29
Revenue from coal:
0% of GDP (2018 est.)
comparison ranking:
140
Air pollutants:
particulate matter emissions:
12.17 micrograms per cubic meter (2019 est.)
carbon dioxide emissions:
1.74 megatons (2016 est.)
methane emissions:
2.28 megatons (2020 est.)
Waste and recycling:
municipal solid waste generated annually:
78,620 tons (2010 est.)
Major watersheds (area sq km): Atlantic Ocean drainage:
Amazon (6,145,186 sq km)
Total water withdrawal:
municipal:
50 million cubic meters (2020 est.)
industrial:
140 million cubic meters (2020 est.)
agricultural:
430 million cubic meters (2020 est.)
Total renewable water resources:
99 billion cubic meters (2020 est.)','31bc5935db6ad8b4f93cb7fa330fc7cdfde1cb5af232596494cd1b760eb3d0ac','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f9accb78d3c75bcf2e2492c12d5cd0016c6724382f7128a9de0964673cadcc3c',2025,'SR','Suriname','environment',15,'Environment - current issues:
ice floes are a maritime hazard; past exploitation of mammal species (whale, seal, walrus, and polar bear) severely depleted the populations, but a gradual recovery seems to be occurring
Climate:
arctic, tempered by warm North Atlantic Current; cool summers, cold winters; North Atlantic Current flows along west and north coasts of Spitsbergen, keeping water open and navigable most of the year
Land use:
agricultural land:
0% (2018 est.)
other:
100% (2018 est.)','2eef100447b3abfc08d8b27459edeedcf58d1e0b67564ba4596148797dbd8fd8','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('66d3ac6f14c8183a9fe891e2543a7b5d2d30c954735794c5f96dc27d3c235839',2025,'SE','Sweden','environment',26,'Environment - current issues:
marine pollution (Baltic Sea and North Sea); acid rain damage to soils and lakes; air pollution; inappropriate timber harvesting practices
Environment - international agreements:
party to:
Air Pollution, Air Pollution-Heavy Metals, Air Pollution-Multi-effect Protocol, Air Pollution-Nitrogen Oxides, Air Pollution-Persistent Organic Pollutants, Air Pollution-Sulphur 85, Air Pollution-Sulphur 94, Air Pollution-Volatile Organic Compounds, Antarctic-Environmental Protection, Antarctic-Marine Living Resources, Antarctic Treaty, Biodiversity, Climate Change, Climate Change-Kyoto Protocol, Climate Change-Paris Agreement, Comprehensive Nuclear Test Ban, Desertification, Endangered Species, Environmental Modification, Hazardous Wastes, Law of the Sea, Marine Dumping-London Convention, Marine Dumping-London Protocol, Nuclear Test Ban, Ozone Layer Protection, Ship Pollution, Tropical Timber 2006, Wetlands, Whaling
signed, but not ratified:
none of the selected agreements
Climate:
temperate in south with cold, cloudy winters and cool, partly cloudy summers; subarctic in north
Land use:
agricultural land:
7.5% (2018 est.)
arable land:
6.4% (2018 est.)
permanent crops:
0% (2018 est.)
permanent pasture:
1.1% (2018 est.)
forest:
68.7% (2018 est.)
other:
23.8% (2018 est.)
Urbanization:
urban population:
88.7% of total population (2023)
rate of urbanization:
0.89% annual rate of change (2020-25 est.)
Revenue from forest resources:
0.21% of GDP (2018 est.)
comparison ranking:
91
Revenue from coal:
0% of GDP (2018 est.)
comparison ranking:
161
Air pollutants:
particulate matter emissions:
5.96 micrograms per cubic meter (2019 est.)
carbon dioxide emissions:
43.25 megatons (2016 est.)
methane emissions:
4.42 megatons (2020 est.)
Waste and recycling:
municipal solid waste generated annually:
4.377 million tons (2015 est.)
municipal solid waste recycled annually:
1,416,835 tons (2015 est.)
percent of municipal solid waste recycled:
32.4% (2015 est.)
Major lakes (area sq km):
fresh water lake(s):
Vanern - 5,580 sq km; Vattern - 1,910 sq km; Malaren - 1,140 sq km
Total water withdrawal:
municipal:
700 million cubic meters (2020 est.)
industrial:
1.27 billion cubic meters (2020 est.)
agricultural:
100 million cubic meters (2020 est.)
Total renewable water resources:
174 billion cubic meters (2020 est.)','8862cbe8f0e599e7a889ab6ed1b0388bc3a06e0b21ea9028f13c2f6ef4b21dd0','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('98dd35a4dd96c70ba7f26e6d34ce80920984710e7e1c311630ebd74585e26b75',2025,'CH','Switzerland','environment',39,'Environment - current issues:
air pollution from vehicle emissions; water pollution from agricultural fertilizers; chemical contaminants and erosion damage the soil and limit productivity; loss of biodiversity
Environment - international agreements:
party to:
Air Pollution, Air Pollution-Heavy Metals, Air Pollution-Multi-effect Protocol, Air Pollution-Nitrogen Oxides, Air Pollution-Persistent Organic Pollutants, Air Pollution-Sulphur 85, Air Pollution-Sulphur 94, Air Pollution-Volatile Organic Compounds, Antarctic-Environmental Protection, Antarctic Treaty, Biodiversity, Climate Change, Climate Change-Kyoto Protocol, Climate Change-Paris Agreement, Comprehensive Nuclear Test Ban, Desertification, Endangered Species, Environmental Modification, Hazardous Wastes, Law of the Sea, Marine Dumping-London Convention, Marine Dumping-London Protocol, Marine Life Conservation, Nuclear Test Ban, Ozone Layer Protection, Ship Pollution, Tropical Timber 2006, Wetlands, Whaling
signed, but not ratified:
none of the selected agreements
Climate:
temperate, but varies with altitude; cold, cloudy, rainy/snowy winters; cool to warm, cloudy, humid summers with occasional showers
Land use:
agricultural land:
38.7% (2018 est.)
arable land:
10.2% (2018 est.)
permanent crops:
0.6% (2018 est.)
permanent pasture:
27.9% (2018 est.)
forest:
31.5% (2018 est.)
other:
29.8% (2018 est.)
Urbanization:
urban population:
74.2% of total population (2023)
rate of urbanization:
0.79% annual rate of change (2020-25 est.)
Revenue from forest resources:
0.01% of GDP (2018 est.)
comparison ranking:
151
Revenue from coal:
0% of GDP (2018 est.)
comparison ranking:
164
Air pollutants:
particulate matter emissions:
8.97 micrograms per cubic meter (2019 est.)
carbon dioxide emissions:
34.48 megatons (2016 est.)
methane emissions:
4.98 megatons (2020 est.)
Waste and recycling:
municipal solid waste generated annually:
6.056 million tons (2016 est.)
municipal solid waste recycled annually:
1.938 million tons (2015 est.)
percent of municipal solid waste recycled:
32% (2015 est.)
Major lakes (area sq km):
fresh water lake(s):
Lake Constance (shared with Germany and Austria) - 540 sq km; Lake Geneva (shared with France) - 580 sq km
Major rivers (by length in km):
Rhein (Rhine) river source (shared with Germany, France, and Netherlands [m]) - 1,233 km
note – [s] after country name indicates river source; [m] after country name indicates river mouth
Major watersheds (area sq km): Atlantic Ocean drainage:
Rhine-Maas (198,735 sq km), (Black Sea) Danube (795,656 sq km), (Adriatic Sea) Po (76,997 sq km), (Mediterranean Sea) Rhone (100,543 sq km)
Total water withdrawal:
municipal:
970 million cubic meters (2020 est.)
industrial:
640 million cubic meters (2020 est.)
agricultural:
160 million cubic meters (2020 est.)
Total renewable water resources:
53.5 billion cubic meters (2020 est.)','d52279bcf553f9031b908703fa923e1a89115ffe523a59f59c9d01cc4cda4a33','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c49befedc3567fb8cc365942745edf0d469f3a371bc6df9795ae191e733a7a3e',2025,'CH','Switzerland','environment',52,'Environment - current issues:
deforestation; overgrazing; soil erosion; desertification; depletion of water resources; water pollution from raw sewage and petroleum refining wastes; inadequate potable water
Environment - international agreements:
party to:
Biodiversity, Climate Change, Climate Change-Kyoto Protocol, Climate Change-Paris Agreement, Desertification, Endangered Species, Hazardous Wastes, Marine Dumping-London Convention, Nuclear Test Ban, Ozone Layer Protection, Ship Pollution, Wetlands
signed, but not ratified:
Environmental Modification
Climate:
mostly desert; hot, dry, sunny summers (June to August) and mild, rainy winters (December to February) along coast; cold weather with snow or sleet periodically in Damascus
Land use:
agricultural land:
75.8% (2018 est.)
arable land:
25.4% (2018 est.)
permanent crops:
5.8% (2018 est.)
permanent pasture:
44.6% (2018 est.)
forest:
2.7% (2018 est.)
other:
21.5% (2018 est.)
Urbanization:
urban population:
57.4% of total population (2023)
rate of urbanization:
5.38% annual rate of change (2020-25 est.)
Food insecurity:
exceptional shortfall in aggregate food production/supplies:
due to civil conflict and economic crisis -
the latest available nationwide food security assessment estimated that about 12 million people, 60% of the overall population, were food insecure in 2021, a slight decline from 12.4 million in 2020, but 5 million more than at the end of 2019, mostly due to constrained livelihood opportunities and a rapidly worsening economy (2022)
Air pollutants:
particulate matter emissions:
25.14 micrograms per cubic meter (2019 est.)
carbon dioxide emissions:
28.83 megatons (2016 est.)
methane emissions:
12.93 megatons (2020 est.)
Waste and recycling:
municipal solid waste generated annually:
4.5 million tons (2009 est.)
municipal solid waste recycled annually:
112,500 tons (2010 est.)
percent of municipal solid waste recycled:
2.5% (2010 est.)
Major rivers (by length in km):
Euphrates (shared with Turkey [s], Iran, and Iraq [m]) - 3,596 km; Tigris (shared with Turkey, Iran, and Iraq [m]) - 1,950 km
note – [s] after country name indicates river source; [m] after country name indicates river mouth
Major watersheds (area sq km): Indian Ocean drainage:
(Persian Gulf) Tigris and Euphrates (918,044 sq km)
Total water withdrawal:
municipal:
1.48 billion cubic meters (2020 est.)
industrial:
620 million cubic meters (2020 est.)
agricultural:
14.67 billion cubic meters (2020 est.)
Total renewable water resources:
16.8 billion cubic meters (2020 est.)','32faa47147cd4cd3d2c327eb297848096c691e7bc6471a17be99ec5f193dd3be','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('652a2e407c94cc7657e07f2f4d69a40897b5de951f102c975f303f40ba589cf6',2025,'TJ','Tajikistan','environment',6,'Environment - current issues:
areas of high air pollution from motor vehicles and industry; water pollution from agricultural runoff and disposal of untreated industrial waste and sewage; poor management of water resources; soil erosion; increasing levels of soil salinity
Environment - international agreements:
party to:
Biodiversity, Climate Change, Climate Change-Kyoto Protocol, Climate Change-Paris Agreement, Comprehensive Nuclear Test Ban, Desertification, Endangered Species, Environmental Modification, Hazardous Wastes, Ozone Layer Protection, Ship Pollution, Wetlands
signed, but not ratified:
none of the selected agreements
Climate:
mid-latitude continental, hot summers, mild winters; semiarid to polar in Pamir Mountains
Land use:
agricultural land:
34.7% (2018 est.)
arable land:
6.1% (2018 est.)
permanent crops:
0.9% (2018 est.)
permanent pasture:
27.7% (2018 est.)
forest:
2.9% (2018 est.)
other:
62.4% (2018 est.)
Urbanization:
urban population:
28.2% of total population (2023)
rate of urbanization:
2.73% annual rate of change (2020-25 est.)
Revenue from forest resources:
1.12% of GDP (2018 est.)
comparison ranking:
51
Revenue from coal:
0.54% of GDP (2018 est.)
comparison ranking:
10
Air pollutants:
particulate matter emissions:
53.65 micrograms per cubic meter (2019 est.)
carbon dioxide emissions:
5.31 megatons (2016 est.)
methane emissions:
4.87 megatons (2020 est.)
Waste and recycling:
municipal solid waste generated annually:
1,787,400 tons (2013 est.)
Major rivers (by length in km):
Syr Darya (shared with Kyrgyzstan [s], Uzbekistan, and Kazakhstan [m]) - 3,078 km; Amu Darya river source (shared with Turkmenistan, Afghanistan, and Uzbekistan [m]) - 2,620 km
note
– [s] after country name indicates river source; [m] after country name indicates river mouth
Major watersheds (area sq km): Internal (endorheic basin) drainage:
Tarim Basin (1,152,448 sq km),
(Aral Sea Basin)
Amu Darya (534,739 sq km), Syr Darya (782,617 sq km)
Total water withdrawal:
municipal:
910 million cubic meters (2020 est.)
industrial:
1.61 billion cubic meters (2020 est.)
agricultural:
7.38 billion cubic meters (2020 est.)
Total renewable water resources:
21.91 billion cubic meters (2020 est.)','cf29cf53641d07b72f012a6a8b45bb3dc3fa37c0f089acb3d14f4f0f85c3d7ed','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('801cd804a1fb0f69715b3ffca5eafcf23a14b9329cc9649405635993dd4a5149',2025,'TJ','Tajikistan','environment',18,'Environment - current issues:
water pollution; improper management of liquid waste; indoor air pollution caused by the burning of fuel wood or charcoal for cooking and heating is a large environmental health issue; soil degradation; deforestation; desertification; destruction of coral reefs threatens marine habitats; wildlife threatened by illegal hunting and trade, especially for ivory; loss of biodiversity; solid waste disposal
Environment - international agreements:
party to:
Biodiversity, Climate Change, Climate Change-Kyoto Protocol, Climate Change-Paris Agreement, Comprehensive Nuclear Test Ban, Desertification, Endangered Species, Hazardous Wastes, Law of the Sea, Marine Dumping-London Convention, Nuclear Test Ban, Ozone Layer Protection, Ship Pollution, Wetlands, Whaling
signed, but not ratified:
none of the selected agreements
Climate:
varies from tropical along coast to temperate in highlands
Land use:
agricultural land:
43.7% (2018 est.)
arable land:
14.3% (2018 est.)
permanent crops:
2.3% (2018 est.)
permanent pasture:
27.1% (2018 est.)
forest:
37.3% (2018 est.)
other:
19% (2018 est.)
Urbanization:
urban population:
37.4% of total population (2023)
rate of urbanization:
4.89% annual rate of change (2020-25 est.)
Food insecurity:
severe localized food insecurity: due to localized shortfalls in staple food production -
about 592,000 people are estimated to be in need of humanitarian assistance between May and September 2022, mainly located in northeastern regions, reflecting crop losses during the October–December “Vuli” 2021 and March–May “Masika” 2022 seasons due to poor rains; high food prices are also constraining households’ economic access to food (2022)
Revenue from forest resources:
2.19% of GDP (2018 est.)
comparison ranking:
32
Revenue from coal:
0.02% of GDP (2018 est.)
comparison ranking:
42
Air pollutants:
particulate matter emissions:
15.36 micrograms per cubic meter (2019 est.)
carbon dioxide emissions:
11.97 megatons (2016 est.)
methane emissions:
59.08 megatons (2020 est.)
Waste and recycling:
municipal solid waste generated annually:
9,276,995 tons (2012 est.)
Major lakes (area sq km):
fresh water lake(s):
Lake Victoria (shared with Uganda and Kenya) - 62,940 sq km; Lake Tanganyika (shared with Democratic Republic of Congo, Burundi, and Zambia) - 32,000 sq km; Lake Malawi (shared with Mozambique and Malawi) - 22,490
salt water lake(s):
Lake Rukwa - 5,760 sq km
Major rivers (by length in km):
Nile (shared with Rwanda [s], Uganda, South Sudan, Sudan, and Egypt [m]) - 6,650 km
note
– [s] after country name indicates river source; [m] after country name indicates river mouth
Major watersheds (area sq km): Atlantic Ocean drainage:
Congo (3,730,881 sq km),
(Mediterranean Sea)
Nile (3,254,853 sq km)
Indian Ocean drainage:
Zambezi (1,332,412 sq km)
Total water withdrawal:
municipal:
530 million cubic meters (2020 est.)
industrial:
30 million cubic meters (2020 est.)
agricultural:
4.63 billion cubic meters (2020 est.)
Total renewable water resources:
96.3 billion cubic meters (2019 est.)','4bd3867f853972a36d22f9decec06d2be325654ae2a28e33521d9bca7fcade2a','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c9c8073b5c2aa9a77106b878a48af1ed3e84ddc90cedbfa89ef5707ec529bd2b',2025,'TH','Thailand','environment',30,'Environment - current issues:
air pollution from vehicle emissions; water pollution from organic and factory wastes; water scarcity; deforestation; soil erosion; wildlife populations threatened by illegal hunting; hazardous waste disposal
Environment - international agreements:
party to:
Biodiversity, Climate Change, Climate Change-Kyoto Protocol, Climate Change-Paris Agreement, Comprehensive Nuclear Test Ban, Desertification, Endangered Species, Hazardous Wastes, Law of the Sea, Marine Life Conservation, Nuclear Test Ban, Ozone Layer Protection, Ship Pollution, Tropical Timber 2006, Wetlands
signed, but not ratified:
none of the selected agreements
Climate:
tropical; rainy, warm, cloudy southwest monsoon (mid-May to September); dry, cool northeast monsoon (November to mid-March); southern isthmus always hot and humid
Land use:
agricultural land:
41.2% (2018 est.)
arable land:
30.8% (2018 est.)
permanent crops:
8.8% (2018 est.)
permanent pasture:
1.6% (2018 est.)
forest:
37.2% (2018 est.)
other:
21.6% (2018 est.)
Urbanization:
urban population:
53.6% of total population (2023)
rate of urbanization:
1.43% annual rate of change (2020-25 est.)
Revenue from forest resources:
0.34% of GDP (2018 est.)
comparison ranking:
76
Revenue from coal:
0.03% of GDP (2018 est.)
comparison ranking:
35
Air pollutants:
particulate matter emissions:
24.64 micrograms per cubic meter (2019 est.)
carbon dioxide emissions:
283.76 megatons (2016 est.)
methane emissions:
86.98 megatons (2020 est.)
Waste and recycling:
municipal solid waste generated annually:
26,853,366 tons (2015 est.)
municipal solid waste recycled annually:
5,128,993 tons (2012 est.)
percent of municipal solid waste recycled:
19.1% (2012 est.)
Major lakes (area sq km):
salt water lake(s):
Thalesap Songkhla - 1,290 sq km
Major rivers (by length in km):
Mae Nam Khong (Mekong) (shared with China [s], Burma, Laos, Cambodia, and Vietnam [m]) - 4,350 km; Salween (shared with China [s] and Burma [m]) - 3,060 km; Mun - 1,162 km
note
– [s] after country name indicates river source; [m] after country name indicates river mouth
Major watersheds (area sq km): Indian Ocean drainage:
Salween (271,914 sq km)
Pacific Ocean drainage:
Mekong (805,604 sq km)
Total water withdrawal:
municipal:
2.74 billion cubic meters (2020 est.)
industrial:
2.78 billion cubic meters (2020 est.)
agricultural:
51.79 billion cubic meters (2020 est.)
Total renewable water resources:
438.61 billion cubic meters (2020 est.)','d523ca8612d73f4b5d6c9a11d0cc86d8b02e537abdce1bfef66a00c1bb70d3ab','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ffe73c9d61a533f1bdf316cc0d50d74ad52aae957154367fb5aab6cef4e6ee42',2025,'TL','Timor-Leste','environment',4,'Environment - current issues:
air pollution and deterioration of air quality; greenhouse gas emissions; water quality, scarcity, and access; land and soil degradation; forest depletion; widespread use of slash and burn agriculture has led to deforestation and soil erosion; loss of biodiversity
Environment - international agreements:
party to:
Biodiversity, Climate Change, Climate Change-Kyoto Protocol, Climate Change-Paris Agreement, Desertification, Law of the Sea, Ozone Layer Protection
signed, but not ratified:
Comprehensive Nuclear Test Ban
Climate:
tropical; hot, humid; distinct rainy and dry seasons
Land use:
agricultural land:
25.1% (2018 est.)
arable land:
10.1% (2018 est.)
permanent crops:
4.9% (2018 est.)
permanent pasture:
10.1% (2018 est.)
forest:
49.1% (2018 est.)
other:
25.8% (2018 est.)
Urbanization:
urban population:
32.5% of total population (2023)
rate of urbanization:
3.31% annual rate of change (2020-25 est.)
Revenue from forest resources:
0.13% of GDP (2018 est.)
comparison ranking:
106
Revenue from coal:
0% of GDP (2018 est.)
comparison ranking:
143
Air pollutants:
particulate matter emissions:
20.47 micrograms per cubic meter (2019 est.)
carbon dioxide emissions:
0.5 megatons (2016 est.)
methane emissions:
4.74 megatons (2020 est.)
Waste and recycling:
municipal solid waste generated annually:
63,875 tons (2016 est.)
Total water withdrawal:
municipal:
100 million cubic meters (2020 est.)
industrial:
2 million cubic meters (2017 est.)
agricultural:
1.07 billion cubic meters (2020 est.)
Total renewable water resources:
8.22 billion cubic meters (2020 est.)','c2efd95d5fbf1f0a21c31173b1dd0da0ccf256cfbdf3d098a9ceeeeb6d6a6cba','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('053fbb1214e15bd604a937256dc61aec927a8ef7684ee6d50fc9fd7300f69077',2025,'TG','Togo','environment',15,'Environment - current issues:
deforestation attributable to slash-and-burn agriculture and the use of wood for fuel; very little rain forest still present and what remains is highly degraded; desertification; water pollution presents health hazards and hinders the fishing industry; air pollution increasing in urban areas
Environment - international agreements:
party to:
Biodiversity, Climate Change, Climate Change-Kyoto Protocol, Climate Change-Paris Agreement, Comprehensive Nuclear Test Ban, Desertification, Endangered Species, Hazardous Wastes, Law of the Sea, Nuclear Test Ban, Ozone Layer Protection, Ship Pollution, Tropical Timber 2006, Wetlands, Whaling
signed, but not ratified:
none of the selected agreements
Climate:
tropical; hot, humid in south; semiarid in north
Land use:
agricultural land:
67.4% (2018 est.)
arable land:
45.2% (2018 est.)
permanent crops:
3.8% (2018 est.)
permanent pasture:
18.4% (2018 est.)
forest:
4.9% (2018 est.)
other:
27.7% (2018 est.)
Urbanization:
urban population:
44.5% of total population (2023)
rate of urbanization:
3.6% annual rate of change (2020-25 est.)
Revenue from forest resources:
3.96% of GDP (2018 est.)
comparison ranking:
18
Revenue from coal:
0% of GDP (2018 est.)
comparison ranking:
55
Air pollutants:
particulate matter emissions:
35.66 micrograms per cubic meter (2019 est.)
carbon dioxide emissions:
3 megatons (2016 est.)
methane emissions:
3.06 megatons (2020 est.)
Waste and recycling:
municipal solid waste generated annually:
1,109,030 tons (2014 est.)
municipal solid waste recycled annually:
22,181 tons (2012 est.)
percent of municipal solid waste recycled:
2% (2012 est.)
Major watersheds (area sq km): Atlantic Ocean drainage:
Volta (410,991 sq km)
Total water withdrawal:
municipal:
140 million cubic meters (2020 est.)
industrial:
10 million cubic meters (2020 est.)
agricultural:
80 million cubic meters (2020 est.)
Total renewable water resources:
14.7 billion cubic meters (2020 est.)','00f77b5d524e5d34a406c387bf9d6c50bd54a4437bb4813c4b619de6128d2a97','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f44f27fb34ba51ad7bd3713104f5c0c515e36f76f404af71e46c1d9f78e87095',2025,'TK','Tokelau','environment',27,'Environment - current issues:
overexploitation of certain fish and other marine species, coastal sand, and forest resources; pollution of freshwater lenses and coastal waters from improper disposal of chemicals
Climate:
tropical; moderated by trade winds (April to November)
Land use:
agricultural land:
60% (2018 est.)
arable land:
0% (2018 est.)
permanent crops:
60% (2018 est.)
permanent pasture:
0% (2018 est.)
forest:
0% (2018 est.)
other:
40% (2018 est.)
Urbanization:
urban population:
0% of total population (2023)
rate of urbanization:
0% annual rate of change (2020-25 est.)
Total renewable water resources:
0 cubic meters (2017 est.)','bd2412418b1285fed154ee37db16989b76bc64baf81c54ac201ea2b4405ca771','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c2f9d893dc62905fd447db09a61e11a2412233f7facd0d48cc4fc698c95efbcc',2025,'TO','Tonga','environment',37,'Environment - current issues:
deforestation from land being cleared for agriculture and settlement; soil exhaustion; water pollution due to salinization, sewage, and toxic chemicals from farming activities; coral reefs and marine populations threatened
Environment - international agreements:
party to:
Biodiversity, Climate Change, Climate Change-Kyoto Protocol, Climate Change-Paris Agreement, Desertification, Endangered Species, Hazardous Wastes, Law of the Sea, Marine Dumping-London Convention, Marine Dumping-London Protocol, Marine Life Conservation, Nuclear Test Ban, Ozone Layer Protection, Ship Pollution
signed, but not ratified:
none of the selected agreements
Climate:
tropical; modified by trade winds; warm season (December to May), cool season (May to December)
Land use:
agricultural land:
43.1% (2018 est.)
arable land:
22.2% (2018 est.)
permanent crops:
15.3% (2018 est.)
permanent pasture:
5.6% (2018 est.)
forest:
12.5% (2018 est.)
other:
44.4% (2018 est.)
Urbanization:
urban population:
23.2% of total population (2023)
rate of urbanization:
0.99% annual rate of change (2020-25 est.)
Revenue from forest resources:
0.03% of GDP (2018 est.)
comparison ranking:
134
Revenue from coal:
0% of GDP (2018 est.)
comparison ranking:
88
Air pollutants:
particulate matter emissions:
7.52 micrograms per cubic meter (2019 est.)
carbon dioxide emissions:
0.13 megatons (2016 est.)
methane emissions:
0.12 megatons (2020 est.)
Waste and recycling:
municipal solid waste generated annually:
17,238 tons (2012 est.)
Total renewable water resources:
0 cubic meters (2017 est.)','40cd3ea32b1887ede8bf4ce78a22ea2fe1d428f68927b608b56005134b1e54c4','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bfb7b882a896250f9dd28ba7d697869271e1e9d8bd6d4a7fbb4bcc377ad66e7f',2025,'TT','Trinidad and Tobago','environment',48,'Environment - current issues:
water pollution from agricultural chemicals, industrial wastes, and raw sewage; widespread pollution of waterways and coastal areas; illegal dumping; deforestation; soil erosion; fisheries and wildlife depletion
Environment - international agreements:
party to:
Biodiversity, Climate Change, Climate Change-Kyoto Protocol, Climate Change-Paris Agreement, Comprehensive Nuclear Test Ban, Desertification, Endangered Species, Hazardous Wastes, Law of the Sea, Marine Dumping-London Protocol, Marine Life Conservation, Nuclear Test Ban, Ozone Layer Protection, Ship Pollution, Tropical Timber 2006, Wetlands
signed, but not ratified:
none of the selected agreements
Climate:
tropical; rainy season (June to December)
Land use:
agricultural land:
10.6% (2018 est.)
arable land:
4.9% (2018 est.)
permanent crops:
4.3% (2018 est.)
permanent pasture:
1.4% (2018 est.)
forest:
44% (2018 est.)
other:
45.4% (2018 est.)
Urbanization:
urban population:
53.4% of total population (2023)
rate of urbanization:
0.23% annual rate of change (2020-25 est.)
Revenue from forest resources:
0.05% of GDP (2018 est.)
comparison ranking:
127
Revenue from coal:
0% of GDP (2018 est.)
comparison ranking:
103
Air pollutants:
particulate matter emissions:
10.26 micrograms per cubic meter (2019 est.)
carbon dioxide emissions:
43.87 megatons (2016 est.)
methane emissions:
1.35 megatons (2020 est.)
Waste and recycling:
municipal solid waste generated annually:
727,874 tons (2010 est.)
Total water withdrawal:
municipal:
240 million cubic meters (2020 est.)
industrial:
130 million cubic meters (202 est.)
agricultural:
20 million cubic meters (2020 est.)
Total renewable water resources:
3.84 billion cubic meters (2020 est.)','0b5a80371bc48d0c2fb1657fa43c46f872b0ad450593c72487e5382bfffb937f','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f642c1d212c5eb48d256ec4a9395ed819eefe5552cc03becbe038ae1101cb925',2025,'TN','Tunisia','environment',4,'Environment - current issues:
toxic and hazardous waste disposal is ineffective and poses health risks; water pollution from raw sewage; limited natural freshwater resources; deforestation; overgrazing; soil erosion; desertification
Environment - international agreements:
party to:
Biodiversity, Climate Change, Climate Change-Kyoto Protocol, Climate Change-Paris Agreement, Comprehensive Nuclear Test Ban, Desertification, Endangered Species, Environmental Modification, Hazardous Wastes, Law of the Sea, Marine Dumping-London Convention, Nuclear Test Ban, Ozone Layer Protection, Ship Pollution, Wetlands
signed, but not ratified:
Marine Life Conservation
Climate:
temperate in north with mild, rainy winters and hot, dry summers; desert in south
Land use:
agricultural land:
64.8% (2018 est.)
arable land:
18.3% (2018 est.)
permanent crops:
15.4% (2018 est.)
permanent pasture:
31.1% (2018 est.)
forest:
6.6% (2018 est.)
other:
28.6% (2018 est.)
Urbanization:
urban population:
70.5% of total population (2023)
rate of urbanization:
1.34% annual rate of change (2020-25 est.)
Revenue from forest resources:
0.21% of GDP (2018 est.)
comparison ranking:
92
Revenue from coal:
0% of GDP (2018 est.)
comparison ranking:
99
Air pollutants:
particulate matter emissions:
26.52 micrograms per cubic meter (2019 est.)
carbon dioxide emissions:
29.94 megatons (2016 est.)
methane emissions:
7.89 megatons (2020 est.)
Waste and recycling:
municipal solid waste generated annually:
2.7 million tons (2014 est.)
municipal solid waste recycled annually:
108,000 tons (2014 est.)
percent of municipal solid waste recycled:
4% (2014 est.)
Major aquifers:
North Western Sahara Aquifer System
Total water withdrawal:
municipal:
820 million cubic meters (2020 est.)
industrial:
60 million cubic meters (2020 est.)
agricultural:
2.71 billion cubic meters (2020 est.)
Total renewable water resources:
4.62 billion cubic meters (2020 est.)','26e9778a713eb9983d3441ad6f070b4f854042f048c19e346581bdbd4f127dda','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1a09dd3cf4ab421cffe7e6b1c4fe29e3a072e13c52b683a2e34adf3bc8e29836',2025,'TN','Tunisia','environment',17,'Environment - current issues:
water pollution from dumping of chemicals and detergents; air pollution, particularly in urban areas; deforestation; land degradation; concern for oil spills from increasing Bosporus ship traffic; conservation of biodiversity
Environment - international agreements:
party to:
Air Pollution, Antarctic-Environmental Protection, Antarctic Treaty, Biodiversity, Climate Change, Climate Change-Kyoto Protocol, Comprehensive Nuclear Test Ban, Desertification, Endangered Species, Hazardous Wastes, Nuclear Test Ban, Ozone Layer Protection, Ship Pollution, Wetlands
signed, but not ratified:
Climate Change-Paris Agreement, Environmental Modification
Climate:
temperate; hot, dry summers with mild, wet winters; harsher in interior
Land use:
agricultural land:
49.7% (2018 est.)
arable land:
26.7% (2018 est.)
permanent crops:
4% (2018 est.)
permanent pasture:
19% (2018 est.)
forest:
14.9% (2018 est.)
other:
35.4% (2018 est.)
Urbanization:
urban population:
77.5% of total population (2023)
rate of urbanization:
1.11% annual rate of change (2020-25 est.)
Revenue from forest resources:
0.08% of GDP (2018 est.)
comparison ranking:
118
Revenue from coal:
0.05% of GDP (2018 est.)
comparison ranking:
31
Air pollutants:
particulate matter emissions:
23.25 micrograms per cubic meter (2019 est.)
carbon dioxide emissions:
372.72 megatons (2016 est.)
methane emissions:
57.53 megatons (2020 est.)
Waste and recycling:
municipal solid waste generated annually:
31.283 million tons (2015 est.)
Major lakes (area sq km):
fresh water lake(s):
Lake Beysehir - 650 sq km; Lake Egridir - 520 sq km
salt water lake(s):
Lake Van - 3,740 sq km; Lake Tuz - 1,640 sq km;
Major rivers (by length in km):
Euphrates river source (shared with Syria, Iran, and Iraq [m]) - 3,596 km; Tigris river source (shared with Syria, Iran, and Iraq [m]) - 1,950 km
note
– [s] after country name indicates river source; [m] after country name indicates river mouth
Major watersheds (area sq km): Indian Ocean drainage:
(Persian Gulf)
Tigris and Euphrates (918,044 sq km)
Total water withdrawal:
municipal:
6.91 billion cubic meters (2020 est.)
industrial:
1.03 billion cubic meters (2020 est.)
agricultural:
54.27 billion cubic meters (2020 est.)
Total renewable water resources:
211.6 billion cubic meters (2020 est.)','f5526ca58175b1eb4dfb83310b920c39696d170cc65e729363e3c5ce14870d61','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('73510bc3c03e93a87c89b44dd8d673fba1b860f25da2392ac5e7d9e9bb2d4540',2025,'TM','Turkmenistan','environment',30,'Environment - current issues:
contamination of soil and groundwater with agricultural chemicals, pesticides; salination, water logging of soil due to poor irrigation methods; Caspian Sea pollution; diversion of a large share of the flow of the Amu Darya into irrigation contributes to that river’s inability to replenish the Aral Sea; soil erosion; desertification
Environment - international agreements:
party to:
Biodiversity, Climate Change, Climate Change-Kyoto Protocol, Climate Change-Paris Agreement, Comprehensive Nuclear Test Ban, Desertification, Hazardous Wastes, Ozone Layer Protection, Ship Pollution, Wetlands
signed, but not ratified:
none of the selected agreements
Climate:
subtropical desert
Land use:
agricultural land:
72% (2018 est.)
arable land:
4.1% (2018 est.)
permanent crops:
0.1% (2018 est.)
permanent pasture:
67.8% (2018 est.)
forest:
8.8% (2018 est.)
other:
19.2% (2018 est.)
Urbanization:
urban population:
54% of total population (2023)
rate of urbanization:
2.23% annual rate of change (2020-25 est.)
Revenue from forest resources:
0% of GDP (2018 est.)
comparison ranking:
180
Revenue from coal:
0% of GDP (2018 est.)
comparison ranking:
67
Air pollutants:
particulate matter emissions:
26.41 micrograms per cubic meter (2019 est.)
carbon dioxide emissions:
70.63 megatons (2016 est.)
methane emissions:
52.09 megatons (2020 est.)
Waste and recycling:
municipal solid waste generated annually:
500,000 tons (2013 est.)
Major lakes (area sq km):
salt water lake(s):
Caspian Sea (shared with Iran, Azerbaijan, Russia, and Kazakhstan) - 374,000 sq km
Major rivers (by length in km):
Amu Darya (shared with Tajikistan [s], Afghanistan, and Uzbekistan [m]) - 2,620 km
note
– [s] after country name indicates river source; [m] after country name indicates river mouth
Major watersheds (area sq km): Internal (endorheic basin) drainage:
(Aral Sea basin)
Amu Darya (534,739 sq km)
Total water withdrawal:
municipal:
450 million cubic meters (2020 est.)
industrial:
810 million cubic meters (2020 est.)
agricultural:
16.12 billion cubic meters (2020 est.)
Total renewable water resources:
24.77 billion cubic meters (2020 est.)','b629466ef285629cb688fac89a16178c01d2bddc05d70bbbea332aeafb0ab7c4','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('63eba36ad6c176a3bcebcc37bae062034415b7c4000b7b5b520dcc9595ede276',2025,'TC','Turks and Caicos Islands','environment',42,'Environment - current issues:
limited natural freshwater resources, private cisterns collect rainwater
Climate:
tropical; marine; moderated by trade winds; sunny and relatively dry
Land use:
agricultural land:
1.1% (2018 est.)
arable land:
1.1% (2018 est.)
permanent crops:
0% (2018 est.)
permanent pasture:
0% (2018 est.)
forest:
36.2% (2018 est.)
other:
62.7% (2018 est.)
Urbanization:
urban population:
94.2% of total population (2023)
rate of urbanization:
1.46% annual rate of change (2020-25 est.)
Revenue from forest resources:
0% of GDP (2018 est.)
comparison ranking:
166
Revenue from coal:
0% of GDP (2018 est.)
comparison ranking:
186
Air pollutants:
carbon dioxide emissions:
0.22 megatons (2016 est.)','4e9c8a6b388e5094324df426fb32f2495f9daeffc20bc97f91609ec0356521f4','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('494bc59eaf8f5bb46f50e3581e8632d34835be4c09059e2aca78ffa738c0ebcd',2025,'TV','Tuvalu','environment',53,'Environment - current issues:
water needs met by catchment systems; the use of sand as a building material has led to beachhead erosion; deforestation; damage to coral reefs from increasing ocean temperatures and acidification; rising sea levels threaten water table; in 2000, the government appealed to Australia and New Zealand to take in Tuvaluans if rising sea levels should make evacuation necessary
Environment - international agreements:
party to:
Biodiversity, Climate Change, Climate Change-Kyoto Protocol, Climate Change-Paris Agreement, Desertification, Hazardous Wastes, Law of the Sea, Ozone Layer Protection, Ship Pollution, Whaling
signed, but not ratified:
Comprehensive Nuclear Test Ban
Climate:
tropical; moderated by easterly trade winds (March to November); westerly gales and heavy rain (November to March)
Land use:
agricultural land:
60% (2018 est.)
arable land:
0% (2018 est.)
permanent crops:
60% (2018 est.)
permanent pasture:
0% (2018 est.)
forest:
33.3% (2018 est.)
other:
6.7% (2018 est.)
Urbanization:
urban population:
66.2% of total population (2023)
rate of urbanization:
2.08% annual rate of change (2020-25 est.)
Revenue from forest resources:
0% of GDP (2018 est.)
comparison ranking:
168
Air pollutants:
particulate matter emissions:
6.81 micrograms per cubic meter (2019 est.)
carbon dioxide emissions:
0.01 megatons (2016 est.)
methane emissions:
0.01 megatons (2020 est.)
Waste and recycling:
municipal solid waste generated annually:
3,989 tons (2011 est.)
municipal solid waste recycled annually:
598 tons (2013 est.)
percent of municipal solid waste recycled:
15% (2013 est.)
Total renewable water resources:
0 cubic meters (2017 est.)','ed071ede17171e2f80ce1ef51e32a3160f3f61337cea297f6c68c7dc768b98d2','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('edeb8f2d22af7559e58b0aa5a2c47adfca90a06caf89f792ac61172142beed48',2025,'UG','Uganda','environment',4,'Environment - current issues:
draining of wetlands for agricultural use; deforestation; overgrazing; soil erosion; water pollution from industrial discharge and water hyacinth infestation in Lake Victoria; widespread poaching
Environment - international agreements:
party to:
Biodiversity, Climate Change, Climate Change-Kyoto Protocol, Climate Change-Paris Agreement, Comprehensive Nuclear Test Ban, Desertification, Endangered Species, Hazardous Wastes, Law of the Sea, Marine Life Conservation, Nuclear Test Ban, Ozone Layer Protection, Ship Pollution, Wetlands
signed, but not ratified:
Environmental Modification
Climate:
tropical; generally rainy with two dry seasons (December to February, June to August); semiarid in northeast
Land use:
agricultural land:
71.2% (2018 est.)
arable land:
34.3% (2018 est.)
permanent crops:
11.3% (2018 est.)
permanent pasture:
25.6% (2018 est.)
forest:
14.5% (2018 est.)
other:
14.3% (2018 est.)
Urbanization:
urban population:
26.8% of total population (2023)
rate of urbanization:
5.41% annual rate of change (2020-25 est.)
Food insecurity:
severe localized food insecurity:
due to weather extremes, civil insecurity, and high food prices- in Karamoja Region, about 518,000 people, 41% of the population, are estimated to be severely food insecure between March and July 2022, as a result of consecutive poor rainy seasons that adversely affected crop and livestock production, frequent episodes of cattle rustling leading to the loss of productive assets, and high food prices (2022)
Revenue from forest resources:
7.32% of GDP (2018 est.)
comparison ranking:
7
Revenue from coal:
0% of GDP (2018 est.)
comparison ranking:
92
Air pollutants:
particulate matter emissions:
31.31 micrograms per cubic meter (2019 est.)
carbon dioxide emissions:
5.68 megatons (2016 est.)
methane emissions:
30.24 megatons (2020 est.)
Waste and recycling:
municipal solid waste generated annually:
7,045,050 tons (2016 est.)
municipal solid waste recycled annually:
422,703 tons (2017 est.)
percent of municipal solid waste recycled:
6% (2017 est.)
Major lakes (area sq km):
fresh water lake(s):
Lake Victoria (shared with Tanzania and Kenya) - 62,940 sq km; Lake Albert (shared with Democratic Republic of Congo) - 5,590 sq km; Lake Kyoga - 4,430 sq km; Lake Edward (shared with Democratic Republic of Congo) - 2,150 sq km
Major rivers (by length in km):
Nile (shared with Rwanda [s], Tanzania, South Sudan, Sudan, and Egypt [m]) - 6,650 km
note
– [s] after country name indicates river source; [m] after country name indicates river mouth
Major watersheds (area sq km): Atlantic Ocean drainage:
Congo (3,730,881 sq km),
(Mediterranean Sea)
Nile (3,254,853 sq km)
Total water withdrawal:
municipal:
330 million cubic meters (2020 est.)
industrial:
50 million cubic meters (2020 est.)
agricultural:
260 million cubic meters (2020 est.)
Total renewable water resources:
60.1 billion cubic meters (2020 est.)','0865c77e19dcd537891f9733a04a24cb3092b4165befb40ad4a29be76a8b2be3','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b502eec12bab6399b8ac3672575a975cb80ac6b6cfd7ed840216f445eb48e7d6',2025,'UA','Ukraine','environment',17,'Environment - current issues:
air and water pollution; land degradation; solid waste management; biodiversity loss; deforestation; radiation contamination in the northeast from 1986 accident at Chornobyl’ Nuclear Power Plant
Environment - international agreements:
party to:
Air Pollution, Air Pollution-Nitrogen Oxides, Air Pollution-Sulphur 85, Antarctic-Environmental Protection, Antarctic-Marine Living Resources, Antarctic Treaty, Biodiversity, Climate Change, Climate Change-Kyoto Protocol, Climate Change-Paris Agreement, Comprehensive Nuclear Test Ban, Desertification, Endangered Species, Environmental Modification, Hazardous Wastes, Law of the Sea, Marine Dumping-London Convention, Nuclear Test Ban, Ozone Layer Protection, Ship Pollution, Wetlands
signed, but not ratified:
Air Pollution-Heavy Metals, Air Pollution-Persistent Organic Pollutants, Air Pollution-Sulfur 94, Air Pollution-Volatile Organic Compounds
Climate:
temperate continental; Mediterranean only on the southern Crimean coast; precipitation disproportionately distributed, highest in west and north, lesser in east and southeast; winters vary from cool along the Black Sea to cold farther inland; warm summers across the greater part of the country, hot in the south
Land use:
agricultural land:
71.2% (2018 est.)
arable land:
56.1% (2018 est.)
permanent crops:
1.5% (2018 est.)
permanent pasture:
13.6% (2018 est.)
forest:
16.8% (2018 est.)
other:
12% (2018 est.)
Urbanization:
urban population:
70.1% of total population (2023)
rate of urbanization:
-0.27% annual rate of change (2020-25 est.)
Food insecurity: severe localized food insecurity:
due to conflict
- Ukraine continues to be a significant supplier of food commodities for the world; however, according to a 2023 analysis, at least 17.6 million people are estimated to be in need of multi-sectoral humanitarian assistance in 2023 due to the war, including over 11 million in need of food security and livelihood interventions; the harvest of the 2023 winter cereal crops, mostly wheat, is onging and will be concluded by August; as a result of a smaller planted area, the 2023 wheat harvest in areas under government control is estimated at 18.5 million mt, about 8% below the already war-affected 2022 output; despite decreased cereal production, food availability at the national level is reported to be adequate, but access remains a major challenge; the country has already experienced elevated levels of food price inflation in the past, due to the economic impact of the conflict in eastern areas; in addition, rising energy costs, amidst high unemployment rates and limited livelihood opportunities, are reducing households’ purchasing power and driving more people into poverty (2023)
Revenue from forest resources:
0.34% of GDP (2018 est.)
comparison ranking:
77
Revenue from coal:
0.42% of GDP (2018 est.)
comparison ranking:
14
Air pollutants:
particulate matter emissions:
13.51 micrograms per cubic meter (2019 est.)
carbon dioxide emissions:
202.25 megatons (2016 est.)
methane emissions:
63.37 megatons (2020 est.)
Waste and recycling:
municipal solid waste generated annually:
15,242,025 tons (2016 est.)
municipal solid waste recycled annually:
487,745 tons (2015 est.)
percent of municipal solid waste recycled:
3.2% (2015 est.)
Major rivers (by length in km):
Dunay (Danube) (shared with Germany [s], Austria, Slovakia, Czechia, Hungary, Croatia, Serbia, Bulgaria, Moldova, and Romania [m]) - 2,888 km; Dnipro (Dnieper) river mouth (shared with Russia [s] and Belarus) - 2,287 km; Dnister (Dniester) river source and mouth (shared with Moldova) - 1,411 km; Vistula (shared with Poland [s/m] and Belarus) - 1,213 km
note
– [s] after country name indicates river source; [m] after country name indicates river mouth
Major watersheds (area sq km): Atlantic Ocean drainage:
(Black Sea)
Danube (795,656 sq km), Don (458,694 sq km), Dnieper (533,966 sq km)
Total water withdrawal:
municipal:
2.77 billion cubic meters (2020 est.)
industrial:
4.04 billion cubic meters (2020 est.)
agricultural:
3.06 billion cubic meters (2020 est.)
Total renewable water resources:
175.28 billion cubic meters (2020 est.)','c1e79085b0a3259f48dcaa52e96c5c6996e37febd8c68f67a2f5fbc6ee826d32','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2307a7367092a837db4db3e0cf0f79279e69dec8c18250ae923f7f3b0f3429f1',2025,'AE','United Arab Emirates','environment',29,'Environment - current issues:
air pollution; rapid population growth and high energy demand contribute to water scarcity; lack of natural freshwater resources compensated by desalination plants; land degradation and desertification; waste generation, beach pollution from oil spills
Environment - international agreements:
party to:
Biodiversity, Climate Change, Climate Change-Kyoto Protocol, Climate Change-Paris Agreement, Comprehensive Nuclear Test Ban, Desertification, Endangered Species, Hazardous Wastes, Marine Dumping-London Convention, Ozone Layer Protection, Ship Pollution, Wetlands
signed, but not ratified:
Law of the Sea
Climate:
desert; cooler in eastern mountains
Land use:
agricultural land:
4.6% (2018 est.)
arable land:
0.5% (2018 est.)
permanent crops:
0.5% (2018 est.)
permanent pasture:
3.6% (2018 est.)
forest:
3.8% (2018 est.)
other:
91.6% (2018 est.)
Urbanization:
urban population:
87.8% of total population (2023)
rate of urbanization:
1.5% annual rate of change (2020-25 est.)
Revenue from forest resources:
0% of GDP (2018 est.)
comparison ranking:
159
Revenue from coal:
0% of GDP (2018 est.)
comparison ranking:
57
Air pollutants:
particulate matter emissions:
41.75 micrograms per cubic meter (2019 est.)
carbon dioxide emissions:
206.32 megatons (2016 est.)
methane emissions:
56.55 megatons (2020 est.)
Waste and recycling:
municipal solid waste generated annually:
5,413,453 tons (2015 est.)
municipal solid waste recycled annually:
1,082,691 tons (2015 est.)
percent of municipal solid waste recycled:
20% (2015 est.)
Total water withdrawal:
municipal:
2.63 billion cubic meters (2020 est.)
industrial:
69 million cubic meters (2020 est.)
agricultural:
2.32 billion cubic meters (2020 est.)
Total renewable water resources:
150 million cubic meters (2020 est.)','bdbdabfcaee49e6be1ebfe9a0e8ac9cafda55d3c288c7f58d8e4d92cf5e59888','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ef48617260c09b80a75c781572a419df3b1a42c5b36ba2010c496816bbe9c5a3',2025,'GB','United Kingdom','environment',41,'Environment - current issues:
air pollution improved but remains a concern, particularly in the London region; soil pollution from pesticides and heavy metals; decline in marine and coastal habitats brought on by pressures from housing, tourism, and industry
Environment - international agreements:
party to:
Air Pollution, Air Pollution-Heavy Metals, Air Pollution-Multi-effect Protocol, Air Pollution-Nitrogen Oxides, Air Pollution-Persistent Organic Pollutants, Air Pollution-Sulphur 94, Air Pollution-Volatile Organic Compounds, Antarctic-Environmental Protection, Antarctic-Marine Living Resources, Antarctic Seals, Antarctic Treaty, Biodiversity, Climate Change, Climate Change-Kyoto Protocol, Climate Change-Paris Agreement, Comprehensive Nuclear Test Ban, Desertification, Endangered Species, Environmental Modification, Hazardous Wastes, Law of the Sea, Marine Dumping-London Convention, Marine Dumping-London Protocol, Marine Life Conservation, Nuclear Test Ban, Ozone Layer Protection, Ship Pollution, Tropical Timber 2006, Wetlands, Whaling
signed, but not ratified:
none of the selected agreements
Climate:
temperate; moderated by prevailing southwest winds over the North Atlantic Current; more than one-half of the days are overcast
Land use:
agricultural land:
71% (2018 est.)
arable land:
25.1% (2018 est.)
permanent crops:
0.2% (2018 est.)
permanent pasture:
45.7% (2018 est.)
forest:
11.9% (2018 est.)
other:
17.1% (2018 est.)
Urbanization:
urban population:
84.6% of total population (2023)
rate of urbanization:
0.8% annual rate of change (2020-25 est.)
Revenue from forest resources:
0.01% of GDP (2018 est.)
comparison ranking:
154
Revenue from coal:
0% of GDP (2018 est.)
comparison ranking:
181
Air pollutants:
particulate matter emissions:
9.52 micrograms per cubic meter (2019 est.)
carbon dioxide emissions:
379.02 megatons (2016 est.)
methane emissions:
49.16 megatons (2020 est.)
Waste and recycling:
municipal solid waste generated annually:
31.567 million tons (2014 est.)
municipal solid waste recycled annually:
8,602,008 tons (2015 est.)
percent of municipal solid waste recycled:
27.3% (2015 est.)
Total water withdrawal:
municipal:
6.23 billion cubic meters (2020 est.)
industrial:
1.01 billion cubic meters (2020 est.)
agricultural:
1.18 billion cubic meters (2020 est.)
Total renewable water resources:
147 billion cubic meters (2020 est.)','10ad70c43c9b72ccbf86290c9dd9cd293b18b8fac99abbe5b3572f408229a53e','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fd79fa1cbeff7a0d4d5081f12afed1f0b123cd1c1f004c2530d1cece0a2c7efe',2025,'US','United States','environment',4,'Environment - current issues:
air pollution; large emitter of carbon dioxide from the burning of fossil fuels; water pollution from runoff of pesticides and fertilizers; declining natural freshwater resources in much of the western part of the country require careful management; deforestation; mining; desertification; species conservation; invasive species (the Hawaiian Islands are particularly vulnerable)
Environment - international agreements:
party to:
Air Pollution, Air Pollution-Heavy Metals, Air Pollution-Multi-effect Protocol, Air Pollution-Nitrogen Oxides, Antarctic-Environmental Protection, Antarctic-Marine Living Resources, Antarctic Seals, Antarctic Treaty, Climate Change, Climate Change-Paris Agreement, Desertification, Endangered Species, Environmental Modification, Marine Dumping-London Convention, Marine Life Conservation, Nuclear Test Ban, Ozone Layer Protection, Ship Pollution, Tropical Timber 2006, Wetlands, Whaling
signed, but not ratified:
Air Pollution-Persistent Organic Pollutants, Air Pollution-Volatile Organic Compounds, Biodiversity, Climate Change-Kyoto Protocol, Comprehensive Nuclear Test Ban, Hazardous Wastes, Marine Dumping-London Protocol
Climate:
mostly temperate, but tropical in Hawaii and Florida, arctic in Alaska, semiarid in the great plains west of the Mississippi River, and arid in the Great Basin of the southwest; low winter temperatures in the northwest are ameliorated occasionally in January and February by warm chinook winds from the eastern slopes of the Rocky Mountains
note:
many consider Denali, the highest peak in the US, to be the world’s coldest mountain because of its combination of high elevation and its subarctic location at 63 degrees north latitude; permanent snow and ice cover over 75 percent of the mountain, and enormous glaciers, up to 45 miles long and 3,700 feet thick, spider out from its base in every direction; it is home to some of the world’s coldest and most violent weather, where winds of over 150 miles per hour and temperatures of -93˚F have been recorded.
Land use:
agricultural land:
44.5% (2018 est.)
arable land:
16.8% (2018 est.)
permanent crops:
0.3% (2018 est.)
permanent pasture:
27.4% (2018 est.)
forest:
33.3% (2018 est.)
other:
22.2% (2018 est.)
Urbanization:
urban population:
83.3% of total population (2023)
rate of urbanization:
0.96% annual rate of change (2020-25 est.)
Revenue from forest resources:
0.04% of GDP (2018 est.)
comparison ranking:
132
Revenue from coal:
0.2% of GDP (2018 est.)
comparison ranking:
22
Air pollutants:
particulate matter emissions:
7.18 micrograms per cubic meter (2019 est.)
carbon dioxide emissions:
5,006.3 megatons (2016 est.)
methane emissions:
685.74 megatons (2020 est.)
Waste and recycling:
municipal solid waste generated annually:
258 million tons (2015 est.)
municipal solid waste recycled annually:
89.268 million tons (2014 est.)
percent of municipal solid waste recycled:
34.6% (2014 est.)
Major lakes (area sq km):
fresh water lake(s):
Michigan – 57,750 sq km; Superior* – 53,348 sq km; Huron* – 23,597 sq km; Erie* – 12,890 sq km;
Ontario* – 9,220 sq km; Lake of the Woods – 4,350 sq km; Iliamna – 2,590 sq km; Okeechobee – 1,810 sq km;
Belcharof – 1,190 sq km; Red – 1,170 sq km; Saint Clair – 1,113 sq km; Champlain – 1,100 sq km note - Great Lakes* area shown as US waters
salt water lake(s):
Great Salt – 4,360 sq km; Pontchartrain – 1,620 sq km; Selawik – 1,400 sq km; Salton Sea – 950 sq km
Major rivers (by length in km):
Missouri - 3,768 km; Mississippi - 3,544 km; Yukon river mouth (shared with Canada [s]) - 3,190 km; Saint Lawrence (shared with Canada) - 3,058 km; Rio Grande river source (mouth shared with Mexico) - 3,057 km; Colorado river source (shared with Mexico [m]) - 2,333 km; Arkansas - 2,348 km; Columbia river mouth (shared with Canada [s]) - 2,250 km; Red - 2,188 km; Ohio - 2,102 km; Snake - 1,670 km
note
– [s] after country name indicates river source; [m] after country name indicates river mouth
Major watersheds (area sq km): Atlantic Ocean drainage:
(Gulf of Mexico)
Mississippi* (3,202,185 sq km); Rio Grande (607,965 sq km);
(Gulf of Saint Lawrence)
Saint Lawrence* (1,049,636 sq km total, US only 505,000 sq km)
Pacific Ocean drainage:
Yukon* (847,620 sq km, US only 23,820 sq km); Colorado (703,148 sq km); Columbia* (657,501 sq km, US only 554,501 sq km)
note
- watersheds shared with Canada shown with *
Major aquifers:
Northern Great Plains Aquifer, Cambrian-Ordovician Aquifer System, Californian Central Valley Aquifer System, Ogallala Aquifer (High Plains), Atlantic and Gulf Coastal Plains Aquifer
Total water withdrawal:
municipal:
58.39 billion cubic meters (2020 est.)
industrial:
209.7 billion cubic meters (2020 est.)
agricultural:
176.2 billion cubic meters (2020 est.)
Total renewable water resources:
3.07 trillion cubic meters (2020 est.)','c42117ff89e5cc62da077c362a496e0d0cd6e74b4032a43bf476b217a2b72f9f','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8f7ed335d04fbb9b98c08470aad1a52aa8949c338f5f53d542574af0c7150599',2025,'US','United States','environment',17,'Environment - current issues:
Baker Island:
no natural freshwater resources; feral cats, introduced in 1937 during a short-lived colonization effort, ravaged the avian population and were eradicated in 1965
Howland Island:
no natural freshwater resources; the island habitat has suffered from invasive exotic species; black rats, introduced in 1854, were eradicated by feral cats within a year of their introduction in 1937; the cats preyed on the bird population and were eliminated by 1985
Jarvis Island:
no natural freshwater resources; feral cats, introduced in the 1930s during a short-lived colonization venture, were not completely removed until 1990
Johnston Atoll:
no natural freshwater resources; the seven decades under US military administration (1934-2004) left the atoll environmentally degraded and required large-scale remediation efforts; a swarm of Anoplolepis (crazy) ants invaded the island in 2010 damaging native wildlife; eradication has been largely, but not completely, successful
Midway Islands:
many exotic species introduced, 75% of the roughly 200 plant species on the island are non-native; plastic pollution harms wildlife, via entanglement, ingestion, and toxic contamination
Kingman Reef:
none
Palmyra Atoll:
black rats, believed to have been introduced to the atoll during the US military occupation of the 1940s, severely degraded the ecosystem outcompeting native species (seabirds, crabs); following a successful rat removal project in 2011, native flora and fauna have begun to recover
Climate:
Baker, Howland, and Jarvis Islands: equatorial; scant rainfall, constant wind, burning sun;
Johnston Atoll and Kingman Reef:
tropical, but generally dry; consistent northeast trade winds with little seasonal temperature variation;
Midway Islands:
subtropical with cool, moist winters (December to February) and warm, dry summers (May to October); moderated by prevailing easterly winds; most of the 107 cm of annual rainfall occurs during the winter;
Palmyra Atoll:
equatorial, hot; located within the low pressure area of the Intertropical Convergence Zone (ITCZ) where the northeast and southeast trade winds meet, it is extremely wet with between 400-500 cm of rainfall each year
Land use:
other:
100% (2018 est.)','f7732ee9c84c20539243ef5a4033a23d86e3f863dbd4b12dec8181c253102cc0','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e167e9188104330eadc7a548cd30f97b78d814eb4eb97880bd8f130caed7bed4',2025,'UY','Uruguay','environment',25,'Environment - current issues:
water pollution from meat packing, tannery industries; heavy metal pollution; inadequate solid and hazardous waste disposal; deforestation
Environment - international agreements:
party to:
Antarctic-Environmental Protection, Antarctic-Marine Living Resources, Antarctic Treaty, Biodiversity, Climate Change, Climate Change-Kyoto Protocol, Climate Change-Paris Agreement, Comprehensive Nuclear Test Ban, Desertification, Endangered Species, Environmental Modification, Hazardous Wastes, Law of the Sea, Marine Dumping-London Protocol, Nuclear Test Ban, Ozone Layer Protection, Ship Pollution, Wetlands, Whaling
signed, but not ratified:
Marine Dumping-London Convention, Marine Life Conservation
Climate:
warm temperate; freezing temperatures almost unknown
Land use:
agricultural land:
87.2% (2018 est.)
arable land:
10.1% (2018 est.)
permanent crops:
0.2% (2018 est.)
permanent pasture:
76.9% (2018 est.)
forest:
10.2% (2018 est.)
other:
2.6% (2018 est.)
Urbanization:
urban population:
95.8% of total population (2023)
rate of urbanization:
0.4% annual rate of change (2020-25 est.)
Revenue from forest resources:
1.56% of GDP (2018 est.)
comparison ranking:
41
Revenue from coal:
0% of GDP (2018 est.)
comparison ranking:
104
Air pollutants:
particulate matter emissions:
8.48 micrograms per cubic meter (2019 est.)
carbon dioxide emissions:
6.77 megatons (2016 est.)
methane emissions:
25.59 megatons (2020 est.)
Waste and recycling:
municipal solid waste generated annually:
1,260,140 tons (2012 est.)
municipal solid waste recycled annually:
100,811 tons (2011 est.)
percent of municipal solid waste recycled:
8% (2011 est.)
Major lakes (area sq km):
salt water lake(s):
Lagoa Mirim (shared with Brazil) - 2,970 sq km
Major rivers (by length in km):
Rio de la Plata/Parana river mouth (shared with Brazil [s], Argentina, Paraguay) - 4,880 km; Uruguay river mouth (shared with Brazil [s] and Argentina) - 1,610 km
note
– [s] after country name indicates river source; [m] after country name indicates river mouth
Major aquifers:
Guarani Aquifer System
Total water withdrawal:
municipal:
410 million cubic meters (2020 est.)
industrial:
80 million cubic meters (2020 est.)
agricultural:
3.17 billion cubic meters (2020 est.)
Total renewable water resources:
172.2 billion cubic meters (2020 est.)','db29e9832ebe6822fdb2eb8a23270780be381f0c490a3c4ae49bef44dc13e427','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0831b50a29d5ab17d7ecebe83a467f8070f2294c4f82eea785b0e3a04505e9e6',2025,'UZ','Uzbekistan','environment',37,'Environment - current issues:
shrinkage of the Aral Sea has resulted in growing concentrations of chemical pesticides and natural salts; these substances are then blown from the increasingly exposed lake bed and contribute to desertification and respiratory health problems; water pollution from industrial wastes and the heavy use of fertilizers and pesticides is the cause of many human health disorders; increasing soil salination; soil contamination from buried nuclear processing and agricultural chemicals, including DDT
Environment - international agreements:
party to:
Biodiversity, Climate Change, Climate Change-Kyoto Protocol, Climate Change-Paris Agreement, Comprehensive Nuclear Test Ban, Desertification, Endangered Species, Environmental Modification, Hazardous Wastes, Ozone Layer Protection, Wetlands
signed, but not ratified:
none of the selected agreements
Climate:
mostly mid-latitude desert, long, hot summers, mild winters; semiarid grassland in east
Land use:
agricultural land:
62.6% (2018 est.)
arable land:
10.1% (2018 est.)
permanent crops:
0.8% (2018 est.)
permanent pasture:
51.7% (2018 est.)
forest:
7.7% (2018 est.)
other:
29.7% (2018 est.)
Urbanization:
urban population:
50.5% of total population (2023)
rate of urbanization:
1.25% annual rate of change (2020-25 est.)
Revenue from forest resources:
0% of GDP (2018 est.)
comparison ranking:
176
Revenue from coal:
0.06% of GDP (2018 est.)
comparison ranking:
30
Air pollutants:
particulate matter emissions:
40.98 micrograms per cubic meter (2019 est.)
carbon dioxide emissions:
91.81 megatons (2016 est.)
methane emissions:
96.16 megatons (2020 est.)
Waste and recycling:
municipal solid waste generated annually:
4 million tons (2016 est.)
Major lakes (area sq km):
fresh water lake(s):
Aral Sea (shared with Kazakhstan) - largely dried up
Major rivers (by length in km):
Syr Darya (shared with Kyrgyzstan [s], Tajikistan, and Kazakhstan [m]) - 3,078 km; Amu Darya river mouth (shared with Tajikistan [s], Afghanistan, and Turkmenistan) - 2,620 km
note
– [s] after country name indicates river source; [m] after country name indicates river mouth
Major watersheds (area sq km): Internal (endorheic basin) drainage:
(Aral Sea basin)
Amu Darya (534,739 sq km), Syr Darya (782,617 sq km)
Total water withdrawal:
municipal:
2.41 billion cubic meters (2020 est.)
industrial:
2.13 billion cubic meters (2020 est.)
agricultural:
54.36 billion cubic meters (2020 est.)
Total renewable water resources:
48.87 billion cubic meters (2020 est.)','36bec256cc0ee8fcdd1fc63980189fada9641d574831a5d5fca02a476bb01fa4','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c515546f7a79dbfa1514261477b55f4721e211a2a34aa29ca06694661341b602',2025,'VU','Vanuatu','environment',4,'Environment - current issues:
population growth; water pollution, most of the population does not have access to a reliable supply of potable water; inadequate sanitation; deforestation
Environment - international agreements:
party to:
Antarctic-Marine Living Resources, Biodiversity, Climate Change, Climate Change-Kyoto Protocol, Climate Change-Paris Agreement, Comprehensive Nuclear Test Ban, Desertification, Endangered Species, Hazardous Wastes, Law of the Sea, Marine Dumping-London Convention, Marine Dumping-London Protocol, Ozone Layer Protection, Ship Pollution, Wetlands
signed, but not ratified:
none of the selected agreements
Climate:
tropical; moderated by southeast trade winds from May to October; moderate rainfall from November to April; may be affected by cyclones from December to April
Land use:
agricultural land:
15.3% (2018 est.)
arable land:
1.6% (2018 est.)
permanent crops:
10.3% (2018 est.)
permanent pasture:
3.4% (2018 est.)
forest:
36.1% (2018 est.)
other:
48.6% (2018 est.)
Urbanization:
urban population:
26% of total population (2023)
rate of urbanization:
2.55% annual rate of change (2020-25 est.)
Revenue from forest resources:
0.54% of GDP (2018 est.)
comparison ranking:
64
Revenue from coal:
0% of GDP (2018 est.)
comparison ranking:
144
Air pollutants:
particulate matter emissions:
8.42 micrograms per cubic meter (2019 est.)
carbon dioxide emissions:
0.15 megatons (2016 est.)
methane emissions:
0.5 megatons (2020 est.)
Waste and recycling:
municipal solid waste generated annually:
70,225 tons (2012 est.)
municipal solid waste recycled annually:
25,983 tons (2013 est.)
percent of municipal solid waste recycled:
37% (2013 est.)
Total renewable water resources:
10 billion cubic meters (2020 est.)','fb04b5c8ddbfa17370e3173c5ed1bdbcd806d2c9c38f99b36c0cdb340ac1a354','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b2e98bdc3517faa5b84efc4f7c41d32ad5b9a1a794889696ab0f5654ac31b290',2025,'VU','Vanuatu','environment',15,'Environment - current issues:
sewage pollution of Lago de Valencia; oil and urban pollution of Lago de Maracaibo; deforestation; soil degradation; urban and industrial pollution, especially along the Caribbean coast; threat to the rainforest ecosystem from irresponsible mining operations
Environment - international agreements:
party to:
Antarctic-Environmental Protection, Antarctic Treaty, Biodiversity, Climate Change, Climate Change-Kyoto Protocol, Climate Change-Paris Agreement, Comprehensive Nuclear Test Ban, Desertification, Endangered Species, Hazardous Wastes, Marine Life Conservation, Nuclear Test Ban, Ozone Layer Protection, Ship Pollution, Tropical Timber 2006, Wetlands
signed, but not ratified:
none of the selected agreements
Climate:
tropical; hot, humid; more moderate in highlands
Land use:
agricultural land:
24.5% (2018 est.)
arable land:
3.1% (2018 est.)
permanent crops:
0.8% (2018 est.)
permanent pasture:
20.6% (2018 est.)
forest:
52.1% (2018 est.)
other:
23.4% (2018 est.)
Urbanization:
urban population:
88.4% of total population (2023)
rate of urbanization:
1.16% annual rate of change (2020-25 est.)
Food insecurity:
widespread lack of access: due to severe economic crisis -
the national economy, highly dependent on oil production and exports, was forecast to contract in 2021 for the eighth consecutive year; with the persistent negative effects of the COVID-19 pandemic that have compounded the already severe macro-economic crisis, the access to food of the most vulnerable households is expected to deteriorate throughout 2021 and into 2022 due to widespread losses of income-generating activities and soaring food prices (2022)
Air pollutants:
particulate matter emissions:
16.21 micrograms per cubic meter (2019 est.)
carbon dioxide emissions:
164.18 megatons (2016 est.)
methane emissions:
68.66 megatons (2020 est.)
Waste and recycling:
municipal solid waste generated annually:
9,779,093 tons (2010 est.)
Major lakes (area sq km):
salt water lake(s):
Lago de Maracaibo - 13,010 sq km
Major rivers (by length in km):
Rio Negro (shared with Colombia [s] and Brazil [m]) - 2,250 km; Orinoco river source and mouth (shared with Colombia) - 2,101 km
note
– [s] after country name indicates river source; [m] after country name indicates river mouth
Major watersheds (area sq km): Atlantic Ocean drainage:
Amazon (6,145,186 sq km), Orinoco (953,675 sq km)
Total water withdrawal:
municipal:
5.12 billion cubic meters (2020 est.)
industrial:
790 million cubic meters (2020 est.)
agricultural:
16.71 billion cubic meters (2020 est.)
Total renewable water resources:
1.33 trillion cubic meters (2020 est.)','9ed12a1bd126e7f8be548d9901f9ff7a9681054aee342526c94a6132b48372f7','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('002c6ad90bed76051c260a26effafb39cb57f91c7ad5d9ee5ca255d2b50e2838',2025,'VU','Vanuatu','environment',28,'Environment - current issues:
logging and slash-and-burn agricultural practices contribute to deforestation and soil degradation; water pollution and overfishing threaten marine life populations; groundwater contamination limits potable water supply; air pollution; growing urban industrialization and population migration are rapidly degrading environment in Hanoi and Ho Chi Minh City
Environment - international agreements:
party to:
Biodiversity, Climate Change, Climate Change-Kyoto Protocol, Climate Change-Paris Agreement, Comprehensive Nuclear Test Ban, Desertification, Endangered Species, Environmental Modification, Hazardous Wastes, Law of the Sea, Ozone Layer Protection, Ship Pollution, Tropical Timber 2006, Wetlands
signed, but not ratified:
none of the selected agreements
Climate:
tropical in south; monsoonal in north with hot, rainy season (May to September) and warm, dry season (October to March)
Land use:
agricultural land:
34.8% (2018 est.)
arable land:
20.6% (2018 est.)
permanent crops:
12.1% (2018 est.)
permanent pasture:
2.1% (2018 est.)
forest:
45% (2018 est.)
other:
20.2% (2018 est.)
Urbanization:
urban population:
39.5% of total population (2023)
rate of urbanization:
2.7% annual rate of change (2020-25 est.)
Revenue from forest resources:
1.49% of GDP (2018 est.)
comparison ranking:
43
Revenue from coal:
0.35% of GDP (2018 est.)
comparison ranking:
16
Air pollutants:
particulate matter emissions:
20.89 micrograms per cubic meter (2019 est.)
carbon dioxide emissions:
192.67 megatons (2016 est.)
methane emissions:
110.4 megatons (2020 est.)
Waste and recycling:
municipal solid waste generated annually:
9,570,300 tons (2011 est.)
municipal solid waste recycled annually:
2,201,169 tons (2014 est.)
percent of municipal solid waste recycled:
23% (2014 est.)
Major rivers (by length in km):
Sông Tiên Giang (Mekong) river mouth (shared with China [s], Burma, Laos, Thailand, Cambodia) - 4,350 km; Pearl river source (shared with China [m]) - 2,200 km; Red river mouth (shared with China [s]) - 1,149 km
note
– [s] after country name indicates river source; [m] after country name indicates river mouth
Major watersheds (area sq km): Pacific Ocean drainage:
Mekong (805,604 sq km)
Total water withdrawal:
municipal:
1.21 billion cubic meters (2020 est.)
industrial:
3.07 billion cubic meters (2020 est.)
agricultural:
77.75 billion cubic meters (2020 est.)
Total renewable water resources:
884.12 billion cubic meters (2020 est.)','bfbfa4030dd5920b3bbdc403ae4dd742942c6138c88dc159be8c475fb3d9dc68','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('609f2deefebd4274fca81aec1d0549dc82f0b8546b47bc6604565ed992c3146f',2025,'VU','Vanuatu','environment',40,'Environment - current issues:
lack of natural freshwater resources; protection of coral reefs; solid waste management; coastal development; increased boating and overfishing
Climate:
subtropical, tempered by easterly trade winds, relatively low humidity, little seasonal temperature variation; rainy season September to November
Land use:
agricultural land:
11.5% (2018 est.)
arable land:
2.9% (2018 est.)
permanent crops:
2.9% (2018 est.)
permanent pasture:
5.7% (2018 est.)
forest:
57.4% (2018 est.)
other:
31.1% (2018 est.)
Urbanization:
urban population:
96.2% of total population (2023)
rate of urbanization:
-0.11% annual rate of change (2020-25 est.)
Revenue from forest resources:
0% of GDP (2017 est.)
comparison ranking:
203
Waste and recycling:
municipal solid waste generated annually:
146,500 tons (2012 est.)','3d59465af041ab34cf3a3b28c9365554d33125907fbae1ca9f3b7919ffefb2ab','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f671e49fa271987928a9beb5c565a2815037b99f4d9aa79c5a0988bf3acf0f97',2025,'WF','Wallis and Futuna','environment',5,'Environment - current issues:
deforestation (only small portions of the original forests remain) largely as a result of the continued use of wood as the main fuel source; as a consequence of cutting down the forests, the mountainous terrain of Futuna is particularly prone to erosion; there are no permanent settlements on Alofi because of the lack of natural freshwater resources; lack of soil fertility on the islands of Uvea and Futuna negatively impacts agricultural productivity
Climate:
tropical; hot, rainy season (November to April); cool, dry season (May to October); rains 250-300 cm per year (80% humidity); average temperature 26.6 degrees Celsius
Land use:
agricultural land:
42.8% (2018 est.)
arable land:
7.1% (2018 est.)
permanent crops:
35.7% (2018 est.)
permanent pasture:
0% (2018 est.)
forest:
41.9% (2018 est.)
other:
15.3% (2018 est.)
Urbanization:
urban population:
0% of total population (2023)
rate of urbanization:
0% annual rate of change (2020-25 est.)','8969a869d0f743906c212a64dbc9d1af16e514ffd5277d7d2f2f2a1bb39d6d51','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6c0afbc442ed5dc1d56d771b751f1fc2331a34a26bd03a3519eb4a1b8cb18a1d',2025,'WF','Wallis and Futuna','environment',15,'Environment - current issues:
adequacy of freshwater supply; sewage treatment
Climate:
temperate; temperature and precipitation vary with altitude, warm to hot summers, cool to mild winters
Land use:
agricultural land:
43.3% (2018 est.)
arable land:
7.4% (2018 est.)
permanent crops:
11% (2018 est.)
permanent pasture:
24.9% (2018 est.)
forest:
1.5% (2018 est.)
other:
55.2% (2018 est.)
note:
includes Gaza Strip
Urbanization:
urban population:
77.6% of total population (2023)
rate of urbanization:
2.85% annual rate of change (2020-25 est.)
note:
data represent Gaza Strip and the West Bank
Revenue from forest resources:
0% of GDP (2018 est.)
comparison ranking:
189
Air pollutants:
particulate matter emissions:
30.82 micrograms per cubic meter (2019 est.)
carbon dioxide emissions:
3.23 megatons (2016 est.)
note:
data represent combined total from the Gaza Strip and the West Bank.
Waste and recycling:
municipal solid waste generated annually:
1.387 million tons (2016 est.)
municipal solid waste recycled annually:
6,935 tons (2013 est.)
percent of municipal solid waste recycled:
0.5% (2013 est.)
note:
data represent combined total from the Gaza Strip and the West Bank.
Major lakes (area sq km):
salt water lake(s):
Dead Sea (shared with Jordan and Israel) - 1,020 sq km
note
- endorheic hypersaline lake; 9.6 times saltier than the ocean; lake shore is 431 meters below sea level
Total water withdrawal:
municipal:
200 million cubic meters (2020 est.)
industrial:
30 million cubic meters (2020 est.)
agricultural:
220 million cubic meters (2020 est.)
note:
data represent combined total from the Gaza Strip and the West Bank.
Total renewable water resources:
840 million cubic meters (2020 est.)
note:
data represent combined total from the Gaza Strip and the West Bank.','0ad81507e17e8778b251622ef3332731d044912c775ecb7ffe63a62034e458a9','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0f8c49ec6919c02c91140850a04d13842397400e5cf75ce20efe8b9ce97ad412',2025,'WF','Wallis and Futuna','environment',29,'Environment - current issues:
large areas subject to overpopulation, industrial disasters, pollution (air, water, acid rain, toxic substances), loss of vegetation (overgrazing, deforestation, desertification), loss of biodiversity; soil degradation, soil depletion, erosion; ozone layer depletion; waste disposal; global warming becoming a greater concern
World biomes: Types of Biomes:
A biome is a biogeographical designation describing a biological community of plants and animals that has formed in response to a physical environment and a shared regional climate. Biomes can extend over more than one continent. Different classification systems define different numbers of biomes. The World Factbook recognizes the following seven biomes used by NASA: Tundra, Coniferous Forest, Temperate Deciduous Forest, Rainforest, Grassland, Shrubland, and Desert.
Tundra biome:
The tundra is the coldest of the biomes. It also receives low amounts of precipitation, making the tundra similar to a desert. Tundra comes from the Finnish word
tunturia
, meaning “treeless plain”. Tundra is found in the regions just below the ice caps of the Arctic, extending across North America, to Europe, and Siberia in Asia. Temperatures usually range between -40°C (-40 °F) and 18°C (64°F). The temperatures are so cold that there is a layer of permanently frozen ground below the surface, called permafrost. This permafrost is a defining characteristic of the tundra biome. In the tundra summers, the top layer of soil thaws only a few inches down, providing a growing surface for the roots of vegetation. This biome sees 150 to 250 mm (6 to 10 in) of rain per year. Vegetation in the tundra has adapted to the cold and the short growing season and consists of lichens, mosses, grasses, sedges, shrubs, but almost no trees due to short growing season and permafrost.
Coniferous Forest biome:
The coniferous forest is sandwiched in between the tundra to the north and the deciduous forest to the south. Coniferous forest regions have cold, long, snowy winters, and warm, humid summers; well-defined seasons; and at least four to six frost-free months. The average temperature in winter ranges from -40°C (-40°F) to 20°C (68°F). The average summer temperatures are usually around 10°C (50°F). 300 to 900 mm (12 to 35 in) of rain per year can be expected in this biome. Vegetation consists of trees that produce cones and needles called, coniferous-evergreen trees. Some needles remain on the trees all year long. Some of the more common conifers are spruces, pines, and firs.
Temperate Deciduous Forest biome:
Temperate deciduous forests are located in the mid-latitude areas which means that they are found between the polar regions and the tropics. The deciduous forest regions are exposed to warm and cold air masses, which cause this area to have four seasons. Hot summers and cold winters are typical in this biome. The average daily temperatures range between -30°C (-22°F) and 30°C (86°F) with a yearly average of 10°C (50°F). On average, this biome receives 750 to 1,500 mm (30 to 59 in) of rain per year. Vegetation includes broadleaf trees (oaks, maples, beeches), shrubs, perennial herbs, and mosses. Temperate deciduous forests are most notable for their transitioning through four seasons. Leaves change color (or senesce) in autumn, fall off in the winter, and grow back in the spring; this adaptation allows plants to survive cold winters.
Rainforest biome:
The rainforest biome remains warm all year and must stay frost-free. The average daily temperatures range from 20°C (68°F) to 25°C (77°F). Rainforests receive the most rain of all of the biomes in a year! A typical year sees 2,000 to 10,000 mm (79 to 394 in) of rain per year. Vegetation typically includes vines, palm trees, orchids, ferns. There are two types of rainforests, tropical and temperate. Tropical rainforests are found closer to the equator and temperate rainforests are found farther north near coastal areas. The majority of common houseplants come from the rainforest.
Grassland biome:
Grasslands are generally open and continuous, fairly flat areas of grass. They are often located between temperate forests at high latitudes and deserts at subtropical latitudes. Found on every continent except Antarctica. Depending on latitude, the annual temperature range can be between -20°C (-4°F) to 30°C (86°F). Grasslands receive around 500 to 900 mm (20 to 35 in) of rain per year. Tropical grasslands have dry and wet seasons that remain warm all the time. Temperate grasslands have cold winters and warm summers with some rain. Vegetation is dominated by grasses but can include sedges and rushes along with some legumes (clover) and herbs. The grasses die back to their roots annually and the soil and the sod protect the roots and the new buds from the cold of winter or dry conditions. A few trees may be found in this biome along the streams, but not many due to the lack of rainfall.
Shrubland biome:
Shrublands include regions such as chaparral, woodland and savanna, and are composed of shrubs or short trees. Many shrubs thrive on steep, rocky slopes, but there is usually not enough rain to support tall trees. Shrublands are the areas that are located in west coastal regions between 30° and 40° North and South latitude. These regions are usually found surrounding deserts and grasslands. The summers are hot and dry with temperatures reaching up to 38°C (100°F). In the winter, temperatures stay around -1 °C (30°F) and are cool and moist. Annual rainfall in the shrublands varies greatly but generally 200 to 1,000 mm (8 to 40 in) of rain per year can be expected. Vegetation comprises aromatic herbs (sage, rosemary, thyme, oregano), shrubs, acacia, chamise, grasses. Plants have adapted to fire caused by the frequent lightning that occurs in the hot, dry summers.
Desert biome:
Desert biomes are the driest of all the biomes. In fact, the most important characteristic of a desert is that it receives very little rainfall. Deserts get about 250 mm (10 in) of rain per year - the least amount of rain of all of the biomes. During the day, desert temperatures rise to an average of 38°C (100°F). At night, desert temperatures fall to an average of -4°C (about 25°F). Vegetation is sparse consisting of cacti, small bushes, short grasses. Perennials survive for several years by becoming dormant and flourishing when water is available. Annuals are referred to as ephemerals because some can complete an entire life cycle in weeks. Since desert conditions are so severe, the plants that live there need to have adaptations to compensate for the lack of water. Some plants, such as cacti, store water in their stems and use it very slowly, while others like bushes conserve water by growing few leaves or by having large root systems to gather water.
Climate:
a wide equatorial band of hot and humid tropical climates, bordered north and south by subtropical temperate zones that separate two large areas of cold and dry polar climates
ten driest places on Earth (average annual precipitation):
McMurdo Dry Valleys, Antarctica 0 mm (0 in)
Arica, Chile 0.76 mm (0.03 in)
Al Kufrah, Libya 0.86 mm (0.03 in)
Aswan, Egypt 0.86 mm (0.03 in)
Luxor, Egypt 0.86 mm (0.03 in)
Ica, Peru 2.29 mm (0.09 in)
Wadi Halfa, Sudan 2.45 mm (0.1 in)
Iquique, Chile 5.08 mm (0.2 in)
Pelican Point, Namibia 8.13 mm (0.32 in)
El Arab (Aoulef), Algeria 12.19 mm (0.48 in)
ten wettest places on Earth (average annual precipitation):
Mawsynram, India 11,871 mm (467.4 in)
Cherrapunji, India 11,777 mm (463.7 in)
Tutunendo, Colombia 11,770 mm (463.4 in)
Cropp River, New Zealand 11,516 mm (453.4 in)
San Antonia de Ureca, Equatorial Guinea 10,450 mm (411.4 in)
Debundsha, Cameroon 10,299 mm (405.5 in)
Big Bog, US (Hawaii) 10,272 mm (404.4 in)
Mt Waialeale, US (Hawaii) 9,763 mm (384.4 in)
Kukui, US (Hawaii) 9,293 mm (365.9 in)
Emeishan, China 8,169 mm (321.6 in)
ten coldest places on Earth (lowest average monthly temperature):
Verkhoyansk, Russia (Siberia) -47°C (-53°F) January
Oymyakon, Russia (Siberia) -46°C (-52°F) January
Eureka, Canada -38.4°C (-37.1°F) February
Isachsen, Canada -36°C (-32.8°F) February
Alert, Canada -34°C (-28°F) February
Kap Morris Jesup, Greenland -34°C (-29°F) March
Cornwallis Island, Canada -33.5°C (-28.3°F) February
Cambridge Bay, Canada -33.5°C (28.3°F) February
Ilirnej, Russia -33°C (-28°F) January
Resolute, Canada -33°C (-27.4°F) February
ten hottest places on Earth (highest average monthly temperature):
Death Valley, US (California) 39°C (101°F) July
Iranshahr, Iran 38.3°C (100.9°F) June
Ouallene, Algeria 38°C (100.4°F) July
Kuwait City, Kuwait 37.7°C (100°F) July
Medina, Saudi Arabia 36°C (97°F) July
Buckeye, US (Arizona) 34°C (93°F) July
Jazan, Saudi Arabia 33°C (91°F) June
Al Kufrah, Libya 31°C (87°F) July
Alice Springs, Australia 29°C (84°F) January
Tamanrasset, Algeria 29°C (84°F) June
Urbanization:
urban population:
57.5% of total population (2023)
rate of urbanization:
1.73% annual rate of change (2020-25 est.)
Major lakes (area sq km):
top ten largest natural lakes:
Caspian Sea (Azerbaijan, Iran, Kazakhstan, Russia, Turkmenistan) 374,000 sq km; Lake Superior (Canada, United States) 82,100 sq km; Lake Victoria (Kenya, Tanzania, Uganda) 62,940 sq km; Lake Huron (Canada, United States) 59,600 sq km; Lake Michigan (United States) 57,750 sq km; Lake Tanganyika (Burundi, Democratic Republic of the Congo, Tanzania, Zambia) 32,000 sq km; Great Bear Lake (Canada) 31,328 sq km; Lake Baikal (Russia) 31,500 sq km; Lake Malawi (Malawi, Mozambique, Tanzania) 22,490 sq km; Great Slave Lake (Canada) 28,568 sq km
note 1:
the areas of the lakes are subject to seasonal variation; only the Caspian Sea is saline, the rest are fresh water
note 2:
Lakes Huron and Michigan are technically a single lake because the flow of water between the Straits of Mackinac that connects the two lakes keeps their water levels at near-equilibrium; combined, Lake Huron-Michigan is the largest freshwater lake by surface area in the World
note 3:
if ranked by water volume, the Caspian Sea would still be first, but it would be followed Lakes Baikal, Tanganyika, Superior, and Malawi; Lake Superior contains more water than the other four North American Great Lakes (Erie, Huron, Michigan, Ontario) combined
Major rivers (by length in km):
top ten longest rivers:
Nile (Africa) 6,650 km; Amazon (South America) 6,436 km; Yangtze (Asia) 6,300 km; Mississippi-Missouri (North America) 6,275 km; Yenisey-Angara (Asia) 5,539 km; Huang He/Yellow (Asia) 5,464 km; Ob-Irtysh (Asia) 5,410 km; Congo (Africa) 4,700 km; Amur (Asia) 4,444 km; Lena (Asia) 4,400 km
note:
there are 21 countries without rivers: 3 in Africa (Comoros, Djibouti, Libya), 1 in the Americas (Bahamas), 8 in Asia (Bahrain, Kuwait, Maldives, Oman, Qatar, Saudi Arabia, United Arab Emirates, Yemen), 3 in Europe (Malta, Monaco, Holy See), 6 in Oceania (Kiribati, Marshall Islands, Nauru, Niue, Tonga, Tuvalu); these countries also do not have natural lakes
Major watersheds (area sq km):
summary statement:
a watershed is a drainage basin on an area of land where precipitation collects and drains off into a common outlet, such as into a river, bay, or other body of water; oceans ultimately take in the drainage from 83% of all land area; the remaining 17% of the land drains into internal (endorheic) basins, e.g., the Caspian Sea;
The World Factbook
lists 51 different watersheds across 102 countries; of these, 18 are in Asia, 9 in Europe, 9 in Africa, 8 in North and Central America, 5 in South America, and 2 in Australia; all watersheds with an area of at least 500,000 sq km have been included along with a number of smaller, regionally significant watersheds; together, these watersheds represent the surface hydrology water flows that are the World’s primary sources of fresh water for individual consumption, industry, and agriculture
Major aquifers:
summary statement:
aquifers are underground layers of water-bearing permeable rock formations; they include alluvial formations such as unconsolidated sand and gravel aquifers, sedimentary rock formations of sandstone and karst (carbonate rocks such as limestone) aquifers, as well as volcanic aquifers, and basement aquifers (igneous and metamorphic rocks that underlie sedimentary and volcanic rock sequences); groundwater from aquifers can be extracted using a water well;
The World Factbook
lists 37 major aquifers across 52 countries; of these, 13 are in Africa, 10 in Asia, 5 in North America, 3 in South America, 4 in Europe, and 2 in Australia; although aquifers can vary in size, the major aquifers listed in
The Factbook
contain the bulk of the stored volume of groundwater; the fresh water held in these aquifers represents more than 30% of the World’s fresh water; in the US, groundwater is primarily used for irrigation and globally, 70% of groundwater withdrawn is used for agriculture; groundwater also supplies almost half of all drinking water worldwide
Total renewable water resources:
54 trillion cubic meters (2011 est.)','c1dbc8960b760c7b4719202aae61f3043d5effd8260c265505354ce86cb9e48f','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('163551b7e886e73a70f17d1809b781e4fe9f90ef5de3146d92e5b7db1bc2bcf5',2025,'YE','Yemen','environment',4,'Environment - current issues:
limited natural freshwater resources; inadequate supplies of potable water; overgrazing; soil erosion; desertification
Environment - international agreements:
party to:
Biodiversity, Climate Change, Climate Change-Kyoto Protocol, Desertification, Endangered Species, Environmental Modification, Hazardous Wastes, Law of the Sea, Marine Dumping-London Protocol, Nuclear Test Ban, Ozone Layer Protection, Wetlands
signed, but not ratified:
Climate Change-Paris Agreement, Comprehensive Nuclear Test Ban
Climate:
mostly desert; hot and humid along west coast; temperate in western mountains affected by seasonal monsoon; extraordinarily hot, dry, harsh desert in east
Land use:
agricultural land:
44.5% (2018 est.)
arable land:
2.2% (2018 est.)
permanent crops:
0.6% (2018 est.)
permanent pasture:
41.7% (2018 est.)
forest:
1% (2018 est.)
other:
54.5% (2018 est.)
Urbanization:
urban population:
39.8% of total population (2023)
rate of urbanization:
3.71% annual rate of change (2015-20 est.)
Food insecurity:
widespread lack of access: due to conflict, poverty, floods, high food and fuel prices -
in 2023, a partial analysis in government-controlled areas, where approximately 25 percent of the population in acute food insecurity resides, shows that the situation remains dire; despite some improvements in security, the economic crisis and localized conflicts continue, fueled by persistent political instability, while insufficient external revenues and elevated global commodity prices on imported food limits food security (2023)
Revenue from forest resources:
0.04% of GDP (2018 est.)
comparison ranking:
130
Revenue from coal:
0% of GDP (2018 est.)
comparison ranking:
65
Air pollutants:
particulate matter emissions:
41.61 micrograms per cubic meter (2019 est.)
carbon dioxide emissions:
10.61 megatons (2016 est.)
methane emissions:
8.03 megatons (2020 est.)
Waste and recycling:
municipal solid waste generated annually:
4,836,820 tons (2011 est.)
municipal solid waste recycled annually:
386,946 tons (2016 est.)
percent of municipal solid waste recycled:
8% (2016 est.)
Total water withdrawal:
municipal:
270 million cubic meters (2020 est.)
industrial:
70 million cubic meters (2020 est.)
agricultural:
3.24 billion cubic meters (2020 est.)
Total renewable water resources:
2.1 billion cubic meters (2020 est.)','462b62143b04e4b5098f7080c7bc5158f1806035ae40fda25dd329613b1078be','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('75ecaa7367c94ecc6a82c20753e4ac519dbba05e0eb1bf57c5e527b867ab0936',2025,'ZM','Zambia','environment',4,'Environment - current issues:
air pollution and resulting acid rain in the mineral extraction and refining region; chemical runoff into watersheds; loss of biodiversity; poaching seriously threatens rhinoceros, elephant, antelope, and large cat populations; deforestation; soil erosion; desertification; lack of adequate water treatment presents human health risks
Environment - international agreements:
party to:
Biodiversity, Climate Change, Climate Change-Kyoto Protocol, Climate Change-Paris Agreement, Comprehensive Nuclear Test Ban, Desertification, Endangered Species, Hazardous Wastes, Law of the Sea, Nuclear Test Ban, Ozone Layer Protection, Wetlands
signed, but not ratified:
none of the selected agreements
Climate:
tropical; modified by altitude; rainy season (October to April)
Land use:
agricultural land:
31.7% (2018 est.)
arable land:
4.8% (2018 est.)
permanent crops:
0% (2018 est.)
permanent pasture:
26.9% (2018 est.)
forest:
66.3% (2018 est.)
other:
2% (2018 est.)
Urbanization:
urban population:
46.3% of total population (2023)
rate of urbanization:
4.15% annual rate of change (2020-25 est.)
Food insecurity:
severe localized food insecurity: due to reduced incomes and localized shortfalls in cereal production -
cereal production declined to a below-average level in 2022 and along with the impact of rising food prices, the number of food insecure is foreseen to increase at the end of 2022 to levels above the 1.6 million people estimated in the first quarter of 2022 (2022)
Revenue from forest resources:
4.45% of GDP (2018 est.)
comparison ranking:
15
Revenue from coal:
0.04% of GDP (2018 est.)
comparison ranking:
33
Air pollutants:
particulate matter emissions:
16.9 micrograms per cubic meter (2019 est.)
carbon dioxide emissions:
5.14 megatons (2016 est.)
methane emissions:
14.1 megatons (2020 est.)
Waste and recycling:
municipal solid waste generated annually:
2,608,268 tons (2002 est.)
Major lakes (area sq km):
fresh water lake(s):
Lake Tanganyika (shared with Democratic Republic of Congo, Tanzania, and Burundi) - 32,000 sq km; Lake Mweru (shared with Democratic Republic of Congo) - 4,350 sq km; Lake Bangweulu - 4,000-15,000 sq km seasonal variation
Major rivers (by length in km):
Congo river source (shared with Angola, Republic of Congo, and Democratic Republic of Congo [m]) - 4,700 km; Zambezi river source (shared with Angola, Namibia, Botswana, Zimbabwe, and Mozambique [m]) - 2,740 km
note
– [s] after country name indicates river source; [m] after country name indicates river mouth
Major watersheds (area sq km): Atlantic Ocean drainage:
Congo (3,730,881 sq km)
Indian Ocean drainage:
Zambezi (1,332,412 sq km)
Major aquifers:
Upper Kalahari-Cuvelai-Upper Zambezi Basin
Total water withdrawal:
municipal:
290 million cubic meters (2020 est.)
industrial:
130 million cubic meters (2020 est.)
agricultural:
1.15 billion cubic meters (2020 est.)
Total renewable water resources:
104.8 billion cubic meters (2020 est.)','ff01d19f09e1eecbbfa4de3f87ac418c61d7cb329ebea7ad94d4fd388a77b01e','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('19cb75fa4dbefef3d87db34603f905f4bb9478859dcd578aa96a990ff31ea7b2',2025,'ZW','Zimbabwe','environment',15,'Environment - current issues:
deforestation; soil erosion; land degradation; air and water pollution; the black rhinoceros herd - once the largest concentration of the species in the world - has been significantly reduced by poaching; poor mining practices have led to toxic waste and heavy metal pollution
Environment - international agreements:
party to:
Biodiversity, Climate Change, Climate Change-Kyoto Protocol, Climate Change-Paris Agreement, Comprehensive Nuclear Test Ban, Desertification, Endangered Species, Hazardous Wastes, Law of the Sea, Ozone Layer Protection, Wetlands
signed, but not ratified:
none of the selected agreements
Climate:
tropical; moderated by altitude; rainy season (November to March)
Land use:
agricultural land:
42.5% (2018 est.)
arable land:
10.9% (2018 est.)
permanent crops:
0.3% (2018 est.)
permanent pasture:
31.3% (2018 est.)
forest:
39.5% (2018 est.)
other:
18% (2018 est.)
Urbanization:
urban population:
32.5% of total population (2023)
rate of urbanization:
2.41% annual rate of change (2020-25 est.)
Food insecurity:
widespread lack of access: due to high food prices -
based on a government assessment, an estimated 3.8 million people are expected to be in need of humanitarian assistance between January and March 2023; this number is higher than the level estimated in the first quarter of 2022; the downturn in food security conditions is largely on account of poor food access resulting from prevailing high food prices and reduced incomes owing to the effects of an economic downturn; a decline in cereal production in 2022 has also aggravated conditions (2023)
Revenue from forest resources:
1.61% of GDP (2018 est.)
comparison ranking:
39
Revenue from coal:
0.4% of GDP (2018 est.)
comparison ranking:
15
Air pollutants:
particulate matter emissions:
13.08 micrograms per cubic meter (2019 est.)
carbon dioxide emissions:
10.98 megatons (2016 est.)
methane emissions:
12.1 megatons (2020 est.)
Waste and recycling:
municipal solid waste generated annually:
1,449,752 tons (2015 est.)
municipal solid waste recycled annually:
231,960 tons (2005 est.)
percent of municipal solid waste recycled:
16% (2005 est.)
Major rivers (by length in km):
Zambezi (shared with Zambia [s]), Angola, Namibia, Botswana, and Mozambique [m]) - 2,740 km; Limpopo (shared with South Africa [s], Botswana, and Mozambique [m]) - 1,800 km
note
– [s] after country name indicates river source; [m] after country name indicates river mouth
Major watersheds (area sq km): Indian Ocean drainage:
Zambezi (1,332,412 sq km)
Internal
(endorheic basin)
drainage:
Okavango Basin (863,866 sq km)
Major aquifers:
Upper Kalahari-Cuvelai-Upper Zambezi Basin
Total water withdrawal:
municipal:
650 million cubic meters (2020 est.)
industrial:
80 million cubic meters (2020 est.)
agricultural:
3.04 billion cubic meters (2020 est.)
Total renewable water resources:
20 billion cubic meters (2020 est.)','850778ffb8d76535de706e19a35731e3e7497d26fde8387d9609ce15095e19e6','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);

SET NAMES utf8mb4;
CREATE TABLE IF NOT EXISTS worldfactbook_chunks (
  chunk_id CHAR(64) NOT NULL,
  edition_year SMALLINT UNSIGNED NOT NULL,
  entity_code VARCHAR(24) NOT NULL DEFAULT '',
  entity_name VARCHAR(160) NOT NULL DEFAULT '',
  category VARCHAR(96) NOT NULL,
  ordinal INT UNSIGNED NOT NULL,
  content MEDIUMTEXT NOT NULL,
  content_sha256 CHAR(64) NOT NULL,
  source_provider VARCHAR(64) NOT NULL,
  source_identifier VARCHAR(255) NOT NULL,
  source_format VARCHAR(32) NOT NULL,
  source_sha256 CHAR(64) NOT NULL,
  source_url TEXT NOT NULL,
  extractor VARCHAR(64) NOT NULL,
  PRIMARY KEY (chunk_id),
  KEY idx_wfb_year_category (edition_year, category),
  KEY idx_wfb_entity_year (entity_code, edition_year),
  KEY idx_wfb_source_sha (source_sha256)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('955c0e8b9aed1e0177c92aac6e2c539828857e4c7f5f49363645d8bf718e1280',2025,'SC','Seychelles','environment',1440,'National anthem: name: “Koste Seselwa” (Sey-
chellois Unite)
lyrics/music: David Francois Marc ANDRE and
George Charles Robert PAYET','df4c1267a63224221763c0d1df95fec7ad15e14c7299acc30d3364803bb33055','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('680b30429ed0945f61b9ccbd52a1a6b0c7e09b3e7664ce9326c02148e4fbfac0',2025,'ZW','Zimbabwe','environment',1731,'members—(8) Canada, Denmark (Greenland, Faroe Islands), Finland, Iceland, Norway, Russia, Sweden, US
permanent participants—(6) Aleut International Association, Arctic Athabaskan Council, Gwich’in Council International, Inuit
Circumpolar Conference, Russian Association of Indigenous People of the North, Saami Council
observers—(6) France, Germany, Netherlands, Poland, Spain, UK
ASEAN Regional Forum (ARF)
established—25 July 1994
aim—to foster constructive dialogue and consultation on political and security issues of common interest and concern
members—(27) Australia, Bangladesh, Brunei, Burma, Cambodia, Canada, China, EU, India, Indonesia, Japan, North Korea, South Korea,
Laos, Malaysia, Mongolia, NZ, Pakistan, Papua New Guinea, Philippines, Russia, Singapore, Sri Lanka, Thailand, Timor-Leste, US, Vietnam
Asia-Pacific Economic Cooperation (APEC)
established—7 November 1989 —
aim—to promote trade and investment in the Pacific basin :
rE N) Australia, Brunei, Canada, Chile, China, Hong Kong, Indonesia, Japan, South Korea, Malaysia, Mexico, NZ, Papua New
Guinea, Peru, Philippines, Russia, Singapore, Taiwan, Thailand, US, Vietnam y
observers—(3) Association of Southeast Asian Nations, Pacific Economic Cooperation Council, Pacific Islands Forum Secretariat
Asian Development Bank (ADB)
established —19 December 1966
aim—to promote regional economic cooperation oo” a ms
én me Afghanistan, Armenia, Australia, Azerbaijan, Bangladesh, Bhutan, Brunei, Burma, Cambodia, China, Cook Islands, Fiji,
Georgia, Hong Kong, India, Indonesia, Japan, Kazakhstan, Kiribati, South Korea, Kyrgyzstan, Laos, Malaysia, Maldives, Marshall Islands,
Federated States of Micronesia, Mongolia, Nauru, Nepal, NZ, Pakistan, Palau, Papua New Guinea, Philippines, Samoa, Singapore, Solomon
Islands, Sri Lanka, Taiwan, Tajikistan, Thailand, Timor- Leste, Tonga, Turkmenistan, Tuvalu, Uzbekistan, Vanuatu, Vietnam
nonregional members—(19) Austria, Belgium, Canada; Denmark, Finland, France, Germany, Ireland, Italy, Luxembourg, Netherlands,
Norway, Portugal, Spain, Sweden, Switzerland, Turkey, UK, US
829
THE CIA WORLD FACTBOOK
Association of Southeast Asian Nations (ASEAN)
established—8 August 1967 ) = ; : :
aim—to encourage regional economic, social, and cultural cooperation among the non-Communist countries of Southeast Asia
members—(10) Brunei, Burma, Cambodia, Indonesia, Laos, Malaysia, Philippines, Singapore, Thailand, Vietnam
dialogue partners—(11) Australia, Canada, China, EU, India, Japan, South Korea, NZ, Pakistan, Russia, US
observers—(2) Papua New Guinea, Timor-Leste
Australia Group (AG)
established—June 1985
aim—to consult on and coordinate export controls related to chemical and biological weapons
members—(41) Argentina, Australia, Austria, Belgium, Bulgaria, Canada, Croatia, Cyprus, Czech Republic, Denmark, Estonia, European
Commission, Finland, France, Germany, Greece, Hungary, Iceland, Ireland, Italy, Japan, South Korea, Latvia, Lithuania, Luxembourg,
Malta, Netherlands, NZ, Norway, Poland, Portugal, Romania, Slovakia, Slovenia, Spain, Sweden, Switzerland, Turkey, Ukraine, UK, US
Australia-New Zealand-United States Security Treaty (ANZUS)
established—1 September 1951; effective—29 April 1952
aim—to implement a trilateral mutual security agreement, although the US suspended security obligations to NZ on 11 August 1986;
Australia and the US continue to hold annual meetings
members—(3) Australia, NZ, US
Baltic Assembly (BA)
established—12 May 1990 Jr
aim—to thoroughly discuss various cooperation issues between Baltic states
members—(3) Estonia, Latvia, Lithuania
Bank for international Settlements (BIS)
established—20 January 1930; effective—17 March 1930
aim—to promote cooperation among central banks in international financial settlements
members—(60) Algeria, Argentina, Australia, Austria, Belgium, Bosnia and Herzegovina, Brazil, Bulgaria, Canada, Chile, China, Colombia,
Croatia, Czech Republic, Denmark, European Central Bank, Estonia, Finland, France, Germany, Greece, Hong Kong, Hungary, Iceland, India,
Indonesia, Ireland, Israel, Italy, Japan, South Korea, Latvia, Lithuania, Luxembourg, Macedonia, Malaysia, Mexico, Netherlands, NZ, Norway,
Peru, Philippines, Poland, Portugal, Romania, Russia, Saudi Arabia, Serbia, Singapore, Slovakia, Slovenia, South Africa, Spain, Sweden,
Switzerland, Thailand, Turkey, UAE, UK, US; note—Montenegro has a separate central bank; its links with BIS are currently under review
Bay of Bengal Initiative for Multi-Sectora! Technical and Economic Cooperation (BIMSTEC)
established—June 1997 . i i ; j
aim—to foster socio-economic cooperation among members
members—(7) Bangladesh, Bhutan, Burma, India, Nepal, Sri Lanka, Thailand
Benelux Union (Benelux)
note—acronym from Belgium, Netherlands, and Luxembourg; was formerly known as Benelux Economic Union
established—3 February 1958; effective—1 November 1960; changed names 17 June 2008
aim—to develop closer economic and legal cooperation and integration
members—(3) Belgium, Luxembourg, Netherlands
Big Seven
note—membership is the same as the Group of 7
established—1975
aim—to discuss and coordinate major economic policies
members—(7) Big Six (Canada, France, Germany, Italy, Japan, UK) plus the US
Black Sea Economic Cooperation Zone (BSEC)
established—25 June 1992
aim—to enhance regional stability through economic cooperation
members—(12) Albania, Armenia, Azerbaijan, Bulgaria, Georgia, Greece, Moldova, Romania, Russia, Serbia, Turkey, Ukraine; note—
Macedonia is in the process of joining
observers—(17) Austria, Belarus, Black Sea Commission, EU, Croatia, Czech Republic, Egypt, Energy Charter Secretariat, France, Germany, Inter-
national Black Sea Club, Israel, Italy, Poland, Slovakia, Tunisia, US; note—Bosnia and Herzegovina and Slovenia havé applied for observer status
BRICS
note—note: the name of the organization stands for the first letter of each of the five members’ names
established—BRIC established 16 June 2009; BRICS established 24 December 2011
aim—to seek common ground in political and economic venues; to achieve peace, security, development, and cooperation; to contribute
significantly to the development of humanity and to establish a more equitable world
members—(5) Brazil, Russia, India, China, South Africa
Caribbean Community and Common Market (Caricom)
established—4 July 1973; effective—1 August 1973
aim—to promote economic integration and development, especially among the less developed countries
members—(15) Antigua and Barbuda, The Bahamas, Barbados, Belize, Dominica, Grenada, Guyana, Haiti, Jamaica, Montserrat, Saint
Kitts and Nevis, Saint Lucia, Saint Vincent and the Grenadines, Suriname, Trinidad and Tobago
associate members—(5) Anguilla, Bermuda, British Virgin Islands, Cayman Islands, Turks and Caicos Islands
observers—(8) Aruba, Colombia, Curacao, Dominican Republic, Mexico, Puerto Rico, Sint Maarten, Venezuela
830
INTERNATIONAL ORGANIZATIONS AND GROUPS
Caribbean Development Bank (CDB)
established —18 October 1969; effective—26 January 1970
aim—to promote economic development and cooperation
regional members—(21) Anguilla, Antigua and Barbuda, The Bahamas, Barbados, Belize, British Virgin Islands, Cayman Islands,
Colombia, Dominica, Grenada, Guyana, Haiti, Jamaica, Mexico, Montserrat, Saint Kitts and Nevis, Saint Lucia, Saint Vincent and the
Grenadines, Trinidad and Tobago, Turks and Caicos Islands, Venezuela
nonregional members—(5) Canada, China, Germany, Italy, UK
Central African Customs and Economic Union (UDEAC)
see Economic and Monetary Community of Central Africa (CEMAC)
Central African States Development Bank (BDEAC)
note—acronym from Banque de Developpement des Etats de I’Afrique Centrale
established—3 December 1975
aim—to provide loans for economic development
members—(11) African Development Bank (AfDB), Cameroon, Central African States Bank (BEAC), Central African Republic, Chad,
Republic of the Congo, Equatorial Guinea, France, Gabon, Kuwait, Libya
Central American Bank for Economic Integration (BCIE)
note—acronym from Banco Centroamericano de Integracion Economico
established—13 December 1960 signature of Articles of Agreement; 31 May 1961 began operations
aim—to promote economic integration and development
members—(5) Costa Rica, El Salvador, Guatemala, Honduras, Nicaragua
nonregional members—(7) Argentina, Colombia, Dominican Republic, Mexico, Panama, Spain, Taiwan
Central American Common Market (CACM)
established—13 December 1960, collapsed in 1969, reinstated in 1991
aim—to promote establishment of a Central American Common Market
members—(5) Costa Rica, El Salvador, Guatemala, Honduras, Nicaragua
Central American Integration System (SICA)
established—13 December 1991; operational 1 February 1993
aim—to strengthen democracy; to set up a new model of regional security; to promote freedom; to achieve a regional system of welfare and
economic and social justice; to attain economic unity and strengthen the area as an economic bloc; to act as a bloc in international matters
members—(7) Belize, Costa Rica, El Salvador, Guatemala, Honduras, Nicaragua, Panama a
ssociated member—(1) Dominican Republic
observers—(13) Argentina, Australia, Brazil, Chile, China, Germany, Italy, Japan, South Korea, Mexico, Peru, Spain, US
Central European Initiative (CE!)
note—evolved from the Quadrilateral Initiative and the Hexagonal Initiative
established—11 November 1989 as the Quadrilateral Initiative, 27 July 1991 became the Hexagonal Initiative, July 1992 its present name
was adopted `
aim—to form an economic, and political cooperation group for the region between the Adriatic and the Baltic Seas
members—(18) Albania, Austria, Belarus, Bosnia and Herzegovina, Bulgaria, Croatia, Czech Republic, Hungary, Italy, Macedonia,
Moldova, Montenegro, Poland, Romania, Serbia, Slovakia, Slovenia, Ukraine
centrally planned economies j l
a term applied mainly to the traditionally Communist states that looked to the former USSR for leadership; most are now evolving
toward more democratic and market-oriented systems; also known formerly as the Second World or as the Communist countries; through
the 1980s, this group included Albania, Bulgaria, Cambodia, China, Cuba, Czechoslovakia, German Democratic Republic, Hungary,
North Korea, Laos, Mongolia, Poland, Romania, USSR, Vietnam, Yugoslavia, but now is limited to Cuba and North Korea, and less so
to China
Collective Security Treaty Organization (CSTO)
established—7 October 2002
aim—to coordinate military and political cooperation, to develop multilateral structures and mechanisms of cooperation for ensuring
national security of the member states
members—(7) Armenia, Belarus, Kazakhstan, Kyrgyzstan, Russia, Tajikistan, Uzbekistan
Colombo Plan (CP)
established—May 1950 proposal was adopted; 1 July 1951 commenced full operations
aim—to promote economic and social development in Asia and the Pacific :
members—(27) Afghanistan, Australia, Bangladesh, Bhutan, Brunei, Burma, Fiji, India, Indonesia, Iran, Japan, South Korea, Laos, Malaysia,
Maldives, Mongolia, Nepal, NZ, Pakistan, Papua New Guinea, Philippines, Saudi Arabia, Singapore, Sri Lanka, Thailand, US, Vietnam ,
Common Market for Eastern and Southern Africa (COMESA)
note—formerly known as Preferential Trade Area for Eastern and Southern Africa (PTA)
established—treaty signed 5 November 1993; treaty ratified 8 December 1994 ; —
aim—recognizing, promoting and protecting fundamental human rights, commitment to the principles of liberty and rule of law, maintain-
ing peace and stability through the promotion and strengthening of good neighborliness, commitment to peaceful settlement of disputes
among member states ; A — l * a l
members—(19) Burundi, Comoros, Democratic Republic of the Congo, Djibouti, Egypt, Eritrea, Ethiopia; Kenya, Libya, Madagascar,
Malawi, Mauritius, Rwanda, Seychelles, Sudan, Swaziland, Uganda, Zambia, Zimbabwe
831
THE CIA WORLD FACTBOOK
Commonwealth (C)
note—also known as Commonwealth of Nations
established—31 December 1931
aim-—to foster multinational cooperation and assistance, as a voluntary association that evolved from the British Empire
members—(54) Antigua and Barbuda, Australia, The Bahamas, Bangladesh, Barbados, Belize, Botswana, Brunei, Cameroon, Canada,
Cyprus, Dominica, Fiji (suspended), The Gambia, Ghana, Grenada, Guyana, India, Jamaica, Kenya, Kiribati, Lesotho, Malawi, Malaysia,
Maldives, Malta, Mauritius, Mozambique, Namibia, Nauru, NZ, Nigeria, Pakistan (reinstated 2004), Papua New Guinea, Rwanda, Saint
Kitts and Nevis, Saint Lucia, Saint Vincent and the Grenadines, Samoa, Seychelles, Sierra Leone, Singapore, Solomon Islands, South
Africa, Sri Lanka, Swaziland, Tanzania, Tonga, Trinidad and Tobago, Tuvalu, Uganda, UK, Vanuatu, Zambia; note—on 7 December 2003
Zimbabwe withdrew its membership from the Commonwealth
Commonwealth of Independent States (CIS)
established—8 December 1991; effective—21 December 1991
aim—to coordinate intercommonwealth relations and to provide a mechanism for the orderly dissolution of the USSR
members—(11) Armenia, Azerbaijan, Belarus, Kazakhstan, Kyrgyzstan, Moldova, Russia, Tajikistan, Turkmenistan (unofficial), Ukraine
(unofficial), Uzbekistan; note—neither Ukraine as a participating member nor Turkmenistan as an associate member have signed the 1993
CIS charter, although both participate in meetings; Georgia left the organization in August 2009
Communist countries
traditionally the Marxist-Leninist states with authoritarian governments and command economies based on the Soviet model; most of the
original and the successor states are no longer Communist; see centrally planned economies
Community of Democracies (CD)
established—27 June 2000
aim—“to respect and uphold core democratic principles and practices” including free and fair elections, freedom of speech and expression,
equal access to education, rule of law, and freedom of peaceful assembly
signatories of the Warsaw Declaration—(110) Albania, Algeria, Argentina, Armenia, Australia, Austria, Bangladesh, Belgium, Belize,
Benin, Bolivia, Bosnia and Herzegovina, Botswana, Brazil, Bulgaria, Burkina Faso, Canada, Cape Verde, Chile, Colombia, Costa Rica,
Croatia, Cyprus, Czech Republic, Denmark, Dominica, Dominican Republic, Ecuador, Egypt, El Salvador, Estonia, Finland, Georgia,
Germany, Greece, Guatemala, Guyana, Haiti, Honduras, Hungary, Iceland, India, Indonesia, Ireland, Italy, Japan, Jordan, Kenya, South
Korea, Kuwait, Latvia, Lesotho, Liechtenstein, Lithuania, Luxembourg, Macedonia, Madagascar, Malawi, Mali, Malta, Mauritius, Mexico,
Moldova, Monaco, Mongolia, Morocco, Morocco, Mozambique, Namibia, Nepal, Netherlands, NZ, Nicaragua, Niger, Nigeria, Norway,
Panama, Papua New Guinea, Paraguay, Peru, Philippines, Poland, Portugal, Qatar, Romania, Russia, Saint Lucia, Sao Tome and Princ-
ipe, Senegal, Seychelles, Slovakia, Slovenia, South Africa, Spain, Sri Lanka, Sweden, Switzerland, Tanzania, Thailand, Tunisia, Turkey,
Ukraine, UK, US, Uruguay, Venezuela, Yemen, Yugoslavia
Community of Latin American and Caribbean States (CELAC)
note—successor to the Rio Group and the Latin America and Caribbean Summit on Integration and Development
established—created 23 February 2010; established July 2011
aim—to deepen the integration within Latin American and to reduce the influence of the US in the politics and economies of that part
of the world
members—(33) Antigua and Barbuda, Argentina, The Bahamas, Barbados, Belize, Bolivia, Brazil, Chile, Colombia, Costa Rica, Cuba,
Dominica, Dominican Republic, Ecuador, El Salvador, Grenada, Guatemala, Guyana, Haiti, Honduras, Jamaica, Mexico, Nicaragua,
Panama, Paraguay, Peru, St. Kitts and Nevis, St. Lucia, St. Vincent and the Grenadines, Suriname, Trinidad and Tobago, Uruguay, Venezuela
Comuinidade dos Paises de Lingua Portuguesa (CPLP)
established—1996 j
aim—to establish a forum for friendship among Portuguese-speaking nations where Portuguese is an official language
members—(8) Angola, Brazil, Cape Verde, Guinea-Bissau, Mozambique, Portugal, Sao Tome and Principe, Timor-Leste
associate observers—(3) Equatorial Guinea, Mauritius, Senegal
Conference of Interaction and Confidence-Building Measures in Asia (CICA)
established—proposed 5 October 1992; established 14 September 1999
aim—promoting a multi-national forum for enhancing cooperation towards promoting peace, security, and stability in Asia
members—(23 and the Palestine Liberation Organization) Afghanistan, Azerbaijan, Bahrain, Cambodia, China, Egypt, India, Iraq, Iran,
Israel, Jordan, Kazakhstan, Kyrgyzstan, Mongolia, Pakistan, South Korea, Russia, Tajikistan, Thailand, Turkey, UAE, Uzbekistan, Vietnam,
and the Palestine Liberation Organization
observers—(12) Bangladesh, Indonesia, Japan, League of Arab States, Malaysia, OSCE, Parliamentary Assembly of the Turkic Speaking
Countries, Philippines, Qatar, Ukraine, UN, US
Convention of the Southeast European Law Enforcement Center (SELEC)
note—successor to Southeast European Cooperative Initiative (SECI) formed in 1996 to help the Southeast European countries rebuild
and stabilize through access to resources
established—7 October 2011
aim—to provide support for Member States and enhance coordination in preventing and combating crime in trans-border activity
members—(13) Albania, Bosnia and Herzegovina, Bulgaria, Croatia, Greece, Hungary, Macedonia, Moldova, Montenegro, Romania,
Serbia, Slovenia, Turkey : a
observers—(17) Austria, Azerbaijan, Belgium, Czech Republic, France, Georgia, Germany, Israel, Italy, Japan, The Netherlands, Portugal,
Slovakia, Spain, Ukraine, UK, US
Coordinating Committee on Export Controls (COCOM)
established in 1949 to control the export of strategic products and technical data from member countries to proscribed destinations; members
were: Australia, Belgium, Canada, Denmark, France, Germany, Greece, Italy, Japan, Luxembourg, Netherlands, Norway, Portugal, Spain,
832
INTERNATIONAL ORGANIZATIONS AND GROUPS
Turkey, UK, US; abolished 31 March 1994; COCOM members established a new organization, the Wassenaar Arrangement, with expanded
membership on 12 July 1996 that focuses on nonproliferation export controls as opposed to East-West control of advanced technology
Council for Mutual Economic Assistance (CEMA)
note—also known as CMEA or Comecon
established 25 January 1949 to promote the development of socialist economies and abolished 1 January 1991; members included
Afghanistan (observer), Albania (had not participated since 1961 break with USSR), Angola (observer), Bulgaria, Cuba, Czechoslovakia,
Ethiopia (observer), GDR, Hungary, Laos (observer), Mongolia, Mozambique (observer), Nicaragua (observer), Poland, Romania, USSR
Vietnam, Yemen (observer), Yugoslavia (associate) : aa
Council of Arab Economic Unity (CAEU)
established—3 June 1957; effective—30 May 1964
aim—to promote economic integration among Arab nations x ; p
members—(17 plus the Palestine Liberation Organization) Algeria, Bahrain, Egypt, Iraq, Jordan, Kuwait, Lebanon, Libya, Morocco, Oman
Qatar, Saudi Arabia, Sudan, Syria, Tunisia, UAE, Yemen, Palestine Liberation Organization l
—(4) Comoros, Djibouti, Mauritania, Somalia
Council of Europe (CE)
established—5 May 1949; effective—3 August 1949
aim—to promote increased unity and quality of life in Europe f ''
members—(47) Albania, Andorra, Armenia, Austria, Azerbaijan, Belgium, Bosnia and Herzegovina, Bulgaria, Croatia, Cyprus, Czech
Republic, Denmark, Estonia, Finland, France, Georgia, Germany, Greece, Hungary, Iceland, Ireland, Italy, Latvia, Liechtenstein, Lithuania,
Luxembourg, Macedonia, Malta, Moldova, Monaco, Montenegro, Netherlands, Norway, Poland, Portugal, Romania, Russia, San Marino,
` Serbia, Slovakia, Slovenia, Spain, Sweden, Switzerland, Turkey, Ukraine, UK
observers—(6) Canada, Holy See, Israel, Japan, Mexico, US
Council of the Baitic Sea States (CBSS)
established—6 March 1992
aim—to promote cooperation among the Baltic Sea states in the areas of aid to new democratic institutions, economic development,
humanitarian aid, energy and the environment, cultural programs and education, and transportation and communication
members—({12) Denmark, Estonia, EC, Finland, Germany, Iceland, Latvia, Lithuania, Norway, Poland, Russia, Sweden
observers—{10) Belarus, France, Italy, Netherlands, Romania, Spain, Slovakia, Ukraine, UK, US
Council of the Entente (Entente)
established—29 May 1959
aim—to promote economic, social, and political coordination
members—(5) Benin, Burkina Faso, Cote d''Ivoire, Niger, Togo
countries in transition
a term used by the International Monetary Fund (IMF) for the middle group in its hierarchy of formerly centrally planned economies;
IMF statistics include the following 28 countries in transition: Albania, Armenia, Azerbaijan, Belarus, Bosnia and Herzegovina, Bul-
garia, Croatia, Czech Republic, Estonia, Georgia, Hungary, Kazakhstan, Kyrgyzstan, Latvia, Lithuania, Macedonia, Moldova, Mongolia,
Montenegro, Poland, Romania, Russia, Serbia, Slovakia, Slovenia, Tajikistan, Turkmenistan, Ukraine, Uzbekistan; note—this group is
identical to the group traditionally referred to as the “former USSR/Eastern Europe” except for the addition of Mongolia
Customs Cooperation Counci! (CCC)
note—see World Customs Organization (WCO)
developed countries (DCs)
the top group in the hierarchy of developed countries (DCs), former USSR/Eastern Europe (former USSR/EE), and less developed countries
(LDCs); includes the market-oriented economies of the mainly democratic nations in the Organization for Economic Cooperation and
Development (OECD), Bermuda, Israel, South Africa, and the European ministates; also known as the First World, high- income countries,
the North, industrial countries; generally have a per capita GDP in excess of $15,000 although four OECD countries and South Africa
have figures well under $15,000 and eight of the excluded OPEC countries have figures of more than $20,000; the DCs include: Andorra,
Australia, Austria, Belgium, Bermuda, Canada, Denmark, Faroe Islands, Finland, France, Germany, Greece, Holy See, Iceland, Ireland,
Israel, Italy, Japan, Liechtenstein, Luxembourg, Malta, Monaco, Netherlands, NZ, Norway, Portugal, San Marino, South Africa, Spain,
Sweden, Switzerland, Turkey, UK, US; note—similar to the new International Monetary Fund (IMF) term “advanced economies” that adds
Hong Kong, South Korea, Singapore, and Taiwan but drops Malta, Mexico, South Africa, and Turkey
developing countries : l
a term used by the International Monetary Fund (IMF) for the bottom group in its hierarchy of advanced economies, countries in transi-
tion, and developing countries; IMF statistics include the following 126 developing countries: Afghanistan, Algeria, Angola, Antigua and
Barbuda, Argentina, Aruba, The Bahamas, Bahrain, Bangladesh, Barbados, Belize, Benin, Bhutan, Bolivia, Botswana, Brazil, Burkina Faso,
Burma, Burundi, Cambodia, Cameroon, Cape Verde, Central African Republic, Chad, Chile, China, Colombia, Comoros, Democratic
Republic of the Congo, Republic of the Congo, Costa Rica, Cote d''Ivoire, Cyprus, Djibouti, Dominica, Dominican Republic, Ecuador, Egypt,
El Salvador, Equatorial Guinea, Ethiopia, Fiji, Gabon, The Gambia, Ghana, Grenada, Guatemala, Guinea, Guinea-Bissau, Guyana, Haiti,
Honduras, India, Indonesia, Iran, Iraq, Jamaica, Jordan, Kenya, Kiribati, Kuwait, Laos, Lebanon, Lesotho, Liberia, Libya, Madagascar, Malawi,
Malaysia, Maldives, Mali, Malta, Marshall Islands, Mauritania, Mauritius, Mexico, Federated States of Micronesia, Morocco, Mozambique,
Namibia, Nepal, Netherlands Antilles, Nicaragua, Niger, Nigeria, Oman, Pakistan, Panama, Papua New Guinea, Paraguay, Peru, Philippines,
Qatar, Rwanda, Saint Kitts and Nevis, Saint Lucia, Saint Vincent and the Grenadines, Samoa, Sao Tome and Principe, Saudi Arabia, Sen-
egal, Seychelles, Sierra Leone, Solomon Islands, Somalia, South Africa, Sri Lanka, Sudan, Suriname, Swaziland, Syria, Tanzania, Thailand,
Togo, Trinidad and Tobago, Tunisia, Turk','8c9333da95e084890c19c265dd105baf5df4719c4d9d96f69161b64d31f55d5c','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('71c271ba49adab89e8b097f3efbff046ca4395c6c9653df6a3f9e855093484a4',2025,'ZW','Zimbabwe','environment',1732,'ey, UAE, Uganda, Uruguay, Vanuatu, Venezuela, Vietnam, Yemen, Zambia, Zimbabwe; note—this
category would presumably also cover the following 46 other countries that are traditionally included in the more comprehensive group of
“less developed countries”: American Samoa, Anguilla, British Virgin Islands, Brunei, Cayman Islands, Christmas Island, Cocos Islands,
833
THE CIA WORLD FACTBOOK
Cook Islands, Cuba, Eritrea, Falkland Islands, French Guiana, French Polynesia, Gaza Strip, Gibraltar, Greenland, Grenada, Guadeloupe,
Guam, Guernsey, Isle of Man, Jersey, North Korea, Macau, Martinique, Mayotte, Montserrat, Nauru, New Caledonia, Niue, Norfolk Island,
Northern Mariana Islands, Palau, Pitcairn Islands, Puerto Rico, Reunion, Saint Helena, Ascension, and Tristan da Cunha, Saint Pierre and
Miquelon, Tokelau, Tonga, Turks and Caicos Islands, Tuvalu, Virgin Islands, Wallis and Futuna, West Bank, Western Sahara
Developing Eight (D-8)
established—15 June 1997 a !
aim—to improve developing countries’ positions in the world economy, diversify and create new opportunities in trade relations, enhance
participation in decision-making at the international level, provide better standards of living
member—(8) Bangladesh, Egypt, Indonesia, Iran, Malaysia, Nigeria, Pakistan, Turkey
East African Community (EAC)
note—originally established in 1967, it was disbanded in 1977 established—January 2001
aim—to establish a political and economic union among the countries
members—(5) Burundi, Kenya, Rwanda, Tanzania, Uganda
East African Development Bank (EADB)
established—6 June 1967; effective—1 December 1967
aim—to promote economic development l
members—(4) Kenya, Rwanda, Tanzania, Uganda
East Asia Summit (EAS)
established—14 December 2005
aim—to promote cooperation in political and security issues; to promote development, financial stability, energy security, eco-
nomic integration and growth; to eradicate poverty and narrow the development gap in East Asia, and to promote deeper cultural
understanding
members—(18) Australia, Brunei, Burma, Cambodia, China, India, Indonesia, Japan, South Korea, Laos, Malaysia, NZ, Philippines,
Russia, Singapore, Thailand, US, Vietnam
Economic and Monetary Community of Central Africa (CEMAC)
note—was formerly the Central African Customs and Economic Union (UDEAC)
established—8 December 1964; effective—1 January 1966-
aim—to promote the establishment of a Central African Common Market
members—(6) Cameroon, Central African Republic, Chad, Republic of the Congo, Equatorial Guinea, Gabon
Economic and Monetary Union (EMU)
note—an integral part of the European Union; also known as the European Economic and Monetary Union
established—1-2 December 1969 (proposed at summit conference of heads of government; 7 February 1992 (Maastricht Treaty signed)
aim—to promote a single market by creating a single currency, the euro; timetable—2 May 1998: European exchange rates fixed for 1
January 1999; 1 January 1999: all banks and stock exchanges begin using euros; 1 January 2002: the euro goes into circulation; 1 July
2002 local currencies no longer accepted
members—(17) Austria, Belgium, Cyprus, Estonia, Finland, France, Germany, Greece, Ireland, Italy, Luxembourg, Malta, Netherlands,
Portugal, Slovakia, Slovenia, Spain
Economic and Social Council (ECOSOC)
established—26 June 1945; effective—24 October 1945
aim—to coordinate the economic and social work of the UN; includes fiye regional commissions (Economic Commission for Africa, Eco-
nomic Commission for Europe, Economic Commission for Latin America and the Caribbean, Economic and Social Commission for Asia
and the Pacific, Economic and Social Commission for Western Asia) and nine functional commissions (Commission for Social Develop-
ment, Commission on Human Rights, Commission on Narcotic Drugs, Commission on the Status of Women, Commission on Population
and Development, Statistical Commission, Commission on Science and Technology for Development, Commission on Sustainable Devel-
opment, and Commission on Crime Prevention and Criminal Justice)
members—(54) selected on a rotating basis from all regions
Economic Community of the Great Lakes Countries (CEPGL)
note—acronym from Communaute Economique des Pays des Grands Lacs
established—20 September 1976
aim—to promote regional economic cboperation and integration
members—(3) Burundi, Democratic Republic of the Congo, Rwanda; note—organization collapsed because of fighting in 1998; reactivated
in 2006
Economic Community of West African States (ECOWAS)
established—28 May 1975
aim—to promote regional-economic cooperation
members—(15) Benin, Burkina Faso, Cape Verde, Cote d’lvoire, The Gambia, Ghana, Guinea, Guinea-Bissau, Liberia, Mali, Niger,
Nigeria, Senegal, Sierra Leone, Togo
Economic Cooperation Organization (ECO)
established—27-29 January 1985
aim—to promote regional cooperation in trade, transportation, communications, tourism, cultural affairs, and economic development
members—(10) Afghanistan, Azerbaijan, Iran, Kazakhstan, Kyrgyzstan, Pakistan, Tajikistan, Turkey, Turkmenistan, Uzbekistan
Eurasian Economic Community (EAEC or EurasEC)
note—merged with Central Asian Cooperation Organization (CACO) in 2005
834
INTERNATIONAL ORGANIZATIONS AND GROUPS
established—May 2001
aim—to create a common economic and energy policy
members—(6) Belarus, Kazakhstan, Kyrgyzstan, Russia, Tajikistan, Uzbekistan
observers—(3) Armenia, Moldova, Ukraine a; `
Euro-Atlantic Partnership Council (EAPC)
note—began as the North Atlantic Cooperation Council (NACC); an extension of NATO
established—8 November 1991; effective—20 December.1991 E
aim—to discuss cooperation on mutual political and security issues
members—(50) Albania, Armenia, Austria, Azerbaijan, Belarus, Belgium, Bosnia and Herzegovina, Bulgaria, Canada, Croatia, Czech
Republic, Denmark, Estonia, Finland, France, Georgia, Germany, Greece, Hungary, Iceland, Ireland, Italy, Kazakhstan, Kyrgyzstan, Lat-
via, Lithuania, Luxembourg, Macedonia, Malta, Moldova, Montenegro, Netherlands, Norway, Poland, Portugal, Romania, Russia, Serbia,
Slovakia, Slovenia, Spain, Sweden, Switzerland, Tajikistan, Turkey, Turkmenistan, Ukraine, UK, US, Uzbekistan
European Bank for Reconstruction and Development (EBRD)
established—8-9 January 1990 (proposals made); 15 April 1991 (bank inaugurated)
aim—to facilitate the transition of seven centrally planned economies in Europe (Bulgaria, former Czechoslovakia, Hungary, Poland,
Romania, former USSR, and former Yugoslavia) to market economies by committing 60% of its loans to privatization
members—(65) Albania, Armenia, Australia, Austria, Azerbaijan, Belarus, Belgium, Bosnia and Herzegovina, Bulgaria, Canada, Croatia,
Cyprus, Czech Republic, Denmark, Egypt, EU, European Investment Bank(EIB), Estonia, Finland, France, Georgia, Germany, Greece,
Hungary, Iceland, Ireland, Israel, Italy, Japan, Jordan, Kazakhstan, South Korea, Kyrgyzstan, Latvia, Liechtenstein, Lithuania, Luxembourg,
Macedonia, Malta, Mexico, Moldova, Mongolia, Montenegro, Morocco, Netherlands, NZ, Norway, Poland, Portugal, Romania, Russia,
Serbia, Slovakia, Slovenia, Spain, Sweden, Switzerland, Tajikistan, Tunisia, Turkey, Turkmenistan, Ukraine, UK, US, Uzbekistan
European Central Bank (ECB)
established—1 June 1998
aim—to administer the monetary policy of the EU Eurozone member states
members—(17) Austria, Belgium, Cyprus, Estonia, Finland, France, Germany, Greece, Ireland, Italy, Luxembourg, Malta, Netherlands,
Portugal, Slovakia, Slovenia, Spain f
European Community (or European Communities, EC)
established 8 April 1965 to integrate the European Atomic Energy Community (Euratom), the European Coal and Steel Community
(ECSC), the European Economic Community (EEC or Common Market), and to establish a completely integrated common market and
an eventual federation of Europe; merged into the European Union (EU) on 7 February 1992; member states at the time of merger were
Belgium, Denmark, France, Germany, Greece, Ireland, Italy, Luxembourg, Netherlands, Portugal, Spain, UK
European Free Trade Association (EFTA)
established—4 January 1960; effective—3 May 1960
aim—to promote expansion of free trade
members—(4) Iceland, Liechtenstein, Norway, Switzerland
European Investment Bank (EIB)
established —25 March 1957; effective—1 January 1958
aim—to promote economic development of the EU and its predecessors, the EEC and the EC
members—(27) Austria, Belgium, Bulgaria, Cyprus, Czech Republic, Denmark, Estonia, Finland, France, Germany, Greece, Hungary,
Ireland, Italy, Latvia, Lithuania, Luxembourg, Malta, Netherlands, Poland, Portugal, Romania, Slovakia, Slovenia, Spain, Sweden, UK
European Organization for Nuclear Research (CERN)
note—acronym retained from the predecessor organization Conseil Europeenne pour la Recherche Nucleaire
established—1 July 1953; effective—29 September 1954
aim—to foster nuclear research for peaceful purposes only
members—(20) Austria, Belgium, Bulgaria, Czech Republic, Denmark, Finland, France, Germany, Greece, Hungary, Italy, Netherlands,
Norway, Poland, Portugal, Slovakia, Spain, Sweden, Switzerland, UK i
observers—(7) EC, India, Japan, Russia, Turkey, United Nations Educational, Scientific, and Cultural Organization (UNESCO), US
European Space Agency (ESA)
established—31 May 1975 ——
aim—to promote peaceful cooperation in space research and technology
members—(20) Austria, Belgium, Czech Republic, Denmark, Finland, France, Germany, Greece, Ireland, Italy, Luxembourg, Netherlands,
Norway, Poland, Portugal, Romania, Spain, Sweden, Switzerland, UK
cooperating states—(3) Estonia, Hungary, Slovenia
European Union (EU)
note—sée European Union entry at the end of the “country” listings
Extractive Industry Transparency Initiative (EITI)
established October 2002 Initiative announced; June 2003 first EITC Plenary Conference
aim—to set a global standard for transparency in the extractive industries in an effort to make natural resources benefit all
stake holders or implementing countries—(17) Australia, Belgium, Canada, Denmark, Finland, France, Germany, Italy, Japan,
`. Netherlands, Norway, Qatar, Spain, Sweden, Switzerland, UK, US oe. ` ee
beanie aaite Azerbaijan, Central African Republic, Ghana, Kyrgyz Republic, Liberia, Mali, Mauritania, Mongolia,
Mozambique, Niger, Nigeria, Peru, Timor-Leste, Yemen, Zambia
å :
835
THE CIA WORLD FACTBOOK
candidate countries—(21) Afghanistan, Albania, Burkina Faso, Cameroon, Chad, Democratic Republic of the Congo, Republic of the
Congo, Cote d''lvoire, Gabon, Guatemala, Guinea, Indonesia, Iraq, Kazakhstan, Madagascar (suspended), Sao Tome and Principe, Sierra
Leone, Solomon Islands, Tanzania, Togo, Trinidad and Tobago
Financial Action Task Force (FATF)
established—by G-7 Summit in Paris in 1989
aim—to develop and promote policies to combat money laundering and terrorist financing
members—(36) Argentina, Australia, Austria, Belgium, Brazil, Canada, China, Denmark, EC, Finland, France, Germany, Greece, Gulf
Cooperation Council, Hong Kong, Iceland, India, Ireland, Italy, Japan, South Korea, Luxembourg, Mexico, Netherlands (Aruba, Curacao,
Sint Maarten), NZ, Norway, Portugal, Russia, Singapore, South Africa, Spain, Sweden, Switzerland, Turkey, UK, US
First World
another term for countries with advanced, industrialized economies; this term is fading from use; see developed countries (DCs)
Food and Agriculture Organization (FAO)
established —16 October 1945
aim—to raise living standards and increase availability of agricultural products; a UN specialized agency
members—(192) includes all UN member countries except Brunei, Liechtenstein, Singapore, South Sudan (189 total); plus Cook Islands,
EU, and Niue
former Soviet Union (FSU) _
former term often used to identify as a group the successor nations to the Soviet Union or USSR; this group of 15 countries consists of:
Armenia, Azerbaijan, Belarus, Estonia, Georgia, Kazakhstan, Kyrgyzstan, Latvia, Lithuania, Moldova, Russia, Tajikistan, Turkmenistan,
Ukraine, Uzbekistan
former USSR/Eastern Europe (former USSR/EE)
the middle group in the hierarchy of developed countries (DCs), former USSR/Eastern Europe (former USSR/EE), and less developed countries
(LDCs); these countries are in political and economic transition and may well be grouped differently in the near future; this group of 27 coun-
tries consists of: Albania, Armenia, Azerbaijan, Belarus, Bosnia and Herzegovina, Bulgaria, Croatia, Czech Republic, Estonia, Georgia, Hun-
gary, Kazakhstan, Kyrgyzstan, Latvia, Lithuania, Macedonia, Moldova, Poland, Romania, Russia, Slovakia, Slovenia, Tajikistan, Turkmenistan,
Ukraine, Uzbekistan, Yugoslavia; this group is identical to the IMF group “countries in transition” except for the IMF''s inclusion of Mongolia
Four Dragons
the four small Asian less developed countries (LDCs) that have experienced unusually rapid economic growth; also known as the Four Tigers;
this group consists of Hong Kong, South Korea, Singapore, Taiwan; these countries are included in the IMF''s “advanced economies” group
Franc Zone (FZ)
note—also known as Conference des Ministres des Finances des Pays de la Zone Franc
established—1964
aim—to form a monetary union among countries whose currencies were linked to the French franc
members—(16) Benin, Burkina Faso, Cameroon, Central African Republic, Chad, Comoros, Republic of the Congo, Cote d''lvoire, Equa-
torial Guinea, France, Gabon, Guinea-Bissau, Mali, Niger, Senegal, Togo
Front Line States (FLS)
established to achieve black majority rule in South Africa; has since gone out of existence; members included Angola, Botswana,
Mozambique, Namibia, Tanzania, Zambia, Zimbabwe
General Agreement on Tariffs and Trade (GATT)
see the World Trade Organization (WTO)
Genera! Confederation of Trade Unions (GCTU)
established—16 April 1992
aim—to consolidate trade union actions to protect citizens’ social and labor rights and interests, to help secure trade unions’ rights and
guarantees, and to strengthen international trade union solidarity
members—(10) Armenia, Azerbaijan, Belarus, Georgia, Kazakhstan, Kyrgyzstan, Moldova, Russia, Tajikistan, Ukraine
Group of 10 (G-10)
note—also known as the Paris Club; includes the wealthiest members of the IMF who provide most of the money to be loaned and act as
the informal steering committee; name persists despite increased membership
established—October 1962
aim—to coordinate credit policy
members—(11) Belgium, Canada, France, Germany, Italy, Japan, Netherlands, Sweden, Switzerland, UK, US
observers—(4) BIS, EC, IMF OECD
Group of 11 (G-11)
established—2006
aim—to narrow the income gap with the world’s richest nations
members—(12) Croatia, Ecuador, El Salvador, Georgia, Honduras, Indonesia, Jordan, Morocco, Pakistan, Paraguay, Sri Lanka, Tunisia
Group of 15 (G-15)
note—byproduct of the Nonaligned Movement; name persists despite increased membership
established—September 1989
aim—to promote economic cooperation among developing nations; to act as the main political organ for the Nonaligned Movement
B36
INTERNATIONAL ORGANIZATIONS AND GROUPS
members—(17) Algeria, A i i i i ; . fis , i ,
lankas comme =o edi Brazil, Chile, Egypt, India, Indonesia, Iran, Jamaica, Kenya, Malaysia, Mexico, Nigeria, Senegal, Sri
Group of 20 (G-20)
established—created 1999; inaugurated 15-16 December 1999
aim—to promote open and constructive discussion between industrial and emerging-market countries on any issues related to global eco-
nomic stability; helps to support growth and development across the globe
members—(20) Argentina, Australia, Brazil, Canada, China, EU, France, G India, Ind i i
ge omen mig. ae Cte ce, Germany, India, Indonesia, Italy, Japan, South Korea, Mexico,
Group of 24 (G-24)
established—1 August 1989 : :
aim—to promote the interests of developing countries in Africa, Asia, and Latin America within the IMF
members—(24) Algeria, Argentina, Brazil, Colombia, Democratic Republic of the Congo, Cote d''Ivoire, Egypt, Ethiopia, Gabon, Ghana
e ae India, Iran, Lebanon, Mexico, Nigeria, Pakistan, Peru, Philippines, South Africa, Sri Lanka, Syria, Trinidad and Teo,
enezuela
observers—(1) China. We l
Group of 3 (G-3)
established—September 1990
aim—mechanism for policy coordination
members—(2) Colombia, Mexico; note—Panama shows interest in joining
'' Group of 5 (G-5)
established—22 September 1985
aim—to coordinate the economic policies of five major noncommunist economic powers
members—(5) France, Germany, Japan, UK, US
Group of 6 (G-6)
also known as Groupe des Six Sur le Desarmement (not to be confused with the Big Six) was established in 22 May 1984 with the aim of
achieving nuclear disarmament; its members were Argentina, Greece, India, Mexico, Sweden, Tanzania
Group of 7 (G-7)
note—membership is the same as the Big Seven
established—22 September 1985
aim—to facilitate economic cooperation among the seven major noncommunist economic powers
members—(7) Group of 5 (France, Germany, Japan, UK, US) plus Canada and Italy
Group of 77 (G-77)
established—15 June1964; October 1967 first ministerial meeting
aim—to promote economic cooperation among developing countries; name persists in spite of increased membership
members—(131 plus the Palestine Liberation Organization) Afghanistan, Algeria, Angola, Antigua and Barbuda, Argentina, The
Bahamas, Bahrain, Bangladesh, Barbados, Belize, Benin, Bhutan, Bolivia, Bosnia and Herzegovina, Botswana, Brazil, Brunei, Burkina Faso,
Burma, Burundi, Cambodia, Cameroon, Cape Verde, Central African Republic, Chad, Chile, China, Colombia, Comoros, Democratic
Republic of the Congo, Republic of the Congo, Costa Rica, Cote d''Ivoire, Cuba, Djibouti, Dominica, Dominican Republic, Ecuador,
Egypt, El Salvador, Equatorial Guinea, Eritrea, Ethiopia, Fiji, Gabon, The Gambia, Ghana, Grenada, Guatemala, Guinea, Guinea- Bissau,
Guyana, Haiti, Honduras, India, Indonesia, Iran, Iraq, Jamaica, Jordan, Kenya, North Korea, Kuwait, Laos, Lebanon, Lesotho, Liberia,
Libya, Madagascar, Malawi, Malaysia, Maldives, Mali, Marshall Islands, Mauritania, Mauritius, Federated States of Micronesia, Mongolia,
Morocco, Mozambique, Namibia, Nauru, Nepal, Nicaragua, Niger, Nigeria, Oman, Pakistan, Panama, Papua New Guinea, Paraguay, Peru,
Philippines, Qatar, Rwanda, Saint Kitts and Nevis, Saint Lucia, Saint Vincent and the Grenadines, Samoa, Sao Tome and Principe, Saudi
Arabia, Senegal, Seychelles, Sierra Leone, Singapore, Solomon Islands, Somalia, South Africa, Sri Lanka, Sudan, Suriname, Swaziland,
Syria, Tajikistan, Tanzania, Thailand, Timor-Leste, Togo, Tonga, Trinidad and Tobago, Tunisia, Turkmenistan, Uganda, UAE, Uruguay,
Vanuatu, Venezuela, Vietnam, Yemen, Zambia, Zimbabwe, Palestine Liberation Organization
Group of 8 (G-8)
established—October 1975
aim—to facilitate economic cooperation among the developed countries (DCs) that participated in the Conference on International Eco-
nomic Cooperation (CIEC), held in several sessions between December 1975 and 3 June 1977
members—(9) Canada, EU, France, Germany, Italy, Japan, Russia, UK, US
Group of 9 (G-9)
established NA
aim—to discuss matters of mutual interest on an informal basis
members—(9) Austria, Belgium, Bulgaria, Denmark, Finland, Hungary, Romania, Serbia, Sweden
Gulf Cooperation Council (GCC)
note—also known as the Cooperation Council for the Arab States of the Gulf
established —25 May 1981 -` ''
aim—to promote regional cooperation in economic, social, political, and military affairs
members—(6) Bahrain, Kuwait, Oman, Qatar, Saudi Arabia, UAE
high income countries :
another term for the industrialized countries with high per capita GDPs; see developed countries (DCs)
837
THE CIA WORLD FACTBOOK
Indian Ocean Commission (In0C)
established—21 December 1982
aim—to organize and promote regional cooperation in all sectors, especially economic
members—(5) Comoros, France (for Reunion), Madagascar, Mauritius, Seychelles
industrial countries
another term for the developed countries; see developed countries (DCs)
Inter-American Development Bank (IADB)
note—also known as Banco Interamericano de Desarrollo (BID)
established—8 April 1959; effective—30 December 1959
aim-—to promote economic and social development in Latin America
members—(48) Argentina, Austria, The Bahamas, Barbados, Belgium, Belize, Bolivia, Brazil, Canada, Chile, China, Colombia, Costa
Rica, Croatia, Denmark, Dominican Republic, Ecuador, El Salvador, Finland, France, Germany, Guatemala, Guyana, Haiti, Honduras,
Israel, Italy, Jamaica, Japan, South Korea, Mexico, Netherlands, Nicaragua, Norway, Panama, Paraguay, Peru, Portugal, Slovenia, Spain,
Suriname, Sweden, Switzerland, Trinidad and Tobago, UK, US, Uruguay, Venezuela
_Inter-Governmental Authority on Development (IGAD)
note—formerly known as Inter-Governmental Authority on Drought and Development (IGADD)
established—15-16 January 1986 as the Inter-Governmental Authority on Drought and Development; revitalized—21 March 1996 as the
Inter-Governmental Authority on Development
aim—to promote a social, economic, and scientific community among its members
members—(6) Djibouti, Ethiopia, Kenya, Somalia, Sudan, Uganda; note—Eritrea declared its suspension in 2007
partners—(20) Austria, Belgium, Canada, Denmark, EC, France, Germany, Greece, International Organization for Migration, Ireland,
Italy, Japan, Netherlands, Norway, Sweden, Switzerland, UK, UN Development Program, US, World Bank
Inter-Parliamentary Union (IPU)
established—1889
aim—fosters contacts among parliamentarians, considers and expresses views of international interest and concern with the purpose of
bringing about action by parliaments and parliamentarians, contributes to the defense and promotion of human rights, contributes to better
knowledge of representative institutions '' `
members—(161 and the Palestine Liberation Organization) Afghanistan, Albania, Algeria, Andorra, Angola, Argentina, Armenia, Aus-
tralia, Austria, Azerbaijan, Bahrain, Bangladesh, Belarus, Belgium, Benin, Bolivia, Bosnia and Herzegovina, Botswana, Brazil, Bulgaria,
Burkina Faso, Burma, Burundi, Cambodia, Cameroon, Canada, Cape Verde, Chad, Chile, China, Colombia, Democratic Republic of the
Congo, Republic of the Congo, Costa Rica, Cote d''Ivoire, Croatia, Cuba, Cyprus, Czech Republic, Denmark, Djibouti, Dominican Repub-
lic, Ecuador, Egypt, El Salvador, Equatorial Guinea, Estonia, Ethiopia, Finland, France, Gabon, The Gambia, Georgia, Germany, Ghana,
Greece, Guatemala, Guinea-Bissau, Haiti, Honduras, Hungary, Iceland, India, Indonesia, Iran, Iraq, Ireland, Israel, Italy, Japan, Jordan,
Kazakhstan, Kenya, North Korea, South Korea, Kuwait, Kyrgyzstan, Laos, Latvia, Lebanon, Lesotho, Libya, Liechtenstein, Lithuania, Lux-
embourg, Macedonia, Malawi, Malaysia, Maldives, Mali, Malta, Mauritania, Mauritius, Mexico, Federated States of Micronesia, Moldova,
Monaco, Mongolia, Montenegro, Morocco, Mozambique, Namibia, Nepal, Netherlands, NZ, Nicaragua, Niger, Nigeria, Norway, Oman,
Pakistan, Palau, Panama, Papua New Guinea, Paraguay, Peru, Philippines, Poland, Portugal, Qatar, Romania, Russia, Rwanda, Samoa, San
Marino, Sao Tome and Principe, Saudi Arabia, Senegal, Serbia, Seychelles, Sierra Leone, Singapore, Slovakia, Slovenia, South Africa,
South Sudan, Spain, Sri Lanka, Sudan, Suriname, Sweden, Switzerland, Syria, Tanzania, Tajikistan, Thailand, Timor-Leste, Togo, Trinidad
and Tobago, Tunisia, Turkey, Uganda, Ukraine, UAE, UK, Uruguay, Venezuela, Vietnam, Yemen, Zambia, Zimbabwe, Palestine Liberation
Organization l i : ''
associate members—(10) Andean Parliament, Central American Parliament, East African Legislative Assembly, European Parliament,
Inter-Parliamentary Committee of the West African Economic and Monetary Union, Latin American Parliament, Parliament of the Eco-
nomic Community of West African States, Parliament of the Economic and Monetary Community of Central Africa, Parliamentary Assem-
bly of the Council of Europe, Transitional Arab Parliament
international Atomic Energy Agency (IAEA)
established—26 October 1956; effect','6aba32d56d5c255e03b524842f24cb0edbb2d1d4a4710dfa3c07d6496815c34c','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('abb4592ada27b45dba2f20f5dfe2569271785aa93c6154a053309214e2b843c8',2025,'ZW','Zimbabwe','environment',1733,'ive—29 July 1957
aim—to promote peaceful uses of atomic energy
members—(162) Afghanistan, Albania, Algeria, Angola, Argentina, Armenia, Australia, Austria, Azerbaijan, Bahrain, Bangladesh,
Belarus, Belgium, Belize, Benin, Bolivia, Bosnia and Herzegovina, Botswana, Brazil, Bulgaria, Burkina Faso, Burma, Burundi, Cambodia,
Cameroon, Canada, Cape Verde, Central African Republic, Chad, Chile, China, Colombia, Democratic Republic of the Congo, Republic
of the Congo, Costa Rica, Cote d''Ivoire, Croatia, Cuba, Cyprus, Czech Republic, Denmark, Dominica, Dominican Republic, Ecuador,
Egypt, El Salvador, Eritrea, Estonia, Ethiopia, Fiji, Finland, France, Gabon, Georgia, Germany, Ghana, Greece, Guatemala, Haiti, Holy
See, Honduras, Hungary, Iceland, India, Indonesia, Iran, Iraq, Ireland, Israel, Italy, Jamaica, Japan, Jordan, Kazakhstan, Kenya, South
Korea, Kuwait, Kyrgyzstan, Laos, Latvia, Lebanon, Lesotho, Liberia, Libya, Liechtenstein, Lithuania, Luxembourg, Macedonia, Madagascar,
Malawi, Malaysia, Mali, Malta, Marshall Islands, Mauritania, Mauritius, Mexico, Moldova, Monaco, Mongolia, Montenegro, Morocco,
Mozambique, Namibia, Nepal, Netherlands, NZ, Nicaragua, Niger, Nigeria, Norway, Oman, Pakistan, Palau, Panama, Papua New Guinea,
Paraguay, Peru, Philippines, Poland, Portugal, Qatar, Romania, Russia, Rwanda, San Marino, Saudi Arabia, Senegal, Serbia, Seychelles,
Sierra Leone, Singapore, Slovakia, Slovenia, South Africa, Spain, Sri Lanka, Sudan, Swaziland, Sweden, Switzerland, Syria, Tajikistan,
Tanzania, Thailand, Togo, Tonga, Trinidad and Tobago, Tunisia, Turkey, Uganda, Ukraine, UAE, UK, US, Uruguay, Uzbekistan, Venezuela,
Vietnam, Yemen, Zambia, Zimbabwe
International Bank for Reconstruction and Development (IBRD)
note—also known as the World Bank
established—22 July 1944; effective—27 December 1945
aim—to provide economic development loans; a UN specialized agency
members—(188) includes all UN member countries except Andorra, Cuba, North Korea, Liechtenstein, Monaco, Nauru; plus Kosovo
838
INTERNATIONAL ORGANIZATIONS AND GROUPS
International Chamber of Commerce (ICC)
established—-1919
aim—to promote free trade and private enterprise and to represent business interests at national and international levels
members—131 plus the Palestine Liberation Organization
countries with national committees—(93 and the Palestine Liberation Organization) Albania, Algeria, Argentina, Australia, Austria,
Bahrain, Bangladesh, Belgium, Bolivia, Brazil, Bulgaria, Cameroon, Canada, Caribbean, Chile, China, Colombia, Costa Rica, Croatia,
Cuba, Cyprus, Czech Republic, Denmark, Dominican Republic, Ecuador, Egypt, El Salvador, Estonia, Finland, France, Georgia, Germany,
Ghana, Greece, Guatemala, Hong Kong, Hungary, Iceland, India, Indonesia, Iran, Ireland, Israel, Italy, Japan, Jordan, Kenya, South Korea,
Kuwait, Lebanon, Lithuania, Luxembourg, Macao, Madagascar, Malaysia, Mexico, Monaco, Morocco, Nepal, Netherlands, NZ, Nigeria,
Norway, Pakistan, Panama, Philippines, Poland, Portugal, Qatar, Romania, Russia, Saudi Arabia, Senegal, Serbia, Singapore, Slovakia,
Slovenia, South Africa, Spain, Sri Lanka, Sweden, Switzerland, Syria, Taiwan, Thailand, Togo, Tunisia, Turkey, Ukraine, UAE, UK, US,
Uruguay, Palestine Liberation Organization; note—Peru is restructuring
countries with no national committees having direct members—(38) Afghanistan, Andorra, Antigua and Barbuda, Armenia, Azerbaijan,
Belarus, Belize, Bermuda, Bosnia and Herzegovina, Brunei, Burkino Faso, Eritrea, Gibraltar, Kazakhstan, North Korea, Kyrgyzstan, Latvia,
Liberia, Libya, Macedonia, Maldives, Malta, Mauritius, Moldova, Mongolia, Montenegro, Mozambique, Oman, Peru, San Marino, Sudan,
Tajikistan, Tanzania, Trinidad: and Tobago, Uganda, Uzbekistan, Venezuela, Vietnam
International Civil Aviation Organization (ICAO)
established—7 December 1944; effective—4 April 1947
aim—to promote international cooperation in civil aviation; a UN specialized agency - a
members—(191) includes all UN member countries except Dominica, Liechtenstein, and Tuvalu (190 total); plus Cook Islands
_ International Civilian Support Mission in Haiti (MICAH)
established 17 December 1999 to promote respect for human rights; members included Argentina, Benin, Canada, France, India, Mali,
Niger, Senegal, Togo, Tunisia, US; closed 2001
International Committee of the Red Cross (ICRC)
established—17 February 1863
aim—to provide humanitarian aid in wartime
members—(15-25 individuals) all Swiss nationals
International Court of Justice (ICJ)
also known as the World Court; primary judicial organ of the UN
established—26 June 1945 with the signing of the UN Charter (inaugural sitting of the Court was on 18 April 1946); superseded Permanent
Court of International Justice (attached to the League of Nations)
aim—to settle disputes submitted by member states and to provide advice to UN organs and other international agencies i: ''
members—(15 judges) elected by the UN General Assembly and Security Council to represent all principal legal systems; judges elected to
nine-year terms (eligible for two additional terms); elections held every three years for one-third of the judges
jurisdiction—based on the principle of consent in contentious issues; consent to compulsory jurisdiction is outlined in Statute 36
of the ICJ; states provide declarations of consent to compulsory jurisdiction of the ICJ either with or without reservations (date in
parens after each state is when the declaration was deposited with the UN Secretary-General); Haiti, Luxembourg, Nicaragua, and
Uruguay deposited declarations with the Permanent Court of International Justice prior to 1945 and these were later transferred to
the ICJ)
states ana compulsory jurisdiction with reservations—(56) Australia (22 March 2002), Barbados (1 August 1980), Belgium (17
June 1958), Botswana (16 March 1970), Bulgaria (21 June 1992), Cambodia (19 September 1957), Canada (10 May 1994), Democratic
Republic of the Congo (8 February 1989), Cote d''Ivoire (29 September 2001), Cyprus (3 September 2002), Denmark (10 December
1956), Djibouti (2 September 2005), Egypt (22 July 1957), Estonia (31 October 1991), Finland (25 June 1958), The Gambia (22 June
1966), Germany (30 April 2008), Greece (10 January 1994), Guinea (4 December 1998), Honduras (6 June 1986), Hungary (22 October
1992), India (18 September 1974), Japan (9 July 2007), Kenya (19 April 1965), Lesotho (6 September 2000), Liberia (20 March 1952),
Liechtenstein (29 March 1950), Lithuania (21 September 2012), Madagascar (2 July 1992), Malawi (12 December 1966), Malta (2 Septem-
ber 1983), Mauritius (23 September 1968), Mexico (28 October 1947), Netherlands (1 August 1956), New Zealand (23 September 1977),
Nicaragua (24 September 1929), Nigeria (30 April 1998), Norway (25 June 1996), Pakistan (13 September 1960), Panama (25 October
1921), Peru (7 July 2003), Philippines (18 January 1972), Poland (25 March 1996), Portugal (25 February 2005), Senegal (2 December
1985), Slovakia (28 May 2004), Somalia (11 April 1963), Spain (20 October 1990), Sudan (2 January 1958), Suriname (31 August 1987),
Swaziland (26 May 1969), Sweden (6 April 1957), Switzerland (28 July 1948), Togo (25 October 1979), Uganda (3 October 1963), United
ingdom (5 July 2004). -
a SS ee mena? jurisdiction without reservations—(13) Austria (19 May 1971), Camerdon’ (3 March 1994), Costa Rica
(20 February 1973), Dominica (31 March 2006), Dominican Republic (30 September 1924), Georgia (20 June 1995), Guinea-Bissau (7
August 1989), Haiti (4 October 1921), Ireland (15 December 2011), Luxembourg (15 September 1930), Paraguay (25 September 1996),
Timor-Leste (21 September 2012), Uruguay (28 January 1921)
International Criminal Court (ICCt)
established—1 July 2002
aim—to hold all individuals and countries accountable to international laws of conduct; to specify international standards of conduct; to
provide an important mechanism for implementing these standards; to ensure that perpetrators are brought to justice
members—21 judges (three judges form the Presidency) and six judges each in the Pre-trial, Trial, and Appeals Divisions; judges “a by
secret ballot by the Assembly of States Parties to the Rome Statute for nine-year terms (not eligible for reelection) governed by the Statute
of the International Criminal Court treaty (or Rome Statute), adopted 17 July 1998 at the UN Conference of Plenipotentiaries in Rome
i el July 2002
e a (102) Afghanistan, Albania, Andorra, Antigua and Barbuda, Argentina, Australia, Austria, oe
Barbados, Belgium, Belize, Benin, Bolivia, Bosnia and Herzegovina, Botswana, Brazil, Bulgaria, Burkina Faso, Burundi, Cambodia, mii È
Cape Verde, Central African Republic, Chad, Chile, Colombia, Comoros, Cook Islands, Democratic Republic of the Congo, -_ e o
the Congo, Costa Rica, Cose d''Ivoire, Croatia, Cyprus, Czech Republic, Denmark, Djibouti, Dominica, Dominican Republic, Ecuador,
839
THE CIA WORLD FACTBOOK
Estonia, Fiji, Finland, France, Gabon, The Gambia, Georgia, Germany, Ghana, Greece, Grenada, Guatemala, Guinea, Guyana, Honduras,
Hungary, Iceland, Ireland, Italy, Japan, Jordan, Kenya, South Korea, Latvia, Lesotho, Liberia, Liechtenstein, Lithuania, Luxembourg, Mac-
edonia, Madagascar, Malawi, Maldives, Mali, Malta, Marshall Islands, Mauritius, Mexico, Moldova, Mongolia, Montenegro, Namibia,
Nauru, Netherlands, NZ, Niger, Nigeria, Norway, Panama, Paraguay, Peru, Philippines, Poland, Portugal, Romania, Saint Kitts and Nevis,
Saint Lucia, Saint Vincent and the Grenadines, Samoa, San Marino, Senegal, Serbia, Seychelles, Sierra Leone, Slovakia, Slovenia, South
Africa, Spain, Suriname, Sweden, Switzerland, Tajikistan, Tanzania, Timor-Leste, Trinidad and Tobago, Tunisia, Uganda, UK, Uruguay,
Vanuatu, Venezuela, Zambia
international Criminal Police Organization (interpol)
established—September 1923 set up as the International Criminal Police Commission; 13 June 1956 constitution modified and present
name adopted
aim—to promote international cooperation among police authorities in fighting crime
members—(190) Afghanistan, Albania, Algeria, Andorra, Angola, Antigua and Barbuda, Argentina, Armenia, Aruba, Australia, Austria,
Azerbaijan, The Bahamas, Bahrain, Bangladesh, Barbados, Belarus, Belgium, Belize, Benin, Bhutan, Bolivia, Bosnia and Herzegovina, Bot-
swana, Brazil, Brunei, Bulgaria, Burkina Faso, Burma, Burundi, Cambodia, Cameroon, Canada, Cape Verde, Central African Republic, Chad,
Chile, China, Colombia, Comoros, Democratic Republic of the Congo, Republic of the Congo, Costa Rica, Cote d''lvoire, Croatia, Cuba,
Curacao, Cyprus, Czech Republic, Denmark, Djibouti, Dominica, Dominican Republic, Ecuador, Egypt, El Salvador, Equatorial Guinea,
Eritrea, Estonia, Ethiopia, Fiji, Finland, France, Gabon, The Gambia, Georgia, Germany, Ghana, Greece, Grenada, Guatemala, Guinea,
Guinea-Bissau, Guyana, Haiti, Holy See, Honduras, Hungary, Iceland, India, Indonesia, Iran, Iraq, Ireland, Israel, Italy, Jamaica, Japan,
Jordan, Kazakhstan, Kenya, South Korea, Kuwait, Kyrgyzstan, Laos, Latvia, Lebanon, Lesotho, Liberia, Libya, Liechtenstein, Lithuania,
Luxembourg, Macedonia, Madagascar, Malawi, Malaysia, Maldives, Mali, Malta, Marshall Islands, Mauritania, Mauritius, Mexico, Moldova,
Monaco, Mongolia, Montenegro, Morocco, Mozambique, Namibia, Nauru, Nepal, Netherlands, NZ, Nicaragua, Niger, Nigeria, Norway,
Oman, Pakistan, Panama, Papua New Guinea, Paraguay, Peru, Philippines, Poland, Portugal, Qatar, Romania, Russia, Rwanda, Saint Kitts
and Nevis, Saint Lucia, Saint Vincent and the Grenadines, Samoa, San Marino, Sao Tome and Principe, Saudi Arabia, Senegal, Serbia,
Seychelles, Sierra Leone, Singapore, Sint Maarten, Slovakia, Slovenia, Somalia, South Africa, South Sudan, Spain, Sri Lanka, Sudan,
Suriname, Swaziland, Sweden, Switzerland, Syria, Tajikistan, Tanzania, Thailand, Timor-Leste, Togo, Tonga, Trinidad and Tobago, Tunisia,
Turkey, Turkmenistan, Uganda, Ukraine, UAE, UK, US, Uruguay, Uzbekistan, Venezuela, Vietnam, Yemen, Zambia, Zimbabwe
subbureaus—(11) American Samoa, Anguilla, Bermuda, British Virgin Islands, Cayman Islands, Gibraltar, Hong Kong, Macau, Montserrat,
Puerto Rico, Turks and Caicos Islands ;
International Development Association (IDA)
established—26 January 1960; effective—24 September 1960
aim—to provide economic loans for low-income countries; UN specialized agency and IBRD affiliate
members—(189) Afghanistan, Albania, Algeria, Angola, Antigua and Barbuda, Argentina, Armenia, Australia, Austria, Azerbaijan, The
Bahamas, Bahrain, Bangladesh, Barbados, Belarus, Belgium, Belize, Benin, Bhutan, Bolivia, Bosnia and Herzegovina, Botswana, Brazil,
Brunei, Bulgaria, Burkina Faso, Burma, Burundi, Cambodia, Cameroon, Canada, Cape Verde, Central African Republic, Chad, Chile,
China, Colombia, Comoros, Democratic Republic of the Congo, Republic of the Congo, Costa Rica, Cote d''Ivoire, Croatia, Cyprus, Czech
Republic, Denmark, Djibouti, Dominica, Dominican Republic, Ecuador, Egypt, El Salvador, Equatorial Guinea, Eritrea, Estonia, Ethiopia,
EU, Fiji, Finland, France, Gabon, The Gambia, Georgia, Germany, Ghana, Greece, Grenada, Guatemala, Guinea, Guinea-Bissau, Guyana,
Haiti, Honduras, Hungary, Iceland, India, Indonesia, Iran, Iraq, Ireland, Israel, Italy, Jamaica, Japan, Jordan, Kazakhstan, Kenya, Kiribati,
South Korea, Kosovo, Kuwait, Kyrgyzstan, Laos, Latvia, Lebanon, Lesotho, Liberia, Libya, Lithuania, Luxembourg, Macedonia, Madagas-
car, Malawi, Malaysia, Maldives, Mali, Malta, Marshall Islands, Mauritania, Mauritius, Mexico, Federated States of Micronesia, Moldova,
Mongolia, Montenegro, Morocco, Mozambique, Namibia, Nepal, Netherlands, NZ, Nicaragua, Niger, Nigeria, Norway, Oman, Pakistan,
Palau, Panama, Papua New Guinea, Paraguay, Peru, Philippines, Poland, Portugal, Qatar, Romania, Russia, Rwanda, Saint Kitrs and Nevis,
Saint Lucia, Saint Vincent and the Grenadines, Samoa, San Marino, Sao Tome and Principe, Saudi Arabia, Senegal, Serbia, Seychelles,
Sierra Leone, Singapore, Slovakia, Slovenia, Solomon Islands, Somalia, South Africa, South Sudan, Spain, Sri Lanka, Sudan, Suriname,
Swaziland, Sweden, Switzerland, Syria, Tajikistan, Tanzania, Thailand, Timor-Leste, Togo, Tonga, Trinidad and Tobago, Tunisia, Turkey,
Turkmenistan, Tuvalu, Uganda, Ukraine, UAE, UK, US, Uruguay, Uzbekistan, Vanuatu, Venezuela, Vietnam, Yemen, Zambia, Zimbabwe
International Energy Agency (IEA)
established—15 November 1974
aim—to promote cooperation on energy matters, especially emergency oil sharing and relations between oil consumers and oil producers;
established by the OECD
members—(29) Australia, Austria, Belgium, Canada, Czech Republic, Denmark, EC, Finland, France, Germany, Greece, Hungary, Ireland,
Italy, Japan, South Korea, Luxembourg, Netherlands, NZ, Norway, Poland, Portugal, Slovakia, Spain, Sweden, Switzerland, Turkey, UK, US
International Federation of Red Cross and Red Crescent Societies (IFRCS)
note—formerly known as League of Red Cross and Red Crescent Societies (LORCS)
established—5 May 1919
aim—to organize, coordinate, and direct international relief actions; to promote humanitarian activities; to represent and encourage the
development of National Societies; to bring help to victims of armed conflicts, refugees, and displaced people; to reduce the vulnerability
of people through development programs
members—(187 plus the Palestine Liberation Organization) Afghanistan, Albania, Algeria, Andorra, Angola, Antigua and Barbuda,
Argentina, Armenia, Australia, Austria, Azerbaijan, The Bahamas, Bahrain, Bangladesh, Barbados, Belarus, Belgium, Belize, Benin,
Bolivia, Bosnia and Herzegovina, Botswana, Brazil, Brunei, Bulgaria, Burkina Faso, Burma, Burundi, Cambodia, Cameroon, Canada, Cape
Verde, Central African Republic, Chad, Chile, China, Colombia, Comoros, Democratic Republic of the Congo, Republic of the Congo,
Cook Islands, Costa Rica, Cote d’lvoire, Croatia, Cuba, Czech Republic, Denmark, Djibouti, Dominica, Dominican Republic, Ecuador,
Egypt, El Salvador, Equatorial Guinea, Estonia, Ethiopia, Fiji, Finland, France, Gabon, The Gambia, Georgia, Germany, Ghana, Greece,
Grenada, Guatemala, Guinea, Guinea-Bissau, Guyana, Haiti, Honduras, Hungary, Iceland, India, Indonesia, Iran, Iraq, Ireland, Israel,
Italy, Jamaica, Japan, Jordan, Kazakhstan, Kenya, Kiribati, North Korea, South Korea, Kuwait, Kyrgyzstan, Laos, Latvia, Lebanon, Lesotho,
Liberia, Libya, Liechtenstein, Lithuania, Luxembourg, Macedonia, Madagascar, Malawi, Malaysia, Maldives, Mali, Malta, Mauritania,
Mauritius, Mexico, Federated States of Micronesia, Moldova, Monaco, Mongolia, Montenegro, Morocco, Mozambique, Namibia, Nepal,
Netherlands, NZ, Nicaragua, Niger, Nigeria, Norway, Pakistan, Palau, Panama, Papua New Guinea, Paraguay, Peru, Philippines, Poland,
840
INTERNATIONAL ORGANIZATIONS AND GROUPS
Portugal, Qatar, Romania, Russia, Rwanda, Saint Kitts and Nevis, Saint Lucia, Saint Vincent and the Grenadines, Samoa, San Marino,
Sao Tome and Principe, Saudi Arabia, Senegal, Serbia, Seychelles, Sierra Leone, Singapore, Slovakia, Slovenia, Solomon Islands, Somalia,
South Africa, South Sudan, Spain, Sri Lanka, Sudan, Suriname, Swaziland, Sweden, Switzerland, Syria, Tajikistan, Tanzania, Thailand,
Timor-Leste, Togo, Tonga, Trinidad and Tobago, Tunisia, Turkey, Turkmenistan, Uganda, Ukraine, UAE, UK, US, Uruguay, Uzbekistan
Vanuatu, Venezuela, Vetnam, Yemen, Zambia, Zimbabwe, Palestine Liberation Organization
observers—(3) Cyprus, Eritrea, and Tuvalu
international Finance Corporation (IFC)
established—25 May 1955; effective—24 July 1956
aim—to support private enterprise in international economic development; a UN specialized agency and IBRD affiliate
members—(183) includes all UN member countries except Andorra, Brunei, Cuba, North Korea, Liechtenstein, Monaco, Nauru, Saint
Vincent and the Grenadines, San Marino, Tuvalu; plus Kosovo
International Fund for Agricultural Development (IFAD)
established—November 1974
aim—to promote agricultural development; a UN specialized agency
members—(168) s''o e .
List A—(23 industrialized aid contributors) Austria, Belgium, Canada, Denmark, Finland, France, Germany, Greece, Hungary, Iceland,
Ireland, Italy, Japan, Luxembourg, Netherlands, NZ, Norway, Portugal, Spain, Sweden, Switzerland, UK, US j
List B—(12 petroleum-exporting aid contributors) Algeria, Gabon, Indonesia, Iran, Iraq, Kuwait, Libya, Nigeria, Qatar, Saudi Arabia,
UAE, Venezuela P , 5 : l
List C—(133 aid recipients) Afghanistan, Albania, Angola, Antigua and Barbuda, Argentina, Armenia, Azerbaijan, The Bahamas,
Bangladesh, Barbados, Belize, Benin, Bhutan, Bolivia, Bosnia and Herzegovina, Botswana, Brazil, Burkina Faso, Burma, Burundi,
Cambodia, Cameroon, Cape Verde, Central African Republic, Chad, Chile, China, Colombia, Comoros, Democratic Republic of
the Congo, Republic of the Congo, Cook Islands, Costa Rica, Cote d''Ivoire, Croatia, Cuba, Cyprus, Djibouti, Dominica, Dominican
Republic, Ecuador, Egypt, El Salvador, Equatorial Guinea, Eritrea, Ethiopia, Fiji, The Gambia, Georgia, Ghana, Grenada, Guatemala,
Guinea, Guinea-Bissau, Guyana, Haiti, Honduras, India, Israel, Jamaica, Jordan, Kazakhstan, Kenya, Kiribati, North Korea, South
Korea, Kyrgyzstan, Laos, Lebanon, Lesotho, Liberia, Macedonia, Madagascar, Malawi, Malaysia, Maldives, Mali, Malta, Marshall Islands,
Mauritania, Mauritius, Mexico, Moldova, Mongolia, Morocco, Mozambique, Namibia, Nepal, Nicaragua, Niger, Niue, Oman, Pakistan,
Panama, Papua New Guinea, Paraguay, Peru, Philippines, Romania, Rwanda, Saint Kitts and Nevis, Saint Lucia, Saint Vincent and the
Grenadines, Samoa, Sao Tome and Principe, Senegal, Seychelles, Sierra Leone, Solomon Islands, Somalia, South Africa, South Sudan,
Sri Lanka, Sudan, Suriname, Swaziland, Syria, Tajikistan, Tanzania, Thailand, Timor-Leste, Togo, Tonga, Trinidad and Tobago, Tunisia,
Turkey, Uganda, Uruguay, Uzbekistan, Vietnam, Yemen, Zambia, Zimbabwe
International Hydrographic Organization (IHO)
note—name changed from International Hydrographic Bureau on 22 September 1970
established—June 1919; effective—June 1921 - ;
aim—to train hydrographic surveyors and nautical cartographers to achieve standardization in nautical charts and electronic chart displays;
to provide advice on nautical cartography and hydrography; to develop the sciences in the field of hydrography and techniques used for
descriptive oceanography
members—(81) Algeria, Argentina, Australia, Bahrain, Bangladesh, Belgium, Brazil, Burma, Cameroon, Canada, Chile, China (including
Hong Kong and Macau), Colombia, Democratic Republic of the Congo, Croatia, Cuba, Cyprus, Denmark, Dominican Republic, Ecuador,
Egypt, Estonia, Fiji, Finland, France, Germany, Greece, Guatemala, Iceland, India, Indonesia, Iran, Ireland, Italy, Jamaica, Japan, North
Korea, South Korea, Kuwait, Latvia, Malaysia, Mauritius, Mexico, Monaco, Morocco, Mozambique, Netherlands, NZ, Nigeria, Norway,
Oman, Pakistan, Papua New Guinea, Peru, Philippines, Poland, Portugal, Qatar, Romania, Russia, Saudi Arabia, Serbia, Singapore,
Slovenia, South Africa, Spain, Sri Lanka, Suriname, Sweden, Syria, Thailand, Tonga, Trinidad and Tobago, Tunisia, Turkey, Ukraine, UAE,
UK, US, Uruguay, Venezuela; note—members approved but waiting for Instrument of Accession: Bulgaria, Mauritania, Montenegro, Sierra
Leone
International Labor Organization (ILO)
established—28 June 1919 set up as part of Treaty of Versailles; 11 April 1919 became operative; 14 December 1946 affiliated with the UN
aim—to deal with world labor issues; a UN specialized agency
members—(185) includes all UN member countries except Andorra, Bhutan, North Korea, Liechtenstein, Federated States of Micronesia,
Monaco, Nauru, Tonga; note—includes the following dependencies: Netherlands (Aruba, Curacao, Sint Maarten)
International Maritime Organization (IMO)
note—name changed from Intergovernmental Maritime Consultative Organization (IMCO) on 22 May 1982
established —6 March 1948 set up as the Inter-Governmental Maritime Consultative Organization; effective—1? March 1958
aim—to deal with international maritime affairs; a UN specialized agency
members—(170) includes all UN member countries except Afghanistan, Andorra, Armenia, Belarus, Bhutan, Botswana, Burkina Faso,
Burundi, Central African Republic, Chad, Kyrgyzstan, Laos, Lesotho, Liechtenstein, Mali, Federated States of Micronesia, Nauru, Niger,
Rwanda; South Sudan, Swaziland, Tajikistan, Uzbekistan, Zambia; and Cook Islands
associate members—(3) Faroe Islands, Hong Kong, Macau
International Mobile Satellite Organization (IMSO)
established—15 April 1999
dim—acts as watchdog over Inmarsat (International Maritime Satellite Organization), a private company, to make sure it follows ICAO
standards and recommended practices; plays an active role in the development of international telecommunications policies
members—(97) Algeria, Antigua and Barbuda, Argentina, Australia, The Bahamas, Bahrain, Bangladesh, Belarus, Belgium, Bosnia and
Herzegovina, Brazil, Brunei, Bulgaria, Cameroon, Canada, Chile, China, Colombia, Comoros, Cook Islands, Costa Rica, Croatia, Cuba,
Cyprus, Czech Republic, Denmark, Egypt, Finland, France, Gabon, Germany, Ghana, Greece, Hungary, Iceland, India, Indonesia, lran,
Iraq, Israel, Italy, Japan, Kenya, South Korea, Kuwait, Latvia, Lebanon, Liberia, Libya, Malaysia, Malta, Marshall Islands, Mauritius,
Mexico, Monaco, Mongolia, Montenegro, Morocco, Mozambique, Netherlands, NZ, Nigeria, Norway, Oman, Pakistan, Palau, Panama,
841
THE CIA WORLD FACTBOOK
Peru, Philippines, Poland, Portugal, Qatar, Romania, Russia, Saudi Arabia, Senegal, Serbia, Singapore, Slovakia, South Africa, Spain,
Sri Lanka, Sweden, Switzerland, Tanzania, Thailand, Tonga, Tunisia, Turkey, Ukraine, UAE, UK, US, Vanuatu, Venezuela, Vietnam,
Armenia, Azerbaijan, Belarus,
Estonia, Georgia, Kazakh-
stan, Kyrgyzstan, Latvia,
Lithuania, Moldova, Russia,
Tajikistan, Turkmenistan,
Ukraine, Uzbekistan','adfb9fb9b28f35141e252a045d3d0a55dfcf09a59309e82a2acb2bc851a32ec9','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('82aecd135196fd5ed6fb5335645b13b861da988957d3b4ed027fd26ab0e0eabc',2025,'YE','Yemen','environment',1734,'International Monetary Fund (IMF)
established—22 July 1944; effective—27 December 1945
aim—to promote world monetary stability and economic development; a UN specialized agency
members—(188) includes all UN member countries except Andorra, Cuba, North Korea, Liechtenstein, Monaco, Nauru; plus Kosovo;
note—includes the following dependencies or areas of special interest: China (Hong Kong and Macau), Netherlands (Aruba)
International Olympic Committee (10C)
established—23 June 1894
aim—to promote the Olympic ideals and administer the Olympic games: 2012 Summer Olympics in London, UK; 2014 Winter Olympics
in Sochi, Russia
National Olympic Committees—(204 and the Palestine Liberation Organization) Afghanistan, Albania, Algeria, American Samoa,
Andorra, Angola, Antigua and Barbuda, Argentina, Armenia, Aruba, Australia, Austria, Azerbaijan, The Bahamas, Bahrain, Bangladesh,
Barbados, Belarus, Belgium, Belize, Benin, Bermuda, Bhutan, Bolivia, Bosnia and Herzegovina, Botswana, Brazil, British Virgin Islands,
Brunei, Bulgaria, Burkina Faso, Burma, Burundi, Cambodia, Cameroon, Canada, Cape Verde, Cayman Islands, Central African Republic,
Chad, Chile, China, Colombia, Comoros, Democratic Republic of the Congo, Republic of the Congo, Cook Islands, Costa Rica, Cote
d''Ivoire, Croatia, Cuba, Cyprus, Czech Republic, Denmark, Djibouti, Dominica, Dominican Republic, Ecuador, Egypt, El Salvador, Equa-
torial Guinea, Eritrea, Estonia, Ethiopia, Fiji, Finland, France, Gabon, The Gambia, Georgia, Germany, Ghana, Greece, Grenada, Guam,
Guatemala, Guinea, Guinea-Bissau, Guyana, Haiti, Honduras, Hong Kong, Hungary, Iceland, India, Indonesia, Iran, Iraq, Ireland, Israel,
Italy, Jamaica, Japan, Jordan, Kazakhstan, Kenya, Kiribati, North Korea, South Korea, Kuwait, Kyrgyzstan, Laos, Latvia, Lebanon, Leso-
tho, Liberia, Libya, Liechtenstein, Lithuania, Luxembourg, Macedonia, Madagascar, Malawi, Malaysia, Maldives, Mali, Malta, Marshall
Islands, Mauritania, Mauritius, Mexico, Federated States of Micronesia, Moldova, Monaco, Mongolia, Montenegro, Morocco, Mozam-
bique, Namibia, Nauru, Nepal, Netherlands, NZ, Nicaragua, Niger, Nigeria, Norway, Oman, Pakistan, Palau, Panama, Papua New Guinea,
Paraguay, Peru, Philippines, Poland, Portugal, Puerto Rico, Qatar, Romania, Russia, Rwanda, Saint Kitts and Nevis, Saint Lucia, Saint
Vincent and the Grenadines, Samoa, San Marino, Sao Tome and Principe, Saudi Arabia, Senegal, Serbia, Seychelles, Sierra Leone, Sin-
gapore, Slovakia, Slovenia, Solomon Islands, Somalia, South Africa, Spain, Sri Lanka, Sudan, Suriname, Swaziland, Sweden, Switzerland,
Syria, Taiwan, Tajikistan, Tanzania, Thailand, Timor-Leste, Togo, Tonga, Trinidad and Tobago, Tunisia, Turkey, Turkmenistan, Tuvalu,
Uganda, Ukraine, UAE, UK, US, Uruguay, Uzbekistan, Vanuatu, Venezuela, Vietnam, Virgin Islands, Yemen, Zambia, Zimbabwe, Pales-
tine Liberation Organization 3
International Organization for Migration (IOM)
note—established as Provisional Intergovernmental Committee for the Movement of Migrants from Europe; renamed Intergovernmen-
tal Committee for European Migration (ICEM) on 15 November 1952; renamed Intergovernmenta! Committee for Migration (ICM) in
November 1980; current name adopted 14 November 1989 ee e í
established—5 December 1951. > z d
aim—to facilitate orderly international emigration and immigration
members—(149) Afghanistan, Albania, Algeria, Angola, Antigua and Barbuda, Argentina, Armenia, Australia, Austria, Azerbaijan,
The Bahamas, Bangladesh, Belarus, Belgium, Belize, Benin, Bolivia, Bosnia and Herzegovina, Botswana, Brazil, Bulgaria, Burkina Faso,
Burma, Burundi, Cambodia, Cameroon, Canada, Cape Verde, Central African Republic, Chad, Chile, Colombia, Comoros, Democratic
Republic of the Congo, Republic of the Congo, Costa Rica, Cote d''Ivoire, Croatia, Cyprus, Czech Republic, Denmark, Djibouti, Dominican
Republic, Ecuador, Egypt, El Salvador, Estonia, Ethiopia, Finland, France, Gabon, The Gambia, Georgia, Germany, Ghana, Greece,
Guatemala, Guinea, Guinea-Bissau, Guyana, Haiti, Holy See, Honduras, Hungary, India, Iran, Ireland, Israel, Italy, Jamaica, Japan, Jordan,
Kazakhstan, Kenya, South Korea, Kyrgyzstan, Latvia, Lesotho, Liberia, Libya, Lithuania, Luxembourg, Madagascar, Maldives, Mali, Malta,
Mauritania, Mauritius, Mexico, Federation of Micronesia, Moldova, Mongolia, Montenegro, Morocco, Mozambique, Namibia, Nauru,
Nepal, Netherlands, NZ, Nicaragua, Niger, Nigeria, Norway, Pakistan, Panama, Papua New Guinea, Paraguay, Peru, Philippines, Poland,
Portugal, Romania, Rwanda, Saint Vincent and the Grenadines, Senegal, Serbia, Seychelles, Sierra Leone, Slovakia, Slovenia, Somalia,
South Africa, South Sudan, Spain, Sri Lanka, Sudan, Swaziland, Sweden, Switzerland, Tajikistan, Tanzania, Thailand, Timor-Leste, Togo,
Trinidad and Tobago, Tunisia, Turkey, Uganda, Ukraine, UK, US, Uruguay, Vanuatu, Venezuela, Vietnam, Yemen, Zambia, Zimbabwe
observers—(12) Bahrain, Bhutan, China, Cuba, Indonesia, Macedonia, Qatar, Russia, San Marino, Sao Tome and Principe, Saudi Arabia,
Turkmenistan , ge ‘
me
International Organization for Standardization (ISO)
established—February 1947
aim—to promote the development of international standards with a view to facilitating international exchange of goods and services and
to developing cooperation in the sphere of intellectual, scientific, technological and economic activity
members—(11] national standards organizations) Algeria, Argentina, Armenia, Australia, Austria, Azerbaijan, Bahrain, Bangladesh,
Barbados, Belarus, Belgium, Bosnia and Herzegovina, Botswana, Brazil, Bulgaria, Cameroon, Canada, Chile, China, Colombia, Democratic
Republic of the Congo, Costa Rica, Cote d''Ivoire, Croatia, Cuba, Cyprus, Czech Republic, Denmark, Ecuador, Egypt, Estonia, Ethiopia,
Fiji, Finland, France, Gabon, Germany, Ghana, Greece, Hungary, leeland, India, Indonesia, Iran, Iraq, Ireland, Israel, Italy, Jamaica, Japan,
Jordan, Kazakhstan, Kenya, North Korea, South Korea, Kuwait, Lebanon, Libya, Lithuania, Luxembourg, Macedonia, Malaysia, Mali,
Malta, Mauritius, Mexico, Mongolia, Morocco, Namibia, Netherlands, NZ, Nigeria, Norway, Oman, Pakistan, Panama, Peru, Philippines,
Poland, Portugal, Qatar, Romania, Russia, Saint Lucia, Saudi Arabia, Senegal, Serbia, Singapore, Slovakia, Slovenia, South Africa, Spain,
Sri Lanka, Sudan, Sweden, Switzerland, Syria, Tanzania, Thailand, Trinidad and Tobago, Tunisia, Turkey, Ukraine, UAE, UK, US, Uruguay,
Uzbekistan, Vietnam, Yemen, Zimbabwe - R i j .
correspondent members—(48 plus the Palestine Liberation Organization) Afghanistan, Albania, Angola, Benin, Bhutan, Bolivia, Brunei,
` Burkina Faso, Burma, Burundi, Cambodia, Republic of the Congo, Dominica, Dominican Republic, El Salvador, Eritrea, Gabon, The
Gambia, Georgia, Guatemala, Guinea, Guyana, Hong Kong, Kyrgyzstan, Latvia, Lesotho, Liberia, Macau, Madagascar, Malawi, Mauritania,
Moldova, Montenegro, Mozambique, Nepal, Nicaragua, Niger, Papua New Guinea, Paraguay, Rwanda, Seychelles, Sierra Leone, Suriname,
Swaziland, Tajikistan, Togo, Turkmenistan, Uganda, Zambia, Palestine Liberation Organization
subscriber members—(4) Antigua and Barbuda, Honduras, Laos, Saint Vincent and the Grenadines
842
INTERNATIONAL ORGANIZATIONS AND GROUPS
Intefnational Organization of the French-speaking World (OIF)
note—name changed from Agency of Cultural and Technical Cooperation (ACCT) in 1997; also known as Organisation Internationale
de la Francophonie st : i
established—20 March 1970
aim—founded around a common language to promote and spread the cultures of its members and to reinforce cultural and technical coop-
eratiori between them = i
members—(56) Albania, Andorra, Armenia, Belgium, Benin, Bulgaria, Burkina Faso, Burundi, Cambodia, Cameroon, Canada, Canada—
New Brunswick, Canada—Quebec, Cape Verde, Central African Republic, Chad, Comoros, Democratic Republic of Congo, Republic
of Congo, Cote d''Ivoire, Cyprus, Djibouti, Dominica, Egypt, Equatorial Guinea, France, French Community of Belgium, Gabon, Ghana,
Greece, Guinea, Guinea-Bissau, Haiti, Laos, Lebanon, Luxembourg, Macedonia, Madagascar, Mali, Mauritania, Mauritius, Moldova,
Monaco, Morocco, Niger, Romania, Rwanda, Saint Lucia, Sao Tome and Principe, Senegal, Seychelles, Switzerland, Togo, Tunisia,
Vanuatu, Vietnam
observers—(19) Austria, Bosnia and Herzegovina, Croatia, Czech Republic, Dominican Republic, Estonia, Georgia, Hungary, Latvia,
Lithuania, Montenegro, Mozambique, Poland, Serbia, Slovakia, Slovenia, Thailand, Ukraine, UAE
International Red Cross and Red Crescent Movement (ICRM)
. established-—1928 ere
aim—to promote worldwide humanitarian aid through the International Committee of the Red Gross (ICRC) in wartime, and Interna-
tional Federation of Red Cross and Red Crescent Societies (IFRCS; formerly League of Red Cross and Red Crescent Societies or LORCS)
in peacetime
National Societies—(187 countries and the Palestine Liberation Organization); note—same as membership for International Federation
of Red Cross and Red Crescent Societies (IFRCS)
International Telecommunication Satellite Organization (ITSO)
established—August 1964
aim—to act as a watchdog over Intelsat, Ltd., a private company, to make sure it provides on a global and non-discriminatory basis public
telecommunication services
members—(150) Afghanistan, Algeria, Angola, Argentina, Armenia, Australia, Austria, Azerbaijan, The Bahamas, Bahrain, Bangladesh,
Barbados, Belgium, Benin, Bhutan, Bolivia, Bosnia and Herzegovina, Botswana, Brazil, Brunei, Bulgaria, Burkina Faso, Cameroon, Canada,
Cape Verde, Central African Republic, Chad, Chile, China, Colombia, Comoros, Democratic Republic of the Congo, Republic of the
Congo, Costa Rica, Cote d’Ivoire, Croatia, Cuba, Cyprus, Czech Republic, Denmark, Dominican Republic, Ecuador, Egypt, El Salvador,
Equatorial Guinea, Estonia, Ethiopia, Fiji, Finland, France, Gabon, The Gambia, Georgia, Germany, Ghana, Greece, Guatemala, Guinea,
Guinea-Bissau, Haiti, Holy See, Honduras, Hungary, Iceland, India, Indonesia, Iran, Iraq, Ireland, Israel, Italy, Jamaica, Japan, Jordan,
Kazakhstan, Kenya, North Korea, South Korea, Kuwait, Kyrgyzstan, Lebanon, Libya, Liechtenstein, Luxembourg, Madagascar, Malawi,
Malaysia, Mali, Malta, Mauritania, Mauritius, Mexico, the Federated States of Micronesia, Monaco, Mongolia, Montenegro, Morocco,
Mozambique, Namibia, Nepal, Netherlands, NZ, Nicaragua, Niger, Nigeria, Norway, Oman, Pakistan, Panama, Papua New Guinea,
Paraguay, Peru, Philippines, Poland, Portugal, Qatar, Romania, Russia, Rwanda, Saudi Arabia, Senegal, Serbia, Singapore, Somalia, South
Africa, Spain, Sri Lanka, Sudan, Swaziland, Sweden, Switzerland, Syria, Tajikistan, Tanzania, Thailand, Togo, Trinidad and Tobago, Tunisia,
Turkey, Uganda, UAE, UK, US, Uruguay, Uzbekistan, Venezuela, Vietnam, Yemen, Zambia, Zimbabwe
International Telecommunication Union (ITU)
'' established—17 May 1865 set up as the International Telegraph Union; 9 December 1932 adopted present name; effective—1 January
1934; affiliated with the UN—15 November 1947
aim—to deal with world telecommunications issues; a UN specialized agency
members—(193) includes all UN member countries except Palau (192 total); plus Holy See
international Trade Union Confederation (ITUC)
note—its predecessors were the International Confederation of Free Trade Unions (ICFTU) and the World Confederation of Labor (WCL)
established—3 November 2006
aim—to promote the trade union movement
members—(309 affiliated organizations in the following 152 countries and the Palestine Liberation Organization as of October 2011) Alba-
nia, Algeria, Angola, Antigua and Barbuda, Aruba, Argentina, Australia, Austria, Azerbaijan, Bahrain, Bangladesh, Barbados, Belarus, Bel-
gium, Benin, Bermuda, Bonaire, Bosnia and Herzegovina, Botswana, Brazil, Bulgaria, Burkina Faso, Burma, Burundi, Cameroon, Canada,
Cape Verde, Central African Republic, Comoros, Chad, Chile, Colombia, Democratic Republic of the Congo, Republic of the Congo,
Cook Islands, Costa Rica, Cote d''Ivoire, Croatia, Curacao, Cyprus, Czech Republic, Denmark, Djibouti, Dominica, Dominican Republic,
Ecuador, El Salvador, Eritrea, Estonia, Ethiopia, Fiji, Finland, France, French Polynesia, Gabon, The Gambia, Georgia, Germany, Ghana,
Greece, Grenada, Guatemala, Guinea, Guinea-Bissau, Haiti, Holy See, Honduras, Hong Kong, Hungary, Iceland, India, Indonesia, Ireland,
Israel, Italy, Japan, Jordan, Kenya, Kiribati, South Korea, Kosovo, Kuwait, Latvia, Liberia, Liechtenstein, Lithuania, Luxembourg, Macedo-
nia, Madagascar, Malawi, Malaysia, Mali, Malta, Mauritania, Mauritius, Mexico, Moldova, Mongolia, Montenegro, Morocco, Mozambique,
Namibia, Nepal, Netherlands, NZ, Nicaragua, Niger, Nigeria, Norway, Pakistan, Panama, Paraguay, Peru, Philippines, Poland, Portugal,
Romania, Russia, Rwanda, Saint Lucia, Samoa, San Marino, Sao Tome and Principe, Senegal, Serbia, Sierra Leone, Singapore, Slovakia,
South Africa, Spain, Sri Lanka, Suriname, Swaziland, Sweden, Switzerland, Taiwan, Tanzania, Thailand, Togo, Tonga, Trinidad and Tobago,
Tunisia, Turkey, Uganda, Ukraine, UK, US, Vanuatu, Venezuela, Yemen, Zambia, Zimbabwe, and the Palestine Liberation Organization
Islamic Development Bank (IDB)
established—15 December 1973 by declaration of intent; effective—12 August 1974
im— ote Islamic economic aid and social development l ; "
te acme plus the Palestine Liberation Organization) Afghanistan, Albania, Algeria, Azerbaijan, Bahrain, Bangladesh, Benin,
Brunei, Burkina Faso, Cameroon, Chad, Comoros, Cote d''Ivoire, Djibouti, Egypt, Gabon, The Gambia, Guinea, Guinea-Bissau, Indonesia,
Iran, Iraq, Jordan, Kazakhstan, Kuwait, Kyrgyzstan, Lebanon, Libya, Malaysia, Maldives, Mali, Mauritania, Morocco, Mozambique, Niger,
Nigeria, Oman, Pakistan, Qatar, Saudi Arabia, Senegal, Sierra Leone, Somalia, Sudan, Suriname, Syria, Tajikistan, Togo, Tunisia, Turkey,
Turkmenistan, Uganda, UAE, Uzbekistan, Yemen, Palestine Liberation Organization
+
843
THE CIA WORLD FACTBOOK
Latin American and Caribbean Economic System (LAES)
note—also known as Sistema Economico Latinoamericana (SELA)
established—17 October 1975
aim—to promote economic and social development through regional cooperation s
members—(28) Argentina, the Bahamas, Barbados, Belize, Bolivia, Brazil, Chile, Colombia, Costa Rica, Cuba, Dominican Republic,
Ecuador, El Salvador, Grenada, Guatemala, Guyana, Haiti, Honduras, Jamaica, Mexico, Nicaragua, Panama, Paraguay, Peru, Suriname,
Trinidad and Tobago, Uruguay, Venezuela
Latin American Integration Association (LAIA)
note—also known as Asociacion Latinoamericana de Integracion (ALADI)
established—12 August 1980; effective—18 March 1981
aim—to promote freer regional trade
members—(14) Argentina, Bolivia, Brazil, Chile, Colombia, Cuba, Ecuador, Mexico, Nicaragua, Panama, Paraguay, Peru, Uruguay,
Venezuela
observers—(29) China, Corporacion Andina de Fomento, Costa Rica, Dominican Republic, EC, El Salvador, Guatemala, Honduras, Inter-
American Development Bank, Inter-American Institute for Cooperation on Agriculture, Italy, Japan, South Korea, Latin America Eco-
nomic System, Nicaragua, Organizacion Panamericana de la Salud, Organizacion Mundial de la Salud, Organization of American States,
Pakistan, Portugal, Romania, Russia, San Marino, Secretaria General Iberoamericana, Spain, Switzerland, Ukraine, United Nations Devel-
opment Program, United Nations Economic Commission for Latin America and the Caribbean
League of Arab States (LAS)
note—also known as Arab League (AL)
established—22 March 1945
aim—aim—to promote economic, social, political, and military cooperation
members—(20 plus the Palestine Liberation Organization) Algeria, Bahrain, Comoros, Djibouti, Egypt, Iraq, Jordan, Kuwait, Lebanon,
Libya, Mauritania, Morocco, Oman, Qatar, Saudi Arabia, Somalia, Sudan, Tunisia, UAE, Yemen, Palestine Liberation Organization
observers—(4) Brazil, Eritrea, India, Venezuela
least developed countries (LLDCs)
that subgroup of the less developed countries (LDCs) initially identified by the UN General Assembly in 1971 as having no significant eco-
nomic growth, per capita GDPs normally less than $1,000, and low literacy rates; also known as the undeveloped countries; the 44 LLDCs
are: Afghanistan, Bangladesh, Benin, Bhutan, Burkina Faso, Burma, Burundi, Cambodia, Cameroon, Central African Republic, Chad,
Comoros, Democratic Republic of the Congo, Cote d''Ivoire, Equatorial Guinea, Eritrea, Ethiopia, The Gambia, Ghana, Guinea, Guinea-
Bissau, Haiti, Kenya, Lesotho, Liberia, Malawi, Mali, Moldova, Mozambique, Nepal, Niger, Rwanda, Sao Tome and Principe, Senegal, Sierra
Leone, Somalia, Sudan, Tajikistan, Tanzania, Togo, Tokelau, Tuvalu, Uganda, Zambia
less developed countries (LDCs) - . i 1
the bottom group in the hierarchy of developed countries (DCs), former USSR/Eastern Europe (former USSR/EE), and less developed
countries (LDCs); mainly countries and dependent areas with low levels of output, living standards, and technology; per capita GDPs
are generally below $5,000 and often less than $1,500; however, the group also includes a number of countries with high per capita
incomes, areas of advanced technology, and rapid rates of growth; includes the advanced developing countries, developing countries,
Four Dragons (Four Tigers), least developed countries (LLDCs), low-income countries, middle-income countries, newly industrial-
izing economies (NIEs), the South, Third World, underdeveloped countries, undeveloped countries; the 172 LDCs are: Afghanistan,
Algeria, American Samoa, Angola, Anguilla, Antigua and Barbuda, Argentina, Aruba, The Bahamas, Bahrain, Bangladesh, Barbados,
Belize, Benin, Bhutan, Bolivia, Botswana, Brazil, British Virgin Islands, Brunei, Burkina Faso, Burma, Burundi, Cambodia, Cam-
eroon, Cape Verde, Cayman Islands, Central African Republic, Chad, Chile, China, Christmas Island, Cocos Islands, Colombia,
Comoros, Democratic Republic of the Congo, Republic of the Congo, Cook Islands, Costa Rica, Cote d''Ivoire, Cuba, Cyprus, Djibouti,
Dominica, Dominican Republic, Ecuador, Egypt, El Salvador, Equatorial Guinea, Eritrea, Ethiopia, Falkland Islands, Fiji, French
Guiana, French Polynesia, Gabon, The Gambia, Gaza Strip, Ghana, Gibraltar, Greenland, Grenada, Guadeloupe, Guam, Guatemala,
Guernsey, Guinea, Guinea-Bissau, Guyana, Haiti, Honduras, Hong Kong, India, Indonesia, Iran, Iraq, Isle of Man, Jamaica, Jersey,
Jordan, Kenya, Kiribati, North Korea, South Korea, Kuwait, Laos, Lebanon, Lesotho, Liberia, Libya, Macau, Madagascar, Malawi,
Malaysia, Maldives, Mali, Marshall Islands, Martinique, Mauritania, Mauritius, Mayotte, Federated States of Micronesia, Mongolia,
Montserrat, Morocco, Mozambique, Namibia, Nauru, Nepal, Netherlands Antilles, New Caledonia, Nicaragua, Niger, Nigeria, Niue,
Norfolk Island, Northern Mariana Islands, Oman, Palau, Pakistan, Panama, Papua New Guinea, Paraguay, Peru, Philippines, Pitcairn
Islands, Puerto Rico, Qatar, Reunion, Rwanda, Saint Helena, Ascension, and Tristan da Cunha, Saint Kitts and Nevis, Saint Lucia,
Saint Pierre and Miquelon, Saint Vincent and the Grenadines, Samoa, Sao Tome and Principe, Saudi Arabia, Senegal, Seychelles,
Sierra Leone, Singapore, Solomon Islands, Somalia, Sri Lanka, Sudan, Suriname, Swaziland, Syria, Taiwan, Tanzania, Thailand,
Togo, Tokelau, Tonga, Trinidad and Tobago, Tunisia, Turks and Caicos Islands, Tuvalu, UAE, Uganda, Uruguay, Vanuatu, Venezuela,
Vietnam, Virgin Islands, Wallis and Futuna, West Bank, Western Sahara, Yemen, Zambia, Zimbabwe; note—similar to the new Inter-
national Monetary Fund (IMF) term “developing countries” which adds Malta, Mexico, South Africa, and Turkey but omits in its
recently published statistics American Samoa, Anguilla, British Virgin Islands, Brunei, Cayman Islands, Christmas Island, Cocos
Islands, Cook Islands, Cuba, Eritrea, Falkland Islands, French Guiana, French Polynesia, Gaza Strip, Gibraltar, Greenland, Grenada,
Guadeloupe, Guam, Guernsey, Isle of Man, Jersey, North Korea, Macau, Martinique, Mayotte, Montserrat, Nauru, New Caledonia,
Niue, Norfolk Island, Northern Mariana Islands, Palau, Pitcairn Islands, Puerto Rico, Reunion, Saint Helena, Ascension, and Tristan
da Cunha, Saint Pierre and Miquelon, Tokelau, Tonga, Turks and Caicos Islands, Tuvalu, Virgin Islands, Wallis and Futuna, West
_ Bank, Western Sahara
low-income countries .
another term for those less developed countries with below -average per capita GDPs; see less developed countries (LDCs)
middle-income countries
another term for those less developed countries with above-average per capita GDPs; see less developed countries (LDCs)
844
INTERNATIONAL ORGANIZATIONS AND GROUPS
Multilateral Investment Guarantee Agency (MIGA)
established—12 April 1988
aim—encourages flow of foreign direct investment among member countries by offering investment insurance, consultation, and negotia-
tion on conditions for foreign investment and technical assistance; a UN spécialized agency
members-(I77) includes all UN member countries except Andorra, Bhutan, Brunei, Burma, Comoros, Cuba, Kiribati, North Korea,
Liechtenstein, Marshall Islands, Monaco, Nauru, San Marino, Sao Tome and Principe, Somalia, Tonga, Tuvalu; plus Kosovo
Near Abroad |
Russian term for the 14 non-Russian successor states of the USSR, in which 25 million ethnic Russians live and in which Moscow has
expressed a strong national security interest; the 14 countries are Armenia, Azerbaijan, Belarus, Estonia, Georgia, Kazakhstan, Kyrgyzstan,
Latvia, Lithuania, Moldova, Tajikistan, Turkmenistan, Ukraine, Uzbekistan
new independent states (NIS)
a term referring to all the countries of the FSU except the Baltic countries (Estonia, Latvia, Lithuania)
newly industrializing countries (NICs)
former term for the newly industrializing economies; see newly industrializing economies (NIEs)
newly industrializing economies (NIEs) ‘
that subgroup of the less developed countries (LDCs) that has experienced particularly rapid industrialization of their economies; formerly
known as the newly industrializing countries (NICs); also known as advanced developing countries; usually includes the Four Dragons
(Hong Kong, South Korea, Singapore, Taiwan), and Brazil
Nonaligned Movement (NAM)
established—i-6 September 1961 .
aim—to establish political and military cooperation apart from the traditional East or West blocs
members—(119 plus the Palestine Liberation Organization) Afghanistan, Algeria, Angola, Antigua and Barbuda, Azerbaijan, The
Bahamas, Bahrain, Bangladesh, Barbados, Belarus, Belize, Benin, Bhutan, Bolivia, Botswana, Brunei, Burkina Faso, Burma, Burundi, Cam-
bodia, Cameroon, Cape Verde, Central African Republic, Chad, Chile, Colombia, Comoros, Democratic Republic of the Congo, Republic
of the Congo, Cote d''Ivoire, Cuba, Djibouti, Dominica, Dominican Republic, Ecuador, Egypt, Equatorial Guinea, Eritrea, Ethiopia, Fiji,
Gabon, The Gambia, Ghana, Grenada, Guatemala, Guinea, Guinea-Bissau, Guyana, Haiti, Honduras, India, Indonesia, Iran, Iraq, Jamaica,
Jordan, Kenya, North Korea, Kuwait, Laos, Lebanon, Lesotho, Liberia, Libya, Madagascar, Malawi, Malaysia, Maldives, Mali, Mauritania,
Mauritius, Mongolia, Morocco, Mozambique, Namibia, Nepal, Nicaragua, Niger, Nigeria, Oman, Pakistan, Panama, Papua New Guinea,
Peru, Philippines, Qatar, Rwanda, Saint Kitts and Nevis, Saint Lucia, Saint Vincent and the Grenadines, Sao Tome and Principe, Saudi
Arabia, Senegal, Seychelles, Sierra Leone, Singapore, Somalia, South Africa, Sri Lanka, Sudan, Suriname, Swaziland, Syria, Tanzania,
Thailand, Timor-Leste, Togo, Trinidad and Tobago, Tunisia, Turkmenistan, Uganda, UAE, Uzbekistan, Vanuatu, Venezuela, Vietnam,
Yemen, Zambia, Zimbabwe, Palestine Liberation Organization f :
observers—(17) Argentina, Armenia, Bosnia and Herzegovina, Brazil, China, Costa Rica, Croatia, El Salvador, Kazakhstan, Kyrgyzstan,
Mexico, Montenegro, Paraguay, Serbia, Tajikistan, Ukraine, Uruguay
Nordic Council (NC)
e','8fed44b5cb90ff0bb89dda90b290c2816c715ef9b02c4f1ce329f8743e3a8912','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('06e49aa7b5475ce2be8f8e1e6abdb2df2444bf6dfed4386636aeb4041a13e0fe',2025,'YE','Yemen','environment',1735,'stablished—16 March 1952; éffective—12 February 1953
aim—to promote regional economic, cultural, and environmental cooperation
members—(5) Denmark (including Faroe Islands and Greenland), Finland (including Aland Islands), Iceland, Norway, Sweden
observers—(6) Estonia, Latvia, Lithuania, and the Sami (Lapp) local parliaments of Finland, Norway, and Sweden
Nordic Investment Bank (NIB)
established—4 December 1975; effective—1 June 1976
aim—to promote economic cooperation and development
members—(8) Denmark (including Farve Islands and Greenland), Estonia, Finland (including Aland Islands), Iceland, Latvia, Lithuania,
Norway, Sweden
North
a popular term for the rich industrialized countries generally located in the northern portion of the Northern Hemisphere; the counterpart
of the South; see developed countries (DCs)
North American Free Trade Agreement (NAFTA)
established—17 December 1992 |
aim—to eliminate trade barriers, promote fair competition, increase investment opportunities, provide protection of intellectual property
rights, and create procedures to settle disputes
members—(3) Canada, Mexico, US
North Atlantic Treaty Organization (NATO)
established—4 April 1949 D
aim—to promote mutual defense and cooperation l i ; l l
MEDE (28) Albania, Belgium, Bulgaria, Canada, Croatia, Czech Republic, Denmark, Estonia, France, Germany, Greece, Hungary,
Iceland, Italy, Latvia, Lithuania, Luxembourg, Netherlands, Norway, Poland, Portugal, Romania, Slovakia, Slovenia, Spain, Turkey, UK, US
Nuclear Energy Agency (NEA)
note—also known as OECD Nuclear Energy Agency
established—1 February 1958
aim—to promote the peaceful uses of nuclear energy; associated with OECD
members—(30) Australia, Austria, Belgium, Canada, Czech Republic, Denmark, Finland, France, Germany, Greece, Hungary, Iceland,
Ireland, Italy, Japan, South Korea, Luxembourg, Mexico, Netherlands, Norway, Poland, Portugal, Slovakia, Slovenia, Spain, Sweden, Swit-
zerland, Turkey, UK, US o i : jj “
ae
THE CIA WORLD FACTBOOK
Nuclear Suppliers Group (NSG)
note—also known as the London Suppliers Group or the London Group
established—1974; effective—1975 s . i l
aim—to establish guidelines for exports of nuclear materials, processing equipment for uranium enrichment, and technical information to
countries of proliferation concern and regions of conflict and instability ` : a i
members—(46) Argentina, Australia, Austria, Belarus, Belgium, Brazil, Bulgaria, Canada, China, Croatia, Cyprus, Czech Republic,
Denmark, Estonia, Finland, France, Germany, Greece, Hungary, Iceland, Ireland, Italy, Japan, Kazakhstan, South Korea, Latvia, Lithuania,
Luxembourg, Malta, Netherlands, NZ, Norway, Poland, Portugal, Romania, Russia, Slovakia, Slovenia, South Africa, Spain, Sweden,
Switzerland, Turkey, Ukraine, UK, US
observer—(2) Chairman of the Zangger Committee, European Commission (a policy-planning body for the EU)
Organization for Democracy and Economic Development (GUAM)
note—acronym standing for the member countries, Georgia, Ukraine, Azerbaijan, Moldova; formerly known as GUUAM before Uzbekistan
withdrew in 5 May 2005
established—7 June 2001
aim—commits the countries to cooperation and assistance in social and economic development, the strengthening and broadening of trade
and economic relations, and the development and effective use of transport and communications, highways, and related infrastructure cross-
ing the boundaries of the member states
members—(4) Azerbaijan, Georgia, Moldova, Ukraine
Organization for Economic Cooperation and Development (OECD)
established—14 December 1960; effective—30 September 1961
aim—to promote economic cooperation and development
members—(34) Australia, Austria, Belgium, Canada, Chile, Czech Republic, Denmark, Estonia, Finland, France, Germany, Greece,
Hungary, Iceland, Ireland, Israel, Italy, Japan, South Korea, Luxembourg, Mexico, Netherlands, NZ, Norway, Poland, Portugal, Slovakia,
Slovenia, Spain, Sweden, Switzerland, Turkey, UK, US
special member—(1) EC
Organization for Security and Cooperation in Europe (OSCE)
note—formerly the Conference on Security and Cooperation in Europe (CSCE) established 3 July 1975
established—1 January 1995
aim—to foster the implementation of human rights, fundamental freedoms, democracy, and the rule of law; to act as an instrument of early
warning, conflict prevention, and crisis management; and to serve as a framework for conventional arms control and confidence building
measures
members—(57) Albania, Andorra, Armenia, Austria, Azerbaijan, Belarus, Belgium, Bosnia and Herzegovina, Bulgaria, Canada, Croatia,
Cyprus, Czech Republic, Denmark, Estonia, Finland, France, Georgia, Germany, Greece, Holy See, Hungary, Iceland, Ireland, Italy,
Kazakhstan, Kyrgyzstan, Latvia, Liechtenstein, Lithuania, Luxembourg, Macedonia, Malta, Moldova, Monaco, Mongolia, Montenegro,
Netherlands, Norway, Poland, Portugal, Romania, Russia, San Marino, Serbia, Slovakia, Slovenia, Spain, Sweden, Switzerland, Tajikistan,
Turkey, Turkmenistan, Ukraine, UK, US, Uzbekistan
partners for cooperation—(11) Afghanistan, Algeria, Australia, Egypt, Israel, Japan, Jordan, South Korea, Morocco, Thailand, Tunisia
Organization for the Prohibition of Chemical Weapons (OPCW)
established—29 April 1997
aim—to enforce the Convention on the Prohibition of the Development, Production, Stockpiling, and Use of Chemical Weapons and on
Their Destruction; to provide a forum for consultation and cooperation among the signatories of the Convention. i
members (countries that have ratified the Convention)—(188) Afghanistan, Albania, Algeria, Andorra, Antiguaʻand Barbuda,
Argentina, Armenia, Australia, Austria, Azerbaijan, The Bahamas, Bahrain, Bangladesh, Barbados, Belarus, Belgium, Belize, Benin,
Bhutan, Bolivia, Bosnia and Herzegovina, Botswana, Brazil, Brunei, Bulgaria, Burkina Faso, Burundi, Cambodia, Cameroon, Canada,
Cape Verde, Central African Republic, Chad, Chile, China, Colombia, Comoros, Democratic Republic of the Congo, Republic of the
Congo, Cook Islands, Costa Rica, Cote d''Ivoire, Croatia, Cuba, Cyprus, Czech Republic, Denmark, Dominica, Dominican Republic,
Djibouti, Ecuador, El Salvador, Equatorial Guinea, Eritrea, Estonia, Ethiopia, Fiji, Finland, France, Gabon, The Gambia, Georgia,
Germany, Ghana, Greece, Grenada, Guatemala, Guinea, Guinea-Bissau, Guyana, Haiti, Holy See, Honduras, Hungary, Iceland, India,
Indonesia, Iran, Iraq, Ireland, Italy, Jamaica, Japan, Jordan, Kazakhstan, Kenya, Kiribati, South Korea, Kuwait, Kyrgyzstan, Laos, Lat-
via, Lebanon, Lesotho, Liberia, Libya, Liechtenstein, Lithuania, Luxembourg, Macedonia, Madagascar, Malawi, Malaysia, Maldives,
Mali, Malta, Marshall Islands, Mauritania, Mauritius, Mexico, Federated States of Micronesia, Moldova, Monaco, Mongolia, Monte-
negro, Morocco, Mozambique, Namibia, Nauru, Nepal, Netherlands, NZ, Nicaragua, Niger, Nigeria, Niue, Norway, Oman, Pakistan,
Palau, Panama, Papua New Guinea, Paraguay, Peru, Philippines, Poland, Portugal, Qatar, Romania, Russia, Rwanda, Saint Kitts and
Nevis, Saint Lucia, Saint Vincent and the Grenadines, Samoa, San Marino, Sao Tome and Principe, Saudi Arabia, Senegal, Serbia,
Seychelles, Sierra Leone, Singapore, Slovakia, Slovenia, Solomon Islands, South Africa, Spain, Sri Lanka, Sudan, Suriname, Swazi-
land, Sweden, Switzerland, Tajikistan, Tanzania, Thailand, Timor-Leste, Togo, Tonga, Trinidad and Tobago, Tunisia, Turkey, Turk-
menistan, Tuvalu, Uganda, Ukraine, UAE, UK, US, Uruguay, Uzbekistan, Vanuatu, Venezuela, Vietnam, Yemen, Zambia, Zimbabwe
signatory states (countries that have signed, but not ratified, the Convention)—(2) Burma, Israel
Organization of African Unity (OAU)
see African Union
Organization of American States (OAS)
established—14 April 1890 as the International Union of American Republics; 30 April 1948 adopted present charter; effective—13
December 1951 eh
aim—to promote regional peace and security as well as economic and social development
members—(35) Antigua and Barbuda, Argentina, The Bahamas, Barbados, Belize, Bolivia, Brazil, Canada, Chile, Colombia, Costa Rica,
Cuba (suspended), Dominica, Dominican Republic, Ecuador, El Salvador, Grenada, Guatemala, Guyana, Haiti, Honduras, Jamaica, Mexico,
Nicaragua, Panama, Paraguay, Peru, Saint Kitts and Nevis, Saint Lucia, Saint Vincent and the Grenadines, Suriname, Trinidad and Tobago,
US, Uruguay, Venezuela
846
INTERNATIONAL ORGANIZATIONS AND GROUPS
observers—(68) Albania, Algeria, Angola, Armenia, Austria, Azerbaijan, Belgium, Benin, Bosnia and Herzegovina, Bulgaria, China,
Croatia, Cyprus, Czech Republic, Denmark, Egypt, Equatorial Guinea, Estonia, EU, Finland, France, Georgia, Germany, Ghana, Greece,
Holy See, Hungary, Iceland, India, Ireland, Israel, Italy, Japan, Kazakhstan, South Korea, Latvia, Lebanon, Lithuania, Luxembourg,
Macedonia, Malta, Monaco, Morocco, Netherlands, Nigeria, Norway, Pakistan, Philippines, Poland, Portugal, Qatar, Romania, Russia,
Saudi Arabia, Serbia, Slovakia, Slovenia, Spain, Sri Lanka, Sweden, Switzerland, Thailand, Tunisia, Turkey, Ukraine, UK, Vanuatu, Yemen
Organization of Arab Petroleum Exporting Countries (OAPEC)
established—9 January 1968
aim—to promote cooperation in the petroleum industry {
members—(11) Algeria, Bahrain, Egypt, Iraq, Kuwait, Libya, Qatar, Saudi Arabia, Syria, Tunisia (suspended), UAE
Organization of Eastern Caribbean States (OECS)
established—18 June 1981; effective—4 July 1981
aim—to promote political, economic, and defense cooperation
members—(9) Anguilla, Antigua and Barbuda, British Virgin Islands, Dominica, Grenada, Montserrat, Saint Kitts and Nevis, Saint Lucia,
Zaire
Indian Ocean
United States (Alaska)
Russia
Atlantic Ocean
Pacific Ocean
Iran
Indian Ocean
Montenegro, Serbia
Bolivia','2ed1644a28ffa877609c76de99bdb28629c1972406e09f30d53d06b5a37fbd42','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c88408a7ad1ab477c7ca0987c93efc532492240be4f1472af206d883187981e8',2025,'VC','Saint Vincent and the Grenadines','environment',1736,'Organization of Islamic Cooperation (OIC)
note—formerly the Organization of the Islamic Conference established—22-25 September 1969
aim—to promote Islamic solidarity in economic, social, cultural, and political affairs
members—(56 plus the Palestine Liberation Organization) Afghanistan, Albania, Algeria, Azerbaijan, Bahrain, Bangladesh, Benin, Brunei,
Burkina Faso, Cameroon, Chad, Comoros, Cote d''Ivoire, Djibouti, Egypt, Gabon, The Gambia, Guinea, Guinea-Bissau, Guyana, Indonesia,
Iran, Iraq, Jordan, Kazakhstan, Kuwait, Kyrgyzstan, Lebanon, Libya, Malaysia, Maldives, Mali, Mauritania, Morocco, Mozambique, Niger,
Nigeria, Oman, Pakistan, Qatar, Saudi Arabia, Senegal, Sierra Leone, Somalia, Sudan, Suriname, Syria, Tajikistan, Togo, Tunisia, Turkey,
Turkmenistan, Uganda, UAE, Uzbekistan, Yemen, Palestine Liberation Organization
observers—(12) AU, Bosnia and Herzegovina, Central African Republic, ECO, LAS, Moro National Liberation Front, NAM, Parliamen-
tary Union of the OIC Member States, Russia, Thailand, Turkish Muslim Community of Kibris, UN
Organization of Petroleum Exporting Countries (OPEC)
established —14 September 1960
aim—to coordinate petroleum policies 3
members—(12) Algeria, Angola, Ecuador, Iran, Iraq, Kuwait, Libya, Nigeria, Qatar, Saudi Arabia, UAE, Venezuela; note—Indonesia left
OPEC in 2008 f
Pacific Community (SPC) a
local name of the Secretariat of the Pacific Community
Pacific Isiands Forum (PIF)
note—formerly known as South Pacific Forum (SPF)
established—5 August 1971
aim—to promote regional cooperation in political matters
members—(16) Australia, Cook Islands, Fiji, Kiribati, Marshall Islands, Federated States of Micronesia, Nauru, NZ, Niue, Palau, Papua
New Guinea, Samoa, Solomon Islands, Tonga, Tuvalu, Vanuatu
associate members—(2) French Polynesia, New Caledonia
partners—(14) Canada, China, EU, France, India, Indonesia, Italy, Japan, South Korea, Malaysia, Philippines, Thailand, UK, US
observers—(11) ACP Group, American Samoa, Asia Development Bank, The Commonwealth, Commonwealth of the Northern Marianas,
Guam, Timor-Leste (special observer), Tokelau, UN, Wallis and Futuna, the World Bank
Paris Club
established—1956
aim—to provide a forum for debtor countries to negotiate rescheduling of debt service payments or loans extended by governments or
official agencies of participating countries; to help restore normal trade and project finance to debtor countries
members—(19) Australia, Austria, Belgium, Canada, Denmark, Finland, France, Germany, Ireland, Italy, Japan, Netherlands, Norway,
Russia, Spain, Sweden, Switzerland, UK, US i
aadiote members (13) Abu Dhabi, Argentina, Brazil, Israel, South Korea, Kuwait, Mexico, Morocco, NZ, Portugal, South Africa,
‘Trinidad and Tobago, Turkey
Partnership for Peace (PFP)
established—10-11 January 1994 ‘ i eae
aim—to expand and intensify political and military cooperation throughout Europe, increase stability, diminish threats to peace, and build
relationships by promoting the spirit of practical cooperation and commitment to democratic principles that underpin NATO; program
under the auspices of NATO l l i
pa ny Armenia, Austria, Azerbaijan, Belarus, Bosnia and Herzegovina, Finland, Georgia, Ireland, Kazakhstan, Kyrgyzstan,
Macedonia, Malta, Moldova, Montenegro, Russia, Serbia, Sweden, Switzerland, Tajikistan, Turkmenistan, Ukraine, Uzbekistan; note—a
nation that becomes a member of NATO is no longer a member of PFP
Permanent Court of Arbitration (PCA)
established—29 July 1899
aim—to facilitate the settlement of international disputes l . pen - J
eRe ners Albania, Argentina, Australia, Austria, Bahrain, Bangladesh, Belarus, Belgium, Belize, Benin, Bolivia, Brazil, Bulgaria,
i zhi i i i i Rica, Croatia, Cuba
i , Cambodia, Cameroon, Canada, Chile, China, Colombia, Democratic Republic of the Congo, Costa ica, | y `
Deen, ~~ Republic, Denmark, Dominican Republic, Ecuador, Egypt, El Salvador, Eritrea, Estonia, Ethiopia, Fiji, Finland, France,
Garen Greece, Guatergala, Guyana, Haiti, Honduras, Hungary, Iceland, India, Iran, Iraq, Ireland, Israel, Italy, Japan, Jordan, Kenya,
847
THE CIA WORLD FACTBOOK
South Korea, Kuwait, Kyrgyzstan, Laos, Latvia, Lebanon, Libya, Liechtenstein, Lithuania, Luxembourg, Macedonia, Madagascar, Malaysia,
Malta, Mauritius, Mexico, Montenegro, Morocco, Netherlands, NZ, Nicaragua, Nigeria, Norway, Pakistan, Panama, Paraguay, Peru,
Philippines, Poland, Portugal, Qatar, Romania, Russia, Rwanda, Saudi Arabia, Senegal, Serbia, Singapore, Slovakia, Slovenia, South Africa,
Spain, Sri Lanka, Sudan, Suriname, Swaziland, Sweden, Switzerland, Thailand, Togo, Turkey, Uganda, Ukraine, UAE, UK, US, Uruguay,
Venezuela, Vietnam, Zambia, Zimbabwe
Petrocaribe
established—29 June 2005
aim—to eliminate existing social inequities, to foster high standards of liying, to promote effective people’s participation in shaping their
own destiny
members—(18) Antigua and Barbuda, The Bahamas, Belize, Cuba, Dominica, Dominican Republic, Grenada, Guatemala, Guyana, Haiti,
Honduras, Jamaica, Nicaragua, St. Kitts and Nevis, St. Lucia, St. Vincent and the Grenadines, Suriname, Venezuela
Rio Group (RG)
note—formerly known as Grupo de los Ocho, established NA December 1986; composed of the Contadora Group and the Lima Group
established in 1988 to consult on regional Latin American issues; its members were Argentina, Belize, Bolivia, Brazil, Chile, Colombia,
Costa Rica, Cuba, Dominican Republic, Ecuador, El Salvador, Guatemala, Guyana, Haiti, Honduras, Jamaica (representing CARICOM),
Mexico, Nicaragua, Panama, Paraguay, Peru, Uruguay, Venezuela; in 2010 joined with the Caribbean Summit on Integration and Develop-
ment (CALC) to form the Community of Latin American and Caribbean States (CELAC)
Schengen Convention
established—signed June 1990; effective March 1995
aim—to allow free movement within an area without internal border controls
members—(26) Austria, Belgium, Czech Republic, Denmark, Estonia; Finland, France, Germany, Greece, Hungary, Iceland, Italy, Latvia,
Liechtenstein, Lithuania, Luxembourg, Malta, Monaco, Netherlands, Norway, Poland, Portugal, Slovakia, Slovenia, Spain, Sweden,
Switzerland; note- UK and Ireland have not joined; Cyprus will probably join in the near future; Bulgaria and Romania are still not fully
implemented
De Facto members—(3) Holy See, Monaco, San Marino
Second World
another term for the traditionally Marxist-Leninist states of the USSR and Eastern Europe, with authoritarian governments and command
economies based on the Soviet model; the term is fading from use; see centrally planned economies
Secretariat of the Pacific Community (SPC) ''
established—6 February 1947; effective 29 July 1948
aim—to serve island development in 22 Pacific countries; to develop technical assistance and professional, scientific, and research support;
to build planning and management capability
members—(26) America Samoa, Australia, Cook Islands, Fiji, France, French Polynesia, Guam, Kiribati, Marshall Islands, Federated States
of Micronesia, Nauru, New Caledonia, Niue, Northern Mariana Islands, NZ, Palau, Papua New Guinea, Pitcairn Islands, Samoa, Solomon
Islands, Tokelau, Tonga, Tuvalu, Vanuatu, US, Wallis and Futuna
Shanghai Cooperation Organization (SCO)
established—15 June 2001
aim—to combat terrorism, extremism, and separatism; to safeguard regional security through mutual trust, disarmament, and cooperative
security; and to increase cooperation in political, trade, economic, scientific and technological, cultural, and educational fields
members—(6) China, Kazakhstan, Kyrgyzstan, Russia, Tajikistan, Uzbekistan .
dialogue members—(2) Belarus, Sri Lanka
observers—(5) Afghanistan, India, Iran, Mongolia, Pakistan
socialist countries
in general, countries in which the government owns and plans the use of the major factors of production; note—the term is sometimes used
incorrectly as a synonym for Communist countries
South
a popular term for the poorer, less industrialized countries generally located south of the developed countries; the counterpart of the North;
see less developed countries (LDCs)
South American Community of Nations (CSN)
established on 9 December 2004; its aim was to coordinate common policies regarding multilateral organizations, to integrate physical infra-
structure, and to consolidate the merger of CAN and Mercosur; the members were Argentina, Bolivia, Brazil, Chile, Colombia, Ecuador,
Guyana, Paraguay, Peru, Surinam, Uruguay, Venezuela; in 2008 it became Union of South American Nations (UNASUR)
South Asia Co-operative Environment Program (SACEP)
established—January 1983
aim—to promote regional cooperation in South Asia in the field of environment, both natural and human, and on issues of economic and
social development; to support Conservation and management of natural resources of the region
members—(8) Afghanistan, Bangladesh, Bhutan, India, Maldives, Nepal, Pakistan, Sri Lanka
South Asian Association for Regional Cooperation (SAARC)
established—8 December 1985
aim—to promote economic, social, and cultural cooperation
members—(8) Afghanistan, Bangladesh, Bhutan, India, Maldives, Nepal, Pakistan, Sri Lanka
observérs—(9) Australia, Burma, China, EU, Iran, Japan, South Korea, Mauritius, US
848
ANTERNATIONAL ORGANIZATIONS AND GROUPS
South Pacific Forum (SPF)
note—see Pacific Island Forum
South Pacific Regional Trade and Economic Cooperation Agreement (Sparteca)
established—1981 : E
aim—to redress unequal trade relationships of Australia and New Zealand with small island economies in the Pacific region
members—(16) Australia, Cook Islands, Fiji (suspended), Kiribati, Marshall Islands, Federated States of Micronesia, Nauru, NZ, Niue,
Palau, Papua New Guinea, Samoa, Solomon Islands, Tonga, Tuvalu, Vanuatu
è
Southern African Customs Union (SACU)
established—-11 December 1969
aim—to promote free trade and cooperation in customs matters
members—(5) Botswana, Lesotho, Namibia, South Africa, Swaziland
Southern African Development Community (SADC)
note—evolved from the Southern African Development Coordination Conference (SADCC)
established—17 August 1992 a
aim—to promote regional economic development and integration ; 3
members—(15) Angola, Botswana, Democratic Republic of the Congo, Lesotho, Madagascar, Malawi, Mauritius, Mozambique, Namibia,
Seychelles, South Africa, Swaziland, Tanzania, Zambia, Zimbabwe
Southern Cone Common Market (Mercosur) or Southern Common Market
note—also known as Mercado Comun del Cono Sur (Mercosur)
established—26 March 1991 aim—to increase regional economic cooperation
members—(5) Argentina, Brazil, Paraguay (suspended), Uruguay, Venezuela
associate members—(4) Bolivia, Chile, Colombia, Ecuador, Peru
Third World
another term for the less developed countries; the term is obsolescent; see less developed countries (LDCs)
underdeveloped countries
refers to those less developed countries with the potential for above-average economic growth; see less developed countries (LDCs)
undeveloped countries
refers to those extremely poor less developed countries (LDCs) with little prospect for economic growth; see least developed countries
(LLDCs)
Union Latina
established —15 May 1954; became functional 1983
aim—to project, protect, and promote the common heritage and unifying identities of the Latin, and Latin-influenced, world
members—(36) Andorra, Angola, Bolivia, Brazil, Cape Verde, Chile, Colombia, Cote d''Ivoire, Costa Rica, Cuba, Dominican Republic,
Ecuador, El Salvador, France, Guatemala, Guinea-Bissau, Haiti, Honduras, Italy, Moldova, Monaco, Mozambique, Nicaragua, Panama,
Paraguay, Peru, Philippines, Portugal, Romanta, San Marino, Sao Tome and Principe, Senegal, Spain, Timor-Leste, Uruguay, Venezuela
observers—(4) Argentina, Holy See, Mexico, Order of Malta
Union of South American Notions (UNASUR—Spanish; UNASUL—Portuguese)
formerly South American Community of Nations (CSN) which terminated on 16 April 2007
established—23 May 2008
aim—to model a community after the European Union which will include a common currency, parliament, passport, and defense policy
‘members—(12) Argentina, Bolivia, Brazil, Chile, Colombia, Ecuador, Guyana, Paraguay, Peru, Suriname, Uruguay, Venezuela
observers—({2) Mexico, Panama
United Nations (UN)
established—26 June 1945; effective—24 October 1945 — —
aim—to maintain international peace and security and to promote cooperation involving economic, social, cultural, and humanitarian
problems : l :
constituent organizations—the UN is composed of six principal organs and numerous subordinate agencies and bodies as follows:
Secretariat
> General Assembly: International Computing Center (ICC), International Trade Center (ITC), Joint United Nations Program on
HIV/AIDS (UN-AIDS), Office of the United Nations High Commissioner for Human Rights (OHCHR), Organization for the Prohibi-
tion of Chemical Weapons (OPCW), United Nations Center for Human Settlements (UN-Habitat), United Nations Children’s Fund
(UNICEF), United Nations Conference on Trade and Development (UNCTAD), United Nations Democracy Fund (UNDEF), United
Nations Development Program (UNDP), United Nations Environment Program (UNEP), United Nations Institute for Disarmament
Research (UNIDIR), United Nations Institute for Training and Research (UNITAR), United Nations Interregional Crime and Justice
Research Institute (UNICRI), United Nations Office on Drugs and Crime (UNODC), United Nations Population Fund (UNFPA), United
Nations Office of Project Services (UNOPS), United Nations Relief and Works Agency tor Palestine Refugees in the Near East (UNRWA),
United Nations Research Institute for Social Development (UNRISD), United Nations System Staff College (UNSSC), United Nations
iversi U), United Nations Women, World Food Program (WFP)
a A International Criminal Tribunal for the Former Yugoslavia (ICTY), International Criminal Tribunal for Rwanda
(ICTR), United Nations Compensation Commission, United Nations Disengagement Observer Force (UNDOF), African Union/United
Nations Hybrid Operation in Darfur (UNAMID), United Nations Assistance Mission in Afghanistan (UNAMA), United Nations Inte-
grated Mission in Timor-Leste (UNMIT), United Nations Interim Administration Mission in Kosovo (UNMIK), United Nations Interim
Force for Abyei (UNIFSA}, United Nations Interim Force in Lebanon (UNIFIL), United Nations Mission in Liberia (UNMIL), United
849
THE CIA WORLD FACTBOOK
Nations Military Observer Group in India and Pakistan (UNMOGIP), United Nations Operation in Cote d''Ivoire (UNOCI), United
Nations Mission for the Referendum in Western Sahara (MINURSO), United Nations Mission in South Sudan (UNMISS), United
Nations Organization Stabilization Mission in the Democratic Republic of the Congo (MONUSCO), United Nations Peace-Keeping Force
in Cyprus (UNFICYP), United Nations Stabilization Mission in Haiti (MINUSTAH), and United Nations Truce Supervision Organization
(UNTSO)
4) Economic and Social Council (ECOSOC): Commission for Social Development, Commission on Crime Prevention and Criminal
Justice, Commission on Narcotics Drugs, Commission on Population and Development, Commission on Science and Technology for Devel-
opment, Commission on Sustainable Development, Commission on the Status of Women, Economic and Social Commission for Asia and
the Pacific (ESCAP), Economic and Social Commission for Western Asia (ESCWA), Economic Commission for Africa (ECA), Economic
Commission for Europe (ECE), Economic Commission for Latin America and the Caribbean (ECLAC), Statistical Commission, Food and
Agriculture Organization of the United Nations (FAO), International Atomic Energy Agency (IAEA), Preparatory Commission for the
Nuclear-Test-Ban Treaty Organization (CTBTO), International Bank for Reconstruction and Development (IBRD), International Center
for Secretariat of Investment Disputes (ICSID), International Civil Aviation Organization (ICAO), International Development Asso-
ciation (IDA), International Finance Corporation (IFC), International Fund for Agricultural Development (IFAD), International Labor
Organization (ILO), International Maritime Organization (IMO), International Monetary Fund (IMF), International Telecommunication
Union (ITU), Multilateral Investment Guarantee Agency (MIGA), Statistical Commission, United Nations Educational, Scientific, and
Cultural Organization (UNESCO), United Nations Forum on Forests, United Nations Industrial Development Organization (UNIDO),
Universal Postal Union {UPU), World Health Organization (WHO), World Intellectual Property Organization (WIPO), World Meteoro-
logical Organization (WMO), World Tourism Organization (UNWTO), and World Trade Organization (WTO), Statistical Commission,
UN Forum on Forests
5) Trusteeship Council (inactive; no trusteeships at this time)
6) International Court of Justice (ICJ)
UN members—(193) Afghanistan, Albania, Algeria, Andorra, Angola, Antigua and Barbuda, Argentina, Armenia, Australia, Austria,
Azerbaijan, The Bahamas, Bahrain, Bangladesh, Barbados, Belarus, Belgium, Belize, Benin, Bhutan, Bolivia, Bosnia and Herzegovina,
Botswana, Brazil, Brunei, Bulgaria, Burkina Faso, Burma, Burundi, Cambodia, Cameroon, Canada, Cape Verde, Central African Republic,
Chad, Chile, China, Colombia, Comoros, Democratic Republic of the Congo, Republic of the Congo, Costa Rica, Cote d''Ivoire, Croatia,
Cuba, Cyprus, Czech Republic, Denmark, Djibouti, Dominica, Dominican Republic, Ecuador, Egypt, El Salvador, Equatorial Guinea,
Eritrea, Estonia, Ethiopia, Fiji, Finland, France, Gabon, The Gambia, Georgia, Germany, Ghana, Greece, Grenada, Guatemala, Guinea,
Guinea-Bissau, Guyana, Haiti, Honduras, Hungary, Iceland, India, Indonesia, Iran, Iraq, Ireland, Israel, Italy, Jamaica, Japan, Jordan,
Kazakhstan, Kenya, Kiribati, North Korea, South Korea, Kuwait, Kyrgyzstan, Laos, Latvia, Lebanon, Lesotho, Liberia, Libya, Liechtenstein,
Lithuania, Luxembourg, Macedonia, Madagascar, Malawi, Malaysia, Maldives, Mali, Malta, Marshall Islands, Mauritania, Mauritius,
Mexico, Federated States of Micronesia, Moldova, Monaco, Mongolia, Montenegro, Morocco, Mozambique, Namibia, Nauru, Nepal,
Netherlands, NZ, Nicaragua, Niger, Nigeria, Norway, Oman, Pakistan, Palau, Panama, Papua New Guinea, Paraguay, Peru, Philippines,
Poland, Portugal, Qatar, Romania, Russia, Rwanda, Saint Kitts and Nevis, Saint Lucia, Saint Vincent and the Grenadines, Samoa, San
Marino, Sao Tome and Principe, Saudi Arabia, Senegal, Serbia, Seychelles, Sierra Leone, Singapore, Slovakia, Slovenia, Solomon Islands,
Somalia, South Africa, South Sudan, Spain, Sri Lanka, Sudan, Suriname, Swaziland, Sweden, Switzerland, Syria, Tajikistan, Tanzania,
Thailand, Timor-Leste, Togo, Tonga, Trinidad and Tobago, Tunisia, Turkey, Turkmenistan, Tuvalu, Uganda, Ukraine, UAE, UK, US,
Uruguay, Uzbekistan, Vanuatu, Venezuela, Vietnam, Yemen, Zambia, Zimbabwe; note—all UN members are represented in the General
Assembly observers—(1 plus the Palestine Liberation Organization) Holy See, Palestine Liberation Organization
United Nations Assistance Mission in Afghanistan (UNAMA)
established—January 2010
aim—to support the government of Afghanistan, in its attempt to improve security, governance, and economic development and regional
cooperation; protect civilians and support efforts to support human rights
note—gives civilian support only
United Nations Children’s Fund (UNICEF)
note—acronym retained from the predecessor organization, UN International Children’s Emergency Fund
established—11 December 1946 `
aim—to help establish child health and welfare services
executive board members—(36) selected on a rotating basis from all regions
United Nations Conference on Trade and Development (UNCTAD)
established—30 December 1964
aim—to promote international
trade members—(194) all UN members plus Holy See
United Nations Development Program (UNDP)
established—22 November 1965
aim—to provide technical assistance to stimulate economic and social development
members (executive board)—(36) selected on a rotating basis from all regions
United Nations Disengagement Observer Force (UNDOF)
established—31 May 1974 :
aim—to observe the 1973 Arab-Israeli cease-fire; established by the UN Security Council
members—(5) Austria, Croatia, India, Japan, Philippines
United Nations Educational, Scientific, and Cultural Organization (UNESCO)
established—16 November 1945; effective—4 November 1946
aim—to promote cooperation in education, science, and culture
members—(194 plus the Palestine Liberation Organization) includes all UN member countries except Liechtenstein (192 total); plus Cook
Islands, Niue, and the Palestine Liberation Organization : ‘
associate members—(8) Aruba, British Virgin Islands, Cayman Islands, Curacao, Faroe Islands, Macau, Sint Maarten, Tokelau
850
INTERNATIONAL ORGANIZATIONS AND GROUPS
United Nations Environment Program (UNEP)
established—-15 December 1972
aim—to promote international cooperation on all environmental matters
members—(58) selected on a rotating basis from all regions
United Nations General Assembly
established—26 June 1945; effective—24 October 1945
aim—to function as the primary deliberative organ of the UN
members—(193) all UN members are represented in the General Assembly
United Nations High Commissioner for Refugees (UNHCR)
established—3 December 1949; effective—1 January 1951
aim—to ensure the humanitarian treatment of refugees and find permanent solutions to refugee problems
members (executive committee)—(87) Algeria, Argentina, Australia, Austria, Azerbaijan, Bangladesh, Belgium, Benin, Brazil, Bulgaria,
Cameroon, Canada, Chile, China, Colombia, Democratic Republic of the Congo, Republic of the Congo, Costa Rica, Cote d''lvoire,
Croatia, Cyprus, Denmark, Djibouti, Ecuador, Egypt, Estonia, Ethiopia, Finland, France, Germany, Ghana, Greece, Guinea, Holy See,
Hungary, India, Iran, Ireland, Israel, Italy, Japan, Jordan, Kenya, South Korea, Lebanon, Lesotho, Luxembourg, Macedonia, Madagascar,
Mexico, Moldova, Montenegro, Morocco, Mozambique, Namibia, Netherlands, NZ, Nicaragua, Nigeria, Norway, Pakistan, Philippines,
Poland, Portugal, Romania, Russia, Rwanda, Serbia, Slovenia, Somalia, South Africa, Spain, Sudan, Sweden, Switzerland, Tanzania,
Thailand, Togo, Tunisia, Turkey, Turkmenistan, Uganda, UK, US, Venezuela, Yemen, Zambia
United Nations industrial Development Organization (UNIDO)
established —17 November 1966; effective—1 January 1967
aim—UN specialized agency that promotes industrial development especially among the members
members—(174) includes all UN member countries except Andorra, Antigua and Barbuda, Australia, Brunei, Canada, Estonia, Iceland,
Kiribati, Latvia, Liechtenstein, Marshall Islands, Federated States of Micronesia, Nauru, Palau, San Marino, Singapore, Solomon Islands,
South Sudan, US 1
United Nations Institute for Training and Research (UNITAR)
established—11 December 1963 adoption of the resolution establishing the Institute; effective—24 March 1965
aim—to help the UN become more effective through training and research
members (Board of Trustees)—(14) Algeria, Brazil, Burkina Faso, Republic of the Congo, Guatemala, India, Iran, Ireland, Jamaica,
Nigeria, Norway, South Africa, Switzerland, US; note- the UN Secretary General can appoint up to 30 members
United Nations Integrated Mission in Timor-Leste (UNMIT)
established—25 August 2006
aim—to support the Government, to support the electoral process, to ensure the restoration and maintenance of public security
members—(12) Australia, Bangladesh, Brazil, China, Fiji, Nepal, NZ, Pakistan, Philippines, Portugal, Sierra Leone, Singapore
United Nations Interim Administration Mission in Kosovo (UNMIK)
established—10 June 1999
aim—to promote the establishment of substantial autonomy and self-government in Kosovo; to perform basic civilian administrative func-
tions; to support the reconstruction of key infrastructure and humanitarian and disaster relief
note—gives civilian support only; works closely with NATO Kosovo Force (KFOR)
Unite','ed4ad6e4aba966a18ef65b2f942bb656e658e7038784d52e67ea47de4aef66df','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('08b5ff553174d283be871a55a64c7b57a55ed13a2af418de0fa5851d0f1bf3e0',2025,'VC','Saint Vincent and the Grenadines','environment',1737,'d Nations interim Force in Lebanon (UNIFIL)
established —19 March 1978 3
aim—to confirm the withdrawal of Israeli forces, and assist in reestablishing Lebanese authority in southern Lebanon; established by the
UN Security Council ’ ’
members—(38) Armenia, Austria, Bangladesh, Belarus, Belgium, Brazil, Brunei, Cambodia, China, Croatia, Cyprus, El Salvador, Finland,
France, Germany, Ghana, Greece, Guatemala, Hungary, India, Indonesia, Ireland, Italy, Kenya, South Korea, Luxembourg, Macedonia,
Malaysia, Nepal, Nigeria, Qatar, Serbia, Sierra Leone, Slovenia, Spain, Sri Lanka, Tanzania, Turkey
United Nations Interim Security Force for Abyel (UNISFA)
established—27 June 2011
aim—to protect civilians and humanitarian workers in Abyei
members—(26) Benin, Bolivia, Brazil, Burundi, Ethiopta, Ghana, Guatemala, India, Indonesia, Kyrgyzstan, Mongolia, Mozambique,
Namibia, Nepal, Nigeria, Paraguay, Peru, Philippines, Russia, Rwanda, Sierra Leone, Sri Lanka, Tanzania, Uruguay, Zambia, Zimbabwe
United Nations Military Observer Group in India and Pakistan (UNMOGIP)
established—24 January 1949 i l
aim—to observe the-1949 India-Pakistan cease-fire; established by the UN Security Council
members—(9) Ghile, Croatia, Finland, Italy, South Korea, Philippines, Sweden, Thailand, Uruguay
United Nations Mission for the Referendum in Western Sahara (MINURSO)
established—29 April 1991 ?
aim—to supervise the cease-fire and conduct a referendum in Western Sahara; established by the UN Security Council l
members—(29) Argentina, Austria, Bangladesh, Brazil, China, Croatia, Djibouti, Egypt, El Salvador, France, Ghana, Guinea, Honduras,
Hungary, Ireland, Italy, South Korea, Malawi, Malaysia, Mongolia, Nepal, Nigeria, Pakistan, Peru, Poland, Russia, Sri Lanka, Uruguay, Yemen
United Nations Mission in Liberia (UNMIL)
established—19 September 2003
aim—to support the cease-fire agreement and peace process,
in national security reform*
protect UN facilities and people, support humanitarian activities, and assist
851
THE CIA WORLD FACTBOOK
members—(43) Bangladesh, Benin, Bolivia, Brazil, Bulgaria, China, Croatia, Denmark, Ecuador, Egypt, El Salvador, Ethiopia, Finland,
France, The Gambia, Ghana, Indonesia, Jordan, South Korea, Kyrgyzstan, Malaysia, Mali, Moldova, Montenegro, Namibia, Nepal, Niger,
Nigeria, Pakistan, Paraguay, Peru, Philippines, Poland, Romania, Russia, Senegal, Serbia, Togo, Ukraine, US, Yemen, Zambia, Zimbabwe
United Nations Mission in the Central African Republic and Chad (MINURCAT)
established on 25 September 2007; to create the security and conditions which will to contribute to the protection of refugees, displaced
persons, and citizens in danger, to facilitate the provision of humanitarian assistance in eastern Chad and the northeastern Central African
Republic, to create favorable conditions for the reconstruction and economic and social development of these areas; members were
Bangladesh, Benin, Burkina Faso, Democratic Republic of the Congo, Egypt, Ethiopia, Ghana, Ireland, Kenya, Mali, Mongolia, Namibia,
Nepal, Nigeria, Norway, Pakistan, Poland, Russia, Rwanda, Senegal, Serbia, Sri Lanka, Togo, Tunisia, US; MINURCAT was dissolved in
December 2010
United Nations Mission in the Republic of South Sudan (UNMISS)
established—8 July 2011
aim—to consolidate peace and security and to establish the conditions in South Sudan which will strengthen its ability to govern effectively
and democratically and establish good relations with its neighbors
members—(54) Australia, Bangladesh, Benin, Bolivia, Brazil, Cambodia, Canada, China, Denmark, Ecuador, Egypt, El Salvador, Fiji,
Germany, Ghana, Guatemala, Guinea, India, Indonesia, Italy, Japan, Jordan, Kenya, South Korea, Kyrgyzstan, Mali, Moldova, Mongolia,
Namibia, Nepal, Netherlands, NZ, Nigeria, Norway, Papua New Guinea, Paraguay, Peru, Philippines, Poland, Romania, Russia, Rwanda,
Senegal, Sri Lanka, Sweden, Switzerland, Tanzania, Timor-Leste, Ukraine, UK, US, Yemen, Zambia, Zimbabwe
United Nations Mission in the Sudan (UNMIS)
established in March 2005 to support implementation of the comprehensive Peace Agreement by monitoring and verifying the implemen-
tation of the Cease Fire Agreement, by observing and monitoring movements of armed groups, and by helping disarm, demobilizing and
reintegrating armed bands; members were Australia, Bangladesh, Belgium, Benin, Bolivia, Brazil, Burkina Faso, Cambodia, Canada, China,
Croatia, Denmark, Ecuador, Egypt, El Salvador, Fiji, Finland, Germany, Greece, Guatemala, Guinea, India, Indonesia, Iran, Japan, Jordan,
Kenya, Kyrgyzstan, Malaysia, Moldova, Mongolia, Morocco, Namibia, Nepal, Netherland, NZ, Niger, Norway, Pakistan, Paraguay, Peru,
Philippines, Poland, Qatar, Romania, Russia, Rwanda, Sierra Leone, Spain, Sweden, Switzerland, Tanzania, Thailand, Turkey, Uganda,
Ukraine, UK, Yemen, Zambia, Zimbabwe; UNMIS was dissolved on 9 July 2011
United Nations Operation in Cote d''Ivoire (UNOCI)
established—27 February 2004
aim—to facilitate the implementation by the Ivorian parties of the peace agreement signed by them in January 2003
members—(42) Bangladesh, Benin, Bolivia, Brazil, Chad, China, Ecuador, Egypt, El Salvador, Ethiopia, France, The Gambia, Ghana,
Guatemala, Guinea, India, Ireland, Jordan, South Korea, Malawi, Moldova, Morocco, Namibia, Nepal, Niger, Nigeria, Pakistan, Paraguay,
Peru, Philippines, Poland, Romania, Russia, Senegal, Serbia, Tanzania, Togo, Tunisia, Uganda, Uruguay, Yemen, Zimbabwe
United Nations Organization Stabilization Mission in the Democratic Republic of the Congo (MONUSCO)
established—28 May 2010
aim—to protect the civilians; to assist the government in the areas of stabilization and peace consolidation
members—(49) Algeria, Bangladesh, Belgium, Benin, Bolivia, Bosnia and Herzegovina, Burkina Faso, Cameroon, Canada, China, Czech
Republic, Egypt, France, Ghana, Guatemala, India, Indonesia, Ireland, Jordan, Kenya, Malawi, Malaysia, Mali, Mongolia, Morocco, Nepal,
Niger, Nigeria, Norway, Pakistan, Paraguay, Peru, Poland, Romania, Russia, Senegal, Serbia, South Africa, Sri Lanka, Sweden, Switzerland,
Tanzania, Tunisia, Ukraine, UK, US, Uruguay, Yemen, Zambia
United Nations Peacekeeping Force in Cyprus (UNFICYP)
established—4 March 1964
aim—to serve as a peacekeeping force between Greek Cypriots and Turkish Cypriots in Cyprus; established by the UN Security Council
members—(12) Argentina, Austria, Brazil, Canada, Chile, China, Croatia, Hungary, Paraguay, Serbia, Slovakia, UK
United Nations Population Fund (UNFPA)
note—acronym retained from predecessor organization UN Fund for Population Activities
established—July 1967
aim—to assist both developed and developing countries to deal with their population problems
members (executive board)—(36) selected on a rotating basis from all regions
United Nations Relief and Works Agency for Palestine Refugees in the Near East (UNRWA)
established—8 December 1949
aim—to provide assistance to Palestinian refugees
members (advisory commission)—(25) Australia, Belgium, Canada, Denmark, Egypt, Finland, France, Germany, Ireland, Italy, Japan,
Jordan, Kuwait, Lebanon, Luxembourg, Netherlands, Norway, Saudi Arabia, Spain, Sweden, Switzerland, Syria, Turkey, UK, US
observers—(3) EC, LAS, Palestine Liberation Organization
United Nations Research Institute for Social Development (UNRISD)
established—1963
aim—to conduct research into the problems of economic development during different phases of economic growth
members—no country members, but a Board of Directors consisting of a chairman appointed by the UN Secretary General and 10 members
confirmed by ECOSOC and a representative of the Secretary General ‘
United Nations Secretariat
established—26 June 1945; effective—24 October 1945
aim—to serve as the primary administrative organ of the UN; a Secretary General is appointed for a five-year term by the General Assembly
on the recommendation of the Security Council
members—the UN Secretary General and staff
852
INTERNATIONAL ORGANIZATIONS AND GROUPS
United Nations Security Council (UNSC)
established—26 June 1945; effective—24 October 1945
aim—to maintain international peace and security
permanent members—(5) China, France, Russia, UK, US : 3 >
nonpermanent members—(10) elected for two-year terms by the UN General Assembly; Argentina (2013-14), Azerbaijan (2012-13),
Australia (2013-14), Guatemala (2012-13), Luxembourg (2013-14), Morocco (2012-13), South Korea (2013-14), Pakistan (2012-13),
Rwanda (2013-14), Togo (2012-13)
United Nations Truce Supervision Organization (UNTSO)
established—June 1948
aim—to supervise the 1948 Arab-lsraeli cease-fire; currently supports timely deployment of reinforcements to other peacekeeping opera-
tions in the region as needed; initially established by the UN Security Council
members—(23) Argentina, Australia, Austria, Belgium, Canada, Chile, China, Denmark, Estonia, Finland, France, Ireland, Italy, Nepal,
Netherlands, NZ, Norway, Russia, Slovakia, Slovenia, Sweden, Switzerland, US
United Nations Trusteeship Council
established on 26 June 1945, effective on 24 October 1945, to supervise the administration of the 11 UN trust territories; members were
China, France, Russia, UK, US; it formally suspended operations 1 November 1994 after the Trust Territory of the Pacific Islands (Palau)
became the Republic of Palau, a constitutional government in free association with the US; the Trusteeship Council was not dissolved
United Nations University (UNU)
established—3 December 1973
aim—to conduct research in development, welfare, and human survival and to train scholars
members—(24 members of UNU Council and the Rector are appointed by the Secretary General of the United Nations and the Director
General of UNESCO) os
Universal Postal Union (UPU)
established—9 October 1874, affiliated with the UN 15 November 1947; effective—I July 1948
aim—to promote international postal cooperation; a UN specialized agency
members—(192) includes all UN member countries except Andorra, Marshall Islands, Federated States of Micronesia, Palau (189 total);
plus Aruba, Curacao, and Sint Maarten and Holy See and Overseas Territories of the UK; note—includes the following dependencies or
areas of special interest: Australia (Norfolk Island), China (Hong Kong, Macau), Denmark (Faroe Islands, Greenland), France (French
Guiana, French Polynesia including Clipperton Island, French Southern and Antarctic Lands, Guadeloupe, Martinique, Mayotte, New
Caledonia, Reunion, Saint Barthelemy, Saint Martin, Saint Pierre and Miquelon, Scattered Islands [Bassas da India, Europe, Juan de Nova,
Glorioso Islands, Tromelin}, Wallis and Futuna), Netherlands (Aruba, Curacao, Sint Maarten), NZ (Cook Island, Niue, Tokelau), UK
(Guernsey, Isle of Man, Jersey; Anguilla, Bermuda, British Indian Ocean Territory, British Virgin Islands, Cayman Islands, Falkland Islands,
Gibraltar, Montserrat, Pitcairn Islands, Saint Helena, Ascension, and Tristan da Cunha, South Georgia and South Sandwich Islands, Turks
and Caicos), US (American Samoa, Guam, Northern Mariana Islands, Puerto Rico, Virgin Islands) :
Warsaw Pact (WP)
established 14 May 1955 to promote mutual defense; members met 1 July 1991 to dissolve the alliance; member states at the time of dissolu-
tion were: Bulgaria, Czechoslovakia, Hungary, Poland, Romania, and the USSR; earlier members included German Democratic Republic
(GDR) and Albania
West African Development Bank (WADB)
note—also known as Banque Ouest-Africaine de Developpement (BOAD); is a financial institution of WAEMU
established—14 November 1973
aim—to promote regional economic development and integration
regional members—{8) Benin, Burkina Faso, Cote d''Ivoire, Guinea-Bissau, Mali, Niger, Senegal, Togo
West African Economic and Monetary Union (WAEMU)
note—also known as Union Economique et Monetaire Ouest Africaine (UEMOA)
established—1 August 1994
aim—to increasecompetitiveness of members’ economic markets; to create a common market
members—(8) Benin, Burkina Faso, Cote d''Ivoire, Guinea-Bissau, Mali, Niger, Senegal, Togo
Western European Union (WEU) e —_—
established 23 October 1954; effective—6 May 1955; aim to provide mutual defense and to move toward political unification; 10 members:
Belgium, France, Germany, Greece, Italy, Luxembourg, Netherlands, Portugal, Spain, UK; 6 associate members: Czech Republic, Hungary,
Iceland, Norway, Poland, Turkey; 7 associate partners: Bulgaria, Estonia, Latvia, Lithuania, Romania, Slovakia, Slovenia; 5 observers:
Austria, Denmark, Finland, Ireland, Sweden; note—to cease existence completely by June 2011
World Bank Group
includes International Bank for Reconstruction and Development (IBRD), International Development Association (IDA), International
Finance Corporation (IFC), and Multilateral Investment Guarantee Agency (MIGA)
World Confederation of Labor (WCL)
established 19 June 1920 as the International Federation of Christian Trade Unions (IFCTU), renamed 4 October 1968; aim was to pro-
mote the trade union movement; on 31 October 2006 it merged with the International Confederation of Free Trade Unions (ICFTU) to
form the International Trade Union Confederation (ITUC); members were (105 national organizations) Antigua and Barbuda, Argentina,
Aruba, Austria, Bangladesh, Belgium, Belize, Benin, Bolivia, Brazil, Bulgaria, Burkina Faso, Cameroon, Canada, Central African Republic,
Chad, Chile, Colombia, Democratic Republic of the Congo, Republic of the Congo, Costa Rica, Cote d''Ivoire, Cuba, Cyprus, Czech
Republic, Denmark, Dominica, Dominican Republic, Ecuador, El Salvador, France, French Guiana, Gabon, The Gambia, Ghana,
` Guadeloupe, Guatemala, Guinea, Guyana, Haiti, Honduras, Hong Kong, Hungary, India, Indonesia, Iran, Italy, Japan, Kazakhstan, South
853
THE CIA WORLD FACTBOOK
Korea, Liberia, Libya, Liechtenstein, Lithuania, Luxembourg, Macedonia, Madagascar, Malawi, Malaysia, Malta, Martinique, Mauritania,
Mauritius, Mexico, Morocco, Namibia, Nepal, Netherlands, Nicaragua, Niger, Pakistan, Panama, Paraguay, Peru, Philippines, Poland,
Portugal, Puerto Rico, Romania, Rwanda, Saint Lucia, Saint Vincent and the Grenadines, Sao Tome and Principe, Senegal, Serbia,’
Sierra Leone, Singapore, Slovakia, South Africa, Spain, Sri Lanka, Suriname, Switzerland, Taiwan, Thailand, Togo, Trinidad and Tobago,
Ukraine, US, Uruguay, Venezuela, Vietnam, Zambia, Zimbabwe
World Customs Organization (WCO)
note—began as the Customs Cooperation Council (CCC)
established—15 December 1950
aim—to promote international cooperation in customs matters
members—(177) Afghanistan, Albania, Algeria, Andorra, Angola, Argentina, Armenia, Australia, Austria, Azerbaijan, The Bahamas,
Bahrain, Bangladesh, Barbados, Belarus, Belgium, Belize, Benin, Bermuda, Bhutan, Bolivia, Bosnia and Herzegovina, Botswana, Brazil,
Brunei, Bulgaria, Burkina Faso, Burma, Burundi, Cambodia, Cameroon, Canada, Cape Verde, Central African Republic, Chad, Chile,
China, Colombia, Comoros, Democratic Republic of the Congo, Republic of the Congo, Costa Rica, Cote d''Ivoire, Croatia, Cuba, Cyprus,
Czech Republic, Denmark, Djibouti, Dominican Republic, EU, Ecuador, Egypt, El Salvador, Eritrea, Estonia, Ethiopia, Fiji, Finland,
France, Gabon, The Gambia, Georgia, Germany, Ghana, Greece, Guatemala, Guinea, Guinea- Bissau, Guyana, Haiti, Honduras, Hong
Kong, Hungary, Iceland, India, Indonesia, Iran, Iraq, Ireland, Israel, Italy, Jamaica, Japan, Jordan, Kazakhstan, Kenya, South Korea, Kuwait,
Kyrgyzstan, Laos, Latvia, Lebanon, Lesotho, Liberia, Libya, Lithuania, Luxembourg, Macau, Macedonia, Madagascar, Malawi, Malaysia,
Maldives, Mali, Malta, Mauritania, Mauritius, Mexico, Moldova, Mongolia, Montenegro, Morocco, Mozambique, Namibia, Nepal,
Netherlands, NZ, Nicaragua, Niger, Nigeria, Norway, Oman, Pakistan, Panama, Papua New Guinea, Paraguay, Peru, Philippines, Poland,
Portugal, Qatar, Romania, Russia, Rwanda, Saint Lucia, Samoa, Sao Tome and Principe, Saudi Arabia, Senegal, Serbia, Seychelles, Sierra
Leone, Singapore, Slovakia, Slovenia, South Africa, Spain, Sri Lanka, Sudan, Swaziland, Sweden, Switzerland, Syria, Tajikistan, Tanzania,
Thailand, Timor-Leste, Togo, Tonga, Trinidad and Tobago, Tunisia, Turkey, Turkmenistan, Uganda, Ukraine, UAE, UK, US, Uruguay,
Uzbekistan, Vanuatu, Venezuela, Vietnam, Yemen, Zambia, Zimbabwe °
World Federation of Trade Unions (WFTU)
established—3 October 1945
aim—to promote the trade union movement
members—(in 2012 there were 119 participating nations and the Palestine Liberation Organization; the nations were not listed); (in
2009 there were 125 nations and the Palestine Liberation Organization) Afghanistan, Albania, Angola, Antigua and Barbuda, Argentina,
Armenia, Australia, Austria, Azerbaijan, Bahrain, Bangladesh, Barbados, Belarus, Benin, Bolivia, Botswana, Brazil, Bulgaria, Burkina Faso,
Cambodia, Cameroon, Canada, Chile, Colombia, Democratic Republic of the Congo, Republic of the Congo, Costa Rica, Cote d''Ivoire,
Cuba, Cyprus, Czech Republic, Djibouti, Dominican Republic, Ecuador, Egypt, El Salvador, Eritrea, Ethiopia, Fiji, Finland, France, French
Guiana, The Gambia, Ghana, Greece, Guadeloupe, Guatemala, Guinea, Guinea-Bissau, Guyana, Haiti, Honduras, Hungary, India,
Indonesia, Iran, Iraq, Jamaica, Japan, Jordan, Kazakhstan, North Korea, Kuwait, Kyrgyzstan, Laos, Lebanon, Lesotho, Liberia, Libya,
Madagascar, Malawi, Malaysia, Mali, Martinique, Mauritius, Mexico, Mozambique, Nepal, New Caledonia, NZ, Niger, Nigeria, Oman,
Pakistan, Panama, Papua New Guinea, Peru, Philippines, Poland, Portugal, Puerto Rico, Reunion, Romania, Russia, Saint Lucia, Saint
Pierre and Miquelon, Saint Vincent and the Grenadines, Saudi Arabia, Senegal, Sierra Leone, Slovakia, Solomon Islands, Somalia, South
Africa, Sri Lanka, Sudan, Sweden, Syria, Tajikistan, Tanzania, Thailand, Togo, Trinidad and Tobago, Tunisia, Turkey, Turkmenistan,
Uganda, Ukraine, Uruguay, Uzbekistan, Vanuatu, Venezuela, Vietnam, Yemen, Zimbabwe, Palestine Liberation Organization
World Food Program (WFP)
established—24 November 1961
aim—to provide food aid in support of economic development or disaster relief; an ECOSOC organization
members (Executive Board)—(36) selected on a rotating basis from all regions
World Health Organization (WHO)
established—22 July 1946; effective—7 April 1948
aim—to deal with health matters worldwide; a UN specialized agency
members—(194) includes all UN member countries except Liechtenstein (192 total); plus Cook Islands and Niue
World:Intellectual Property Organization (WIPO)
established—14 July 1967; effective—26 April 1970
‘ aim—to furnish protection for literary, artistic, and scientific works; a UN specialized agency
members—(185) includes all UN member countries except Kiribati, Marshall Istands, Federated States of Micronesia, Nauru, Palau, Solo-
mon Islands, South Sudan, Timor-Leste, Tuvalu (184 total); plus Holy See
y
World Meteorological Organization (WMO)
established—11 October 1947; effective—4 April 1951
aim—to sponsor meteorological cooperation; a UN specialized agency
members—(183) includes all UN member countries except Andorra, Equatorial Guinea, Grenada, Liechtenstein, Marshall Islands, Nauru,
Palau, Saint Kitts and Nevis, Saint Vincent and the Grenadines, San Marino, South Sudan, Tuvalu (181 total); plus Cook Islands and Niue
World Tourism Organization (UNWTO) . t "
established—2 January 1975
aim—to promote tourism as a means of contributing to economic development, international understanding, and peace
members—(155) Afghanistan, Albania, Algeria, Andorra, Angola, Argentina, Armenia, Australia, Austria, Azerbaijan, The Bahamas,
Bahrain, Bangladesh, Belarus, Benin, Bhutan, Bolivia, Bosnia and Herzegovina, Botswana, Brazil, Brunei, Bulgaria, Burkina Faso, Burma,
Burundi, Cambodia, Cameroon, Cape Verde, Central African Republic, Chad, Chile, China, Colombia, Democratic Republic of the Congo,
Republic of the Congo, Costa Rica, Cote d''Ivoire, Croatia, Cuba, Cyprus, Czech Republic, Djibouti, Dominican Republic, Ecuador, Egypt, El
Salvador, Equatorial Guinea, Eritrea, Ethiopia, Fiji, France, Gabon, The Gambia, Georgia, Germany, Ghana, Greece, Guatemala, Guinea,
Guinea-Bissau, Haiti, Honduras, Hungary, India, Indonesia, Iran, Iraq, Israel, Italy, Jamaica, Japan, Jordan, Kazakhstan, Kenya, North Korea,
South Korea, Kuwait, Kyrgyzstan, Laos, Latvia, Lebanon, Lesotho, Liberia, Libya, Lithuania, Macedonia, Madagascar, Malawi, Malaysia,
854
INTERNATIONAL ORGANIZATIONS AND GROUPS
Maldives, Mali, Malta, Mauritania, Mauritius, Mexico, Moldova, Monaco, Mongolia, Montenegro, Morocco, Mozambique, Namibia,
Nepal, Netherlands, Nicaragua, Niger, Nigeria, Norway, Oman, Pakistan, Panama, Papua New Guinea, Paraguay, Peru, Philippines, Poland,
Portugal, Qatar, Romania, Russia, Rwanda, San Marino, Sao Tome and Principe, Saudi Arabia, Senegal, Serbia, Seychelles, Sierra Leone,
Slovakia, Slovenia, South Africa, Spain, Sri Lanka, Sudan, Swaziland, Switzerland, Syria, Tajikistan, Tanzania, Thailand, Timor-Leste,
Togo, Tunisia, Turkey, Turkmenistan, Uganda, Ukraine, Uruguay, Uzbekistan, Vanuatu, Venezuela, Vietnam, Yemen, Zambia, Zimbabwe
associate members—(7) Aruba, Curacao, Flanders, Hong Kong, Macau, Madeira Islands, Puerto Rico
observers—(1 plus Palestine Liberation Organization) Holy See, Palestine Liberation Organization
World Trade Organization (WTO)
note—succeeded General Agreement on Tariff and Trade (GATT)
established—15 April 1994; effective—1 January 1995
aim—to provide a forum to resolve trade conflicts between members and to carry on negotiations with the goal of further lowering and/or
eliminating tariffs and other trade barriers
members—(157) Albania, Angola, Antigua and Barbuda, Argentina, Armenia, Australia, Austria, Bahrain, Bangladesh, Barbados,
Belgium, Belize, Benin, Bolivia, Botswana, Brazil, Brunei, Bulgaria, Burkina Faso, Burma, Burundi, Cambodia, Cameroon, Canada, Cape
Verde, Central African Republic, Chad, Chile, China, Colombia, Democratic Republic of the Congo, Republic of the Congo, Costa Rica,
Cote d''Ivoire, Croatia, Cuba, Cyprus, Czech Republic, Denmark, Djibouti, Dominica, Dominican Republic, Ecuador, Egypt, El Salvador,
Estonia, EU, Fiji, Finland, France, Gabon, The Gambia, Georgia, Germany, Ghana, Greece, Grenada, Guatemala, Guinea, Guinea-
Bissau, Guyana, Haiti, Honduras, Hong Kong, Hungary, Iceland, India, Indonesia, Ireland, Israel, Italy, Jamaica, Japan, Jordan, Kenya,
South Korea, Kuwait, Kyrgyzstan, Laos, Latvia, Lesotho, Liechtenstein, Lithuania, Luxembourg, Macau, Macedonia, Madagascar, Malawi,
Malaysia, Maldives, Mali, Malta, Mauritania, Mauritius, Mexico, Moldova, Mongolia, Montenegro, Morocco, Mozambique, Namibia,
Nepal, Netherlands, NZ, Nicaragua, Niger, Nigeria, Norway, Oman, Pakistan, Panama, Papua New Guinea, Paraguay, Peru, Philippines,
Poland, Portugal, Qatar, Romania, Russia, Rwanda, Saint Kitts and Nevis, Saint Lucia, Saint Vincent and the Grenadines, Samoa, Saudi
Arabia, Senegal, Sierra Leone, Singapore, Slovakia, Slovenia, Solomon Islands, South Africa, Spain, Sri Lanka, Suriname, Swaziland,
Sweden, Switzerland, Taiwan, Tanzania, Thailand, Togo, Tonga, Trinidad and Tobago, Tunisia, Turkey, Uganda, Ukraine, UAE, UK, US,
Uruguey, Vanuatu, Venezuela, Vietnam, Zambia, Zimbabwe j Ši
observers—(27) Afghanistan, Algeria, Andorra, Azerbaijan, The Bahamas, Belarus, Bhutan, Bosnia and Herzegovina, Comoros, Equatorial
Guinea, Ethiopia, Holy See, Iran, Iraq, Kazakhstan, Lebanon, Liberia, Libya, Sao Tome and Principe, Serbia, Seychelles, Sudan, Syria,
Tajikistan, Uzbekistan, Yemen; note—with the exception of the Holy See, an observer must start accession negotiations within five years
of becoming-observers : ; y
Zangger Committee (ZC)
established—early 1970s
aim—to establish guidelines for the export control provisions of the Nonproliferation of Nuclear Weapons Treaty (NPT)
members—(38) Argentina, Australia, Austria, Belarus, Belgium, Bulgaria, Canada, China, Croatia, Czech Republic, Denmark, Finland,
France, Germany, Greece, Hu','1f4d24c3fa634fc74c2b70e089fbc2a91f04ceaf6137f1e72fef2a9c59e4ea01','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e2c6d7ad23a27b570343c3393029e433be4e91151e7ec90202bd066cfd152185',2025,'VC','Saint Vincent and the Grenadines','environment',1738,'ngary, Ireland, Italy, Japan, Kazakhstan, South Korea, Luxembourg, Netherlands, Norway, Poland, Portugal,
Romania, Russia, Slovakia, Slovenia, South Africa, Spain, Sweden, Switzerland, Turkey, Ukraine, UK, US
observers—(1) European Commission
B55
APPENDIX C
SELECTED INTERNATIONAL ENVIRONMENTAL AGREEMENTS
Air Pollution
see Convention on Long-Range Transboundary Air Pollution
Air Pollution-Nitrogen Oxides
see Protocol to the 1979 Convention on Long-Range Transboundary Air Pollution Concerning the Control of Emissions of Nitrogen Oxides
orTheir Transboundary Fluxes
Air Pollution-Persistent Organic Pollutants
see Protocol to the 1979 Convention on Long-Range Transboundary Air Pollution on Persistent Organic Pollutants
Air Pollution-Sulphur 85
see Protocol to the 1979 Convention on Long-Range Transboundary Air Pollution on the Biwi of Sulphur Emissions or Their Trans-
boundary Fluxes by at least 30%
Air Pollution-Sulphur 94
see Protocol to the 1979 Convention on Long-Range Transboundary Air Pollution on Further Reduction of Sulphur Emisstons
Air Pollution-Volatile Organic Compounds
see Protocol to the 1979 Convention on Long-Range Transboundary Air Pollution Concerning the Control of Emissions of Volatile Organic
Compounds or Their Transboundary Fluxes
Antarctic—Environmental Protocol
see Protocol on Environmental Protection to the Antarctic Treaty
Antarctic Treaty
opened for signature—1 December 1959
entered into force—23 June 1961
objective—to ensure that Antarctica is used for peaceful purposes only (such as international cooperation in scientific research); to defer
the question of territorial claims asserted by some nations and not recognized by others; to provide an international forum for management
of the region; applies to land and ice shelves south of 60 degrees south latitude
parties—(46) Argentina, Australia, Austria, Belarus, Belgium, Brazil, Bulgaria, Canada, Chile, China, Colombia, Cuba, Czech Republic,
Denmark, Ecuador, Estonia, Finland, France, Germany, Greece, Guatemala, Hungary, India, Italy, Japan, North Korea, South Korea,
Netherlands, NZ, Norway, Papua New Guinea, Peru, Poland, Romania, Russia, Slovakia, South Africa, Spain, Sweden, Switzerland, Turkey,
Ukraine, UK, US, Uruguay, Venezuela
Basel Convention on the Control of Transboundary Movements of Hazardous Wastes and Their Disposal
note—abbreviated as Hazardous Wastes
opened for signature—22 March 1989
entered into force—5 May 1992
objective—to reduce transboundary movements of wastes subject to the Convention to a minimum consistent with the environmentally
sound and efficient management of such wastes; to minimize the amount and toxicity of wastes generated and ensure their environmen-
tally sound management as closely as possible to the source of generation; and to assist LDCs in environmentally sound management of the
hazardous and other wastes they generate
parties—(172) Albania, Algeria, Andorra, Antigua and Barbuda, Argentina, Armenia, Australia, Austria, Azerbaijan, The Bahamas,
Bahrain, Bangladesh, Barbados, Belarus, Belgium, Belize, Benin, Bhutan, Bolivia, Bosnia and Herzegovina, Botswana, Brazil, Brunei,
Bulgaria, Burkina Faso, Burundi, Cambodia, Cameroon, Canada, Cape Verde, Central African Republic, Chad, Chile, China, Colombia,
Comoros, Democratic Republic of the Congo, Republic of the Congo, Cook Islands, Costa Rica, Cote d''lvoire, Croatia, Cuba, Cyprus,
Czech Republic, Denmark, Djibouti, Dominica, Dominican Republic, Ecuador, Egypt, El Salvador, Equatorial Guinea, Eritrea, Estonia,
Ethiopia, EU, Finland, France, Gabon, The Gambia, Georgia, Germany, Ghana, Greece, Guatemala, Guinea, Guinea-Bissau, Guyana,
Honduras, Hungary, Iceland, India, Indonesia, Iran, Ireland, Israel, Italy, Jamaica, Japan, Jordan, Kazakhstan, Kenya, Kiribati, North
Korea, South Korea, Kuwait, Kyrgyzstan, Latvia, Lebanon, Lesotho, Liberia, Libya, Liechtenstein, Lithuania, Luxembourg, Macedonia,
Madagascar, Malawi, Malaysia, Maldives, Mali, Malta, Marshall Islands, Mauritania, Mauritius, Mexico, Federated States of Micronesia,
Moldova, Monaco, Mongolia, Montenegro, Morocco, Mozambique, Namibia, Nauru, Nepal, Netherlands, NZ, Nicaragua, Niger, Nigeria,
Norway, Oman, Paktstan, Panama, Papua New Guinea, Paraguay, Peru, Philippines, Poland, Portugal, Qatar, Romania, Russia, Rwanda,
Saint Kitts and Nevis, Saint Lucia, Saint Vincent and the Grenadines, Samoa, Saudi Arabia, Senegal, Serbia, Seychelles, Singapore,
Slovakia, Slovenia, South Atrea, Spain, Sri Lanka, Sudan, Swaziland, Sweden, Switzerland, Syria, Tanzania, Thailand, Trinidad and
Tobago, Tunisia, Turkey, Turkmenistan, Uganda, Ukraine, UAE, UK, Uruguay, Uzbekistan, Venezuela, Vietnam, Yemen, Zambia
countries that have signed, but not yet ratified—(3) Afghanistan, Haiti, US
Biodiversity
see Convention on Biological Diversity
Climate Change
see United Nations Framework Convention on Climate Change
Climate Change-Kyoto Protocol
see Kyoto Protocol to the United Nations Framework Convention on Climate Change
856
SELECTED INTERNATIONAL ENVIRONMENTAL AGREEMENTS
Convention for the Conservation of Antarctic Seals
note—abbreviated as Antarctic Seals
opened for signature—1 June 1972
. entered into force—11 March 1978
objective—to promote and achieve the protection, scientific study, and rational use of Antarctic seals, and to maintain a satisfactory balance
within the ecological system of Antarctica
a 16) Argentina, Australia, Belgium, Brazil, Canada, Chile, France, Germany, Italy, Japan, Norway, Poland, Russia, South Africa,
countries that have signed, but not yet ratified—(1) NZ
Convention on Biological Diversity
note—abbreviated as Biodiversity
opened for signature—5 June 1992
entered into force—29 December 1993
objective—to develop national strategies for the conservation and sustainable use of biological diversity
parties—(191) Afghanistan, Albania, Algeria, Andorra, Angola, Antigua and Barbuda, Argentina, Armenia, Australia, Austria,
Azerbaijan, The Bahamas, Bahrain, Bangladesh, Barbados, Belarus, Belgium, Belize, Benin, Bhutan, Bolivia, Bosnia and Herzegovina,
Botswana, Brazil, Brunei, Bulgaria, Burkina Faso, Burma, Burundi, Cambodia, Cameroon, Canada, Cape Verde, Central African Republic,
Chad, Chile, China, Colombia, Comoros, Democratic Republic of the Congo, Republic of the Congo, Cook Islands, Costa Rica, Cote
d''Ivoire, Croatia, Cuba, Cyprus, Czech Republic, Denmark, Djibouti, Dominica, Dominican Republic, Ecuador, Egypt, El Salvador,
Equatorial Guinea, Eritrea, Estonia, Ethiopia, EU, Fiji, Finland, France, Gabon, The Gambia, Georgia, Germany, Ghana, Greece, Grenada,
Guatemala, Guinea, Guinea-Bissau, Guyana, Haiti, Honduras, Hungary, Iceland, India, Indonesia, Iran, Ireland, Israel, Italy, Jamaica,
Japan, Jordan, Kazakhstan, Kenya, Kiribati, North Korea, South Korea, Kuwait, Kyrgyzstan, Laos, Latvia, Lebanon, Lesotho, Liberia, Libya,
Liechtenstein, Lithuania, Luxembourg, Macedonia, Madagascar, Malawi, Malaysia, Maldives, Mali, Malta, Marshall Islands, Mauritania,
Mauritius, Mexico, Federated States of Micronesia, Moldova, Monaco, Mongolia, Montenegro, Morocco, Mozambique, Namibia, Nauru,
Nepat, Netherlands, NZ, Nicaragua, Niger, Nigeria, Niue, Norway, Oman, Pakistan, Palau, Panama, Papua New Guinea, Paraguay, Peru,
Philippines, Poland, Portugal, Qatar, Romania, Russia, Rwanda, Saint Kitts and Nevis, Saint Lucia, Saint Vincent and the Grenadines,
Samoa, San Marino, Sao Tome and Principe, Saudi Arabia, Senegal, Serbia, Seychelles, Sierra Leone, Singapore, Slovakia, Slovenia,
Solomon Islands, South Africa, Spain, Sri Lanka, Sudan, Suriname, Swaziland, Sweden, Switzerland, Syria, Tajikistan, Tanzania, Thailand,
Timor-Leste, Togo, Tonga, Trinidad and Tobago, Tunisia, Turkey, Turkmenistan, Tuvalu, Uganda, Ukraine, UAE, UK, Uruguay, Uzbekistan,
Vanuatu, Venezuela, Vietnam, Yemen, Zambia, Zimbabwe
countries that have signed, but not yet ratified—({1) US
Convention on Fishing and Conservation of Living Resources of the High Seas —
note—abbreviated as Marine Life Conservation r
opened for signature—29 April 1958
entered into force—20 March 1966 s
objective—to solve through international cooperation the problems involved in the conservation of living resources of the high seas, con-
sidering that because of the development of modern technology some of these resources are in danger of being overexploited
parties—(38) Australia, Belgium, Bosnia and Herzegovina, Burkina Faso, Cambodia, Colombia, Denmark, Dominican Republic, Fiji,
Finland, France, Haiti, Jamaica, Kenya, Lesotho, Madagascar, Malawi, Malaysia, Mauritius, Mexico, Montenegro, Netherlands, Nigeria,
Portugal, Senegal, Serbia, Sierra Leone, Solomon Islands, South Africa, Spain, Switzerland, Thailand, Tonga, Trinidad and Tobago, Uganda,
UK, US, Venezuela ’
countries that have signed, but not yet ratified—(21) Afghanistan, Argentina, Bolivia, Canada, Costa Rica, Cuba, Ghana, Iceland,
Indonesia, Iran, Ireland, Israel, Lebanon, Liberia, Nepal, NZ, Pakistan, Panama, Sri Lanka, Tunisia, Uruguay
Convention on Long-Range Transboundary Air Pollution
note—abbreviated as Air Pollution
opened for signature—13 November 1979
entered into force—16 March 1983 ` we.
objective—to protect the human environment against air pollution and to gradually reduce and prevent air pollution, including long-range
transboun air pollution
— oo ae Armenia, Austria, Azerbaijan, Belarus, Belgium, Bosnia and Herzegovina, Bulgaria, Canada, Croatia, Cyprus, Czech
Republic, Denmark, Estonia, EU, Finland, France, Georgia, Germany, Greece, Hungary, Iceland, Ireland, Italy, Kazakhstan, Kyrgyzstan,
Latvia, Liechtenstein, Lithuania, Luxembourg, Macedonia, Malta, Moldova, Monaco, Montenegro, Netherlands, Norway, Poland, Portugal,
Romania, Russia, Serbia, Slovakia, Slovenia, Spain, Sweden, Switzerland, Turkey, Ukraine, UK, US
countries that have signed, but not yet ratified—(2) Holy See, San Marino
Convention on Wetlands of International Importance Especially as Waterfowl Habitat (Ramsar)
note—abbreviated as Wetlands
opened for signature—2 February 1971
entered into force—21 December 1975 n i
objective—to stem the progressive encroachment on and loss of wetlands now and in the future, recognizing the fundamental ecological
functions of wetlands and their economic, cultural, scientific, and recreational value l g
parties—(154) Albania, Algeria, Antigua and Barbuda, Argentina, Armenia, Australia, Austria, Azerbaijan, The Bahamas, Bahrain,
Bangladesh, Barbados, Belarus, Belgium, Belize, Benin, Bolivia, Bosnia and Herzegovina, Botswana, Brazil, Bulgaria, Burkina Faso, Burma,
Bürundi, Cambodia, Cameroon, Canada, Cape Verde, Central African Republic, Chad, Chile, China, Colombia, Comoros, Democratic
Republic of the Congo, Republic of the Congo, Costa Rica, Cote d''Ivoire, Croatia, Cuba, Cyprus, Czech Republic, Denmark, Djibouti,
Dominican Republic, Ecuador, Egypt, El Salvador, Equatorial Guinea, Estonia, Fiji, Finland, France, Gabon, The Gambia, Georgia,
Germany, Ghana, Greece, Guatemala, Guinea, Guinea-Bissau, Honduras, Hungary, Iceland, India, Indonesia, Iran, Ireland, Israel, Italy,
Jamaica, Japan, Jordan, Kazakhstan, Kenya, South Korea, Kyrgyzstan, Latvia, Lebanon, Lesotho, Liberia, Libya, Liechtenstein, Lithuania,
Luxembourg, Macedonia, Madagascar, Malawi, Malaysia, Mali, Malta, Marshall Islands, Mauritania, Mauritius, Mexico, Moldova, Monaco,
Mongolia, Morocco, Mozambique, Namibia, Nepal, Netherlands, NZ, Nicaragua, Niger, Nigeria, Norway, Pakistan, Palau, Panama, Papua
857
THE CIA WORLD FACTBOOK
New Guinea, Paraguay, Peru, Philippines, Poland, Portugal, Romania, Russia, Rwanda, Saint Lucia, Samoa, Sao Tome and Principe,
Senegal, Serbia, Seychelles, Sierra Leone, Slovakia, Slovenia, South Africa, Spain, Sri Lanka, Sudan, Suriname, Sweden, Switzerland, Syria,
Tanzania, Tajikistan, Thailand, Togo, Trinidad and Tobago, Tunisia, Turkey, Uganda, Ukraine, UK, US, Uruguay, Uzbekistan, Venezuela,
Vietnam, Zambia : : 3
Convention on the Conservation of Antarctic Marine Living Resources
note—abbreviated as Antarctic-Marine Living Resources
opened for signature—5 May 1980
entered into force—7 April 1982
objective—to safeguard the environment and protect the integrity of the ecosystem of the seas surrounding Antarctica, and to conserve
Antarctic marine living resources
parties—(31) Argentina, Australia, Belgium, Brazil, Bulgaria, Canada, Chile, EU, Finland, France, Germany, Greece, India, Italy, Japan,
South Korea, Mauritius, Namibia, Netherlands, NZ, Norway, Peru, Poland, Russia, South Africa, Spain, Sweden, Ukraine, UK, US,
Uruguay, Vanuatu l
Convention on the International Trade in Endangered Species of Wild Flora and Fauna (CITES)
note—abbreviated as Endangered Species
opened for signature—3 March 1973
entered into force—I July 1975
objective—to protect certain endangered species from overexploitation by means of a system of import/export permits
parties—(170) Afghanistan, Albania, Algeria, Antigua and Barbuda, Argentina, Australia, Austria, Azerbaijan, The Bahamas,
Bangladesh, Barbados, Belarus, Belgium, Belize, Benin, Bhutan, Bolivia, Botswana, Brazil, Brunei, Bulgaria, Burkina Faso, Burma,
Burundi, Cambodia, Cameroon, Canada, Cape Verde, Central African Republic, Chad, Chile, China, Colombia, Comoros, Democratic
Republic of the Congo, Republic of the Congo, Costa Rica, Cote d''Ivoire, Croatia, Cuba, Cyprus, Czech Republic, Denmark, Djibouti,
Dominica, Dominican Republic, Ecuador, Egypt, El Salvador, Equatorial Guinea, Eritrea, Estonia, Ethiopia, Fiji, Finland, France, Gabon,
The Gambia, Georgia, Germany, Ghana, Greece, Grenada, Guatemala, Guinea, Guinea-Bissau, Guyana, Honduras, Hungary, Iceland,
India, Indonesia, Iran, Ireland, Israel, Italy, Jamaica, Japan, Jordan, Kazakhstan, Kenya, South Korea, Kuwait, Laos, Latvia, Lesotho,
Liberia, Libya, Liechtenstein, Lithuania, Luxembourg, Macedonia, Madagascar, Malawi, Malaysia, Mali, Malta, Mauritania, Mauritius,
Mexico, Moldova, Monaco, Mongolia, Montenegro, Morocco, Mozambique, Namibia, Nepal, Netherlands, NZ, Nicaragua, Niger,
Nigeria, Norway, Palau, Pakistan, Panama, Papua New Guinea, Paraguay, Peru, Philippines, Poland, Portugal, Qatar, Romania, Russia,
Rwanda, Saint Kitts and Nevis, Saint Lucia, Saint Vincent and the Grenadines, Samoa, San Marino, Sao Tome and Principe, Saudi
Arabia, Senegal, Serbia, Seychelles, Sierra Leone, Singapore, Slovakia, Slovenia, Somalia, South Africa, Spain, Sri Lanka, Sudan,
Suriname, Swaziland, Sweden, Switzerland, Syria, Tanzania, Thailand, Togo, Trinidad and Tobago, Tunisia, Turkey, Uganda, Ukraine,
UAE, UK, US, Uruguay, Uzbekistan, Vanuatu, Venezuela, Vietnam, Yemen, Zambia, Zimbabwe
Convention on the Prevention of Marine Pollution by Dumping Wastes and Other Matter (London Convention)
note—abbreviated as Marine Dumping
opened for signature—29 December 1972
entered into force—30 August 1975
objective—to control pollution of the sea by dumping and to encourage regional agreements supplementary to the Convention; the London
Convention came into force in 1996
parties—(88) Afghanistan, Angola, Antigua and Barbuda, Argentina, Australia, Azerbaijan, Barbados, Belarus, Belgium, Bolivia, Brazil,
Bulgaria, Canada, Cape Verde, Chile, China, Democratic Republic of the Congo, Costa Rica, Cote d''lvoire, Croatia, Cuba, Cyprus,
Denmark, Dominican Republic, Egypt, Equatorial Guinea, Finland, France, Gabon, Germany, Greece, Guatemala, Haiti, Honduras, Hong
Kong (associate member), Hungary, Iceland, Iran, Ireland, Italy, Jamaica, Japan, Jordan, Kenya, Kiribati, South Korea, Libya, Luxembourg,
Malta, Mexico, Monaco, Montenegro, Morocco, Nauru, Netherlands, NZ, Nigeria, Norway, Oman, Pakistan, Panama, Papua New Guinea,
Peru, Philippines, Poland, Portugal, Russia, Saint Kitts and Nevis, Saint Lucia, Saint Vincent and the Grenadines, Saudi Arabia, Serbia,
Seychelles, Slovenia, Solomon Islands, South Africa, Spain, Suriname, Sweden, Switzerland, Tonga, Trinidad and Tobago, Tunisia, Ukraine,
UAE, UK, US, Vanuatu
associate members to the London Convention—(2) Faroe Islands, Macau
countries that have signed, but not yet ratified—(3) Chad, Kuwait, Uruguay
Convention on the Prohibition of Military or Any Other Hostile Use of Environmental Modification Techniques
note—abbreviated as Environmental Modification
opened for signature—10 December 1976
entered into force—5 October 1978 i =
objective—to prohibit the military or other hostile use of environmental modification techniques in order to further world peace and trust
among nations
parties—(73) Afghanistan, Algeria, Antigua and Barbuda, Argentina, Armenia, Australia, Austria, Bangladesh, Belarus, Belgium, Benin,
Brazil, Bulgaria, Canada, Cape Verde, Chile, China, Costa Rica, Cuba, Cyprus, Czech Republic, Denmark, Dominica, Egypt, Finland,
Germany, Ghana, Greece, Guatemala, Hungary, India, Ireland, Italy, Japan, Kazakhstan, North Korea, South Korea, Kuwait, Laos,
Lithuania, Malawi, Mauritius, Mongolia, Netherlands, NZ, Nicaragua, Niger, Norway, Pakistan, Panama, Papua New Guinea, Poland,
Romania, Russia, Saint Lucia, Saint Vincent and the Grenadines, Sao Tome and Principe, Slovakia, Slovenia, Solomon Islands, Spain, Sri
Lanka, Sweden, Switzerland, Tajikistan, Tunisia, Ukraine, UK, US, Uruguay, Uzbekistan, Vietnam, Yemen
countries that have signed, but not yet ratified—(16) Bolivia, Democratic Republic of the Congo, Ethiopia, Holy See, Iceland, Iran, Iraq,
Lebanon, Liberia, Luxembourg, Morocco, Portugal, Sierra Leone, Syria, Turkey, Uganda
Desertification
see United Nations Convention to Combat Desertification in those Countries Experiencing Serious Drought and/or Desertification, Par-
ticularly in Africa
Endangered Species
see Convention on the International Trade in Endangered Species of Wild Flora and Fauna (CITES)
858
SELECTED INTERNATIONAL ENVIRONMENTAL AGREEMENTS
Environmental Modification
see Convention on the Prohibition of Military or Any Other Hostile Use of Environmental Modification Techniques
Hazardous Wastes 3
see Basel Convention on the Contro! of Transboundary Movements of Hazardous Wastes and Their Disposal
international Convention for the Regulation of Whaling
note—abbreviated as Whaling
opened for signature—2 December 1946
entered into force—10 November 1948
objective—to protect all species of whales from overhunting; to establish a system of international regulation for the whale fisheries to
ensure proper conservation and development of whale stocks; and to safeguard for future generations the great natural resources represented
by whale stocks
parties—(84) Antigua and Barbuda, Argentina, Australia, Austria, Belgium, Belize, Benin, Brazil, Cambodia, Cameroon, Chile, China,
Republic of the Congo, Costa Rica, Cote D''Ivoire, Croatia, Cyprus, Czech Republic, Denmark, Dominica, Ecuador, Eritrea, Estonia,
Finland, France, Gabon, The Gambia, Germany, Greece, Grenada, Guatemala, Guinea, Guinea-Bissau, Hungary, Iceland, India, Ireland,
Israel, Italy, Japan, Kenya, Kiribati, South Korea, Laos, Lithuania, Luxembourg, Mali, Marshall Islands, Mauritania, Mexico, Monaco,
Mongolia, Morocco, Nauru, Netherlands, NZ, Nicaragua, Norway, Oman, Palau, Panama, Peru, Portugal, Romania, Russia, Saint Kitts and
Nevis, Saint Lucia, Saint Vincent and the Grenadines, San Marino, Senegal, Slovakia, Slovenia, Solomon Islands, South Africa, Spain,
Suriname, Sweden, Switzerland, Tanzania, Togo, Tuvalu, UK, US, Uruguay :
International Tropical Timber Agreement, 1983
note—abbreviated as Tropical Timber 83
opened for signature—18 November 1983
entered into force—1 April 1985; this agreement expired when the International Tropical Timber Agreement, 1994, went into force
objective—to provide an effective framework for cooperation between tropical timber producers and consumers and to encourage the devel-
opment of national policies aimed at sustainable utilization and conservation of tropical forests and their genetic resources
parties—(59) Australia, Austria, Belgium, Bolivia, Brazil, Burma, Cambodia, Cameroon, Canada, Central African Republic, China,
Colombia, Democratic Republic of the Congo, Republic of the Congo, Cote d''Ivoire, Denmark, Ecuador, Egypt, EU, Fiji, Finland, France,
Gabon, Germany, Ghana, Greece, Guatemala, Guyana, Honduras, India, Indonesia, Ireland, Italy, Japan, South Korea, Liberia, Luxembourg,
Malaysia, Mexico, Nepal, Netherlands, NZ, Nigeria, Norway, Panama, Papua New Guinea, Peru, Philippines, Portugal, Russia, Spain,
Suriname, Sweden, Switzerland, Thailand, Togo, Trinidad and Tobago, UK, US, Vanuatu, Venezuela
international Tropica! Timber Agreement, 1994
note—abbreviated as Tropical Timber 94
opened for signature—26 January 1994
entered into force—1 January 1997
objective—to ensure that by the year 2000 exports of tropical timber originate from sustainably managed sources; to establish a fund to assist
tropical timber producers in obtaining the resources necessary to reach this objective
parties—(61) Australia, Austria, Belgium, Bolivia, Brazil, Burma, Cambodia, Cameroon, Canada, Central African Republic, China,
Colombia, Democratic Republic of the Congo, Republic of the Congo, Cote d''lvoire, Denmark, Ecuador, Egypt, EU, Fiji, Finland, France,
Gabon, Germany, Ghana, Greece, Guatemala, Guyana, Honduras, India, Indonesia, Ireland, Italy, Japan, South Korea, Liberia, Luxembourg,
Malaysia, Mexico, Nepal, Netherlands, NZ, Nigeria, Norway, Panama, Papua New Guinea, Peru, Philippines, Poland, Portugal, Spain,
Suriname, Sweden, Switzerland, Thailand, Togo, Trinidad and Tobago, UK, US, Vanuatu, Venezuela
Kyoto Protocol to the United Nations Framework Convention on Climate Change
note—abbreviated as Climate Change-Kyoto Protocol
opened for signature—16 March 1998
entered into force—23 February 2005
objective—to further reduce greenhouse gas emissions by enhancing the national programs of developed countries aimed at this goal and by
establishing percentage reduction targets for the developed countries
parties—(184) Albania, Algeria, Angola, Antigua and Barbuda, Argentina, Armenia, Australia, Austria, Azerbaijan, The Bahamas,
Bahrain, Bangladesh, Barbados, Belarus, Belgium, Belize, Benin, Bhutan, Bolivia, Bosnia and Herzegovina, Botswana, Brazil, Bulgaria,
Burkina Faso, Burma, Burundi, Cambodia, Cameroon, Cape Verde, Central African Republic, Chile, China, Colombia, Comoros,
Democratic Republic of the Congo, Republic of the Congo, Cook Island, Costa Rica, Cote d''Ivoire, Croatia, Cuba, Cyprus, Czech
Republic, Denmark, Djibouti, Dominica, Dominican Republic, Ecuador, Egypt, El Salvador, Equatorial Guinea, Eritrea, Estonia,
Ethiopia, EU, Fiji, Finland, France, Gabon, The Gambia, Georgia, Germany, Ghana, Greece, Grenada, Guatemala, Guinea, Guinea-
Bissau, Guyana, Haiti, Honduras, Hungary, Iceland, India, Indonesia, Iran, Ireland, Israel, Italy, Jamaica, Japan, Jordan, Kenya, Kiribati,
North Korea, South Korea, Kuwait, Kyrgyzstan, Laos, Latvia, Lebanon, Lesotho, Liberia, Libya, Liechtenstein, Lithuania, Luxembourg,
Macedonia, Madagascar, Malawi, Malaysia, Maldives, Mali, Malta, Marshall Islands, Mauritania, Mauritius, Mexico, Federated States of
Micronesia, Moldova, Monaco, Mongolia, Montenegro, Morocco, Mozambique, Namibia, Nauru, Nepal, Netherlands, NZ, Nicaragua,
Niger, Nigeria, Niue, Norway, Oman, Pakistan, Palau, Panama, Papua New Guinea, Paraguay, Peru, Philippines, Poland, Portugal, Qatar,
Romania, Russia, Rwanda, Saint Kitts and Nevis, Saint Lucia, Saint Vincent and the Grenadines, Samoa, Sao Tome and Principe,
Saudi Arabia, Senegal, Serbia, Seychelles, Sierra Leone, Singapore, Slovakia, Slovenia, Solomon Islands, South Africa, Spain, Sri Lanka,
Sudan, Suriname, Swaziland, Sweden, Switzerland, Syria, Tajikistan, Tanzania, Thailand, Timor-Leste, Togo, Tonga, Trinidad and Tobago,
Tunisia, Turkmenistan, Tuvalu, Uganda, Ukraine, UAE, UK, Uruguay, Uzbekistan, Vanuatu, Venezuela, Vietnam, Yemen, Zambia
countries that have signed, but not yet ratified (2) Kazakhstan, US
Law of the Sea
see United Nations Convention on the Law of the S','f0ef7b56110e822a7e0aaac4d78e8fb4b238722f1b8ed898bd3495a9e060c576','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('28c663ea23c356d3b5a7a487f560bdabcd1da2cd4317d105df85cd7ab2110a74',2025,'VC','Saint Vincent and the Grenadines','environment',1739,'ea (LOS)
Marine Dumping A :
see Convention on the Prevention of Marine Pollution by Dumping Wastes and Other Matter (London Convention)
859
THE CIA WORLD FACTBOOK
Marine Life Conservation
see Convention on Fishing and Conservation of Living Resources of the High Seas
Montreal Protocol on Substances That Deplete the Ozone Layer
note—abbreviated as Ozone Layer Protection
opened for signature—16 September 1987
entered into force—i January 1989
objective—to protect the ozone layer by controlling emissions of substances that deplete it
parties—(194) Afghanistan, Albania, Algeria, Andorra, Angola, Antigua and Barbuda, Argentina, Armenia, Australia,
Austria, Azerbaijan, The Bahamas, Bahrain, Bangladesh, Barbados, Belarus, Belgium, Belize, Benin, Bhutan, Bolivia, Bosnia and
Herzegovina, Botswana, Brazil, Brunei, Bulgaria, Burkina Faso, Burma, Burundi, Cambodia, Cameroon, Canada, Cape Verde,
Central African Republic, Chad, Chile, China, Colombia, Comoros, Democratic Republic of the Congo, Republic of the Congo,
Cook Islands, Costa Rica, Cote d''Ivoire, Croatia, Cuba, Cyprus, Czech Republic, Denmark, Djibouti, Dominica, Dominican
Republic, Ecuador, Egypt, El Salvador, Equatorial Guinea, Eritrea, Estonia, Ethiopia, EU, Fiji, Finland, France, Gabon, The
Gambia, Georgia, Germany, Ghana, Greece, Grenada, Guatemala, Guinea, Guinea-Bissau, Guyana, Haiti, Holy See, Honduras,
Hungary, Iceland, India, Indonesia, Iran, Iraq, Ireland, Israel, Italy, Jamaica, Japan, Jordan, Kazakhstan, Kenya, Kiribati, North
Korea, South Korea, Kuwait, Kyrgyzstan, Laos, Latvia, Lebanon, Lesotho, Liberia, Libya, Liechtenstein, Lithuania, Luxembourg,
Macedonia, Madagascar, Malawi, Malaysia, Maldives, Mali, Malta, Marshall Islands, Mauritania, Mauritius, Mexico, Federated
States of Micronesia, Moldova, Monaco, Mongolia, Montenegro, Morocco, Mozambique, Namibia, Nauru, Nepal, Netherlands,
NZ, Nicaragua, Niger, Nigeria, Niue, Norway, Oman, Pakistan, Palau, Panama, Papua New Guinea, Paraguay, Peru, Philippines,
Poland, Portugal, Qatar, Romania, Russia, Rwanda, Saint Kitts and Nevis, Saint Lucia, Saint Vincent and the Grenadines,
Samoa, Sao Tome and Principe, Saudi Arabia, Senegal, Serbia, Seychelles, Sierra Leone, Singapore, Slovakia, Slovenia, Solomon
Islands, Somalia, South Africa, Spain, Sri Lanka, Sudan, Suriname, Swaziland, Sweden, Switzerland, Syria, Tajikistan, Tanzania,
Thailand, Togo, Tonga, Trinidad and Tobago, Tunisia, Turkey, Turkmenistan, Tuvalu, Uganda, Ukraine, UAE, UK, US, Uruguay,
Uzbekistan, Vanuatu, Venezuela, Vietnam, Yemen, Zambia, Zimbabwe
Nuclear Test Ban
see Treaty Banning Nuclear Weapons Tests in the Atmosphere, in Outer Space, and Under Water
Ozone Layer Protection
see Montreal Protocol on Substances That Deplete the Ozone Layer
Protocol of 1978 Relating to the International Convention for the Prevention of Pollution From Ships, 1973 (MARPOL)
note—abbreviated as Ship Pollution
opened for signature—17 February 1978
entered into force—2 October 1983
objective—to preserve the marine environment through the complete elimination of pollution by oil and other harmful substances and the
minimization of accidental discharge of such substances i i :
parties—(139) Algeria, Angola, Antigua and Barbuda, Argentina, Australia, Austria, Azerbaijan, The Bahamas, Bangladesh, Barbados,
Belarus, Belgium, Belize, Benin, Bolivia, Brazil, Brunei, Bulgaria, Burma, Cambodia, Canada, Cape Verde, Chile, China, Colom-
bia, Comoros, Republic of Congo, Cote d''Ivoire, Croatia, Cuba, Cyprus, Czech Republic, Denmark, Djibouti, Dominica, Dominican
Republic, Ecuador, Egypt, Equatorial Guinea, Estonia, Faroe Islands, Finland, France, Gabon, The Gambia, Georgia, Germany, Ghana,
Greece, Guatemala, Guinea, Guyana, Honduras, Hong Kong, Hungary, Iceland, India, Indonesia, Iran, Ireland, Israel, Italy, Jamaica,
Japan, Kazakhstan, Kenya, North Korea, South Korea, Latvia, Lebanon, Liberia, Lithuania, Luxembourg, Libya, Macau, Madagascar,
Malawi, Malaysia, Maldives, Malta, Marshall Islands, Mauritania, Mauritius, Mexico, Moldova, Monaco, Mongolia, Montenegro,
Morocco, Mozambique, Netherlands, NZ, Nicaragua, Nigeria, Norway, Oman, Pakistan, Panama, Papua New Guinea, Peru, Philippines,
Poland, Portugal, Qatar Romania, Russia, Saint Kitts and Nevis, Saint Lucia, Saint Vincent and the Grenadines, Samoa, Sao Tome
and Principe, Saudi Arabia, Senegal, Serbia, Seychelles, Sierra Leone, Singapore, Slovakia, Slovenia, South Africa, Spain, Sri Lanka,
Suriname, Sweden, Switzerland, Syria, Togo, Tonga, Trinidad and Tobago, Tunisia, Turkey, Tuvalu, Ukraine, UK, US, Uruguay, Vanuatu,
Venezuela, Vietnam
Protocol on Environmental Protection to the Antarctic Treaty
note—abbreviated as Antarctic-Environmental Protocol
opened for signature—4 October 1991
entered into force—14 January 1998
objective—to provide for comprehensive protection of the Antarctic environment and dependent and associated ecosystems; applies to the
area covered by the Antarctic Treaty
consultative parties—(31) Argentina, Australia, Belgium, Brazil, Bulgaria, Canada, Chile, China, Czech Republic, Ecuador, Finland,
France, Germany, India, Italy, Japan, South Korea, Netherlands, NZ, Norway, Peru, Poland, Romania, Russia, South Africa, Spain, Sweden,
Ukraine, UK, US, Uruguay i
non consultative parties—(12) Austria, Colombia, Cuba, Denmark, Greece, Guatemala, Hungary, North Korea, Papua New Guinea,
Slovakia, Switzerland, Turkey :
Protocol to the 1979 Convention on Long-Range Transboundary Air Pollution Concerning the Control of Emissions of Nitrogen
Oxides or Their Transboundary Fluxes
note—abbreviated as Air Pollution-Nitrogen Oxides
opened for signature—31 October 1988
entered into force—14 February 1991 :
objective—to provide for the control or reduction of nitrogen oxides and their transboundary fluxes
parties—(32) Austria, Belarus, Belgium, Bulgaria, Canada, Croatia, Cyprus, Czech Republic, Denmark, Estonia, EU, Finland, France,
Germany, Greece, Hungary, Ireland, Italy, Liechtenstein, Lithuania, Luxembourg, Netherlands, Norway, Russia, Slovakia, Slovenia, Spain,
Sweden, Switzerland, Ukraine, UK, US
countries that have signed, but not yet ratified—(1) Poland
860
SELECTED INTERNATIONAL ENVIRONMENTAL AGREEMENTS
Protocol to the 1979 Convention on Long-Range Transboundary Air Pollution Concerning the Control of Emissions of Volatile
Organic Compounds or Their Transboundary Fluxes
note—abbreviated as Air Pollution- Volatile Organic Compounds
opened for signature—18 November 1991
entered into force—29 September 1997
objective—to provide for the control and reduction of emissions of volatile organic compounds in order to reduce their transboundary fluxes
so as to protect human health and the environment from adverse effects
parttes—(23) Austria, Belgium, Bulgaria, Croatia, Czech Republic, Denmark, Estonia, Finland, France, Germany, Hungary, Italy, `
Liechtenstein, Lithuania, Luxembourg, Monaco, Netherlands, Norway, Slovakia, Spain, Sweden, Switzerland, UK
countries that have signed, but not yet ratified—(6) Canada, EU, Greece, Portugal, Ukraine, US
Protocol to the 1979 Convention on Long-Range Transboundary Air Pollution on Further Reduction of Sulphur Emissions
note—abbreviated as Air Pollution-Sulphur 94
opened for signature—14 June 1994
entered into force—5 August 1998
objective—to provide for a further reduction in sulfur emissions or transboundary fluxes
parties—(28) Austria, Belgium, Bulgaria, Canada, Croatia, Cyprus, Czech Republic, Denmark, EU, Finland, France, Germany, Greece,
Hungary, Ireland, Italy, Liechtenstein, Lithuania, Luxembourg, Monaco, Netherlands, Norway, Slovakia, Slovenia, Spain, Sweden,
Switzerland, UK
countries that have signed, but not yet ratified—(3) Poland, Russia, Ukraine
Protocol to the 1979 Convention on Long-Range Transboundary Air Pollution on Persistent Organic Pollutants
note—abbreviated as Air Pollution-Persistent Organic Pollutants
opened for signature—24 June 1998
entered into force—23 October 2003
objective—to provide for the control and reduction of emissions of persistent organic pollutants in order to reduce their transboundary
fluxes so as to protect human health and the environment from adverse effects
parties—(29) Austria, Belgium, Bulgaria, Canada, Croatia, Cyprus, Czech Republic, Denmark, Estonia, EU, Finland, France, Germany,
Hungary, Iceland, Italy, Latvia, Liechtenstein, Lithuania, Luxembourg, Moldova, Netherlands, Norway, Romania, Slovakia, Slovenia,
Sweden, Switzerland, UK
countries that have signed, but not yet ratified —(8) Armenia, Greece, Ireland, Poland, Portugal, Spain, Ukraine, US
Protocol to the 1979 Convention on Long-Range Transboundary Air Pollution on the Reduction of Sulphur Emissions or Their
Transboundary Fluxes by at Least 30%
note—abbreviated as Air Pollution-Sulphur 85
opened for signature—8 July 1985
entered into force—2 September 1987
objective—to provide for a 30% reduction in sulfur emissions or transboundary fluxes by 1993
parties—(23) Austria, Belarus, Belgium, Bulgaria, Canada, Czech Republic, Denmark, Estonia, Finland, France, Germany, Hungary, Italy,
Liechtenstein, Lithuania, Luxembourg, Netherlands, Norway, Russia, Slovakia, Sweden, Switzerland, Ukraine
Ship Pollution
see Protocol of 1978 Relating to the International Convention for the Prevention of Pollution From Ships, 1973 (MARPOL)
Treaty Banning Nuclear Weapon Tests in the Atmosphere, in Outer Space, and Under Water
note—abbreviated as Nuclear Test Ban
opened for signature—5 August 1963
entered into force—10 October 1963
objective—to obtain an agreement on general and complete disarmament under strict international control in accordance with the objec-
tives of the United Nations; to put an end to the armaments race and eliminate incentives for the production and testing of all kinds of
weapons, including nuclear weapons ; À
parties—(113) Afghanistan, Antigua and Barbuda, Argentina, Armenia, Australia, Austria, The Bahamas, Bangladesh, Belgium, Benin,
Bhutan, Bolivia, Bosnia and Herzegovina, Botswana, Brazil, Bulgaria, Burma, Canada, Central African Republic, Chad, China, Colombia,
Democratic Republic of the Congo, Costa Rica, Cote d''Ivoire, Croatia, Cyprus, Czech Republic, Denmark, Dominican Republic, Ecuador,
Egypt, El Salvador, Fiji, Finland, Gabon, The Gambia, Germany, Ghana, Greece, Guatemala, Honduras, Hungary, Iceland, India, Indonesia,
Iran, Iraq, Ireland, Israel, Italy, Jamaica, Japan, Jordan, Kenya, South Korea, Kuwait, Laos, Lebanon, Liberia, Luxembourg, Madagascar,
Malawi, Malaysia, Malta, Mauritania, Mauritius, Mexico, Morocco, Nepal, Netherlands, NZ, Nicaragua, Niger, Nigeria, Norway, Panama,
Papua New Guinea, Peru, Philippines, Poland, Romania, Russia, Rwanda, Samoa, San Marino, Senegal, Serbia, Seychelles, Sierra Leone,
Singapore, Slovakia, Slovenia, South Africa, Spain, Sri Lanka, Sudan, Suriname, Swaziland, Sweden, Switzerland, Syria, Thailand, Togo,
Tonga, Trinidad and Tobago, Tunisia, Turkey, Uganda, UK, US, Venezuela, Zambia '' cats ma
countries that have signed, but not yet ratified—(17) Algeria, Burkina Faso, Burundi, Cameroon, Chile, Ethiopia, Haiti, Libya, Mali,
Pakistan, Paraguay, Portugal, Somalia, Tanzania, Uruguay, Vietnam, Yemen
Tropical Timber 83
see International Tropical Timber Agreement, 1983
Tropical Timber 94
see International Tropical Timber Agreement, 1994
United Nations Convention on the Law of the Sea (LOS)
note—abbreviated as Law of the Sea
opened for signature—10 December 1982
entered into force—16 November 1994
a
861
THE CIA WORLD FACTBOOK
objective—to set up a comprehensive new legal regime for the sea and oceans; to include rules concerning environmental standards as well
as enforcement provisions dealing with pollution of the marine environment
parties—(157) Albania, Algeria, Angola, Antigua and Barbuda, Argentina, Armenia, Australia, Austria, The Bahamas, Bahrain,
Bangladesh, Barbados, Belarus, Belgium, Belize, Benin, Bolivia, Bosnia and Herzegovina, Botswana, Brazil, Brunei, Bulgaria, Burkina Faso,
Burma, Cameroon, Canada, Cape Verde, Chile, China, Comoros, Democratic Republic of the Congo, Republic of the Congo, Cook Islands,
Costa Rica, Cote d''Ivoire, Croatia, Cuba, Cyprus, Czech Republic, Denmark, Djihouti, Dominica, Egypt, Equatorial Guinea, Estonia, EU,
Fiji, Finland, France, Gabon, The Gambia, Georgia, Germany, Ghana, Greece, Grenada, Guatemala, Guinea, Guinea-Bissau, Guyana, Haiti,
Honduras, Hungary, Iceland, India, Indonesia, Iraq, Ireland, Italy, Jamaica, Japan, Jordan, Kenya, Kiribati, South Korea, Kuwait, Laos, Lat-
via, Lebanon, Lesotho, Liberia, Lithuania, Luxembourg, Macedonia, Madagascar, Malaysia, Maldives, Mali, Malta, Marshall Islands, Mau-
titania, Mauritius, Mexico, Federated States of Micronesia, Moldova, Monaco, Mongolia, Montenegro, Morocco, Mozambique, Namibia,
Nauru, Nepal, Netherlands, NZ, Nicaragua, Nigeria, Niue, Norway, Oman, Pakistan, Palau, Panama, Papua New Guinea, Paraguay, Philip-
pines, Poland, Portugal, Qatar, Romania, Russia, Saint Kitts and Nevis, Saint Lucia, Saint Vincent and the Grenadines, Samoa, Sao Tome
and Principe, Saudi Arabia, Senegal, Serbia, Seychelles, Sierra Leone, Singapore, Slovakia, Slovenia, Solomon Islands, Somalia, South
Africa, Spain, Sri Lanka, Sudan, Suriname, Sweden, Tanzania, Togo, Tonga, Trinidad and Tobago, Tunisia, Tuvalu, Uganda, Ukraine, UK,
Uruguay, Vanuatu, Vietnam, Yemen, Zambia, Zimbabwe
countries that have signed, but not yet ratified—(21) Afghanistan, Bhutan, Burundi, Cambodia, Central African Republic, Chad,
Colombia, Dominican Republic, El Salvador, Ethiopia, Iran, North Korea, Libya, Liechtenstein, Malawi, Niger, Rwanda, Swaziland,
Switzerland, Thailand, UAE
United Nations Convention to Combat Desertification in Those Countries Experiencing Serious Drought and/or Desertification,
Particularly in Africa
note—abbreviated as Desertification
opened for signature—14 October 1994
entered into force—26 December 1996 :
objective—to combat desertification and mitigate the effects of drought through national action programs that incorporate long-term strate-
gies supported by international cooperation and partnership arrangements
parttes—(193) Afghanistan, Albania, Algeria, Andorra, Angola, Antigua and Barbuda, Argentina, Armenia, Australia, Austria,
Azerbaijan, The Bahamas, Bahrain, Bangladesh, Barbados, Belarus, Belgium, Belize, Benin, Bhutan, Bolivia, Bosnia and Herzegovina,
Botswana, Brazil, Brunei, Bulgaria, Burkina Faso, Burma, Burundi, Cambodia, Cameroon, Canada, Cape Verde, Central African
Republic, Chad, Chile, China, Colombia, Comoros, Democratic Republic of the Congo, Republic of the Congo, Cook Islands,
Costa Rica, Cote d''Ivoire, Croatia, Cuba, Cyprus, Czech Republic, Denmark, Djibouti, Dominica, Dominican Republic, Ecuador,
Egypt, El Salvador, Equatorial Guinea, Eritrea, Ethiopia, EU, Fiji, Finland, France, Gabon, The Gambia, Georgia, Germany, Ghana,
Greece, Grenada, Guatemala, Guinea, Guinea-Bissau, Guyana, Haiti, Honduras, Hungary, Iceland, India, Indonesia, Iran, Ireland,
Israel, Italy, Jamaica, Japan, Jordan, Kazakhstan, Kenya, Kiribati, North Korea, South Korea, Kuwait, Kyrgyzstan, Laos, Latvia, Leba-
non, Lesotho, Liberia, Libya, Liechtenstein, Lithuania, Luxembourg, Macedonia, Madagascar, Malawi, Malaysia, Maldives, Mali,
Malta, Marshall Islands, Mauritania, Mauritius, Mexico, Federated States of Micronesia, Moldova, Monaco, Mongolia, Montenegro,
Morocco, Mozambique, Namibia, Nauru, Nepal, Netherlands, NZ, Nicaragua, Niger, Nigeria, Niue, Norway, Oman, Pakistan, Palau,
Panama, Papua New Guinea, Paraguay, Peru, Philippines, Poland, Portugal, Qatar, Romania, Russia, Rwanda, Saint Kitts and Nevis,
Saint Lucia, Saint Vincent and the Grenadines, Samoa, San Marino, Sao Tome and Principe, Saudi Arabia, Senegal, Serbia, Sey-
chelles, Sierra Leone, Singapore, Slovakia, Slovenia, Solomon Islands, Somalia, South Africa, Spain, Sri Lanka, Sudan, Suriname,
Swaziland, Sweden, Switzerland, Syria, Tajikistan, Thailand, Tanzania, Timor-Leste, Togo, Tonga, Trinidad and Tobago, Tunisia,
Turkey, Turkmenistan, Tuvalu, Uganda, Ukraine, UAE, UK, US, Uruguay, Uzbekistan, Vanuatu, Venezuela, Vietnam, Yemen, Zam-
bia, Zimbabwe
United Nations Framework Convention on Climate Change
note—abbreviated as Climate Change
opened for signature—9 May 1992
entered into force—21 March 1994 :
objective—to achieve stabilization of greenhouse gas concentrations in the atmosphere at a low enough level to prevent dangerous anthro-
pogenic interference with the climate system
parties—(192) Afghanistan, Albania, Algeria, Angola, Antigua and Barbuda, Argentina, Armenia, Australia, Austria, Azerbaijan, The
Bahamas, Bahrain, Bangladesh, Barbados, Belarus, Belgium, Belize, Benin, Bhutan, Bolivia, Bosnia and Herzegovina, Botswana, Brazil,
Brunei, Bulgaria, Burkina Faso, Burma, Burundi, Cambodia, Cameroon, Canada, Cape Verde, Central African Republic, Chad, Chile, China,
Colombia, Comoros, Democratic Republic of the Congo, Republic of the Congo, Cook Islands, Costa Rica, Cote d''lvoire, Croatia, Cuba,
Cyprus, Czech Republic, Denmark, Djibouti, Dominica, Dominican Republic, Ecuador, Egypt, El Salvador, Equatorial Guinea, Eritrea, Esto-
nia, Ethiopia, EU, Fiji, Finland, France, Gabon, The Gambia, Georgia, Germany, Ghana, Greece, Grenada, Guatemala, Guinea, Guinea-
Bissau, Guyana, Haiti, Honduras, Hungary, Iceland, India, Indonesia, Iran, Ireland, Israel, Italy, Jamaica, Japan, Jordan, Kazakhstan, Kenya,
Kiribati, North Korea, South Korea, Kuwait, Kyrgyzstan, Laos, Latvia, Lebanon, Lesotho, Liberia, Libya, Liechtenstein, Lithuania, Luxem-
bourg, Macedonia, Madagascar, Malawi, Malaysia, Maldives, Mali, Malta, Marshall Islands, Mauritania, Mauritius, Mexico, Federated States
of Micronesia, Moldova, Monaco, Mongolia, Montenegro, Morocco, Mozambique, Namibia, Nauru, Nepal, Netherlands, NZ, Nicaragua,
Niger, Nigeria, Niue, Norway, Oman, Pakistan, Palau, Panama, Papua New Guinea, Paraguay, Peru, Philippines, Poland, Portugal, Qatar,
Romania, Russia, Rwanda, Saint Kitts and Nevis, Saint Lucia, Saint Vincent and the Grenadines, Samoa, San Marino, Sao Tome and
Principe, Saudi Arabia, Senegal, Serbia, Seychelles, Sierra Leone, Singapore, Slovakia, Slovenia, Solomon Islands, South Africa, Spain,
Sri Lanka, Sudan, Suriname, Swaziland, Sweden, Switzerland, Syria, Tajikistan, Tanzania, Thailand, Timor-Leste, Togo, Tonga, Trinidad
and Tobago, Tunisia, Turkey, Turkmenistan, Tuvalu, Uganda, Ukraine, UAE, UK, US, Uruguay, Uzbekistan, Vanuatu, Venezuela, Vietnam,
Yemen, Zambia, Zimbabwe
Wetlands
see Convention on Wetlands of International Importance Especially As Waterfowl Habitat (Ramsar)
Whaling
see International Convention for the Regulation of Whaling
862
“APPENDIX D
CROSS-REFERENCE LIST OF COUNTRY DATA CODES
GEOPOLITICAL ENTITIES and CODES (formerly FIPS PUB 10-4): Geopolitical Entities, Names, and Codes(GENC) Standard, the US
Government''s implementation of ISO 3166, has been designated as thereplacement standard for FIPS PUB 10-4. The GENC Standard will
provide a list of the basic geopoliticalentities in the world, together with the principal divisions that comprise each entity. The names of
thepolitical entities are derived from official meeting records of the Foreign Names Committee of the US Boardon Geographic Names (US
BGN). The National Geospatial-Intelligence Agency (NGA), is the maintenanceauthority for the GENC Standard.
ISO 3166: Codes for the Representation of Names of Countries (ISO 3166) is prepared by the InternationalOrganization for Standardiza-
tion. ISO 3166 includes two- and three-character alphabetic codes and three-digit numeric codes that may be needed for activities involv-
ing exchange of data with internationalorganizations that have adopted that standard. Except for the numeric codes, ISO 3166 codes have
beenadopted in the US as FIPS 104-1: American National Standard Codes for the Representation of Names ofCountries, Dependencies,
and Areas of Special Sovereignty for Information Interchange.
STANAG 1059: Letter Codes for Geographical Entities (8th edition, 2004) is a Standardization Agreement(STANAG) established and
maintained by the North Atlantic Treaty Organization (NATO/OTAN) for thepurpose of providing a common set of geo-spatial identifiers
for countries, territories, and possessions. The 8th edition established trigraph codes for each country based upon the ISO 3166-1 alpha-3
charactersets. These codes are used throughout NATO.
Internet: The Internet country code is the two-letter digraph maintained by the International Organizationfor Standardization (ISO) in
the ISO 3166 Alpha-2 list and used by the Internet Assigned NumbersAuthority (IANA) to establish country-coded top-level domains
(ccTLDs).
Stanag- :
Entity FIPS 10 ISO 3166 1059 Internet Comment
Afghanistan AF AF AFG 004 AFG .af
Akrotiri l | a = e 2
Albania TER AL - AL ALB 008 ALB al
Algeria . AG DZ DZA : 012 DZA .dz
American Samoa AQ AS ASM 016 ASM .as
Andorra AN AD AND 020 AND ad
Angola AO AO AGO 024 AGO ao
Anguilla AV Al . AIA 660 AIA ai
Antarctica AY AQ ATA 010 ATA .aq ISO defines as the territory south
of 60 degrees south latitude
Antigua and Barbuda AC AG ATG 028 ATG ag
Argentina AR AR ARG 032 ARG ar
Armenia AM AM ARM 051 ARM am
Aruba AA AW ABW 533 ABW aw
Ashmore and Cartier Islands AT. - - - AUS - ISO includes with Australia
as 1 a
Austria AU ` AT AUT 040 AUT „at
Azerbaljan a AJ AZ AZE 031 AZE .az
Bahamas, The © BF BS BHS 044 BHS bs
- Bahrain BA BH BHR 048 BHR -bh
Baker Island FQ = - - UMI - pet a the US Minor
Bangladesh = BG BD BGD 050 BGD bd
Barbados E BB _ BB BRB 052 BRB -bb
ISO codes assigned
Belarus í BO BY BLR 112 BLR .by
Belgium BE BE BEL 056° BEL -be
Belizo BH BZ BLZ 084 BLZ be
Benin BN BJ BEN 204 BEN bj
an BM > BMU 060 BMU bm
863
THE CIA WORLD FACTBOOK
Stanag-
Entity FIPS 10 ISO 3166 1059 Internet Comment
Bhuton BT BT BIN 064 BIN -bt
Bolivia BL BO BOL 068 BOL .bo
Bosnia and Herzegovina BK BA BIH 070 BIH -ba
Botswana BC BW BWA 072 BWA .bw
Bouvet Island BV BV BVT 074 BVT .byv
Brazil BR BR BRA 076 BRA -br
British Indian Ocean Territory IO IO IOT 086 IOT .io
British Virgin Islands VI VG VGB 092 VGB vg
Brunei BX BN BRN 096 BRN -bn
Bulgaria BU BG BGR 100 BGR .bg
Burkina Faso UV BF BFA 854 BFA bf
Burma BM MM MMR 104 MMR .mm ISO uses the name Myanmar
Burundi BY BI BDI 108 BDI bi
Cambodia CB KH KHM 116 KHM kh
Cameroon CM CM CMR 120 CMR .cm
Canada CA CA "EAN H ON @a
Cape Verde ‘CV CV CPV 132 CPV cv
Cayman Islands CJ KY CYM 136 CYM sky
Centra! African Republic Cr CF CAF 140 CAF cf
Chad CD TD TCD 148 TCD td
. Chile Cl CE Grr 152 CHL cl
China ‘CH CN CHN 156 CHN cn see also Taiwan
Christmas Island KT CX CXR 162 CXR nex
Clipperton Isiand IP - ~ — FYP - ISO includes with France
Cocos (Keeling) Isiands CK CE CCK 166 AUS ace à
Colombia CO co COL 170 COL .cO
Comoros CN KM COM 174 COM «km
Congo, Democratic Republic CG GD COD 180 COD „cd
of the formerly Zaire l
Congo, Republic of the CF CG COG 178 COG cg
Cook Islands CW CK COK 184 COK ick
Coral Sea Islands CR - - - AUS - ISO includes with Australia
Costa Rica (OS CR CRI 188 CRI cr
Cote d''ivoire IV CI CIV 384 CIV ci
Croatia HR HR HRV 191 HRV hr
Cuba (CG CU CUB 192 CUB cu
Curacao UC CW CUW 531 - .cw
Cyprus (Cy CY CYP 196 CYP cy
Czech Republic EZ GZ. CZE 203 CZE EZ
Denmatk DA DK DNK 208 DNK .dk
Dhekelia DX = = = 2 =
Djibouti DJ DJ DJI 262 DJI dj
Dominica DO DM DMA 22 DMA .dm
Dominican Republic DR DO DOM 214 DOM do
864
CROSS-REFERENCE LIST OF COUNTRY DATA CODES
E Sa T i Stanag-
ntity a FIPS 10 . à ISO 3166 1059 Internet Comment
Ecuador oo TEG EC ECU 218 EGUN ec
Egypt l : EG EG = EGY 818 “EGY .eg
Ei Salvador . ES SV SLV 222 SLV SV
Equatorial Guinea EK GQ GNQ - 226 GNQ -gq
Eritrea k : ER ` ER .. ERI 232 ERI .er
Estonia EN EE EST . 233 EST ee
Ethiopia ; ET ET ETH =: 231 ETH -et
Europa Island - : EU ~ - = - = administered as part of French
Southern and Antarctic Lands; no
ISO codes assigned
Falkland Islands (Islas _ FK FK FLK 238 FLK fk
Malvinas) - |
Faroe islands FO FO FRO _ 234 FRO fo
Fiji FJ FJ FJI 242 - FJI fj
Finland | FI F','6e5a2296d63b68da1e78eb901e1db24a270245989f492c2dd6f297793cbf6529','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('146a88ddf14b52023f749926301b23cb85a6a17c7772dc1775856d094dc8a5ea',2025,'VC','Saint Vincent and the Grenadines','environment',1740,'I FIN 246 FN fi
Francé FR FR FRA 250 FRA fr ISO includes metropolitan France
along with the dependencies of
Clipperton Island, French Gui-
ana, French Polynesia, French
Southern and Antarctic Lands,
Guadeloupe, Martinique, May-
otte, New Caledonia, Reunion,
Saint Pierre and Miquelon, Wallis
and Futuna
France, Metropolitan - FX FXX 249 - fx ISO limits to the European part
: i of France
French Guiana FG GF ` GUF 254 GUF ` gf
French Polynesia FE PF PYF 258 PYF pf
French Southern and Antare- © FS TF ATF 260 ATF wtf FIPS 10-4 does not include the
tic Lands i French-claimed portion of Ant-
arctica (Terre Adelie)
Gabon l A GB GA _ GAB 266 GAB ga
Gambia, The GA GM GMB 270 GMB gm
Gaza Strip GZ PS PSE 275 PSE ps ISO identifies as Occupied Pales-
tinian Territory
Georgia GG GE GEO 268 GEO ge
Germany GM DE DEU 276 DEU de
Ghana GH GH GHA 288 GHA gh
Gibraltar af Gl GI GIB 292 GIB gi
Glorioso Islands GO = - -= -= - administered as part of French
Southern and Antarctic Lands; no
ISO codes assigned
Greece GR GR GRC 300 GRC gr For its internal communications,
the European Union recommends
the use of the code EL in lieu of
the ISO-3166-2 code of GR
Greenland : 7) GL GL GRL 304 GRL gl
Grenada g GD GRD 308 GRD gd
Guadeloupe GP GP ‘GLP 312 GLP gP
Guam i GQ GU .. GUM 316 GUM gu
Guatemala oa o Gt GTM 320 GTM gt
865
Entity','9c4d576d60cd39c0da83f3d8932ddb6dfbe2e8810a6e2d07e8ba2655dc3803e8','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('09a947bec27885aed28e98bd6b2d71ee134adb776342441a41108e485b53e3a0',2025,'ID','Indonesia','environment',1741,'iran
Pacific Ocean
Atlantic Ocean
Pacific Ocean
Atlantic Ocean
Pacific Ocean
Atlantic Ocean
Romania, Serbia
Turkey
Arctic Ocean
Saint Helena; Ascension, and
Tristan da Cunha
Pacific Ocean
Israel, West Bank
Russia
Indian Ocean
Svalbard
Pacific Ocean
Pacific Ocean
Indonesia, Malaysia
Indian Ocean
Pacific Ocean
(deg min)
6100S
4220N
30 00S
5745S
6200S
46 30 N
12 00 N
1400 N
2200S
12 20N
2000S
200N
32 00 N
3515N
24 30 N
25 00 N
200S
78 00 N
44 00 N
47 34N
5142S
59 20 N
4835 N
48 46 N
1902S
29 55 N
2810 N
47 00 N
200S
300 N
6 00 N
809 N
000N
1000S
910S
830S
200S
6005S
64 00 N
7138
1015N
Longitude
(deg min)
4500 W
4400E
13000 W
26 30 W
59 00 W
10 30 E
108 00 E
48 00E
17 00E
61 30 W
30 00 E
10 00 E
700 W
400 W
13 00 W
13 00 W
28 00 E
20 00 E
2100E
52 43 W
5741 W
18 03 E
144E
IME
6517 W
3233E
33 27E
800E
121 00 E
122 00 E
121 00 E
120 00 E
102 00 E
120 00 E
120 00 E
118 00 E
110 00E
105 45 E
26 00 E
112 45E
125231E
CROSS-REFERENCE LIST OF GEOGRAPHIC NAMES
Surinam (former name for Suriname)
Suriyah (local name for Syria)
Surtsey (volcanic island)
Suva (capital)
Sverdlovsk (city; also Yekaterinburg)
Sverige (local name for Sweden)
Svizzera (local italian name for Switzerland)
Swains Island i
Swan islands
Sydney (city)
T''bilisi (capital)
Tadzhikistan (former name for Tajikistan)
Tahiti (island)
Taipei (capital) ©
Taiwan Strait
Tallinn (capital)
` Tanganyika (former name for the mainland portion of Tanzania)
Tangier (city)
Tannu-Tuva (region)
Tarawa (island)
Tartary, Gulf of
Tashkent (capita!)
Tasman Sea
Tasmania (island)
Tatar Strait
Taymyr Peninsula (Poluostrov Taymyr)
Tchad (local name for Chad)
Tegucigalpa (capital)
Tehran (capital)
Tel Aviv (capital, de facto)
Teluk Bone (gulf)
Teluk Tomini (gulf)
Terre Adelie (claimed by France; aiso Adelie Land)
Terres Australes et Antarctiques Francaises (local name for the
French Southern and Antarctic Lands)
Thailand, Guif of
The Former Yugoslav Republic of Macedonia
Thessaloniki (city; also Salonika)
Thimphu (capital)
Thuringia (region)
Thurston Island
Tiberias, Lake
Tibet (autonomous region; also Xizang)
Tibilisi (see T''bilisi)
Tien Shan (mountains)
Tierra det Fuego (island, island group)
Timor (island)
Timor Lorosa’e (local name for Timor-Leste)
Timor Sea `
Tinian (island)
Tiran, Strait of
Entry In The
World','887763b85bd72724fc3462aad8c7b5ac3225ed77b093bf498f208d0a090cca50','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c12e8a201b696d44a1346f4961a0e8bb4138b011d46d14631fbd5b571d4d5528',2025,'JP','Japan','environment',1742,'Jarvis island
Indian Ocean
Djibouti, Eritrea, Ethiopia,
Turkey
Bolivia
Pacific Ocean
Venezuela
Guam, Northern Mariana
Islands
Federated States of Micronesia
Pacific Ocean
Russia (de facto)
Pacific Ocean','b9b31c65e78964c0b72e34d49298c1f2196efb87b19328e3e0c6f4fa8b0dc538','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9638e95a7cdc2fdf3c624848af5e9f886f6dfac0a971c7b08fc339f23612464f',2025,'KI','Kiribati','environment',1743,'Korea, North
Korea, South
Kosovo
Arctic Ocean
Federated States of Micronesia
Turkey
Indian Ocean
Arctic Ocean
Russia
Pacific Ocean
` Uzbekistan
Pacific Ocean
Wake Island','75264b6a9fb5f9d8b47d127fc4570c422d8b9b05a0a2029f651574640beaa542','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1c564e414e74a28b52ed98ce58dbbaeb2b3a8a032a0f2d37fcf7c3fb5ff2ddd1',2025,'KG','Kyrgyzstan','environment',1744,'866
FIPS 10
GK
GV
KG
THE CIA WORLD FACTBOOK
KW
KG
ISO 3166
GGY
‘GIN
GNB
GUY
HTI
HMD
KGZ
831
324
624
328
332
334
832
410
417
Stanag-
1059
KGZ
Internet
“BE
“en
«kw
Comment
ISO includes with the US Minor
Outlying Islands
ISO includes with Svalbard
ISO includes with the US Minor
Outlying Islands
ISO includes with the US Minor
Outlying Islands
administered as part of French
Southern and Antarctic Lands; no
ISO codes assigned
ISO includes with the US Minor
Outlying Islands
XK and XKS are ISO 3166 user
assigned codes; ISO 3166 Main-
tenace Authority has not assigned
codes','75d2d7eb57efe7a782885411ca25e6d40094900eb7a73eabee73b9019783e4ed','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('30f1f3adc1bbdc22ccfe580f73dfe03e0aebbed85fa8f321433b4548cd00cc53',2025,'MX','Mexico','environment',1745,'Micronesia, Federated
States of
Midway Islands
Moldova
Swaziland
Heard Island and McDonald
Islands
Atlantic Ocean
Republic of the Congo
Montenegro, Serbia
Bosnia and Herzegovina, Croa-
tia, Macedonia, Montene-
gro, Serbia, Slovenia
Bosnia and Herzegovina, Croa-
tia, Macedonia, Montene-
gro, Serbia, Slovenia','4fb21b43bdcd7eb156b913bb5115b0f79ecb035ff012fadf714ad3cd61a688c9','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('696f188dec3042271de1e7feb87cb74548f877ef5c090e64ababc5ac3e5e34ff',2025,'NL','Netherlands','environment',1746,'Netherlands Antilles
French Southern and Antarctic
Lands
Southern Ocean
China, Russia
Pacific Ocean
Pacific Ocean
Turkey
Sint Maarten, Saint Martin','41a5fe69bb71ca0126e9f953ba4ef50ac8c68f32161d269a1a3269033b40178c','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('47bc1ea2772db5ecdd842274b067de300dd204d145efb46cf9bf0375e9067245',2025,'NC','New Caledonia','environment',1747,'CROSS-REFERENCE LIST OF COUNTRY DATA CODES
FIPS 10
LA
LG
LE
EE
LI
LY
ES
LH
LU
NC
MN
NP
NL
NC
ISO 3166
LAO
LVA
LBN
LSO
LBR
LBY
LIE
LTU
* LUX
MAC
MKD
MDG
~ MWI
MYS
MDV
MLI
MLT
MHL
MTQ
MRT
MUS
MYT
NCL
418
428
422
426
430
434
438
440
442
446
807
450
454
458
462
466
470
584
474
540
Stanag-
1059
LAO
LVA
LBN
LSO
LBR
LBY
LIE
LTU
LUX
MAC
FYR
NCL
Internet
ne
Comment
ISO includes with the US Minor
Outlying Islands
see Burma
?
ISO includes with the US Minor
Outlying Islands
disestablished in October 2010
this entity no longer exists; ISO
deleted the codes in December
2010
867
THE CIA WORLD FACTBOOK
Stanag- :
Entity FIPS 10 s ISO 3166 1059 internet > Comment
New Zealand NZ NZ NZL . 554 NZL mz
Nicaragua ` NU NI NIC 558 NIC ni
Niger NG NE NER 562 NER ne
Nigeria NI NG NGA 566 NGA ng
Niue ; NE NU NIU 570 NIU nu
Norfolk Island NF NF NFK '' 574° NFK anf
Northern Mariana Islands CQ: MP MNP 580 MNP mp
Norway i NO NO - NOR 578 NOR no
Oman MU OM OMN 512 OMN om
Pakistan ~ PK PK PAK 586 PAK .pk
Palau . PS PW PLW ` 585 PLW .pw
Palmyra Atoll $ LQ - - -- UMI - ISO includes with the US Minor
Outlying Islands
Panama - PM PA PAN 591 PAN .pa d
Papua New Guinea PP PG PNG | 598 PNG pe
Paracel stands PF - - — - = =
Paraguay PA BY PRY 600 . PRY py
Peru i PE PE PER 604 . PER pe
Philippines RP PH PHL 608 PHL ph
Pitcairn Islands -TPE PN PCN 612 PCN .pn
Poland ; ` PL PL POL 616 POL pl
Portugal PO PT PRT. 620 PRT pe
Puerto Rico l RQ PR | PRI 630 PRI pr
Qatar $ QA QA QAT 634 QAT qa
Reunion RE RE REU '' 638 REU re
Romania gel RO RO ROU 642 ROU . mo
Russia RS RU RUS 643 RUS Tu
Rwanda RW RW . RWA 646 RWA w
Saint Barthelemy TB BL > BLM 652 - bl ccTLD .fr and .gp may also be
used
Saint Helena, Ascension, and SH SH '' SHN 654 © SHN sh includes Saint Helena Island,
Tristan da Cunha l Ascension Island, and the Tristan
da Cunha archipelago
Saint Kitts and Nevis SC KN KNA ` 659 KNA -kn
Saint Lucia ST LC LCA 662 LCA alc
_ Saint Martin RN MF MAF 663 ` - .mf ccTLD .fr and .gp may also be
used
Saint Pierre and Miquelon SB - PM SPM 666 SPM pm
Saint Vincent and the NG VG; VCT 670 VCT vc
Grenadines
Samoa WS WS WSM 882 WSM WS
San Marino SM SM SMR 674 SMR sm
Sao Tome and Principe TP ST STP 678 STP st
Saudi Arabia : SA SA SAU 682 SAU $2
Senegal SG SN SEN 686 SEN sn
Serbia RI RS SRB 688 - rs
868
Entity
Pacific Ocean','f8ceef299ed1ec7d2409c297cb350758b5d685631f80e9b8115eaa76f8138586','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2e0f2dbfdbfe8cd3fe01f692609979577541992f803b8381dec3ae2e62728e49',2025,'ZA','South Africa','environment',1748,'South Georgia and the
Islands
Venezuela
Holy See
Vietnam
Pacific Ocean
Atlantic Ocean
Pacific Ocean','14c03d4a34b1b8457d0d71adde5892ceed5f5a96e4007ed8ab2b152b64ef024b','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5bc60b1b1467dd140d01ff15d8f87785a7f8a4291b4ab86525f2801b6141d144',2025,'SS','South Sudan','environment',1749,'Spair-
Spratly Islands
Kyrgyzstan, Tajikistan,
Indian Ocean
Israel, West Bank
Bosnia and Herzegovina, Croa-
tia, Macedonia, Montene-
gro, Serbia, Slovenia','16170b1f9600f70431458d7101916438097df512cbda8c52d1e8d5f08fda30b4','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('da2ebb341e44395a1fcd5fd830ef60d4497065a81816da29751a9c7df9e939ad',2025,'CH','Switzerland','environment',1750,'Syria
Tolwan
Moldova, Romania, Ukraine
Republic of the Congo
Democratic Republic of the
Israel, West Bank
Atlantic Ocean, Southern
Ocean
Lotitude
(deg min)
1335S
820S
65 30N
7100S
1206 N
22 34S
20 00 N
4953 N
71 14N
2215 N
31 30N
800 N
3955 N
649 N
1647 N
352 N
930N
0328S
56 50 N
36 00 N
15 00 N
1400 N
40 11N
35 26 N
21 40N
2145 N
1930 N
43 00 N
43 00N
43 00 N
45 48 N
1500S
54 00 N
60 00 N
1600S
610S
35 00 N
3146 N
4123 N
Longitude
(deg min)
172 20 W
126 30 E
38 00E
120 00 E
68 56 W
17 06 E
73 50 W
9710W
179 36 W
11410E
3445E
38 00 E
124 20 E
517W
96 10E
11 31E
138 00 E
166 55 E
60 39 E
123 00 E
44 00E
46 00 E
44 30E
139 37E
82 50 W
85 45 W
89 00 W
21 00E
19 00 E
1900E
1558E
30 00 E
142 00E
15730E
37 00E
SOE
105 00 E
35 14E
832E
A PPENDTX"G
WEIGHTS AND MEASURES
Note: At this time, only three countries—Burma, Liberia, and the US—have not adopted the International System of Units (SI, or metric
system) as their official system of weights and measures. Although use of the metric system has been sanctioned by law in the US since
1866, it has been slow in displacing the American adaptation of the British Imperial System known as the US Customary System. The US
is the only industrialized nation that does not mainly use the metric system in its commercial and standards activities, but there is increasing
acceptance in science, medicine, government, and many sectors of industry.
Mathematical Notation
Mathematical Power
10! or 1,000,000,000,000,000,000
10" or 1,000,000,000,000,000
10 or 1,000,000,000,000
10° or 1,000,000,000
10° or 1,000,000
Name
one quintillion
one quadrillion
one trillion
one billion
one million
10 or 1,000 one thousand
10? or 100 one hundred
10! or 10 ten
10° or 1 one
107 or 0.1 one-tenth
107 or 0.01 one-hundredth
10° or 0.001 one-thousandth
10* or 0.000 001 one-millionth
10° or 0.000 000 001 one-billionth
10°” or 0.000 000 000 001
10° or 0.000 000 000 000 001
108 or 0.000 000 000 000 000 001
one-trillionth
one-quadrillionth
one-quintillionth
Metric Interrelationships
Prefix Symbol Length, weight, or capacity
yotta Y 10%
zetta Z 1O%
exa E 10''8
peta Je 10
tera T 10”
giga G 10°
mega M 10°
kilo k 10°
hecto h 10?
deka da 10!
basic unit ~ 1 meter, 1 gram, 1 liter
deci d 10!
centi c 10”
milli m 10
micro u 10°
nano n 10°
pico p 10"
femto f 10"
atto ; a 10"
zepto Z 107
yocto" y 10%
903
Conversion Factors
To Convert From
acres
acres
acres
acres
acres
acres
acres
ares
ares
barrels, US beer
barrels, US beer
barrels, US petroleum
barrels, US petroleum
barrels, US petroleum
barrels, US proof spirits
barrels, US proof spirits
bushels (US)
bushels (US)
bushels (US)
bushels (US)
bushels (US)
bushels (US)
bushels (US)
bushels (US)
bushels (US)
bushels (US)
cables
cables
cables
carat
centimeters
centimeters
centimeters
centimeters
centimeters, cubic
centimeters, square
centimeters, square
centimeters, square
centimeters, square
chains, square surveyor''s
chains, square surveyor''s
chains, surveyor''s
chains, surveyor''s
chains, surveyor''s
cords of wood
cords of wood
cords of wood
cups
cups
degrees Celsius
degrees Fahrenheit
904
THE CIA WORLD FACTBOOK
To
ares
hectares
square feet
square kilometers
square meters
square miles (statute)
square yards
square meters
square yards
gallons
liters
gallons (British)
gallons (US)
liters
gallons
liters
bushels (British)
cubic feet
cubic inches
cubic meters
cubic yards
dekaliters
dry pints
dry quarts
liters
pecks
fathoms
meters
yards
milligrams
feet
inches
meters
yards
cubic inches
square feet
square inches
square meters
square yards
ares
square feet
feet
meters
rods
cubic feet
cubic meters
cubic yards
liquid ounces (US)
liters
degrees Fahrenheit
degrees Celsius
. Multiply By
40.468 564 224
0.404 685 642 24
43,560
0.004 046 856 422 4
4,046.856 422 4
0.001 562 50
4,840
100
119.599
31
117.347 77
34.97
42
- 158.987 29
40
151.416 47
0.968 9
1.244 456
2,150.42
0.035 239 07
0.046 090 96
3.523 907
64
32
35.239 070 17
4
120
219.456
240
200
0.032 808 40
0.393 7008
0.01
0.010 936 13
0.061 023 744
0.001 076 39
0.155 000 31
0.000 1
0.000 119 599
4.046 86
4,356
66
20.116 8
4
128
3.624 556
4.7407
8
0.236 588 2
multiply by 1.8 and add 32
subtract 32 and divide by 1.8
:
,
-Conversion Factors
To Convert From
. dekaliters
dekaliters
dekaliters
dekaliters
dekaliters
dekaliters
dekaliters
drams, avoirdupois -
drams, avoirdupois
drams, avoirdupois
drams, troy
drams, troy
drams, troy
_ drams, troy
- drams, liquid (US)
drams, liquid (US)
dramis, liquid (US)
drams, liquid (US) .
drams, liquid (US)
fathoms
fathoms
feet .
feet
feet
feet
feet, cubic
feet, cubic
feet, cubic
feet, cubic
feet, cubic
`
feet, cubiç
feet, cubic
feet, cubic
feet, cubic
feet, cubic
feet, cubic
feet, cubic
feet, cubic
feet, cubic
feet, square
feet, square
feet, square
feet, square
'' feet, square
feet, square
furlongs
furlongs
furlongs
furlongs
WEIGHTS AND MEASURES
To
bushels
cubic feet
cubic inches
dry pints
dry quarts
liters
pecks ,
avoirdupois ounces
grains
scruples
troy ounces
cubic inches
liquid drams (British)
liquid ounces
milliliters
minims
feet
meters
centimeters
inches
kilometers
meters
statute miles
yards
bushels
cubic decimeters
cubic inches
cubic meters
cubic yards
dry pints
dry quarts
gallons
gills
liquid ounces
liquid pints
liquid quarts
liters
pecks
acres
square centimeters
square decimeters
square inches
square meters
square yards
feet
inches
meters
statute miles
Multiply By
0.283 775 9
0.353 1467
610.237 4
18.161 66
9.080 829 8
10
1.135 104
0.062 55
27.344
1.771 845 2
60
"3.887 934 6
3
0.125
0.226
1.041
0.125
3.696 69
60
6
1.828 8
` 30.48
12
0.000 304 8
0.304 8
0.000 189 39
0.333 333 3
0.803 563 95
28.316 847
1,728
0.028 316 846 592
0.037 037 04
51.428 09
25.714 05
7.480 519
‘239.376 6
957.506 5
59.844 16
29.922 08
28.316 846 592
3.214 256
0.000 022 956 8
929.030 4
9.290 304
144
0.092 903 04
0.111 1111
` 660
7,920
201.168
0.125
905
Conversion Factors
To Convert From
furlongs
‘gallons, liquid (US)
gallons, liquid (US)
gallons, liquid (US)
gallons, liquid (US)
gallons, liquid (US)
gallons, liquid (US)
gallons, liquid (US)
gallons, liquid (US)
gallons, liquid (US)
gallons, liquid (US)
gallons, liquid (US)
gallons, liquid (US)
gills (US)
gills (US)
gills (US)
gills (US)
gills (US)
gills (US)
gills (US)
gills (US)
gills (US)
gills (US)
gills (US)
grains
grains
grains
grains
grains
grains `
grains
grains
grains
grains
grains
grams
grams
grams
grams
grams
grams
prams
prams
hands (height of horse)
hands (height of horse)
hectares
hectares
hectares
hectares
hectares
hectares
THE CIA WORLD FACTBOOK
To Multiply By
cubic feet 0.133 680 6
cubic inches Zla T
cubic meters 0.003 785 411 784
cubic yards 0.004 951 13
gills (US) 132
liquid gallons (British) 0.832 67
liquid ounces 128
liquid pints 8
3 liquid quarts 4
liters 3.785 411 784
milliliters 3,785.411 784
minims 61,440
+ centiliters 11.829 4
cubic feet 0.004 177 517
cubic inches 7.218 75
gallons 0.031 25
gills (British) 0.832 67
liquid ounces 4
liquid pints 0.25
liquid quarts 0.125
liters 0.118 294 118 25
milliliters 118.294 118 25
minims 1,920
avoirdupois drams 0.036 571 43
avoirdupois ounces 0.002 285 71
avoirdupois pounds 0.000 142 86
grams 0.064 798 91
kilograms 0.000 064 798 91
milligrams 64.798 910
pennyweights 0.042
scruples 0.05
troy drams 0.016 6
troy ounces 0.002 083 33
troy pounds 0.000 173 61
avoirdupois drams 0.564 383 39
avoirdupois ounces 0.035 273 961
avoirdupois pounds 0.002 204 622 6
prains 15.432 361
kilograms 0.001
milligrams 1,000
troy ounces | 0.032 150 746 6
troy pounds 0.002 679 23
centimeters 10.16
inches 4
acres 2.471 053 8
square feet 107,639.1
square kilometers 0.01
square meters 10,000
square miles 0.003 861 02
square yards 11,959.90
906
Conversion Factors
To Convert From .
WEIGHTS AND MEASURES
To
Multiply By
Eee
hundredweights, long
hundredweights, long
hundredweights, long
hundredweights, long
hundredweights, long
hundredweights, short -
hundredweights, short
` hundredweights, short
- hundredweights, short
_ hundredweights, short
inches
inches
inches --
inches
inches
inches, cubic
inches, cubic
inches, cubic
inches, cubic
inches, cubic
inches, cubic
inches, cubic
inches, cubic
| inches, cubic
inches, cubic
inches, cubic
inches, cubic
inches, cubic
inches, cubic
inches, cubic
inches, cubic -
inches, square
inches, square
inches, square
inches, square
kilograms
’ kilograms
kilograms
kilograms
kilograms
kilograms
kilograms
kilograms -
kilograms i A
kilograíns l
kilograms
kilometers
kilometers
kilometers, square
kilometers, square
kilometers, square
avoirdupois pounds . ‘
- kilograms
long tons
metric tons
short tons
avoirdupois pounds
kilograms
long tons —
metric tons
short tons
. centimeters
feet
meters
millimeters
yards
bushels
cubic centimeters
cubic feet
cubic meters
cubic yards
- dry pints
dry quarts
gallons
gills
liquid ounces
liquid pints
liquid quarts
liters
milliliters
minims (US)
pecks
square centimeters
square feet
square meters
square yards
avoirdupois drams
avoirdupois ounces
avoirdupois pounds
grains
-grams
- long tons
metric tons
short hundredweights
short tons
troy ounces
troy pounds
meters
statute miles
acres
hectares
square meters
112
50.802 345
0.05
0.050 802 345
0.056
100
45.359 237
0.044 642 86
- 0.045 359 237
0.05
2.54
0.083 333 33
0.025 4
25.4
0.027 777 78
0.000 465 025
16.387 064
0.000 578 703 7
0.000 016 387 064
0.000 021 433 47
0.029 761 6
- 0.014 880 8
0.004 329 0
` 0.138 528 1
0.554 112 6
0.034 632 03
0.017 316 02
0.016 387 064
16.387 064
265.974 0
0.001 860 10
6.451 600
0.006 944 44
0.000 645 16
0.000 771 605
564.383 4
35.273 962
2.204 622 622
15,432.36
1,000
0.000 984 2
0.001
0.022 046 23
0.001 102 31
32.150 75
2.679 229
1,000
0.621 371 192
247.105 38
100
1,000,000
907
Conversion Factors
To Convert From
THE CIA WORLD FACTBOOK
To
Multiply By
eee _.2.200€80«@€O OE eee
kilometers,»square
knots (nautical mi/hr)
knots (nautical mi/hr)
leagues, nautical
leagues, nautical
leagues, statute
leagues, statute
links, square surveyor''s
links, square surveyor''s
links, surveyor''s
links, surveyor''s
links, surveyor''s
liters
liters
liters
liters
liters
liters
liters
liters
liters
liters
liters
liters
liters
liters
liters
meters
meters
meters
meters
meters
meters
meters
meters, cubic
meters, cubic
meters, cubic
meters, cubic
meters, cubic
meters, cubic
meters, cubic
meters, square
meters, square
meters, square
meters, square
meters, square
meters, square
microns
microns
mils
mils
908
statute miles
kilometers/hour
statute miles/hour
kilometers
nautical miles
kilometers
statute miles
square centimeters
square inches
centimeters
chains
inches
bushels
cubic feet
cubic inches
cubic meters
cubic yards
dekaliters
dry pints
dry quarts
gallons
gills (US)
liquid ounces
liquid pints
liquid quarts
milliliters
pecks
centimeters
feet
inches
kilometers
millimeters
statute miles
yards
bushels
cubic feet
cubic inches
cubic yards
gallons
liters
pecks
acres
hectares
square centimeters
square feet
square inches
square yards
meters
inches
inches
millimeters
0.386 102 16
1.852
1.151
5.556
3
4.828 032
3
404.686
62.726 4
20.116 8
0.01
7.92
0.028 377 59
0.035 314 67
61.023 74
0.001
0.001 307 95
0.1
1.816 166
0.908 082 98
0.264 172 052
8.453 506
33.814 02
2.113 376
. 1.056 688 2
1,000
0.113 510 4
100
3.280 839 895
39.370 079
0.001
1,000
0.000 621 371
1.093 613 298
28.377 59
35.314 666 7
61,023.744
1.307 950 619
264.172 05
1,000
113.510 4
0.000 247 105 38
0.000 1
10,000
10.763 910 4
1,550.003 1
1.195 990 046
0.000 001
0.000 039 4
0.001
0.025 4
Conversion Factors
To Convert From
WEIGHTS AND MEASURES
To
Multiply By
rr
` miles, nautical
miles, nautical
miles, statute
miles, statute
miles, statute
miles, statute
miles, statute
miles, statute
miles, statute
miles, statute
miles, square nautical
miles, square nautical
miles, square statute
miles, square statute
miles, square statute
miles, square statute
- miles, square statute
fiities, square statute
milligrams
milliliters
milliliters
milliliters
milliliters
milliliters
milliliters
milliliters
milliliters
millimeters
minims (US)
minims (US)
minims (US)
minims (US)
minims (US)
ounces; avoirdupois
ounces, avoirdupois
ounces, avoirdupois
ounces, avoirdupois
ounces, avoirdupois
ounces, avoirdupois
ounces, avoirdupois
ounces, liquid (US)
ounces, liquid (US)
ounces, liquid (US)
ounces, liquid (US)
ounces, liquid (US)
ounces, liquid (US)
ounces, liquid (US)
ounces, liquid (US)
ounces, liquid (US)
ounces, liquid (US)
ounces, liquid (US)
kilometers
statute miles
centimeters
feet
furlongs
inches
kilometers
meters
rods
yards
square kilometers
square statute miles
acres
hectares
sections
square kilometers
square nautical miles
square rods
grains
cubic inches
gallons
gills (US)
liquid ounces
liquid pints
liquid quarts
liters
minims
inches
cubic inches
gills (US)
liquid ounces
milliliters
minims (British)
avoirdupois drams
avoirdupois pounds
grains
grams
kilograms
troy ounces
troy pounds
cubic feet
centiliters
cubic inches
gallons
gills (US)
liquid drams
liquid ounces (British)
liquid pints
liquid quarts
liters
milliliters
1.852 0
1.150 779 4
160,934.4
5,280
8
63,360
1.609 344
1,609.344
320
1,760
3.429 904
1.325
640
258.998 811 033 6
1
2.589 988 110 336
0.755 miles
102,400
0.015 432 358 35
0.061 023 744
0.000 264 17
0.008 453 5
0.033 814 02
0.002 113 4
0.001 056 7
0.001
16.230 73
0.039 370 078 7
0.003 759 77
0.000 520 83
0.002 083 33
0.061 611 52
1.041
16
0.062 5
437.5
28.349 523 125
0.028 349 523 125
0.911 458 3
0.075 954 86
0.001 044 38
2.957 35
1.804 687 5
0.007 812 5
0.25
8
1.041
0.062 5
0.031 25
0.029 573 53
29.573 529 6
909
Conversion Factors
To Convert From
ounces, liquid (US)
ounces, troy
ounces, troy
ounces, troy
ounces, troy
ounces, troy
ounces, troy
ounces, troy
ounces, troy
paces (US)
paces (US)
pecks (US)
pecks (US)
pecks (US)
pecks (US)
pecks (US)
pecks (US)
pecks (Us)
pecks (US)
pecks (US)
pecks (US)
pennyweights
pennyweights
pennyweights
pints, dry (US)
pints, dry (US)
pints, dry (US)
pints, dry (US)
pints, dry (US)
pints, dry (US)
pints, dry (US)
pints, liquid (US)
pints, liquid (US)
pints, liquid (US)
pints, liquid (US)
pints, liquid (US)
pints, liquid (US)
pints, liquid (US)
pints, liquid (US)
pints, liquid (US)
pints, liquid (US)
pints, liquid (US)
points (typographical)
points (typographical)
pounds, avoirdupois
pounds, avoirdupois
pounds, avoirdupois
pounds, avoirdupois
pounds, avoirdupois
pounds, avoirdupois
THE CIA WORLD FACTBOOK
To Multiply By
ani) °° itm = ————
avoirdupois drams - 17.554 29
avoirdupois ounces 1.097 143
avoirdupois pounds 0.068 571 43
grains 480
grams 31.103 476 8
pennyweights 20
troy drams 8
troy pounds 0.083 333 3
centimeters 76.2
inches 30
bushels 0.25
cubic feet 0.311 114
cubic inches 537.605
cubic meters 0.008 809 77
cubic yards 0.011 522 74
dekaliters 0.880 976 75
dry pints 16
dry quarts 8
liters 8.809 767 5
pecks (British) 0.968 9
grains 24
grams 1.555 173 84
troy ounces 0.05
bushels 0.015 625
cubic feet 0.019 444 63
cubic inches 33.600 312 5
dekaliters 0.055 061 05
dry pints (British) 0.968 9
dry quarts 0.5
liters 0.550 610 47
cubic feet 0.016 710 07
cubic inches 28.875
deciliters 4.731 76
gallons 0.125
gills (US) 4
liquid ounces 16
liquid pints (British) 0.832 67
liquid quarts 0.5
liters 0.473 176 473
milliliters 473.176 473
minims 7,680
inches 0.013 837
millimeters 0.351 459 8
avoirdupois drams 256
avoirdupois ounces 16
grains 7,000
grams 453.592 37
kilograms 0.453 592 37
long tons 0.000 446 428 6
metric tons 0.000 453 592 37
pounds, avoirdupois .
910
Conversion Factors
To Convert From
. pounds, avoirdupois
pounds, avoirdupois
pounds, avoirdupois
pounds, avoirdupois
pounds, troy
pounds, troy
pounds, troy
pounds, troy
pounds, troy
pounds, troy
pounds, troy
pounds, troy
quarts, dry (US)
quarts, dry (US)
quarts, dry (US)
quarts, dry (US)
quarts; dry (US)
quarts, dry (US)
quarts, dry (US)
quarts, dry (US)
quarts, dry (US)
quarts, liquid (US)
quarts, liquid (US)
quarts, liquid (US)
quarts, liquid (US)
quarts, liquid (US)
quarts, liquid (US)
quarts, liquid (US)
quarts, liquid (US)
quarts, liquid (US)
quarts, liquid (US)
quarts, liquid (US)
quintals
quintals
quintals
rods
rods
rods
“rods, square
rods, square
rods, square
scruples
scruples
scruples
sections (US)
sections (US)
spans
spans
steres
steres
tablespoons
WEIGHTS AND MEASURES
To
quintals
short tons
troy ounces
troy pounds
avoirdupois drams
avoirdupois ounces
avoirdupois pounds
grains
grams
kilograms
pennyweights
troy ounces
bushels
cubic feet
cubic inches
dekaliters
dry pints
dry quarts (British)
liters
pecks
pints, dry (US)
cubic feet
cubic inches
deciliters
gallons
gills (US)
liquid ounces
liquid pints (US)
liquid quarts (British)
liters
milliliters
minims
avoirdupois pounds
kilograms
metric tons
feet
meters
yards
acres
square meters
square yards
grains
grams
troy drams
square kilometers
square statute miles
centimeters
inches
cubic meters
cubic yards
milliliters
Multiply By
0.004 535 92
0.000 5
14.583 33
1.215 278
210.651 4
13.165 71
0.822 857 1
5,760
373.241 7216
0.373 241 721 6
240
12
0.031 25
0.038 889 25
67.200 625
~ 0.110 1221
2
0.968 9
1.101 221
0.125
2
0.033 420 14
57.75
9.463 53
0.25
8
32
2
0.832 67
0.946 352 946
946.352 946
15,360
220.462 26
100
0.1
16.5
5.029 2
55
0.006 25
25.292 85
30.25
20
1.295 978 2
0.333
2.589 988 1
1
22.86
9
1
1.307 95
14.786 76
911
THE CIA WORLD FACTBOOK
Conversion Factors To Multiply By
To Convert From
tablespoons teaspoons 3
teaspoons milliliters 4.928 922
teaspoons tablespoons 0.333 333
ton-miles, long metric ton-kilometers 1.635 169
ton-miles, short metric ton-kilometers 1.459 972
tons, gross register cubic feet of permanently enclosed space 100
tons, gross register cubic meters of permanently enclosed space 2.831 684 7
tons, long (deadweight) avoirdupois ounces 35,840
tons, long (deadweight) avoirdupois pounds 2,240
tons, long (deadweight) kilograms 1,016.046 909 8
tons, long (deadweight) long hundredweights 20
tons, long (deadweight) metric tons 1.016 046 908 8
tons, long (deadweight) short hundredweights 22.4
tons, long (deadweight) short tons Hay
tons, metric avoirdupois pounds 2,204.623
tons, metric kilograms 1,000
tons, metric long hundredweights 19.684 130 3
tons, metric long tons 0.984 206 5
tons, metric quintals 10
tons, metric short hundredweights 22.046 23
tons, metric short tons 1.102 3113
tons, metric l troy ounces 32,150.75
tons, net register cubic feet of permanently enclosed space for 100
cargo and passengers
tons, net register cubic meters of permanently enclosed space 2.831 684 7
for cargo and passengers
tons, shipping cubic feet of permanently enclosed cargo 42','76997d753fd547547224840a6ee6e1953c8377f5f3eba1d6caf0ac4bea103c78','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1b8f978b6049e54db57204fb71d5702f611e74fd8fdfe0deec84cbc6a18ad973',2025,'AE','United Arab Emirates','environment',1751,'CROSS-REFERENCE LIST OF COUNTRY DATA CODES
FIPS 10
SE
SL
SN
NN
LO
Sl
BP
SO
SE
SX
OD
ddd
6 d
UP
AE
ISO 3166
SYC
SLE
SGP
SXM
SVK
SVN
SLB
SOM
ZAE
SGS
SSD
690
694
702
534
703
705
090
706
710
239
800
804
Stanag-
1059
SYC
Internet
“SC
sl
Sg
«SX
sk
Si
sb
“sO
Za
-gs
-ua
-ae
Comment
IANA has designated .ss as the
ccTLD for South Sudan, however
it has not been activated in DNS
root zone
ISO includes Jan Mayen
administered as part of French
Southern and Antarctic Lands; no
ISO codes assigned
869
Entity
Tran
Russia (de facto)
Federated States of Micronesia
Pacific Ocean','6720a21a81028df2b03a930b8e2dbc9f6975841a132c99c5f868e0dc5221095d','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d2bb3b11358e995533d8c926b3ce6171e689958575941b2da0502cc4b866302f',2025,'US','United States','environment',1752,'United States Minor Outlying
Istonds
Pacific Ocean
Atlantic Ocean
Lotitude
(deg min)
19 20N
2128N
3500S
5530N
30 20N
54 00 N
625 N
21 00N
030 N
200S
4305
79 00 N
1315 N
1207 N
54155
20 40 N
932S
29 11 N
23 09 N
20 00 N
1438 N
12 00 N
200 N
3 00N
11 00 N
1753 N
400 N
1942S
43 30 N
15 00 N
13 28 N
5205 N
32 50N
19 00 N
20 52 N
22 30N
44 39 N
1 00N
030S
53 34N
3217N
37 00 N
2102 N
1750S
2114S
3630N
23 08 N
1945 N
2100N
Longitude
(deg min)
81 20 W
71 08 W
130 00 E
11 00 E
JASE
200 W
94 20E
73 20 W
3600E
11000E
154 10E
500 W
6112 W
6140 W
36 45 W
103 24 W
160 12 E
11817 W
HSE
75 08 W
9031 W
1500 W`
10 00 E
230E
10 00 W
62 51 W
53 00 W
174 29 W
146 10 E
50 00 E
144 45 E
418E
35 00 E
109 30 E
106 41 E
35 00 E
6336 W
128 00 E
129 00 E
959E
6446 W
127 30 E
105 51 E
3103 E
159 46 W.
36 15E
82 22 W
155 45 W
15745 W
883
THE CIA WORLD FACTBOOK
Hawar (island)
Hayastan (local name for Armenia)
Heard Island
Hejaz (region)
Helsinki (capital)
Herzegovina (political region)
Hiiumaa (island)
Hispaniola (island)
Ho Chi Minh City (formerly Saigon)
Hokkaido (island)
Holland (region)
Hong Kong (special administrative region)
Honiara (capital)
Honshu (island)
Hormuz, Strait of ‘
Horn of Africa (region)
Horn, Cape (Cabo de Hornos)
Horne, lles de (island group)
Hrvatska (local name for Croatia)
Hudson Bay
Hudson Strait
Hunter Island
Iberian Peninsula
Iceland Sea
Ifni (region; former name of part of Spanish West Africa)
Inaccessible Island
Indochina (region)
Ingushetia (region)
Inhambane (region)
Inini (former name for French Guiana)
inland Sea
Inner Hebrides (islands)
Inner Mongolia (region; also Nel Mongol)
lonian Islands
lonian Sea
Irian Jaya (province)
Irish Sea
iron Gate (river gorge)
Iskenderun (region; formerly Alexandretta)
Islamabad (capital)
Island (local name for Iceland)
Islas Malvinas (island group)
Istanbul (city)
Istrian Peninsula
italia (local name for Italy)
Italian East Africa (former name for Italian possessions in
eastern Africa)
italian Somaliland (former name for southern Somalia)
884
Entry in The
World Factbook
Southern Ocean','af09708d3c32aecd2eae1f82b36b67d991559313a1fdea67ec3e91db6b7a9672','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9611975ed60d553e5a589427c4aa1c128abc9890f04f893b01ffb78ca29a15e1',2025,'VU','Vanuatu','environment',1753,'Venezuela
Vietnam
Virgin islands
Virgin Islands (UK)
Virgin Islands (US)
Wake Island
Russia
Egypt, Sudan','28a21d36bc2afc76e5bbd74bba446430af803d6d482a8c076bccac2c3189b4c9','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1443808ee34466bfeef5001cf74c82e2d478c41346b08a8eac77bd31e97d2337',2025,'ZM','Zambia','environment',1754,'Zimhobwa
870
FIPS 10
UK
US
YM
7A
THE CIA WORLD FACTBOOK
GB
US
UM
PS
EH
ZM
ZW
JS0 3166
GBR
USA
UMI
PSE
826
840
581
858
Stanag-
1059
GBR
USA
Internet
suk
-US
um
-ps
eh
“ye
Zm
Comment
for its internal communications,
the European Union recommends
the use of the code UK in lieu of
the ISO 3166-2 code of GB
ISO includes Baker Island,
Howland Island, Jarvis Island,
Johnston Atoll, Kingman Reef,
Midway Islands, Navassa Island,
Palmyra Atoll, Wake Island
see British Virgin Islands
see Virgin Islands
ISO includes with the US Minor
Outlying Islands
ISO identifies as Occupied Pales-
tinian Territory
see Samoa
the Factbook uses the W data
code from DIAM 65-18 Geopo-
litical Data Elements and Related
Features, Data Standard No. 3,
December 1994, published by the
Defense Intelligence Agency
see Democratic Republic of the
Arctic Ocean
Atlantic Ocean','95da44b1ff8745b13411f1d554d6c00883a307c536b8a43f56002c6d72a29cc6','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('60699c8d22adda9f316cde46751bdf49c3bd28cdf3a6bb3c8b1fb0115690b55d',2025,'CG','Congo','environment',1755,'APPENDIX E
CROSS-REFERENCE LIST OF HYDROGRAPHIC DATA CODES
IHO 23-4th: Limits of Oceans and Seas, Special Publication 23, Draft 4th Edition 1986, published by the International Hydrographic
Bureau of the International Hydrographic Organization.
IHO 23-3rd: Limits of Oceans and Seas, Special Publication 23, 3rd Edition 1953, published by the International Hydrographic
Organization.
ACIC M 49-1: Chart of Limits of Seas and Oceans, revised January 1958, published by the Aeronautical Chart and Information Center
(ACIC), United States Air Force.
DIAM 65-18: Geopolitical Data Elements and Related Features, Data Standard No. 4, Defense ‘Intelligence Agency Manual 65-18,
December 1994, published by the Defense Intelligence Agency. The US Government has not yet adopted a standard for hydrographic codes
similar to the Federal Information Processing Standards (FIPS) 10-4 country codes. The names and limits of the following oceans and seas
are not always directly comparable because of differences in the customers, needs, and requirements of the individual organizations. Even the
number of principal water bodies varies from organization to organization. Facebook users, for example, find the Atlantic Ocean and Pacific
Ocean entries useful, but none of the following standards include those oceans in their entirety. Nor is there any provision for combining
codes or overcodes to aggregate water bodies. The recently delimited Southern Ocean is not included.
Principal Oceans and Seas of the World With Hydrographic Codes by Institution
IHO 23-4th IHO 23-3rd* © ACIC M 49-1 DIAM 65-18
Arctie Ocean 9 17 A ; 5A
Atlantic Ocean Fre = ao bad À
Baltic Sea i 2 1 B26 7B
Eastern Mediterranean Sule? 28B - 8E
Indian Ocean ~ 5 45 F l 6A
Mediterranean Sea aa 28 Bil . =
North Atlantic Ocean i B B 1A
North Pacific Ocean 7 S D 5 3A
Pacific Ocean i - -— -. -
South Atlantic Ocean 4 32 re: 2A
South China and Eastern Archipelagic Seas 6 _ 49,48 D18 plus others 3U plus others
South Pacific Ocean 8 61 E i 4A
Western Mediterranean Jll 28 A - 8W
cha MO
*The letters after the numbers are subdivisions, not footnotes.
871
This appendix cross-references a wide variety of geographic names to the appropriate Factbook "country" entry. Additional information is
included in parentheses.
Abidjan (capital)
Abkhazia (region)
Abu Dhabi (capital)
Abu Musa (island)
Abuja (capital)
Abyssinia (former name for Ethiopia)
Acapulco (city)
Accra (capital)
Adamstown (capital)
Addis Ababa (capital)
` Adelie Land (claimed by France; also Terre Adelie)
Aden (city)
Aden, Gulf of
Admiralty Island
Admiralty islands
Adriatic Sea
Adygey (region)
Aegean Islands
Aegean Sea
Afars and Issas, French Territory of the (or FTAI; former name
for Djibouti)
Afghanestan (local name for Afghanistan)
Agalega Islands i
Agana (city; former name for Hagatna)
Ajaccio (city)
Ajaria (region)
Akmola (city; former name for Astana)
Aksai Chin (region)
Al Arabiyah as Suudiyah (local name for Saudi pale) =
Al Bahrayn (local name for Bahrain)
Al imarat al Arabiyah al Muttahidah (local name for the United
Arab Emirates)
Al Iraq (local name for Iraq)
Al Jaza''ir (local name for Algeria)
Al Kuwayt (local name for Kuwait)
Al Maghrib (local name for Morocco)
Al Urdun (local name for Jordan)
Al Yaman (local name for Yemen)
Aland Islands
Alaska (state)
Alaska, Gulf of
Alboran Sea
Aldabra Islands (Groupe d‘Aldabra)
Alderney (istand)
Aleutian Islands
Alexander Archipelago (island giup)
872
A PAP EoD IX F
CROSS-REFERENCE LIST OF GEOGRAPHIC NAMES
Entry in The
World Factbook
Cote d''Ivoire
Latitude
(deg min)
456N
200S
300N |
51 00N
700N
230S
4945 N
49 00 N
4224N
35 53 N
700N
3512N
600S
1122N
49 20 N
1821N
4400S
43 15N
34 00 N
33 20N
30 43 N
13 04 N
1952S
38 30 N
4250S
35 00 N
23 30 N
47 0N
705S
4000 N
1025S
152N
69 00 N
725N
36 50 N
3300S
41 54N
11 00N
532 N
1230S
6 56 N
000 N
55 00N
1210S
8 43N
931N
4700N
100S
000N
Longitude
(deg min)
52 20 W
121 00 E
122 00 E
630 W
21 0E
129 30 E
1530E
1730E
1855E
519W
81 00 E
226 W
71 30E
- 142 36E
220W
64 56 W
176 30 W
45 40E
126 30 E
126 30 E
104 04 E
80 16 E
158 15 E
120 00 E
74 00 W
105 00 E
121 00 E
28 50 E
121 00 E
127 00 E
105 39 E
157 20 W
171 00 W
151 47 W
3430 E
27 00E
1227 E
107 00 E
87 04 W
96 50 E
TJANE
90 30 W
167 00 E
44 15E
106 36 E
1343W
8 00 E
15 00 E
25 00 E
CROSS-REFERENCE LIST OF GEOGRAPHIC NAMES
Constantinople (city; former name for Istanbul)
Cook Strait
Copenhagen (capital)
Coral Sea
Corfu (island)
Corinth (region)
Corisco (island)
Corn Islands (Islas del Maiz)
Corocoro Island
Corsica (island; also Corse) ;
Cosmoledo Group (island group; also Atoll de Cosmoledo)
Cotonou (former capital)
Cotopaxi (volcano)
Courantyne River
Cozumel (island)
Crete (island)
Crimea (region)
Crimean Peninsula
Crooked Island Passage
Crozet Islands (Iles Crozet)
Cyclades (island group)
Cyrenaica (region)
Czechoslovakia (former name for the entity that subsequently
split into the Czech Republic and Slovakia)
D''Entrecasteaux Islands
Dagestan (region)
Dahomey (former name for Benin)
Daito Islands
Dakar (capital)
Dalmatia (region)
Daman (city; also Damao)
Damascus (capital)
Danger islands (see Pukapuka Atoll)
Danish Straits
Danish West Indies (former name for the Virgin islands)
Danmark (local name)
Danzig (city; former name for Gdansk)
Dao Bach Long Vi (island)
Dar es Salaam (capital)
Dardanelles (strait)
Davis Strait
Dead Sea
Deception isiand
Denmark Strait
Desolation Islands (Isles Kerguelen)
Deutschland (local name for Germany)
Devils isiand (ile du Diable)
Devon Island
Dhaka (capital)
Dhivehi Raojje (local name for Maldives)
Entry in The
World Factbook
Turkey
Pacific Ocean
Kathmandu (capital) Nepal 2743.N 85 19E
Kattegat (strait) Atlantic Ocean 57 00N 1100E
Kauai Channel Pacific Ocean 2145N 158 50 W
Kazakstan (former name for Kazakhstan) Kazakhstan `- 4800N 68 00E
Keeling Islands Cocos (Keeling) Islands 1230S 9650E
Kerguelen, lies (island group) pet oe and Antarctic 4930S 69 30E
nas
Kermadec Islands New Zealand 2950S 178 15 W
Kerulen River China, Mongolia 48 48 N 117 00E
Khabarovsk (city) Russia 4827N 135 06 E
Khanka, Lake China, Russia ` 45 00N 132 24E
Khartoum (capital) Sudan 1536N 32 32E
Khios (island) Greece 38 22 N 26 04 E
Khmer Republic (former name for Cambodia) Cambodia 13 00N 105 00 E
Khuriya Muriya Isiands (Kuria Muria Islands) - Oman 1730N 56 00 E
Khyber Pass - Afghanistan, Pakistan 3405 N 71 10E
Kibris (Turkish local name for Cyprus) Cyprus 35 00N 33 00E
Kiel Canal (Nord-Ostsee Kanal) Atlantic Ocean 53 53 N 908E
Kiev (city; former name for Kyiv) Ukraine 5026 N 3031 E
Kigali (capital) : Rwanda 1157''S 3004E
Kingston (capital) Jamaica 18 00 N 76 48 W
Kingston (capital) Norfolk Island ` 2903S 167 58 E
Kingstown (capital) Saint Vincent and the 13 09 N 6114W
Grenadines
Kinshasa (capital) Democratic Republic of the 418S 15 18E
Kipros (Greek local name for Cyprus) Cyprus 35 00 N 33 00 E
Kirghiziya, Kirgizia (former name for Kyrgyzstan) - Kyrgyzstan 4100N 75 00 E
Kirguizstan (local name for Kyrgyzstan) Kyrgyzstan. 41 00N 75 OOE
Kiritimati (Christmas Island) Kiribati 152N 15720 W
Kishinev (see Chisinau) Moldova l 47 0N 28 50E ,
Kithira Strait Atlantic Ocean 36 00 N - 23 00E
Kobe (city) Japan 3441 N. 135 10E
Kodiak Island United States 5749 N 152 23 W
Kodok (town; also Fashoda) South Sudan 953 N 327E
Kola Peninsula (Kol''skiy Poluostrov) Russia 67 20N 37 00E
Kolonia (town; former capital; changed to Palikir) Federated States of Micronesia 658N 158 13E
Korea Bay l Pacific Ocean 39 00 N 124 0E
Korea Strait Pacific Ocean 34 00 N 129 00 E
Korea, Democratic People''s Republic of North Korea 40 00 N 12700E
Korea, Republic of South Korea 3700N ` 127 30E
Koror (capital) Palau 720N 134 29E
Kosovo (region) Kosovo “ 4230N 21 00E
Kosrae (island) Federated States of Micronesia 5 20N 163 00 E
Kowloon (city) Hong Kong l 2218 N 114 10E
Kra, Isthmus of Burma, Thailand 1020 N 99 00 E
Krakatoa (volcano) Indonesia 607S 105 24 E
886
CROSS-REFERENCE LIST OF GEOGRAPHIC NAMES
Krakow (city)
Kuala Lumpur (capital)
Kunashiri (island; also Kunashir)
Kantun Mountuins
Kuril Islands
Kuwait (capital)
Kuznetsk Basin
Kwajalein Atoll
Kyiv (capita!)
Kyushu (island)
La Paz (administrative capital)
La Perouse Strait
Labrador (peninsula, region)
Labrador Sea
Laccadive Isiands
Laccadive Sea
Lagos (former capital)
Lahore (city)
Lake Erie
Lake Huron
Lake Michigan
Lake Ontario
Lake Superior
Lakshadweep (Laccadive Islands)
Lantau Island
Lao (local name for Laos)
Laptev Sea
Las Palmas (city)
Latakia (region)
Latvija (local name for Latvia)
Lau Group (island group)
Lefkosa (see Nicosia)
Leipzig (city)
Lemnos (island)
Leningrad (city; former name for Saint Petersburg)
Lesser Sunda Islands
Lesvos (island)
Leyte (island)
Liancourt Rocks (claimed by Japan)
Liaodong Wan (gulf)
Liban (local name for Lebanon)
Libreville (capital) .
Lietuva (local name for Lithuania)
Ligurian Sea
Lilongwe (capital)
Lima (capita!)
Lincoln Sea
_ Line Islands
Lion, Gulf of
Lisbon (capital) -
Entry in The
World Factbook
Heard Island and McDonald
Islands
South Georgia and the South
Sandwich Islands
Pacific Ocean
Pacific Ocean','29df4fe4f6f17bbc752b8a5e31b875a3e94369995a26d9b4bc9d95f2e60b3813','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('93ca423878b604f1a9e0d1be2e542c56318dcde81417820530e000f1a9aee395',2025,'PG','Papua New Guinea','environment',1756,'Atlantic Ocean
Russia
Russia
Arctic Ocean
Saint Vincent and the
Grenadines
Russia
Indian Ocean','c319be853d3cbb86c04787b9adeebed9f2287f0256092842de36b076e63dba3d','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('24caacb7eb2e3b96c95de4aa5b3a0c77708bb4a9650b17115504cba5a7c8ff02',2025,'GG','Guernsey','environment',1757,'United States (Alaska)
United States (Alaska)
Latitude
(deg min)
519N
43 00 N
24 28 N
2552 N
912 N
800 N
1651 N
533N
2504S
902 N
66 30S
12 46N
12 30N
57 44N
210S
42 30N
44 30 N
38 00 N
38 30 N
1130N
33 00N
1025S
1328 N
4155N
4145 N
51 10N
35 00N
25 00 N
26 00 N
24 00 N
33 00N
28 00 N
2930 N
32 00N
31 00N
15 00N
60 15N
65 00 N
58 00N
36 00 N
925S
49 43 N
52 00N
57 00N
Longitude
(deg min)
402 W
4100E
5422E
5503 E
7 IE
38 00 E
99 55 W
013 W
13005 W
38 42 E
139 00 E
4501E
48 00E
134 20 W
147 00E
1600E
40 10E
25 00 E
25 00E
43 00E
65 00E .
56 40 E
144 45 E
8 44E
42 10E
71 30E
79 OO E
45 00 E
50 33 E
54 00 E
44 00 E
300E
4545E
500 W
36 00 E
48 00 E
20 00 E
153 00 W
145 00 W
230W
4622 E
212 W
176 00 W
134 00 W
CROSS-REFERENCE LIST OF GEOGRAPHIC NAMES
Alexander island
Alexandretta (region; former name for Iskenderun)
Alexandria (city)
Algiers (capital)
Alhucemas, Penon de (istand group)
Alma-Ata (city; former name for Almaty)
Almaty (former capital)
Alofi (capital)
Alphonse island
Alsace (region)
Amami Strait
Amindivi Islands (former name for Laccadive islands)
Amirante Isles (island group; also Les Amirantes)
Amman (capital)
Amsterdam (capital)
Amsterdam Island (lie Amsterdam)
< Amundsen Sea
Amur River
Amurskiy Liman (strait)
Anadyrskiy Zaliv (gulf)
Anatolia (region)
Andaman Islands
Andaman Sea
Andorra la Vella (capital)
Andros (island)
Andros Island
Anegada Passage
Angkor Wat (ruins)
Anglto-Egyptian Sudan (former name for Sudan)
Anjouan (island)
Ankara (capital)
Annobon (island)
Antananarivo (capital)
Antigua (island)
Antipodes Islands
Antwerp (city)
Aomen (local Chinese short-form name for Macau)
Aozou Strip (region)
Apia (capital)
Aqaba, Gulf of
Arab, Shatt al (river)
Arabian Sea
Arafura Sea
Aral Sea
Argun River
Aru Sea
As-Sudan (local name for Sudan)
Ascension Island
Ashgabat, Ashkhabad (capital)
Entry in The
World Factbook','ee095dea26769061c64aeadee56ac5a303b74836dd98abca746798a98d461d6c','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b6c38659cc9c4690de199198c340419c4f2e1734c6721a0cca7b11dc96e11208',2025,'AQ','Antarctica','environment',1758,'Turkey
Atlantic Ocean
French Southern and Antarctic
Lands
Argentina, Paraguay
The Bahamas
Atlantic Ocean
Latitude
(deg min)
16 30N
29 00S
5335N
42 54N
- 830S
` 4500N
1419S
. 5520N
2445S
000N
4245 N
4930 N
32 54 N
11 00 N
2309S
300S
~ 5423 N
4612 N
4425 N
1920N
526N
23 30N
648 N
13 30 N
52 00N
220S -
51 00N
- 36 11N
* 3557N
3013N
125N
1130S
1520N’
42 30N
64 11N
33 00N
8 00N
46. 00S
4130S
3424S
5743 N
5730N
4020S
6500S
2400S
26 40 N
47 06 N
Longitude
_ (deg min)
62 00 W
175 00 W
640E
74 36E
179 12 E
66 00 W
178 05 W
10 25E
25 55E
90 30 W
810E
23 0E
35 20E
60 55 W
134 58 W
107 00 E
18 40E
-610E
857E
8123 W
` 10016E
75 46 W
58 10 W
1447W
13 00 E
17 00 E
900E
522W
536W
33 09 E
173 00 E
47 20E
74 00E
107 00 E
5144W
3545E
200 W
66 00 W
64 00 W
18 30E
11 58 E
18 33 E
955W
64 00 W
60 00 W
78 35 W
55 48 W
CROSS-REFERENCE LIST OF GEOGRAPHIC NAMES
Grand Cayman (isiand)
Grand Turk (capital; also Cockburn Town)
Great Australian Bight
Great Belt (strait; also Store Baelt)
Great Bitter Lake :
Great Britain (island)
Great Channel
Great Inagua (island)
Great Rift Valley
Greater Sunda Islands
Green Islands
Greenland Sea
Grenadines, Northern (island group)
Grenadines, Southern (island group)
._ Grytviken (town; on South Georgia)
Guadalahara (city)
Guadalcanal (island)
Guadalupe, Isla de (island)
Guangzhou (city; also Canton)
Guantanamo Bay (US Naval Base)
Guatemala (capital)
Guine-Bissau (local name for Guinea-Bissau)
Guinea Ecuatorial (local name for Equatorial Guinea)
Guinea, Gulf of
Guinee (loca! name for Guinea)
Gustavia (capital)
Guyane Francaise (loca! name for French Guiana)
Ha''apai Group (island group)
Habomai Islands
Hadhramaut (region)
Hagatna (capital; formerly Agana)
Hague, The (seat of government)
Haifa (city)
Hainan Dao (island)
Haiphong (city)
Hala''ib Triangle (region)
Halifax (city)
Halmahera (island)
Halmahera Sea
Hamburg (city)
Hamilton (capital)
Han-guk (local name for South Korea
Hanoi (capital)
Harare (capital)
Harvey Istands (former name for Cook Islands)
Hatay (province)
Havana (capital)
Hawaii (island)
Hawaiian Islands 4
Entry in The
World Factbook
Saint Martin
Russia
Taiwan
Latitude
(deg min)
138N
42 40N
53 00 N
1053S
30 50N
821 N
48 00 N
3125N
46 48 N
53 00 N
78 00 N
7330S
2427 N
0138
3402 N
800N
1647N
2707S
900N
2000 N
16 55 N
19 00 N
700N
46 00 N
100S
200S
8 00 N
5535N
19 00 N
64 09 N
36 10N
1500S
2000S
5657N
57 30 N
130N
2255S
23 45 N
3500S
2438 N
1827 N
33 38 S
3518
5735N
19 42 S
41 54N
13 32 N
79 30S
15 18 N
80 00 S
Longitude
(deg min)
PSIE
21 10E
14 00E
165 49 W
7330 E
49 08E
68 00 E
34 20 E
7115W
132 00 W
95 00 W
12 00E
11823 E
7830 W
651W
167 00 E
96 10E
109 22 W
171 00E
38 O0 E
62 19 W
70 40 W
21 00E
200E
1145E
30 00E
110E
131 06 W
11245 W.
2157W
28 00 E
30 00E
30 00E
24 06 E
23 30 E
1000E
43.17 W
1545 W
5900 W
46 43 E
6437 W
7852 W
33 49 W
13 48 W
6325E
1229 E
80 03 W
162 00 W
6124W
180 00 E
CROSS-REFERENCE LIST OF GEOGRAPHIC NAMES
Entry in The : Latitude Longitude
Ross {sland Antarctica 8130S 175 00 W
Ross Sea ‘Antarctica, Southern Ocean 7600S 175 00 W
Rossiya (local name for Russia) _ Russia 60 00 N 100 00 E
Rota (island) - Northern Mariana Islands 1410N 14512E
Rotuma (island) Fiji ; 1230S 177 05 E
Ruanda (former name for Rwanda) Rwanda 200S . 30 00 E
Rub al Khali (desert) - . Saudi Arabia 1930N 49 00 E
Rumelia (region) Albania, Bulgaria, Macedonia 42 00N 22 30E
Ruthenia (region; former name for Carpatho-Ukraine) Ukraine aed 48 22N 23 32E
Ryukyu Islands Japan 26 30N 128 00 E
Saar (region) = Germany - 4925N 700E
Saaremaa (island) Estonia 5825 N 22 30E
Saba (island) Netherlands 1738 N 63 10 W
Sabah (state) T Malaysia 520N - 117 10E
Sable Island Canada 4355N 5950W .
Safety Islands (lles du Salut) French Guiana : 520N 5237 W
Sahara Occidental (former name for Western Sahara) Western Sahara 24 30 N 13 00 W
Sahel (region) Burkina Faso, Chad, The Gam- 15 00N 800 W
bia, Guinea- Bissau, Mali,
Mauritania, Niger, Senegal
Saigon (city; former name for Ho Chi Minh City) Vietnam 1045 N 106 40E
Saint Brandon (Cargados Carajos Shoals) Mauritius 1625S 59 38 E
Saint Christopher (island) Saint Kitts and Nevis 17 20N 6245 W
Saint Christopher and Nevis Saint Kitts and Nevis 17 20N 62 45 W
Saint Eustatius (island) Netherlands 1730N 63 00 W
Saint George''s (capital) Grenada 1203 N 6145 W
Saint George''s Channel Atlantic Ocean 52 00N -600 W
Saint Helena Island Saint Helena, Ascension, and 15575 54W
Tristan da Cunha
Saint Helens, Mount (volcano) _ United States 46 15N 122 12 W
Saint Helier (capital) Jersey 49 12N 207 W
Saint John (city) Canada (New Brunswick) 45 16N 66 04 W
Saint John''s (capital) Antigua and Barbuda 1706N 6151 W
Saint Lawrence Island United States 49 30N 6700 W
Saint Lawrence Seaway Atlantic Ocean 49 15N 67 00 W
Saint Lawrence, Gulf of Atlantic Ocean 48 00 N 62 00 W
Saint Paul island — Canada 4712N 6009 W
Saint Paul Island United States 5711 N 17016 W
Saint Paul island (ile Saint-Paul) i pa eee and Antarctic 3843S TI 29E
S
Saint Peter Port (capital) ; Guernsey 4927N 232W
Saint Peter and Saint Paul Rocks (Penedos de Sao Pedro e Sao Brazil 023 N 2923 W
Paulo)
Saint Petersburg (city; former capital) Russia 59 55 N 3015E
Saint Thomas (island) Virgin Islands 1821 N 6455W
Saint Vincent Passage Atlantic Ocean 1330 N 6100 W
Saint-Denis (capital) Reunion mi 2052S 5528 E
Saint-Pierre (capital) Saint Pierre and Miquelon 46 46 N 5611 W
Saipan (island) Northern Mariana Islands 1512N 145 45 E
Sak''art''velo (local name for Georgia) Georgia 42 00 N 43 30E
Sakhalin Island (Ostrov Sakhalin) —- Russia 5100N 143 00 E
Sakishima Islands : - Japa 24 30N 12400 E
s
895
THE CIA WORLD FACTBOOK
Sala y Gomez, Isla (island)
Salisbury (city; former name for Harare)
Salzburg (city)
Samar (island)
Samaria (region)
Samoo Islands
Samos (island)
San Ambrosio, Isla (island)
San Andres y Providencia, Archipielago (island group)
San Bernardino Strait
San Felix, Isla (island)
San Jose (capital)
San Juan (capital)
San Marino (capital)
San Salvador (capital)
Sanaa (capital)
Sandzak (region)
Santa Cruz (city)
Santa Cruz Islands
Santa Sede (local name for the Holy See)
Santiago (capital)
Santo Antao (island)
Santo Domingo (capital)
Sao Paulo (city) .
Sao Pedro e Sao Paulo, Penedos de (rocks)
Sao Tiago (isiand)
Sao Tome (island)
Sapporo (city)
Sapudi Strait
Sarajevo (capital)
Sarawak (state) :
Sardinia (island)
Sargasso Sea (region)
Sark (island)
Savage Island (former name for Niue)
Savu Sea
Saxony (region)
Schleswig-Holstein (region)
Schweiz (local German name for Switzerland)
Scopus, Mount i
Scotia Sea
Scotiand (region)
Scott Island
Senegambia (region; former name of confederation of Senegal
and The Gambia)
Senyavin Islands
Seoul (capital)
Serendib (former name for Sri Lanka)
Serrana Bank (shoal)
Serranilla Bank (shoal)
896
Entry in The
World Factbook
The Gambia, Senegal
Federated States of Micronesia
South Korea
French Southern and Antarctic
Lands
Pacific Ocean
Macedonia
Curacao','074a74f4394886eb263dd2a3001e8d3cc504d17856037ccba2f3fcd53812c855','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e18b63e645d0c234cbc5c762e0933f7c9b4a0d4b073754e74c87b5dee23656dc',2025,'IN','India','environment',1759,'Indian Ocean
Latitude
(deg min)
10125
1400S
1738N
4125N
74 00 N
1059N
22 00 N
6 49N
-4300N
3920S
2130S
16 00 N
17 18 N
4242 N
2930S
20 30 N
48 30 N
54 53 S
71426 N
73 00 N
2200S
39 56 N
33 53 N
34 00 N
730 N
1945S
54 36 N
0 00N
50 50 N
44 50 N
1730N
5135 N
7100S
1715 N
53 00 N
4 00N
24 30 N
15 00 N
2305S
55 00 N
60 00 N
65 30 N
79 30S
5231N
52 30N
52 30N
4657N
4700 N
2000 N
23 16N
Longitude
(deg min)
142 16E
167 30E
61 48 W
2 131Ẹ
36 00E
1448 W
121 00E
12205E
230 W
145 30 E
39 50 E
61 44 W
62 43 W
927E
28 30E
12150E
1130E
68 10 W
1905E
140 00 W
24 00 E
116 24E
3530E
36 05E
134 30 E
163 40 E
555W
25 00E
400E
2030E
88 12 W
56 30 W
85 00 W
88 46 W
28 00 E
46 00 E
88 15 E
90 00 E
132 30 E
166 30 E
175 00 W
169 00 W
49 30 W
13 24 E
13 33 E
13 20 E
726E
28 30E
77 00E
T724E
875
THE CIA WORLD FACTBOOK
Name Entry in The Latitude Longitude
World Factbook (deg min) (deg min)
Biafra (region) Nigeria 530N 730E
Big Diomede Isiand Russia 65 46 N 169 06 W
Bijagos, Arquipelago dos (island group) Guinea-Bissau 1125 N 1620 W
Bikini Atoll i Marshall Islands 1135N 165 23 E
Bilbao (city) Spain 43 15N 258 W
Bioko (island) Equatorial Guinea 330N 842E
Biscay, Bay of Atlantic Ocean 4400 N 400 W
Bishkek (capital) Kyrgyzstan 42 54 N 7436 E
Bishop Rock United Kingdom ` 4952 N 627W
Bismarck Archipelago (island group) Papua New Guinea 500S 150 00 E
Bismarck Sea Pacific Ocean 400S 148 00 E
Bissau (capital) Guinea-Bissau 1151N 1535 W
Bjornoya (Bear island) Svalbard 74 26N 1905E
Black Forest (region) Germany 48 00N 815E
Black Rock (island) South Georgia and the South 5339S 4148 W
Sandwich Islands
Black Sea - Atlantic Ocean 43 0ON 35 00E
Bloemfontein (judicial capital) South Africa 2912S 2607E
Bo Hai (gulf) _ Pacific Ocean 38 00 N 120 00 E
Boa Vista (island) Cape Verde 16 05 N 22 50 W
Bogota (capital) Colombia 436N 7405 W
Bohemia (region) Czech Republic 50 00 N 1430E
Bombay (city; see Mumbai) India 18 58 N 72 50E
Bonaire (island) Netherlands 1210 N 6815 W
Bonifacio, Strait of a Ocean (Mediterranean 41 01N 1400 E
Sea
Bonin Islands Japan 27 00N 142 10E
Bonn (former capital) Germany. __ 50 44 N 705E
Bophuthatswana (region; enclave) South Africa 2630S 25 30E
Bora-Bora (island) ; French Polynesia 1630S 15145 W
Bordeaux (city) France 44 50N 034 W
Borneo (island) Brunei, Indonesia, Malaysia 030N 11400E
Bornholm (island) l Denmark 55 10N 15 0E
Bosna i Hercegovina (local name for Bosnia and Herzegovina) Bosnia and Herzegovina 44 00 N 18 00 E
Bosnia (political region) Bosnia and Herzegovina 44 00N 18 00 E
Bosporus (strait) Atlantic Ocean 41 00N 29 00 E
Bothnia, Gulf of Atlantic Ocean 63 00N 2000E
Bougainville (island) . Papua New Guinea 600S 155 00 E
Bougainville Strait Pacific Ocean 640S 156 10E
Bounty Islands New Zealand 4743S . 17400E
Bourbon Island (former name of Reunion) Reunion 2106S " 5536E
Brasilia (capital) Brazil 1547S 4755 W
Bratislava (capital) Slovakia 48 09N 17 07 E
Brazzaville (capital) Republic of the Congo 4165S 15 17E
Bridgetown (capital) Barbados ''1306N 5937 W
Brisbane (city) - Australia 2728S 153 02E
Bristol Bay Pacific Ocean 5700N 160 00 W
Bristol Channel Atlantic Ocean 5118N 330W
Britain (see Great Britain) l United Kingdom 54 00N 20W
= ee (region; former name for northwest South South Africa 2730S 23 30E
rica
British Central African Protectorate (former name of Nyasaland) Malawi 1330S 34 00E
876
CROSS-REFERENCE LIST OF GEOGRAPHIC NAMES
British East Africa (former name for British possessions in
eastern Africa)
British Guiana (former name for Guyana)
British Honduras (former name for Belize)
British Solomon Islands (former name for Solomon Islands)
British Somaliland (former name for northern Somalia)
Brussels (capital)
Bubiyan (island)
Bucharest (capita!)
Budapest (capital)
Buenos Aires (capital)
Bujumbura (capita!)
Bukovina (region)
Byelarus (local name for Belarus)
Byelorussia (former name for Belarus)
Cabinda (province)
Cabo Verde (local name for Cape Verde)
Cabot Strait
Caicos Islands
Cairo (capital)
Calcutta (city)
Calgary (city)
California, Gulf of
Cameroun (ioca! name for Cameroon)
Campbell Island
Campeche, Bay of
Canal Zone (former name for US possessions in Panama)
Canarias Sea
Canary Islands
Canberra (capital)
Cancun (city)
Canton (city; now Guangzhou)
Canton Island (Kanton island)
Cape Juby (region; former name for Southern Morocco)
Cape Province (region; former name for Northern, Western, and
Eastern Cape Provinces of South Africa)
Cape Town (legislative capital)
Cape of Good Hope (cape; also alternate name for Cape Prov-
ince of South Africa)
Caracas (capital)
Cargados Carajos Shoals
Caribbean Sea
Caroline Islands
Carpatho-Ukraine (region; former name for Zakarpattya oblast’)
Carpentaria, Gulf of
Casablanca (city)
Castries (capital)
Catalonia (region)
Cato Island
Caucasus (region)
Entry in The
World Factbook
Kenya, Tanzania, Uganda
Syria
China, Mongolia’
India, Pakistan
Pacific Ocean
Laos
Indian Ocean
Indonesia, Papua New Guinea
Czech Republic, Germany,','e032000b6e90fa8bb50c5f9a193d4d9a983a528940a21c00f011512069e0ab02','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3d3ecfcf1a7aad733ab2dcfa803f8f5f08625465dd43c2586dcb5d6567fc1abb',2025,'BE','Belgium','environment',1760,'Macau
Latitude
(deg min)
5505N
4603 N
800N
2627S
828S
830S
608 N
5130N
78 133 N
3130S __
4842 N
1100S
2556S
2100S
8 48S
33 50N
1140S
1525S
49 45N
16 00 N
2030 N
73 45 N
22 10N
22 10N
5436S
2000S
4113N
3240N
13 04 N
40 24 N
5400S
34 00 N
32 00 N
47 00 N
AANS
1215N
39 30 N
705N
200S
41 50N
345 N
230N
2000S
230N
710N
410N
39 30N
50 26 N
Longitude
(deg min)
955E
1431 E
68 00 W
3112E
116 40E
115 50E
113E
010 W
1533E
159 00E
611E
153 00 E
32 34E
167 00E
13 14E
36 50 E
27 28E
2817E
610E
121 00E
121 00E
138 00 E
113 33E
11333E
158 54 E
470E
09 24 E
1645W
80 16 E
341W
710W
30E `
500 W
20 00 E
55 30E
83 00 W
3 00E
171 08 E
117 30E
22 00E
847E
101 20E
47 00 E
120 00 E
100 35 E
7331 E
300E
602E
CROSS-REFERENCE LIST OF GEOGRAPHIC NAMES
Malpelo, Isla de (island)
Malta Channel
Malvinas, Islas (island group)
Mamoutzou (capital)
Managua (capital) `- — i
Manama (capital)
Manchukuo (former state) |
Manchuria (region)
Manila (capital) l a
Manipa Strait
Mannar, Gulf of
Manua Islands
Maputo (capital)
Marcus Island (Minami-tori-shima)
Margarita, Isla (island)
Mariana Islands
Marie Byrd Land (region)
Marigot (capital)
Marion Island
Marmara, Sea of
Marquesas islands (lles Marquises)
Marseille (city)
Martin Vaz, tlhas (island group)
Mas a Tierra (Robinson Crusoe island)
Mascarene Isiands
Maseru (capital)
Mata-Utu (capital)
Matsu (island)
Matthew Island i
Mauritanie (local name for Mauritania)
Mazatlan (city)
Mbabane (capital)
McDonald Islands
Mecca (city)
Mediterranean Sea
Melbourne (city)
Melilla (exclave)
Memel (region)
Mesopotamia (region)
Messino, Strait of °
Mexico City (capital)
Mexico, Gulf of
Middle Congo (former name for Republic of the Congo)
Milan (city)
Milwaukee Deep (Puerto Rico Trench) —
Minami-torl-shima (Marcus island)
Mindanao (island)
Mindanao Sea
Mindoro (island) ss *
Entry in The
Worid Factbook
_ Colombia
Atlantic Ocean
’ Falkland Islands (Islas
Malvinas)
Mayotte -','35b56cc392d3368785c291ce43df36c3341ea9a340a0e64db9ecf2257085d952','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f0bfbe9c69871f9035863da8d92b912df14b6281198631f2025b085e411d6f07',2025,'WS','Samoa','environment',1761,'Indian Ocean
Iran, Iraq
Indian Ocean
Pacific Ocean
Kazakhstan, Uzbekistan
China, Russia
Pacific Ocean
Pacific Ocean
Arctic Ocean','5288416778895f381bc395480860de645878f0de1aa00a2acca753686a0cac71','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('47525c3f2ee70eb42e000eb1f90b1bbec5f647955aa676addaed194eebbee762',2025,'TM','Turkmenistan','environment',1762,'Lotitude
(deg min)
7100S
3634 N
3112 N
36 47 N
3513N
43 15N
43 15N
1901S
TOIS
48 30N
28 40 N
11 30N
6005S
3157 N
5223N
3752S
72 30S
52 56N
53 00N
64 00 N
39 00 N
12 00N
1000 N
42 30 N
3745 N
2426 N
18 30N
13 26 N
15 00N
1215S
39 56 N
125S
1852S
1434 N
4941S
STIJN
2210N
22 00 N
1350S
29 00 N
2957 N
15 00 N
900S
45 00N
53 20N
6155
15 00 N
7578
3757N
Longitude
(deg min)
70 00 W
36 08 E
29 54 E
203E
PEIN
76 57E
16 57E
169 55 W
5245E
720E
12930Ẹ
72 30E
53 10E
35 56E
454E
7732E
11200 W
141 10E
14130E
177 00E
35 00E
9245E
95 00E
130E
2442E
7757 W
63 40 W
103 50E
30 00 E
4425E
3252E
536E
47 30E
9044 W
178 43 E
425E
11333 E
18 00E
17144 W
3430E
48 34 E
65 00 E
133 00E
60 00 E
121 28 E
135 00 E
30 00E
1422W
58 23 E
873
THE CIA WORLD FACTBOOK
Name Entry in The Lotitude Longitude
World Factbook (deg min) (deg min)
Asmara, Asmera (capital) Eritrea 15 20N 3853 E
Assumption Island. Seychelles 946S 46 34 E
Astana (capital; formerly Akmola) Kazakhstan 51 10N 71 30 E
Asuncion (capital) Paraguay 2516S 57 40 W
Asuncion Island Northern Mariana Islands 19 40N 145 24 E
Atacama (desert) Chile 2300S 70 10 W
Atacama (region) Chile 2430S 69 15 W
Athens (capital) Greece 37 59N 23 44E
Attu Island United States 52 55N 172 57E
Auckland (city) New Zealand 3652S 17446E
-Auckland Isiands New Zealand 5100S 166 30E
Australes, Iles (island group; also Iles Tubuai) French Polynesia 23 20S 151 00 W
Avarua (capital) Cook Islands 2112''S 159 46 W
Axel Heiberg Island Canada 79 30N 90 00 W
Azad Kashmir (region) Pakistan 34 30N 74 00E
Azarbaycan, Azerbaidzhan (local name for Azerbaijan) Azerbaijan 40 30N 47 30E
Azores (islands) Portugal 38 30N 28 00 W
Azov, Sea of Atlantic Ocean 49 00 N 3600E
Bab el Mandeb (strait) „Indian Ocean 12 40N 43 20E
Babuyan Channel Pacific Ocean 18 44 N 121 40E
Babuyan Islands Philippines 19 10N 121 40E
Baffin Bay Arctic Ocean 73 00N 66 00 W
Baffin Island ` Canada 68 00N 70 00 W
Baghdad (capital) Iraq 3321 N 4425E
Baku (capital; also Baki, Baky) Azerbaijan 4023 N 4951 E
Balabac Strait Pacific Ocean 735N 117 00E
Balearic Islands Spain 3930 N 300E
Balearic Sea (Iberian Sea) n Ocean (Mediterranean 4030 N 200E
ea
Bali (island) Indonesia 820S 11500E
Bali Sea Indian Ocean 7458 11530E
Balintang Channel Pacific Ocean 19 49 N 121 40E
Balintang Islands Philippines 1955N 122 10 E
Balkan Peninsula - Albania, Bosnia and Herze- 42 00N 23 00E
govina, Bulgaria, Croatia,
Greece, Kosovo, Macedo-
nia, Montenegro, Romania,
Serbia, Slovenia, Turkey
(European part)
Balleny Islands Antarctica 67 00S 163 00 E
Balochistan (region) : Pakistan 28 00 N 63 00 E
Baltic Sea : ; - Atlantic Ocean 57 00N 19 00E
Bamako (capital) Mali 1239N 800 W
Banaba (Ocean Island) Kiribati 052S 169 35 E
Banat (region) Hungary, Romania, Serbia 45 30N 21 00E
Banda Sea Pacific Ocean 5008S 128 00 E
Bandar Seri Begawan (capitat) : '' Brunei 453 N 114 56E
Bangka (island) Indonesia 23016 106 00 E
Bangkok (capital) Thailand 1345 N 100 31 E
Bangui (capital) Central African Republic 422N 18 35E
Banju! (capital) a The Gambia 13 28 N 1639 W
Banks Island : Canada 75 15N 12130 W
874
CROSS-REFERENCE LIST OF GEOGRAPHIC NAMES
Banks tstand
Banks Islands (lles Banks)
Barbuda (isiand)
Barcelona (city)
Barents Sea
Barranquilla (city)
Bashi Channel
Basilan Strait
Basque Provinces
Boss Strait
Bassas da India
Basse-Terre (capital)
Basseterre (capital)
Bastia (city)
Basutoland (former name for Lesotho)
Baton islands
Bavaria (region; also Bayern)
Beagle Channel
Bear Island (see Bjornoya)
Beaufort Sea
Bechuanaland (former name for Botswana)
Beijing (capital)
Beirut (capita!)
Bekaa Valley
Belau (Palau Islands)
Belep Islands (Iles Belep)
Belfast (city)
Belgian Congo (former name for Democratic Republic of the
Congo)
Belgie, Belgique (local name for Belgium)
Belgrade (capital)
Belize City
Belle Isle, Strait of
Bellingshausen Sea
Belmopan (capital)
Belorussia (former name for Belarus)
Benadir (region; former name of Italian Somaliland)
Bengal (region)
Bengal, Bay of
Berau, Guif of
Bering Island
Bering Sea
Bering Strait
Berkner island ’
Berlin (capital)
Berlin, East (former name for eastern sector of Berlin)
Berlin, West (former name for western sector of Berlin)
Bern (capital)
Bessarabia (region)
Bharat (local name for India)
Bhopal (city)
+
Entry in The
World Factbook
Atlantic Ocean','3a0372fdbf83ee86937806457966224d1bb3597f8ce0d7c87be2308bd2412c0a','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4241aa89bfeafc8f091c5abe9ecb9995445ce6700360fc85c9817f74dbc18bdb',2025,'ES','Spain','environment',1763,'Arctic Ocean.
Pacific Ocean
Indian Ocean
France (Guadeloupe)
Poland, Ukraine
Atlantic Ocean
Algeria, Libya, Mauritania,
Morocco, Tunisia','bf0991147274b4c1612d07ca213cece0a0994ba5e5c289a9c18dfc695967c4f0','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3617ab6477623a1bb022a4fa5221d0ee4fae1d483d2527ee3caca2762d7daede',2025,'CO','Colombia','environment',1764,'Pacific Ocean
Pacific Ocean
Pacific Ocean
Latitude
(deg min)
2628S
1750S
47 48 N
12 00N
32 15N
1400S
37 48N
2621S
13 00N
1232 N
2617S
956 N
1828 N
43 56 N
1342 N
1521 N
43 05 N
1748S
1100S
4154N
3327S
1705N
1828 N
2335S
023N
1505N
012N
43 04 N
705S
43 52 N
230N
40 00 N
3000N
4926 N
1902S
930S
5100N
5431N
47 00N
3148N
5600S
5700 N
6724S
13 50N
655 N
3734 N
700N
1425N
1551 N
Longitude
(deg min)
105 00 W
105 00 W
1302E
12500E
3510E
171 00 W
2644E
79 52 W
8130W
124 10 E
8005 W
84 05 W
66 07 W
1225E
8912 W
4412E
1945E
63 10 W
166 15E
1227E
70 40 W
25 10 W
69 54 W
46 43 W
2923 W
23 40 W
639E
141 20 E
11410E
1825E
11330E
900E
55 00 W
221W
169 52 W
122 00 E
13 00 E
933E
8 00 E
35 14E
40 00 W
400 W
179 55 W
1525 W
158 00 E
127 00 E
81 00 E
80 16 W
1946 W
CROSS-REFERENCE LIST OF GEOGRAPHIC NAMES
Settlement, The (capital)
Severnaya Zemlya (island group; also Northland)
Shaba (region)
Shag Island
Shag Rocks
Shanghai (city)
Shenyang (city; also Mukden)
Shetland Islands
Shikoku (island)
Shikotan (istand)
Shqiperia (local name for Albania)
Siam (former name for Thailand)
Siberia (region)
Sibutu Passage
Sicily (island)
Sicily, Strait of
Sidra, Gulf of
Sikkim (state)
Silesia (region)
Sinai Peninsula
Singapore (capital)
Singapore Strait
Sinkiang (autonomous region; also Xinjiang)
Sint Eustatius (island)
Sint Maarten (island; also Saint-Martin)
Sjaelland (island)
Skagerrak (strait)
Skopje (capital)
Slavonia (region)
Slovenija (local name for Slovenia)
Slovensko (local name for Slovakia)
Smyrna (region; former name for Izmir)
Society Islands (iles de la Societe)
Socotra (island)
Sofia (capital)
Solomon Islands, northern
Solomon Islands, southern
Solomon Sea
Somaliland (region)
Somers Islands (former name for Bermuda)
Songkhla (city)
Sound, The (strait; also Oresund)
South Atlantic Ocean
South China Sea
South Georgia (island)
South Island
South Korea ~ y
Entry in The
World Factbook','27aa8151af298d2f80cdfce99cdee742d03c7fb2dad12f5419f34c2eadce3704','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7fd606a45b4d1fc007a4469df7b9791e5872a13b16b59fc17b830fa07d568d95',2025,'GB','United Kingdom','environment',1765,'Democratic Republic of the
Atlantic Ocean
Indian Ocean
The Bahamas
Ethiopia, Kenya
Brunei, Indonesia, Malaysia
Svalbard','a53db2783c77d6a6a3177f45c80222571ae23a4ca7324b09ca01c018de169323','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('45d0f235250ca510961fe8ebd612d2542d9b79b7c744264d5c944dceb4953511',2025,'SO','Somalia','environment',1766,'Bangladesh, India
Indian Ocean
Pacific Ocean
Russia
Pacific Ocean
Pacific Ocean
Latitude
(deg min)
2540N
4000 N
5306S
2430N
60 10N
44 00 N
58 50 N
18 45 N
1045 N
44 00 N
52 30 N
22 15N
9265
36 00 N
26 34 N
800 N
5559S
1419S
45 10N
60 00 N
62 00N
22 24S
4000 N
68 00 N
2922 N
37178
1500N
43 15N
22°30''S
400N
3420N
56 30 N
42 00 N
38 30 N
38 30 N
5005
53 30 N
4441 N
36 34 N
3342 N
65 00 N
5145S
4101N
45 00N
42 50N
800N
10 00 N
Longitude
(deg min)
5047E
45 00E
73 30 E
38 30 E
24 58 E
18 00 E
22305
71 00 W
106 40 E
143 00 E
545E
114 10E
159 57 E
138 00 E
56 15 E
48 00E
67 16 W
17805 W
15 30E
86 00 W
71 00 W
172 06 E
500 W
2000 W
1009 W
12 40 W
107 00 E
45 00E
34 30E
53 00 W
133 30E
6 20 W
113 00 E
20 30 E
18 00 E
138 00 E
5 20 W
ZONE
36 08 E
73 10E
18 00 W
59 00 W
28 58 E
14 00 E
12501
38 00 E
49 00 E
CROSS-REFERENCE LIST OF GEOGRAPHIC NAMES
ittihad al-imarat al-Arabiyah (local name for the United Arab
Emirates)
Iturup (island; see Etorofu)
ityop''iya (local name for Ethiopia)
Ivory Coast (former name for Cote d''ivoire)
Iwo Jima (island)
Izmir (region)
Jakarta (capital)
James Bay
Jamestown (capital)
Jammu (city)
Jammu and Kashmir (region)
Japan, Sea of
Jars, Plain of
Java (island)
Java Sea
Jerusalem (capital, proclaimed)
Jiddah, Jeddah (city)
Johannesburg (city)
Joseph Bonaparte Guif
Juan Fernandez, Islas de (island group)
Juan de Fuca, Strait of
Juan de Nova Island
Juba (capital)
Jubal, Strait of
Judaea (region)
Jugoslavia, Jugoslavija (local names for Yugoslavia, a former
Balkan federation)
Jutland (region)
Juventud, Isla de Ia (Isle of Youth)
Kabardino-Balkaria (region)
Kabul (capital)
Kaduna (city)
Kailas Range
Kalaallit Nunaat (local name for Greenland)
Kalahari (desert)
Kalimantan (region)
“Kaliningrad (region; formerly part of East Prussia)
Kamaran (island)
Kamchatka Peninsula (Poiuostrov —_
Kampala (capital)
Kampuchea (former name for Cambodia)
Kane Basin (portion of channel)
Kanton Island
Kara Sea
Karachevo-Cherkessia (region)
Karachi (city)
Karafuto (island; former name for southern Sakhalin Island)
Karakoram Pass
Karelia, Kareliya (region) “
Entry in The
World Factbook','0250fbdc8f20c7672ec1d1822ae6a99c1f18bc0c1050a8c8ddd741cb49896f63','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('de9a0b7b086b291b62ca0998ca68b415b89bfac085c44c1355ad10a86c13ba66',2025,'CA','Canada','environment',1767,'Pacific Ocean
Atlantic Ocean
Latitude
(deg min)
1000 N
2405 N
1215 N
5100S
4 00N
17 09 N
6005
28 36 N
500S
1600S
320N
75 00 N
2224 N
52 00 N
1331 N
8 00 N
35 10N
3725S
36 00 N
530N
62 00 N
49 20N
30 00 N
55 10N
54 50 N
78 00 N
3900S
43:00 N
30 00 N
56 00 N
23 00 N
15 00 N
25 40 N
360 N
35 15N
40 00 N
1245 N
54 40 N
1500S
74 40 N
66 00 N
18 06 N
2216S
2130S
1600S
74 00 N
2030N
2108S
72 00N
Longitude
(deg min)
123 00 E
45 15E
68 45 W
120 00 E
56 00 W
62 35 W
150 00 E
TTIZE
140 00 E
167 00 E
152 00 E
142 00 E
114 10E
56 00 W
207E
93 30E
SoHE
12 30 W
138 00 E
153 40 E
1000 E
220W
45 00 W
540W
812E
50W
176 00 E
44 10E
165 00 W
40E
106 00 E
44 00E
7709 W
150E
33 44E
2030 E
6115W
645 W
30 00 E
100 00 W
600E
1557 W
16627 E
165 30 E
167 00 E
57 00 E
33 00E
175 12 W
90 00 W
891
Nuuk (capital; also Godthab)
Nyasaland (former name for Malawi)
Nyassa (region)
Oahu (island)
Ocean island (Banaba)
Ocean Island (Kure Island)
Oesterreich (local name for Austria)
Ogaden (region)
Oil Islands (Chagos Archipelago)
Okhotsk, Sea of
Okinawa (island group)
Oland (island)
Oman, Gulf of
Ombai Strait
Oran (city)
Orange River Colony (region; former name of Free State Prov-
ince of South Africa)
Oranjestad (capital)
Oresund (The Sound) (strait)
Orkney Islands
Osaka (city)
Oslo (capital)
Osumi Strait (Van Diemen Strait)
Otranto, Strait of
Ottawa (capital)
Ouagadougou (capital)
Outer Hebrides (islands)
Outer Mongolia (region)
P''yongyang (capital)
Pacific Islands, Trust Territory of the (former name of a large
area of the western North Pacific Ocean)
Pagan (island)
Pago Pago (capital)
Palawan (island)
Palermo (city)
Palestine (region)
Palikir (capital)
Palk Strait
Pamirs (mountains)
Pampas (region)
Panama (capital)
Panama Canal
Panama, Guif of
Panay (island)
Pantelleria, Isola di (island)
Papeete (capital)
Paramaribo (capital)
Parece Vela (island)
Paris (capital)
Pascua, Isla de (Easter Island)
Pashtunistan (region)
892
THE CIA WORLD FACTBOOK
Entry in The
World Factbook
Lotiteds
(deg min)
1017N
4800S
39 56 N
3540 N
701N
3730N
520S
523N
58 44N
1239 N
4445 N
32 00N
27 00N
3156S
2330 N
3401 N
68 48S
5955 N
2908S
20 00 N
181 N
1133 N
330S
15 08 N
21 40N
032S
16 44 N
4226 N
52 00N
1500S
53 40 N
655N
2010S
930S
1744S
1832 N
1039 N
629 N
1815S
12 00 N
900S
5225 N
5005 N
1455 N
15 00N
2542S
4224N
5700 N
46 20N
4635S
7630 N
Longitude
(deg min)
109 13 W
61 00 W
116 24E
12 40E
13415E
2225E
39 45 E
100 15E
313 W
43 25E
142 0E
53 00 E
51 00E
115 50E
11930E
71 40E
90 35 W
3015 E
167 57 E
134 00 E
632 W
104 55 E
172 00 W
12021E
82 50 W
166 55 E
6214W
1916 E
20 00 E
140 00 W
1535E
15815 E
57 30E
147 10E
168 19E
72 20 W
6131 W
Love
35 00 E
15 00 W
126 00 E
(Goo E
1428 E
2331 W
100 00 E
28 13E
18 31 E
170 00 W
63 20 W
38 00 E
119 00 W
893
THE. CIA WORLD FACTBOOK
Principe (island)
Pristina, Prishtina, Prishtine (capital)
Prussia (region)
Pukapuka Atoll
Punjab (region)
Puntland (region)
Qazaqstan (local name for Kazakhstan)
Qita Ghazzah (local name Gaza Strip)
Quebec (city)
Queen Charlotte Islands
Queen Elizabeth Islands
Queen Maud Land (claimed by Norway)
Quemoy (island)
Quito (capital)
Rabat (capital)
Ralik Chain (island group)
Rangoon (capital; also Yangon)
Rapa Nui (Easter Island)
Ratak Chain (istand group)
Red Sea
Redonda (island) :
` Republica Dominicana (local name for Dominican Republic)
Republique Centrafricain (local name for Central African
Republic) :
Republique Francaise (local name for France)
Republique Gabonaise (local name for Gabon)
Republique Rwandaise (local name for Rwanda)
Republique Togolaise (local name for Togo)
Revillagigedo Isiand
Revillagigedo Isiands
Reykjavik (capital)
Rhodes (island)
Rhodesia, Northern (former name for Zambia)
Rhodesia, Southern (former name for Zimbabwe)
Riga (capital)
Riga, Guif of
Rio Muni (mainland region)
Rio de Janiero (city)
Rio de Oro (region)
Rio de ta Plata (gulf)
Riyadh (capital)
Road Town (capital)
Robinson Crusoe Isiand (Mas a Tierra)
Rocas, Atol das (island)
Rockall (istand)
Rodrigues (island)
Rome (capital)
Roncador Cay (Island)
Roosevelt island
Roseau (capital)
Ross Dependency (claimed by New Zealand)
894
Entry in The
World Factbook
Pacific Ocean
Holy See
Russia','dc5f8c001f93d3b8a099de36c493ec26fa95489172e5b4743850bb73361a9b8e','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5a7cb9b64f69ef308df4c1f448fefd73228258b38a2568b7d815ee8641843687',2025,'NZ','New Zealand','environment',1768,'Atlantic Ocean (Gulf of
Mexico)
Russia
Pacific Ocean
Korea, South
Russia
Pacific Ocean
Atlantic Ocean
Vietnam
South Korea
Latitude
(deg min)
1025S
79 30N
800S
53 00S
53 33 S
31 14N
41 46 N
60 30 N
33 45 N
4347 N
41 00N
15 00 N
60 00 N
4 50N
3730 N
37 20 N
31 30N
27 50N
51 00 N
29 30 N
117 N
115N
42 00N
1729N
1804N
55 30N
5745 N
41 59N
45 27N
46 00 N
48 40 N
3825 N
17 00S
12 30N
4241 N
6005S
800S
800S
930 N
3220 N
712 N
55 50 N
3000S
1000 N
5415S
4300S
3700N
Longitude
(deg min)
105 43 E
98 OOE
2700E
1230 E
4202 W
121 30E
123 24 E
130 W
133 30E
146 45 E
20 00 E
100 00 E
100 00 E
IOS SE
1400E
1120E
1800E
88 30 E
17 00E
34 00 E
103 51 E
104 00 E
86 00 E
62 58 W
63 04 W
12 00 E
900E
21 26E
18 00 E
15 00 E
19 30E
27 10E
150 00 W
54 00E
23 19E
155 00 E
159 00 E
153 00 E
46 00 E
6445 W
100 36 E
12 40 E
1500 W
113 00E
36 45 W
171 00 E
127 30E
897
South Orkney Islands
South Ossetia (region)
South Pacific Ocean
South Sandwich Islands
South Shetland Islands
South Tyrol (region)
South Vietnam (former name for the southern portion of
Vietnam)
South Yemen (People''s Democratic Republic of Yemen; now part
of Yemen)
South-West Africa (former name for Namibia)
Southern Grenadines (island group)
Southern Rhodesia (former name for Zimbabwe)
Soviet Union (former name of a large Eurasian empire, roughly
coequal with the former Russian Empire)
Spanish Guinea (former name for Equatorial Guinea)
Spanish Morocco (former name for northern Morocco)
Spanish North Africa (exclaves)
Spanish Sahara (former name)
Spanish West Africa (former name for Ifni and Spanish Sahara)
Spice Islands (Moluccas)
Spitsbergen (island)
Srbija (local name for Serbia)
St. John''s (city)
Stanley (capital)
Stockholm (capita!)
Strasbourg (city)
Stuttgart (city)
Sucre (constitutional capital)
Suez Canal l
Suez, Gulf of
Suisse (local French name for Switzerland)
Sulawesi (island; Celebes)
Sulawesi Sea
Sulu Archipelago (island group)
Sulu Sea
Sumatra (istand)
Sumba (island)
„Sumba Strait
Sumbawa (island)
Sunda Islands (Soenda Isles)
Sunda Strait
Suomi (local name for Finland)
Surabaya (city)
Surigao Strait
898
THE CIA WORLD FACTBOOK
Entry in The
World Factbook','ff701cfb63f3b27e4eff1c909ae0cc91a76e4258856cb0f33b53f38d4d052eec','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bde705229524de991422a25e39936eeb4c1055fc101ed9482208b6b887a4534b',2025,'AU','Australia','environment',1769,'Russia
Latitude
(deg min)
1 00N
500 N
17 15N
800S
1000 N
50 50 N
2947N
44 26 N
47 30N
3436S
323S
48 00 N
53 00 N
53 00 N
5133$
16 00 N
47 20 N
21 56N
3003 N
2232 N
5102 N
28 00 N
600 N
5233S
20 00 N
900N
28 00 N
28 00 N
3517S
21 10N
23 06 N
249S
27 53 N
3130S
3357S
3415S
10 30 N
1625S
1500N
‘730N
4822 N
1400S
3335N
1401 N
42 00 N
23155
42 00 N
Longitude
(deg min)
38 00 E
59 00 W
88 45 W
159 00 E
49 00E
420E
48 10E
26 06 E
1905 E
5827 W
292E
26 00 E
28 00 E
28 00E
1212E
24 00 W
59 30 W
7158 W
3L TSE
88 21 E
114 04 W
112 00 W
12 00 E
169 09 E
94 00 W
79 45 W
16 00 W
15 30 W
149 08 E
86 50 W
113 16E
171 40 W
12 58 W
22 30E
1825E
18 20 E
66 56 W
59 38 E
73 00 W
148 00 E
SME
139 00 E
7134W
61 00 W
200E
155 32 E
45 00E
877
THE CIA WORLD FACTBOOK
Name
Cayenne (capital)
Celebes (island)
Celebes Sea
Celtic Sea
Central African Empire (former name for Central African
Republic)
Ceram (Seram) Sea
Ceska Republika (local name for Czech Republic)
Ceskoslovensko (former local name for Czechoslovakia)
Cetinje (capital city)
Ceuta (city)
Ceylon (former name for Sri Lanka)
Chafarinas, Islas (island)
Chagos Archipelago (Oil Islands)
Challenger Deep (Mariana Trench)
Channel Islands
Charlotte Amalie (capital)
Chatham Islands
Chechnya (region; also Chechnia)
Cheju Strait
Cheju-do (island)
Chengdu (city)
Chennai (city; also Madras)
Chesterfield Islands (Iles Chesterfield)
Chihti, Gulf of (see Bo Hai)
Chiloe (island)
China, People''s Republic of
China, Republic of
Chisinau (capital; also Kishinev)
Choiseul (island)
Choson (local name for North Korea)
Christmas Island (indian Ocean)
Christmas Island (Pacific Ocean; also Kiritimati)
Chukchi Sea
Chuuk Islands (Truk Islands)
Cilicia (region)
Ciskei (enclave)
Citta del Vaticano (local name for Vatican City)
Cochin China (region)
Coco, Isla del (island)
Cocos Islands
Colombo (capital)
Colon, Archipielago de (Galapagos Islands)
Commander Islands (Komandorsklye Ostrova)
Comores (local name for Comoros)
Con Son (islands)
Conakry (capital)
Confederatio Helvetica (local name for Switzerland)
Congo (Brazzaville) (former name for Republic of the Congo)
Congo (Leopoldville) (former name for the Democratic Repub-
lic of the Congo)
878
Entry in The
World Factbook
Taiwan
Pacific Ocean
Russia','92700c94a999f2222060e16b5167a49b04a8681fda81ec76c2bf8d60e8fa4294','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b4b49fd64fdf0f91fd39ceaa3e91cae1d8085cfbb5df29a4002c6d8868d9a0bf',2025,'CN','China','environment',1770,'Taiwan
Moldova
Vietnam
Egypt (claimed), Sudan (de
facto)
Russia (de facto)
Israel, West Bank','a34dd12d37c462d2205bd038cee95622ac5e3b1db014af4a9080ec581c5b06a8','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a1ba72790ef71961d153700335953f28bac68e9ee5a4049b0163fb249603bfeb',2025,'PL','Poland','environment',1771,'Vietnam
Tanzania
Atlantic Ocean
Atlantic Ocean
Israel, Jordan, West Bank
Czech Republic
Cape Verde','4b1be775b544b9953c288aeaedeeea3d53058b332e569481d66018e57ec1b347','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b42ecf4c5940bae408c78e84f62dedb183c38346427a1614c786d3f05f4f94d7',2025,'MV','Maldives','environment',1772,'Latitude
(deg min)
4101 N
4115S
5540N
1500S
39 40 N
37 56N
055N
1215N
338 N
42 00 N
943S
621 N
0398
557N
20 30N
35 15N
45 00 N
45 00 N
2255 N
4630S
37 00 N
31 00N
49 00 N
930S
43 00 N
930N
43 00 N
14 40 N
43 00 N
20 10N
33 30 N
1053S
58 00 N
18 20N
56 00 N
54 23 N
20 08 N
6485S
4015 N
67 00 N
32 30 N
62 56S
67 00 N
4930S
51 00N
517N
76 00 N
2343 N
315N
Longitude
(deg min)
28 58 E
174 30E
12 35E
150 00 E
1945E
22 56E
919E
83 00 W
66 50 W
900E
4735E
226E
78 26 W
57 06 W
86 55 W
2445E
3400E
34 00 E
7435 W
51 00E
25 10E
22 00 E
18 00 E
150 40 E
47 00E
25E
17 00 E
17 26 W
17 00 E
73 00 E
36 18E
165 49 W
11 00 E
64 50 W
10 00 E
18 40 E
10744E
IHE
2625E
57 00 W
35 30E
60 34 W
24 00 W
69 30 E
900E
5235 W
87 00 W
90 25E
73 00E
879
THE CIA WORLD FACTBOOK
Name - Entry in The Latitude Longitude
World Factbook (deg min) (deg min)
Dhofar (region) Oman 1700N 54 10E
Diego Garcia (island) British Indian Ocean Territory 7208S 7TZ251E
Diego Ramirez (islands) Chile 5630S 68 43 W
Dill (capital) Timor-Leste ` B35S _ 12536E
Dilmun (former name for Bahrain) Bahrain 700N 81 00E
Diomede Islands - Russia (Big Diomede), United 65 47 N 169 00 W
States (Little Diomede)
Diu (region) India 20 42N 70 59E
Djibouti (capital) Djibouti 11 30N 43 15E
Dnieper (river) Belarus, Russia, Ukraine 46 30N | 3218E
(Dnyapro, Dnepr, Dnipro)
Dniester (river) Moldova, Ukraine (Nistru, 46 18N 3017E
Dnister)
Dobruja (region) Bulgaria, Romania 43 30N - 2800E
Dodecanese (island group) Greece 36 00 N 2705''E
Dodoma (city) Tanzania 611S — 35 45 E
Doha (capital) Qatar 2517 N 5132E
Donets Basin Russia, Ukraine ~ 48 15N 38 30 E
Douala (city) Cameroon 403 N 942E
Douglas (capital) Man, Isle of 54 09 N 428 W
Dover, Strait of Atlantic Ocean 51 00N 130E
Drake Passage Atlantic Ocean, Southern 6000S 60 00 W
Ocean
Druk Yul (local name for Bhutan) Bhutan 2730N 90 30 E
Dubai, Dubayy (city) United Arab Emirates ` 25 18N 5518E
Dublin (capital) _ Ireland 53 20N 615 W
Duesseldorf (city) Germany 5113N 647E
Durban (city) South Africa 2951S 3102E
Dushanbe (capital) Tajikistan 38 35 N 68 48 E
Dutch Antilles (former name for the Netherlands Antilles) Aruba, Curaçao, Sint Maarten 12 10N 68 30 W
Dutch East Indies (former name for Indonesio) Indonesia 500S 120 00 E
Dutch Guiana (former name for Suriname) Suriname 40N 560W `
Dutch West Indies (former name for the Netherlands Antilles) Aruba, Curacao, Sint Maarten 12 10N 68 30 W
Dzungarian Gate (valley) China, Kazakhstan 45 25 N^ 8225E
East China Sea Pacific Ocean 3000 N 126 00 E
East Frisian Islands =. Germany 53 44 N T25E
East Germany (German Democratic Republic; former name for Germany 52 00N 13 00 E
eastern portion of Germany)
East Korea Strait (Eastern Channel or Tsushima Strait) Pacific Ocean 34 00N 129 00 E
East Pakistan (former name for Bangladesh) - Bangladesh 24 00N ` 90 00E
East Siberian Sea a Arctic Ocean 74.00 N 166 00 E
Easter Island (Isla de Pascua) Chile 2707S 109 22 W
Eastern Channel (East Korea Strait or Tsushima Strait) Pacific Ocean 34 00 N 129 00 E
Eastern Samoa (former name for American Samoa) American Samoa 1420S 170 00 W
Edinburgh (city) l ‘United Kingdom 55 57N 311W
Eesti (locat name for Estonia) Estonia 5900N. 26 00 E
Eire (local name for Ireland) Ireland 53 00 N 8 00 W
Elbo (island) Italy 42 46 N 10 ITE
Elemi Triangle (region) . Ethiopia (claimed), Kenya (de 500N 35 30 E
facto), Sudan (claimed)
Ellada, Ellas (local name for Greece) Greece 39 00N 22 00 E
Ellef Ringnes island Canada 78 00N 103 00 W
Ellesmere Island > Canada 81 00N 80 00 W
Ba0
CROSS-REFERENCE LIST OF GEOGRAPHIC NAMES
Eliicé Islands
Ellsworth Land (region)
Elobey, Islas de (island group)
Enderbury Island
Enewetak Atoll (Eniwetok Atoll)
England (region)
` English Channel
Eniwetok Atoll (see Enewetak Atoll)
Eolie, isole (island group)
Epirus, Northern (region)
Episkopi Cantonment (capital)
Ertra (local name for Eritreo)
Espana
Essequibo (region; claimed by Venezuela)
Etorofu (island; also Iturup)
Europa Island
Farquhar Group (island group; also Atoll de Farquhar)
Fashoda (town; also Kodok)
Fergana Valley
Fernando Po (island; see Bioko)
Fernando de Noronha (island group)
Filipinas (local name for the Philippines; also Pilipinas)
Finland, Gulf of
Fiume (city; former name for Rijeka)
Florence (city)
Flores (island)
Flores Sea
Florida, Straits of
Fongafale (largest island of Funafuti)
Former Soviet Union (FSU)
Formosa (island)
Formosa Strait (see Taiwan Strait)
Foroyar (local name for Faroe Islands)
Fort-de-France (capital)
Frankfurt am Main (city)
Franz Josef Land (island group)
Freetown (capital)
French Cameroon (former name for Cameroon)
French Guinea (former name for Guinea)
French Indochina (former name for French possessions in
southeast Asia)
French Morocco (former name for Morocco)
French Somaliland (former name for Djibouti)
French Sudan (former name for Mali)
French Territory of the Afars and Issas (or FTAI; former name for
Djibouti) `
French Togoland (former name for Togo)
Entry in The
World Factbook','6e5ee461b7086c7d0d7d4c3aaeb1f0b00cdf8d5f6793ea187052d95d4d780378','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2fd6d34e12df55cb8f8bf3393f1bd929a3111902f8e936e8048e23209bf6ef35',2025,'IT','Italy','environment',1773,'Albania, Greece
Akrotiri, Dhekelia
Eritrea, Ethiopia, Somalia
Atlantic Ocean
Israel, West Bank
Federated States of Micronesia
Indian Ocean
China, Tajikistan
Atlantic Ocean
Atlantic Ocean
Atlantic Ocean
Vietnam
Atlantic Ocean
Turkey','37a68db36327347c1920a8453459825e652f450759f01667874a0945656d4d9e','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0862d38803b175298c65db7812aa751f721d9fd58524bc836efe49be71b99e48',2025,'PH','Philippines','environment',1774,'Atlantic Ocean (Baltic Sea)
South Korea
Pacific Ocean
Pacific Ocean
Russia
Macau
Malaysia, Thailand
Pacific Ocean
Indian Ocean
Pacific Ocean
Latitude
(deg min)
400N
56 44 N
51455
1247S
12 09 N
. 2613 N
44 00 N
44 00 N
1435N
320S
830 N
1413S
25 58 S
2416 N
1000 N
16 00 N
7700S
18 04 N
4651S
40 40 N
900S
43 18 N
2030S
33 38S
2100S
2928S
1357S
2613 N
2220S
20 00 N
2313 N
2618S
5306S -
2127N
36 00 N
37498
3519N
5543 N
33 00 N
38 15 N
1924 N
25 00 N
100S
45 28 N
1955 N
2416N
800 N
915N
1250 N
Longitude
(deg min)
-9030 W
26 53 E
59 00 W
45 14E
8617 W
5035E
12400E
124 00 E
, 121 00E
127 23 E
79 OOE
. 16935 W
'' 32355
154 00 E
64 00 W
145 30 E
13000 W
63 05 W
3752E
28 15E
13930 W
523E
2851 W
7852W
57 90E.
`" 2730E
171 56 W
119 56 E
171 20E
1200 W
106 25 W
3106E
73 30E
39 49 E
15 00 E
144 58 E
258 W
21 30E
44 00 E
15 go
99 09 W
9000 W
15 00 E
911E
6527 W
154 00 E
125 00 E
124 30 E
121 05E
889
THE CIA WORLD FACTBOOK
Name ~~ : m Entry in The : Latitude . longitude
l World Factbook (deg min) (deg min)
Mindoro Strait Pacific Ocean 12 20N 120 40E
Mingrelia (region) Georgia 42 30N 4152E
Minicoy Island India 817N 7302 E
Minorca Island (Ista de Menorca) Spain 4000 N 400E
Minsk (capital) i Belarus 53 54 N 27 34 E
Misr (local name for Egypt) Egypt 27 00N 30 00 E
Mitla Pass Egypt 30 02 N 32 54 E
Mocambique (local name for Mozambique) Mozambique 1815S 35 00E
Mogadishu (capital) Somalia ~ 2,04N - 45 22E
Moldavia (region) Moldova, Romania 4700N 29 00E
Molucca Sea Pacific Ocean 200N 127 00 E
Moluccas (Spice Islands) Indonesia 200S 128 00 E
Mombasa (city) Kenya 403S . 3940E
Mona Passage Atlantic Ocean 18 30N . 6745 W
Monaco (capital) Monaco 43 44N 725E
Mongol Uls (local name for Mongolia) Mongolia 46 00 N 105 00 E
Monrovia (capital) Liberia 618 N 1047 W
Monterrey (city) Mexico 25 40N 100 19 W
Montevideo (capital) Uruguay 34 53S 5611 W
Montreal (city) Canada 4531N 73 34 W
Moravia (region) Czech Republic 49 30N 17 00E
Moravian Gate (pass) Czech Republic 4935N _ 1750E
Moroni (capital) Comoros . 141s 43 16E
Mortlock Islands (Nomoi Islands) Federated States of Micronesia 530N 153 40E
Moscow (capital) Russia 55 45N 3735E
Mount Pinatubo (volcano) Philippines 15 08 N 12021 E
Mozambique Channel Indian Ocean 1900S 41 00E
Mumbai (city; aiso Bombay) India 1858N 72 50E
Munich, Muenchen (city) Germany 48 08 N 1135E
Muritaniyah (tocal name for Mauritania) Mauritania 2000 N 12 00 W
Musandam Peninsula Oman, United Arab Emirates 26 18N 56 24 E
Muscat (capital) — Oman '' 2337N 58 35 E
Muscat and Oman (former name for Oman) Oman 2100N 57 00 E
Myanma, Myanmar Burma 22 00N 98 00 E
N''Djamena (capital) Chad 1207 N 15 03 E
Nagorno-Karabakh (region) Azerbaijan 40 00N 46 40E
Nairobi (capital) ‘Kenya 117S 36 49 E
Namib (desert) Namibia 2400S 1500E
Nampo-shoto (island group) Japan 3000N 140 00 E
Nan Madol (ruins) | Federated States of Micronesia 685 N 15835E
Naples (city) Italy 4051N 1415E
Nassau (capital) The Bahamas 2505N 7721 W
Natal (region) South Africa 29 00S 3025E
Natuna Besar islands Indonesia 330N 102 30 E
Natuna Sea Pacific Ocean . 330N 108 00 E
Naxcivan (region) Azerbaijan 3920N 45 20E
Naxos (island) l Greece 3705 N 25 30 E
Nederland (local name for the Netherlands) Netherlands 52 30N 545E
Nederlandse Antillen (local name for the former Netherlands Curacao, Sint Maarten 1215N 68 45 W
Antilles) A :
Negev (region) Israel 3030 N 3455 E
890
CROSS-REFERENCE LIST OF GEOGRAPHIC NAMES
Negros (island)
Nejd (region)
Netherlands Antilles (former name of Dutch Caribbean depend-
encies)
Netherlands East Indies (former name for Indonesia)
Netherlands Guiana (former name for Suriname)
Nevis (island)
New Britain (island)
New Delhi (capital)
New Guinea (island)
New Hebrides (island group)
New Ireland (island)
New Siberian Islands
New Territories (mainland region)
Newfoundland (island, with mainland area, and a province)
Niamey (capital)
Nicobar Islands
Nicosia (capital; also Lefkosia)
Nightingale tstand
Nihon, Nippon (local name for Japan)
Nomoi Islands (Mortlock Islands)
Norge (loca! name for Norway)
Norman Isles (Channel Islands)
North Atlantic Ocean
North Channel
North Frisian Islands
North Greenland Sea
North Island
North Ossetia (region)
North Pacific Ocean
North Sea
North Vietnam (former name for northern portion of Vietnam)
North Yemen (Yemen Arab Republic; now part of Yemen)
Northeast Providence Channel
Northern Areas
Northern Cyprus (region)
Northern Epirus (region)
Northern Grenadines (political region)
Northern Ireland
Northern Rhodesia (former name for Zambia)
Northwest Passages
Norwegian Sea’
Nouakchott (capital)
Noumea (capital)
Nouvelle-Caledonie (local name for New Caledonia)
Nouvelles Hebrides (former name for Vanuatu)
Novaya Zemlya (islands)
Nubia (region)
Nuku''alofa (capital)
Nunavut (region)
Entry in The
World Factbook
West Bank
American Samoa, Samoa
Pacific Ocean','b8ca48265eabf53e13505cab0d7c48a5eecf4a25b01305ba85912bcbf0b6c2fd','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b49eb798871a49c6c59d27aa9c563af85b88ba9b8c306583eb569025c29d8d98',2025,'TV','Tuvalu','environment',1775,'Armenia, Azerbaijan, Belarus,
Estonia, Georgia, Kazakh-
stan, Kyrgyzstan, Latvia,
Lithuania, Moldova, Russia,
Tajikistan, Turkmenistan,
Ukraine, Uzbekistan
Taiwan
Pacific Ocean
Atlantic Ocean','cc10ec855d6c114d7b55d0d096a14c7e9a24f11807187ea95abb2a20138aa444','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('16ca25fa47d8a0042163da4e83636799084e7518b382f6a5d6b88aa4f8c5d423',2025,'TG','Togo','environment',1776,'Lotitude
(deg min)
800S
7500S
0 59N
3085
11 30N
52 30N
50 20N
11 30N
38 30 N
40 00 N
34 40 N
15 00 N
40 00 N
6 59N
4455 N
2220S
1010S
953N
4100N
330N
3515
13 00 N
60 00 N
45:19 N
43 46 N
8455
7405S
25 00 N
830S
23 30N
24 00 N
62 00 N
14 36 N
5007 N
81 00 N
830 N
6 00 N
11 00N
15 00 N
32 00 N
11 30N
17 00 N
11 30 N
800 N
Longitude
(deg min)
178 00 E
92 00 W
933E
17105 W
162 15E
130W
100 W
162 15E
15 00 E
20 30 E
32 51 E
39 00 E
400 W
58 23 W
147 40 E
4022 E
51 10E
327E
72 00E
842E
32 25 W
122 00 E
27 00 E
1425E
11 16E
121 00 E
119 45 E
7945 W
179 12E
121 00 E
119 00 E
700 W
6105 W
841E
55 00 E
1315 W
12 00 E
10 00 W
107 OOF
5 00 W
43 00 E
4 00 W
43 00 E
110E
French West Indies (former name for French possessions in the
West Indies)
Friendly Islands
Frisian Islands
Frunze (city; former name for Bishkek)
Funafuti (capital, atoll)
Fundy, Bay of
Futuna Islands (Hoorn Islands/lles de Horne)
Fyn (island)
Gaborone (capital)
Galapagos Islands (Archipielago de Colon)
Galicia (region)
Galicia (region)
Galilee (region)
Galleons Passage
Gambier Islands (lles Gambier) -
Gaspar Strait
Gdansk (city; formerly Danzig)
Geneva (city)
Genoa (city)
George Town (capital)
George Town (city)
George Town (city)
Georgetown (capital)
Georgetown (city)
German Democratic Republic (East Germany; former name for
eastern portion of Germany)
German Southwest Africa (former name for Namibia)
Germany, Federal Republic of
Gibraltar (city, peninsula) -
Gibraltar, Strait of
Gidi Pass
Gilbert Isiands
Glorioso Islands
Goa (state)
Gobi (desert)
Godthab (capital; also Nuuk)
Golan Heights (region)
Gold Coast (former name for Ghana) |
Golfo San Jorge (gulf)
Golfo San Matias (gulf)
Good Hope, Cape of
Goteborg (city)
Gotland (island)
Gough Island
Graham Land (region)
Gran Chaco (region)
Grand Bahama (island)
Grand Banks (fishing ground)
882
THE CIA WORLD FACTBOOK
Entry in The
World Factbook
Guadeloupe, Martinique
United States (Alaska)','ef93c805528fc5463ef78531988f9a45bb685352cfaac7e9ef39cc8ddd69cc5a','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ea5cf9de878ca9a44906436f5dc6fa0c162dea9c9a97339953388221b547259b',2025,'PF','French Polynesia','environment',1777,'Pacific Ocean
Germany, Poland
Federated States of Micronesia
Taiwan
Pacific Ocean
Iran
Iran','7c055731d9e7faae2aebeaeb4625de45f0372e27e9387551dd56258f1598cfe9','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0f194fd9d0e8fca0b0497352b9e70769c7590776b1a2116226dc7c61aedc4270',2025,'GQ','Equatorial Guinea','environment',1778,'Atlantic Ocean
Indian Ocean
Madapascar
Brunei, Indonesia, Malay-
sia, Papua New Guinea,','ce89a5840c01b140047599b76211cbc6dcb21c00796614f622310d6d2dcbd387','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6fb49857bc1ea6f9530c27076943359b357b99d0663f079d86ecad3f6ab658db',2025,'HR','Croatia','environment',1779,'Arctic Ocean
Arctic Ocean a
New Caledonia, Vanuatu
Portugal, Spain
Arctic Ocean
Democratic Republic of the','2053304a4596a63f4272624d6f183426c0b59aa92b0f1c9757d45620ae57942a','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7617a96fa91c4a08abc52b8843604a93f3ac23c1f459b04227e090ef2524c60c',2025,'MA','Morocco','environment',1780,'Saint Helena, Ascension, and
Tristan da Cunha
Cambodia, Laos, Vietnam
Russia
Spain (Ceuta, Islas Chafarinas,
Melilla, Penon de Alhuce-
mas, Penon de Velez de la
Gomera)
Russia','a8c429193f72f1a0b0b09d1f13470ebb609c7ce97471e2797d083726463321c2','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c50afab181916e9a7ac0cf1c2122a6a2bfd1dee257f44b3a6c96a3bc884f0403',2025,'CL','Chile','environment',1781,'Pacific Ocean
Indian Ocean
Mauritius, Reunion
Afghanistan, Pakistan
Latitude
(deg min)
6411N
1330S
1330S
2130N
0528
2825 N
47 20N
700N
600S
53 00 N
26 30 N
5645 N
24 30 N
8305S
35 43N
2820S
12 33 N
55 50 N
59 00 N
3442 N
59 55 N
31 00N
40 00 N
45 25N
1222 N
5745 N
46 00 N
3901 N
10 00 N
18 08 N
1416S
930N
3807 N
32 00 N
655 N
10 00 N
38 00 N
3500S
858N
900N
800N
1115N
3647N
17328
5 50N
20 20N
4852N
2707S
32 00 N
Longitude
(deg min)
5144 W
34 00 E
37 00''E
158 00 W
169 35 E
178 20 W
13 20 E
46 00 E
71 30E
150 00 E
128 00 E
16 40 E
58 30E
125 00E
043 W
26 40E
70 06 W
12 40 E
300 W
135 30E
1045E
131 00 E
1900E
75 40 W
131 W
700 W
105 00 E
125 45 E
155 00 E
145 47 E
170 42 W
11830E
I32NE
3545
158 08 E
79 45 E
73 00 E
63 00 W
7932 W
7945 W
79 30 W
122 30E
12 00 E
149 34 W
5510 W
136 00 E
220E
109 22 W
69 00 E
CROSS-REFERENCE LIST OF GEOGRAPHIC NAMES
Passion, fle de Ia (island)
Patagonia (region)
Peking (see Beijing)
Pelagian Islands (Isole Pelagie)
Peleliu (Beliliou) (istand)
Peloponnese (peninsula)
Pemba Island
Penang Island
Pentiand Firth (channel)
Perim (island)
Perouse Strait, La
Persia (former name for Iran)
Persian Guif
Perth (city)
Pescadores (islands)
Peshawar (city)
Peter | Island
Petrograd (city; former name for Saint Petersburg)
Philip Island ~
Philippine Sea
Philipsburg (capital)
Phnom Penh (capital)
Phoenix Isiands
Pinatubo, Mount (volcano)
Pines, isie of (island; former name for Isla de la Juventud)
Pleasant Island
Piymouth (capital)
Podgorica (administrative capital)
Polska (local name)
Polynesie Francaise (local name for French Polynesia)
Pomerania (region) . l
Ponape (Pohnpel) (island)
Port Louis (capital)
Port Moresby (capital)
Port-Vila (capital)
Port-au-Prince (capital)
Port-of-Spain (capital)
Porto-Novo (capital)
Portuguese East Africa (former name for Mozambique)
Portuguese Guinea (former name for Guinea-Bissau)
Portuguese Timor (former name for Timor-Leste)
Poznan (city)
Prague (capital)
Praia (capital)
Prathet Thai (local name for Thailand)
Pretoria (administrative capital)
Previaka peninsula
Pribilof Islands
Prince Edward Island
Prince Edward Islands
Prince Patrick Island
Entry in The
World
Clipperton Island
Cape Verde','9ce42e387268728437acfc8f8d181eeb0bb26d0dd3c5b49bbcf59f7d2146b348','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('308856948aa887602094485b6c5b1005e37173ee66b9c6a19c94d6a17457c517',2025,'PK','Pakistan','environment',1782,'Russia
China, India
Finland, Russia
Lotifude
(deg min)
2400N
4455N
800N
8 00N
2441 N
3825 N
610S
5400 N
1556S
3242 N
34 00 N
40 00 N
1927N
7308
5 00S
3147N
2130N
2615S
1400S
3300S
48 18 N
1703S
04 51 N
2740 N
3135N
43 00N
56 00 N
21 40N
43 30 N
3431 N
10 33 N
30 00 N
72 00N
24 30S
000N
54 30 N
1521 N
56 00 N
019N
13 00 N
7930 N
2495S
76 00 N
43 40 N
2451 N
50 00 N
35 30 N
6315 N
Longitude
(deg min)
54 00 E
147 40 E
38 00 E
500 W
141 20E
27 10E
106 48 E
80 00 W
544 W
7452 E
76 00E
135 00 E
103 10E
110 00 E
11000 E
35 14E
39112 E
28 00 E
128 45 E
80 00 W
124 00 W
42 45E
3TOTE
3355E
35 00 E
21 00E
JSE
82 50 W
43 30 E
69 12E
TWRNE
82 00 E
40 00 W
21 00 E
115 00 E
21 00 E
42 34E
160 00 E
32 25E
105 00 E
68 00 W
171 40 W
80 00 E
41 50E
67 03E
143 00 E
77 50 E
30 48 E
885
THE CIA WORLD FACTBOOK
Name a: Entry in The = Latitude Longitude
World Factbook (deg min) (deg min)
Karelian isthmus Russia 6025N 30 00 E
Karimata Strait ` Pacific Ocean 205S 108 40 E
Kashmir (region) _ India, Pakistan 3400N 76 00 E
Katanga (region) Democratic Republic of the 1000S 26 00 E
Atlantic Ocean
Atlantic Ocean
Atlantic Ocean
Atlantic Ocean
Atlantic Ocean
Russia
Pacific Ocean
1300N
60 00 N
3100N
330S
4828 N
4709 N
3700 N
35 54N
1813N
3100N .
49 16N
49 45 N
41 54N
3511 N
2300S
13 34N
438S
7100N
7200S
4812 N
1758 N
5441 N
1800S
43 10N
4535 N
25 00 N
1006S
1917N
37 00N
44 45 N
5230 N
1317S
2259S
52 15N
38 53 N
7200S
4128S
5326 N
5322 N
1210S
34 40 N
30 00 N
60 00 N
34 40 N
2 00 W
60 00 E
36 00 E
30 00 E
13502E
OBIE
73 00 E
1431 E
63 04 W
131 00 E
123 08 W
126 00 W
21E
418 W
31 00E
12051E
SIRE
110 00 W
155 00 E
1622E
102 36E
2519E
178 00 E
131 56 E
20 00 E
141 00 E
152 23 W
166 39 E
73 OOF
2605E
330 W
176 10 W
1431E
2100E
77:02 W
45 00 W
174 51E
530E
SOE
96 55 E
129 00 E
70 00 E
75 00 E
129 00 E
901
THE CIA WORLD FACTBOOK
Western Samoa (former name for Samoa)
Wetar Strait
White Sea
Wilkes Land (region)
Willemstad (capital)
Windhoek (capital)
Windward Passage
Winnipeg (city)
Wrangel island (Ostrov Vrangelya)
Xianggang (local name for Hong Kong)
Y''israel (local name for Israel)
Yaitopya (local name for Ethiopia)
Yalu River
Yamoussoukro (capital)
Yangon (see Rangoon)
Yaounde (capital)
Yap islands
Yaren (governmental center)
Yekaterinburg (city; formerly Sverdlovsk)
Yellow Sea
Yemen Arab Republic (also Yemen (Sanaa); former name for
northern portion of Yemen)
Yemen, People''s Democratic Republic of (also Yemen (Aden);
former name for southern portion of Yemen)
Yerevan (capital)
Yokohama (city)
Youth, Isle of (Isla de fa Juventud)
Yucatan Channel
Yucatan Peninsula
Yugoslavia (former name for a federation of Serbia and Mon-
fenegro)
Yugoslavia, Kingdom of (former name for a Balkan federation)
Yugoslavia, Socialist Federal Republic of (former name for a
Balkan federation)
Zagreb (capital)
Zaire (former name for the Democratic Republic of the Congo)
Zakhalinskiy Zaliv (bay)
Zaliv Shelikhova (bay)
Zambezia (region)
Zanzibar (island)
Zhong Guo, Zhonghua (local name for China)
Zion, Mount (locale in Jerusalem)
Zurich (city)
902
Entry in The
World Factbook','f150e9137122423054214299a234e601c4ca0e9204bcd26302e2df331e65a35b','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('823aa145c3a7bfcaa03a6cee362845d3b1d586cccdcfbc28d6c16583702f6124',2025,'PE','Peru','environment',1783,'Arctic Ocean
Jarvis Island, Kingman Reef,
Kiribati, Palmyra Atoll
Atlantic Ocean','38a81634a19bb3542bd0c3b92d8a9429171af75e85aabce8ccc88ec2f09d2cdc','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b009e0c4b56b5a35b82677add13756f90d964bbae70153d3f40b14809d2e3e30',2025,'PT','Portugal','environment',1784,'Latitude
(deg min)
50 03 N
310N
44 20N
36 00 N
46 10N
29 20N
54 00N
905N
5026 N
33 00 N
1630S
4545N
54 00N
60 00 N
1000 N
700N
627N
3133N
42 30N
4500N
43 30N
43 30N
48 00 N
1000N
22 15N
18 00 N
76 00 N
28 06 N
36 00 N
57 00N
1820S
3510N
5121N
39 54 N
59 55 N
900S
3915N
10 50 N
3715 N
40 30 N
33 50N
023 N
56 00 N
43 30 N
1359S
1203S
83 00 N
005N
43 20 N
38 43 N
Longitude
(deg min)
19 56 E
101 42 E
146 00 E
84 00 E
152 00E
47 59E
86 00 E
167 20E
30 31 E
131 00 E
68 09 W
142 00 E
62 00 W
55 00 W
73 00 E
76 00 E
324E
7423''E
81 00 W
83 00 W
87 30 W
78 00 W
88 00 W
73 00E
113 55E
105 00 E
126 00 E
1524W
35 50E
25 00 E
178 30 E
3322 E
1223''E
2521E
3015 È
120 00 E
2615 E
124 50 E
131 50 E
121 20E
36 50E
927E
2400E
900E
33 44E
7703 W
56 00 W
157 00 W
400E
908 W
887
THE CIA WORLD FACTBOOK
Little Belt (strait; also Lille Baelt)
Ljubljana (capital)
Llanos (region)
Lobamba (city)
Lombok (island)
Lombok Strait
Lome (capital)
London (capital)
Longyearbyen (capital)
Lord Howe Island
Lorraine (region)
Louisiade Archipelago
Lourenco Marques (city; former name for Maputo)
Loyalty Islands (lles Loyaute)
Luanda (capital) .
Lubnan (local name for Lebanon)
Lubumbashi (city)
Lusaka (capital)
Luxembourg (capital)
Luzon (island)
Luzon Strait
Lyakhov Islands','43478f504817a88460c660365afe8a067eab9d5064b6094dafd98f9cdc36d0c9','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4a5064cbce7c44f68d14e46f919cdfcaf4eccf4a3031befadcf721e4d6bcf8a3',2025,'MO','Macao','environment',1785,'Macau (special administrative region)
Macquarie Island
Madagasikara (local name for Madagascar)
Maddalena, Isola
Madeira Islands
Madras (city; see Chennai)
Madrid (capital)
Magellan, Strait of
Maghreb (region)
Magreb (local name for Morocco)
Magyarorszag (local name for Hungary) -
Mahe Island
Maiz, Islas del (Corn Islands)
Majorca Island (isla de Mallorca)
Majuro (capital)
Makassar Strait
Makedonija (local name for Macedonia)
Malabo (capital)
Malacco, Strait of
Malagasy Republic
Malay Archipelago
Malay Peninsula
Male (capital)
Mallorca, Isla de (island; also Majorca)
Malmady (region)
888
Entry In The
World Factbook
Atlantic Ocean','4449177bbfeb74026ac2440bcdf028510195fb3bbf2f1c610fd677be6775e35b','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('361b4f30227816102d81e68327f3f78a51a3e7ca0d56586057852155f68c9ea5',2025,'CY','Cyprus','environment',1786,'Saint Helena, Ascension, and
Tristan da Cunha
Albania, Greece
Saint Vincent and the
Grenadines','979486f26270deaf6921b092469526036009eea5e65f92525421b856ac524e32','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('51e8bb36532ce94035f2028b0086b6c771347f1b4d0c01cc4a3220f28e00757b',2025,'NO','Norway','environment',1787,'Guernsey, Jersey
Atlantic Ocean
Atlantic Ocean
Denmark, Germany
Arctic Ocean
Pacific Ocean
Atlantic Ocean','ca037f0cecee2687b00ef6f590d4788d623aa2fb5c08e6f6ebd1d663af149872','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cd862c9a4753fafea60b9ae099d0685edbd1a222dece33e9a516489b0787183d',2025,'MN','Mongolia','environment',1788,'North Korea
Marshall Islands, Federated
States of Micronesia, North-
em Mariana Islands, Palau
South Korea
Ireland, United Kingdom','67fa9a19239d65377c8cbaf2a643565bba078e6572f1b16374161aeb60eeb19f','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('18b2edaee954cf5c73bd57a0326cb99abbede39b0d9dbc84fd4037368c24f18d',2025,'TH','Thailand','environment',1789,'Russia
Pacific Ocean —
Atlantic Ocean
Atlantic Ocean
Pacific Ocean
South Georgia and the South
Sandwich Islands','052f9b32e5d8527320e06753eac65b77850c8cc188c257cba8617236a752b83d','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2f9cfcf0367be39047013ada8c2d2dd21a9da972d9dc2889c5856f147e5215da',2025,'GE','Georgia','environment',1790,'Pacific Ocean
South Georgia and the South
Sandwich Islands
China, Kyrgyzstan
Argentina, Chile
Timor-Leste, Indonesia','4a2c393652a3393290076a1b35c0cd3ef326b8e7a32ccb71a5b5f41d9e206a3f','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('290a9752ee876c7d55d60160dfe602276c88405690b4a8aa38aec32f3b7791aa',2025,'MP','Northern Mariana Islands','environment',1791,'Indian Ocean
Latitude
(deg min)
400N
35 00 N
6317 N
1808S
56 50 N
62 00 N
47 00 N
11 03S
17255
33 53S
41 43 N
39 00 N
17 37S
25 03 N
24 00 N
5925 N
6005S
35 48 N
5125 N
125 N
50 00 N
41 20N
4305S
43 00S
5000 N
76 00 N
15 00 N
14 06 N
35 40 N
32 05 N
400S
030S
66 30S
43 00S
10 00 N
41 50N
40 38 N
2728 N
51 00N
7220S
32 48 N
32 00 N
41 43 N
42 00N
5400S
900S
900N
1100S
15 00 N
28 00 N
Longitude
(deg min)
56 00 W
38 00 E
20 40 W
17825 E
60 39E
15 00 E
8 00 E
17115 W
83 56 W
151 13E
44 49E
71 00E
14927 W
121 30E
11900 E
2445 E
35 00 E
545 W
94 45E
173 00 E
141 00 E
69 18E
168 00 E
147 00 E
141 00E
104 00 E
19 00E
87 13 W
51 26E
34 48 E
120 45 E
121 00 E
139 00 E
67 00E
101 00 E
22 00 E
22SME
89 39 E
11 00E
99 00 W
35I35:E
90 00 E
44 49E
80 00 E
69 00 W
12500E
126 00 E
128 00 E
145 38 E
3427E
899
THE CIA WORLD FACTBOOK
Tirana, Tirane (capital)
Tirol, Tyrol (region)
Tobago (island)
Tokyo (capital)
Tonkin, Gulf of
Toronto (city) . ''
Torres Strait
Torshavn (capital)
Toshkent (see Tashkent)
Transcarpathia (region; alternate name for Carpatho-Ukraine)
Transjordan (former name for Jordan)
Transkei (enclave)
Transvaal (region; former name for northeastern South Africa)
Transylvania (region)
Trindade, liha de (island)
Trinidad (island)
Tripoli (capital)
Tripoli (city)
Tripolitania (region)
Tristan da Cunha Group (island group)
Trobriand Islands
Tromelin Island
Trucial Coast (former name for the United Arab Emirates)
Trucial Oman (former name for the United Arab Emirates)
Trucial States (former name for the United Arab Emirates)
Truk Islands (former name for the Chuuk islands)
Tsugaru Strait
Tuamotu Islands (lles Tuamotu)
Tubuai islands (Hes Tubuai)
Tunb al Kubra (istand)
Tunb as Sughra (island)
Tunis (capital)
Turin (city)
Turkish Straits (see Bosporus and Dardenelles)
Turkiye (local name for Turkey)
Turkmenia, Turkmeniya (former name for Turkmenistan)
Turks Island Passage
Tuscany (region)
Tutuila (island)
Tyrrhenian Sea
Ubangi-Shari (former name for the Central African Republic
Ukrayina (local name for Ukraine)
Ulaanbaatar (capital)
Ullung-do (island)
Ulster (region)
Uman (local name for Oman)
Unimak Pass (strait)
900
Entry in The
World Factbook','ecba67b9c9afa7f458a8dfbf93f38e48eca216c81287ffdd82b531f635e0efcd','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c790c3d4f70e645deb3f362b84e9529aef6f37e170e86fed107d332e398a4226',2025,'OM','Oman','environment',1792,'Pacific Ocean
Latitude
(deg min)
4120N
4700N
1L15N
3542 N
2000 N
43 40 N
1025S
62 01 N
4120N
4822 N
3100N
3215S
2510S
46 30 N
2031S
1022 N
32 54 N
3426 N
31 00N
Sif iS)
8 38S
1552$
24 00 N
24 00N
24 00 N
725N
4135N
1900S
2300S
2614N
26 14N
36 48 N
45 04 N
40 40 N
39 00 N
40 00 N
2140N
4325 N
1418S
40 00 N
638 N
49 00 N
4755 N
37 29N
5435 N
21 00 N
54 20 N
Longitude
(deg min)
19 50E
11 00E
60 40 W
139 46 E
108 00 E
79 23 W
142 10 E
646 W
69 18E
2332 E
36 00E
28 15E
2925E
24 00 E
2920 W
6115W
13 Í1E
35 51E
14 00 E
12 30 W
151 04E
5425E
54 00E
54 00E
54 00E
151 47E
141 00E
142 00 W
15000 W
5519E
5509E
1011E
740E
28 00 E
35 00E
60 00E
710W
11 00E
17042 W
120E
2033 E
320E
106 53 E
130 52E
70W
57 00E
164 50 W
CROSS-REFERENCE LIST OF GEOGRAPHIC NAMES
Entry in The
World Factbook
+
Lotitude
(deg min)
Longitude
(deg min)
Union of Soviet Socialist Republics or USSR (former name of
, G large Eurasian empire, roughly coequal with the former
Russian Empire) -
United Arab Republic or UAR (former name for a federation
between Egypt and Syria)
Upper Volta (former name for Burkina Faso)
Ural Mountains
Urdunn (local name for Jordan)
Urundi (former name for Burundi)
Ussuri River
Vaduz (capital)
Vakhan (Wakhan Corridor)
Valletta (capital)
- Valley, The (capital)
Van Diemen Strait (Osumi Strait)
Vancoüver (city)
Vancouver Island
Vatican City (capital)
Velez de lo Gomera, Penon de (island)
Venda (enclave)
Verde Island Passage
Victoria (capita!)
Victoria (island)
Victoria Land (region)
Vienna (capital)
Vientiane (capital)
Vilnius (capital)
Viti Levu (island)
Vladivostok (city)
Vojvodina (region)
Volcano Islands
Vostok Island
Wake Atoll
Wakhan Corridor (see Vakhan)
Walachia (region)
Wales (region)
Wallis Islands
Walvis Bay (city; former exclave)
Warsaw (capital)
Washington, DC (capital)
Weddell Sea
Wellington (capital)
West Frisian Islands
West Germany (Federal Republic of Germany; former name for
western portion of Germany)
West Island (capital)
West Korea Strait (Western Channel)
West Pakistan (former name for present-day Pakistan)
West Siberian Plain
Western Channel (West Korea Strait)
Armenia, Azerbaijan, Belarus,
Estonia, Georgia, Kazakh-
stan, Kyrgyzstan, Latvia,
Lithuania, Moldova, Russia,
Tajikistan, Turkmenistan,
Ukraine, Uzbekistan
Egypt, Syria','fa5f345800e1c4e1d4eba2c65012502c93ac96683c95b009927aec48c496884b','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);

SET NAMES utf8mb4;
CREATE TABLE IF NOT EXISTS worldfactbook_chunks (
  chunk_id CHAR(64) NOT NULL,
  edition_year SMALLINT UNSIGNED NOT NULL,
  entity_code VARCHAR(24) NOT NULL DEFAULT '',
  entity_name VARCHAR(160) NOT NULL DEFAULT '',
  category VARCHAR(96) NOT NULL,
  ordinal INT UNSIGNED NOT NULL,
  content MEDIUMTEXT NOT NULL,
  content_sha256 CHAR(64) NOT NULL,
  source_provider VARCHAR(64) NOT NULL,
  source_identifier VARCHAR(255) NOT NULL,
  source_format VARCHAR(32) NOT NULL,
  source_sha256 CHAR(64) NOT NULL,
  source_url TEXT NOT NULL,
  extractor VARCHAR(64) NOT NULL,
  PRIMARY KEY (chunk_id),
  KEY idx_wfb_year_category (edition_year, category),
  KEY idx_wfb_entity_year (entity_code, edition_year),
  KEY idx_wfb_source_sha (source_sha256)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5a946a2217b86850c8a1b0523e20cec8671ad83b4a40831ebd8f34169b2b6a16',2025,'ZW','Zimbabwe','transportation',20,'Airports
Airports—with paved runways
total
over 3,047 m
2,438 to 3,047 m
1,524 to 2,437 m
914 to 1,523 m
under 914 m
Airports—with unpaved runways
total > nd 3
over 3,047 m
2,438 to 3,047 m
1,524 to 2,437 m
914 to 1,523 m
under 914 m
Heliports
Pipelines
Railways
total
broad gauge
standard gauge
narrow gauge
dual gauge
Roadways
total
paved
unpaved
Waterways
Merchant marine
total
ships by type
foreign-owned
registered in other countries
Ports and terminals
Transportation—note
Military branches
Military service age and obligation
Manpower available for military service
males age 16-49
females age 16-49
Manpower fit for military service
males age 16-49
females age 16-49
Manpower reaching militarily significant
age annually
males
females :
Military expenditures—percent of GDP
Military—note
paved: 20,1 17 km
unpaved: 71,323 km (2001)
Waterways: 2,250 km (includes Lake Tanganyika
and the Zambezi and Luapula rivers) (2010)
country comparison to the world: 39
Ports and terminals: Mpulungu
Airports: 202 (2012)
country comparison to the world: 29
Airports—with paved runways: total: 17 over
3,047 m: 3
2,438 to 3,047 m: 2
1524 to 2,437 m: 5
914 to 1,523 m: 7 (2012)
Airports—with unpaved runways: coral: 185
1,524 to 2,437 m: 2
914 to 1,523 m: 110
under 914 m: 73 (2012)
Pipelines: refined products 270 km (2010)
Railways: toral: 3,427 km
country comparison to the world: 50
narrow gauge: 3,427 km 1.067-m gauge (313 km
electrified) (2008)
Roadways: total:97,267 km
country comparison to the world: 43
paved: 18,481 km
unpaved: 78,786 km (2002)
Waterways: (some navigation possible on Lake
Kariba) (2011)
Ports and terminals: Binga, Kariba','104cf586a0df70b60518808a07192fcfd871747a92f13ae89f13c597c59c305f','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4b80d69305d5d5d25388bea9eb4ca1f73ebb56adf8f9c13ffa45269a02147a59',2025,'AF','Afghanistan','transportation',30,'Airports: 52 (2012)
country comparison to the world: 91
Airports—with paved runways: total: 23
over 3,047 m: 4
2,438 to 3,047 m: 4
1,524 to 2,437 m: 10
914 to 1,523 m: 2
under 914 m: 3 (2012)
Airports—with unpaved runways: total: 29
2,438 to 3,047 m: 5
1,524 to 2,437 m: 12
914 to 1,523 m: 6
under 914 m: 6 (2012)
Heliports: 10 (2012)
Pipelines: gas 466 km (2010)
Roadways: total: 42,150 km
country comparison to the world: 85
paved: 12,350 km
unpaved: 29,800 km (2006)
Waterways: 1,200 km; (chiefly Amu Darya, which
handles vessels up to 500 DWT) (2011)
THE CIA WORLD FACTBOOK
country comparison to the world: 60
Ports and terminals: Kheyrabad, Shir Khan','f532f329caa898a848533a2718bbe61ff4bae508d7d14972ca86a249b67a115a','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6f4927e92b336d6f9d93bccca897bd612418fe776e615c11b95d4e8d5029ce1e',2025,'AL','Albania','transportation',45,'Airports: 5 (2012)
country comparison to the world: 178
Airports—with paved runways: total: 4
2,438 to 3,047 m: 3
1,524 to 2,437 m: 1 (2012)
Airports—with unpaved runways: total: 1
914 to 1,523 m: 1 (2012)
Heliports: 1 (2012)
Pipelines: gas 339 km; oil 207 km (2010)
Railways: total: 339 km
country comparison to the world: 117
standard gauge: 339 km 1.435-m gauge (2009)
Roadways: total: 18,000 km
country comparison to the world: 115
paved: 7,020 km
unpaved: 10,980 km (2002)
Waterways: 41 km (on the Bojana River) (2011)
country comparison to the world: 104
Merchant marine: total: 17
country comparison to the world: 99
by type: cargo 16, roll on/roll off 1
foreign-owned: 1 (Turkey 1)
registered in other countries: 5 (Antigua and Bar-
buda 1, Panama 4) (2010)
Ports and terminals: Durres, Sarande, Shengjin,
Vlore','da476393361a4a2d782901d37a9d144d79430126cf90aa8173d1dbdb683c1659','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b32656653a86952a64e3a80e3ee3f81017027014409834ef349c3184fd6a6ebe',2025,'AS','American Samoa','transportation',65,'Airports: 3 (2012)
country comparison to the world: 193
Airports—with paved runways: total: 3
over 3,047 m: 1
914 to 1,523 m: 1
under 914 m: 1 (2012)
Roadways: toral: 241 km (2008)
country comparison to the world: 206
Ports and terminals: Pago Pago','9300a89812cbe223f710fecd3735662d1ab5dd8f20a267f7711a8565f441dcc9','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('313fdfc129a0e4969bfc6aa66a08d6a3f085d80182591351625b2c1b85b41766',2025,'AO','Angola','transportation',78,'Airports: 176 (2012)
country comparison to the world: 33
Airports—with paved runways: total: 30
over 3,047 m:6
2,438 to 3,047 m:8
1,524 to 2,437 m: 12
914 to 1,523 m: 66
under 914 m: 43 (2012)
Airports—with unpaved runways: total: 146
over 3,047 m: 3
2,438 to 3,047 m:3
2,438 to 3,047 m: 31
914 to 1,523 m: 66
under 914 m: 43 (2012)
Heliports: 1 (2012)
Pipelines: gas 2 km; oil 87 km (2010)
Railways: total: 2,764 km
country comparison to the world: 59
narrow gauge: 2,641 km 1.067-m gauge; 123 km
0.600-m gauge (2008)
Roadways: total: 51,429 km
country comparison to the world: 77
paved: 5,349 km
unpaved: 46,080 km (2001)
Water ways: 1,300 km (2011)
country comparison to the world: 56
Merchant marine: total: 7
country comparison. to the world: 123
by type: cargo 1, chemical tanker 1, passenger/
cargo 2, petroleum tanker 2, roll on/roll off 1
foreign-owned: 1 (Spain 1)
registered In other countries: 17 (Bahamas 6,
Curacao 2, Cyprus 1, Liberia 1, Malta 7) (2010)
Ports and terminals: Cabinda, Lobito, Luanda,
Namibe','2e1f8561d50ab03775b203ae68cb026f7f746f198c16ed325a62b5e2f2529ea0','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5d9dc7a579d9132ff822fd1367c4cbb796019e47e8a0eba1c82d64822da8a506',2025,'AI','Anguilla','transportation',89,'Airports: 3 (2012)
country comparison to the world: 197
Airports—with paved runways: total: 1
1,524 to 2,437 m: 1 (2012)
Airports—with unpaved runways: total: 2
under 914 m: 2 (2012)
Roadways: total: 175 km
country comparison to the world: 210
paved: 82 km
unpaved: 93 km (2004)
Ports and terminals: Blowing Point, Road Bay','e2ffff0ed42eae8f7aa62283ffe7f6709b9d5608a81b5dbe935ceb35fcfc3162','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e3d23571c0e3526396aec3d3e72294128d32d33b35512dfb7d6fd6d748e8f483',2025,'AQ','Antarctica','transportation',97,'Airports: 23 (2012)
country comparison to the world: 133
Airports—with unpaved runways: total: 23 over
3,047 m: 3
2,438 to 3,047 m:5
914 to 1,523 m:9
under 914 m: 6 (2012)
Heliports? 53
note: all year-round and seasonal stations oper-
ated by National Antarctic Programs stations have
some kind of helicopter landing facilities, prepared
(helipads) or unprepared (2012)
Ports and terminals: McMurdo Station; most
coastal stations have sparse and intermittent off-
shore anchorages; a few stations have basic wharf
facilities
Transportation—note: US coastal stations
include McMurdo (77 51 S, 166 40 E) and
Palmer (64 43 S, 64 03 W); government use
only except by permit (see Permit Office under
“Legal System”); all ships at port are subject to
inspection in accordance with Article 7, Ant-
arctic Treaty; relevant legal instruments and
authorization procedures adopted by the states
parties to the Antarctic Treaty regulating access
to the Antarctic Treaty area to all areas between
60 and 90 degrees of latitude south have to be
complied with (see “Legal System”); The Hydro-
graphic Commission on Antarctica (HCA), a
commission of the International Hydrographic
Organization (IHO), is responsible for hydro-
graphic surveying and nautical charting mat-
ters in Antarctic Treaty area; it coordinates and
facilitates provision of accurate and appropriate
charts and other aids to navigation in support
of safety of navigation in region; membership of
HCA is open to any IHO Member State whose
government has acceded to the Antarctic Treaty
and which contributes resources or data to IHO
Chart coverage of the area','e3def926f2aa13fd7352ec0a50fffcc542eb351576fc9492f69fcb29441f9ba7','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bf356f5a61fb4ef183cc4b95da78d2452bc24d3bf41f01009f6fe1c84cb757a6',2025,'AG','Antigua and Barbuda','transportation',106,'Airports: 3 (2012)
country comparison to the world: 192
Airports—with paved runways: total: 2
2,438 to 3,047 m: 1
under 914 m: 1 (2012)
Airports—with unpaved runways: total: 1
under 914 m: 1 (2012)
Roadwoys: total: 1,165 km
country comparison to the world: 181
paved: 384 km
unpaved: 781 km (2002)
Merchant marine: total: 1,257
country comparison to the world: 9 by type: bulk
carrier 49, cargo 753, carrier 6, chemical tanker 4,
container 407, liquefied gas 12, refrigerated cargo
7, roll on/roll off 17, vehicle carrier 2
foreign-owned: 1,215 (Albania 1, Colombia 1,
Denmark 20, Estonia 10, Germany 1094, Greece
4, Iceland 10, Latvia 16, Lithuania 3, Mexico 1,
Netherlands 17, Norway 9, NZ 2, Poland 2, Russia
3, Sw itzerland 7, Turkey 7, UK 1, US 7) (2010)
Ports and terminals: Saint John’s
Ports and terminals: Churchill (Canada), Mur-
mansk (Russia), Prudhoe Bay (US)
Transportation—note: sparse network of air,
ocean, river, and land routes; the Northwest Pas-
sage (North America) and Northern Sea Route
(Eurasia) are important seasonal waterways','dee6b387dcba59812b637d2f7e4aab7dbfc9388beab98d10404ae8cf88f13ea0','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('66e595808d779540a077029922376e721e11fcb11d4692cbef4793187e217af8',2025,'AR','Argentina','transportation',115,'Airports: 1,149 (2012)
country comparison to the world: 6
Airports—with paved runways: total: 159
over 3,047 m: 4
to 3,047 m: 28
to 2,437 m: 64
914 to 1,523m: 54
under 914 m; 9 (2012)
Airports—with unpaved runways: total: 990
over 3,047 m: 1
to 3,047 m:1
to 2,437 m: 45
914 to 1,523 m: 499
under 914 m: 444 (2012)
Heliports: 2 (2012)
Pipelines: gas 29,401 km; liquid petroleum gas
41 km; oil 6,166 km; refined products 3,631 km
(2010)
Railways: total: 36,966 km
country comparison. to the world: 8
broad gauge: 26,475 km 1.676-m gauge (94 km
electrified)
standard gauge: 2,780 km 1.435-m gauge (42 km
electrified)
narrow gauge: 7,711 km 1.000-m gauge (2008)
Roadwoys: total: 231,374 km
country comparison to the world: 21
paved: 69,412 km (includes 734 km of expressways)
unpaved: 161,962 km (2004)
Wate rwoys: 11,000 km (2012)
country comparison to the world: 12
Merchant marine: total: 36
country comparison to the world: 80
by type: bulk carrier 1, cargo 5, chemical tanker 6,
container 1, passenger/cargo 1, petroleum tanker
18, refrigerated cargo 4
foreign-owned: 14 (Brazil 1, Chile 6, Spain 3,
Taiwan 2, UK 2)
registered in other countries: 15 (Liberia 1,
Panama 5, Paraguay 5, Uruguay 1, unknown 3)
(2010)
Ports and terminals: Arroyo Seco, Bahia Blanca,
Buenos Aires, La Plata, Punta Colorada, Rosario,
San Lorenzo-San Martin, Ushuaia','543c71c46edd8807ee683055a6568e1ca5cc3f186444987fabb707f301939473','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('babd0d32505dc48d0f8438bb12a4f117c51cf2bbc71cbec9c20a047f669fe339',2025,'AM','Armenia','transportation',122,'Airports: 11(2012)
country comparison to the world: 155
Airports—with paved runways: total: 10
over 3,047 m: 2
2,438 to 3,047 m: 2
1,524 to 2,437 m: 4
914 to 1,523 m: 2 (2012)
Airports—with unpaved runways: total: 1
914 to 1,523 m: 1 (2012) .
Pipelines: gas 2,233 km (2010)
Railways: total: 869 km
country comparison to the world: 96
broad gauge: 869 km 1.520-m gauge (818 km
electrified)
note: some lines are out of service (2009)
Roadways: total: 7,705 km (2012)
country comparison to the world: 144','219776f8602e21c046a9c1d49e17bddf4a9e3b9e940d80a925caa795327117eb','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6d78999c5a45124cdefa52a14a01d8ad54d80ca47925cd78548de1dc344f1d57',2025,'AW','Aruba','transportation',132,'Airports: 1(2012)
country comparison to the world: 210
Airports—with paved runways: total: 1
2,438 to 3,047 m: 1 (2012)
Ports and terminals: Barcadera, Oranjestad, Sint
Nicolaas
Ports and terminals: none; offshore anchorage only
Australia; periodic visits by the Royal Australian
Navy and Royal Australian Air Force
ATLANTIC OCEAN
parts of the Ashmore and Cartier reserve to Indo-
nesian traditional fishing; Indonesian groups chal-
lenge Australia’s claim to Ashmore Reef
SOUTH
ATLANTIC
OCEAN
Ports and terminals: Alexandria (Egypt), Algiers
(Algeria), Antwerp (Belgium), Barcelona (Spain),
Buenos Aires (Argentina), Casablanca (Morocco),
Colon (Panama), Copenhagen (Denmark), Dakar
(Senegal), Gdansk (Poland), Hamburg (Ger-
many), Helsinki (Finland), Las Palmas (Canary
Islands, Spain), Le Havre (France), Lisbon (Portu-
gal), London (UK), Marseille (France), Montevi-
deo (Urugudy), Montreal (Canada), Naples (Italy),
New Orleans (US), New York (US), Oran (Alge-
tia), Oslo (Norway), Peiraiefs or Piraeus (Greece),
_ Rio de Janeiro (Brazil), Rotterdam (Netherlands),
Saint Petersburg (Russia), Stockholm (Sweden)
Transportation—note: Kiel Canal and Saint Law
rence Seaway are two important waterways; signifi-
cant domestic commercial and recreational use of
Intracoastal Waterway on central and south Atlan-
tic seaboard and Gulf of Mexico coast of US; the
International Maritime Bureau reports the territo-
rial waters of littoral states and offshore Atlantic
waters as high risk for piracy and armed robbery
against ships, particularly in the Gulf of Guinea off
West Africa; in 2012, 58 commercial vessels were
attacked in the Gulf of Guinea with 10 hijacked
and 207 crew members taken hostage; hijacked ves-
sels are often disguised and cargoes stolen; crew s
have been robbed and stores or cargoes stolen','3fd4f9fdb868f1067e3aec520bd4859c6109ce9e67376c6947604e39b82fd3b2','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('33a21f12c9693332fcafd8d5e8102bc050d85d7ba39a5821a7a5edeb9fc464a8',2025,'AU','Australia','transportation',143,'Airports: 467 (2012)
country-comparison to the world: 18
Airports—with paved runways: total: 333
over 3,047 m: 11
2,438 to 3,047 m: 13
1,524 to 2,437 m: 146
914 to 1,523 m: 149
under 914 m: 14 (2012)
Airports—with unpaved runways: total: 134
1,524 to 2,437 m: 19
914 to 1,523 m: 101
under 914 m: 14 (2012)
Heliports: 1 (2012)
-Pipelines: gas 27,900 km; liquid petroleum gas
240 km; oil 3,257 km; oil/gas/water 1 km (2010)
Railways: total: 38,445 km
country comparison to the world: 7
broad gauge: 3,355 km 1.600-m gauge
standard gauge: 21,674 km 1.435-m gauge (650
km electrified)
narrow gauge: 9,539 km 1.067-m gauge (2,067
km electrified); 3,877 km 1.000-m gauge (2008)
Roadways: total: 823,217 km
country comparison to the world: 9
paved: 356,343 km
unpaved: 466,874 km (2011)
Waterways: 2,000 km (mainly used for recrea-
tion on Murray and Murray-Darling river systems)
(2011)
country. comparison to the world: 43
Merchant marine: total: 41
country comparison to the world: 75
by type: bulk carrier 8, cargo 7, liquefied gas 4, pas-
senger 6, passenger/cargo 6, petroleum tanker 5,
roll on/roll off 5
foreign-owned: 17 (Canada 5, Germany 2, Singa-
pore 2, South Africa 1, UK 5, US 2)
registered in other countries: 25 (Bahamas 1,
Dominica 1, Fiji 2, Liberia 1, Netherlarids 1, Pan-
ama 4, Singapore 12, Tonga 1, UK 1, US 1) (2010)
Ports and terminals: Brisbane, Cairns, Damp-
ier, Darw in, Fremantle, Gladstone, Geelong,
Hay Point, Hobart, Jervis Bay, Melbourne, New
castle, Port Adelaide, Port Dalrymple, Port Hed-
land, Port Kembla, Port Lincoln, Port Walcott,
Sydney
Airports: 1 (2012)
country comparison to the world: 214
Airports—with paved runways: total: 1
2,438 to 3,047 m: 1 (2012)
Roadways: total:22 km
country comparison to the world: 221
THE CIA WORLD FACTBOOK
paved: 10 km
unpaved: 12 km (2007)
Ports and terminals: Port Refuge
Ports and terminals: none; offshore anchorage
only
Military—note: defense is the responsibility of
Airports: 1 (2012)
country comparison to the world: 228
Airports—with paved runways: total: |
1,524 to''2,437 m: 1 (2012)
Roadways: toral:80 km
country comparison to the world: 216
paved: 53 km
unpaved: 27 km (2008)
Ports and terminals: Kingston
Military—note: defense is the responsibility of','d48e7a4d9c74cc342ed716ff8f432385c6e60d0e1c854a93c1eab96588d09963','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('03cb6f3ce8269021bd581579d3e95cd633f9e6527ca59b035e3d729582861604',2025,'AT','Austria','transportation',154,'Airports: 52 (2012) ’
country comparison to the world: 90
Airports—with paved runways: total: 24
over 3,047 m: 1
2,438 to 3,047 m: 5
1524 to 2,437 m: 1
914 to 1,523 m: 4
under 914 m: 13 (2012)
Airports—with unpaved runways: total: 28
1,524 to 2,437 m: 1
914 to 1,523 m:3
under 914 m: 24 (2012)
Heliports: 1(2012)
Pipelines: gas 3,028 km; oil 663 km; refined prod-
ucts 157 km (2010)
Railways: total: 6,399 km
country comparison to the world: 29
standard gauge: 5,927 km 1.435-m gauge (3,853
km electrified)
narrow gauge: 384 km 1.000-m gauge (15 km
electrified); 88 km 0.760-m gauge (10 km electri-
fied) (2008)
Roadways: total: 124,508 km
country comparison to the world: 37
paved: 124,508 km (includes 1,719 km of express-
ways) (2012)
Waterways: 358 km (2011)
country comparison to the world: 90
Merchant marine: registered in other countries:
3 (Cyprus 1, Kazakhstan 1, Saint Vincent and the
Grenadines 1) (2010)
country comparison to the world: 134
Ports and terminals: Enns, Krems, Linz, Vienna
Airports: 128 (2012)
country comparison to the world: 45
Airports—with paved runways: total: 41
over 3,047 m: 2
2,438 to 3,047 m:9
1,524 to 2,437 m: 12
914 to 1,523 m: 2
under 914 m: 16 (2012)
Airports—with unpaved runways: total: 87
1,524 to 2,437 m: 1
914 to 1,523 m: 26
under 914 m: 60 (2012)
Heliports: (2012)
Pipelines: gas 7,010 km; oil 547 km; refined prod-
ucts 94 km (2010)
Railways: total: 9,469 km
country comparison to the world: 22
standard gauge: 9,449 km 1.435-m gauge (3,165
km electrified)
narrow gauge; 20 km 0.750-m gauge (2008)
Roadways: total: 127,797 km (includes urban
roads)
country comparison to the world: 36
paved: 127,797 km (includes 730 km of express-
ways) (2008)
Waterways: 664 km (principally on Elbe, Vltava,
Oder, and other navigable rivers, lakes, and
canals) (2010)
country comparison to the world; 77
Merchant marine: registered in other countries:
1 (Saint Vincent and the Grenadines 1) (2010)
country comparison to the world: 150
Ports and terminals: Decin, Prague, Usti nad
Labem','8150ed64bd3f48c46e22aa39918ebafda7ac6dcab21942fd46fe6ad9dfb19917','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a5f26d23bb6bef699a0f03b862a5417deabf955541f2d1b00cc509bc4858a9a9',2025,'AZ','Azerbaijan','transportation',162,'Airports: 37 (2012)
country comparison to the world: 109
Airports—with paved runways: total: 30
over 3,047 m: 5
2,438 to 3,047 m: 5
1,524 to 2,437 m: 13
914 to 1,523''m: 4
under 914 m: 3 (2012)
Airports—with unpaved runways: total: 7
under 914 m: 7 (2012)
Heliports: 1 (2012)
Pipelines: condensate 1 km; gas 3,361 km; oil
1,424 km (2010)
Railways: total: 2,918 km
country comparison to the world: 57
broad gauge: 2,918 km 1.520-m gauge (1,278 km
electrified) (2009)
Roadways: total: 52,942 km
country comparison to the world: 76
paved: 26,789 km
unpaved: 26,153 km (2006)
Merchant marine: total: 90
country comparison to the world: 53
by type: cargo 27, chemical tanker 1, passenger 2,
passenger/cargo 8, petroleum tanker 47, roll on/roll
off 3, specialized tanker 2
foreign-owned: 1 (Turkey 1)
registered in other countries: 2 (Malta 1, Saint
Vincent and the Grenadines 1) (2010)
Ports and terminals: Baku (Baki)
Airports: 61 (2012)
country comparison to the world: 81
Airports—with paved runways: total: 22
over 3,047 m: 2
2,438 to 3,047 m: 2
1,524 to 2,437 m: 13
914 to 1,523 m: 5 (2012)
Airports—with unpaved runways: total: 39
1,524 to 2,437 m: 4
914 to 1,523 m: 15
under 914 m: 20 (2012)
Heliports: | (2012)
Roadways: total: 2,717 km
country comparison to the world: 169
paved: 1,560 km
unpaved: 1,157 km (2002)
Merchant marine: total: 1,160
country comparison to the world: 10
by type: barge carrier 1, bulk carrier 238, cargo 170,
carrier 2, chemical tanker 87, combination ore/oil
8, container 57, liquefied gas 71, passenger 102,
passenger/cargo 26, petroleum tanker 225, refriger-
ated cargo 97, roll on/roll off 13, specialized tanker
2, vehicle carrier 61
foreign-owned: 1,063 (Angola 6, Australia 1, Bel-
gium 6, Bermuda 15, Brazil 1, Canada 96, Croatia
1, Cyprus 23, Denmark 69, Finland 8, France 15,
Germany 30, Greece 225, Guernsey 6, Hong Kong
3, Indonesia 2, Ireland 3, Italy 1, Japan 88, Jordan
2, Kuwait 1, Malaysia 13, Monaco 8, Montenegro
2, Netherlands 23, Nigeria 2, Norway 186, Poland
34, Saudi Arabia 16, Singapore 7, South Korea 1,
Shain ‘6, Sweden 11, Switzerland 1, Thailand 4,
Turkey 3, UAE 23, UK 18, US 109)
registered in other countries: 6 (Panama 6) (2010)
Ports and terminals: Freeport, Nassau, South
Riding Point','a43465865ff01de4ed6694d84654f6a36eb97af47e25b5751d1e2fb6ebf657b7','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b5f2a86fdba42aa31933cea74668dd37a58f0a42fd1b1eaf2deb65e7fb8fa13d',2025,'BH','Bahrain','transportation',173,'Airport: 4 (2012)
country comparison to the world: 185
Alrports—with paved runways: total: 4
over 3,047 m: 3
914 to 1,523 m: 1 (2012)
Heliports: 1 (2012)
Pipelines: gas 20 km; oil 29 km (2010)
Roadways: total: 4,122 km
country comparison to the world: 156
paved: 3,392 km
unpaved: 730 km (2010)
Merchant marine: total: 8
country comparison to the world: 119
by type: bulk carrier 2, container 4, petroleum
tanker 2
foreign-owned: 5 (Kuwait 5)
registered in other countries: 5 (Honduras 5)
(2010)
Ports and terminals: Mina’ Salman, Sitrah','a302b5719ced9f47288952cc1c4ecc0a1eeb288e0d7bf699446b11b074af748e','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e8638adcff39df855887931e39e8588ee74266f03900e3033514c39e05eccfd8',2025,'BD','Bangladesh','transportation',181,'Airports: 18 (2012)
country comparison to the world: 138
Airports—with paved runways: total; 16
over 3,047 m: 2
2,438 to 3,047 m: 2
1,524 to 2,437 m: 6
914 to 1,523 m: 2
under 914 m: 4 (2012)
Airports—with unpaved runways: total: 2
1,524 to 2,437 m: 1
under 914 m: 1 (2012)
Heliports: 3 (2012)
Pipelines: gas 2,714 km (2010)
Railways: total: 2,622 km
country comparison to the world: 64
broad gauge: 946 km 1.676-m gauge
narrow gauge: 1,676 km 1.000-m gauge (2008)
Roadways: total: 21,269 km
country comparison to the world; 105
paved: 1,063 km
unpaved: 20,206 km (2010)
Waterways: 8,370 km (includes up to 3,060 km of
main cargo routes; the network is reduced to 5,200
km in the dry season) (2011)
country comparison to the world: 17
Merchant marine: total: 62
country comparison to the world: 64
by type: bulk carrier 25, cargo 28, chemical tanker
1, container 5, petroleum tanker 3
foreign-owned: 8 (China 1, Singapore 7)
registered in other countries: 10 (Comoros 1,
Hong Kong 1, Panama 5, Saint Vincent and the
Grenadines 1, Sierra Leone 1, Singapore 1) (2010)
Ports and terminals: Chittagong, Mongla Port
Transportation—note: the International Mari-
time Bureau reports the territorial waters of Bang-
ladesh remain a risk for armed robbery. against
ships; attacks against vessels have decreased over
the last few years in response to improved local
security','6fb59eb8f6e4a9dd5e7e1f093821124ff01720bf7346a173361cc7912115d62b','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('39f1ebb8000076e92d33657b221d4b8f516a7d26c81818d8ea4564027d95cb69',2025,'BB','Barbados','transportation',192,'Airports: (2012)
country comparison to the world: 236
Airports—with paved runways: total: 1
over 3,047 m: 1 (2012)
Pipelines: gas 33 km; oil 62 km; refined products
4 km (2010)
Roadways: total: 1,600 km
country comparison to the world: 176
paved: 1,600 km (2004)
Merchant marine: total: 109
country comparison to the world: 49
by type: bulk carrier 23, cargo 52, chemical tanker
13, container 6, passenger 1, passenger/cargo 1,
petroleum tanker 8, refrigerated cargo 4, roll on/
roll off 1
foreign-owned: 83 (Canada 11, Greece 14, Iran 5,
Lebanon 2, Norway 38, Sweden 4, Syria 1, Turkey
1, UAE 1, UK 6) (2010)
Ports and terminals: Bridgetown','68978a6e5d4c544b1e6c88d3ef944af1dc6b2d8c6e09d12117634bfe79a2f628','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bb2ea1ffb02b5a8a091ac230c5dfb9fa1f07918e946e98d21fe77815ed183103',2025,'BY','Belarus','transportation',202,'Airports: 65 (2012)
country comparison to the world: 76
Alrports—with paved runways: total: 34
over 3,047 m: 2
2,438 to 3,047 m: 20
1,524 to 2,437 m: 4
914 to 1,523 m: 1
under 914 m: 7 (2012)
Airports—with unpaved runways:
311,524 to 2,437 m: 1
914 to 1,523 m: 2
under 914 m: 28 (2012)
Heliports: (2012)
Pipelines: gas 5,250 km; oil 1,528 km; refined
products 1,730 km (2010)
Railways: total: 5,537 km
country comparison to the world: 32
broad gauge: 5,512 km 1.520-m gauge (874 km
electrified)
standard gauge: 25 km 1.435-m gauge (2008)
total:
Roadways: total: 86,392 km
country comparison to the world: 53
paved: 74,651 km
unpaved: 11,741 km (2010)
Waterways: 2,500 km (use limited by its location
on the perimeter of the country and by its shal-
lowness) (2011)
country comparison to the world: 36
Ports and terminals: Mazyr','3e9e7bcebf06365e311ee2a3bdd2f7d98b8b44ac598bd8fa4f3868945bffd883','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('95091f367b7e402ebcf638bc1416e6295d09783f91afd4698652f1f1461b6a68',2025,'BE','Belgium','transportation',212,'Airports: 43 (2012)
country comparison to the world: 100
Airports—with paved runways: total: 27
over 3,047 m: 6
2,438 to 3,047 m:9
1,524 to 2,437 m: 2
914 to 1,523 m: 1
under 914 m: 9 (2012)
Airports—with unpaved runways: total: 16
under 914 m: 16 (2012)
Heliports: (2012)
Pipelines: gas 2,826 km; oil 154 km; refined prod-
ucts 535 km (2010)
Railways: total: 3,233 km
country comparison to the world: 55
standard gauge: 3,233 km 1.435-m gauge (2,950
km electrified) (2008)
Roadways: total: 154,012 km
country comparison to the world: 31
paved: 120,514 km (includes 1,756 km of
expressways)
unpaved: 33,498 km (2010)
Waterways: 2,043 km (1,528 km in regular com-
mercial use) (2012)
country comparison to the world: 42
Merchant marine: total: 87
country comparison to the world: 56
by type: bulk carrier 23, cargo 15, chemical tanker
5, container 4, liquefied gas 23, passenger 2, petro-
leum tanker 8, roll on/roll off 7
foreign-owned: 15 (Denmark 4, France 7, Russia
1, UK 2, US 1)
registered in other countries: 107 (Bahamas
6, Cambodia 1, Cyprus 3, France 7, Gibraltar 1,
Greece 17, Hong Kong 26, Liberia 1, Luxembourg
11, Malta 7, Marshall Islands 1, Mozambique 2,
North Korea 1, Panama 1, Portugal 8, Russia 4,
Saint Kitts and Nevis 1, Saint Vincent and the
Grenadines 7, Singapore 1, Vanuatu 1) (2010)
Ports and terminals: cargo ports (tonnage):
Antwerp, Gent, Liege, Zeebrugge container
ports (TEUs): Antwerp. (8,662,891), Zeebrugge
(2,209,715)
Airports: 43 (2012)
country comparison to the world: 99
Airports—with paved runways: total: 6
2,438 to 3,047 m: 1
914 to 1,523 m: 2
under 914 m: 3 (2012)
Airports—with unpaved runways: total: 37
2,438 to 3,047 m: 1
914 to 1,523 m: 10
under 914 m: 26 (2012)
Roadways: total: 3,007 km
country comparison to the world: 167
paved: 575 km
: unpaved: 2,432 km (2006)
Waterways: 825 km (navigable only by small
craft) (2011)
country comparison to the world: 71
Merchant marine: total: 247
country comparison to the world: 33
by type: barge cartier 1, bulk carrier 33, cargo 156,
chemical tanker 2, liquefied gas 1, passenger/cargo
4, petroleum tanker 9, refrigerated cargo 30, roll
on/roll off 10, specialized tanker 1
foreign-owned: 152 (Bulgaria 1, China 61, Croa-
tia 1, Estonia 1, Greece 2, Iceland 1, Italy 3, Latvia
9, Lithuariia 1, Netherlands 1, Norway 2, Russia
30, Singapore 4, Switzerland 1, Syria 4, Thailand
1, Turkey 16, UAE 3, UK 4, Ukraine 6) (2010)
Ports and terminals: Belize City, Big Creek','0f7f44493f1f8ef78dd5787ca3473db3a212770822f77794fe59303b170dbfcb','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3dac807d80d59d1ae3b1ba3481e034d1f6286d2a468f92b72aefdbe9a49aba30',2025,'BJ','Benin','transportation',225,'Airports: 5 (2012)
country comparison to the world: 179
Airports—with paved runways: total: |
1,524 to 2,437 m: 1 (2012)
Airports—with unpaved runways: total: 4
2,438 to 3,047 m: 1
1,524 to 2,437 m: 1
914 to 1,523 m: 2 (2012)
Railways: total: 438 km
country comparison to the world: 113
narrow gauge: 438 km 1.000-m gauge (2008)
Roadways: total: 16,000 km
country comparison to the world: 119
paved: 1,400 km
unpaved: 14,600 km (2006)
Waterways: 150 km (seasonal navigation on
River Niger along northern border) (2011)
country comparison to the world: 102
Ports and terminals: Cotonou','a684c4de9d833fb10f3891d5d6110cb5192abd6a6f2fd48567da51b306be5560','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bf3cc2d98d75d3ae8b3fe2fa19b2ea93b083c1eecde2b79ef2b71f792c5af064',2025,'BM','Bermuda','transportation',235,'Airports: (2012)
country comparison to the world: 212
Airports—with paved runways: total: |
2,438 to 3,047 m: 1 (2012)
Roadways: total: 447 km
country comparison to the world: 197
paved: 447 km
note: 225 km public roads; 222 km private roads
(2007)
Merchant marine: total: 139
country comparison to the world: 41
by type: bulk carrier 22, chemical tanker 3, con-
tainer 14, liquefied gas 43, passenger 27, pas-
senger/cargo 2, petroleum tanker 19, refrigerated
cargo 9
foreign-owned: 105 (France 1, Germany 14,
Greece 8, Hong Kong 4, Ireland 1, Israel 3, Japan
2, Monaco 2, Nigeria 11, Norway 5, Sweden 14,
UK 14, US 26)
registered in other countries: 241 (Bahamas 15,
Cyprus 1, France 5, Greece 3, Hong Kong 20, Isle
of Man 7, Liberia 4, Malta 15, Marshall Islands
35, Netherlands 1, Norway 24, Panama 27, Phil-
ippines 47, Saint Vincent and the Grenadines 1,
Singapore 25, UK 6, US 5) (2010)
Ports and terminals: Hamilton, Ireland Island,
Saint George','034f11f0a57e95768bdd873a5710a2c5357cc7e6434b3b9f132129280d86a996','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d14c7b084bc1c65485860c52306c373bbadec77f4880a7c8efece3f03edbd7a5',2025,'BT','Bhutan','transportation',247,'Airports: (2012)
country comparison to the world: 198
Airports—with paved runways: total: 1
1,524 to 2,437 m: 1 (2012)
Airports—with unpaved runways: total: 1
914 to 1,523 m: 1 (2012)
Roadways: total: 8,050 km
country comparison to the world: 140
paved: 4,991 km (includes 622 km of expressways)
unpaved: 3,059 km (2003)','7e97a0a5500cb86cad12bc5cc7e3ad33e710f92938e481678ac81ae90d2301f8','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('227a02ddf39e4e01da343a93db1661fecb17e53cb31923dd431f42bd390b5f13',2025,'BR','Brazil','transportation',255,'Airports: 865 (2012)
country comparison to the world: 7
Airports—with paved runways: total: 21
over 3,047 m: 4
2,438 to 3,047 m:5
1,524 to 2,437 m: 6
914 to 1,523 m: 6 (2012)
Airports—with unpaved runways: over 3,047
m:1
2,438 to 3,047 m: 4
1,524 to 2,437 m: 5I
914 to 1,523 m:157
under 914 m: 631 (2012) ;
Pipelines: gas 5,330 km; liquid petroleum gas
51 km; oil 2,510 km; refined products 1,627 km
(2010)
Railways: total: 3,652 km A
country comparison to the world: 46
narrowgauge: 3,652 km 1.000-m gauge (2010)
Roadways: total: 80,488 km
country comparison to the world: 57
paved: 11,993 km
unpaved: 68,495, km (2010)
Waterways: 10,000 km (commercially navigable
almost exclusively in the northern and eastern
parts of the country) (2012)
country comparison to the world: 13
Merchant marine: total: 18
country comparison to the world: 98
by type: bulk carrier 1, cargo 14, petroleum tanker
1, roll on/roll off 2
foreign-owned: 5 (Syria 4, UK 1, (2010)
Ports and terminals: Puerto Aguirre (inland port
on the Paraguay/Parana waterway at the Bolivia/
Brazil border); Bolivia has free port privileges in
maritime ports in Argentina, Brazil, Chile, and
Airports: 4,105 (2012)
country comparison to the world: 2
Airports—with paved runways: total: 713
over 3,047 m: 7
2,438 to 3,047 m: 28
1,524 to 2,437 m: 1212)
Airports—with unpaved runways: total: 3,392
1,524 to 2,437 m: 91
914 to 1,523 m: 1,648
under 914 m: 1,653 (2012)
Heliports: 13 (2012)
Pipelines: condensate/gas 62 km; gas 13,514 km;
liquid petroleum gas 352 km; oil 3,729 km; refined
products 4,684 km (2010)
Railways: total: 28,538 km
country comparison. to the world: 10
broad gauge: 5,627 km 1.600-m gauge (467 km
electrified)
standard gauge: 194 km 1.440-m gauge
narrow gauge: 22,717 km 1.000-m gauge (2008)
Roadways: total: 1,580,964 km
country comparison to the world: 4
paved: 212,798 km
unpaved: 1,368,166 km
note: does not include urban roads (2010)
Waterways: 50,000 km (most in areas remote
from industry and population) (2012)
country comparison to the world: 3
Merchant marine: total: 109
country comparison to the world: 50
by type: bulk carrier 18, cargo 16, chemical tanker
7, container 13, liquefied gas 11, petroleum tanker
39, roll on/roll off 5
foreign-owned: 27 (Chile 1, Denmark 3, Ger-
many 6, Greece 1, Norway 3, Spain 12, Turkey
1) registered in other countries: 36 (Argentina 1,
Bahamas 1, Ghana 1, Liberia 20, Marshall Islands
1, Panama 3, Singapore 9) (2010)
Ports and terminals: cargo ports: Ilha Grande
(Gebig), Paranagua, Rio Grande, Santos, Sao
Sebastiao, Tubarao container ports (TEUs); San-
tos (2,677,839), Itajai (693,580)
oil terminals: DTSE/Gegua oil terminal, Guaiba
Island terminal, Guamare oil terminal','0415ffe40d09e0f2d92b7e4291540984a1a0a169f43b73e7c07b7e0ca006041c','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ffea43798b2c9d7c90a1f90a7b569f2d39840abb767b29b020b059a9cf9b98f3',2025,'BA','Bosnia and Herzegovina','transportation',264,'Airports: 25 (2012)
country comparison to the world: 127
Airports—with paved runways: total: 7
2,438 to 3,047 m: 4
1,524 to 2,437 m: 1
under 914 m: 2 (2012)
Airports—with unpaved runways: total: 18
1,524 to 2,437 m: 1
914 to 1,523 m:6
under 914 m: 11 (2012)
Heliports: 6 (2012)
Pipelines: gas 147 km; oil 9 km (2010)
Railways: total: 601 km
country comparison to the world: 107
standard gauge: 601 km 1.435-m gauge (392 km
electrified) (2009)
Roadways: total: 22,926 km
country comparison to the world: 102
paved: 19,426 km (4,652 km of interurban roads)
unpaved: 3,500 km (2010)
Waterways: (Sava River on northern border;
open to shipping but use limited) (2011)
Ports and terminals: Bosanska Gradiska, Bosan-
ski Brod, Bosanski Samac, and Brcko (all inland
waterway ports on the Sava River), Orasje','c2a516d4c55891b98a7559c9c7a0f63d549d3db024093d6f9d55969dfc85787d','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7d20584009d3a566c535b14b7c67908fd268dbfe4d730792680f39018595400e',2025,'BW','Botswana','transportation',275,'Airports: 76 (2012)
country comparison to the world: 72
Airports—with paved runways: total: 10 over
3,047 m: 1
2,438 to 3,047 m: 1
1,524 to 2,437 m: 7
914 to 1,523 m: 1 (2012)
Airports—with unpaved runways: total: 66
1,524 to 2,437 m: 5
914 to 1,523 m: 47
97
under 914 m: 14 (2012)
Railways: total: 888 km
country comparison to the world: 93
narrow gauge: 888 km 1.067-m gauge (2008)
Roadways: total: 17,916 km
country comparison to the world: 116
note: includes 8,916 km of Public Highway Network
roads (6,116 km paved and 2,800 km unpaved) and
other 9,000 km of District Council roads (2011)','72dd22e72325d47e6e6984214f2f8fb2271e17384cc984aaba16c2e8520b4176','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9e6ce1c6fc07e6167539feadd0b20a491d422436aa8cbd65bda95d8d415353e2',2025,'ID','Indonesia','transportation',291,'Airports: (2012)
country comparison to the world: 220
Airports—with paved runways: total: 1
over 3,047 m: 1 (2012)
Roadways: note: short section of paved road
between port and airfield on Diego Garcia
Ports and terminals: Diego Garcia
Airports: 4 (2012)
country comparison to the world: 190
Airports—with paved runways: total: 2
914 to 1,523 m:1
under 914 m: 1 (2012)
Airports—with unpaved runways: total: 2
914 to 1,523 m: 2 (2012)
Roadways: total: 200 km
country comparison to the world: 208
paved: 200 km (2007)
Ports and terminals: Road Harbor
Manpower available for military service:
males age 16-49: 7,266 (2010 est.)
Manpower fit for military service: males age
16-49: 6,057
females age 16-49: 5,805 (2010 est.)
Manpower reaching militarily significant age
annually: male: 168
female: 162 (2010 est.)
Military—note: defense is the responsibility of
the UK
Airports: (2012)
country comparison to the world: 213
Alrports—with paved runways: total: 1
over 3,047 m: 1 (2012)
Heliports: 3 (2012)
Pipelines: condensate 33 km; gas 37 km; oil 18
km (2010)
Roadways: total: 3,029 km
country comparison to the world: 166
paved: 2,425 km
unpaved: 604 km (2010)
Waterways: 209 km (navigable by craft drawing
less than 1.2 m; the Belait, Brunei, and Tutong riv-
ers are major transport links) (2012)
country comparison to the world: 97
Merchant marine: total: 9
country comparison to the world: 115
by type: chemical tanker 1, liquefied gas 8
foreign-owned: 2 (UK 2) (2010)
Ports and terminais: Lumut, Muara, Seria
Airports: 676 (2012)
country comparison to the world: 10
Airports—with paved runways: total: 185
over 3,047 m: 4
2,438 to 3,047 m: 22
1,524 to 2,437 m: 51
914 to 1,523 m: 71
under 914 m: 37 (2012)
Airports—with unpaved runways: total: 491
1,524 to 2,437 m: 5
914 to 1,523 m: 24
under 914 m: 462 (2012)
Heliports: 76 (2012)
Pipelines: condensate 812 km; condensate/
gas 73 km; gas 7,165 km; oil 5,984 km; oil/gas/
water 12 km; refined products 617 km; water 44
km (2010)
Railways: total: 5,042 km
country comparison to the world: 35
narrow gauge: 5,042 km 1.067-m gauge (565 km
electrified) (2008)
Roadways: total: 437,759 km
country comparison to the world: 14
paved: 258,744 km
unpaved: 179,015 km (2008)
Waterways: 21,579 km (2011)
country comparison to the world: 6
Merchant marine: total: 1,340
country comparison to the world: 8
by type: bulk carrier 105, cargo 618, chemical .
tanker 69, container 120, liquefied gas 28, passen-
ger 49, passenger/cargo 77, petroleum tanker 244,
refrigerated cargo 6, roll on/roll off 12, specialized
tanker 1, vehicle carrier 11
foreign-owned; 69 (China 1, France 1, Greece 1,
Japan 8, Jordan 1, Malaysia 1, Norway 3, Singa-
pore 46, South Korea 2, Taiwan 1, UK 2, US 2)
registered in other countries: 95 (Bahamas 2,
Cambodia 2, China 2, Hong Kong 10, Liberia 4,
Marshall Islands 1, Mongolia 2, Panama 10, Singa-
pore 60, Tuvalu 1, unknown 1) (2010)
Ports and terminals: Banjarmasin, Belawan,
Kotabaru, Krueg Geuktich, Palembang, Panjang,
Sungai Pakning, Tanjung Perak, Tanjung Priok
Transportation—note: the International Mari-
time Bureau continues to report the territorial and ,
offshore waters in the Strait of Malacca and South
China Sea as high risk for piracy and armed rob-
bery against ships; attacks have increased yearly
since 2009; in 2012, 73 commercial vessels were
boarded and 47 crew members taken hostage;
hijacked vessels are often disguised and cargo
diverted to ports in East Asia; crews have been
murdered or cast adrift
Airports: 324 (2012)
country comparison to the world: 23
Airports—with paved runways: total: 136
over 3,047 m: 42
2,438 to 3,047 m: 29
1,524 to 2,437 m: 24
914 to 1,523 m: 34
under 914 m: 7 (2012)
Airports—with unpoved runways: total: 188
over 3,047 m: 1
2,438 to 3,047 m: 1
1,524 to 2,437 m: 10
914 to 1,523 m: 142
under 914 m: 34 (2012)
Heliports: 21 (2012)
Pipelines: condensate 7 km; condensate/gas 12
km; gas 20,155 km; liquid petroleum gas 570 km;
oil 7,123 km; refined products 7,937 km (2010)
Railways: total: 8,442 km
country comparison to the world: 24
broad gauge: 94 km 1.676-m gauge
standard gauge: 8,348 km 1.435-m gauge (148 km
electrified) (2008)
Roadways: total: 172,927 km
country comparison to the world: 28
paved: 125,908 km (includes 1,429 km of
expressways)
unpaved: 47,019 km (2006)
Waterways: 850 km (on Karun River; some navi-
gation on Lake Urmia) (2012)
country comparison to the world: 70
Merchant marine: total: 76
country comparison to the world: 60
350
THE CIA WORLD FACTBOOK
by type: bulk carrier 8, cargo 51, chemical tanker
3, container 4, liquefied gas 1, passenger/cargo 3,
petroleum tanker 2, refrigerated cargo 2, roll on/
roll off 2 foreign-owned: 2 (UAE 2)
registered in other countries: 71 (Barbados 5,
Cyprus 10, Hong Kong 3, Malta 48, Panama 5)
(2010)
Ports and terminals: Assaluyeh, Bandar Abbas,
Bandar-e-Eman Khomeyni','63963858819913d80ae2eb7833f2969146e0c5c6e8c6bc1f2d3fd88f56b1ab45','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('591ad134914415618ebbd63de6ef5018a79204cf2dae3382ba018356cac67ea8',2025,'BG','Bulgaria','transportation',305,'Airports: 202 (2012)
country comparison to the world: 28
Airports—with paved runways: total: 124
over 3,047 m: 2
2,438 to 3,047 m: 17
1,524 to 2,437 m: 15
under 914 m: 90 (2012)
Airports—with unpaved runways: total: 78
914 to 1,523 m: 6
under 914 m: 72 (2012)
Heliports: (2012)
Pipelines: gas 2,844 km; oil 346 km; refined prod-
ucts 156 km (2010)
Railways: total: 4,152 km
country comparison to the world: 40
standard gauge: 4,072 km 1.435-m gauge (2,863
km electrified)
narrow gauge: 80 km 0.760-m gauge (2011)
Roadways: total: 19,512 km
country comparison to the world: 109
paved: 19,235 km (includes 458 km of expressways)
unpaved: 277 km
note: does not include Category IV local roads
(2011)
Waterways: 470 km (2009)
country comparison to the world: 84
Merchant marine: total: 22
country comparison to the world: 93
by type: bulk carrier 9, cargo 8, liquefied gas 2,
petroleum tanker 1, roll on/roll off 2
foreign-owned: 14 (Germany 12, Russia 2)
registered in other countries: 30 (Belize 1,
Comoros 4, Georgia 1, Malta 8, Moldova 1, Pan-
ama 6, Saint Vincent and the Grenadines 9) (2010)
Ports and terminals: Burgas, Varna','c76b6a87da7c3643175d10c9081482f03638f3de56e923ecdc6eb211adbff1a7','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b2f4eff48934c13aa7f627f00f49f7ab170cb51da3bc16bb5eb6aaebc5402373',2025,'BF','Burkina Faso','transportation',319,'Airports: 24 (2012)
country comparison to the world: 131
Airports—with paved runways: total: 2
over 3,047 m: 1
2,438 to 3,047 m: 1 (2012)
Airports—with unpaved runways: total: 22
1,524 to 2,437 m: 4
914 to 1,523 m: 12
under 914 m: 6 (2012)
Railways: total: 622 km
country comparison to the world: 106
narrow gauge: 622 km 1.000-m gauge
note: another 660 km of this railway extends into
Cote d''Ivoire (2008)
Roadways: total: 15,272 km
country comparison to the world: 121
note: does not include urban roads (2010)
Airports: 74 (2012)
country comparison to the world: 73
Airports—with paved runways: total: 36
over 3,047 m: 12
2,438 to 3,047 m: 11
1,524 to 2,437 m: 12
under 914 m: 1 (2012)
Airports—with unpaved runways: total: 38 over
3,047 m: 1
over 3,047 m: 1
1,524 to 2,437 m: 4
914 to 1,523 m: 10
under 914 m: 23 (2012)
Heliports: 9 (2012) ; i
Pipelines: gas 3,046 km; oil 551 km (2010)
Railways: total: 5,031 km
country comparison to the world: 36
narrow gauge: 5;031 km 1.000-m gauge (2008)
Roadways: total: 34,377 km (includes 358 km of
expressways) (2010)
country comparison to the world: 94
Waterways: 12,800 km (2011)
country comparison to the world: 10
Merchant marine: total: 29
country comparison to the world: 86
by type: cargo 22, passenger 2, passenger/cargo 3,
specialized tanker 1, vehicle carrier 1
foreign-owned: 2 (Germany 1, Japan 1) registered
in other countries: 3 (Panama 3) (2010)
Ports and terminals: Moulmein, Rangoon,
Sittwe','e653fb12cab0a5ec9957df8e9d4079ca9721c8542ba1a5b3a809d4e51c75c20b','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('61d61e54480853b55a84c07169ec8ac028742641b8dd0905067f5ba993f7e493',2025,'BI','Burundi','transportation',329,'Airports: 7 (2012)
country comparison to the world: 165
Airports—with paved runways: total: 1
over 3,047 m: 1 (2012)
Airports—with unpaved runways: total: 6
914 to 1,523 m: 4
under 914 m: 2 (2012)
Heliports: 1 (2012)
Roadways: total: 12,322 km
country comparison to the world: 129
paved: 1,286 km
unpaved: 11,036 km (2004)
Waterways: (mainly on Lake Tanganyika between
Bujumbura, Burundi’s principal port, and lake
124
THE CIA WORLD FACTBOOK
ports in Tanzania, Zambia, and the Democratic
Republic of Congo) (2011)
Ports and terminals: Bujumbura','0ae6e6f1f467a83872d9bd0a1a20dd21a7ca6abcccf916905904352c9ad6b3dd','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('aee9afa986f109e556d0ad9de2752e2759b4370aafc4a41edf32ad6fffe0dde2',2025,'KH','Cambodia','transportation',337,'Airports: 16 (2012)
country comparison to the world: 142
Airports—with paved runways: total: 6
2,438 to 3,047 m: 3
1,524 to 2,437 m: 2
914 to 1,523 m: 1 (2012)
Airports—with unpaved runways: total: 10
1,524 to 2,437 m: 2
914 to 1,523 m: 7
under 914 m: 1 (2012)
Heliports: 1 (2012)
Railways: total: 690 km
country comparison to the world: 101
narrow gauge: 690 km 1.000-m gauge
note: under restoration (2010)
Roadways: total: 39,618 km
country comparison to the world: 89
paved: 2,492 km
unpaved: 37,126 km (2009)
Waterways: 3,700 km (mainly on Mekong River)
(2012)
country comparison to the world: 29
Merchant marine: total: 544
country comparison to the world: 21 ‘ :
by type: bulk carrier 38, cargo 459, carrier 7,
chemical tanker 4, container 4, liquefied gas 1,
passenger 1, passenger/cargo 6, petroleum tanker
8, refrigerated cargo 11, roll on/roll off 4, vehicle
carrier 1
foreign-owned: 352 (Belgium 1, Canada 2, China
177, Cyprus 4, Egypt 4, Estonia 1, French Polynesia
1, Gabon 1, Greece 2, Hong Kong 10, Indonesia 2,
Ireland 1, Japan 1, Lebanon 5, Russia 50, Singapore
3, South Korea 10, Syria 22, Taiwan 1, Turkey 15,
UAE 2, UK 1, Ukraine 35, Vietnam 1) (2010)
Ports and terminals: Phnom Penh, Kampong
Saom (Sihanoukville)','44e147b923721ff6a3190fed8f152925cda610082748370bdfff295226c304ff','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('134f624af596e4b40366d3ea3658892bbfd0877d1028f67a3c897d28d5cc1538',2025,'CM','Cameroon','transportation',346,'Airports: 34 (2012)
country comparison to the world: 112
Airports—with paved runways: total: 11
over 3,047 m:2
2,438 to 3,047 m: 5
1,524 to 2,437 m:3
914 to 1,523 m: 1 (2012)
Airports—with unpaved runways: total: 23
1,524 to 2,437 m: 3
914 to 1,523 m: 13
under 914 m: 7 (2012)
Pipetines: oi! 886 km (2010)
Railways: total: 1,245 km
country comparison to the world: 82
narrow gauge: 1,245 km 1.000-m gauge (2008)
Roadways: total: 50,000 km
country comparison to the world; 78
paved: 5,000 km
unpaved: 45,000 km
note: there are 28,857 km of national roads (2008)
Waterways: (major rivers in the south, such as the
Wouri and the Sanaga, are largely non-navigable;
in the north, the Benue, which connects through
Nigeria to the Niger River, is navigable in the
rainy season only to the port of Garoua) (2010)
Ports and terminals: Douala, Garoua, Limboh
Terminal','d534d2a8fa225e7d7a3da047f43ed0d2132e1a13ed5b168bf772322da802197b','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('53338cd6f2bdf0d60f6dc91e87199285086834a690b574351bb72722e29f7e1f',2025,'CA','Canada','transportation',354,'Airports: 1,453 (2012)
country comparison to the world: 4
Airports—with paved runways: total: 522
over 3,047 m: 19
2,438 to 3,047 m: 20
1,524 to 2,437 m: 148
914 to 1,523 m: 257
under 914 m: 78 (2012)
Airports—with unpaved runways: total: 931
1,524 to 2,437 m: 72
914 to 1,523 m: 387
under 914 m: 472 (2012)
Heliports: 27 (2012)
Pipelines: gas 835 km; liquid petroleum gas
75,000 km (2010)
Railways: total: 46,552 km
country comparison to the world: 5 `
standard gauge: 46,552 km 1.435-m gauge (2008)
Roadways: total: 1,042,300 km
country comparison to the world: 6
paved: 415,600 km (includes 17,000 km of
expressways)
unpaved: 626,700 km (2008)
Waterways: 636 km (Saint Lawrence Seaway of
3,769 km, including the Saint Lawrence River of
3,058 km, shared with United States) (2011)
country comparison to the world: 78
Merchont marine: total: 181
country comparison to the world: 35
by type: bulk carrier 62, cargo 15, carrier 1, chemi-
cal tanker 15, combination ore/oil 1, container 2,
passenger 5, passenger/cargo 63, petroleum tanker
11, roll on/roll off 6
foreign-owned: 19 (Estonia 1, France 1, Nether-
lands 1, Norway 4, Sweden 2, US 10)
registered in other countries: 225 (Australia 5,
Bahamas 96, Barbados 11, Cambodia 2, Cyprus 2,
Honduras 1, Hong Kong 77, Liberia 2, Malta 5,
Marshall Islands 8, Norway 1, Panama 6, Spain 4,
Vanuatu 5) (2010)
Ports and terminals: Fraser River Port, Hali-
fax, Hamilton, Montreal, Port-Cartier, Quebec
City, Saint John (New Brunswick), Seprt-Isles,
Vancouver
oil terminals: Lower Lakes terminal
Airports: 9 (2012)
country comparison to the world: 159
Airports—with paved runways: total: 9
over 3,047 m: 1
1524 to 2,437 m: 3
914 to 1,523 m: 3
under 914 m: 2 (2012)
Roadways: total: 1,350 km
country comparison to the world: 178
paved: 932 km
unpaved: 418 km (2000)
Merchant marine: total: 13
country comparison to the world: 104
by type: cargo 3, chemical tanker 2, passenger/
cargo 7, petroleum tanker I
foreign-owned: 3 (Greece 1, Spain 1, UK 1)
registered in other countries: 1 (unknown 1)
(2010)
Ports and terminals: Porto Grande','38f77cbdd2cb5f28bab2f025f45d4335939f1d880fea732c1e3132b610cd4bb8','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a0d5537a4d21aa20e11602eefa065d365f98f33870b329814a0ec2caf9ed2392',2025,'KY','Cayman Islands','transportation',366,'Airports: 3 (2012)
country comparison to the world: 195
Airports—with paved runways: total: 2
1,524 to 2,437 m: 2 (2012)
Airports—with unpaved runways: total: 1
914 to 1,523 m: 1 (2012)
Roadways: total: 785 km
country comparison to the world: 187
paved: 785 km (2007)
Merchant marine: total: 116
country comparison to the world: 46
by type: bulk carrier 19, cargo 3, chemical tanker
61, liquefied gas 1, passenger 1, petroleum tanker
5, refrigerated cargo 10, vehicle carrier 16
foreign-owned: 102 (Germany 3, Greece 9, Italy
7, Japan 23, Switzerland 1, UK 2, US 57) (2010)
Ports and terminals: Cayman Brac, George Town','90862da2c349faee44d7fc0ca931d039ec4bef55cee2120359c836b6926d7815','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b77583ce6c09f9a50cc4d943b03753dc8fa0f2fd04ed725d0e5df2f98cf1f446',2025,'CF','Central African Republic','transportation',376,'Airports: 40 (2012)
country comparison to the world: 106
Airports—with paved runways: total: 2
2,438 to 3,047 m: 1
1,524 to 2,437 m: 1 (2012)
Airports—with unpaved runways: total: 38
2,438 to 3,047 m: 1
1,524 to 2,437 m: 12
914 to 1,523 m: 19
under 914 m: 6 (2012)
Roadways: total: 20,278 km (2010)
country comparison to the world: 107
Waterways: 2,800 km (the primary naviga-
ble river is the Ubangi, which joins the River
Congo; it was the traditional route for the
export of products because it connected with
the Congo-Ocean railway at Brazzaville; because
of the warfare on both sides of the River Congo
from 1997, however, routes through Cameroon
became preferred by importers and exporters)
(2011)
country comparison to the world: 35
Ports and terminals: Bangui, Nola, Salo, Nzinga','abea52c5741bfc0d41a48b2fd18277cf07a4bf6af377804b5daa9dbb45cef126','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('22633ad47cb90e829a4b219911af7aad7408f22d8b1d79320626e1d16d871c16',2025,'TD','Chad','transportation',383,'Airports: 58 (2012)
country comparison to the world: 83
Airports—with paved runways: total: 9
over 3,047 m:2
2,438 to 3,047 m: 4
1,524 to 2,437 m: 2
under 914 m: 1 (2012)
Airports—with unpaved runways: total: 49
2,438 to 3,047 m: 2
1,524 to 2,437 m: 16
914 to 1,523 m: 20
under 914 m: 11 (2012)
Pipelines: oil 265 km (2010)
Roadways: total: 40,000 km
country comparison to the world: 88
note: consists of 25,000 km of national and
regional roads and 15,000 km of local roads; 206
km of urban roads are paved (2011)
Waterways: (Chari and Legone rivers are naviga-
ble only in wet season) (2012)','e56731e6b53d0129a8fa812062d89a2c4ee6f27d0c0a9464479a5aa52d21627f','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('588f46abece899290697939f65c7d8f5e39830d46148f83bdc286b5c3fb17e77',2025,'CN','China','transportation',398,'Airports: 497 (2012)
country comparison to the world: 14
Airports—with paved runways: total: 452
over 3,047 m: 68
2,438 to 3,047 m: 147
1,524 to 2,437 m: 126
914 to 1,523 m: 26
under 914 m: 85 (2012)
Airports—with unpaved runways: total: 45
over 3,047 m: 2
2,438 to 3,047 m: 2
1,524 to 2,437 m: 10
914 to 1,523 m: 10
under 914 m: 21 (2012)
Heliports: 50 (2012)
Pipelines: gas 38,566 km; oil 23,470 km; refined
products 13,706 km (2010)
Railways: total: 86,000 km
country comparison to the world: 3 standard
gauge: 86,000 km 1.435-m gauge (36,000 km elec-
trified) (2008)
Roadways: total: 4,106,387 km
country comparison to the world: 2
paved: 3,453,890 km (includes 84,946 km of
expressways)
unpaved: 652,497 km (2011)
Waterways: 110,000 km (navigable waterways)
(2011)
country comparison to the world: 1
Merchant marine: total: 2,030
country comparison to the world: 3
by type: barge carrier 7, bulk carrier 621, cargo
566, carrier 10, chemical tanker 140, container
206, liquefied gas 60, passenger 9, passenger/cargo
81, petroleum tanker 264, refrigerated cargo 33,
roll on/roll off 8, specialized tanker 2, vehicle ċar-
rier 23
foreign-owned: 22 (Hong Kong 18, Indonesia 2,
Japan 2)
registered in other countries: 1,559 (Bangladesh
1, Belize 61, Cambodia 177, Comoros 1, Cyprus 6,
Georgia 10, Honduras 2, Hong Kong 500, India 1,
Indonesia 1, Kiribati 26,-Liberia 4, Malta 6, Mar-
shall Islands 14, North Korea 3, Panama 534, Phil-
ippines 4, Saint Kitts and Nevis 1, Saint Vincent
and the Grenadines 65, Sao Tome and Principe
1, Sierra Leone 19, Singapore 29, South Korea 6,
Thailand 1, Togo 1, Tuvalu 4, UK 7, Vanuatu 1,
unknown 73) (2010)
Ports and terminals: Dalian, Guangzhou,
Ningbo, Qingdao, Qinhuangdao, Shanghai, Shen-
zhen, Tianjin
MILITARNY
Military branches: People’s Liberation Army
(PLA): Ground Forces, Navy (includes marines
and naval aviation), Air Force (Zhongguo Renmin
Jiefangjun Kongjun, PLAAF; includes Airborne
Forces), and Second Artillery Corps (strategic
missile force); People’s Armed Police (PAP); PLA
Reserve Force (20 10)
Military service age and obligation: 18-24 years
of age for selective compulsory military service,
156
THE CIA WORLD FACTBOOK
with a 2-year service obligation; no minimum age
for voluntary service (all officers are volunteers);
18-19 years of age for women high school gradu-
ates who meet requirements for specific military
jobs; a recent military decision allows women in
combat roles; the first class of women warship
commanders was in 2011 (2012)
Manpower available for military service:
males age 16-49: 385,821,101
females age 16-49: 363,789,674 (2010 est.)
Manpower fit for military service: males age
16-49: 318,265,016
females age 16-49: 300,323,611 (2010 est.)
Manpower reaching militarily significant age
annually: male: 10,406,544
female: 9,131,990 (2010 est.)
Military expenditures: 2.6% of GDP (2012)
country comparison to the world: 53
Airports: 14 (2012)
country comparison to the world: 151
Airports—with paved runways: total: 10
2,438 to 3,047 m: 2
under 914 m: 8 (2012)
Airports—with unpaved runways: total: 4
914 to 1,523 m: 1
under 914 m: 3 (2012)
Pipelines: gas 268 km; oil 120 km (2010)
Railways: total: 699 km
country comparison to the world: 100
standard gauge: 699 km 1.435-m gauge (234 km
electrified) (2010)
Roadways: total: 13,736 km (includes 216 km of
expressways) (2010)
country comparison to the world: 127','fd26e038fe996cffaad16ec24672487c14a06764727c5bba46251bf36b7ab515','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d48d63b907894016915c1f333f9b45bc53b96b38097f6c9c87d728767ff5b5b0',2025,'CX','Christmas Island','transportation',406,'Airports: 1 (2012)
country comparison to the world: 223
Airports—with paved runways: total: 1
1,524 to 2,437 m: 1 (2012)
Railways: total: 18 km
country comparison to the world: 133
standard gauge: 18 km 1.435-m (not in opera-
tion) (2010)
Roadways: total: 140 km
country comparison to the world: 211
paved: 30 km
unpaved: 110 km (2007)
Ports and terminals: Flying Fish Cove
Military—note: defense is the responsibility of
>
G
z
5
Ports and terminals: none; offshore anchorage
only','492873b7198cce0891fdc464bc1cfcd39ea61e343295a29646d8aafd93bf4b0b','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('54f685a01103e5f98aae0be17d01a1c0f5aa120833beded1455bcc784448c687',2025,'CO','Colombia','transportation',420,'Airports; 862 (2012)
country comparison to the world: 8
Airports—with paved runways: total: 121
over 3,047 m: 2
2,438 to 3,047 m:7
1,524 to 2,437 m: 41
914 to 1,523 m: 55
under 914 m: 16 (2012)
Airports—with unpaved runways: total: 741
over 3,047: 1
1,524 to 2,437 m: 25
914 to 1,523 m: 178
under 914 m: 537 (2012)
Heliports: 2 (2012)
Pipelines: gas 4,801 km; oil 6,334 km; refined
products 3,309 km (2010)
Railways: total: 874 km
country comparison to theworld: 95
standard gauge: 150 km 1.435-m gauge
narrow gauge: 498 km 0.950-m gauge; 226 km
0.914-m gauge (2008)
Roadways: total: 141,374 km (2010)
country comparison to the world: 33
Waterways: 24,725 km (18,300 km navigable; the
most important waterw ay, the River Magdalena,
of which 1,488 km is navigable, is dredged regu-
larly to ensure the safe passage of cargo vessels and
container barges) (2012)
country comparison to the world: 5
Merchant marine: total: 12
country comparison to the world: 105
by type: cargo 9, chemical tanker 1, petroleum
tanker 2
registered in other countries: 4 (Antigua and Bar-
buda 1, Panama 2, Portugal 1) (2010)
Ports and terminals: Barranquilla, Buenaventura,
Cartagena, Puerto Bolivar, Santa Marta, Turbo
oil term inals: Covenas offshore terminal
163
Airports: 492 (2012)
country comparison to the world: 15
Airports—with paved runways: total: 128
over 3,047 m: 6
2,438 to 3,047 m:9
1,524 to 2,437 m: 35
914 to 1,523 m: 61
under 914 m: 17 (2012)
Airports—with unpaved runways: total: 364
2,438 to 3,047 m:3
1,524 to 2,437 m: 55
914 to 1,523 m: 113
under 914 m: 193 (2012)
Heliports: 3 (2012)
Pipelines: extra heavy crude 980 km; gas 5,347
km; oil 6,694 km; refined products 1,620 km
(2010)
Railways: total: 806 km
country comparison to the world: 98
standard gauge: 806 km 1.435-m gauge (41 km
electrified) (2008)
Roadways: total: 96,155 km
country comparison to the world: 44
paved; 32,308 km
unpaved: 63,847 km (2002)
Waterways: 7,100 km (the Orinoco River (400
km) and Lake de Maracaibo are navigable by
oceangoing vessels) (2011)
country comparison to the world: 21
Merchant marine: total: 53
country comparison to the world: 69
by type: bulk carrier 4, cargo 12, chemical tanker
1, liquefied gas 5, passenger 1, passenger/cargo 14,
petroleum tanker 16
foreign-owned: 9 (Denmark 1, Estonia 1, Ger-
many 1, Greece 4, Mexico 1, Spain 1)
registered in- other countries: 14 (Panama 13,
Saint Vincent and the Grenadines tł) (2010)
Ports and terminais: La Guaira, Maracaibo,
Puerto Cabello, Punta Cardon
oil terminals: Jose terminal
Transportation—note: the International Mari-
time Bureau reports the territorial and offshore
waters in the Caribbean Sea as a significant risk
for piracy and armed robbery against ships; numer-
ous vessels, including commercial shipping and
pleasure craft, have been attacked and hijacked
both at anchor and while underway; crews have
been robbed and stores or cargoes stolen','d101054fa9bfbbd379e0b8c37fa9030b7f45887ba6aed52f3db6bc8219c5d30a','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('65a945bac07019430d1c84c8e2f3650702da893891ee0fb5efdf7f3d8310f6dc',2025,'KM','Comoros','transportation',430,'Airports: 4 (2012)
country comparison to the world: 186
Airports—with paved runways: total: 4
2,438 to 3,047 m:1
914 to 1,523 m: 3 (2012)
Roadways: total: 880 km
country comparison to the world: 185
paved: 673 km
unpaved: 207 km (2002)
Merchant marine: zotal: 149
country comparison to the world: 39
by type: bulk carrier 16, cargo 83, carrier 5, chemi-
cal tanker 5, container 2, passenger 2, passenger/
cargo 1, petroleum tanker 17, refrigerated cargo 10,
roll on/roll off 8
foreign-owned: 73 (Bangladesh 1, Bulgaria 4,
China 1, Cyprus 2, Greece 4, Kenya 2, Kuwait 1,
Latvia 2, Lebanon 2, Lithuania 1, Nigeria 1, Norw
ay l, Pakistan 5, Russia 12, Syria 5, Turkey 8, UAE
8, UK 1, Ukraine 10, US 2) (2010)
Ports and terminals: Mayotte, Mutsamudu','1cd5184e07606ee3eabc62ee7bd2697431231c314f3c1c436bb778dbb1b4724a','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('90aa485b8029a52543191c4e4db55475ea7d1a726aa12a5d4c75a5490a082786',2025,'ZM','Zambia','transportation',436,'THE Airports: 201 (2012)
country comparison to the world: 30
Airports—with paved runways: total: 26
over 3,047 m: 4
2,438 to 3,047 m:2
1,524 to 2,437 m: 17
* 914 to 1,523 m: 2
under 914 m: 1 (2012)
Alrports—with unpaved runways: total: 175
1,524 to 2,437 m: 19
914 to 1523 m: 94
under 914 m: 62 (2012)
Heliports: 1 (2012)
Pipelines: gas 37 km; oil 39 km; refined products
756 km (2010)
Railways: total: 4,007 km
country comparison to the world: 43
narrow gauge: 3,882 km 1.067-m gauge (858 km
electrified); 125 km 1.000-m gauge (2008)
Roadways: total: 153,497 km
country comparison to the world: 32
paved: 2,794 km
unpaved: 150,703 km (2004)
Waterways: 15,000 km (including the Congo, its
tributaries, and unconnected lakes) (2011)
country comparison to the world: 8
Merchant marine: total: 1
country comparison to the world: 148
by type: petroleum tanker 1
foreign-owned: 1 (Republic of the Congo 1)
(2010)
Ports and terminals: Banana, Boma, Bukavu,
Bumba, Goma, Kalemie, Kindu, Kinshasa, Kisan-
gani, Matadi, Mbandaka a
Airports: 88 (2012)
country comparison to the world: 65
Airports—with paved runways: total: 8
over 3,047 m; 1
2,438 to 3,047 m: 3
1,524 to 2,437 m: 3
914 to 1,523 m: 1 (2012)
Airports—with unpaved runways: total: 80
2,438 to 3,047 m: 1
1524 to 2,437 m: 5
914 to 1,523 m: 53
under 914 m: 21 (2012)
Pipelines: oil 771 km (2010)
Railways: total: 2,157 km
country comparison to the world: 69
narrow gauge: 2,157 km 1.067-m gauge
note: includes 891 km of the Tanzania-Zambia
Railway Authority (TAZARA) (2008)
Roadways: total:91,440 km
country comparison to the world: 50','8955ef8773cf3e5b74eaa2a6562885671f2e34c9447721c5a33bb2161e816242','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7d58b2620437157156639346be55828363e46ccd43c95946735055606a1758a8',2025,'CK','Cook Islands','transportation',445,'Airports: 11 (2012)
country comparison to the world: 154
Airports—with paved runways: total: |
1,524 to 2,437 m: 1 (2012)
Airports—with unpaved runways: total: 10
1,524 to 2,437 m:2
914 to 1,523 m: 7
under 914 m: 1 (2012)
Roadways: total: 320 km
country comparison to the world: 204
paved: 33 km
unpaved: 287 km (2003)
Merchant marine: total: 35
country comparison to the world: 81
by type: bulk carrier 2, cargo 25, passenger 1, refrig-
erated cargo 6, roll on/roll off 1
foreign-owned: 23 (Estonia 1, Germany 1, Lithu-
ania 1, Norway 8, NZ 2, Russia 1, Sweden 3, Tur-
key 4, UK 2) (2010)
Ports and terminals: Avatiu','5699b93090e13c123a44ba5a4dda09ff52a4906b7417979dba709c0f54191fe4','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('567cc1010486f2ff1a2d32f5dce4c84635bb78c01a9e637fb7126461a73c802d',2025,'MX','Mexico','transportation',461,'Airports: 27 (2012)
country comparison to the world: 123
Airports—with paved runways: total: 7
over 3,047 m: |
2,438 t0.3,047 m: 2
1,524 to 2,437 m: 4 (2012)
Alrports—with unpaved runways: total: 20
1,524 to 2,437 m: 6
914 to 1,523 m: 11
under 914 m: 3 (2012)
Heliports: 1 (2012)
Pipelines: condensate 86 km; gas 180 km; oil 92
km (2010)
Railways: total: 660 km
country comparison to the world: 104
narrow gauge: 660 km 1.000-m gauge
note: an additional 622 km of this railroad extends
into Burkina Faso (2008)
Roadways: total: 80,000 km
country comparison to the world: 58
paved: 6,500 km
unpaved: 73,500 km
note: includes intercity and urban roads; another
20,000 km of dirt roads are in poor condition and
150,000 km of dist roads are impassable (2006)
Waterways: 980 km (navigable rivers, canals, and
numerous coastal lagoons) (2011)
181
country comparison to the world: 67
Ports and terminals: Abidjan, Espoir, San-Pedro
Airports: 1,724 (2012)
country comparison to the world: 3
Airports—with paved runways: total: 249 over
3,047 m: 12
2.438 to 3,047 m: 30
1524 to 2,437 m: 82
914 to 1,523 m: 88
under 914 m: 37 (2012)
Airports—with unpaved runways: total: 1,475
over 3,047 m: 1
2,438 to 3,047 m: 2
1524 to 2,437 m: 44
914 to 1,523 m: 288
under 914 m: 1,140 (2012)
Heliports: 1 (2012)
Pipelines: gas 16,594 km; liquid petroleum gas
2,152 km; oil 7,499 km; oil/gas/water 4 km; refined
products 7,264 km; water 33 km(2010)
Railways: total: 17,166 km
country comparison to the world: 16
standard gauge: 17,166 km1.435-mgauge (22 km
electrified) (2008)
Roadways: total: 366,095 km
country comparison to the world: 17
paved: 132,289 km(includes .6,279 km of
expressways)
unpaved; 233,806 km(2008)
Waterways: 2,900 km (navigable rivers and
coastal canals mostly connected with ports on the
country’s east’ coast) (2012)
country comparison to the world: 34
Merchant marine: total: 52
country comparison to the world: 70
by type: bulk carrier 5, cargo 3, chemical tanker
11, liquefied gas 3, passenger/cargo 10, petroleum
tanker 17, roll on/roll off 3
foreign-owned: 5 (France 1, Greece 2, South
Africa 1, UAE 1)
registered in other countries; 12 (Antigua and
Barbuda 1, Marshall Islands 2, Panama 5, Portugal
1, Spain 1, Venezuela 1, unknown 1) (2010)
Ports and terminals: Altamira, Coatzacoalcos,
Lazaro Cardenas, Manzanillo, Salina Cruz, Verac-
ruz oil terminals: Cayo Arcas terminal, Dos Bocas
terminal
Airports: 6 (2012)
country comparison to the world: 171
Airports—with paved runways: total: 6
1524 to 2,437 m: 4
914 to 1,523 m: 2 (2012)
Roadways: total: 240 km
country comparison to the world: 207
paved: 42 km
unpaved: 198 km (2000)
Merchant marine: total:3
country comparison to the world: 139
by type: cargo 1, passenger/cargo 2 (2010)
Ports and terminals: Colonia (Tomil Harbor),
Lele Harbor, Pohnepi Harbor','47d7dc55a206fa68e7492793722248438bf2d568bc094874bf784839c9c44eff','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3ad17a194443aa6ef38d6c91ce6910f6a17524a8811927f1682a5e036384df55',2025,'HR','Croatia','transportation',472,'Airports: 69 (2012)
country comparison to the world: 75
Airports—with paved runways: total: 24
over 3,047 m:2
2,438 to 3,047 m: 6
1,524 to 2,437 m:3
914 to 1,523 m:3
under 914 m: 10 (2012)
Airports—with unpaved runways: total: 45
1,524 to 2,437 m: 1
914 to 1,523 m: 6
under 914 m: 38 (2012)
Heliports: 1 (2012)
Pipelines: gas 1,686 km; oil 532 km (2010)
Railways: total:-2,722 km
country comparison to the world: 60
standard gauge: 2,722 km 1.435-m gauge (984 km
electrified) (2009)
Roadways: total: 29,343 km (includes 1,047 km
of expressways) (2008)
country comparison to the world: 98
Waterways: 785 km (2009)
country comparison to the world: 74
Merchant marine: total: 77
country comparison to the world: 57
by type: bulk carrier 24, cargo 7, chemical tanker 8,
passenger/cargo 27, petroleum tanker 10, refriger-
ated cargo |
foreign-owned: 2 (Norw ay 2)
registered in other countries: 31 (Bahamas 1,
Belize 1, Liberia 1, Malta 6, Marshall Islands 12,
Panama 2, Saint Vincent and the Grenadines 8)
(2010)
Ports and terminals: Omisalj, Ploce, Rijeka,
Sibernik, Split, Vukovar (on Danube River)','6457233091aec0da5d8748d135c1a56c54c8de5d36d73bd00edaebbc3f606309','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e196022b939261e088feebf7dfdea9435963162d757722fb8a7e43efdd90a350',2025,'CU','Cuba','transportation',481,'Airports: 136 (2012)
country comparison to the world: 42
Airports—with paved runways: total: 65
over 3,047 m:7
2,438 to 3,047 m:9
1,524 to 2,437 m: 18
914 to 1,523 m: 4
under 914 m: 27 (2012)
Airporis—with unpaved runways: total: 71
914 to 1,523 m: 12
under 914 m: 59 (2012)"
Pipelines: gas 41 km; oil 230 km (2010)
Railways: total: 8,193 km
country comparison to the world: 25
standard gauge: 8,079 km 1.435-m gauge (124 km
electrified)
narrow gauge: 114 km 1.000-m gauge
note: 3,129 km of the track is used by sugar planta-
tions; 3,015 km is standard gauge; 114 km is nar-
tow gauge (2010)
Roadways: total: 60,858 km `
country comparison to the word: 72
paved: 29,820 km (includes 638 km of expressways)
unpaved: 31,038 km (2000)
Waterways: 240 km (almost all navigable inland
waterways are near the mouths of rivers) (2011)
country comparison to the world: 95
Merchant marine: total: 3
country comparison to the world: 135
by type: cargo 1, passenger 1, refrigerated cargo 1
registered in other countries: 5 (Curacao 1, Pan-
ama 2, unknown 2) (2010)
Ports and terminals: Antilla, Cienfuegos, Guan-
tanamo, Havana, Matanzas, Mariel, Nuevitas Bay,
Santiago de Cuba, Tanamo
Military branches: Revolutionary Armed Forces
(Fuerzas Armadas Revolucionarias, FAR): Revo-
lutionary Army (Ejercito Revolucionario, ER,
includes Territorial Militia Troops (Milicia de
Tropas de Territoriales, MTT)); Revolutionary
Navy (Marina de Guerra Revolucionaria, MGR,
includes Marine Corps); Revolutionary Air and
Air Defense Forces (Defensas Anti-Aereas y
Fuerza Aerea Revolucionaria, DAAFAR), Youth
Labor Army (Ejercito Juvenil del Trabajo, EJT)
(2011)
Military service age and obligation: 17-28
years of age for compulsory military service; 2-year
service obligation; both sexes subject to military
service (2012)
Manpower available for military service:
males age 16-49: 2,998,201
females age 16-49: 2,919,107 (2010 est.)
Manpower fit for military service: males age
16-49: 2,446,131
females age 16-49: 2,375,590 (2010 est.)
Manpower reaching militarily significant age
annually: male: 72,823
female: 69,108 (2010 est.)
Military expenditures: 3.2% of GDP (2011)
country comparison to the world: 37
Military—note: the collapse of the Soviet Union
deprived the Cuban military of its major eco-
nomic and logistic support and had a significant
impact on the state of Cuban equipment; the
army remains well trained and professional in
nature; while the lack of replacement parts for
its existing equipment has increasingly affected
operational capabilities, Cuba remains able to
offer considerable resistance to any regional
power (2010)','e2f18f9c78d60ca3c272fb667207f8694c28194ffd5f75a5d49d917c8d8b3e6a','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b6ecc94fed89828e62e7c4957ca1bb15afcfeca700b80b931cd08760d7c0400a',2025,'CY','Cyprus','transportation',484,'Airports: 15 (2012)
country comparison to the world: 145
Airports—with paved runways: total: 13
2,438 to 3,047 m:6
1,524 to 2,437 m:3
914 to 1,523 m: 3
under 914 m: 1 (2012)
Airports—with unpaved runways: total: 2
under 914 m: 2 (2012)
Heliports: 9 (2012)
Roadways: total: 14,671 km
193
country comparison to the world: 122
12,321 km under government control (includes
257 km of expressways),
2,350 km administered by Turkish Cypriots
(2008)
Merchant marine: total: 838
country comparison to the world: 13
by type: bulk carrier 278, cargo: 163, chemical
tanker 77, container 201, liquefied gas 11, pas-
senger 3, passenger/cargo 25, petroleum tanker
62, refrigerated cargo 5, roll on/roll off 9, vehicle
carrier 4
foreign-owned: 622 (Angola 1, Austria 1, Bel-
gium 3, Bermuda 1, Canada 2, China 6, Denmark
6, Estonia 6, France 16, Germany 192, Greece 201,
Hong Kong 2, India 4, Iran 10, Ireland 3, Italy 6,
Japan 16, Netherlands 23, Norway 14, Philippines
1, Poland 24, Portugal 2, Russia 46, Singaporel,
Slovenia 5, Spain 6, Sw eden 5, Turkey 1, UAE 3,
UK 7, Ukraine 3, US 5)
registered in other countries: 152 (Bahamas 23,
Cambodia 4, Comoros 2, Finland 1, Gibraltarl,
Greece 3, Hong Kong 3, Liberia 9, Malta 32, Mar-
shall Islands 40, Norway 1, Panama 5, Russia 13,
Saint Vincent and the Grenadines 3, Sierra Leone
2, Singapore 6, unknown 4) (2010)
Ports and terminals: area under government
control: Larnaca, Limassol, Vasilikos; area admin-
istered by Turkish Cypriots: Famagusta, Kyrenia
THE CIA WORLD FACTBOOK','d41d69638778a9703114c8ca1d7714139227020a2abaabaecbba0acf8029ec67','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3bc7b155e690e06f75e00b067a944e26c9bc2a84dfcd9777af9c9b7911342458',2025,'DK','Denmark','transportation',499,'Airports: 89 (2012)
country comparison to the world: 64
Airports—with paved runways: total: 28 over
3,047 m: 2
2,438 to 3,047 m:7
1,524 to 2,437 m: 4
914 to 1,523 m: 12
under 914 m: 3 (2012)
Airports—with unpaved runways: total: 61
914 to 1,523 m: 2
under 914 m: 59 (2012)
Pipelines: gas 2,858 km; oil 107 km (2010)
Railways: total: 2,667 km
country comparison to the world: 61
standard gauge: 2,667 km 1.435-m gauge (640 km
electrified) (2008)
Roadways: total: 73,197 km
country comparison to the world: 62
paved: 73,197 km (includes 1,111 km of express-
ways) (2008)
Waterways: 400 km (2010)
country comparison to the world: 88
Merchant marine: total: 367
country comparison to the world: 27
by type: bulk carrier 4, cargo 48, carrier 1, chemi-
cal tanker 125, container 94, liquefied gas 4, pas-
senger 1, passenger/cargo 40, petroleum tanker 36,
refrigerated cargo 3, roll on/roll off 8, specialized
tanker 3
foreign—owned: 27 (Germany 9, Greenland 1,
Norway 2, Sweden 15)
registered in other countries: 582 (Antigua and
Barbuda 20, Bahamas 69, Belgium 4, Brazil 3, Cura-
cao 1, Cyprus 6, Egypt 1, France 11, Gibraltar 7,
Hong Kong 42, Isle of Man 30, Italy 4, Jamaica 1,
Liberia 8, Lithuania 8, Luxembourg 1, Malaysia 1,
Malta 34, Marshall Islands 7, Moldova Netherlands
27, Norway 7, Panama 41, Philippines 2, Portugal
4, Saint Vincent and the Grenadines 9, Singapore
149, Sweden 4, UK 43, Uruguay 1, US 31, Ven-
ezuela 1, unknown 4) (2010)
Ports and terminals: Aalborg, Aarhus, Copenha-
gen, Ensted, Esbjerg, Fredericia, Kalundborg','ad7d7671a27f4275bfd61b973d5ab8aedc60f9f4343996035f8e5fd34d15e3b2','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6a12c2f16175f8715c476c8f5095a3eb04b0fc850861dfe30d9a4c617ee162e2',2025,'DJ','Djibouti','transportation',513,'Airports: 13 (2012)
country comparison to the world: 153
THE CIA WORLD FACTBOOK
Airports—with paved runways: total: 3
over 3,047 m: 1
2,438 to 3,047 m: 1
1,524 to 2,437 m: 1 (2012)
Airports—with unpaved runways: total: 10
1,524 to 2,437 m: 1
914 to 1,523 m: 7
under 914 m: 2 (2012)
Railways: total: 100 km (Djibouti segment of the
781 km Addis Ababa-Djibouti railway)
country comparison to the world: 126
narrow gauge: 100 km 1.000-m gauge
note; railway is under joint control of Djibouti and
Ethiopia but is largely inoperable (2008)
Roadways: total: 3,065 km country
comparison to the world: 165
paved: 1,226 km
unpaved: 1,839 km (2000)
Ports and terminals: Djibouti
Transportation—note: while attacks decreased
significantly in 2012, the International Maritime
Bureau reports offshore waters in the Gulf of Aden
remain a high risk for piracy; the presence of sev-
eral naval task forces’ in the Gulf of “Aden and
additional anti-piracy measures on the part of ship
operators, including the use of on-board armed
security teams, contributed to the drop in incidents','70d97eb0db607cc7d42e0c51d8a4cd92392d35bc8c436f79031667dfbe7f0531','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e7cbaab20c326cc97273f953d5c31ae7670a14ee8803bb2a811015fdc7015959',2025,'DM','Dominica','transportation',523,'Airports: 2 (2012)
country comparison to the world: 199
Airports—with paved runways: total: 2
1524 to 2,437 m: 1
914 to 1,523 m: 1 (2012)
Roadways: total: 780 km
country comparison to the world: 188
paved: 393 km
unpaved: 387 km (2000)
Merchant marine: total: 43
country comparison to the world: 73
by type: bulk carrier 11, cargo 22, chemical tanker
2, pétroleum tanker 4, refrigerated cargo 3, roll on/
roll off 1
foreign-owned: 32 (Australia 1, Estonia 6, Ger-
many 5, Greece 4, India 2, Latvia 2, Norway
1, Russia 3, Saudi Arabia 2, Syria 4, Turkey 1,
Ukraine 1)
registered in other countries: 1 (Saint Vincent
and the Grenadines 1) (2010)
Ports and terminals: Portsmouth, Roseau','bc0da576a1e297089441d9855f2b84cd547d0c4f9cd3c30551a663ed4374209b','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6c93322909c8dfad6567cb691affda130f8e32c4b04d247fab8798723ddc0131',2025,'DO','Dominican Republic','transportation',532,'Airports: 36 (2012)
country comparison to the world: 110
Airports—with paved runways: total: 16
?
over 3,047 m: 3
2,438 to 3,047 m: 4 ‘
1,524 to 2,437 m:4
914 to 1,523 m: 4
under 914 m: 1 (2012)
Airports—with unpaved runways: coral: 20
1,524 to 2,437 m: 1
914 to 1,523 m: 1
under 914 m: 18 (2012)
Heliports: 1 (2012)
Pipelines: oil 99 km
Railways: total: 142 km
country comparison to the world: 125
standard gauge: 142 km 1.435-m gauge (2008)
Roadways: total: 19,705 km
country comparison to the world: 108
paved: 9,872 km
unpaved: 9,833 km (2002)
Ports and terminals: Puerto Haina, Puerto Plata,
Santo Domingo
oil terminals: Andres LNG terminal
Chica), Punta Nizao oil terminal','7de0638bfd44ac9694ad0c03fcc8d3e493d3e61d97684bd96cd7606099fc9ee5','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('acab676a97f9b764b6209b97b55f95cfc5c2114460109b6e742e6a85ff5accb7',2025,'EC','Ecuador','transportation',537,'Airports: 431 (2012)
country comparison to the world: 20
Airports—with paved runways: total: 101
over 3,047 m:3
2,438 to 3,047 m: 5
1,524 to 2,437 m: 18
914 to 1,523 m: 23
under 914 m: 52 (2012)
Airports—with unpaved runways: total: 330
‘914 to 1,523 m: 40
under 914 m: 290 (2012)
Heliports: 2 (2012)
Pipelines: extra heavy crude 434 km; gas 5 km; oil
1,378 km; refined products 1,262 km (2010)
Railways: total: 965 km
country comparison to the world: 90
narrow gauge: 965 km 1.067-m gauge (2008)
Roadways: total: 43,670 km
country comparison to the world: 84
paved: 6,472 km
unpaved: 37,198 km (2006)
Waterways: 1,500 km (most inaccessible) (2012)
country comparison to the world: 53
Merchant marine: total: 44
country comparison to the world: 72
by type: cargo 1, chemical tanker 4, liquefied gas 1,
passenger 9, petroleum tanker 28, refrigerated cargo 1
registered in other countries: 4 (Panama 3,
Peru 1) (2010)
Ports and terminals: Esmeraldas, Guayaquil,
Manta, Puerto Bolivar','4feca3a6098a99228c2017d3161e0f0b5ac5dca6dd79f6b950c358516a59bbc3','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4696ec2ea3d3beb422037d06be07dbc54b26c0e4f083d72f0f6ccc8e89156507',2025,'EG','Egypt','transportation',548,'Airports: 84 (2012)
country comparison to the world: 66
Airports—with paved runways: total: 72
over 3,047 m: 15
2.438t0 3,047 m: 36
1.524to 2,437 m: 15
under 914 m:6 (2012)
Alrports—with unpaved runways: total; 12
2,437 to 3,047 m:1
1,523 to 2,437 m: 3
914 to 1523 m: 5
under 914 m: 3 (2012)
Heliports: 6 (2012)
Pipelines: condensate 320 km; condensate/gas
13 km; gas 6,628 km; liquid petroleum gas 956 km;
oil 4,332 km; oil/gas/water 3 km; refined products
895 km; water 13 km(2010)
Railways: total: 5,083 km country
comparison to the world: 34
standard gauge: 5,083 kmi.435-mgauge (62 km
electrified) (2009)
Roodways: total: 65,050 km country
comparison to the world: 69
paved: 47,500 km
unpaved: 17,550 km (2009)
Waterways: 3,500 km(includes the Nile River,
Lake Nasser, Alexandria-Cairo Waterway, and
numerous smaller canals in Nile Delta; the Suez
Canal (193.5 km including approaches) is naviga-
ble by oceangoing vessels drawing up to 17.68 m)
(2011)
country comparison to the world: 30
Merchant marine: total: 67
country comparison to the world: 62
by type: bulk carrier 16, cargo 20, container 3,
passenger/cargo 7, petroleum tanker 12, roll on/
roll off 9
foreign-owned: 13 (Denmark 1, France 1, Greece
8, Jordan 2, Lebanon 1)
registered in other countries: 42 (Cambodia 4,
Georgia 7, Honduras 2, Liberia 3, Malta 1, Mar-
shall Islands 1, Moldova 5, Panama 11, Saint Kitts
and Nevis 1, Saint Vincent and the Grenadines
2, Saudi Arabia 1, Sierra Leone 3, unknown 1)
(2010)
Ports and terminals: Ayn Sukhnah, Alexandria,
Damietta, El Dekheila, Port Said, Sidi Kurayr, Suez','981a6b0661e82868988f491df5ef2a9341b544f004ce95b4cf2613b99e1d5992','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('758c09140b45c30ca435dcf8e159b3c051e98e2e1f371b28ba22977c23c9f545',2025,'SV','El Salvador','transportation',560,'Airports: 65 (2012)
country comparison to the world: 78
Airports—with paved runways: total: 5
over 3,047 m: 1
1,523 to 2,437 m: 1
914 to 1,523 m: 2
under 914 m: 1 (2012)
Airports—with unpaved runways: total: 60
1,523 to 2,437 m: 1
914 to 1,523 m: 11
under 914 m: 48 (2012)
Heliports: 2 (2012)
Railways: total: 283 km
country comparison to the world: 121
narrow gauge: 283 km 0.600-m gauge
note: railways have been inoperable since 2005
because of disuse and high costs that led to a lack
of maintenance (2008)
Roadways: total: 10,886 km
country comparison to the world: 134
paved: 2,827 km (includes 327 km of expressways)
unpaved: 8,059 km (2000)
Waterways: (Rio Lempa is partially navigable for
small craft) (2011)
Ports and terminals: Puerto Cutuco
oil terminals: Acajutla offshore terminal','85b432ace4e56a7c844e23040eed77bdbffcf4b93215c8a71d4357ec73c11aef','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('75217a6d5c6ac052209928d11964a95c1d2c80e11c115f1e8b8374856d1d1b97',2025,'GQ','Equatorial Guinea','transportation',566,'Airports: 7 (2012)
country comparison to the world: 166
Airports—with paved runways: total: 6
2,437 to 3,047 m: 2
1,524 to 2,437 m: 2
under 914 m: 2 (2012)
Airports—with unpaved runways: total: |
2,437 to 3,047 m: 1 (2012)
Pipelines: gas 37 km (2010)
Roadways: total: 2,880 km (2000)
country comparison to the world: 168
Merchant marine: total: 5
country comparison to the world: 124
by type: cargo 1, chemical tanker 1, petroleum
tanker 3
foreign-owned: 1 (Norway 1) (2010)
Ports and terminals: Bata, Luba, Malabo (2010)','d3d0d0fc1e4584baf3d823f8d08509e87b3e97ebfa099af6794fbfeb6efacd6a','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('eb72787caad99aa8a50b1a7061f112cce4522f395ef890fb23d8b1a479cb29be',2025,'ET','Ethiopia','transportation',574,'Airports: 13 (2012)
country comparison to the world: 152
Airports—with paved runways: total: 4
over 3,047 m: 2
2,438 to 3,047 m: 2 (2012)
Airports—with unpaved runways: total: 9
over 3,047 m: 1
2,438 to 3,047 m: 1
1,524 to 2,437 m: 5
914 to 1,523 m: 2 (2012)
Heliports: 1 (2012)
Railways: total: 306 km
country comparison to the world: 119
narrow gauge: 306 km 0.950-m gauge (2008)
Roadways: total: 4,010 km
country comparison to the world: 158
paved: 874 km
unpaved: 3,136 km (2000)
Merchant marine: total: 4
country comparison to the world: 129
by type: cargo 2, petroleum tanker 1, roll on/roll
off 1 (2010)
Ports and terminals: Assab, Massawa
Airports: 58 (2012)
country comparison to the world: 82
Airports—with paved runways: total: 17
over 3,047 m:3
2,438 to 3,047 m: 8
1,524 to 2,437 m: 4
under 914 m: 2 (2012)
Airports—with unpaved runways: total: 41
2,438 to 3,047 m:3
1,524 to 2,437 m:9
914 to 1,523 m: 22
under 914 m: 7 (2012)
Railways: total: 681 km (Ethiopian segment of
the 781 km Addis Ababa-Djibouti railroad)
country comparison to the world: 102
narrow gauge: 681 km 1.000-m gauge
note: railway is under joint control of Djibouti and
Ethiopia but is largely inoperable (2008)
Roadways: total: 36,469 km
country comparison to the world: 93
paved: 6,980 km
unpaved: 29,489 km (2004)
Merchant marine: total: 8
country comparison to the world: 121
by type: cargo 8 (2010)
Ports and terminals: Ethiopia is landlocked and
uses ports of Djibouti in Djibouti and Berbera in
Airports: 3,294 (2012)
Airports—with paved runways: total: 1,933
over 3,047 m: 117
2,438 to 3,047 m: 332
1,524 to 2,437 m: 513
914 to 1,523 m: 417
under 914 m: 554 (2012)
Airports—with unpaved runways: total: 1,361
over 3,047 m: 1
1,524 to 2,437 m: 14
914 to 1,523 m: 249
under 914 m: 1,097 (2012)
Heliports: 91 (2012)
Railways: total: 228,710 km (2010)
Roadways: total: 5,814,080 km (2010)
Waterways: 44,103 km (2010)
Ports and terminals: Antwerp (Belgium),
Barcelona (Spain), Braila (Romania), Bremen
(Germany), Burgas ~ (Bulgaria), Constanta
(Romania), Copenhagen (Denmark), Galati
(Romania), Gdansk (Poland), Hamburg (Ger-
many), Helsinki (Finland), Las Palmas (Canary
Islands, Spain), Le Havre (France), Lisbon (Por-
tugal), London (UK), Marseille (France), Naples
(Italy), Peiraiefs or Piraeus (Greece), Riga
(Latvia), Rotterdam (Netherlands), Stockholm
(Sweden), Talinn (Estonia), Tulcea (Romania),
Varna (Bulgaria)
Airports: 7 (2012)
country comparison to the world: 170
Airports—with paved runways: total: 2
2,438 to 3,047 m: 1
1914 to 1,523 m: 1 (2012)
Airports—with unpaved runways: total:5
under 914 m: 5 (2012)
Roadways: total: 440 km
country comparison to the world: 198
paved: 50 km
unpaved: 390 km (2008)
Ports and terminals: Stanley
Airports: (2012)
country comparison to the world: 206
Airports—with paved runways: coral: 2
1,524 to 2,437 m: 1
914 to 1,523 m: 1 (2012)
Roadways: total: 320 km
country comparison to the world: 202','4ef3d4ff93681bb645d0c8706c4be99bfd28c4f52babceba3ebf2601433f0508','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ab6a0d6c33311b1b4fe75105700697a2c189eb40a4b4dbbc8de8c2544d930558',2025,'ER','Eritrea','transportation',575,'Military branches: Eritrean Armed Forces: Eri-
trean Ground Forces, Eritrean Navy, Eritrean Air
Force (includes Air Defense Force) (2011)
Military service age and obligation: 18-40 years
of age for male and female voluntary and compul-
sory military service; 16-month conscript service
obligation (2012)
Manpower available for military service:
males age 16-49: 1,350,446
females age 16-49: 1,362,575 (2010 est.)
Manpower fit for military service: males age
16-49: 896,096
females age 16-49: 953,757 (2010 est.)
Manpower reaching militarily significant age
annually: male: 66,829
female: 66,731 (2010 est.)
Military expenditures: 6.3% of GDP (2006
est.)
country comparison to the world: 10','4c1e1845ffdf4a7eb255c857d013505ae184aa3c041e5070fd62c9a0d6436eee','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f27cdf28f93da99ed2adf5ed82f0e56a10fe85d5fe2f8b280fb07aa9aad6c9eb',2025,'EE','Estonia','transportation',584,'Alrports: 18 (2012)
country comparison to the world: 140
Airports—with paved runways: total: 13
over 3,047 m: 2
2,438 to 3,047 m:8
1,523 to 2,437 m: 2
914 to 1,523 m: 1 (2012)
Airports—with unpaved runways: total: 5
1,524 to 2,437 m:1
914 to 1,523 m: 1
under 914 m: 3 (2012)
Heliports: 1 (2012)
Pipelines: gas 859 km (2010)
Railways: total: 1,200 km
country comparison to the world: 85
broad gauge: 1,200 km 1.520-m and 1.524-m
gauge (133 km electrified) (2008)
Roadways: total: 58,034 km (includes 41,912 km
urban roads)
country comparison to the world; 75
paved: 34,936 km (includes 104 km of expressways)
unpaved: 23,098 km (2009)
Waterways: 335 km (320 km are navigable year
round) (2011)
country comparison to the world: 91
Merchant marine: total: 25
country comparison to the world: 89
by type: cargo 4, chemical tanker 1, passenger/
cargo 18, petroleum tanker 2
foreign-owned: 3 (Germany 1, Norway 2)
registered in other countries: 63 (Antigua and
Barbuda 10, Belize 1, Cambodia 1, Canada 1,
Cook Islands 1, Cyprus 6, Dominica 6, Finland 2,
Latvia 3, Malta 16, Russia 1, Saint Vincent and
the Grenadines 8, Sierra Leone 2, Sweden 3, Ven-
ezuela 1, unknown 1) (2010)
Ports and terminals: Kuivastu, Kunda, Muuga,
Parnu Reid, Sillamae, Tallinn','9882889b43b4552c37bec93ee243d7fdfccca770cede2de471688d0b97d0cf06','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('efe2910ae0a69a19621862ba7b327a46891c9d37029fb1e99e24c23533b1bf62',2025,'FO','Faroe Islands','transportation',601,'Airports: 1 (2012) x
country comparison to the world: 215
Airports—with paved runways: total: 1
1,524 to 2,437 m: 1 (2012)
Roadways: total: 463 km (2006)
country comparison to the world: 196
Merchant marine: total: 37
country comparison to the world: 79
by type: cargo 20, chemical tanker 7, container
2, passenger/cargo 3, refrigerated cargo 3, roll on/
roll off 2
foreign-owned: 28 (Iceland 4, Norway 13, Swe-
den 11) (2010)
Ports and terminals: Fuglafjordur, Torshavn,
Vagur
Military branches: no regular military forces
(2012)
Manpower available for military service: males
age 16-49: 11,831 (2010 est.)
Manpower fit for military service:
males age 16-49; 9,827
females age 16-49: 8,418 (2010 est.)
Manpower reaching militarily significant age
annually: male: 372
female: 373 (2010 est.)
Military expenditures: NA
Military—note: defense is the responsibility of','bb7cca5a211bca533d3dbb417c1707f2b83da398e616cbf0acad88f991f1b214','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3402d960dd0feab3f14a22f5d49f627a4cbf2d482dd618b091c146b764ae2cd9',2025,'FJ','Fiji','transportation',608,'Airports: 28 (2012)
country comparison to the world: 120
Airports—with paved runways: coral: 4
over 3,047 m: 1
1,524 to 2,437 m: 1
914 to 1,523 m: 2 (2012)
Airports—with unpaved runways: total: 24
914 to 1,523 m:5
under 914 m: 19 (2012)
Railways: total:597 km
country comparison to the world: 108
narrow gauge: 597 km 0.600-m gauge
note: belongs to the government-owned Fiji Sugar
Corporation; used to haul sugarcane during the
harvest season, which runs from May to December
(2008)
Roadways: total: 3,440 km
country comparison to the world: 162
paved: 1,692 km
unpaved: 1,748 km (2000)
Waterways: 203 km (122 km are navigable by
motorized craft and 200-metric-ton barges) (2012)
country comparison to the world: 98
Merchant marine: total: 11
country comparison to the world: 108
by type: passenger 4, passenger/cargo 4, refrigerated
cargo 1, roll on/roll off 2
foreign-owned; 2 (Australia 2) (2010)
Ports and terminals: Lautoka, Levuka, Suva','07515b4de376c00dadd0f2c98c0f07946e04c084f0d944437abdadc4cf858fa0','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('513e768c3fed2aee0a061cb00f571c65319ba71d49ca73e39bca28868bd812db',2025,'FI','Finland','transportation',615,'Airports: 148 (2012)
country comparison to the world: 38
Airports—with paved runways: toral: 75
over 3,047 m:
32,438 to 3,047 m: 2
61,524 to 2,437 m: 10
914 to 1,523 m: 21
under 914 m: 15 (2012)
Airports—with unpaved runways: total: 73
914 to 1,523 m: 3 T
under 914 m: 70 (2012)
Pipelines: gas 694 km (2010)
Railways: total: 5,919 km
country comparison to the world: 31
broad gauge: 5,919 km 1.524-m gauge (3,067 km
electrified) (2008)
Roadways: total: 78,141 km
country comparison to the world: 59
paved: 50,914 km (includes 739 km of expressways)
unpaved: 27,227 km (2009)
Waterways: 7,842 km (includes Saimaa Canal
system of 3,577 km; southern part leased from Rus-
sia; water transport is used frequently in the sum-
mer and is widely replaced with sledges on the ice
in winter; there are 187,888 lakes in Finland that
cover 31,500 km) (2011)
country comparison to the world: 18
Merchant marine: total:97
country comparison to the world: 51
by type: bulk carrier 2, cargo 25, carrier 1, chemical
tanker 6, container 3, passenger 5, passenger/cargo
16, petroleum tanker 5, roll on/roll off 31, vehicle
carrier 3 foreign-owned: 5 (Cyprus 1, Estonia 2,
Iceland 1, Sweden 1)
registered in other countries: 47 (Bahamas 8,
Germany 3, Gibraltar 2, Malta 3, Netherlands 13,
Panama 2, Sweden 16) (2010)
Ports and terminals: Helsinki, Kotka, Naantali,
Porvoo, Raahe, Rauma','55652756526ed81a92da890a39a0d4ecbdf12808fa6e8337efdb8c1df3ef9b43','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5af7a88d936a216d2b6b7df536855836c469fbbafba22fa23644b3f2d9d8e6c9',2025,'FR','France','transportation',624,'Airports: 473 (2012)
country comparison to the world: 17
Airports—with paved runways: total:297
over 3,047 m: 14
2,438 to 3,047 m: 26
1,524 to 2,437 m: 98
914 to 1,523 m: 83
under 914 m: 76 (2012)
Airports—with unpaved runways: total: 176
914 to 1,523 m: 67
under 914 m: 109 (2012)
Heliports: (2012)
Pipelines: gas 15,276 km; oil 2,939 km; refined
products 5,084 km (2010)
Railways: total: 29,640 km
country comparison to the world: 9
standard gauge: 29,473 km 1.435-m gauge
(15,361 km electrified)
narrow gauge: 167 km 1.000-m gauge (63 km
electrified) (2008)
Roadways: total: 951,200 km (metropolitan
France; includes 11,100 km of expressways)
country comparison to the world: 8
note: there are another 5,100 km of roadways in
overseas departments (2007)
Waterways: metropolitan France: 8,501 km (1,621
km accessible to craft of 3,000 metric tons) (2010)
country comparison to the world: 16
Merchant marine: total: 162
country comparison to the world; 36 by type:
bulk carrier 3, cargo 7, chemical tanker 34, con-
tainer 27, liquefied gas 12, passenger 10, passenger/
cargo 41, petroleum tanker 16, refrigerated cargo
1, roll on/roll off 11 foreign-owned: 50 (Belgium
7, Bermuda 5, Denmark 11, French Polynesia 11,
Germany 1, New Caledonia 3, Singapore 3, Swe-
den 4, Switzerland 5)
registered in other countries: 151 (Bahamas 15,
Belgium 7, Bermuda 1, Canada 1, Cyprus 16, Egypt
t, Hong Kong 4, Indonesia 1, Ireland 2, Italy 2,
Luxembourg 15, Malta 8, Marshall Islands 7,
Mexico 1, Morocco 3, Netherlands 2, Norway 5,
Panama 7, Saint Vincent and the Grenadines 2,
Singapore 3, South Korea 2, Taiwan 2, UK 39, US
4, unknown 1) (2010)
Ports and terminals: Calais, Dunkerque, Le
Havre, Marseille, Nantes, Paris, Rouen
Airports: 4; note—one each on Europa Island,
Glorioso Islands, Juan de Nova Island, and Trome-
lin Island in the Iles Eparses district (2010)
country comparison to the world: 187
Ports and terminals: none; offshore anchorage only
Airports: 1 (2012)
country comparison to the world: 234
Airports—with paved runways: total: 1
under 914 m: 1 (2012)
Ports and terminals: Gustavia
Transportation—note: nearest airport for inter-
national flights is Princess Juliana International
Airport (SXM) located on Sint Maarten
Airports: 1 (Ascension Island) (2012)
country comparison to the world: 232
Airports—with paved runways: total: 1
over 3,047 m: 1 (2012)
Roadways: total: 198 km (Saint Helena 138 km,
Ascension 40 km, Tristan da Cunha 20 km)
country comparison to the world: 209
paved: 168 km (Saint Helena 118 km, Ascension
40 km, Tristan da Cunha 10 km)
unpaved: 30 km (Saint Helena 20 km, Tristan da
Cunha 10 km) (2002)
Ports and terminals: Saint Helena: Jamestown
Ascension Island: Georgetown
Tristan da Cunha: Calshot Harbor (Edinburgh)
Transportation—note: there is no air connection
to Saint Helena or Tristan da Cunha; construction
on the new international airport for Saint Helena
began in 2012 with an estimated completion date
of late 2015 or early 2016; the new airport will
have a runway of 1,550 m capable of handling
B737/A319 size aircraft
Manpower fit for military service: males age
16-49: 1,565
females age 16-49: 1,579 (2010 est.)
Manpower reaching militarily significant age
annually: male: 49
female: 48 (2010 est.)
Military—note: defense is the responsibility of
the UK
Airports: 1 (2012)
country comparison to the world: 231
Airports—with paved runways: total: |
914 to 1,523 m: 1 (2012)
Transportation—note: nearest airport for inter-
national flights is Princess Juliana International
Airport (SXM) located on Sint Maarten','f00a8224e9c72f86e17927f14dea33c85badf157ae4dbf899e398c4453ac8e83','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f32a2b9c3f747e800e435d161d677bd39b570285b0e648e227387f0d3dc92e7d',2025,'PF','French Polynesia','transportation',632,'Airports: 53 (2012)
country comparison to the world: 86
Airports—with paved runways: total: 46
over 3,047 m: 2
1,524 to 2,437 m: 5
914 to 1,523 m: 34
under 914 m: 5 (2012)
Airports—with unpaved runways: total: 7
914 to 1,523 m: 3
under 914 m: 4 (2012)
Heliports: 1 (2012)
Roadways: total: 2,590 km
country comparison to the world: 170
paved: 1,735 km
unpaved: 855 km (1999)
Merchant marine: registered in other countries:
12 (Cambodia 1, France 11) (2010)
country comparison to the world: 107
Ports and terminals: Papeete','11b5e337c566b7c281493c30aaff29fa458f792094b84edc3d249e4af91ce071','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b5ec303716d3c9399e91e6b74ef9d2a4d66b74096d60ddc9c8d5d5e0683f1554',2025,'GA','Gabon','transportation',642,'Airports: 45 (2012)
country comparison to the world; 96
Airports—with paved runways: total: 14
over 3,047 m: 1
2,438 to 3,047 m: 2
1,524 to 2,437 m:9
914 to 1,523 m: 1
under 914 m: 1 (2012)
Airports—with unpaved runways: total: 31
1,524 to 2,437 m:7
914 to 1,523 m: 10
under 914 m: 14 (2012)
Pipelines: gas 294 km; oil 893 km (2010)
Railways: total: 649 km
country comparison to the world: 105
standard gauge: 649 km 1.435-m gauge (2008)
Roadways: total:9,170 km
country comparison to the world: 138
THE CIA WORLD FACTBOOK
paved: 937 km
unpaved: 8,233 km (2004)
Waterways: 1,600 km (310 km on Ogooue River)
(2010)
country comparison to the world: 51
Merchant marine: registered in other countries:
2 (Cambodia 1, Panama 1) (2010)
country comparison to the world: 140
Ports and terminals: Gamba, Libreville, Lucinda,
Owendo, Port-Gentil','915309d2be7d4c5401783f44b70c6d0e3c4661eb9a6edd275c6e71a7b270f5cd','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c2e92207ddac062f94d8eeae8613323bd0c0e433639f787a35ff8ce354090ced',2025,'SN','Senegal','transportation',653,'Airports: 1 (2012)
country comparison to the world: 216
Airports—with paved runways: total: 1
over 3,047 m: 1 (2012)
Roadways: total:3,742 km
country comparison to the world: 159
paved: 723 km
unpaved: 3,019 km (2004)
Waterways: 390 km (on River Gambia; small
ocean-going vessels can reach 190 km) (2010)
country comparison to the world: 89
Merchant marine: total: 4
country comparison to the world: 130
by typé: passenger/cargo 3, petroleum tanker 1
(2010)
Ports and terminals: Banjul
Airports: 1 (2012)
country comparison to the world: 218
Airports—with paved runways: total: 1
over 3,047 m: 1 (2012) > , ;
Heliports: 0 (2012)
Roadways: note: see entry for West Bank
Ports and terminals: Gaza
Airports: 20 (2012)
country comparison to the world: 136
Airports—with paved runways: total:9
over 3,047 m: 2
1524 to 2,437 m:6
914 to 1,523 m: 1 (2012)
Airports—with unpaved runways: total: 11
1,524 to 2,437 m:7
914 to 1,523 m: 3
under 914 m: 1 (2012)
Pipelines: gas 43 km; refined products 8 km
(2010)
Railways: toral:906 km
country comparison to the world: 92
narrow gauge: 906 km 1.000-m gauge (2008)
Roadways: total: 14,008 km
country comparison to the world: 125
paved: 4,099 km (includes 7 km of expressways)
unpaved: 9,909 km (2003)
Waterways: 1,000 km (primarily on the Senegal,
Saloum, and Casamance rivers) (2012)
country comparison to the world: 65
Merchant marine: total: 1
country comparison to the world: 153
by type: passenger/cargo 1 (2010)
Ports and terminals: Dakar','9d45c65ac99ded364d9b653e778870100aa60363fd9b97f828b9da278da2da30','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d277b9a1d06725f46ea2cd573dc2dc108eba6a1473b3773b417647cb24e122c5',2025,'GE','Georgia','transportation',658,'Airports: 22 (2012)
country comparison to the world: 134
Airports—with paved runways: total: 18
over 3,047 m: 1
2,438 to 3,047 m:7
1,524 to 2,437 m: 3
914 to 1,523 m: 5
under 914 m: 2 (2012)
Airports—with unpaved runways: total: 4
1,524 to 2,437 m: 1
914 to 1,523 m:2
under 914 m: 1 (2012)
Heliports: 0 (2012)
Pipelines: gas 1,596 km; oil 1,258 km (2010)
Railways: total: 1,612 km
country comparison to the world: 78
broad gauge: 1,575 km 1.520-m gauge (1,575 km
electrified)
narrow gauge: 37 km 0.912-m gauge (37 km elec-
trified) (2008)
Roadways: total: 20,329 km
country comparison to the world: 106
paved: 19,123 km (includes 13 km of expressways)
unpaved: 1,206 km (2006)
Merchant marine: total: 142
country comparison to the world: 40
by type: bulk carrier 13, cargo 114, chemical
tanker 1, container 1, liquefied gas 1, passenger/
cargo 1, petroleum tanker 3, refrigerated cargo 1,
roll on/roll off 5, vehicle carrier 2
foreign-owned: 95 (Bulgaria 1, China 10, Egypt 7,
Hong Kong 3, Israel 1, Italy 2, Latvia 1, Lebanon 1,
Romania 7, Russia 6, Syria 24, Turkey 14, UAE 2,
UK 5, Ukraine 10, US 1)
registered in other countries: 1 (unknown 1)
(2010)
Ports and terminals: Batumi, P’ot''i','38b40950e38b8a0832e9941c1f8cbb372d90c5b085500103a695727a0f51e7e2','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('78aa1447b842cb5be7bbb0d57f6fb57649d8fafd93fa2f190ec1aa5c5f363d91',2025,'DE','Germany','transportation',668,'Airports: 541 (2012)
country comparison to the world: 13
Airports—with paved runways: total: 322
over 3,047 m: 14
2,438 to 3,047 m: 48
1,524 to 2,437 m: 60
914 to 1,523 m: 70
under 914 m: 130 (2012)
Alrports—with unpaved runways: total: 219
1,524 to 2,437 m:2
914 to 1,523 m: 32
under 914 m: 185 (2012)
Heliports: 22 (2012)
Pipelines: gas 24,688 km; oil 3,687 km; refined
products 4,875 km (2010)
Railways: total:41,981 km
country comparison to the world: 6
standard gauge: 41,722 km 1.435-m gauge
(20,053 km electrified)
narrow gauge: 220 km 1.000-m gauge (75 km
electrified); 39 km 0.750-m gauge (24 km electri-
fied) (2008)
Roadways: total: 644,480 km
country comparison to the world: 11
paved: 644,480 km {includes 12,800 km of
expressways)
note: includes local roads (2008)
Waterways: 7,467 km (Rhine River carries most
goods; Main-Danube Canal links North Sea and
Black Sea) (2012)
country comparison to the world: 19
Merchant marine: total: 427
country comparison to the world: 24
by type: barge carrier 2, bulk carrier 6, cargo 51,
carrier |, chemical tanker 15, container 298, lique-
fied gas 6, passenger 4, passenger/cargo 24, petro-
leum tanker 10, refrigerated cargo 3, roll on/roll off
6, vehicle carrier 1
foreign-owned: 6 (Finland 3, Netherlands 1,
Switzerland 2)
registered in other countries: 3,420 (Antigua and
Barbuda 1094, Australia 2, Bahamas 30, Bermuda
14, Brazil 6, Bulgaria 12, Burma 1, Cayman Islands
3, Cook Islands 1, Curacao 25, Cyprus 192, Den-
mark 9, Dominica 5, Estonia 1, France 1, Gibraltar
123, Hong Kong 10, Isle of Man 56, Jamaica 10,
Liberia 1185, Luxembourg 9, Malta 135, Marshall
Islands 248, Morocco 1, Netherlands 86, NZ 2,
Panama 24, Papua New Guinea 1, Philippines 2,
Portugal 14, Saint Vincent and the Grenadines
3, Singapore 32, Slovakia 3, Spain 4, Sri Lanka 8,
Sweden 3, UK 59, US 5, Venezuela 1) (2010)
~
Ports and terminals: Bremen, Bremerhaven,
Duisburg, Hamburg, Karlsruhe, Lubeck, Neuss-
Dusseldorf, Rostock, Wilhemshaven
oil terminals: Brunsbuttel Canal terminals
Military branches: Federal Armed Forces (Bun-
deswehr): Army (Heer), Navy (Deutsche Marine,
includes naval air arm), Air Force (Luftwaffe),
Joint Support Services (Streitkraeftbasis, SKB),
Central Medical Service (Zentraler Sanitaetsdi-
enst, ZSanDstBw) (2013)
Military service age and obligation: 17-23
years of age for male and female voluntary military
service; conscription ended 1 July 2011; service
obligation 8-23 months or 12 years; women have
been eligible for voluntary service in all military
branches and positions since 2001 (2013)
Manpower available for military service:
males age 16-49: 18,529,299
females age 16-49: 17,888,543 (2010 est.)
Manpower fit for military service: males age
16-49: 15,027,886
females age 16-49: 14,510,527 (2010 est.)
Manpower reaching militarily significant age
annually: male: 405,438
female: 384,930 (2010 est.)
Military expenditures: 1.5% of GDP (2005
est.)
country comparison to the world: 96','5cba09811f88d7d95aae0317aafa3a1273552c120e20c0d3f7238ce100c470f8','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e9327352bd97061343d138a0daf7fdc2d3a316642e74940609f77301d6ad5468',2025,'GH','Ghana','transportation',677,'Airports: 10 (2012)
country comparison to the world: 157
Airports—with paved runways: total: 7
over 3,047 m: 1
2,438 to 3,047 m: 1
1,524 to 2,437 m: 3
914 to 1,523 m: 2 (2012)
Airports—with unpaved runways: total: 3
914 to 1,523 m: 3 (2012) ,
Pipelines: gas 1 km; oil 5 km; refined products
312 km (2010)
Railways: cotal:947 km
country comparison to the world: 91
narrow gauge: 947 km 1.067-m gauge (2008)
. Roadways: total: 62,221 km
country comparison to the world: 71
paved: 9,955 km
unpaved: 52,266 km (2006)
Waterways: 1,293 km (168 km for launches and
lighters on Volta, Ankobra, and Tano rivers; 1,125°
km of arterial and feeder waterways on Lake Volta)
(2011)
country comparison to the world: 57
Merchant marine: total: 4
country comparison to the world: 133
by type: petroleum tanker 1, refrigerated cargo 3
foreign-owned: 2 (Brazil 1, South Korea 1) (2010)
Ports and terminals: Takoradi, Tema','d3072871efb710ca58c016f1bd37a0502c42abb0f2919f8b5f1a491af1c63216','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f9ccb7d5c99df13c6e4b211776eaa38a6e7d31bcafb9a4dab6de4db798d3edd0',2025,'GI','Gibraltar','transportation',687,'Airports: 1 (2012)
country comparison to the world: 217
Airports—with paved runways: total: 1
1524 to 2,437 m: 1 (2012) :
Roadways: total: 29 km
country comparison to the world: 219
paved: 29 km (2007)
Merchant marine: total: 267
country comparison to the world: 32
by type: bulk carrier 3, cargo 146, chemical tanker
64, container 28, liquefied gas 2, petroleum tanker
14, roll on/roll off 2, vehicle carrier 8
foreign-owned: 254 (Belgium 1, Cyprus 1, Den-
mark 7, Finland 2, Germany 123, Greece 8, Ice-
land 1, Italy 4, Jersey 1, Morocco 4, Netherlands
34, Norway 46, Sweden 11, UAE 5, UK 6)
registered in other countries: 6 (Liberia 5, Pan-
ama 1) (2010)
Ports and terminals: Gibraltar','45e15873e2d8fde9546402e09fb5bf066eb91734291e7fcec2ab5d1e2cfa8592','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bd1a1f805d34f34167a1279f0026cb6288b3f633725571f8a8b8e3e4abc35b67',2025,'GR','Greece','transportation',698,'Airports: 82 (2012)
country comparison to the world: 69
Airports—with paved runways: total: 67
over 3,047 m: 6
2,438 to 3,047 m: 15
1,524 to 2,437 m: 19
914 to 1,523 m: 18
under 914 m: 9 (2012)
Airports—with unpaved runways: total: 15
914 to 1,523 m:2
under 914 m: 13 (2012)
Heliports: 9 (2012)
Pipelines: gas 1,240 km; oil 75 km (2010)
Railways: total: 2,548 km ''
country comparison to the world: 65
standard gauge: 1,565 km 1.435-m gauge (764 km
electrified)
narrow gauge: 961 km 1.000-m gauge; 22 km
0.750-m gauge (2008)
Roadways: total: 116,711 km (includes 948 km of
expressways) (2005)
country comparison to the world: 38
Waterways: 6 km (the 6 km long Corinth Canal
crosses the Isthmus of Corinth; it shortens a sea
voyage by 325 km) (2012)
country comparison to the world: 107
Merchant marine: total: 860
country comparison to the world: 12
by type: bulk carrier 262, cargo 49, carrier 1, chem-
ical tanker 68, container 35, liquefied gas 13, pas-
senger 7, passenger/cargo 109, petroleum tanker
302, roll on/roll off 14
foreign-owned: 42 (Belgium 17, Bermuda 3,
Cyprus 3, Italy 5, UK 6, US 8)
registered in other countries: 2,459 (Anti-
gua and Barbuda 4, Bahamas 225, Barbados
Ihoqqodtoorn®
Scoresbysund),
14, Belize 2, Bermuda 8, Brazil 1, Cambodia
2, Cape Verde 1, Cayman Islands 9, Comoros
4, Curacao 1, Cyprus 201, Dominica 4, Egypt
8, Gibraltar 8, Honduras 4, Hong Kong 27,
Indonesia 1, Isle of Man 62, Italy 7, Jamaica 3,
Liberia 505, Malta 469, Marshall Islands 408,
Mexico 2, Moldova 1, Panama 379, Philippines
5, Portugal 2, Saint Kitts and Nevis 2, Saint
Vincent and the Grenadines 42, Sao Tome and
Principe 1, Saudi Arabia 4, Singapore 22, UAE
3, Uruguay 1, Vanuatu 3, Venezuela 4, unknown
10) (2010)
Ports and terminals: Agioi Theodoroi, Aspropyr-
gos, Pachi, Piraeus, Thessaloniki','320a4169375c2c0f7e601a291166f0f63a6f3044c5cae5d76c5aad9670498899','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b4c5a5aec02c42bb390c9de0136343b2978f282256e6d87ead14376c6a90b1a4',2025,'GL','Greenland','transportation',703,'Airports: 15 (2012)
country comparison to the world: 148
Airports—with paved runways: total: 10
2,438 to 3,047 m: 2
1,524 to 2,437 m: 1
914 to 1,523 m: 1
under 914 m: 6 (2012)
Airports—with unpaved runways: total:5
1,524 to 2,437 m: 1
914 to 1,523 m: 2
under 914 m: 2 (2012)
I
THE CIA WORLD FACTBOOK
Roadways: note: although there are short roads in
towns, there are no roads between towns; inter-urban
transport takes place either by sea or air (2005)
Merchant marine: registered in other countries:
1 (Denmark 1) (2010)
country comparison to the world: 156
Ports and terminals: Sisimiut','e76d0d738f0704a6a74bb66ea1e432b5b529637bb9334032f349b724ebca2305','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('45d1932c60472051ad55db727347b2fbb219161794605e72cff176af231d5c5d',2025,'GD','Grenada','transportation',708,'Airports: 3 (2012)
country comparison to the world: 196
Airports—with paved runways: total:3
2,438 to 3,047 m: 1
1,524 to 2,437 m: 1
under 914 m: 1 (2012)
Roadways: total: 1,127 km
country comparison to the world: 182
paved: 687 km
unpaved: 440 km (2000)
Ports and terminals: Saint George’s
Airports: 5 (2012)
country comparison to the world: 184
Alrports—with paved runways: total: 4
over 3,047 m: 2
2,438 to 3,047 m: 1
914 to 1,523 m: 1 (2012)
Airports—with unpaved runways: total: 1
under 914 m: 1 (2012)
Roadwoys: total: 1,045 km (2008)
country comparison to the world: 184
Ports and terminals: Apra Harbor','76730af1f4462b072341e2c504a1e2c97dd19aeab0cac9a395da38a0d11e6594','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('17a81bff926519e05b5783c2c45139a143a51b70c3cb1de309508f739c721226',2025,'GT','Guatemala','transportation',717,'Airports: 291 (2012)
cOuntry comparison to the world: 24
Airports—with paved runways: total: 15
2,438 to 3,047 m: 3
1,524 to 2,437 m:3
914 to 1,523 m: 5
under 914 m: 4 (2012)
Airports—with unpaved runways: total: 276
2,438 to 3,047 m: 1
1,524 to 2,437 m: 2
914 to 1,523 m: 79
under 914 m: 194 (2012)
Heliports: (2012)
Pipelines: oil 480 km (2010)
Railways: total: 332 km
country comparison to the world: 118
narrow gauge: 332 km 0.914-m gauge (2008)
Roadways: total: 14,095 km
country comparison to the world: 124
paved; 4,863 km (includes 75 km of expressways)
unpaved: 9,232 km (2000)
Waterways: 990 km (260 km navigable year
round; additional 730 km navigable during high-
water season) (2012)
country comparison to the world: 66
Ports and terminals: Puerto Quetzal, Santo
Tomas de Castilla','e231df04b4e26c8d30770090302f2955930418589bf883181cee5ab69505a0ce','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('acb327dd1f53a8e64f7d5e8ebc9ee39371ebd08dbbe63ca08281821e1ccf7fb4',2025,'GG','Guernsey','transportation',725,'Airports: 2 (2012)
country comparison to the world: 200
subsequently to Burkina Faso. A transitional
government led by Gen. Sekouba KONATE held
democratic elections in 2010 and Alpha CONDE
was elected president in the country’s first free and
fair elections since independence. CONDE in July
2011 survived an attack on his residence allegedly
perpetrated by the military. In October 2012, he
announced a cabinet reshuffle that removed three
members of the military from their positions, mak-
ing the current administration Guinea’s first all-
civilian government.','53dcd116c81a7672adc4fb727e202f1aeb92ca75c26548fbb5014df11f3d1d82','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2a394a332dd002a3ad11d439632138c09b935c727d528dc294895049ad9da8ef',2025,'GN','Guinea','transportation',734,'Airports: 16 (2012)
country comparison to the world: 144
Airports—with paved runways: total: 4
over 3,047 m: 1
1,524 to 2,437 m: 3 (2012)
Airports—with unpaved runways: total: 12
1,524 to 2,437 m:7
914 to 1,523 m: 3
under 914 m: 2 (2012)
Railways: total: 1,185 km
country comparison to the world: 87
standard gauge: 238 km 1.435-m gauge
narrow gauge: 947 km 1.000-m gauge (2008)
Roadways: total: 44,348 km
country comparison. to the world: 82
paved: 4,342 km
unpaved: 40,006 km (2003)
Waterways: 1,300 km (navigable by shallow-draft
native craft in the northern part of the Niger sys-
tem) (2011)
country comparison to the world: 56
Ports and terminals: Conakry, Kamsar','b07b93a03694a74d42bafd91677ad8d7e4020a570cc5561c38d41b2e5c69b814','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fd5ca2e6e2b500e7fcb17a1f601868bdfbd4a76b08a7d00dd30a2e0986dfe9bf',2025,'GW','Guinea-Bissau','transportation',744,'Airports: 8 (2012)
country comparison to the world: 161
Alrports—with paved runways: total: 2
over 3,047 m: 1
1,524 to 2,437 m: 1 (2012)
Airporte—with unpaved runways: total: 6
1,524 to 2,437 m: 1
914 to 1,523 m: 2
under 914 m: 3 (2012)
Roadways: total: 3,455 km
country comparison to the world: 161
paved: 965 km
unpaved: 2,490 km (2002)
Waterways: (rivers are navigable for some dis-
tance; many inlets and creeks give shallow-water
access to much of interior) (2012)
Ports and terminals: Bissau, Buba, Cacheu,
Farim','151ddb601be41958b2e618a195aec2e9f12d473202cf50efc5b96f2c872abdd8','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('47dbca100e57973053e5dd72d00e33fbedda1b2e294cfd36fd0c0d9e76257377',2025,'GY','Guyana','transportation',754,'Airports: 98 (2012)
country comparison to the world: 59
Airports—with paved runways: total: 11
1524 to 2,437 m: 2
914 to 1,523 m: 1
under 914 m: 8 (2012)
Airports—with unpaved runways: total: 87
934 to 1,523 m: 13
under.914 m: 74 (2012)
Roadways: total: 7,970 km
country comparison to the world: 141
paved: 590 km
unpaved: 7,380 km (2000)
Waterways: 330 km (the Berbice, Demerara, and
Essequibo rivers are navigable by oceangoing vessels
for 150 km, 100 km, and 80 km respectively) (2012)
country comparison to the world: 92
Merchant marine: oral: 10
country comparison to the world: 114
by type: cargo 7, petroleum tanker 2, refrigerated cargo 1
registered in other countries: 3 (Saint Vincent
and the Grenadines 2, unknown 1) (2010)
Ports and terminals: Georgetown','46eb5f2ab3236e6e8da15a00b2bdd8937bccd575b3bd29df964a27500bdd6818','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4358ca96cca2357b0bd0ddc7b51476a1a52632e9c8709b4c13c91fba10effbf4',2025,'HT','Haiti','transportation',759,'Airports: 14 (2012)
country comparison to the world: 149
Airports—with paved runways: total: 4
2,438 to 3,047 m: 1
914 to 1,523 m: 3 (2012)
Airports—with unpaved runways: total: 10
914 to 1,523 m: 2
under 914 m: 8 (2012)
Roadways: total: 4,266 km
country comparison to the world: 155
paved: 768 km
unpaved: 3,498 km (2009)
Ports and terminals: Cap-Haitien, Gonaives,
Jacmel, Port-au-Prince','c7cc018b740681376f7915b07e6a92fa07b40f2bd299366f6c12db14ab27d83a','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c57d74d7d52c080e4ebdd82791cf70d299814e92ccb0632b203c4036542e1b39',2025,'HM','Heard Island and McDonald Islands','transportation',768,'Ports and terminals: none; offshore anchorage
only
Military—note: defense is the responsibility of
Australia; Australia conducts fisheries patrols','e1311f45cc2e9cb7c2fc51f7cc613e6031ce3d1e92afd44b7b7c63c5c29d7551','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a687f883c1a0848da8e973428daad913622653cf3f16cbfb086bf100a2687c56',2025,'HN','Honduras','transportation',780,'Airports: 104 (2012)
country comparison to the world: 53
Airports—with paved runways: total: 13
2,438 to 3,047 m: 3
1,524 to 2,437 m:3
914 to 1,523 m: 4
under 914 m: 3 (2012)
Airports—with unpaved runways: total: 91
1,524 to 2,437 m: 1
914 to 1,523 m: 17
under 914 m: 73 (2012)
Railways: total: 75 km
country comparison to the world: 128
ridrrow gauge: 75 km 1.067-m gauge (2009)
Roadways: total: 14,239 km
country comparison to the world: 123
paved: 3,159 km
unpaved: 11,080 km (1,420 km summer only)
(2009)
Waterways: 465 km (most navigable only by
small craft) (2012)
country comparison to the world: 85
Merchant marine: total: 88
country comparison to the world: 55
by type: bulk carrier 5, cargo 39, carrier 2, chemi-
cal tanker 5, container 1, passenger 4, passenger/
cargo 1, petroleum tanker 21, refrigerated cargo 7,
roll on/roll off 3
foreign-owned: 47 (Bahrain 5, Canada 1, Chile
1, China 2, Egypt 2, Greece 4, Israel 1, Japan 4,
Lebanon 2, Montenegro 1, Panama 1, Singapore
11, South Korea 6, Taiwan 1, Thailand 2, UAE 1,
UK 1, US 1) (2010)
Ports and terminals: La Ceiba, Puerto Cortes,
San Lorenzo, Tela','72c395ce3e9ab23c034849ebb531a69aa62619ce18cfc0adee4ef676ada3d87a','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c66af4b079e25f16deee3cee3bf01b200eecf6e8e6977921ec17478043ed8aef',2025,'HK','Hong Kong','transportation',789,'Airports: 2 (2012)
country comparison to the world: 201
Airports—with paved runways: total: 2
over 3,047 m: 1
1,524 to 2,437 m: 1 (2012)
Heliports: 9 (2012)
Roadways: total: 2,067 km','fa1b0ba7c8d1915314d8d9a923c1457ea8b442cba62ad3244a5bd7d3e8cba3c6','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('88988063eec9c4b5c431bdd4776c185f54dafdd471229656759c04d7c38f0e79',2025,'HU','Hungary','transportation',797,'Airports: 41 (2012)
332
THE CIA WORLD FACTBOOK
country comparison to the world: 104
Airports—with paved runways: total: 20
over 3,047 m:2
2,438 to 3,047 m: 6
1,524 to 2,437 m:5
914 to 1,523 m: 6
under 914 m: 1 (2012)
Airports—with unpaved runways: total: 21
1,524 to 2,437 m: 2
914 to 1,523 m: 8
under 914 m: 11 (2012)
Heliports: 3 (2012)
Pipelines: gas 4,716 km; oil 984 km; refined prod-
ucts 361 km (2010)
Railways: total: 8,057 km
country comparison to the world: 26
broad gauge: 36 km 1.524-m gauge
standard gauge: 7,802 km 1.435-m gauge (2,911
km electrified)
narrow gauge: 219 km 0.760-m gauge (2009)
Roadways: total: 197,519 km
country comparison to the world: 24
paved: 74,993 km (43,898 km of interurban roads
including 911 km of expressways)
unpaved: 112,526 km (2010)
Waterways: 1,622 km (most on Danube River)
(2011) : ''
country comparison to the world: 48
Ports and terminals: Budapest, Dunaujvaros,
Gyor-Gonyu, Csepel, Baja, Mohacs','7ceccb98a1790bbdf693a2b7bba9ee6596e7914f3d6de5787386ef381798c871','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('183584f91e0f251c74d2af4fb5c62d42151bd6af15915830ae74ef98a6336260',2025,'IS','Iceland','transportation',804,'Airports: 99 (2012)
THE CIA WORLD FACTBOOK
country comparison to the world: 57
Airports—with paved runways: total: 6
over 3,047 m: 1
1,524 to 2,437 m: 3
914 to 1,523 m: 2 (2012)
Airports—with unpaved runways: total: 93
1,524 to 2;437 m: 3
914 to 1,523 m: 27
under 914 m: 63 (2012)
Roadways: total: 12,869 km
country comparison to the world: 128
paved/oiled gravel: 4,438 km (does not include
urban roads)
unpaved: 8,431 km (2009)
Merchant marine: total: 2
country comparison to the world: 141
by type: passenger/cargo 2
registered in other countries: 19 (Antigua and
Barbuda 10, Belize 1, Faroe Islands 4, Finland 1,
Gibraltar 1, Norway 2) (2010)
Ports and terminals: Grundartangi, Hafnarfjor-
dur, Reykjavik','4cda35a621504e883f67cd4f5a4b1e771bb33114c0dbbca28e405c3aa02495a4','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6801c9306a04415b4656880a9136c15a7b68af5b43bbcff717551a48c10f0b00',2025,'IN','India','transportation',813,'Airports: 352 (2012)
country comparison to the world: 22
Airports—with paved runways: total: 251
over 3,047 m: 21
2,438 to 3,047 m: 59
1,524 to 2,437 m: 74
914 to 1,523 m: 83
under 914 m: 14 (2012)
Airports—with unpaved runways: total: 101
over 3,047 m: 1
2,438 to 3,047 m: 4
1,524 to 2,437 m: 6
914 to 1,523 Ñ: 42
under 914 m: 48 (2012)
Heliports: 41 (2012)
Pipelines: condensate/gas 2 km; gas 9,596 km; liq-
uid petroleum gas 2,152 km; oil 7,448 km; refined
products 10,486 km (2010)
Railways: total: 63,974 km
country comparison to the world: 4
‘broad gauge: 54,257 km 1,676-m gauge (18,927
km electrified)
narrow gauge: 7,180 km 1,000-m gauge; 2,537 km
0.762-m gauge and 0.610-m gauge (2009)
Roadways: total: 3,320,410 km (includes 200 km
of expressways) (2009)
country comparison to the world: 3
Waterways: 14,500 km (5,200 km on major riv-
ers and 485 km on canals suitable for mechanized
vessels) (2012)
country comparison to the world: 9
Merchant marine: total: 340
country comparison to the world: 29
by type: bulk carrier 104, cargo 78, chemical
tanker 22, container 14, liquefied gas 11, passenger
4, passenger/cargo 15, petroleum tanker 92
foreign-owned: 10 (China 1, Hong Kong 2, Jersey
2, Malaysia 1, UAE 4)
registered in other countries: 76 (Cyprus 4,
Dominica 2, Liberia 8, Malta 3, Marshall Islands
10, Nigeria 1, Panama 24, Saint Kitts and Nevis 2,
Singapore 21, unknown 1) (2010)
Ports and terminals: Chennai, Jawaharal Nehru
Port, Kandla, Kolkata (Calcutta), Mumbai (Bom-
bay), Sikka, Vishakhapatnam
Shipyards and Ship Building: Shipyards: 13
Ships Built: 33 (2009)
Ports and terminals: Chennai (Madras, India);
Colombo (Sri Lanka); Durban (South Africa);
Jakarta (Indonesia); Kolkata (Calcutta, India);
Melbourne (Australia); Mumbai (Bombay, India);
Richards Bay (South Africa)
Transportation—note: although the number of
reported incidents of piracy have dropped dramati-
cally in 2012, the International Maritime Bureau
continues to report the territorial waters of littoral
states and offshore waters as high risk for piracy and
armed robbery against ships, particularly in the Gulf
of Aden, along the east coast of Africa, the Bay of
Bengal, and the Strait of Malacca; the presence of
several naval task forces in the Gulf of Aden and
additional anti-piracy measures on the part of ship
operators, including the use of on-board armed
security teams, have reduced incidents of piracy; in
response, Somali-based pirates, using hijacked fish-
ing trawlers as “mother ships” to extend their range,
shifted operations as far south as the Mozambique
Channel, eastward to the vicinity of the Maldives,
and northeastward to the Strait of Hormuz','9cbc746b67a5cc9fdd19f7ef78a0aba402e82189d516a5724c96b89b7188f8d9','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2bbaf7f37ceeebd40eb957a22961d468d61806c8fd6e48e6cd6ecef27fc8c0ea',2025,'IQ','Iraq','transportation',825,'Airports: 104 (2012)
country comparison to the world: 54
Airports—with paved runways: total: 75
over 3,047 m: 20
2,438 to 3,047 m: 36
1,524 to 2,437 m: 5
914 to 1,523 m: 6
under 914 m: 8 (2012)
Airports—with unpaved runways: toral:29
over 3,047 m: 3
2,438 to 3,047 m: 4
1,524 to 2,437 m: 3,
914 to 1,523 m: 13
under 914 m: 6 (2012)
Heliports: 20 (2012)
Pipelines: gas 2,447 km; liquid petroleum gas 918
km; oil 5,104 km; refined products 1,637 km (2010)
Railways: total: 2,272 km
country comparison to the world: 66
standard gauge: 2,272 km 1.435-m gauge (2008)
Roadways: total: 44,900 km
country comparison to the world: 81
paved: 37,851 km
unpaved: 7,049 km (2002)
Waterways: 5,279 km (the Euphrates River
(2,815 km), Tigris River (1,899 km), and Third
River (565 km) are the principal waterways)
(2012)
country comparison to the world: 23
Merchant marine: total: 2
country comparison to the world: 142
by type: petroleum tanker 2
registered in other countries: 2 (Marshall Islands
2) (2010)
Ports and terminals: Al Basrah, Khawraz Zubayr,
Umm Qasr','289a41dbffff08a25b0d4722eddb59fa2b91eb2c5d1d37bcf299c508a588151d','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f013c6a3d288050e26f4376816b4ce69c90c7937d6727cc4090ad28374175fa5',2025,'IE','Ireland','transportation',831,'Airports: 39 (2012)
country comparison to the world: 107
Airports—with paved runways: total: 16
over 3,047 m: 1
2,438 to 3,047 m: 1
1,524 to 2,437 m: 4
914 to 1,523 m: 5
under 914 m: 5 (2012)
Airports—with unpaved runways: total: 23
914 to 1,523 m: 2
under 914 m: 21 (2012)
Pipelines: gas 1,888 km (2010)
Railways: total: 3,237 km
country comparison to the world: 54
broad gauge: 1,872 km 1.600-m gauge (37 km
electrified)
narrow gauge: 1,365 km 0.914-m gauge (operated
by the Irish Peat Board to transport peat to power
stations and briquetting plants) (2008)
Roadways: total: 96,036 km
country comparison to the world: 45 ,
paved: 96,036 km (includes 1,224 km of express-
ways) (2010)
Waterways: 956 km (pleasure craft only) (2010)
country comparison to the world: 68
Merchant marine: total: 31
country comparison to the world: 84
by type: cargo 28, chemical tanker 2, container 1
foreign-owned: 5 (France 2, Spain 1, US 2)
registered in other countries: 33 (Bahamas
3, Bermuda 1, Cambodia 1, Cyprus 3, Isle of
Man1,Kazakhstan 1, Malta 4, Marshall Islands 6,
Netherlands 8, Panama 1, Russia 1, Slovakia 1,
Sweden 1, UK 1) (2010)
Ports and terminals: Cork, Dublin, Shannon
Foynes, Waterford','ad7bd5d9abb44f5e16f624335177718aa9d84ed39dd055eb6e57fa4ce3994624','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e55b7bcfe72e9b197ccadd2ae5ef94c1384b4d892558c790c794929c1a138e16',2025,'IM','Isle of Man','transportation',840,'Airports: 0 (2012)
country comparison to the world: 219
Airports—with paved runways: total: 1
1,524 to 2,437 m: 1 (2012)
Railways: total: 63 km
country comparison to the world: 129
narrow gauge: 6 km 1.076-m gauge (6 km elec-
trified); 57 km 0.914-m gauge (29 km electrified)
* note: primarily summer tourist attractions (2008)
Roadways: total: 500 km (2008)
country comparison to the world: 195
Merchant marine: total: 321
country comparison to the world: 30 by type:
bulk carrier 59, cargo 55, chemical tanker 52, con-
tainer 7, liquefied gas 43, passenger/cargo 2, petro-
leum tanker 93, roll on/roll off 5, vehicle carrier 5
foreign-owned: 223 (Bermuda 7, Chile 9, Den-
mark 30, Germany 56, Greece 62, Ireland 1, Japan
19, Malaysia 6, Norway 30, South Africa 2, US 1)
(2010)
Ports and terminals: Douglas, Ramsey','2c5dc3a13bf0fd353291031f3309fb156b6b854ecb92196b1b99f14229a56d6b','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a5cadd8dca0588d3208fdb8081fd1f6901b4d5a05d47d35a4560fef507c419c9',2025,'IL','Israel','transportation',848,'Airports: 47 (2012)
country comparison to the world: 92
Airports—with paved runways: total: 29
over 3,047 m: 2
2,438 to 3,047 m:5
1,524 to 2,437 m: 6
914 to 1,523 m: 11
under 914 m: 5 (2012)
Airports—with unpaved runways: total: 18
1,524 to 2,437 m: 1
914 to 1,523 m: 3
under 914 m: 14 (2012)
Heliports: 3 (2012)
Pipelines: gas 211 km; oil 442 km; refined prod-
ucts 261 km (2010)
Railways: total:975 km
country comparison to the world: 89
standard gauge: 975 km 1.435-m gauge (2008)
Roadways: total: 18,290 km
country comparison to the world: 114
paved: 18,290 km (includes 146 km of express-
ways) (2008)
Merchant marine: total: 8
country comparison to the world: 120
by type: cargo 1, container 7
registered in other countries: 48 (Bermuda 3,
Georgia 1, Honduras 1, Liberia 34, Malta 3,
Moldova 2, Panama 1, Saint Vincent and the
Grenadines 3) (2010)
_ Ports and terminals: Ashdod, Elat (Eilat), Had-
era, Haifa
Airports: 2 (2012)
country comparison to the world: 208
Airports—with paved runways: total: 2
1,524 to 2,437 m: 1
under 914 m: 1 (2012)
Roadways: total: 5,147 km
country comparison to the world: 153
paved: 5,147 km
note: includes Gaza Strip (2006)','fa5a73608bcda344a1c7afb781058802b8aad7bbd2b6f91a00ab462883e58d63','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bbbca9ba14698ae363f7e7081e5b492e178949c452e4409027ce78558d4f757d',2025,'IT','Italy','transportation',858,'Airports: 130 (2012)
country comparison to the world: 44
Airports—with paved runways: total: 99
over 3,047 m:9
2,438 to 3,047 m: 31
1,524 to 2,437 m: 18
914 to 1,523 m: 29
under 914 m: 12 (2012)
Airports—with unpaved runways: total: 31
1,524 to 2,437 m: 1
914 to 1,523 m: 11
under 914 m: 19 (2012)
Heliports: 5 (2012)
Pipelines: gas 18,348 km; oil 1,241 km (2010)
- Railways: total: 20,255 km
country comparison to the world: 13
standard gauge: 18,611 km 1.435-m gauge
” (12,662 km electrified)
narrow gauge: 123 km 1.000-m gauge (123 km
electrified); 1,290 km 0.950-m gauge (151 km
electrified); 231 km 0.850-m gauge (2008) i
Roadways: total: 487,700 km
country comparison to the world: 13
paved: 487,700 km (includes 6,700 km of express-
ways) (2007)
Waterways: 2,400 km (used for commercial traf-
fic; of limited overall value compared to road and
rail) (2012)
country comparison to the world: 37
Merchant marine: total: 681
country comparison to the world: 17
by type: bulk carrier 105, cargo 42, carrier 1,
chemical tanker 164, container 21, liquefied gas
28, passenger 25, passenger/cargo 154, petroleum
tanker 59, refrigerated cargo 4, roll on/roll off 39,
specialized tanker 9, vehicle carrier 30
foreign-owned: 90 (Denmark 4, France 2, Greece
7, Luxembourg 14, Netherlands 2, Nigeria 1, Nor-
way 6, Singapore 1, Sweden 1, Switzerland 13,
Taiwan 10, Turkey 4, UK 2, US 23)
registered in other countries: 201 (Bahamas 1,
Belize 3, Cayman Islands 7, Cyprus 6, Georgia 2,
Gibraltar 4, Greece 5, Liberia 47, Malta 45, Mar-
shall Islands 1, Morocco 1, Netherlands 6, Panama
25, Portugal 12, Russia 14, Saint Vincent and the
Grenadines 4, Singapore 5, Slovakia 2, Spain 1,
Sweden 5, Turkey 1, UK 3, unknown 1) (2010)
Ports and terminals: Augusta, Cagliari, Genoa,
Livorno, Taranto, Trieste, Venice
oil terminals: Melilli (Santa Panagia) oil termi-
nal, Sarroch oil terminal','6753e2148bfcdfb90e515384fa519ff5e9269a0d3d75b207fea37a09740e8711','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7223f7bde35ab90d8e32c2eb5bb29863b533d20fdb31bce6f94ba15fbe9d9c9e',2025,'JM','Jamaica','transportation',866,'Airports: 27 (2012)
country comparison to the world: 125
Airports—with paved runways: oral: 12
2438 to 31047 m: 2
914 to 153m: 4
under 914 m: 6 (2012)
Airports—with unpaved runways: total: 15
under 914m: 15 (2012
Roadways: total: 22,12} km (includes 44 km of
expressways) (2005)
country comparison to the world: 103
Merchont marine: coral: 14
country comparison to the world: 102
by rype bulk camer 4, cargo 5, container 4, roll
onJroll off 1
foreign-owned: 14 (Denmark 1, Germany 10,
Greece 3) (2010)
Ports aad terminais: Discovery Bay (Port
Rhoades). Kingston, Montego Bay, Port Antonio,
Post Esquivel, Port Kaiser, Rocky Point
i TAR
Military bronches: Jamaica Defense Force:
Ground Forces, Coast Guard, Air Wing (2010)
Military service age and obligation: 17 1/2 is
the legal minimum age for voluntary military ser-
vice; no conscription (2012)
Manpower available for military service:
males age 16-49: 726,263
females age 16-49: 742,958 (2010 est.)
371
Manpower fit for military service: males age
16-49: 590,673
females age 16-49: 596,414 (2010 est.)
Manpower reaching militarily significant age
annually: male: 33,369
female: 32,702 (2010 est.)
Military expenditures: 0.9% of GDP (2012)
THE CiA WORLD FACTBOOK
country comparison to the world: 144
Airports: 1 (2012)
country comparison to the world: 222
Airports—with unpaved runways: total: 1
1,524 to 2,437 m: 1 (2012)
Ports and terminals: none; offshore anchorage only','deff7f781db7ff999a5c6c30569cd3eedacbcbbd0747f1cd01766131af8cf5b2','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9a1746a6238b142e9142f1638af0545d7774f3cfd963553e28e9b04df57beed7',2025,'JP','Japan','transportation',880,'Airports: 175 (2012)
country comparison to the world: 34
numerous
THE CIA WORLD FACTBOOK
Airports—with paved runways: total: 143
over 3,047 m: 6
2,438 to 3,047 m: 45
1,524 to 2,437 m: 38
914 to 1,523 m: 29
under 914 m: 25 (2012)
Airports—with unpaved runways: total: 32
1,524 to 2,437 m: ł
914 to 1,523 m:3
under 914 m: 28 (2012)
Heliports: 15 (2012)
Pipelines: gas 4,135 km; oil 171 km; oil/gas/water
53 km (2010)
Railways: total: 27,182 km
country comparison to the world: 11
standard gauge: 4,251 km 1.435-m gauge (4,251
km electrified)
dual gauge: 486 km 1.435-1.067-m gauge (486 km
electrified)
narrow gauge: 96 km 1.372-m gauge (96 km
electrified); 22,301 km 1.067-m gauge (15,222 km
electrified); 48 km 0.762-m gauge (48 km electri-
fied) (2009) i
Roadways: total: 1,210,251 km
country comparison to the world: 5
paved: 973,234 km (includes 7,803 km of
expressways)
unpaved: 237,017 km (2008)
Waterways: 1,770 km (seagoing vessels use inland
seas) (2010)
country comparison to the world: 45
Merchant marine: total: 684
country comparison to the world: 16
by type: bulk carrier 168, cargo 34, carrier 3, chemical
tanker 29, container 2, liquefied gas 58, passenger 11,
passenger/cargo 117, petroleum tanker 152, refriger-
ated cargo 4, roll on/roll off 52, vehicle carrier 54
registered in other countries: 3,122 (Bahamas 88,
Bermuda 2, Burma 1, Cambodia 1, Cayman Islands
23, China 2, Cyprus 16, Honduras 4, Hong Kong
79, Indonesia 8, Isle of Man 19, Liberia 110, Lux-
embourg 3, Malaysia 2, Malta 5, Marshall Islands
59, Mongolia 2, Netherlands 1, Panama 2372,
Philippines 77, Portugal 9, Saint Kitts and Nevis 2,
Saint Vincent and the Grenadines 3, Sierra Leone
4, Singapore 164, South Korea 14, Tanzania 1, UK
5, Vanuatu 39, unknown 7) (2010)
Ports and terminals: Chiba, Kawasaki, Kobe,
Mizushima, Moji, Nagoya, Osaka, Tokyo, Toma-
komai, Yokohama','adeef48cac4a8fdad7ae8456e7c1f9f59f59f100cf0c596c535e59e249216a27','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('644d0e2ea5da888e9d0f16eaaa0a83fae237744989158946e1663215983894d0',2025,'JE','Jersey','transportation',889,'Airports: 1 (2012)
country comparison to the world: 221
Airports—with paved runways: total: 1
1,524 to 2,437 m: 1 (2012)
Roadways: total: 576 km (2010)
country comparison to the world: 191
Merchant marine: registered in other countries:
14 (Gibraltar 1, India 2, Marshall Islands 11)
(2010)
country comparison to the world: 103
Ports and terminals: Gorey, Saint Aubin, Saint
Helier
Airports: 15 (2012)
country comparison to the world: 146
Airports—with paved runways: total: 2
over 3,047 m: 1
2,438 to 3,047 m: 1 (2012)
Airports—with unpaved runways: total: 13
914 to 1,523 m: 6
under 914 m: 7.(2012)
Railways: total: 301 km
country comparison to the world: 120
narrow gauge: 301 km 1.067-m gauge (2008)
Roadways: total: 3,594 km
ee
et Ne
i
f N
è
F
|
Lued \\
.
s
7
p Kona
l Kinneke
Skelett,
L
/
È
{
\\
{
:
>
e
j
Haimst
P ies ad nar es
Kasarin','a125d5744e445c1122d0f398ce06758796583e299c8dd0bfb595b6d8ac5847b0','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6c58a1bf5578421efb99bf9108318b1fcb4fbbbe0b223df173f2faab31cf19bb',2025,'JO','Jordan','transportation',897,'Airports: 18 (2012)
country comparison to the world: 139
Airports—with paved runways: total: 16
over 3,047 m: 8
2,438 to 3,047 m: 5
1,524 to 2,437 m:2
914 to 1,523 m: 1 (2012)
381
Alrports—with unpaved runways: total: 2
under 914 m: 2 (2012)
Heliports: 1 (2012)
Pipelines: gas 439 km; oil 49 km (2010)
Railways: total: 507 km
country comparison to the world: 111
narrow gauge: 507 km 1.050-m gauge (2008)
Roadways: total: 7,891 km
country comparison to the world: 142
paved: 7,891 km (2009)
Merchant marine: total: 12
country comparison to the world: 106
by type: cargo 4, passenger/cargo 6, petroleum
tanker 1, roll on/roll off 1
foreign-owned: 2 (UAE 2)
registered in other countries: 16 (Bahamas 2,
Egypt 2, Indonesia 1, Panama 11) (2010)
Ports and terminals: Al ‘Aqabah
382
THE CIA WORLD FACTBOOK','ded68c472273b2df8ad3f9f5ebbb03146f4498024a0961955d9e38067f781b75','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f4414d3dd0612742441e5548c88ea15abbe266fb943f73ce32d39798e4ab071b',2025,'KZ','Kazakhstan','transportation',903,'Airports: 97 (2012)
country comparison to the world: 62
Airports—with paved runways: total: 64
over 3,047 m: 10
''2,438 to 3,047 m: 25
1,524 to 2,437 m: 16
914 to 1,523 m:5
under 914 m: 8 (2012)
Airports—with unpaved runways: total: 33
over 3,047 m:5
2,438 to 3,047 m:7
1,524 to 2,437 m:3
914 to 1,523 m: 5
under 914 m: 13 (2012)
Heltports: 3 (2012)
Pipelines: condensate 658 km; gas 12,317 km; oil
11,201 km; refined products 1,095 km; water 1,465
km (2010)
Railways: total: 15,079 km
country comparison to the world: 19
broad gauge: 15,079 km 1.520-m gauge (4,000 km
electrified) (2008)
Roadways: oral: 93,612 km
country comparison to the world: 47
paved: 84,100 km
unpaved: 9,512 km (2008)
Waterways: 4,000 km (on the Ertis (Irtysh) River
(80%) and Syr Darya (Syrdariya) River) (2010)
country comparison to the world: 26
Merchant marine: total: 11
country comparison to the world: 109
by type: cargo 1, petroleum tanker 8, refrigerated
cargo 1, specialized tanker 1
foreign-owned: 3 (Austria 1, Ireland 1, Turkey 1)
(2010)
Ports and terminals: Aqtau (Shevchenko),
Atyrau (Guryev), Oskemen (Ust-Kamenogorsk),
Pavlodar, Semey (Semipalatinsk)','9483d5b7288dfbf9fbcba99b641c18de802cff9646994b052d88150c9559c907','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('df0127dfeb7ef28871066b3f8b66cb38057cddcfbd433196f74991f6b461ec1d',2025,'KE','Kenya','transportation',913,'Airports: 194 (2012)
country comparison to the world: 31
Airports—with paved runways: total: 15
over 3,047 m: 4
2,438 to 3,047 m: 2
1,524 to 2,437 m: 3
914 to 1,523 m: 5
under 914 m: 1 (2012)
Airports—with unpaved runways: total: 179
1,524 to 2,437 m: 14
914 to 1,523 m: 110
under 914 m: 55 (2012)
Pipelines: oil 4 km; refined products 928 km
(2010)
Railways: total; 2,066 km
country comparison to the world: 71
narrow gauge: 2,066 km 1.000-m gauge (2008)
Roadways: total: 160,886 km
country comparison to the world; 30
paved: 11,197 km
unpaved: 149,689 km (2008)
Waterways: none specifically the only significant
inland waterway in the country is the part of Lake
Victoria within the boundaries of Kenya; Kisumu
is the main port and has ferry connections to
Uganda and Tanzania (2011)
Merchant marine: registered in other coun-
tries: 5 (Comoros 2, Saint Vincent and the
Grenadines 2, unknown 1) (2010)
country comparison to the world: 125
Ports and terminals: Kisumu, Mombasa','1362863e3f20449cf0c053226f111a729ef3d236fd9c8ada1bed3619b126a2f3','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('310e6d215e5124588b3ddc88dbb6b83b164c67f19d6d617dd09d5d353876ac5d',2025,'KI','Kiribati','transportation',922,'Airports: 19 (2012)
country comparison to the world: 137
Airports—with paved runways: total: 4
1524 to 2,437 m: 4 (2012)
Airports—with unpaved runways: total: 14
914 to 1,523 m: 10
under 914 m: 5 (2012)
Roadways: total: 670 km (2000)
country comparison to the world: 190
Waterways: 5 km (small network of canals in Line
Islands) (2012)
country comparison to the world: 108
Merchant marine: total: 77
country comparison to the world: 58
by type: bulk carrier 7, cargo 35, chemical
tanker 6, passenger 1, passenger/cargo 1, petro-
leum tanker 12, refrigerated cargo 15
foreign-owned: 43 (China 26, Hong Kong 2,
Russia 1, Singapore 9, South Korea 1, Taiwan 2,
Vietnam 2) (2010)
Ports and terminals: Betio (Tarawa Atoll), Can-
ton Island, English Harbor
Airports: 81 (2012)
country comparison to the world: 71
Airports—with paved runways: total: 39
over 3,047 m: 3
2,438 to 3,047 m: 22
1,524 to 2,437 m: 8
914 to 1,523 m:2
under 914 m: 4 (2012)
Airports—with unpaved runways: total: 42
2,438 to 3,047 m: 3
1,524 to 2,437 m: 17
914 to 1,523 m: 14
under 914 m: 8 (2012)
Heliports: 23 (2012)
Pipelines: oil 154 km (2010)
Railways: total:5,242 km
country comparison to the world: 33
standard gauge: 5,242 km 1.435-m gauge (3,500
km electrified) (2009)
Roadways: total: 25,554 km
country comparison to the world: 101
paved: 724 km
unpaved: 24,830 km (2006)
Waterways: 2,250 km (most navigable only by
small craft) (2011)
country comparison to the world: 38
Merchant marine: total: 158
country comparison to the world: 37
by type: bulk carrier 6, cargo 131, carrier 1, chemi-
cal tanker 1, container 4, passenger/cargo 1, petro-
leum tanker 12, refrigerated cargo 2
foreign-owned: 13 (Belgium 1, China 3, Nigeria
1, Singapore 1, South Korea 1, Syria 4, UAE 2)
. registered in other countries: 6 (Mongolia 1,
Sierra Leone 2, unknown 3) (2010)
Ports and terminals: Ch’ongjin; Haeju, Hung-
nam (Hamhung), Namp''o, Senbong, Songnim,
Sonbong (formerly Unggi), Wonsan
Airports: 114 (2012)
country comparison to the world: 50
Airports—with paved runways: tocal:71
over 3,047 m: 4
2,438 to 3,047 m: 20
1,524 to 2,437 m: 12
914 to 1,523 m: 13
under 914 m: 22 (2012)
Airports—with unpaved runways: total: 43
914 to 1,523 m: 2
under 914 m: 41 (2012)
Heliports: 510 (2012)
Pipelines: gas 2,139 km; refined products 864 km
(2010)
Railways: total: 3,381 km
country comparison to the world: 51
standard gauge: 3,381 km 1.435-m gauge (1,843
km electrified) (2008)
Roadways: total: 103,029 km
country comparison to the world: 40 ’
paved: 80,642 km (includes 3,367 km of
expressways)
unpaved: 22,387 km (2008)
Waterways: 1,600 km (most navigable only by
small craft) (2011)
country comparison to the world: 50
Merchant marine: total: 786
country comparison to the world: 14
by type: bulk carrier 191, cargo 235, carrier 8,
chemical tanker 130, container 72, liquefied gas
44, passenger 5, passenger/cargo 15, petroleum
tanker 55, refrigerated cargo 15, roll on/reil off 10,
vehicle carrier 6
foreign-owned: 31 (China 6, France 2, Japan 14,
Taiwan 1, US 8)
registered in other countries: 457 (Bahamas 1,
Cambodia 10, Ghana 1, Honduras 6, Hong Kong
3, Indonesia 2, Kiribati 1, Liberia 2, Malta 2,
Marshall Islands 41, North Korea 1, Panama 373,
Philippines 1, Russia 1, Singapore 3, Tuvalu 1,
unknown 8) (2010)
Ports and terminals: Incheon (Inch''on), Pohang
(P’ohang), Busan (Pusan), Ulsan, Yeosu (Yosu)','a6e316a8cb7f9313f20c225f02c387df63ce5d27590c168d12cc7fe221416588','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('875344f4c0174b7c3d6cc0c1ee65f42dbacd33d36a3202b202a005b4413d4897',2025,'RS','Serbia','transportation',931,'Airports: 8 (2012)
country comparison to the world: 160
Airports—with paved runways: total: 4
2,438 to 3,047 m: 1
1,524 to 2,437 m: 1
under 914 m: 2 (2012):
Airports—with unpaved runways: total: 4
under 914 m: 4 (2012)
Heliports: 2 (2012)
Railways: coral: 430 km
country comparison to the world: 114
August 1990. Following several weeks of aerial
bombardment, a US-led, UN coalition began a
ground assault on 23 February 1991 that liberated
Kuwait in four days. Kuwait spent more than $5
billion to repair oil infrastructure damaged during
1990-91. The AL-SABAH family has ruled since
returning to`power in 1991 and reestablished
an elected legislature that in recent years has
become increasingly assertive. The country wit-
nessed the historic election in May 2009 of four
women to its National Assembly. Amid the 2010-
11 uprisings and protests across the Arab world,
stateless Arabs, known as bidoon, staged small
protests in February and March 2011 demanding
citizenship, jobs, and other benefits available to
Kuwaiti nationals. Youth activist groups—sup-
ported by opposition legislators and the prime
munistet’s rivals within the ruling family—trallied
repeatedly in 2011 for an end to corruption and
the ouster of the prime minister and his cabinet.
Opposition legislators forced the prime minister
to resign in late 2011. In October-December
2012, Kuwait witnessed unprecedented protests
in response to the Amir’s changes to the electoral
law by decree reducing the number of votes per
standard gauge: 430 km 1.435-m gauge (2007)
Roadways: total: 1,964 km
country comparison to the world: 175
paved: 1,706 km
unpaved: 258 km (2009)
Military branches: Kosovo Security Force (FSK)
(2010)
Manpower fit for military service: males age
16-49: 430,926
females age 16-49: 389,614 (2010 est.)
Airports: 30 (2012)
country comparison to the world: 115
Airports—with paved runways: total: 11
over 3,047 m: 2
2,438 to 3,047 m: 3
1,524 to 2,437 m:3
914 to 1,523 m: 3 (2012)
Airports—with unpaved runways: total: 19
1,524 to 2,437 m: 1
914 to 1,523 m: 10
under 914 m: 8 (2012)
Heliports: 2 (2012)
Railways: total:3,379 km
country comparison to the world: 52
standard gauge: 3,379 km 1.435-m gauge (1,196
km electrified) (2006)
Roadways: total: 41,913 km
country comparison to the world: 86
paved: 26,007 km
unpaved: 15,906 km (2007)
Waterways: 587 km (primarily on the Danube
and Sava rivers) (2009)
country comparison to the world: 81','f06e22c0dbf3006a7d9aadd5dbbdda85c7ea986263ba1f50fe8886457b50295f','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0ab54ff50b8bab98b30ccedc6e71e67a043c59b9da8371e8c0983a932825312f',2025,'KW','Kuwait','transportation',937,'Airports: 7 (2012)
country comparison to the world: 168
Airports—with paved runways: total: 4
over 3,047 m: 1
2,438 to 3,047 m: 2
1,524 to 2,437 m: 1 (2012)
Alrports—with unpaved runways: total: 3
1,524 to 2,437 m: 1 i
under 914 m: 2 (2012)
Heliports: 4 (2012)
Pipelines: gas 269 km; oil 540 km; refined prod-
ucts 57 km (2010)
Roadways: total: 5,749 km
country comparison to the world: 150
paved: 4,887 km
unpaved: 862 km (2004)
Merchant marine: total: 34
country comparison to the world: 82
by type: bulk carrier 2, carrier 3, container 6, lique-
fied gas 4, petroleum tanker 19
registered in other countries: 45 (Bahamas 1,
Bahrain 5, Comoros 1, Libya 1, Malta 3, Marshall
Islands 2, Panama 12, Qatar 6, Saudi Arabia 4,
UAE 10) (2010)
Ports and terminais: Ash Shu’aybah, Ash Shu-
waykh, Az Zawr (Mina’ Sa''ud), Mina’ ‘Abd Allah,
Mina’ al Ahmadi','eaa6d84f4ddfd2a00c461d703d28509325efa060da4ecd1a75172a05088cc906','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4340440438299f44a4e95cfc20bbcefcd5420c408ee44911dd7e3eee67d36186',2025,'KG','Kyrgyzstan','transportation',948,'Airports: 28 (2012)
`
410
THE CIA WORLD FACTBOOK
country comparison to the world: 122
Airports—with paved runways: total: 18
over 3,047 m: 1
2,438 to 3,047 m: 3
1,524 to 2,437 m: 11
under 914 m: 3 (2012)
Airports—with unpaved runways: total: 10
1,524 to 2,437 m: 1
914 to 1,523 m: 1
under 914 m: 8 (2012)
Pipelines: gas 480 km; oil 16 km (2010)
Railways: total:470 km
country comparison to the world: 112
broad gauge: 470 km 1.520-m gauge (2008)
Roadways: total: 34,000 km (2003)
country comparison to the world: 95
Waterways: 600 km (2010).
country comparison to the world: 80
Ports and terminals: Balykchy (Ysyk-Kol or
Rybach’ye)
Airports: 42 (2012)
country comparison to the world: 103
Airports—with paved runways: coral: 9
2,438 to 3,047 m:3
1,524 to 2,437 m: 3
914 to 1,523 m: 3 (2012)
Airports—with unpaved runways: rotal: 33
1524 to 2,437 m:2
914 to 1,523 m: 9
under 914 m: 22 (2012)
Pipelines: refined products 540 km (2010)
Roadways: total: 39,568 km
country comparison to the world: ©
paved: 530 km
unpaved: 39,038 km (2007)
Waterways: 4.600 km (primanly on the Mekong
River and its mbutanes: 2.900 additonal km are
intermittently navigable by craft drawing less than
0.5 m) (2012)
country comparison to the world: 24
Military branches: Lao People’s Armed Forces
(LPAF): Lao People’s Army (LPA; includes Raves-
ine Force), Air Force (2011)
Military service age and obligation: 18 years
of age for compulsory or voluntary military ser-
vice; conscript service obligation—mimnimum
18-months (2012)
413
Manpower available for military service:
males age 16-49: 1,574,362
females age 16-49: 1,607,856 (2010 est.)
Manpower fit for military service: males age
16-49: 1,111,629
females age 16-49: 1,190,035 (2010 est.)
Manpower reaching militarily significant age
annually: male: 71,400
female: 73,038 (2010 est.)
Military expenditures: 0.2% of GDP (2012)
country comparison to the world: 168
Military—note: serving one of the world’s least
developed countries, the Lao People’s Armed
Forces (LPAF) is small, poorly funded, and inef-
fectively resourced; its mission focus is border and
THE CIA WORLD FACTBOOK
internal security, primarily in countering ethnic
Hmong insurgent groups; together with the Lao
People’s Revolutionary Party and the government,
the Lao People’s Army (LPA) is the third pillar of
state machinery, and as such is expected to sup-
press political and civil unrest and similar national
emergencies, but the LPA also has upgraded skills
to respond to avian influenza outbreaks; there is
no perceived external threat to the state and the
LPA maintains strong ties with the neighboring
Vietnamese military (2008)','1d642c72ca0039df7e1878e5d7eb342cedfcf9e9b3c76506d78f5cf7fddca004','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0935e31683f1b8a5679327e73099bcc38b6b6edc6689eca3350f519bda6a2a7b',2025,'LV','Latvia','transportation',962,'Airports: 42 (2012)
country comparison to the world: 102
Airports—with paved runways: total: 19
over 3,047 m: 1
2,438 to 3,047 m:3
1,524 to 2,437 m: 5
914 to 1,523 m: 3
under 914 m: 7 (2012)
Airports—with unpaved runways: total: 23
under 914 m: 23 (2012)
Heliports: 1 (2012)
Pipelines: gas 948 km; refined products 415 km
(2010)
Railways: total: 2,239 km
country comparison to the world: 67
broad gauge: 2,206 km 1.520-m gauge
narrow gauge: 33 km 0.750-m gauge (2008)
Roadways: total: 73,074 km
country comparison to the world: 63
paved: 14,459 km
unpaved: 58,615 km (2010)
Waterways: 300 km (navigable year round) (2010)
country comparison to the world: 93
Merchant marine: total: 11
country comparison to the world: 113
by type: cargo 3, chemical tanker 1, passenger/
cargo 4, petroleum tanker 2, roll on/roll off 1
foreign-owned: 3 (Estonia 3)
registered in other countries: 79 (Antigua and Bar-
buda 16, Belize 9, Comoros 2, Dominica 2, Georgia
1, Liberia 5, Malta 8, Marshall Islands 19, Russia 2,
Saint Vincent and the Grenadines 15) (2010)
Ports and terminals: Riga, Ventspils','36ad9b180b673152b5447c97740836a080994a90a34c6a79574ffab667c488de','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8bfb7169b2ce21fa6d452e6c0065f65b17047dcb4cfafa91f61aa4b272557143',2025,'LB','Lebanon','transportation',970,'Airports: 7 (2012)
country comparison to the world: 169
Airports—with paved runways: total: 5
over 3,047 m: 1
2,438 to 3,047 m: 2
1,524 to 2,437 m: 1
under 914 m: 1 (2012)
Airports—with unpaved runways: coral: 2
914 to 1,523 m: 2 (2012)
Pipelines: gas 102 km (2010)
Railways: total: 401 km
country comparison to the world: 116
standard gauge: 319 km 1.435-m gauge
narrow gauge: 82 km 1.050-m gauge
note: rail system unusable because of the damage
done during fighting in the 1980s and in 2006
(2008)
Roadways: total: 6,970 km (includes 170 km of
expressways) (2005)
country comparison to the world: 148
Merchant marine: total: 29
country comparison to the world: 85
by type: bulk carrier 4, cargo 7, carrier 17, vehicle
carrier l
foreign-owned: 2 (Syria 2)
registered in other countries: 34 (Barbados 2,
Cambodia 5, Comoros 2, Egypt 1, Georgia 1, Hon-
duras 2, Liberia 1, Malta 6, Moldova 1, Panama 2,
Saint Vincent and the Grenadines 2, Sierra Leone
2, Togo 6, unknown 1) (2010)
Ports and terminais: Beirut, Tripoli','1de52192ab5a12ad9f114705b025e712317c166dab882bbea6974af20c449943','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fbf31cb54426d2cb3932113909d0ede5913ab819e6ceca92aaf182178811bf11',2025,'LS','Lesotho','transportation',979,'Airports: 24 (2012)
country comparison to the world: 130
Airports—with paved runways: total: 3
over 3,047 m: 1
914 to 1,523 m: 1
under 914 m: 1 (2012)
Airports—with unpaved runways: total: 21
914 to 1,523 m: 5
under 914 m: 16 (2012)
Roadways: total: 7,091 km
country comparison to the world: 147
paved: 1,404 km
unpaved: 5,687 km (2003)','5b8980c5bf9f783c24873595a411e081c03728078ddab0caf858e1146ca61a26','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c377396a242a8103b9dcab1490b045ffc6a7891ff58eef62f5b9dc379907de69',2025,'LR','Liberia','transportation',989,'Airports: 29 (2012)
country comparison to the world: 117
Airports—with paved runways: total: 2
over 3,047 m: 1
1,524 to 2,437 m: 1 (2012)
Airports—with unpaved runways: total: 27
1,524 to 2,437 m:5
914 to 1,523 m: 8
under 914 m: 14 (2012)
Pipelines: oil 4 km (2010)
Railways: total: 429 km
country comparison to the world: 115
standard gauge: 345 km 1.435-m gauge
narrow gauge: 84 km 1.067-m gauge
note: most sections of the railways were inoperable
because of damage suffered during the civil wars
from 1980 to 2003, but many are being rebuilt
(2008)
Roadways: total: 10,600 km
country comparison to the world: 135
paved: 657 km
unpaved: 9,943 km (2000)
Merchant marine: total: 2,771
country comparison to the world: 2
by type: barge carrier 5, bulk carrier 662, cargo 143,
carrier 2, chemical tanker 248, combination ore/
oil 8, container 937, liquefied gas 92, passenger 2,
passenger/cargo 2, petroleum tanker 526, refriger-
ated cargo 102, roll on/roll off 5, specialized tanker
10, vehicle carrier 27
foreign-owned: 2,581 (Angola 1, Argentina 1,
Australia 1, Belgium 1, Bermuda 4, Brazil 20,
Canada 2, Chile 9, China 4, Croatia 1, Cyprus
9, Denmark 8, Egypt 3, Germany 1185, Gibral-
tar 5, Greece 505, Hong Kong 48, India 8, Indo-
nesia 4, Israel 34, Italy 47, Japan 110, Latvia 5,
Lebanon 1,Monaco 8, Netherlands 31, Nigeria
4, Norway 38, Poland 13, Qatar 5, Romania
3, Russia 109, Saudi Arabia 20, Singapore 22,
Slovenia 7, South Korea 2, Sweden 12, Switzer-
land 25, Syria 1, Taiwan 94, Turkey 16, UAE
37, UK 32, UK 22, Ukraine 10, Uruguay 1, US
53) (2010)
Ports and terminals: Buchanan, Monrovia','d08714f901f43418327ddfaf0e9678dcaacbdc56e760c30974742d6444802154','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('dbbd8681b0dbc6d80ca7d4c049847757ef2637c0d6350db5d32c47a1cf2bf3dc',2025,'LY','Libya','transportation',998,'Airports: 144 (2012)
country comparison to the world: 39
Airports—with paved runways: total: 64
over 3,047 m: 23
2,438 to 3,047 m:7
1524 to 2,437 m: 26
914 to 1,523 m: 7
under 914 m: 1 (2012)
Airports—with unpaved runways: total: 80 over
3,047 m: 4 a en i
2,438 to 3,047 m: 3
1,524 to 2,437 m: 13
914 to 1,523 m: 40
under 914 m: 20 (2012)
Heliports: 2 (2012)
Pipelines: condensate 776 km; gas 3,216 km; oil
6,960 km (2010)
Roadways: total: 100,024 km
country comparison to the world: 41
paved: 57,214 km
unpaved: 42,810 km (2003)
Merchant marine: total: 23
country comparison to the world: 91
by type: cargo 2, chemical tanker 4, liquefied gas 3,
petroleum tanker 13, roll on/roll off 1
foreign-owned: 2 (Kuwait 1, Norway 1)
registered in other countries: 6 (Hong Kong 1,
Malta 5) (2010)
Ports and terminals: Az Zawiyah, Marsa al
Burayqah (Marsa el Brega), Ra''s Lanuf, Tripoli','c3ccd75bcd547c7fcf3170795a262808c4c3b257cf3491775ee7d2e6fe148e3d','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1dea1a2c853a77e025bf012f0a57b63c81569cc8a79db1ee73274b41cb173531',2025,'LI','Liechtenstein','transportation',1007,'Pipelines: gas 20 km (2010)
Railways: total: 9 km
country comparison to the world: 134
standard gauge: 9 km 1.435-m gauge (electrified)
note: belongs to the Austrian Railway System con-
necting Austria and Switzerland (2008)
Roadways: total: 380 km
country comparison to the world: 201
paved: 380 km (2010)
Waterways: 28 km (2010)
country comparison to the world: 106.','a6d3cf447883f67d89679ffc71bf7452031cea97f954b65e91827164f6823b22','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('19b2e5c580c815bf9a807efd33cf62cc5387e0924d0da23eaf349b3c86029ee0',2025,'LT','Lithuania','transportation',1014,'Airports: 81 (2012)
country comparison to the world: 70
Airports—with paved runways: total: 26 over
3,047 m: 3
2,438 to 3,047 m: 1
1,524 to 2,437 m:7
914 to 1,523 m: 2
under 914 m: 13 (2012)
Airporis—with unpaved runways: roral:55
over 3,047 m: 1
914 to 1,523 m: 2
under 914 m: 52 (2012)
Pipelines: gas 1,695 km; refined products 114 km
(2010)
Railways: total: 1,767 km
country comparison to the world: 76
broad gauge: 1,745 km 1.524-m gauge (122 km
electrified)
standard gauge: 22 km 1.435-m gauge (2011)
Roadways: total: 82,131 km
country comparison to the world: 56
paved: 72,048 km (includes 309 km of expressways)
unpaved: 10,083 km (2010)
Waterways: 441 km (navigable year round)
(2007)
country comparison to the world: 87
Merchant marine: coral: 38
country comparison to the world: 78
by type: cargo 20, container 1, passenger/cargo 6,
refrigerated cargo 9, roll on/roll off 2
foreign-owned: 8 (Denmark 8)
registered in other countries: 22 (Antigua and
Barbuda 3, Belize 1, Comoros 1, Cook Islands 1,
Norway 1, Panama 3, Saint Vincent and the Gren-
adines 9, unknown 3) (2010)
Ports and terminals: Klaipeda
Oil terminals: Butinge oil terminal','daa15cb0124058ea1e2ef7d4422dbe821e80541b58b18c361b47dbdef213c370','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fcd4fd117821a9fc53016358562aa8e79422ebdb029a6f75849557bacc3595ab',2025,'LU','Luxembourg','transportation',1019,'Airports: 2 (2012)
country comparison to the world: 202
Airports—with paved runways: total: 1
over 3,047 m: 1 (2012)
Airports—with unpaved runways: total: !
under 914 m: 1 (2012)
Heliports: 1 (2012)
Pipelines: gas 142 km; refined products 27 km
(2010)
Railways: total: 275 km
country comparison to the world: 123
standard gauge: 275 km 1.435-m gauge (243 km
electrified) (2008)
Roadways: total: 5,227 km
country comparison to the world: 152
paved: 5,227 km (includes 147 km of expressways)
(2008)
Waterways: 37 km (on Moselle River) (2010)
country comparison to the world: 105
Merchant marine: total: 49
country comparison to the world: 71
by type: bulk carrier 2, cargo 3, chemical tanker
20, container 10, petroleum tanker 2, roll on/roll
off 12
foreign-owned: 48 (Belgium 11, Denmark 1,
France 15, Germany 9, Japan 3, Netherlands 3,
Switzerland 1, UK 5)
registered in other countries: 18 (Italy 14, Malta
3, Panama 1) (2010)
Ports and terminals: Mertert
Airports: 1 (2012)
country comparison to the world: 224
Airports—with paved runways: total: |
over 3,047 m: 1 (2012)
Heliports: 2 (2012)
Roadways: total: 413 km
country comparison to the world: 199
paved: 413 km (2009)
Ports and terminals: Macau','b9f38bd5ed1bc5f24c5be48c9c2d539a24e6a47fd7089acf2b985fd080e44c54','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f6b583fc6c35207ebc64400574efe90f2f0d5625b1e351ca28dbe86d85504b89',2025,'MG','Madagascar','transportation',1032,'Airports: 82 (2012)
country comparison to the world: 68
Airports—with paved runways: total: 26
over 3,047 m: I
2,438 to 3,047 m: 2
1,524 to 2,437 m: 6
914 to 1,523 m: 16
under 914 m: 1 (2012)
Airports—with unpaved runways: total: 56
1,524 to 2,437 m:2
914 to 1,523 m: 36
under 914 m: 18 (2012)
Railways: coral: 854 km
country comparison to the world: 97
narrow gauge: 854 km 1.000-m gauge (2008)
Roadways: total: 65,663 km
country comparison to the world: 68
paved: 7,617 km
unpaved: 58,046 km (2003)
Waterways: 600 km (432 km navigable) (2011)
country comparison to the world: 79
Merchant marine: total: 1
country comparison.o the world: 152
by type: cargo 1
registered in other countries: 1 (unknown 1)
(2010)
Ports and terminals: Antsiranana (Diego
Suarez), Mahajanga, Toamasina, Toliara (Tulear)','175cf288043caf96aa957d6f8d8f38b0827cc9c8dcb9518798fbe9a646ae6f7a','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a19abe9445acc4a0057f1279e0a2eddeebc32bab05d77056f56828081f4dd5e7',2025,'MW','Malawi','transportation',1043,'Airports: 31 (2012)
country comparison to the world: 114
Airports—with paved runways: total: 7
over 3,047 m: 1
1,524 to 2,437 m: 2
914 to 1,523 m: 4 (2012)
Airports—with unpaved runways: total: 24
1,524 to 2,437 m: 1
914 to 1,523 m: 12
under 914 m: 11 (2012)
Railways: total: 797 km
country comparison to the world: 99
narrow gauge: 797 km 1.067-m gauge (2008)
Roadways: total: 15,451 km
country comparison to the world: 120
paved: 6,956 km
unpaved: 8,495 km (2003)
Waterways: 700 km (on Lake Nyasa [Lake
Malawi] and Shire River) (2010)
country comparison to the world: 76
Ports and terminals: Chipoka, Monkey Bay,
Nkhata Bay, Nkhotakota, Chilumba','1343f5a52859c160415bdd21f5b2a41d9aa19f6eca501d07dbd4af40b37f35a7','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('46459ddafa749c7b3db88e6cfaaf605f4a332085ca03c2c8f7902d01ce35c5d7',2025,'MY','Malaysia','transportation',1054,'_ Airports: 117-(2012)
457
country comparison to the world: 49
Airports—with paved runways: total: 39
over 3,047 m: 8
2,438 to 3,047 m:9
1524 to 2,437 m:6
914 to 1,523 m: 8
under 914 m: 8 (2012)
Airports—with unpaved runways: total: 78
914 to 1,523 m:7
under 914 m: 71 (2012)
Heliports: 3 (2012)
Pipelines: condensate 3 km; gas 1,757 km; liquid
petroleum gas 155 km; oil 30 km; refined products
114 km (2010)
Railways: total: 1,849 km
country comparison to the world: 75
standard gauge: 57 km 1.435-m gauge (57 km
electrified)
narrow gauge: 1,792 km 1.000-m gauge (150 km
electrified) (2008)
Roadways: total:98,721 km
country comparison to the world: 42
paved: 80,280 km (includes 1,821 km of
expressways)
unpaved: 18,441 km (2004)
Waterways: 7,200 km (Peninsular Malaysia 3,200
km; Sabah 1,500 km; Sarawak 2,500 km) (2011)
country comparison to the world: 20
Merchant marine: total: 315
country comparison to the world: 31
by type: bulk carrier 11, cargo 83, carrier 2, chemi-
cal tanker 47, container 41, liquefied gas 34, pas-
senger/cargo 4, petroleum tanker 86, roll on/roll off
2, vehicle carrier 5
foreign-owned: 26 (Denmark 1, Hong Kong 8,
Japan 2, Russia 2,‘Singapore 13)
registered in other countries; 82 (Bahamas 13,
India 1, Indonesia 1, Isle of Man 6, Malta 1, Mar-
shall Islands 11, Panama 12, Papua New Guinea 1,
Philippines 1, Saint Kitts and Nevis 1, Singapore
27, Thailand 3, US 2, unknown 2) (2010)
Ports and terminals: Bintulu, Johor Bahru,
George Town (Penang), Port Kelang (Port Klang),
Tanjung Pelepas
Transportation—note: the International Mari-
time Bureau reports that the territorial and off-
shore waters in the Strait of Malacca and South
China Sea remain high risk for piracy and armed
robbery against ships; in the past, commercial
vessels have been attacked and hijacked both at
458
THE CIA WORLD FACTBOOK
anchor and while underway; hijacked vessels are
often disguised and cargo diverted to ports in East
Asia; crews have been murdered or cast adrift;
increased naval patrols since 2005 in the Strait of
Malacca resulted in no reported incidents in 2010','704a69315b6e6c524da1b3c7a67925da957520efbb1990858d61d84cd8995fe7','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('46cd2661b3478269ef3050c562f3668fe3af5dee054e8ebd020831027f22a65b',2025,'MV','Maldives','transportation',1062,'Airports: 6 (2012)
country comparison to the world: 172
Airports—with paved runways: total: 4
over 3,047 m: 1
2,438 to 3,047 m:1
1,524 to 2,437 m: 1
914 to 1,523 m: 1 (2012)
Airports—with unpaved runways: total: 2
461
914 to 1,523 m: 2 (2012)
Roadways: total: 88 km
country comparison to the world: 215
'' paved roads: 88 km—60 km in Male; 14 km on
Addu Atolis; 14 km on Laamu
note: island roads are mainly, compacted coral
(2013)
Merchant marine: total: 18
country comparison to the world: 97
by type: bulk carrier 1, cargo 14, petroleum tanker
1, refrigerated cargo 2
foreign-owned: 4 (Singapore 4)
registered in other countries: 4 (Panama 2,
Tuvalu 1, unknown 1) (2010)
Ports and terminals: Male
~
{Taoudennt >`.
4 e N,
SIA','633fb42041cf4d4ce92ff033d2c4cfefcd41a0dabe6bc2c3087f1f00bd9a7da2','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b1025d1ecd755af0954e3d1576a4675198a6cc397a586579c325ad7fb7ee663b',2025,'MR','Mauritania','transportation',1063,'H A RSA
|
‘gees
a
ee eee ee |
v
Mopti,
* aKayes
Kas
A T BAÑAKO^ i =
A * sammie ‘Saale G ý
2 A swesgo®/ a >
` < T
mian cael
Airports: 28 (2012)
country comparison to the world: 121
Airports—with paved runways: coral: 10
2,438 to 3,047 m: 5
1,524 to 2,437 m: 5 (2012)
Airports—with unpaved runways: total: 18
2,438 to 3,047 m:1
1,524 to 2,437 m: 7
914 to 1,523 m: 8
under 914 m: 2 (2012)
Railways: 728 km
standard gauge: 728 km1.435-mgauge (2008)
Roadwoys: total: 11,066 km
country comparison to the world: 133
paved: 2,966 km
unpaved: 8,100 km(2006)
Waterways: (some navigation is possible on the
Senegal River) (2011)
Ports and terminals: Nouadhibou, Nouakchott
Agee dans aay
U n
AUR Are rt Jara
@PORT LOUIS
Centre*®
de Fiacq
a Quatre Bomes','6c9a10d19e8a66ad569aac57b2f1ff4e4c949cbac442c86539c689e7fd0cb827','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('56ee40184dd07d6ba9b66273173c58e9b44da6354214de2df8764d68a1f2b30b',2025,'ML','Mali','transportation',1072,'Airports: 21 (2012)
country comparison to the world: 135
Airports—with paved runways: total: 8
2,438 to 3,047 m:5
1524 to 2,437 m: 2
914 to 1,523 m: 1 (2012)
Airports—with unpaved runways: total: 13
1524 to 2,437 m: 4
914 to 1,523 m: 6
under 914 m: 3 (2012)
Railways: total: 593 km
country comparison to the world: 109 narrow
gauge: 593 km 1.000-m gauge (2008)
Roadways: total: 18,912 km
country comparison to the world: 113
paved: 3,597 km
unpaved: 15,315 km (2004)
Waterways: 1,800 km (downstream of Koulikoro:
low water levels on the River Niger cause problems
in dry years; in the months before the rainy season
the river is not navigable by commercial vessels)
(2011)
country comparison to the world: 44
Ports and terminals: Koulikoro','705a92d1f942c34bf22512c9470c6d90c56f62ae5dfe86fde5bf1f2cb81ada44','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('485d5a362912ffcc559eb8e4a3dd992b90e3e78e15c313799b7dcd1ee5a73921',2025,'MT','Malta','transportation',1081,'Airports: 1 (2012)
country comparison to the world: 226
Airports—with paved runways: total: 1
over 3,047 m: 1 (2012)
Heliports: 2 (2012)
Roadways: total: 3,096 km
country comparison to the world: 164
paved: 2,710 km
unpaved: 386 km (2005)
Merchant marine: total: 1,650
country comparison to the world: 4
by type: bulk carrier 544, cargo 351, carrier 1, chemi-
cal tanker 324, container 117, liquefied gas 36, pas-
senger 50, passenger/cargo 18, petroleum tanker 160,
Cani
refrigerated cargo 7, roll on/roll off 21, specialized
tanker 2, vehicle carrier 18
foreign-owned: 1,437 (Angola 7, Azerbaijan 1, Bel-
gium 7, Bermuda 15, Bulgaria 8, Canada 5, China 6,
Croatia 6, Cyprus 32, Denmark 34, Egypt 1, Estonia
16, Finland 3, France 8, Germany 135, Greece 469,
Hong Kong 4, India 3, Iran 48, Ireland 4, Israel 3,
ltaly 45, Japan 5, Kuwait 3, Latvia 8, Lebanon 6,
Libya 5, Luxembourg 3, Malaysia 1, Monaco 3, Neth-
erlands 3, Norway 96, Oman 5, Poland 21, Portugal
3, Romania 7, Russia 45, Saudi Arabia 2, Singapore
4, Slovenia 4, South Korea 2, Spain 8, Sweden 1,
Switzerland 20, Syria 4, Turkey 233, UAE 1, UK 21,
Ukraine 29, US 34) i
registered in other countries: 2 (Panama 2)
(2010)
Ports and terminals: Marsaxlokk (Malta Free-
port), Valletta','5a68288e33b6bbd4a9e46ef4250f140b65be42a674d171c4f07bd30b819d3fe0','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('670a1848bcb274f37866fe3e33c45d32a2815732d7d7a413856cff071f6a4bd9',2025,'MH','Marshall Islands','transportation',1091,'Airports: 15 ( 2012)
country comparison to the world: 147
Airports—with paved runways: total: 4
1524 to 2,437 m:3
914 to 1,523 m: 1 (2012)
Airports—with unpaved runways: total: 11
914 to 1,523 m: 10
under 914 m: 1 (2012)
Roadways: total: 2,028 km (includes 75 km of
expressways) (2007)
country comparison to the world: 174
Merchant marine: total: 1,593
country comparison to the world: 7
by type: barge carrier 1, bulk carrier 524, cargo
65, carrier 1, chemical tanker 351, container 226,
liquefied gas 88, passenger 7, passenger/cargo 1,
petroleum tanker 297, refrigerated cargo 13, roll
6n/roll off 9, vehicle carrier 10
foreign-owned: 1,468 (Belgium 1, Bermuda 35,
Brazil 1, Canada 8, China 14, Croatia 12, Cyprus
40, Denmark 7, Egypt 1, France 7, Germany 248,
Greece 408, Hong Kong 3, India 10, Indonesia
1, Iraq 2, Ireland 6, Italy 1, Japan 59, Jersey 11,
Kuwait 2, Latvia 19, Malaysia 11, Mexico 2,
Monaco 30, Netherlands 21, Norway 75, Pakistan
1, Qatar 29, Romania 2, Russia 5, Singapore 30,
Slovenia 6, South Korea 41, Sweden 1, Switzer-
land 12, Taiwan 8, Turkey 70, UAE 12, UK 12,
Ukraine 1, US 200) (2010)
Ports and terminals: Enitwetak Island, Kwaja-
lein, Majuro','7926794693af453433d4ca52a217a09f19fbe9fc18c41f87ab50972837542968','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0c3d8556dc2fdab83c672fb5a2986d337dae05859cd82cfc09f0265a75cf7612',2025,'MU','Mauritius','transportation',1101,'Airports: 5 (2012)
country comparison to the world: 183
independence early in the 19th century. The global
financial crisis beginning in late 2008 caused a
massive economic downturn the following year,
although growth returned quickly in 2010. Ongo-
ing economic and social concerns include low
real wages, underemployment for a large segment
of the population, inequitable income distribu-
tion, and few advancement opportunities for the
largely indigenous population in the impoverished
southern states. The elections held in 2000 marked
the first time since the 1910 Mexican Revolution
that an opposition candidate—Vicente FOX of the
National Action Party (PAN)—defeated the party
in government, the Institutional Revolutionary
Party (PRI). He was succeeded in 2006 by another
PAN candidate Felipe CALDERON, but the PRI
regained the presidency in 2012. Since 2007,
Airports—with paved runways: tocal:2
over 3,047 m: 1
914 to 1,523 m: 1 (2012)
Airports—with unpaved runways: oral: 3
914 to 1,523 m:2
under 914 m: 1 (2012)
Roadways: total: 2,066 km
country comparison to the world: 173
paved: 2,066 km (includes 75 km of expressways)
(2009)
Merchant marine: toral:4
country comparison to the world: 132
by type: passenger/cargo 2, petroleum tanker 1,
refrigerated cargo | (2010)
Ports and terminals: Port Louis','c54217530e1e0494a082c445da72a82a54324a223d6afeceaa215eacb3d89cea','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d3b8ed85e64a01720df9a41255baedacaab05180a2fce92be3f90daea866cc81',2025,'RO','Romania','transportation',1113,'Airports: 10 (2012)
country comparison to the world: 156
Airports—with paved runways: total: 5
over 3,047 m: 1
2,438 to 3,047 m: 2
1524 to 2,437 m: 2 (2012)
Airports—with unpaved runways: total: 5
1524 to 2,437 m: 1
under 914 m: 4 (2012)
Pipelines: gas 1,906 km (2010)
Railways: total: 1,190 km
country comparison to the world: 86
broad gauge: 1,176 km 1.520-m gauge
standard gauge: 14 km 1.435-m gauge (2008)
Roadways: total: 9,343 km
country comparison to the world: 137
paved: 8,810 km
unpaved: 533 km (2008)
Waterways: 558 km (in public use on Danube,
Dniester and Prut rivers) (2011) ’
country comparison to the world: 83
Merchant marine: total: 121
country comparison to the world: 45
by type: bulk carrier 7, cargo 88, carrier 1, chemi-
cal tanker 3, passenger/cargo 7, petroleum tanker
2, refrigerated cargo 1, roll on/roll off 11, special-
ized tanker 1
foreign-owned: 63 (Bulgaria 1, Denmark 1,
Egypt 5, Greece 1, Israel 2, Lebanon 1, Pakistan
1, Romania 2, Russia 5, Syria 5, Turkey 18, UK 3,
Ukraine 14, Yemen 4) (2010)
Airports: 53 (2012)
country comparison to the world: 88
Airports—with paved runways: total: 26
over 3,047 m: 4
2,438 to 3,047 m: 10
1,524 to 2,437 m: 11
under 914 m: 1 (2012)
Airports—with unpaved runways: total: 27
914 to 1523 m: 6
under 914 m: 21 (2012)
Heliports: 4 (2012)
Pipelines: gas 3,652 km; oil 2,424 km (2010)
Railways: total: 10,785 km
country comparison to the world: 21
broad gauge: 135 km 1.524-m gauge
standard gauge: 10,645 km 1.435-m gauge (4,002
km electrified)
narrow gauge: 5 km 1.000-m gauge (2010)
Roadways: total: 82,386 km (does not include
urban roads)
country comparison to the world: 55
paved: 71,154 km (includes 371 km of expressways)
unpaved: 1 1,232 km (2009)
Waterways: 1,731 km (includes 1,075 km on the
Danube River, 524 km on secondary branches, and
132 km on canals) (2010)
country comparison to the world: 46
Merchant marine: total: 5
country comparison to the world: 127
by type: cargo 1, passenger/cargo 2, petroleum
tanker 1, roll on/roll off |
foreign—owned: 1 (Russia 1)
registered in other countries: 31 (Georgia 7,
Liberia 3, Malta 7, Marshall Islands 2, Moldova
2, Panama 3, Russia 1, Saint Vincent and the
Grenadines 1, Sierra Leone 2, Tanzania 1, Togo 1,
unknown 1) (2010)
Ports and terminals: Braila, Constanta, Galati
(Galatz), Mancanului (Giurgiu), Midia, Tulcea
Airports: 1,218 (2012)
country comparison to the world: 5
Airports—with paved runways: total: 593
over 3,047 m: 54
2,438 to 3,047 m: 198
1,524 to 2,437 m: 125
914 to 1,523 m: 95
under 914 m: 121 (2012)
Airports—with unpaved runways:
total: 625
over 3,047 m: 3
2,438 to 3,047 m: 14
1,524 to 2,437 m: 69
914 to 1,523 m: 85
under 914 m: 454 (2012)
Heliports: 48 (2012)
Pipelines: condensate 122 km; gas 1 60,952 km;
liquid petroleum gas 127 km; oil 77,630 km; oil/
gas/water 38 km; refinea proaucts 13,658 km
(2U1U)
Railways: total: 87,157 km
country comparison to the world: 2
broad gauge: 86,200 km 1.520-m gauge (40,300
km electrified)
narrow gauge: 957 km 1.067-m gauge (on Sakha-
lin Island)
603
note: an additional 30,000 km of non-common
carrier lines serve industries (2006)
Roadways: total: 982,000 km
country comparison to the world: 7
paved: 776,000 km (includes 30,000 km of
expressways)
unpaved: 206,000 km
note: includes public, local, and departmental
roads (2009)
Waterways: 102,000 km (including 48,000 km
with guaranteed depth; the 72,000 km system in
European Russia links Baltic Sea, White Sea, Cas-
pian Sea, Sea of Azov, and Black Sea) (2009)
country comparison to the world: 2
Merchant marine: total: 1,143
country comparison to the world: 11
by type: bulk carrier 20, cargo 642, carrier 3, chem-
ical tanker 57, combination ore/oil 42, container
13, passenger 15, passenger/cargo 7, petroleum
tanker 244, refrigerated cargo 84, roll on/roll off
13, specialized tanker 3
foreign-owned: 155 (Belgium 4, Cyprus 13, Esto-
nia 1, Ireland 1, Italy 14, Latvia 2, Netherlands 2,
Romania 1, South Korea 1, Switzerland 3, Turkey
101, Ukraine 12)
registered in other countries: 439 (Antigua and
Barbuda 3, Belgium 1, Belize 30, Bulgaria 2, Cam-
bodia 50, Comoros 12, Cook Islands 1, Cyprus 46,
Dominica 3, Georgia 6, Hong Kong 1, Kiribati 1,
Liberia 109, Malaysia 2, Malta 45, Marshall Islands
5, Moldova 5, Mongolia 2, Panama 49, Romania
1, Saint Kitts and Nevis 13, Saint Vincent and the
Grenadines 11, Sierra Leone 7, Singapore 2, Spain
6, Vanuatu 7, unknown 19) (2010)
Ports and terminals: Kaliningrad, Kavkaz, Nak-
hodka, Novorossiysk, Primorsk, Saint Petersburg,
Vostochnyy','b09d2feef48d07e1992d1b198fbe4a0c8c3ecb0a19000c35b241eb7096bddfb3','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('549b6b19482d952c1b230ba7c63eded314222b0aacceb264ab734ba7ec4311a0',2025,'MC','Monaco','transportation',1120,'Heliports: 1 (2012)
Roadways: total:77 km
country comparison to the world: 217
paved: 77 km (2007)
Merchant marine: registered in other countries:
64 (Bahamas 8, Bermuda 2, Liberia 8, Malta 3,
Marshall Islands 30, Panama 11, Saint Vincent
and the Grenadines 2) (2010)
country comparison to the world: 63
Ports and terminals: Monaco','1ad533906dad385e176b5f1342ae0e0969ffc4db054c409a374d8dcdbb7c4c88','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('08f0e53f54aae5448e60d3cec4776e24fe30afe9428bf86c08bfe9fbc755c195',2025,'MN','Mongolia','transportation',1125,'Airports: 44 (2012)
country comparison to the world: 98
Airports—with paved runways: total: 15 over
3,047 m: 1
2,438 to 3,047 m: 11
1,524 to 2,437 m: 3 (2012)
Airports—with unpaved runways: total: 29 over
3,047 m: 2
2,438 to 3,047 m:3
1,524 to 2,437 m: 23
under 914 m: 1 (2012)
Heliports: 0 (2012)
Railways: total: 1,908 km
country comparison to the world: 73
broad gauge: 1,908 km 1.520-m gauge
note: the railway is 50 percent owned by the Rus-
sian State Railway (2010)
Roadways: total: 49,249 km
country comparison to the world: 79
paved: 3,015 km
unpaved: 46,234 km (2010)
Waterways: 580 km (the only waterway in opera-
tion is Lake Hovsgol) (135 kv); Selenge River
(270 kv) and Orhon River (175 kv) are naviga-
ble but carry little traffic; lakes and rivers freeze
in winter, they are open from May to September)
(2010)
country comparison to the world: 82
Merchant marine: total: 57
country comparison to the world: 68
by type: bulk carrier 21, cargo 25, chemical tanker
1, container 2, liquefied gas 2, passenger/cargo 2,
roll on/roll off 3, vehicle carrier 1
foreign-owned: 44 (Indonesia 2, Japan 2, North
Korea 1, Russia 2, Singapore 3, Ukraine I, Viet-
nam 33) (2010)','b3862305815b511b15bfb8f5b22d6bbe921e452d6e19f8052e70d580ac2ce7cc','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1603eecac36a65ca958b019dfed883139a82f805f592b792d07512ae0d65e7f6',2025,'ME','Montenegro','transportation',1134,'Airports: 5 (2012)
country comparison to the world: 182
Airports—with paved runways: total: 5
2,438 to 3,047 m: 2
1,524 to 2,437 m: 1
914 to 1,523 m: 1
under 914 m: 1 (2012)
Heliports: (2012)
Railways: total: 250 km
country comparison to the world: 124
standard gauge: 250 km 1.435-m gauge (169 km
electrified) (2007)
Roadways: total: 7,624 km
country comparison to the world: 145
paved: 5,097 km
unpaved: 2,527 km (2008)
Merchant marine: total: 2
country comparison to the world: 146
by type: cargo 1, passenger/cargo 1
registered in other countries: 4 (Bahamas 2, Hon-
duras 1, Slovakia 1) (2010)
Ports and terminals: Bar','fcc1d4ff57bb5c14d48c69821abd65ad054cf829a0f10b50ada3af77781ea26b','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('07b8932e9a267ac8e9381f3f8878d16260d233f4a7604357676f48486def9846',2025,'MS','Montserrat','transportation',1144,'Airports: 0 (2012)
country comparison to the world: 225
Airports—with paved runways: total: 1
under 914 m: 1 (2012)
Roadways: note: volcanic eruptions that began in
1995 destroyed most of the 227 km road system; a
new toad infrastructure has been built on the north
end of the island (2008)
Ports and terminals: Little Bay, Plymouth','c296241763e15b54752d84d94679c486f215fc0cc2298839767b0043d5919395','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('079379b6fefb3c66a81755e5e3c99978ca1729fb646c300c8f20253c9305995f',2025,'MA','Morocco','transportation',1153,'Airports: 56 (2012)
country comparison to the world: 85
Airports—with paved runways: oral: 31
over 3,047 m: 12
2.4328 to 3,047 m:7
1524 to 2,437 m:8
914 to 1523 m: 4 (2012)
Airports—with unpaved runways: total: 25
2.438 to 3,047 m: 2
1524 to 2,437 m:7
914 to 1,523 m: 11
under 914 m: 5 (2012)
Heliports: 0 (2012)
Pipelines: gas 830 km; oil 439 km (2010)
Railways: total: 2,067 km
country comparison to the world: 70
standard gauge: 2,067 km 1.435-m gauge (1,022
km electrified) (2008)
Roadways: coral: 58,256 km
country comparison to the world: 74
paved: 39,480 km (includes 866 km of expressways)
unpaved: 18,776 km (2006)
Merchant marine: coral: 26
country comparison to the world: 88 _
by type: cargo 1, chemical ranker 3, container 6,
passenger/cargo 14, roll on/roll off 2
foreign-owned: 14 (France 3, Germany 1, Iraly 1,
Spain 9)
registered in other countries: 4 (Gibraltar 4)
(2010)
Ports and terminais: Casablanca, Jorf Lasfar,
Mohammedia, Safi, Tangier','8059a5340225d9770fd1314072d01839074dec3b64fcad366b485e63abe90f3a','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2894ab0a286dfcb0c0c48f6c0536816d81c4bdf363928771d9d82a5945bd5a93',2025,'MZ','Mozambique','transportation',1163,'Airports: 100 (2012)
country comparison to the world: 56
Airports—with paved runways: total: 21 over
3,047 m: 1
2.438 to 3,047 m: 3
1524 to 2,437 m:9
914 to 1,523 m: 4
under 914 m: 4 (2012)
Airports—with unpaved runways; total: 79
2.438 to 3,047 m:1
1.524 to 2,437 m:9
914 to 1,523 m: 32
under 914 m: 37 (2012)
Pipelines: gas 918 km; refined products 278 km
(2010)
Railways: total: 4,787 km
country comparison to the world: 38
narrow gauge: 4,787 km 1.067-m gauge (2008)
Roadways: total: 30,331 km
country comparison to the world: 96
paved: 6,303 km
unpaved: 24,028 km (2000)
Waterways: 460 km (Zambezi River navigable to
Tete and along Cahora Bassa Lake) (2010)
country comparison to the world: 86
Merchant marine: total: 2
country comparison to the world: 144
by type: cargo 2
foreign-owned: 2 (Belgium 2) (2010)
Ports and terminals: Beira, Maputo, Nacala','216a047c04e038ebf83f28cbb8aaadf7d213d79313d4cabbfe47a9b7535f1117','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('98e52a90c09e924265aac937c1c08c651621d3a8aa270bf2b9c42c22d9644a9e',2025,'NA','Namibia','transportation',1170,'Airports: 112 (2012)
country comparison to the world: 51
Airports—with paved runways: total: 19
over 3,047 m: 4
2,438 to 3,047 m: 2
1524 to 2,437 m: 12
914 to 1,523 m: 1 (2012)
Airports—with unpaved runways: total: 93
1,524 to.2,437 m: 25
phosphite
Py Stockpew','8346613e0e47337745b58a411a9a1fd5918f0cd66f089a02fc2c0b33e36d1cc2','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('78acf0d173578541c2d7884bda45d4767b605e16d0e445de25fd942e63beb6b8',2025,'NR','Nauru','transportation',1177,'Airports: total: 1
country comparison to the world: 229
Airports—with paved runways: total: 1
1,524 to 2,437 m: 1 (2012)
Roadways: total: 24 km
country comparison to the world: 220
paved: 24 km (2002)
Ports and terminals: Nauru
Ports and terminals: none; offshore anchorage
o
=
P=','84b9adab2ca4b81409be7f6e50a90bfb32e38d06dcafa50a30ca67bdd1cfc025','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('159d1fcc209d8843a9854583a4566d82a7bc045ce01ccdfbee9f385c52824c74',2025,'NP','Nepal','transportation',1188,'Airports: 47 (2012)
country comparison to the world: 94
Airports—with paved runways: total: 11 over
3,047 m: 1
1524 to 2,437 m:3
914 to 1,523 m: 6
under 914 m: 1 (2012)
Airports—with unpaved runways: total: 36
1.524 to 2,437 m: 1
914 to 1,523 m:6
under 914 m: 29 (2012)
Railways: total:59 km
country comparison to the world: 130
517
i
narrow gauge: 59 km 0.762-m gauge (2008)
Roadways: total: 17,282 km
country comparison to the world: 118
paved: 10,142 km
unpaved: 7,140 km (2007)','1cbd71438626054c5a40b89c04ab28ccbcaa521a3a60c441b6ee7b674d6972d6','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bfcf506491a0daeedf79e442b827ad2955c63f9665139daff6c54523c6d0fcb6',2025,'NL','Netherlands','transportation',1198,'Airports: 27 (2012)
country comparison to the world: 124
Airports—with paved runways: total: 20 over
3,047 m: 2
2,438 to 3,047 m: 10
1,524 to 2,437 m:2
914 to 1,523 m:5
under 914 m: 1 (2012)
Airports—with unpaved runways: total:7
914 to 1,523 m:3
under 914 m: 4 (2012)
Heliports: 1 (2012)
Pipelines: gas 4,413 km; oil 365 km; refined prod-
ucts 716 km (2010)
Railways: total: 2,896 km
country comparison to the world: 58
standard gauge: 2,896 km 1.435-m gauge (2,195
km electrified) (2009)
Roadways: total: 136,827 km (includes 2,631 km
of expressways) (2008)
country comparison to the world: 35
Waterways: 6,214 km (navigable for ships of 50
tons) (2009)
country comparison to the world: 22
Merchant marine: total: 744
country comparison to the world: 15
by type: bulk carrier 4, cargo 514, carrier 15, chem-
ical tanker 56, container 67, liquefied gas 21, pas-
senger 17, passenger/cargo 14, petroleum tanker 4,
refrigerated cargo 10, roll on/roll off 19, specialized
tanker 3
foreign-owned: 196 (Australia 1, Bermuda 1,
Denmark 27, Finland 13, France 2, Germany 86,
Ireland 8, Italy 6, Japan 1, Norway 19, Sweden 12,
UAE 4, US 16)
registered in other countries: 233 (Antigua and
Barbuda 17, Bahamas 23, Belize 1, Canada 1,
Curacao 43, Cyprus 23, Germany 1, Gibraltar 34,
Italy 2, Liberia 31, Luxembourg 3, Malta 3, Mar-
shall Islands 21, Panama 6, Paraguay 1, Philippines
17, Russia 2, Saint Vincent and the Grenadines 1,
Singapore 1, UK 1, unknown 1) (2010)
Ports and terminals: Amsterdam, |Jmuiden,
Moerdijk, Rotterdam, Terneuzen, Vlissingen','a1e48a58f6d1bab0e62d0c4889f51c3ff21af9d693fa39e5ec8bb95a046a3982','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('eb4506dcbf256b79233cbc3a0194507e827fab90825dbcac6e7a9e025d094fc3',2025,'NC','New Caledonia','transportation',1204,'Airports: 25 (2012)
country comparison to the world: 128
Airports—with paved runways: total: 12
over 3,047 m: 1
914 to 1,523 m: 10
under 914 m: 1 (2012)
Airports—with unpaved runways: total: 13
914 to 1,523 m:5
under 914 m: 8 (2012)
Heliports: 8 (2012)
Roadways: total: 5,622 km (2006)
country comparison to the world: 151
Merchant marine: registered in other countries:
3 (France 3) (2010)
country comparison to the world: 137
Ports and terminals: Noumea','babc8f3d53d5c2676bd878a830226abf024de8def23687a10116eaa26ace9748','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('07e7b247897492b38cb4b1860dcda1c6d7800f64b6ea69857017de1213e45fe0',2025,'NZ','New Zealand','transportation',1210,'Airports: 122 (2012)
country comparison to the world: 47
Airports—with paved runways: total: 39
over 3,047 m:2
2,438 to 3,047 m: 1
1.524 to 2,437 m: 12
914 to 1,523 m: 23
under 914 m: 1 (2012)
Airports—with unpaved runways: total:83
1.524 to 2,437 m:3 |
914 to 1,523 m: 33
under 914 m: 47 (2012)
Pipelines: condensate 331 km; gas 1,838 km;
liquid petroleum gas 172 km; oil 288 km; refined
products 198 km (2010)
Railways: total: 4,128 km
country comparison to the world: 41
narrow gauge: 4,128 km 1.067-m gauge (506 km
electrified) (2008)
Roadways: total: 93,911 km
country comparison to the world: 46
paved: 61,879 km (includes 172 km of expressways)
unpaved; 32,032 km (2009)
Merchant marine: total: 15
country comparison to the world: 101 by type:
bulk carrier 3, cargo 3, chemical tanker 1, con-
tainer 1, passenger/cargo 5, petroleum tanker 2
foreign-owned: 7 (Germany 2, Hong Kong 1,
South Africa 1, Switzerland 2, UK 1)
registered in other countries: 5 (Antigua and Bar-
buda 2, Cook Islands 2, Samoa 1) (2010)
Ports and terminals: Auckland, Lyrtelton,
Manukau Harbor, Marsden Point, Tauranga,
Wellington. i','81a202753be9a1902e78f3350ced1259bad1c56d2a34e852fe8062b9b74cbcd3','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9965771d7d56d14c1ced4e27a74484aa7e4b6b853647983729e89ebda6e46b7d',2025,'NI','Nicaragua','transportation',1221,'Airports: 143 (2012)
country comparison to the world: 40
Alrports—with paved runways: total: 11
2,438 to 3,047 m: 3
1,524 to 2,437 m: 2
914 to 1,523 m: 2
under 914 m: 4 (2012)
Airports—with unpaved runways: total: 132
1,524 to 2,437 m: 1
914 to 1,523 m: 16
under 914 m: 115 (2012)
Pipelines: oil 54 km (2010)
Roadways: total: 19,137 km
country comparison to the world: 111
paved: 2,033 km
unpaved: 17,104 km (2009)
Waterways: 2,220 km (navigable waterways as
well as the use of the large Lake Managua and Lake
Nicaragua; rivers serve only the sparsely populated
eastern part of the country) (2011)
country comparison to the world: 40
Ports and terminals: Bluefields, Corinto','12624623e1880aa5e629c7fbe0f82447706d0a8b7a63d4d3059ec72d79ffec94','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6e84ca5d7bf722b9b12d09ea180b5516165807326c1a04df6e5e9cfbc605c957',2025,'NE','Niger','transportation',1227,'Airports: 30 (2012)
country comparison to the world: 116
Airporis—with paved runways: total: 10
2,438 to 3,047 m: 3
‘1.524 to 2,437 m: 6
914 to 1,523 m: 1 (2012)
Airports—with unpaved runways: total: 20
1524 to 2,437 m:3
914 to 1.523 m: 15
under 914 m: 2 (2012)
Roadways: total: 18,949 km
country comparison to the world: 112
paved: 3,912 km
unpaved: 15,037 km (2008)
Waterways: 300 km (the Niger, the only major
river, is navigable to Gaya between September and
March) (2012)-
country comparison to the world: 94','7154e60410984dfd7cd3e3f16c6eb49c67305522753d074dd70b3e3b20a15ad9','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9b231eacc31f785ea03d73e6e205bd4da5e398177406cd2aa5f48e9ccf9baeda',2025,'NG','Nigeria','transportation',1235,'Airports; 53 (2012)
country comparison to the world: 89
Alrports—with paved runways: total: 40
over 3,047 m: 10
2,438 to 3,047 m: 12
1524-to 2,437 m:9
914 to 1523 m:6
under 914 m: 3 (2012)
Airports—with unpaved runways: total: 13
1524 to 2,437 m:3
914 to 1,523 m: 8
under 914 m: 2 (2012)
Heliports: 5 (2012)
Pipelines: condensate 26 km; gas 2,756 km; liquid
petroleum gas 97 km; oil 3,441 km; refined prod-
ucts 4,090 km (2010) Sd
Railways: total:3,505 km.
country comparison to the world: 49
narrow gauge: 3,505 km 1.067-m gauge (2008)
Roadways: total: 193,200 km
country comparison to the world: 25
paved: 28,980 km
unpaved: 164,220 km (2004)
Waterwoys: 8,600 *km (Niger and Benue rivers
and smaller rivers and creeks) (2011)
country comparison to the world: 15
Merchant marine: total: 89
country comparison to the world: 54 by type:
. cargo 2, chemical tanker 28, liquefied gas 1, pas-
senger/cargo 1, petroleum tanker 56, specialized
tanker 1 foreign-owned: 3 (India 1, UK 2)
registered in other countries: 33 (Bahamas 2, Ber-
muda 11, Comoros 1, Italy 1, Liberia 4, North Korea
1, Panama 6, Seychelles 1, unknown 6) (2010)
Ports and terminals: Bonny Inshore Terminal,
Calabar, Lagos
Jransportation—note: the International Mari-
time Bureau reports the territorial and offshore
waters in the Niger Delta and Gulf of Guinea as
high risk for piracy and armed robbery against
ships; in 2012, 27 commercial vessels were boarded
or attacked compared with 10 attacks in 2011;
crews were robbed and stores or cargoes stolen;
Nigerian pirates have extended the range of their
attacks to as far away as Cote d''Ivoire','cab340f0c9754383d7fcf81de568bdf7ae95cc008ba35c897a97db2eec903b5b','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0f6cbb4f73a591f40e341012821d4e600e132df89972f7632fc539c95832cb3f',2025,'NU','Niue','transportation',1239,'Alrports: 1 (2012)
country comparison to the world: 227
Airports—with paved runways: total: 1
1,524 to 2,437 m: 1 (2012)
Roadways: total: 120 km
country comparison to the world: 213
paved: 120 km (2008)
Ports and terminals: Alofi
Military branches: no regular indigenous military
forces; Police Force
Military—note: defense is the responsibility of','1c0e27a2ee2f5f8355dedbe2beeff8efe477df6d48278650000f03e12a564b2e','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('620e3e09abb3c797b603d55687aafb555e922592d08066cd4939745737971758',2025,'NO','Norway','transportation',1254,'Airports: 98 (2012)
country comparison to the world: 60
Airports—with paved runways: total:67
over 3,047 m: 1
2,438 to 3,047 m: 12
1,524 to 2,437 m: 11
914 to 1,523 m: 19
under 914 m: 24 (2012)
Airports—with unpaved runways: total:31
914 to 1,523 m: 6
under 914 m: 25 (2012)
Heliports: 0 (2012)
Pipelines: condensate 31 km; gas 64 km (2010)
Railways: total: 4,169 km
country comparison to the world: 39 standard
gauge: 4,169 km 1.435-m gauge (2,784 km electri-
fied) (2009)
Roadways: total: 93,509 km (includes 253 km of
expressways) (2007)
country comparison to the world: 48 ''
Waterways: 1,577 km (2010)
country comparison to the world: 52
Merchant marine: total: 585
country comparison to the world: 19
by type: bulk carrier 55, cargo 105, carrier.5, chem-
ical tanker 121, combination ore/oil 12, liquefied
gas 47, passenger 3, passenger/cargo 121, petro-
leum tanker 54, refrigerated cargo 9, roll on/roll off
4, vehicle carrier 49
foreign-owned: 81 (Bermuda 24, Canada 1,
Cyprus 1, Denmark 7, France 5, Iceland 2, Lithu-
ania Saudi Arabia 3, Sweden 27, US 10)
registered in other countries: 974 (Antigua and
Barbuda 9, Bahamas 186, Barbados 38, Belize 2,
Bermuda 5, Brazil 3, Canada 4, Chile 1, Comoros
1, Cook Islands 8, Croatia 2, Curacao 2, Cyprus
14, Denmark 2, Dominica 1, Equatorial Guinea
1, Estonia 2, Faroe Islands 13, Gibraltar 46,
Hong Kong 48, Indonesia 3, Isle of Man 30,
Italy 6, Liberia 38, Libya 1, Malta 96, Marshall
Islands 75, Netherlands 19, Panama 81, Portugal
2, Saint Kitts and Nevis 3, Saint Vincent and
the Grenadines 13, Singapore 153, Spain 10,
Sweden 3, UK 32, US 17, Vanuatu 1, unknown
3) (2010)
Ports and terminalis: Bergen, Haugesund,
Maaloy, Mongstad, Narvik, Sture','87fe8b29f6a63e6d0cacdd6976df4cbfbfa9c3f2f0daef63f2df621876d79a04','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8b2f05d6bc9fe7d02737f4fd81256d27906f44ee0fd965df29e5736bd43222a4',2025,'OM','Oman','transportation',1261,'Airports: 130 (2012)
country comparison to the world: 43
Airports—with paved runways: total: 12
over 3,047 m: 6
2.438 to 3,047 m:5
914 to 1,523 m: 1 (2012)
Airports—with unpaved runways: total: 118
` over 3,047 m: 2
2.438 to 3,047 m:7
1,524 to 2,437 m: 51
914 to 1,523 m: 32
under 914 m: 26 (2012)
Heliports: 3 (2012)
Pipelines: condensate 107 km; gas 4,209 km; oil
3,558 km; refined products 263 km (2010)
Roadways: total: 45,985 km
552
THE CIA WORLD FACTBOOK
country comparison to the world: 80
paved: 29,685 km (includes 1,384 km of
expressways)
unpaved: 16,300 km (2011)
Merchant marine: total: 5
country comparison to the world: 128
by type: chemical tanker 1, passenger 1, passenger/
cargo 3
registered in other countries: 15 (Malta 5, Pan-
ama 10) (2010)
Ports and terminals: Mina’ Qabus, Salalah,
Suhar
Ports and terminals: Bangkok (Thailand), Hong
Kong (China), Kao-hsiung (Taiwan), Los Angeles
(US), Manila (Philippines), Pusan (South Korea),
San Francisco (US), Seattle (US), Shanghai
(China), Singaporé, Sydney (Australia), Vladi-
vostok (Russia), Wellington (NZ), Yokohama
(Japan)
Transportation—note: the Inside Passage offers
protected waters from southeast Alaska to Puget
Sound (Washington state); the International
Maritime Bureau reports the territorial waters of
littoral states and offshore waters in the South
China Sea as high risk for piracy and armed rob-
bery against ships; numerous commercial vessels
have been attacked and hijacked both at anchor
and while underway; hijacked vessels are often
disguised and cargoes stolen; crew and passengers
are often held for ransom, murdered, or cast adrift','6e197cebeab02259df7a7e19bb0c2f309692c1007751b678c066cf6e94375a65','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a5af45f2bbe4af6bd6e2111397cad67ffb1f7034a795cca4d469b98f8b51895d',2025,'PK','Pakistan','transportation',1272,'Alrports: 151 (2012)
country comparison to the world: 37
Airports—with paved runways: total: 107
over 3,047 m: 15
2,438 to 3,047 m: 20
1524 to 2,437 m: 42
914 to 1,523 m: 20
under 914 m: 10 (2012)
Airports—with unpaved runways: total: 44
1524 to 2.437 m:11
914 to 1,523 m:9
under 914 m: 24 (2012)
Heliports: 24 (2012)
Pipelines: gas 10,514 km; oil 2,013 km; refined
products 787 km (2010)
Railways: total: 7,791 km
country comparison to the world: 27
broad gauge: 7,479 km 1.676-m gauge (293 km
electrified)
narrow gauge: 312 km 1.000-m gauge (2007)
Roadways: total: 260,760 km
country comparison to the world: 20
paved: 180,910 km (includes 711
expressways)
unpaved: 79,850 km (2007)
Merchant marine: total: 11
country comparison to the world: 112
by type: bulk carrier 5, cargo 3, petroleum tanker 3
registered in other countries: 11 (Comoros 5,
Marshall Islands 1, Moldova 1, Panama 3, Saint
Kitts and Nevis 1) (2010)
Ports and terminals: Karachi, Port Muhammad
Bin Qasim','80b4c6805af92095c95ae8fdb6b0be46b66d9a3f0b6b3991c86abf390a5ff0cc','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b006b778f97acb825d370a3f7bdf0566bc446fde676741f553ebcad67bec3e95',2025,'PW','Palau','transportation',1279,'Airports: 3 (2012)
country comparison to the world: 194
Airports—with paved runways: total: 1
559
1524 to 2,437 m: 1 (2012)
Airports—with unpaved runways: total: 2
1,524 to 2,437 m: 2 (2012)
Ports and terminals: Koror
Ports and terminals: Adamstown (on Bounty Bay)
Military—note: defense is the responsibility of
the UK','05fd16e07f91f7aa2d5195388d3f3ef9e1668a306951d5d1acfee2c178aec15c','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c33186c024262e5c90c886f978ee04b6bdd1286b87f8fd2b5d50f97ea4a87e51',2025,'PA','Panama','transportation',1289,'Airports: 118 (2012)
country comparison to the world: 48
Airports—with paved runways: total: 55
over 3,047 m:1
2,438 to 3,047 m: 1
1,524 to 2,437 m:5
914 to 1,523 m: 18
under 914 m: 30 (2012)
Airports—with unpaved runways: total: 63
1,524 to 2,437 m: 1
914 to 1,523 m: 11
under 914 m: 51 (2012)
Heliports: 3 (2012)
Pipelines: oil 128 km (2010)
Railways: total: 76 km
country comparison to the world: 127
standard gauge: 76 km 1.435-m gauge (2008)
Roadways: total: 11,978 km
country comparison to the world: 130
paved: 4,300 km
unpaved: 7,678 km (2002)
Waterways: 800 km (includes the 82-km Panama
Canal that is being widened) (2011)
country comparison to the world: 73
Merchant marine: total: 6,413
country comparison to the world: 1
by type: barge carrier 1, bulk carrier 2,525, cargo
1,115, carrier 27, chemical tanker 588, combina-
tion ore/oil 1, container 742, liquefied gas 205,
passenger 42, passenger/cargo 51, petroleum
tanker 545, refrigerated cargo 191, roll on/roll off
87, specialized tanker 3, vehicle carrier 290
foreign-owned: 5,162 (Albania 4, Argentina 5,
Australia 4, Bahamas 6, Bangladesh 5, Belgium 1,
Bermuda 27, Brazil 3, Bulgaria 6, Burma 3, Canada
6, Chile 14, China 534, Colombia 2, Croatia 2,
Cuba 2, Cyprus 5, Denmark 41, Ecuador 3, Egypt
11, Finland 2, France 7, Gabon 1, Germany 24,
Gibraltar 1, Greece 379, Hong Kong 144, India
24, Indonesia 10, Iran 5, Ireland 1, Israel 1, Italy
25, Japan 2372, Jordan 11, Kuwait 12, Lebanon 2,
Lithuania 3, Luxembourg 1, Malaysia 12, Maldives
2, Malta 2, Mexico 5, Monaco 11, Netherlands 6,
Nigeria 6, Norway 81, Oman 10, Pakistan 3, Peru
9, Philippines 5, Portugal 10, Qatar 1, Romania 3,
Russia 49, Saudi Arabia 11, Singapore 92, South
Korea 373, Spain 30, Sweden 2, Switzerland 15,
Syria 34, Taiwan 328, Tanzania 2, Thailand 6, Tur-
key 62, UAE 83, UK 37, UK 5, Ukraine 8, US 90,
Venezuela 13, Vietnam 43, Yemen 4)
registered in other countries: 1 (Honduras 1)
(2010)
Ports and terminals: Balboa, Colon, Cristobal','634b3ba0ace90a0c5fe8a14cc1718c05414c0bdc2fd5d1023aa90bdf8f2ca3f0','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b38829fc9ab9fb279f51cac4a1cf5a13ffb44fa048d0ff9c6214b7c88b68c008',2025,'PG','Papua New Guinea','transportation',1299,'Airports: 562 (2012)
country comparison to the world: 12
Airports—with paved runways: total: 20
2,438 to 3,047 m: 2
1,524 to 2,437 m: 12
914 to 1,523 m: 5
under 914 m: 1 (2012)
Airports—with unpaved runways: total: 542
1524 to 2,437 m: 11
914 to 1,523 m: 55
under 914 m: 476 (2012)
Heliports: 2 (2012)
Pipelines: oil 195 km (2010)
Roadways: total: 9,349 km
country comparison to the world: 136
paved: 3,000 km
unpaved; 6,349 km (2011)
Waterways: 11,000 km (2011)
country comparison to the world: 12
Merchant marine: total: 31
country comparison to the world: 83
by type: bulk carrier 7, cargo 22, petroleum
tanker 2
foreign-owned: 8 (Germany 1, Malaysia 1, UAE
6) (2010) er j
Ports and terminals: Kimbe, Lae, Madang,
Rabaul, Wewak
Airports: 0 (2012)
country comparison to the world: 230
Airports—with paved runways: total: 1
1524 to 2,437 m: 1 (2012)
THE CIA WORLD FACTBOOK
Ports and terminals: small Chinese port facilities
on Woody Island and Duncan Island','e8c311703c43cdb41dd0be965248cceacf6f054382637a5433cd36e9afc5d778','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9501d6bd2e8dc85955d805d7474f9f47eec07163745b13302a69b8d74ddf4cb7',2025,'PY','Paraguay','transportation',1306,'Airports: 800 (2012)
country comparison to the world: 9
Airports—with paved runways: total: 15
over 3,047 m: 3
1,524 to 2,437 m:7
914 to 1,523 m: 5 (2012)
Airports—with unpaved runways: total: 785
1,524 to 2,437 m: 23
914 to 1,523 m: 289
under 914 m: 473 (2012)
Railways: total: 36 km
country comparison to the world: 132
standard gauge: 36 km 1.435-m gauge (2008)
Roadways: total: 29,500 km
country comparison to the world: 97
paved: 14,986 km
unpaved: 14,514 km (2000)
Waterways: 3,100 km (primarily on the Paraguay
and Paraná river systems) (2012)
country comparison to the world: 33
Merchant marine: total: 19
country comparison to the world: 96
by type: cargo 13, container 3, passenger 1, petro-
leum tanker 1, roll on/roll off 1
foreign-owned: 6 (Argentina 5, Netherlands 1)
(2010)
Ports and terminals: Asuncion, Villeta, San
Antonio, Encarnacion','26b31b2b6cb594e48aca92103814324b0fcbb63a12e39f7aa9ceae84454b71c5','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1f2adee5ea0868b5414440747e277d9e163904ff7f5c37b1e47a05a2623d977f',2025,'PE','Peru','transportation',1311,'Airports: 191 (2012)
country comparison to the world: 32
Airports—with paved runways: total: 58
over 3,047 m: 5
2,438 to 3,047 m: 21
1,524 to 2,437 m: 16
914 to 1,523 m: 12
under 914 m: 4 (2012)
Airports—with unpaved runways: total: 133
2,438 to 3,047 m:1
1,524 to 2,437 m: 19
914 to 1,523 m: 30
under 914 m: 83 (2012)
Heliports: 4 (2012)
Pipelines: extra heavy crude 533 km; gas 1,526
km; liquid petroleum gas 679 km; oil 1,033 km; `
refined products 15 km (2010)
Railways: total: 1,907 km
country comparison to the world: 74
standard gauge: 1,772 km 1.435-m gauge
narrow gauge: 135 km 0.914-m gauge (2012)
Roadways: total: 140,672 km (of which 18,698
km are paved)
country comparison to the world: 34
note: includes 24,593 km of national roads (of
which 14,748 km are paved), 24,235 km of depart-
mental roads (2,340 km paved), and 91,844 km of
local roads (1,611 km paved) (2012)
Waterways: 8,808 km (there are 8,600 km of nav-
igable tributaries on the Amazon system and 208
km on Lago Titicaca) (2011) country comparison
to the world: 14
Merchant marine: total: 22
country comparison to the world: 92
by type: cargo 2, chemical tanker §, liquefied gas 2,
petroleum tanker 13
foreign-owned: 8 (Chile 6, Ecuador 1, Spain 1)
registered in other countries; 9 (Panama 9)
(2010)
Ports and terminals: Callao, Iquitos, Mata-
rani, Paita, Pucallpa, Yurimaguas; note—Iquitos,
Pucallpa, and Yurimaguas are on the upper reaches
of the Amazon and its tributaries
Oil terminals: Conchan oil terminal, La Pampilla
oil terminal','3b5efcd9110f0050f761cb009046b00fbfdace6098df6c5788f9ccdec49e5a37','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('69ff99c552022f8251bd7f89e0b25b26ed6a761ef1cffcfaee37e02e9a4b30fa',2025,'PH','Philippines','transportation',1322,'Airports: 247 (2012)
country comparison to the world; 25
Airports—with paved runways: total: 83
over 3,047 m: 4
2,438 to 3,047 m: 8
1,524 to 2,437 m: 31
914 to 1,523 m: 31
under 914 m: 9 (2012)
Airports—with unpaved runways; total: 164
1,524 to 2,437 m:3
914 to 1,523 m: 60
under 914 m: 101 (2012)
Heliports: 2 (2012)
Pipelines: gas 7 km; oil 107 km; refined products
181 km (2010)
Railways: total: 995 km
country comparison to the world: 88
narrow gauge: 995 km 1.067-m gauge (484 km are
in operation) (2010)
Roadways: total: 213,151 km
country comparison to the world: 23
paved: 54,481 km
unpaved: 158,670 km (2009)
Waterwoys: 3,219 km (limited to vessels with
draft less than 1.5 m) (2011)
country comparison to the world: 31
Merchant marine: total: 446
country comparison to the world: 23
by type: bulk carrier 76, cargo 152, carrier 12,
chemical tanker 27, container 17, liquefied gas 5,
passenger 7, passenger/cargo 65, petroleum tanker
44, refrigerated cargo 20, roll on/roll off 11, vehicle
carrier 10
foreign-owned: 159 (Bermuda 47, China 4, Den-
mark 2, Germany 2, Greece 5, Japan 77, Malaysia
579
1, Netherlands 17, Singapore 1, South Korea 1,
Taiwan 1, UAE 1)
registered in other countries: 7 (Cyprus 1, Pan-
ama 5, unknown 1) (2010)
Ports and terminals: Batangas, Cagayan de Oro,
Cebu, Davao, Liman, Manila
Transportation—note: the International Mari-
time Bureau reports the territorial and offshore
waters in the South China Sea as high risk for
piracy and armed robbery against ships; numer-
ous commercial vessels have been attacked and
hijacked both at anchor and while underway;
hijacked vessels are often disguised and cargo
diverted to ports in East Asia; crews have been
murdered or cast adrift
Airports: 4 (2012) ?
country comparison to the world: 191
Airports—with paved runways: total: 3
914 to 1,523 m: 2
under 914 m: 1 (2012)
Airports—with unpaved runways: total: 1
914 to 1,523 m: 1 (2012)
Heliports: 3 (2012)
Ports and terminals: none; offshore anchorage
only','3fed31e31675059dacc355324731cfb1ff1791d30fdc14aedf68ae885f5c3dff','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c3edf63b3251f5fa3be58b42dab7908a8c16452742d6e35281ec1ab838d52548',2025,'PL','Poland','transportation',1335,'Airports: 125 (2012)
country comparison to the world: 46
Airports—with paved runways: total: 86
over 3,047 m: 5
2,438 to 3,047 m: 29
1,524 to 2,437 m: 37
914 to 1,523 m:9
under 914 m: 6 (2012)
Airports—with unpaved runways: total: 39
1524 to 2,437 m: 1
914 to 1.523 m: 17
under 914 m: 21 (2012)
Heliports: 6 (2012)
Pipelines: gas 13,860 km; oil 1,384 km; refined
products 777 km; unknown 35 km (2010)
Railways: total: 19,428 km
country comparison to the world: 15
broad gauge: 399 km 1.524-m gauge
standard gauge: 19,029 km 1.435-m gauge
(11,805 km electrified) (2007)
Roadways: total: 423,997 km
country comparison to the world: 15
paved: 295,356 km {includes 765 km of
expressways)
unpaved; 128,641 km (2008)
Waterways: 3,997 km (navigable rivers and
canals) (2009)
country comparison to the world: 28
Merchant marine: total: 9
country comparison to the world: 118
by-type: cargo 7, chemical tanker 1, passenger/
cargol ‘
registered in other countries: 106 (Antigua and
Barbuda 2, Bahamas 34, Cyprus 24, Liberia 13,
Malta 21, Saint Vincent and the Grenadines 3,
Vanuatu 9) (2010)
Ports and terminals: Gdansk, Gdynia, Swinou-
jscie, Szczecin','80a3645029aba7a876f4d1242d0629fcffef2b661a35c97b54f2eea22eeddf51','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('30c86c2bde22e71bd178a7679b4d1dafb537aa3a0a1c5ea9ba27b4fa212dcf4d',2025,'PT','Portugal','transportation',1341,'Airports: 65 (2012)
country comparison to the world: 77
Airports—with paved runways: total: 43
over 3,047 m:5
2,438 to 3,047 m: 7
1,524 to 2,437 m:8
914 to 1523 m:13
under 914 m: 10 (2012)
Airports—with unpaved runways: total: 22
914 to 1,523 m: 1
under 914 m: 21 (2012)
Pipelines: gas 1,307 km; oil 11 km; refined prod-
ucts 188 km (2010)
Railways: total: 3,319 km
country comparison to the world: 53
broad gauge: 2,700 km 1.668-m gauge (1,436 km
electrified)
narrow gauge: 192 km 1.000-m gauge; 427 km
0.760-m gauge (2008)
Roadways: total: 82,900 km
country comparison to the world: 54
paved: 71,294 km (includes 2,613 km of
expressways)
unpaved: 11,606 km (2008)
Waterways: 210 km (on Douro River from Porto)
(2011)
country comparison to the world: 96
Merchant marine: total: 109
country comparison to the world: 48
by type: bulk carrier 8, cargo 35, carrier 1, chemical
tanker 21, container 7, liquefied gas 6, passenger 13,
passenger/cargo 5, petroleum tanker 3, roll on/roll
off 1, vehicle carrier 9
foreign-owned: 81 (Belgium 8, Colombia 1, Den-
mark 4, Germany 14, Greece 2, Italy 12, Japan 9,
Mexico 1, Norway 2, Spain 18, Sweden 3, Swit-
zerland 3, US 4)
registered in other countries: 15 (Cyprus 2, Malta
3, Panama 10) (2010)
Ports and terminals: Leixoes, Lisbon, Setubal, Sines','d765054eebcd00bdc8f6601d90ff94bee7f0fbb53ac1d182c839a1e66167eba8','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('26d588f4b408c783963d1b117958d75ea58977c83303532684c457a23b25cddd',2025,'PR','Puerto Rico','transportation',1348,'Airports: 29 (2012)
country comparison to the world: 119
Airports—with paved runways: total: 17
over 3,047 m:3
1,524 to 2,437 m: 2
914 to 1523 m:7
under 914 m: 5 (2012)
Airports—with unpaved runways: total: 12
1,524 to 2,437 m: 1
914 to 1,523 m: 1
under 914 m: 10 (2012)
Roadways: total: 26,670 km
country comparison to the world: 100
paved: 25,337 km (includes 427 km of expressways)
unpaved: 1,333 km (2008)
Ports and terminals: Ensenada Honda,
Mayaguez, Playa de Guayanilla, Playa de Ponce,
San Juan 3
Airports: 2 (2012)
country comparison to the world: 207
Airports—with paved runways: total: 2
ove r 3,047 m: 1
1,524 to 2,437 m: 1 (2012)
Roadways: total: 1,260 km (2008)
country comparison to the world: 179
Ports and terminals: Charlotte Amalie, Chris-
tiansted, Cruz Bay, Frederiksted, Limetree Bay','0f8adb5442bea27c62f3a8d0481658d35698bf6a89bfb5968f785ae085a8446f','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('83226edc17ffb15d7fd3e282a2a5ca28c78c5c1630d2afeba6d52f6454dc76c0',2025,'QA','Qatar','transportation',1357,'Airports: 6 (2012)
country comparison to the world: 173
Airports—with paved runways: total: 4
over 3,047 m: 3
1,524 to 2,437 m: 1 (2012)
Airports—with unpaved runways: total: 2
914 to 1,523 m: 1
under 914 m: 1 (2012)
Heliports: 1(2012)
Pipelines: condensate 145 km; condensate/gas 1
32 km; gas 980 km; liquid petroleum gas 90 km;
oil 382 km (2010)
Roadways: total: 7,790 km (2006)
country comparison to the world: 143
Merchant marine: total: 28
country comparison to the world: 87 by type:
bulk carrier 3, chemical tanker 2, container 13,
liquefied gas 6, petroleum tanker 4 foreign-owned:
6 (Kuwait 6) `
registered in other countries: 35 (Liberia 5, Mar-
shall Islands 29, Panama 1) (2010)
Ports and terminals: Doha, Mesaieed (Umaieed),
Ra''s Laffan','a6817f7486280ad52ff913f2a53980a8f465bc3849ac984d6d4368b8a94052c3','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fa83e4a42dfc24ca2936c1547a89b732507d01b96673f7dca5eb92e04d24fbfb',2025,'RW','Rwanda','transportation',1371,'Airports: 7 (2012)
country comparison to the world: 167
Airports—with paved runways: total: 4
over 3,047 m: 1
914 to 1,523 m:2
under 914 m: 1 (2012)
Airports—with unpaved runways: total: 3
914 to 1,523 m: 2
under 914 m: 1 (2012)
Roadways: total: 14,008 km
country comparison to the world: 126
paved: 2,662 km
unpaved: 1 1,346 km (2004)
Waterways: (Lac Kivu navigable by shallow-draft
barges and native craft) (2011)
Ports and terminals: Cyangugu, Gisenyi, Kibuye','9777f198338dcac21e4451678aa5189daa5c240ca38a7717a497b3e2011adb6b','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('29b2677646b4f65043e73e81dae30e9bf42c5b15d9548f17da669c3d06d3739a',2025,'KN','Saint Kitts and Nevis','transportation',1381,'Airports: 2 (2012)
country comparison to the world: 204
Airports—with paved runways: total: 2
1524 to 2,437 m: 1
914 to 1,523 m: 1 (2042)
Railways: total: 50 km
country comparison to the world: 131
narrow gauge: 50 km 0.762-m gauge on Saint
Kitts for tourists (2008)
Roadways: total: 383 km
country comparison to the world: 200
paved: 163 km
unpaved: 220 km (2002)
Merchant marine: total: 152
country comparison to the world: 38
by type: bulk carrier 16, cargo 81, chemical tanker
4, combination ore/oil 1, container 2, liquefied gas','b5d57802a90dfc2652456367af53378b48d27f8be0f6beb2481256fdbf9af4fc','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('01c316112e1e66d50106017c57e6b243347bcab01065cc4254984f1e37749943',2025,'LC','Saint Lucia','transportation',1389,'Airports: 2 (2012)
country comparison to the world: 205
Airports—with paved runways: total: 2
Spanish retook the island in 1633, but contin-
ued to be harassed by the Dutch. The Spanish
finally relinquished Saint Martin to the French
and Dutch, who divided it between themselves
in 1648. Friction between the two sides caused
the border to frequently fluctuate over the next
two centuries, with the French eventually hold-
ing the greater portion of the island (about 57%).
The cultivation of sugar cane introduced African
slavery to the island in the late 18th century; the
practice was not abolished until 1848. The island
became a free port in 1939; the tourism industry
was dramatically expanded during the 1970s and
1980s. In 2003, the populace of Saint Martin
voted to secede from Guadeloupe and in 2007, the
northern portion of the island became a French
overseas collectivity. In 2010, the southern Dutch
portion of the island became the independent
nation of Sint Maarten within the Kingdom of
the Netherlands.','a306b9c1a4646761d809177029a0af85da17217bdb3609990647bfff3c52d804','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('400c7f0077199247058e3ff903a59fdf9157fc6f4edc7967333ac4c592ea8fcb',2025,'PM','Saint Pierre and Miquelon','transportation',1403,'Airports: 2 (2012)
country comparison to the world: 209
Airports—with paved runways: coral: 2
1,524 to 2,437 m: 1
THE CIA WORLD FACTBOOK
914 to 1,523 m: 1 (2012)
Roadways: total:117 km
country comparison to the world: 214
paved: 80 km
unpaved: 37 km (2000)
Ports and terminals: Saint-Pierre','ae6b038f94855602773deb2ce328dde64f27f63979d684b6f9a5ff00eff030cd','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3c7608a36b644f1f8d705c7328431952079dc9c35ff0811e573e9695e832d75f',2025,'VC','Saint Vincent and the Grenadines','transportation',1411,'Airports: 6 (2012)
country comparison to the world: 176
Airports—with paved runways: total: 5
1,524 to 2,437 m: 1
914 to 1,523 m: 3
under 914 m: 1 (2012)
Airports—with unpaved runways: total: 1
under 914 m: 1 (2012)
Roadways: total: 829 km
country comparison to the world: 186
paved: 580 km
unpaved: 249 km (2003)
Merchant marine: total: 412
country comparison to the world: 25
by type: bulk carrier 64, cargo 263, carrier 14,
chemical tanker 4, container 18, liquefied gas 3,
passenger 2, passenger/cargo 7, petroleum tanker
9, refrigerated cargo 12, roll on/roll off 15, special-
ized tanker 1
foreign-owned: 325 (Austria 1, Azerbaijan 1,
Bangladesh 1, Belgium 7, Bermuda 1, Bulgaria 9,
China 65, Croatia 8, Cyprus 3, Czech Republic
1, Denmark 9, Dominica 1, Egypt 2, Estonia 8,
France 2, Germany 3, Greece 42, Guyana 2, Hong
Kong 5, Israel 3, Italy 4, Japan 3, Kenya 2, Latvia
15, Lebanon 2, Lithuania 9, Monaco 2, Nether-
lands 1, Norway 13, Poland 3, Romania 1, Russia
11, Singapore 5, Slovenia 1, Sweden 10, Switzer-
land 7, Syria 9, Turkey 13, UAE 3, UK 6, Ukraine
12, US 18, Venezuela 1) (2010)
Ports and terminals: Kingstown','32bd143f91a9da5415eca19a02176c489b1ddc0eddb97b8448677da4cbcfdbf5','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6342978a1af8bc7ff066b70867f7dae63bf9c16e1bd33d6efdc3035353b8f72a',2025,'SM','San Marino','transportation',1423,'Roadways: total: 292 km
country comparison to the world: 205
paved: 292 km (2006)','b25c5ab7c7da116980a41d8366ab69cc5e0698f3ad6fb2ad6d7c5fbabc5552ab','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b80c5e5205d10ee0bfd66a21a8232d10e5575762269a6b92641a154a900ed02a',2025,'ST','Sao Tome and Principe','transportation',1427,'paved: 218 km
unpaved: 102 km (2000)
Merchant marine: cotal:3
country comparison to the world: 136
by type: bulk carrier 1, cargo 2
foreign-owned: 2 (China 1, Greece 1) (2010)
Ports and terminals: Sao Tome `','49a01ce6fc2160484f9a67c0e2eddb6d6629e690969c58fc4efd81b90837f7fb','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3e417b0cd2f03fac6aa17731d319f97879f73ab9be16ab4f9246ef4235ea717c',2025,'SA','Saudi Arabia','transportation',1435,'Airports: 216 (2012)
country comparison to the world: 27
Airports—with paved runways: rotal:80
over 3,047 m: 33
2,438 to 3,047 m: 15
1,254 to 2,437 m: 26
914 to 1.523 m:2
under 914 m: 4 (2012)
Airports—with unpaved runways: total: 136
2,438 to 3,047 m: 8
1,254 to 2,437 m: 71
914 to 1,523 m: 41
under 914 m: 16 (2012)
Heliports: 10 (2012)
Pipelines: condensate 212 km; gas 2,846 km; liq-
uid petroleum gas 1,183 km; oil 4,232 km; refined
products 1,151 km €2010)
Railways: total: 1,378 km
country comparison to the world: 81
standard gauge: 1,378 km 1.435-m gauge (with
branch lines and sidings) (2008)
Roadways: total: 221,372 km
country comparison to the world: 22
paved: 47,529 km (includes 3,891
expressways)
unpaved: 173,843 km (2006)
Merchant marine: total: 72
country comparison to the world: 61
by type: cargo 1, chemical tanker 25, container
4, liquefied gas 2, passenger/cargo 10, petroleum
tanker 20, refrigerated cargo 3, roll on/roll off 7
foreign-owned: 15 (Egypt I, Greece 4, Kuwait 4,
UAE 6)
registered in other countries: 55 (Bahamas 16,
Dominica 2, Liberia 20, Malta 2, Norway 3, Pan-
ama 11, Tanzania 1) (2010)
Ports and terminals: Ad Dammam, Al Jubayl,
Jeddah, Yanbu al Bahr','1011d75569320dc29b480665e48d9c78bc77d642ada9a7496f7674c42ff5480d','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f2385284b988ecf38ae0793c1e62d1bbffe310e6e30cb4e364654c6e2a92027c',2025,'SC','Seychelles','transportation',1444,'Airports: 14 (2012)
country comparison to the world: 150
Airports—with paved runways: total: 7
2,438 to 3,047 m: 1
914 to 1,523 m:5
under 914 m: 1 (2012)
Airports—with unpaved runways: total: 7
914 to 1,523 m: 2
under 914 m: 5 (2012)
Heliports: 1 (2012)
Roadways: total: 508 km —
THE CIA WORLD FACTBOOK
country comparison to the world: 194
paved: 490 km
unpaved: 18 km (2003)
Merchant marine: total:9
country comparison to the world: 117
by type: cargo 1, carrier 1, chemical tanker 6,
petroleum tanker 1 foreign-owned: 3 (Hong Kong
1, Nigeria 1, South Africa 1) (2010)
Ports and terminals: Victoria','3dad1c4e392907e351b14590da9bec5ce4b33777045de1f7339ccc0dfffa76c7','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8a7d572a6aa8b28e5be7f9b132e0c805245f665bd2fda7361a4dbef97d6d493d',2025,'SL','Sierra Leone','transportation',1451,'Airports: 8 (2012)
country comparison to the world: 164
Alrparts—with paved runways: total: 1
over 3,047 m: 1 (2012)
Airports—with unpaved runways: total: 7
914 to 1,523 m: 7 (2012)
Heliports: 2 (2012)
Roadways: total: 11,300 km
country comparison to the world: 132
paved: 904 km
unpaved: 10,396 km (2002)
Waterways: 800 km (600 km navigable year
round) (2011)
country comparison to the world: 72
Merchant marine: total: 215
country comparison to the world: 34
by type: bulk carrier 22, cargo 120, carrier 2,
chemical tanker 19, container 6, liquefied gas 3,
passenger/cargo 2, petroleum tanker 28, refriger-
ated cargo 7, roll on/roll off 4, specialized tanker
1, vehicle carrier 1
foreign-owned: 98 (Bangladesh 1, China 19,
Cyprus 2, Egypt 3, Estonia 2, Hong Kong 7, Japan
4, Lebanon 2, North Korea 2, Romania 2, Russia
7, Singapore 9, Syria 13, Taiwan 7, Turkey 9, UAE
1, UK 1, Ukraine 5, Yemen 2) (2010)
Ports and terminals: Freetown, Pepel, Sherbro
Islands ;','89f80552e23f69586483d818a3af6c31c6e6e5c747a194810bc0fd52d228779d','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4d3236fd933f3788e935afc63393657a75bae2553eaa3e57782b8c4b7f2c1219',2025,'SG','Singapore','transportation',1456,'Airports: 9 (2012)
country comparison to the world: 158
Airports—with paved runways: total:9
over 3,047 m: 2
2,438 to 3,047 m:2
1,524 to 2,437 m:3
914 to 1,523 m: 2 (2012)
Pipelines: gas 111 km (2010)
Roadways: total: 3,356 km
country comparison to the world: 163
paved: 3,356 km (includes 161 km of expressways)
` (2009)
Merchant marine: total: 1,599
country comparison to the world: 6
by type: bulk carrier 247, cargo 109, carrier 6,
chemical tanker 256, container 339, liquefied gas
131, petroleum tanker 436, refrigerated cargo 13,
roll on/roll off 5, vehicle carrier 57 foreign-owned:
966 (Australia 12, Bangladesh 1, Belgium 1, Ber-
muda 25, Brazil 9, Chile 6, China 29, Cyprus 6,
Denmark 149, France 3, Germany 32, Greece 22,
Hong Kong 46, India 21, Indonesia 60, Italy 5,
Japan 164, Malaysia 27, Netherlands 1, Norway
153, Russia 2, South Africa 13, South Korea 3,
Sweden 11, Switzerland 3, Taiwan 77, Thailand
33, UAE 10, UK 6, US 36) registered in other
countries; 344 (Australia 2, Bahamas 7, Bangla-
desh 7, Belize 4, Cambodia 3, Cyprus 1, France 3,
Honduras 11, Hong Kong 13, Indonesia 46, Italy
1, Kiribati 9, Liberia 22, Malaysia 13, Maldives 4,
Malta 4, Marshall Islands 30, Mongolia 3, North
Korea 1, Panama 92, Philippines 1, Saint Kitts
and Nevis 10, Saint Vincent and the Grenadines
5, Sierra Leone 9, Thailand 1, Tuvalu 19, US 16,
Vanuatu 2, unknown 5) (2010)
Ports and terminals: Singapore
Transportation—note: the International Mari-
time Bureau reports the territorial and offshore
waters in the South China Sea as high risk for
piracy and armed robbery against ships; numer-
ous commercial vessels have been attacked and
hijacked both at anchor and while underway;
hijacked vessels are often disguised and cargo
diverted to ports in East Asia; crews have been
murdered or cast adrift
Military branches: Singapore Armed Forces:
Army, Navy, Air Force (includes Air Defense)
(2013)
Military service age and obligation: 18-21 years
of age for male compulsory military service; 16 1/2
years of age for volunteers; 2-year conscript service
obligation, with a reserve obligation to age 40
(enlisted) or age 50 (officers) (2012)
Manpower available for military service: males
age 16-49: 1,255,902 (2010 est.)
Manpower fit for military service: males age
16-49: 1,018,839
females age 16-49: 1,087,134 (2010 est.)
Manpower reaching militarily significant age
annually: male: 27,098
female: 25,368 (2010 est.)
Military expenditures: 3.6% of GDP (2012)
country comparison to the world: 33','f6e5f65933f99585eb9ae0ddfb52855db2548ef7acecc2e5c52947b42830f3ca','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3a2d8dffc69879ba2730052101f2cf457c4d056359e2b018f8b74481e7883053',2025,'SK','Slovakia','transportation',1463,'Airports: 37 (2012)
country comparison to the world: 108
Airports—with paved runways: total: 19
over 3,047 m:2
2,438 to 3,047 m: 2
1,524 to 2,437 m: 3
914 to 1,523 m:3
under 914 m: 9 (2012)
Airports—with unpaved runways: total: 18
914 to 1,523 m: 10
under 914 m: 8 (2012)
Heliports: (2012)
THE CIA WORLD FACTBOOK
Pipelines: gas 6,769 km; oil 416 km (2010)
Railways: total: 3,622 km
country comparison to the world: 48
broad gauge: 99 km 1.520-m gauge
standard gauge: 3,473 km 1.435-m gauge (1,615
km electrified) narrow gauge: 50 km 1.000-m or
0,750-m gauge (2008)
Roadways: total: 43,761 km
country comparison to the world: 83
paved: 38,085 km (includes 384 km of expressways)
unpaved: 5,676 km (2008)
Waterways: 172 km (on Danube River) (2009)
country comparison to the world: 100
Merchant marine: total: 11
country comparison to the world: 111
by type: cargo 9, refrigerated cargo 2
foreign-owned: 11 (Germany 3, Ireland 1, Italy
2, Montenegro 1, Slovenia 1, Turkey 1, Ukraine
2) (2010)
Ports and terminals: Bratislava, Komarno','7f02059fb0a633342ba488da8f902313836eb8a03fdc66c695f796d01a8b1e4f','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f77fdf242e8560440b5e5ee77c3b6ada03fc5ef1a388a3d438885f6523e45766',2025,'SI','Slovenia','transportation',1469,'Airports: 16 (2012)
country comparison to the world: 143
Airports—with paved runways: total: 7
over 3,047 m: |
2,438 to 3,047 m: 1
1,524 to 2,437 m: 1
914 to 1,523 m: 3
under 914 m: 1 (2012)
Airports—with unpaved runways: total:9
1,524 to 2,437 m: 1
914 to 1,523 m: 3
661
under 914 m: 5 (2012)
Pipelines: gas''840 km; oil 5 km (2010)
Railways: total: 1,228 km
country comparison to the world: 84
standard gauge: 1,228 km 1.435-m gauge (503 km
electrified) (2007)
Roadways: total: 38,925 km
country comparison to the world: 91
paved: 38,925 km (includes 658 km of express-
ways) (2008)
* Waterways: (there is some transport on the Drava
River) (2012)
Merchant marine: registered in other countries:
24 (Cyprus 5, Liberia 7, Malta 4, Marshall Islands
6, Saint Vincent and the Grenadines 1, Slova-
kia 1) (2010)
country comparison to the world: 90
Ports ond terminals: Koper
THE CIA WORLD FACTBOOK','c2d09b4d047ae1ae752cb0e47f1cf990f9624f6a20c54b36ed2183ef7571786f','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('88efbf5cb731cae5e43ac9c770faebe46a6cf5de1f5756318f52d8be9d5e8d32',2025,'SB','Solomon Islands','transportation',1477,'Airports: 36 (2012)
country comparison to the world: 111
Airports—with paved runways: total: 1
1,524 to 2,437 m: 1 (2012)
Airports—with unpaved runways: total: 35
1,524 to 2,437 m: 1
914 to 1,523 m:9
under 914 m: 25 (2012)
Heliports: 3 (2012)
Roadways: total: 1,360 km
country comparison to the world: 177
paved: 33 km
unpaved: 1,327 km
note: includes 800 km of private plantation roads
(2002)
Ports and terminals: Honiara, Malloco Bay, Viru
Harbor, Tulaghi','78875f17dd2df8220c0e5e8c5f6ceb9e6b8423a490f5f4b39dfdf111a23759b1','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('08af1a9764c7f8354c1b2b35c63ee6ebedff453e21455fddddf6aeda89a49c2d',2025,'SO','Somalia','transportation',1482,'Airports: 62 (2012)
country comparison to the world: 80
Airports—with paved runways: total: 7
over 3,047 m: 4
2,438 to 3,047 m: 2
1,524 to 2,437 m: 1 (2012)
Airports—with unpaved runways: total:55
over 3,047 m: 1
2,438 to 3,047 m:4
1,524 to 2,437 m: 20
914 to 1,523 m: 24
under 914 m:6 (2012)
Roadways: total: 22,100 km
country comparison to the world: 104
paved: 2,608 km
unpaved: 19,492 km (2000)
Merchant marine: total: 1
country comparison to the world: 154
by type: cargo 1 (2008)
Ports and terminals: Berbera, Kismaayo
Transportation—note: despite a dramatic drop in
the number of attacks in 2012, the International
Maritime Bureau continues to report the territo-
rial and offshore waters in the Gulf of Aden and
Indian Ocean as a region of significant risk for
piracy and armed robbery against ships accounting
for 25% of all attacks in 2012; 75 vessels, includ-
ing commercial shipping and pleasure craft, were
attacked or hijacked both at anchor and while
underway compared with 237 in 2011; the number
of hijackings off the coast of Somalia was reduced
to 14 in 2012, down from 28 in 2011; as of April
2013, 77 vessels and 7 hostages were being held for
ransom by Somali pirates; the presence of several
naval task forces in the Gulf of Aden and addi-
tional anti-piracy measures on the part of ship
operators, including the use of on-board armed
security teams, have reduced piracy incidents
in that body of water; in response Somali-based
pirates, using hijacked fishing trawlers as “mother
ships” to extend their range, shifted operations as
far south as the Mozambique Channel, eastward to','2a4fea80264834f7cfef1a96192b35d36740a8cd99eff24089ab38f7e9ce37e7','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a8aa875d3d4c5e3604fb241f30344f29323947f797d7a71824197de63ed03287',2025,'ZA','South Africa','transportation',1488,'Airports: 567 (2012)
country comparison to the world: 11
THE CIA WORLD FACTBOOK
Airports—with paved runways: total: 145
over 3,047 m: 11
2,438 to 3,047 m: 6
1,524 to 2,437 m: 53
914 to 1,523 m: 66
under 914 m: 9 (2012)
Airports—with unpaved runways: total: 422
2,438 to 3,047 m: 1
1,524 to 2,437 m: 29
914 to 1,523 m: 260
under 914 m: 132 (2012)
Heiiports: | (2012)
Pipelines: condensate 11 km; gas 908 km; oil 980
km; refined products 1,382 km (2010)
Railways: total: 20,192 km
country comparison to the world: 14
narrow gauge: 19,756 km 1.065-m gauge (8,271
km electrified); 122 km 0.750-m gauge; 314 km
0.610-m gauge (2008)
Roadways: total: 362,099 km
country comparison to the world: 18
paved: 73,506 km (includes 239 km of
expressways) K?
unpaved: 288,593 km (2002)
Merchant marine: total: 3
country comparison to the world: 138
by type: petroleum tanker 3
registered in other countries: 19 (Australia 1, Isle
of Man 2, Mexico 1, NZ 1, Seychelles 1, Singapore
13) (2010)
Ports and terminals: Cape Town, Durban, Port
Elizabeth, Richards Bay, Saldanha Bay
Ports and terminals: Grytviken
Military—note: defense is the responsibility of
the UK
Ports and terminals: McMurdo, Palmer, and off-
shore anchorages in Antarctica
note: few ports or harbors exist on the southern
side of the Southern Ocean; ice conditions limit
use of most to short periods in midsummer; even
then some cannot be entered without icebreaker
escort; most Antarctic ports are operated by
government research stations and, except in an
emergency, are not open to commercial or private
vessels
Transportation—note: Drake Passage offers alter-
native to transit through the Panama Canal','671f0a0c00da935344bea31de0039c0a132e898a510aa487476bb410a6f0c8bb','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fc6900be4f722cfd8ce2507df07416d381aed67ee8b189c4389f60f7cd1631aa',2025,'ES','Spain','transportation',1494,'Airports: 152 (2012)
country comparison to the world: 36
Airports—with paved runways: toral:98
over 3,047 m: 18
2,438 to 3,047 m: 12
1,524 to 2,437 m: 19
914 to 1,523 m: 25
under 914 m: 24 (2012)
Airports—with unpaved runways: total: 54
1,524 to 2,437 m: 2
914 to 1,523 m: 14
under 914 m: 38 (2012)
Heliports: 10 (2012)
Pipelines: gas 9,359 km; oil 560 km; refined prod-
ucts 3,441 km (2010)
Railways: total: 15,293 km
country comparison to the world: 18
broad gauge: 11,919 km 1.668-m gauge (6,950 km
electrified)
standard gauge: 1,392 km 1.435-m gauge (1,054
km electrified)
narrow gauge: 1,954 km 1.000-m gauge (815 km
electrified); 28 km 0.914-m gauge (2008)
Roadways: cotal: 681,298 km
country comparison to the world: 10
paved: 681,298 km (includes 15,152 km of
expressways) (2008)
Waterways: 1,000 kr (2012)
country comparison to the world: 64
Merchant marine: total: 132
country comparison to the world: 44
by type: bulk carrier 7, cargo 19, chemical tanker
8, container 5, liquefied gas 12, passenget/cargo
43, petroleum tanker 18, refrigerated cargo 4, roll
on/roll off 9, vehicle carrier 7 foreign-owned: 27
(Canada 4, Germany 4, Italy 1, Mexico 1, Norway
10, Russia 6, Switzerland 1)
registered in other countries: 103 (Angola 1,
Argentina 3, Bahamas 6, Brazil 12, Cape Verde 1,
Cyprus 6, Ireland 1, Malta 8, Morocco 9, Panama
30, Peru 1, Portugal 18, Uruguay 5, Venezuela 1,
unknown 1) (2010)
Ports and terminals: Algeciras, Barcelona,
Bilbao, Cartagena, Huelva, Tarragona, Valen-
cia (Spain); Las Palmas, Santa Cruz de Tenerife
(Canary Islands)
Milltary branches: Spanish Armed Forces: Army
(Ejercito de Tierra), Spanish Navy (Armada Espa-
nola, AE; includes Marine: Corps), Spanish Air
Force (Ejercito del Aire Espanola, EdA) (2013)
Military service age and obligation: 17 years of
age for voluntary military service by a Spanish citi-
zen or legal immigrant, 2-3 year obligation; women
allowed to serve in all SAF branches, includ-
ing combat units; no conscription, but Spanish
Government retains right to mobilize citizens 19-25
years of age in a national emergency; mandatory
retirement of non-NCO enlisted personnel at age
45 or 58, depending on service length (2012)
Manpower available for military service:
males age 16-49: 11,759,557
females age 16-49: 11,204,688 (2010 est.)
Manpower fit for military service: males age
16-49: 9,603,939
females age 16-49: 9,116,928 (2010 est.)
_ Manpower reaching militarily significant age
annually: male: 217,244
female: 205,278 (2010 est.)
Military expenditures: 1.2% of GDP (2005 est.)
country comparison to the world: 118','15b071b49005d0e83e90a96b26ca6b53baca891277248e2c8a4ea94bde2b89fc','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('88453934dfc75290f5a4239ea2cfe50c6275adccf5b6c558df368bec37ac76eb',2025,'LK','Sri Lanka','transportation',1503,'Airports: 18 (2012)
country comparison to the world: 141
Airports—with paved runways: total: 14
over 3,047 m: 1
1,524 to 2,437 m:6
914 to 1,523 m: 7 (2012)
Airports—with unpaved runways: total: 4
914 to 1,523 m: 1
under 914 m: 3 (2012)
Heliports: 0 (2012)
Railways: total: 1,449 km
country comparison to the world: 80
broad gauge: 1,449 km 1.676-m gauge (2007)
Roadways: total: 91,907 km (2008)
country comparison to the world: 49
Waterways: 160 km (primarily on rivers in south-
west) (2012)
country comparison to the world: 101
Merchant marine: total: 21
country comparison to the world: 94
by type: bulk carrier 4, cargo 13, chemical tanker 1,
container 1, petroleum tanker 2
foreign-owned: 8 {Germany 8) (2010)
Ports and terminals: Colombo','6c9154bffa2438eb55eac736444939469f7ea1a1a4f2c1bbf7d6a6fceae017bb','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d015343c267810e0377262922866fb83f19872c110fa95539023d64ed81b56d0',2025,'SD','Sudan','transportation',1511,'Airports: 72 (2012)
country comparison to the world: 74
Airports—with paved runways: total: 15
over 3,047 m: 3
2,438 to 3,047 m:9
1.524 to 2,437 m:2
under 914 m: 1 (2012)
Airports—with unpaved runways: total: 57
2,438 to 3,047 m: 1
1,524 to 2,437 m: 17
914 to 1,523 m: 27
under 914 m: 12 (2012)
Heliports: 5 (2012)
Pipelines: gas 156 km; oil 4,070 km; refined prod-
ucts 1,613 km (2010)
Railways: total:5,978 km
country comparison to the world: 30
narrow gauge: 4,578 km 1.067-m gauge; 1,400 km
0.600-m gauge for cotton plantations (2008)
Roadways: total: 11,900 km
country comparison to the world: 131
paved: 4,320 km
unpaved: 7,580 km (2000)
Waterways: 4,068 km (1,723 km open year round
on White and Blue Nile rivers) (2011)
country comparison to the world: 25
Merchant marine: total: 2
country comparison to the world: 145
by type: cargo 2 (2010)
Ports and terminals: Port Sudan
Military branches: Sudanese Armed Forces
(SAF): Land Forces, Navy (includes Marines),
Sudanese Air Force (Sikakh al-Jawwiya as-
Sudaniya), Popular Defense Forces (2011)
Military service age and obligation: 18-33
years of age for male and female compulsory or
voluntary military service; 1-2 year service obliga-
tion; a requirement that completion of national
service was mandatory before entering public or
private sector employment has been cancelled
(2012)
Manpower available for military service:
males age 16-49: 10,433,973
females age 16-49: 10,411,443 (2010 est.)
Manpower fit for military service: males age
16-49: 6,475,530
females age 16-49: 6,840,885 (2010 est.)
Manpower reaching militarily significant age
annually: male: 532,030
female: 512,476 (2010 est.)
Military expenditures: 4.2% of GDP (2012)
country comparison to the world: 24','50a641d4a174d2cdfe02a264bcf49d5c8073e47ecb185529d14d37d2279d2f7a','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e8218de6df160fb745ab65f3e957c76f4552eb9cd4d33259a43f0fc03039ee79',2025,'SR','Suriname','transportation',1519,'Airports: 47 (2012)
country comparison to the world: 93
Airports—with paved runways: total: 5
over 3,047 m: 1
under 914 m: 4 (2012)
Airports—with unpaved runways: coral: 42
914 to 1,523 m: 4
under 914 m: 38 (2012)
Pipelines: oil 50 km (2010)
Roadways: total: 4,304 km
country comparison to the world: 154
paved: 1,130 km
unpaved: 3,174 km (2003)
Waterways: 1,200 km (most navigable by ships
with drafts up to 7 m) (2011)
country comparison to the world: 59
Ports and terminals: Paramaribo, Wageningen
Airports: 4 (2012)
country comparison to the world: 189
S@uTH
AFRICA
f Lobamba,
‘
J MBABANE
f *
Manzini
tilatiku''y
aN ~Nhlangano
~~ Lavumisa i |','8b2e0f20eadf0f28fe33d52890c1bb434d498b7d42173578c69294c68aed484a','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e1ea73e363407fa6d7502239ed02f0d27b8f81c9681acfd22778a072c8afecd7',2025,'SE','Sweden','transportation',1528,'Airports: 230 (2012)
country comparison to the world: 26
Airports—with paved runways: total: 149
over 3,047 m:3
2,438 to 3,047 m: 12
1,524 to 2,437 m: 74
914 to 1,523 m: 23
under 914 m: 37 (2012)
Airports—with unpaved runways: total: 81
914 to 1,523 m: 5
under 914 m: 76 (2012)
Heliports: 2 (2012)
Pipelines: gas 786 km (2010)
Railways: total: 11,633 km
country comparison to the world: 20
standard gauge: 11,568 km 1.435-m gauge (7,567
km electrified)
narrow gauge: 65 km 1.000-m gauge (65 km elec-
trified) (2008)
Roadways: total: 572,900 km (includes 1,855 km
of expressways)
country comparison to the world: 12
note: includes 98,400 km of state roads, 433,500
km of private roads, and 41,000 km of municipal
roads; 215,700 km of these are open to public traf-
fic (2009)
Waterways: 2,052 km (2010)
country comparison to the world: 41
Merchant marine: total: 135
country comparison to the world: 42
by type: bulk carrier 4, cargo 16, carrier 1, chemi-
cal tanker 15, passenger 5, passenger/cargo 36,
petroleum tanker 11, roll on/roll off 30, vehicle
carrier 17foreign-owned: 35 (Denmark 4, Estonia
3, Finland 16, Germany 3, Ireland 1, Italy 5, Nor-
way 3) registered in other countries: 189 (Baha-
mas 11, Barbados 4, Bermuda 14, Canada 2, Cook
Islands 3, Cyprus 5, Denmark 15, Faroe Islands 11,
Finland 1, France 4, Gibraltar 11, Italy 1, Liberia
12, Malta 1, Marshall Islands 1, Netherlands 12,
Norway 27, Panama 2, Portugal 3, Saint Vincent
and the Grenadines 10, Singapore 11, UK 28)
(2010)
Ports and terminals: Brofjorden, Goteborg, Hels-
ingborg, Karlshamn, Lulea, Malmo, Stockholm,
Trelleborg, Visby','a9eb42a5ba87d4cbaedeea107039bc08682ef3baf3883691f4a523d2c920c18b','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bac09e3c5c70eba839416b7247c1aaae68746d2cc21c35980bd9dfeb6d48ced2',2025,'CH','Switzerland','transportation',1534,'Airports: 64 (2012)
country comparison to the world: 79
Airports—with paved runwoys: total: 41
over 3,047 m:3
2,438 to 3,047 m:2
1,524 to 2,437 m: 13
914 to 1,523 m: 6
under 914 m: 17 (2012)
Airports—with unpaved runways: total: 23
under 914 m: 23 (2012) `
Heliports: 0 (2012)
Pipelines: gas 1,681 km; oil 94 km; refined prod-
ucts 7 km (2010)
Railways: total: 4,876 km
country comparison to the world: 37
standard gauge: 3,846 km 1.435-m gauge (3,591
km electrified)
narrow gauge: 1,020 km 1.000-m gauge (1,013
km electrified); 10 km 0.800-m gauge (10 km elec-
trified) (2008)
Roadways: total: 71,454 km
country comparison to the world: 64
paved: 71,454 km (includes 1,790 of expressways)
(2010)
Waterways: 1,292 km (there are 1,227 km of
waterways on lakes and rivers for public transport
and another 64 km on the Rhine River berween
Basel-Rheinfelden and Schaffhausen-Bodensee
used for the transport of commercial goods) (2010)
_ country comparison to the world: 58
Merchant marine: total: 38
country comparison to the world: 77
by type: bulk carrier 19, cargo 9, chemical tanker 5,
container 4, petroleum tanker ] registered in other
countries: 127 (Antigua and Barbuda 7, Bahamas
1, Belize 1, Cayman Islands 1, France 5, Germany
2, Hong Kong 5, Italy 13, Liberia 25, Luxembourg
1, Malta 20, Marshall Islands 12, NZ 2, Panama
15, Portugal 3, Russia 3, Saint Vincent and the
Grenadines 7, Singapore 3, Spain 1) (2010)
Ports and terminais: Basel
Airports: 99 (2012)
country comparison to the world: 58
Airports—with paved runways: total: 29
over 3,047 m: 5
2,438 to 3,047 m: 16
914 to 1,523 m: 3
under 914 m: 5 (2012)
Airports—with unpaved runways: total:.70
1,524 to 2,437 m: 1
914 to 1,523 m: 14
under 914 m: 55 (2012)
Heliports: 6 (2012)
Pipelines: gas 3,161 km; oil 1,997 km (2010)
Railways: total: 2,052 km A
country comparison to the world: 72
standard gauge: 1,801 km 1.435-m gauge
narrow gauge: 251 km 1.050-m gauge (2008)
Roadways: total: 68,157 km
country comparison to the world: 67
paved: 61,514 km (includes 1,103 km of
expressways)
unpaved: 6,643 km (2006)
Waterways: 900 km (navigable but not economi-
cally significant) (2011)
country comparison to the world: 69
Merchant marine: total: 19
country comparison to the world: 95
by type: bulk carrier 4, cargo 14, carrier 1
registered in other countries: 166 (Barbados 1,
Belize 4, Bolivia 4, Cambodia 22, Comoros 5,
Dominica 4, Georgia 24, Lebanon 2, Liberia 1,
Malta 4, Moldova 5, North Korea 4, Panama 34,
Saint Vincent and the Grenadines 9, Sierra Leone
13, Tanzania 23, Togo 6, unknown 1) (2010)
Ports and terminals: Baniyas, Latakia, Tartus
Airports: 40 (2012)
country comparison to the world: 105 _
Airports—with paved runways: total: 37
ove r 3,047 m:8
2,438 to 3,047 m:7
1,524 to 2,437 m: 11
914 to 1,523 m:9
under 914 m: 2 (2012)
Airports—with unpaved runways: total: 3
1,524 to 2,437 m:2
under 914 m: 1 (2012)
Heliports: 32 (2012)
Pipelines: gas 412 km (2010)
Railways: total: 1,580 km
country comparison to the world: 79
standaid gauge: 345 km 1.435-m gauge (345 km
elecnnied)
narrow gauge: 1,085 km 1.067-m gauge (685 km
electrified); 150 km 0.762-m gauge
note: the 0.762 gauge track belongs to three enti-
ties, the Forestry Bureau, Taiwan Cement, and
TaiPower (2009)
Roadways: total: 41,475 km
THE CIA WORLD FACTBOOK
country comparison to the world: 87
paved:41,033 km (includes 720 km of expressways)
unpaved: 442 km (2009)
Merchant marine: total: 112
country comparison to the world: 47
by type: bulk carrier 35, cargo 20, chemical
tanker 1, container 31, passenger/cargo 4, petro-
leum tanker 12, refrigerated cargo 7, roll on/roll
off 2
foreign-owned: 3 (France 2, Vietnam 1)
registered in other countries: 579 (Argentina 2,
Cambodia 1, Honduras 1, Hong Kong 25, Indo-
nesia 1, Italy 10, Kiribati 2, Liberia 94, Marshall
Islands 8, Panama 328, Philippines 1, Sierra Leone
7, Singapore 77, South Korea 1, Thailand 1, UK
11, Vanuatu 1, unknown 8) (2010)
Ports and terminals: Chilung (Keelung), Kaohsi-
ung, Hualian, Taichung
Shipyards and Ship Building: Shipyards: 6
Ships Built: 18 (2009)','1cd4321a0029a9f6e766d2711f133b14f8f1b4f1064cff4bfaa83f1891ffa7d2','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('110a2b4eb75f8586485492f73e7de14006ea198cf474a69b5ae0e8da4167263f',2025,'TJ','Tajikistan','transportation',1543,'Airports: 24 (2012)
country comparison to the world: 132
Airports—with paved runways: total: 17
over 3,047 m:2
2,438 to 3,047 m: 4
1,524 to 2,437 m:5
914 to 1,523 m: 3
under 914 m: 3 (2012)
Airports—with unpaved runways: total: 7
1,524 to 2,437 m: 1
914 to 1,523 m: 1
under 914 m: 5 (2012)
Pipelines: gas 549 km; oil 38 km (2010)
Railways: total: 680 km l
country comparison to the world: 103
broad gauge: 680 km 1.520-m gauge (2008)
Roadways: total: 27,767 km (2000)
country comparison to the world: 99
Waterways: 200 km (along Vakhsh River)
(2011)
countrycomparison to the world: 99
Airports: 106 (2012)
country comparison to the world: 52
Airports—with paved runways: total: 11 over
3,047 m: 3
2,438 to 3,047 m: 2
1,524 to 2,437 m: 4
914 to 1,523 m: 2 (2012)
Airports—with unpaved runways: total: 95
1,524 to 2,437 m: 19
914 to 1,523 m: 58
under 914 m: 18 (2012)
Pipelines: gas 254 km; oil 888 km; refined prod-
ucts 8 km (2010)
Railways: total: 3,689 km
country comparison to the world: 45
narrow gauge: 969 km 1.067-m gauge; 2,720 km
1.000-m gauge (2008)
Roadways: total: 91,049 km
country comparison to the world: 51
paved: 6,578 km
unpaved: 84,471 km (2007)
Waterways: (Lake Tanganyika, Lake Victoria,
and Lake Nyasa (Lake Malawi) are the principal
avenues of commerce with neighboring countries;
the rivers are not navigable) (2011)
Merchant marine: total: 94
country comparison to the world: 52
by type: bulk carrier 6, cargo 66, carrier 4, chemi-
cal tanker 1, container 1, passenger/cargo 2, petro-
leum tanker 10, refrigerated cargo 1, roll on/roll
off 3
foreign-owned: 42 (Japan 1, Romania 1, Saudi
Arabia 1, Syria 23, Turkey 13, UAE 3)
registered in other countries: 3 (Panama 2, UK
1) (2010)
Ports and terminals: Dares Salaam, Zanzibar
Transportation—note: the International Mari-
time Bureau reports that shipping in territorial and
offshore waters in the Indian Ocean remain at risk
for piracy and armed robbery against ships, espe-
cially as Somali-based pirates extend their activi-
ties south; numerous commercial vessels have been
attacked and-hijacked both at anchor and while
underway; crews have been robbed and stores or
cargoes stolen','70d7a8b80dfe26892b94e870fc47aad8604acb08a6e0d8fc97de5d104fb3daef','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5a22d8ee458e0bbb11ef050f572ba15c78f551a5f09f1190b730148c9e5d5fcd',2025,'TH','Thailand','transportation',1552,'Airports: 103 (2012)
country comparison to the world: 55
Airports—with paved runways: total: 63
over 3,047 m: 8
2,438 to 3,047 m: 12
1,524 to 2,437 m: 23
914 to 1,523 m: 15
under 914 m: 5 (2012)
Airports—with unpaved runways: total: 40
1,524 to 2,437 m: 1
914 to 1,523 m: 12
under 914 m: 27 (2012)
Heliports: 6 (2012)
Pipelines: gas 1,889 km; liquid petroleum gas 85
km; refined products 1,099 km (2010) >
Railways: total: 4,071 km
country comparison to the world: 42
standard gauge: 29 km 1.435-m gauge (29 km
electrified)
narrow gauge: 4,042 km 1.000-m gauge (2008)
Roadways: total: 180,053 km (includes 450 km of
expressways) (2006)
country comparison to the world: 27
Waterways: 4,000 km (3,701 km navigable by
boats with drafts up to 0.9 m) (2011)
country comparison to the world: 27
Merchant marine: total: 363
country comparison to the world: 28
by type: bulk carrier 31, cargo 99, chemical
tanker 28, container 18, liquefied gas 36, passen-
ger 1, passenger/cargo 10, petroleum tanker 114,
refrigerated cargo 24, roll on/roll off 1, vehicle
carrier |
foreign-owned: 13 (China 1, Hong Kong 1,
Malaysia 3, Singapore 1, Taiwan 1, UK 6)
registered in other countries: 46 (Bahamas 4, Belize
1, Honduras 2, Panama 6, Singapore 33) (2010)
Ports and terminals: Bangkok, Laem Chabang,
Map Ta Phut, Prachuap Port, Si Racha','376214f58ce267b168c613a29e88e4005ac7a6f843fab4f48d4a86259ad778c8','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4869b356445a59e86fcbb71cdc4bb5ca6fc556ac92c113cc965a2e00fa0c7844',2025,'TL','Timor-Leste','transportation',1560,'Airports: 6 (2012)
country comparison to the world: 175
Airports—with paved runways: total: 2
2,438 to 3,047 m: 1
1,524 to 2,437 m: 1 (2012)
Airports—with unpaved runways: total: 4
914 to 1,523 m: 2
under 914 m: 2 (2012)
Heliports: 8 (2012)
Roadways: total: 6,040 km
country comparison to the world: 149
paved: 2,600 km
unpaved: 3,440 km (2005)
Merchant marine: total: 1
country comparison to the world: 155
by type: passenger/cargo 1 (2010)
Ports and terminals: Dili','dfe1c7929023a198270132bd51b314ef9c7e28a4b3c9a5c03b2842ccb9d981ba','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2e20de8e178c09cef1315968516cc86df438f8d0933af1835f56d4c5ae8fea5e',2025,'TG','Togo','transportation',1567,'Airports: 8 (2012)
country comparison to the world: 162
Airports—with paved runways: total: 2
2,438 to 3,047 m: 2 (2012)
Airports—with unpaved runways: total: 6
914 to 1,523 m: 4
under 914 m: 2 (2012)
Railways: total: 568 km
country comparison to the world:110 __
narrow gauge: 568 km 1.000-m gauge (2008)
Roadways: total: 7,520 km
country comparison to the world: 146
paved: 2,376 km
unpaved: 5,144 km (2000)
Waterways: 50 km (seasonally navigable by small
craft on the Mono River depending on rainfall)
(2011)
country comparison to the world: 103
Merchant marine: total: 61
country comparison. to the world: 65
by type: bulk carrier 6, cargo 38, carrier 3, chemical
tanker 5, container 3, passenger/cargo 1, petroleum
tanker 3, refrigerated cargo 1, roll on/roll off 1
foreign-owned: 21 (China 1, Lebanon 6, Roma-
nia 1, Syria 6, Turkey 4, UAE 1, US 1, Yemen 1)
(2010)
Ports and terminals: Kpeme, Lome','a19e9f461724f44111a20fd16e1798e1b705efb415b867bdd90c7cc10c2dbcd6','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bea1c46ea160b0078f77820750c66bd115382e50ba51086b81e03d5dce3f5803',2025,'TO','Tonga','transportation',1581,'Airports: 6 (2012)
country comparison to the world: 177
Airports—with paved runways: total: 1
2,438 to 3,047 m: 1 (2012)
Airports—with unpaved runways: total: 5
1,524 to 2,437 m: 1
914 to 1,523 m: 3
under 914 m: 1 (2012)
Roadways: total: 680 km
country comparison to the world: 189
paved: 184 km
unpaved: 496 km (2000)
Merchant marine: total: 7
country comparison to the world: 122
by type: cargo 4, carrier 1, passenger/cargo 2
foreign-owned: 2 (Australia 1, UK 1) (2010)
Ports and terminals: Nuku''alofa, Neiafu, Pangai
Military branches: Tonga. Defense Services
(TDS): Land Force (Réyal Guard), Maritime
Force (includes Royal Marines, Air Wing) (2013)
Military service age and obligation: 16 years of
age for voluntary enlistment (with parental con-
sent); no conscription; the king retains the right
to call up “all those capable of bearing arms” in
wartime (2012)
Manpower available for military service:
males age 16-49: 24,460
females age 16-49: 24,041 (2010 est.)
Manpower fit for military service: males age
16-49: 20,956
females age 16-49: 20,577 (2010 est.)
Manpower reaching militarily significant age
annually: male: 1,196
female: 1,134 (2010 est.)
Military expenditures: 0.9% of GDP (2012)
country comparison to the world: 133','44f806a5e28457ff139fd042b06afc480029d58c60c498ec5133a103f1202570','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2f459cd59c5de593f48181285836ca66eba8fef7070ce90e530a0622be9d6e63',2025,'TT','Trinidad and Tobago','transportation',1585,'Airports: 5 (2012)
country comparison to the world; 181
Airports—with paved runways: total: 2
over 3,047 m: 1
2,438 to 3,047 m: 1 (2012)
Airports—with unpaved runways: total: 3
914 to 1,523 m: 1
under 914 m: 2 (2012)
Pipelines: gas 671 km; oil 334 km (2010)
Roadwoys: total: 8,320 km
country comparison.to the world: 139
paved: 4,252 km
unpaved: 4,068 km (2000)
Merchant marine: total: 4
country comparison to the world: 131
by type: passenger k, passenger/cargo 2, petroleum
tanker 1
registered in other countries: 2 (unknown 2)
(2010)
Ports and terminals: Point Fortin, Point Lisas,
Port of Spain, Scarborough
oil term inals: Galeota Point terminal','ec82148a3c1fa641f31e5a915f4b972fd0d6e9d9717d4a74dbc0e5b6498d5a9d','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a779d82e3d7c1f747e8b2b95388746e41034396767d6a40e3caaea4c9e0a6b69',2025,'TN','Tunisia','transportation',1591,'Airports: 29 (2012)
country comparison to the world: 118
Airports—with paved runways: total: 15
over 3,047 m: 4 J
2,438 to 3,047 m: 6
1,524 to 2,437 m: 2
_ 914 to 1,523 m: 3 (2012)
Airports—with unpaved runways: total: 14
1,524 to 2,437 m: 1
914 to 1,523 m:5
under 914 m: 8 (2012)
Pipelines: gas 2,386 km; oil 1,323 km; refined
products 453 km (2010)
Party and the peaceful transfer of power. Since then,
Turkish political parties have multiplied, but democ-
racy has been fractured by periods of instability and
intermittent military coups (1960, 1971, 1980),
which in each case eventually resulted in a return
of political power to civilians. In 1997, the military
again helped engineer the ouster—popularly dubbed
a “post-modern coup”’—of the then Islamic-oriented
government. Turkey intervened militarily on Cyprus
in 1974 to prevent a Greek takeover of the island
and has since acted as patron state to the “Turkish
Republic of Northern Cyprus,” which only Turkey
recognizes. A separatist insurgency begun in 1984 by
the Kurdistan Workers” Party (PKK)—now known
as the Kurdistan People’s Congress or Kongra-Gel
(KGK)—has dominated the Turkish military''s atten-
tion and claimed more than 30,000 lives. After the
capture of the group''s leader in 1999, the insurgents
largely withdrew from Turkey mainly to northem
Iraq. In 2004, KGK announced an end to its ceasefire
Railways: total: 2,165 km
country comparison to the world: 68
standard gauge: 471 km 1.435-m gauge
narrow gauge: 1,694 km 1.000-m gauge (65 km
electrified) (2008)
Roadways: total: 19,232 km
country comparison to the world: 110
paved: 12,655 km (includes 262 km of expressways)
unpaved: 6,577 km (2006)
Merchant marine: total: 9
country comparison to the world: 116
by type: bulk carrier 1, cargo 2, passenger/cargo 4,
roll on/roll off 2 (2010)
Ports and terminals: Bizerte, Gabes, Rades, Sfax,
Skhira
Airports: 98 (2012)
country comparison to the world: 61
Airports—with paved runways: total: 89
over 3,047 m: 16
2,438 to 3,047 m: 35
1524 to 2,437 m: 17
914 to 1,523 m: 17
under 914 m: 4 (2012)
Airports—with unpaved runways: total: 9
1,524 to 2,437 m: 1
914 to 1,523 m: 4
under 914 m: 4 (2012)
Heliports: 20 (2012)
Pipelines: gas 10,706 km; oil 3,636 km (2010)
Railways: total: 8,699 km
country comparison to the world: 23
standard gauge: 8,699 km 1.435-m gauge (1,928
km electrified) (2008)
Roadways: total: 352,046 km
country comparison to the world: 19 paved:
313,151 km (includes 2,010 km of expressways)
unpaved: 38,895 km (2008)
Waterways: 1,200 km (2010)
744
THE CIA WORLD FACTBOOK
country comparison to the world: 60
Merchant marine: total: 629
country comparison to the world: 18
by type: bulk carrier 102, cargo 281, chemical
tanker 80, container 42, liquefied gas 6, passen-
ger 2, passenger/cargo 60, petroleum tanker 25,
refrigerated cargo 1, roll on/roll off 29, specialized
tanker 1 foreign-owned: 1 (Italy 1)
registered in other countries: 645 (Albania 1,
Antigua and Barbuda 7, Azerbaijan 1, Bahamas
3, Barbados 1, Belize 16, Brazil 1, Cambodia 15,
Comoros 8, Cook Islands 4, Curacao 5, Cyprus 1,
Dominica 1, Georgia 14, Italy 4, Kazakhstan 1,
Liberia 16, Malta 233, Marshall Islands 70, Mol-
dova 18, Panama 62, Russia 101, Saint Kitts and
Nevis 18, Saint Vincent and the Grenadines 13,
Sierra Leone 9, Slovakia 1, Tanzania 13, Togo 4,
Tuvalu 1, unknown 3) (2010)
Ports and terminals: Aliaga, Ambarli, Diliskel-
esi, Eregli, Izmir, Izmit (Kocaeli), Mercin (Icel),
Limani, Yarimca','782a757a487e9c472611b4bb7992bab85db3f0e9d4124c60a18bcbb28c1c4a02','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4fa9a9190e970b63b7bd1117d0c3be4ec3332266070ec3adb0845d04015deb77',2025,'TM','Turkmenistan','transportation',1599,'Airports: 25 (2012)
country comparison to the world: 126
Airports—with paved runways: total: 21
over 3,047 m: 1
2,438 to 3,047 m:9
1,524 to 2,437 m:9
914 to 1,523 m: 2 (2012)
Airports—with unpaved runways: total: 5
1,524 to 2,437 m: 1
under 914 m: 4 (2012)
Heliports: 1 (2012)
Pipelines: gas 7,352 km; oil 1,457 km (2010)
Railways: total: 2,980 km
THE CIA WORLD FACTBOOK
country comparison to the world: 56
broad gauge: 2,980 km 1.520-m gauge (2008)
Roadways: total: 58,592 km
country comparison to the world: 73
paved: 47,577 km
unpaved: 11,015 km (2002)
Waterways: 1,300 km (Amu Darya and Kara Kum
canal are important inland waterways) (2011)
country comparison to the world: 54
Merchant marine: total: 11
country comparison to the world: 110
by type: cargo 4, chemical tanker 1, petroleum
tanker 5, refrigerated cargo 1 (2010)
Ports and terminals: Turkmenbasy','3dab6265d32925543c0d0744398916ec965fe0e29be023d08e70bf27b20fe0aa','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ddb1d0a84d11bc0d915f0780cb8e6dd11edb60b0ea522bb58e8d644a4b9b344c',2025,'TC','Turks and Caicos Islands','transportation',1608,'Airports: 8 (2012)
country comparison to the world: 163
Airports—with paved runways: total: 6
2,438 to 3,047 m: 1
1,524 to 2,437 m: 3
914 to 1,523 m: 1
under 914 m: 1 (2012)
Airports—with unpaved runways: total: 2
under 914 m: 2 (2012)
Roadways: total: 121 km
country comparison to the world: 212
paved; 24 km
unpaved: 97 km (2003)
Ports and terminals: Cockburn Harbour, Grand
Turk, Providenciales','137b256e33be2c9bcf9abfcf736731b0b46171c630ccd4e7bc63871de34e7563','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9c9de104ef4c32664ab97d196e918d7ab28d2f43de914f1ab22f57424532419d',2025,'TV','Tuvalu','transportation',1615,'Airports: 0 (2012)
country comparison to the world: 235
Airports—with unpaved runways: total: 1
1,524 to 2,437 m: 1 (2012)
Roadways: total: 8 km
country comparison to the world: 222
paved: 8 km (2002)
Merchant marine: total: 58
country comparison to the world: 67
by type: bulk carrier 4, cargo 24, chemical tanker
15, container 1, passenger 2, passenger/cargo 1,
petroleum tanker 10, refrigerated cargo 1
foreign-owned: 33 (China 4, Indonesia 1, Mal-
dives 1, Singapore 19, South Korea 1, Turkey 1,
Vietnam 6) (2010)
Ports and terminals: Funafuti','9ed31877af04d24125cd4059e68b7894175921e1babba2249df1e78f258d7c9c','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f8ebabd4c08202a8ad4f05a3d6cebb971a96a473f35b0d33b5e0463f29bf9225',2025,'UG','Uganda','transportation',1623,'Airports: 46 (2012)
country comparison to the world: 95
Airports—with paved runways: total: 5
over 3,047 m: 3
1,524 to,2,437 m: 1
914 to 1,523 m: 1 (2012)
Airports—with unpaved runways: total: 41
over 3,047 m: 1','577e1b96d81a3a9fb9a416585329228b2e098dfac439600cb9bb0b661f4ceb42','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('494c37288a2dd0feaa3f83ddd6294c88dbe13b15a033ed6879a4fc348197dbad',2025,'UA','Ukraine','transportation',1634,'Airports: 412 (2012)
country comparison to the world: 21
Airports—with paved runways: total: 179
over 3,047 m: 13
2,438 to 3,047 m: 49
1,524 to 2,437 m: 22
914 to 1,523 m: 6
under 914 m: 89 (2012)
Airports—with unpaved runways: cotal: 233
2,438 to 3,047 m: 2
1,524 to 2,437 m: 6
914 to 1,523 m:9
under 914 m: 216 (2012)
Heliports: 7 (2012)
Pipelines: gas 36,493 km; oil-4,514 km; refined
products 4,211 km (2010)
Railways: total: 21,684 km
country comparison to the world: 12
broad gauge: 21,684 km 1.524-m gauge (9,854 km
electrified) (2009)
Roadways: total: 169,496 km
country comparison to the world: 29
paved: 165,844 km (includes 15 km of expressways)
unpaved: 3,652 km (2009)
Waterways: 1,672 km (most on Dnieper River)
(2012)
country comparison to the world: 47
Merchant marine: total: 134
country comparison to the world: 43
by type: bulk carrier 3, cargo 98, chemical tanker 1,
passenger 6, passenger/cargo 5, petroleum tanker 8,
refrigerated cargo 11, specialized tanker 2
registered in other countries: 172 (Belize 6, Cam-
bodia 35, Comoros 10, Cyprus 3, Dominica 1,
Georgia 10, Liberia 10, Malta 29, Marshall Islands
1, Moldova 14, Mongolia 1, Panama 8, Russia
12, Saint Kitts and Nevis 8, Saint Vincent and
the Grenadines 12, Sierra Leone 5, Slovakia 2,
unknown 5)({2010)
Ports and terminals: Feodosiya (Theodosia),
Illichivsk, Mariupol’, Mykolayiv, Odesa, Yuzhnyy','af2baac753257bd280d91bd533ebe8963a567c304bd709d1fd2a4da255cb7805','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a0d1e829bb62efad5f86e2785d0b0e62faf2e72478bca52987473cb900512830',2025,'AE','United Arab Emirates','transportation',1642,'Airports: 42 (2012)
country comparison to the world: 101
763
Airports—with paved runways: total: 25
over 3,047 m: 12
2,438 to 3,047 m:3
1524 to 2,437 m:4
914 to 1,523 m: 4
under 914 m: 2 (2012)
Airports—with unpaved runways: total: 17
over 3,047 m: 1
2,438 to 3,047 m: 1
1,524 to 2,437 m: 4
914 to 1,523 m: 6
under 914 m: 5 (2012)
Heliports: 5 (2012)
Pipelines: condensate 458 km; gas 2,352 km; liq-
uid petroleum gas 220 km; oil 1,437 km; refined
products 212 km (2010)
Roadways: total: 4,080 km
country comparison to the world: 157 paved:
4,080 km (includes 253 km of expressways) (2008)
Merchant marine: total: 61
country comparison to the world: 66
by type: bulk carrier 3, cargo 13, chemical tanker
8, container 7, liquefied gas 1, passenger/cargo 1,
petroleum tanker 24, roll on/roll off 4 foreign-
owned: 13 (Greece 3, Kuwait 10)
registered in other countries: 253 (Bahamas
23, Barbados 1, Belize 3, Cambodia 2, Comoros
THE CIA WORLD FACTBOOK
8, Cyprus 3, Georgia 2, Gibraltar 5, Honduras 1,
Hong Kong 1, India 4, Iran 2, Jordan 2, Liberia
37, Malta 1, Marshall Islands 12, Mexico 1, Neth-
erlands 4, North Korea 2, Panama 83, Papua New
Guinea 6, Philippines 1, Saint Kitts and Nevis 8,
Saint Vincent and the Grenadines 3, Saudi Ara-
bia 6, Sierra Leone 1, Singapore 10, Tanzania 3,
Togo 1, UK 8, Vanuatu 1, unknown 8) (2010)
Ports and terminals: Al Fujayrah, Mina’ Jabal
‘Ali (Dubai), Khor Fakkan (Khawr Fakkan),
Mubarraz Island, Mina’ Rashid (Dubai), Mina’
Saqr (Ra’s al Khaymah)','c562d845a7cc577b301a50723e4a582588f6eeb9b8cc87d466b519a536d90226','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4a13feaa1fe0a6ebc2827b9160bc3d36b7a1fb3e836434c354a67852d154537d',2025,'GB','United Kingdom','transportation',1651,'Airports: 462 (2012)
country comparison to the world: 19
Airports—with paved runways: total: 272 over
3,047 m: 7
2,438 to 3,047 m: 31
1,524 to 2,437 m: 93
914 to 1,523 m: 76
under 914 m: 65 (2012)
Airports—with unpaved siti total: 190
1,524 to 2,437 m: 2
914 to 1,523 m: 25
under 914 m: 163 (2012)
Heliports: 9 (2012)
Pipelines: condensate 8 km; gas 14,071 km; liquid
petroleum gas 59 km; oil 595 km; refined products
4,907 km (2010)
Railways: total: 16,454 km
country comparison to the world: 17
broad gauge: 303 km 1.600-m gauge (in Northem
Ireland)
standard gauge: 16,151 km 1.435-m gauge (5,248
km electrified) (2008)
Roadways: total: 394,428 km
country comparison to the world: 16
paved: 394,428 km (includes 3,519 km of express-
ways) (2009)
Waterways: 3,200 km (620 km used for com-
merce) (2009)
country comparison to the world: 32
Merchant marine: total: 504
country comparison to the world: 22
by type: bulk carrier 33, cargo 76, carrier 4, chemi-
cal tanker 58, container 178, liquefied gas 6, pas-
senger 7, passenger/cargo 66, petroleum tanker
18, refrigerated cargo 2, roll on/roll off 31, vehicle
carrier 25
foreign-owned: 271 (Australia 1, Bermuda 6,
China 7, Denmark 43, France 39, Germany 59,
Hong Kong 12, Ireland 1, Italy 3, Japan 5, Nether-
lands 1, Norway 32, Sweden 28, Taiwan 11, Tanza-
nia 1, UAE 8, US 14)
registered in other countries: 308 (Algeria 15,
Antigua and Barbuda 1, Argentina 2, Australia
5, Bahamas 18, Barbados 6, Belgium 2, Belize 4,
Bermuda 14, Bolivia 1, Brunei 2, Cambodia 1,
Cape Verde 1, Cayman Islands 2, Comoros 1,
Cook Islands 2, Cyprus 7, Georgia 5, Gibraltar 6,
Greece 6, Honduras 1, Hong Kong 33, Indonesia
2, Italy 2, Liberia 22, Liberia 32, Luxembourg 5,
Malta 21, Marshall Islands 12, Marshall Islands
3, Moldova 3, Nigeria 2, NZ 1, Panama 37,
Panama 5, Saint Kitts and Nevis 1, Saint Vin-
cent and the Grenadines 6, Sierra Leone 1, Sin-
gapore 6, Thailand 6, Tonga 1, US 4, unknown
1) (2010)
Ports and terminals: Dover, Felixstowe, Imming-
ham, Liverpool, London, Southampton, Teesport
(England); Forth Ports (Scotland); Milford Haven
(Wales)
oil terminals: Fawley Marine terminal, Liverpool
Bay terminal (England); Braefoot Bay termi-
nal, Finnart oil terminal, Hound Point terminal
(Scotland)','ea713e660dfe21186e76956c963b1964d4faccb7a024b38e7e8ca6d3d6bfe5db','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d681f27bc54b94072721d083aad7f568086b1460cfe3b64f3ccae7cfbfd5480c',2025,'US','United States','transportation',1660,'Airports: 15,079 (2010)
country comparison to the world: 1
Airports—with paved runways: total: 5,194
over 3,047 m: 189
2,438 to 3,047m:235 _ «4
1,524 to 2,437 m: 1,479
i 914 to 1,523 m: 2,316
under 914 m: 975 (2010)
Airports—with unpaved runways: total: 9,885
2,438 to 3,047 m:7
1,524 to 2,437 m: 155
914 to 1,523 m: 1,752
under 914 m: 7,971 (2010)
Heliports: 126 (2012)
Pipelines: natural gas 548,665 km; petroleum
products 244,620 km (2010)
Railways: total: 224,792 km
country comparison to the world: 1
standard gauge: 224,792 km 1.435-m gauge
(2007)
Roadways: total: 6,506,204 km
country comparison to the world: 1
paved: 4,374,784 km (includes 75,238 km of
expressways)
unpaved: 2,131,420 km (2008)
Waterways: 41,009 km (19,312 km used for
commerce; Saint Lawrence Seaway of 3,769 km,
including the Saint Lawrence River of 3,058 km,
is shared with Canada) (2012)
country comparison to the world: 4
Merchant marine: total: 393
country comparison to the world: 26
by type: barge carrier 6, bulk carrier 55, cargo 51,
carrier 2, chemical tanker 30, container 84, pas-
senger 18, passenger/cargo 56, petroleum tanker
35, refrigerated cargo 3, roll on/roll off 27, vehicle
carrier 26
foreign-owned: 85 (Australia 1, Bermuda 5, Den-
mark 31, France 4, Germany 5, Malaysia 2, Nor-
way 17, Singapore 16, UK 4)
registered in other countries: 794 (Antigua and Bar-
buda 7, Australia 2, Bahamas 109, Belgium 1, Ber-
muda 26, Canada 10, Cayman Islands 57, Comoros
2, Cyprus 5, Georgia 1, Greece 8, Honduras 1, Hong
Kong 44, Indonesia 2, Ireland 2, Isle of Man 1, Italy
23, Liberia 53, Malta 34, Marshall Islands 200, Neth-
erlands 16, Norway 10, Panama 90, Portugal 4, Saint
Kitts and Nevis 1, Saint Vincent and the Grenadines
18, Singapore 36, South Korea 8, Togo 1, UK 14,
Vanuatu 2, unknown 6) (2010)
Ports and terminals: cargo ports (tonnage):
Baton Rouge, Corpus Christi, Hampton Roads,
Houston, Long Beach, Los Angeles, New Orleans,
New York, Plaquemines, Tampa, Texas City
container ports (TEUs): Los Angeles (7,849,985),
Long Beach (6,350,125), New York/New Jersey
(5,265,058), Savannah (2,616,126), Oakland
(2,236,244), Hampton Roads (2,083,278)
(2008)
cruise departure ports (passengers): Miami
(2,032,000), Port Everglades (1,277,000), Port
Canaveral (1,189,000), Seattle (430,000), Long
Beach (415,000) (2009) oil terminals: LOOP ter-
minal, Haymark terminal
Airports: Baker Island: one abandoned World
War II runway of 1,665 m covered with vegetation
and unusable
Howland Island: airstrip constructed in 1937 for
scheduled refueling stop on the round-the-world
flight of Amelia EARHART and Fred NOONAN;
the aviators left Lae, New Guinea, for Howland
Island but were never seen again; the airstrip is no
longer serviceable
Johnston Atoll: one closed and not maintained
Kingman Reef: lagoon was used as a halfway sta-
tion berween Hawai: and American Samoa by Pan
American Airways for flying boats in 1937 and
1936
Midway Islands: 3—one operational (2,377 m
paved); no fuel for sale except emergencies
Palmyra Atoll: 1—1,846 m unpaved runway; pri-
vately owned (2012)
Ports and terminals: Baker, Howland, and
Jarvis Islands, and Kingman Reef:none; offshore
anchorage only
Johnston Atoll: Johnston Island
Midway Islands: Sand Island
Palmyra Atoll: West Lagoon','63413da3b2e5262774502ec56214e7b4c8e4c27bb65aa806ee79fcb4cdb192a1','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('488dced0ad79f658fdb6109f53f5c9e2144e676ddd87cfa0677791a73469c010',2025,'UY','Uruguay','transportation',1667,'Airports: 94 (2012)
country comparison to the world: 63
Airports—with paved runways: total: 11
over 3,047 m: 1 :
1,524 to 2,437 m: 4
914 to 1,523 m: 4
under 914 m: 2 (2012)
Airports—with unpaved runways: total: 83
1,524 to 2,437 m: 3
914 to 1,523 m: 27
under 914 m: 53 (2012)
Pipelines: gas 226 km; oil 155 km (2010)
Railways: total: 1,641 km
country comparison to the world: 77
standard gauge: 1,641 km 1.435-m gauge (1,200
km operational) (2010)
Roadways: total: 77,732 km
country comparison to the world: 61
paved: 7,743 km
unpaved: 69,989 km (2010)
Waterways: 1,600 km (2011)
country comparison to the world: 49
Merchant marine: total: 16
country comparison to the world: 100
by type: bulk carrier 1, cargo 2; chemical tanker
3, passenger/cargo 6, petroleum tanker 3, roll on/
roll off 1
foreign-owned: 8 (Argentina 1, Denmark 1,
Greece 1, Spain 5)
registered in other countries: 1 (Liberia 1) (2010)
Ports and terminals: Montevideo','a0613bb588d6260fc10d845d547aeb5003c7b96405a133f7bf5741ca92a4e2f0','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('00a488909519f9f4036eded6c90f316e654ba9071823dda21288d7bf5a417466',2025,'UZ','Uzbekistan','transportation',1676,'Airports: 53 (2012)
country comparison to the world: 87
Airports—with paved runways: total: 33
over 3,047 m: 6
2,438 to 3,047 m: 13
1,524 to 2,437 m: 6
914 to 1,523 m: 4
under 914 m: 4 (2012)
Airports—with unpaved runways: total: 20
2,438 to 3,047 m: 2
under 914 m: 18 (2012)
Pipelines: gas 10,253 km; oil 868 km (2010)
Railways: total: 3,645 km
country comparison to the world: 47
broad gauge: 3,645 km 1.520-m gauge (620 km
electrified) (2008)
Roadways: total: 86,496 km
country comparison to the world: 52
paved: 75,511 km
unpaved: 10,985 km (2000)
Waterways: 1,100 km (2012)
country comparison to the world: 63
Ports and terminals: Termiz (Amu Darya)','054e0f114b2b32b7dfc404e28e1aa49054d318eb2c440c55cf7c0e89902db7ef','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('547b559343a720e3f4490dc2282e3093f6fcde79d27c8a44a8eae8f4eaba2f25',2025,'VU','Vanuatu','transportation',1686,'Airports: 31 (2012)
country comparison to the world: 113
Airports—with paved runways: total: 3
2,438 to 3,047 m: 1
1,524 to 2,437 m: 1
914 to 1.523 m: 1 (2012)
Airports—with unpaved runways: total: 28
914 to 1.523 m: 5
under 914 m: 23 (2012)
Roadways: total: 1,070 km
country comparison to the world: 183
paved: 256 km
unpaved: 814 km (1999)
Merchant marine: total: 77
country comparison to the world: 59
by type: bulk carrier 38, cargo 8, chemical tanker
2, container 1, liquefied gas 2, passenger 1, refrig-
erated cargo 24, vehicle carrier 1 :
foreign-owned: 72 (Belgium 1, Canada 5, China
1, Greece 3, Japan 39, Norway 1, Poland 9, Russia
7, Singapore 2, Taiwan 1, UAE 1, US 2) (2010)
Ports and terminals: Forari Bay, Luganville
(Santo, Espiritu Santo), Port-Vila','3a185396589eac39ce7a78a862945fd8bc79e66f90361e7777f13f3115097b37','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('42691d72229e462ca4d1122bd17790889e3c62a13884f78192294ed5c846b2eb',2025,'VN','Viet Nam','transportation',1693,'Airports : 44 (2012)
country comparison to the world: 97
Airports—with paved runways: total: 37
over 3,047 m:9
2,438 to 3,047 m: 6
1,524 to 2,437 m: 13
914 to 1,523 m: 9 (2012)
Airports—with unpaved runways: total: 7
1,524 to 2,437 m: 1
914 to 1,523 m: 3
under 914 m: 3 (2012)
Heliports: 1 (2012)
Pipelines: condensate 28 km; condensate/gas 10
km; gas 216 km; refined products 206 km (2010)
Railways: total: 2,632 km
country comparison to the world: 62
standard gauge: 527 km 1.435-m gauge
narrow gauge: 2,105 km 1.000-m gauge (2008)
Roadways: total: 180,549 km
country comparison to the world: 26
paved: 133,899 km
unpaved: 46,650 km (2008)
Waterways: 17,702 km (5,000 km are navigable
by vessels up to 1.8 m draft) (2011)
country comparison to the world: 7
Merchant marine: total: 579
country comparison to the world: 20
by type: barge carrier 1, bulk carrier 142, cargo 335,
chemical tanker 23, container 19, liquefied gas 7,
passenger/cargo 1, petroleum tanker 48, refriger-
ated cargo 1, roll on/roll off 1, specialized tanker 1
registered in other countries: 86 (Cambodia 1,
Kiribati 2, Mongolia 33, Panama 43, Taiwan 1,
Tuvalu 6) (2010)
Ports and terminals: Cam Pha Port, Da Nang,
Haiphong, Ho Chi Minh, Phu My, Quy Nhon
Transportation—note: the International Mari-
time Bureau reports the territorial and offshore
waters in the South China Sea as high risk for
piracy and armed robbery against ships; numer-
ous commercial vessels have been attacked and
hijackéd both at anchor and while underway;
hijacked vessels are often disguised and cargo
diverted to ports in East. Asia; crews have been
murdered or cast adrift','93b152763ba7fe8f4796bab108ade8eab1177ecf8c1114552e75456c2988c300','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f2af3edb81b7991eb4c7fc4e9eb3d2dbba05866346a3edc3fc1ba12cb1dbb97d',2025,'WF','Wallis and Futuna','transportation',1702,'Airports: 1 (2012)
country comparison to the world: 211
Airports—with paved runways:
total: 1
2,438 to 3,047 m: 1 (2012)
Ports and terminals: none; two offshore anchor-
ages for large ships
Transportation—note: there are no commercial
or civilian flights to and from Wake Island, except
in direct support of island missions; emergency
landing is available
Airports: 2 (2012)
country comparison to the world: 203
Airports—with paved runways: total: 2
1,524 to 2,437 m: 1
914 to 1,523 m: 1 (2012)
Ports and terminals: Leava, Mata-Utu','31b72e76602ae16256f07ceed2dc17d4c04c339d5185f1dc03a1902e1864b222','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c76b3a147abb56ac4737cc6334c3caada84a71f9cdea31e5039e6f4717a39c9f',2025,'EH','Western Sahara','transportation',1717,'Airports: 6 (2012)
country comparison to the world: 174
Airports—with paved runways: total: 3
2,438 to 3,047 m: 3 (2012)
Airports—with unpaved runways: total: 3
1,524 to 2,437 m: 1
914 to 1,523 m: 1
under 914 m: 1 (2012)
Ports and terminals: Ad Dakhla, Laayoune (El
Aaiun)
Airports: total airports—43,794 (2012)
top ten by passengers: Atlanta (ATL)—
89,331,622; Beijing (PEK)—73,948,113; Chi-
cago (ORD)—66,774,738; London (LHR)—
65,884,143; Tokyo (HND)—64,211,074; Los
Angeles (LAX)—59,070,127; Paris (CDG)—
58,167,062; Dallas/Fort Worth (DFW)—
56,906,610; Frankfurt (FRA)—53,009,221; Den-
ver (DEN)—52,209,377 (2010)
top ten by cargo (metric tons): Hong Kong
(HKG)—4, 165,852; Memphis (MEM)—.,
3,916,811; Shanghai (PVG)—3,228,081; Incheon
(ICN)—2,684,499; Anchorage (ANC)—
2,646,695; Paris (CDG)—-2,399,067; Frankfurt
(FRA)—2,275,000; Dubai (DXB)—2,270,498;
Tokyo (NRT)—2,167,853; Louisville (SDF)—
2,166,656 (2010)
Heliports: 3,825 (2012)
Railways: total: 1,139,615 km (2008)
Roadways: total: 102,260,304 km (2008)
Waterways: 671,886 km
top ten longest rivers: Nile (Africa) 6,693 km;
Amazon (South America) 6,436 km; Mississippi-
Missouri (North America) 6,238 km; Yenisey-
Angara (Asia) 5,981 km; Ob-Irtysh (Asia) 5,569
km; Yangtze (Asia) 5,525 km; Yellow (Asia) 4,671
km; Amur (Asia) 4,352 km; Lena (Asia) 4,345 km;
Congo (Africa) 4,344 km
note: rivers are not necessarily navigable along the
entire length; if measured by volume, the Amazon
is the largest river in the world
top ten largest natural lakes (by surface area):
Caspian Sea (Azerbaijan, Iran, Kazakhstan, Rus-
sia, Turkmenistan) 372,960 sq km; Lake Superior
(Canada, United States) 82,414 sq km; Lake
Victoria (Kenya, Tanzania, Uganda) 69,490 5q
km; Lake Huron (Canada, United States) 59,596
sq, km; Lake Michigan (United: States) 57,441
sq km; Lake Tanganyika (Burundi, Democratic
Republic of the Congo, Tanzania, Zambia) 32,890
sq km; Great Bear Lake (Canada) 31,800 sq km;
Lake Baikal (Russia) 31,494 sq km; Lake Nyasa
(Malawi, Mozambique, Tanzania) 30,044 sq km;
Great Slave Lake (Canada) 28,400 sq km
note: the areas of the lakes are subject to seasonal
variation; only the Caspian Sea is saline, the rest
are fresh water:
Ports and terminals: top ten container ports as
measured by Twenty-Foot Equivalent Units (TEUs)
throughput: Shanghai (China)—29,069,000; Sin-
gapore (Singapore)—28,431,100; Hong Kong
(China) —23,669,242;° Shenzhen (China)—
22,509,700; Busan (South Korea)—14,194,334;
Ningbo (China)—13,144,000; Guangzhou
(China)—12,486,900; Qingdao ~“(China)—
12,012,000; Dubai (UAE)—11,575,775;—Rotter-
dam (Netherlands)-11,145,804 (2010)
Transportation—note: the International Mari-
time Bureau (IMB) reports that 2011 saw a very
slight (1%) decrease in global pirate activities
with marginally fewer people taken hostage at
sea; in 2011, pirates attacked a total of 439 ships
world-wide including hijacking 45 ships, cap-
turing 802 seafarers, and killing eight; while the
Horn of Africa remains the most dangerous area
for maritime shipping, accounting for more than
50% of all attacks in 2011, a number of attacks also
occurred in the coastal waters of Indonesia, the
South China Sea, Bangladesh, and West Africa;
as of July 2012, there were 189 attacks worldwide
with 20 hijackings; the Horn of Africa remains the
most dangerous region in 2012 with 70 attacks, 13
hijackings, 212 hostages seized; as of July 2012,
Somali pirates held 11 vessels and 174 hostages;
the decrease in successful pirate attacks is due, in
part, to more aggressive anti-piracy operations by
international naval forces as well as the increased
use of armed security teams aboard merchant ships','bcd9c225c15bca63c1e8d20d570d7267eb1eb856f6f155deacf01b39d7a20924','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('265c9c5017eb6ac5e64d5bbf79cb5e965346b730e2aa784c69c3eb71e748ee14',2025,'YE','Yemen','transportation',1722,'Airports: 57 (2012)
country comparison to the world: 84
Airports—with paved runways: total: 17
over 3,047 m: 4
2,438 to 3,047 m: 9
1,524 to 2,437 m:3
914 ta 1,523 m: 1 (2012)
Airports—with unpaved runways: total: 40
over 3,047 m: 3
2,438 to 3,047 m:5
1,524 to 2,437 m:7
914 to 1,523 m: 16
under 914 m: 9 (2012)
Pipelines: gas 423 km; liquid petroleum gas
22 km; oil 1,367 km (2010)
Roadways: total: 71,300 km
country comparison to the world: 65
paved: 6,200 km
unpaved: 65,100 km (2005)
Merchant marine: total:5
country comparison to the world: 126
by type: chemical tanker 2, petroleum tanker 2,
roll on/roll off 1
registered in other countries: 14 (Moldova 4,
Panama 4, Sierra Leone 2, Togo 1, unknown 3)
(2010)
Ports and terminals: Aden, Al Hudaydah,
Al Mukalla
Transportation—note: the International Mari-
time Bureau reports offshore waters in the Gulf of
Aden are high risk for piracy; numerous vessels,
including commercial shipping and pleasure craft,
have been attacked and hijacked both at anchor
and while underway; crew, passengers, and cargo
are held for ransom; the presence of several naval
task forces in the Gulf of Aden and additional
anti-piracy measures on the part of ship operators
reduced the incidence of piracy in that body of
water by more than half in 2010','7d1e2800c1e053cf77a5c7d27e07898f0224cf7ab93c7d7fb6a2d20d425f9480','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);

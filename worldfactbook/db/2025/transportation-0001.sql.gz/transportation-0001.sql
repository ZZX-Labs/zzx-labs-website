SET NAMES utf8mb4;
CREATE TABLE IF NOT EXISTS worldfactbook_chunks (
  chunk_id CHAR(64) NOT NULL,
  edition_year SMALLINT UNSIGNED NOT NULL,
  entity_code VARCHAR(24) NOT NULL DEFAULT '',
  entity_name VARCHAR(160) NOT NULL DEFAULT '',
  category VARCHAR(96) NOT NULL,
  ordinal INT UNSIGNED NOT NULL,
  content MEDIUMTEXT NOT NULL,
  content_sha256 CHAR(64) NOT NULL,
  source_provider VARCHAR(64) NOT NULL,
  source_identifier VARCHAR(255) NOT NULL,
  source_format VARCHAR(32) NOT NULL,
  source_sha256 CHAR(64) NOT NULL,
  source_url TEXT NOT NULL,
  extractor VARCHAR(64) NOT NULL,
  PRIMARY KEY (chunk_id),
  KEY idx_wfb_year_category (edition_year, category),
  KEY idx_wfb_entity_year (entity_code, edition_year),
  KEY idx_wfb_source_sha (source_sha256)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ff37f72fb7337037de6a3bf8053ac1a3566ceb1d2c853630a651120a5b072564',2025,'AF','Afghanistan','transportation',9,'National air transport system:
number of registered air carriers:
3 (2020)
inventory of registered aircraft operated by air carriers:
13
annual passenger traffic on registered air carriers:
1,722,612 (2018)
annual freight traffic on registered air carriers:
29.56 million (2018) mt-km
Civil aircraft registration country code prefix:
YA
Airports:
46 (2021)
comparison ranking:
total 94
Airports - with paved runways:
29
note:
paved runways have a concrete or asphalt surface but not all have facilities for refueling, maintenance, or air traffic control; the length of a runway required for aircraft to safely operate depends on a number of factors including the type of aircraft, the takeoff weight (including passengers, cargo, and fuel), engine types, flap settings, landing speed, elevation of the airport, and average maximum daily air temperature; paved runways can reach a length of 5,000 m (16,000 ft.), but the “typical” length of a commercial airline runway is between 2,500-4,000 m (8,000-13,000 ft.)
Airports - with unpaved runways:
17
note:
unpaved runways have a surface composition such as grass or packed earth and are most suited to the operation of light aircraft; unpaved runways are usually short, often less than 1,000 m (3,280 ft.) in length; airports with unpaved runways often lack facilities for refueling, maintenance, or air traffic control
Heliports:
1 (2021)
Pipelines:
466 km gas (2013)
Roadways:
total:
34,903 km (2017)
paved:
17,903 km (2017)
unpaved:
17,000 km (2017)
comparison ranking:
total 92
Waterways:
1,200 km (2011) (chiefly Amu Darya, which handles vessels up to 500 DWT)
comparison ranking:
64
Ports and terminals:
river port(s):
Hairatan, Qizil Qal’ah (Amu Darya)','ec41e20774db86a1404059fa064923b1ea430e738835a09308bb1fe3e8ab5a37','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bd7fa81de5ad001f7baf8a90b642e31970306159c9d5c45ee2d1423362e5a03b',2025,'AF','Afghanistan','transportation',20,'Airports:
1 (2021)
comparison ranking:
total 224
Airports - with paved runways:
note:
paved runways have a concrete or asphalt surface but not all have facilities for refueling, maintenance, or air traffic control; the length of a runway required for aircraft to safely operate depends on a number of factors including the type of aircraft, the takeoff weight (including passengers, cargo, and fuel), engine types, flap settings, landing speed, elevation of the airport, and average maximum daily air temperature; paved runways can reach a length of 5,000 m (16,000 ft.), but the “typical” length of a commercial airline runway is between 2,500-4,000 m (8,000-13,000 ft.)','58584d34ffe995143e151576a8a4171448bce95a3cc7fc330d2f1b1e9d34aec3','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('801730a108398ef6e9f4a06c131fb066387f38c77d40af22aa811b4cec1cc78c',2025,'AL','Albania','transportation',30,'National air transport system:
number of registered air carriers:
2 (2020)
inventory of registered aircraft operated by air carriers:
5
annual passenger traffic on registered air carriers:
303,137 (2018)
Civil aircraft registration country code prefix:
ZA
Airports:
3 (2021)
comparison ranking:
total 190
Airports - with paved runways:
3
civil airports:
0
military airports:
1
joint use (civil-military) airports:
1
other airports:
1
note:
paved runways have a concrete or asphalt surface but not all have facilities for refueling, maintenance, or air traffic control; the length of a runway required for aircraft to safely operate depends on a number of factors including the type of aircraft, the takeoff weight (including passengers, cargo, and fuel), engine types, flap settings, landing speed, elevation of the airport, and average maximum daily air temperature; paved runways can reach a length of 5,000 m (16,000 ft.), but the “typical” length of a commercial airline runway is between 2,500-4,000 m (8,000-13,000 ft.)
Pipelines:
498 km gas (a majority of the network is in disrepair and parts of it are missing), 249 km oil (2015)
Railways:
total:
424 km (2017)
2021-All the trains in the country suspended
comparison ranking:
total 119
Roadways:
total:
3,945 km (2018)
paved:
(2002)
unpaved:
(2002)
comparison ranking:
total 156
Waterways:
41 km (2011) (on the Bojana River)
comparison ranking:
114
Merchant marine:
total:
69 (2022)
by type:
general cargo 47, oil tanker 1, other 21
comparison ranking:
total 110
Ports and terminals:
major seaport(s):
Durres, Sarande, Shengjin, Vlore','cd0bb4e359dd0b81bebc831158df6741b6df8049b577add5378da4b71512fe7f','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b070f87261f5901405dfa517538d9195922084ef5828551e71c043b58591107e',2025,'DZ','Algeria','transportation',42,'National air transport system:
number of registered air carriers:
3 (2020)
inventory of registered aircraft operated by air carriers:
87
annual passenger traffic on registered air carriers:
6,442,442 (2018)
annual freight traffic on registered air carriers:
28.28 million (2018) mt-km
Civil aircraft registration country code prefix:
7T
Airports:
149 (2021)
comparison ranking:
total 36
Airports - with paved runways:
67 (2023)
civil airports:
19
military airports:
11
joint use (civil-military) airports:
14
other airports:
32
note:
paved runways have a concrete or asphalt surface but not all have facilities for refueling, maintenance, or air traffic control; the length of a runway required for aircraft to safely operate depends on a number of factors including the type of aircraft, the takeoff weight (including passengers, cargo, and fuel), engine types, flap settings, landing speed, elevation of the airport, and average maximum daily air temperature; paved runways can reach a length of 5,000 m (16,000 ft.), but the “typical” length of a commercial airline runway is between 2,500-4,000 m (8,000-13,000 ft.)
Airports - with unpaved runways:
82
note:
unpaved runways have a surface composition such as grass or packed earth and are most suited to the operation of light aircraft; unpaved runways are usually short, often less than 1,000 m (3,280 ft.) in length; airports with unpaved runways often lack facilities for refueling, maintenance, or air traffic control
Heliports:
4 (2022)
Pipelines:
2,600 km condensate, 16,415 km gas, 3,447 km liquid petroleum gas, 7,036 km oil, 144 km refined products (2013)
Railways:
total:
4,020 km (2019)
comparison ranking:
total 46
Roadways:
total:
104,000 km (2015)
paved:
71,656 km (2015)
unpaved:
32,344 km (2015)
comparison ranking:
total 45
Merchant marine:
total:
119 (2022)
by type:
bulk carrier 1, container ship 4, general cargo 11, oil tanker 14, other 89
comparison ranking:
total 84
Ports and terminals:
major seaport(s):
Algiers, Annaba, Arzew, Bejaia, Djendjene, Jijel, Mostaganem, Oran, Skikda
LNG terminal(s) (export):
Arzew, Bethioua, Skikda','166c62a245dbdaeffeb7434bea0d4f7e01dbed2fb8a2073e8cf4f0df223605e9','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9725877c6a0f206efb728fb892db5f3fc6a6de47d3f24c53b241d4c542f3b99b',2025,'AS','American Samoa','transportation',55,'Airports:
3 (2021)
comparison ranking:
total 196
Airports - with paved runways:
3
note:
paved runways have a concrete or asphalt surface but not all have facilities for refueling, maintenance, or air traffic control; the length of a runway required for aircraft to safely operate depends on a number of factors including the type of aircraft, the takeoff weight (including passengers, cargo, and fuel), engine types, flap settings, landing speed, elevation of the airport, and average maximum daily air temperature; paved runways can reach a length of 5,000 m (16,000 ft.), but the “typical” length of a commercial airline runway is between 2,500-4,000 m (8,000-13,000 ft.)
Roadways:
total:
241 km (2016)
comparison ranking:
total 205
Ports and terminals:
major seaport(s):
Pago Pago','480a8b765fff671859a14b05d600f07fd64f51181009b0c0993adae069b242e6','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3d8ab1a5a169a0636a88eb3a32cc04d9368383ae19ed33ee0e5a9d95b11374b3',2025,'AD','Andorra','transportation',66,'Civil aircraft registration country code prefix:
C3
Roadways:
total:
320 km (2019)
comparison ranking:
total 201','6e2deb84ced37e5d809ee79b117a6f4a43426ce8c93b6916b030584c6de0a843','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4cd541c9602b35b61daeb73bd0980ef8b014180f9525fc988b27ae72f73c8586',2025,'AO','Angola','transportation',9,'National air transport system:
number of registered air carriers:
10 (2020)
inventory of registered aircraft operated by air carriers:
55
annual passenger traffic on registered air carriers:
1,516,628 (2018)
annual freight traffic on registered air carriers:
78.16 million (2018) mt-km
Civil aircraft registration country code prefix:
D2
Airports:
102 (2021)
comparison ranking:
total 54
Airports - with paved runways:
32
civil airports:
3
military airports:
1
joint use (civil-military) airports:
2
other airports:
26
note:
paved runways have a concrete or asphalt surface but not all have facilities for refueling, maintenance, or air traffic control; the length of a runway required for aircraft to safely operate depends on a number of factors including the type of aircraft, the takeoff weight (including passengers, cargo, and fuel), engine types, flap settings, landing speed, elevation of the airport, and average maximum daily air temperature; paved runways can reach a length of 5,000 m (16,000 ft.), but the “typical” length of a commercial airline runway is between 2,500-4,000 m (8,000-13,000 ft.)
Airports - with unpaved runways:
70
note:
unpaved runways have a surface composition such as grass or packed earth and are most suited to the operation of light aircraft; unpaved runways are usually short, often less than 1,000 m (3,280 ft.) in length; airports with unpaved runways often lack facilities for refueling, maintenance, or air traffic control
Heliports:
1 (2021)
Pipelines:
352 km gas, 85 km liquid petroleum gas, 1,065 km oil, 5 km oil/gas/water (2013)
Railways:
total:
2,761 km (2022)
narrow gauge:
2,638 km (2022) 1.067-m gauge 123 km 0.600-mm gauge
comparison ranking:
total 60
Roadways:
total:
26,000 km (2018)
paved:
13,600 km (2018)
unpaved:
12,400 km (2018)
comparison ranking:
total 102
Waterways:
1,300 km (2011)
comparison ranking:
57
Merchant marine:
total:
58 (2022)
by type:
general cargo 13, oil tanker 8, other 37
comparison ranking:
total 115
Ports and terminals:
major seaport(s):
Cabinda, Lobito, Luanda, Namibe
LNG terminal(s) (export):
Angola Soyo','ab866b2d25e06ba0540249d8defb8ce228f5e2bf17f9d079d386fcb8241b45fa','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('78d6d44b3ef50901b86a643ceb92643e57d4630ad748088d0cb7b180263f60bc',2025,'AI','Anguilla','transportation',21,'National air transport system:
number of registered air carriers:
2 (2020)
inventory of registered aircraft operated by air carriers:
4
Civil aircraft registration country code prefix:
VP-A
Airports:
1 (2021)
comparison ranking:
total 227
Airports - with paved runways:
1
note:
paved runways have a concrete or asphalt surface but not all have facilities for refueling, maintenance, or air traffic control; the length of a runway required for aircraft to safely operate depends on a number of factors including the type of aircraft, the takeoff weight (including passengers, cargo, and fuel), engine types, flap settings, landing speed, elevation of the airport, and average maximum daily air temperature; paved runways can reach a length of 5,000 m (16,000 ft.), but the “typical” length of a commercial airline runway is between 2,500-4,000 m (8,000-13,000 ft.)
Roadways:
total:
175 km (2004)
paved:
82 km (2004)
unpaved:
93 km (2004)
comparison ranking:
total 209
Merchant marine:
total:
2 (2022)
by type:
other 2
comparison ranking:
total 176
Ports and terminals:
major seaport(s):
Blowing Point, Road Bay','bf1704357094bd840aa409d1520007ddce79935ffad270e1f33bdb91dc3265a8','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('247cc4bfcce5f9d024494b2e5a005d3dba6ce36bc255fe9f974b30a55c5549d9',2025,'AQ','Antarctica','transportation',31,'Airports:
17 (2021)
comparison ranking:
total 141
Airports - with unpaved runways:
17
note:
unpaved runways have a surface composition such as snow, grass, and packed earth and are most suited to the operation of light aircraft; unpaved runways are usually short, often less than 1,000 m (3,280 ft.) in length; airports with unpaved runways often lack facilities for refueling, maintenance, or air traffic control
Heliports:
53 (2021)
note:
all year-round and seasonal stations operated by National Antarctic Programs stations have some kind of helicopter landing facilities, prepared (helipads) or unprepared
Ports and terminals:
most coastal stations have sparse and intermittent offshore anchorages; a few stations have basic wharf facilities
Transportation - note:
US coastal stations include McMurdo (77 51 S, 166 40 E) and Palmer (64 43 S, 64 03 W); government use only; all ships are subject to inspection in accordance with Article 7, Antarctic Treaty; relevant legal instruments and authorization procedures adopted by the states parties to the Antarctic Treaty regulating the Antarctic Treaty area have to be complied with (see “Legal System”); The Hydrographic Commission on Antarctica (HCA), a commission of the International Hydrographic Organization (IHO), is responsible for hydrographic surveying and nautical charting matters in Antarctic Treaty area; it coordinates and facilitates provision of accurate and appropriate charts and other aids to navigation in support of safety of navigation in region; membership of HCA is open to any IHO Member State whose government has acceded to the Antarctic Treaty and which contributes resources or data to IHO Chart coverage of the area','9415b6f87fee8cac16d479145db46a4aa645affd0379a54294a320458bca84ad','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f3517a10b9654bfce8e440908ad4d5cce5a123fe1c379db5a83c9a5f567e0066',2025,'AG','Antigua and Barbuda','transportation',42,'National air transport system:
number of registered air carriers:
1 (2020)
inventory of registered aircraft operated by air carriers:
10
annual passenger traffic on registered air carriers:
580,174 (2018)
annual freight traffic on registered air carriers:
290,000 (2018) mt-km
Civil aircraft registration country code prefix:
V2
Airports:
3 (2021)
comparison ranking:
total 192
Airports - with paved runways:
2
note:
paved runways have a concrete or asphalt surface but not all have facilities for refueling, maintenance, or air traffic control; the length of a runway required for aircraft to safely operate depends on a number of factors including the type of aircraft, the takeoff weight (including passengers, cargo, and fuel), engine types, flap settings, landing speed, elevation of the airport, and average maximum daily air temperature; paved runways can reach a length of 5,000 m (16,000 ft.), but the “typical” length of a commercial airline runway is between 2,500-4,000 m (8,000-13,000 ft.)
Airports - with unpaved runways:
1
note:
unpaved runways have a surface composition such as grass or packed earth and are most suited to the operation of light aircraft; unpaved runways are usually short, often less than 1,000 m (3,280 ft.) in length; airports with unpaved runways often lack facilities for refueling, maintenance, or air traffic control
Roadways:
total:
1,170 km (2011)
paved:
386 km (2011)
unpaved:
784 km (2011)
comparison ranking:
total 180
Merchant marine:
total:
638 (2022)
by type:
bulk carrier 26, container ship 112, general cargo 443, oil tanker 4, other 53
comparison ranking:
total 35
Ports and terminals:
major seaport(s):
Saint John’s
cruise port(s):
St. John’s','bfe40e89ffa1f97f424591e44d360a5b1c7298f06c9bf222b3ad0b1821d47e5c','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0948b08998a0eeb343ddbed5fcb6f1305569bbf82028cd69b48c4a8faca6bc40',2025,'AG','Antigua and Barbuda','transportation',49,'Icebreakers: Norway:
one PC 3 or 4 class medium icebreaker, and one PC 5 or 6 class light icebreaker
Russia:
seven PC 1 or 2 class heavy icebreakers, eight PC 3 or 4 class medium icebreakers, and three PC 5 or 6 class light icebreakers
note:
the ships are listed by Polar Class (PC) vessel: PC 1 - year-round operation in all polar waters (ice thickness >3 m); PC 2 - year-round operation in moderate multi-year ice conditions (ice thickness up to 3 m); PC 3 - year-round operation in second-year ice which may include multi-year ice inclusions (ice thickness up to 2.5 m); PC 4 - year-round operation in thick first-year ice which may include old ice inclusions (ice thickness up to 120 cm); PC 5 - year-round operation in medium first-year ice which may include old ice inclusions (ice thickness up to 70-120 cm); PC 6 - summer/autumn operation in medium first-year ice which may include old ice inclusions (ice thickness up to 30-70 cm)
Ports and terminals:
major seaport(s):
Churchill (Canada), Murmansk (Russia), Prudhoe Bay (US)
Transportation - note:
sparse network of air, ocean, river, and land routes; the Northwest Passage (North America) and Northern Sea Route (Eurasia) are important seasonal waterways','1e4c5d3672d6a6f9839983c5d8421ad96824faeb279544358c4fec3c25a1ff44','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('61ac8cfa5cefd44ca5d5de85bd467328debb09f5b3888b65e1e75fac79539143',2025,'AR','Argentina','transportation',59,'National air transport system:
number of registered air carriers:
6 (2020)
inventory of registered aircraft operated by air carriers:
107
annual passenger traffic on registered air carriers:
18,081,937 (2018)
annual freight traffic on registered air carriers:
311.57 million (2018) mt-km
Civil aircraft registration country code prefix:
LV
Airports:
916 (2021)
comparison ranking:
total 6
Airports - with paved runways:
161
civil airports:
15
military airports:
5
joint use (civil-military) airports:
16
other airports:
125
note:
paved runways have a concrete or asphalt surface but not all have facilities for refueling, maintenance, or air traffic control; the length of a runway required for aircraft to safely operate depends on a number of factors including the type of aircraft, the takeoff weight (including passengers, cargo, and fuel), engine types, flap settings, landing speed, elevation of the airport, and average maximum daily air temperature; paved runways can reach a length of 5,000 m (16,000 ft.), but the “typical” length of a commercial airline runway is between 2,500-4,000 m (8,000-13,000 ft.)
Airports - with unpaved runways:
977
note:
unpaved runways have a surface composition such as grass or packed earth and are most suited to the operation of light aircraft; unpaved runways are usually short, often less than 1,000 m (3,280 ft.) in length; airports with unpaved runways often lack facilities for refueling, maintenance, or air traffic control
Heliports:
2 (2021)
Pipelines:
29,930 km gas, 41 km liquid petroleum gas, 6,248 km oil, 3,631 km refined products (2013)
Railways:
total:
17,866 km (2018)
comparison ranking:
total 16
Roadways:
total:
281,290 km (2017)
paved:
117,616 km (2017)
unpaved:
163,674 km (2017)
comparison ranking:
total 21
Waterways:
11,000 km (2012)
comparison ranking:
13
Merchant marine:
total:
203 (2022)
by type:
container ship 1, bulk carrier 1 general cargo 8, oil tanker 33, other 160
comparison ranking:
total 64
Ports and terminals:
major seaport(s):
Bahia Blanca, Buenos Aires, La Plata, Punta Colorada, Ushuaia
container port(s) (TEUs):
Buenos Aires (1,446,452) (2021)
LNG terminal(s) (import):
Bahia Blanca
river port(s):
Arroyo Seco, Rosario, San Lorenzo-San Martin (Parana)
Transportation - note:
Argentina operates one PC 5 or 6 class light icebreaker
note - PC indicates a Polar Class vessel:
PC 5 - year-round operation in medium first-year ice which may include old ice inclusions (ice thickness up to 70-120 cm); PC 6 - summer/autumn operation in medium first-year ice which may include old ice inclusions (ice thickness up to 30-70 cm)','9335ce7f746bc8320aa1f6f0cd1ebfd5484a05999fd7c88e18a8ae0e945ff809','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('956025e8c38e9249cb810bf1c87558a46a4951ec3b56928b8848cf6698879c25',2025,'AM','Armenia','transportation',72,'National air transport system:
number of registered air carriers:
3 (2020)
inventory of registered aircraft operated by air carriers:
5
Civil aircraft registration country code prefix:
EK
Airports:
7 (2021)
comparison ranking:
total 166
Airports - with paved runways:
10
civil airports:
2
military airports:
0
joint use (civil-military) airports:
1
other airports:
7
note:
paved runways have a concrete or asphalt surface but not all have facilities for refueling, maintenance, or air traffic control; the length of a runway required for aircraft to safely operate depends on a number of factors including the type of aircraft, the takeoff weight (including passengers, cargo, and fuel), engine types, flap settings, landing speed, elevation of the airport, and average maximum daily air temperature; paved runways can reach a length of 5,000 m (16,000 ft.), but the “typical” length of a commercial airline runway is between 2,500-4,000 m (8,000-13,000 ft.)
Airports - with unpaved runways:
1
note:
unpaved runways have a surface composition such as grass or packed earth and are most suited to the operation of light aircraft; unpaved runways are usually short, often less than 1,000 m (3,280 ft.) in length; airports with unpaved runways often lack facilities for refueling, maintenance, or air traffic control
Pipelines:
3,838 km gas (high and medium pressure) (2017)
Railways:
total:
686 km (2017)
comparison ranking:
total 101
Roadways:
total:
7,700 km (2019)
urban:
3,780 km
non-
urban:
3,920 km
comparison ranking:
total 140','e9acb35593ba97ceedb29592fc2c4ab1e1907394b7bf702794287b8306f73f54','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2f309b708ab6ac2e0fa87d24cac2c30525a52497ab86c974117c8759c80cdb4a',2025,'AW','Aruba','transportation',9,'National air transport system:
number of registered air carriers:
3 (2020)
inventory of registered aircraft operated by air carriers:
19
annual passenger traffic on registered air carriers:
274,280 (2018)
Civil aircraft registration country code prefix:
P4
Airports:
1 (2021)
comparison ranking:
total 222
Airports - with paved runways:
1
note:
paved runways have a concrete or asphalt surface but not all have facilities for refueling, maintenance, or air traffic control; the length of a runway required for aircraft to safely operate depends on a number of factors including the type of aircraft, the takeoff weight (including passengers, cargo, and fuel), engine types, flap settings, landing speed, elevation of the airport, and average maximum daily air temperature; paved runways can reach a length of 5,000 m (16,000 ft.), but the “typical” length of a commercial airline runway is between 2,500-4,000 m (8,000-13,000 ft.)
Roadways:
total:
1,000 km (2010)
comparison ranking:
total 186
Merchant marine:
total:
1 (2022)
by type:
other 1
comparison ranking:
total 182
Ports and terminals:
major seaport(s):
Barcadera, Oranjestad
oil terminal(s):
Sint Nicolaas
cruise port(s):
Oranjestad','6247076927f61864624e07ebb8a83cee5535dc4f7993adbe2418da30b9b03d95','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1f13cbc2aa730bf3bdbe694d3d1cba8f3297b9e31d7bf5e8667d0210bc57db07',2025,'AW','Aruba','transportation',17,'Ports and terminals:
none; offshore anchorage only','97a08f7f958d0d9909c5d5cf9b653fbd7f83ba17e780ff6265a95bb5fccb5752','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b333493867b3fd2cc360d9e1236ae79bfe79ab8286dba42bb411aaf4c4815e07',2025,'AW','Aruba','transportation',24,'Icebreakers:
North Atlantic
Canada:
one PC 3 or 4 class medium icebreaker
France:
one PC 5 or 6 class light icebreaker
Germany:
one PC 5 or 6 class light icebreaker
US:
one PC 3 or 4 class medium icebreaker, and one PC 5 or 6 class light icebreaker
Baltic
Denmark:
three PC 5 or 6 class light icebreakers
Estonia:
two PC 5 or 6 class light icebreakers
Finland:
seven PC 3 or 4 class medium icebreakers, and two PC 5 or 6 class light icebreakers Latvia: one PC 5 or 6 class light icebreaker
Russia:
22 PC 3 or 4 class medium icebreakers, and five PC 5 or 6 class light icebreakers Sweden: four PC 3 or 4 class medium icebreakers
Great Lakes/St Lawrence Seaway
Canada:
one PC 3 or 4 class medium icebreaker, ten PC 5 or 6 class light icebreakers
Mediterranean
Italy:
one PC 5 or 6 class light icebreaker
South Atlantic
Argentina:
one PC 5 or 6 class light icebreaker
UK (Falkland Islands):
one PC 3 or 4 class medium icebreaker
South Africa:
one PC 5 or 6 class light icebreaker
note:
the ships are listed by Polar Class (PC) vessel: PC 1 - year-round operation in all polar waters (ice thickness >3 m); PC 2 - year-round operation in moderate multi-year ice conditions (ice thickness up to 3 m); PC 3 - year-round operation in second-year ice which may include multi-year ice inclusions (ice thickness up to 2.5 m); PC 4 - year-round operation in thick first-year ice which may include old ice inclusions (ice thickness up to 120 cm); PC 5 - year-round operation in medium first-year ice which may include old ice inclusions (ice thickness up to 70-120 cm); PC 6 - summer/autumn operation in medium first-year ice which may include old ice inclusions (ice thickness up to 30-70 cm)
Ports and terminals:
major seaport(s):
Alexandria (Egypt), Algiers (Algeria), Antwerp (Belgium), Barcelona (Spain), Buenos Aires (Argentina), Casablanca (Morocco), Colon (Panama), Copenhagen (Denmark), Dakar (Senegal), Gdansk (Poland), Hamburg (Germany), Helsinki (Finland), Las Palmas (Canary Islands, Spain), Le Havre (France), Lisbon (Portugal), London (UK), Marseille (France), Montevideo (Uruguay), Montreal (Canada), Naples (Italy), New Orleans (US), New York (US), Oran (Algeria), Oslo (Norway), Peiraiefs or Piraeus (Greece), Rio de Janeiro (Brazil), Rotterdam (Netherlands), Saint Petersburg (Russia), Stockholm (Sweden)
Transportation - note:
Kiel Canal and Saint Lawrence Seaway are two important waterways; significant domestic commercial and recreational use of Intracoastal Waterway on central and south Atlantic seaboard and Gulf of Mexico coast of US','ac02125183f5d56afba8ab36857454e52468f52792434bfa1c500ae974df16d6','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e5964671f7d644e1174f2db141bc4c6c5f673b50c6d9547e7ad35a9182f6b346',2025,'AU','Australia','transportation',35,'National air transport system:
number of registered air carriers:
25 (2020)
inventory of registered aircraft operated by air carriers:
583
annual passenger traffic on registered air carriers:
75,667,645 (2018)
annual freight traffic on registered air carriers:
2,027,640,000 (2018) mt-km
Civil aircraft registration country code prefix:
VH
Airports:
418 (2021)
comparison ranking:
total 19
Airports - with paved runways:
349
civil airports:
29
military airports:
17
joint use (civil-military) airports:
2
other airports:
301
note:
paved runways have a concrete or asphalt surface but not all have facilities for refueling, maintenance, or air traffic control; the length of a runway required for aircraft to safely operate depends on a number of factors including the type of aircraft, the takeoff weight (including passengers, cargo, and fuel), engine types, flap settings, landing speed, elevation of the airport, and average maximum daily air temperature; paved runways can reach a length of 5,000 m (16,000 ft.), but the “typical” length of a commercial airline runway is between 2,500-4,000 m (8,000-13,000 ft.)
Airports - with unpaved runways:
131
note:
unpaved runways have a surface composition such as grass or packed earth and are most suited to the operation of light aircraft; unpaved runways are usually short, often less than 1,000 m (3,280 ft.) in length; airports with unpaved runways often lack facilities for refueling, maintenance, or air traffic control
Heliports:
1 (2021)
Pipelines:
637 km condensate/gas, 30,054 km gas, 240 km liquid petroleum gas, 3,609 km oil, 110 km oil/gas/water, 72 km refined products (2013)
Railways:
total:
36,064 km (2022) 3,448 km electrified
standard gauge:
18,007 km (2022) 1.435 mm
narrow gauge:
11,914 km (2022) 1.067 mm
broad gauge:
2,685 km (2022) 1.600 mm
other:
35 km (2015)
comparison ranking:
total 7
Roadways:
total:
873,573 km (2015)
urban:
145,928 km (2015)
non-
urban:
727,645 km (2015)
comparison ranking:
total 9
Waterways:
2,000 km (2011) (mainly used for recreation on Murray and Murray-Darling River systems)
comparison ranking:
44
Merchant marine:
total:
587 (2022)
by type:
bulk carrier 2, general cargo 77, oil tanker 6, other 502
comparison ranking:
total 39
Ports and terminals:
major seaport(s):
Indian Ocean:
Adelaide, Darwin, Fremantle, Geelong, Melbourne
Pacific Ocean:
Brisbane, Cairns, Gladstone, Hobart, Newcastle, Port Port Kembla, Sydney
container port(s) (TEUs):
Melbourne (2,909,288), Sydney (2,761,648) (2021)
LNG terminal(s) (export):
Australia Pacific, Barrow Island, Burrup (Pluto), Curtis Island, Darwin, Karratha, Bladin Point (Ichthys), Gladstone, Prelude (offshore FLNG), Wheatstone
dry bulk cargo port(s):
Dampier (iron ore), Dalrymple Bay (coal), Hay Point (coal), Port Hedland (iron ore), Port Walcott (iron ore)
Transportation - note:
Australia operates one PC 3 or 4 class medium icebreaker based in Tasmania in support of operations in Antarctica note - PC indicates a Polar Class vessel: PC 3 - year-round operation in second-year ice which may include multi-year ice inclusions (ice thickness up to 2.5 m); PC 4 - year-round operation in thick first-year ice which may include old ice inclusions (ice thickness up to 120 cm)','d46f204549898249d3849fd651e20b7e079a990cb22f399f7a2787cafbd2cbf5','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ae3b3caaef49956197f84c4e02cc6c1e9566fb08f0374b00085d2a463acef6d6',2025,'AT','Austria','transportation',48,'National air transport system:
number of registered air carriers:
11 (2020)
inventory of registered aircraft operated by air carriers:
130
annual passenger traffic on registered air carriers:
12,935,505 (2018)
annual freight traffic on registered air carriers:
373.51 million (2018) mt-km
Civil aircraft registration country code prefix:
OE
Airports:
50 (2021)
comparison ranking:
total 90
Airports - with paved runways:
24
civil airports:
5
military airports:
1
joint use (civil-military) airports:
0
other airports:
18
note:
paved runways have a concrete or asphalt surface but not all have facilities for refueling, maintenance, or air traffic control; the length of a runway required for aircraft to safely operate depends on a number of factors including the type of aircraft, the takeoff weight (including passengers, cargo, and fuel), engine types, flap settings, landing speed, elevation of the airport, and average maximum daily air temperature; paved runways can reach a length of 5,000 m (16,000 ft.), but the “typical” length of a commercial airline runway is between 2,500-4,000 m (8,000-13,000 ft.)
Airports - with unpaved runways:
28
note:
unpaved runways have a surface composition such as grass or packed earth and are most suited to the operation of light aircraft; unpaved runways are usually short, often less than 1,000 m (3,280 ft.) in length; airports with unpaved runways often lack facilities for refueling, maintenance, or air traffic control
Heliports:
1 (2021)
Pipelines:
1,888 km gas, 594 km oil, 157 km refined products (2017)
Railways:
total:
6,123 km (2022) 3,523 km electrified
comparison ranking:
total 32
Roadways:
total:
137,039 km (2018)
paved:
137,039 km (2018) (includes 2,232 km of expressways)
comparison ranking:
total 39
Waterways:
358 km (2011)
comparison ranking:
98
Merchant marine:
total:
1 (2022)
by type:
other 1
comparison ranking:
total 180
Ports and terminals:
river port(s):
Enns, Krems, Linz, Vienna (Danube)','c5536188c863285932dbd35afb5b5a94696f78f6397af1a952d7ca80a7b4f589','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('eb0796e955be5352885cd0d74a913ffea8528ab8bf23cc4049dfa1d2218a5241',2025,'AZ','Azerbaijan','transportation',61,'National air transport system:
number of registered air carriers:
42 (2020)
inventory of registered aircraft operated by air carriers:
44
annual passenger traffic on registered air carriers:
2,279,546 (2018)
annual freight traffic on registered air carriers:
44.09 million (2018) mt-km
Civil aircraft registration country code prefix:
4K
Airports:
23 (2021)
comparison ranking:
total 132
Airports - with paved runways:
30
civil airports:
4
military airports:
5
joint use (civil-military) airports:
1
other airports:
20
note:
paved runways have a concrete or asphalt surface but not all have facilities for refueling, maintenance, or air traffic control; the length of a runway required for aircraft to safely operate depends on a number of factors including the type of aircraft, the takeoff weight (including passengers, cargo, and fuel), engine types, flap settings, landing speed, elevation of the airport, and average maximum daily air temperature; paved runways can reach a length of 5,000 m (16,000 ft.), but the “typical” length of a commercial airline runway is between 2,500-4,000 m (8,000-13,000 ft.)
Airports - with unpaved runways:
7
note:
unpaved runways have a surface composition such as grass or packed earth and are most suited to the operation of light aircraft; unpaved runways are usually short, often less than 1,000 m (3,280 ft.) in length; airports with unpaved runways often lack facilities for refueling, maintenance, or air traffic control
Heliports:
1 (2021)
Pipelines:
89 km condensate, 3,890 km gas, 2,446 km oil (2013)
Railways:
total:
2,944.3 km (2017)
broad gauge:
2,944.3 km (2017) 1.520-m gauge (approx. 1,767 km electrified)
comparison ranking:
total 59
Roadways:
total:
24,981 km (2013)
paved:
(2013)
unpaved:
(2013)
note:
total roadway length has increased significantly and continues to grow due to the recovery of Armenian-held territories and related reconstruction efforts. No updated figure is currently available.
comparison ranking:
total 104
Merchant marine:
total:
309 (2022)
by type:
general cargo 38, oil tanker 44, other 227
comparison ranking:
total 54
Ports and terminals:
major seaport(s):
Baku (Baki) located on the Caspian Sea','e972416677583bce13e2d137df5a7f236c15f22e031593254bccfdb889cd04df','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('842c2f623d612cdbf72e11f1cc7ffbb8d7b09e77d753b6bdb1e97958395fc1b4',2025,'BH','Bahrain','transportation',11,'National air transport system:
number of registered air carriers:
6 (2020)
inventory of registered aircraft operated by air carriers:
42
annual passenger traffic on registered air carriers:
5,877,003 (2018)
annual freight traffic on registered air carriers:
420.98 million (2018) mt-km
Civil aircraft registration country code prefix:
A9C
Airports:
4 (2021)
comparison ranking:
total 184
Airports - with paved runways:
4
note:
paved runways have a concrete or asphalt surface but not all have facilities for refueling, maintenance, or air traffic control; the length of a runway required for aircraft to safely operate depends on a number of factors including the type of aircraft, the takeoff weight (including passengers, cargo, and fuel), engine types, flap settings, landing speed, elevation of the airport, and average maximum daily air temperature; paved runways can reach a length of 5,000 m (16,000 ft.), but the “typical” length of a commercial airline runway is between 2,500-4,000 m (8,000-13,000 ft.)
Heliports:
1 (2021)
Pipelines:
20 km gas, 54 km oil (2013)
Roadways:
total:
4,122 km (2010)
paved:
3,392 km (2010)
unpaved:
730 km (2010)
comparison ranking:
total 152
Merchant marine:
total:
190 (2022)
by type:
general cargo 11, oil tanker 3, other 176
comparison ranking:
total 68
Ports and terminals:
major seaport(s):
Mina’ Salman, Sitrah','0011ca01a3128956efa3bf93aba07431126fccf9720fd396c52b294a4a24d12c','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bd1bc7549f10c3a83c931051626e30498ab5dc4e285d3e68798a9fbbb72a6dcd',2025,'BD','Bangladesh','transportation',24,'National air transport system:
number of registered air carriers:
6 (2020)
inventory of registered aircraft operated by air carriers:
30
annual passenger traffic on registered air carriers:
5,984,155 (2018)
annual freight traffic on registered air carriers:
63.82 million (2018) mt-km
Civil aircraft registration country code prefix:
S2
Airports:
18 (2021)
comparison ranking:
total 137
Airports - with paved runways:
16
civil airports:
1
military airports:
2
joint use (civil-military) airports:
2
other airports:
11
note:
paved runways have a concrete or asphalt surface but not all have facilities for refueling, maintenance, or air traffic control; the length of a runway required for aircraft to safely operate depends on a number of factors including the type of aircraft, the takeoff weight (including passengers, cargo, and fuel), engine types, flap settings, landing speed, elevation of the airport, and average maximum daily air temperature; paved runways can reach a length of 5,000 m (16,000 ft.), but the “typical” length of a commercial airline runway is between 2,500-4,000 m (8,000-13,000 ft.)
Airports - with unpaved runways:
2
note:
unpaved runways have a surface composition such as grass or packed earth and are most suited to the operation of light aircraft; unpaved runways are usually short, often less than 1,000 m (3,280 ft.) in length; airports with unpaved runways often lack facilities for refueling, maintenance, or air traffic control
Heliports:
3 (2021)
Pipelines:
2,950 km gas (2013)
Railways:
total:
2,460 km (2014)
narrow gauge:
1,801 km (2014) 1.000-m gauge
broad gauge:
659 km (2014) 1.676-m gauge
comparison ranking:
total 66
Roadways:
total:
369,105 km (2018)
paved:
110,311 km (2018)
unpaved:
258,794 km (2018)
comparison ranking:
total 20
Waterways:
8,370 km (2011) (includes up to 3,060 km of main cargo routes; network reduced to 5,200 km in the dry season)
comparison ranking:
18
Merchant marine:
total:
511 (2022)
by type:
bulk carrier 56, container ship 10, general cargo 150, oil tanker 152, other 143
comparison ranking:
total 41
Ports and terminals:
major seaport(s):
Chattogram (Chittagong)
container port(s) (TEUs):
Chattogram (Chittagong) (3,214,548) (2021)
LNG terminal(s) (import):
Moheshkhali (2 FSRU)
river port(s):
Mongla Port (Sela River)','dc0a0a1759c54cd43668540ea193a07b9d03c2e1cce16c594239bdc3726100c0','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6be64a67e6a13a18742be25182b78384c6b9e24d8e1feb1ba499747e88171c00',2025,'BB','Barbados','transportation',37,'Civil aircraft registration country code prefix:
8P
Airports:
1 (2021)
comparison ranking:
total 211
Airports - with paved runways:
1
note:
paved runways have a concrete or asphalt surface but not all have facilities for refueling, maintenance, or air traffic control; the length of a runway required for aircraft to safely operate depends on a number of factors including the type of aircraft, the takeoff weight (including passengers, cargo, and fuel), engine types, flap settings, landing speed, elevation of the airport, and average maximum daily air temperature; paved runways can reach a length of 5,000 m (16,000 ft.), but the “typical” length of a commercial airline runway is between 2,500-4,000 m (8,000-13,000 ft.)
Pipelines:
33 km gas, 64 km oil, 6 km refined products (2013)
Roadways:
total:
1,700 km (2015)
paved:
1,700 km (2015)
comparison ranking:
total 173
Merchant marine:
total:
195 (2022)
by type:
bulk carrier 61, general cargo 114, other 20
comparison ranking:
total 67
Ports and terminals:
major seaport(s):
Bridgetown','e3146af5496adfec45cbe3d8173a038f45125a7e892a8b521bad770065ced81e','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('26f5b10af4a5a501c49ec410028a7868c2985509a6e5baabc94d729a2e907f62',2025,'BY','Belarus','transportation',48,'National air transport system:
number of registered air carriers:
2 (2020)
inventory of registered aircraft operated by air carriers:
30
annual passenger traffic on registered air carriers:
2,760,168 (2018)
annual freight traffic on registered air carriers:
1.9 million (2018) mt-km
Civil aircraft registration country code prefix:
EW
Airports:
65 (2021)
comparison ranking:
total 75
Airports - with paved runways:
33
note:
paved runways have a concrete or asphalt surface but not all have facilities for refueling, maintenance, or air traffic control; the length of a runway required for aircraft to safely operate depends on a number of factors including the type of aircraft, the takeoff weight (including passengers, cargo, and fuel), engine types, flap settings, landing speed, elevation of the airport, and average maximum daily air temperature; paved runways can reach a length of 5,000 m (16,000 ft.), but the “typical” length of a commercial airline runway is between 2,500-4,000 m (8,000-13,000 ft.)
Airports - with unpaved runways:
32
note:
unpaved runways have a surface composition such as grass or packed earth and are most suited to the operation of light aircraft; unpaved runways are usually short, often less than 1,000 m (3,280 ft.) in length; airports with unpaved runways often lack facilities for refueling, maintenance, or air traffic control
Heliports:
1 (2021)
Pipelines:
5,386 km gas, 1,589 km oil, 1,730 km refined products (2013)
Railways:
total:
5,528 km (2014)
standard gauge:
25 km (2014) 1.435-m gauge
broad gauge:
5,503 km (2014) 1.520-m gauge (874 km electrified)
comparison ranking:
total 34
Roadways:
total:
86,600 km (2017)
paved:
(2010)
unpaved:
(2010)
comparison ranking:
total 55
Waterways:
2,500 km (2011) (major rivers are the west-flowing Western Dvina and Neman Rivers and the south-flowing Dnepr River and its tributaries, the Berezina, Sozh, and Pripyat Rivers)
comparison ranking:
37
Merchant marine:
total:
4 (2022)
by type:
other 4
comparison ranking:
total 169
Ports and terminals:
river port(s):
Mazyr (Prypyats’)','2b62884c70bc3b5906702cba5cb7e8d776b2c318559bba7a95a3f09ec76f67c6','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('eb0a7797ddf6726a9d6211622dcefa07d4c21c0ee0790176baa1cabbd00fc327',2025,'BE','Belgium','transportation',60,'National air transport system:
number of registered air carriers:
7 (2020)
inventory of registered aircraft operated by air carriers:
117
annual passenger traffic on registered air carriers:
13,639,487 (2018)
annual freight traffic on registered air carriers:
1,285,340,000 (2018) mt-km
Civil aircraft registration country code prefix:
OO
Airports:
41 (2021)
comparison ranking:
total 103
Airports - with paved runways:
26
civil airports:
5
military airports:
5
joint use (civil-military) airports:
2
other airports:
14
note:
paved runways have a concrete or asphalt surface but not all have facilities for refueling, maintenance, or air traffic control; the length of a runway required for aircraft to safely operate depends on a number of factors including the type of aircraft, the takeoff weight (including passengers, cargo, and fuel), engine types, flap settings, landing speed, elevation of the airport, and average maximum daily air temperature; paved runways can reach a length of 5,000 m (16,000 ft.), but the “typical” length of a commercial airline runway is between 2,500-4,000 m (8,000-13,000 ft.)
Airports - with unpaved runways:
15
note:
unpaved runways have a surface composition such as grass or packed earth and are most suited to the operation of light aircraft; unpaved runways are usually short, often less than 1,000 m (3,280 ft.) in length; airports with unpaved runways often lack facilities for refueling, maintenance, or air traffic control
Heliports:
1 (2021)
Pipelines:
3,139 km gas, 154 km oil, 535 km refined products (2013)
Railways:
total:
3,602 km (2020) 3,160 km electrified
comparison ranking:
total 54
Roadways:
total:
118,414 km (2015)
paved:
118,414 km (2015) (includes 1,747 km of expressways)
unpaved:
(2010)
comparison ranking:
total 41
Waterways:
2,043 km (2012) (1,528 km in regular commercial use)
comparison ranking:
43
Merchant marine:
total:
199 (2022)
by type:
bulk carrier 18, container ship 3, general cargo 15, oil tanker 23, other 140
comparison ranking:
total 66
Ports and terminals:
major seaport(s):
Oostende, Zeebrugge
container port(s) (TEUs):
Antwerp (12,020,000) (2021)
LNG terminal(s) (import):
Zeebrugge
river port(s):
Antwerp, Gent (Schelde River)
Brussels (Senne River) Liege (Meuse River)','658713dcb9f4a0036b5839c2d0338a5c886847541c9f6b78639dbed1fdb5d063','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('282ba22d4df690a04bf0f24fd58ebfa6fc21d72830998268ce430e56c77ca2d6',2025,'BZ','Belize','transportation',9,'National air transport system:
number of registered air carriers:
2 (2020)
inventory of registered aircraft operated by air carriers:
28
annual passenger traffic on registered air carriers:
1,297,533 (2018)
annual freight traffic on registered air carriers:
3.78 million (2018) mt-km
Civil aircraft registration country code prefix:
V3
Airports:
47 (2021)
comparison ranking:
total 91
Airports - with paved runways:
6
note:
paved runways have a concrete or asphalt surface but not all have facilities for refueling, maintenance, or air traffic control; the length of a runway required for aircraft to safely operate depends on a number of factors including the type of aircraft, the takeoff weight (including passengers, cargo, and fuel), engine types, flap settings, landing speed, elevation of the airport, and average maximum daily air temperature; paved runways can reach a length of 5,000 m (16,000 ft.), but the “typical” length of a commercial airline runway is between 2,500-4,000 m (8,000-13,000 ft.)
Airports - with unpaved runways:
41
note:
unpaved runways have a surface composition such as grass or packed earth and are most suited to the operation of light aircraft; unpaved runways are usually short, often less than 1,000 m (3,280 ft.) in length; airports with unpaved runways often lack facilities for refueling, maintenance, or air traffic control
Roadways:
total:
3,281 km (2017)
paved:
601 km (2017)
unpaved:
2,680 km (2017)
comparison ranking:
total 160
Waterways:
825 km (2011) (navigable only by small craft)
comparison ranking:
77
Merchant marine:
total:
817 (2022)
by type:
bulk carrier 51, general cargo 433, oil tanker 67, other 266
comparison ranking:
total 31
Ports and terminals:
major seaport(s):
Belize City, Big Creek','a011375e0b62ad0fa353a9a3149dc793b7ebac8df46c09804749909ed2cd1033','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ec05479f2ea46a437ca9163d36bc4050ff838c50dd5ecd16c24f0e62d0c43162',2025,'BJ','Benin','transportation',20,'National air transport system:
number of registered air carriers:
1 (2015)
inventory of registered aircraft operated by air carriers:
1 (2015)
annual passenger traffic on registered air carriers:
112,392 (2015)
annual freight traffic on registered air carriers:
805,347 (2015) mt-km
Civil aircraft registration country code prefix:
TY
Airports:
6 (2021)
comparison ranking:
total 176
Airports - with paved runways:
1
note:
paved runways have a concrete or asphalt surface but not all have facilities for refueling, maintenance, or air traffic control; the length of a runway required for aircraft to safely operate depends on a number of factors including the type of aircraft, the takeoff weight (including passengers, cargo, and fuel), engine types, flap settings, landing speed, elevation of the airport, and average maximum daily air temperature; paved runways can reach a length of 5,000 m (16,000 ft.), but the “typical” length of a commercial airline runway is between 2,500-4,000 m (8,000-13,000 ft.)
Airports - with unpaved runways:
5
note:
unpaved runways have a surface composition such as grass or packed earth and are most suited to the operation of light aircraft; unpaved runways are usually short, often less than 1,000 m (3,280 ft.) in length; airports with unpaved runways often lack facilities for refueling, maintenance, or air traffic control
Pipelines:
134 km gas
Railways:
total:
438 km (2014)
narrow gauge:
438 km (2014) 1.000-m gauge
comparison ranking:
total 115
Roadways:
total:
16,000 km (2006)
paved:
1,400 km (2006)
unpaved:
14,600 km (2006)
comparison ranking:
total 121
Waterways:
150 km (2011) (seasonal navigation on River Niger along northern border)
comparison ranking:
111
Merchant marine:
total:
7 (2022)
by type:
other 7
comparison ranking:
total 163
Ports and terminals:
major seaport(s):
Cotonou
LNG terminal(s) (import):
Cotonou','ea87198663a3008514256fbf9ceddca5e1c35250bd36572ab3fd1cff63d3d213','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9c8fee5628d75e49c07035b496fd6625de1ceed46fe3515ac3c014949a4fbdd3',2025,'BM','Bermuda','transportation',32,'Civil aircraft registration country code prefix:
VP-B
Airports:
1 (2021)
comparison ranking:
total 235
Airports - with paved runways:
1
note:
paved runways have a concrete or asphalt surface but not all have facilities for refueling, maintenance, or air traffic control; the length of a runway required for aircraft to safely operate depends on a number of factors including the type of aircraft, the takeoff weight (including passengers, cargo, and fuel), engine types, flap settings, landing speed, elevation of the airport, and average maximum daily air temperature; paved runways can reach a length of 5,000 m (16,000 ft.), but the “typical” length of a commercial airline runway is between 2,500-4,000 m (8,000-13,000 ft.)
Roadways:
total:
447 km (2010)
paved:
447 km (2010)
note:
225 km public roads; 222 km private roads
comparison ranking:
total 197
Merchant marine:
total:
135 (2022)
by type:
container ship 14, oil tanker 15, other 106
comparison ranking:
total 78
Ports and terminals:
major seaport(s):
Hamilton, Ireland Island, Saint George','9a5de77dd1b850987910a0616025dabf037f2737ab6dc1135aef725f5170f3eb','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0900aa8ca8d6edc187d8717fecd2d384e81f718ac979f6339fa4de3260af38fd',2025,'BT','Bhutan','transportation',43,'National air transport system:
number of registered air carriers:
2 (2020)
inventory of registered aircraft operated by air carriers:
6
annual passenger traffic on registered air carriers:
275,849 (2018)
annual freight traffic on registered air carriers:
690,000 (2018) mt-km
Civil aircraft registration country code prefix:
A5
Airports:
3 (2021)
comparison ranking:
total 191
Airports - with paved runways:
2
note:
paved runways have a concrete or asphalt surface but not all have facilities for refueling, maintenance, or air traffic control; the length of a runway required for aircraft to safely operate depends on a number of factors including the type of aircraft, the takeoff weight (including passengers, cargo, and fuel), engine types, flap settings, landing speed, elevation of the airport, and average maximum daily air temperature; paved runways can reach a length of 5,000 m (16,000 ft.), but the “typical” length of a commercial airline runway is between 2,500-4,000 m (8,000-13,000 ft.)
Airports - with unpaved runways:
1
note:
unpaved runways have a surface composition such as grass or packed earth and are most suited to the operation of light aircraft; unpaved runways are usually short, often less than 1,000 m (3,280 ft.) in length; airports with unpaved runways often lack facilities for refueling, maintenance, or air traffic control
Roadways:
total:
12,205 km (2017)
paved:
(2017)
unpaved:
(2017)
urban:
437 km (2017)
comparison ranking:
total 132','a26225283e147454a01e5ad6260b3c3abbfd48cb5956079df2fbf77df9d3ce2b','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f6b854c604040efaf5cb7d4f2f1db295396cdae61a9830aa8513542f5b12bae7',2025,'BT','Bhutan','transportation',55,'National air transport system:
number of registered air carriers:
7 (2020)
inventory of registered aircraft operated by air carriers:
39
annual passenger traffic on registered air carriers:
4,122,113 (2018)
annual freight traffic on registered air carriers:
13.73 million (2018) mt-km
Civil aircraft registration country code prefix:
CP
Airports:
855 (2021)
comparison ranking:
total 7
Airports - with paved runways:
21
civil airports:
3
military airports:
1
joint use (civil-military) airports:
4
other airports:
13
note:
paved runways have a concrete or asphalt surface but not all have facilities for refueling, maintenance, or air traffic control; the length of a runway required for aircraft to safely operate depends on a number of factors including the type of aircraft, the takeoff weight (including passengers, cargo, and fuel), engine types, flap settings, landing speed, elevation of the airport, and average maximum daily air temperature; paved runways can reach a length of 5,000 m (16,000 ft.), but the “typical” length of a commercial airline runway is between 2,500-4,000 m (8,000-13,000 ft.)
Airports - with unpaved runways:
834
note:
unpaved runways have a surface composition such as grass or packed earth and are most suited to the operation of light aircraft; unpaved runways are usually short, often less than 1,000 m (3,280 ft.) in length; airports with unpaved runways often lack facilities for refueling, maintenance, or air traffic control
Pipelines:
5,457 km gas, 51 km liquid petroleum gas, 2,511 km oil, 1,627 km refined products (2013)
Railways:
total:
3,960 km (2019)
narrow gauge:
3,960 km (2014) 1.000-m gauge
comparison ranking:
total 49
Roadways:
total:
90,568 km (2017)
paved:
9,792 km (2017)
unpaved:
80,776 km (2017)
comparison ranking:
total 53
Waterways:
10,000 km (2012) (commercially navigable almost exclusively in the northern and eastern parts of the country)
comparison ranking:
15
Merchant marine:
total:
46 (2022)
by type:
general cargo 29, oil tanker 3, other 14
comparison ranking:
total 121
Ports and terminals:
river port(s):
Puerto Aguirre (Paraguay/Parana)
note:
Bolivia has free port privileges in maritime ports in Argentina, Brazil, Chile, and Paraguay','57997670f0ef758e82b44a3881fbd2034127b0974ef1c174ea5f70ea711fb1ee','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('152b53c3926fe2bce5b2fc2958e392c4c845adb16cb082fbc76c66f2ac5f37f2',2025,'BA','Bosnia and Herzegovina','transportation',67,'National air transport system:
number of registered air carriers:
1 (2020)
inventory of registered aircraft operated by air carriers:
1
annual passenger traffic on registered air carriers:
7,070 (2015)
annual freight traffic on registered air carriers:
87 (2015) mt-km
Civil aircraft registration country code prefix:
T9
Airports:
24 (2021)
comparison ranking:
total 130
Airports - with paved runways:
7
note:
paved runways have a concrete or asphalt surface but not all have facilities for refueling, maintenance, or air traffic control; the length of a runway required for aircraft to safely operate depends on a number of factors including the type of aircraft, the takeoff weight (including passengers, cargo, and fuel), engine types, flap settings, landing speed, elevation of the airport, and average maximum daily air temperature; paved runways can reach a length of 5,000 m (16,000 ft.), but the “typical” length of a commercial airline runway is between 2,500-4,000 m (8,000-13,000 ft.)
Airports - with unpaved runways:
17
note:
unpaved runways have a surface composition such as grass or packed earth and are most suited to the operation of light aircraft; unpaved runways are usually short, often less than 1,000 m (3,280 ft.) in length; airports with unpaved runways often lack facilities for refueling, maintenance, or air traffic control
Heliports:
6 (2021)
Pipelines:
147 km gas, 9 km oil (2013)
Railways:
total:
965 km (2014)
standard gauge:
965 km (2014) 1.435-m gauge (565 km electrified)
comparison ranking:
total 91
Roadways:
total:
22,926 km (2010)
paved:
19,426 km (2010) (4,652 km of interurban roads)
unpaved:
3,500 km (2010)
comparison ranking:
total 108
Waterways:
990 km (2022) (Sava River on northern border; open to shipping but use limited)
comparison ranking:
70
Ports and terminals:
river port(s):
Bosanska Gradiska, Bosanski Brod, Bosanski Samac, Brcko, Orasje (Sava River)','7cb3e1531d497f4096334d56bb749ca636391179ef3bd4a30284e672ddf08b5b','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0579b38f9a156667b74b4c164ab21dc96b57d5a48917665679da9fc56c165402',2025,'BW','Botswana','transportation',9,'National air transport system:
number of registered air carriers:
1 (2020)
inventory of registered aircraft operated by air carriers:
6
annual passenger traffic on registered air carriers:
253,417 (2018)
annual freight traffic on registered air carriers:
110,000 (2018) mt-km
Civil aircraft registration country code prefix:
A2
Airports:
74 (2021)
comparison ranking:
total 70
Airports - with paved runways:
10
note:
paved runways have a concrete or asphalt surface but not all have facilities for refueling, maintenance, or air traffic control; the length of a runway required for aircraft to safely operate depends on a number of factors including the type of aircraft, the takeoff weight (including passengers, cargo, and fuel), engine types, flap settings, landing speed, elevation of the airport, and average maximum daily air temperature; paved runways can reach a length of 5,000 m (16,000 ft.), but the “typical” length of a commercial airline runway is between 2,500-4,000 m (8,000-13,000 ft.)
Airports - with unpaved runways:
64
note:
unpaved runways have a surface composition such as grass or packed earth and are most suited to the operation of light aircraft; unpaved runways are usually short, often less than 1,000 m (3,280 ft.) in length; airports with unpaved runways often lack facilities for refueling, maintenance, or air traffic control
Railways:
total:
888 km (2014)
narrow gauge:
888 km (2014) 1.067-m gauge
comparison ranking:
total 94
Roadways:
total:
31,747 km (2017)
paved:
9,810 km (2017)
unpaved:
21,937 km (2017)
comparison ranking:
total 94','f6365fbab758209f7af19515385ec78c0948c1ed51cbcb3e20c648bbc3916034','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('00ea2d521ac84fddb0efb297576926dc4e97974cc6e3916446acf1ed0ebc706c',2025,'BV','Bouvet Island','transportation',19,'Ports and terminals:
none; offshore anchorage only','97a08f7f958d0d9909c5d5cf9b653fbd7f83ba17e780ff6265a95bb5fccb5752','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f7bc740c2cdf202e998d9a3446732d662903bf422eb76c63edce680aad513755',2025,'BR','Brazil','transportation',30,'National air transport system:
number of registered air carriers:
9 (2020)
inventory of registered aircraft operated by air carriers:
443
annual passenger traffic on registered air carriers:
102,109,977 (2018)
annual freight traffic on registered air carriers:
1,845,650,000 (2018) mt-km
Civil aircraft registration country code prefix:
PP
Airports:
4,093 (2021)
comparison ranking:
total 2
Airports - with paved runways:
698
civil airports:
35
military airports:
14
joint use (civil-military) airports:
17
other airports:
632
note:
paved runways have a concrete or asphalt surface but not all have facilities for refueling, maintenance, or air traffic control; the length of a runway required for aircraft to safely operate depends on a number of factors including the type of aircraft, the takeoff weight (including passengers, cargo, and fuel), engine types, flap settings, landing speed, elevation of the airport, and average maximum daily air temperature; paved runways can reach a length of 5,000 m (16,000 ft.), but the “typical” length of a commercial airline runway is between 2,500-4,000 m (8,000-13,000 ft.)
Airports - with unpaved runways:
3,395
note:
unpaved runways have a surface composition such as grass or packed earth and are most suited to the operation of light aircraft; unpaved runways are usually short, often less than 1,000 m (3,280 ft.) in length; airports with unpaved runways often lack facilities for refueling, maintenance, or air traffic control
Heliports:
13 (2021)
Pipelines:
5,959 km refined petroleum product (1,165 km distribution, 4,794 km transport), 11,696 km natural gas (2,274 km distribution, 9,422 km transport), 1,985 km crude oil (distribution), 77 km ethanol/petrochemical (37 km distribution, 40 km transport) (2016)
Railways:
total:
29,849.9 km (2014)
standard gauge:
194 km (2014) 1.435-m gauge
narrow gauge:
23,341.6 km (2014) 1.000-m gauge (24 km electrified)
broad gauge:
5,822.3 km (2014) 1.600-m gauge (498.3 km electrified)
dual gauge:
492 km (2014) 1.600-1.000-m gauge
comparison ranking:
total 8
Roadways:
total:
2 million km (2018)
paved:
246,000 km (2018)
unpaved:
1.754 million km (2018)
comparison ranking:
total 4
Waterways:
50,000 km (2012) (most in areas remote from industry and population)
comparison ranking:
2
Merchant marine:
total:
877 (2022)
by type:
bulk carrier 11, container ship 20, general cargo 40, oil tanker 27, other 779
comparison ranking:
total 26
Ports and terminals:
major seaport(s):
Belem, Itajai, Paranagua, Rio Grande, Rio de Janeiro, Santos, Sao Sebastiao, Tubarao
oil terminal(s):
DTSE/Gegua oil terminal, Ilha Grande (Gebig), Guaiba Island terminal, Guamare oil terminal
container port(s) (TEUs):
Itajai (1,610,092), Paranagua (1,044,157), Santos (4,442,876) (2021)
LNG terminal(s) (import):
Pecem, Rio de Janiero
river port(s):
Manaus (Amazon)
dry bulk cargo port(s):
Sepetiba ore terminal, Tubarao','e0cd9cc66be6296b40c11e4def62810c56780cafc090a30fc4d806e1a8f88665','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('398893625c0a1f3b67d32bbc6facabd71a295467470e06014284b4a7330a8a60',2025,'IO','British Indian Ocean Territory','transportation',42,'Airports:
1 (2021)
comparison ranking:
total 230
Airports - with paved runways:
1
note:
paved runways have a concrete or asphalt surface but not all have facilities for refueling, maintenance, or air traffic control; the length of a runway required for aircraft to safely operate depends on a number of factors including the type of aircraft, the takeoff weight (including passengers, cargo, and fuel), engine types, flap settings, landing speed, elevation of the airport, and average maximum daily air temperature; paved runways can reach a length of 5,000 m (16,000 ft.), but the “typical” length of a commercial airline runway is between 2,500-4,000 m (8,000-13,000 ft.)
Roadways:
note:
short section of paved road between port and airfield on Diego Garcia
Ports and terminals:
major seaport(s):
Diego Garcia','74ea750ac2a5bc76261a17bcefbe9338d185fcc73032caafca0611d4489acf71','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('08981acc95750ee1ce866e3eb65828acc7f34d018e365a6c1f96f5c34123608a',2025,'IO','British Indian Ocean Territory','transportation',53,'Civil aircraft registration country code prefix:
VP-L
Airports:
4 (2021)
comparison ranking:
total 189
Airports - with paved runways:
2
note:
paved runways have a concrete or asphalt surface but not all have facilities for refueling, maintenance, or air traffic control; the length of a runway required for aircraft to safely operate depends on a number of factors including the type of aircraft, the takeoff weight (including passengers, cargo, and fuel), engine types, flap settings, landing speed, elevation of the airport, and average maximum daily air temperature; paved runways can reach a length of 5,000 m (16,000 ft.), but the “typical” length of a commercial airline runway is between 2,500-4,000 m (8,000-13,000 ft.)
Airports - with unpaved runways:
2
note:
unpaved runways have a surface composition such as grass or packed earth and are most suited to the operation of light aircraft; unpaved runways are usually short, often less than 1,000 m (3,280 ft.) in length; airports with unpaved runways often lack facilities for refueling, maintenance, or air traffic control
Roadways:
total:
200 km (2007)
paved:
200 km (2007)
comparison ranking:
total 207
Merchant marine:
total:
30 (2022)
by type:
general cargo 3, other 27
comparison ranking:
total 136
Ports and terminals:
major seaport(s):
Road Harbor
cruise port(s):
Tortola','a2860f52d9d0383292a2f6cf5ed613df2068b85eaaad0fd5b8ce5890bd9aca79','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('05fce2a5b52c877c00d0f50b84827fb67c5e6e1da1bfe8c94b3052356dc5992c',2025,'IO','British Indian Ocean Territory','transportation',64,'National air transport system:
number of registered air carriers:
1 (2020)
inventory of registered aircraft operated by air carriers:
10
annual passenger traffic on registered air carriers:
1,234,455 (2018)
annual freight traffic on registered air carriers:
129.35 million (2018) mt-km
Civil aircraft registration country code prefix:
V8
Airports:
1 (2021)
comparison ranking:
total 216
Airports - with paved runways:
1
note:
paved runways have a concrete or asphalt surface but not all have facilities for refueling, maintenance, or air traffic control; the length of a runway required for aircraft to safely operate depends on a number of factors including the type of aircraft, the takeoff weight (including passengers, cargo, and fuel), engine types, flap settings, landing speed, elevation of the airport, and average maximum daily air temperature; paved runways can reach a length of 5,000 m (16,000 ft.), but the “typical” length of a commercial airline runway is between 2,500-4,000 m (8,000-13,000 ft.)
Heliports:
3 (2021)
Pipelines:
33 km condensate, 86 km condensate/gas, 628 km gas, 492 km oil (2013)
Roadways:
total:
2,976 km (2014)
paved:
2,559 km (2014)
unpaved:
417 km (2014)
comparison ranking:
total 163
Waterways:
209 km (2012) (navigable by craft drawing less than 1.2 m; the Belait, Brunei, and Tutong Rivers are major transport links)
comparison ranking:
106
Merchant marine:
total:
98 (2022)
by type:
general cargo 18, oil tanker 3, other 77
comparison ranking:
total 91
Ports and terminals:
major seaport(s):
Muara
oil terminal(s):
Lumut, Seria
LNG terminal(s) (export):
Lumut','acb19d2419565c14e212dd8c50c05302b1ff98009128697fca3286b1187dfe3d','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('464d6a65d05c4836ba90c94735333e29689181cc87f256571a5284102f9eebfb',2025,'BG','Bulgaria','transportation',9,'National air transport system:
number of registered air carriers:
8 (2020)
inventory of registered aircraft operated by air carriers:
44
annual passenger traffic on registered air carriers:
1,022,645 (2018)
annual freight traffic on registered air carriers:
1.38 million (2018) mt-km
Civil aircraft registration country code prefix:
LZ
Airports:
68 (2021)
comparison ranking:
total 72
Airports - with paved runways:
57
civil airports:
5
military airports:
6
joint use (civil-military) airports:
1
other airports:
45
note:
paved runways have a concrete or asphalt surface but not all have facilities for refueling, maintenance, or air traffic control; the length of a runway required for aircraft to safely operate depends on a number of factors including the type of aircraft, the takeoff weight (including passengers, cargo, and fuel), engine types, flap settings, landing speed, elevation of the airport, and average maximum daily air temperature; paved runways can reach a length of 5,000 m (16,000 ft.), but the “typical” length of a commercial airline runway is between 2,500-4,000 m (8,000-13,000 ft.)
Airports - with unpaved runways:
11
note:
unpaved runways have a surface composition such as grass or packed earth and are most suited to the operation of light aircraft; unpaved runways are usually short, often less than 1,000 m (3,280 ft.) in length; airports with unpaved runways often lack facilities for refueling, maintenance, or air traffic control
Heliports:
1 (2021)
Pipelines:
2,765 km gas, 346 km oil, 378 km refined products (2017)
Railways:
total:
4,029 km (2020) 2,871 km electrified
comparison ranking:
total 45
Roadways:
total:
19,512 km (2011)
paved:
19,235 km (2011) (includes 458 km of expressways)
unpaved:
277 km (2011)
note:
does not include Category IV local roads
comparison ranking:
total 115
Waterways:
470 km (2009)
comparison ranking:
91
Merchant marine:
total:
80 (2022)
by type:
bulk carrier 3, general cargo 14, oil tanker 8, other 55
comparison ranking:
total 101
Ports and terminals:
major seaport(s):
Burgas, Varna (Black Sea)','7cf08f10b449571b6cd61bff5e8b8dfee4ab5c3c6d06d92de64529c2bac5ba14','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ff53a4948f803fd6a19fc0fa899fc4291665c06028203ab36be38acb81082e39',2025,'BF','Burkina Faso','transportation',22,'National air transport system:
number of registered air carriers:
1 (2020)
inventory of registered aircraft operated by air carriers:
3
annual passenger traffic on registered air carriers:
151,531 (2018)
annual freight traffic on registered air carriers:
100,000 (2018) mt-km
Civil aircraft registration country code prefix:
XT
Airports:
23 (2021)
comparison ranking:
total 133
Airports - with paved runways:
2
note:
paved runways have a concrete or asphalt surface but not all have facilities for refueling, maintenance, or air traffic control; the length of a runway required for aircraft to safely operate depends on a number of factors including the type of aircraft, the takeoff weight (including passengers, cargo, and fuel), engine types, flap settings, landing speed, elevation of the airport, and average maximum daily air temperature; paved runways can reach a length of 5,000 m (16,000 ft.), but the “typical” length of a commercial airline runway is between 2,500-4,000 m (8,000-13,000 ft.)
Airports - with unpaved runways:
21
note:
unpaved runways have a surface composition such as grass or packed earth and are most suited to the operation of light aircraft; unpaved runways are usually short, often less than 1,000 m (3,280 ft.) in length; airports with unpaved runways often lack facilities for refueling, maintenance, or air traffic control
Railways:
total:
622 km (2014)
narrow gauge:
622 km (2014) 1.000-m gauge
note:
another 660 km of this railway extends into Cote d’Ivoire
comparison ranking:
total 107
Roadways:
total:
15,304 km (2014)
paved:
3,642 km (2014)
unpaved:
11,662 km (2014)
comparison ranking:
total 123','187b27b4d3fe11efc6dcf58754c3df4ce23801fdbd413870beea70cff904f492','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('73bbc49e9765ca1643e423cea6fc97c4dcede1c098cdf81991f5bdbb37eb2302',2025,'BF','Burkina Faso','transportation',34,'National air transport system:
number of registered air carriers:
8 (2020)
inventory of registered aircraft operated by air carriers:
42
annual passenger traffic on registered air carriers:
3,407,788 (2018)
annual freight traffic on registered air carriers:
4.74 million (2018) mt-km
Civil aircraft registration country code prefix:
XY
Airports:
64 (2021)
comparison ranking:
total 77
Airports - with paved runways:
36
note:
paved runways have a concrete or asphalt surface but not all have facilities for refueling, maintenance, or air traffic control; the length of a runway required for aircraft to safely operate depends on a number of factors including the type of aircraft, the takeoff weight (including passengers, cargo, and fuel), engine types, flap settings, landing speed, elevation of the airport, and average maximum daily air temperature; paved runways can reach a length of 5,000 m (16,000 ft.), but the “typical” length of a commercial airline runway is between 2,500-4,000 m (8,000-13,000 ft.)
Airports - with unpaved runways:
28
note:
unpaved runways have a surface composition such as grass or packed earth and are most suited to the operation of light aircraft; unpaved runways are usually short, often less than 1,000 m (3,280 ft.) in length; airports with unpaved runways often lack facilities for refueling, maintenance, or air traffic control
Heliports:
11 (2021)
Pipelines:
3,739 km gas, 1321 km oil (2017)
Railways:
total:
5,031 km (2008)
narrow gauge:
5,031 km (2008) 1.000-m gauge
comparison ranking:
total 39
Roadways:
total:
157,000 km (2013)
paved:
34,700 km (2013)
unpaved:
122,300 km (2013)
comparison ranking:
total 33
Waterways:
12,800 km (2011)
comparison ranking:
11
Merchant marine:
total:
102 (2022)
by type:
bulk carrier 1, general cargo 45, oil tanker 5, other 51
comparison ranking:
total 88
Ports and terminals:
major seaport(s):
Mawlamyine (Moulmein), Sittwe
river port(s):
Rangoon (Yangon) (Rangoon River)','8edafc60527b7e07dca6b108b2d060be28c84305ef70ccde9b3e02af45b545c7','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c0ca8e7df1b16e024e51998676c6b47036273767fb5e652f0a4c64ed281839d1',2025,'BI','Burundi','transportation',45,'Civil aircraft registration country code prefix:
9U
Airports:
7 (2021)
comparison ranking:
total 165
Airports - with paved runways:
1
note:
paved runways have a concrete or asphalt surface but not all have facilities for refueling, maintenance, or air traffic control; the length of a runway required for aircraft to safely operate depends on a number of factors including the type of aircraft, the takeoff weight (including passengers, cargo, and fuel), engine types, flap settings, landing speed, elevation of the airport, and average maximum daily air temperature; paved runways can reach a length of 5,000 m (16,000 ft.), but the “typical” length of a commercial airline runway is between 2,500-4,000 m (8,000-13,000 ft.)
Airports - with unpaved runways:
6
note:
unpaved runways have a surface composition such as grass or packed earth and are most suited to the operation of light aircraft; unpaved runways are usually short, often less than 1,000 m (3,280 ft.) in length; airports with unpaved runways often lack facilities for refueling, maintenance, or air traffic control
Heliports:
1 (2021)
Roadways:
total:
12,322 km (2016)
paved:
1,500 km (2016)
unpaved:
10,822 km (2016)
comparison ranking:
total 130
Waterways:
673 km (2022) (mainly on Lake Tanganyika between Bujumbura, Burundi’s principal port, and lake ports in Tanzania, Zambia, and the Democratic Republic of the Congo)
comparison ranking:
83
Ports and terminals:
lake port(s):
Bujumbura (Lake Tanganyika)','1662eb9be97f2cbd2bacf2f0905bb2f05a451dd48194989aa4a58daa49852c6e','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cba1d4c048be4daeb6b8c4947d27cbef51dd662036370ddea825b0fa88736258',2025,'CV','Cabo Verde','transportation',9,'National air transport system:
number of registered air carriers:
2 (2020)
inventory of registered aircraft operated by air carriers:
5
annual passenger traffic on registered air carriers:
140,429 (2018)
annual freight traffic on registered air carriers:
1,728,152 (2015) mt-km
Civil aircraft registration country code prefix:
D4
Airports:
9 (2021)
comparison ranking:
total 156
Airports - with paved runways:
9
note:
paved runways have a concrete or asphalt surface but not all have facilities for refueling, maintenance, or air traffic control; the length of a runway required for aircraft to safely operate depends on a number of factors including the type of aircraft, the takeoff weight (including passengers, cargo, and fuel), engine types, flap settings, landing speed, elevation of the airport, and average maximum daily air temperature; paved runways can reach a length of 5,000 m (16,000 ft.), but the “typical” length of a commercial airline runway is between 2,500-4,000 m (8,000-13,000 ft.)
Roadways:
total:
1,350 km (2013)
paved:
932 km (2013)
unpaved:
418 km (2013)
comparison ranking:
total 176
Merchant marine:
total:
47 (2022)
by type:
general cargo 16, oil tanker 3, other 28
comparison ranking:
total 120
Ports and terminals:
major seaport(s):
Porto Grande','c4e3c2b064e4df6135ec7e78eae7c11c6e326c99c7cae058ae05e404a4991e50','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a1457a9d42fbd478df675b3b38a04f15c0efd20b6e15b10e022e8a12a6f21d5a',2025,'KH','Cambodia','transportation',20,'National air transport system:
number of registered air carriers:
6 (2020)
inventory of registered aircraft operated by air carriers:
25
annual passenger traffic on registered air carriers:
1,411,059 (2018)
annual freight traffic on registered air carriers:
680,000 (2018) mt-km
Civil aircraft registration country code prefix:
XU
Airports:
16 (2021)
comparison ranking:
total 142
Airports - with paved runways:
6
note:
paved runways have a concrete or asphalt surface but not all have facilities for refueling, maintenance, or air traffic control; the length of a runway required for aircraft to safely operate depends on a number of factors including the type of aircraft, the takeoff weight (including passengers, cargo, and fuel), engine types, flap settings, landing speed, elevation of the airport, and average maximum daily air temperature; paved runways can reach a length of 5,000 m (16,000 ft.), but the “typical” length of a commercial airline runway is between 2,500-4,000 m (8,000-13,000 ft.)
Airports - with unpaved runways:
10
note:
unpaved runways have a surface composition such as grass or packed earth and are most suited to the operation of light aircraft; unpaved runways are usually short, often less than 1,000 m (3,280 ft.) in length; airports with unpaved runways often lack facilities for refueling, maintenance, or air traffic control
Heliports:
1 (2021)
Railways:
total:
642 km (2014)
narrow gauge:
642 km (2014) 1.000-m gauge
note:
under restoration
comparison ranking:
total 106
Roadways:
total:
47,263 km (2013)
paved:
12,239 km (2013)
unpaved:
35,024 km (2013)
comparison ranking:
total 83
Waterways:
3,700 km (2012) (mainly on Mekong River)
comparison ranking:
30
Merchant marine:
total:
242 (2022)
by type:
container ship 2, general cargo 159, oil tanker 18, other 63
comparison ranking:
total 62
Ports and terminals:
major seaport(s):
Sihanoukville (Kampong Saom)
river port(s):
Phnom Penh (Mekong)','e1eee4bce1148f4e7bfed86ec72b0c5aabda79845b786a9c96ec6dad63f624f5','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4af7f9111779771085cb44e17a7462f3d57d89ed5dbd9274d80b76e3054fd992',2025,'CM','Cameroon','transportation',31,'National air transport system:
number of registered air carriers:
1 (2020)
inventory of registered aircraft operated by air carriers:
3
annual passenger traffic on registered air carriers:
265,136 (2018)
annual freight traffic on registered air carriers:
70,000 (2018) mt-km
Civil aircraft registration country code prefix:
TJ
Airports:
33 (2021)
comparison ranking:
total 111
Airports - with paved runways:
11
note:
paved runways have a concrete or asphalt surface but not all have facilities for refueling, maintenance, or air traffic control; the length of a runway required for aircraft to safely operate depends on a number of factors including the type of aircraft, the takeoff weight (including passengers, cargo, and fuel), engine types, flap settings, landing speed, elevation of the airport, and average maximum daily air temperature; paved runways can reach a length of 5,000 m (16,000 ft.), but the “typical” length of a commercial airline runway is between 2,500-4,000 m (8,000-13,000 ft.)
Airports - with unpaved runways:
22
note:
unpaved runways have a surface composition such as grass or packed earth and are most suited to the operation of light aircraft; unpaved runways are usually short, often less than 1,000 m (3,280 ft.) in length; airports with unpaved runways often lack facilities for refueling, maintenance, or air traffic control
Pipelines:
53 km gas, 5 km liquid petroleum gas, 1,107 km oil, 35 km water (2013)
Railways:
total:
987 km (2014)
narrow gauge:
987 km (2014) 1.000-m gauge
note:
railway connections generally efficient but limited; rail lines connect major cities of Douala, Yaounde, Ngaoundere, and Garoua; passenger and freight service provided by CAMRAIL
comparison ranking:
total 89
Roadways:
total:
77,589 km (2016)
paved:
5,133 km (2016)
unpaved:
72,456 km (2016)
comparison ranking:
total 64
Waterways:
(2010) (major rivers in the south, such as the Wouri and the Sanaga, are largely non-navigable; in the north, the Benue, which connects through Nigeria to the Niger River, is navigable in the rainy season only to the port of Garoua)
Merchant marine:
total:
121 (2022)
by type:
bulk carrier 2, general cargo 45, oil tanker 33, other 41
comparison ranking:
total 82
Ports and terminals:
oil terminal(s):
Limboh Terminal
river port(s):
Douala (Wouri)
Garoua (Benoue)','8be0b83702309805c91c3599e822011a9ed1d709535bfc04aaefb082a1dd0ce8','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8b432215c5ce2ca0f10acf86f2aab3c187867520dc9dde4983d835a8c417a95a',2025,'CA','Canada','transportation',43,'National air transport system:
number of registered air carriers:
51 (2020)
inventory of registered aircraft operated by air carriers:
879
annual passenger traffic on registered air carriers:
89.38 million (2018)
annual freight traffic on registered air carriers:
3,434,070,000 (2018) mt-km
Civil aircraft registration country code prefix:
C
Airports:
1,467 (2021)
comparison ranking:
total 4
Airports - with paved runways:
523
civil airports:
123
military airports:
8
joint use (civil-military) airports:
3
other airports:
389
note:
paved runways have a concrete or asphalt surface but not all have facilities for refueling, maintenance, or air traffic control; the length of a runway required for aircraft to safely operate depends on a number of factors including the type of aircraft, the takeoff weight (including passengers, cargo, and fuel), engine types, flap settings, landing speed, elevation of the airport, and average maximum daily air temperature; paved runways can reach a length of 5,000 m (16,000 ft.), but the “typical” length of a commercial airline runway is between 2,500-4,000 m (8,000-13,000 ft.)
Airports - with unpaved runways:
944
note:
unpaved runways have a surface composition such as grass or packed earth and are most suited to the operation of light aircraft; unpaved runways are usually short, often less than 1,000 m (3,280 ft.) in length; airports with unpaved runways often lack facilities for refueling, maintenance, or air traffic control
Heliports:
26 (2021)
Pipelines:
840,000 km oil and gas (2020)
Railways:
total:
49,422 km (2021) note: 129 km electrified (2021)
standard gauge:
49,422 km (2021) 1.435-m gauge
comparison ranking:
total 5
Roadways:
total:
1,042,300 km (2011)
paved:
415,600 km (2011) (includes 17,000 km of expressways)
unpaved:
626,700 km (2011)
comparison ranking:
total 8
Waterways:
636 km (2011) (Saint Lawrence Seaway of 3,769 km, including the Saint Lawrence River of 3,058 km, shared with United States)
comparison ranking:
85
Merchant marine:
total:
689 (2022)
by type:
bulk carrier 21, container ship 1, general cargo 65, oil tanker 15, other 587
comparison ranking:
total 33
Ports and terminals:
major seaport(s):
Halifax, Saint John (New Brunswick), Vancouver
oil terminal(s):
Lower Lakes terminal
container port(s) (TEUs):
Montreal (1,585,465), Vancouver (3,678,952) (2021)
LNG terminal(s) (import):
Saint John
river and lake port(s):
Montreal, Quebec City, Sept-Isles (St. Lawrence)
dry bulk cargo port(s):
Port-Cartier (iron ore and grain),
Fraser River Port (Fraser) Hamilton (Lake Ontario)
Transportation - note:
Canada operates a fleet of 12 icebreakers including two PC 3 or 4 class medium icebreakers and ten PC 5 or 6 class light icebreakers
note - PC indicates a Polar Class vessel:
PC 3 - year-round operation in second-year ice which may include multi-year ice inclusions (ice thickness up to 2.5 m); PC 4 - year-round operation in thick first-year ice which may include old ice inclusions (ice thickness up to 120 cm); PC 5 - year-round operation in medium first-year ice which may include old ice inclusions (ice thickness up to 70-120 cm); PC 6 - summer/autumn operation in medium first-year ice which may include old ice inclusions (ice thickness up to 30-70 cm)
Canadian Coast Guard Ship Louis S. St-Laurent:','432ec38448c08657f4ef563c86dd8d027dd6daebecba094e3c07c8b992ecb274','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9366e31ef63732e2bd60aaf57a5abc1f38f78e47201a1256b1f25be3744975a5',2025,'KY','Cayman Islands','transportation',56,'National air transport system:
number of registered air carriers:
1 (2020)
inventory of registered aircraft operated by air carriers:
6
Civil aircraft registration country code prefix:
VP-C
Airports:
3 (2021)
comparison ranking:
total 193
Airports - with paved runways:
3
note:
paved runways have a concrete or asphalt surface but not all have facilities for refueling, maintenance, or air traffic control; the length of a runway required for aircraft to safely operate depends on a number of factors including the type of aircraft, the takeoff weight (including passengers, cargo, and fuel), engine types, flap settings, landing speed, elevation of the airport, and average maximum daily air temperature; paved runways can reach a length of 5,000 m (16,000 ft.), but the “typical” length of a commercial airline runway is between 2,500-4,000 m (8,000-13,000 ft.)
Airports - with unpaved runways:
1
note:
unpaved runways have a surface composition such as grass or packed earth and are most suited to the operation of light aircraft; unpaved runways are usually short, often less than 1,000 m (3,280 ft.) in length; airports with unpaved runways often lack facilities for refueling, maintenance, or air traffic control
Roadways:
total:
785 km (2007)
paved:
785 km (2007)
comparison ranking:
total 189
Merchant marine:
total:
139 (2022)
by type:
bulk carrier 29, container ship 3, general cargo 1, oil tanker 20, other 86
comparison ranking:
total 77
Ports and terminals:
major seaport(s):
Cayman Brac, George Town
cruise port(s):
George Town, Grand Cayman','72419da3abecf0c3fe99e503fb92bc8d5b87f84b66d56252f525ce313304e547','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8051d801bf50ca51e549212a91cc24b41071afce7b24f59088f1dd0ca4286b76',2025,'CF','Central African Republic','transportation',67,'National air transport system:
number of registered air carriers:
2 (2020)
inventory of registered aircraft operated by air carriers:
2
annual passenger traffic on registered air carriers:
46,364 (2015)
annual freight traffic on registered air carriers:
0 (2015) mt-km
Civil aircraft registration country code prefix:
TL
Airports:
39 (2021)
comparison ranking:
total 106
Airports - with paved runways:
1
note:
paved runways have a concrete or asphalt surface but not all have facilities for refueling, maintenance, or air traffic control; the length of a runway required for aircraft to safely operate depends on a number of factors including the type of aircraft, the takeoff weight (including passengers, cargo, and fuel), engine types, flap settings, landing speed, elevation of the airport, and average maximum daily air temperature; paved runways can reach a length of 5,000 m (16,000 ft.), but the “typical” length of a commercial airline runway is between 2,500-4,000 m (8,000-13,000 ft.)
Airports - with unpaved runways:
37
note:
unpaved runways have a surface composition such as grass or packed earth and are most suited to the operation of light aircraft; unpaved runways are usually short, often less than 1,000 m (3,280 ft.) in length; airports with unpaved runways often lack facilities for refueling, maintenance, or air traffic control
Roadways:
total:
24,000 km (2018)
paved:
700 km (2018)
unpaved:
23,300 km (2018)
comparison ranking:
total 105
Waterways:
2,800 km (2011) (the primary navigable river is the Ubangi, which joins the River Congo; it was the traditional route for the export of products because it connected with the Congo-Ocean railway at Brazzaville; because of the warfare on both sides of the River Congo from 1997, importers and exporters preferred routes through Cameroon)
comparison ranking:
36
Ports and terminals:
river port(s):
Bangui (Oubangui)
Nola (Sangha)','cb0f2533a64f25c23fbca612465361958e46b745c0f6f78a0b757d0b3edc02a1','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('dab433f4c674b05acbc3860f37554da424e9e29708a79c780c8fd77574a351d0',2025,'TD','Chad','transportation',9,'National air transport system:
number of registered air carriers:
2 (2020)
inventory of registered aircraft operated by air carriers:
3
Civil aircraft registration country code prefix:
TT
Airports:
59 (2021)
comparison ranking:
total 81
Airports - with paved runways:
9
note:
paved runways have a concrete or asphalt surface but not all have facilities for refueling, maintenance, or air traffic control; the length of a runway required for aircraft to safely operate depends on a number of factors including the type of aircraft, the takeoff weight (including passengers, cargo, and fuel), engine types, flap settings, landing speed, elevation of the airport, and average maximum daily air temperature; paved runways can reach a length of 5,000 m (16,000 ft.), but the “typical” length of a commercial airline runway is between 2,500-4,000 m (8,000-13,000 ft.)
Airports - with unpaved runways:
50
note:
unpaved runways have a surface composition such as grass or packed earth and are most suited to the operation of light aircraft; unpaved runways are usually short, often less than 1,000 m (3,280 ft.) in length; airports with unpaved runways often lack facilities for refueling, maintenance, or air traffic control
Pipelines:
582 km oil (2013)
Roadways:
total:
40,000 km (2018)
note:
consists of 25,000 km of national and regional roads and 15,000 km of local roads; 206 km of urban roads are paved
comparison ranking:
total 88
Waterways:
12,400 km (2022) (Chari and Logone Rivers are navigable only in wet season) Chari is 11,400 km Legone is 1,000 km
comparison ranking:
12','84166cadc38cb95c97420d212a486792c75fc9329908df74279ac5e61efdb93e','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('21788300fa85e410324a4200b1c290a221222e473f77716596da94e5f9faf5e1',2025,'CL','Chile','transportation',21,'National air transport system:
number of registered air carriers:
9 (2020)
inventory of registered aircraft operated by air carriers:
173
annual passenger traffic on registered air carriers:
19,517,185 (2018)
annual freight traffic on registered air carriers:
1,226,440,000 (2018) mt-km
Civil aircraft registration country code prefix:
CC
Airports:
481 (2021)
comparison ranking:
total 14
Airports - with paved runways:
90
note:
paved runways have a concrete or asphalt surface but not all have facilities for refueling, maintenance, or air traffic control; the length of a runway required for aircraft to safely operate depends on a number of factors including the type of aircraft, the takeoff weight (including passengers, cargo, and fuel), engine types, flap settings, landing speed, elevation of the airport, and average maximum daily air temperature; paved runways can reach a length of 5,000 m (16,000 ft.), but the “typical” length of a commercial airline runway is between 2,500-4,000 m (8,000-13,000 ft.)
Airports - with unpaved runways:
391
note:
unpaved runways have a surface composition such as grass or packed earth and are most suited to the operation of light aircraft; unpaved runways are usually short, often less than 1,000 m (3,280 ft.) in length; airports with unpaved runways often lack facilities for refueling, maintenance, or air traffic control
Heliports:
1 (2021)
Pipelines:
3,160 km gas, 781 km liquid petroleum gas, 985 km oil, 722 km refined products (2013)
Railways:
total:
7,281.5 km (2014)
narrow gauge:
3,853.5 km (2014) 1.000-m gauge
broad gauge:
3,428 km (2014) 1.676-m gauge (1,691 km electrified)
comparison ranking:
total 30
Roadways:
total:
77,801 km (2016)
paved:
(2010)
unpaved:
(2010)
comparison ranking:
total 62
Merchant marine:
total:
239 (2022)
by type:
bulk carrier 4, container ship 5, general cargo 64, oil tanker 14, other 152 comparison ranking: total 63
Ports and terminals:
major seaport(s):
Coronel, Huasco, Lirquen, Puerto Ventanas, San Antonio, San Vicente, Valparaiso
container port(s) (TEUs):
San Antonio (1,840,458), Valparaiso (793,118) (2021)
LNG terminal(s) (import):
Mejillones, Quintero
Transportation - note:
Chile operates one PC 5 or 6 class light icebreaker for operations in Antarctica and the Southern Ocean
note - PC indicates a Polar Class vessel:
PC 5 - year-round operation in medium first-year ice which may include old ice inclusions (ice thickness up to 70-120 cm); PC 6 - summer/autumn operation in medium first-year ice which may include old ice inclusions (ice thickness up to 30-70 cm)','1ce5cff36f7d8e32ca8bc88f8d65b1d66b730df77d844d85e2dd714a4e129ec0','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6098178ae1af78279b76c09b9a83c885873fdefbfd5dff82145e645194af50ac',2025,'CN','China','transportation',33,'National air transport system:
number of registered air carriers:
56 (2020)
inventory of registered aircraft operated by air carriers:
2,890
annual passenger traffic on registered air carriers:
436,183,969 (2018)
annual freight traffic on registered air carriers:
611,439,830 (2018) mt-km
Civil aircraft registration country code prefix:
B
Airports:
507 (2021)
comparison ranking:
total 13
Airports - with paved runways:
510
civil airports:
131
military airports:
127
joint use (civil-military) airports:
69
other airports:
183
note:
paved runways have a concrete or asphalt surface but not all have facilities for refueling, maintenance, or air traffic control; the length of a runway required for aircraft to safely operate depends on a number of factors including the type of aircraft, the takeoff weight (including passengers, cargo, and fuel), engine types, flap settings, landing speed, elevation of the airport, and average maximum daily air temperature; paved runways can reach a length of 5,000 m (16,000 ft.), but the “typical” length of a commercial airline runway is between 2,500-4,000 m (8,000-13,000 ft.)
Airports - with unpaved runways:
23
note:
unpaved runways have a surface composition such as grass or packed earth and are most suited to the operation of light aircraft; unpaved runways are usually short, often less than 1,000 m (3,280 ft.) in length; airports with unpaved runways often lack facilities for refueling, maintenance, or air traffic control
Heliports:
39 (2021)
Pipelines:
76,000 km gas, 30,400 km crude oil, 27,700 km refined petroleum products, 797,000 km water (2018)
Railways:
total:
150,000 km (2021) 1.435-m gauge (100,000 km electrified); 104,0000 traditional, 40,000 high-speed
standard gauge:
(2018)
comparison ranking:
total 2
Roadways:
total:
5.2 million km (2020)
paved:
4.578 million km (2020) (includes 168000 km of expressways)
unpaved:
622,000 km (2017)
comparison ranking:
total 3
Waterways:
27,700 km (2020) (navigable waterways)
comparison ranking:
6
Merchant marine:
total:
7,362 (2022)
by type:
bulk carrier 1,684, container ship 355, general cargo 1,164, oil tanker 1,133, other 3,026
comparison ranking:
total 3
Ports and terminals:
major seaport(s):
Dalian, Ningbo, Qingdao, Qinhuangdao, Shanghai, Shenzhen, Tianjin, Xiamen
container port(s) (TEUs):
Dalian (3,672,000), Guangzhou (24,180,000), Ningbo (31,070,000), Qingdao (23,710,000), Shanghai (47,030,300), Shenzhen (28,767,600), Tianjin (20,269,400), Xiamen (12,045,700) (2021)
LNG terminal(s) (import):
Fujian, Guangdong, Jiangsu, Shandong, Shanghai, Tangshan, Zhejiang
river port(s):
Guangzhou (Pearl)
Transportation - note:
note 1:
seven of the world’s ten largest container ports are in China
note 2:
China operates one PC 3 or 4 class medium ice breaker and three PC 5 or 6 class light icebreakers
note - PC indicates a Polar Class vessel:
PC 3 - year-round operation in second-year ice which may include multi-year ice inclusions (ice thickness up to 2.5 m); PC 4 - year-round operation in thick first-year ice which may include old ice inclusions (ice thickness up to 120 cm); PC 5 - year-round operation in medium first-year ice which may include old ice inclusions (ice thickness up to 70-120 cm); PC 6 - summer/autumn operation in medium first-year ice which may include old ice inclusions (ice thickness up to 30-70 cm)','384cdb02bddfb5e111a335177a6f71f395614c13e75f55ec7843c6a74aeb4d0b','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cd5b1482c0cd9cb96f3804e11350b05df24c3bbbc650a221f9d267c059c8f9dc',2025,'CX','Christmas Island','transportation',44,'Airports:
1 (2021)
comparison ranking:
total 233
Airports - with paved runways:
1
note:
paved runways have a concrete or asphalt surface but not all have facilities for refueling, maintenance, or air traffic control; the length of a runway required for aircraft to safely operate depends on a number of factors including the type of aircraft, the takeoff weight (including passengers, cargo, and fuel), engine types, flap settings, landing speed, elevation of the airport, and average maximum daily air temperature; paved runways can reach a length of 5,000 m (16,000 ft.), but the “typical” length of a commercial airline runway is between 2,500-4,000 m (8,000-13,000 ft.)
Railways:
total:
18 km (2017)
standard gauge:
18 km (2017) 1.435-m (not in operation)
note:
the 18-km Christmas Island Phosphate Company Railway between Flying Fish Cove and South Point was decommissioned in 1987; some tracks and scrap remain in place
comparison ranking:
total 135
Roadways:
total:
142 km (2011)
paved:
32 km (2011)
unpaved:
110 km (2011)
comparison ranking:
total 210
Ports and terminals:
major seaport(s):
Flying Fish Cove','46e7c0cd1f4d685643c5cf27c2bb72b4a04afa96c384e81c9563ccb681848a90','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('683eee6c3d399523be3b8e8aa64275d9bf73f2e83b017535ed67dd15dc04e6a5',2025,'CX','Christmas Island','transportation',52,'Ports and terminals:
none; offshore anchorage only','97a08f7f958d0d9909c5d5cf9b653fbd7f83ba17e780ff6265a95bb5fccb5752','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('de1426bcd0ddd3a81d7db36b16721405ff5cc6e3e3d2c2a154e507630adb049e',2025,'CC','Cocos (Keeling) Islands','transportation',62,'Airports:
1 (2021)
comparison ranking:
total 219
Airports - with paved runways:
1
note:
paved runways have a concrete or asphalt surface but not all have facilities for refueling, maintenance, or air traffic control; the length of a runway required for aircraft to safely operate depends on a number of factors including the type of aircraft, the takeoff weight (including passengers, cargo, and fuel), engine types, flap settings, landing speed, elevation of the airport, and average maximum daily air temperature; paved runways can reach a length of 5,000 m (16,000 ft.), but the “typical” length of a commercial airline runway is between 2,500-4,000 m (8,000-13,000 ft.)
Roadways:
total:
22 km (2007)
paved:
10 km (2007)
unpaved:
12 km (2007)
comparison ranking:
total 221
Ports and terminals:
major seaport(s):
Port Refuge','abdd74a4aa2a943c4443e67de2413f7a0250c1561441e9668bdab1ce035b92fb','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('01ea6fc058c93f7dc4126b7a436172eaea0a7de463f719d3c72baee3c1e708f4',2025,'CO','Colombia','transportation',73,'National air transport system:
number of registered air carriers:
12 (2020)
inventory of registered aircraft operated by air carriers:
157
annual passenger traffic on registered air carriers:
33,704,037 (2018)
annual freight traffic on registered air carriers:
1,349,450,000 (2018) mt-km
Civil aircraft registration country code prefix:
HJ, HK
Airports:
836 (2021)
comparison ranking:
total 8
Airports - with paved runways:
121
note:
paved runways have a concrete or asphalt surface but not all have facilities for refueling, maintenance, or air traffic control; the length of a runway required for aircraft to safely operate depends on a number of factors including the type of aircraft, the takeoff weight (including passengers, cargo, and fuel), engine types, flap settings, landing speed, elevation of the airport, and average maximum daily air temperature; paved runways can reach a length of 5,000 m (16,000 ft.), but the “typical” length of a commercial airline runway is between 2,500-4,000 m (8,000-13,000 ft.)
Airports - with unpaved runways:
715
note:
unpaved runways have a surface composition such as grass or packed earth and are most suited to the operation of light aircraft; unpaved runways are usually short, often less than 1,000 m (3,280 ft.) in length; airports with unpaved runways often lack facilities for refueling, maintenance, or air traffic control
Heliports:
3 (2021)
Pipelines:
4,991 km gas, 6,796 km oil, 3,429 km refined products (2013)
Railways:
total:
2,141 km (2019)
standard gauge:
150 km (2019) 1.435-m gauge
narrow gauge:
1,991 km (2019) 0.914-m gauge
comparison ranking:
total 71
Roadways:
total:
205,379 km (2019)
comparison ranking:
total 26
Waterways:
24,725 km (2019) (18,225 km navigable; the most important waterway, the River Magdalena, of which 1,092 km is navigable, is dredged regularly to ensure safe passage of cargo vessels and container barges)
comparison ranking:
7
Merchant marine:
total:
148 (2022)
by type:
general cargo 28, oil tanker 12, other 108
comparison ranking:
total 75
Ports and terminals:
major seaport(s):
Atlantic Ocean (Caribbean) - Cartagena, Santa Marta, Turbo
Pacific Ocean - Buenaventura
oil terminal(s):
Covenas offshore terminal
container port(s) (TEUs):
Buenaventura (1,082,746), Cartagena (3,343,810) (2021)
river port(s):
Barranquilla (Rio Magdalena)
dry bulk cargo port(s):
Puerto Bolivar (coal)
Pacific Ocean - Buenaventura','bd6a517b461c84990002b0f18b735a3d2f57fc42bc8c156c6fefbac4d8bd7226','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5f0a532c2c65680621e3dd0f8f3ea9648fcb5a69304dc33f30dab1410753b834',2025,'KM','Comoros','transportation',9,'National air transport system:
number of registered air carriers:
2 (2020)
inventory of registered aircraft operated by air carriers:
9
Civil aircraft registration country code prefix:
D6
Airports:
4 (2021)
comparison ranking:
total 185
Airports - with paved runways:
4
note:
paved runways have a concrete or asphalt surface but not all have facilities for refueling, maintenance, or air traffic control; the length of a runway required for aircraft to safely operate depends on a number of factors including the type of aircraft, the takeoff weight (including passengers, cargo, and fuel), engine types, flap settings, landing speed, elevation of the airport, and average maximum daily air temperature; paved runways can reach a length of 5,000 m (16,000 ft.), but the “typical” length of a commercial airline runway is between 2,500-4,000 m (8,000-13,000 ft.)
Roadways:
total:
880 km (2002)
paved:
673 km (2002)
unpaved:
207 km (2002)
comparison ranking:
total 188
Merchant marine:
total:
248 (2022)
by type:
bulk carrier 10, container ship 6, general cargo 108, oil tanker 38, other 86
comparison ranking:
total 61
Ports and terminals:
major seaport(s):
Moroni, Moutsamoudou','90c1fea0fad16910a7a8c8c16ec53db3cfefa7d93b37e542779ea40783762a99','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('aaace4f4a31ca8a8724436620b6e646fbf4fa298609bc7efc112721f3f4dbe60',2025,'KM','Comoros','transportation',20,'National air transport system:
number of registered air carriers:
8 (2020)
inventory of registered aircraft operated by air carriers:
13
annual passenger traffic on registered air carriers:
932,043 (2018)
annual freight traffic on registered air carriers:
890,000 (2018) mt-km
Civil aircraft registration country code prefix:
9Q
Airports:
198 (2021)
comparison ranking:
total 28
Airports - with paved runways:
26
note:
paved runways have a concrete or asphalt surface but not all have facilities for refueling, maintenance, or air traffic control; the length of a runway required for aircraft to safely operate depends on a number of factors including the type of aircraft, the takeoff weight (including passengers, cargo, and fuel), engine types, flap settings, landing speed, elevation of the airport, and average maximum daily air temperature; paved runways can reach a length of 5,000 m (16,000 ft.), but the “typical” length of a commercial airline runway is between 2,500-4,000 m (8,000-13,000 ft.)
Airports - with unpaved runways:
172
note:
unpaved runways have a surface composition such as grass or packed earth and are most suited to the operation of light aircraft; unpaved runways are usually short, often less than 1,000 m (3,280 ft.) in length; airports with unpaved runways often lack facilities for refueling, maintenance, or air traffic control
Heliports:
1 (2021)
Pipelines:
62 km gas, 77 km oil, 756 km refined products (2013)
Railways:
total:
4,007 km (2014)
narrow gauge:
3,882 km (2014) 1.067-m gauge (858 km electrified)
125 1.000-mm gauge
comparison ranking:
total 47
Roadways:
total:
152,373 km (2015)
paved:
3,047 km (2015)
unpaved:
149,326 km (2015)
urban:
7,400 km (2015)
non-urban:
144,973 km
comparison ranking:
total 34
Waterways:
15,000 km (2011) (including the Congo River, its tributaries, and unconnected lakes)
comparison ranking:
9
Merchant marine:
total:
23 (2022)
by type:
general cargo 5, oil tanker 2, other 16
comparison ranking:
total 144
Ports and terminals:
major seaport(s):
Banana
river or lake port(s):
Boma, Bumba, Kinshasa, Kisangani, Matadi, Mbandaka (Congo); Kindu (Lualaba); Bukavu, Goma (Lake Kivu); Kalemie (Lake Tanganyika)','6e674258a367fe775939c4ae8b88dfc44d427022292ef31e1219cfad64fa4bbe','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('321f273a69cc8eb0a37518138473aaac68e79060842f236f987168b2ca158e35',2025,'KM','Comoros','transportation',32,'National air transport system:
number of registered air carriers:
3 (2020)
inventory of registered aircraft operated by air carriers:
12
annual passenger traffic on registered air carriers:
333,899 (2018)
annual freight traffic on registered air carriers:
4.6 million (2018) mt-km
Civil aircraft registration country code prefix:
TN
Airports:
27 (2021)
comparison ranking:
total 124
Airports - with paved runways:
8
note:
paved runways have a concrete or asphalt surface but not all have facilities for refueling, maintenance, or air traffic control; the length of a runway required for aircraft to safely operate depends on a number of factors including the type of aircraft, the takeoff weight (including passengers, cargo, and fuel), engine types, flap settings, landing speed, elevation of the airport, and average maximum daily air temperature; paved runways can reach a length of 5,000 m (16,000 ft.), but the “typical” length of a commercial airline runway is between 2,500-4,000 m (8,000-13,000 ft.)
Airports - with unpaved runways:
19
note:
unpaved runways have a surface composition such as grass or packed earth and are most suited to the operation of light aircraft; unpaved runways are usually short, often less than 1,000 m (3,280 ft.) in length; airports with unpaved runways often lack facilities for refueling, maintenance, or air traffic control
Pipelines:
232 km gas, 4 km liquid petroleum gas, 982 km oil (2013)
Railways:
total:
510 km (2014)
narrow gauge:
510 km (2014) 1.067-m gauge
comparison ranking:
total 111
Roadways:
total:
23,324 km (2017)
paved:
3,111 km (2017)
unpaved:
20,213 km (2017)
note:
road network in Congo is composed of 23,324 km of which 17,000 km are classified as national, departmental, and routes of local interest: 6,324 km are non-classified routes
comparison ranking:
total 107
Waterways:
1,120 km (2011) (commercially navigable on Congo and Oubangui Rivers above Brazzaville; there are many ferries across the river to Kinshasa; the Congo south of Brazzaville-Kinshasa to the coast is not navigable because of rapids, necessitating a rail connection to Pointe-Noire; other rivers are used for local traffic only)
comparison ranking:
65
Merchant marine:
total:
11 (2022)
by type:
general cargo 1, oil tanker 1, other 9
comparison ranking:
total 156
Ports and terminals:
major seaport(s):
Pointe-Noire
oil terminal(s):
Djeno
river port(s):
Brazzaville (Congo)
Impfondo (Oubangui) Ouesso (Sangha) Oyo (Alima)','f7284045a77cc259edea3c8ff236db9d759cac5d568e80ef34ce4d3adf1ca4c4','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('78ef359997c2627ffe0f4888ab81fc740b8a96cdf6a87067ac4b678aa8094617',2025,'CK','Cook Islands','transportation',43,'National air transport system:
number of registered air carriers:
1 (2020)
inventory of registered aircraft operated by air carriers:
6
Civil aircraft registration country code prefix:
E5
Airports:
11 (2021)
comparison ranking:
total 153
Airports - with paved runways:
1
note:
paved runways have a concrete or asphalt surface but not all have facilities for refueling, maintenance, or air traffic control; the length of a runway required for aircraft to safely operate depends on a number of factors including the type of aircraft, the takeoff weight (including passengers, cargo, and fuel), engine types, flap settings, landing speed, elevation of the airport, and average maximum daily air temperature; paved runways can reach a length of 5,000 m (16,000 ft.), but the “typical” length of a commercial airline runway is between 2,500-4,000 m (8,000-13,000 ft.)
Airports - with unpaved runways:
10
note:
unpaved runways have a surface composition such as grass or packed earth and are most suited to the operation of light aircraft; unpaved runways are usually short, often less than 1,000 m (3,280 ft.) in length; airports with unpaved runways often lack facilities for refueling, maintenance, or air traffic control
Roadways:
total:
295 km (2018)
paved:
207 km (2018)
unpaved:
88 km (2018)
comparison ranking:
total 202
Merchant marine:
total:
189 (2022)
by type:
bulk carrier 20, general cargo 53, oil tanker 51, other 65
comparison ranking:
total 69
Ports and terminals:
major seaport(s):
Avatiu','960a16aa74e60a522e21dcc8cb5fe4ad3cffa912076d311de15e9ad548ca48cc','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bee84671b4d3f4457a33dbcdf3300bce0e8fafc108cfd6d6bb750a7ac5c098de',2025,'CK','Cook Islands','transportation',52,'Ports and terminals:
none; offshore anchorage only','97a08f7f958d0d9909c5d5cf9b653fbd7f83ba17e780ff6265a95bb5fccb5752','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('deecdfb917409715085ed2d0f506d2a5b1fe18c32e4f0c90df29339f8cffd572',2025,'CR','Costa Rica','transportation',63,'National air transport system:
number of registered air carriers:
1 (2020)
inventory of registered aircraft operated by air carriers:
39
annual passenger traffic on registered air carriers:
1,948,546 (2018)
annual freight traffic on registered air carriers:
11.13 million (2018) mt-km
Civil aircraft registration country code prefix:
TI
Airports:
161 (2021)
comparison ranking:
total 34
Airports - with paved runways:
47
note:
paved runways have a concrete or asphalt surface but not all have facilities for refueling, maintenance, or air traffic control; the length of a runway required for aircraft to safely operate depends on a number of factors including the type of aircraft, the takeoff weight (including passengers, cargo, and fuel), engine types, flap settings, landing speed, elevation of the airport, and average maximum daily air temperature; paved runways can reach a length of 5,000 m (16,000 ft.), but the “typical” length of a commercial airline runway is between 2,500-4,000 m (8,000-13,000 ft.)
Airports - with unpaved runways:
114
note:
unpaved runways have a surface composition such as grass or packed earth and are most suited to the operation of light aircraft; unpaved runways are usually short, often less than 1,000 m (3,280 ft.) in length; airports with unpaved runways often lack facilities for refueling, maintenance, or air traffic control
Pipelines:
662 km refined products (2013)
Railways:
total:
278 km (2014)
narrow gauge:
278 km (2014) 1.067-m gauge
note:
the entire rail network fell into disrepair and out of use at the end of the 20th century; since 2005, certain sections of rail have been rehabilitated
comparison ranking:
total 124
Roadways:
total:
5,035 km (2017)
paved:
(2010)
unpaved:
(2010)
comparison ranking:
total 147
Waterways:
730 km (2011) (seasonally navigable by small craft)
comparison ranking:
80
Merchant marine:
total:
11 (2022)
by type:
other 11
comparison ranking:
total 154
Ports and terminals:
major seaport(s):
Atlantic Ocean (Caribbean) - Puerto Limon
container port(s) (TEUs):
Puerto Limon (1,319,372)
Pacific Ocean - Caldera','e460a135fb389e3aadd4fae0e1aa8e78cb7dc5750b2bfe70af51a7a963022dec','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d99135a74b3356ad2bb63e97c8ea7a76c54dcbfd664323e037803263b5ab81c8',2025,'CR','Costa Rica','transportation',75,'National air transport system:
number of registered air carriers:
1 (2020)
inventory of registered aircraft operated by air carriers:
10
annual passenger traffic on registered air carriers:
779,482 (2018)
annual freight traffic on registered air carriers:
5.8 million (2018) mt-km
Civil aircraft registration country code prefix:
TU
Airports:
27 (2021)
comparison ranking:
total 123
Airports - with paved runways:
7
note:
paved runways have a concrete or asphalt surface but not all have facilities for refueling, maintenance, or air traffic control; the length of a runway required for aircraft to safely operate depends on a number of factors including the type of aircraft, the takeoff weight (including passengers, cargo, and fuel), engine types, flap settings, landing speed, elevation of the airport, and average maximum daily air temperature; paved runways can reach a length of 5,000 m (16,000 ft.), but the “typical” length of a commercial airline runway is between 2,500-4,000 m (8,000-13,000 ft.)
Airports - with unpaved runways:
20
note:
unpaved runways have a surface composition such as grass or packed earth and are most suited to the operation of light aircraft; unpaved runways are usually short, often less than 1,000 m (3,280 ft.) in length; airports with unpaved runways often lack facilities for refueling, maintenance, or air traffic control
Heliports:
1 (2021)
Pipelines:
101 km condensate, 256 km gas, 118 km oil, 5 km oil/gas/water, 7 km water (2013)
Railways:
total:
660 km (2008)
narrow gauge:
660 km (2008) 1.000-m gauge
note:
an additional 622 km of this railroad extends into Burkina Faso
comparison ranking:
total 103
Roadways:
total:
81,996 km (2007)
paved:
6,502 km (2007)
unpaved:
75,494 km (2007)
note:
includes intercity and urban roads; another 20,000 km of dirt roads are in poor condition and 150,000 km of dirt roads are impassable
comparison ranking:
total 60
Waterways:
980 km (2011) (navigable rivers, canals, and numerous coastal lagoons)
comparison ranking:
72
Merchant marine:
total:
25 (2022)
by type:
oil tanker 2, other 23
comparison ranking:
total 139
Ports and terminals:
major seaport(s):
Abidjan, San-Pedro
oil terminal(s):
Espoir Offshore Terminal','8f06ecb189df22455e060681acfbe9e5a032f375e675418c05733846d7f86c2d','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('88d915e16e2d566a0487b0cd7e63ee76ec1b7939418a3041fdbe41acb7fcb7d2',2025,'HR','Croatia','transportation',9,'National air transport system:
number of registered air carriers:
2 (2020)
inventory of registered aircraft operated by air carriers:
18
annual passenger traffic on registered air carriers:
2,093,577 (2018)
annual freight traffic on registered air carriers:
530,000 (2018) mt-km
Civil aircraft registration country code prefix:
9A
Airports:
69 (2021)
comparison ranking:
total 71
Airports - with paved runways:
24
note:
paved runways have a concrete or asphalt surface but not all have facilities for refueling, maintenance, or air traffic control; the length of a runway required for aircraft to safely operate depends on a number of factors including the type of aircraft, the takeoff weight (including passengers, cargo, and fuel), engine types, flap settings, landing speed, elevation of the airport, and average maximum daily air temperature; paved runways can reach a length of 5,000 m (16,000 ft.), but the “typical” length of a commercial airline runway is between 2,500-4,000 m (8,000-13,000 ft.)
Airports - with unpaved runways:
45
note:
unpaved runways have a surface composition such as grass or packed earth and are most suited to the operation of light aircraft; unpaved runways are usually short, often less than 1,000 m (3,280 ft.) in length; airports with unpaved runways often lack facilities for refueling, maintenance, or air traffic control
Heliports:
1 (2021)
Pipelines:
2,410 km gas, 610 km oil (2011)
Railways:
total:
2,617 km (2020) 980 km electrified
comparison ranking:
total 63
Roadways:
total:
26,958 km (2015) (includes 1,416 km of expressways)
comparison ranking:
total 100
Waterways:
4,714 km (2022) Danube 2,859 km, Sava 562 km, Drava 505 km, Neretva 20 km, Bosut 151 km, Kupa 296 km, Mura 53 km, Korana 134 km, Lonja 134 km
comparison ranking:
25
Merchant marine:
total:
376 (2022)
by type:
bulk carrier 12, general cargo 33, oil tanker 14, other 317
comparison ranking:
total 49
Ports and terminals:
major seaport(s):
Ploce, Rijeka, Sibenik, Split
oil terminal(s):
Omisalj
LNG terminal(s) (import):
Krk Island
river port(s):
Vukovar (Danube)','ab52df9de7c25f8b1d7c797934bdd57d24a583f0fe59e7975ef60b07d043664d','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a115e781a0fe7ad98272d163e84a93fbbabfa6eb2074698484f683be17a2e2ae',2025,'CU','Cuba','transportation',20,'National air transport system:
number of registered air carriers:
4 (2020)
inventory of registered aircraft operated by air carriers:
18
annual passenger traffic on registered air carriers:
560,754 (2018)
annual freight traffic on registered air carriers:
17.76 million (2018) mt-km
Civil aircraft registration country code prefix:
CU
Airports:
133 (2021)
comparison ranking:
total 41
Airports - with paved runways:
64
civil airports:
7
military airports:
3
joint use (civil-military) airports:
2
other airports:
52
note:
paved runways have a concrete or asphalt surface but not all have facilities for refueling, maintenance, or air traffic control; the length of a runway required for aircraft to safely operate depends on a number of factors including the type of aircraft, the takeoff weight (including passengers, cargo, and fuel), engine types, flap settings, landing speed, elevation of the airport, and average maximum daily air temperature; paved runways can reach a length of 5,000 m (16,000 ft.), but the “typical” length of a commercial airline runway is between 2,500-4,000 m (8,000-13,000 ft.)
Airports - with unpaved runways:
69
note:
unpaved runways have a surface composition such as grass or packed earth and are most suited to the operation of light aircraft; unpaved runways are usually short, often less than 1,000 m (3,280 ft.) in length; airports with unpaved runways often lack facilities for refueling, maintenance, or air traffic control
Pipelines:
41 km gas, 230 km oil (2013)
Railways:
total:
8,367 km (2017)
standard gauge:
8,195 km (2017) 1.435-m gauge (124 km electrified)
narrow gauge:
172 km (2017) 1.000-m gauge
note:
As of 2013, 70 km of standard gauge and 12 km of narrow gauge track were not for public use
comparison ranking:
total 26
Roadways:
total:
60,000 km (2015)
paved:
20,000 km (2001)
unpaved:
40,000 km (2001)
comparison ranking:
total 75
Waterways:
240 km (2011) (almost all navigable inland waterways are near the mouths of rivers)
comparison ranking:
103
Merchant marine:
total:
64 (2022)
by type:
general cargo 13, oil tanker 10, other 41
comparison ranking:
total 111
Ports and terminals:
major seaport(s):
Antilla, Cienfuegos, Guantanamo, Havana, Matanzas, Mariel, Nuevitas Bay, Santiago de Cuba','a2f0b69609b956b71aa47c315a5e23f1021b0b9e6f630b93a57066469254f09c','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b730bec97c80f75124a84c74b95522e606f01924980ec1c1616199ebdff858e0',2025,'CU','Cuba','transportation',31,'National air transport system:
number of registered air carriers:
2 (2020)
inventory of registered aircraft operated by air carriers:
11
Civil aircraft registration country code prefix:
PJ
Airports:
1 (2021)
comparison ranking:
total 223
Airports - with paved runways:
1
note:
paved runways have a concrete or asphalt surface but not all have facilities for refueling, maintenance, or air traffic control; the length of a runway required for aircraft to safely operate depends on a number of factors including the type of aircraft, the takeoff weight (including passengers, cargo, and fuel), engine types, flap settings, landing speed, elevation of the airport, and average maximum daily air temperature; paved runways can reach a length of 5,000 m (16,000 ft.), but the “typical” length of a commercial airline runway is between 2,500-4,000 m (8,000-13,000 ft.)
Roadways:
total:
550 km
comparison ranking:
total 194
Merchant marine:
total:
59 (2022)
by type:
general cargo 5, oil tanker 1, other 53
comparison ranking:
total 114
Ports and terminals:
major seaport(s):
Willemstad
oil terminal(s):
Bullen Baai (Curacao Terminal)
cruise port(s):
Willemstad
bulk cargo port(s):
Fuik Bay (phosphate rock)','0dfaa4715bf4acabb3c12aecb4e1cb93136e5866e1b384b31deac31ff947ce1f','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6940bb56108069794543b69db4a2d4ed061377478c6e007aa3a6290ceddbd1f0',2025,'CY','Cyprus','transportation',42,'National air transport system:
number of registered air carriers:
2 (2020)
inventory of registered aircraft operated by air carriers:
6
annual passenger traffic on registered air carriers:
401,408 (2018)
annual freight traffic on registered air carriers:
20,000 (2018) mt-km
Civil aircraft registration country code prefix:
5B
Airports:
15 (2021)
comparison ranking:
total 145
Airports - with paved runways:
13
note:
paved runways have a concrete or asphalt surface but not all have facilities for refueling, maintenance, or air traffic control; the length of a runway required for aircraft to safely operate depends on a number of factors including the type of aircraft, the takeoff weight (including passengers, cargo, and fuel), engine types, flap settings, landing speed, elevation of the airport, and average maximum daily air temperature; paved runways can reach a length of 5,000 m (16,000 ft.), but the “typical” length of a commercial airline runway is between 2,500-4,000 m (8,000-13,000 ft.)
Airports - with unpaved runways:
2
note:
unpaved runways have a surface composition such as grass or packed earth and are most suited to the operation of light aircraft; unpaved runways are usually short, often less than 1,000 m (3,280 ft.) in length; airports with unpaved runways often lack facilities for refueling, maintenance, or air traffic control
Heliports:
9 (2021)
Roadways:
total:
12,901 km (2016)
government control:
12,901 km (2016) (includes 272 km of expressways)
paved:
8,631 km (2016)
unpaved:
4,270 km (2016)
Turkish Cypriot control:
7,000 km (2011)
comparison ranking:
total 128
Merchant marine:
total:
1,030 (2022)
by type:
bulk carrier 255, container ship 169, general cargo 200, oil tanker 61, other 345
comparison ranking:
total 24
Ports and terminals:
major seaport(s):
area under government control: Larnaca, Limassol, Vasilikos
area administered by Turkish Cypriots:
Famagusta, Kyrenia','115d8f888cd5ab3daf815c251595b1a896237e3e3f24af478d3516abde7a07f8','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('50eaf1f46802278bb79f5b7595a0ff90e655114bb51fec9fbdbf29d5e6a86a26',2025,'CZ','Czechia','transportation',54,'National air transport system:
number of registered air carriers:
4 (2020)
inventory of registered aircraft operated by air carriers:
48
annual passenger traffic on registered air carriers:
5,727,200 (2018)
annual freight traffic on registered air carriers:
25.23 million (2018) mt-km
Civil aircraft registration country code prefix:
OK
Airports:
128 (2021)
comparison ranking:
total 45
Airports - with paved runways:
41
note:
paved runways have a concrete or asphalt surface but not all have facilities for refueling, maintenance, or air traffic control; the length of a runway required for aircraft to safely operate depends on a number of factors including the type of aircraft, the takeoff weight (including passengers, cargo, and fuel), engine types, flap settings, landing speed, elevation of the airport, and average maximum daily air temperature; paved runways can reach a length of 5,000 m (16,000 ft.), but the “typical” length of a commercial airline runway is between 2,500-4,000 m (8,000-13,000 ft.)
Airports - with unpaved runways:
87
note:
unpaved runways have a surface composition such as grass or packed earth and are most suited to the operation of light aircraft; unpaved runways are usually short, often less than 1,000 m (3,280 ft.) in length; airports with unpaved runways often lack facilities for refueling, maintenance, or air traffic control
Heliports:
1 (2021)
Pipelines:
7,160 km gas, 675 km oil, 94 km refined products (2016)
Railways:
total:
9,548 km (2020) 3,242 km electrified
comparison ranking:
total 24
Roadways:
total:
55,744 km (2019) (includes urban and category I, II, III roads)
paved:
55,744 km (2019) (includes 1,252 km of expressways)
comparison ranking:
total 81
Waterways:
664 km (2010) (principally on Elbe, Vltava, Oder, and other navigable rivers, lakes, and canals)
comparison ranking:
84
Ports and terminals:
river port(s):
Prague (Vltava)
Decin, Usti nad Labem (Elbe)','e739bd879eb32eefc2f050eb3bd88586543d307779c2c4bdc462ad98cbe292be','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9e525b552984bb2bdb134d6698874a028dde587c84838ffc732e4f7589bdbd43',2025,'DK','Denmark','transportation',9,'National air transport system:
number of registered air carriers:
10 (2020)
inventory of registered aircraft operated by air carriers:
76
annual passenger traffic on registered air carriers:
582,011 (2015)
annual freight traffic on registered air carriers:
mt-km
Civil aircraft registration country code prefix:
OY
Airports:
80 (2021)
comparison ranking:
total 68
Airports - with paved runways:
28
note:
paved runways have a concrete or asphalt surface but not all have facilities for refueling, maintenance, or air traffic control; the length of a runway required for aircraft to safely operate depends on a number of factors including the type of aircraft, the takeoff weight (including passengers, cargo, and fuel), engine types, flap settings, landing speed, elevation of the airport, and average maximum daily air temperature; paved runways can reach a length of 5,000 m (16,000 ft.), but the “typical” length of a commercial airline runway is between 2,500-4,000 m (8,000-13,000 ft.)
Airports - with unpaved runways:
52
note:
unpaved runways have a surface composition such as grass or packed earth and are most suited to the operation of light aircraft; unpaved runways are usually short, often less than 1,000 m (3,280 ft.) in length; airports with unpaved runways often lack facilities for refueling, maintenance, or air traffic control
Pipelines:
1,536 km gas, 330 km oil (2015)
Railways:
total:
2,682 km (2020) 876 km electrified
comparison ranking:
total 61
Roadways:
total:
74,558 km (2017)
paved:
74,558 km (2017) (includes 1,205 km of expressways)
comparison ranking:
total 65
Waterways:
400 km (2010)
comparison ranking:
96
Merchant marine:
total:
731 (2022)
by type:
bulk carrier 13, container ship 137, general cargo 70, oil tanker 118, other 393
comparison ranking:
total 32
Ports and terminals:
major seaport(s):
Baltic Sea - Aarhus, Copenhagen, Fredericia, Kalundborg
cruise port(s):
Copenhagen
river port(s):
Aalborg (Langerak)
dry bulk cargo port(s):
Ensted (coal)
North Sea - Esbjerg,
Transportation - note:
Denmark operates icebreakers in the Baltic Sea and Danish Straits; currently operating three PC 5 or 6 class light icebreakers
note - PC indicates a Polar Class vessel: PC 5 - year-round operation in medium first-year ice which may include old ice inclusions (ice thickness up to 70-120 cm); PC 6 - summer/autumn operation in medium first-year ice which may include old ice inclusions (ice thickness up to 30-70 cm)','e9ed6c3b4a6bb19d387979a530539b7215b48fb69c3fd9feb56182c078594558','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0c5b10177d77bc376a0b79a0113458bb46378d0cc3d9c45c3fec18a20e4c1ea6',2025,'DJ','Djibouti','transportation',30,'National air transport system:
number of registered air carriers:
2 (2020)
inventory of registered aircraft operated by air carriers:
4
Civil aircraft registration country code prefix:
J2
Airports:
13 (2021)
comparison ranking:
total 151
Airports - with paved runways:
3
note:
paved runways have a concrete or asphalt surface but not all have facilities for refueling, maintenance, or air traffic control; the length of a runway required for aircraft to safely operate depends on a number of factors including the type of aircraft, the takeoff weight (including passengers, cargo, and fuel), engine types, flap settings, landing speed, elevation of the airport, and average maximum daily air temperature; paved runways can reach a length of 5,000 m (16,000 ft.), but the “typical” length of a commercial airline runway is between 2,500-4,000 m (8,000-13,000 ft.)
Airports - with unpaved runways:
10
note:
unpaved runways have a surface composition such as grass or packed earth and are most suited to the operation of light aircraft; unpaved runways are usually short, often less than 1,000 m (3,280 ft.) in length; airports with unpaved runways often lack facilities for refueling, maintenance, or air traffic control
Railways:
total:
97 km (2017) (Djibouti segment of the 756 km Addis Ababa-Djibouti railway)
standard gauge:
97 km (2017) 1.435-m gauge
comparison ranking:
total 128
Roadways:
total:
2,893 km (2013)
paved:
(2000)
unpaved:
(2000)
comparison ranking:
total 164
Merchant marine:
total:
42 (2022)
by type:
bulk carrier 1, container ship 1, general cargo 4, oil tanker 15, other 21 comparison ranking: total 124
Ports and terminals:
major seaport(s):','f590b06c3ea366698471d0bffb480c2e1aee6b46bf3ac9b9e5e3092d6002b494','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('eb825989ad9c32ab61e96b68a2d0c00e5f6f553420ada80699eecc9f9e6e8f75',2025,'DM','Dominica','transportation',42,'Civil aircraft registration country code prefix:
J7
Airports:
2 (2021)
comparison ranking:
total 201
Airports - with paved runways:
2
note:
paved runways have a concrete or asphalt surface but not all have facilities for refueling, maintenance, or air traffic control; the length of a runway required for aircraft to safely operate depends on a number of factors including the type of aircraft, the takeoff weight (including passengers, cargo, and fuel), engine types, flap settings, landing speed, elevation of the airport, and average maximum daily air temperature; paved runways can reach a length of 5,000 m (16,000 ft.), but the “typical” length of a commercial airline runway is between 2,500-4,000 m (8,000-13,000 ft.)
Roadways:
total:
1,512 km (2018)
paved:
762 km (2018)
unpaved:
750 km (2018)
comparison ranking:
total 174
Merchant marine:
total:
84 (2022)
by type:
general cargo 31, oil tanker 13, other 40
comparison ranking:
total 99
Ports and terminals:
major seaport(s):
Portsmouth, Roseau','8cf3c9555778b2f772550f39eddfb50b003cfc481cad772d0a1fb46587127ce8','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('aeff682e7cd0da120c8df39d9cd0f67c26454b96ebbb5c095da8dac8a4354f46',2025,'DO','Dominican Republic','transportation',53,'National air transport system:
number of registered air carriers:
1 (2020)
inventory of registered aircraft operated by air carriers:
6
Civil aircraft registration country code prefix:
HI
Airports:
36 (2021)
comparison ranking:
total 109
Airports - with paved runways:
16
note:
paved runways have a concrete or asphalt surface but not all have facilities for refueling, maintenance, or air traffic control; the length of a runway required for aircraft to safely operate depends on a number of factors including the type of aircraft, the takeoff weight (including passengers, cargo, and fuel), engine types, flap settings, landing speed, elevation of the airport, and average maximum daily air temperature; paved runways can reach a length of 5,000 m (16,000 ft.), but the “typical” length of a commercial airline runway is between 2,500-4,000 m (8,000-13,000 ft.)
Airports - with unpaved runways:
20
note:
unpaved runways have a surface composition such as grass or packed earth and are most suited to the operation of light aircraft; unpaved runways are usually short, often less than 1,000 m (3,280 ft.) in length; airports with unpaved runways often lack facilities for refueling, maintenance, or air traffic control
Heliports:
1 (2021)
Pipelines:
27 km gas, 103 km oil (2013)
Railways:
total:
496 km (2014)
standard gauge:
354 km (2014) 1.435-m gauge
narrow gauge:
142 km (2014) 0.762-m gauge
comparison ranking:
total 113
Roadways:
total:
19,705 km (2002)
paved:
9,872 km (2002)
unpaved:
9,833 km (2002)
comparison ranking:
total 114
Merchant marine:
total:
38 (2022)
by type:
container ship 1, general cargo 2, oil tanker 1, other 34
comparison ranking:
total 126
Ports and terminals:
major seaport(s):
Puerto Haina, Puerto Plata, Santo Domingo
oil terminal(s):
Punta Nizao oil terminal
cruise port(s):
La Romana
container port(s) (TEUs):
Caucedo (1,265,459); Haina (495,243)
LNG terminal(s) (import):
Andres LNG terminal (Boca Chica)','ee3bef26b0a0e162614c721896c8e2e6df2717905adecb7a087ad02efc0e5ecc','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('456e667e5e95def2f0526a7e978ca0da8e92fec7030f0aad05c0eb48fc9cba66',2025,'EC','Ecuador','transportation',9,'National air transport system:
number of registered air carriers:
7 (2020)
inventory of registered aircraft operated by air carriers:
35
annual passenger traffic on registered air carriers:
5,365,261 (2018)
annual freight traffic on registered air carriers:
64.2 million (2018) mt-km
Civil aircraft registration country code prefix:
HC
Airports:
432 (2021)
comparison ranking:
total 18
Airports - with paved runways:
104
note:
paved runways have a concrete or asphalt surface but not all have facilities for refueling, maintenance, or air traffic control; the length of a runway required for aircraft to safely operate depends on a number of factors including the type of aircraft, the takeoff weight (including passengers, cargo, and fuel), engine types, flap settings, landing speed, elevation of the airport, and average maximum daily air temperature; paved runways can reach a length of 5,000 m (16,000 ft.), but the “typical” length of a commercial airline runway is between 2,500-4,000 m (8,000-13,000 ft.)
Airports - with unpaved runways:
328
note:
unpaved runways have a surface composition such as grass or packed earth and are most suited to the operation of light aircraft; unpaved runways are usually short, often less than 1,000 m (3,280 ft.) in length; airports with unpaved runways often lack facilities for refueling, maintenance, or air traffic control
Heliports:
2 (2021)
Pipelines:
485 km extra heavy crude, 123 km gas, 2,131 km oil, 1,526 km refined products (2017)
Railways:
total:
965 km (2022)
narrow gauge:
965 km (2022) 1.067-m gauge
note:
passenger service limited to certain sections of track, mostly for tourist trains
comparison ranking:
total 90
Roadways:
total:
43,950 km (2022)
paved:
8,895 km (2022)
unpaved:
35,055 km (2022)
comparison ranking:
total 86
Waterways:
1,500 km (2012) (most inaccessible)
comparison ranking:
55
Merchant marine:
total:
147 (2022)
by type:
container ship 1, general cargo 8, oil tanker 28, other 110
comparison ranking:
total 76
Ports and terminals:
major seaport(s):
Esmeraldas, Manta, Puerto Bolivar
container port(s) (TEUs):
Guayaquil (2,163,151) (2021)
river port(s):
Guayaquil (Guayas)','d1c1c442a5f8eeadf8f3409d5dc159b68f5a3a43aaf351df2d840a0fb0384a71','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9ef38ce361636aa75a5e48db83119c39ae726722c4e56afa5c7bc4bca5cff44a',2025,'EG','Egypt','transportation',21,'National air transport system:
number of registered air carriers:
14 (2020)
inventory of registered aircraft operated by air carriers:
101
annual passenger traffic on registered air carriers:
12,340,832 (2018)
annual freight traffic on registered air carriers:
437.63 million (2018) mt-km
Civil aircraft registration country code prefix:
SU
Airports:
83 (2021)
comparison ranking:
total 65
Airports - with paved runways 72
civil airports:
17
military airports:
21
joint use (civil-military) airports:
3
other airports:
31
note:
paved runways have a concrete or asphalt surface but not all have facilities for refueling, maintenance, or air traffic control; the length of a runway required for aircraft to safely operate depends on a number of factors including the type of aircraft, the takeoff weight (including passengers, cargo, and fuel), engine types, flap settings, landing speed, elevation of the airport, and average maximum daily air temperature; paved runways can reach a length of 5,000 m (16,000 ft.), but the “typical” length of a commercial airline runway is between 2,500-4,000 m (8,000-13,000 ft.)
Airports - with unpaved runways:
11
note:
unpaved runways have a surface composition such as grass or packed earth and are most suited to the operation of light aircraft; unpaved runways are usually short, often less than 1,000 m (3,280 ft.) in length; airports with unpaved runways often lack facilities for refueling, maintenance, or air traffic control
Heliports:
7 (2021)
Pipelines:
486 km condensate, 74 km condensate/gas, 7,986 km gas, 957 km liquid petroleum gas, 5,225 km oil, 37 km oil/gas/water, 895 km refined products, 65 km water (2013)
Railways:
total:
5,085 km (2014)
standard gauge:
5,085 km (2014) 1.435-m gauge (62 km electrified)
comparison ranking:
total 38
Roadways:
total:
65,050 km (2018)
paved:
48,000 km (2018)
unpaved:
17,050 km (2018)
comparison ranking:
total 73
Waterways:
3,500 km (2018) (includes the Nile River, Lake Nasser, Alexandria-Cairo Waterway, and numerous smaller canals in Nile Delta; the Suez Canal (193.5 km including approaches) is navigable by oceangoing vessels drawing up to 17.68 m)
comparison ranking:
31
Merchant marine:
total:
436 (2022)
by type:
bulk carrier 15, container ship 6, general cargo 27, oil tanker 41, other 347
comparison ranking:
total 45
Ports and terminals:
major seaport(s):
Mediterranean Sea - Alexandria, Damietta, El Dekheila, Port Said
oil terminal(s):
Ain Sukhna terminal, Sidi Kerir terminal
container port(s) (TEUs):
Port Said (East) (4,764,583) (2021)
LNG terminal(s) (export):
Damietta, Idku (Abu Qir Bay), Sumed
Gulf of Suez - Suez','30ed39af0b73d7f61241938ff03bfc57d1265a3979419ff4c65d1d18b3fa3f21','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('325fefd48edbf7437241e2bc58229a56cf9d76259cb15c58b106235f2e96efb3',2025,'SV','El Salvador','transportation',34,'National air transport system:
number of registered air carriers:
1 (2020)
inventory of registered aircraft operated by air carriers:
13
annual passenger traffic on registered air carriers:
2,545,105 (2018)
annual freight traffic on registered air carriers:
10.73 million (2018) mt-km
Civil aircraft registration country code prefix:
YS
Airports:
68 (2021)
comparison ranking:
total 73
Airports - with paved runways:
5
note:
paved runways have a concrete or asphalt surface but not all have facilities for refueling, maintenance, or air traffic control; the length of a runway required for aircraft to safely operate depends on a number of factors including the type of aircraft, the takeoff weight (including passengers, cargo, and fuel), engine types, flap settings, landing speed, elevation of the airport, and average maximum daily air temperature; paved runways can reach a length of 5,000 m (16,000 ft.), but the “typical” length of a commercial airline runway is between 2,500-4,000 m (8,000-13,000 ft.)
Airports - with unpaved runways:
63
note:
unpaved runways have a surface composition such as grass or packed earth and are most suited to the operation of light aircraft; unpaved runways are usually short, often less than 1,000 m (3,280 ft.) in length; airports with unpaved runways often lack facilities for refueling, maintenance, or air traffic control
Heliports:
2 (2021)
Railways:
total:
12.5 km (2014)
narrow gauge:
12.5 km (2014) 0.914-mm gauge
comparison ranking:
total 136
Roadways:
total:
9,012 km (2017)
paved:
5,341 km (2017)
unpaved:
3,671 km (2017)
comparison ranking:
total 138
Waterways:
422 km (2022) (Rio Lempa River is partially navigable by small craft)
comparison ranking:
95
Merchant marine:
total:
4 (2022)
by type:
other 4
comparison ranking:
total 168
Ports and terminals:
major seaport(s):
Puerto Cutuco
oil terminal(s):
Acajutla offshore terminal','988d2f73f4af615f076a9249bb386986fad16b6c074c853db3cde06a61aa7ff1','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0e885ddb8cf3647675fbd706fcffa5ea06fae2dfadeabf103abb4376480151f1',2025,'GQ','Equatorial Guinea','transportation',46,'National air transport system:
number of registered air carriers:
6 (2020)
inventory of registered aircraft operated by air carriers:
15
annual passenger traffic on registered air carriers:
466,435 (2018)
annual freight traffic on registered air carriers:
350,000 (2018) mt-km
Civil aircraft registration country code prefix:
3C
Airports:
7 (2021)
comparison ranking:
total 170
Airports - with paved runways:
6
note:
paved runways have a concrete or asphalt surface but not all have facilities for refueling, maintenance, or air traffic control; the length of a runway required for aircraft to safely operate depends on a number of factors including the type of aircraft, the takeoff weight (including passengers, cargo, and fuel), engine types, flap settings, landing speed, elevation of the airport, and average maximum daily air temperature; paved runways can reach a length of 5,000 m (16,000 ft.), but the “typical” length of a commercial airline runway is between 2,500-4,000 m (8,000-13,000 ft.)
Airports - with unpaved runways:
1
note:
unpaved runways have a surface composition such as grass or packed earth and are most suited to the operation of light aircraft; unpaved runways are usually short, often less than 1,000 m (3,280 ft.) in length; airports with unpaved runways often lack facilities for refueling, maintenance, or air traffic control
Pipelines:
42 km condensate, 5 km condensate/gas, 79 km gas, 71 km oil (2013)
Roadways:
total:
2,880 km (2017)
comparison ranking:
total 165
Merchant marine:
total:
46 (2022)
by type:
bulk carrier 1, general cargo 12, oil tanker 7, other 26
comparison ranking:
total 122
Ports and terminals:
major seaport(s):
Bata, Luba, Malabo
LNG terminal(s) (export):
Bioko Island','f03866d6c76fa973a47a6da0825166fbd7dedab241e88f6720a6be29fb00fac0','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c15a3be916b20b964e5e9aac43227efe23c12648770e4a479614d758d56c4ad5',2025,'ER','Eritrea','transportation',57,'National air transport system:
number of registered air carriers:
1 (2020)
inventory of registered aircraft operated by air carriers:
1
annual passenger traffic on registered air carriers:
102,729 (2018)
Civil aircraft registration country code prefix:
E3
Airports:
13 (2021)
comparison ranking:
total 152
Airports - with paved runways:
4
note:
paved runways have a concrete or asphalt surface but not all have facilities for refueling, maintenance, or air traffic control; the length of a runway required for aircraft to safely operate depends on a number of factors including the type of aircraft, the takeoff weight (including passengers, cargo, and fuel), engine types, flap settings, landing speed, elevation of the airport, and average maximum daily air temperature; paved runways can reach a length of 5,000 m (16,000 ft.), but the “typical” length of a commercial airline runway is between 2,500-4,000 m (8,000-13,000 ft.)
Airports - with unpaved runways:
9
note:
unpaved runways have a surface composition such as grass or packed earth and are most suited to the operation of light aircraft; unpaved runways are usually short, often less than 1,000 m (3,280 ft.) in length; airports with unpaved runways often lack facilities for refueling, maintenance, or air traffic control
Heliports:
1 (2021)
Railways:
total:
306 km (2018)
narrow gauge:
306 km (2018) 0.950-m gauge
comparison ranking:
total 122
Roadways:
total:
16,000 km (2018)
paved:
1,600 km (2000)
unpaved:
14,400 km (2000)
comparison ranking:
total 120
Merchant marine:
total:
9 (2022)
by type:
general cargo 4, oil tanker 1, other 4
comparison ranking:
total 159
Ports and terminals:
major seaport(s):
Assab, Massawa','710551825b25e8e7f63e437a200ce0b332e883b84cc69cc0bf551e8ddede613c','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9a875126b4705fb5b6f2eaaef98e9d0ec8695a187aff9f1841ebe414734a373d',2025,'EE','Estonia','transportation',9,'National air transport system:
number of registered air carriers:
3 (2020)
inventory of registered aircraft operated by air carriers:
14
annual passenger traffic on registered air carriers:
31,981 (2018)
Civil aircraft registration country code prefix:
ES
Airports:
18 (2021)
comparison ranking:
total 140
Airports - with paved runways:
13
note:
paved runways have a concrete or asphalt surface but not all have facilities for refueling, maintenance, or air traffic control; the length of a runway required for aircraft to safely operate depends on a number of factors including the type of aircraft, the takeoff weight (including passengers, cargo, and fuel), engine types, flap settings, landing speed, elevation of the airport, and average maximum daily air temperature; paved runways can reach a length of 5,000 m (16,000 ft.), but the “typical” length of a commercial airline runway is between 2,500-4,000 m (8,000-13,000 ft.)
Airports - with unpaved runways:
5
note:
unpaved runways have a surface composition such as grass or packed earth and are most suited to the operation of light aircraft; unpaved runways are usually short, often less than 1,000 m (3,280 ft.) in length; airports with unpaved runways often lack facilities for refueling, maintenance, or air traffic control
Heliports:
1 (2021)
Pipelines:
2,360 km gas (2016)
Railways:
total:
1,441 km (2020) 225 km electrified
comparison ranking:
total 83
Roadways:
total:
58,412 km (2011) (includes urban roads)
paved:
10,427 km (2011) (includes 115 km of expressways)
unpaved:
47,985 km (2011)
comparison ranking:
total 78
Waterways:
335 km (2011) (320 km are navigable year-round)
comparison ranking:
99
Merchant marine:
total:
70 (2022)
by type:
general cargo 2, oil tanker 3, other 65
comparison ranking:
total 109
Ports and terminals:
major seaport(s):
Kuivastu, Kunda, Muuga, Parnu Reid, Sillamae, Tallinn
Transportation - note:
Estonia operates two PC 5 or 6 class icebreakers in the Baltic Sea
note - PC indicates a Polar Class vessel:
PC 5 - year-round operation in medium first-year ice which may include old ice inclusions (ice thickness up to 70-120 cm); PC 6 - summer/autumn operation in medium first-year ice which may include old ice inclusions (ice thickness up to 30-70 cm)','2ac6c994a98b545e228787f2ac7bbdd867ce1bda50d59090f6ba4dfbdec34912','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d10fbc15a7f84f3827440ec3b8cec1f7072027cafa2b803588af86bb304596cb',2025,'SZ','Eswatini','transportation',20,'Civil aircraft registration country code prefix:
3DC
Airports:
14 (2021)
comparison ranking:
total 148
Airports - with paved runways:
2
note:
paved runways have a concrete or asphalt surface but not all have facilities for refueling, maintenance, or air traffic control; the length of a runway required for aircraft to safely operate depends on a number of factors including the type of aircraft, the takeoff weight (including passengers, cargo, and fuel), engine types, flap settings, landing speed, elevation of the airport, and average maximum daily air temperature; paved runways can reach a length of 5,000 m (16,000 ft.), but the “typical” length of a commercial airline runway is between 2,500-4,000 m (8,000-13,000 ft.)
Airports - with unpaved runways:
12
note:
unpaved runways have a surface composition such as grass or packed earth and are most suited to the operation of light aircraft; unpaved runways are usually short, often less than 1,000 m (3,280 ft.) in length; airports with unpaved runways often lack facilities for refueling, maintenance, or air traffic control
Railways:
total:
301 km (2014)
narrow gauge:
301 km (2014) 1.067-m gauge
comparison ranking:
total 123
Roadways:
total:
3,769 km (2019)
comparison ranking:
total 157','c8f9f6364ee4d05f01fae5155a172d7d13485ed8fec4acd6b140b3ee6ea24054','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2d97c971c4c24652bb9527505983461f4f601cabf6d1b6ab865ae965eeb515f9',2025,'ET','Ethiopia','transportation',31,'National air transport system:
number of registered air carriers:
1 (2020)
inventory of registered aircraft operated by air carriers:
75
annual passenger traffic on registered air carriers:
11,501,244 (2018)
annual freight traffic on registered air carriers:
2,089,280,000 (2018) mt-km
Civil aircraft registration country code prefix:
ET
Airports:
57 (2021)
comparison ranking:
total 83
Airports - with paved runways:
17
note:
paved runways have a concrete or asphalt surface but not all have facilities for refueling, maintenance, or air traffic control; the length of a runway required for aircraft to safely operate depends on a number of factors including the type of aircraft, the takeoff weight (including passengers, cargo, and fuel), engine types, flap settings, landing speed, elevation of the airport, and average maximum daily air temperature; paved runways can reach a length of 5,000 m (16,000 ft.), but the “typical” length of a commercial airline runway is between 2,500-4,000 m (8,000-13,000 ft.)
Airports - with unpaved runways:
40
note:
unpaved runways have a surface composition such as grass or packed earth and are most suited to the operation of light aircraft; unpaved runways are usually short, often less than 1,000 m (3,280 ft.) in length; airports with unpaved runways often lack facilities for refueling, maintenance, or air traffic control
Railways:
total:
659 km (2017) (Ethiopian segment of the 756 km Addis Ababa-Djibouti railroad)
standard gauge:
659 km (2017) 1.435-m gauge
note:
electric railway with redundant power supplies; under joint control of Djibouti and Ethiopia and managed by a Chinese contractor
comparison ranking:
total 104
Roadways:
total:
120,171 km (2018)
paved:
(2018)
unpaved:
(2015)
comparison ranking:
total 40
Merchant marine:
total:
12 (2022)
by type:
general cargo 10, oil tanker 2
comparison ranking:
total 153
Ports and terminals:
Ethiopia is landlocked and uses the ports of Djibouti in Djibouti and Berbera in Somalia','5901e79c68ad7b8bdd5eb70265a7d022fc4dea4255503145bc6f0ef1683ab2b9','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8f6611a9f69f932c0fc6cc6ecd6106ef0aa6bf2bac0e96609404b7fa977ddfe0',2025,'ET','Ethiopia','transportation',44,'National air transport system:
annual passenger traffic on registered air carriers: 636,860,155 (2018)
annual freight traffic on registered air carriers:
31,730,660,000 (2018)
Airports - with paved runways:
1,882
note:
paved runways have a concrete or asphalt surface but not all have facilities for refueling, maintenance, or air traffic control; the length of a runway required for aircraft to safely operate depends on a number of factors including the type of aircraft, the takeoff weight (including passengers, cargo, and fuel), engine types, flap settings, landing speed, elevation of the airport, and average maximum daily air temperature; paved runways can reach a length of 5,000 m (16,000 ft.), but the “typical” length of a commercial airline runway is between 2,500-4,000 m (8,000-13,000 ft.)
Airports - with unpaved runways:
1,244
note:
unpaved runways have a surface composition such as grass or packed earth and are most suited to the operation of light aircraft; unpaved runways are usually short, often less than 1,000 m (3,280 ft.) in length; airports with unpaved runways often lack facilities for refueling, maintenance, or air traffic control
Heliports:
(2021)90
Railways:
total:
4,894,173 km (2019)
Roadways:
total:
4,894,173 km (2019) 4,894,173
Waterways:
42,000 km (2017) 42,000 km
Ports and terminals:
major port(s):
Antwerp (Belgium), Barcelona (Spain), Braila (Romania), Bremen (Germany), Burgas (Bulgaria), Constanta (Romania), Copenhagen (Denmark), Galati (Romania), Gdansk (Poland), Hamburg (Germany), Helsinki (Finland), Las Palmas (Canary Islands, Spain), Le Havre (France), Lisbon (Portugal), Marseille (France), Naples (Italy), Peiraiefs or Piraeus (Greece), Riga (Latvia), Rotterdam (Netherlands), Split (Croatia), Stockholm (Sweden), Talinn (Estonia), Tulcea (Romania), Varna (Bulgaria)','a06aec13f85bcc04538b090aa757a524dbc0168d90da2d2cc15e104a76173826','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('461f9d2ac2403dfecf6e21430fffdcbcbd2e3244882098214d35a939ba27556e',2025,'FO','Faroe Islands','transportation',10,'National air transport system:
number of registered air carriers:
1 (2020) (registered in Denmark)
inventory of registered aircraft operated by air carriers:
3 (registered in Denmark)
Civil aircraft registration country code prefix:
OY-H
Airports:
1 (2021)
comparison ranking:
total 232
Airports - with paved runways:
1
note:
paved runways have a concrete or asphalt surface but not all have facilities for refueling, maintenance, or air traffic control; the length of a runway required for aircraft to safely operate depends on a number of factors including the type of aircraft, the takeoff weight (including passengers, cargo, and fuel), engine types, flap settings, landing speed, elevation of the airport, and average maximum daily air temperature; paved runways can reach a length of 5,000 m (16,000 ft.), but the “typical” length of a commercial airline runway is between 2,500-4,000 m (8,000-13,000 ft.)
Roadways:
total:
960 km (2017)
paved:
500 km (2017)
unpaved:
460 km (2017)
note:
those islands not connected by roads (bridges or tunnels) are connected by seven different ferry links operated by the nationally owned company SSL; 28 km of tunnels
comparison ranking:
total 187
Merchant marine:
total:
91 (2022)
by type:
container ships 6, general cargo 43, other 42
comparison ranking:
total 96
Ports and terminals:
major seaport(s):
Fuglafjordur, Torshavn, Vagur','39baa762f0f8fc6109b2a6e2de8093ea080db0b3c486d098b1a693e9626bd37d','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c9d9cc51cf90dd06f261f2a16430ef146ff64ed49c612191e289f8683996f0a6',2025,'FJ','Fiji','transportation',21,'National air transport system:
number of registered air carriers:
2 (2020)
inventory of registered aircraft operated by air carriers:
16
annual passenger traffic on registered air carriers:
1,670,216 (2018)
annual freight traffic on registered air carriers:
106.83 million (2018) mt-km
Civil aircraft registration country code prefix:
DQ
Airports:
28 (2021)
comparison ranking:
total 122
Airports - with paved runways:
4
note:
paved runways have a concrete or asphalt surface but not all have facilities for refueling, maintenance, or air traffic control; the length of a runway required for aircraft to safely operate depends on a number of factors including the type of aircraft, the takeoff weight (including passengers, cargo, and fuel), engine types, flap settings, landing speed, elevation of the airport, and average maximum daily air temperature; paved runways can reach a length of 5,000 m (16,000 ft.), but the “typical” length of a commercial airline runway is between 2,500-4,000 m (8,000-13,000 ft.)
Airports - with unpaved runways:
24
note:
unpaved runways have a surface composition such as grass or packed earth and are most suited to the operation of light aircraft; unpaved runways are usually short, often less than 1,000 m (3,280 ft.) in length; airports with unpaved runways often lack facilities for refueling, maintenance, or air traffic control
Railways:
total:
597 km (2008)
narrow gauge:
597 km (2008) 0.600-m gauge
note:
belongs to the government-owned Fiji Sugar Corporation; used to haul sugarcane during the harvest season, which runs from May to December
comparison ranking:
total 108
Roadways:
total:
3,440 km (2011)
paved:
1,686 km (2011)
unpaved:
1,754 km (2011)
comparison ranking:
total 159
Waterways:
203 km (2012) (122 km are navigable by motorized craft and 200-metric-ton barges)
comparison ranking:
107
Merchant marine:
total:
75 (2022)
by type:
general cargo 21, oil tanker 4, other 50
comparison ranking:
total 104
Ports and terminals:
major seaport(s):
Lautoka, Levuka, Suva','6d761874c258fc3cbe7ce4cc8139f4b2a3bf91deef63f6946682a1fb9f89af3a','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2097008cff9cab77e2192468228d8a2cb1d341dfc50e54b1291d34301e52348f',2025,'FI','Finland','transportation',32,'National air transport system:
number of registered air carriers:
3 (2020)
inventory of registered aircraft operated by air carriers:
77
annual passenger traffic on registered air carriers:
13,364,839 (2018)
annual freight traffic on registered air carriers:
957.64 million (2018) mt-km
Civil aircraft registration country code prefix:
OH
Airports:
148 (2021)
comparison ranking:
total 37
Airports - with paved runways:
74
civil airports:
11
military airports:
2
joint use (civil-military) airports:
2
other airports:
59
note:
paved runways have a concrete or asphalt surface but not all have facilities for refueling, maintenance, or air traffic control; the length of a runway required for aircraft to safely operate depends on a number of factors including the type of aircraft, the takeoff weight (including passengers, cargo, and fuel), engine types, flap settings, landing speed, elevation of the airport, and average maximum daily air temperature; paved runways can reach a length of 5,000 m (16,000 ft.), but the “typical” length of a commercial airline runway is between 2,500-4,000 m (8,000-13,000 ft.)
Airports - with unpaved runways:
74
note:
unpaved runways have a surface composition such as grass or packed earth and are most suited to the operation of light aircraft; unpaved runways are usually short, often less than 1,000 m (3,280 ft.) in length; airports with unpaved runways often lack facilities for refueling, maintenance, or air traffic control
Pipelines:
1,288 km gas transmission pipes, 1,976 km distribution pipes (2016)
Railways:
total:
5,918 km (2020) 3,349 km electrified
comparison ranking:
total 33
Roadways:
total:
454,000 km (2012)
highways:
78,000 km (2012) (50,000 paved, including 700 km of expressways; 28,000 unpaved)
private and forest roads:
350,000 km (2012)
urban:
26,000 km (2012)
comparison ranking:
total 17
Waterways:
8,000 km (2013) (includes Saimaa Canal system of 3,577 km; southern part leased from Russia; water transport used frequently in the summer and widely replaced with sledges on the ice in winter; there are 187,888 lakes in Finland that cover 31,500 km); Finland also maintains 8,200 km of coastal fairways
comparison ranking:
19
Merchant marine:
total:
278 (2022)
by type:
bulk carrier 9, container ship 1, general cargo 74, oil tanker 5, other 189
comparison ranking:
total 57
Ports and terminals:
major seaport(s):
Helsinki, Kotka, Naantali, Porvoo, Raahe, Rauma
LNG terminal(s) (import):
Hamina, Inkoo (operational 2023), Pori, Tornio Manga
Transportation - note:
Finland operates icebreakers in the Baltic Sea including seven PC 3 or 4 class medium icebreakers and two PC 5 or 6 class light icebreakers
note - PC indicates a Polar Class vessel:
PC 3 - year-round operation in second-year ice which may include multi-year ice inclusions (ice thickness up to 2.5 m); PC 4 - year-round operation in thick first-year ice which may include old ice inclusions (ice thickness up to 120 cm); PC 5 - year-round operation in medium first-year ice which may include old ice inclusions (ice thickness up to 70-120 cm); PC 6 - summer/autumn operation in medium first-year ice which may include old ice inclusions (ice thickness up to 30-70 cm)','1c485bf53ae4eb54fea01b53c2d3e79053beab5a66b03d13be29d9fd6033cfad','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('29d14e07dcce4b4d8fd42b1f487743a0466a9cac13fc98bc1f72fa0c5f1ff699',2025,'FR','France','transportation',43,'National air transport system:
number of registered air carriers:
19 (2020)
inventory of registered aircraft operated by air carriers:
553
annual passenger traffic on registered air carriers:
70,188,028 (2018)
annual freight traffic on registered air carriers:
4,443,790,000 (2018) mt-km
Civil aircraft registration country code prefix:
F
Airports:
464 (2021)
comparison ranking:
total 15
Airports - with paved runways:
294
civil airports:
64
military airports:
22
joint use (civil-military) airports:
5
other airports:
204
note:
paved runways have a concrete or asphalt surface but not all have facilities for refueling, maintenance, or air traffic control; the length of a runway required for aircraft to safely operate depends on a number of factors including the type of aircraft, the takeoff weight (including passengers, cargo, and fuel), engine types, flap settings, landing speed, elevation of the airport, and average maximum daily air temperature; paved runways can reach a length of 5,000 m (16,000 ft.), but the “typical” length of a commercial airline runway is between 2,500-4,000 m (8,000-13,000 ft.)
Airports - with unpaved runways:
170
note:
unpaved runways have a surface composition such as grass or packed earth and are most suited to the operation of light aircraft; unpaved runways are usually short, often less than 1,000 m (3,280 ft.) in length; airports with unpaved runways often lack facilities for refueling, maintenance, or air traffic control
Heliports:
1 (2021)
Pipelines:
15,322 km gas, 2,939 km oil, 5,084 km refined products (2013)
Railways:
total:
27,860 km (2020) 16,660 km electrified
narrow gauge:
-5 km
comparison ranking:
total 9
Roadways:
total:
1,053,215 km (2011)
paved:
(2011)
urban:
654,201 km (2011)
non-
urban:
399,014 km (2011)
comparison ranking:
total 7
Waterways:
metropolitan France:
8,501 km (1,621 km navigable by craft up to 3,000 metric tons) (2010)
Merchant marine:
total:
549 (2022)
by type:
container ship 32, general cargo 49, oil tanker 26, other 442
note:
includes Monaco
comparison ranking:
total 40
Ports and terminals:
major seaport(s):
Atlantic Ocean:
Brest, Calais, Dunkerque, Le Havre, Nantes
Mediterranean Sea:
Marseille
container port(s) (TEUs):
Le Havre (3,018,550) (2021)
LNG terminal(s) (import):
Dunkerque, Fos Cavaou, Fos Tonkin, Montoir de Bretagne
river port(s):
Bordeaux (Garronne); Nantes - Saint Nazaire (Loire); Paris, Rouen (Seine); Strasbourg (Rhine)
cruise/ferry port(s):
Calais, Cherbourg, Le Havre
Transportation - note:
note 1:
begun in 1988 and completed in 1994, the Channel Tunnel (nicknamed the Chunnel) is a 50.5-km (31.4-mi) rail tunnel beneath the English Channel at the Strait of Dover that runs from Folkestone, Kent, England to Coquelles, Pas-de-Calais in northern France; it is the only fixed link between the island of Great Britain and mainland Europe
note 2:
France operates two icebreakers, one PC 3 or 4 class icebreaker based in French Polynesia for operations in Antarctica and one PC 5 or 6 class icebreaker based in the North Atlantic
note - PC indicates a Polar Class vessel:
PC 3 - year-round operation in second-year ice which may include multi-year ice inclusions (ice thickness up to 2.5 m); PC 4 - year-round operation in thick first-year ice which may include old ice inclusions (ice thickness up to 120 cm); PC 5 - year-round operation in medium first-year ice which may include old ice inclusions (ice thickness up to 70-120 cm); PC 6 - summer/autumn operation in medium first-year ice which may include old ice inclusions (ice thickness up to 30-70 cm)','3001f48aad27782448bc157c160b08d2dc4feacafd9c8b3cc9a40808c90a9d14','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9969dd9318892721a3863d128d3eb14c886a94a50c4d7a540fc47dd6671d0af0',2025,'PF','French Polynesia','transportation',56,'National air transport system:
number of registered air carriers:
2 (2020) (registered in France)
inventory of registered aircraft operated by air carriers:
19 (registered in France)
Civil aircraft registration country code prefix:
F-OH
Airports:
54 (2021)
comparison ranking:
total 85
Airports - with paved runways:
45
note:
paved runways have a concrete or asphalt surface but not all have facilities for refueling, maintenance, or air traffic control; the length of a runway required for aircraft to safely operate depends on a number of factors including the type of aircraft, the takeoff weight (including passengers, cargo, and fuel), engine types, flap settings, landing speed, elevation of the airport, and average maximum daily air temperature; paved runways can reach a length of 5,000 m (16,000 ft.), but the “typical” length of a commercial airline runway is between 2,500-4,000 m (8,000-13,000 ft.)
Airports - with unpaved runways:
9
note:
unpaved runways have a surface composition such as grass or packed earth and are most suited to the operation of light aircraft; unpaved runways are usually short, often less than 1,000 m (3,280 ft.) in length; airports with unpaved runways often lack facilities for refueling, maintenance, or air traffic control
Heliports:
1 (2021)
Roadways:
total:
2,590 km (1999)
paved:
1,735 km (1999)
unpaved:
855 km (1999)
comparison ranking:
total 168
Merchant marine:
total:
25 (2022)
by type:
general cargo 14, other 11
comparison ranking:
total 142
Ports and terminals:
major seaport(s):
Papeete','2efa962781d13a72e4ce9263096801008dac0416b469e8062a237e52aaa39e3e','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cf58b8e57be7bd3d91590c860fc792f6d3467140c8eb2ed32158e707fb540206',2025,'PF','French Polynesia','transportation',66,'Airports:
4 (2021)
comparison ranking:
total 186
Airports - with unpaved runways:
4
note 1:
1 - Europa Island, 1 - Glorioso Islands, 1 - Juan de Nova Island, 1 - Tromelin Island
note 2:
unpaved runways have a surface composition such as grass or packed earth and are most suited to the operation of light aircraft; unpaved runways are usually short, often less than 1,000 m (3,280 ft.) in length; airports with unpaved runways often lack facilities for refueling, maintenance, or air traffic control
Heliports:
3 (2022)
Note:
1 - Ile Amsterdam, 1 - Ile Kerguelen, 1 - Ile de la Possession
Merchant marine:
total:
2 (2022)
by type:
other 2
comparison ranking:
total 178
Ports and terminals:
none; offshore anchorage only','a1c624586b849c098905ece7af5950e7176df47a5ab17862b7944202434cd889','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('284575856201654f34f07461ea376155fecf9460c5966a7c621a16bfc81b9760',2025,'GA','Gabon','transportation',9,'National air transport system:
number of registered air carriers:
3 (2020)
inventory of registered aircraft operated by air carriers:
8
Civil aircraft registration country code prefix:
TR
Airports:
44 (2021)
comparison ranking:
total 97
Airports - with paved runways:
14
note:
paved runways have a concrete or asphalt surface but not all have facilities for refueling, maintenance, or air traffic control; the length of a runway required for aircraft to safely operate depends on a number of factors including the type of aircraft, the takeoff weight (including passengers, cargo, and fuel), engine types, flap settings, landing speed, elevation of the airport, and average maximum daily air temperature; paved runways can reach a length of 5,000 m (16,000 ft.), but the “typical” length of a commercial airline runway is between 2,500-4,000 m (8,000-13,000 ft.)
Airports - with unpaved runways:
30
note:
unpaved runways have a surface composition such as grass or packed earth and are most suited to the operation of light aircraft; unpaved runways are usually short, often less than 1,000 m (3,280 ft.) in length; airports with unpaved runways often lack facilities for refueling, maintenance, or air traffic control
Pipelines:
807 km gas, 1,639 km oil, 3 km water (2013)
Railways:
total:
649 km (2014)
standard gauge:
649 km (2014) 1.435-m gauge
comparison ranking:
total 105
Roadways:
total:
14,300 km (2001)
paved:
900 km (2001)
unpaved:
13,400 km (2001)
comparison ranking:
total 126
Waterways:
1,600 km (2010) (310 km on Ogooue River)
comparison ranking:
51
Merchant marine:
total:
71 (2022)
by type:
bulk carrier 2, general cargo 19, oil tanker 20, other 30
comparison ranking:
total 107
Ports and terminals:
major seaport(s):
Libreville, Owendo, Port-Gentil
oil terminal(s):
Gamba, Lucina','0225c90a3064f631d2bd00ae3fd935a890911729940acb8250d06aa40d88d849','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f76b43d0df43697fed4cffed0ee160eb721f3894532c08a00a2cefa9801fe45f',2025,'GA','Gabon','transportation',21,'National air transport system:
number of registered air carriers:
2 (2020)
inventory of registered aircraft operated by air carriers:
6
annual passenger traffic on registered air carriers:
53,735 (2018)
Civil aircraft registration country code prefix:
C5
Airports:
1 (2021)
comparison ranking:
total 225
Airports - with paved runways:
1
note:
paved runways have a concrete or asphalt surface but not all have facilities for refueling, maintenance, or air traffic control; the length of a runway required for aircraft to safely operate depends on a number of factors including the type of aircraft, the takeoff weight (including passengers, cargo, and fuel), engine types, flap settings, landing speed, elevation of the airport, and average maximum daily air temperature; paved runways can reach a length of 5,000 m (16,000 ft.), but the “typical” length of a commercial airline runway is between 2,500-4,000 m (8,000-13,000 ft.)
Roadways:
total:
2,977 km (2011)
paved:
518 km (2011)
unpaved:
2,459 km (2011)
comparison ranking:
total 162
Waterways:
390 km (2010) (on River Gambia; small oceangoing vessels can reach 190 km)
comparison ranking:
97
Merchant marine:
total:
9 (2022)
by type:
general cargo 1, other 8
comparison ranking:
total 158
Ports and terminals:
major seaport(s):
Banjul','c7067f06a2b7d29f4bda74c4d206b358ac145ffe0ef1650ae4517d5d8e02fe5b','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8eac3aa1316c2f42264930cfa4658ba5eb47c833314121dee8ae6ac31e72ee2c',2025,'GA','Gabon','transportation',32,'Airports:
1 (2021)
comparison ranking:
total 231
Airports - with paved runways:
1
note:
non-operational
Heliports:
1 (2021)
Roadways:
note:
see entry for the West Bank
Ports and terminals:
major seaport(s):
Gaza','7b9d7183f4eb1f38d311598d9038a5f829821626ccdc939f329a09c890022138','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0ef1ebab911059a68a2a655c00e3643ffc2d4598410f7b5cb65e45775cb59655',2025,'GE','Georgia','transportation',44,'National air transport system:
number of registered air carriers:
4 (2020)
inventory of registered aircraft operated by air carriers:
12
annual passenger traffic on registered air carriers:
516,034 (2018)
annual freight traffic on registered air carriers:
750,000 (2018) mt-km
Civil aircraft registration country code prefix:
4L
Airports:
22 (2021)
comparison ranking:
total 134
Airports - with paved runways:
18
note:
paved runways have a concrete or asphalt surface but not all have facilities for refueling, maintenance, or air traffic control; the length of a runway required for aircraft to safely operate depends on a number of factors including the type of aircraft, the takeoff weight (including passengers, cargo, and fuel), engine types, flap settings, landing speed, elevation of the airport, and average maximum daily air temperature; paved runways can reach a length of 5,000 m (16,000 ft.), but the “typical” length of a commercial airline runway is between 2,500-4,000 m (8,000-13,000 ft.)
Airports - with unpaved runways:
4
note:
unpaved runways have a surface composition such as grass or packed earth and are most suited to the operation of light aircraft; unpaved runways are usually short, often less than 1,000 m (3,280 ft.) in length; airports with unpaved runways often lack facilities for refueling, maintenance, or air traffic control
Heliports:
2 (2021)
Pipelines:
1,596 km gas, 1,175 km oil (2013)
Railways:
total:
1,363 km (2014)
narrow gauge:
37 km (2014) 0.912-m gauge (37 km electrified)
broad gauge:
1,326 km (2014) 1.520-m gauge (1,251 km electrified)
comparison ranking:
total 84
Roadways:
total:
20,295 km (2018)
comparison ranking:
total 113
Merchant marine:
total:
24 (2022)
by type:
general cargo 3, other 21
comparison ranking:
total 143
Ports and terminals:
major seaport(s):
Black Sea - Batumi, Poti','c4adf0711a0f67c3479d7e8f1a64afaff75fc36b47ab93d71d7ece84cb643acf','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b370f80ed9d81214cf71080c0d9ff02716bda02dc657a5e50fe9efe4b4b3bb58',2025,'DE','Germany','transportation',55,'National air transport system:
number of registered air carriers:
20 (2020)
inventory of registered aircraft operated by air carriers:
1,113
annual passenger traffic on registered air carriers:
109,796,202 (2018)
annual freight traffic on registered air carriers:
7,969,860,000 (2018) mt-km
Civil aircraft registration country code prefix:
D
Airports:
539 (2021)
comparison ranking:
total 12
Airports - with paved runways:
318
civil airports:
49
military airports:
21
joint use (civil-military) airports:
6
other airports:
242
note:
paved runways have a concrete or asphalt surface but not all have facilities for refueling, maintenance, or air traffic control; the length of a runway required for aircraft to safely operate depends on a number of factors including the type of aircraft, the takeoff weight (including passengers, cargo, and fuel), engine types, flap settings, landing speed, elevation of the airport, and average maximum daily air temperature; paved runways can reach a length of 5,000 m (16,000 ft.), but the “typical” length of a commercial airline runway is between 2,500-4,000 m (8,000-13,000 ft.)
Airports - with unpaved runways:
221
note:
unpaved runways have a surface composition such as grass or packed earth and are most suited to the operation of light aircraft; unpaved runways are usually short, often less than 1,000 m (3,280 ft.) in length; airports with unpaved runways often lack facilities for refueling, maintenance, or air traffic control
Heliports:
23 (2021)
Pipelines:
37 km condensate, 26,985 km gas, 2,400 km oil, 4,479 km refined products, 8 km water (2013)
Railways:
total:
39,379 km (2020) 20,942 km electrified
15 km 0.900-mm gauge, 24 km 0.750-mm gauge (2015)
comparison ranking:
total 6
Roadways:
total:
830,000 km (2022) 830,000 km
paved:
830,000 km (2022) (includes 13,155 km of expressways)
note:
includes local roads
comparison ranking:
total 10
Waterways:
7,300 km (2022) (Rhine River carries most goods; Main-Danube Canal links North Sea and Black Sea)
comparison ranking:
20
Merchant marine:
total:
592 (2022)
by type:
bulk carrier 1, container ship 72, general cargo 79, oil tanker 34, other 406
comparison ranking:
total 38
Ports and terminals:
major seaport(s):
Baltic Sea:
Kiel, Rostock
North Sea:
Bremerhaven, Brunsbuttel, Emden, Hamburg, Wilhelmshaven
oil terminal(s):
Brunsbuttel Canal terminals
container port(s) (TEUs):
Bremen/Bremerhaven (5,018,900), Hamburg (8,715,000) (2021)
LNG terminal(s) (import):
Hamburg; Brunsbuettel (FSRU); Lubmin (FSRU); Wilhelmshaven (FSRU)
river port(s):
Bremen (Weser); Bremerhaven (Geeste); Duisburg, Karlsruhe, Neuss-Dusseldorf (Rhine); Lubeck (Wakenitz); Brunsbuttel, Hamburg (Elbe)
Transportation - note:
Germany operates one PC 5 or 6 class icebreaker based in the North Atlantic
note - PC indicates a Polar Class vessel:
PC 5 - year-round operation in medium first-year ice which may include old ice inclusions (ice thickness up to 70-120 cm); PC 6 - summer/autumn operation in medium first-year ice which may include old ice inclusions (ice thickness up to 30-70 cm)','a2a217a11f0343fa3bc26ae09007d5cf467bcdd8498c93a9e2ef6ae9aeab2987','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e48775b916e7ae6552dec23d7067437a406e009214b32919c44f6bca6952ebed',2025,'GH','Ghana','transportation',68,'National air transport system:
number of registered air carriers:
3 (2020)
inventory of registered aircraft operated by air carriers:
21
annual passenger traffic on registered air carriers:
467,438 (2018)
Civil aircraft registration country code prefix:
9G
Airports:
10 (2021)
comparison ranking:
total 155
Airports - with paved runways:
7
note:
paved runways have a concrete or asphalt surface but not all have facilities for refueling, maintenance, or air traffic control; the length of a runway required for aircraft to safely operate depends on a number of factors including the type of aircraft, the takeoff weight (including passengers, cargo, and fuel), engine types, flap settings, landing speed, elevation of the airport, and average maximum daily air temperature; paved runways can reach a length of 5,000 m (16,000 ft.), but the “typical” length of a commercial airline runway is between 2,500-4,000 m (8,000-13,000 ft.)
Airports - with unpaved runways:
3
note:
unpaved runways have a surface composition such as grass or packed earth and are most suited to the operation of light aircraft; unpaved runways are usually short, often less than 1,000 m (3,280 ft.) in length; airports with unpaved runways often lack facilities for refueling, maintenance, or air traffic control
Pipelines:
681.3 km gas, 11.4 km oil, 435 km refined products (2022)
Railways:
total:
947 km (2022)
narrow gauge:
947 km (2022) 1.067-m gauge
comparison ranking:
total 92
Roadways:
total:
65,725 km (2021)
paved:
14,948 km (2021)
unpaved:
50,777 km (2021)
urban:
28,480 km 27% total paved 73% total unpaved
comparison ranking:
total 72
Waterways:
1,293 km (2011) (168 km for launches and lighters on Volta, Ankobra, and Tano Rivers; 1,125 km of arterial and feeder waterways on Lake Volta)
comparison ranking:
60
Merchant marine:
total:
52 (2022)
by type:
general cargo 7, oil tanker 3, other 42
comparison ranking:
total 118
Ports and terminals:
major seaport(s):
Takoradi, Tema','b0bfa4e4346fddb32da8f3b70f115e8941ea62cb78307b889fe1e5cdbc22ac16','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('42654b001f523de1dee23913e6f65ddcc73ced4eb3450ceee025cb11a113bc38',2025,'GI','Gibraltar','transportation',9,'Civil aircraft registration country code prefix:
VP-G
Airports:
1 (2021)
comparison ranking:
total 215
Airports - with paved runways:
1
note:
paved runways have a concrete or asphalt surface but not all have facilities for refueling, maintenance, or air traffic control; the length of a runway required for aircraft to safely operate depends on a number of factors including the type of aircraft, the takeoff weight (including passengers, cargo, and fuel), engine types, flap settings, landing speed, elevation of the airport, and average maximum daily air temperature; paved runways can reach a length of 5,000 m (16,000 ft.), but the “typical” length of a commercial airline runway is between 2,500-4,000 m (8,000-13,000 ft.)
Roadways:
total:
29 km (2007)
paved:
29 km (2007)
comparison ranking:
total 220
Merchant marine:
total:
155 (2022)
by type:
bulk carrier 8, container ship 12, general cargo 36, oil tanker 16, other 83
comparison ranking:
total 72
Ports and terminals:
major seaport(s):','282b93170ad73b9b42ccb7ec8f4753dfe4c67d1d09942240ba71064bdd9ae9d4','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a125c96af3fbef4da2841c3defa5760d2e4e8b8fa87b6e7649907d75c7da6807',2025,'GR','Greece','transportation',20,'National air transport system:
number of registered air carriers:
11 (2020)
inventory of registered aircraft operated by air carriers:
97
annual passenger traffic on registered air carriers:
15,125,933 (2018)
annual freight traffic on registered air carriers:
21.91 million (2018) mt-km
Civil aircraft registration country code prefix:
SX
Airports:
77 (2021)
comparison ranking:
total 69
Airports - with paved runways:
68
note:
paved runways have a concrete or asphalt surface but not all have facilities for refueling, maintenance, or air traffic control; the length of a runway required for aircraft to safely operate depends on a number of factors including the type of aircraft, the takeoff weight (including passengers, cargo, and fuel), engine types, flap settings, landing speed, elevation of the airport, and average maximum daily air temperature; paved runways can reach a length of 5,000 m (16,000 ft.), but the “typical” length of a commercial airline runway is between 2,500-4,000 m (8,000-13,000 ft.)
Airports - with unpaved runways:
9
note:
unpaved runways have a surface composition such as grass or packed earth and are most suited to the operation of light aircraft; unpaved runways are usually short, often less than 1,000 m (3,280 ft.) in length; airports with unpaved runways often lack facilities for refueling, maintenance, or air traffic control
Heliports:
9 (2021)
Pipelines:
1,466 km gas, 94 km oil (2013)
Railways:
total:
2,345 km (2020) 731 km electrified
comparison ranking:
total 67
Roadways:
total:
117,000 km (2018)
comparison ranking:
total 42
Waterways:
6 km (2012) (the 6-km-long Corinth Canal crosses the Isthmus of Corinth; it shortens a sea voyage by 325 km) comparison ranking: 117
Merchant marine:
total:
1,234 (2022)
by type:
bulk carrier 146, container ship 5, general cargo 83, oil tanker 311, other 689
comparison ranking:
total 21
Ports and terminals:
major seaport(s):
Aspropyrgos, Pachi, Piraeus, Thessaloniki
oil terminal(s):
Agioi Theodoroi
container port(s) (TEUs):
Piraeus (5,311,810) (2021)
LNG terminal(s) (import):
Revithoussa','8ba3195ecd8eb710edc4f48467a299731a97b9731df31cbb0204597f00f96bab','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9875771da6523d85f8914ad99c1c405ed87926b74480a783fa98f40569291a96',2025,'GL','Greenland','transportation',33,'National air transport system:
number of registered air carriers:
1 (2020) (registered in Denmark)
inventory of registered aircraft operated by air carriers:
8 (registered in Denmark)
Civil aircraft registration country code prefix:
OY-H
Airports:
15 (2021)
comparison ranking:
total 146
Airports - with paved runways:
10
note:
paved runways have a concrete or asphalt surface but not all have facilities for refueling, maintenance, or air traffic control; the length of a runway required for aircraft to safely operate depends on a number of factors including the type of aircraft, the takeoff weight (including passengers, cargo, and fuel), engine types, flap settings, landing speed, elevation of the airport, and average maximum daily air temperature; paved runways can reach a length of 5,000 m (16,000 ft.), but the “typical” length of a commercial airline runway is between 2,500-4,000 m (8,000-13,000 ft.)
Airports - with unpaved runways:
5
note:
unpaved runways have a surface composition such as grass or packed earth and are most suited to the operation of light aircraft; unpaved runways are usually short, often less than 1,000 m (3,280 ft.) in length; airports with unpaved runways often lack facilities for refueling, maintenance, or air traffic control
Roadways:
note:
although there are short roads in towns, there are no roads between towns; inter-urban transport is either by sea or by air
Merchant marine:
total:
6 (2022)
by type:
other 6
comparison ranking:
total 164
Ports and terminals:
major seaport(s):
Sisimiut','9edeb3702acb45be150995b4bb5716324889caac0f72e499a3c7dcf67b729891','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('640da6e810d2e692deaa7c5007108516ce9dbceef83aaf4bc95599d17a30c426',2025,'GD','Grenada','transportation',44,'Civil aircraft registration country code prefix:
J3
Airports:
3 (2021)
comparison ranking:
total 195
Airports - with paved runways:
3
note:
paved runways have a concrete or asphalt surface but not all have facilities for refueling, maintenance, or air traffic control; the length of a runway required for aircraft to safely operate depends on a number of factors including the type of aircraft, the takeoff weight (including passengers, cargo, and fuel), engine types, flap settings, landing speed, elevation of the airport, and average maximum daily air temperature; paved runways can reach a length of 5,000 m (16,000 ft.), but the “typical” length of a commercial airline runway is between 2,500-4,000 m (8,000-13,000 ft.)
Roadways:
total:
1,127 km (2017)
paved:
902 km (2017)
unpaved:
225 km (2017)
comparison ranking:
total 182
Merchant marine:
total:
6 (2022)
by type:
general cargo 3, other 3
comparison ranking:
total 165
Ports and terminals:
major seaport(s):
Saint George’s','cd14cc1f5f2fac2efadca14ea964a9a267b230d3da3fbe04e8c48c6004dc067b','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5865b46163d008b72c0c54131f738736d67c75e99ba999f6d84e876b627e3077',2025,'GU','Guam','transportation',55,'Civil aircraft registration country code prefix:
N
Airports:
5 (2021)
comparison ranking:
total 179
Airports - with paved runways:
4
note:
paved runways have a concrete or asphalt surface but not all have facilities for refueling, maintenance, or air traffic control; the length of a runway required for aircraft to safely operate depends on a number of factors including the type of aircraft, the takeoff weight (including passengers, cargo, and fuel), engine types, flap settings, landing speed, elevation of the airport, and average maximum daily air temperature; paved runways can reach a length of 5,000 m (16,000 ft.), but the “typical” length of a commercial airline runway is between 2,500-4,000 m (8,000-13,000 ft.)
Airports - with unpaved runways:
1
note:
unpaved runways have a surface composition such as grass or packed earth and are most suited to the operation of light aircraft; unpaved runways are usually short, often less than 1,000 m (3,280 ft.) in length; airports with unpaved runways often lack facilities for refueling, maintenance, or air traffic control
Roadways:
total:
1,045 km (2008)
comparison ranking:
total 185
Merchant marine:
total:
3 (2022)
by type:
other 3
comparison ranking:
total 173
Ports and terminals:
major seaport(s):
Apra Harbor','bf76ad7d90849a660737ac937dfe8829eb15e1a63b89cc9a5f76be792d7f827f','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e8fe2f7ddbe93910680bb2a82b2ff94706df445071a64d0648762e2b7c9960fa',2025,'GT','Guatemala','transportation',66,'National air transport system:
number of registered air carriers:
3 (2020)
inventory of registered aircraft operated by air carriers:
5
annual passenger traffic on registered air carriers:
145,795 (2018)
annual freight traffic on registered air carriers:
110,000 (2018) mt-km
Civil aircraft registration country code prefix:
TG
Airports:
291 (2021)
comparison ranking:
total 23
Airports - with paved runways:
16
note:
paved runways have a concrete or asphalt surface but not all have facilities for refueling, maintenance, or air traffic control; the length of a runway required for aircraft to safely operate depends on a number of factors including the type of aircraft, the takeoff weight (including passengers, cargo, and fuel), engine types, flap settings, landing speed, elevation of the airport, and average maximum daily air temperature; paved runways can reach a length of 5,000 m (16,000 ft.), but the “typical” length of a commercial airline runway is between 2,500-4,000 m (8,000-13,000 ft.)
Airports - with unpaved runways:
275
note:
unpaved runways have a surface composition such as grass or packed earth and are most suited to the operation of light aircraft; unpaved runways are usually short, often less than 1,000 m (3,280 ft.) in length; airports with unpaved runways often lack facilities for refueling, maintenance, or air traffic control
Heliports:
1 (2021)
Pipelines:
480 km oil (2013)
Railways:
total:
800 km (2018)
narrow gauge:
800 km (2018) 0.914-m gauge
note:
despite the existence of a railway network, all rail service was suspended in 2007 and no passenger or freight train currently runs in the country (2018)
comparison ranking:
total 96
Roadways:
total:
17,440 km (2020)
paved:
7,458 km (2020)
unpaved:
9,982 km (2020) (includes 4,548 km of rural roads)
comparison ranking:
total 118
Waterways:
990 km (2012) (260 km navigable year round; additional 730 km navigable during high-water season)
comparison ranking:
71
Merchant marine:
total:
9 (2022)
by type:
oil tanker 1, other 8
comparison ranking:
total 160
Ports and terminals:
major seaport(s):
Puerto Quetzal, Santo Tomas de Castilla','0f2678c42245754197651ff00f4239924b89fd93376e9688431e7854841a00b0','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('05e002f5faba9d074edbbfe6fe29d0f2978f63fb26f1026d68ae326f0e370608',2025,'GG','Guernsey','transportation',9,'National air transport system:
number of registered air carriers:
1 (2020) (registered in UK)
inventory of registered aircraft operated by air carriers:
9 (registered in UK)
Civil aircraft registration country code prefix:
2
Airports:
2 (2021)
comparison ranking:
total 205
Airports - with paved runways:
2
note:
paved runways have a concrete or asphalt surface but not all have facilities for refueling, maintenance, or air traffic control; the length of a runway required for aircraft to safely operate depends on a number of factors including the type of aircraft, the takeoff weight (including passengers, cargo, and fuel), engine types, flap settings, landing speed, elevation of the airport, and average maximum daily air temperature; paved runways can reach a length of 5,000 m (16,000 ft.), but the “typical” length of a commercial airline runway is between 2,500-4,000 m (8,000-13,000 ft.)
Roadways:
total:
260 km (2017)
comparison ranking:
total 204
Ports and terminals:
major seaport(s):
Braye Bay, Saint Peter Port','7e1c20d5c946b6c08264365304e416cd9874270a65fd20a7982c3dfb8afb6091','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('80ee09908a607d231de2b64e092f930c62ebed052c5e017ff1e55859f42b3a09',2025,'GN','Guinea','transportation',20,'Civil aircraft registration country code prefix:
3X
Airports:
16 (2021)
comparison ranking:
total 143
Airports - with paved runways:
4
note:
paved runways have a concrete or asphalt surface but not all have facilities for refueling, maintenance, or air traffic control; the length of a runway required for aircraft to safely operate depends on a number of factors including the type of aircraft, the takeoff weight (including passengers, cargo, and fuel), engine types, flap settings, landing speed, elevation of the airport, and average maximum daily air temperature; paved runways can reach a length of 5,000 m (16,000 ft.), but the “typical” length of a commercial airline runway is between 2,500-4,000 m (8,000-13,000 ft.)
Airports - with unpaved runways:
12
note:
unpaved runways have a surface composition such as grass or packed earth and are most suited to the operation of light aircraft; unpaved runways are usually short, often less than 1,000 m (3,280 ft.) in length; airports with unpaved runways often lack facilities for refueling, maintenance, or air traffic control
Railways:
total:
1,086 km (2017)
standard gauge:
279 km (2017) 1.435-m gauge
narrow gauge:
807 km (2017) 1.000-m gauge
comparison ranking:
total 88
Roadways:
total:
44,301 km (2018)
paved:
3,346 km (2018)
unpaved:
40,955 km (2018)
comparison ranking:
total 84
Waterways:
1,300 km (2011) (navigable by shallow-draft native craft in the northern part of the Niger River system) comparison ranking: 58
Merchant marine:
total:
3 (2022)
by type:
general cargo 1, other 2
comparison ranking:
total 172
Ports and terminals:
major seaport(s):
Conakry, Kamsar','b290e6c85ddd2399f7515da13e41258fb98ec03b5424af20e862de439dca6c15','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7cfc63fa5c7afc95a56c9ba5b3c48a9b24c6e2b1dd230c51e8bea16eed93427a',2025,'GW','Guinea-Bissau','transportation',31,'Civil aircraft registration country code prefix:
J5
Airports:
8 (2021)
comparison ranking:
total 161
Airports - with paved runways:
2
note:
paved runways have a concrete or asphalt surface but not all have facilities for refueling, maintenance, or air traffic control; the length of a runway required for aircraft to safely operate depends on a number of factors including the type of aircraft, the takeoff weight (including passengers, cargo, and fuel), engine types, flap settings, landing speed, elevation of the airport, and average maximum daily air temperature; paved runways can reach a length of 5,000 m (16,000 ft.), but the “typical” length of a commercial airline runway is between 2,500-4,000 m (8,000-13,000 ft.)
Airports - with unpaved runways:
6
note:
unpaved runways have a surface composition such as grass or packed earth and are most suited to the operation of light aircraft; unpaved runways are usually short, often less than 1,000 m (3,280 ft.) in length; airports with unpaved runways often lack facilities for refueling, maintenance, or air traffic control
Roadways:
total:
4,400 km (2018)
paved:
453 km (2018)
unpaved:
3,947 km (2018)
comparison ranking:
total 150
Waterways:
1,367 km (2022) major rivers Geba- 550km, Corubal 560 km, Cacheu 257 km (rivers are partially navigable; many inlets and creeks provide shallow-water access to much of interior)
comparison ranking:
56
Merchant marine:
total:
8 (2022)
by type:
general cargo 5, other 3
comparison ranking:
total 162
Ports and terminals:
major seaport(s):
Bissau, Buba, Cacheu, Farim','eab5b1877581c458d4f80d99b2da18e9e3b7873b0d4ef1b1a2edf56deb4f9d1a','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b74a7b386786467e93fcc662f19be093acc2f485a8cdad5fe44514c58d1e750d',2025,'GY','Guyana','transportation',42,'Civil aircraft registration country code prefix:
8R
Airports:
117 (2021)
comparison ranking:
total 48
Airports - with paved runways:
11
note:
paved runways have a concrete or asphalt surface but not all have facilities for refueling, maintenance, or air traffic control; the length of a runway required for aircraft to safely operate depends on a number of factors including the type of aircraft, the takeoff weight (including passengers, cargo, and fuel), engine types, flap settings, landing speed, elevation of the airport, and average maximum daily air temperature; paved runways can reach a length of 5,000 m (16,000 ft.), but the “typical” length of a commercial airline runway is between 2,500-4,000 m (8,000-13,000 ft.)
Airports - with unpaved runways:
106
note:
unpaved runways have a surface composition such as grass or packed earth and are most suited to the operation of light aircraft; unpaved runways are usually short, often less than 1,000 m (3,280 ft.) in length; airports with unpaved runways often lack facilities for refueling, maintenance, or air traffic control
Roadways:
total:
3,995 km (2019)
paved:
799 km (2019)
unpaved:
3,196 km (2019)
comparison ranking:
total 155
Waterways:
330 km (2012) (the Berbice, Demerara, and Essequibo Rivers are navigable by oceangoing vessels for 150 km, 100 km, and 80 km respectively)
comparison ranking:
100
Merchant marine:
total:
89 (2022)
by type:
bulk carrier 1, general cargo 45, oil tanker 12, other 31
comparison ranking:
total 98
Ports and terminals:
major seaport(s):
Georgetown','3f58cce16b672a2dc40ceedb327f6ecf6e67082518ef8c1096b29db9577a3e74','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1dee5e109e664dd1724f6cc161c4a8fe93f4df2a572416d34160eb0ae6f7f6c6',2025,'HT','Haiti','transportation',9,'National air transport system:
number of registered air carriers:
1 (2020)
inventory of registered aircraft operated by air carriers:
1
Civil aircraft registration country code prefix:
HH
Airports:
14 (2021)
comparison ranking:
total 149
Airports - with paved runways:
4
note:
paved runways have a concrete or asphalt surface but not all have facilities for refueling, maintenance, or air traffic control; the length of a runway required for aircraft to safely operate depends on a number of factors including the type of aircraft, the takeoff weight (including passengers, cargo, and fuel), engine types, flap settings, landing speed, elevation of the airport, and average maximum daily air temperature; paved runways can reach a length of 5,000 m (16,000 ft.), but the “typical” length of a commercial airline runway is between 2,500-4,000 m (8,000-13,000 ft.)
Airports - with unpaved runways:
10
note:
unpaved runways have a surface composition such as grass or packed earth and are most suited to the operation of light aircraft; unpaved runways are usually short, often less than 1,000 m (3,280 ft.) in length; airports with unpaved runways often lack facilities for refueling, maintenance, or air traffic control
Roadways:
total:
4,102 km (2011)
paved:
600 km (2011)
unpaved:
3,502 km (2011)
comparison ranking:
total 153
Merchant marine:
total:
4 (2022)
by type:
general cargo 3, other 1
comparison ranking:
total 167
Ports and terminals:
major seaport(s):
Cap-Haitien, Gonaives, Jacmel, Port-au-Prince','6628cae2dc9100d1e54c1c80352f3b7b1b0a6d16058ec2aa216610d8902e24b3','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('77b245f585ad4f7fd1dae634a336209b344305528c18a1ba92be9090eea1eda9',2025,'HM','Heard Island and McDonald Islands','transportation',18,'Ports and terminals:
none; offshore anchorage only','97a08f7f958d0d9909c5d5cf9b653fbd7f83ba17e780ff6265a95bb5fccb5752','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2649c921c6339c91e25d4db55f1e3cf15c70e0d8ebfe295ad4127bb86bd14b69',2025,'HN','Honduras','transportation',39,'National air transport system:
number of registered air carriers:
4 (2020)
inventory of registered aircraft operated by air carriers:
26
annual passenger traffic on registered air carriers:
251,149 (2018)
annual freight traffic on registered air carriers:
450,000 (2018) mt-km
Civil aircraft registration country code prefix:
HR
Airports:
103 (2021)
comparison ranking:
total 53
Airports - with paved runways:
13
note:
paved runways have a concrete or asphalt surface but not all have facilities for refueling, maintenance, or air traffic control; the length of a runway required for aircraft to safely operate depends on a number of factors including the type of aircraft, the takeoff weight (including passengers, cargo, and fuel), engine types, flap settings, landing speed, elevation of the airport, and average maximum daily air temperature; paved runways can reach a length of 5,000 m (16,000 ft.), but the “typical” length of a commercial airline runway is between 2,500-4,000 m (8,000-13,000 ft.)
Airports - with unpaved runways:
90
note:
unpaved runways have a surface composition such as grass or packed earth and are most suited to the operation of light aircraft; unpaved runways are usually short, often less than 1,000 m (3,280 ft.) in length; airports with unpaved runways often lack facilities for refueling, maintenance, or air traffic control
Railways:
total:
699 km (2014)
narrow gauge:
164 km (2014) 1.067-m gauge
115 km 1.057-mm gauge
420 km 0.914-mm gauge
comparison ranking:
total 100
Roadways:
total:
14,742 km (2012)
paved:
3,367 km (2012)
unpaved:
11,375 km (2012) (1,543 km summer only)
note:
an additional 8,951 km of non-official roads used by the coffee industry
comparison ranking:
total 125
Waterways:
465 km (2012) (most navigable only by small craft)
comparison ranking:
92
Merchant marine:
total:
505 (2022)
by type:
general cargo 246, oil tanker 82, other 177
comparison ranking:
total 42
Ports and terminals:
major seaport(s):
La Ceiba, Puerto Cortes, San Lorenzo, Tela','e04a0b2b167b6c7ce0de6890536f86e4dede220e4b3fecc5fe1f94205a2bb212','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4b0c1a089812ce6647ea4e6d0f5cc498e8ca3017005f96ebef0c0fc0414c31c5',2025,'HK','Hong Kong','transportation',50,'National air transport system:
number of registered air carriers:
12 (2020) (registered in China)
inventory of registered aircraft operated by air carriers:
275 (registered in China)
annual passenger traffic on registered air carriers:
47,101,822 (2018)
annual freight traffic on registered air carriers:
12,676,720,000 (2018) mt-km
Civil aircraft registration country code prefix:
B-H
Airports:
2 (2021)
comparison ranking:
total 208
Airports - with paved runways:
2
note:
paved runways have a concrete or asphalt surface but not all have facilities for refueling, maintenance, or air traffic control; the length of a runway required for aircraft to safely operate depends on a number of factors including the type of aircraft, the takeoff weight (including passengers, cargo, and fuel), engine types, flap settings, landing speed, elevation of the airport, and average maximum daily air temperature; paved runways can reach a length of 5,000 m (16,000 ft.), but the “typical” length of a commercial airline runway is between 2,500-4,000 m (8,000-13,000 ft.)
Heliports:
9 (2021)
Roadways:
total:
2,193 km (2021)
paved:
2,193 km (2021)
comparison ranking:
total 170
Merchant marine:
total:
2,661 (2022)
by type:
bulk carrier 1,135, container ship 558, general cargo 155, oil tanker 394, other 419
comparison ranking:
total 9
Ports and terminals:
major seaport(s):','492913175a49ea696077e0d0d292e94c787c23a2bdf197f8d1f05a3f36a5afbf','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c1f3ac1095c71a8d945a9b1d3c8272b11714d06f0e2505f6dcf030383c768016',2025,'HU','Hungary','transportation',62,'National air transport system:
number of registered air carriers:
5 (2020)
inventory of registered aircraft operated by air carriers:
145
annual passenger traffic on registered air carriers:
31,226,848 (2018)
Civil aircraft registration country code prefix:
HA
Airports:
41 (2021)
comparison ranking:
total 102
Airports - with paved runways:
20
note:
paved runways have a concrete or asphalt surface but not all have facilities for refueling, maintenance, or air traffic control; the length of a runway required for aircraft to safely operate depends on a number of factors including the type of aircraft, the takeoff weight (including passengers, cargo, and fuel), engine types, flap settings, landing speed, elevation of the airport, and average maximum daily air temperature; paved runways can reach a length of 5,000 m (16,000 ft.), but the “typical” length of a commercial airline runway is between 2,500-4,000 m (8,000-13,000 ft.)
Airports - with unpaved runways:
21
note:
unpaved runways have a surface composition such as grass or packed earth and are most suited to the operation of light aircraft; unpaved runways are usually short, often less than 1,000 m (3,280 ft.) in length; airports with unpaved runways often lack facilities for refueling, maintenance, or air traffic control
Heliports:
3 (2021)
Pipelines:
5,874 km gas (high-pressure transmission system), 83,732 km gas (low-pressure distribution network), 850 km oil, 1,200 km refined products (2018)
Railways:
total:
7,687 km (2020) 3,111 km electrified
comparison ranking:
total 28
Roadways:
total:
203,601 km (2014)
paved:
77,087 km (2014) (includes 1,582 km of expressways)
unpaved:
126,514 km (2014)
comparison ranking:
total 27
Waterways:
1,622 km (2011) (most on Danube River)
comparison ranking:
49
Merchant marine total:
1 (2022)
by type:
other 1
comparison ranking:
total 186
Ports and terminals:
river port(s):
Baja, Csepel (Budapest), Dunaujvaros, Gyor-Gonyu, Mohacs (Danube)','1bb0efe450f6b278c3a7372c29fe77c22b049656bb5ef23d0576c58cf4fa9a08','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3c6b9fa86801b43377478dd935494d77bb1e7d1b022d652250b0d714814926b6',2025,'IS','Iceland','transportation',9,'National air transport system:
number of registered air carriers:
6 (2020)
inventory of registered aircraft operated by air carriers:
63
annual passenger traffic on registered air carriers:
7,819,740 (2018)
annual freight traffic on registered air carriers:
163.65 million (2018) mt-km
Civil aircraft registration country code prefix:
TF
Airports:
96 (2021)
comparison ranking:
total 60
Airports - with paved runways:
7
note:
paved runways have a concrete or asphalt surface but not all have facilities for refueling, maintenance, or air traffic control; the length of a runway required for aircraft to safely operate depends on a number of factors including the type of aircraft, the takeoff weight (including passengers, cargo, and fuel), engine types, flap settings, landing speed, elevation of the airport, and average maximum daily air temperature; paved runways can reach a length of 5,000 m (16,000 ft.), but the “typical” length of a commercial airline runway is between 2,500-4,000 m (8,000-13,000 ft.)
Airports - with unpaved runways:
89
note:
unpaved runways have a surface composition such as grass or packed earth and are most suited to the operation of light aircraft; unpaved runways are usually short, often less than 1,000 m (3,280 ft.) in length; airports with unpaved runways often lack facilities for refueling, maintenance, or air traffic control
Roadways:
total:
12,898 km (2012)
paved/oiled gravel:
5,647 km (2012) (excludes urban roads)
unpaved:
7,251 km (2012)
comparison ranking:
total 129
Merchant marine:
total:
40 (2022)
by type:
general cargo 5, oil tanker 2, other 33
comparison ranking:
total 125
Ports and terminals:
major seaport(s):
Grundartangi, Hafnarfjordur, Reykjavik','a4c2444509f7c232157087526363f79685cf967488621f479889026e617c0fbb','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c4b175c5f170ab9137c9e0f0d14424096964fbd6076c7b1b55de844eb52b7134',2025,'IN','India','transportation',20,'National air transport system:
number of registered air carriers:
14 (2020)
inventory of registered aircraft operated by air carriers:
485
annual passenger traffic on registered air carriers:
164,035,637 (2018)
annual freight traffic on registered air carriers:
2,703,960,000 (2018) mt-km
Civil aircraft registration country code prefix:
VT
Airports:
346 (2021)
comparison ranking:
total 21
Airports - with paved runways:
253
note:
paved runways have a concrete or asphalt surface but not all have facilities for refueling, maintenance, or air traffic control; the length of a runway required for aircraft to safely operate depends on a number of factors including the type of aircraft, the takeoff weight (including passengers, cargo, and fuel), engine types, flap settings, landing speed, elevation of the airport, and average maximum daily air temperature; paved runways can reach a length of 5,000 m (16,000 ft.), but the “typical” length of a commercial airline runway is between 2,500-4,000 m (8,000-13,000 ft.)
Airports - with unpaved runways:
93
note:
unpaved runways have a surface composition such as grass or packed earth and are most suited to the operation of light aircraft; unpaved runways are usually short, often less than 1,000 m (3,280 ft.) in length; airports with unpaved runways often lack facilities for refueling, maintenance, or air traffic control
Heliports:
45 (2021)
Pipelines:
17,389 km natural gas, 10, 419 km crude oil, 3,544 liquid petroleum gas, 14,729 km refined products (2020) 9 km condensate/gas, 20 km oil/gas/water (2013) (2020)
Railways:
total:
65,554 km (2014)
narrow gauge:
1,604 km (2014) 1.000-m gauge
broad gauge:
63,950 km (2014) (39, 329 km electrified)
comparison ranking:
total 4
Roadways:
total:
6,371,847 km (2021) note: includes 140,995 km of national highways and expressways, 171.039 km of state highways, and 6,059,813 km of other roads
note:
includes 96,214 km of national highways and expressways, 147,800 km of state highways, and 4,455,010 km of other roads
comparison ranking:
total 2
Waterways:
14,500 km (2012) (5,200 km on major rivers and 485 km on canals suitable for mechanized vessels)
comparison ranking:
10
Merchant marine:
total:
1,810 (2022)
by type:
bulk carrier 65, container ship 23, general cargo 594, oil tanker 134, other 994
comparison ranking:
total 15
Ports and terminals:
major seaport(s):
Chennai, Jawaharal Nehru Port, Kandla, Kolkata (Calcutta), Mumbai (Bombay), Sikka, Vishakhapatnam
container port(s) (TEUs):
Jawaharal Nehru Port (5,630,000), Mundra (6,660,000) (2021)
LNG terminal(s) (import):
Dabhol, Dahej, Dhamra, Ennore, Hazira, Kochi, Mundra','4219c1d8e249624597f6ec598c85df1a1ab4cdc47164aa07ac5086f121777383','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('933760a719551779b83fba42351a27e5f9e8fd7fa94bddde882af7bcd0c010f9',2025,'IN','India','transportation',29,'Ports and terminals:
major seaport(s):
Chennai (Madras, India); Colombo (Sri Lanka); Durban (South Africa); Jakarta (Indonesia); Kolkata (Calcutta, India); Melbourne (Australia); Mumbai (Bombay, India); Richards Bay (South Africa)','4be202dba271066c69ef33d4b9b34e498e4deaea5e0745fc03e04e43c23d660b','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d2333b4945cfc16a84db8e0ef42486611e3f2ac5bfc8b469bdfcf1ba03696602',2025,'ID','Indonesia','transportation',40,'National air transport system:
number of registered air carriers:
25 (2020)
inventory of registered aircraft operated by air carriers:
611
annual passenger traffic on registered air carriers:
115,154,100 (2018)
annual freight traffic on registered air carriers:
1,131,910,000 (2018) mt-km
Civil aircraft registration country code prefix:
PK
Airports:
673 (2021)
comparison ranking:
total 10
Airports - with paved runways:
186
note:
paved runways have a concrete or asphalt surface but not all have facilities for refueling, maintenance, or air traffic control; the length of a runway required for aircraft to safely operate depends on a number of factors including the type of aircraft, the takeoff weight (including passengers, cargo, and fuel), engine types, flap settings, landing speed, elevation of the airport, and average maximum daily air temperature; paved runways can reach a length of 5,000 m (16,000 ft.), but the “typical” length of a commercial airline runway is between 2,500-4,000 m (8,000-13,000 ft.)
Airports - with unpaved runways:
487
note:
unpaved runways have a surface composition such as grass or packed earth and are most suited to the operation of light aircraft; unpaved runways are usually short, often less than 1,000 m (3,280 ft.) in length; airports with unpaved runways often lack facilities for refueling, maintenance, or air traffic control
Heliports:
76 (2021)
Pipelines:
1,064 km condensate, 150 km condensate/gas, 11,702 km gas, 119 km liquid petroleum gas, 7,767 km oil, 77 km oil/gas /water, 728 km refined products, 53 km unknown, 44 km water (2013)
Railways:
total:
8,159 km (2014)
narrow gauge:
8,159 km (2014) 1.067-m gauge (565 km electrified)
note:
4,816 km operational
comparison ranking:
total 27
Roadways:
total:
496,607 km (2011)
paved:
283,102 km (2011)
unpaved:
213,505 km (2011)
comparison ranking:
total 15
Waterways:
21,579 km (2011)
comparison ranking:
8
Merchant marine:
total:
11,015 (2022)
by type:
bulk carrier 154, container ship 218, general cargo 2,310, oil tanker 700, other 7,633
comparison ranking:
total 1
Ports and terminals:
major seaport(s):
Banjarmasin, Belawan, Kotabaru, Krueg Geukueh, Palembang, Panjang, Sungai Pakning, Tanjung Perak, Tanjung Priok
container port(s) (TEUs):
Tanjung Perak (3,901,215), Tanjung Priok (6,849,227) (2021)
LNG terminal(s) (export):
Bontang, Tangguh
LNG terminal(s) (import):
Arun, Lampung, West Java','0c055e1945b2cf7580736a6bc15a071d2a3f0526dfd453adf2009af791b8255e','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('81e158d7e2085289fe0896dd58b1e0699e43f443b95da8049542bb75ba7d4717',2025,'ID','Indonesia','transportation',53,'National air transport system:
number of registered air carriers:
22 (2020)
inventory of registered aircraft operated by air carriers:
237
annual passenger traffic on registered air carriers:
25,604,871 (2018)
annual freight traffic on registered air carriers:
290.74 million (2018) mt-km
Civil aircraft registration country code prefix:
EP
Airports:
319 (2021)
comparison ranking:
total 22
Airports - with paved runways:
140
note:
paved runways have a concrete or asphalt surface but not all have facilities for refueling, maintenance, or air traffic control; the length of a runway required for aircraft to safely operate depends on a number of factors including the type of aircraft, the takeoff weight (including passengers, cargo, and fuel), engine types, flap settings, landing speed, elevation of the airport, and average maximum daily air temperature; paved runways can reach a length of 5,000 m (16,000 ft.), but the “typical” length of a commercial airline runway is between 2,500-4,000 m (8,000-13,000 ft.)
Airports - with unpaved runways:
179
note:
unpaved runways have a surface composition such as grass or packed earth and are most suited to the operation of light aircraft; unpaved runways are usually short, often less than 1,000 m (3,280 ft.) in length; airports with unpaved runways often lack facilities for refueling, maintenance, or air traffic control
Heliports:
26 (2021)
Pipelines:
7 km condensate, 973 km condensate/gas, 20,794 km gas, 570 km liquid petroleum gas, 8,625 km oil, 7,937 km refined products (2013)
Railways:
total:
8,483.5 km (2014)
standard gauge:
8,389.5 km (2014) 1.435-m gauge (189.5 km electrified)
broad gauge:
94 km (2014) 1.676-m gauge
comparison ranking:
total 25
Roadways:
total:
223,485 km (2018)
paved:
195,485 km (2018)
unpaved:
28,000 km (2018)
comparison ranking:
total 23
Waterways:
850 km (2012) (on Karun River; some navigation on Lake Urmia)
comparison ranking:
76
Merchant marine:
total:
942 (2022)
by type:
bulk carrier 32, container ship 31, general cargo 393, oil tanker 83, other 403
comparison ranking:
total 25
Ports and terminals:
major seaport(s):
Bandar-e Asaluyeh, Bandar Abbas, Bandar-e Emam Khomeyni
container port(s) (TEUs):
Bandar Abbas','48ef2f64b5d72d4456c76010b9d4c7dd4ca2463dbff22acb1fe45a49097a3514','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6451bf290f3e6bdf012220866c313eb8fa78a62fa3c016cb94229bec1965db3d',2025,'IQ','Iraq','transportation',9,'National air transport system:
number of registered air carriers:
4 (2020)
inventory of registered aircraft operated by air carriers:
34
annual passenger traffic on registered air carriers:
2,075,065 (2018)
annual freight traffic on registered air carriers:
16.2 million (2018) mt-km
Civil aircraft registration country code prefix:
YI
Airports:
102 (2021)
comparison ranking:
total 55
Airports - with paved runways:
72
note:
paved runways have a concrete or asphalt surface but not all have facilities for refueling, maintenance, or air traffic control; the length of a runway required for aircraft to safely operate depends on a number of factors including the type of aircraft, the takeoff weight (including passengers, cargo, and fuel), engine types, flap settings, landing speed, elevation of the airport, and average maximum daily air temperature; paved runways can reach a length of 5,000 m (16,000 ft.), but the “typical” length of a commercial airline runway is between 2,500-4,000 m (8,000-13,000 ft.)
Airports - with unpaved runways:
30
note:
unpaved runways have a surface composition such as grass or packed earth and are most suited to the operation of light aircraft; unpaved runways are usually short, often less than 1,000 m (3,280 ft.) in length; airports with unpaved runways often lack facilities for refueling, maintenance, or air traffic control
Heliports:
16 (2021)
Pipelines:
2,455 km gas, 913 km liquid petroleum gas, 5,432 km oil, 1,637 km refined products (2013)
Railways:
total:
2,272 km (2014)
standard gauge:
2,272 km (2014) 1.435-m gauge
comparison ranking:
total 68
Roadways:
total:
59,623 km (2012)
paved:
59,623 km (2012) (includes Kurdistan region)
comparison ranking:
total 76
Waterways:
5,279 km (2012) (the Euphrates River (2,815 km), Tigris River (1,899 km), and Third River (565 km) are the principal waterways)
comparison ranking:
24
Merchant marine:
total:
75 (2022)
by type:
general cargo 1, oil tanker 7, other 67
comparison ranking:
total 103
Ports and terminals:
river port(s):
Al Basrah (Shatt al Arab); Khawr az Zubayr, Umm Qasr (Khawr az Zubayr waterway)','6153a289f261544bf35c9a546db754486dd54082062a34febad8ea2786cb5efe','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2d9ee29163d79b3567cb0dab3843194a5b3559d2c694284bc81ab15a7fde1500',2025,'IE','Ireland','transportation',22,'National air transport system:
number of registered air carriers:
9 (2020)
inventory of registered aircraft operated by air carriers:
450
annual passenger traffic on registered air carriers:
1.676 million (2018)
annual freight traffic on registered air carriers:
168.71 million (2018) mt-km
Civil aircraft registration country code prefix:
EI
Airports:
40 (2021)
comparison ranking:
total 105
Airports - with paved runways:
16
note:
paved runways have a concrete or asphalt surface but not all have facilities for refueling, maintenance, or air traffic control; the length of a runway required for aircraft to safely operate depends on a number of factors including the type of aircraft, the takeoff weight (including passengers, cargo, and fuel), engine types, flap settings, landing speed, elevation of the airport, and average maximum daily air temperature; paved runways can reach a length of 5,000 m (16,000 ft.), but the “typical” length of a commercial airline runway is between 2,500-4,000 m (8,000-13,000 ft.)
Airports - with unpaved runways:
24
note:
unpaved runways have a surface composition such as grass or packed earth and are most suited to the operation of light aircraft; unpaved runways are usually short, often less than 1,000 m (3,280 ft.) in length; airports with unpaved runways often lack facilities for refueling, maintenance, or air traffic control
Pipelines:
2,427 km gas (2017)
Railways:
total:
1,688 km (2020) 53 km electrified
comparison ranking:
total 78
Roadways:
total:
99,830 km (2018)
paved:
99,830 km (2018) (includes 2,717 km of expressways)
comparison ranking:
total 47
Waterways:
956 km (2010) (pleasure craft only)
comparison ranking:
73
Merchant marine:
total:
96 (2022)
by type:
bulk carrier 12, general cargo 34, oil tanker 1, other 49
comparison ranking:
total 92
Ports and terminals:
major seaport(s):
Dublin, Shannon Foynes
cruise port(s):
Cork (250,000), Dublin (359,966) (2020)
container port(s) (TEUs):
Dublin (529,563) (2016)
river port(s):
Cork (Lee), Waterford (Suir)','39ee59522ff8cd1ccf61cae40d279e4e5fde4f87b6b925f7901f54f4c0ae4ecc','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5c15fdee0918380d870c255f15c278a257afa6123e1760458b20d9af65d17329',2025,'IM','Isle of Man','transportation',34,'Civil aircraft registration country code prefix:
M
Airports:
1 (2021)
comparison ranking:
total 217
Airports - with paved runways:
1
note:
paved runways have a concrete or asphalt surface but not all have facilities for refueling, maintenance, or air traffic control; the length of a runway required for aircraft to safely operate depends on a number of factors including the type of aircraft, the takeoff weight (including passengers, cargo, and fuel), engine types, flap settings, landing speed, elevation of the airport, and average maximum daily air temperature; paved runways can reach a length of 5,000 m (16,000 ft.), but the “typical” length of a commercial airline runway is between 2,500-4,000 m (8,000-13,000 ft.)
Railways:
total:
63 km (2008)
narrow gauge:
6 km (2008) 1.076-m gauge (6 km electrified)
57 0.914-mm gauge (29 km electrified)
note:
primarily summer tourist attractions
comparison ranking:
total 131
Roadways:
total:
1,107 km (2022)
paved:
1,107 km
comparison ranking:
total 183
Ports and terminals:
major seaport(s):
Douglas, Ramsey','ae751b4e57670f9c783584f0acac588989223766200a89d22b0b4a87ba7ad330','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7b9bae671fcfc3fae66542cae46f4596733620b3fa9f3f7a7a77d5472d2d18d5',2025,'IL','Israel','transportation',45,'National air transport system:
number of registered air carriers:
6 (2020)
inventory of registered aircraft operated by air carriers:
64
annual passenger traffic on registered air carriers:
7,404,373 (2018)
annual freight traffic on registered air carriers:
994.54 million (2018) mt-km
Civil aircraft registration country code prefix:
4X
Airports:
42 (2021)
comparison ranking:
total 101
Airports - with paved runways:
33
note:
paved runways have a concrete or asphalt surface but not all have facilities for refueling, maintenance, or air traffic control; the length of a runway required for aircraft to safely operate depends on a number of factors including the type of aircraft, the takeoff weight (including passengers, cargo, and fuel), engine types, flap settings, landing speed, elevation of the airport, and average maximum daily air temperature; paved runways can reach a length of 5,000 m (16,000 ft.), but the “typical” length of a commercial airline runway is between 2,500-4,000 m (8,000-13,000 ft.)
Airports - with unpaved runways:
9
note:
unpaved runways have a surface composition such as grass or packed earth and are most suited to the operation of light aircraft; unpaved runways are usually short, often less than 1,000 m (3,280 ft.) in length; airports with unpaved runways often lack facilities for refueling, maintenance, or air traffic control
Heliports:
3 (2021)
Pipelines:
763 km gas, 442 km oil, 261 km refined products (2013)
Railways:
total:
1,497 km (2021) (2019)
standard gauge:
1,497 km (2021) 1.435-m gauge
comparison ranking:
total 82
Roadways:
total:
20,391 km (2021)
paved:
20,391 km (2021) (includes 449 km of expressways)
comparison ranking:
total 112
Merchant marine:
total:
45 (2022)
by type:
container ship 6, general cargo 2, oil tanker 4, other 33
comparison ranking:
total 123
Ports and terminals:
major seaport(s):
Ashdod, Elat (Eilat), Hadera, Haifa
container port(s) (TEUs):
Ashdod (1,584,000) (2019)
LNG terminal(s) (import):
Hadera','05afc37779e3b806684953ef772dea88556cf0b9180bd668b3c992027c18d39f','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0c830928eb348bcaff8c9574aea2025bdedae4b0bbc208997d61ee61e6ed5b4d',2025,'IT','Italy','transportation',58,'National air transport system:
number of registered air carriers: 9 (2020)
inventory of registered aircraft operated by air carriers:
180
annual passenger traffic on registered air carriers:
27,630,435 (2018)
annual freight traffic on registered air carriers:
1.418 billion (2018) mt-km
Civil aircraft registration country code prefix:
I
Airports:
129 (2021)
comparison ranking:
total 44
Airports - with paved runways:
98
note:
paved runways have a concrete or asphalt surface but not all have facilities for refueling, maintenance, or air traffic control; the length of a runway required for aircraft to safely operate depends on a number of factors including the type of aircraft, the takeoff weight (including passengers, cargo, and fuel), engine types, flap settings, landing speed, elevation of the airport, and average maximum daily air temperature; paved runways can reach a length of 5,000 m (16,000 ft.), but the “typical” length of a commercial airline runway is between 2,500-4,000 m (8,000-13,000 ft.)
Airports - with unpaved runways:
31
note:
unpaved runways have a surface composition such as grass or packed earth and are most suited to the operation of light aircraft; unpaved runways are usually short, often less than 1,000 m (3,280 ft.) in length; airports with unpaved runways often lack facilities for refueling, maintenance, or air traffic control
Heliports:
5 (2021)
Pipelines:
20,223 km gas, 1,393 km oil, 1,574 km refined products (2013)
Railways:
total:
18,475 km (2020) 12,936 km electrified
1289.3 0.950-mm gauge (151.3 km electrified)
comparison ranking:
total 15
Roadways:
total:
487,700 km (2007)
paved:
487,700 km (2007) (includes 6,700 km of expressways)
comparison ranking:
total 16
Waterways:
2,400 km (2012) (used for commercial traffic; of limited overall value compared to road and rail)
comparison ranking:
38
Merchant marine:
total:
1,266 (2022)
by type:
bulk carrier 20, container ship 6, general cargo 107, oil tanker 102, other 1,031
comparison ranking:
total 19
Ports and terminals:
major seaport(s): Augusta, Cagliari, Genoa, Livorno, Taranto, Trieste, Venice
oil terminal(s):
Melilli (Santa Panagia) oil terminal, Sarroch oil terminal
container port(s) (TEUs):
Genoa (2,557,847), Gioia Tauro (3,146,553) (2021)
LNG terminal(s) (import):
Panigaglia (La Spezia), Adriatic (Porto Levante), Oristano (Sardinia), Ravenna, Toscana (Livorno)
Transportation - note:
Italy operates one PC 5 or 6 class light icebreaker, it is based in the Mediterranean
note - PC indicates a Polar Class vessel:
PC 5 - year-round operation in medium first-year ice which may include old ice inclusions (ice thickness up to 70-120 cm); PC 6 - summer/autumn operation in medium first-year ice which may include old ice inclusions (ice thickness up to 30-70 cm)','a44099a718dfadc41d30604d61ab937010f3362d2f4a0192acef42876f7ad7fb','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c6de5685d89646eecf444179e6a2ceb601944c45fb7559dd6f69bfc931a4bbc1',2025,'JM','Jamaica','transportation',9,'National air transport system:
number of registered air carriers:
0 (2020)
Civil aircraft registration country code prefix:
6Y
Airports:
28 (2021)
comparison ranking:
total 121
Airports - with paved runways:
11
note:
paved runways have a concrete or asphalt surface but not all have facilities for refueling, maintenance, or air traffic control; the length of a runway required for aircraft to safely operate depends on a number of factors including the type of aircraft, the takeoff weight (including passengers, cargo, and fuel), engine types, flap settings, landing speed, elevation of the airport, and average maximum daily air temperature; paved runways can reach a length of 5,000 m (16,000 ft.), but the “typical” length of a commercial airline runway is between 2,500-4,000 m (8,000-13,000 ft.)
Airports - with unpaved runways:
17
note:
unpaved runways have a surface composition such as grass or packed earth and are most suited to the operation of light aircraft; unpaved runways are usually short, often less than 1,000 m (3,280 ft.) in length; airports with unpaved runways often lack facilities for refueling, maintenance, or air traffic control
Roadways:
total:
22,121 km (2011) (includes 44 km of expressways)
paved:
16,148 km (2011)
unpaved:
5,973 km (2011)
comparison ranking:
total 109
Merchant marine:
total:
36 (2022)
by type:
bulk carrier 1, general cargo 9, oil tanker 1, other 25
comparison ranking:
total 128
Ports and terminals:
major seaport(s):
Discovery Bay (Port Rhoades), Kingston, Montego Bay, Port Antonio, Port Esquivel, Port Kaiser, Rocky Point
cruise port(s):
Falmouth, Montego Bay, Port Antonio, Ocho Rios,
container port(s) (TEUs):
Kingston (2,004,302) (2021)','f1c645b88a8e120fbf7455ffad9a2833f447d9060bb4456e62d0669816204d00','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('29eb8eadb98ca3db007222f2cda4d761c8d9cf24e85da8dd6a0aaba360d3a8c9',2025,'JM','Jamaica','transportation',18,'Airports:
1 (2021)
comparison ranking:
total 210
Airports - with unpaved runways:
1
note:
unpaved runways have a surface composition such as grass or packed earth and are most suited to the operation of light aircraft; unpaved runways are usually short, often less than 1,000 m (3,280 ft.) in length; airports with unpaved runways often lack facilities for refueling, maintenance, or air traffic control
Ports and terminals:
none; offshore anchorage only','cfed4f801573874926f77c1cd531430612e05d39738a8520e9ef40e7fa0e8738','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fd7db040469a3e98d2e5fc0e5649e77882babec8aa826502fe78c61c56408a1f',2025,'JP','Japan','transportation',29,'National air transport system:
number of registered air carriers:
22 (2020)
inventory of registered aircraft operated by air carriers:
673
annual passenger traffic on registered air carriers:
126,387,527 (2018)
annual freight traffic on registered air carriers:
9,420,660,000 (2018) mt-km
Civil aircraft registration country code prefix:
JA
Airports:
175 (2021)
comparison ranking:
total 32
Airports - with paved runways:
142
note:
paved runways have a concrete or asphalt surface but not all have facilities for refueling, maintenance, or air traffic control; the length of a runway required for aircraft to safely operate depends on a number of factors including the type of aircraft, the takeoff weight (including passengers, cargo, and fuel), engine types, flap settings, landing speed, elevation of the airport, and average maximum daily air temperature; paved runways can reach a length of 5,000 m (16,000 ft.), but the “typical” length of a commercial airline runway is between 2,500-4,000 m (8,000-13,000 ft.)
Airports - with unpaved runways:
33
note:
unpaved runways have a surface composition such as grass or packed earth and are most suited to the operation of light aircraft; unpaved runways are usually short, often less than 1,000 m (3,280 ft.) in length; airports with unpaved runways often lack facilities for refueling, maintenance, or air traffic control
Heliports:
16 (2021)
Pipelines:
4,456 km gas, 174 km oil, 104 km oil/gas/water (2013)
Railways:
total:
27,311 km (2015)
standard gauge:
4,800 km (2015) 1.435-m gauge (4,800 km electrified)
narrow gauge:
124 km (2015) 1.372-m gauge (124 km electrified)
dual gauge:
132 km (2015) 1.435-1.067-m gauge (132 km electrified)
22,207 km 1.067-mm gauge (15,430 km electrified)
48 km 0.762-m gauge (48 km electrified)
comparison ranking:
total 10
Roadways:
total:
1,218,772 km (2015)
paved:
992,835 km (2015) (includes 8,428 km of expressways)
unpaved:
225,937 km (2015)
comparison ranking:
total 6
Waterways:
1,770 km (2010) (seagoing vessels use inland seas)
comparison ranking:
46
Merchant marine:
total:
5,590 (2022)
by type:
bulk carrier 149, container ship 47, general cargo 2,071, oil tanker 690, other 2,633
comparison ranking:
total 4
Ports and terminals:
major seaport(s):
Chiba, Kawasaki, Kobe, Mizushima, Moji, Nagoya, Osaka, Tokyo, Tomakomai, Yokohama
container port(s) (TEUs):
Kobe (2,823,774), Nagoya (2,725,597), Osaka (2,425,638), Tokyo (4,325,956), Yokohama (2,861,197) (2021)
LNG terminal(s) (import):
Chita, Chita Midorihama, Fukuoka, Futtsu, Hachinone, Hakodate, Hatsukaichi, Higashi Ohgishima, Higashi Niigata, Himeiji, Hitachi, Ishikari, Joetsu, Kagoshima, Kawagoe, Hibiki, Mitzushima, Nagasaki, Naoetsu, Negishi, Ohgishima, Oita, Sakai, Sakaide, Senboku, Shin Minato, Shin-Sendai, Sodeshi Shimizu, Sodegaura, Soma, Tobata, Toyama Shinko, Yanai, Yokkaichi, Yoshinoura Okinawa - Nakagusuku
Transportation - note:
Japan operates one PC 3 or 4 class medium icebreaker
note - PC indicates a Polar Class vessel:
PC 3 - year-round operation in second-year ice which may include multi-year ice inclusions (ice thickness up to 2.5 m); PC 4 - year-round operation in thick first-year ice which may include old ice inclusions (ice thickness up to 120 cm)','b5eeb9e594c2df61f6a261572e04aa0ae4d57d10ff284d034605869ba0805095','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('11df7c12fc9c45a28ec4016ec4288c67e5dd0541ecc83bf6e3bc39a8cc3b630d',2025,'JE','Jersey','transportation',41,'National air transport system:
number of registered air carriers:
1 (2020) (registered in UK)
inventory of registered aircraft operated by air carriers:
4 (registered in UK)
Airports:
1 (2021)
comparison ranking:
total 237
Airports - with paved runways:
1
note:
paved runways have a concrete or asphalt surface but not all have facilities for refueling, maintenance, or air traffic control; the length of a runway required for aircraft to safely operate depends on a number of factors including the type of aircraft, the takeoff weight (including passengers, cargo, and fuel), engine types, flap settings, landing speed, elevation of the airport, and average maximum daily air temperature; paved runways can reach a length of 5,000 m (16,000 ft.), but the “typical” length of a commercial airline runway is between 2,500-4,000 m (8,000-13,000 ft.)
Roadways:
total:
576 km (2010)
comparison ranking:
total 193
Ports and terminals:
major seaport(s): Gorey, Saint Aubin, Saint Helier','94597c46ec0c2420d29cef55632eb524a66c76dc929994052f21b2cf89d5f8c9','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e20cd391dc1505a9ccf88cc72e8711434c7de7aa4bf600bf95d936e533f328a7',2025,'JO','Jordan','transportation',52,'National air transport system:
number of registered air carriers:
4 (2020)
inventory of registered aircraft operated by air carriers:
54
annual passenger traffic on registered air carriers:
3,383,805 (2018)
annual freight traffic on registered air carriers:
175.84 million (2018) mt-km
Civil aircraft registration country code prefix:
JY
Airports:
18 (2021)
comparison ranking:
total 138
Airports - with paved runways:
16
note:
paved runways have a concrete or asphalt surface but not all have facilities for refueling, maintenance, or air traffic control; the length of a runway required for aircraft to safely operate depends on a number of factors including the type of aircraft, the takeoff weight (including passengers, cargo, and fuel), engine types, flap settings, landing speed, elevation of the airport, and average maximum daily air temperature; paved runways can reach a length of 5,000 m (16,000 ft.), but the “typical” length of a commercial airline runway is between 2,500-4,000 m (8,000-13,000 ft.)
Airports - with unpaved runways:
2
note:
unpaved runways have a surface composition such as grass or packed earth and are most suited to the operation of light aircraft; unpaved runways are usually short, often less than 1,000 m (3,280 ft.) in length; airports with unpaved runways often lack facilities for refueling, maintenance, or air traffic control
Heliports:
1 (2021)
Pipelines:
473 km gas, 49 km oil (2013)
Railways:
total:
509 km (2020)
narrow gauge:
509 km (2014) 1.050-m gauge
comparison ranking:
total 112
Roadways:
total:
7,203 km (2011)
paved:
7,203 km (2011)
comparison ranking:
total 141
Merchant marine:
total:
35 (2022)
by type:
general cargo 6, other 29
comparison ranking:
total 130
Ports and terminals:
major seaport(s):
Al ’Aqabah','af0377930e9b09887d0fd175fae815efe14702e8cd48c41df149cd7a8ea92d1c','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('af2a441498850867ec2698614b8a592b5049094db3aabb5822acdc66e6b2242f',2025,'KZ','Kazakhstan','transportation',9,'National air transport system:
number of registered air carriers: 12
(2020)
inventory of registered aircraft operated by air carriers:
84
annual passenger traffic on registered air carriers:
7,143,797 (2018)
annual freight traffic on registered air carriers:
50.22 million (2018) mt-km
Civil aircraft registration country code prefix:
UP
Airports:
96 (2021)
comparison ranking:
total 59
Airports - with paved runways:
63
civil airports:
18
military airports:
5
joint use (civil-military) airports:
2
other airports:
38
note:
paved runways have a concrete or asphalt surface but not all have facilities for refueling, maintenance, or air traffic control; the length of a runway required for aircraft to safely operate depends on a number of factors including the type of aircraft, the takeoff weight (including passengers, cargo, and fuel), engine types, flap settings, landing speed, elevation of the airport, and average maximum daily air temperature; paved runways can reach a length of 5,000 m (16,000 ft.), but the “typical” length of a commercial airline runway is between 2,500-4,000 m (8,000-13,000 ft.)
Airports - with unpaved runways:
33
note:
unpaved runways have a surface composition such as grass or packed earth and are most suited to the operation of light aircraft; unpaved runways are usually short, often less than 1,000 m (3,280 ft.) in length; airports with unpaved runways often lack facilities for refueling, maintenance, or air traffic control
Heliports:
3 (2021)
Pipelines:
658 km condensate, 15,429 km gas (2020), 8,020 km oil (2020), 1,095 km refined products, 1,975 km water (2017) (2020)
Railways:
total: 16,636
km (2021)
broad gauge:
16,636 km (2021) 1.520-m gauge (4,237 km electrified)
comparison ranking:
total 17
Roadways:
total: 96,167
km (2021)
paved:
83,813 km (2021)
unpaved:
12,354 km (2021)
comparison ranking:
total 50
Waterways:
43,983 km (2020) (on the Ertis (Irtysh) River (80%) and Syr Darya (Syrdariya) River)
comparison ranking:
4
Merchant marine:
total: 120
(2022)
by type:
general cargo 3, oil tanker 7, other 110
comparison ranking:
total 83
Ports and terminals:
major seaport(s): Caspian
Sea - Aqtau (Shevchenko), Atyrau (Gur’yev)
river port(s):
Oskemen (Ust-Kamenogorsk), Pavlodar, Semey (Semipalatinsk) (Irtysh River)','6fbebb26ada7427f87e0759aa6ffeb0e4b6fd59492c4483d18fe3eeeed14be85','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2782fdc1c44349dd8e384569581b00984e320bdafe5941ca7bfb11415fe48764',2025,'KE','Kenya','transportation',21,'National air transport system:
number of registered air carriers: 25
(2020)
inventory of registered aircraft operated by air carriers:
188
annual passenger traffic on registered air carriers:
5,935,831 (2018)
annual freight traffic on registered air carriers:
294.97 million (2018) mt-km
Civil aircraft registration country code prefix:
5Y
Airports:
197 (2021)
comparison ranking:
total 29
Airports - with paved runways:
16
note:
paved runways have a concrete or asphalt surface but not all have facilities for refueling, maintenance, or air traffic control; the length of a runway required for aircraft to safely operate depends on a number of factors including the type of aircraft, the takeoff weight (including passengers, cargo, and fuel), engine types, flap settings, landing speed, elevation of the airport, and average maximum daily air temperature; paved runways can reach a length of 5,000 m (16,000 ft.), but the “typical” length of a commercial airline runway is between 2,500-4,000 m (8,000-13,000 ft.)
Airports - with unpaved runways:
181
note:
unpaved runways have a surface composition such as grass or packed earth and are most suited to the operation of light aircraft; unpaved runways are usually short, often less than 1,000 m (3,280 ft.) in length; airports with unpaved runways often lack facilities for refueling, maintenance, or air traffic control
Pipelines:
4 km oil, 1,432 km refined products (2018)
Railways:
total: 3,819
km (2018)
standard gauge:
485 km (2018) 1.435-m gauge
narrow gauge:
3,334 km (2018) 1.000-m gauge
comparison ranking:
total 51
Roadways:
total: 161,452
km (2018)
paved:
14,420 km (2017) (8,500 km highways, 1,872 urban roads, and 4,048 rural roads)
unpaved:
147,032 km (2017)
comparison ranking:
total 32
Waterways:
(2011) none specifically; the only significant inland waterway is the part of Lake Victoria within the boundaries of Kenya; Kisumu is the main port and has ferry connections to Uganda and Tanzania
Merchant marine:
total: 25
(2022)
by type:
oil tanker 3, other 22
comparison ranking:
total 140
Ports and terminals:
major seaport(s): Kisumu,
Mombasa
LNG terminal(s) (import):
Mombasa','7ad989d675d1405e1466b5c1d28b899bbeda518b97fe4a57e9561ff3eced0bfd','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('455eb68fdf53c18ef8d1b0b9627fb27397831ad53b253e6729500f07320d63c4',2025,'KI','Kiribati','transportation',34,'National air transport system:
number of registered air carriers: 2
(2020)
inventory of registered aircraft operated by air carriers:
8
annual passenger traffic on registered air carriers:
66,567 (2018)
Civil aircraft registration country code prefix:
T3
Airports:
19 (2021)
comparison ranking:
total 136
Airports - with paved runways:
4
note:
paved runways have a concrete or asphalt surface but not all have facilities for refueling, maintenance, or air traffic control; the length of a runway required for aircraft to safely operate depends on a number of factors including the type of aircraft, the takeoff weight (including passengers, cargo, and fuel), engine types, flap settings, landing speed, elevation of the airport, and average maximum daily air temperature; paved runways can reach a length of 5,000 m (16,000 ft.), but the “typical” length of a commercial airline runway is between 2,500-4,000 m (8,000-13,000 ft.)
Airports - with unpaved runways:
15
note:
unpaved runways have a surface composition such as grass or packed earth and are most suited to the operation of light aircraft; unpaved runways are usually short, often less than 1,000 m (3,280 ft.) in length; airports with unpaved runways often lack facilities for refueling, maintenance, or air traffic control
Roadways:
total: 670
km (2017)
comparison ranking:
total 191
Waterways:
5 km (2012) (small network of canals in Line Islands)
comparison ranking:
118
Merchant marine:
total: 90
(2022)
by type:
bulk carrier 3, general cargo 35, oil tanker 11, other 41
comparison ranking:
total 97
Ports and terminals:
major seaport(s): Betio
(Tarawa Atoll), Canton Island, English Harbor','74a6b66d43f6b288c24584baa36647f28e2a830063736d852419756cbf344424','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3a1d79c0e49fe399c086e95cc7e6db0b96afd920ad97d109082dda5f162a8406',2025,'KI','Kiribati','transportation',45,'National air transport system:
number of registered air carriers: 1
(2020)
inventory of registered aircraft operated by air carriers:
4
annual passenger traffic on registered air carriers:
103,560 (2018)
annual freight traffic on registered air carriers:
250,000 (2018) mt-km
Civil aircraft registration country code prefix:
P
Airports:
82 (2021)
comparison ranking:
total 67
Airports - with paved runways:
39
note:
paved runways have a concrete or asphalt surface but not all have facilities for refueling, maintenance, or air traffic control; the length of a runway required for aircraft to safely operate depends on a number of factors including the type of aircraft, the takeoff weight (including passengers, cargo, and fuel), engine types, flap settings, landing speed, elevation of the airport, and average maximum daily air temperature; paved runways can reach a length of 5,000 m (16,000 ft.), but the “typical” length of a commercial airline runway is between 2,500-4,000 m (8,000-13,000 ft.)
Airports - with unpaved runways:
43
note:
unpaved runways have a surface composition such as grass or packed earth and are most suited to the operation of light aircraft; unpaved runways are usually short, often less than 1,000 m (3,280 ft.) in length; airports with unpaved runways often lack facilities for refueling, maintenance, or air traffic control
Heliports:
23 (2021)
Pipelines:
6 km oil (2013)
Railways:
total: 7,435
km (2014)
standard gauge:
7,435 km (2014) 1.435-m gauge (5,400 km electrified)
note:
figures are approximate; some narrow-gauge railway also exists
comparison ranking:
total 29
Roadways:
total: 25,554
km (2006)
paved:
724 km (2006)
unpaved:
24,830 km (2006)
comparison ranking:
total 103
Waterways:
2,250 km (2011) (most navigable only by small craft)
comparison ranking:
40
Merchant marine:
total: 270
(2022)
by type:
bulk carrier 9, container ship 5, general cargo 193, oil tanker 33, other 30
comparison ranking:
total 59
Ports and terminals:
major seaport(s): Ch’ongjin,
Haeju, Hungnam, Namp’o, Songnim, Sonbong (formerly Unggi), Wonsan','85ea89244fbfff7de021b2bba28741e66bdc4180f036832d551e0aba9cb30589','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('33b868e6e9c94c77e8b18a64446dd8d4b3cc1ff4bfd6fff8186b0f1a340d0f78',2025,'KW','Kuwait','transportation',13,'National air transport system:
number of registered air carriers: 2
(2020)
inventory of registered aircraft operated by air carriers:
44
annual passenger traffic on registered air carriers:
6,464,847 (2018)
annual freight traffic on registered air carriers:
392.36 million (2018) mt-km
Civil aircraft registration country code prefix:
9K
Airports:
7 (2021)
comparison ranking:
total 169
Airports - with paved runways:
4
note:
paved runways have a concrete or asphalt surface but not all have facilities for refueling, maintenance, or air traffic control; the length of a runway required for aircraft to safely operate depends on a number of factors including the type of aircraft, the takeoff weight (including passengers, cargo, and fuel), engine types, flap settings, landing speed, elevation of the airport, and average maximum daily air temperature; paved runways can reach a length of 5,000 m (16,000 ft.), but the “typical” length of a commercial airline runway is between 2,500-4,000 m (8,000-13,000 ft.)
Airports - with unpaved runways:
3
note:
unpaved runways have a surface composition such as grass or packed earth and are most suited to the operation of light aircraft; unpaved runways are usually short, often less than 1,000 m (3,280 ft.) in length; airports with unpaved runways often lack facilities for refueling, maintenance, or air traffic control
Heliports:
4 (2021)
Pipelines:
261 km gas, 540 km oil, 57 km refined products (2013)
Roadways:
total: 5,749
km (2018)
paved:
4,887 km (2018)
unpaved:
862 km (2018)
comparison ranking:
total 145
Merchant marine:
total: 166
(2022)
by type:
general cargo 15, oil tanker 29, other 122
comparison ranking:
total 71
Ports and terminals:
major seaport(s): Ash
Shu’aybah, Ash Shuwaykh, Az Zawr (Mina’ Sa’ud), Mina’ ‘Abd Allah, Mina’ al Ahmadi','41072de8d6ae068dac935c9df554b8bbaaf390d74248a7480f0c8c3f00a4c5a5','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('99e5c1312e74c721fc03c517b935b93d9a7590af7de39814f709977e1bc301d4',2025,'KG','Kyrgyzstan','transportation',24,'National air transport system:
number of registered air carriers: 5
(2020)
inventory of registered aircraft operated by air carriers:
17
annual passenger traffic on registered air carriers:
709,198 (2018)
Civil aircraft registration country code prefix:
EX
Airports:
28 (2021)
comparison ranking:
total 120
Airports - with paved runways:
18
note:
paved runways have a concrete or asphalt surface but not all have facilities for refueling, maintenance, or air traffic control; the length of a runway required for aircraft to safely operate depends on a number of factors including the type of aircraft, the takeoff weight (including passengers, cargo, and fuel), engine types, flap settings, landing speed, elevation of the airport, and average maximum daily air temperature; paved runways can reach a length of 5,000 m (16,000 ft.), but the “typical” length of a commercial airline runway is between 2,500-4,000 m (8,000-13,000 ft.)
Airports - with unpaved runways:
10
note:
unpaved runways have a surface composition such as grass or packed earth and are most suited to the operation of light aircraft; unpaved runways are usually short, often less than 1,000 m (3,280 ft.) in length; airports with unpaved runways often lack facilities for refueling, maintenance, or air traffic control
Pipelines:
4,195 km gas (2022), 16 km oil (2022) (2022)
Railways:
total: 424
km (2022)
broad gauge:
424 km (2018) 1.520-m gauge
comparison ranking:
total 118
Roadways:
total: 34,000
km (2022)
comparison ranking:
total 93
Waterways:
576 km (2022)
comparison ranking:
89
Ports and terminals:
lake port(s): Balykchy
(Ysyk-Kol or Rybach’ye)(Lake Ysyk-Kol)','7205f3201c62bf1100ef680f2afbbe224dff80788333dfeefd3683cd53cb6e51','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e84c71bf8cc0cf0f20abc825be023426dad379bfc75a82b8acc56096923d3fe9',2025,'LV','Latvia','transportation',11,'National air transport system:
number of registered air carriers:
3 (2020)
inventory of registered aircraft operated by air carriers:
53
annual passenger traffic on registered air carriers:
4,058,762 (2018)
annual freight traffic on registered air carriers:
4.01 million (2018) mt-km
Civil aircraft registration country code prefix:
YL
Airports:
42 (2021)
comparison ranking:
total 100
Airports - with paved runways:
18
note:
paved runways have a concrete or asphalt surface but not all have facilities for refueling, maintenance, or air traffic control; the length of a runway required for aircraft to safely operate depends on a number of factors including the type of aircraft, the takeoff weight (including passengers, cargo, and fuel), engine types, flap settings, landing speed, elevation of the airport, and average maximum daily air temperature; paved runways can reach a length of 5,000 m (16,000 ft.), but the “typical” length of a commercial airline runway is between 2,500-4,000 m (8,000-13,000 ft.)
Airports - with unpaved runways:
24
note:
unpaved runways have a surface composition such as grass or packed earth and are most suited to the operation of light aircraft; unpaved runways are usually short, often less than 1,000 m (3,280 ft.) in length; airports with unpaved runways often lack facilities for refueling, maintenance, or air traffic control
Heliports:
1 (2021)
Pipelines:
1,213 km gas, 417 km refined products (2018)
Railways:
total:
2,216 km (2020) 257 km electrified
comparison ranking:
total 69
Roadways:
total:
70,244 km (2018)
paved:
15,158 km (2018)
unpaved:
55,086 km (2018)
comparison ranking:
total 68
Waterways:
300 km (2010) (navigable year-round)
comparison ranking:
101
Merchant marine:
total:
80 (2022)
by type:
container ship 2, general cargo 30, oil tanker 9, other 39
comparison ranking:
total 100
Ports and terminals:
major seaport(s):
Riga, Ventspils
Transportation - note:
Latvia operates one PC 5 or 6 class icebreaker in the Baltic Sea
note – PC indicates a Polar Class vessel:
PC 5 - year-round operation in medium first-year ice which may include old ice inclusions (ice thickness up to 70-120 cm); PC 6 - summer/autumn operation in medium first-year ice which may include old ice inclusions (ice thickness up to 30-70 cm)','f1a5c138de87ce0183fb7b59e0b2dccbaf68697ef6593c73f72b4a640ede5161','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0ac968cc06cdc2181e2e849b1db55d4ddfd4ff76fb9187e2183ab5297f5e2526',2025,'LB','Lebanon','transportation',22,'National air transport system:
number of registered air carriers:
1 (2020)
inventory of registered aircraft operated by air carriers:
21
annual passenger traffic on registered air carriers:
2,981,937 (2018)
annual freight traffic on registered air carriers:
56.57 million (2018) mt-km
Civil aircraft registration country code prefix:
OD
Airports:
8 (2021)
comparison ranking:
total 160
Airports - with paved runways:
5
note:
paved runways have a concrete or asphalt surface but not all have facilities for refueling, maintenance, or air traffic control; the length of a runway required for aircraft to safely operate depends on a number of factors including the type of aircraft, the takeoff weight (including passengers, cargo, and fuel), engine types, flap settings, landing speed, elevation of the airport, and average maximum daily air temperature; paved runways can reach a length of 5,000 m (16,000 ft.), but the “typical” length of a commercial airline runway is between 2,500-4,000 m (8,000-13,000 ft.)
Airports - with unpaved runways:
3
note:
unpaved runways have a surface composition such as grass or packed earth and are most suited to the operation of light aircraft; unpaved runways are usually short, often less than 1,000 m (3,280 ft.) in length; airports with unpaved runways often lack facilities for refueling, maintenance, or air traffic control
Heliports:
1 (2021)
Pipelines:
88 km gas (2013)
Railways:
total:
401 km (2017)
standard gauge:
319 km (2017) 1.435-m gauge
narrow gauge:
82 km (2017) 1.050-m gauge
note:
rail system is still unusable due to damage sustained from fighting in the 1980s and in 2006
comparison ranking:
total 121
Roadways:
total:
21,705 km (2017)
comparison ranking:
total 110
Merchant marine:
total:
49 (2022)
by type:
bulk carrier 2, general cargo 32, oil tanker 1, other 14
comparison ranking:
total 119
Ports and terminals:
major seaport(s):
Beirut, Tripoli
container port(s) (TEUs):
Beirut (1,229,100) (2019)','eb4a26ab854d333794f92002fd9a1120499526d7f3c6181559cab68df6046c0c','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('717e53677ea32b0c60318cfb716d3c96464925baca9f1ef7156226393cbd5866',2025,'LS','Lesotho','transportation',34,'Civil aircraft registration country code prefix:
7P
Airports:
24 (2021)
comparison ranking:
total 131
Airports - with paved runways:
3
note:
paved runways have a concrete or asphalt surface but not all have facilities for refueling, maintenance, or air traffic control; the length of a runway required for aircraft to safely operate depends on a number of factors including the type of aircraft, the takeoff weight (including passengers, cargo, and fuel), engine types, flap settings, landing speed, elevation of the airport, and average maximum daily air temperature; paved runways can reach a length of 5,000 m (16,000 ft.), but the “typical” length of a commercial airline runway is between 2,500-4,000 m (8,000-13,000 ft.)
Airports - with unpaved runways:
21
note:
unpaved runways have a surface composition such as grass or packed earth and are most suited to the operation of light aircraft; unpaved runways are usually short, often less than 1,000 m (3,280 ft.) in length; airports with unpaved runways often lack facilities for refueling, maintenance, or air traffic control
Roadways:
total:
5,940 km (2011)
paved:
1,069 km (2011)
unpaved:
4,871 km (2011)
comparison ranking:
total 144','806030989f6df366a0577581579f0b5507dd2ebc1a65776842bb633258cf0b24','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a0c56a4573cf0a44c028dd6f9c2c1ee0e568f923d5f876414a497bcdf66da646',2025,'LR','Liberia','transportation',45,'Civil aircraft registration country code prefix:
A8
Airports:
29 (2021)
comparison ranking:
total 116
Airports - with paved runways:
2
note:
paved runways have a concrete or asphalt surface but not all have facilities for refueling, maintenance, or air traffic control; the length of a runway required for aircraft to safely operate depends on a number of factors including the type of aircraft, the takeoff weight (including passengers, cargo, and fuel), engine types, flap settings, landing speed, elevation of the airport, and average maximum daily air temperature; paved runways can reach a length of 5,000 m (16,000 ft.), but the “typical” length of a commercial airline runway is between 2,500-4,000 m (8,000-13,000 ft.)
Airports - with unpaved runways:
27
note:
unpaved runways have a surface composition such as grass or packed earth and are most suited to the operation of light aircraft; unpaved runways are usually short, often less than 1,000 m (3,280 ft.) in length; airports with unpaved runways often lack facilities for refueling, maintenance, or air traffic control
Pipelines:
4 km oil (2013)
Railways:
total:
429 km (2008)
standard gauge:
345 km (2008) 1.435-m gauge
narrow gauge:
84 km (2008) 1.067-m gauge
note:
most sections of the railways inoperable due to damage sustained during the civil wars from 1980 to 2003, but many are being rebuilt
comparison ranking:
total 117
Roadways:
total:
10,600 km (2018)
paved:
657 km (2018)
unpaved:
9,943 km (2018)
comparison ranking:
total 134
Merchant marine:
total:
4,311 (2022)
by type:
bulk carrier 1,673, container ship 962, general cargo 141, oil tanker 907, other 628
comparison ranking:
total 5
Ports and terminals:
major seaport(s):
Buchanan, Monrovia','fe128b61e367635b28bd88dcf32505f1c78d1ee713ef7b4cd6e2aea351b0847d','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8d72d9143ae6f9577a88eb662bbc0ad58db95675a6d42e3886d1baa5e2faa68c',2025,'LY','Libya','transportation',9,'National air transport system:
number of registered air carriers:
9 (2020)
inventory of registered aircraft operated by air carriers:
55
annual passenger traffic on registered air carriers:
927,153 (2018)
Civil aircraft registration country code prefix:
5A
Airports:
146 (2021)
comparison ranking:
total 39
Airports - with paved runways:
68
note:
paved runways have a concrete or asphalt surface but not all have facilities for refueling, maintenance, or air traffic control; the length of a runway required for aircraft to safely operate depends on a number of factors including the type of aircraft, the takeoff weight (including passengers, cargo, and fuel), engine types, flap settings, landing speed, elevation of the airport, and average maximum daily air temperature; paved runways can reach a length of 5,000 m (16,000 ft.), but the “typical” length of a commercial airline runway is between 2,500-4,000 m (8,000-13,000 ft.)
Airports - with unpaved runways:
78
note:
unpaved runways have a surface composition such as grass or packed earth and are most suited to the operation of light aircraft; unpaved runways are usually short, often less than 1,000 m (3,280 ft.) in length; airports with unpaved runways often lack facilities for refueling, maintenance, or air traffic control
Heliports:
2 (2021)
Pipelines:
882 km condensate, 3,743 km gas, 7,005 km oil (2013)
Roadways:
total:
37,000 km (2010)
paved:
34,000 km (2010)
unpaved:
3,000 km (2010)
comparison ranking:
total 91
Merchant marine:
total:
94 (2022)
by type:
general cargo 2, oil tanker 12, other 80
comparison ranking:
total 93
Ports and terminals:
major seaport(s):
Marsa al Burayqah (Marsa el Brega), Tripoli
oil terminal(s):
Az Zawiyah, Ra’s Lanuf
LNG terminal(s) (export):
Marsa el Brega','fc06929bb2dcbed2b02caa799aca8ff31f7aab4ff89536a8571fab25e8480040','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f046a164539df26bd2a2a4fa0292fc050eaa7e523955ac21cfbbe8087a6d0712',2025,'LI','Liechtenstein','transportation',21,'Civil aircraft registration country code prefix:
HB
Pipelines:
434.5 km gas (2018)
Railways:
total:
9 km (2018)
standard gauge:
9 km (2018) 1.435-m gauge (electrified)
note:
belongs to the Austrian Railway System connecting Austria and Switzerland
comparison ranking:
total 137
Roadways:
total:
630 km (2019)
paved:
(2019)
comparison ranking:
total 192
Waterways:
28 km (2010)
comparison ranking:
116
Merchant marine:
total:
20 (2022)
by type:
bulk carrier 16, general cargo 1, other 3 (includes Switzerland)
comparison ranking:
total 148','8dfeda6d564c9f66dc7ff878b5fd4bae36e1cc9cdc2d73a6a467aa116ca6526a','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4da0e21fb5f5be10330fb961607aa7a700b2a1c1252f2d5a14928cc9b856142d',2025,'LT','Lithuania','transportation',32,'National air transport system:
number of registered air carriers:
3 (2020)
inventory of registered aircraft operated by air carriers:
50
annual passenger traffic on registered air carriers:
26,031 (2018)
Civil aircraft registration country code prefix:
LY
Airports:
61 (2021)
comparison ranking:
total 80
Airports - with paved runways:
22
note:
paved runways have a concrete or asphalt surface but not all have facilities for refueling, maintenance, or air traffic control; the length of a runway required for aircraft to safely operate depends on a number of factors including the type of aircraft, the takeoff weight (including passengers, cargo, and fuel), engine types, flap settings, landing speed, elevation of the airport, and average maximum daily air temperature; paved runways can reach a length of 5,000 m (16,000 ft.), but the “typical” length of a commercial airline runway is between 2,500-4,000 m (8,000-13,000 ft.)
Airports - with unpaved runways:
39
note:
unpaved runways have a surface composition such as grass or packed earth and are most suited to the operation of light aircraft; unpaved runways are usually short, often less than 1,000 m (3,280 ft.) in length; airports with unpaved runways often lack facilities for refueling, maintenance, or air traffic control
Pipelines:
1,921 km gas, 121 km refined products (2013)
Railways:
total:
1,911 km (2020) 152 km electrified
comparison ranking:
total 74
Roadways:
total:
84,166 km (2012)
paved:
72,297 km (2012) (includes 312 km of expressways)
unpaved:
11,869 km (2012)
comparison ranking:
total 58
Waterways:
441 km (2007) (navigable year-round)
comparison ranking:
94
Merchant marine:
total:
62 (2022)
by type:
container ship 4, general cargo 22, oil tanker 2, other 34
comparison ranking:
total 112
Ports and terminals:
major seaport(s):
Klaipeda
oil terminal(s):
Butinge oil terminal
LNG terminal(s) (import):
Klaipeda','3453e3788097548f9665abef3afb1f691846186acd9cb712e7664c989df315d2','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('21ed1301975a25d2d2eb18e964123cd776e88d5b16e3566aea66efea5cb2407e',2025,'LU','Luxembourg','transportation',44,'National air transport system:
number of registered air carriers:
4 (2020)
inventory of registered aircraft operated by air carriers:
66
annual passenger traffic on registered air carriers:
2,099,102 (2018)
annual freight traffic on registered air carriers:
7,323,040,000 (2018) mt-km
Civil aircraft registration country code prefix:
LX
Airports:
2 (2021)
comparison ranking:
total 206
Airports - with paved runways:
1
note:
paved runways have a concrete or asphalt surface but not all have facilities for refueling, maintenance, or air traffic control; the length of a runway required for aircraft to safely operate depends on a number of factors including the type of aircraft, the takeoff weight (including passengers, cargo, and fuel), engine types, flap settings, landing speed, elevation of the airport, and average maximum daily air temperature; paved runways can reach a length of 5,000 m (16,000 ft.), but the “typical” length of a commercial airline runway is between 2,500-4,000 m (8,000-13,000 ft.)
Airports - with unpaved runways:
1
note:
unpaved runways have a surface composition such as grass or packed earth and are most suited to the operation of light aircraft; unpaved runways are usually short, often less than 1,000 m (3,280 ft.) in length; airports with unpaved runways often lack facilities for refueling, maintenance, or air traffic control
Heliports:
1 (2021)
Pipelines:
142 km gas, 27 km refined products (2013)
Railways:
total:
271 km (2020) 262 km electrified
comparison ranking:
total 125
Roadways:
total:
2,875 km (2019)
paved:
(2011)
comparison ranking:
total 166
Waterways:
37 km (2010) (on Moselle River)
comparison ranking:
115
Merchant marine:
total:
149 (2022)
by type:
bulk carrier 4, container ship 1, general cargo 27, oil tanker 3, other 114
comparison ranking:
total 74
Ports and terminals:
river port(s):
Mertert (Moselle)','da13c5f43142107ecdb711ad3193aa199a0809a7dc362166f83c26418b413900','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('31b529dbb922f010284645af812d69d1a76c2b39c85bc1a586536a45c6249dd7',2025,'MG','Madagascar','transportation',11,'National air transport system:
number of registered air carriers:
4 (2020)
inventory of registered aircraft operated by air carriers:
18
annual passenger traffic on registered air carriers:
541,290 (2018)
annual freight traffic on registered air carriers:
16.25 million (2018) mt-km
Civil aircraft registration country code prefix:
5R
Airports:
83 (2021)
comparison ranking:
total 66
Airports - with paved runways:
26
note:
paved runways have a concrete or asphalt surface but not all have facilities for refueling, maintenance, or air traffic control; the length of a runway required for aircraft to safely operate depends on a number of factors including the type of aircraft, the takeoff weight (including passengers, cargo, and fuel), engine types, flap settings, landing speed, elevation of the airport, and average maximum daily air temperature; paved runways can reach a length of 5,000 m (16,000 ft.), but the “typical” length of a commercial airline runway is between 2,500-4,000 m (8,000-13,000 ft.)
Airports - with unpaved runways:
57
note:
unpaved runways have a surface composition such as grass or packed earth and are most suited to the operation of light aircraft; unpaved runways are usually short, often less than 1,000 m (3,280 ft.) in length; airports with unpaved runways often lack facilities for refueling, maintenance, or air traffic control
Railways:
total:
836 km (2018)
narrow gauge:
836 km (2018) 1.000-m gauge
comparison ranking:
total 95
Roadways:
total:
31,640 km (2018)
comparison ranking:
total 95
Waterways:
600 km (2011) (432 km navigable)
comparison ranking:
86
Merchant marine:
total:
28 (2022)
by type:
general cargo 15, oil tanker 2, other 11
comparison ranking:
total 137
Ports and terminals:
major seaport(s):
Antsiranana (Diego Suarez), Mahajanga, Toamasina, Toliara (Tulear)','53783bdcc236bc5348de99a414554a39c530c80cd7dca67470eab275130824d5','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a6eb045e859434223d3ab9dc8004aca9291787ea8abaa66d3b67450f1ac56fa1',2025,'MW','Malawi','transportation',22,'National air transport system:
number of registered air carriers:
2 (2020)
inventory of registered aircraft operated by air carriers:
9
annual passenger traffic on registered air carriers:
10,545 (2018)
annual freight traffic on registered air carriers:
10,000 (2018) mt-km
Civil aircraft registration country code prefix:
7Q
Airports:
32 (2021)
comparison ranking:
total 112
Airports - with paved runways:
7
note:
paved runways have a concrete or asphalt surface but not all have facilities for refueling, maintenance, or air traffic control; the length of a runway required for aircraft to safely operate depends on a number of factors including the type of aircraft, the takeoff weight (including passengers, cargo, and fuel), engine types, flap settings, landing speed, elevation of the airport, and average maximum daily air temperature; paved runways can reach a length of 5,000 m (16,000 ft.), but the “typical” length of a commercial airline runway is between 2,500-4,000 m (8,000-13,000 ft.)
Airports - with unpaved runways:
25
note:
unpaved runways have a surface composition such as grass or packed earth and are most suited to the operation of light aircraft; unpaved runways are usually short, often less than 1,000 m (3,280 ft.) in length; airports with unpaved runways often lack facilities for refueling, maintenance, or air traffic control
Railways:
total:
767 km (2014)
narrow gauge:
767 km (2014) 1.067-m gauge
comparison ranking:
total 97
Roadways:
total:
15,452 km (2015)
paved:
4,074 km (2015)
unpaved:
11,378 km (2015)
comparison ranking:
total 122
Waterways:
700 km (2010) (on Lake Nyasa [Lake Malawi] and Shire River)
comparison ranking:
82
Ports and terminals:
lake port(s):
Chipoka, Monkey Bay, Nkhata Bay, Nkhotakota, Chilumba (Lake Nyasa)','32c8214a2fadbc880f19bca03c541309560f77fb82b13f7d7cc7c19c1484ea49','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b469adebc8e3bc0a07e92df83c787f2defa2ce308339abd8df81e745376249f0',2025,'MY','Malaysia','transportation',33,'National air transport system:
number of registered air carriers:
13 (2020)
inventory of registered aircraft operated by air carriers:
270
annual passenger traffic on registered air carriers:
60,481,772 (2018)
annual freight traffic on registered air carriers:
1,404,410,000 (2018) mt-km
Civil aircraft registration country code prefix:
9M
Airports:
114 (2021)
comparison ranking:
total 50
Airports - with paved runways:
39
note:
paved runways have a concrete or asphalt surface but not all have facilities for refueling, maintenance, or air traffic control; the length of a runway required for aircraft to safely operate depends on a number of factors including the type of aircraft, the takeoff weight (including passengers, cargo, and fuel), engine types, flap settings, landing speed, elevation of the airport, and average maximum daily air temperature; paved runways can reach a length of 5,000 m (16,000 ft.), but the “typical” length of a commercial airline runway is between 2,500-4,000 m (8,000-13,000 ft.)
Airports - with unpaved runways:
75
note:
unpaved runways have a surface composition such as grass or packed earth and are most suited to the operation of light aircraft; unpaved runways are usually short, often less than 1,000 m (3,280 ft.) in length; airports with unpaved runways often lack facilities for refueling, maintenance, or air traffic control
Heliports:
4 (2021)
Pipelines:
354 km condensate, 6,439 km gas, 155 km liquid petroleum gas, 1,937 km oil, 43 km oil/gas/water, 114 km refined products, 26 km water (2013)
Railways:
total:
1,851 km (2014)
standard gauge:
59 km (2014) 1.435-m gauge (59 km electrified)
narrow gauge:
1,792 km (2014) 1.000-m gauge (339 km electrified)
comparison ranking:
total 76
Roadways:
total:
144,403 km (2010) (excludes local roads)
paved:
116,169 km (2010) (includes 1,821 km of expressways)
unpaved:
28,234 km (2010)
comparison ranking:
total 36
Waterways:
7,200 km (2011) (Peninsular Malaysia 3,200 km; Sabah 1,500 km; Sarawak 2,500 km)
comparison ranking:
21
Merchant marine:
total:
1,790 (2022)
by type:
bulk carrier 14, container ship 33, general cargo 181, oil tanker 156, other 1,406
comparison ranking:
total 16
Ports and terminals:
major seaport(s):
Bintulu, Johor Bahru, George Town (Penang), Pelabuhan Klang (Port Klang), Tanjung Pelepas
container port(s) (TEUs):
Port Kelang (Port Klang) (13,724,460), Tanjung Pelepas (11,200,000) (2021)
LNG terminal(s) (export):
Bintulu (Sarawak)
LNG terminal(s) (import):
Sungei Udang','98bc2715e8bade09fff40df2d3f42b2554ed20cf29c972885a282361616caebf','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('be3168cba5a994170bfc19fb25e5b5cee90dc34e286f5440b77b250936119646',2025,'MV','Maldives','transportation',46,'National air transport system:
number of registered air carriers:
3 (2020)
inventory of registered aircraft operated by air carriers:
36
annual passenger traffic on registered air carriers:
1,147,247 (2018)
annual freight traffic on registered air carriers:
7.75 million (2018)
Civil aircraft registration country code prefix:
8Q
Airports:
9 (2021)
comparison ranking:
total 157
Airports - with paved runways:
7
note:
paved runways have a concrete or asphalt surface but not all have facilities for refueling, maintenance, or air traffic control; the length of a runway required for aircraft to safely operate depends on a number of factors including the type of aircraft, the takeoff weight (including passengers, cargo, and fuel), engine types, flap settings, landing speed, elevation of the airport, and average maximum daily air temperature; paved runways can reach a length of 5,000 m (16,000 ft.), but the “typical” length of a commercial airline runway is between 2,500-4,000 m (8,000-13,000 ft.)
Airports - with unpaved runways:
2
note:
unpaved runways have a surface composition such as grass or packed earth and are most suited to the operation of light aircraft; unpaved runways are usually short, often less than 1,000 m (3,280 ft.) in length; airports with unpaved runways often lack facilities for refueling, maintenance, or air traffic control
Roadways:
total:
93 km (2018)
paved:
93 km (2018) - 60 km in Malée; 16 km on Addu Atolis; 17 km on Laamu
note:
island roads are mainly compacted coral
comparison ranking:
total 214
Merchant marine:
total:
80 (2022)
by type:
general cargo 30, oil tanker 20, other 30
comparison ranking:
total 102
Ports and terminals:
major seaport(s):
Male','6d7a5db8820a06226db667473727cf4b5dc95281fdb2d10eaeab7c29fd191d04','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ae1bda40beebd755d4b15067ea1e7609ef855f0110b378781545c7b4e0c12cfb',2025,'ML','Mali','transportation',9,'National air transport system:
number of registered air carriers:
0 (2020)
Civil aircraft registration country code prefix:
TZ, TT
Airports:
25 (2021)
comparison ranking:
total 127
Airports - with paved runways:
8
note:
paved runways have a concrete or asphalt surface but not all have facilities for refueling, maintenance, or air traffic control; the length of a runway required for aircraft to safely operate depends on a number of factors including the type of aircraft, the takeoff weight (including passengers, cargo, and fuel), engine types, flap settings, landing speed, elevation of the airport, and average maximum daily air temperature; paved runways can reach a length of 5,000 m (16,000 ft.), but the “typical” length of a commercial airline runway is between 2,500-4,000 m (8,000-13,000 ft.)
Airports - with unpaved runways:
17
note:
unpaved runways have a surface composition such as grass or packed earth and are most suited to the operation of light aircraft; unpaved runways are usually short, often less than 1,000 m (3,280 ft.) in length; airports with unpaved runways often lack facilities for refueling, maintenance, or air traffic control
Heliports:
2 (2021)
Railways:
total:
593 km (2014)
narrow gauge:
593 km (2014) 1.000-m gauge
comparison ranking:
total 109
Roadways:
total:
139,107 km (2018)
paved:
(2009)
unpaved:
(2009)
comparison ranking:
total 38
Waterways:
1,800 km (2011) (downstream of Koulikoro; low water levels on the River Niger cause problems in dry years; in the months before the rainy season the river is not navigable by commercial vessels)
comparison ranking:
45
Ports and terminals:
river port(s):
Koulikoro (Niger)','64ca3e4561660b8c58e24c935fc0c93e5acd85ebc1f3d5eb62f2e8abb1f15b8a','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('612019fab5e52ab4baf89cd7d7bb0c8f49bf9dd61114bb2db89b455bc971fe04',2025,'MT','Malta','transportation',21,'National air transport system:
number of registered air carriers:
13 (2020)
inventory of registered aircraft operated by air carriers:
180
annual passenger traffic on registered air carriers:
2,576,898 (2018)
annual freight traffic on registered air carriers:
5.14 million (2018) mt-km
Civil aircraft registration country code prefix:
9H
Airports:
1 (2021)
comparison ranking:
total 221
Airports - with paved runways:
1
note:
paved runways have a concrete or asphalt surface but not all have facilities for refueling, maintenance, or air traffic control; the length of a runway required for aircraft to safely operate depends on a number of factors including the type of aircraft, the takeoff weight (including passengers, cargo, and fuel), engine types, flap settings, landing speed, elevation of the airport, and average maximum daily air temperature; paved runways can reach a length of 5,000 m (16,000 ft.), but the “typical” length of a commercial airline runway is between 2,500-4,000 m (8,000-13,000 ft.)
Heliports:
2 (2021)
Roadways:
total:
3,096 km (2008)
paved:
2,704 km (2008)
unpaved:
392 km (2008)
urban:
1,422 km (2001)
non-
urban:
832 km (2001)
comparison ranking:
total 161
Merchant marine:
total:
2,047 (2022)
by type:
bulk carrier 545, container ship 312, general cargo 182, oil tanker 395, other 613
comparison ranking:
total 11
Ports and terminals:
major seaport(s):
Marsaxlokk (Malta Freeport), Valletta
container port(s) (TEUs):
Marsaxlokk (2,967,765) (2021)
LNG terminal(s) (import):
Delimara','194d0732562153785cfd98b9bc09b250ce129f8210e661197e2b77d60f4d6aa2','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('99173727eb412b29542b619dee667d981dc39b9497cc0f0842ca024aa6ff6256',2025,'MH','Marshall Islands','transportation',33,'National air transport system:
number of registered air carriers:
1 (2020)
inventory of registered aircraft operated by air carriers:
3
annual passenger traffic on registered air carriers:
24,313 (2018)
annual freight traffic on registered air carriers:
130,000 (2018) mt-km
Civil aircraft registration country code prefix:
V7
Airports:
15 (2021)
comparison ranking:
total 147
Airports - with paved runways:
4
note:
paved runways have a concrete or asphalt surface but not all have facilities for refueling, maintenance, or air traffic control; the length of a runway required for aircraft to safely operate depends on a number of factors including the type of aircraft, the takeoff weight (including passengers, cargo, and fuel), engine types, flap settings, landing speed, elevation of the airport, and average maximum daily air temperature; paved runways can reach a length of 5,000 m (16,000 ft.), but the “typical” length of a commercial airline runway is between 2,500-4,000 m (8,000-13,000 ft.)
Airports - with unpaved runways:
11
note:
unpaved runways have a surface composition such as grass or packed earth and are most suited to the operation of light aircraft; unpaved runways are usually short, often less than 1,000 m (3,280 ft.) in length; airports with unpaved runways often lack facilities for refueling, maintenance, or air traffic control
Roadways:
total:
2,028 km (2007)
paved:
75 km (2007)
unpaved:
1,953 km
comparison ranking:
total 171
Merchant marine:
total:
4,042 (2022)
by type:
bulk carrier 1,879 container ship 276, general cargo 62, oil tanker 1023, other 802
comparison ranking:
total 6
Ports and terminals:
major seaport(s):
Enitwetak Island, Kwajalein, Majuro','6781a8960a3bba36bbcae23dd2fb1d507ec1c26c0615ad5a25001f315a792d63','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5936e451a6cfe8442e5fa54239a1dec035e591c37c1c6c2a0343e1b4a834ad72',2025,'MR','Mauritania','transportation',44,'National air transport system:
number of registered air carriers:
1 (2020)
inventory of registered aircraft operated by air carriers:
6
annual passenger traffic on registered air carriers:
454,435 (2018)
Civil aircraft registration country code prefix:
5T
Airports:
30 (2021)
comparison ranking:
total 115
Airports - with paved runways:
9
note:
paved runways have a concrete or asphalt surface but not all have facilities for refueling, maintenance, or air traffic control; the length of a runway required for aircraft to safely operate depends on a number of factors including the type of aircraft, the takeoff weight (including passengers, cargo, and fuel), engine types, flap settings, landing speed, elevation of the airport, and average maximum daily air temperature; paved runways can reach a length of 5,000 m (16,000 ft.), but the “typical” length of a commercial airline runway is between 2,500-4,000 m (8,000-13,000 ft.)
Airports - with unpaved runways:
21
note:
unpaved runways have a surface composition such as grass or packed earth and are most suited to the operation of light aircraft; unpaved runways are usually short, often less than 1,000 m (3,280 ft.) in length; airports with unpaved runways often lack facilities for refueling, maintenance, or air traffic control
Railways:
total:
728 km (2014)
standard gauge:
728 km (2014) 1.435-m gauge
comparison ranking:
total 98
Roadways:
total:
12,253 km (2018)
paved:
3,988 km (2018)
unpaved:
8,265 km (2018)
comparison ranking:
total 131
Waterways:
1,086 km (2022) (some navigation possible on the Senegal River)
comparison ranking:
67
Merchant marine:
total:
11 (2022)
by type:
general cargo 2, other 9
comparison ranking:
total 155
Ports and terminals:
major seaport(s):
Nouadhibou, Nouakchott','173907cae6f41a8cba3826ae6bdf6e6f09d655e916988a947e99992cfffd6052','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fb185b5cc7f265e26a1d871350d41c4a4bad1ba035583775db51213ae4e96c55',2025,'MU','Mauritius','transportation',56,'National air transport system:
number of registered air carriers:
1 (2020)
inventory of registered aircraft operated by air carriers:
13
annual passenger traffic on registered air carriers:
1,745,291 (2018)
annual freight traffic on registered air carriers:
233.72 million (2018) mt-km
Civil aircraft registration country code prefix:
3B
Airports:
5 (2021)
comparison ranking:
total 181
Airports - with paved runways:
2
note:
paved runways have a concrete or asphalt surface but not all have facilities for refueling, maintenance, or air traffic control; the length of a runway required for aircraft to safely operate depends on a number of factors including the type of aircraft, the takeoff weight (including passengers, cargo, and fuel), engine types, flap settings, landing speed, elevation of the airport, and average maximum daily air temperature; paved runways can reach a length of 5,000 m (16,000 ft.), but the “typical” length of a commercial airline runway is between 2,500-4,000 m (8,000-13,000 ft.)
Airports - with unpaved runways:
3
note:
unpaved runways have a surface composition such as grass or packed earth and are most suited to the operation of light aircraft; unpaved runways are usually short, often less than 1,000 m (3,280 ft.) in length; airports with unpaved runways often lack facilities for refueling, maintenance, or air traffic control
Roadways:
total:
2,428 km (2015)
paved:
2,379 km (2015) (includes 99 km of expressways)
unpaved:
49 km (2015)
comparison ranking:
total 169
Merchant marine:
total:
31 (2022)
by type:
general cargo 1, oil tanker 5, other 25
comparison ranking:
total 133
Ports and terminals:
major seaport(s):
Port Louis','457f87bf70f2c874da2571d051df05ec1e3848490ca08c3a5e178c429308ca85','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4a45239bf9fe21b9074b8986573de68b2f1ee85e7d211c688480e238894c4cad',2025,'MX','Mexico','transportation',9,'National air transport system:
number of registered air carriers:
16 (2020)
inventory of registered aircraft operated by air carriers:
370
annual passenger traffic on registered air carriers:
64,569,640 (2018)
annual freight traffic on registered air carriers:
1,090,380,000 (2018) mt-km
Civil aircraft registration country code prefix:
XA
Airports:
1,714 (2021)
comparison ranking:
total 3
Airports - with paved runways:
243
note:
paved runways have a concrete or asphalt surface but not all have facilities for refueling, maintenance, or air traffic control; the length of a runway required for aircraft to safely operate depends on a number of factors including the type of aircraft, the takeoff weight (including passengers, cargo, and fuel), engine types, flap settings, landing speed, elevation of the airport, and average maximum daily air temperature; paved runways can reach a length of 5,000 m (16,000 ft.), but the “typical” length of a commercial airline runway is between 2,500-4,000 m (8,000-13,000 ft.)
Airports - with unpaved runways:
1,471
note:
unpaved runways have a surface composition such as grass or packed earth and are most suited to the operation of light aircraft; unpaved runways are usually short, often less than 1,000 m (3,280 ft.) in length; airports with unpaved runways often lack facilities for refueling, maintenance, or air traffic control
Heliports:
1 (2021)
Pipelines:
17,210 km natural gas (2022), 9,757 km oil (2017), 10,237 km refined products (2020)
Railways:
total:
23,389 km (2017)
standard gauge:
23,389 km (2017) 1.435-m gauge (27 km electrified)
comparison ranking:
total 11
Roadways:
total:
704,884 km (2017)
paved:
175,526 km (2017) (includes 10,845 km of expressways)
unpaved:
529,358 km (2017)
comparison ranking:
total 12
Waterways:
2,900 km (2012) (navigable rivers and coastal canals mostly connected with ports on the country’s east coast)
comparison ranking:
35
Merchant marine:
total:
669 (2022)
by type:
container ship 1, bulk carrier 5, general cargo 10, oil tanker 32, other 621
comparison ranking:
total 34
Ports and terminals:
major seaport(s):
Altamira, Coatzacoalcos, Lazaro Cardenas, Manzanillo, Veracruz
oil terminal(s):
Cayo Arcas terminal, Dos Bocas terminal
cruise port(s):
Cancun, Cozumel, Ensenada
container port(s) (TEUs):
Lazaro Cardenas (1,686,076), Manzanillo (3,371,400), Veracruz (1,165,043) (2021)
LNG terminal(s) (import):
Altamira, Ensenada','b94a998a0bfb68e3127a748447e10c1c78541007b0e3e45b9c6c4b11568a6879','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1d3dad187d638cf2fadb95c2c203b0e14fd5546ed0da6661baf9f5d26133b04f',2025,'FM','Micronesia, Federated States of','transportation',21,'Civil aircraft registration country code prefix:
V6
Airports:
6 (2021)
comparison ranking:
total 174
Airports - with paved runways:
6
note:
paved runways have a concrete or asphalt surface but not all have facilities for refueling, maintenance, or air traffic control; the length of a runway required for aircraft to safely operate depends on a number of factors including the type of aircraft, the takeoff weight (including passengers, cargo, and fuel), engine types, flap settings, landing speed, elevation of the airport, and average maximum daily air temperature; paved runways can reach a length of 5,000 m (16,000 ft.), but the “typical” length of a commercial airline runway is between 2,500-4,000 m (8,000-13,000 ft.)
Roadways:
total:
(2015)
paved:
(2015)
unpaved:
(2015)
note - paved and unpaved circumferential roads, most interior roads are unpaved
Merchant marine:
total:
37 (2022)
by type:
general cargo 19, oil tanker 4, other 14
comparison ranking:
total 127
Ports and terminals:
major seaport(s):
Colonia (Tamil Harbor), Molsron Lele Harbor, Pohnepi Harbor','8ad5bc4d6541a68986cd5ac2f3beb0cc80fca009eb9300a94ddefbc208da1c5e','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('540aac9ebf1dc0db9434c5cb110729f078a07f44eff5cf3fbf9bbd7ae133c938',2025,'FM','Micronesia, Federated States of','transportation',32,'National air transport system:
number of registered air carriers:
6 (2020)
inventory of registered aircraft operated by air carriers:
21
annual passenger traffic on registered air carriers:
1,135,999 (2018)
annual freight traffic on registered air carriers:
640,000 (2018) mt-km
Civil aircraft registration country code prefix:
ER
Airports:
7 (2021)
comparison ranking:
total 168
Airports - with paved runways:
5
note:
paved runways have a concrete or asphalt surface but not all have facilities for refueling, maintenance, or air traffic control; the length of a runway required for aircraft to safely operate depends on a number of factors including the type of aircraft, the takeoff weight (including passengers, cargo, and fuel), engine types, flap settings, landing speed, elevation of the airport, and average maximum daily air temperature; paved runways can reach a length of 5,000 m (16,000 ft.), but the “typical” length of a commercial airline runway is between 2,500-4,000 m (8,000-13,000 ft.)
Airports - with unpaved runways:
2
note:
unpaved runways have a surface composition such as grass or packed earth and are most suited to the operation of light aircraft; unpaved runways are usually short, often less than 1,000 m (3,280 ft.) in length; airports with unpaved runways often lack facilities for refueling, maintenance, or air traffic control
Pipelines:
2,026 km gas (2021) (2021)
Railways:
total:
1,171 km (2014)
standard gauge:
14 km (2014) 1.435-m gauge
broad gauge:
1,157 km (2014) 1.520-m gauge
comparison ranking:
total 87
Roadways:
total:
9,352 km (2012)
paved:
8,835 km (2012)
unpaved:
517 km (2012)
comparison ranking:
total 136
Waterways:
558 km (2011) (in public use on Danube, Dniester and Prut Rivers)
comparison ranking:
90
Merchant marine:
total:
126 (2022)
by type:
bulk carrier 5, container ship 2, general cargo 79, oil tanker 7, other 33
comparison ranking:
total 79','10c628f7b8b55c5b52c6aa0e208301d8bfa89575bcf14993f62bbbe05b9c4ecd','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('879003c2766f33b3ac6b9157e1e8819c863f42551b7bb83dc184f6d92f7d41b1',2025,'MC','Monaco','transportation',43,'Civil aircraft registration country code prefix:
3A
Heliports:
1 (2021)
Railways:
note:
Monaco has a single railway station but does not operate its own train service; the French operator SNCF operates rail services in Monaco
Roadways:
total:
(2010)
paved:
(2010)
Ports and terminals:
major seaport(s):
Hercules Port','b3b1579751a0c6ce1efb7d673c258abe85f51216bbb4d6c13f94e91e5feed81e','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('271d1ae1fd3d28bdb53591dbe70e1dcb7f77a5a79db9e552f71affbe723bd939',2025,'MN','Mongolia','transportation',54,'National air transport system:
number of registered air carriers:
4 (2020)
inventory of registered aircraft operated by air carriers:
12
annual passenger traffic on registered air carriers:
670,360 (2018)
annual freight traffic on registered air carriers:
7.82 million (2018) mt-km
Civil aircraft registration country code prefix:
JU
Airports:
44 (2021)
comparison ranking:
total 98
Airports - with paved runways:
15
note:
paved runways have a concrete or asphalt surface but not all have facilities for refueling, maintenance, or air traffic control; the length of a runway required for aircraft to safely operate depends on a number of factors including the type of aircraft, the takeoff weight (including passengers, cargo, and fuel), engine types, flap settings, landing speed, elevation of the airport, and average maximum daily air temperature; paved runways can reach a length of 5,000 m (16,000 ft.), but the “typical” length of a commercial airline runway is between 2,500-4,000 m (8,000-13,000 ft.)
Airports - with unpaved runways:
29
note:
unpaved runways have a surface composition such as grass or packed earth and are most suited to the operation of light aircraft; unpaved runways are usually short, often less than 1,000 m (3,280 ft.) in length; airports with unpaved runways often lack facilities for refueling, maintenance, or air traffic control
Heliports:
1 (2021)
Railways:
total:
1,815 km (2017)
broad gauge:
1,815 km (2017) 1.520-m gauge
note:
national operator Ulaanbaatar Railway is jointly owned by the Mongolian Government and by the Russian State Railway
comparison ranking:
total 77
Roadways:
total:
113,200 km (2017)
paved:
10,600 km (2017)
unpaved:
102,600 km (2017)
comparison ranking:
total 44
Waterways:
580 km (2010) (the only waterway in operation is Lake Hovsgol) (135 km); Selenge River (270 km) and Orhon River (175 km) are navigable but carry little traffic; lakes and rivers ice-free from May to September)
comparison ranking:
88
Merchant marine:
total:
314 (2022)
by type:
bulk carrier 3, container ship 6, general cargo 151, oil tanker 57, other 97
comparison ranking:
total 53','581ee272ad2ca96cabe70d83bba20e77a8ca656ed98a0ee851e1586957032af7','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('87b51f8350b916c52f289742071f7a88518f3a66d359844393f5cf04bf86754c',2025,'ME','Montenegro','transportation',9,'National air transport system:
number of registered air carriers:
1 (2020)
inventory of registered aircraft operated by air carriers:
4
annual passenger traffic on registered air carriers:
565,522 (2018)
annual freight traffic on registered air carriers:
130,000 (2018) mt-km
Civil aircraft registration country code prefix:
4O
Airports:
5 (2021)
comparison ranking:
total 182
Airports - with paved runways:
5
note:
paved runways have a concrete or asphalt surface but not all have facilities for refueling, maintenance, or air traffic control; the length of a runway required for aircraft to safely operate depends on a number of factors including the type of aircraft, the takeoff weight (including passengers, cargo, and fuel), engine types, flap settings, landing speed, elevation of the airport, and average maximum daily air temperature; paved runways can reach a length of 5,000 m (16,000 ft.), but the “typical” length of a commercial airline runway is between 2,500-4,000 m (8,000-13,000 ft.)
Heliports:
1 (2021)
Railways:
total:
250 km (2017)
standard gauge:
250 km (2017) 1.435-m gauge (224 km electrified)
comparison ranking:
total 126
Roadways:
total:
7,762 km (2010)
paved:
7,141 km (2010)
unpaved:
621 km (2010)
comparison ranking:
total 139
Merchant marine:
total:
18 (2022)
by type:
bulk carrier 4, other 14
comparison ranking:
total 149
Ports and terminals:
major seaport(s):
Bar','2bbe47b37ef69667dccf4b752bcea7546247ef11f1f7c82f49ac87de7a621af9','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e8a52c64f9cc609c51e2c1ecb7aa21d5483006249621409ad531fd1f89dfdc9b',2025,'MS','Montserrat','transportation',20,'National air transport system:
number of registered air carriers:
1 (2020)
inventory of registered aircraft operated by air carriers:
3
Civil aircraft registration country code prefix:
VP-M
Airports:
1 (2021)
comparison ranking:
total 218
Airports - with paved runways:
1
note:
paved runways have a concrete or asphalt surface but not all have facilities for refueling, maintenance, or air traffic control; the length of a runway required for aircraft to safely operate depends on a number of factors including the type of aircraft, the takeoff weight (including passengers, cargo, and fuel), engine types, flap settings, landing speed, elevation of the airport, and average maximum daily air temperature; paved runways can reach a length of 5,000 m (16,000 ft.), but the “typical” length of a commercial airline runway is between 2,500-4,000 m (8,000-13,000 ft.)
Roadways:
note:
volcanic eruptions that began in 1995 destroyed most of the 227 km road system; a new road infrastructure has been built on the north end of the island
Ports and terminals:
major seaport(s):
Little Bay, Plymouth','6f6bb8b7b67d54db29a420844d733c9a127cf8738476934ea7875a7e86eca23f','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e259ea286eadb93938a7aaa16a40b2cab009f44b2d58632aac840b29c12b4411',2025,'MA','Morocco','transportation',31,'National air transport system:
number of registered air carriers:
3 (2020)
inventory of registered aircraft operated by air carriers:
76
annual passenger traffic on registered air carriers:
8,132,917 (2018)
annual freight traffic on registered air carriers:
97.71 million (2018) mt-km
Civil aircraft registration country code prefix:
CN
Airports:
62 (2021)
comparison ranking:
total 79
Airports - with paved runways:
36
civil airports:
7
military airports:
5
joint use (civil-military) airports:
4
other airports:
20
note:
paved runways have a concrete or asphalt surface but not all have facilities for refueling, maintenance, or air traffic control; the length of a runway required for aircraft to safely operate depends on a number of factors including the type of aircraft, the takeoff weight (including passengers, cargo, and fuel), engine types, flap settings, landing speed, elevation of the airport, and average maximum daily air temperature; paved runways can reach a length of 5,000 m (16,000 ft.), but the “typical” length of a commercial airline runway is between 2,500-4,000 m (8,000-13,000 ft.)
Airports - with unpaved runways:
26
note:
unpaved runways have a surface composition such as grass or packed earth and are most suited to the operation of light aircraft; unpaved runways are usually short, often less than 1,000 m (3,280 ft.) in length; airports with unpaved runways often lack facilities for refueling, maintenance, or air traffic control
Heliports:
1 (2021)
Pipelines:
944 km gas, 270 km oil, 175 km refined products (2013)
Railways:
total:
2,067 km (2014)
standard gauge:
2,067 km (2014) 1.435-m gauge (1,022 km electrified)
comparison ranking:
total 72
Roadways:
total:
57,300 km (2018)
comparison ranking:
total 79
Merchant marine:
total:
93 (2022)
by type:
container ship 6, general cargo 5, oil tanker 2, other 80
comparison ranking:
total 94
Ports and terminals:
major seaport(s):
Ad Dakhla, Agadir, Casablanca, Jorf Lasfar, Laayoune (El Aaiun), Mohammedia, Safi, Tangier
container port(s) (TEUs):
Tangier (7,173,870) (2021)
LNG terminal(s) (import):
Jorf Lasfar (planned)','f0b08737b1ebf858819c70b6436635c780f7a3fed3734707d3482f23d6c75ba5','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('df78ac05de12f18912f54a12032f95478e1e0d6dcfd5b3795df430a6e201dcd9',2025,'MZ','Mozambique','transportation',44,'National air transport system:
number of registered air carriers:
2 (2020)
inventory of registered aircraft operated by air carriers:
11
annual passenger traffic on registered air carriers:
540,124 (2018)
annual freight traffic on registered air carriers:
4.78 million (2018) mt-km
Civil aircraft registration country code prefix:
C9
Airports:
98 (2021)
comparison ranking:
total 58
Airports - with paved runways:
21
note:
paved runways have a concrete or asphalt surface but not all have facilities for refueling, maintenance, or air traffic control; the length of a runway required for aircraft to safely operate depends on a number of factors including the type of aircraft, the takeoff weight (including passengers, cargo, and fuel), engine types, flap settings, landing speed, elevation of the airport, and average maximum daily air temperature; paved runways can reach a length of 5,000 m (16,000 ft.), but the “typical” length of a commercial airline runway is between 2,500-4,000 m (8,000-13,000 ft.)
Airports - with unpaved runways:
77
note:
unpaved runways have a surface composition such as grass or packed earth and are most suited to the operation of light aircraft; unpaved runways are usually short, often less than 1,000 m (3,280 ft.) in length; airports with unpaved runways often lack facilities for refueling, maintenance, or air traffic control
Pipelines:
972 km gas, 278 km refined products (2013)
Railways:
total:
4,787 km (2014)
narrow gauge:
4,787 km (2014) 1.067-m gauge
comparison ranking:
total 40
Roadways:
total:
31,083 km (2015)
paved:
7,365 km (2015)
unpaved:
23,718 km (2015)
comparison ranking:
total 96
Waterways:
460 km (2010) (Zambezi River navigable to Tete and along Cahora Bassa Lake)
comparison ranking:
93
Merchant marine:
total:
30 (2022)
by type:
general cargo 9, other 21
comparison ranking:
total 135
Ports and terminals:
major seaport(s):
Beira, Maputo, Nacala
LNG terminal(s) (export):
Coral Sul (FLNG)','ad8c9ccc7937580eca4efc40015f0b0212a9e8d1122a074dab5329750bb550a7','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4fd320c3af5984adaad35bc157b1f48e05b383dbc23c6fb54e654d7c940f5737',2025,'NA','Namibia','transportation',9,'National air transport system:
number of registered air carriers:
2 (2020)
inventory of registered aircraft operated by air carriers:
21
annual passenger traffic on registered air carriers:
602,893 (2018)
annual freight traffic on registered air carriers:
26.29 million (2018) mt-km
Civil aircraft registration country code prefix:
V5
Airports:
112 (2021)
comparison ranking:
total 51
Airports - with paved runways:
19
note:
paved runways have a concrete or asphalt surface but not all have facilities for refueling, maintenance, or air traffic control; the length of a runway required for aircraft to safely operate depends on a number of factors including the type of aircraft, the takeoff weight (including passengers, cargo, and fuel), engine types, flap settings, landing speed, elevation of the airport, and average maximum daily air temperature; paved runways can reach a length of 5,000 m (16,000 ft.), but the “typical” length of a commercial airline runway is between 2,500-4,000 m (8,000-13,000 ft.)
Airports - with unpaved runways:
93
note:
unpaved runways have a surface composition such as grass or packed earth and are most suited to the operation of light aircraft; unpaved runways are usually short, often less than 1,000 m (3,280 ft.) in length; airports with unpaved runways often lack facilities for refueling, maintenance, or air traffic control
Railways:
total:
2,628 km (2014)
narrow gauge:
2,628 km (2014) 1.067-m gauge
comparison ranking:
total 62
Roadways:
total:
48,875 km (2018)
paved:
7,893 km (2018)
unpaved:
40,982 km (2018)
comparison ranking:
total 82
Merchant marine:
total:
15 (2022)
by type:
general cargo 1, other 14
comparison ranking:
total 151
Ports and terminals:
major seaport(s):
Luderitz, Walvis Bay','5c01d69884e9afa30f83b3c4dcf5b806743b051ae237a34a722affc8eca766e1','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4dc9aff5054268e5e108f116d23886d58c465dc0f094a0a802a3a95eec79ce92',2025,'NR','Nauru','transportation',20,'National air transport system:
number of registered air carriers:
1 (2020)
inventory of registered aircraft operated by air carriers:
5
annual passenger traffic on registered air carriers:
45,457 (2018)
annual freight traffic on registered air carriers:
7.94 million (2018) mt-km
Civil aircraft registration country code prefix:
C2
Airports:
1 (2021)
comparison rank
ing:
total 229
Airports - with paved runways:
1
note:
paved runways have a concrete or asphalt surface but not all have facilities for refueling, maintenance, or air traffic control; the length of a runway required for aircraft to safely operate depends on a number of factors including the type of aircraft, the takeoff weight (including passengers, cargo, and fuel), engine types, flap settings, landing speed, elevation of the airport, and average maximum daily air temperature; paved runways can reach a length of 5,000 m (16,000 ft.), but the “typical” length of a commercial airline runway is between 2,500-4,000 m (8,000-13,000 ft.)
Roadways:
total:
30 km (2002)
paved:
24 km (2002)
unpaved:
6 km (2002)
comparison ranking:
total 219
Merchant marine:
total:
3 (2022)
by type:
other 3
comparison ranking:
total 171
Ports and terminals:
major seaport(s):','5af7b9ffa6a1f48d70ac72d5ae7226f7cb3959e551e10fa78c3a3bde68927a6e','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cc64fe44379f3b115cacf371b61fb5e17284b899be69e1a11ee791be2067b9a3',2025,'NR','Nauru','transportation',28,'Ports and terminals:
none; offshore anchorage only','97a08f7f958d0d9909c5d5cf9b653fbd7f83ba17e780ff6265a95bb5fccb5752','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c1f2ef2c71f63e0ab9e0e7a68430be5fa1c02ea1a47bd4e467e5fc9b5043a2d2',2025,'NP','Nepal','transportation',39,'National air transport system:
number of registered air carriers:
6 (2020)
inventory of registered aircraft operated by air carriers:
39
annual passenger traffic on registered air carriers:
3,296,953 (2018)
annual freight traffic on registered air carriers:
4.66 million (2018) mt-km
Civil aircraft registration country code prefix:
9N
Airports:
47 (2021)
comparison ranking:
total 93
Airports - with paved runways:
11
note:
paved runways have a concrete or asphalt surface but not all have facilities for refueling, maintenance, or air traffic control; the length of a runway required for aircraft to safely operate depends on a number of factors including the type of aircraft, the takeoff weight (including passengers, cargo, and fuel), engine types, flap settings, landing speed, elevation of the airport, and average maximum daily air temperature; paved runways can reach a length of 5,000 m (16,000 ft.), but the “typical” length of a commercial airline runway is between 2,500-4,000 m (8,000-13,000 ft.)
Airports - with unpaved runways:
36
note:
unpaved runways have a surface composition such as grass or packed earth and are most suited to the operation of light aircraft; unpaved runways are usually short, often less than 1,000 m (3,280 ft.) in length; airports with unpaved runways often lack facilities for refueling, maintenance, or air traffic control
Railways:
total:
59 km (2018)
narrow gauge:
59 km (2018) 0.762-m gauge
comparison ranking:
total 132
Roadways:
total:
27,990 km (2016)
paved:
11,890 km (2016)
unpaved:
16,100 km (2016)
comparison ranking:
total 99','1b45559dc18cdc1bf059212db3e8824e7fa94802654ed46d5fd5ecb48faec8e3','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3dab61e226652e088072b6ddc32e9063321c2ce7742c9e63157d07b3485172fe',2025,'NL','Netherlands','transportation',51,'National air transport system:
number of registered air carriers:
8 (2020)
inventory of registered aircraft operated by air carriers:
238
annual passenger traffic on registered air carriers:
43,996,044 (2018)
annual freight traffic on registered air carriers:
5,886,510,000 (2018) mt-km
Civil aircraft registration country code prefix:
PH
Airports:
29 (2021)
comparison ranking:
total 118
Airports - with paved runways:
23
civil airports:
6
military airports:
5
joint use (civil-military) airports:
2
other airports:
10
note:
paved runways have a concrete or asphalt surface but not all have facilities for refueling, maintenance, or air traffic control; the length of a runway required for aircraft to safely operate depends on a number of factors including the type of aircraft, the takeoff weight (including passengers, cargo, and fuel), engine types, flap settings, landing speed, elevation of the airport, and average maximum daily air temperature; paved runways can reach a length of 5,000 m (16,000 ft.), but the “typical” length of a commercial airline runway is between 2,500-4,000 m (8,000-13,000 ft.)
Airports - with unpaved runways:
6
note:
unpaved runways have a surface composition such as grass or packed earth and are most suited to the operation of light aircraft; unpaved runways are usually short, often less than 1,000 m (3,280 ft.) in length; airports with unpaved runways often lack facilities for refueling, maintenance, or air traffic control
Heliports:
1 (2021)
Pipelines:
14,000 km gas, 2,500 km oil and refined products, 3,000 km chemicals (2017)
Railways:
total:
3,055 km (2020) 2,310 km electrified
comparison ranking:
total 58
Roadways:
total:
139,124 km (2016) (includes 3,654 km of expressways)
comparison ranking:
total 37
Waterways:
6,237 km (2012) (navigable by ships up to 50 tons)
comparison ranking:
23
Merchant marine:
total:
1,175 (2022)
by type:
bulk carrier 11, container ship 37, general cargo 543, oil tanker 26, other 558
comparison ranking:
total 22
Ports and terminals:
major seaport(s):
IJmuiden, Vlissingen
container port(s) (TEUs):
Rotterdam (15,300,000) (2021)
LNG terminal(s) (import):
Gate (Rotterdam)
river port(s):
Amsterdam (Nordsee Kanaal); Moerdijk (Hollands Diep River); Rotterdam (Rhine River); Terneuzen (Western Scheldt River)','eb563732a87dfcad6103c981d1a92071d3e1dbf3f9459fbe4e318bcaf47867ae','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a2bd1f42b37381d00bf67510df778894ba17d63e4b45c87916a004b06e205f97',2025,'NC','New Caledonia','transportation',64,'National air transport system:
number of registered air carriers:
3 (2020) (registered in France)
inventory of registered aircraft operated by air carriers:
15 (registered in France)
Airports:
25 (2021)
comparison ranking:
total 128
Airports - with paved runways:
12
note:
paved runways have a concrete or asphalt surface but not all have facilities for refueling, maintenance, or air traffic control; the length of a runway required for aircraft to safely operate depends on a number of factors including the type of aircraft, the takeoff weight (including passengers, cargo, and fuel), engine types, flap settings, landing speed, elevation of the airport, and average maximum daily air temperature; paved runways can reach a length of 5,000 m (16,000 ft.), but the “typical” length of a commercial airline runway is between 2,500-4,000 m (8,000-13,000 ft.)
Airports - with unpaved runways:
13
note:
unpaved runways have a surface composition such as grass or packed earth and are most suited to the operation of light aircraft; unpaved runways are usually short, often less than 1,000 m (3,280 ft.) in length; airports with unpaved runways often lack facilities for refueling, maintenance, or air traffic control
Heliports:
8 (2021)
Roadways:
total:
5,622 km (2006)
comparison ranking:
total 146
Merchant marine:
total:
23 (2022)
by type:
general cargo 5, oil tanker 1, other 17
comparison ranking:
total 145
Ports and terminals:
major seaport(s):
Noumea','37c5af8b2e643f0e2676c0be876d667094d07ea99b77c6b89de760fced32cf8b','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2d4b2489ad46da67d26c6c98f82f4160a5859d9c09316894e55038a5d8467d73',2025,'NZ','New Zealand','transportation',9,'National air transport system:
number of registered air carriers:
15 (2020)
inventory of registered aircraft operated by air carriers:
199
annual passenger traffic on registered air carriers:
17,249,049 (2018)
annual freight traffic on registered air carriers:
1,349,300,000 (2018) mt-km
Civil aircraft registration country code prefix:
ZK
Airports:
123 (2021)
comparison ranking:
total 47
Airports - with paved runways:
39
civil airports:
15
military airports:
2
joint use (civil-military) airports:
1
other airports:
21
note:
paved runways have a concrete or asphalt surface but not all have facilities for refueling, maintenance, or air traffic control; the length of a runway required for aircraft to safely operate depends on a number of factors including the type of aircraft, the takeoff weight (including passengers, cargo, and fuel), engine types, flap settings, landing speed, elevation of the airport, and average maximum daily air temperature; paved runways can reach a length of 5,000 m (16,000 ft.), but the “typical” length of a commercial airline runway is between 2,500-4,000 m (8,000-13,000 ft.)
Airports - with unpaved runways:
84
note:
unpaved runways have a surface composition such as grass or packed earth and are most suited to the operation of light aircraft; unpaved runways are usually short, often less than 1,000 m (3,280 ft.) in length; airports with unpaved runways often lack facilities for refueling, maintenance, or air traffic control
Pipelines:
331 km condensate, 2,500 km gas, 172 km liquid petroleum gas, 288 km oil, 198 km refined products (2018)
Railways:
total:
4,128 km (2018)
narrow gauge:
4,128 km (2018) 1.067-m gauge (506 km electrified)
comparison ranking:
total 42
Roadways:
total:
94,000 km (2017)
paved:
61,600 km (2017) (includes 199 km of expressways)
unpaved:
32,400 km (2017)
comparison ranking:
total 52
Merchant marine:
total:
116 (2022)
by type:
container ship 1, general cargo 12, oil tanker 5, other 98
comparison ranking:
total 85
Ports and terminals:
major seaport(s):
Auckland, Lyttelton, Manukau Harbor, Marsden Point, Tauranga, Wellington','e433b6a2f5671f07a4139b4dfbc29cbaac8fc37c13c91c8b0e8c92179d9ecf44','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('638d8c285c37e73a4cb6be0059c78809d039f04ebd2fc92eeb7bc060b18d9f00',2025,'NI','Nicaragua','transportation',22,'National air transport system:
number of registered air carriers:
1 (2020)
inventory of registered aircraft operated by air carriers:
7
Civil aircraft registration country code prefix:
YN
Airports:
147 (2021)
comparison ranking:
total 38
Airports - with paved runways:
12
note:
paved runways have a concrete or asphalt surface but not all have facilities for refueling, maintenance, or air traffic control; the length of a runway required for aircraft to safely operate depends on a number of factors including the type of aircraft, the takeoff weight (including passengers, cargo, and fuel), engine types, flap settings, landing speed, elevation of the airport, and average maximum daily air temperature; paved runways can reach a length of 5,000 m (16,000 ft.), but the “typical” length of a commercial airline runway is between 2,500-4,000 m (8,000-13,000 ft.)
Airports - with unpaved runways:
135
note:
unpaved runways have a surface composition such as grass or packed earth and are most suited to the operation of light aircraft; unpaved runways are usually short, often less than 1,000 m (3,280 ft.) in length; airports with unpaved runways often lack facilities for refueling, maintenance, or air traffic control
Pipelines:
54 km oil (2013)
Roadways:
total:
23,897 km (2014)
paved:
3,346 km (2014)
unpaved:
20,551 km (2014)
comparison ranking:
total 106
Waterways:
2,220 km (2011) (navigable waterways as well as the use of the large Lake Managua and Lake Nicaragua; rivers serve only the sparsely populated eastern part of the country)
comparison ranking:
41
Merchant marine:
total:
5 (2022)
by type:
general cargo 1, oil tanker 1, other 3
comparison ranking:
total 166
Ports and terminals:
major seaport(s):
Bluefields, Corinto','cc3c5bcb6d5499ad865758412def2538f7fea31967ca4b2ce37ff9b465391ab3','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f5c39e7eac00da82f96f6d63c09704cc8a74e28285dccc1e3aa041198524abd2',2025,'NE','Niger','transportation',34,'National air transport system:
number of registered air carriers:
2 (2020)
inventory of registered aircraft operated by air carriers:
3
Civil aircraft registration country code prefix:
5U
Airports:
30 (2021)
comparison ranking:
total 114
Airports - with paved runways:
10
note:
paved runways have a concrete or asphalt surface but not all have facilities for refueling, maintenance, or air traffic control; the length of a runway required for aircraft to safely operate depends on a number of factors including the type of aircraft, the takeoff weight (including passengers, cargo, and fuel), engine types, flap settings, landing speed, elevation of the airport, and average maximum daily air temperature; paved runways can reach a length of 5,000 m (16,000 ft.), but the “typical” length of a commercial airline runway is between 2,500-4,000 m (8,000-13,000 ft.)
Airports - with unpaved runways:
20
note:
unpaved runways have a surface composition such as grass or packed earth and are most suited to the operation of light aircraft; unpaved runways are usually short, often less than 1,000 m (3,280 ft.) in length; airports with unpaved runways often lack facilities for refueling, maintenance, or air traffic control
Heliports:
1 (2021)
Pipelines:
464 km oil
Roadways:
total:
18,949 km (2010)
paved:
3,912 km (2010)
unpaved:
15,037 km (2010)
comparison ranking:
total 116
Waterways:
300 km (2012) (the Niger, the only major river, is navigable to Gaya between September and March) comparison ranking: 102
Merchant marine:
total:
2 (2022)
by type:
general cargo 1, other 1
comparison ranking:
total 175','f08798dbd2f3af87bfd818efd600d7f65cef66dcf12b64495c362fc5de86c300','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7127d5c5ad4dabcd83572e34ef2664fef96e6542a43ef66c9bb9f6078781d685',2025,'NG','Nigeria','transportation',46,'National air transport system:
number of registered air carriers:
13 (2020)
inventory of registered aircraft operated by air carriers:
104
annual passenger traffic on registered air carriers:
8,169,192 (2018)
annual freight traffic on registered air carriers:
19.42 million (2018) mt-km
Civil aircraft registration country code prefix:
5N
Airports:
54 (2021)
comparison ranking:
total 86
Airports - with paved runways:
40
civil airports:
8
military airports:
0
joint use (civil-military) airports:
3
other airports:
29
note:
paved runways have a concrete or asphalt surface but not all have facilities for refueling, maintenance, or air traffic control; the length of a runway required for aircraft to safely operate depends on a number of factors including the type of aircraft, the takeoff weight (including passengers, cargo, and fuel), engine types, flap settings, landing speed, elevation of the airport, and average maximum daily air temperature; paved runways can reach a length of 5,000 m (16,000 ft.), but the “typical” length of a commercial airline runway is between 2,500-4,000 m (8,000-13,000 ft.)
Airports - with unpaved runways:
14
note:
unpaved runways have a surface composition such as grass or packed earth and are most suited to the operation of light aircraft; unpaved runways are usually short, often less than 1,000 m (3,280 ft.) in length; airports with unpaved runways often lack facilities for refueling, maintenance, or air traffic control
Heliports:
5 (2021)
Pipelines:
124 km condensate, 4,045 km gas, 164 km liquid petroleum gas, 4,441 km oil, 3,940 km refined products (2013)
Railways:
total:
3,798 km (2014)
standard gauge:
293 km (2014) 1.435-m gauge
narrow gauge:
3,505 km (2014) 1.067-m gauge
note:
as of the end of 2018, there were only six operational locomotives in Nigeria primarily used for passenger service; the majority of the rail lines are in a severe state of disrepair and need to be replaced
comparison ranking:
total 52
Roadways:
total:
195,000 km (2017)
paved:
60,000 km (2017)
unpaved:
135,000 km (2017)
comparison ranking:
total 29
Waterways:
8,600 km (2011) (Niger and Benue Rivers and smaller rivers and creeks)
comparison ranking:
17
Merchant marine:
total:
832 (2022)
by type:
general cargo 16, oil tanker 111, other 705
comparison ranking:
total 27
Ports and terminals:
major seaport(s):
Bonny Inshore Terminal, Calabar, Lagos
oil terminal(s):
Bonny Terminal, Brass Terminal, Escravos Terminal, Forcados Terminal, Pennington Terminal, Qua Iboe Terminal
LNG terminal(s) (export):
Bonny Island','d2e8a1f599ac93b58a5b9eb318cfef30465777dd3061ee4af8d1cf6cd737dfb7','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8a78daaaddc1a05de3a23b6f548fca0185bc7bc96214c8ee6766ad3e495c665d',2025,'NU','Niue','transportation',9,'Airports:
1 (2021)
comparison ranking:
total 226
Airports - with paved runways:
1
note:
paved runways have a concrete or asphalt surface but not all have facilities for refueling, maintenance, or air traffic control; the length of a runway required for aircraft to safely operate depends on a number of factors including the type of aircraft, the takeoff weight (including passengers, cargo, and fuel), engine types, flap settings, landing speed, elevation of the airport, and average maximum daily air temperature; paved runways can reach a length of 5,000 m (16,000 ft.), but the “typical” length of a commercial airline runway is between 2,500-4,000 m (8,000-13,000 ft.)
Roadways:
total:
234 km (2017)
paved:
210 km (2017)
unpaved:
24 km
comparison ranking:
total 206
Merchant marine:
total:
71 (2022)
by type:
bulk carrier 4, container ship 2, general cargo 29, oil tanker 4, other 32
comparison ranking:
total 106
Ports and terminals:
major seaport(s):
Alofi','017fe0cc7622b97788d4602b6889985c2ea1a23f8779d80cfc5f4e8684cb45ff','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7ffbd587effe0391f77e7d5295d901b6702db19438112a52e4fb53b4d5d14249',2025,'NF','Norfolk Island','transportation',19,'Airports:
1 (2021)
comparison ranking:
total 214
Airports - with paved runways:
1
note:
paved runways have a concrete or asphalt surface but not all have facilities for refueling, maintenance, or air traffic control; the length of a runway required for aircraft to safely operate depends on a number of factors including the type of aircraft, the takeoff weight (including passengers, cargo, and fuel), engine types, flap settings, landing speed, elevation of the airport, and average maximum daily air temperature; paved runways can reach a length of 5,000 m (16,000 ft.), but the “typical” length of a commercial airline runway is between 2,500-4,000 m (8,000-13,000 ft.)
Roadways:
total:
80 km (2008)
paved:
53 km (2008)
unpaved:
27 km (2008)
comparison ranking:
total 215
Ports and terminals:
major seaport(s):
Kingston','e64b85d88b2a407ecb1d3884aac01cae9476b07050885d0b143c7576a5f1cb4f','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fcd4adaec6f56d0662a21b3150d00276b8a4437a2d79c84c230686dd750d9a32',2025,'MK','North Macedonia','transportation',30,'Civil aircraft registration country code prefix:
Z3
Airports:
10 (2021)
comparison ranking:
total 154
Airports - with paved runways:
8
note:
paved runways have a concrete or asphalt surface but not all have facilities for refueling, maintenance, or air traffic control; the length of a runway required for aircraft to safely operate depends on a number of factors including the type of aircraft, the takeoff weight (including passengers, cargo, and fuel), engine types, flap settings, landing speed, elevation of the airport, and average maximum daily air temperature; paved runways can reach a length of 5,000 m (16,000 ft.), but the “typical” length of a commercial airline runway is between 2,500-4,000 m (8,000-13,000 ft.)
Airports - with unpaved runways:
2
note:
unpaved runways have a surface composition such as grass or packed earth and are most suited to the operation of light aircraft; unpaved runways are usually short, often less than 1,000 m (3,280 ft.) in length; airports with unpaved runways often lack facilities for refueling, maintenance, or air traffic control
Pipelines:
262 km gas, 120 km oil (2017)
Railways:
total:
699 km (2020) 313 km electrified
comparison ranking:
total 99
Roadways:
total:
14,182 km (2017) (includes 290 km of expressways)
paved:
9,633 km (2017)
unpaved:
4,549 km (2017)
comparison ranking:
total 127','9505d7ad5e765ed3740ea9aa4950f0af82729b06ff982d24600fd778390ffecf','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ffa1d40597eeeb1aadf69f1c190987feb8a0ebb6ac1f86d9cb43c278d80127c3',2025,'MP','Northern Mariana Islands','transportation',42,'Airports:
5 (2021)
comparison ranking:
total 180
Airports - with paved runways:
3
note:
paved runways have a concrete or asphalt surface but not all have facilities for refueling, maintenance, or air traffic control; the length of a runway required for aircraft to safely operate depends on a number of factors including the type of aircraft, the takeoff weight (including passengers, cargo, and fuel), engine types, flap settings, landing speed, elevation of the airport, and average maximum daily air temperature; paved runways can reach a length of 5,000 m (16,000 ft.), but the “typical” length of a commercial airline runway is between 2,500-4,000 m (8,000-13,000 ft.)
Airports - with unpaved runways:
2
note:
unpaved runways have a surface composition such as grass or packed earth and are most suited to the operation of light aircraft; unpaved runways are usually short, often less than 1,000 m (3,280 ft.) in length; airports with unpaved runways often lack facilities for refueling, maintenance, or air traffic control
Heliports:
1 (2021)
Roadways:
total:
536 km (2008)
comparison ranking:
total 195
Ports and terminals:
major seaport(s):
Saipan, Tinian, Rota','16058880623e0886706bbeb4762f228bb6b72d0ff36128469d136bfa75875466','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1a7e67b93f0331aaf7936e68b622bcdeaf692f3a50ccea1370df51466247bb62',2025,'NO','Norway','transportation',53,'National air transport system:
number of registered air carriers:
8 (2020)
inventory of registered aircraft operated by air carriers:
125
Civil aircraft registration country code prefix:
LN
Airports:
95 (2021)
comparison ranking:
total 61
Airports - with paved runways:
67
civil airports:
25
military airports:
1
joint use (civil-military) airports:
6
other airports:
35
note:
paved runways have a concrete or asphalt surface but not all have facilities for refueling, maintenance, or air traffic control; the length of a runway required for aircraft to safely operate depends on a number of factors including the type of aircraft, the takeoff weight (including passengers, cargo, and fuel), engine types, flap settings, landing speed, elevation of the airport, and average maximum daily air temperature; paved runways can reach a length of 5,000 m (16,000 ft.), but the “typical” length of a commercial airline runway is between 2,500-4,000 m (8,000-13,000 ft.)
Airports - with unpaved runways:
28
note:
unpaved runways have a surface composition such as grass or packed earth and are most suited to the operation of light aircraft; unpaved runways are usually short, often less than 1,000 m (3,280 ft.) in length; airports with unpaved runways often lack facilities for refueling, maintenance, or air traffic control
Heliports:
1 (2021)
Pipelines:
8,520 km gas, 1,304 km oil/condensate (2017)
Railways:
total:
3,848 km (2020) 2,482 km electrified
comparison ranking:
total 50
Roadways:
total:
94,902 km (2018) (includes 455 km of expressways)
paved:
(2013)
unpaved:
(2013)
comparison ranking:
total 51
Waterways:
1,577 km (2010)
comparison ranking:
54
Merchant marine:
total:
1,710 (2022)
by type:
bulk carrier 105, container ship 1, general cargo 273, oil tanker 95, other 1,236
comparison ranking:
total 17
Ports and terminals:
major seaport(s):
Bergen, Haugesund, Maaloy, Mongstad, Narvik, Sture
LNG terminal(s) (export):
Kamoy, Kollsnes, Melkoya Island, Tjeldbergodden
LNG terminal(s) (import):
Fredrikstad, Mosjoen
Transportation - note:
Norway operates one PC 3 or 4 class icebreaker and one PC 5 or 6 class icebreaker in the Arctic Ocean
note - PC indicates a Polar Class vessel:
PC 3 - year-round operation in second-year ice which may include multi-year ice inclusions (ice thickness up to 2.5 m); PC 4 - year-round operation in thick first-year ice which may include old ice inclusions (ice thickness up to 120 cm); PC 5 - year-round operation in medium first-year ice which may include old ice inclusions (ice thickness up to 70-120 cm); PC 6 - summer/autumn operation in medium first-year ice which may include old ice inclusions (ice thickness up to 30-70 cm)','b70b85b00f709cd89490733eaa4ff5322666e2677bd89d7b7246bb570facbd3c','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a1e99ae8ec3062a42023af740b9b905e760d04d2a7f5526de1d8ccbb5e4b12bf',2025,'OM','Oman','transportation',9,'National air transport system:
number of registered air carriers:
2 (2020)
inventory of registered aircraft operated by air carriers:
57
annual passenger traffic on registered air carriers:
10,438,241 (2018)
annual freight traffic on registered air carriers:
510.43 million (2018) mt-km
Civil aircraft registration country code prefix:
A4O
Airports:
132 (2021)
comparison ranking:
total 43
Airports - with paved runways:
13
note:
paved runways have a concrete or asphalt surface but not all have facilities for refueling, maintenance, or air traffic control; the length of a runway required for aircraft to safely operate depends on a number of factors including the type of aircraft, the takeoff weight (including passengers, cargo, and fuel), engine types, flap settings, landing speed, elevation of the airport, and average maximum daily air temperature; paved runways can reach a length of 5,000 m (16,000 ft.), but the “typical” length of a commercial airline runway is between 2,500-4,000 m (8,000-13,000 ft.)
Airports - with unpaved runways:
119
note:
unpaved runways have a surface composition such as grass or packed earth and are most suited to the operation of light aircraft; unpaved runways are usually short, often less than 1,000 m (3,280 ft.) in length; airports with unpaved runways often lack facilities for refueling, maintenance, or air traffic control
Heliports:
3 (2021)
Pipelines:
106 km condensate, 4,224 km gas, 3,558 km oil, 33 km oil/gas/water, 264 km refined products (2013)
Roadways:
total:
60,230 km (2012)
paved:
29,685 km (2012) (includes 1,943 km of expressways)
unpaved:
30,545 km (2012)
comparison ranking:
total 74
Merchant marine:
total:
57 (2022)
by type:
general cargo 11, other 46
comparison ranking:
total 117
Ports and terminals:
major seaport(s):
Mina’ Qabus, Salalah, Suhar
container port(s) (TEUs):
Salalah (4,510,000) (2021)
LNG terminal(s) (export):
Qalhat','f0740f3103a077a28893cc0bad75bacd9433abbecb6b4981209cf9b3473cf44e','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('67c856eee8ac3230836c9600bca8b9cc71cce28b266c667469cbbbcfd45989c9',2025,'PK','Pakistan','transportation',10,'National air transport system:
number of registered air carriers:
5 (2020)
inventory of registered aircraft operated by air carriers:
52
annual passenger traffic on registered air carriers:
6,880,637 (2018)
annual freight traffic on registered air carriers:
217.53 million (2018) mt-km
Civil aircraft registration country code prefix:
AP
Airports:
151 (2021)
comparison ranking:
total 35
Airports - with paved runways:
108
civil airports:
5
military airports:
12
joint use (civil-military) airports:
5
other airports:
86
note:
paved runways have a concrete or asphalt surface but not all have facilities for refueling, maintenance, or air traffic control; the length of a runway required for aircraft to safely operate depends on a number of factors including the type of aircraft, the takeoff weight (including passengers, cargo, and fuel), engine types, flap settings, landing speed, elevation of the airport, and average maximum daily air temperature; paved runways can reach a length of 5,000 m (16,000 ft.), but the “typical” length of a commercial airline runway is between 2,500-4,000 m (8,000-13,000 ft.)
Airports - with unpaved runways:
43
note:
unpaved runways have a surface composition such as grass or packed earth and are most suited to the operation of light aircraft; unpaved runways are usually short, often less than 1,000 m (3,280 ft.) in length; airports with unpaved runways often lack facilities for refueling, maintenance, or air traffic control
Heliports:
23 (2021)
Pipelines:
13,452 km gas transmission and 177,029 km gas distribution, 3,663 km oil, 1,150 km refined products (2022)
Railways:
total:
11,881 km (2021)
narrow gauge:
389 km (2021) 1.000-m gauge
broad gauge:
11,492 km (2021) 1.676-m gauge (286 km electrified)
comparison ranking:
total 20
Roadways:
total:
264,175 km (2021)
paved:
185,463 km (2021) (includes 708 km of expressways)
unpaved:
78,712 km (2021)
comparison ranking:
total 22
Merchant marine:
total:
58 (2022)
by type:
bulk carrier 5, oil tanker 7, other 46
comparison ranking:
total 116
Ports and terminals:
major seaport(s):
Karachi, Port Muhammad Bin Qasim
container port(s) (TEUs):
Karachi (2,097,855) (2019)
LNG terminal(s) (import):
Port Qasim','5a537c2b05a8dd09751f51797a8cc4cbe334333305ee2be3f37b388d6dcbf52a','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('79c289792d431133fff46b656e0a19eb6457cf4dee51f498071e8b0206b810f6',2025,'PW','Palau','transportation',23,'National air transport system:
number of registered air carriers:
1 (2020)
inventory of registered aircraft operated by air carriers:
1
Civil aircraft registration country code prefix:
T8
Airports:
3 (2021)
comparison ranking:
total 194
Airports - with paved runways:
1
note:
paved runways have a concrete or asphalt surface but not all have facilities for refueling, maintenance, or air traffic control; the length of a runway required for aircraft to safely operate depends on a number of factors including the type of aircraft, the takeoff weight (including passengers, cargo, and fuel), engine types, flap settings, landing speed, elevation of the airport, and average maximum daily air temperature; paved runways can reach a length of 5,000 m (16,000 ft.), but the “typical” length of a commercial airline runway is between 2,500-4,000 m (8,000-13,000 ft.)
Airports - with unpaved runways:
2
note:
unpaved runways have a surface composition such as grass or packed earth and are most suited to the operation of light aircraft; unpaved runways are usually short, often less than 1,000 m (3,280 ft.) in length; airports with unpaved runways often lack facilities for refueling, maintenance, or air traffic control
Roadways:
total:
125 km (2018)
paved:
89 km (2018)
unpaved:
36 km (2018)
comparison ranking:
total 211
Merchant marine:
total:
304 (2022)
by type:
bulk carrier 29, container ship 6, general cargo 137, oil tanker 43, other 89
comparison ranking:
total 55
Ports and terminals:
major seaport(s):
Koror','c85f9e62ad8cd07b338d4d667e7b94ba4707491c102c75f28ec0f93540110665','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('345b0c08b63f6fdc8c03e70d5e01e37f6c4f9887aff17866a9ddc016e13ce4a0',2025,'PA','Panama','transportation',34,'National air transport system:
number of registered air carriers:
4 (2020)
inventory of registered aircraft operated by air carriers:
122
annual passenger traffic on registered air carriers:
12,939,350 (2018)
annual freight traffic on registered air carriers:
47.63 million (2018) mt-km
Civil aircraft registration country code prefix:
HP
Airports:
117 (2021)
comparison ranking:
total 49
Airports - with paved runways:
57
note:
paved runways have a concrete or asphalt surface but not all have facilities for refueling, maintenance, or air traffic control; the length of a runway required for aircraft to safely operate depends on a number of factors including the type of aircraft, the takeoff weight (including passengers, cargo, and fuel), engine types, flap settings, landing speed, elevation of the airport, and average maximum daily air temperature; paved runways can reach a length of 5,000 m (16,000 ft.), but the “typical” length of a commercial airline runway is between 2,500-4,000 m (8,000-13,000 ft.)
Airports - with unpaved runways:
60
note:
unpaved runways have a surface composition such as grass or packed earth and are most suited to the operation of light aircraft; unpaved runways are usually short, often less than 1,000 m (3,280 ft.) in length; airports with unpaved runways often lack facilities for refueling, maintenance, or air traffic control
Heliports:
3 (2021)
Pipelines:
128 km oil (2013)
Railways:
total:
77 km (2014)
standard gauge:
77 km (2014) 1.435-m gauge
comparison ranking:
total 129
Roadways:
total:
(2010)
paved:
(2010)
unpaved:
(2010)
Waterways:
800 km (2011) (includes the 82-km Panama Canal that is being widened)
comparison ranking:
78
Merchant marine:
total:
8,025 (2022)
by type:
bulk carrier 2,690, container ship 662, general cargo 1,418, oil tanker 785, other 2,470
comparison ranking:
total 2
Ports and terminals:
major seaport(s):
Balboa, Colon, Cristobal
container port(s) (TEUs):
Balboa (3,561,432), Colon (4,915,975) (2021)','c84560c3d4c73e9378dfd13d633d3ab7faa6692d9c1ced9adec880cce6a03a2e','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a4eeb6b2d9adc31da208218cee51b3cbbcbaff88213493949f2057c9ba4bbc11',2025,'PG','Papua New Guinea','transportation',45,'National air transport system:
number of registered air carriers:
6 (2020)
inventory of registered aircraft operated by air carriers:
48
annual passenger traffic on registered air carriers:
964,713 (2018)
annual freight traffic on registered air carriers:
30.93 million (2018) mt-km
Civil aircraft registration country code prefix:
P2
Airports:
561 (2021)
comparison ranking:
total 11
Airports - with paved runways:
21
note:
paved runways have a concrete or asphalt surface but not all have facilities for refueling, maintenance, or air traffic control; the length of a runway required for aircraft to safely operate depends on a number of factors including the type of aircraft, the takeoff weight (including passengers, cargo, and fuel), engine types, flap settings, landing speed, elevation of the airport, and average maximum daily air temperature; paved runways can reach a length of 5,000 m (16,000 ft.), but the “typical” length of a commercial airline runway is between 2,500-4,000 m (8,000-13,000 ft.)
Airports - with unpaved runways:
540
note:
unpaved runways have a surface composition such as grass or packed earth and are most suited to the operation of light aircraft; unpaved runways are usually short, often less than 1,000 m (3,280 ft.) in length; airports with unpaved runways often lack facilities for refueling, maintenance, or air traffic control
Heliports:
2 (2021)
Pipelines:
264 km oil (2013)
Roadways:
total:
9,349 km (2011)
paved:
3,000 km (2011)
unpaved:
6,349 km (2011)
comparison ranking:
total 137
Waterways:
11,000 km (2011)
comparison ranking:
14
Merchant marine:
total:
199 (2022)
by type:
container ship 6, general cargo 87, oil tanker 3, other 103
comparison ranking:
total 65
Ports and terminals:
major seaport(s):
Kimbe, Lae, Madang, Rabaul, Wewak
LNG terminal(s) (export):
Port Moresby','19dcde3e54319231588e26efb523c16829c7b185ab1f62566ed5e483a87cae63','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6a4b592fd906a815be576079bcc30e6512f4f7dcbe707be895796d8792a228af',2025,'PG','Papua New Guinea','transportation',53,'Airports:
1 (2021)
comparison ranking:
total 220
Airports - with paved runways:
1
civil airports:
0
military airports:
1 (controlled by China)
joint use (civil-military) airports:
0
other airports:
0
note 1:
paved runways have a concrete or asphalt surface but not all have facilities for refueling, maintenance, or air traffic control; the length of a runway required for aircraft to safely operate depends on a number of factors including the type of aircraft, the takeoff weight (including passengers, cargo, and fuel), engine types, flap settings, landing speed, elevation of the airport, and average maximum daily air temperature; paved runways can reach a length of 5,000 m (16,000 ft.), but the “typical” length of a commercial airline runway is between 2,500-4,000 m (8,000-13,000 ft.)
note 2:
controlled by China
Ports and terminals:
small Chinese port facilities on Woody Island and Duncan Island','48ef849aa74bb884f0c06e21bee3fa86f6f3ef7cd15aeac8c1ca6a9b6b4b93d6','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('47687c953fde2e7457418a813c104d479b5711616e6acd311f035bb591d09ed7',2025,'PY','Paraguay','transportation',64,'National air transport system:
number of registered air carriers:
2 (2020)
inventory of registered aircraft operated by air carriers:
8
annual passenger traffic on registered air carriers:
560,631 (2018)
annual freight traffic on registered air carriers:
1.97 million (2018) mt-km
Civil aircraft registration country code prefix:
ZP
Airports:
799 (2021)
comparison ranking:
total 9
Airports - with paved runways:
15
note:
paved runways have a concrete or asphalt surface but not all have facilities for refueling, maintenance, or air traffic control; the length of a runway required for aircraft to safely operate depends on a number of factors including the type of aircraft, the takeoff weight (including passengers, cargo, and fuel), engine types, flap settings, landing speed, elevation of the airport, and average maximum daily air temperature; paved runways can reach a length of 5,000 m (16,000 ft.), but the “typical” length of a commercial airline runway is between 2,500-4,000 m (8,000-13,000 ft.)
Airports - with unpaved runways:
784
note:
unpaved runways have a surface composition such as grass or packed earth and are most suited to the operation of light aircraft; unpaved runways are usually short, often less than 1,000 m (3,280 ft.) in length; airports with unpaved runways often lack facilities for refueling, maintenance, or air traffic control
Railways:
total:
30 km (2014)
standard gauge:
30 km (2014) 1.435-m gauge
comparison ranking:
total 134
Roadways:
total:
78,811 km (2020)
paved:
8,573 km (2020)
unpaved:
70,238 km (2020)
comparison ranking:
total 61
Waterways:
3,100 km (2012) (primarily on the Paraguay and Paraná River systems)
comparison ranking:
34
Merchant marine:
total:
105 (2022)
by type:
container ship 2, general cargo 24, oil tanker 5, other 74
note:
as of 2017, Paraguay registered 2,012 fluvial vessels of which 1,741 were commercial barges
comparison ranking:
total 87
Ports and terminals:
river port(s):
Asuncion, Villeta, San Antonio, Encarnacion (Parana)','2c36849e7fd30ce6d4166eb823ecb0efc9d198992fb4a34e484a5b6aa9eccc7b','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f5e4bd9ad1fe4d9b2a39eb81858cfbc3785e31ec022cc0c91e809899f1b314d7',2025,'PE','Peru','transportation',9,'National air transport system:
number of registered air carriers:
6 (2020)
inventory of registered aircraft operated by air carriers:
62
annual passenger traffic on registered air carriers:
17,758,527 (2018)
annual freight traffic on registered air carriers:
313.26 million (2018) mt-km
Civil aircraft registration country code prefix:
OB
Airports:
191 (2021)
comparison ranking:
total 31
Airports - with paved runways:
59
note:
paved runways have a concrete or asphalt surface but not all have facilities for refueling, maintenance, or air traffic control; the length of a runway required for aircraft to safely operate depends on a number of factors including the type of aircraft, the takeoff weight (including passengers, cargo, and fuel), engine types, flap settings, landing speed, elevation of the airport, and average maximum daily air temperature; paved runways can reach a length of 5,000 m (16,000 ft.), but the “typical” length of a commercial airline runway is between 2,500-4,000 m (8,000-13,000 ft.)
Airports - with unpaved runways:
132
note:
unpaved runways have a surface composition such as grass or packed earth and are most suited to the operation of light aircraft; unpaved runways are usually short, often less than 1,000 m (3,280 ft.) in length; airports with unpaved runways often lack facilities for refueling, maintenance, or air traffic control
Heliports:
5 (2021)
Pipelines:
786 km extra heavy crude, 1,526 km gas, 679 km liquid petroleum gas, 1,106 km oil, 15 km refined products (2022)
Railways:
total:
1,854.4 km (2017)
standard gauge:
1,730.4 km (2014) 1.435-m gauge (34 km electrified)
narrow gauge:
124 km (2014) 0.914-m gauge
comparison ranking:
total 75
Roadways:
total:
18,699 km (2018)
paved:
18,699 km
note:
includes 27,109 km of national roads (21,434 km paved), 247,505 km of departmental roads (3,623 km paved), and 113,857 km of local roads (1,858 km paved)
comparison ranking:
total 117
Waterways:
8,808 km (2011) (8,600 km of navigable tributaries on the Amazon River system and 208 km on Lago Titicaca)
comparison ranking:
16
Merchant marine:
total:
101 (2022)
by type:
general cargo 1, oil tanker 8, other 92
comparison ranking:
total 90
Ports and terminals:
major seaport(s):
Callao, Matarani, Paita
oil terminal(s):
Conchan oil terminal, La Pampilla oil terminal
container port(s) (TEUs):
Balboa (3,563,432); Callao (2,486,425) (2021)
river port(s):
Iquitos, Pucallpa, Yurimaguas (Amazon)','bb92e44c2df859060f5a152c0b15916323a74b9a97d3937f3dd927997d277014','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('248b85a66cae23c9be4909222eff75865bc2c008e1231fca1af3435e41343c7b',2025,'PH','Philippines','transportation',22,'National air transport system:
number of registered air carriers:
13 (2020)
inventory of registered aircraft operated by air carriers:
200
annual passenger traffic on registered air carriers:
43,080,118 (2018)
annual freight traffic on registered air carriers:
835.9 million (2018) mt-km
Civil aircraft registration country code prefix:
RP
Airports:
247 (2021)
comparison ranking:
total 24
Airports - with paved runways:
89
civil airports:
11
military airports:
4
joint use (civil-military) airports:
2
other airports:
72
note:
paved runways have a concrete or asphalt surface but not all have facilities for refueling, maintenance, or air traffic control; the length of a runway required for aircraft to safely operate depends on a number of factors including the type of aircraft, the takeoff weight (including passengers, cargo, and fuel), engine types, flap settings, landing speed, elevation of the airport, and average maximum daily air temperature; paved runways can reach a length of 5,000 m (16,000 ft.), but the “typical” length of a commercial airline runway is between 2,500-4,000 m (8,000-13,000 ft.)
Airports - with unpaved runways:
158
note:
unpaved runways have a surface composition such as grass or packed earth and are most suited to the operation of light aircraft; unpaved runways are usually short, often less than 1,000 m (3,280 ft.) in length; airports with unpaved runways often lack facilities for refueling, maintenance, or air traffic control
Heliports:
2 (2021)
Pipelines:
530 km gas, 138 km oil (non-operational), 185 km refined products (2017)
Railways:
total:
77 km (2017)
standard gauge:
49 km (2017) 1.435-m gauge
narrow gauge:
28 km (2017) 1.067-m gauge
comparison ranking:
total 130
Roadways:
total:
216,387 km (2014)
paved:
61,093 km (2014)
unpaved:
155,294 km (2014)
comparison ranking:
total 25
Waterways:
3,219 km (2011) (limited to vessels with draft less than 1.5 m)
comparison ranking:
32
Merchant marine:
total:
1,853 (2022)
by type:
bulk carrier 59, container ship 43, general cargo 749, oil tanker 210, other 792
comparison ranking:
total 14
Ports and terminals:
major seaport(s):
Batangas, Cagayan de Oro, Cebu, Davao, Liman, Manila
container port(s) (TEUs):
Manila (4,976,014) (2021)
LNG terminal(s) (import):
Batangas','d7ba33a703ed98a89cd1cfb9b7202f3017b1d875300c1cec30ae2dbde879f8e7','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('590364e9e52d0c5c666d86e77307e430cc8cf90779413fe636ec9b7278286013',2025,'PH','Philippines','transportation',34,'Ports and terminals:
major seaport(s):
Adamstown (on Bounty Bay)','3ef478b4b74eac5b4fd1b470dd06afef3f376806064879237c13ddbb55048cd1','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('381bf56cbc9074b1052a6e047cf3be8a9d9a3c3354c4a1c75d401434b1cc3e98',2025,'PL','Poland','transportation',45,'National air transport system:
number of registered air carriers:
6 (2020)
inventory of registered aircraft operated by air carriers:
169
annual passenger traffic on registered air carriers:
9,277,538 (2018)
annual freight traffic on registered air carriers:
271.49 million (2018) mt-km
Civil aircraft registration country code prefix:
SP
Airports:
126 (2021)
comparison ranking:
total 46
Airports - with paved runways:
87
civil airports:
13
military airports:
13
joint use (civil-military) airports:
0
other airports:
61
note:
paved runways have a concrete or asphalt surface but not all have facilities for refueling, maintenance, or air traffic control; the length of a runway required for aircraft to safely operate depends on a number of factors including the type of aircraft, the takeoff weight (including passengers, cargo, and fuel), engine types, flap settings, landing speed, elevation of the airport, and average maximum daily air temperature; paved runways can reach a length of 5,000 m (16,000 ft.), but the “typical” length of a commercial airline runway is between 2,500-4,000 m (8,000-13,000 ft.)
Airports - with unpaved runways:
39
note:
unpaved runways have a surface composition such as grass or packed earth and are most suited to the operation of light aircraft; unpaved runways are usually short, often less than 1,000 m (3,280 ft.) in length; airports with unpaved runways often lack facilities for refueling, maintenance, or air traffic control
Heliports:
6 (2021)
Pipelines:
14,198 km gas, 1,374 km oil, 2,483 km refined products (2018)
Railways:
total:
19,461 km (2020) 11,946 km electrified
comparison ranking:
total 14
Roadways:
total:
420,000 km (2016)
paved:
291,000 km (2016) (includes 1,492 km of expressways, 1,559 of motorways)
unpaved:
129,000 km (2016)
comparison ranking:
total 18
Waterways:
3,997 km (2009) (navigable rivers and canals)
comparison ranking:
29
Merchant marine:
total:
149 (2022)
by type:
general cargo 7, oil tanker 6, other 136
comparison ranking:
total 73
Ports and terminals:
major seaport(s):
Gdansk, Gdynia, Swinoujscie
container port(s) (TEUs):
Gdansk (2,117,829) (2021)
LNG terminal(s) (import):
Swinoujscie
river port(s):
Szczecin (River Oder)','dbf7cea29fc81fea542a087bf533d25e8cdfb4c6b7b236f433feb12b1b08a61c','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('100980d6ce6e3cbbed56985c4d36a532ea5aed4e6e091a85cbbae9797a8b8b31',2025,'PT','Portugal','transportation',58,'National air transport system:
number of registered air carriers:
10 (2020)
inventory of registered aircraft operated by air carriers:
168
annual passenger traffic on registered air carriers:
17,367,956 (2018)
annual freight traffic on registered air carriers:
454.21 million (2018) mt-km
Civil aircraft registration country code prefix:
CR, CS
Airports:
64 (2021)
comparison ranking:
total 76
Airports - with paved runways:
43
note:
paved runways have a concrete or asphalt surface but not all have facilities for refueling, maintenance, or air traffic control; the length of a runway required for aircraft to safely operate depends on a number of factors including the type of aircraft, the takeoff weight (including passengers, cargo, and fuel), engine types, flap settings, landing speed, elevation of the airport, and average maximum daily air temperature; paved runways can reach a length of 5,000 m (16,000 ft.), but the “typical” length of a commercial airline runway is between 2,500-4,000 m (8,000-13,000 ft.)
Airports - with unpaved runways:
21
note:
unpaved runways have a surface composition such as grass or packed earth and are most suited to the operation of light aircraft; unpaved runways are usually short, often less than 1,000 m (3,280 ft.) in length; airports with unpaved runways often lack facilities for refueling, maintenance, or air traffic control
Pipelines:
1,344 km gas, 11 km oil, 188 km refined products (2013)
Railways:
total:
2,526 km (2020) 1,696 km electrified
comparison ranking:
total 65
Roadways:
total:
82,900 km (2008)
paved:
71,294 km (2008) (includes 2,613 km of expressways)
unpaved:
11,606 km (2008)
comparison ranking:
total 59
Waterways:
210 km (2011) (on Douro River from Porto)
comparison ranking:
105
Merchant marine:
total:
820 (2022)
by type:
bulk carrier 103, container ship 290, general cargo 175, oil tanker 28, other 224
comparison ranking:
total 30
Ports and terminals:
major seaport(s):
Leixoes, Lisbon, Setubal, Sines
container port(s) (TEUs):
Sines (1,420,000) (2019)
LNG terminal(s) (import):
Sines','3982ad891a56bc483623e41f60310f35c5a3433e4c9ec59ce0ea619a8f7f6c72','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('97ca614b6fa7a0311019b5d70e625142bd8933949837a664c6d7ad92166aa77d',2025,'PR','Puerto Rico','transportation',71,'Airports:
29 (2021)
comparison ranking:
total 117
Airports - with paved runways:
17
note:
paved runways have a concrete or asphalt surface but not all have facilities for refueling, maintenance, or air traffic control; the length of a runway required for aircraft to safely operate depends on a number of factors including the type of aircraft, the takeoff weight (including passengers, cargo, and fuel), engine types, flap settings, landing speed, elevation of the airport, and average maximum daily air temperature; paved runways can reach a length of 5,000 m (16,000 ft.), but the “typical” length of a commercial airline runway is between 2,500-4,000 m (8,000-13,000 ft.)
Airports - with unpaved runways:
12
note:
unpaved runways have a surface composition such as grass or packed earth and are most suited to the operation of light aircraft; unpaved runways are usually short, often less than 1,000 m (3,280 ft.) in length; airports with unpaved runways often lack facilities for refueling, maintenance, or air traffic control
Roadways:
total:
26,862 km (2012) (includes 454 km of expressways)
comparison ranking:
total 101
Ports and terminals:
major seaport(s):
Ensenada Honda, Mayaguez, Playa de Guayanilla, Playa de Ponce, San Juan
container port(s) (TEUs):
San Juan (1,438,218) (2021)
LNG terminal(s) (import):
Guayanilla Bay','96fdf2222c6451f3c199c3df2e2d84bd52b6114bf57e134417abd2b4f7367d6f','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2b2c744ffd537f2e1db86310837102e995d814ca095080a0e20f48ec19e9aa34',2025,'QA','Qatar','transportation',9,'National air transport system:
number of registered air carriers:
3 (2020)
inventory of registered aircraft operated by air carriers:
251
annual passenger traffic on registered air carriers:
29,178,923 (2018)
annual freight traffic on registered air carriers:
12,666,710,000 (2018) mt-km
Civil aircraft registration country code prefix:
A7
Airports:
6 (2021)
comparison ranking:
total 173
Airports - with paved runways:
4
note:
paved runways have a concrete or asphalt surface but not all have facilities for refueling, maintenance, or air traffic control; the length of a runway required for aircraft to safely operate depends on a number of factors including the type of aircraft, the takeoff weight (including passengers, cargo, and fuel), engine types, flap settings, landing speed, elevation of the airport, and average maximum daily air temperature; paved runways can reach a length of 5,000 m (16,000 ft.), but the “typical” length of a commercial airline runway is between 2,500-4,000 m (8,000-13,000 ft.)
Airports - with unpaved runways:
2
note:
unpaved runways have a surface composition such as grass or packed earth and are most suited to the operation of light aircraft; unpaved runways are usually short, often less than 1,000 m (3,280 ft.) in length; airports with unpaved runways often lack facilities for refueling, maintenance, or air traffic control
Heliports:
1 (2021)
Pipelines:
288 km condensate, 221 km condensate/gas, 2,383 km gas, 90 km liquid petroleum gas, 745 km oil, 103 km refined products (2013)
Roadways:
total:
7,039 km (2016)
comparison ranking:
total 142
Merchant marine:
total:
123 (2022)
by type:
bulk carrier 6, container ship 4, general cargo 4, oil tanker 3, other 106
comparison ranking:
total 81
Ports and terminals:
major seaport(s):
Doha, Musay’id, Ra’s Laffan
LNG terminal(s) (export):
Ras Laffan','59725f821c1119845f2575f39a348836065c8342fdb4afbae52912bef5d9e66d','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('64d850499bd7912e853d7b3b928e894a440a801365ef0dad5e291549116e683f',2025,'RO','Romania','transportation',9,'National air transport system:
number of registered air carriers:
8 (2020)
inventory of registered aircraft operated by air carriers:
60
annual passenger traffic on registered air carriers:
4,908,235 (2018)
annual freight traffic on registered air carriers:
2.71 million (2018) mt-km
Civil aircraft registration country code prefix:
YR
Airports:
45 (2021)
comparison ranking:
total 95
Airports - with paved runways:
26
note:
paved runways have a concrete or asphalt surface but not all have facilities for refueling, maintenance, or air traffic control; the length of a runway required for aircraft to safely operate depends on a number of factors including the type of aircraft, the takeoff weight (including passengers, cargo, and fuel), engine types, flap settings, landing speed, elevation of the airport, and average maximum daily air temperature; paved runways can reach a length of 5,000 m (16,000 ft.), but the “typical” length of a commercial airline runway is between 2,500-4,000 m (8,000-13,000 ft.)
Airports - with unpaved runways:
19
note:
unpaved runways have a surface composition such as grass or packed earth and are most suited to the operation of light aircraft; unpaved runways are usually short, often less than 1,000 m (3,280 ft.) in length; airports with unpaved runways often lack facilities for refueling, maintenance, or air traffic control
Heliports:
2 (2021)
Pipelines:
3,726 km gas, 2,451 km oil (2013)
Railways:
total:
10,628 km (2020) 4,030 km electrified
comparison ranking:
total 23
Roadways:
total:
84,185 km (2012)
paved:
49,873 km (2012) (includes 337 km of expressways)
unpaved:
34,312 km (2012)
comparison ranking:
total 57
Waterways:
1,731 km (2010) (includes 1,075 km on the Danube River, 524 km on secondary branches, and 132 km on canals)
comparison ranking:
47
Merchant marine:
total:
125 (2022)
by type:
general cargo 11, oil tanker 6, other 108
comparison ranking:
total 80
Ports and terminals:
major seaport(s):
Constanta, Midia
river port(s):
Braila, Galati (Galatz), Mancanului (Giurgiu), Tulcea (Danube River)','d115cfacab1b008e09427e31d05afa5d10f77ef675ebf14637a89358f68bf4e6','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('46582cdc63e7bd288ca76575630ba48b3c4d4ed46295e9834694dc50cf6c18bf',2025,'RO','Romania','transportation',22,'National air transport system:
number of registered air carriers:
32 (2020)
inventory of registered aircraft operated by air carriers:
958
annual passenger traffic on registered air carriers:
99,327,311 (2018)
annual freight traffic on registered air carriers:
6,810,610,000 (2018) mt-km
Civil aircraft registration country code prefix:
RA
Airports:
1,218 (2021)
comparison ranking:
total 5
Airports - with paved runways:
594
civil airports:
93
military airports:
105
joint use (civil-military) airports:
28
other airports:
368
note:
paved runways have a concrete or asphalt surface but not all have facilities for refueling, maintenance, or air traffic control; the length of a runway required for aircraft to safely operate depends on a number of factors including the type of aircraft, the takeoff weight (including passengers, cargo, and fuel), engine types, flap settings, landing speed, elevation of the airport, and average maximum daily air temperature; paved runways can reach a length of 5,000 m (16,000 ft.), but the “typical” length of a commercial airline runway is between 2,500-4,000 m (8,000-13,000 ft.)
Airports - with unpaved runways:
624
note:
unpaved runways have a surface composition such as grass or packed earth and are most suited to the operation of light aircraft; unpaved runways are usually short, often less than 1,000 m (3,280 ft.) in length; airports with unpaved runways often lack facilities for refueling, maintenance, or air traffic control
Heliports:
49 (2021)
Pipelines:
177,700 km gas, 54,800 km oil, 19,300 km refined products (2017)
Railways:
total:
85,494 km (2019)
narrow gauge:
957 km
comparison ranking:
total 3
Roadways:
total:
1,283,387 km (2012)
paved:
927,721 km (2012) (includes 39,143 km of expressways)
unpaved:
355,666 km (2012)
comparison ranking:
total 5
Waterways:
102,000 km (2009) (including 48,000 km with guaranteed depth; the 72,000-km system in European Russia links Baltic Sea, White Sea, Caspian Sea, Sea of Azov, and Black Sea)
comparison ranking:
1
Merchant marine:
total:
2,917 (2022)
by type:
bulk carrier 12, container ship 18, general cargo 987, oil tanker 392, other 1,508
comparison ranking:
total 8
Ports and terminals:
major seaport(s):
Arctic Ocean:
Arkhangelsk, Murmansk
Baltic Sea:
Kaliningrad, Primorsk, Saint Petersburg
Black Sea:
Novorossiysk
Pacific Ocean:
Nakhodka, Vladivostok, Vostochnyy
oil terminal(s):
Kavkaz oil terminal, Primorsk
container port(s) (TEUs):
Saint Petersburg (2,042,358) (2021)
LNG terminal(s) (export):
Sabetta, Sakhalin Island
river port(s):
Astrakhan, Kazan (Volga River); Rostov-on-Don (Don River); Saint Petersburg (Neva River)
Transportation - note:
Russia operates the largest polar class icebreaker fleet in the World with 52 vessels, including the World’s only seven nuclear powered heavy icebreakers; the primary missions of Russia’s fleet includes keeping open the Northern Sea Route (NSR) in the Arctic Ocean (see Arctic Ocean map) along with Russia’s Arctic ports and terminals, maintaining shipping lanes in the Baltic Sea, and supporting ports, terminals, and shipping in the Russian Far East including the Sea of Okhotsk; Russia operates seven PC 1 or 2 heavy icebreakers, 31 PC 3 or 4 medium icebreakers, and 14 PC 5 or 6 light icebreakers
note - PC indicates a Polar Class vessel:
PC 1 - year-round operation in all polar waters (ice thickness >3 m); PC 2 - year-round operation in moderate multi-year ice conditions (ice thickness up to 3 m); PC 3 - year-round operation in second-year ice which may include multi-year ice inclusions (ice thickness up to 2.5 m); PC 4 - year-round operation in thick first-year ice which may include old ice inclusions (ice thickness up to 120 cm); PC 5 - year-round operation in medium first-year ice which may include old ice inclusions (ice thickness up to 70-120 cm); PC 6 - summer/autumn operation in medium first-year ice which may include old ice inclusions (ice thickness up to 30-70 cm)','79a2570dcbdfad73ff2d104e8fad331f1306d49f735411dbd249e071f5d96285','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fd59025fc53407c5f5bdba505d2f88353cfadad5fab7ecc39e5f205479f9420e',2025,'RW','Rwanda','transportation',35,'National air transport system:
number of registered air carriers:
1 (2020)
inventory of registered aircraft operated by air carriers:
12
annual passenger traffic on registered air carriers:
1,073,528 (2018)
Civil aircraft registration country code prefix:
9XR
Airports:
7 (2021)
comparison ranking:
total 167
Airports - with paved runways:
4
note:
paved runways have a concrete or asphalt surface but not all have facilities for refueling, maintenance, or air traffic control; the length of a runway required for aircraft to safely operate depends on a number of factors including the type of aircraft, the takeoff weight (including passengers, cargo, and fuel), engine types, flap settings, landing speed, elevation of the airport, and average maximum daily air temperature; paved runways can reach a length of 5,000 m (16,000 ft.), but the “typical” length of a commercial airline runway is between 2,500-4,000 m (8,000-13,000 ft.)
Airports - with unpaved runways:
3
note:
unpaved runways have a surface composition such as grass or packed earth and are most suited to the operation of light aircraft; unpaved runways are usually short, often less than 1,000 m (3,280 ft.) in length; airports with unpaved runways often lack facilities for refueling, maintenance, or air traffic control
Roadways:
total:
4,700 km (2012)
paved:
1,207 km (2012)
unpaved:
3,493 km (2012)
comparison ranking:
total 148
Waterways:
90 km (2022) (Lake Kivu navigable by shallow-draft barges and native craft)
comparison ranking:
112
Ports and terminals:
lake port(s):
Cyangugu, Gisenyi, Kibuye (Lake Kivu)','a69e8803704d468badf894bb76d5798c2137f8e1edba23f8669ef0d4a918c70a','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e4cfc108792545d66ac869569278a58ad63b69e17d2b4ca1e9464fc420abcfde',2025,'KN','Saint Kitts and Nevis','transportation',11,'Civil aircraft registration country code prefix:
V4
Airports:
2 (2021)
comparison ranking:
total 204
Airports - with paved runways:
2
note:
paved runways have a concrete or asphalt surface but not all have facilities for refueling, maintenance, or air traffic control; the length of a runway required for aircraft to safely operate depends on a number of factors including the type of aircraft, the takeoff weight (including passengers, cargo, and fuel), engine types, flap settings, landing speed, elevation of the airport, and average maximum daily air temperature; paved runways can reach a length of 5,000 m (16,000 ft.), but the “typical” length of a commercial airline runway is between 2,500-4,000 m (8,000-13,000 ft.)
Railways:
total:
50 km (2008)
narrow gauge:
50 km (2008) 0.762-m gauge on Saint Kitts for tourists
comparison ranking:
total 133
Roadways:
total:
383 km (2002)
paved:
163 km (2002)
unpaved:
220 km (2002)
comparison ranking:
total 200
Merchant marine:
total:
282 (2022)
by type:
bulk carrier 9, container ship 11, general cargo 64, oil tanker 46, other 152
comparison ranking:
total 56
Ports and terminals:
major seaport(s):
Basseterre, Charlestown','f861c8d305c6a17ef9020fde9292ecec0a5a43430766b2224ac98de7d4174e20','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('61dbaae20e060e4dc2ce55869ba6e6db8b226ba89d66008bcd7cf11f3b88b6ca',2025,'LC','Saint Lucia','transportation',22,'Civil aircraft registration country code prefix:
J6
Airports:
2 (2021)
comparison ranking:
total 203
Airports - with paved runways:
2
note:
paved runways have a concrete or asphalt surface but not all have facilities for refueling, maintenance, or air traffic control; the length of a runway required for aircraft to safely operate depends on a number of factors including the type of aircraft, the takeoff weight (including passengers, cargo, and fuel), engine types, flap settings, landing speed, elevation of the airport, and average maximum daily air temperature; paved runways can reach a length of 5,000 m (16,000 ft.), but the “typical” length of a commercial airline runway is between 2,500-4,000 m (8,000-13,000 ft.)
Roadways:
total:
1,210 km (2011)
paved:
847 km (2011)
unpaved:
363 km (2011)
comparison ranking:
total 179
Ports and terminals:
major seaport(s):
Castries, Cul-de-Sac, Vieux-Fort','3528c26cbee13e98dde18b29c8870c7e024fc2b4f623d6a841d23b6ef3d0fbc6','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4706610d27e5d4b555426776caed78c195d826644c95b4fe6039b7ce2aa1b4fa',2025,'LC','Saint Lucia','transportation',33,'Airports:
1 (2021)
comparison ranking:
total 234
Airports - with paved runways:
1
note:
paved runways have a concrete or asphalt surface but not all have facilities for refueling, maintenance, or air traffic control; the length of a runway required for aircraft to safely operate depends on a number of factors including the type of aircraft, the takeoff weight (including passengers, cargo, and fuel), engine types, flap settings, landing speed, elevation of the airport, and average maximum daily air temperature; paved runways can reach a length of 5,000 m (16,000 ft.), but the “typical” length of a commercial airline runway is between 2,500-4,000 m (8,000-13,000 ft.)
Transportation - note:
nearest airport for international flights is Princess Juliana International Airport (SXM) located on Sint Maarten','23e1b30eb838f6a4ef371dd2b8155cdfdfe70b3acd3bc68b7927c614fdad9f29','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7477bf2b8ab8969a37c416c65858e874dece77feec612d41468660694fec8eb7',2025,'PM','Saint Pierre and Miquelon','transportation',44,'Airports:
2 (2021)
comparison ranking:
total 202
Airports - with paved runways:
2
note:
paved runways have a concrete or asphalt surface but not all have facilities for refueling, maintenance, or air traffic control; the length of a runway required for aircraft to safely operate depends on a number of factors including the type of aircraft, the takeoff weight (including passengers, cargo, and fuel), engine types, flap settings, landing speed, elevation of the airport, and average maximum daily air temperature; paved runways can reach a length of 5,000 m (16,000 ft.), but the “typical” length of a commercial airline runway is between 2,500-4,000 m (8,000-13,000 ft.)
Roadways:
total:
117 km (2009)
paved:
80 km (2009)
unpaved:
37 km (2009)
comparison ranking:
total 213
Ports and terminals:
major seaport(s):
Saint-Pierre','4292a86af3ea6537a2430635d1a855ce77bffaaf699171901a78b35a440785b7','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4a7ddbe55bb2ffd0c0c13419a293ccddd4622676929422bf4554173590288c76',2025,'VC','Saint Vincent and the Grenadines','transportation',55,'National air transport system:
number of registered air carriers:
2 (2020)
inventory of registered aircraft operated by air carriers:
11
Civil aircraft registration country code prefix:
J8
Airports:
6 (2021)
comparison ranking:
total 175
Airports - with paved runways:
5
note:
paved runways have a concrete or asphalt surface but not all have facilities for refueling, maintenance, or air traffic control; the length of a runway required for aircraft to safely operate depends on a number of factors including the type of aircraft, the takeoff weight (including passengers, cargo, and fuel), engine types, flap settings, landing speed, elevation of the airport, and average maximum daily air temperature; paved runways can reach a length of 5,000 m (16,000 ft.), but the “typical” length of a commercial airline runway is between 2,500-4,000 m (8,000-13,000 ft.)
Airports - with unpaved runways:
1
note:
unpaved runways have a surface composition such as grass or packed earth and are most suited to the operation of light aircraft; unpaved runways are usually short, often less than 1,000 m (3,280 ft.) in length; airports with unpaved runways often lack facilities for refueling, maintenance, or air traffic control
Merchant marine:
total:
832 (2022)
by type:
bulk carrier 32, container ship 17, general cargo 148, oil tanker 14, other 621
comparison ranking:
total 28
Ports and terminals:
major seaport(s):
Kingstown','667b31c5a970559dc4f32211b0dc97df1a86464b1f59af7fdd991b979aedffba','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8c19536cf12e64fa8001d5551dc861707f0151888e1092a4bc24b6a842fe6b51',2025,'WS','Samoa','transportation',66,'National air transport system:
number of registered air carriers:
1 (2020)
inventory of registered aircraft operated by air carriers:
4
annual passenger traffic on registered air carriers:
137,770 (2018)
Civil aircraft registration country code prefix:
5W
Airports:
4 (2021)
comparison ranking:
total 183
Airports - with paved runways:
1
note:
paved runways have a concrete or asphalt surface but not all have facilities for refueling, maintenance, or air traffic control; the length of a runway required for aircraft to safely operate depends on a number of factors including the type of aircraft, the takeoff weight (including passengers, cargo, and fuel), engine types, flap settings, landing speed, elevation of the airport, and average maximum daily air temperature; paved runways can reach a length of 5,000 m (16,000 ft.), but the “typical” length of a commercial airline runway is between 2,500-4,000 m (8,000-13,000 ft.)
Airports - with unpaved runways:
3
note:
unpaved runways have a surface composition such as grass or packed earth and are most suited to the operation of light aircraft; unpaved runways are usually short, often less than 1,000 m (3,280 ft.) in length; airports with unpaved runways often lack facilities for refueling, maintenance, or air traffic control
Roadways:
total:
1,150 km (2018)
comparison ranking:
total 181
Merchant marine:
total:
15 (2022)
by type:
general cargo 3, oil tanker 5, other 7
comparison ranking:
total 152
Ports and terminals:
major seaport(s):
Apia','a17c0975185bb9080dbe285adf3f839eac02fec7b288d8bce47925f0a777a7ea','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b6fff4609b69659190b88d93023532c92f1777eb47d7da6b48832fccf1e35f29',2025,'SM','San Marino','transportation',9,'Civil aircraft registration country code prefix:
T7
Roadways:
total:
292 km (2006)
paved:
292 km (2006)
comparison ranking:
total 203','de67780f5ddde3ec1fe0294080969578f1794e93cd8f4193bc75577daae162af','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a143a33b3ec445119c5aa2c72f59bc43a55694e7f23f37db9aac5fc208033ed4',2025,'ST','Sao Tome and Principe','transportation',20,'National air transport system:
number of registered air carriers:
1 (2020)
inventory of registered aircraft operated by air carriers:
1
Civil aircraft registration country code prefix:
S9
Airports:
2 (2021)
comparison ranking:
total 200
Airports - with paved runways:
2
note:
paved runways have a concrete or asphalt surface but not all have facilities for refueling, maintenance, or air traffic control; the length of a runway required for aircraft to safely operate depends on a number of factors including the type of aircraft, the takeoff weight (including passengers, cargo, and fuel), engine types, flap settings, landing speed, elevation of the airport, and average maximum daily air temperature; paved runways can reach a length of 5,000 m (16,000 ft.), but the “typical” length of a commercial airline runway is between 2,500-4,000 m (8,000-13,000 ft.)
Roadways:
total:
1,300 km (2018)
paved:
230 km (2018)
unpaved:
1,070 km (2018)
comparison ranking:
total 177
Merchant marine:
total:
25 (2022)
by type:
general cargo 15, oil tanker 2, other 8
comparison ranking:
total 141
Ports and terminals:
major seaport(s):
Sao Tome','043212b3f109d8f52a920a249ca0074a133fcf881497c511bfe6b4ae62039729','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1798e06c926a18bcb40af589ca2506b6e3f4662c1283aa29bd961d1ce5f27913',2025,'SA','Saudi Arabia','transportation',31,'National air transport system:
number of registered air carriers:
12 (2020)
inventory of registered aircraft operated by air carriers:
230
annual passenger traffic on registered air carriers:
39,141,660 (2018)
annual freight traffic on registered air carriers:
1,085,470,000 (2018) mt-km
Civil aircraft registration country code prefix:
HZ
Airports:
214 (2021)
comparison ranking:
total 27
Airports - with paved runways:
82
civil airports:
17
military airports:
10
joint use (civil-military) airports:
6
other airports:
49
note:
paved runways have a concrete or asphalt surface but not all have facilities for refueling, maintenance, or air traffic control; the length of a runway required for aircraft to safely operate depends on a number of factors including the type of aircraft, the takeoff weight (including passengers, cargo, and fuel), engine types, flap settings, landing speed, elevation of the airport, and average maximum daily air temperature; paved runways can reach a length of 5,000 m (16,000 ft.), but the “typical” length of a commercial airline runway is between 2,500-4,000 m (8,000-13,000 ft.)
Airports - with unpaved runways:
132
note:
unpaved runways have a surface composition such as grass or packed earth and are most suited to the operation of light aircraft; unpaved runways are usually short, often less than 1,000 m (3,280 ft.) in length; airports with unpaved runways often lack facilities for refueling, maintenance, or air traffic control
Heliports:
10 (2021)
Pipelines:
209 km condensate, 2,940 km gas, 1,183 km liquid petroleum gas, 5,117 km oil, 1,151 km refined products (2013)
Railways:
total:
5,410 km (2016)
standard gauge:
5,410 km (2016) 1.435-m gauge (with branch lines and sidings)
comparison ranking:
total 35
Roadways:
total:
221,372 km (2006)
paved:
47,529 km (2006) (includes 3,891 km of expressways)
unpaved:
173,843 km (2006)
comparison ranking:
total 24
Merchant marine:
total:
413 (2022)
by type:
bulk carrier 6, container ship 1, general cargo 21, oil tanker 58, other 327
comparison ranking:
total 46
Ports and terminals:
major seaport(s):
Ad Dammam, Al Jubayl, Jeddah, King Abdulla, Yanbu’
container port(s) (TEUs):
Ad Dammam (1,770,000), Jeddah (4,882,342), King Abdulla (2,813,920) (2021)','c44a29b41b96d9b5a95b7961c431aac791af318b1f092c28a3d32c1d0a4f469a','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ce3ab97c2f1261c612edb5d3748416a621145ee5e42b31f2c32c32f877ff4407',2025,'SN','Senegal','transportation',44,'National air transport system:
number of registered air carriers:
2 (2020)
inventory of registered aircraft operated by air carriers:
11
annual passenger traffic on registered air carriers:
21,038 (2018)
annual freight traffic on registered air carriers:
40,000 (2018) mt-km
Civil aircraft registration country code prefix:
6V
Airports:
20 (2021)
comparison ranking:
total 135
Airports - with paved runways:
9
note:
paved runways have a concrete or asphalt surface but not all have facilities for refueling, maintenance, or air traffic control; the length of a runway required for aircraft to safely operate depends on a number of factors including the type of aircraft, the takeoff weight (including passengers, cargo, and fuel), engine types, flap settings, landing speed, elevation of the airport, and average maximum daily air temperature; paved runways can reach a length of 5,000 m (16,000 ft.), but the “typical” length of a commercial airline runway is between 2,500-4,000 m (8,000-13,000 ft.)
Airports - with unpaved runways:
11
note:
unpaved runways have a surface composition such as grass or packed earth and are most suited to the operation of light aircraft; unpaved runways are usually short, often less than 1,000 m (3,280 ft.) in length; airports with unpaved runways often lack facilities for refueling, maintenance, or air traffic control
Pipelines:
43 km gas, 8 km refined products (2017)
Railways:
total:
906 km (2017) (713 km operational in 2017)
narrow gauge:
906 km (2017) 1.000-m gauge
comparison ranking:
total 93
Roadways:
total:
16,665 km (2017)
paved:
6,126 km (2017) (includes 241 km of expressways)
unpaved:
10,539 km (2017)
comparison ranking:
total 119
Waterways:
1,000 km (2012) (primarily on the Senegal, Saloum, and Casamance Rivers)
comparison ranking:
68
Merchant marine:
total:
35 (2022)
by type:
general cargo 5, oil tanker 1, other 29
comparison ranking:
total 129
Ports and terminals:
major seaport(s):
Dakar','8110401e0f0e7c5d835a7275079fcac0589252cd3e12d69497e9137b1113dcf6','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f831870c8f6cecb58fbe726b6778df9e020594e325b31824b4a19923be50d602',2025,'RS','Serbia','transportation',56,'National air transport system:
number of registered air carriers:
4 (2020)
inventory of registered aircraft operated by air carriers:
43
annual passenger traffic on registered air carriers:
2,262,703 (2018)
annual freight traffic on registered air carriers:
17.71 million (2018) mt-km
Civil aircraft registration country code prefix:
YU
Airports:
26 (2021)
comparison ranking:
total 126
Airports - with paved runways:
10
note:
paved runways have a concrete or asphalt surface but not all have facilities for refueling, maintenance, or air traffic control; the length of a runway required for aircraft to safely operate depends on a number of factors including the type of aircraft, the takeoff weight (including passengers, cargo, and fuel), engine types, flap settings, landing speed, elevation of the airport, and average maximum daily air temperature; paved runways can reach a length of 5,000 m (16,000 ft.), but the “typical” length of a commercial airline runway is between 2,500-4,000 m (8,000-13,000 ft.)
Airports - with unpaved runways:
16
note:
unpaved runways have a surface composition such as grass or packed earth and are most suited to the operation of light aircraft; unpaved runways are usually short, often less than 1,000 m (3,280 ft.) in length; airports with unpaved runways often lack facilities for refueling, maintenance, or air traffic control
Heliports:
2 (2021)
Pipelines:
1,936 km gas, 413 km oil
Railways:
total:
3,333 km (2020) 1,274 km electrified
comparison ranking:
total 56
Roadways:
total:
44,248 km (2016)
paved:
28,000 km (2016) (16,162 km state roads, out of which 741 km highways)
unpaved:
16,248 km (2016)
comparison ranking:
total 85
Waterways:
587 km (2009) (primarily on the Danube and Sava Rivers)
comparison ranking:
87
Ports and terminals:
river port(s):
Belgrade (Danube)','3971212d87df82744d4fc2ba9ad236a084176801c3bb4442879e011c8e84d10b','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3983cb10fd5ddfc96a44b5465db1043b5c95606fea6fa129a1ea92e70fd1d2f4',2025,'SC','Seychelles','transportation',9,'National air transport system:
number of registered air carriers:
1 (2020)
inventory of registered aircraft operated by air carriers:
7
annual passenger traffic on registered air carriers:
455,201 (2018)
annual freight traffic on registered air carriers:
7.79 million (2018) mt-km
Civil aircraft registration country code prefix:
S7
Airports:
14 (2021)
comparison ranking:
total 150
Airports - with paved runways:
7
note:
paved runways have a concrete or asphalt surface but not all have facilities for refueling, maintenance, or air traffic control; the length of a runway required for aircraft to safely operate depends on a number of factors including the type of aircraft, the takeoff weight (including passengers, cargo, and fuel), engine types, flap settings, landing speed, elevation of the airport, and average maximum daily air temperature; paved runways can reach a length of 5,000 m (16,000 ft.), but the “typical” length of a commercial airline runway is between 2,500-4,000 m (8,000-13,000 ft.)
Airports - with unpaved runways:
7
note:
unpaved runways have a surface composition such as grass or packed earth and are most suited to the operation of light aircraft; unpaved runways are usually short, often less than 1,000 m (3,280 ft.) in length; airports with unpaved runways often lack facilities for refueling, maintenance, or air traffic control
Heliports:
1 (2021)
Roadways:
total:
526 km (2015)
paved:
514 km (2015)
unpaved:
12 km (2015)
comparison ranking:
total 196
Merchant marine:
total:
31 (2022)
by type:
general cargo 6, oil tanker 7, other 18
comparison ranking:
total 132
Ports and terminals:
major seaport(s):
Victoria','fe415f5fa65bde20bd307d887d7572d1e274adc0ab7b280fbe7e6932d91f4dc3','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6ec911c856816540f3d1f67b85b4ae5dadf64938ee477ca7dbda32e0d9f84b95',2025,'SL','Sierra Leone','transportation',20,'National air transport system:
annual passenger traffic on registered air carriers:
50,193 (2015)
annual freight traffic on registered air carriers:
0 (2015) mt-km
Civil aircraft registration country code prefix:
9L
Airports:
8 (2021)
comparison ranking:
total 159
Airports - with paved runways:
1
note:
paved runways have a concrete or asphalt surface but not all have facilities for refueling, maintenance, or air traffic control; the length of a runway required for aircraft to safely operate depends on a number of factors including the type of aircraft, the takeoff weight (including passengers, cargo, and fuel), engine types, flap settings, landing speed, elevation of the airport, and average maximum daily air temperature; paved runways can reach a length of 5,000 m (16,000 ft.), but the “typical” length of a commercial airline runway is between 2,500-4,000 m (8,000-13,000 ft.)
Airports - with unpaved runways:
7
note:
unpaved runways have a surface composition such as grass or packed earth and are most suited to the operation of light aircraft; unpaved runways are usually short, often less than 1,000 m (3,280 ft.) in length; airports with unpaved runways often lack facilities for refueling, maintenance, or air traffic control
Heliports:
2 (2021)
Roadways:
total:
11,701 km (2015)
paved:
1,051 km (2015)
unpaved:
10,650 km (2015)
urban:
3,000 km (2015)
non-
urban:
8,700 km (2015)
comparison ranking:
total 133
Waterways:
800 km (2011) (600 km navigable year-round)
comparison ranking:
79
Merchant marine:
total:
605 (2022)
by type:
bulk carrier 36, container ship 6, general cargo 325, oil tanker 104, other 134
comparison ranking:
total 37
Ports and terminals:
major seaport(s):
Freetown, Pepel, Sherbro Islands','7a8b522877df43d7f15a85f003ddc42f17bf94ccf8c706ab02cf7eed1ce3f41c','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1314e1bf76db4fc11a779e8820d6d1448607592cc54299f038e9cbebed6c7e89',2025,'SG','Singapore','transportation',31,'National air transport system:
number of registered air carriers:
4 (2020)
inventory of registered aircraft operated by air carriers:
230
annual passenger traffic on registered air carriers:
40,401,515 (2018)
annual freight traffic on registered air carriers:
5,194,900,000 (2018) mt-km
Civil aircraft registration country code prefix:
9V
Airports:
9 (2021)
comparison ranking:
total 158
Airports - with paved runways:
9
civil airports:
0
military airports:
2
joint use (civil-military) airports:
3
other airports:
4
note:
paved runways have a concrete or asphalt surface but not all have facilities for refueling, maintenance, or air traffic control; the length of a runway required for aircraft to safely operate depends on a number of factors including the type of aircraft, the takeoff weight (including passengers, cargo, and fuel), engine types, flap settings, landing speed, elevation of the airport, and average maximum daily air temperature; paved runways can reach a length of 5,000 m (16,000 ft.), but the “typical” length of a commercial airline runway is between 2,500-4,000 m (8,000-13,000 ft.)
Pipelines:
3,220 km domestic gas (2014), 1,122 km cross-border pipelines (2017), 8 km refined products (2013) (2013)
Roadways:
total:
3,500 km (2017)
paved:
3,500 km (2017) (includes 164 km of expressways)
comparison ranking:
total 158
Merchant marine:
total:
3,227 (2022)
by type:
bulk carrier 574, container ship 542, general cargo 99, oil tanker 633, other 1,379
comparison ranking:
total 7
Ports and terminals:
major seaport(s):','19cca9d30a0ce4ac7fbcef0d9e565394a810c2d45c649e2a130849fa40d96e34','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fb7c32da0674cc3d42b2e436f31fbeb0409f530798d1390da737009f1168f697',2025,'SG','Singapore','transportation',44,'Airports:
1 (2021)
comparison ranking:
total 236
Airports - with paved runways:
1
note:
paved runways have a concrete or asphalt surface but not all have facilities for refueling, maintenance, or air traffic control; the length of a runway required for aircraft to safely operate depends on a number of factors including the type of aircraft, the takeoff weight (including passengers, cargo, and fuel), engine types, flap settings, landing speed, elevation of the airport, and average maximum daily air temperature; paved runways can reach a length of 5,000 m (16,000 ft.), but the “typical” length of a commercial airline runway is between 2,500-4,000 m (8,000-13,000 ft.)
Roadways:
total:
53 km
comparison ranking:
total 216
Ports and terminals:
major seaport(s):
Philipsburg
oil terminal(s):
Coles Bay oil terminal','eb50d0f0b3d88b3b448bc0c0e14a91ebd1b15fae3e1f8a8ca4ae5eca38048439','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7bd829c667ca6d5ae745314a1030e557c99de93db87c4e62c00a72cf69935186',2025,'SK','Slovakia','transportation',55,'National air transport system:
number of registered air carriers:
4 (2020)
inventory of registered aircraft operated by air carriers:
45
Civil aircraft registration country code prefix:
OM
Airports:
35 (2021)
comparison ranking:
total 110
Airports - with paved runways:
19
note:
paved runways have a concrete or asphalt surface but not all have facilities for refueling, maintenance, or air traffic control; the length of a runway required for aircraft to safely operate depends on a number of factors including the type of aircraft, the takeoff weight (including passengers, cargo, and fuel), engine types, flap settings, landing speed, elevation of the airport, and average maximum daily air temperature; paved runways can reach a length of 5,000 m (16,000 ft.), but the “typical” length of a commercial airline runway is between 2,500-4,000 m (8,000-13,000 ft.)
Airports - with unpaved runways:
15
note:
unpaved runways have a surface composition such as grass or packed earth and are most suited to the operation of light aircraft; unpaved runways are usually short, often less than 1,000 m (3,280 ft.) in length; airports with unpaved runways often lack facilities for refueling, maintenance, or air traffic control
Heliports:
1 (2021)
Pipelines:
2,270 km gas transmission pipelines, 6,278 km high-pressure gas distribution pipelines, 27,023 km mid- and low-pressure gas distribution pipelines (2016), 510 km oil (2015) (2016)
Railways:
total:
3,627 km (2020) 1,585 km electrified
comparison ranking:
total 53
Roadways:
total:
56,926 km (2016) (includes local roads, national roads, and 464 km of highways)
comparison ranking:
total 80
Waterways:
172 km (2012) (on Danube River)
comparison ranking:
109
Ports and terminals:
river port(s):
Bratislava, Komarno (Danube)','700a00a32c4d24097e76c49d217f40be637004fee9a7ba3a4517d64a0eb63d44','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6a7c6a9e6cde8c4df9b7a4739e8aa345ae7404e0d278eeadec0c66982e793274',2025,'SI','Slovenia','transportation',9,'National air transport system:
number of registered air carriers:
2 (2020)
inventory of registered aircraft operated by air carriers:
21
annual passenger traffic on registered air carriers:
1,094,762 (2018)
annual freight traffic on registered air carriers:
540,000 (2018) mt-km
Civil aircraft registration country code prefix:
S5
Airports:
16 (2021)
comparison ranking:
total 144
Airports - with paved runways:
9
civil airports:
3
military airports:
0
joint use (civil-military) airports:
1
other airports:
5
note:
paved runways have a concrete or asphalt surface but not all have facilities for refueling, maintenance, or air traffic control; the length of a runway required for aircraft to safely operate depends on a number of factors including the type of aircraft, the takeoff weight (including passengers, cargo, and fuel), engine types, flap settings, landing speed, elevation of the airport, and average maximum daily air temperature; paved runways can reach a length of 5,000 m (16,000 ft.), but the “typical” length of a commercial airline runway is between 2,500-4,000 m (8,000-13,000 ft.)
Airports - with unpaved runways:
7
note:
unpaved runways have a surface composition such as grass or packed earth and are most suited to the operation of light aircraft; unpaved runways are usually short, often less than 1,000 m (3,280 ft.) in length; airports with unpaved runways often lack facilities for refueling, maintenance, or air traffic control
Pipelines:
1,155 km gas, 5 km oil (2018)
Railways:
total:
1,207 km (2020) 609 km electrified
comparison ranking:
total 86
Roadways:
total:
38,985 km (2012)
paved:
38,985 km (2012) (includes 769 km of expressways)
comparison ranking:
total 90
Waterways:
710 km (2022) (some transport on the Drava River)
comparison ranking:
81
Merchant marine:
total:
9 (2022)
by type:
general cargo 1, other 8
comparison ranking:
total 161
Ports and terminals:
major seaport(s):
Koper','06ad3f1474a1f4e3886cf23901a4308f9bb641b1dbc41fb96dd323c619980232','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('210de716ec8db2c9d7a05501fb96ba05d51b09b8cd2d6d4b3703f58ede49152d',2025,'SB','Solomon Islands','transportation',20,'National air transport system:
number of registered air carriers:
1 (2020)
inventory of registered aircraft operated by air carriers:
6
annual passenger traffic on registered air carriers:
427,806 (2018)
annual freight traffic on registered air carriers:
3.84 million (2018) mt-km
Civil aircraft registration country code prefix:
H4
Airports:
36 (2021)
comparison ranking:
total 108
Airports - with paved runways:
1
note:
paved runways have a concrete or asphalt surface but not all have facilities for refueling, maintenance, or air traffic control; the length of a runway required for aircraft to safely operate depends on a number of factors including the type of aircraft, the takeoff weight (including passengers, cargo, and fuel), engine types, flap settings, landing speed, elevation of the airport, and average maximum daily air temperature; paved runways can reach a length of 5,000 m (16,000 ft.), but the “typical” length of a commercial airline runway is between 2,500-4,000 m (8,000-13,000 ft.)
Airports - with unpaved runways:
35
note:
unpaved runways have a surface composition such as grass or packed earth and are most suited to the operation of light aircraft; unpaved runways are usually short, often less than 1,000 m (3,280 ft.) in length; airports with unpaved runways often lack facilities for refueling, maintenance, or air traffic control
Heliports:
3 (2021)
Roadways:
total:
1,390 km (2011)
paved:
34 km (2011)
unpaved:
1,356 km (2011)
note:
includes 920 km of private plantation roads
comparison ranking:
total 175
Merchant marine:
total:
27 (2022)
by type:
general cargo 9, oil tanker 1, other 17
comparison ranking:
total 138
Ports and terminals:
major seaport(s):
Honiara, Malloco Bay, Viru Harbor, Tulagi','71a7da546e5e1e0bb8137e13b7ae63ea59b73646594de7fcf2e23b5782e788f4','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5d4845f98ff6dbfd87750756978b976a0296d76ae396bdfe042e8ffad2adf93a',2025,'SO','Somalia','transportation',31,'National air transport system:
number of registered air carriers:
6 (2020)
inventory of registered aircraft operated by air carriers:
7
annual passenger traffic on registered air carriers:
4,486 (2018)
Civil aircraft registration country code prefix:
6O
Airports:
52 (2021)
comparison ranking:
total 89
Airports - with paved runways:
8
note:
paved runways have a concrete or asphalt surface but not all have facilities for refueling, maintenance, or air traffic control; the length of a runway required for aircraft to safely operate depends on a number of factors including the type of aircraft, the takeoff weight (including passengers, cargo, and fuel), engine types, flap settings, landing speed, elevation of the airport, and average maximum daily air temperature; paved runways can reach a length of 5,000 m (16,000 ft.), but the “typical” length of a commercial airline runway is between 2,500-4,000 m (8,000-13,000 ft.)
Airports - with unpaved runways:
44
note:
unpaved runways have a surface composition such as grass or packed earth and are most suited to the operation of light aircraft; unpaved runways are usually short, often less than 1,000 m (3,280 ft.) in length; airports with unpaved runways often lack facilities for refueling, maintenance, or air traffic control
Roadways:
total:
15,000 km (2018)
comparison ranking:
total 124
Merchant marine:
total:
4 (2022)
by type:
general cargo 1, other 3
comparison ranking:
total 170
Ports and terminals:
major seaport(s):
Berbera, Kismaayo','7432433a2bcc3dfe608552764464dfa30f90d9785ce3c580567ecaca2ebe4d76','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5571cec1c98cdcc8859438bd895c0e3868b6d48369302104d99f54702a241960',2025,'ZA','South Africa','transportation',43,'National air transport system:
number of registered air carriers:
17 (2020)
inventory of registered aircraft operated by air carriers:
243
annual passenger traffic on registered air carriers:
23,921,748 (2018)
annual freight traffic on registered air carriers:
716.25 million (2018) mt-km
Civil aircraft registration country code prefix:
ZS
Airports:
407 (2021)
comparison ranking:
total 20
Airports - with paved runways:
130
civil airports:
21
military airports:
7
joint use (civil-military) airports:
1
other airports:
101
note:
paved runways have a concrete or asphalt surface but not all have facilities for refueling, maintenance, or air traffic control; the length of a runway required for aircraft to safely operate depends on a number of factors including the type of aircraft, the takeoff weight (including passengers, cargo, and fuel), engine types, flap settings, landing speed, elevation of the airport, and average maximum daily air temperature; paved runways can reach a length of 5,000 m (16,000 ft.), but the “typical” length of a commercial airline runway is between 2,500-4,000 m (8,000-13,000 ft.)
Airports - with unpaved runways:
277
note:
unpaved runways have a surface composition such as grass or packed earth and are most suited to the operation of light aircraft; unpaved runways are usually short, often less than 1,000 m (3,280 ft.) in length; airports with unpaved runways often lack facilities for refueling, maintenance, or air traffic control
Pipelines:
94 km condensate, 1,293 km gas, 992 km oil, 1,460 km refined products (2013)
Railways:
total:
20,986 km (2014)
standard gauge:
80 km (2014) 1.435-m gauge (80 km electrified)
narrow gauge:
19,756 km (2014) 1.065-m gauge (8,271 km electrified)
other:
(2014) 1,150 km (passenger rail, gauge unspecified, 1,115.5 km electrified)
comparison ranking:
total 13
Roadways:
total:
750,000 km (2016)
paved:
158,124 km (2016)
unpaved:
591,876 km (2016)
comparison ranking:
total 11
Merchant marine:
total:
107 (2022)
by type:
bulk carrier 3, general cargo 1, oil tanker 7, other 96
comparison ranking:
total 86
Ports and terminals:
major seaport(s):
Cape Town, Durban, Port Elizabeth, Richards Bay, Saldanha Bay
container port(s) (TEUs):
Durban (2,430,295) (2021)
LNG terminal(s) (import):
Mossel Bay
Transportation - note:
South Africa operates one PC 5 or 6 class light icebreaker
note - PC indicates a Polar Class vessel:
PC 5 - year-round operation in medium first-year ice which may include old ice inclusions (ice thickness up to 70-120 cm); PC 6 - summer/autumn operation in medium first-year ice which may include old ice inclusions (ice thickness up to 30-70 cm)','90362835727dc538e9550ac33f9460f1c8bf29e94f526bd6f984b84d83cbb42d','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a3b823882e0cf6a6ea6ebb4b7de32bd7d3db3ea1163b2d8adbd772cd2e938982',2025,'SS','South Sudan','transportation',10,'National air transport system:
number of registered air carriers:
2 (2020)
inventory of registered aircraft operated by air carriers:
2
annual freight traffic on registered air carriers:
0 mt-km
Civil aircraft registration country code prefix:
Z8
Airports:
89 (2021)
comparison ranking:
total 63
Airports - with paved runways:
4
note:
paved runways have a concrete or asphalt surface but not all have facilities for refueling, maintenance, or air traffic control; the length of a runway required for aircraft to safely operate depends on a number of factors including the type of aircraft, the takeoff weight (including passengers, cargo, and fuel), engine types, flap settings, landing speed, elevation of the airport, and average maximum daily air temperature; paved runways can reach a length of 5,000 m (16,000 ft.), but the “typical” length of a commercial airline runway is between 2,500-4,000 m (8,000-13,000 ft.)
Airports - with unpaved runways:
84
note:
unpaved runways have a surface composition such as grass or packed earth and are most suited to the operation of light aircraft; unpaved runways are usually short, often less than 1,000 m (3,280 ft.) in length; airports with unpaved runways often lack facilities for refueling, maintenance, or air traffic control
Heliports:
3 (2021)
Railways:
total:
248 km (2018)
note:
a narrow gauge, single-track railroad between Babonosa (Sudan) and Wau, the only existing rail system, was repaired in 2010 with $250 million in UN funds, but is not currently operational
comparison ranking:
total 127
Roadways:
total:
90,200 km (2019)
paved:
300 km (2019)
unpaved:
89,900 km (2019)
note:
most of the road network is unpaved and much of it is in disrepair; the Juba-Nimule highway connecting Juba to the border with Uganda is the main paved road in South Sudan
comparison ranking:
total 54
Waterways:
see entry for Sudan','4a47860aa9b4ec230a08227a0c5e5b0ab0da30fa1c26028ec99a3087a473c6d6','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('809d3d98c702781b27a7b97cd09f33c26c4472833eb50eea0c4ca5421f2dfb3e',2025,'SS','South Sudan','transportation',17,'Ports and terminals:
major seaport(s):
McMurdo, Palmer, and offshore anchorages in Antarctica
note:
few ports or harbors exist on the southern side of the Southern Ocean; ice conditions limit use of most to short periods in midsummer; even then some cannot be entered without icebreaker escort; most Antarctic ports are operated by government research stations and, except in an emergency, are not open to commercial or private vessels
Transportation - note:
Drake Passage offers alternative to transit through the Panama Canal','b63b3d3b081ebe374aa861b2a26935360d1c63e4e632a1be34b38dfa41c8f478','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('05d65c843b5d3cb2bf09cda13c7c6d78199f658d332f1494143e9319884a517a',2025,'ES','Spain','transportation',27,'National air transport system:
number of registered air carriers:
21 (2020)
inventory of registered aircraft operated by air carriers:
552
annual passenger traffic on registered air carriers:
80,672,105 (2018)
annual freight traffic on registered air carriers:
1.117 billion (2018) mt-km
Civil aircraft registration country code prefix:
EC
Airports:
135 (2021)
comparison ranking:
total 40
Airports - with paved runways:
102
civil airports:
28
military airports:
6
joint use (civil-military) airports:
13
other airports:
55
note:
paved runways have a concrete or asphalt surface but not all have facilities for refueling, maintenance, or air traffic control; the length of a runway required for aircraft to safely operate depends on a number of factors including the type of aircraft, the takeoff weight (including passengers, cargo, and fuel), engine types, flap settings, landing speed, elevation of the airport, and average maximum daily air temperature; paved runways can reach a length of 5,000 m (16,000 ft.), but the “typical” length of a commercial airline runway is between 2,500-4,000 m (8,000-13,000 ft.)
Airports - with unpaved runways:
33
note:
unpaved runways have a surface composition such as grass or packed earth and are most suited to the operation of light aircraft; unpaved runways are usually short, often less than 1,000 m (3,280 ft.) in length; airports with unpaved runways often lack facilities for refueling, maintenance, or air traffic control
Heliports:
13 (2021)
Pipelines:
10,481 km gas, 358 km oil, 4,378 km refined products (2017)
Railways:
total:
15,489 km (2020) 9,953 km electrified
comparison ranking:
total 19
Roadways:
total:
683,175 km (2011)
paved:
683,175 km (2011) (includes 16,205 km of expressways)
comparison ranking:
total 13
Waterways:
1,000 km (2012)
comparison ranking:
69
Merchant marine:
total:
494 (2022)
by type:
bulk carrier 1, general cargo 35, oil tanker 23, other 435
comparison ranking:
total 43
Ports and terminals:
major seaport(s):
Atlantic Ocean:
Bilbao, Huelva; Las Palmas, Santa Cruz de Tenerife (in the Canary Islands)
Mediterranean Sea:
Algeciras, Barcelona, Cartagena, Tarragona, Valencia
container port(s) (TEUs):
Algeciras (4,799,497), Barcelona (3,531,762), Valencia (5,604,478) (2021)
LNG terminal(s) (import):
Barcelona, Bilbao, Cartagena, El Musel, Huelva, Mugardos, Sagunto
river port(s):
Seville (Guadalquivir River)','0107b1b7d7aac5c756f39130a24ff9e00d98c8425f3515a48788766f4f2159fd','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fd478a6c4f437ce14ac2cdd5ade0d2d452210d0c4fed73ee2279c4c4dfaed823',2025,'ES','Spain','transportation',37,'Airports:
8 (2021)
comparison ranking:
total 163
Airports - with paved runways:
7
note:
paved runways have a concrete or asphalt surface but not all have facilities for refueling, maintenance, or air traffic control; the length of a runway required for aircraft to safely operate depends on a number of factors including the type of aircraft, the takeoff weight (including passengers, cargo, and fuel), engine types, flap settings, landing speed, elevation of the airport, and average maximum daily air temperature; paved runways can reach a length of 5,000 m (16,000 ft.), but the “typical” length of a commercial airline runway is between 2,500-4,000 m (8,000-13,000 ft.)
Airports - with unpaved runways:
2
note:
unpaved runways have a surface composition such as grass or packed earth and are most suited to the operation of light aircraft; unpaved runways are usually short, often less than 1,000 m (3,280 ft.) in length; airports with unpaved runways often lack facilities for refueling, maintenance, or air traffic control
Heliports:
5 (2021)
Ports and terminals:
none; offshore anchorage only','e876d1671366d2bc82624f65ec4816dde68fccbd111d62e439f859af7b14b846','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0ae68a9b022fa09811bda5314289ac281d65efbcb703ca7e8f0b6b695d35c001',2025,'LK','Sri Lanka','transportation',48,'National air transport system:
number of registered air carriers:
3 (2020)
inventory of registered aircraft operated by air carriers:
34
annual passenger traffic on registered air carriers:
5,882,376 (2018)
annual freight traffic on registered air carriers:
436.2 million (2018) mt-km
Civil aircraft registration country code prefix:
4R
Airports:
18 (2021)
comparison ranking:
total 139
Airports - with paved runways:
11
note:
paved runways have a concrete or asphalt surface but not all have facilities for refueling, maintenance, or air traffic control; the length of a runway required for aircraft to safely operate depends on a number of factors including the type of aircraft, the takeoff weight (including passengers, cargo, and fuel), engine types, flap settings, landing speed, elevation of the airport, and average maximum daily air temperature; paved runways can reach a length of 5,000 m (16,000 ft.), but the “typical” length of a commercial airline runway is between 2,500-4,000 m (8,000-13,000 ft.)
Airports - with unpaved runways:
7
note:
unpaved runways have a surface composition such as grass or packed earth and are most suited to the operation of light aircraft; unpaved runways are usually short, often less than 1,000 m (3,280 ft.) in length; airports with unpaved runways often lack facilities for refueling, maintenance, or air traffic control
Heliports:
1 (2021)
Pipelines:
7 km refined products
Railways:
total:
1,562 km (2016)
broad gauge:
1,562 km (2016) 1.676-m gauge
comparison ranking:
total 81
Roadways:
total:
114,093 km (2010)
paved:
16,977 km (2010)
unpaved:
97,116 km (2010)
comparison ranking:
total 43
Waterways:
160 km (2012) (primarily on rivers in southwest)
comparison ranking:
110
Merchant marine:
total:
92 (2022)
by type:
bulk carrier 5, general cargo 13, oil tanker 11, other 63
comparison ranking:
total 95
Ports and terminals:
major seaport(s):
Colombo
container port(s) (TEUs):
Colombo (7,250,000) (2021)','01f855823be20637f8742880672819d03fdb6acb995d367f2c331f0a3af2e5be','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('88fd8c6b4f549eda0b2008079588602cc48cff1aa41480385e52e561438ce37d',2025,'SD','Sudan','transportation',61,'National air transport system:
number of registered air carriers:
9 (2020)
inventory of registered aircraft operated by air carriers:
42
annual passenger traffic on registered air carriers:
269,958 (2018)
Civil aircraft registration country code prefix:
ST
Airports:
67 (2021)
comparison ranking:
total 74
Airports - with paved runways:
17
civil airports:
5
military airports:
1
joint use (civil-military) airports:
1
other airports:
10
note:
paved runways have a concrete or asphalt surface but not all have facilities for refueling, maintenance, or air traffic control; the length of a runway required for aircraft to safely operate depends on a number of factors including the type of aircraft, the takeoff weight (including passengers, cargo, and fuel), engine types, flap settings, landing speed, elevation of the airport, and average maximum daily air temperature; paved runways can reach a length of 5,000 m (16,000 ft.), but the “typical” length of a commercial airline runway is between 2,500-4,000 m (8,000-13,000 ft.)
Airports - with unpaved runways:
50
note:
unpaved runways have a surface composition such as grass or packed earth and are most suited to the operation of light aircraft; unpaved runways are usually short, often less than 1,000 m (3,280 ft.) in length; airports with unpaved runways often lack facilities for refueling, maintenance, or air traffic control
Heliports:
7 (2021)
Pipelines:
156 km gas, 4,070 km oil, 1,613 km refined products (2013)
Railways:
total:
7,251 km (2014)
narrow gauge:
5,851 km (2014) 1.067-m gauge
1,400 km 0.600-m gauge for cotton plantations
comparison ranking:
total 31
Roadways:
total:
31,000 km (2019)
paved:
8,000 km (2019)
unpaved:
23,000 km (2019)
urban:
1,000 km (2019)
comparison ranking:
total 97
Waterways:
4,068 km (2011) (1,723 km open year-round on White and Blue Nile Rivers)
comparison ranking:
27
Merchant marine:
total:
15 (2022)
by type:
other 15
comparison ranking:
total 150
Ports and terminals:
major seaport(s):
Port Sudan','a343c7966840b4c15ffc87b9f19d87161fe63552c6e9f946326fe8a8a1f51ba7','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('44472e8932e83ae7f7129ffdbc81671ef852c5c49b752ff2b658031045d9c27a',2025,'SR','Suriname','transportation',9,'National air transport system:
number of registered air carriers:
4 (2020)
inventory of registered aircraft operated by air carriers:
20
annual passenger traffic on registered air carriers:
272,347 (2018)
annual freight traffic on registered air carriers:
33.2 million (2018) mt-km
Civil aircraft registration country code prefix:
PZ
Airports:
55 (2021)
comparison ranking:
total 84
Airports - with paved runways:
6
note:
paved runways have a concrete or asphalt surface but not all have facilities for refueling, maintenance, or air traffic control; the length of a runway required for aircraft to safely operate depends on a number of factors including the type of aircraft, the takeoff weight (including passengers, cargo, and fuel), engine types, flap settings, landing speed, elevation of the airport, and average maximum daily air temperature; paved runways can reach a length of 5,000 m (16,000 ft.), but the “typical” length of a commercial airline runway is between 2,500-4,000 m (8,000-13,000 ft.)
Airports - with unpaved runways:
49
note:
unpaved runways have a surface composition such as grass or packed earth and are most suited to the operation of light aircraft; unpaved runways are usually short, often less than 1,000 m (3,280 ft.) in length; airports with unpaved runways often lack facilities for refueling, maintenance, or air traffic control
Pipelines:
50 km oil (2013)
Roadways:
total:
4,304 km (2003)
paved:
1,119 km (2003)
unpaved:
3,185 km (2003)
comparison ranking:
total 151
Waterways:
1,200 km (2011) (most navigable by ships with drafts up to 7 m)
comparison ranking:
63
Merchant marine:
total:
10 (2022)
by type:
general cargo 5, oil tanker 3, other 2
comparison ranking:
total 157
Ports and terminals:
major seaport(s):
Paramaribo, Wageningen','2ae266154cdc0e0b91f9e11354d662d4ce7698d4a2eab4d32830d952d9c9d546','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cd9d3c36ddf5461aa46a38abb5942693841e906d057f357457ec2a35766dd275',2025,'SR','Suriname','transportation',20,'Airports:
4 (2021)
comparison ranking:
total 188
Airports - with paved runways:
1
note:
paved runways have a concrete or asphalt surface but not all have facilities for refueling, maintenance, or air traffic control; the length of a runway required for aircraft to safely operate depends on a number of factors including the type of aircraft, the takeoff weight (including passengers, cargo, and fuel), engine types, flap settings, landing speed, elevation of the airport, and average maximum daily air temperature; paved runways can reach a length of 5,000 m (16,000 ft.), but the “typical” length of a commercial airline runway is between 2,500-4,000 m (8,000-13,000 ft.)
Airports - with unpaved runways:
3
note:
unpaved runways have a surface composition such as grass or packed earth and are most suited to the operation of light aircraft; unpaved runways are usually short, often less than 1,000 m (3,280 ft.) in length; airports with unpaved runways often lack facilities for refueling, maintenance, or air traffic control
Heliports:
1 (2021)
Roadways:
total:
40 km (2020)
comparison ranking:
total 217
Ports and terminals:
major seaport(s):
Barentsburg, Longyearbyen, Ny-Alesund, Pyramiden','e7aabae7ec0bad4c7df8549b69af0ccead831411f5a6fd1e4d9f946da7b80fa1','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d4061017cbe9020a9812bbd0eb3fde568a96e23b225e3ea2491211834daee819',2025,'SE','Sweden','transportation',31,'National air transport system:
number of registered air carriers:
11 (2020)
inventory of registered aircraft operated by air carriers:
316
Civil aircraft registration country code prefix:
SE
Airports:
231 (2021)
comparison ranking:
total 25
Airports - with paved runways:
149
civil airports:
26
military airports:
4
joint use (civil-military) airports:
3
other airports:
116
note:
paved runways have a concrete or asphalt surface but not all have facilities for refueling, maintenance, or air traffic control; the length of a runway required for aircraft to safely operate depends on a number of factors including the type of aircraft, the takeoff weight (including passengers, cargo, and fuel), engine types, flap settings, landing speed, elevation of the airport, and average maximum daily air temperature; paved runways can reach a length of 5,000 m (16,000 ft.), but the “typical” length of a commercial airline runway is between 2,500-4,000 m (8,000-13,000 ft.)
Airports - with unpaved runways:
82
note:
unpaved runways have a surface composition such as grass or packed earth and are most suited to the operation of light aircraft; unpaved runways are usually short, often less than 1,000 m (3,280 ft.) in length; airports with unpaved runways often lack facilities for refueling, maintenance, or air traffic control
Heliports:
2 (2021)
Pipelines:
1626 km gas (2013)
Railways:
total:
10,910 km (2020) 8,184 km electrified
narrow gauge:
65 km
comparison ranking:
total 22
Roadways:
total:
573,134 km (2016) (includes 2,050 km of expressways)
paved:
140,100 km (2016)
unpaved:
433,034 km (2016)
note:
includes 98,500 km of state roads, 433,034 km of private roads, and 41,600 km of municipal roads
comparison ranking:
total 14
Waterways:
2,052 km (2010)
comparison ranking:
42
Merchant marine:
total:
368 (2022)
by type:
general cargo 46, oil tanker 21, other 301
comparison ranking:
total 50
Ports and terminals:
major seaport(s):
Brofjorden, Goteborg, Helsingborg, Karlshamn, Lulea, Malmo, Stockholm, Trelleborg, Visby
LNG terminal(s) (import):
Brunnsviksholme, Lysekil
Transportation - note:
Sweden operates four PC 3 or 4 class medium icebreakers in the Baltic Sea
note - PC indicates a Polar Class vessel:
PC 3 - year-round operation in second-year ice which may include multi-year ice inclusions (ice thickness up to 2.5 m); PC 4 - year-round operation in thick first-year ice which may include old ice inclusions (ice thickness up to 120 cm)','0836bee6f3bf20e536883a9987564c468145db993b633968932aca923539888d','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cfcfa81e9b5c95e62fe40e089bb0047f77b90a7dd321fe77b8f5119928290e87',2025,'CH','Switzerland','transportation',44,'National air transport system:
number of registered air carriers:
6 (2020)
inventory of registered aircraft operated by air carriers:
179
annual passenger traffic on registered air carriers:
28,857,994 (2018)
annual freight traffic on registered air carriers:
1,841,310,000 (2018) mt-km
Civil aircraft registration country code prefix:
HB
Airports:
63 (2021)
comparison ranking:
total 78
Airports - with paved runways:
40
note:
paved runways have a concrete or asphalt surface but not all have facilities for refueling, maintenance, or air traffic control; the length of a runway required for aircraft to safely operate depends on a number of factors including the type of aircraft, the takeoff weight (including passengers, cargo, and fuel), engine types, flap settings, landing speed, elevation of the airport, and average maximum daily air temperature; paved runways can reach a length of 5,000 m (16,000 ft.), but the “typical” length of a commercial airline runway is between 2,500-4,000 m (8,000-13,000 ft.)
Airports - with unpaved runways:
23
note:
unpaved runways have a surface composition such as grass or packed earth and are most suited to the operation of light aircraft; unpaved runways are usually short, often less than 1,000 m (3,280 ft.) in length; airports with unpaved runways often lack facilities for refueling, maintenance, or air traffic control
Heliports:
2 (2021)
Pipelines:
1,800 km gas, 94 km oil (of which 60 are inactive), 17 km refined products (2017)
Railways:
total:
5,296 km (2020) 5,296 km electrified; Switzerland remains the only country with a fully electrified network
comparison ranking:
total 36
Roadways:
total:
71,557 km (2017)
paved:
71,557 km (2017) (includes 1,458 of expressways)
comparison ranking:
total 66
Waterways:
1,292 km (2010) (there are 1,227 km of waterways on lakes and rivers for public transport and 65 km on the Rhine River between Basel-Rheinfelden and Schaffhausen-Bodensee for commercial goods transport)
comparison ranking:
61
Merchant marine:
total:
20 (2022)
by type:
bulk carrier 16, general cargo 1, other 3 (includes Liechtenstein)
comparison ranking:
total 147
Ports and terminals:
river port(s):
Basel (Rhine)','60c3aec57b59de27b38a216569d28386c3cb0e2e1d1c25bd45ca9f3aecf9dfe6','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ba5e33b5ec6f970aff5be53f920f4a1afb1bf2dd6d6b43992494dbad652d449e',2025,'CH','Switzerland','transportation',57,'National air transport system:
number of registered air carriers:
3 (2020)
inventory of registered aircraft operated by air carriers:
11
annual passenger traffic on registered air carriers:
17,896 (2018)
annual freight traffic on registered air carriers:
30,000 (2018) mt-km
Civil aircraft registration country code prefix:
YK
Airports:
90 (2021)
comparison ranking:
total 62
Airports - with paved runways:
29
note:
paved runways have a concrete or asphalt surface but not all have facilities for refueling, maintenance, or air traffic control; the length of a runway required for aircraft to safely operate depends on a number of factors including the type of aircraft, the takeoff weight (including passengers, cargo, and fuel), engine types, flap settings, landing speed, elevation of the airport, and average maximum daily air temperature; paved runways can reach a length of 5,000 m (16,000 ft.), but the “typical” length of a commercial airline runway is between 2,500-4,000 m (8,000-13,000 ft.)
Airports - with unpaved runways:
61
note:
unpaved runways have a surface composition such as grass or packed earth and are most suited to the operation of light aircraft; unpaved runways are usually short, often less than 1,000 m (3,280 ft.) in length; airports with unpaved runways often lack facilities for refueling, maintenance, or air traffic control
Heliports:
6 (2021)
Pipelines:
3,170 km gas, 2029 km oil (2013)
Railways:
total:
2,052 km (2014)
standard gauge:
1,801 km (2014) 1.435-m gauge
narrow gauge:
251 km (2014) 1.050-m gauge
comparison ranking:
total 73
Roadways:
total:
69,873 km (2010)
paved:
63,060 km (2010)
unpaved:
6,813 km (2010)
comparison ranking:
total 69
Waterways:
900 km (2011) (navigable but not economically significant)
comparison ranking:
75
Merchant marine:
total:
22 (2022)
by type:
bulk carrier 1, general cargo 8, other 13
comparison ranking:
total 146
Ports and terminals:
major seaport(s):
Baniyas, Latakia, Tartus','ee1824e39e182b474dd399f7a0954021e9ec323ad1b4fe953ca77afa2aa2cbe8','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a6f5370be0cd030c9d05931ddd586f61998eccaa78122c79817dcfa8b0e9f6af',2025,'TJ','Tajikistan','transportation',11,'National air transport system:
number of registered air carriers:
2 (2020)
inventory of registered aircraft operated by air carriers:
6
annual passenger traffic on registered air carriers:
492,320 (2018)
annual freight traffic on registered air carriers:
2.34 million (2018) mt-km
Civil aircraft registration country code prefix:
EY
Airports:
24 (2021)
comparison ranking:
total 129
Airports - with paved runways:
17
note:
paved runways have a concrete or asphalt surface but not all have facilities for refueling, maintenance, or air traffic control; the length of a runway required for aircraft to safely operate depends on a number of factors including the type of aircraft, the takeoff weight (including passengers, cargo, and fuel), engine types, flap settings, landing speed, elevation of the airport, and average maximum daily air temperature; paved runways can reach a length of 5,000 m (16,000 ft.), but the “typical” length of a commercial airline runway is between 2,500-4,000 m (8,000-13,000 ft.)
Airports - with unpaved runways:
7
note:
unpaved runways have a surface composition such as grass or packed earth and are most suited to the operation of light aircraft; unpaved runways are usually short, often less than 1,000 m (3,280 ft.) in length; airports with unpaved runways often lack facilities for refueling, maintenance, or air traffic control
Pipelines:
549 km gas, 38 km oil (2013)
Railways:
total:
680 km (2014)
broad gauge:
680 km (2014) 1.520-m gauge
comparison ranking:
total 102
Roadways:
total:
30,000 km (2018)
comparison ranking:
total 98
Waterways:
200 km (2011) (along Vakhsh River)
comparison ranking:
108','5fa8a21b8c4e3ecc86a63cc20f9c52e3775be57bf6bf64a14f6846d482a69fda','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7dc3639f2580d9abec6c1541cb7cfb5844111acb1bd3cc2c19901dc15e931fee',2025,'TJ','Tajikistan','transportation',23,'National air transport system:
number of registered air carriers:
11 (2020)
inventory of registered aircraft operated by air carriers:
91
annual passenger traffic on registered air carriers:
1,481,557 (2018)
annual freight traffic on registered air carriers:
390,000 (2018) mt-km
Civil aircraft registration country code prefix:
5H
Airports:
166 (2021)
comparison ranking:
total 33
Airports - with paved runways:
10
note:
paved runways have a concrete or asphalt surface but not all have facilities for refueling, maintenance, or air traffic control; the length of a runway required for aircraft to safely operate depends on a number of factors including the type of aircraft, the takeoff weight (including passengers, cargo, and fuel), engine types, flap settings, landing speed, elevation of the airport, and average maximum daily air temperature; paved runways can reach a length of 5,000 m (16,000 ft.), but the “typical” length of a commercial airline runway is between 2,500-4,000 m (8,000-13,000 ft.)
Airports - with unpaved runways:
156
note:
unpaved runways have a surface composition such as grass or packed earth and are most suited to the operation of light aircraft; unpaved runways are usually short, often less than 1,000 m (3,280 ft.) in length; airports with unpaved runways often lack facilities for refueling, maintenance, or air traffic control
Pipelines:
311 km gas, 891 km oil, 8 km refined products (2013)
Railways:
total:
4,097 km (2022)
standard gauge:
421 km (2022)
narrow gauge:
969 km (2022) 1.067 m gauge
broad gauge:
2,707 km (2022) 1.000 m guage
comparison ranking:
total 44
Roadways:
total:
145,203 km (2022)
paved:
11,201 km (2022)
unpaved:
134,002 km (2022)
comparison ranking:
total 35
Waterways:
1,594 km (2022) (Lake Tanganyika 673 km, Lake Victoria 337 km, and Lake Nyasa (Lake Malawi) 584 km are the principal avenues of commerce with neighboring countries; the rivers are not navigable)
comparison ranking:
53
Merchant marine:
total:
322 (2022)
by type:
bulk carrier 4, container ship 9, general cargo 148, oil tanker 46, other 115
comparison ranking:
total 52
Ports and terminals:
major seaport(s):
Dar es Salaam, Zanzibar','0697c7b40921752f0800f1f98517c3527970ab5078a246a92235f3ba60a2c241','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4bf2b49afea330a3067cb8e54544aefa1b47d94c366bdd47d1b67dee4399152a',2025,'TH','Thailand','transportation',35,'National air transport system:
number of registered air carriers:
15 (2020)
inventory of registered aircraft operated by air carriers:
283
annual passenger traffic on registered air carriers:
76,053,042 (2018)
annual freight traffic on registered air carriers:
2,666,260,000 (2018) mt-km
Civil aircraft registration country code prefix:
HS
Airports:
101 (2021)
comparison ranking:
total 56
Airports - with paved runways:
63
note:
paved runways have a concrete or asphalt surface but not all have facilities for refueling, maintenance, or air traffic control; the length of a runway required for aircraft to safely operate depends on a number of factors including the type of aircraft, the takeoff weight (including passengers, cargo, and fuel), engine types, flap settings, landing speed, elevation of the airport, and average maximum daily air temperature; paved runways can reach a length of 5,000 m (16,000 ft.), but the “typical” length of a commercial airline runway is between 2,500-4,000 m (8,000-13,000 ft.)
Airports - with unpaved runways:
38
note:
unpaved runways have a surface composition such as grass or packed earth and are most suited to the operation of light aircraft; unpaved runways are usually short, often less than 1,000 m (3,280 ft.) in length; airports with unpaved runways often lack facilities for refueling, maintenance, or air traffic control
Heliports:
7 (2021)
Pipelines:
2 km condensate, 5,900 km gas, 85 km liquid petroleum gas, 1 km oil, 1,097 km refined products (2013)
Railways:
total:
4,127 km (2017)
standard gauge:
84 km (2017) 1.435-m gauge (84 km electrified)
narrow gauge:
4,043 km (2017) 1.000-m gauge
comparison ranking:
total 43
Roadways:
total:
180,053 km (2006) (includes 450 km of expressways)
comparison ranking:
total 30
Waterways:
4,000 km (2011) (3,701 km navigable by boats with drafts up to 0.9 m)
comparison ranking:
28
Merchant marine:
total:
829 (2022)
by type:
bulk carrier 26, container ship 28, general cargo 91, oil tanker 246, other 438 comparison ranking: total 29
Ports and terminals:
major seaport(s):
Bangkok, Laem Chabang, Map Ta Phut, Prachuap Port, Si Racha
container port(s) (TEUs):
Laem Chabang (8,335,384) (2021)
LNG terminal(s) (import):
Map Ta Phut','6c7b405850fec6872bde0af92e8998172ca9bffcba0177777497049c69fc6e69','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('46c1a1b7846c48015dd444faa153ba81c32eda7b33725859d63a59511af3732a',2025,'TL','Timor-Leste','transportation',9,'National air transport system:
number of registered air carriers:
2 (2020)
inventory of registered aircraft operated by air carriers:
2
Civil aircraft registration country code prefix:
4W
Airports:
6 (2021)
comparison ranking:
total 178
Airports - with paved runways:
2
note:
paved runways have a concrete or asphalt surface but not all have facilities for refueling, maintenance, or air traffic control; the length of a runway required for aircraft to safely operate depends on a number of factors including the type of aircraft, the takeoff weight (including passengers, cargo, and fuel), engine types, flap settings, landing speed, elevation of the airport, and average maximum daily air temperature; paved runways can reach a length of 5,000 m (16,000 ft.), but the “typical” length of a commercial airline runway is between 2,500-4,000 m (8,000-13,000 ft.)
Airports - with unpaved runways:
4
note:
unpaved runways have a surface composition such as grass or packed earth and are most suited to the operation of light aircraft; unpaved runways are usually short, often less than 1,000 m (3,280 ft.) in length; airports with unpaved runways often lack facilities for refueling, maintenance, or air traffic control
Heliports:
8 (2021)
Roadways:
total:
6,040 km (2008)
paved:
2,600 km (2008)
unpaved:
3,440 km (2008)
comparison ranking:
total 143
Merchant marine:
total:
1 (2022)
by type:
other 1
comparison ranking:
total 185
Ports and terminals:
major seaport(s):
Dili','63a30a78ebf30687fd10e070f091ca7b4d1c4dfd0a00aac54c199970fdbd0905','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5175a398e76cdfb6e36c3b148bea8d6cd44159a52806c92d581adec2122d4f25',2025,'TG','Togo','transportation',20,'National air transport system:
number of registered air carriers:
1 (2020)
inventory of registered aircraft operated by air carriers:
8
annual passenger traffic on registered air carriers:
566,295 (2018)
annual freight traffic on registered air carriers:
10.89 million (2018) mt-km
Civil aircraft registration country code prefix:
5V
Airports:
8 (2021)
comparison ranking:
total 164
Airports - with paved runways:
2
note:
paved runways have a concrete or asphalt surface but not all have facilities for refueling, maintenance, or air traffic control; the length of a runway required for aircraft to safely operate depends on a number of factors including the type of aircraft, the takeoff weight (including passengers, cargo, and fuel), engine types, flap settings, landing speed, elevation of the airport, and average maximum daily air temperature; paved runways can reach a length of 5,000 m (16,000 ft.), but the “typical” length of a commercial airline runway is between 2,500-4,000 m (8,000-13,000 ft.)
Airports - with unpaved runways:
6
note:
unpaved runways have a surface composition such as grass or packed earth and are most suited to the operation of light aircraft; unpaved runways are usually short, often less than 1,000 m (3,280 ft.) in length; airports with unpaved runways often lack facilities for refueling, maintenance, or air traffic control
Pipelines:
62 km gas
Railways:
total:
568 km (2014)
narrow gauge:
568 km (2014) 1.000-m gauge
comparison ranking:
total 110
Roadways:
total:
9,951 km (2018)
paved:
1,794 km (2018)
unpaved:
8,157 km (2018)
urban:
1,783 km (2018)
comparison ranking:
total 135
Waterways:
50 km (2011) (seasonally navigable by small craft on the Mono River depending on rainfall)
comparison ranking:
113
Merchant marine:
total:
403 (2022)
by type:
bulk carrier 1, container ship 10, general cargo 254, oil tanker 57, other 81
comparison ranking:
total 48
Ports and terminals:
major seaport(s):
Kpeme, Lome
container port(s) (TEUs):
Lome (1,962,304) (2021)','d7668763aa899a0678d088318238a32a376228bc057ae6274345e00a54bcda55','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5fbbba289384a99df5d2f8ae3c1f7e10b9972501d1a300d6904bf1dc4f0ba702',2025,'TK','Tokelau','transportation',31,'Roadways:
total:
10 km (2019)
comparison ranking:
total 222
Ports and terminals:
none; offshore anchorage only','edbcd0d212226c71cd773f93190affd12083e622a260bc47e23c71d97578df32','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('327ee13f6c4084050269ef427b29ac5d051ebe1461c86b177ba97de119b70abb',2025,'TO','Tonga','transportation',42,'National air transport system:
number of registered air carriers:
1 (2020)
inventory of registered aircraft operated by air carriers:
1
Civil aircraft registration country code prefix:
A3
Airports:
6 (2021)
comparison ranking:
total 177
Airports - with paved runways:
1
note:
paved runways have a concrete or asphalt surface but not all have facilities for refueling, maintenance, or air traffic control; the length of a runway required for aircraft to safely operate depends on a number of factors including the type of aircraft, the takeoff weight (including passengers, cargo, and fuel), engine types, flap settings, landing speed, elevation of the airport, and average maximum daily air temperature; paved runways can reach a length of 5,000 m (16,000 ft.), but the “typical” length of a commercial airline runway is between 2,500-4,000 m (8,000-13,000 ft.)
Airports - with unpaved runways:
5
note:
unpaved runways have a surface composition such as grass or packed earth and are most suited to the operation of light aircraft; unpaved runways are usually short, often less than 1,000 m (3,280 ft.) in length; airports with unpaved runways often lack facilities for refueling, maintenance, or air traffic control
Roadways:
total:
680 km (2011)
paved:
184 km (2011)
unpaved:
496 km (2011)
comparison ranking:
total 190
Merchant marine:
total:
32 (2022)
by type:
container ship 4, general cargo 13, oil tanker 1, other 14
comparison ranking:
total 131
Ports and terminals:
major seaport(s):
Nuku’alofa, Neiafu, Pangai','b02e1b0c46dbec760b023003e97c7020b2521180ae9d096f63d51618f26894b9','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('838f3d123a09ca09595396fb79f8d5eb9926272c746b8071a6da751a4412a4f3',2025,'TT','Trinidad and Tobago','transportation',53,'National air transport system:
number of registered air carriers:
1 (2020)
inventory of registered aircraft operated by air carriers:
19
annual passenger traffic on registered air carriers:
2,525,130 (2018)
annual freight traffic on registered air carriers:
41.14 million (2018) mt-km
Civil aircraft registration country code prefix:
9Y
Airports:
4 (2021)
comparison ranking:
total 187
Airports - with paved runways:
2
note:
paved runways have a concrete or asphalt surface but not all have facilities for refueling, maintenance, or air traffic control; the length of a runway required for aircraft to safely operate depends on a number of factors including the type of aircraft, the takeoff weight (including passengers, cargo, and fuel), engine types, flap settings, landing speed, elevation of the airport, and average maximum daily air temperature; paved runways can reach a length of 5,000 m (16,000 ft.), but the “typical” length of a commercial airline runway is between 2,500-4,000 m (8,000-13,000 ft.)
Airports - with unpaved runways:
2
note:
unpaved runways have a surface composition such as grass or packed earth and are most suited to the operation of light aircraft; unpaved runways are usually short, often less than 1,000 m (3,280 ft.) in length; airports with unpaved runways often lack facilities for refueling, maintenance, or air traffic control
Pipelines:
257 km condensate, 11 km condensate/gas, 1,567 km gas, 587 km oil (2013)
Merchant marine:
total:
102 (2022)
by type:
general cargo 1, other 101
comparison ranking:
total 89
Ports and terminals:
major seaport(s):
Point Fortin, Point Lisas, Port of Spain, Scarborough
oil terminal(s):
Galeota Point terminal
LNG terminal(s) (export):
Port Fortin','e24186fc28058f36c45cf2fbc5ea7e65a2cbe0d6877813281bc67b731179db59','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('35dc7388706ecf832cc711775738551f34498e1d67f4e8523f9ab87facfd30e7',2025,'TN','Tunisia','transportation',9,'National air transport system:
number of registered air carriers:
7 (2020)
inventory of registered aircraft operated by air carriers:
53
annual passenger traffic on registered air carriers:
4,274,199 (2018)
annual freight traffic on registered air carriers:
13.23 million (2018) mt-km
Civil aircraft registration country code prefix:
TS
Airports:
29 (2021)
comparison ranking:
total 119
Airports - with paved runways:
15
note:
paved runways have a concrete or asphalt surface but not all have facilities for refueling, maintenance, or air traffic control; the length of a runway required for aircraft to safely operate depends on a number of factors including the type of aircraft, the takeoff weight (including passengers, cargo, and fuel), engine types, flap settings, landing speed, elevation of the airport, and average maximum daily air temperature; paved runways can reach a length of 5,000 m (16,000 ft.), but the “typical” length of a commercial airline runway is between 2,500-4,000 m (8,000-13,000 ft.)
Airports - with unpaved runways:
14
note:
unpaved runways have a surface composition such as grass or packed earth and are most suited to the operation of light aircraft; unpaved runways are usually short, often less than 1,000 m (3,280 ft.) in length; airports with unpaved runways often lack facilities for refueling, maintenance, or air traffic control
Pipelines:
68 km condensate, 3,111 km gas, 1,381 km oil, 453 km refined products (2013)
Railways:
total:
2,173 km (2014) (1,991 in use)
standard gauge:
471 km (2014) 1.435-m gauge
narrow gauge:
1,694 km (2014) 1.000-m gauge (65 km electrified)
dual gauge:
8 km (2014) 1.435-1.000-m gauge
comparison ranking:
total 70
Roadways:
paved:
20,000 km (2015)
Merchant marine:
total:
70 (2022)
by type:
container ship 1, general cargo 8, oil tanker 1, other 60
comparison ranking:
total 108
Ports and terminals:
major seaport(s):
Bizerte, Gabes, Rades, Sfax, Skhira','efa54b0f663f139f19967c4a43e6cbed2aa323309af549c9c3e953713c4ebedf','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('44a5b72596e4ee91c10fffa43597fb0356888578725a7326c88e1618602bca22',2025,'TN','Tunisia','transportation',22,'National air transport system:
number of registered air carriers:
11 (2020)
inventory of registered aircraft operated by air carriers:
618
annual passenger traffic on registered air carriers:
115,595,495 (2018)
annual freight traffic on registered air carriers:
5,949,210,000 (2018) mt-km
Civil aircraft registration country code prefix:
TC
Airports:
98 (2021)
comparison ranking:
total 57
Airports - with paved runways:
91
note:
paved runways have a concrete or asphalt surface but not all have facilities for refueling, maintenance, or air traffic control; the length of a runway required for aircraft to safely operate depends on a number of factors including the type of aircraft, the takeoff weight (including passengers, cargo, and fuel), engine types, flap settings, landing speed, elevation of the airport, and average maximum daily air temperature; paved runways can reach a length of 5,000 m (16,000 ft.), but the “typical” length of a commercial airline runway is between 2,500-4,000 m (8,000-13,000 ft.)
Airports - with unpaved runways:
7
note:
unpaved runways have a surface composition such as grass or packed earth and are most suited to the operation of light aircraft; unpaved runways are usually short, often less than 1,000 m (3,280 ft.) in length; airports with unpaved runways often lack facilities for refueling, maintenance, or air traffic control
Heliports:
20 (2021)
Pipelines:
14,666 km gas, 3,293 km oil (2017)
Railways:
total:
11,497 km (2018)
standard gauge:
11,497 km (2018) 1.435-m gauge (1.435 km high speed train)
comparison ranking:
total 21
Roadways:
total:
67,333 km (2018)
paved:
24,082 km (2018) (includes 2,159 km of expressways)
unpaved:
43,251 km (2018)
comparison ranking:
total 71
Waterways:
1,200 km (2010)
comparison ranking:
62
Merchant marine:
total:
1,237 (2022)
by type:
bulk carrier 37, container ship 41, general cargo 288, oil tanker 130, other 741
comparison ranking:
total 20
Ports and terminals:
major seaport(s):
Aliaga, Ambarli, Diliskelesi, Eregli, Izmir, Kocaeli (Izmit), Mersin (Icel), Limani, Yarimca
container port(s) (TEUs):
Ambarli (2,942,550), Mersin (Icel) (2,106,937), Izmet (1,967,946) (2021)
LNG terminal(s) (import):
Aliaga, Dortyol, Ekti (Izmir), Marmara Ereglisi','460c7a55325b4efc505cb52d039f132195dc225316c4306ee8d0b2ed4fb4e167','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('33564263ac8bd37dae67bfeca0e4bec67bbf4d069329730dc0a0aa9139faa895',2025,'TM','Turkmenistan','transportation',35,'National air transport system:
number of registered air carriers:
1 (2020)
inventory of registered aircraft operated by air carriers:
27
annual passenger traffic on registered air carriers:
2,457,474 (2018)
annual freight traffic on registered air carriers:
16.92 million (2018) mt-km
Civil aircraft registration country code prefix:
EZ
Airports:
26 (2021)
comparison ranking:
total 125
Airports - with paved runways:
21
note:
paved runways have a concrete or asphalt surface but not all have facilities for refueling, maintenance, or air traffic control; the length of a runway required for aircraft to safely operate depends on a number of factors including the type of aircraft, the takeoff weight (including passengers, cargo, and fuel), engine types, flap settings, landing speed, elevation of the airport, and average maximum daily air temperature; paved runways can reach a length of 5,000 m (16,000 ft.), but the “typical” length of a commercial airline runway is between 2,500-4,000 m (8,000-13,000 ft.)
Airports - with unpaved runways:
5
note:
unpaved runways have a surface composition such as grass or packed earth and are most suited to the operation of light aircraft; unpaved runways are usually short, often less than 1,000 m (3,280 ft.) in length; airports with unpaved runways often lack facilities for refueling, maintenance, or air traffic control
Heliports:
1 (2021)
Pipelines:
7,500 km gas, 1501 km oil (2013)
Railways:
total:
5,113 km (2017)
broad gauge:
5,113 km (2017) 1.520-m gauge
comparison ranking:
total 37
Roadways:
total:
58,592 km (2002)
paved:
47,577 km (2002)
unpaved:
11,015 km (2002)
comparison ranking:
total 77
Waterways:
1,300 km (2011) (Amu Darya River and Kara Kum Canal are important inland waterways)
comparison ranking:
59
Merchant marine:
total:
72 (2022)
by type:
general cargo 6, oil tanker 8, other 58
comparison ranking:
total 105
Ports and terminals:
major seaport(s):
Caspian Sea - Turkmenbasy','153da2b35061804201063cd38df169ab4d2c80e7dbd6854503f6712e8ddb2b4b','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7e3a961b69dbd1b60ab30e7cc5ff401e94c953cb3289e76314461fd7f42653d5',2025,'TC','Turks and Caicos Islands','transportation',47,'National air transport system:
number of registered air carriers:
3 (2020)
inventory of registered aircraft operated by air carriers:
22
Civil aircraft registration country code prefix:
VQ-T
Airports:
8 (2021)
comparison ranking:
total 162
Airports - with paved runways:
6
note:
paved runways have a concrete or asphalt surface but not all have facilities for refueling, maintenance, or air traffic control; the length of a runway required for aircraft to safely operate depends on a number of factors including the type of aircraft, the takeoff weight (including passengers, cargo, and fuel), engine types, flap settings, landing speed, elevation of the airport, and average maximum daily air temperature; paved runways can reach a length of 5,000 m (16,000 ft.), but the “typical” length of a commercial airline runway is between 2,500-4,000 m (8,000-13,000 ft.)
Airports - with unpaved runways:
2
note:
unpaved runways have a surface composition such as grass or packed earth and are most suited to the operation of light aircraft; unpaved runways are usually short, often less than 1,000 m (3,280 ft.) in length; airports with unpaved runways often lack facilities for refueling, maintenance, or air traffic control
Roadways:
total:
121 km (2003)
paved:
24 km (2003)
unpaved:
97 km (2003)
comparison ranking:
total 212
Merchant marine:
total:
3 (2022)
by type:
general cargo 1, other 2
comparison ranking:
total 174
Ports and terminals:
major seaport(s):
Cockburn Harbour, Grand Turk, Providenciales','9bdb5c8258ef80b6a68f58139b5765fd44b07e09c9c2cda39f286f949a23e613','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bf75888c2b58aada71738e5cc6ec168ee02d6ea4ad37d3a033c6c58d74fd2c9e',2025,'TV','Tuvalu','transportation',58,'Civil aircraft registration country code prefix:
T2
Airports:
1 (2021)
comparison ranking:
total 213
Airports - with unpaved runways:
1
note:
unpaved runways have a surface composition such as grass or packed earth and are most suited to the operation of light aircraft; unpaved runways are usually short, often less than 1,000 m (3,280 ft.) in length; airports with unpaved runways often lack facilities for refueling, maintenance, or air traffic control
Roadways:
total:
8 km (2011)
paved:
8 km (2011)
comparison ranking:
total 223
Merchant marine:
total:
260 (2022)
by type:
bulk carrier 23, container ship 3, general cargo 39, oil tanker 24, other 171
comparison ranking:
total 60
Ports and terminals:
major seaport(s):
Funafuti','404685e6dbc278d0c9d6defa3a1653bfe7087045d49442c715b1e925858b40de','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('da2912018bccd70b79069f4027541b08ce459c20e9fa0191f28337808156ca64',2025,'UG','Uganda','transportation',9,'National air transport system:
number of registered air carriers:
6 (2020)
inventory of registered aircraft operated by air carriers:
26
annual passenger traffic on registered air carriers:
21,537 (2018)
Civil aircraft registration country code prefix:
5X
Airports:
47 (2021)
comparison ranking:
total 92
Airports - with paved runways:
5
note:
paved runways have a concrete or asphalt surface but not all have facilities for refueling, maintenance, or air traffic control; the length of a runway required for aircraft to safely operate depends on a number of factors including the type of aircraft, the takeoff weight (including passengers, cargo, and fuel), engine types, flap settings, landing speed, elevation of the airport, and average maximum daily air temperature; paved runways can reach a length of 5,000 m (16,000 ft.), but the “typical” length of a commercial airline runway is between 2,500-4,000 m (8,000-13,000 ft.)
Airports - with unpaved runways:
42
note:
unpaved runways have a surface composition such as grass or packed earth and are most suited to the operation of light aircraft; unpaved runways are usually short, often less than 1,000 m (3,280 ft.) in length; airports with unpaved runways often lack facilities for refueling, maintenance, or air traffic control
Railways:
total:
1,244 km (2014)
narrow gauge:
1,244 km (2014) 1.000-m gauge
comparison ranking:
total 85
Roadways:
total:
20,544 km (2017) (excludes local roads)
paved:
4,257 km (2017)
unpaved:
16,287 km (2017)
comparison ranking:
total 111
Waterways:
907 km (2022) (there are no long navigable stretches of river in Uganda; parts of the Albert Nile (210 km) that flow out of Lake Albert (160 km) in the northwestern part of the country are navigable; several lakes including Lake Victoria (337 km) and Lake Kyoga (199.5) have substantial traffic; Lake Albert is navigable along a 200-km stretch from its northern tip to its southern shores)
comparison ranking:
74
Ports and terminals:
lake port(s):
Entebbe, Jinja, Port Bell (Lake Victoria)','031c281ee3d30b78456838f5daac55dd66e63e762ba8cc81d859e53bfc4104ce','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('93c81c64db1613f3257de6a8d13fc55082b49ba8f8c22e6bbd4dcf6c83e5e6f6',2025,'UA','Ukraine','transportation',22,'National air transport system:
number of registered air carriers:
14 (2020)
inventory of registered aircraft operated by air carriers:
126
annual passenger traffic on registered air carriers:
7,854,842 (2018)
annual freight traffic on registered air carriers:
75.26 million (2018) mt-km
Civil aircraft registration country code prefix:
UR
Airports:
215 (2021)
comparison ranking:
total 26
Airports - with paved runways:
108
civil airports:
17
military airports:
15
joint use (civil-military) airports:
4
other airports:
72
note:
paved runways have a concrete or asphalt surface but not all have facilities for refueling, maintenance, or air traffic control; the length of a runway required for aircraft to safely operate depends on a number of factors including the type of aircraft, the takeoff weight (including passengers, cargo, and fuel), engine types, flap settings, landing speed, elevation of the airport, and average maximum daily air temperature; paved runways can reach a length of 5,000 m (16,000 ft.), but the “typical” length of a commercial airline runway is between 2,500-4,000 m (8,000-13,000 ft.)
Airports - with unpaved runways:
79
note:
unpaved runways have a surface composition such as grass or packed earth and are most suited to the operation of light aircraft; unpaved runways are usually short, often less than 1,000 m (3,280 ft.) in length; airports with unpaved runways often lack facilities for refueling, maintenance, or air traffic control
Heliports:
9 (2021)
Pipelines:
36,720 km gas, 4,514 km oil, 4,363 km refined products (2013)
Railways:
total:
21,733 km (2014)
standard gauge:
49 km (2014) 1.435-m gauge (49 km electrified)
broad gauge:
21,684 km (2014) 1.524-m gauge (9,250 km electrified)
comparison ranking:
total 12
Roadways:
total:
169,694 km (2012)
paved:
166,095 km (2012) (includes 17 km of expressways)
unpaved:
3,599 km (2012)
comparison ranking:
total 31
Waterways:
1,672 km (2012) (most on Dnieper River)
comparison ranking:
48
Merchant marine:
total:
410 (2022)
by type:
bulk carrier 1, container ship 1, general cargo 84, oil tanker 15, other 309
comparison ranking:
total 47
Ports and terminals:
major seaport(s):
Feodosiia, Chornomorsk, Mariupol, Mykolaiv, Odesa, Yuzhne
river port(s):
Kherson, Kyiv (Dnieper River), Mykolaiv (Pivdennyy Buh River)','9e166eda4a4f46f331af94b771984a95f14d3b370b7c68cecded437d427745d8','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5c9d70ed11f979a8ec8d90b5041cde27e59c48ba04efbc5ac30c951b237e9e8e',2025,'AE','United Arab Emirates','transportation',34,'National air transport system:
number of registered air carriers:
10 (2020)
inventory of registered aircraft operated by air carriers:
497
annual passenger traffic on registered air carriers:
95,533,069 (2018)
annual freight traffic on registered air carriers:
15,962,900,000 (2018) mt-km
Civil aircraft registration country code prefix:
A6
Airports:
43 (2021)
comparison ranking:
total 99
Airports - with paved runways:
25
note:
paved runways have a concrete or asphalt surface but not all have facilities for refueling, maintenance, or air traffic control; the length of a runway required for aircraft to safely operate depends on a number of factors including the type of aircraft, the takeoff weight (including passengers, cargo, and fuel), engine types, flap settings, landing speed, elevation of the airport, and average maximum daily air temperature; paved runways can reach a length of 5,000 m (16,000 ft.), but the “typical” length of a commercial airline runway is between 2,500-4,000 m (8,000-13,000 ft.)
Airports - with unpaved runways:
18
note:
unpaved runways have a surface composition such as grass or packed earth and are most suited to the operation of light aircraft; unpaved runways are usually short, often less than 1,000 m (3,280 ft.) in length; airports with unpaved runways often lack facilities for refueling, maintenance, or air traffic control
Heliports:
5 (2021)
Pipelines:
533 km condensate, 3,277 km gas, 300 km liquid petroleum gas, 3287 km oil, 24 km oil/gas/water, 218 km refined products, 99 km water (2013)
Roadways:
total:
4,080 km (2008)
paved:
4,080 km (2008) (includes 253 km of expressways)
comparison ranking:
total 154
Merchant marine:
total:
636 (2022)
by type:
bulk carrier 2, container ship 3, general cargo 121, oil tanker 16, other 494
comparison ranking:
total 36
Ports and terminals:
major seaport(s):
Al Fujayrah, Mina’ Jabal ‘Ali (Dubai), Khor Fakkan (Khawr Fakkan) (Sharjah), Mubarraz Island (Abu Dhabi), Mina’ Rashid (Dubai), Mina’ Saqr (Ra’s al Khaymah)
container port(s) (TEUs):
Dubai Port (13,742,000) (2021)
LNG terminal(s) (export):
Das Island
Aerial view of the busy seaport of Mina’ Jabal ‘Ali, United Arab Emirates.:','8261e0b2428e1a536b3b5b7660496785bbc6867d4d253a0f0cac10f9ff31cbe1','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c841a96f6228bb77de00a25692e04161eb949cb5f4f8d9da963754ab9abd3980',2025,'GB','United Kingdom','transportation',46,'National air transport system:
number of registered air carriers:
20 (2020)
inventory of registered aircraft operated by air carriers:
794
annual passenger traffic on registered air carriers:
165,388,610 (2018)
annual freight traffic on registered air carriers:
6,198,370,000 (2018) mt-km
Civil aircraft registration country code prefix:
G
Airports:
460 (2021)
comparison ranking:
total 16
Airports - with paved runways:
271
civil airports:
51
military airports:
25
joint use (civil-military) airports:
1
other airports:
194
note:
paved runways have a concrete or asphalt surface but not all have facilities for refueling, maintenance, or air traffic control; the length of a runway required for aircraft to safely operate depends on a number of factors including the type of aircraft, the takeoff weight (including passengers, cargo, and fuel), engine types, flap settings, landing speed, elevation of the airport, and average maximum daily air temperature; paved runways can reach a length of 5,000 m (16,000 ft.), but the “typical” length of a commercial airline runway is between 2,500-4,000 m (8,000-13,000 ft.)
Airports - with unpaved runways:
189
note:
unpaved runways have a surface composition such as grass or packed earth and are most suited to the operation of light aircraft; unpaved runways are usually short, often less than 1,000 m (3,280 ft.) in length; airports with unpaved runways often lack facilities for refueling, maintenance, or air traffic control
Heliports:
9 (2021)
Pipelines:
502 km condensate, 9 km condensate/gas, 28,603 km gas, 59 km liquid petroleum gas, 5,256 km oil, 175 km oil/gas /water, 4,919 km refined products, 255 km water (2013)
Railways:
total:
16,390 km (2020) 6,167 km electrified
comparison ranking:
total 18
Roadways:
total:
394,428 km (2009)
paved:
394,428 km (2009) (includes 3,519 km of expressways)
comparison ranking:
total 19
Waterways:
3,200 km (2009) (620 km used for commerce)
comparison ranking:
33
Merchant marine:
total:
1,174 (2022)
by type:
bulk carrier 133, container ship 58, general cargo 97, oil tanker 73, other 813
comparison ranking:
total 23
Ports and terminals:
major seaport(s):
Dover, Felixstowe, Immingham, Liverpool, London, Southampton, Teesport (England); Forth Ports (Scotland); Milford Haven (Wales)
oil terminal(s):
Fawley Marine terminal, Liverpool Bay terminal (England); Braefoot Bay terminal, Finnart oil terminal, Hound Point terminal (Scotland)
container port(s) (TEUs):
Felixstowe (3,700,000), London (3,111,000), Southampton (1,871,081) (2021)
LNG terminal(s) (import):
Dragon, Isle of Grain, South Hook, Teesside
Transportation - note:
note 1:
begun in 1988 and completed in 1994, the Channel Tunnel (nicknamed the Chunnel) is a 50.5-km (31.4-mi) rail tunnel beneath the English Channel at the Strait of Dover that runs from Folkestone, Kent, England to Coquelles, Pas-de-Calais in northern France; it is the only fixed link between the island of Great Britain and mainland Europe
note 2:
the UK operates one PC 3 or 4 class medium icebreaker in the South Atlantic in support of operations in Antarctica
note - PC indicates a Polar Class vessel:
PC 3 - year-round operation in second-year ice which may include multi-year ice inclusions (ice thickness up to 2.5 m); PC 4 - year-round operation in thick first-year ice which may include old ice inclusions (ice thickness up to 120 cm)','ae077c9141afc78f29f726622075fcfbb548d7f8a13e394a04ddfbd83bd3dfe1','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('198b8ee7a301fde04fd3b8ee0512b32290f8bd613043157a24d047698368a679',2025,'US','United States','transportation',9,'National air transport system:
number of registered air carriers:
99 (2020)
inventory of registered aircraft operated by air carriers:
7,249
annual passenger traffic on registered air carriers:
889.022 million (2018)
annual freight traffic on registered air carriers:
42,985,300,000 (2018) mt-km
Civil aircraft registration country code prefix:
N
Airports:
13,513 (2022)
note
- 24.5% of airports are public
comparison ranking:
total 1
Airports - with paved runways:
5,054
civil airports:
1,606
military airports:
162
joint use (civil-military) airports:
31
other airports:
3,255
note:
paved runways have a concrete or asphalt surface but not all have facilities for refueling, maintenance, or air traffic control; the length of a runway required for aircraft to safely operate depends on a number of factors including the type of aircraft, the takeoff weight (including passengers, cargo, and fuel), engine types, flap settings, landing speed, elevation of the airport, and average maximum daily air temperature; paved runways can reach a length of 5,000 m (16,000 ft.), but the “typical” length of a commercial airline runway is between 2,500-4,000 m (8,000-13,000 ft.)
Airports - with unpaved runways:
8,459
note:
unpaved runways have a surface composition such as grass or packed earth and are most suited to the operation of light aircraft; unpaved runways are usually short, often less than 1,000 m (3,280 ft.) in length; airports with unpaved runways often lack facilities for refueling, maintenance, or air traffic control
Heliports:
6,092 (2022)
Pipelines:
1,984,321 km natural gas, 240,711 km petroleum products (2013)
Railways:
total:
293,564.2 km (2014)
standard gauge:
293,564.2 km (2014) 1.435-m gauge
comparison ranking:
total 1
Roadways:
total:
6,586,610 km (2012)
paved:
4,304,715 km (2012) (includes 76,334 km of expressways)
unpaved:
2,281,895 km (2012)
comparison ranking:
total 1
Waterways:
41,009 km (2012) (19,312 km used for commerce; Saint Lawrence Seaway of 3,769 km, including the Saint Lawrence River of 3,058 km, is shared with Canada)
comparison ranking:
5
Merchant marine:
total:
178 (2022)
by type:
bulk carrier 4, container ship 61, general cargo 19, oil tanker 65, other (roll on/roll off 29)
note
- oceangoing self-propelled, cargo-carrying vessels of 1,000 gross tons and above
comparison ranking:
total 70
Ports and terminals:
major seaport(s):
Atlantic Ocean:
Charleston, Hampton Roads, New York/New Jersey, Savannah
Pacific Ocean:
Long Beach, Los Angeles, Oakland, Seattle/Tacoma
Gulf of Mexico:
Houston
oil terminal(s):
LOOP terminal, Haymark terminal
container port(s) (TEUs):
Charleston (2,751,442), Hampton Roads (3,522,834), Houston (3,453,220), Long Beach (9,384,368), Los Angeles (10,677,610), New York/New Jersey (8,985,929), Oakland (2,448,243), Savannah (5,613,163), Seattle/Tacoma (3,736,206) (2021)
LNG terminal(s) (export):
Calcasieu Pass (LA), Cameron (LA), Corpus Christi (TX), Cove Point (MD), Elba Island (GA), Freeport (TX), Sabine Pass (LA)
note
- two additional export facilities are under construction and expected to begin commercial operations in 2023-2024
LNG terminal(s) (import):
Cove Point (MD), Elba Island (GA), Everett (MA), Freeport (TX), Golden Pass (TX), Hackberry (LA), Lake Charles (LA), Neptune (offshore), Northeast Gateway (offshore), Pascagoula (MS), Sabine Pass (TX)
river port(s):
Baton Rouge, Plaquemines, New Orleans (Mississippi River)
cargo ports:
Baton Rouge, Corpus Christi, Hampton Roads, Houston, Long Beach, Los Angeles, New Orleans, New York, Plaquemines (LA), Tampa, Texas City
cruise departure ports (passengers):
Miami, Port Everglades, Port Canaveral, Seattle, Long Beach
Transportation - note:
the US operates one PC 1 or 2 class heavy icebreaker, two PC 3 or 4 class medium icebreakers, and two PC 5 or 6 class light icebreakers; the heavy and medium icebreakers carry out various polar missions including opening passage for the annual resupply of McMurdo Station in Antarctica
note - PC indicates a Polar Class vessel:
PC 1 - year-round operation in all polar waters (ice thickness >3 m); PC 2 - year-round operation in moderate multi-year ice conditions (ice thickness up to 3 m); PC 3 - year-round operation in second-year ice which may include multi-year ice inclusions (ice thickness up to 2.5 m); PC 4 - year-round operation in thick first-year ice which may include old ice inclusions (ice thickness up to 120 cm); PC 5 - year-round operation in medium first-year ice which may include old ice inclusions (ice thickness up to 70-120 cm); PC 6 - summer/autumn operation in medium first-year ice which may include old ice inclusions (ice thickness up to 30-70 cm)','d7f321c6684943be0ff95f96d512ceb72c15e308ed917917a06110e64d895dc7','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('da39a33eb546d3958e6c049c64c26db86fbc1a23c914cf57907d76cf1a5a1283',2025,'US','United States','transportation',19,'Airports: Midway Islands:
(2013) 3 - one operational (2,377 m paved); no fuel for sale except emergencies
Airports - with paved runways:
note - abandoned but usable
Ports and terminals:
major seaport(s):
Baker, Howland, and Jarvis Islands, and Kingman Reef','6d6b4b1797063633e946aff9e685b853371baea44465bc3a827003b7b8f8c5f0','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8d1a4d53c5bb5118e391e87f56f8f79254547585277b6610bffb09f242f4fdb2',2025,'UY','Uruguay','transportation',30,'National air transport system:
number of registered air carriers:
2 (2020)
inventory of registered aircraft operated by air carriers:
5
Civil aircraft registration country code prefix:
CX
Airports:
133 (2021)
comparison ranking:
total 42
Airports - with paved runways:
11
note:
paved runways have a concrete or asphalt surface but not all have facilities for refueling, maintenance, or air traffic control; the length of a runway required for aircraft to safely operate depends on a number of factors including the type of aircraft, the takeoff weight (including passengers, cargo, and fuel), engine types, flap settings, landing speed, elevation of the airport, and average maximum daily air temperature; paved runways can reach a length of 5,000 m (16,000 ft.), but the “typical” length of a commercial airline runway is between 2,500-4,000 m (8,000-13,000 ft.)
Airports - with unpaved runways:
122
note:
unpaved runways have a surface composition such as grass or packed earth and are most suited to the operation of light aircraft; unpaved runways are usually short, often less than 1,000 m (3,280 ft.) in length; airports with unpaved runways often lack facilities for refueling, maintenance, or air traffic control
Pipelines:
257 km gas, 160 km oil (2013)
Railways:
total:
1,673 km (2016) (operational; government claims overall length is 2,961 km)
standard gauge:
1,673 km (2016) 1.435-m gauge
comparison ranking:
total 79
Roadways:
total:
77,732 km (2010)
paved:
7,743 km (2010)
unpaved:
69,989 km (2010)
comparison ranking:
total 63
Waterways:
1,600 km (2011)
comparison ranking:
50
Merchant marine:
total:
60 (2022)
by type:
container ship 1, general cargo 4, oil tanker 4, other 51
comparison ranking:
total 113
Ports and terminals:
major seaport(s):
Montevideo','387eb696c6370dba57d36f1a12de3f0d858d0badac12afd7929de8881afbb09f','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('abe4c83438738495556cbff8af308e2070462fa415be2ad9256ea6d169f830aa',2025,'UZ','Uzbekistan','transportation',42,'National air transport system:
number of registered air carriers:
2 (2020)
inventory of registered aircraft operated by air carriers:
34
annual passenger traffic on registered air carriers:
3,056,558 (2018)
annual freight traffic on registered air carriers:
89.43 million (2018) mt-km
Civil aircraft registration country code prefix:
UK
Airports:
53 (2021)
comparison ranking:
total 88
Airports - with paved runways:
33
civil airports:
9
military airports:
3
joint use (civil-military) airports:
1
other airports:
20
note:
paved runways have a concrete or asphalt surface but not all have facilities for refueling, maintenance, or air traffic control; the length of a runway required for aircraft to safely operate depends on a number of factors including the type of aircraft, the takeoff weight (including passengers, cargo, and fuel), engine types, flap settings, landing speed, elevation of the airport, and average maximum daily air temperature; paved runways can reach a length of 5,000 m (16,000 ft.), but the “typical” length of a commercial airline runway is between 2,500-4,000 m (8,000-13,000 ft.)
Airports - with unpaved runways:
20
note:
unpaved runways have a surface composition such as grass or packed earth and are most suited to the operation of light aircraft; unpaved runways are usually short, often less than 1,000 m (3,280 ft.) in length; airports with unpaved runways often lack facilities for refueling, maintenance, or air traffic control
Pipelines:
13,700 km gas, 944 km oil (2016)
Railways:
total:
4,642 km (2018)
broad gauge:
4,642 km (2018) 1.520-m gauge (1,684 km electrified)
comparison ranking:
total 41
Roadways:
total:
86,496 km (2000)
paved:
75,511 km (2000)
unpaved:
10,985 km (2000)
comparison ranking:
total 56
Waterways:
1,100 km (2012)
comparison ranking:
66
Ports and terminals:
river port(s):
Termiz (Amu Darya)','29c8aafd51a29f7845848f65b3695420da8dbd2f060b1e2158b4121eb95c72fe','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('926658c5fd1e500d127e4261244dee8270ad3eab74e63315084886e95b73b65b',2025,'VU','Vanuatu','transportation',9,'National air transport system:
number of registered air carriers:
1 (2020)
inventory of registered aircraft operated by air carriers:
8
annual passenger traffic on registered air carriers:
374,603 (2018)
annual freight traffic on registered air carriers:
1.66 million (2018) mt-km
Civil aircraft registration country code prefix:
YJ
Airports:
31 (2021)
comparison ranking:
total 113
Airports - with paved runways:
3
note:
paved runways have a concrete or asphalt surface but not all have facilities for refueling, maintenance, or air traffic control; the length of a runway required for aircraft to safely operate depends on a number of factors including the type of aircraft, the takeoff weight (including passengers, cargo, and fuel), engine types, flap settings, landing speed, elevation of the airport, and average maximum daily air temperature; paved runways can reach a length of 5,000 m (16,000 ft.), but the “typical” length of a commercial airline runway is between 2,500-4,000 m (8,000-13,000 ft.)
Airports - with unpaved runways:
28
note:
unpaved runways have a surface composition such as grass or packed earth and are most suited to the operation of light aircraft; unpaved runways are usually short, often less than 1,000 m (3,280 ft.) in length; airports with unpaved runways often lack facilities for refueling, maintenance, or air traffic control
Roadways:
total:
1,070 km (2000)
paved:
256 km (2000)
unpaved:
814 km (2000)
comparison ranking:
total 184
Merchant marine:
total:
331 (2022)
by type:
bulk carrier 16, container ship 4, general cargo 87, oil tanker 2, other 222
comparison ranking:
total 51
Ports and terminals:
major seaport(s):
Forari Bay, Luganville (Santo, Espiritu Santo), Port-Vila','7af407d03e9fe46c2ca3f87071083047436d41701d587525f2d890a74177f3cb','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0b59aed306827b04a4413f6dbba159d0e5116bc512459d60b0a062353568d1f1',2025,'VU','Vanuatu','transportation',20,'National air transport system:
number of registered air carriers:
12 (2020)
inventory of registered aircraft operated by air carriers:
75
annual passenger traffic on registered air carriers:
2,137,771 (2018)
annual freight traffic on registered air carriers:
1.55 million (2018) mt-km
Civil aircraft registration country code prefix:
YV
Airports:
444 (2021)
comparison ranking:
total 17
Airports - with paved runways:
127
note:
paved runways have a concrete or asphalt surface but not all have facilities for refueling, maintenance, or air traffic control; the length of a runway required for aircraft to safely operate depends on a number of factors including the type of aircraft, the takeoff weight (including passengers, cargo, and fuel), engine types, flap settings, landing speed, elevation of the airport, and average maximum daily air temperature; paved runways can reach a length of 5,000 m (16,000 ft.), but the “typical” length of a commercial airline runway is between 2,500-4,000 m (8,000-13,000 ft.)
Airports - with unpaved runways:
317
note:
unpaved runways have a surface composition such as grass or packed earth and are most suited to the operation of light aircraft; unpaved runways are usually short, often less than 1,000 m (3,280 ft.) in length; airports with unpaved runways often lack facilities for refueling, maintenance, or air traffic control
Heliports:
3 (2021)
Pipelines:
981 km extra heavy crude, 5941 km gas, 7,588 km oil, 1,778 km refined products (2013)
Railways:
total:
447 km (2014)
standard gauge:
447 km (2014) 1.435-m gauge (41.4 km electrified)
comparison ranking:
total 114
Roadways:
total:
96,189 km (2014)
comparison ranking:
total 49
Waterways:
7,100 km (2011) (Orinoco River (400 km) and Lake de Maracaibo navigable by oceangoing vessels)
comparison ranking:
22
Merchant marine:
total:
272 (2022)
by type:
bulk carrier 3, container ship 1, general cargo 25, oil tanker 17, other 226
comparison ranking:
total 58
Ports and terminals:
major seaport(s):
La Guaira, Maracaibo, Puerto Cabello, Punta Cardon
oil terminal(s):
Jose terminal','576826a6a45bde48ab85d4617d13d480065400e3e3d0c0e31405f031f06532fc','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('45e1932f1e8f920e74e530626efc5775bc66265a8a01945c0dc71b1a4492f0a9',2025,'VU','Vanuatu','transportation',33,'National air transport system:
number of registered air carriers:
5 (2020)
inventory of registered aircraft operated by air carriers:
224
annual passenger traffic on registered air carriers:
47,049,671 (2018)
annual freight traffic on registered air carriers:
481.37 million (2018) mt-km
Civil aircraft registration country code prefix:
VN
Airports:
45 (2021)
comparison ranking:
total 96
Airports - with paved runways:
38
note:
paved runways have a concrete or asphalt surface but not all have facilities for refueling, maintenance, or air traffic control; the length of a runway required for aircraft to safely operate depends on a number of factors including the type of aircraft, the takeoff weight (including passengers, cargo, and fuel), engine types, flap settings, landing speed, elevation of the airport, and average maximum daily air temperature; paved runways can reach a length of 5,000 m (16,000 ft.), but the “typical” length of a commercial airline runway is between 2,500-4,000 m (8,000-13,000 ft.)
Airports - with unpaved runways:
7
note:
unpaved runways have a surface composition such as grass or packed earth and are most suited to the operation of light aircraft; unpaved runways are usually short, often less than 1,000 m (3,280 ft.) in length; airports with unpaved runways often lack facilities for refueling, maintenance, or air traffic control
Heliports:
1 (2021)
Pipelines:
72 km condensate, 398 km condensate/gas, 955 km gas, 128 km oil, 33 km oil/gas/water, 206 km refined products, 13 km water (2013)
Railways:
total:
2,600 km (2014)
standard gauge:
178 km (2014) 1.435-m gauge; 253 km mixed gauge
narrow gauge:
2,169 km (2014) 1.000-m gauge
comparison ranking:
total 64
Roadways:
total:
195,468 km (2013)
paved:
148,338 km (2013)
unpaved:
47,130 km (2013)
comparison ranking:
total 28
Waterways:
47,130 km (2011) (30,831 km weight under 50 tons)
comparison ranking:
3
Merchant marine:
total:
1,975 (2022)
by type:
bulk carrier 116, container ship 42, general cargo 1,194, oil tanker 137, other 486
comparison ranking:
total 12
Ports and terminals:
major seaport(s):
Cam Pha Port, Da Nang, Haiphong, Phu My, Quy Nhon
container port(s) (TEUs):
Saigon (7,956,133), Cai Mep (5,385,289), Haiphong (5,695,839) (2021)
river port(s):
Ho Chi Minh (Mekong)','dfeacff8ca1a498ee87a06e19e360259e19890a804d4bb3d9c1d5ed3ae0fd0f7','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('82f2725a632eeb67e30997653a3444420c3f275960d1bffe7964d01b1cd8f362',2025,'VU','Vanuatu','transportation',45,'Airports:
2 (2021)
comparison ranking:
total 207
Airports - with paved runways:
2
note:
paved runways have a concrete or asphalt surface but not all have facilities for refueling, maintenance, or air traffic control; the length of a runway required for aircraft to safely operate depends on a number of factors including the type of aircraft, the takeoff weight (including passengers, cargo, and fuel), engine types, flap settings, landing speed, elevation of the airport, and average maximum daily air temperature; paved runways can reach a length of 5,000 m (16,000 ft.), but the “typical” length of a commercial airline runway is between 2,500-4,000 m (8,000-13,000 ft.)
Roadways:
total:
1,260 km (2008)
comparison ranking:
total 178
Merchant marine:
total:
1,868 (2019)
by type:
bulk carrier 91, container ship 39, general cargo 1,205, oil tanker 118, other 415
comparison ranking:
total 13
Ports and terminals:
major seaport(s):
Charlotte Amalie, Christiansted, Cruz Bay, Frederiksted, Limetree Bay','4ef295ae9796384892f814b94af532db5ac86af01916c4e156934a82fa8a0edc','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e8cafb7ec4917fa7c47256b4768667fb1a4966db8dc0555a41b08d715365fe19',2025,'WF','Wallis and Futuna','transportation',9,'Airports:
2 (2021)
comparison ranking:
total 199
Airports - with paved runways:
2
note:
paved runways have a concrete or asphalt surface but not all have facilities for refueling, maintenance, or air traffic control; the length of a runway required for aircraft to safely operate depends on a number of factors including the type of aircraft, the takeoff weight (including passengers, cargo, and fuel), engine types, flap settings, landing speed, elevation of the airport, and average maximum daily air temperature; paved runways can reach a length of 5,000 m (16,000 ft.), but the “typical” length of a commercial airline runway is between 2,500-4,000 m (8,000-13,000 ft.)
Merchant marine:
total:
1 (2021)
by type:
other 1
comparison ranking:
total 183
Ports and terminals:
major seaport(s):
Leava, Mata-Utu','e227c4c1980109fb368bce4963b1c273d98ffaace0cb1f53fde3caeefeb554e2','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ffe2d4c2f9f9c8e922d1c99bc7294093be25713c4f67901c665e42b5de8d1a8b',2025,'WF','Wallis and Futuna','transportation',20,'Airports:
2 (2021)
comparison ranking:
total 198
Airports - with paved runways:
2
note:
paved runways have a concrete or asphalt surface but not all have facilities for refueling, maintenance, or air traffic control; the length of a runway required for aircraft to safely operate depends on a number of factors including the type of aircraft, the takeoff weight (including passengers, cargo, and fuel), engine types, flap settings, landing speed, elevation of the airport, and average maximum daily air temperature; paved runways can reach a length of 5,000 m (16,000 ft.), but the “typical” length of a commercial airline runway is between 2,500-4,000 m (8,000-13,000 ft.)
Heliports:
1 (2021)
Roadways:
total:
4,686 km (2010)
paved:
4,686 km (2010)
note:
includes Gaza Strip
comparison ranking:
total 149','a41d2097f16c1248da0054fb5aa300acf9f48ead0318177355a72ee6c5e1d1da','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('232d9dbb6b1e39f1a98802f3e585db463236c9d1741ca9515bd7284db74bc9b7',2025,'WF','Wallis and Futuna','transportation',34,'Airports:
41,820 (2021)
top ten by passengers (2021):
Atlanta (ATL) - 75,704,760; Dallas/Fort Worth, TX (DFW) 62,465,756; Denver, CO (DEN) 58,828,552; Chicago, IL (ORD) 54,020,399; Los Angeles, CA (LAX) 48,007,284; Charlotte, NC (CLT) 43,302,230; Orlando, FL (MCO) 40,351,068; Guangzhou (CAN) 40,259,401; Chengdu (CTU) 40,117,496; Las Vegas, NV (LAS) 39,754,366 (2021)
top ten by passengers (2020):
Guangzhou (CAN) 43,767,558; Atlanta (ATL) - 42,918,685; Chengdu (CTU) 40,741,509; Dallas/Fort Worth, TX (DFW) 39,364,990; Shenzhen (SZX) 37,916,054; Beijing (PEK) - 34,513,827; Denver, CO (DEN) 33,741,129; Kunming (KMG) 32,990,805; Shanghai (PVG) 31,165,641; Xi’an (XIY) 31,073,924 (2020)
note
- 2020 numbers included to allow for a comparison with the effects of COVID-19 restrictions on international air travel in 2020
top ten by cargo (metric tons):
Hong Kong (HKG) - 5,025,495; Memphis, TN (MEM) - 4,480,465; Shanghai (PVG) - 3,982,616; Anchorage, AK (ANC) - 3,555,160; Incheon (ICN) - 3,329,292; Louisville, KY (SDF) - 3,052,269; Taipei (TPE) - 2,812,065; Los Angeles, CA (LAX) 2,691,830; Tokyo (NRT) 2,644,074; Doha, Qatar (DOH) 2,620,095 (2021)
Heliports:
6,524 (2021)
Railways:
total:
1,148,186 km (2013)
Waterways:
2,293,412 km (2017)
top ten longest rivers:
Nile (Africa) 6,693 km; Amazon (South America) 6,436 km; Mississippi-Missouri (North America) 6,238 km; Yenisey-Angara (Asia) 5,981 km; Ob-Irtysh (Asia) 5,569 km; Yangtze (Asia) 5,525 km; Yellow (Asia) 4,671 km; Amur (Asia) 4,352 km; Lena (Asia) 4,345 km; Congo (Africa) 4,344 km
note 1:
rivers are not necessarily navigable along the entire length; if measured by volume, the Amazon is the largest river in the World, responsible for about 20% of the Earth’s freshwater entering the ocean
note 2:
there are 20 countries without rivers: 3 in Africa (Comoros, Djibouti, Libya); 1 in the Americas (Bahamas); 8 in Asia (Bahrain, Kuwait, Maldives, Oman, Qatar, Saudi Arabia, United Arab Emirates, Yemen); 3 in Europe (Malta, Monaco, Holy See), 5 in Oceania (Kiribati, Marshall Islands, Nauru, Tonga, Tuvalu); these countries also do not have natural lakes
top ten largest natural lakes (by surface area):
Caspian Sea (Azerbaijan, Iran, Kazakhstan, Russia, Turkmenistan) 372,960 sq km; Lake Superior (Canada, United States) 82,414 sq km; Lake Victoria (Kenya, Tanzania, Uganda) 69,490 sq km; Lake Huron (Canada, United States) 59,596 sq km; Lake Michigan (United States) 57,441 sq km; Lake Tanganyika (Burundi, Democratic Republic of the Congo, Tanzania, Zambia) 32,890 sq km; Great Bear Lake (Canada) 31,800 sq km; Lake Baikal (Russia) 31,494 sq km; Lake Nyasa (Malawi, Mozambique, Tanzania) 30,044 sq km; Great Slave Lake (Canada) 28,400 sq km
note 1:
the areas of the lakes are subject to seasonal variation; only the Caspian Sea is saline, the rest are fresh water
note 2:
Lakes Huron and Michigan are technically a single lake because the flow of water between the Straits of Mackinac that connects the two lakes keeps their water levels at near-equilibrium; combined, Lake Huron-Michigan is the largest freshwater lake by surface area in the World
note 3:
the deepest lake in the world (1,620 m), and also the largest freshwater lake by volume (23,600 cu km), is Lake Baikal in Russia
Merchant marine:
total:
101,158 (2022)
by type:
bulk carrier 12,707, container ship 5,583, general cargo 19,647, oil tanker 11,396, other 51,825
Ports and terminals:
top twenty container ports as measured by Twenty-Foot Equivalent Units (TEUs) throughput:
Shanghai (China) - 47,030,300; Singapore (Singapore) - 37,470,000; Ningbo (China) - 31,070,000; Shenzhen (China) - 28,767,600; Guangzhou (China) - 24,180,000; Qingdao (China) - 23,710,000; Busan (South Korea) - 22,706,130; Tianjin (China) - 20,269,400; Hong Kong (China) - 17,798,000; Rotterdam (Netherlands) - 15,300,000; Dubai (UAE) - 13,742,000; Port Kelang (Malaysia) - 13,724,460; Xiamen (China) - 12,045,700; Antwerp (Belgium) - 12,020,000; Tanjung Pelepas (Malaysia) - 11,200,000; Los Angeles (US) - 10,677,610; Kaohsiung (Taiwan) - 9,864,448; Long Beach (US) - 9,384,368; New York/New Jersey (US) - 8,985,929; Hamburg (Germany) - 8,715,000 (2021)','7cfa7ed2ce86ced670341b28e20d5a07ed743c65acda83a0de4eb01371d41517','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('83c91089cffe42bfcc40728765b7f5314f8fbf8cf83f8b719d6d10352a9906e8',2025,'YE','Yemen','transportation',9,'National air transport system:
number of registered air carriers:
2 (2020)
inventory of registered aircraft operated by air carriers:
8
annual passenger traffic on registered air carriers:
336,310 (2018)
annual freight traffic on registered air carriers:
3.27 million (2018) mt-km
Civil aircraft registration country code prefix:
7O
Airports:
57 (2021)
comparison ranking:
total 82
Airports - with paved runways:
17
note:
paved runways have a concrete or asphalt surface but not all have facilities for refueling, maintenance, or air traffic control; the length of a runway required for aircraft to safely operate depends on a number of factors including the type of aircraft, the takeoff weight (including passengers, cargo, and fuel), engine types, flap settings, landing speed, elevation of the airport, and average maximum daily air temperature; paved runways can reach a length of 5,000 m (16,000 ft.), but the “typical” length of a commercial airline runway is between 2,500-4,000 m (8,000-13,000 ft.)
Airports - with unpaved runways:
40
note:
unpaved runways have a surface composition such as grass or packed earth and are most suited to the operation of light aircraft; unpaved runways are usually short, often less than 1,000 m (3,280 ft.) in length; airports with unpaved runways often lack facilities for refueling, maintenance, or air traffic control
Pipelines:
641 km gas, 22 km liquid petroleum gas, 1,370 km oil (2013)
Roadways:
total:
71,300 km (2005)
paved:
6,200 km (2005)
unpaved:
65,100 km (2005)
comparison ranking:
total 67
Merchant marine:
total:
30 (2022)
by type:
general cargo 2, oil tanker 1, other 27
comparison ranking:
total 134
Ports and terminals:
major seaport(s):
Aden, Al Hudaydah, Al Mukalla','06d368f7523c71a52531aa92783e66d6b1691914ffed1652ccc64ece56979435','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('20a9e8aa7e397193059fec82ca0ac77a449fec3f815bba0bc5aee6735a6a9ffe',2025,'ZM','Zambia','transportation',9,'National air transport system:
number of registered air carriers:
3 (2020)
inventory of registered aircraft operated by air carriers:
6
annual passenger traffic on registered air carriers:
8,904 (2018)
annual freight traffic on registered air carriers:
75.08 million (2018) mt-km
Civil aircraft registration country code prefix:
9J
Airports:
88 (2021)
comparison ranking:
total 64
Airports - with paved runways:
8
note:
paved runways have a concrete or asphalt surface but not all have facilities for refueling, maintenance, or air traffic control; the length of a runway required for aircraft to safely operate depends on a number of factors including the type of aircraft, the takeoff weight (including passengers, cargo, and fuel), engine types, flap settings, landing speed, elevation of the airport, and average maximum daily air temperature; paved runways can reach a length of 5,000 m (16,000 ft.), but the “typical” length of a commercial airline runway is between 2,500-4,000 m (8,000-13,000 ft.)
Airports - with unpaved runways:
80
note:
unpaved runways have a surface composition such as grass or packed earth and are most suited to the operation of light aircraft; unpaved runways are usually short, often less than 1,000 m (3,280 ft.) in length; airports with unpaved runways often lack facilities for refueling, maintenance, or air traffic control
Pipelines:
771 km oil (2013)
Railways:
total:
3,126 km (2014)
narrow gauge:
3,126 km (2014) 1.067-m gauge
note:
includes 1,860 km of the Tanzania-Zambia Railway Authority (TAZARA)
comparison ranking:
total 57
Roadways:
total:
67,671 km (2018)
paved:
14,888 km (2018)
unpaved:
52,783 km (2018)
comparison ranking:
total 70
Waterways:
2,250 km (2010) (includes Lake Tanganyika and the Zambezi and Luapula Rivers)
comparison ranking:
39
Merchant marine:
total:
2 (2022)
by type:
general cargo 1, oil tanker 1
comparison ranking:
total 177
Ports and terminals:
river port(s):
Mpulungu (Zambezi)','a3aee115ab1cb57e33c350c334dc9d3d0fe3a96068e8580795bac48f77ab101c','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d41733be29b53d9898886e6846185b3e22e29dadb4d7009aed131eacf14eb1e8',2025,'ZW','Zimbabwe','transportation',20,'National air transport system:
number of registered air carriers:
2 (2020)
inventory of registered aircraft operated by air carriers:
12
annual passenger traffic on registered air carriers:
285,539 (2018)
annual freight traffic on registered air carriers:
670,000 (2018) mt-km
Civil aircraft registration country code prefix:
Z
Airports:
196 (2021)
comparison ranking:
total 30
Airports - with paved runways:
17
note:
paved runways have a concrete or asphalt surface but not all have facilities for refueling, maintenance, or air traffic control; the length of a runway required for aircraft to safely operate depends on a number of factors including the type of aircraft, the takeoff weight (including passengers, cargo, and fuel), engine types, flap settings, landing speed, elevation of the airport, and average maximum daily air temperature; paved runways can reach a length of 5,000 m (16,000 ft.), but the “typical” length of a commercial airline runway is between 2,500-4,000 m (8,000-13,000 ft.)
Airports - with unpaved runways:
179
note:
unpaved runways have a surface composition such as grass or packed earth and are most suited to the operation of light aircraft; unpaved runways are usually short, often less than 1,000 m (3,280 ft.) in length; airports with unpaved runways often lack facilities for refueling, maintenance, or air traffic control
Pipelines:
270 km refined products (2013)
Railways:
total:
3,427 km (2014)
narrow gauge:
3,427 km (2014) 1.067-m gauge (313 km electrified)
comparison ranking:
total 55
Roadways:
total:
97,267 km (2019)
paved:
18,481 km (2019)
unpaved:
78,786 km (2019)
comparison ranking:
total 48
Waterways:
223 km (2022) some navigation possible on Lake Kariba (223 km)
comparison ranking:
104
Ports and terminals:
river port(s):
Binga, Kariba (Zambezi)','25abaab52031d928165cee465824be4f7cf814669a1e2bcd6f48d73c29794a1d','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);

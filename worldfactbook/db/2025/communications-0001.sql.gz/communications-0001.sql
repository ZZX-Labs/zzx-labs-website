SET NAMES utf8mb4;
CREATE TABLE IF NOT EXISTS worldfactbook_chunks (
  chunk_id CHAR(64) NOT NULL,
  edition_year SMALLINT UNSIGNED NOT NULL,
  entity_code VARCHAR(24) NOT NULL DEFAULT '',
  entity_name VARCHAR(160) NOT NULL DEFAULT '',
  category VARCHAR(96) NOT NULL,
  ordinal INT UNSIGNED NOT NULL,
  content MEDIUMTEXT NOT NULL,
  content_sha256 CHAR(64) NOT NULL,
  source_provider VARCHAR(64) NOT NULL,
  source_identifier VARCHAR(255) NOT NULL,
  source_format VARCHAR(32) NOT NULL,
  source_sha256 CHAR(64) NOT NULL,
  source_url TEXT NOT NULL,
  extractor VARCHAR(64) NOT NULL,
  PRIMARY KEY (chunk_id),
  KEY idx_wfb_year_category (edition_year, category),
  KEY idx_wfb_entity_year (entity_code, edition_year),
  KEY idx_wfb_source_sha (source_sha256)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a708a6afdfd0fc9fd677d816af3c2d782965beece0790370da8d108a286f7232',2025,'AF','Afghanistan','communications',8,'Telephones - fixed lines:
total subscriptions:
150,000 (2021 est.)
subscriptions per 100 inhabitants:
(2021 est.) less than 1
comparison ranking:
total subscriptions 126
Telephones - mobile cellular:
total subscriptions:
23 million (2021 est.)
subscriptions per 100 inhabitants:
57 (2021 est.)
comparison ranking:
total subscriptions 54
Telecommunication systems:
general assessment:
Afghanistan’s telecom sector is facing challenges providing adequate coverage to all of the population; prior to the Taliban regaining power, the World Bank and other donors supported the development of a nationwide fiber backbone and there is terrestrial cable connectivity to five neighboring countries; work on the ‘Wakhan Corridor Fiber Optic Survey Project’ to connect to China has faced obstacles because of Afghanistan’s economic issues. (2021)
domestic:
before the Taliban takeover in August 2021, less than 1 per 100 for fixed-line teledensity; 57 per 100 for mobile-cellular subscriptions (2021)
international:
country code - 93; multiple VSAT’s provide international and domestic voice and data connectivity (2019)
Broadcast media:
under the Taliban government, independent media outlets have decreased in number and are probably self-censoring criticism of the Taliban and the Ministry of Information and Culture monitors all mass media in Afghanistan; television and radio are key media platforms; only about a fifth of Afghans use the internet, mostly through smartphones (2023)
Internet country code:
.af
Internet users:
total:
7.02 million (2020 est.)
percent of population:
18% (2020 est.)
comparison ranking:
total 79
Broadband - fixed subscriptions:
total:
26,570 (2020 est.)
subscriptions per 100 inhabitants:
0.1 (2020 est.)
comparison ranking:
total 157','d8e48dde014b39ef865fe4154640aff80c31f6cb2fb9e237391e7b908d34ef11','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('39093693a7c0d9b3b9bea99c7fa06dc234b78e4895ef7a964b3875f1fc568422',2025,'AF','Afghanistan','communications',19,'Broadcast media:
British Forces Broadcast Service (BFBS) provides multi-channel satellite TV service as well as BFBS radio broadcasts to the Akrotiri Sovereign Base Area','4743bb1d50cd15297fd73c41c7b04deab3be1c6f05c3a5f7898c1c61ed176ce2','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1f0d7afaa0846ee9ff4dd5c3e212e1fccdce5a8da4a01398e7cbf99704255611',2025,'AL','Albania','communications',29,'Telephones - fixed lines:
total subscriptions:
197,690 (2021 est.)
subscriptions per 100 inhabitants:
7 (2021 est.)
comparison ranking:
total subscriptions 122
Telephones - mobile cellular:
total subscriptions:
2,635,466 (2021 est.)
subscriptions per 100 inhabitants:
92 (2021 est.)
comparison ranking:
total subscriptions 145
Telecommunication systems:
general assessment:
Albania’s small telecom market has experienced some significant changes in recent years; upgrades were made to the fixed-line infrastructure to support broadband services; fixed-line telephony use and penetration in Albania is declining steadily as subscribers migrate to mobile solutions; the mobile sector is well provided with LTE networks, while operators have invested in 5G; some of these efforts have been made in conjunction with neighboring Kosovo, with the intention of a seamless 5G corridor along the highway connecting the two countries; the country has long sought accession to the European Union (EU) which has benefited its telecoms sector through closer scrutiny of its regulatory regime and through the injection of funding to help modernize infrastructure (2021)
domestic:
fixed-line approximately 7 per 100, teledensity continues to decline due to heavy use of mobile-cellular telephone services; mobile-cellular telephone use is widespread and generally effective, 92 per 100 for mobile-cellular (2021)
international:
country code - 355; submarine cables for the Adria 1 and Italy-Albania provide connectivity to Italy, Croatia, and Greece; a combination submarine cable and land fiber-optic system, provides additional connectivity to Bulgaria, Macedonia, and Turkey; international traffic carried by fiber-optic cable and, when necessary, by microwave radio relay from the Tirana exchange to Italy and Greece (2019)
Broadcast media:
Albania has more than 65 TV stations, including several that broadcast nationally; Albanian TV broadcasts are also available to Albanian-speaking populations in neighboring countries; many viewers have access to Italian and Greek TV broadcasts via terrestrial reception; Albania’s TV stations have begun a government-mandated conversion from analog to digital broadcast; the government has pledged to provide analog-to-digital converters to low-income families affected by this decision; cable TV service is available; 2 public radio networks and roughly 78 private radio stations; several international broadcasters are available (2019)
Internet country code:
.al
Internet users:
total:
2.291 million (2021 est.)
percent of population:
79% (2021 est.)
comparison ranking:
total 132
Broadband - fixed subscriptions:
total:
508,937 (2020 est.)
subscriptions per 100 inhabitants:
18 (2020 est.)
comparison ranking:
total 91','7bd58fc98d37faa7f67c738274cb2a1d71685ff2cc9bbfd24c914a9e4c38830a','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d894b55532f4f4280d04a00142eca8dc8c48f9d201013a9b5260feb3287b2366',2025,'DZ','Algeria','communications',41,'Telephones - fixed lines:
total subscriptions:
5,097,095 (2021 est.)
subscriptions per 100 inhabitants:
12 (2021 est.)
comparison ranking:
total subscriptions 26
Telephones - mobile cellular:
total subscriptions:
47,028,685 (2021 est.)
subscriptions per 100 inhabitants:
106 (2021 est.)
comparison ranking:
total subscriptions 35
Telecommunication systems:
general assessment:
Algeria has a steadily developing telecom infrastructure with growth encouraged by supportive regulatory measures and by government policies aimed at delivering serviceable internet connections across the country; mobile broadband is largely based on 3G and LTE, and the data rates are also low in global terms; LTE is available in all provinces, investment is required from the mobile network operators (MNOs) to improve the quality of service; the state has previously been hesitant to commit to 5G, instead encouraging the MNOs to undertake upgrades to LTE infrastructure before investing in commercial 5G services; in March 2022, the state is in the process of freeing up the requisite spectrum to enable the MNOs to launch 5G services sometime this year; fixed internet speeds remain slow (2022)
domestic:
a limited network of fixed-lines with a teledensity of slightly less than 12 telephones per 100 persons has been offset by the rapid increase in mobile-cellular subscribership; mobile-cellular teledensity was approximately 106 telephones per 100 persons in 2020 (2021)
international:
country code - 213; ALPAL-2 is a submarine telecommunications cable system in the Mediterranean Sea linking Algeria and the Spanish Balearic island of Majorca; ORVAL is a submarine cable to Spain; landing points for the TE North/TGN-Eurasia/SEACOM/SeaMeWe-4 fiber-optic submarine cable system that provides links to Europe, the Middle East, and Asia; MED cable connecting Algeria with France; microwave radio relay to Italy, France, Spain, Morocco, and Tunisia; Algeria part of the 4,500 Km terrestrial Trans Sahara Backbone network which connects to other fiber networks in the region; Alcomstat-1 satellite offering telemedicine network (2020)
Broadcast media:
state-run Radio-Television Algerienne operates the broadcast media and carries programming in Arabic, Berber dialects, and French; use of satellite dishes is widespread, providing easy access to European and Arab satellite stations; state-run radio operates several national networks and roughly 40 regional radio stations
Internet country code:
.dz
Internet users:
total:
31.24 million (2021 est.)
percent of population:
71% (2021 est.)
comparison ranking:
total 32
Broadband - fixed subscriptions:
total:
3,790,459 (2020 est.)
subscriptions per 100 inhabitants:
9 (2020 est.)
comparison ranking:
total 40','5de77e5c369bf02cea6a82fa8119fa795f3093fe789200dd099bc101bcd8db62','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('42a2e5a1198d6de11ea9313110e756e00ba8c24d7a7ce431728c29f389734bb8',2025,'AS','American Samoa','communications',54,'Telephones - fixed lines:
total subscriptions:
10,000 (2021 est.)
subscriptions per 100 inhabitants:
22 (2021 est.)
comparison ranking:
total subscriptions 191
Telephones - mobile cellular:
total subscriptions:
2,250 (2009 est.)
subscriptions per 100 inhabitants:
4 (2009 est.)
comparison ranking:
total subscriptions 224
Telecommunication systems:
general assessment:
American Samoa Telecommunications Authority, ASTCA, supplies telecommunication services to the residents of the American Samoan islands, a territory of the United States, which are found in a remote area of the Pacific Ocean; the primary system between the islands consists of fiber-optic cables and satellite connections; over Independence Day weekend 2021, the undersea fiber-optic cable linking the Tutuila and Manu’a Islands failed, completely stranding the Manu’a Islands from all telecommunication services; telecommunication services were restored to the people of Manu’a islands through microwave link between Tutuila to the Manu’a Islands; the link is now providing a steady 1 Gbps backhaul most of the time of the year with 600Mbps at four 9’s availability, over this extremely long distance (2022)
domestic:
nearly 22 per 100 fixed-line teledensity (2020)
international:
country code - 1-684; landing points for the ASH, Southern Cross NEXT and Hawaiki providing connectivity to New Zealand, Australia, American Samoa, Hawaii, California, and SAS connecting American Samoa with Samoa; satellite earth station - 1 (Intelsat-Pacific Ocean) (2019)
Broadcast media:
3 TV stations; multi-channel pay TV services are available; about a dozen radio stations, some of which are repeater stations
Internet country code:
.as
Internet users:
total:
18,135 (2021 est.)
percent of population:
40.3% (2021 est.)
comparison ranking:
total 213','486d3b7af0fa0d72ea6df035589e7e2cfdcbd6631aebd84c8de4840126d30e1e','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e5b02e574893d638db278cec016a9350156682cd7dc54b8fc8049864d164b629',2025,'AD','Andorra','communications',65,'Telephones - fixed lines:
total subscriptions:
50,000 (2021 est.)
subscriptions per 100 inhabitants:
63 (2021 est.)
comparison ranking:
total subscriptions 156
Telephones - mobile cellular:
total subscriptions:
89,000 (2021 est.)
subscriptions per 100 inhabitants:
110 (2021 est.)
comparison ranking:
total subscriptions 194
Telecommunication systems:
general assessment:
Andorra has a modern telecommunications system with microwave radio relay connections between the exchanges and land line circuits to France and Spain (2020)
domestic:
about 63 per 100 fixed-line, 110 per 100 mobile-cellular (2021)
international:
country code - 376; landline circuits to France and Spain; modern system with microwave radio relay connections between exchanges (2019)
Broadcast media:
1 public TV station and 2 public radio stations; about 10 commercial radio stations; good reception of radio and TV broadcasts from stations in France and Spain; upgraded to terrestrial digital TV broadcasting in 2007; roughly 25 international TV channels available (2019)
Internet country code:
.ad
Internet users:
total:
74,260 (2021 est.)
percent of population:
94% (2021 est.)
comparison ranking:
total 193
Broadband - fixed subscriptions:
total:
37,000 (2020 est.)
subscriptions per 100 inhabitants:
48 (2020 est.)
comparison ranking:
total 146','194c3858d313054498d96107cff7e5f729ecc70e3780593722534f0a270c0f48','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('689cd5bd82b6e72daadcd29d1a80ae69e79be9990f55a2c1fdb3ccff83640d55',2025,'AO','Angola','communications',8,'Telephones - fixed lines:
total subscriptions:
119,826 (2021 est.)
subscriptions per 100 inhabitants:
(2021 est.) less than 1
comparison ranking:
total subscriptions 132
Telephones - mobile cellular:
total subscriptions:
15,327,864 (2021 est.)
subscriptions per 100 inhabitants:
44 (2021 est.)
comparison ranking:
total subscriptions 70
Telecommunication systems:
general assessment:
Angola’s telecom sector in recent years has benefited from political stability, which has encouraged foreign investment in the sector; the government and regulator have also set in train mechanisms to open up the telecom sector to new competitors, mobile services were launched in April 2022; the MNOs were slow to develop LTE services, instead relying on their GSM and 3G network capabilities; there has been slow progress in LTE network development, with only a small proportion of the country covered by network infrastructure; the Ministry of Telecommunications in early 2021 set up a 5G hub to assess 5G user cases; the regulator in November 2021 granted licenses to various companies offering 5G services, with spectrum in the 3.3-3.7GHz range having been set aside for such services (2022)
domestic:
less than one fixed-line per 100 persons; mobile-cellular teledensity about 44 telephones per 100 persons (2021)
international:
country code - 244; landing points for the SAT-3/WASC, WACS, ACE and SACS fiber-optic submarine cable that provides connectivity to other countries in west Africa, Brazil, Europe and Asia; satellite earth stations - 29, Angosat-2 satellite expected by 2021 (2019)
Broadcast media:
state controls all broadcast media with nationwide reach; state-owned Televisao Popular de Angola (TPA) provides terrestrial TV service on 2 channels; a third TPA channel is available via cable and satellite; TV subscription services are available; state-owned Radio Nacional de Angola (RNA) broadcasts on 5 stations; about a half-dozen private radio stations broadcast locally
Internet country code:
.ao
Internet users:
total:
11.55 million (2021 est.)
percent of population:
33% (2021 est.)
comparison ranking:
total 55
Broadband - fixed subscriptions:
total:
230,610 (2020 est.)
subscriptions per 100 inhabitants:
0.7 (2020 est.)
comparison ranking:
total 116','225cf3eec7ba25a24eee01d9d175c0022d5fa795f7ed699362c102a88aaf4091','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4e65b8d678f5261600eee1ed2209182cb0c01ac1c58726ef30720018fd2ff26f',2025,'AI','Anguilla','communications',20,'Telephones - fixed lines:
total subscriptions:
6,000 (2021 est.)
subscriptions per 100 inhabitants:
38 (2021 est.)
comparison ranking:
total subscriptions 201
Telephones - mobile cellular:
total subscriptions:
26,000 (2021 est.)
subscriptions per 100 inhabitants:
170 (2021 est.)
comparison ranking:
total subscriptions 212
Telecommunication systems:
general assessment:
in the telecom sector, with declines seen in subscriber numbers (particularly for prepaid mobile services — the mainstay of short-term visitors) and revenue; fixed and mobile broadband services are two areas that have benefited from the crisis to a small extent as employees and students have resorted to working from home, but their contribution to the sector has been insufficient to offset steep falls in other areas of the market; one area of the telecom market that does not yet appear poised for growth is 5G mobile; governments, regulators, and even the mobile network operators have shown that they have little appetite for investing in 5G opportunities at the present time; network expansion and enhancements remain concentrated around improving LTE coverage; until the economies and markets stabilize, and overseas visitors return there is unlikely to be much momentum towards implementing 5G capabilities anywhere in the region (2021)
domestic:
fixed-line teledensity is about 38 per 100 persons; mobile-cellular teledensity is roughly 170 per 100 persons (2021)
international:
country code - 1-264; landing points for the SSCS, ECFS, GCN and Southern Caribbean Fiber with submarine cable links to Caribbean islands and to the US; microwave radio relay to island of Saint Martin/Sint Maarten (2019)
Broadcast media:
1 private TV station; multi-channel cable TV subscription services are available; about 10 radio stations, one of which is government-owned
Internet country code:
.ai
Internet users:
total:
13,056 (2021 est.)
percent of population:
81.6% (2021 est.)
comparison ranking:
total 215
Broadband - fixed subscriptions:
total:
5,000 (2018 est.)
subscriptions per 100 inhabitants:
35 (2018 est.)
comparison ranking:
total 186','659c2ab50772189459a719035a99bede70984bee517b280ce9e3f4026700fb3a','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('906a7ee510d0375e3d6f420c0c01579206dbd3c38cf97283e1862b7247fc9f65',2025,'AQ','Antarctica','communications',30,'Telecommunication systems:
general assessment:
scientists with the United States Antarctic Program at McMurdo Station have now got their hands on a Starlink terminal of their own, where it is said to be improving connectivity as they carry out their research; this was made possible through laser links between the SpaceX satellites in orbit that eliminate the need for ground stations at the poles, and makes Antarctica the seventh and final continent to receive Starlink internet coverage (2022)
domestic:
commercial cellular networks operating in a small number of locations (2019)
international:
country code - none allocated; via satellite (including mobile Inmarsat and Iridium systems) to and from all research stations, ships, aircraft, and most field parties
Internet country code:
.aq
Internet users:
total:
4,400 (2021 est.)
percent of population:
100% (2021 est.)
comparison ranking:
total 224','632991b64c7d729e1de256d0ffd9e57352ddea8e9862f3b2772930624d6acfd7','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a42044c956ceb134fad17df42b4164b4296ad44776ad7224f5150a33b67be9e7',2025,'AG','Antigua and Barbuda','communications',41,'Telephones - fixed lines:
total subscriptions:
27,000 (2021 est.)
subscriptions per 100 inhabitants:
27 (2021 est.)
comparison ranking:
total subscriptions 168
Telephones - mobile cellular:
total subscriptions:
180,000 (2021 est.)
subscriptions per 100 inhabitants:
200 (2021 est.)
comparison ranking:
total subscriptions 185
Telecommunication systems:
general assessment:
the telecom sector has seen a decline in subscriber numbers (particularly for prepaid mobile services the mainstay of short term visitors) and revenue; fixed and mobile broadband services are two areas that have benefited from the crisis as employees and students have resorted to working from home; one area of the telecom market that is not prepared for growth is 5G mobile; governments, regulators, and even the mobile network operators have shown that they have not been investing in 5G opportunities at the present time; network expansion and enhancements remain concentrated around improving LTE coverage (2021)
domestic:
fixed-line teledensity roughly 27 per 100 persons; mobile-cellular teledensity is about 200 per 100 persons (2021)
international:
country code - 1-268; landing points for the ECFS and Southern Caribbean Fiber submarine cable systems with links to other islands in the eastern Caribbean; satellite earth stations - 1 Intelsat (Atlantic Ocean) (2019)
Broadcast media:
state-controlled Antigua and Barbuda Broadcasting Service (ABS) operates 1 TV station; multi-channel cable TV subscription services are available; ABS operates 1 radio station; roughly 15 radio stations, some broadcasting on multiple frequencies
Internet country code:
.ag
Internet users:
total:
89,280 (2021 est.)
percent of population:
96% (2021 est.)
comparison ranking:
total 191
Broadband - fixed subscriptions:
total:
8,000 (2020 est.)
subscriptions per 100 inhabitants:
8 (2020 est.)
comparison ranking:
total 181','04929290b71a9516af79e7c658c70dca3f779f33cdea351729b6c88494e947f4','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('203163427b07f3dfea9831bd1a1184b6e4158936389cac81cd1ae1cea9b6750f',2025,'AR','Argentina','communications',58,'Telephones - fixed lines:
total subscriptions:
6,903,068 (2021 est.)
subscriptions per 100 inhabitants:
15 (2021 est.)
comparison ranking:
total subscriptions 22
Telephones - mobile cellular:
total subscriptions:
59,065,827 (2021 est.)
subscriptions per 100 inhabitants:
130 (2021 est.)
comparison ranking:
total subscriptions 28
Telecommunication systems:
general assessment:
Argentina’s ongoing problem with hyperinflation continues to distort the telecom market’s performance, which shows strong growth in revenue but only modest gains in subscriber numbers each year; the fixed broadband segment has penetration levels only slightly higher than the fixed-line teledensity; nearly a quarter of the country’s broadband connections are via DSL, although fiber is starting claim an increasing share of that market as networks expand across most of the main cities; mobile broadband continues to be the preferred platform for internet access, supported by high mobile penetration levels and nationwide LTE coverage; the first 5G service was launched in February 2021 using refarmed LTE frequencies; the anticipated 5G spectrum auctions should drive even stronger uptake in mobile broadband services; while the various fixed, mobile, and cable operators push to expand and enhance their services, the government is also making an active contribution towards boosting broadband connectivity around the country; its national connectivity plan ‘Plan Conectar’, launched in September 2020, provides funding for a range of programs to increase coverage; in August 2021, the telecom regulator announced the release funding to help operators accelerate the rollout of their broadband infrastructure and services (2021)
domestic:
roughly 15 per 100 fixed-line and 130 per 100 mobile-cellular; microwave radio relay, fiber-optic cable, and a domestic satellite system with 40 earth stations serve the trunk network (2021)
international:
country code - 54; landing points for the UNISUR, Bicentenario, Atlantis-2, SAm-1, and SAC, Tannat, Malbec and ARBR submarine cable systems that provide links to Europe, Africa, South and Central America, and US; satellite earth stations - 112 (2019)
Broadcast media:
government owns a TV station and radio network; more than two dozen TV stations and hundreds of privately owned radio stations; high rate of cable TV subscription usage (2022)
Internet country code:
.ar
Internet users:
total:
39.15 million (2021 est.)
percent of population:
87% (2021 est.)
comparison ranking:
total 25
Broadband - fixed subscriptions:
total:
9,571,562 (2020 est.)
subscriptions per 100 inhabitants:
21 (2020 est.)
comparison ranking:
total 20','454f10c3653a4d81d09064c1faef90ccd08916897cf9adc23e38502c9d40436e','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bbcac09c6f438c30251d5194ed72ee0c2089306c2a24c88b4a44f04d3a49fa66',2025,'AM','Armenia','communications',71,'Telephones - fixed lines:
total subscriptions:
418,122 (2021 est.)
subscriptions per 100 inhabitants:
15 (2021 est.)
comparison ranking:
total subscriptions 101
Telephones - mobile cellular:
total subscriptions:
3,599,278 (2021 est.)
subscriptions per 100 inhabitants:
129 (2021 est.)
comparison ranking:
total subscriptions 138
Telecommunication systems:
general assessment:
Armenia’s telecom sector was able to post in the mobile and broadband segments; its fixed-line penetration continues to slide downwards, with the rollout of fiber networks which have encouraged the increase in bundled services; the fixed broadband market remains undeveloped due to the lack of underlying infrastructure outside the main cities (2021)
domestic:
roughly 15 per 100 fixed-line and 129 per 100 mobile-cellular; reliable fixed-line and mobile-cellular services are available across Yerevan and in major cities and towns; mobile-cellular coverage available in most rural areas (2021)
international:
country code - 374; Yerevan is connected to the Caucasus Cable System fiber-optic cable through Georgia and Iran to Europe; additional international service is available by microwave radio relay and landline connections to the other countries of the Commonwealth of Independent States, through the Moscow international switch, and by satellite to the rest of the world; satellite earth stations - 3 (2019)
Broadcast media:
Armenia’s government-run Public Television network operates alongside 100 privately owned TV stations that provide local to near nationwide coverage; three Russian TV companies are broadcast in Armenia under interstate agreements; subscription cable TV services are available in most regions; several major international broadcasters are available, including CNN; Armenian TV completed conversion from analog to digital broadcasting in late 2016; Public Radio of Armenia is a national, state-run broadcast network that operates alongside 18 privately owned radio stations
(2019)
Internet country code:
.am
Internet users:
total:
2.212 million (2021 est.)
percent of population:
79% (2021 est.)
comparison ranking:
total 133
Broadband - fixed subscriptions:
total:
430,407 (2020 est.)
subscriptions per 100 inhabitants:
15 (2020 est.)
comparison ranking:
total 95','cb7ded7ee81a55ba9ae89783ce5c7a5e4fb75a09411a6631ca080aebca579272','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a0e92ec8c46c47d75d6170cc1c3c349f382bd795cb9add92a76e260f08497297',2025,'AW','Aruba','communications',8,'Telephones - fixed lines:
total subscriptions:
35,000 (2021 est.)
subscriptions per 100 inhabitants:
33 (2021 est.)
comparison ranking:
total subscriptions 164
Telephones - mobile cellular:
total subscriptions:
140,000 (2021 est.)
subscriptions per 100 inhabitants:
130 (2021 est.)
comparison ranking:
total subscriptions 188
Telecommunication systems:
general assessment:
the telecom sector has seen a decline in subscriber numbers (particularly for prepaid mobile services the mainstay of short term visitors) and revenue; fixed and mobile broadband services are two areas that have benefited from the crisis as employees and students have resorted to working from home; one area of the telecom market that is not prepared for growth is 5G mobile; governments, regulators, and even the mobile network operators have shown that they have not been investing in 5G opportunities at the present time; network expansion and enhancements remain concentrated around improving LTE coverage (2021)
domestic:
33 per 100 fixed-line telephone subscriptions and 130 per 100 mobile-cellular (2021)
international:
country code - 297; landing points for the PAN-AM, PCCS, Deep Blue Cable, and Alonso de Ojeda submarine telecommunications cable system that extends from Trinidad and Tobago, Florida, Puerto Ricco, Jamaica, Guyana, Sint Eustatius & Saba, Suriname, Dominican Republic, BVI, USVI, Haiti, Cayman Islands, the Netherlands Antilles, through Aruba to Panama, Venezuela, Colombia, Ecuador, Peru and Chile; extensive interisland microwave radio relay links (2019)
Broadcast media:
2 commercial TV stations; cable TV subscription service provides access to foreign channels; about 19 commercial radio stations broadcast (2017)
Internet country code:
.aw
Internet users:
total:
106,800 (2021 est.)
percent of population:
97% (2021 est.)
comparison ranking:
total 187
Broadband - fixed subscriptions:
total:
19,000 (2020 est.)
subscriptions per 100 inhabitants:
18 (2020 est.)
comparison ranking:
total 167','5b79ac692a850a8483eb7823d3f82144d10bbd03b0a011a19b86c1c31f15d698','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a13cdbe174e34ddf36ba6fc0041428276f71ba2c9b57dadd2211305ae7feaa68',2025,'AU','Australia','communications',34,'Telephones - fixed lines:
total subscriptions:
4.6 million (2021 est.)
subscriptions per 100 inhabitants:
18 (2021 est.)
comparison ranking:
total subscriptions 30
Telephones - mobile cellular:
total subscriptions:
27.09 million (2021 est.)
subscriptions per 100 inhabitants:
105 (2021 est.)
comparison ranking:
total subscriptions 48
Telecommunication systems:
general assessment:
the Australian telecom market since 2020 has been impacted by the pandemic, which forced many people to school and work from home and thus adopt fixed-line broadband services; internet traffic, both fixed and mobile, increased substantially as a result; in the fixed sector, there is an ongoing migration from copper-based platforms to fiber; the extension of fixed wireless access will mean that up to 120,000 premises currently dependent on satellite broadband will be able to access 5G-based fixed services; the fixed-line market has been falling steadily over the past five years; in the Australian fixed broadband market, there is a dynamic shift among customers to fiber networks; the DSL sector is steadily shrinking while subscribers on HFC infrastructure will continue to be provided by existing cable, with a steady migration to full fiber connectivity (2022)
domestic:
18 per 100 fixed-line telephone subscriptions and 105 per 100 mobile-cellular; more subscribers to mobile services than there are people; 90% of all mobile device sales are now smartphones, growth in mobile traffic brisk (2021)
international:
country code - 61; landing points for more than 20 submarine cables including: the SeaMeWe-3 optical telecommunications submarine cable with links to Asia, the Middle East, and Europe; the INDIGO-Central, INDIGO West and ASC, North West Cable System, Australia-Papua New Guinea cable, CSCS, PPC-1, Gondwana-1, SCCN, Hawaiki, TGA, Basslink, Bass Strait-1, Bass Strait-2, JGA-S, with links to other Australian cities, New Zealand and many countries in southeast Asia, US and Europe; the H2 Cable, AJC, Telstra Endeavor, Southern Cross NEXT with links to Japan, Hong Kong, and other Pacific Ocean countries as well as the US; satellite earth stations - 10 Intelsat (4 Indian Ocean and 6 Pacific Ocean), 2 Inmarsat, 2 Globalstar, 5 other (2019)
Broadcast media:
the Australian Broadcasting Corporation (ABC) runs multiple national and local radio networks and TV stations, as well as ABC Australia, a TV service that broadcasts in the Asia-Pacific region and is the main public broadcaster; Special Broadcasting Service (SBS), a second large public broadcaster, operates radio and TV networks broadcasting in multiple languages; several large national commercial TV networks, a large number of local commercial TV stations, and hundreds of commercial radio stations are accessible; cable and satellite systems are available (2022)
Internet country code:
.au
Internet users:
total:
24.96 million (2021 est.)
percent of population:
96% (2021 est.)
comparison ranking:
total 34
Broadband - fixed subscriptions:
total:
9,099,619 (2020 est.)
subscriptions per 100 inhabitants:
36 (2020 est.)
comparison ranking:
total 23','d32c7133f90555e64d7249483e8c603bfe8fef3264fda27a7c7ca5b410e3053f','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f05d6341d07524df5af94034ede28bc73726ead3aca23b20b493e2ed80d328fd',2025,'AT','Austria','communications',47,'Telephones - fixed lines:
total subscriptions:
3,808,709 (2021 est.)
subscriptions per 100 inhabitants:
43 (2021 est.)
comparison ranking:
total subscriptions 34
Telephones - mobile cellular:
total subscriptions:
10,882,217 (2021 est.)
subscriptions per 100 inhabitants:
122 (2021 est.)
comparison ranking:
total subscriptions 90
Telecommunication systems:
general assessment:
mature telecom market; the mobile market benefits from a growing number of Mobile Virtual Network Operators; the telcos as well as the government and regulator have been focused on delivering improved telecom infrastructure; the government has a program to provide a national gigabit service by 2030, delivered by private enterprise though with some state funding; this is based on fiber networks supported by 5G, with the Mobile Network Operators able to expand the reach of their 5G services following auctions held in March 2019 and September 2020; the fixed-line broadband market is still dominated by the DSL sector, while the cable broadband sector has held a steady share of connections in recent years; the fiber sector was slow to develop, and although fiber remains low there are plans to build out the network infrastructure (2021)
domestic:
developed and efficient; 43 per 100 fixed telephone subscriptions; 122 per 100 mobile-cellular subscriptions (2021)
international:
country code - 43; earth stations available in the Astra, Intelsat, Eutelsat satellite systems (2019)
Broadcast media:
worldwide cable and satellite TV are available; the public incumbent ORF competes with three other major, several regional domestic, and up to 400 international TV stations; TV coverage is in principle 100%, but only 90% use broadcast media; Internet streaming not only complements, but increasingly replaces regular TV stations (2019)
Internet country code:
.at
Internet users:
total:
8.277 million (2021 est.)
percent of population:
93% (2021 est.)
comparison ranking:
total 71
Broadband - fixed subscriptions:
total:
2.606 million (2020 est.)
subscriptions per 100 inhabitants:
29 (2020 est.)
comparison ranking:
total 49
Communications - note:
note 1:
the Austrian National Library contains important collections of the Imperial Library of the Holy Roman Empire and of the Austrian Empire, as well as of the Austrian Republic; among its more than 12 million items are outstanding holdings of rare books, maps, globes, papyrus, and music; its Globe Museum is the only one in the world
note 2:
on 1 October 1869, Austria-Hungary introduced the world’s first postal card - postal stationery with an imprinted stamp indicating the prepayment of postage; simple and cheap (sent for a fraction of the cost of a regular letter), postal cards became an instant success, widely produced in the millions worldwide
note 3:
Austria followed up with the creation of the world’s first commercial picture postcards - cards bearing a picture or photo to which postage is affixed - in May 1871; sent from Vienna, the image served as a souvenir of the city; together, postal cards and post cards served as the world’s e-mails of the late 19th and early 20th centuries
note 4:
Austria was also an airmail pioneer; from March to October of 1918, it conducted the world’s first regular (daily) airmail service - between the imperial cities of Vienna, Krakow, and Lemberg - a combined distance of some 650 km (400 mi) (earlier airmail services had been set up in a few parts of the world but only for short stretches, and none lasted beyond a few days or weeks); an expansion of the route in June of 1918 allowed private mail to be flown to Kyiv, in newly independent Ukraine, which made the route the world’s first regular international airmail service (covering a distance of some 1,200 km; 750 mi)','77a5bf6beb77f293b914f0d9533a37d1d6b0a05f18a507d66c50fb2464fdf5a6','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('711117009b8f1f1e45375e4f5d0e12d8c1b28771ac6c8e5a98dba71397215bb0',2025,'AZ','Azerbaijan','communications',60,'Telephones - fixed lines:
total subscriptions:
1,644,300 (2021 est.)
subscriptions per 100 inhabitants:
16 (2021 est.)
comparison ranking:
total subscriptions 58
Telephones - mobile cellular:
total subscriptions:
10,817,071 (2021 est.)
subscriptions per 100 inhabitants:
105 (2021 est.)
comparison ranking:
total subscriptions 91
Telecommunication systems:
general assessment:
in spite of the telecom sector being one of the major contributors to Azerbaijan’s non-oil GDP, overall development, growth, and investment in the sector has been held back by years of political and civil unrest coupled with endemic corruption; mobile penetration rates reached 100% as far back as 2011 but have largely stagnated since then; the Mobile Network Operators (MNOs) are slowly extending the reach of their LTE networks around the country, and this increased coverage (along with access to faster data-based services) is expected to produce a moderate resurgence for both mobile and mobile broadband over the next few years as customers migrate from 3G to 4G. 5G services are still some ways off, as the demand for high-speed data and fast broadband can easily be met by existing capacity on LTE networks; fixed-line teledensity continues to drop down each year as customers consolidate their telecommunications services around the mobile platform; the rate of decline is comparatively slower than other countries, since Azerbaijan has a relatively high proportion of (87%) of fixed-line broadband customers still on DSL; fiber is gradually being rolled out in urban areas, and this makes up the bulk of the growth being seen in the overall fixed broadband market; DSL’s predominance, however, will serve to keep Azerbaijan’s average access speeds in the sub-10Mbps range for the foreseeable future (2020)
domestic:
16 fixed-lines subscriptions per 100 persons; mobile-cellular subscriptions of 105 telephones per 100 persons (2021)
international:
country code - 994; Azerbaijan’s largest mobile network operator (MNO) launched trial 5G mobile services in Baku on 27 December 2022 (2023)
Broadcast media:
3 state-run and 1 public TV channels; 4 domestic commercial TV stations and about 15 regional TV stations; cable TV services are available in Baku; 1 state-run and 1 public radio network operating; a small number of private commercial radio stations broadcasting; local FM relays of Baku commercial stations are available in many localities; note - all broadcast media is pro-government, and most private broadcast media outlets are owned by entities directly linked to the government
Internet country code:
.az
Internet users:
total:
8.6 million (2021 est.)
percent of population:
86% (2021 est.)
comparison ranking:
total 67
Broadband - fixed subscriptions:
total:
1,995,474 (2020 est.)
subscriptions per 100 inhabitants:
20 (2020 est.)
comparison ranking:
total 58','3d70abdd42575c9a7ba28fef8f7d6f0920a6024bc01f5fc73fb0270a1b590bb0','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('40a60c00611469b3d6b6a27747c7ea1eec5cbc4ed876acd9985251ccd5eac1f2',2025,'BH','Bahrain','communications',10,'Telephones - fixed lines:
total subscriptions:
266,741 (2021 est.)
subscriptions per 100 inhabitants:
18 (2021 est.)
comparison ranking:
total subscriptions 114
Telephones - mobile cellular:
total subscriptions:
1,923,443 (2021 est.)
subscriptions per 100 inhabitants:
131 (2021 est.)
comparison ranking:
total subscriptions 153
Telecommunication systems:
general assessment:
Bahrain continues to develop its telecoms sector in a bid to develop its long-term Economic Vision 2030 strategy; this is a multi-faceted strategy aimed at developing a digital transformation across numerous sectors, including e-government, e-health, e-commerce, and e-banking; 5G services have become widely available since they were launched in 2020; Bahrain’s telecom sector by the Fourth National Telecommunications Plan (initiated in 2016) which focuses on fiber optic infrastructure deployment and establishing affordable prices for high-speed access (2022)
domestic:
approximately 18 per 100 fixed-line and 131 per 100 mobile-cellular; modern fiber-optic integrated services; digital network with rapidly expanding mobile-cellular telephones (2021)
international:
country code - 973; Bahrain’s Telecommunications Regulatory Authority (TRA) has made part of the C-band spectrum available for 5G private networks, in line with the goals outlined in its Workplan for the 2022-23 period (2023)
Broadcast media:
state-run Bahrain Radio and Television Corporation (BRTC) operates 5 terrestrial TV networks and several radio stations; satellite TV systems provide access to international broadcasts; 1 private FM station directs broadcasts to Indian listeners; radio and TV broadcasts from countries in the region are available (2019)
Internet country code:
.bh
Internet users:
total:
1.5 million (2021 est.)
percent of population:
100% (2021 est.)
comparison ranking:
total 144
Broadband - fixed subscriptions:
total:
148,928 (2020 est.)
subscriptions per 100 inhabitants:
9 (2020 est.)
comparison ranking:
total 123','2622c390f00888ba535920bedaa3dbfc64a77cb9158d6d19587b61f86fd3c6d2','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3dcb7e4b9cc1c5f3720a859e83b58709d56641285861a5433d6d56bc38a67393',2025,'BD','Bangladesh','communications',23,'Telephones - fixed lines:
total subscriptions:
587,476 (2021 est.)
subscriptions per 100 inhabitants:
0 (2021 est.) less than 1
comparison ranking:
total subscriptions 85
Telephones - mobile cellular:
total subscriptions:
181,021,227 (2021 est.)
subscriptions per 100 inhabitants:
107 (2021 est.)
comparison ranking:
total subscriptions 10
Telecommunication systems:
general assessment:
Bangladesh’s economic resurgence over the last decade took a battering in 2020 and 2021 as a result of the Covid-19 pandemic; the country had been on track to move off the United Nation’s Least Developed Countries list by 2026, however the crisis may have pushed that back a few years; the telecommunications sector experienced a set of challenges, with mobile data usage exploding at the same time as many consumers were being forced to curb their spending in other areas; the demand on data grew so large and so rapidly that Bangladesh came close to running out of bandwidth; at the start of 2020, Bangladesh was consuming around 900Gb/s on average, well below the 2,642GB/s capacity of its submarine cables; this ballooned to over 2,300Gb/s during the pandemic; Bangladesh was looking forward to adding 7,200Gb/s capacity when the SEA-ME-WE-6 submarine cable goes into service in mid-2024, but the sudden upsurge in downloads is forcing state-run company Bangladesh Submarine Cable Company Limited (BSCCL) to scramble to find alternatives before the country’s internet supply is maxed out; the increased demand during the Covid-19 crisis also put pressure on the country’s existing mobile networks, already under strain as a result of strong growth in the mobile broadband market coupled with significant untapped potential for mobile services in general across the country; this led to premium prices being paid at auction for spectrum in the 1800MHz and 2100MHz bands, most of which will be used to enhance and expand LTE services; a 5G spectrum auction had been anticipated for 2020, but low interest from the MNOs in going down that path when there are still so many areas waiting for LTE access means that 5G will likely be deferred until 2023 (2021)
domestic:
fixed-line teledensity remains less than 1 per 100 persons; mobile-cellular telephone subscribership has been increasing rapidly and now exceeds 107 per 100 persons; mobile subscriber growth is anticipated over the next five years to 2023 (2021)
international:
country code - 880; landing points for the SeaMeWe-4 and SeaMeWe-5 fiber-optic submarine cable system that provides links to Europe, the Middle East, and Asia; satellite earth stations - 6; international radiotelephone communications and landline service to neighboring countries (2019)
Broadcast media:
state-owned Bangladesh Television (BTV) broadcasts throughout the country. Some channels, such as BTV World, operate via satellite. The government also owns a medium wave radio channel and some private FM radio broadcast news channels. Of the 41 Bangladesh approved TV stations, 26 are currently being used to broadcast. Of those, 23 operate under private management via cable distribution. Collectively, TV channels can reach more than 50 million people across the country.
Internet country code:
.bd
Internet users:
total:
66.3 million (2021 est.)
percent of population:
39% (2021 est.)
comparison ranking:
total 15
Broadband - fixed subscriptions:
total:
10,052,819 (2020 est.)
subscriptions per 100 inhabitants:
6 (2020 est.)
comparison ranking:
total 19','6eb6e671c7e7b0da976927d9f2a30d96685cf055740be386b3876ac048324f18','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9599fc44f66674d385c0be8fa470c6c318ecfe86905781eca3e5e860cc6c0184',2025,'BB','Barbados','communications',36,'Telephones - fixed lines:
total subscriptions:
120,980 (2021 est.)
subscriptions per 100 inhabitants:
43 (2021 est.)
comparison ranking:
total subscriptions 130
Telephones - mobile cellular:
total subscriptions:
316,633 (2021 est.)
subscriptions per 100 inhabitants:
113 (2021 est.)
comparison ranking:
total subscriptions 179
Telecommunication systems:
general assessment:
the telecom sector has seen a decline in subscriber numbers (particularly for prepaid mobile services the mainstay of short term visitors) and revenue; fixed and mobile broadband services are two areas that have benefited from the crisis as employees and students have resorted to working from home; one area of the telecom market that is not prepared for growth is 5G mobile; governments, regulators, and even the mobile network operators have shown that they have not been investing in 5G opportunities at the present time; network expansion and enhancements remain concentrated around improving LTE coverage (2021)
domestic:
fixed-line teledensity of roughly 43 per 100 persons; mobile-cellular telephone density about 113 per 100 persons (2021)
international:
country code - 1-246; landing points for the ECFS and Southern Caribbean Fiber submarine cable with links to 15 other islands in the eastern Caribbean extending from the British Virgin Islands to Trinidad and Puerto Ricco; satellite earth stations - 1 (Intelsat - Atlantic Ocean); tropospheric scatter to Trinidad and Saint Lucia (2019)
Broadcast media:
government-owned Caribbean Broadcasting Corporation (CBC) operates the lone terrestrial TV station; CBC also operates a multi-channel cable TV subscription service; roughly a dozen radio stations, consisting of a CBC-operated network operating alongside privately owned radio stations (2019)
Internet country code:
.bb
Internet users:
total:
240,800 (2021 est.)
percent of population:
86% (2021 est.)
comparison ranking:
total 177
Broadband - fixed subscriptions:
total:
128,000 (2020 est.)
subscriptions per 100 inhabitants:
45 (2020 est.)
comparison ranking:
total 125','51510f322db8ee1869be43836eca4e3cb3a54fe9f21339e6679afbab02150cff','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ac1b97b17c2532cbde700c45ad87e2eea253d5f5ec148c786c7941f5efcdaab5',2025,'BY','Belarus','communications',47,'Telephones - fixed lines:
total subscriptions:
4,332,754 (2021 est.)
subscriptions per 100 inhabitants:
45 (2021 est.)
comparison ranking:
total subscriptions 32
Telephones - mobile cellular:
total subscriptions:
11,760,087 (2021 est.)
subscriptions per 100 inhabitants:
123 (2021 est.)
comparison ranking:
total subscriptions 84
Telecommunication systems:
general assessment:
the Government of Belarus has successfully promoted the migration to an all-IP platform as part of a wider effort towards a digital transformation for the economy; the state-supported infrastructure operator beCloud has built an extensive fiber network, which reaches all but the smallest settlements in the country; Belarus has the second-highest fiber subscription rate in Europe, behind only Iceland; LTE coverage is almost universal, while considerable progress has also been made in developing 5G services (2021)
domestic:
fixed-line teledensity is improving although rural areas continue to be underserved, approximately 45 per 100 fixed-line; mobile-cellular teledensity now roughly 123 telephones per 100 persons (2021)
international:
country code - 375; Belarus is landlocked and therefore a member of the Trans-European Line (TEL), Trans-Asia-Europe (TAE) fiber-optic line, and has access to the Trans-Siberia Line (TSL); 3 fiber-optic segments provide connectivity to Latvia, Poland, Russia, and Ukraine; worldwide service is available to Belarus through this infrastructure; additional analog lines to Russia; Intelsat, Eutelsat, and Intersputnik earth stations; almost 31,000 base stations in service in 2019 (2020)
Broadcast media:
7 state-controlled national TV channels; Polish and Russian TV broadcasts are available in some areas; state-run Belarusian Radio operates 5 national networks and an external service; Russian and Polish radio broadcasts are available (2019)
Internet country code:
.by
Internet users:
total:
8.352 million (2021 est.)
percent of population:
87% (2021 est.)
comparison ranking:
total 69
Broadband - fixed subscriptions:
total:
3,255,552 (2020 est.)
subscriptions per 100 inhabitants:
35 (2020 est.)
comparison ranking:
total 44','d42b7aa5c85cc0f568e93b11065819019c02199f1d649512abb2315150709a1d','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3af0395570392b1c69fdce58ea1d7874921af8995d2dd766e5e2222bbfbd863e',2025,'BE','Belgium','communications',59,'Telephones - fixed lines:
total subscriptions:
3,293,420 (2021 est.)
subscriptions per 100 inhabitants:
28 (2021 est.)
comparison ranking:
total subscriptions 37
Telephones - mobile cellular:
total subscriptions:
11,740,118 (2021 est.)
subscriptions per 100 inhabitants:
101 (2021 est.)
comparison ranking:
total subscriptions 85
Telecommunication systems:
general assessment:
mobile networks have been upgraded to support growing mobile data use among subscribers, with near-comprehensive LTE coverage; operators have also trialed 5G in preparation for launching services; the auction of 5G-suitable spectrum has been delayed to the beginning of 2022, while the onerous restrictions on radiation have meant that some 5G trials have been suspended; there is effective competition in Belgium between the DSL and cable platforms, while in recent years government support has also encouraged investment in fiber networks; in a bid to encourage investment in under served areas, the regulator in 2018 amended the conditions by which market players grant wholesale access to copper and fiber infrastructure; in May 2019 it opened a further consultation on cost models for access to the networks of cablecos and fiber infrastructure (2021)
domestic:
about 28 per 100 fixed-line and 101 per 100 mobile-cellular; nationwide mobile-cellular telephone system; extensive cable network; limited microwave radio relay network (2021)
international:
country code - 32; landing points for Concerto, UK-Belgium, Tangerine, and SeaMeWe-3, submarine cables that provide links to Europe, the Middle East, Australia, and Asia; satellite earth stations - 7 (Intelsat - 3) (2019)
Broadcast media:
a segmented market with the three major communities (Flemish, French, and German speaking) each having responsibility for their own broadcast media; multiple TV channels exist for each community; additionally, in excess of 90% of households are connected to cable and can access broadcasts of TV stations from neighboring countries; each community has a public radio network coexisting with private broadcasters
Internet country code:
.be
Internet users:
total:
10.92 million (2021 est.)
percent of population:
91% (2021 est.)
comparison ranking:
total 56
Broadband - fixed subscriptions:
total:
4,734,210 (2020 est.)
subscriptions per 100 inhabitants:
41 (2020 est.)
comparison ranking:
total 34','17d4ee3a7da87778543ba703c174bd4ffc44288a7176e8983d7d571468264ec8','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('847697bc3e214fb6b28db23d9014262a56b178a34a5e77055df1f3bd7eeca4dc',2025,'BZ','Belize','communications',8,'Telephones - fixed lines:
total subscriptions:
19,000 (2021 est.)
subscriptions per 100 inhabitants:
5 (2021 est.)
comparison ranking:
total subscriptions 174
Telephones - mobile cellular:
total subscriptions:
260,000 (2021 est.)
subscriptions per 100 inhabitants:
66 (2021 est.)
comparison ranking:
total subscriptions 181
Telecommunication systems:
general assessment:
Belize’s fixed-line teledensity and mobile penetration remain lower than average for the region, a legacy of insufficient market competition and under investment in telecoms services; a significant investment in infrastructure, launching an LTE-A service at the end of 2016 and in mid-2017 completing a submarine cable to Ambergris Caye, enabling it to launch an FttP service in San Pedro; the nfrastructure has been updated from the legacy copper to fiber; investments have been made to provide high speed broadband to 80% of residences across Belize. (2021)
domestic:
roughly 5 per 100 fixed-line and mobile-cellular teledensity of 66 per 100 persons; mobile sector accounting for over 90% of all phone subscriptions (2021)
international:
country code - 501; landing points for the ARCOS and SEUL fiber-optic telecommunications submarine cable that provides links to South and Central America, parts of the Caribbean, and the US; satellite earth station - 8 (Intelsat - 2, unknown - 6) (2019)
Broadcast media:
8 privately owned TV stations; multi-channel cable TV provides access to foreign stations; about 25 radio stations broadcasting on roughly 50 different frequencies; state-run radio was privatized in 1998 (2019)
Internet country code:
.bz
Internet users:
total:
248,000 (2021 est.)
percent of population:
62% (2021 est.)
comparison ranking:
total 176
Broadband - fixed subscriptions:
total:
36,000 (2020 est.)
subscriptions per 100 inhabitants:
9 (2020 est.)
comparison ranking:
total 147','a0c1a0baca52c93b7c7132601c6b92053f478215ce284abb238fbebcfbb42f0b','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('18283fa9991febfc3ba25fc5f427f5a25de8754c5f04737e1eb43be9f7009270',2025,'BJ','Benin','communications',19,'Telephones - fixed lines:
total subscriptions:
11,493 (2021 est.)
subscriptions per 100 inhabitants:
(2021 est.) less than 1
comparison ranking:
total subscriptions 187
Telephones - mobile cellular:
total subscriptions:
12,731,782 (2021 est.)
subscriptions per 100 inhabitants:
98 (2021 est.)
comparison ranking:
total subscriptions 78
Telecommunication systems:
general assessment:
Benin’s telecom market continues to be restricted by the poor condition of the country’s fixed-line infrastructure; this has hampered the development of fixed-line voice and internet services, and there is negligible revenue derived from these sectors; mobile networks account for almost all internet connections, and also carry most voice traffic; there is promise for considerable change in the mobile sector; slow progress is being made in developing competition in the mobile sector; in May 2021 the government sought foreign companies to bid for a fourth mobile license; improved international internet connectivity has contributed to a reduction in end-user pricing, and provided the potential to transform many areas of the country’s economy, bringing a greater proportion of the population into the orbit of internet commerce and connectivity; a 2,000km fiber project started in 2016 was finally completed in mid-2021, prompting the government to secure a loan to build additional fiber infrastructure connecting four of the country’s 12 departments (2022)
domestic:
fixed-line teledensity less than 1 per 100 people; mobile cellular subscriptions are 98 per 100 people (2021)
international:
country code - 229; landing points for the SAT-3/WASC and ACE fiber-optic submarine cable that provides connectivity to Europe, and most West African countries; satellite earth stations - 7 (Intelsat-Atlantic Ocean) (2019)
Broadcast media:
state-run Office de Radiodiffusion et de Television du Benin (ORTB) operates a TV station providing a wide broadcast reach; several privately owned TV stations broadcast from Cotonou; satellite TV subscription service is available; state-owned radio, under ORTB control, includes a national station supplemented by a number of regional stations; substantial number of privately owned radio broadcast stations; transmissions of a few international broadcasters are available on FM in Cotonou (2019)
Internet country code:
.bj
Internet users:
total:
4.42 million (2021 est.)
percent of population:
34% (2021 est.)
comparison ranking:
total 103
Broadband - fixed subscriptions:
total:
29,981 (2020 est.)
subscriptions per 100 inhabitants:
0.3 (2020 est.)
comparison ranking:
total 155','5389c2ef929c824e2fcd61d7bc1f62e0efa8f3585be8d686c63ef448156db7be','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('da8997a06919665087a46cca79c664969793b743a53d7ff887e2d148193ebe4e',2025,'BM','Bermuda','communications',31,'Telephones - fixed lines:
total subscriptions:
25,000 (2021 est.)
subscriptions per 100 inhabitants:
39 (2021 est.)
comparison ranking:
total subscriptions 171
Telephones - mobile cellular:
total subscriptions:
68,000 (2021 est.)
subscriptions per 100 inhabitants:
110 (2021 est.)
comparison ranking:
total subscriptions 200
Telecommunication systems:
general assessment:
the telecom sector has seen a decline in subscriber numbers (particularly for prepaid mobile services the mainstay of short term visitors) and revenue; fixed and mobile broadband services are two areas that have benefited from the crisis as employees and students have resorted to working from home; one area of the telecom market that is not prepared for growth is 5G mobile; governments, regulators, and even the mobile network operators have shown that they have not been investing in 5G opportunities at the present time; network expansion and enhancements remain concentrated around improving LTE coverage (2021)
domestic:
the system has a fixed-line teledensity of 39 per 100, coupled with a mobile-cellular teledensity of roughly 110 per 100 persons (2021)
international:
country code - 1-441; landing points for the GlobeNet, Gemini Bermuda, CBUS, and the CB-1 submarine cables to the Caribbean, South America and the US; satellite earth stations - 3 (2019)
Broadcast media:
3 TV stations; cable and satellite TV subscription services are available; roughly 13 radio stations operating
Internet country code:
.bm
Internet users:
total:
64,000 (2021 est.)
percent of population:
100% (2021 est.)
comparison ranking:
total 197
Broadband - fixed subscriptions:
total:
23,000 (2020 est.)
subscriptions per 100 inhabitants:
37 (2020 est.)
comparison ranking:
total 163','f3bd27803919a7070567b656c1705115facd984ce74869cc1a1f3d924498d4b8','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9a7b2f00389a484796138738d51fb6994a13578289dbbf204b00db0120b0c6be',2025,'BT','Bhutan','communications',42,'Telephones - fixed lines:
total subscriptions:
19,680 (2021 est.)
subscriptions per 100 inhabitants:
3 (2021 est.)
comparison ranking:
total subscriptions 173
Telephones - mobile cellular:
total subscriptions:
778,008 (2021 est.)
subscriptions per 100 inhabitants:
100 (2021 est.)
comparison ranking:
total subscriptions 168
Telecommunication systems:
general assessment:
the small land-locked Kingdom of Bhutan has only recently emerged from decades of isolation from the modern world; that, and its mountainous terrain, left the country far back in the field in terms of teledensity as well as access to the Internet; over the last decade, the country has undergone a significant transformation due to the opening of its borders, liberalization of its telecom sector, and the active support from the government towards increased competition in the mobile, broadband, and ISP segments; the relatively widespread availability of the mobile platform has caused an explosion in mobile broadband subscriber numbers, growing from zero to over 100% penetration in just ten years (between 2010 and 2019).; the onset of the Covid-19 crisis in 2020 caused the subscription rates to drop back a little; growth is projected to return in 2022 (along with the broader mobile market) as the overall economy recovers; the government opens up more to foreign investment, trade, and tourism; and network expansion continues – the recent (December 2021) launch of 5G services by both of the country’s mobile operators being particularly noteworthy (2022)
domestic:
approximately 3 to 100 fixed-line and 100 mobile cellular subscriptions per 100 people (2021)
international:
country code - 975; international telephone and telegraph service via landline and microwave relay through India; satellite earth station - 1 Intelsat
Broadcast media:
state-owned TV station established in 1999; cable TV service offers dozens of Indian and other international channels; first radio station, privately launched in 1973, is now state-owned; 5 private radio stations are currently broadcasting (2012)
Internet country code:
.bt
Internet users:
total:
670,800 (2021 est.)
percent of population:
86% (2021 est.)
comparison ranking:
total 162
Broadband - fixed subscriptions:
total:
3,189 (2020 est.)
subscriptions per 100 inhabitants:
0.4 (2020 est.)
comparison ranking:
total 192','a6c7c7451b01c803b55d60c6b7fe881dbef5d34dd52f5ac1d08a6bdbc7f7e8ad','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b5879f8c19101cf7105ab5c387d4654258f4e268d78d311cf1a448029f94618b',2025,'BT','Bhutan','communications',54,'Telephones - fixed lines:
total subscriptions:
539,481 (2021 est.)
subscriptions per 100 inhabitants:
4 (2021 est.)
comparison ranking:
total subscriptions 90
Telephones - mobile cellular:
total subscriptions:
12,033,941 (2021 est.)
subscriptions per 100 inhabitants:
100 (2021 est.)
comparison ranking:
total subscriptions 81
Telecommunication systems:
general assessment:
the structure of Bolivia’s fixed telecom market is different from most other countries; local services are primarily provided by 15 telecom cooperatives; these are non-profit-making companies privately owned and controlled by their users; since the market was liberalized, the cooperatives have also provided long-distance telephony, while several also offer broadband and pay TV service; they have invested in network upgrades in a bid to improve services for customers, and to expand their footprints; Bolivia has a multi-carrier system wherein consumers can choose a long-distance carrier for each call by dialing the carrier’s prefix; several operators have also adopted fixed-wireless technologies, and some rent fiber-optic capacity; the fixed broadband services remain expensive, though the cost of bandwidth is only a fraction of what it was only a few years ago; services are still unavailable in many rural and remote areas, and even in some of the major urban areas; being a landlocked country, Bolivia had no direct access to submarine cable networks, and relies on satellite services or terrestrial links across neighboring countries; in September 2020 a new cable running via Peru, has increased capacity and contributed to a dramatic fall in end-user prices; fixed broadband services are fast migrating from DSL to fiber, while there are also cable broadband services available in some major cities; in 2007 the focus was on providing telecom services in rural areas under a project known as ‘Territory with Total Coverage’; this project aims to increase telecom coverage through mobile rather than through fixed networks; Bolivia has almost twenty times as many mobile phone subscribers as fixed line connections, and the trend towards fixed-mobile substitution continues; all the mobile companies offer 3G and LTE services; due to the poor quality, high cost, and poor reach of DSL, mobile networks have become the principal platform for voice services and data access; by early 2021 companies’ networks reached more than 95% of the population; about 92% of all internet accesses are via smartphones (2021)
domestic:
4 per 100 fixed-line, mobile-cellular telephone use expanding rapidly and teledensity stands at 100 per 100 persons; most telephones are concentrated in La Paz, Santa Cruz, and other capital cities (2021)
international:
country code - 591; Bolivia has no direct access to submarine cable networks and must therefore connect to the rest of the world either via satellite or through terrestrial links across neighboring countries; satellite earth station - 1 Intelsat (Atlantic Ocean) (2019)
Broadcast media:
large number of radio and TV stations broadcasting with private media outlets dominating; state-owned and private radio and TV stations generally operating freely, although both pro-government and anti-government groups have attacked media outlets in response to their reporting (2019)
Internet country code:
.bo
Internet users:
total:
7.92 million (2021 est.)
percent of population:
66% (2021 est.)
comparison ranking:
total 75
Broadband - fixed subscriptions:
total:
931,918 (2020 est.)
subscriptions per 100 inhabitants:
8 (2020 est.)
comparison ranking:
total 76','9607d1b26f8c5484876ca2e42ec58df208cd90273ad58d0517b038b314b8afc2','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4cb6f80ef7bcbf78f7406512a68431b214a9247585cec7ccf1eab10f533b03ab',2025,'BA','Bosnia and Herzegovina','communications',66,'Telephones - fixed lines:
total subscriptions:
689,295 (2021 est.)
subscriptions per 100 inhabitants:
21 (2021 est.)
comparison ranking:
total subscriptions 83
Telephones - mobile cellular:
total subscriptions:
3,728,775 (2021 est.)
subscriptions per 100 inhabitants:
114 (2021 est.)
comparison ranking:
total subscriptions 135
Telecommunication systems:
general assessment:
the telecom market has been liberalized and a regulatory framework created based on the EU’s regulatory framework for communications; although Bosnia-Herzegovina remains an EU candidate country, in July 2017 it applied amended mobile roaming charges to fit in with changes introduced across the Union; further roaming agreements were made in 2019 with other western Balkan countries; the fixed-line broadband network is comparatively underdeveloped, with the result that investments made in mobile upgrades to facilitate broadband connectivity in the country to a greater extent than is common elsewhere in Europe; internet services are available; DSL and cable are the main platforms for fixed-line connectivity, while fiber broadband as yet has only a small market presence; the three MNOs, each affiliated with one of the incumbent fixed-line operators, provide national coverage with 3G, though LTE coverage is only about 89%; their upgraded networks are helping to support broadband in rural areas where fixed-line infrastructure is insufficient; mobile data and mobile broadband offers will provide future revenue growth given the limited potential of mobile voice services; the MNOs tested LTE services under trial licenses from 2013, commercial launches were delayed until the award of spectrum in early 2019; the regulator stipulated that licenses must provide national coverage within five years; trials of 5G technology have been undertaken, though there are no plans to launch services commercially in the short term, given that the MNOs can continue to exploit the capacity of their existing LTE networks (2021)
domestic:
fixed-line teledensity roughly 21 per 100 persons and mobile-cellular subscribership stands at 114 telephones per 100 persons (2021)
international:
country code - 387; no satellite earth stations
Broadcast media:
3 public TV broadcasters:
Radio and TV of Bosnia and Herzegovina, Federation TV (operating 2 networks), and Republika Srpska Radio-TV; a local commercial network of 5 TV stations; 3 private, near-national TV stations and dozens of small independent TV broadcasting stations; 3 large public radio broadcasters and many private radio stations (2019)
Internet country code:
.ba
Internet users:
total:
2.508 million (2021 est.)
percent of population:
76% (2021 est.)
comparison ranking:
total 128
Broadband - fixed subscriptions:
total:
770,424 (2020 est.)
subscriptions per 100 inhabitants:
24 (2020 est.)
comparison ranking:
total 78','1bb5b15477bebd7e5cef81783310a2866dc4ef0c000ec2dc6aabb4acfa1479ad','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4c0da48a947aaaf191318514e2a895512be154fe405eb8f15e4fe4846ed4acc9',2025,'BW','Botswana','communications',8,'Telephones - fixed lines:
total subscriptions:
132,457 (2021 est.)
subscriptions per 100 inhabitants:
5 (2021 est.)
comparison ranking:
total subscriptions 127
Telephones - mobile cellular:
total subscriptions:
4,160,553 (2021 est.)
subscriptions per 100 inhabitants:
161 (2021 est.)
comparison ranking:
total subscriptions 130
Telecommunication systems:
general assessment:
effective regulatory reform has made Botswana’s telecom market one of the most liberalized in the region; there is a service-neutral licensing regime adapted to the convergence of technologies and services, and several operators now compete in all telecom sectors; Botswana has one of the highest mobile penetration rates in Africa; in a bid to generate new revenue streams and secure market share, the three mobile network operators have entered the underdeveloped broadband sector by adopting of 3G, LTE, and WiMAX technologies; in the fixed-line broadband market they compete with a large number of ISPs, some of which have rolled out their own wireless access infrastructure; the landlocked country depends on satellites for international bandwidth, and on other countries for transit capacity to the landing points of international submarine cables; the landing of additional cables in the region in recent years has improved the competitive situation in this sector, while prices for connectivity have fallen dramatically (2022)
domestic:
fixed-line teledensity has declined in recent years and now stands at roughly 5 telephones per 100 persons; mobile-cellular teledensity is roughly 161 telephones per 100 persons (2021)
international:
country code - 267; international calls are made via satellite, using international direct dialing; 2 international exchanges; digital microwave radio relay links to Namibia, Zambia, Zimbabwe, and South Africa; satellite earth station - 1 Intelsat (Indian Ocean)
Broadcast media:
2 TV stations - 1 state-owned and 1 privately owned; privately owned satellite TV subscription service is available; 2 state-owned national radio stations; 4 privately owned radio stations broadcast locally (2019)
Internet country code:
.bw
Internet users:
total:
1.924 million (2021 est.)
percent of population:
74% (2021 est.)
comparison ranking:
total 134
Broadband - fixed subscriptions:
total:
259,525 (2020 est.)
subscriptions per 100 inhabitants:
11 (2020 est.)
comparison ranking:
total 111','f59f103db04546891161e3347ef2b2768af4f4a7ee240c74bc39288806c96a43','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c675ae813578e67ac77f18414bccd8844551ab6202a49a80a9942141528d5905',2025,'BV','Bouvet Island','communications',18,'Internet country code:
.bv
Communications - note:
has an automated meteorological station','89ee17a3c6e87f1bbe2477cc63d327036cab8256ffae4c4a399f6a2fc4fc5f2d','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c8a035ce7d2ddbcb0ddd47e282d04f0d920096d4f01cbb629813d36a61aac9f2',2025,'BR','Brazil','communications',29,'Telephones - fixed lines:
total subscriptions:
28,883,475 (2021 est.)
subscriptions per 100 inhabitants:
13 (2021 est.)
comparison ranking:
total subscriptions 8
Telephones - mobile cellular:
total subscriptions:
219,660,524 (2021 est.)
subscriptions per 100 inhabitants:
102 (2021 est.)
comparison ranking:
total subscriptions 6
Telecommunication systems:
general assessment:
Brazil is one of the largest mobile and broadband markets in Latin America with healthy competition and pricing; 5G services was provided to all capital cities in July 2022, as well as about 35,500km of the national highway network; the country also has one of the largest fixed line broadband markets in Latin America, though broadband subscriptions is only slightly above the regional average, trailing behind Chile, Argentina, and Uruguay; amendments to the licensing regime adopted in October 2019 also require that ISPs which have switched to authorizations invest money saved from lighter regulations in the expansion of broadband services; the fixed line broadband market has seen rapid growth for a number of years, with a growing focus on fiber broadband; in 2019 the number of fiber accesses overtook DSL connections; the country is a key landing point for a number of important submarine cables connecting to the US, Central and South America, the Caribbean, Europe, and Africa; several new cable systems are due to come into service through to 2022, which will increase bandwidth and push down broadband prices for end-users; investments have also been made into terrestrial fiber cables between Brazil, Argentina, and Chile (2022)
domestic:
fixed-line connections stand at roughly 13 per 100 persons; mobile-cellular teledensity roughly 102 per 100 persons (2021)
international:
country code - 55; landing points for a number of submarine cables, including Malbec, ARBR, Tamnat, SAC, SAm-1, Atlantis -2, Seabras-1, Monet, EllaLink, BRUSA, GlobeNet, AMX-1, Brazilian Festoon, Bicentenario, Unisur, Junior, Americas -II, SAE x1, SAIL, SACS and SABR that provide direct connectivity to South and Central America, the Caribbean, the US, Africa, and Europe; satellite earth stations - 3 Intelsat (Atlantic Ocean), 1 Inmarsat (Atlantic Ocean region east), connected by microwave relay system to Mercosur Brazilsat B3 satellite earth station; satellites is a major communication platform, as it is almost impossible to lay fiber optic cable in the thick vegetation (2019)
Broadcast media:
state-run Radiobras operates a radio and a TV network; more than 1,000 radio stations and more than 100 TV channels operating - mostly privately owned; private media ownership highly concentrated (2022)
Internet country code:
.br
Internet users:
total:
170.1 million (2021 est.)
percent of population:
81% (2021 est.)
comparison ranking:
total 4
Broadband - fixed subscriptions:
total:
36,344,670 (2020 est.)
subscriptions per 100 inhabitants:
17 (2020 est.)
comparison ranking:
total 4','289b6ba55e2ad01c05bb09faaab9d28832d16ba60778192a35ebb1a32f258503','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('50a7e72665345137116d235450eb7fe26d03e7acc0f10fc0749e7f2adb1bb895',2025,'IO','British Indian Ocean Territory','communications',41,'Telecommunication systems:
general assessment:
separate facilities for military and public needs are available (2018)
domestic:
all commercial telephone services are available, including connection to the Internet (2018)
international:
country code (Diego Garcia) - 246; landing point for the SAFE submarine cable that provides direct connectivity to Africa, Asia and near-by Indian Ocean island countries; international telephone service is carried by satellite (2019)
Broadcast media:
Armed Forces Radio and Television Service (AFRTS) broadcasts over 3 separate frequencies for US and UK military personnel stationed on the islands
Internet country code:
.io
Communications - note:
Diego Garcia hosts one of four dedicated ground antennas that assist in the operation of the Global Positioning System (GPS) navigation system (the others are on Kwajalein (Marshall Islands), at Cape Canaveral, Florida (US), and on Ascension Island (Saint Helena, Ascension, and Tristan da Cunha))','d9b921ac79bfdc2ca80f938f55857797a9db7f4f67a9f0e14f37388f48e9677c','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5d519b4117eaf0b003a12a21bf84402dc2976929a9fe13468af48ad9bb6e1dab',2025,'IO','British Indian Ocean Territory','communications',52,'Telephones - fixed lines:
total subscriptions:
7,000 (2021 est.)
subscriptions per 100 inhabitants:
22 (2021 est.)
comparison ranking:
total subscriptions 197
Telephones - mobile cellular:
total subscriptions:
35,000 (2021 est.)
subscriptions per 100 inhabitants:
110 (2021 est.)
comparison ranking:
total subscriptions 210
Telecommunication systems:
general assessment:
the telecom sector has seen a decline in subscriber numbers (particularly for prepaid mobile services the mainstay of short term visitors) and revenue; fixed and mobile broadband services are two areas that have benefited from the crisis as employees and students have resorted to working from home; one major casualty may be the region’s second largest telco operator, Digicel; the company filed for bankruptcy in the US in April 2020; it continues to operate in all of its Caribbean markets as it seeks to refinance billions of dollars of debt; the other major telco, regional incumbent Cable & Wireless Communications (CWC), is experiencing similar drops in subscriber numbers and revenue; CWC is expanding and enhancing its fixed and mobile networks in many of the countries it serves around the Caribbean, despite many locations being small islands with very small populations; one area of the telecom market that is not prepared for growth is 5G mobile; governments, regulators, and even the mobile network operators have shown that they have not been investing in 5G opportunities at the present time; network expansion and enhancements remain concentrated around improving LTE coverage. (2021)
domestic:
fixed-line connections exceed 22 per 100 persons and mobile cellular subscribership is roughly 110 per 100 persons (2021)
international:
country code - 1-284; landing points for PCCS, ECFS, CBUS, Deep Blue Cable, East-West, PAN-AM, Americas-1, Southern Caribbean Fiber, Columbus- IIb, St Thomas - St Croix System, Taino-Carib, and Americas I-North via submarine cable to Caribbean, Central and South America, and US (2019)
Broadcast media:
1 private TV station; multi-channel TV is available from cable and satellite subscription services; about a half-dozen private radio stations
Internet country code:
.vg
Internet users:
total:
24,087 (2021 est.)
percent of population:
77.7% (2021 est.)
comparison ranking:
total 211
Broadband - fixed subscriptions:
total:
6,738 (2020 est.)
subscriptions per 100 inhabitants:
22 (2020 est.)
comparison ranking:
total 182','fc81741e3f4125dd54a8ddd31b493594d4258bbb580343c0ab0c8e7f20d226e8','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('de3f043e46f8d09b375c555208a0f27860b4f8dd054ad4f8106830a1f35a6e3b',2025,'IO','British Indian Ocean Territory','communications',63,'Telephones - fixed lines:
total subscriptions:
112,298 (2021 est.)
subscriptions per 100 inhabitants:
25 (2021 est.)
comparison ranking:
total subscriptions 133
Telephones - mobile cellular:
total subscriptions:
603,486 (2021 est.)
subscriptions per 100 inhabitants:
136 (2021 est.)
comparison ranking:
total subscriptions 172
Telecommunication systems:
general assessment:
Brunei’s mobile market experienced drop-off in subscriber numbers in 2020; in 2022 there was a concerted effort to build out the fixed-line infrastructure while progressing towards introducing 5G mobile services; Brunei’s fixed-line market is one of the few countries in the world to have displayed significant growth rather than a decline in teledensity in the last few years; this upward trend is set to continue as the new Unified National Network (UNN) works diligently to expand and enhance the fixed-line infrastructure around the country; strong growth was also seen in the fixed broadband space, on the back of those same infrastructure developments that are part of the Brunei Vision 2035 initiative; fixed broadband is starting from a relatively low base by international standards and is still only at 18%, leaving lots of room for growth; mobile and mobile broadband, on the other hand, are still suffering from the market contractions first felt in 2020; Brunei’s 2G GSM network is shut down, with the spectrum to be reallocated to 3G, 4G, and potentially 5G use (2021)
domestic:
25 per 100 fixed-line, 136 per 100 mobile-cellular (2021)
international:
country code - 673; landing points for the SEA-ME-WE-3, SJC, AAG, Lubuan-Brunei Submarine Cable via optical telecommunications submarine cables that provides links to Asia, the Middle East, Southeast Asia, Africa, Australia, and the US; satellite earth stations - 2 Intelsat (1 Indian Ocean and 1 Pacific Ocean) (2019)
Broadcast media:
state-controlled Radio Television Brunei (RTB) operates 5 channels; 3 Malaysian TV stations are available; foreign TV broadcasts are available via satellite systems; RTB operates 5 radio networks and broadcasts on multiple frequencies; British Forces Broadcast Service (BFBS) provides radio broadcasts on 2 FM stations; some radio broadcast stations from Malaysia are available via repeaters
Internet country code:
.bn
Internet users:
total:
441,000 (2021 est.)
percent of population:
98% (2021 est.)
comparison ranking:
total 170
Broadband - fixed subscriptions:
total:
71,078 (2020 est.)
subscriptions per 100 inhabitants:
16 (2020 est.)
comparison ranking:
total 134','2301ff66f1766b4d354841f23e4a53ee8a0ee34696b03a2fdb104fc5ec918035','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('11063930de09d29c57e49b01b8aae3c3539d5346598e1387992dc659eddd3c0f',2025,'BG','Bulgaria','communications',8,'Telephones - fixed lines:
total subscriptions:
787,637 (2021 est.)
subscriptions per 100 inhabitants:
11 (2021 est.)
comparison ranking:
total subscriptions 77
Telephones - mobile cellular:
total subscriptions:
7,902,756 (2021 est.)
subscriptions per 100 inhabitants:
115 (2021 est.)
comparison ranking:
total subscriptions 101
Telecommunication systems:
general assessment:
Bulgaria’s telecom market was for some years affected by the difficult macroeconomic climate, as well as by relatively high unemployment and a shrinking population; these factors continue to slow investments in the sector, though revenue growth has returned since 2019; there still remains pressure on revenue growth, with consumers migrating from fixed-line voice telephony to mobile and VoIP alternatives, while the volume of SMS and MMS traffic has been affected by the growing use of alternative OTT messaging services; investing in network upgrades and its development of services based on 5G have stimulated other market players to invest in their own service provision; by the end of 2022 about 70% of the population is expected to be covered by 5G; the broadband market in Bulgaria enjoys excellent cross-platform competition; the share of the market held by DSL has fallen steadily as a result of customers being migrated to fiber networks; by early 2021 about 65% of fixed-line broadband subscribers were on fiber infrastructure; Bulgaria joins the U.S. State Department’s Clean Network initiative in a bid to protect its 5G communications networks (2022)
domestic:
fixed-line over 11 per 100 persons, mobile-cellular teledensity, fostered by multiple service providers, is over 115 telephones per 100 persons (2021)
international:
country code - 359; Caucasus Cable System via submarine cable provides connectivity to Ukraine, Georgia and Russia; a combination submarine cable and land fiber-optic system provides connectivity to Italy, Albania, and Macedonia; satellite earth stations - 3 (1 Intersputnik in the Atlantic Ocean region, 2 Intelsat in the Atlantic and Indian Ocean regions) (2019)
Broadcast media:
4 national terrestrial TV stations with 1 state-owned and 3 privately owned; a vast array of TV stations are available from cable and satellite TV providers; state-owned national radio broadcasts over 3 networks; large number of private radio stations broadcasting, especially in urban areas
Internet country code:
.bg
Internet users:
total:
5.175 million (2021 est.)
percent of population:
75% (2021 est.)
comparison ranking:
total 89
Broadband - fixed subscriptions:
total:
2,115,053 (2020 est.)
subscriptions per 100 inhabitants:
30 (2020 est.)
comparison ranking:
total 56','132429501d9fcd65f0d73f43774fca12efe7e69d9f1ef6a0c3b1a8347c3cb7bb','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f0d4f59cff9f3c5baa8d149f2cf22ce56ebb9277909fe6a1d857748ff2f7819a',2025,'BF','Burkina Faso','communications',21,'Telephones - fixed lines:
total subscriptions:
81,374 (2021 est.)
subscriptions per 100 inhabitants:
(2021 est.) less than 1
comparison ranking:
total subscriptions 142
Telephones - mobile cellular:
total subscriptions:
24,678,315 (2021 est.)
subscriptions per 100 inhabitants:
112 (2021 est.)
comparison ranking:
total subscriptions 51
Telecommunication systems:
general assessment:
Burkina Faso’s telecom sector in recent years has made some gains in providing the necessary infrastructure and bandwidth to support telecom services; an IXP completed in September 2020 increased international bandwidth capacity by a third, while in mid-2021 the government was able to start the second phase of a national fiber backbone project; this will link the capital city to an addition 145 municipalities, and provide additional connectivity to terrestrial cables in neighboring countries; the activities of the militants in side areas of the country jeopardize overall security, and render it difficult for the telcos to safeguard their networks and equipment; Burkina Faso joins G5 Sahel countries to eliminate roaming fees (2022)
domestic:
fixed-line connections stand at less than 1 per 100 persons; mobile-cellular usage nearly 112 per 100, with multiple providers there is competition and the hope for growth from a low base; Internet penetration is 16% (2021)
international:
country code - 226; satellite earth station - 1 Intelsat (Atlantic Ocean)
Broadcast media:
since the official inauguration of Terrestrial Digital Television (TNT) in December 2017, Burkina Faso now has 14 digital TV channels among which 2 are state-owned; there are more than 140 radio stations (commercial, religious, community) available throughout the country including a national and regional state-owned network; the state-owned Radio Burkina and the private Radio Omega are among the most widespread stations and both include broadcasts in French and local languages (2019)
Internet country code:
.bf
Internet users:
total:
4.84 million (2021 est.)
percent of population:
22% (2021 est.)
comparison ranking:
total 96
Broadband - fixed subscriptions:
total:
13,979 (2020 est.)
subscriptions per 100 inhabitants:
0.1 (2020 est.)
comparison ranking:
total 174','2e0094f3d63f5638007838ed6f47e04ffaa2b9852b0df4306952ba8d98b042d8','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('45b2bdc71556d7445bc37a39580e60352f2dac9db56b22a6c243b39b7e66d5e4',2025,'BF','Burkina Faso','communications',33,'Telephones - fixed lines:
total subscriptions:
522,141 (2021 est.)
subscriptions per 100 inhabitants:
1 (2021 est.)
comparison ranking:
total subscriptions 91
Telephones - mobile cellular:
total subscriptions:
67,930,093 (2021 est.)
subscriptions per 100 inhabitants:
126 (2021 est.)
comparison ranking:
total subscriptions 25
Telecommunication systems:
general assessment:
Burma, one of the least developed telecom markets in Asia, saw growth in mobile and broadband services through foreign competition and roll out of 4G and 5G networks; infrastructure development challenged by flooding, unreliable electricity, inefficient bureaucracy, and corruption; digital divide affects rural areas; fixed broadband remains low due to number of fixed-lines and near saturation of the mobile platform; healthy m-banking platform; tests for NB-IoT; benefit from launch of regional satellite; government utilizes intermittent censorship and shut-down of Internet in political crisis (2020)
domestic:
fixed-line is just under 1 per 100, while mobile-cellular is roughly 126 per 100 (2021)
international:
country code - 95; landing points for the SeaMeWe-3, SeaMeWe-5, AAE-1 and Singapore-Myanmar optical telecommunications submarine cable that provides links to Asia, the Middle East, Africa, Southeast Asia, Australia and Europe; satellite earth stations - 2, Intelsat (Indian Ocean) and ShinSat (2019)
Broadcast media:
government controls all domestic broadcast media; 2 state-controlled TV stations with 1 of the stations controlled by the armed forces; 2 pay-TV stations are joint state-private ventures; 1 state-controlled domestic radio station and 9 FM stations that are joint state-private ventures; transmissions of several international broadcasters are available in parts of Burma; the Voice of America (VOA), Radio Free Asia (RFA), BBC Burmese service, the Democratic Voice of Burma (DVB), and Radio Australia use shortwave to broadcast in Burma; VOA, RFA, and DVB produce daily TV news programs that are transmitted by satellite to audiences in Burma; in March 2017, the government granted licenses to 5 private broadcasters, allowing them digital free-to-air TV channels to be operated in partnership with government-owned Myanmar Radio and Television (MRTV) and will rely upon MRTV’s transmission infrastructure; following the February 2021 military coup, the regime revoked the media licenses of most independent outlets, including the free-to-air licenses for DVB and Mizzima (2022)
Internet country code:
.mm
Internet users:
total:
23.76 million (2021 est.)
percent of population:
44% (2021 est.)
comparison ranking:
total 36
Broadband - fixed subscriptions:
total:
688,185 (2020 est.)
subscriptions per 100 inhabitants:
1 (2020 est.)
comparison ranking:
total 81','f60ca3c1a9026f5cebfc69f1810ce17d405cdc2e9c907c7adec1857aed7e7a60','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('071af9903b0472afe3952cd8636d04bfd675c88edeae9628ecae32f210b19ec4',2025,'BI','Burundi','communications',44,'Telephones - fixed lines:
total subscriptions:
15,976 (2021 est.)
subscriptions per 100 inhabitants:
(2021 est.) less than 1
comparison ranking:
total subscriptions 180
Telephones - mobile cellular:
total subscriptions:
7,740,494 (2021 est.)
subscriptions per 100 inhabitants:
62 (2021 est.)
comparison ranking:
total subscriptions 103
Telecommunication systems:
general assessment:
Burundi provides an attractive telecom market given its high population density and existing low subscription rates for all services; one downside for investors is that the country has a very low economic output, disposable income is also very low, and fixed-line infrastructure is poor outside the main urban areas; this is a greater motivation for investors to focus on improving mobile networks than in expanding fixed-line infrastructure; to overcome difficulties associated with the poor telecom infrastructure, the government has supported a number of prominent telcos building a national fiber backbone network; this network offers onward connectivity to submarine cable infrastructure landings in Kenya and Tanzania; the first sections of this network were switched on in early 2014, and additional provinces have since been connected; in addition, the government in early 2018 kick-started the Burundi Broadband project, which aims to deliver national connectivity by 2025; based on this improved infrastructure the government and ITU have developed an ICT strategy to make use of telecoms to promote the country’s socio-economic development through to 2028; progress made by Tanzania with its own national backbone network has benefited Burundi, which has been provided with onward connectivity to most countries in the region; International bandwidth capacity has continued to increase in recent years, including a 38% increase in the nine months to September 2021, resulting in lower retail prices for consumers; two of the mobile operators have launched 3G and LTE services to capitalize on the growing demand for internet access; the number of mobile subscribers increased 7% in the third quarter of 2021, quarter-on-quarter; similar growth is expected for the next two years at least, which will help bring the mobile level closer to the average for the region (2022)
domestic:
fixed-line connections stand at less than 1 per 100 persons; mobile-cellular usage is about 62 per 100 persons (2021)
international:
country code - 257; satellite earth station - 1 Intelsat (Indian Ocean); the government, supported by the World Bank, has backed a joint venture with a number of prominent telecoms to build a national fiber backbone network, offering onward connectivity to submarine cable infrastructure landings in Kenya and Tanzania (2019)
Broadcast media:
state-controlled Radio Television Nationale de Burundi (RTNB) operates a TV station and a national radio network; 3 private TV stations and about 10 privately owned radio stations; transmissions of several international broadcasters are available in Bujumbura (2019)
Internet country code:
.bi
Internet users:
total:
754,000 (2021 est.)
percent of population:
5.8% (2021 est.)
comparison ranking:
total 158
Broadband - fixed subscriptions:
total:
4,230 (2020 est.)
subscriptions per 100 inhabitants:
0.04 (2020 est.)
comparison ranking:
total 190','d0f5377e980149739977bdc9deeca3794c32505d4eed85c02efa8d8c8d9518cf','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8a1c24fa749551c25cb660789a46b88a46bf87b9591f91a359b183635402e915',2025,'CV','Cabo Verde','communications',8,'Telephones - fixed lines:
total subscriptions:
53,586 (2021 est.)
subscriptions per 100 inhabitants:
9 (2021 est.)
comparison ranking:
total subscriptions 154
Telephones - mobile cellular:
total subscriptions:
590,171 (2021 est.)
subscriptions per 100 inhabitants:
100 (2021 est.)
comparison ranking:
total subscriptions 173
Telecommunication systems:
general assessment:
LTE reaches almost 40% of the population; regulator awards commercial 4G licenses and starts 5G pilot; govt. extends USD 25 million for submarine fiber-optic cable project linking Africa to Portugal and Brazil (2020)
domestic:
9 per 100 fixed-line teledensity and nearly 100 per 100 mobile-cellular (2021)
international:
country code - 238; landing points for the Atlantis-2, EllaLink, Cabo Verde Telecom Domestic Submarine Cable Phase 1, 2, 3 and WACS fiber-optic transatlantic telephone cable that provides links to South America, Africa, and Europe; HF radiotelephone to Senegal and Guinea-Bissau; satellite earth station - 1 Intelsat (Atlantic Ocean) (2019)
Broadcast media:
state-run TV and radio broadcast network plus a growing number of private broadcasters; Portuguese public TV and radio services for Africa are available; transmissions of a few international broadcasters are available (2019)
Internet country code:
.cv
Internet users:
total:
413,000 (2021 est.)
percent of population:
70% (2021 est.)
comparison ranking:
total 171
Broadband - fixed subscriptions:
total:
24,839 (2020 est.)
subscriptions per 100 inhabitants:
5 (2020 est.)
comparison ranking:
total 160','aeb68766106c6448341bed07c37494ccc8e20076c21334e71d9d505f52d9dbfb','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8ae186a84b5191d2d5c9394795eaff5b77590810ded04cd71636232e30c8c6c1',2025,'KH','Cambodia','communications',19,'Telephones - fixed lines:
total subscriptions:
40,296 (2021 est.)
subscriptions per 100 inhabitants:
(2021 est.) less than 1
comparison ranking:
total subscriptions 162
Telephones - mobile cellular:
total subscriptions:
19,899,790 (2021 est.)
subscriptions per 100 inhabitants:
120 (2021 est.)
comparison ranking:
total subscriptions 61
Telecommunication systems:
general assessment: Cambodia’s mobile-dominated telecoms sector spent much of 2020 battling two major challenges: the global pandemic, and the government’s retraction of trial licenses for the rollout of 5G; citing concerns about waste and inefficiency occurring if each operator built a separate 5G infrastructure in order to maximize their own network’s coverage (and, presumably, to capture greater market share), the regulator withdrew the licenses that the operators had been using for their 5G trials; this was despite all of the operators having already announced a successful completion of their trials; more than a year later, the market is still waiting on the government to release its 5G policy and roadmap, along with the allocation of spectrum and approvals to permit commercial operation; there is little expectation of any further progress happening before the start of 2022; the mobile network operators have maintained their focus and investment strategies on upgrading and expanding their existing LTE networks around the country, and to 5G-enable their base stations; when the 5G market eventually arrives, the underlying infrastructure will at least be ready to support a rapid adoption of the higher-value applications and services; the mobile market fell back slightly during 2020 and 2021 (in terms of total subscriber numbers) as the Covid-19 crisis wore on, but it remains in relatively good health as mobile users increased their data usage over the period; the mobile broadband market experienced a small but very rare contraction in 2020, although rates were already very high in this area; there is likely to be a quick rebound to previous levels once economic conditions stabilize, followed by a modest rates of growth over the next five years; the number of fixed telephony lines in service continues to fall sharply as customers migrate to mobile platforms for both voice and data; the lack of any widespread fixed-line infrastructure has had a flow-on effect in the fixed-line broadband market, a sector that also remains largely under-developed (2021)
domestic:
fixed-line connections stand at less than 1 per 100 persons; mobile-cellular usage, aided by competition among service providers, is about 120 per 100 persons (2021)
international:
country code - 855; landing points for MCT and AAE-1 via submarine cables providing communication to Asia, the Middle East, Europe and Africa; satellite earth station - 1 Intersputnik (Indian Ocean region) (2019)
Broadcast media:
mixture of state-owned, joint public-private, and privately owned broadcast media; 27 TV broadcast stations with most operating on multiple channels, including 1 state-operated station broadcasting from multiple locations, 11 stations either jointly operated or privately owned with some broadcasting from several locations; multi-channel cable and satellite systems are available (2019); 84 radio broadcast stations - 1 state-owned broadcaster with multiple stations and a large mixture of public and private broadcasters; one international broadcaster is available (2019) as well as one Chinese joint venture television station with the Ministry of Interior; several television and radio operators broadcast online only (often via Facebook) (2019)
Internet country code:
.kh
Internet users:
total:
10.2 million (2021 est.)
percent of population:
60% (2021 est.)
comparison ranking:
total 57
Broadband - fixed subscriptions:
total:
233,732 (2020 est.) Slowly increase as focus is on mobile internet
subscriptions per 100 inhabitants:
1 (2020 est.)
comparison ranking:
total 114','6dc16b0bb7c11b6984760882f1ed52cd20f0233426766f60aca19681634a1f0e','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('04944fc8b32991c180f52f956b3ac54bd0bb83396b2de1c612b3867e239ebebc',2025,'CM','Cameroon','communications',30,'Telephones - fixed lines:
total subscriptions:
739,572 (2021 est.)
subscriptions per 100 inhabitants:
3 (2021 est.)
comparison ranking:
total subscriptions 78
Telephones - mobile cellular:
total subscriptions:
22,442,414 (2021 est.)
subscriptions per 100 inhabitants:
83 (2021 est.)
comparison ranking:
total subscriptions 56
Telecommunication systems:
general assessment:
Cameroon was for many years one of the few countries in Africa with only two competing mobile operators; the investment programs among operators over the next few years will considerably boost mobile broadband services in rural areas of the country, many of which are under served by fixed-line infrastructure; the government has also been supportive, having launched its ‘Cameroon Digital 2020’ program, aimed at improving connectivity nationally; improved submarine and terrestrial cable connectivity has substantially increased international bandwidth, in turn leading to reductions in access prices for consumers; other projects such as Acceleration of the Digital Transformation of Cameroon are aimed at developing the digital economy (2022)
domestic:
only a little above 3 per 100 persons for fixed-line subscriptions; mobile-cellular usage has increased sharply, reaching a subscribership base of roughly 83 per 100 persons (2021)
international:
country code - 237; landing points for the SAT-3/WASC, SAIL, ACE, NCSCS, Ceiba-2, and WACS fiber-optic submarine cable that provides connectivity to Europe, South America, and West Africa; satellite earth stations - 2 Intelsat (Atlantic Ocean) (2019)
Broadcast media:
government maintains tight control over broadcast media; state-owned Cameroon Radio Television (CRTV), broadcasting on both a TV and radio network, was the only officially recognized and fully licensed broadcaster until August 2007, when the government finally issued licenses to 2 private TV broadcasters and 1 private radio broadcaster; about 70 privately owned, unlicensed radio stations operate but are subject to closure at any time; foreign news services required to partner with state-owned national station (2019)
Internet country code:
.cm
Internet users:
total:
12.42 million (2021 est.)
percent of population:
46% (2021 est.)
comparison ranking:
total 53
Broadband - fixed subscriptions:
total:
722,579 (2020 est.)
subscriptions per 100 inhabitants:
3 (2020 est.)
comparison ranking:
total 79','b0ccbbb17e0dc829e32e45653444c69f2f795c56ec8a2c69624a716f3bd45b8d','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3c515ccb84b34bde26d710a9cc88b9aacd5eee992c69b1b6465124b49d5ed198',2025,'CA','Canada','communications',42,'Telephones - fixed lines:
total subscriptions:
12.928 million (2021 est.)
subscriptions per 100 inhabitants:
34 (2021 est.)
comparison ranking:
total subscriptions 16
Telephones - mobile cellular:
total subscriptions:
32.723 million (2021 est.)
subscriptions per 100 inhabitants:
86 (2021 est.)
comparison ranking:
total subscriptions 44
Telecommunication systems:
general assessment:
the Canadian telecom market continues to show steady development as operators invest in network upgrades; much of the investment among telcos has been channeled into LTE infrastructure to capitalize on consumer demand for mobile data services, while there has also been further investment in 5G; investment programs have also been supported by regulatory efforts to ensure that operators have spectrum available to develop 5G services; an investment in fixed-line infrastructure, focused on FttP and, among cable broadband providers; government policy has encouraged the extension of broadband to rural and regional areas, with the result that services are almost universally available and the emphasis now is on improving service speeds to enable the entire population to benefit from the digital economy and society; cable broadband is the principal access platform, followed by DSL; the mobile rate remains comparatively low by international standards; Canadians have provided for LTE and LTE-A infrastructure; despite topographical challenges and the remoteness of many areas, the major players effectively offer 99% population coverage with LTE; operators now provide up to 70% population coverage with 5G (2022)
domestic:
Nearly 34 per 100 fixed-line and 86 per 100 mobile-cellular teledensity (2021)
international:
country code - 1; landing points for the Nunavut Undersea Fiber Optic Network System, Greenland Connect, Persona, GTT Atlantic, and Express, KetchCan 1 Submarine Fiber Cable system, St Pierre and Miquelon Cable submarine cables providing links to the US and Europe; satellite earth stations - 7 (5 Intelsat - 4 Atlantic Ocean and 1 Pacific Ocean, and 2 Intersputnik - Atlantic Ocean region) (2019)
Broadcast media:
2 public TV broadcasting networks, 1 in English and 1 in French, each with a large number of network affiliates; several private-commercial networks also with multiple network affiliates; overall, about 150 TV stations; multi-channel satellite and cable systems provide access to a wide range of stations including US stations; mix of public and commercial radio broadcasters with the Canadian Broadcasting Corporation (CBC), the public radio broadcaster, operating 4 radio networks, Radio Canada International, and radio services to indigenous populations in the north; roughly 1,119 licensed radio stations (2016)
Internet country code:
.ca
Internet users:
total:
35.34 million (2021 est.)
percent of population:
93% (2021 est.)
comparison ranking:
total 28
Broadband - fixed subscriptions:
total:
15,825,813 (2020 est.)
subscriptions per 100 inhabitants:
42 (2020 est.)
comparison ranking:
total 16','2b5fcebf8e04165b189201268337dc670214bbd17b6ff4c8574c6b20dad4dfa9','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0d9f8b32ee6a811baaf46ec5f4317c9a2b6afbef0fe0eda8eb4bc2fddb6cba4e',2025,'KY','Cayman Islands','communications',55,'Telephones - fixed lines:
total subscriptions:
36,000 (2021 est.)
subscriptions per 100 inhabitants:
53 (2021 est.)
comparison ranking:
total subscriptions 163
Telephones - mobile cellular:
total subscriptions:
100,000 (2021 est.)
subscriptions per 100 inhabitants:
150 (2021 est.)
comparison ranking:
total subscriptions 192
Telecommunication systems:
general assessment:
the telecom sector has seen a decline in subscriber numbers (particularly for prepaid mobile services the mainstay of short term visitors) and revenue; fixed and mobile broadband services are two areas that have benefited from the crisis as employees and students have resorted to working from home; one area of the telecom market that is not prepared for growth is 5G mobile; governments, regulators, and even the mobile network operators have shown that they have not been investing in 5G opportunities at the present time; network expansion and enhancements remain concentrated around improving LTE coverage (2021)
domestic:
53 per 100 fixed-line and 150 per 100 mobile-cellular (2021)
international:
country code - 1-345; landing points for the Maya-1, Deep Blue Cable, and the Cayman-Jamaica Fiber System submarine cables that provide links to the US and parts of Central and South America; satellite earth station - 1 Intelsat (Atlantic Ocean) (2019)
Broadcast media:
4 TV stations; cable and satellite subscription services offer a variety of international programming; government-owned Radio Cayman operates 2 networks broadcasting on 5 stations; 10 privately owned radio stations operate alongside Radio Cayman
Internet country code:
.ky
Internet users:
total:
55,148 (2021 est.)
percent of population:
81.1% (2021 est.)
comparison ranking:
total 199
Broadband - fixed subscriptions:
total:
3,200 (2020 est.)
subscriptions per 100 inhabitants:
49 (2020 est.)
comparison ranking:
total 191','b135628339658fdb234faea76930662a0c98714ccd1148f0f7a738d78d7f192f','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('91d39846c7efb08a7840c1e4f4a916b73791a1d74ae4190a6e06d40bdae95669',2025,'CF','Central African Republic','communications',66,'Telephones - fixed lines:
total subscriptions:
2,000 (2021 est.)
subscriptions per 100 inhabitants:
(2021 est.) less than 1
comparison ranking:
total subscriptions 215
Telephones - mobile cellular:
total subscriptions:
1.8 million (2021 est.)
subscriptions per 100 inhabitants:
34 (2021 est.)
comparison ranking:
total subscriptions 155
Telecommunication systems:
general assessment:
given the poor fixed-line infrastructure in most countries across Africa, voice and data services across the region are greatly dependent on mobile networks; in the majority of markets, including those with better developed fixed infrastructure such as South Africa, Nigeria, and Kenya, up to 98% of all voice and data connections are via mobile networks; during the last two to three years, national governments and telecom regulators have striven to improve fixed infrastructure with the wider aim of developing economic growth based on digital services and connectivity; this work is principally focused on delivering fiber-based connectivity; since the amount of copper infrastructure (DSL or HFC) used for broadband is so negligible, governments and private firms, including telcos are investing in fiber rather than in older technologies; while supporting broadband to premises, health centers, and government buildings, the new fiber infrastructure is mainly being deployed to provide mobile platforms and to support the rapid growth in data traffic (2022)
domestic:
very limited telephone service with less than 1 fixed-line connection per 100 persons; 34 per 100 mobile-cellular subscribers (2020)
international:
country code - 236; satellite earth station - 1 Intelsat (Atlantic Ocean)
Broadcast media:
government-owned network, Radiodiffusion Television Centrafricaine, provides limited domestic TV broadcasting; state-owned radio network is supplemented by a small number of privately owned broadcast stations as well as a few community radio stations; transmissions of at least 2 international broadcasters are available (2017)
Internet country code:
.cf
Internet users:
total:
605,000 (2021 est.)
percent of population:
11% (2021 est.)
comparison ranking:
total 165
Broadband - fixed subscriptions:
total:
499 (2019 est.) Data available for 2019 only.
subscriptions per 100 inhabitants:
0.01 (2019 est.)
comparison ranking:
total 210','36bf07d92c2877f841f632f0f74c12f48511c839eb5f1d5503e1f479f700d90d','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7f0a034c714e510e7855e787f47a6e4a5b58025dcd9169b17492a08e558097b9',2025,'TD','Chad','communications',8,'Telephones - fixed lines:
total subscriptions:
5,300 (2021 est.)
subscriptions per 100 inhabitants:
(2021 est.) less than 1
comparison ranking:
total subscriptions 205
Telephones - mobile cellular:
total subscriptions:
10 million (2021 est.)
subscriptions per 100 inhabitants:
60 (2021 est.)
comparison ranking:
total subscriptions 93
Telecommunication systems:
general assessment:
the telecom infrastructure is particularly poor; fixed, mobile and internet is well below African averages; Chad’s telecom market offers some potential for investors to develop services given the low starting base; the country’s first 3G/LTE mobile license was awarded in April 2014; Chad finally gained access to international fiber bandwidth in 2012 its national backbone infrastructure remains underdeveloped; the World Bank-funded Central African Backbone (CAB) project takes in Chad, while the country is also party to a Trans-Saharan Backbone project which will link a fiber cable to Nigeria and Algeria (2022)
domestic:
fixed-line connections less than 1 per 100 persons; mobile-cellular subscribership base of about 60 per 100 persons (2021)
international:
country code - 235; satellite earth station - 1 Intelsat (Atlantic Ocean)
Broadcast media:
1 state-owned TV station; 2 privately-owned TV stations; state-owned radio network, Radiodiffusion Nationale Tchadienne (RNT), operates national and regional stations; over 10 private radio stations; some stations rebroadcast programs from international broadcasters (2017)
Internet country code:
.td
Internet users:
total:
3.06 million (2021 est.)
percent of population:
18% (2021 est.)
comparison ranking:
total 119
Broadband - fixed subscriptions:
total:
(2020 est.)
subscriptions per 100 inhabitants:
(2020 est.)','3f0357f372ff71c37a04269d2eb7d697d41f4bcfe549f8dfd54e132f806e03f7','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('647e15a92dd56d42eeafa668bfc2c92c8591d70910e3a33bbadbfb7bc6e502d9',2025,'CL','Chile','communications',20,'Telephones - fixed lines:
total subscriptions:
2,510,972 (2021 est.)
subscriptions per 100 inhabitants:
13 (2021 est.)
comparison ranking:
total subscriptions 49
Telephones - mobile cellular:
total subscriptions:
26,571,823 (2021 est.)
subscriptions per 100 inhabitants:
136 (2021 est.)
comparison ranking:
total subscriptions 50
Telecommunication systems:
general assessment:
the market for fixed and mobile telephony is highly competitive and rapidly evolving; the mobile rate is among the highest in South America; LTE infrastructure is extensive and 5G spectrum auctions which took place in February 2021 are expected to prompt the deployment of 5G networks by the end of the year, following extensive trials held by the MNOs; fixed broadband is relatively high for the region, with services among the fastest and least expensive in Latin America; government initiatives such as the National Fiber Optic project and Fibra Óptica Austral are providing high-capacity connectivity across the country and will further increase fixed-line broadband; there is a strong focus on fiber broadband, with the number of fiber subscribers having increased 61.7% in 2020, year-on-year; technological improvements have allowed operators to provide a variety of services via their networks, giving rise to a number of bundled packages at competitive prices, including access to video on demand services which in turn is increasing fixed-line broadband; traditional fixed-line teledensity continues to fall as consumers switch to mobile networks and to fixed broadband for voice and data connectivity; more than 8,300 schools receive free broadband as part of the ‘Connectivity for Education 2030’ project (2021)
domestic:
number of fixed-line connections 13 per 100, mobile-cellular usage continues to increase, reaching 136 telephones per 100 persons (2021)
international:
country code - 56; landing points for the Pan-Am, Prat, SAm-1, American Movil-Telxius West Coast Cable, FOS Quellon-Chacabuco, Fibra Optical Austral, SAC and Curie submarine cables providing links to the US, Caribbean and to Central and South America; satellite earth stations - 2 Intelsat (Atlantic Ocean) (2019)
Broadcast media:
national and local terrestrial TV channels, coupled with extensive cable TV networks; the state-owned Television Nacional de Chile (TVN) network is self-financed through commercial advertising revenues and is not under direct government control; large number of privately owned TV stations; about 250 radio stations
Internet country code:
.cl
Internet users:
total:
17.1 million (2021 est.)
percent of population:
90% (2021 est.)
comparison ranking:
total 45
Broadband - fixed subscriptions:
total:
3,763,826 (2020 est.)
subscriptions per 100 inhabitants:
20 (2020 est.)
comparison ranking:
total 41','6bfd7ed31d0d49aefb46dac160b46f9c86ed98389b16fe80e72d2e5de722d78d','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('875ffa84c1dc9aa8802cb6fa0c78e773f1670105ca0066b78de78452f5a1d724',2025,'CN','China','communications',32,'Telephones - fixed lines:
total subscriptions:
180,700,500 (2021 est.)
subscriptions per 100 inhabitants:
13 (2021 est.)
comparison ranking:
total subscriptions 1
Telephones - mobile cellular:
total subscriptions:
1.73 billion (2021 est.)
subscriptions per 100 inhabitants:
122 (2021 est.)
comparison ranking:
total subscriptions 1
Telecommunication systems:
general assessment:
China has the largest Internet market in the world with almost all subscribers accessing Internet through mobile devices; market is driven through government-allied investment; fast-developing data center market; government aims to provide universal and affordable broadband coverage through market competition and private investment in state-controlled enterprises; 3G and LTE subscribers will migrate to 5G aiming for 2 million 5G base stations by the end of 2022; government strengthens IoT policies to boost economic growth; China is pushing development of smart cities beyond Beijing; Beijing residents carry virtual card integrating identity, social security, health, and education documents; government controls gateways to global Internet through censorship, surveillance, and shutdowns; major exporter of broadcasting equipment world-wide (2022)
domestic:
nearly 13 per 100 fixed line and 122 per 100 mobile-cellular (2021)
international:
country code - 86; landing points for the RJCN, EAC-C2C, TPE, APCN-2, APG, NCP, TEA, SeaMeWe-3, SJC2, Taiwan Strait Express-1, AAE-1, APCN-2, AAG, FEA, FLAG and TSE submarine cables providing connectivity to Asia, the Middle East, Europe, and the US; satellite earth stations - 7 (5 Intelsat - 4 Pacific Ocean and 1 Indian Ocean; 1 Intersputnik - Indian Ocean region; and 1 Inmarsat - Pacific and Indian Ocean regions) (2019)
Broadcast media:
all broadcast media are owned by, or affiliated with, the Chinese Communisty Party (CCP) or a government agency; no privately owned TV or radio stations; state-run Chinese Central TV, provincial, and municipal stations offer more than 2,000 channels; the Central Propaganda Department as well as local (provincial, municipal) sends directives to all domestic media outlets to guide its reporting with the government maintaining authority to approve all programming; foreign-made TV programs must be approved/censored prior to broadcast; increasingly, PRC nationals turn to online platforms (Bilibili, Tencent Video, iQiyi, etc) to access PRC and international films and television shows. Video platforms have to abide by regulations issued by the Cyberspace Administration of China (CAC), which align with censorship policies from CCP propaganda authorities. (2022)
Internet country code:
.cn
Internet users:
total:
1.022 billion (2021 est.)
percent of population:
73% (2021 est.)
comparison ranking:
total 1
Broadband - fixed subscriptions:
total:
483,549,500 (2020 est.)
subscriptions per 100 inhabitants:
34 (2020 est.)
comparison ranking:
total 1','9ac4868cbd19f6db5db25eaa3536a63e9e420c7c56df678943c34ed25a2d758c','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('404c97aee5808533adaca90dc0b981a2ebec71591ee1f1535148a861fa6e1fe8',2025,'CX','Christmas Island','communications',43,'Telecommunication systems:
general assessment:
internet access on Christmas Island is provided by satellite; improvements through the Regional Connectivity Program to the macro and small cell mobile sites will provide new and improved mobile, voice and data connectivity for residents and visitors; the upgrade will also support local businesses and community facilities, enabling increased residential access to essential services such as telehealth and education (2022)
domestic:
improvements to Christmas Island include an upgrade to the macro cell base stations and deploy a new macro cell base station at the airport (2022)
international:
international code - 61 8; ASC submarine cable to Singapore and Australia; satellite earth station - 1 (Intelsat provides telephone and telex service) (2019)
Broadcast media:
1 community radio station; satellite broadcasts of several Australian radio and TV stations (2017)
Internet country code:
.cx
Internet users:
total:
1,139 (2021 est.)
percent of population:
78.6% (2021 est.)
comparison ranking:
total 229','52922401d74a583b5145cb3b6443a24ed37aad51575f19b804889d2ceceea2e3','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ea4309ac5d3b8c606f36550ff5b90d663d252abafc77cb891ee8495e7f60f341',2025,'CC','Cocos (Keeling) Islands','communications',61,'Telecommunication systems:
general assessment:
telephone service is part of the Australian network; an operational local mobile-cellular network available; wireless Internet connectivity available
domestic:
local area code - 08
international:
international code - 61 8; telephone, telex, and facsimile communications with Australia and elsewhere via satellite; satellite earth station - 1 (Intelsat)
Broadcast media:
1 local radio station staffed by community volunteers; satellite broadcasts of several Australian radio and TV stations available (2017)
Internet country code:
.cc
Internet users:
total:
80 (2021 est.)
percent of population:
13.4% (2021 est.)
comparison ranking:
total 233','fbe288b486915b521765b59e5e13aa1b899a32fdf1a99815144deba020c460c6','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('79ed8cdefdc0419ad223220e6ec91fe48bf2a490e8725602dda84ad662023091',2025,'CO','Colombia','communications',72,'Telephones - fixed lines:
total subscriptions:
7.6 million (2021 est.)
subscriptions per 100 inhabitants:
15 (2021 est.)
comparison ranking:
total subscriptions 21
Telephones - mobile cellular:
total subscriptions:
75 million (2021 est.)
subscriptions per 100 inhabitants:
150 (2021 est.)
comparison ranking:
total subscriptions 22
Telecommunication systems:
general assessment:
the telecom sector had a solid year thanks to positive performances in the fixed-line broadband, mobile broadband, and mobile voice and data markets; the fixed-line penetration remained stable by the end of 2020, though began to increase into 2021 as a result of the particular demands on households resulting from government measures associated with addressing the pandemic; the mobile market reached a penetration rate of 136% (an increase of over three percentage points on 2019) and managed to keep the same upward growth trajectory that it has sustained over the last ten years; the fixed-line broadband market also expanded, with the number of subscribers increasing 11.4%, and with revenue increasing 9.9% thanks to increased data usage as many customers were forced to work or study from home during the year; the mobile broadband market was the standout performer in 2020, with a 13% increase in the number of subscribers year-on-year, the penetration rate is relatively low compared to other Latin American countries; most significant of all was the surge in mobile broadband traffic a 51% increase over the previous year (2022)
domestic:
fixed-line connections stand at about 15 per 100 persons; mobile cellular telephone subscribership is 150 per 100 persons (2021)
international:
country code - 57; landing points for the SAC, Maya-1, SAIT, ACROS, AMX-1, CFX-1, PCCS, Deep Blue Cable, Globe Net, PAN-AM, SAm-1 submarine cable systems providing links to the US, parts of the Caribbean, and Central and South America; satellite earth stations - 10 (6 Intelsat, 1 Inmarsat, 3 fully digitalized international switching centers) (2019)
Broadcast media:
combination of state-owned and privately owned broadcast media provide service; more than 500 radio stations and many national, regional, and local TV stations (2019)
Internet country code:
.co
Internet users:
total:
37.96 million (2021 est.)
percent of population:
73% (2021 est.)
comparison ranking:
total 26
Broadband - fixed subscriptions:
total:
7,764,772 (2020 est.)
subscriptions per 100 inhabitants:
15 (2020 est.)
comparison ranking:
total 28','9b0c8bab95428af3e27699e43c29b1e6ef956ebe788eb09f5380f896991490ea','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('df14ad455ed1595afff864505ba499ed98c04a41594e9f9e6f4b0694c6619f3a',2025,'KM','Comoros','communications',8,'Telephones - fixed lines:
total subscriptions:
7,431 (2021 est.)
subscriptions per 100 inhabitants:
1 (2021 est.)
comparison ranking:
total subscriptions 195
Telephones - mobile cellular:
total subscriptions:
853,449 (2021 est.)
subscriptions per 100 inhabitants:
104 (2021 est.)
comparison ranking:
total subscriptions 167
Telecommunication systems:
general assessment:
Comoros launched a special program for the construction of a wireless network to inter connect the 3 islands of the archipelago; telephone service limited to the islands’ few towns (2020)
domestic:
fixed-line connections less than 1 per 100 persons; mobile-cellular usage about 104 per 100 persons (2021)
international:
country code - 269; landing point for the EASSy, Comoros Domestic Cable System, Avassa, and FLY-LION3 fiber-optic submarine cable system connecting East Africa with Europe; HF radiotelephone communications to Madagascar and Reunion (2019)
Broadcast media:
national state-owned TV station and a TV station run by Anjouan regional government; national state-owned radio; regional governments on the islands of Grande Comore and Anjouan each operate a radio station; a few independent and small community radio stations operate on the islands of Grande Comore and Moheli, and these two islands have access to Mayotte Radio and French TV
Internet country code:
.km
Internet users:
total:
221,400 (2021 est.)
percent of population:
27% (2021 est.)
comparison ranking:
total 179
Broadband - fixed subscriptions:
total:
1,066 (2020 est.)
subscriptions per 100 inhabitants:
0.1 (2020 est.)
comparison ranking:
total 201','ddfa9c558a15245ccce98b33b196bb2ce46f87014fc5e0284a879222047aa876','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('85c8aa74f01b48a7ba830b4ba43d03114531bd80cc4b15960b4c96d5836f5b8a',2025,'KM','Comoros','communications',19,'Telephones - fixed lines:
total subscriptions:
(2021 est.) less than 1
subscriptions per 100 inhabitants:
(2021 est.) less than 1
Telephones - mobile cellular:
total subscriptions:
47 million (2021 est.)
subscriptions per 100 inhabitants:
49 (2021 est.)
comparison ranking:
total subscriptions 36
Telecommunication systems:
general assessment:
the telecom system remains one of the least developed in the region; the government can only loosely regulate the sector; the investment made in infrastructure is derived from donor countries or from the efforts of foreign (particularly Chinese) companies and banks; efforts have been made to improve the regulation of the telecom sector; the limited fixed-line infrastructure has become the principal providers of basic telecom services; the development of the DRC’s internet and broadband market has been held back by the poorly developed national and international infrastructure; the country was finally connected to international bandwidth through the WACS submarine cable in 2013; breakages in the WACS cable have exposed the vulnerability of international bandwidth, which is still limited; the Equiano submarine cable, and has also completed a 5,000km cable running through the DRC to link to cable systems landing in countries facing the Atlantic and Indian Oceans; the first commercial LTE networks were launched in May 2018 soon after LTE licenses were issued; mobile operators are keen to develop mobile data services, capitalizing on the growth of smartphones usage; there has been some progress with updating technologies, most of the GSM network has been upgraded to 3G by 2021 (2022)
domestic:
inadequate fixed-line infrastructure with fixed-line connections less than 1 per 100 persons; mobile-cellular subscriptions over 49 per 100 persons (2021)
international:
country code - 243; ACE and WACS submarine cables to West and South Africa and Europe; satellite earth station - 1 Intelsat (Atlantic Ocean) (2019)
Broadcast media:
state-owned TV broadcast station with near national coverage; more than a dozen privately owned TV stations - 2 with near national coverage; 2 state-owned radio stations are supplemented by more than 100 private radio stations; transmissions of at least 2 international broadcasters are available
Internet country code:
.cd
Internet users:
total:
21,102,720 (2021 est.)
percent of population:
23.2% (2021 est.)
comparison ranking:
total 41
Broadband - fixed subscriptions:
total:
31,000 (2020 est.)
subscriptions per 100 inhabitants:
0.03 (2020 est.)
comparison ranking:
total 153','9bde1e16aa363ec555049e46673525528a77394cb6d471ad2fd21ab8bc28dd3c','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f954665fa3683437ffc9dcdce96f0fb2923d68a57d0f87ba7289810a8aa31e40',2025,'KM','Comoros','communications',31,'Telephones - fixed lines:
total subscriptions:
17,000 (2020 est.)
subscriptions per 100 inhabitants:
(2020 est.) less than 1
comparison ranking:
total subscriptions 176
Telephones - mobile cellular:
total subscriptions:
5,558,658 (2021 est.)
subscriptions per 100 inhabitants:
97 (2021 est.)
comparison ranking:
total subscriptions 121
Telecommunication systems:
general assessment:
suffering from economic challenges of stimulating recovery and reducing poverty; primary network consists of microwave radio relay and coaxial cable with services barely adequate for government use; key exchanges are in Brazzaville, Pointe-Noire, and Loubomo; intercity lines frequently out of order; youth are seeking the Internet more than their parents and often gain access through cyber cafes; only the most affluent have Internet access in their homes; operator has plans to upgrade national broadband through fiber link to West Africa Cable System (WACS) landing station at Pointe-Noire with connections to Angola and DRC; fiber network project with aims to connect north and south regions; DRC operator added fiber link between Brazzaville and Kinshasa (2020)
domestic:
fixed-line infrastructure inadequate, providing less than 1 fixed-line connection per 100 persons; mobile-cellular 97 per 100 persons (2021)
international:
country code - 242; WACS submarine cables to Europe and Western and South Africa; satellite earth station - 1 Intelsat (Atlantic Ocean) (2019)
Broadcast media:
1 state-owned TV and 3 state-owned radio stations; several privately owned TV and radio stations; satellite TV service is available; rebroadcasts of several international broadcasters are available
Internet country code:
.cg
Internet users:
total:
1,794,390 (2021 est.)
percent of population:
32.1% (2021 est.)
comparison ranking:
total 137
Broadband - fixed subscriptions:
total:
1,000 (2020 est.)
subscriptions per 100 inhabitants:
0.02 (2020 est.)
comparison ranking:
total 204','8c5bc21a4ff3e73f8fbf66364bf25d1363c56da1f324ae9a7dfe6fc1d355aba6','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c9335e95d469d8e9838870c105c0dee77d4e2b19022233f40656e4d11e4a1697',2025,'CK','Cook Islands','communications',42,'Telephones - fixed lines:
total subscriptions:
7,000 (2021 est.)
subscriptions per 100 inhabitants:
41 (2021 est.)
comparison ranking:
total subscriptions 196
Telephones - mobile cellular:
total subscriptions:
17,000 (2021 est.)
subscriptions per 100 inhabitants:
100 (2021 est.)
comparison ranking:
total subscriptions 217
Telecommunication systems:
general assessment:
demand for mobile broadband is increasing due to mobile services being the primary and most wide-spread source for Internet access across the region; Telecom Cook Islands offers international direct dialing, Internet, email, and fax; individual islands are connected by a combination of satellite earth stations, microwave systems, and VHF and HF radiotelephone (2020)
domestic:
service is provided by small exchanges connected to subscribers by open-wire, cable, and fiber-optic cable; nearly 41 per 100 fixed-line and about 100 per 100 mobile-cellular (2021)
international:
country code - 682; the Manatua submarine cable to surrounding islands of Niue, Samoa, French Polynesia and other Cook Islands, the topography of the South Pacific region has made Internet connectivity a serious issue for many of the remote islands; submarine fiber-optic networks are expensive to build and maintain; satellite earth station - 1 Intelsat (Pacific Ocean) (2019)
Broadcast media:
1 privately owned TV station broadcasts from Rarotonga providing a mix of local news and overseas-sourced programs (2019)
Internet country code:
.ck
Internet users:
total:
11,382 (2021 est.)
percent of population:
64.8% (2021 est.)
comparison ranking:
total 217
Broadband - fixed subscriptions:
total:
2,700 (2018 est.)
subscriptions per 100 inhabitants:
15 (2018 est.)
comparison ranking:
total 195','349205a459df075a5a1f37f249766bfac2caae61618b80b8f5cef78cbd0f596f','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0939ce7f8512f0f0daa570673d98edbc78d241aa6ea781111dea0a386b5f4fbb',2025,'CK','Cook Islands','communications',51,'Communications - note:
automatic weather stations on many of the isles and reefs relay data to the mainland','9e28245a2f448ff7dc27fc6d1e3dc4602e02f49bca765220baf05904546264b8','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('dc53592d4ff89836f0f5c635e17452adf867d7147b0bbc66822d03baf7a223c1',2025,'CR','Costa Rica','communications',62,'Telephones - fixed lines:
total subscriptions:
553,455 (2021 est.)
subscriptions per 100 inhabitants:
11 (2021 est.)
comparison ranking:
total subscriptions 89
Telephones - mobile cellular:
total subscriptions:
7,834,435 (2021 est.)
subscriptions per 100 inhabitants:
152 (2021 est.)
comparison ranking:
total subscriptions 102
Telecommunication systems:
general assessment:
the fixed broadband market is one of the few parts of Costa Rica’s telecom sector to experience solid growth in recent years, both in size and revenue; the country’s fiber network expanded by 56% in 2020, reaching about 176,200km; fixed-line broadband traffic volume also increased by more than 30%, year-on-year; other areas of the market have proven relatively lack luster, with slow or even negative growth; some of this can be attributed to the economic and social impacts of the pandemic, but the fixed-line and mobile sectors have both been struggling to produce decent results since well before the start of the crisis; the rollout of 5G network infrastructure in Costa Rica is unlikely to occur to any scale before 2023, but this may be one of the few remaining areas of opportunity open to investors outside of fixed-line internet and pay TV services (2021)
domestic:
roughly 11 per 100 fixed-line and 152 per 100 mobile-cellular (2021)
international:
country code - 506; landing points for the ARCOS-1, MAYA-1, and the PAC submarine cables that provide links to South and Central America, parts of the Caribbean, and the US; connected to Central American Microwave System; satellite earth stations - 2 Intelsat (Atlantic Ocean) (2019)
Broadcast media:
over two dozen privately owned TV stations and 1 publicly owned TV station nationwide; cable network services are widely available; more than 100 privately owned radio stations and a public radio network (2022)
Internet country code:
.cr
Internet users:
total:
4.316 million (2021 est.)
percent of population:
83% (2021 est.)
comparison ranking:
total 105
Broadband - fixed subscriptions:
total:
992,725 (2020 est.)
subscriptions per 100 inhabitants:
20 (2020 est.)
comparison ranking:
total 74','fe85d25ef1ceb3aa1d4981dcb6bdef1a14cd3b692e884c01f6b21f4bf06e4d5c','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4480dd62480ff7489621550a5f17e4e2b48018a301f5a07be43c726563a86fa1',2025,'CR','Costa Rica','communications',74,'Telephones - fixed lines:
total subscriptions:
265,513 (2021 est.)
subscriptions per 100 inhabitants:
1 (2021 est.)
comparison ranking:
total subscriptions 115
Telephones - mobile cellular:
total subscriptions:
44,561,505 (2021 est.)
subscriptions per 100 inhabitants:
162 (2021 est.)
comparison ranking:
total subscriptions 38
Telecommunication systems:
general assessment:
in recent years the government of Ivory Coast has helped develop a competitive telecom sector focused on the provision of converged services, thus allowing operators to offer fixed-line and mobile services under a universal services license regime; the fixed internet and broadband sectors remain underdeveloped; this is a legacy of poor international connectivity, which resulted in high wholesale prices, limited bandwidth, and a lack of access for alternative operators to international infrastructure; these limitations were addressed following the landing of a second cable in November 2011; Orange Group has also launched its 20,000km Djoliba cable system, reaching across eight countries in the region, while the 2Africa submarine cable is being developed by a consortium of companies; with a landing station providing connectivity to Côte d’Ivoire, the system is expected to be completed in late 2023 (2022)
domestic:
1 per 100 fixed-line teledensity; mobile subscriptions are 162 per 100 persons (2021)
international:
country code - 225; landing point for the SAT-3/WASC, ACE, MainOne, and WACS fiber-optic submarine cable that provides connectivity to Europe and South and West Africa; satellite earth stations - 2 Intelsat (1 Atlantic Ocean and 1 Indian Ocean) (2019)
Broadcast media:
state-controlled Radiodiffusion Television Ivoirieinne (RTI) is made up of 2 radio stations (Radio Cote d’Ivoire and Frequence2) and 2 television stations (RTI1 and RTI2), with nationwide coverage, broadcasts mainly in French; after 2011 post-electoral crisis, President OUATTARA’s administration reopened RTI Bouake’, the broadcaster’s office in Cote d’Ivoire’s 2nd largest city, where facilities were destroyed during the 2002 rebellion; Cote d’Ivoire is also home to 178 proximity radio stations, 16 religious radio stations, 5 commercial radio stations, and 5 international radios stations, according to the Haute Autorite’ de la Communication Audiovisuelle (HACA); govt now runs radio UNOCIFM, a radio station previously owned by the UN Operation in Cote d’Ivoire; in Dec 2016, the govt announced 4 companies had been granted licenses to operate -Live TV, Optimum Media Cote d’Ivoire, the Audiovisual Company of Cote d’Ivoire (Sedaci), and Sorano-CI, out of the 4 companies only one has started operating (2019)
Internet country code:
.ci
Internet users:
total:
12.15 million (2021 est.)
percent of population:
45% (2021 est.)
comparison ranking:
total 54
Broadband - fixed subscriptions:
total:
260,097 (2020 est.)
subscriptions per 100 inhabitants:
1 (2020 est.)
comparison ranking:
total 110','98d17a5bd43de451c9bcfd8786c979124cfc4980c750764cf905325f9ce2344b','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ede068d10725ba132a663da0e43c164b7371e3c7d0770c396b975c6d4f1d619b',2025,'HR','Croatia','communications',8,'Telephones - fixed lines:
total subscriptions:
1,268,941 (2021 est.)
subscriptions per 100 inhabitants:
31 (2021 est.)
comparison ranking:
total subscriptions 66
Telephones - mobile cellular:
total subscriptions:
4,402,213 (2021 est.)
subscriptions per 100 inhabitants:
108 (2021 est.)
comparison ranking:
total subscriptions 128
Telecommunication systems:
general assessment:
the mobile market is served by three MNOs, supplemented by a number of MVNOs; the network operators have focused on improving ARPU by encouraging prepaid subscribers to migrate to postpaid plans, and on developing revenue from mobile data services; 5G services are widely available, though the sector will only show its full potential later in 2021 following the award of licenses in several bands; this will contribute towards the government’s national broadband plan to 2027, which is tied to the EC’s two allied projects aimed at providing gigabit connectivity by the end of 2025; the broadband sector benefits from effective competition between the DSL and cable platforms, while there are also numerous fiber deployments in urban areas; the number of FttP subscribers broached 134,000 in March 2021. (2021)
domestic:
fixed-line teledensity 31 per 100 persons; mobile-cellular telephone subscriptions are 108 per 100 (2021)
international:
country code - 385; the ADRIA-1 submarine cable provides connectivity to Albania and Greece; digital international service is provided through the main switch in Zagreb; Croatia participates in the Trans-Asia-Europe fiber-optic project, which consists of 2 fiber-optic trunk connections with Slovenia and a fiber-optic trunk line from Rijeka to Split and Dubrovnik (2019)
Broadcast media:
the national state-owned public broadcaster, Croatian Radiotelevision, operates 4 terrestrial TV networks, a satellite channel that rebroadcasts programs for Croatians living abroad, and 6 regional TV centers; 2 private broadcasters operate national terrestrial networks; 29 privately owned regional TV stations; multi-channel cable and satellite TV subscription services are available; state-owned public broadcaster operates 4 national radio networks and 23 regional radio stations; 2 privately owned national radio networks and 117 local radio stations (2019)
Internet country code:
.hr
Internet users:
total:
3.321 million (2021 est.)
percent of population:
81% (2021 est.)
comparison ranking:
total 114
Broadband - fixed subscriptions:
total:
1,030,973 (2020 est.)
subscriptions per 100 inhabitants:
25 (2020 est.)
comparison ranking:
total 73','b427e498988d7be2fc7a7c0c703e1fa8516e8d9b4a7af0c29f7e9325bbeb82bd','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('67a96b027361ef0cf614480959ad9a5ced572968d20bc6515e429e556abdb34a',2025,'CU','Cuba','communications',19,'Telephones - fixed lines:
total subscriptions:
1,539,269 (2021 est.)
subscriptions per 100 inhabitants:
14 (2021 est.)
comparison ranking:
total subscriptions 61
Telephones - mobile cellular:
total subscriptions:
7,103,296 (2021 est.)
subscriptions per 100 inhabitants:
63 (2021 est.)
comparison ranking:
total subscriptions 110
Telecommunication systems:
general assessment:
internet availability has increased substantially over the past few years, but only about 64 percent of Cubans have Internet access, and even fewer Cubans--about 60 percent of the population--have access to cell phone service; in 2021 the Cuban Government passed a decree that strengthened its authority to censor Internet and telephonic communications; state control of the telecom sector hinders development; Cuba has the lowest mobile phone and Internet subscription rates in the region; fixed-line density is also very low; thaw of US-Cuba relations encouraged access to services, such as Wi-Fi hot spots; access to sites is controlled and censored; DSL and Internet are available in Havana, though costs are too high for most Cubans; international investment and agreement to improve Internet access through cost-free and direct connection between networks (2021)
domestic:
fixed-line density remains low at a little over 14 per 100 inhabitants; mobile-cellular service has expanded to about 63 per 100 persons (2021)
international:
country code - 53; the ALBA-1, GTMO-1, and GTMO-PR fiber-optic submarine cables link Cuba, Jamaica, and Venezuela; satellite earth station - 1 Intersputnik (Atlantic Ocean region) (2019)
Broadcast media:
government owns and controls all broadcast media:
eight national TV channels (Cubavision, Cubavision Plus, Tele Rebelde, Multivision, Educational Channel 1 and 2, Canal Clave, Canal Habana), two international channels (Cubavision Internacional and Canal Caribe), multiple regional TV stations, 7 national radio networks, and multiple regional stations; the Cuban Government beams over the Radio-TV Marti signal; although private ownership of electronic media is prohibited, several online independent news sites exist; those that are not openly critical of the government are often tolerated; the others are blocked by the government; there are no independent TV channels, but several outlets have created strong audiovisual content (El Toque, for example); a community of young Youtubers is also growing, mostly with channels about sports, technology and fashion; Christian denominations are creating original video content to distribute via social media (2023)
Internet country code:
.cu
Internet users:
total:
7.81 million (2021 est.)
percent of population:
71% (2021 est.)
note:
private citizens are prohibited from buying computers or accessing the Internet without special authorization; foreigners may access the Internet in large hotels but are subject to firewalls; some Cubans buy illegal passwords on the black market or take advantage of public outlets to access limited email and the government-controlled “intranet”; issues relating to COVID-19 impact research into internet adoption, so actual internet user figures may be different than published numbers suggest
comparison ranking:
total 76
Broadband - fixed subscriptions:
total:
231,654 (2020 est.)
subscriptions per 100 inhabitants:
2 (2020 est.)
comparison ranking:
total 115','8e1483932d08893b3241f483a2c067e6f2811d1808db24192daae7503090ee0e','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ef056616af05fc57554452f39978d530d8361bca60d515a0a7fb30a397a23efe',2025,'CU','Cuba','communications',30,'Telephones - fixed lines:
total subscriptions:
53,000 (2021 est.)
subscriptions per 100 inhabitants:
28 (2021 est.)
comparison ranking:
total subscriptions 155
Telephones - mobile cellular:
total subscriptions:
170,000 (2021 est.)
subscriptions per 100 inhabitants:
88 (2021 est.)
comparison ranking:
total subscriptions 187
Telecommunication systems:
general assessment:
fully automatic modern telecommunications system; telecom sector across the Caribbean region continues to be one of the growth areas; given the lack of economic diversity in the region, with a high dependence on tourism and activities such as fisheries and offshore financial services the telecom sector contributes greatly to the GDP (2020)
domestic:
roughly 28 per 100 users for fixed-line and 88 per 100 users for cellular-mobile (2021)
international:
country code - +599, PCCS submarine cable system to US, Caribbean and Central and South America (2019)
Broadcast media:
government-run TeleCuracao operates a TV station and a radio station; 2 other privately owned TV stations and several privately owned radio stations (2019)
Internet country code:
.cw
Internet users:
total:
111,956 (2021 est.)
percent of population:
68.1% (2021 est.)
comparison ranking:
total 186
Broadband - fixed subscriptions:
total:
55,000 (2020 est.)
subscriptions per 100 inhabitants:
34 (2020 est.)
comparison ranking:
total 141','b41ee1097ad67575612261b1163a9e53a2276a2c5c44ef213fc20f30a0a83db7','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('161eca0da42b27add763446a4ef374309442b94a24b8f8a7782420c07a3293aa',2025,'CY','Cyprus','communications',41,'Telephones - fixed lines:
total subscriptions:
304,581 (2021 est.)
subscriptions per 100 inhabitants:
34 (2021 est.)
comparison ranking:
total subscriptions 108
Telephones - mobile cellular:
total subscriptions:
1,320,794 (2021 est.)
subscriptions per 100 inhabitants:
149 (2021 est.)
comparison ranking:
total subscriptions 161
Telecommunication systems:
general assessment:
Cyprus suffered from the effects of the pandemic in 2020 and 2021, when the tourism sector was essentially closed; during 2022, there were adverse effects caused by Russia’s invasion of Ukraine, which has resulted in a dramatic drop in the number of Russian tourists entering the country; the mobile market is served by four mobile network operators; the number of mobile subscribers fell in 2020, largely the result of subscribers scaling back on multiple SIM cards as an economic measure; the broadband market continues to develop steadily, providing the country with one of the highest broadband penetration rates in the region; DSL remains the dominant access platform, accounting for about two-thirds of fixed broadband connections; although fiber infrastructure in Cyprus is minimal (supported by the government and regulator) to extend an FttP service to about 200,000 premises; as a result, the number of DSL subscribers is set to fall steadily in coming years as customers are migrated to the fiber platform (2023)
domestic:
fixed-line about 34 per 100 and about 149 per 100 for mobile-cellular teledensity (2021)
international:
country code - 357 (area administered by Turkish Cypriots uses the country code of Turkey - 90); a number of submarine cables, including the SEA-ME-WE-3, CADMOS, MedNautilus Submarine System, POSEIDON, TE North/TGN-Eurasia/SEACOM/Alexandros/Medes, UGARIT, Aphrodite2, Hawk, Lev Submarine System, and Tamares combine to provide connectivity to Europe, the Middle East, Africa, Asia, Australia, and Southeast Asia; Turcyos-1 and Turcyos-2 submarine cable in Turkish North Cyprus link to Turkey; tropospheric scatter; satellite earth stations - 8 (3 Intelsat - 1 Atlantic Ocean and 2 Indian Ocean, 2 Eutelsat, 2 Intersputnik, and 1 Arabsat) (2019)
Broadcast media:
mixture of state and privately run TV and radio services; the public broadcaster operates 2 TV channels and 4 radio stations; 6 private TV broadcasters, satellite and cable TV services including telecasts from Greece and Turkey, and a number of private radio stations are available; in areas administered by Turkish Cypriots, there are 2 public TV stations, 4 public radio stations, and 7 privately owned TV and 21 radio broadcast stations plus 6 radio and 4 TV channels of local universities, plus 1 radio station of military, security forces and 1 radio station of civil defense cooperation, as well as relay stations from Turkey (2019)
Internet country code:
.cy
Internet users:
total:
809,900 (2021 est.)
percent of population:
91% (2021 est.)
comparison ranking:
total 154
Broadband - fixed subscriptions:
total:
332,080 (2020 est.)
subscriptions per 100 inhabitants:
37 (2020 est.)
comparison ranking:
total 103','1a30c4716d5e43461583c1e75d8f0f5a274cf397217a8ff86c85507d8d113251','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('634eb8b67e6d3cb75278160af0c6c59a59505edac50c82baf65c9dc6b988677f',2025,'CZ','Czechia','communications',53,'Telephones - fixed lines:
total subscriptions:
1,294,806 (2021 est.)
subscriptions per 100 inhabitants:
12 (2021 est.)
comparison ranking:
total subscriptions 65
Telephones - mobile cellular:
total subscriptions:
13,129,905 (2021 est.)
subscriptions per 100 inhabitants:
125 (2021 est.)
comparison ranking:
total subscriptions 76
Telecommunication systems:
general assessment:
the telecom market has attracted investment from among the key regional telcos; telcos in the Czech Republic have become multi-service providers, offering a full range of fixed and mobile services; this has enabled the reach of their 5G networks; this process has also been assisted by them closing down 3G networks and reforming spectrum for 5G and LTE use (2023)
domestic:
roughly 12 fixed-telephone subscriptions per 100 inhabitants and mobile telephone usage of 125 per 100 inhabitants (2021)
international:
country code - 420; satellite earth stations - 6 (2 Intersputnik - Atlantic and Indian Ocean regions, 1 Intelsat, 1 Eutelsat, 1 Inmarsat, 1 Globalstar) (2019)
Broadcast media:
22 TV stations operate nationally, with 17 of them in private hands; publicly operated Czech Television has 5 national channels; throughout the country, there are some 350 TV channels in operation, many through cable, satellite, and IPTV subscription services; 63 radio broadcasters are registered, operating over 80 radio stations, including 7 multiregional radio stations or networks; publicly operated broadcaster Czech Radio operates 4 national, 14 regional, and 4 Internet stations; both Czech Radio and Czech Television are partially financed through a license fee (2019)
Internet country code:
.cz
Internet users:
total:
9.13 million (2021 est.)
percent of population:
83% (20201 est.)
comparison ranking:
total 63
Broadband - fixed subscriptions:
total:
3,845,426 (2020 est.)
subscriptions per 100 inhabitants:
36 (2020 est.)
comparison ranking:
total 39','10cf76e02e2a6d2bdfe5cdd45ddf87771c2d4893f92df4e7495396b264784adb','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1eb98229d4bdbff4cac6228baa08ac3e82635fbd901605d7edf5d532edc2a5c4',2025,'DK','Denmark','communications',8,'Telephones - fixed lines:
total subscriptions:
706,604 (2021 est.)
subscriptions per 100 inhabitants:
12 (2021 est.)
comparison ranking:
total subscriptions 81
Telephones - mobile cellular:
total subscriptions:
7,287,875 (2021 est.)
subscriptions per 100 inhabitants:
124 (2021 est.)
comparison ranking:
total subscriptions 107
Telecommunication systems:
general assessment:
Denmark has one of the highest broadband subscription rates globally, with a near universal availability of super-fast connections; extensive cable and DSL infrastructure has been supported by a progressive regulatory regime which has encouraged operator access to both copper and fiber networks; fiber networks have a fast-growing footprint, while a number of community and metropolitan schemes have supplemented their own commitments to build out fiber nationally; a number of wholesale fiber schemes have also added to the wider availability of fiber broadband; the reach of LTE infrastructure is comprehensive, while the Mobile Network Operators by mid-2021 had also provided about 90% population coverage with 5G; services based on 5G were initially launched using trial 3.5GHz licenses; the multi-spectrum auction held in April 2021 has enabled them to improve the resilience and capacity of 5G; all MNOs are engaged in closing down their 3G networks and repurposing spectrum for LTE and 5G use (2021)
domestic:
fixed-line roughly 12 per 100 and about 124 per 100 for mobile-cellular subscriptions (2021)
international:
country code - 45; landing points for the NSC, COBRAcable, CANTAT-3, DANICE, Havfrue/AEC-2, TAT-14m Denmark-Norway-5 & 6, Skagenfiber West & East, GC1, GC2, GC3, GC-KPN, Kattegat 1 & 2 & 3, Energinet Lyngsa-Laeso, Energinet Laeso-Varberg, Fehmarn Balt, Baltica, German-Denmark 2 & 3, Ronne-Rodvig, Denmark-Sweden 15 & 16 & 17 & 18, IP-Only Denmark-Sweden, Scandinavian South, Scandinavian Ring North, Danica North, 34 series of fiber-optic submarine cables link Denmark with Canada, Faroe Islands, Germany, Iceland, Netherlands, Norway, Poland, Russia, Sweden, US, and UK; satellite earth stations - 18 (6 Intelsat, 10 Eutelsat, 1 Orion, 1 Inmarsat (Blaavand-Atlantic-East)); note - the Nordic countries (Denmark, Finland, Iceland, Norway, and Sweden) share the Danish earth station and the Eik, Norway, station for worldwide Inmarsat access (2019)
Broadcast media:
strong public-sector TV presence with state-owned Danmarks Radio (DR) operating 6 channels and publicly owned TV2 operating roughly a half-dozen channels; broadcasts of privately owned stations are available via satellite and cable feed; DR operates 4 nationwide FM radio stations, 10 digital audio broadcasting stations, and 14 web-based radio stations; 140 commercial and 187 community (non-commercial) radio stations (2019)
Internet country code:
.dk
Internet users:
total:
5.841 million (2021 est.)
percent of population:
99% (2021 est.)
comparison ranking:
total 81
Broadband - fixed subscriptions:
total:
2,590,282 (2020 est.)
subscriptions per 100 inhabitants:
45 (2020 est.)
comparison ranking:
total 51','7f362abdfca65f90a5ce82a2f8f11da1a3fbeb2f1087c5f99efac596b66896a9','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4b1b5cf6e565b9686c3ad65bff99acc7b9e3e2248d6d8ea70f3bac82c1cbfbac',2025,'DK','Denmark','communications',20,'Broadcast media:
British Forces Broadcast Service (BFBS) provides multi-channel satellite TV service as well as BFBS radio broadcasts to the Dhekelia Sovereign Base','a409c28f1f029361ffb600ef3ea7c72f87a2223c62da393d3a5b9172302bab67','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3f67bf7ec8a470863c21305f06138287c6aa4b63cd73189cf66f83d0aeed5ad5',2025,'DJ','Djibouti','communications',29,'Telephones - fixed lines:
total subscriptions:
27,326 (2021 est.)
subscriptions per 100 inhabitants:
2 (2021 est.)
comparison ranking:
total subscriptions 167
Telephones - mobile cellular:
total subscriptions:
489,339 (2021 est.)
subscriptions per 100 inhabitants:
44 (2021 est.)
comparison ranking:
total subscriptions 174
Telecommunication systems:
general assessment:
Djibouti remains one of the last bastions where the national telco has a monopoly on all telecom services, including fixed lines, mobile, internet, and broadband; despite the country benefiting from its location as a hub for international submarine cables, prices for telecom services remain relatively high, and out of reach for a number of customers, weighing on market advancement; the Djibouti government is aiming to sell a minority stake in the incumbent telco (retaining some control of decisions) while securing the financial backing and the management acumen of a foreign operator; this is part of a larger plan to modernize the country’s economy more generally; the state expects to conduct a sale of up to 40% of the company to an international investor (2023)
domestic:
about 2 per 100 fixed-line teledensity and nearly 44 per 100 mobile-cellular (2021)
international:
country code - 253; landing points for the SEA-ME-WE-3 & 5, EASSy, Aden-Djibouti, Africa-1, DARE-1, EIG, MENA, Bridge International, PEACE Cable, and SEACOM fiber-optic submarine cable systems providing links to Asia, the Middle East, Europe, Southeast Asia, Australia and Africa; satellite earth stations - 2 (1 Intelsat - Indian Ocean and 1 Arabsat) (2019)
Broadcast media:
state-owned Radiodiffusion-Television de Djibouti operates the sole terrestrial TV station, as well as the only 2 domestic radio networks; no private TV or radio stations; transmissions of several international broadcasters are available (2019)
Internet country code:
.dj
Internet users:
total:
759,000 (2021 est.)
percent of population:
69% (2021 est.)
comparison ranking:
total 157
Broadband - fixed subscriptions:
total:
25,053 (2020 est.)
subscriptions per 100 inhabitants:
3 (2020 est.)
comparison ranking:
total 159','3def8509afa67f45dbc38137931345edea51b40cf7ccf6807cb3478a0a5513aa','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8fa9d683b0cac9f821e49b2cad2165bfbc92d8c544b893d9bab40bf5d68eed22',2025,'DM','Dominica','communications',41,'Telephones - fixed lines:
total subscriptions:
7,500 (2021 est.)
subscriptions per 100 inhabitants:
10 (2021 est.)
comparison ranking:
total subscriptions 194
Telephones - mobile cellular:
total subscriptions:
62,000 (2021 est.)
subscriptions per 100 inhabitants:
86 (2021 est.)
comparison ranking:
total subscriptions 203
Telecommunication systems:
general assessment:
the telecom sector has seen a decline in subscriber numbers (particularly for prepaid mobile services the mainstay of short term visitors) and revenue; fixed and mobile broadband services are two areas that have benefited from the crisis as employees and students have resorted to working from home; one area of the telecom market that is not prepared for growth is 5G mobile; governments, regulators, and even the mobile network operators have shown that they have not been investing in 5G opportunities at the present time; network expansion and enhancements remain concentrated around improving LTE coverage (2021)
domestic:
10 fixed-line connections per 100 persons; mobile-cellular subscriptions are about 86 per 100 persons (2021)
international:
country code - 1-767; landing points for the ECFS and the Southern Caribbean Fiber submarine cables providing connectivity to other islands in the eastern Caribbean extending from the British Virgin Islands to Trinidad and to the US; microwave radio relay and SHF radiotelephone links to Martinique and Guadeloupe; VHF and UHF radiotelephone links to Saint Lucia (2019)
Broadcast media:
no terrestrial TV service available; subscription cable TV provider offers some locally produced programming plus channels from the US, Latin America, and the Caribbean; state-operated radio broadcasts on 6 stations; privately owned radio broadcasts on about 15 stations (2019)
Internet country code:
.dm
Internet users:
total:
58,320 (2021 est.)
percent of population:
81% (2021 est.)
comparison ranking:
total 198
Broadband - fixed subscriptions:
total:
16,000 (2020 est.)
subscriptions per 100 inhabitants:
22 (2020 est.)
comparison ranking:
total 172','fd87fc3d1be6328d56473e4c7958e0f1e5d2fd50c1412ba41607e59907d24e81','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b0d0324abbbb787cda7a4da97c92e86baf3829e0954c60c5b1f4390285987e66',2025,'DO','Dominican Republic','communications',52,'Telephones - fixed lines:
total subscriptions:
1,154,670 (2021 est.)
subscriptions per 100 inhabitants:
10 (2021 est.)
comparison ranking:
total subscriptions 70
Telephones - mobile cellular:
total subscriptions:
9,735,351 (2021 est.)
subscriptions per 100 inhabitants:
88 (2021 est.)
comparison ranking:
total subscriptions 94
Telecommunication systems:
general assessment:
the Dominican Republic’s telecom sector continued its solid form throughout 2020 and into 2021, shrugging off the economic turmoil unleashed by the Covid-19 pandemic to maintain a decade-long run of low but positive growth across all areas of the market; the Dominican Republic remains behind most of its counterparts in the Latin American region, especially in terms of fixed-line network coverage; mobile subscriptions are on par with the regional average, but at subscription levels of around 88% there is still ample opportunity for growth; in terms of growth, the standout winner was once again the mobile broadband segment; the market is expected to see close to 8% growth in 2021, building further on the gains it already made in 2020 when lock downs and work-from-home rules encouraged many people to find ways to upgrade their internet access and performance; the limited coverage of fixed-line broadband networks makes mobile the first, if not only, choice for most people in the country (2021)
domestic:
fixed-line teledensity is about 10 per 100 persons; mobile cellular subscriptions 88 per 100 persons (2021)
international:
country code - 1-809; 1-829; 1-849; landing point for the ARCOS-1, Antillas 1, AMX-1, SAm-1, East-West, Deep Blue Cable and the Fibralink submarine cables that provide links to South and Central America, parts of the Caribbean, and US; satellite earth station - 1 Intelsat (Atlantic Ocean) (2019)
Broadcast media:
combination of state-owned and privately owned broadcast media; 1 state-owned TV network and a number of private TV networks; networks operate repeaters to extend signals throughout country; combination of state-owned and privately owned radio stations with more than 300 radio stations operating (2019)
Internet country code:
.do
Internet users:
total:
9.35 million (2021 est.)
percent of population:
85% (2021 est.)
comparison ranking:
total 61
Broadband - fixed subscriptions:
total:
1,031,858 (2020 est.)
subscriptions per 100 inhabitants:
10 (2020 est.)
comparison ranking:
total 72','28fdb4b60029bbd792207141f8654f2b599f7aef12827d52bf2f75e9fa68d256','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cd001510557eccc84b5463f3490e6104b83aa0f886f1664554956ebf8fdde16e',2025,'EC','Ecuador','communications',8,'Telephones - fixed lines:
total subscriptions:
1,846,666 (2021)
subscriptions per 100 inhabitants:
10 (2021 est.)
comparison ranking:
total subscriptions 56
Telephones - mobile cellular:
total subscriptions:
16,789,600 (2021 est.)
subscriptions per 100 inhabitants:
94 (2021 est.)
comparison ranking:
total subscriptions 66
Telecommunication systems:
general assessment:
Ecuador has a small telecom market dominated by the mobile sector; the evolution of the market has been influenced by the poor fixed-line infrastructure, which has stymied the development of fixed-line broadband services; to some extent poor infrastructure has been the result of topographical challenges which have rendered the cost of deploying networks to remote and mountainous areas prohibitive; although Ecuador has several fixed-line operators and a large number of ISPs, the state-owned incumbent leads the fixed-line market, and thus also the fixed broadband market; thus far the MVNO sector has been slow to develop, partly because the incumbent operators also have their low-cost brands and thus there is little business case for new market entrants; the government is keen to advance and improve teledensity; from 2022, additional revenue will be earmarked for programs aimed at expanding the reach of internet and mobile services in rural areas of the country; Ecuador lacks a national 5G roadmap; the mobile operators have conducted several 5G pilots, but no progress has been made on allocation spectrum for 5G, or on developing strategies to encourage investment in the sector (2022)
domestic:
according to 2021 statistics from the Ministry of Telecommunications and Information Society, 50 percent of Ecuadorian homes do not have access to fixed internet; fixed-line teledensity is about 10 per 100 persons; mobile-cellular service with a subscribership of nearly 94 per 100 persons (2021)
international:
country code - 593; landing points for the SPSC (Mistral Submarine Cable), Panamerican Cable System (PAN-AM), Pacific Caribbean Cable System (PCCS), America Movil-Telxius West Coast Cable and SAm-1 submarine (SAm-1) cables that provide links to South and Central America, and extending onward to the Caribbean and the US; satellite earth station - 1 Intelsat (Atlantic Ocean) (2019)
Broadcast media:
the Communication Council, an official entity, carried out a media registry in Ecuador in December 2020. It registered 956 media outlets, 89% are private, 5% are public and 6% belong to small communities. The government controls most of the 44 public media, this includes national media and multiple local radio stations. In addition, of the 956 registered media, 58% are radio and 18% print. Two provinces have the largest number of media outlets: Guayas has 172 media outlets and Pichincha has 130 media outlets. (2020) so also sent to the National Assembly a new regulation proposal that is still under discussion.
(2022)
Internet country code:
.ec
Internet users:
total:
13.68 million (2021 est.)
percent of population:
76% (2021 est.)
according to 2021 statistics from Ecuador’s Ministry of Telecommunications and Information Society, 50% of homes do not have access to fixed internet
comparison ranking:
total 51
Broadband - fixed subscriptions:
total:
2,371,297 (2020 est.)
subscriptions per 100 inhabitants:
13 (2020 est.)
comparison ranking:
total 55','f1b1806014ddf77f98ef045415962683fbae76212665984e172f6141d626edae','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7a5265a67b4307f5f0e079751942bd66b963de5930f5de2795952ebc344db756',2025,'EG','Egypt','communications',20,'Telephones - fixed lines:
total subscriptions:
11,030,900 (2021 est.)
subscriptions per 100 inhabitants:
10 (2021 est.)
comparison ranking:
total subscriptions 18
Telephones - mobile cellular:
total subscriptions:
103,449,427 (2021 est.)
subscriptions per 100 inhabitants:
95 (2021 est.)
comparison ranking:
total subscriptions 17
Telecommunication systems:
general assessment:
Egypt’s large telecom market is supported by a population of about 109 million and benefits from effective competition in most sectors; a liberal regulatory regime allows for unified licenses which permit operators to offer fixed-line as well as mobile services; in recent years the government has developed a number of digital migration projects aimed at increasing average broadband speeds, delivering fiber broadband to about 60% of the population, developing an in-house satellite program, and creating a knowledge-based economy through the greater adoption of ICTs; the New Administrative Capital being built is only one of more than a dozen smart city projects, which together are stimulating investment in 5G and fiber broadband, as well as the adoption of IoT and AI solutions; the country endeavors to be a significant ICT hub in the North Africa and Middle East regions; Egypt’s mature mobile market has one of the highest subscription rates in Africa; progress in the adoption of mobile data services has been hampered by the lack of sufficient spectrum; the regulator in September 2020 made available 60MHz in the 2.6GHz band, though the spectrum was not allocated until late 2021; the additional spectrum will go far to enabling the MNOs to improve the quality of mobile broadband services offered; further 5G trials are to be held later in 2022, focused on the New Administrative Capital; the international cable infrastructure remains an important asset for Egypt, which benefits from its geographical position; Telecom Egypt has become one of the largest concerns in this segment, being a participating member in numerous cable systems; in mid-2021 the telco announced plans to build the Hybrid African Ring Path system, connecting a number of landlocked countries in Africa with Italy, France, and Portugal; the system will partly use the company’s existing terrestrial and sub sea cable networks (2022)
domestic:
fixed-line roughly 10 per 100, mobile-cellular 95 per 100 (2021)
international:
country code - 20; landing points for Aletar, Africa-1, FEA, Hawk, IMEWE, and the SEA-ME-WE-3 & 4 submarine cable networks linking to Asia, Africa, the Middle East, and Australia ; satellite earth stations - 4 (2 Intelsat - Atlantic Ocean and Indian Ocean, 1 Arabsat, and 1 Inmarsat); tropospheric scatter to Sudan; microwave radio relay to Israel; a participant in Medarabtel (2019)
Broadcast media:
mix of state-run and private broadcast media; state-run TV operates 2 national and 6 regional terrestrial networks, as well as a few satellite channels; dozens of private satellite channels and a large number of Arabic satellite channels are available for free; some limited satellite services are also available via subscription; state-run radio operates about 30 stations belonging to 8 networks; privately-owned radio includes 8 major stations, 4 of which belong to 1 network (2019)
Internet country code:
.eg
Internet users:
total:
79.2 million (2021 est.)
percent of population:
72% (2021 est.)
comparison ranking:
total 10
Broadband - fixed subscriptions:
total:
9,349,469 (2020 est.)
subscriptions per 100 inhabitants:
9 (2020 est.)
comparison ranking:
total 22
Communications - note:
one of the largest and most famous libraries in the ancient world was the Great Library of Alexandria in Egypt (founded about 295 B.C., it may have survived in some form into the 5th century A.D.); seeking to resurrect the great center of learning and communication, the Egyptian Government in 2002 inaugurated the Bibliotheca Alexandrina, an Egyptian National Library on the site of the original Great Library, which commemorates the original archive and also serves as a center of cultural and scientific excellence','cb6386de8431934b69436bd7ebb01b647a7f0fb97badc3913f2531807341c3d1','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f29bd953e4fbba9f2097d029f6c2e887f522e57efaf309022e2b5517ba2f1a9b',2025,'SV','El Salvador','communications',33,'Telephones - fixed lines:
total subscriptions:
856,090 (2021 est.)
subscriptions per 100 inhabitants:
14 (2021 est.)
comparison ranking:
total subscriptions 74
Telephones - mobile cellular:
total subscriptions:
11,071,073 (2021 est.)
subscriptions per 100 inhabitants:
175 (2021 est.)
comparison ranking:
total subscriptions 87
Telecommunication systems:
general assessment:
El Salvador is the smallest country in central America geographically, it has the fourth largest economy in the region; the country’s telecom sector has been restricted by poor infrastructure and unequal income distribution; there have been organizational delays which have slowed the development of telecom services; El Salvador’s fixed-line teledensity is substantially lower than the Latin American and Caribbean average; there has been a significant drop in the number of fixed lines since 2010, particularly in 2017, largely due to the substitution for mobile-only alternatives; about 94% of all telephony lines in the country are on mobile networks; mobile subscriptions are remarkably high considering El Salvador’s economic indicators, being about a third higher than average for Latin America and the Caribbean; the country was one of the last in the region to provide LTE services, mainly due to the inadequate provision of suitable spectrum; the multi-spectrum auction conducted at the end of 2019 has allowed MNOs to improve the reach and quality of their service offerings; El Salvador’s telecom legislation is one of the more liberal in Latin America, encouraging competition in most areas and permitting foreign investment; there are no regulations which promote wholesale broadband; the only effective cross-platform competition in the broadband market comes from the few cable operators; there has been some market consolidation in recent years (2021)
domestic:
fixed-line services, roughly 14 per 100, mobile-cellular competition now at 175 subscribers per 100 inhabitants (2021)
international:
country code - 503; satellite earth station - 1 Intelsat (Atlantic Ocean); connected to Central American Microwave System (2019)
Broadcast media:
multiple privately owned national terrestrial TV networks, supplemented by cable TV networks that carry international channels; hundreds of commercial radio broadcast stations and two known government-owned radio broadcast station; transition to digital transmission to begin in 2018 along with adaptation of the Japanese-Brazilian Digital Standard (ISDB- T) (2022)
Internet country code:
.sv
Internet users:
total:
3.969 million (2021 est.)
percent of population:
63% (2021 est.)
comparison ranking:
total 109
Broadband - fixed subscriptions:
total:
586,000 (2020 est.)
subscriptions per 100 inhabitants:
9 (2020 est.)
comparison ranking:
total 87','74de8a403580caf24c6395d6d9c7ea75571d467907eff12128ef08961982715e','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('dfa23b14766a38b579990e36a0b4bfe894ebc09ac0ad7b44c51171486e7f8b77',2025,'GQ','Equatorial Guinea','communications',45,'Telephones - fixed lines:
total subscriptions:
11,000 (2021 est.)
subscriptions per 100 inhabitants:
(2021 est.) less than 1
comparison ranking:
total subscriptions 189
Telephones - mobile cellular:
total subscriptions:
650,000 (2021 est.)
subscriptions per 100 inhabitants:
39 (2021 est.)
comparison ranking:
total subscriptions 170
Telecommunication systems:
general assessment:
the telecom service is forecasted to register a growth of more than 6% during the period of 2022-2026; mobile data is the largest contributor to total service revenue in 2021, followed by mobile voice, fixed broadband, mobile messaging, and fixed voice; the launch of the international submarine cable ACE, which connects 13 West African countries with Europe, will improve international capacity, bringing opportunities to data center providers; 4G network expansion and 4G service promotion will allow consumers and businesses to leverage 4G services (2022)
domestic:
fixed-line density is less than 1 per 100 persons and mobile-cellular subscribership is roughly 39 per 100 (2021)
international:
country code - 240; landing points for the ACE, Ceiba-1, and Ceiba-2 submarine cables providing communication from Bata and Malabo, Equatorial Guinea to numerous Western African and European countries; satellite earth station - 1 Intelsat (Indian Ocean) (2019)
Broadcast media:
the state maintains control of broadcast media with domestic broadcast media limited to 1 state-owned TV station, 1 private TV station owned by the president’s eldest son (who is the Vice President), 1 state-owned radio station, and 1 private radio station owned by the president’s eldest son; satellite TV service is available; transmissions of multiple international broadcasters are generally accessible (2019)
Internet country code:
.gq
Internet users:
total:
864,000 (2021 est.)
percent of population:
54% (2021 est.)
comparison ranking:
total 152
Broadband - fixed subscriptions:
total:
1,000 (2020 est.)
subscriptions per 100 inhabitants:
0.1 (2020 est.)
comparison ranking:
total 202','06ab2d7406b3ebbc148dc32597fe0691343db65098386d14b759d4f3c78bbfab','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a5f528a41ae37461cf34c397ddc2949b561624a8125d46a0a0b0bf02ea546600',2025,'ER','Eritrea','communications',56,'Telephones - fixed lines:
total subscriptions:
66,000 (2021 est.)
subscriptions per 100 inhabitants:
2 (2021 est.)
comparison ranking:
total subscriptions 147
Telephones - mobile cellular:
total subscriptions:
1.8 million (2021 est.)
subscriptions per 100 inhabitants:
50 (2021 est.)
comparison ranking:
total subscriptions 156
Telecommunication systems:
general assessment:
Eritrea’s telecom sector operates under a state-owned monopoly for fixed and mobile services; as a result of such restrictions on competition, the country has the least developed telecommunications market in Africa; mobile penetration stands at only about 20%, while fixed-line internet use barely registers; this is exacerbated by the very low use of computers, with only about 4% of households having a computer, and most of these being in the capital, Asmara; the 3G network continues to rollout which provides basic internet access to the majority of Eritreans; investment in telecom infrastructure is still required to improve the quality of services; the government has embarked on a work program to do exactly that, specifically aimed at extending services to remote areas, improving the quality of services, and ensuring that more telecoms infrastructure is supported by solar power to compensate for the poor state of the electricity network (2022)
domestic:
fixed-line subscribership is less than 2 per 100 persons and mobile-cellular is just over 50 per 100 (2021)
international:
country code - 291 (2019)
Broadcast media:
government controls broadcast media with private ownership prohibited; 1 state-owned TV station; 2 state-owned radio networks; purchases of satellite dishes and subscriptions to international broadcast media are permitted (2023)
Internet country code:
.er
Internet users:
total:
792,000 (2021 est.)
percent of population:
22% (2021 est.)
comparison ranking:
total 156
Broadband - fixed subscriptions:
total:
5,000 (2020 est.)
subscriptions per 100 inhabitants:
0.1 (2020 est.)
comparison ranking:
total 189','541f056c882c6bcdd0599ea534e9b8e13aeb87a98bf07dbbddfd0dd7cea449fd','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('38159893ccbd52abf80a7c6d3fa94a8038b54e71fe0241a265b4350d68356dea',2025,'EE','Estonia','communications',8,'Telephones - fixed lines:
total subscriptions:
296,620 (2021 est.)
subscriptions per 100 inhabitants:
22 (2021 est.)
comparison ranking:
total subscriptions 111
Telephones - mobile cellular:
total subscriptions:
1,980,838 (2021 est.)
subscriptions per 100 inhabitants:
149 (2021 est.)
comparison ranking:
total subscriptions 150
Telecommunication systems:
general assessment:
the competitive telecom market continues to progress with a range of regulatory measures which have enabled alternative operators to chip away at the fixed-line market share; fixed-line infrastructure upgrades have been focused on fiber, and the legacy DSL network has gradually been replaced; limited commercial 5G deployments have been made though an expansion of service availability awaits the delayed auction of spectrum in the 3.5GHz band, which is expected to be held later in 2021 (2021)
domestic:
22 per 100 for fixed-line subscribership and approximately 149 per 100 for mobile-cellular (2021)
international:
country code - 372; landing points for the EE-S-1, EESF-3, Baltic Sea Submarine Cable, FEC and EESF-2 fiber-optic submarine cables to other Estonia points, Finland, and Sweden; 2 international switches are located in Tallinn (2019)
Broadcast media:
the publicly owned broadcaster, Eesti Rahvusringhaaling (ERR), operates 3 TV channels and 5 radio networks; growing number of private commercial radio stations broadcasting nationally, regionally, and locally; fully transitioned to digital television in 2010; national private TV channels expanding service; a range of channels are aimed at Russian-speaking viewers; in 2016, there were 42 on-demand services available in Estonia, including 19 pay TVOD and SVOD services; roughly 85% of households accessed digital television services
Internet country code:
.ee
Internet users:
total:
1.183 million (2021 est.)
percent of population:
91% (2021 est.)
comparison ranking:
total 147
Broadband - fixed subscriptions:
total:
415,610 (2020 est.)
subscriptions per 100 inhabitants:
31 (2020 est.)
comparison ranking:
total 96','e309283ccaec9f904338ca3b7970f10f0d9c93873136b0c465f5159297d95ba5','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5e2d4f2a1e9969235673a49f9e902098e5b80974d5b48d72e27cd205ef94ec48',2025,'SZ','Eswatini','communications',19,'Telephones - fixed lines:
total subscriptions:
46,000 (2021 est.)
subscriptions per 100 inhabitants:
4 (2021 est.)
comparison ranking:
total subscriptions 159
Telephones - mobile cellular:
total subscriptions:
1.4 million (2021 est.)
subscriptions per 100 inhabitants:
120 (2021 est.)
comparison ranking:
total subscriptions 160
Telecommunication systems:
general assessment:
Eswatini was one of the last countries in the world to open up its telecom market to competition; until 2011 the state-owned Eswatini Posts and Telecommunications also acted as the industry regulator and had a stake in the country’s sole mobile network; a new independent regulatory authority was established in late 2013 and has since embarked on significant changes to the sector; mobile market subscriptions have been affected by the common use among subscribers when they use SIM cards from different networks in order to access cheaper on-net calls; subscriber growth has slowed in recent years, but was expected to have reached 8% in 2021, as people adapted to the changing needs for connectivity caused by the pandemic; the internet sector has been open to competition with a small number of licensed ISPs; DSL services were introduced in 2008, development of the sector has been hampered by the limited fixed-line infrastructure and by a lack of competition in the access and backbone networks; Eswatini is landlocked and so depends on neighboring countries for international bandwidth; this has meant that access pricing is relatively high, and market subscriptions remains relatively low; prices have fallen recently in line with greater bandwidth availability resulting from several new submarine cable systems which have reached the region in recent years; in September 2020 a terrestrial cable linked Mozambique with Eswatini and South Africa (2022)
domestic:
fixed-line stands at nearly 4 per 100 and mobile-cellular teledensity roughly 120 telephones per 100 persons (2021)
international:
country code - 268; satellite earth station - 1 Intelsat (Atlantic Ocean)
Broadcast media:
1 state-owned TV station; satellite dishes are able to access South African providers; state-owned radio network with 3 channels; 1 private radio station (2019)
Internet country code:
.sz
Internet users:
total:
708,000 (2021 est.)
percent of population:
59% (2021 est.)
comparison ranking:
total 160
Broadband - fixed subscriptions:
total:
12,000 (2020 est.)
subscriptions per 100 inhabitants:
1 (2020 est.)
comparison ranking:
total 178','1c534fa978fb069df300e9f0d3f4d3df88169fc1290a85c8278a3d5c0cf47e84','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b35c385966e58231a12226e6c962549e883901671667564a9c1efa9cffed479e',2025,'ET','Ethiopia','communications',30,'Telephones - fixed lines:
total subscriptions:
890,000 (2021 est.)
subscriptions per 100 inhabitants:
(2021 est.) less than 1
comparison ranking:
total subscriptions 72
Telephones - mobile cellular:
total subscriptions:
65 million (2021 est.)
subscriptions per 100 inhabitants:
54 (2021 est.)
comparison ranking:
total subscriptions 27
Telecommunication systems:
general assessment:
Ethio telecom is the major provider, but no longer has a complete monopoly on all telecom services; the World Bank in early 2021 provided a $200 million loan to help develop the country’s digital transformation, while the government has embarked on its 2020-2030 program as well as its Digital Ethiopia 2025 strategy, both aimed at making better use of digital technologies to promote socioeconomic development (2023)
domestic:
fixed-line subscriptions less than 1 per 100 while mobile-cellular stands at a little over 54 per 100 people (2021)
international:
country code - 251; open-wire to Sudan and Djibouti; microwave radio relay to Kenya and Djibouti; 2 domestic satellites provide the national trunk service; satellite earth stations - 3 Intelsat (1 Atlantic Ocean and 2 Pacific Ocean) (2016)
Broadcast media:
6 public TV stations broadcasting nationally and 10 public radio broadcasters; 7 private radio stations and 19 community radio stations (2017)
Internet country code:
.et
Internet users:
total:
20.4 million (2021 est.)
percent of population:
17% (2021 est.)
comparison ranking:
total 43
Broadband - fixed subscriptions:
total:
212,000 (2020 est.)
subscriptions per 100 inhabitants:
0.2 (2020 est.)
comparison ranking:
total 118','5d2de270a3de916cc4e31c6aa63a8f361069fd135eea57102dabd409b2bfb36d','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4eb23b3a30015f8458dedb022a73b90982e4a4276d2bbb2967157bf853d59052',2025,'ET','Ethiopia','communications',43,'Telephones - fixed lines:
total subscriptions: 160,149,025 (2020 est.)
subscriptions per 100 inhabitants:
36 (2020 est.)
Telephones - mobile cellular:
total subscriptions: 540,557,924 (2020 est.)
subscriptions per 100 inhabitants:
121 (2020 est.)
Telecommunication systems:
note - see individual country entries of member states
Internet country code:
.eu; note - see country entries of member states for individual country codes
Internet users:
total:
389,063,826 (2021 est.)
percent of population:
87% (2021 est.)
Broadband - fixed subscriptions:
total:
163,772,540 (2020 est.)
subscriptions per 100 inhabitants:
37 (2020 est.)','fdfa93cd774ef1bd9389ff25645ed2fcac4ac8ec69a5c62fbc5139e3b29220a7','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ec34f60887a5d9295326fc481144e4937e0fe131573d36ae13cdb55197898ad9',2025,'FO','Faroe Islands','communications',9,'Telephones - fixed lines:
total subscriptions:
15,000 (2021 est.)
subscriptions per 100 inhabitants:
29 (2021 est.)
comparison ranking:
total subscriptions 181
Telephones - mobile cellular:
total subscriptions:
59,000 (2021 est.)
subscriptions per 100 inhabitants:
110 (2021 est.)
comparison ranking:
total subscriptions 204
Telecommunication systems:
general assessment:
the Faroe Islands have a highly developed communication network, which covers the whole country; from telecommunication and mobile phones to the internet and media, the Faroe Islands are at the forefront of modern communications technology; working within the special geographic circumstances of the Faroe Islands; companies have become world experts in providing digital communication solutions to remote and sparsely populated areas (2022)
domestic:
29 per 100 teledensity for fixed-line and nearly 110 per 100 for mobile-cellular (2021)
international:
country code - 298; landing points for the SHEFA-2, FARICE-1, and CANTAT-3 fiber-optic submarine cables from the Faroe Islands, to Denmark, Germany, UK and Iceland; satellite earth stations - 1 Orion; (2019)
Broadcast media:
1 publicly owned TV station; the Faroese telecommunications company distributes local and international channels through its digital terrestrial network; publicly owned radio station supplemented by 3 privately owned stations broadcasting over multiple frequencies
Internet country code:
.fo
Internet users:
total:
51,728 (2021 est.)
percent of population:
97.6% (2021 est.)
comparison ranking:
total 201
Broadband - fixed subscriptions:
total:
18,443 (2020 est.)
subscriptions per 100 inhabitants:
38 (2020 est.)
comparison ranking:
total 169','a4f2dbfcfbc83ca89b7395acce2bbaf216c490767452fc31b29aecd82b8b78b8','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f7b6e2c51f9d7adbc7b6d0b8aa932252f8f7928ab4830c14e1919abaea444abe',2025,'FJ','Fiji','communications',20,'Telephones - fixed lines:
total subscriptions:
49,000 (2021 est.)
subscriptions per 100 inhabitants:
5 (2021 est.)
comparison ranking:
total subscriptions 157
Telephones - mobile cellular:
total subscriptions:
990,000 (2021 est.)
subscriptions per 100 inhabitants:
110 (2021 est.)
comparison ranking:
total subscriptions 163
Telecommunication systems:
general assessment:
Fiji is the leading market to watch in terms of both LTE and 5G development in the region; the market boasts relatively sophisticated, advanced digital infrastructure, with telcos’ heavy investment resulting in the country having the highest mobile and internet subscriptions in the Pacific Islands region; LTE, LTE-A, and fiber technologies have received the most investment by the Fijian mobile operators, LTE now accounts for the largest share of connections in the mobile segment; concentrating on the more highly populated areas, the operators are preparing for the next growth area of high-speed data; they also have 5G in mind, and are preparing their networks to be 5G-ready, anticipating an easier migration to the technology based on the relatively high LTE subscription rate; Fiji presents a challenging geographic environment for infrastructure development due to its population being spread across more than 100 islands; the majority of Fijians live on the two main islands of Viti Levu and Vanua Levu; in July 2018, the two islands were linked by the Savusavu submarine cable system, which provides a more secure link in times of emergency weather events such as the regular tropical cyclones that often cause massive destruction to the area, including destroying essential infrastructure such as electricity and telecommunications equipment; notably, the December 2021 eruption of the Hunga Tonga–Hunga Ha’apai submarine volcano in Tonga damaged the Tonga Cable which connects Fiji, and Tonga blocking the latter off from internet services; cable theft and damage of critical communications infrastructure has also become a concern in Fiji, prompting authorities to establish a joint task force to tackle the issue (2022)
domestic:
fixed-line nearly 5 per 100 persons and mobile-cellular teledensity roughly 110 per 100 persons (2021)
international:
country code - 679; landing points for the ICN1, SCCN, Southern Cross NEXT, Tonga Cable and Tui-Samoa submarine cable links to US, NZ, Australia and Pacific islands of Fiji, Vanuatu, Kiribati, Samoa, Tokelau, Tonga, Fallis & Futuna, and American Samoa; satellite earth stations - 2 Inmarsat (Pacific Ocean) (2019)
Broadcast media:
Fiji TV, a publicly traded company, operates a free-to-air channel; Digicel Fiji operates the Sky Fiji and Sky Pacific multi-channel pay-TV services; state-owned commercial company, Fiji Broadcasting Corporation, Ltd, operates 6 radio stations - 2 public broadcasters and 4 commercial broadcasters with multiple repeaters; 5 radio stations with repeaters operated by Communications Fiji, Ltd; transmissions of multiple international broadcasters are available
Internet country code:
.fj
Internet users:
total:
809,600 (2021 est.)
percent of population:
88% (2021 est.)
comparison ranking:
total 155
Broadband - fixed subscriptions:
total:
23,062 (2020 est.)
subscriptions per 100 inhabitants:
3 (2020 est.)
comparison ranking:
total 162','86035617547096dce0e51ec51bcb19b16a22bffafe41b1276c20fe4a5e8b3cfa','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('90a1064d6e1b9189a29f4ade5ba711a131acb956708c457d8dfb4cc76bc7e249',2025,'FI','Finland','communications',31,'Telephones - fixed lines:
total subscriptions:
207,000 (2021 est.)
subscriptions per 100 inhabitants:
4 (2021 est.)
comparison ranking:
total subscriptions 120
Telephones - mobile cellular:
total subscriptions:
7.15 million (2021 est.)
subscriptions per 100 inhabitants:
129 (2021 est.)
comparison ranking:
total subscriptions 109
Telecommunication systems:
general assessment:
Finland’s telecom market is among the more progressive in Europe, with operators having been at the forefront in deploying technologies and with the regulator being among the first to auction spectrum for 5G use; these efforts have been supported by the government which is working towards its target of providing a broadband service of at least 100Mb/s by 2025; 5G services were available to more than 40% of the population by early 2021, and take-up among subscribers has been strong although most will remain with LTE in the short term; the country enjoys one of the highest broadband and mobile subscription rates in the region, with customers able to make use of the latest iterations of technologies including DOCSIS3.1, LTE-A, 5G, and GPON fiber infrastructure; Finland has emerged as one of the pioneers in 5G; the auction of spectrum in the 700MHz and 3.5GHh bands has enabled network operators to extend the availability of LTE services nationally and to prepare for 5G services; Spectrum in the 2.5GHz band was auctioned in mid-2020 and has since enabled the MNOs to widen their 5G footprint considerably; there is an ongoing shift away from DSL to fiber and mobile networks (2021)
domestic:
fixed-line 4 per 100 subscriptions and nearly 129 per 100 mobile-cellular (2021)
international:
country code - 358; landing points for Botnia, BCS North-1 & 2, SFL, SFS-4, C-Lion1, Eastern Lights, Baltic Sea Submarine Cable, FEC, and EESF-2 & 3 submarine cables that provide links to many Finland points, Estonia, Sweden, Germany, and Russia; satellite earth stations - access to Intelsat transmission service via a Swedish satellite earth station, 1 Inmarsat (Atlantic and Indian Ocean regions); note - Finland shares the Inmarsat earth station with the other Nordic countries (Denmark, Iceland, Norway, and Sweden) (2019)
Broadcast media:
a mix of 3 publicly operated TV stations and numerous privately owned TV stations; several free and special-interest pay-TV channels; cable and satellite multi-channel subscription services are available; all TV signals are broadcast digitally; Internet television, such as Netflix and others, is available; public broadcasting maintains a network of 13 national and 25 regional radio stations; a large number of private radio broadcasters and access to Internet radio
Internet country code:
.fi
note - Aland Islands assigned .ax
Internet users:
total:
5.115 million (2021 est.)
percent of population:
93% (2021 est.)
comparison ranking:
total 91
Broadband - fixed subscriptions:
total:
1.846 million (2020 est.)
subscriptions per 100 inhabitants:
33 (2020 est.)
comparison ranking:
total 59','a68486b4ba4bd313c796eabca8aa266fe172671fb16d5f0256357f2829c40b98','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('06287eedaa59e0598665466227a8c3ba6cce976f87ce380a85e4632e0036c968',2025,'FR','France','communications',42,'Telephones - fixed lines:
total subscriptions:
38 million (2021 est.)
subscriptions per 100 inhabitants:
59 (2021 est.)
comparison ranking:
total subscriptions 5
Telephones - mobile cellular:
total subscriptions:
73 million (2021 est.)
subscriptions per 100 inhabitants:
110 (2021 est.)
comparison ranking:
total subscriptions 23
Telecommunication systems:
general assessment:
France’s telecom market is one of the largest in Europe; there is a multi-year Engage 2025 plan which is focused on growth in the developing markets, and on the greater use of artificial intelligence and data; there are many MVNOs in the market; LTE networks provide near universal coverage, and carry about 95% of mobile data traffic; operators have launched 5G services, and these have been supported by the late-2020 auction of spectrum in the 3.5GHz range; France’s fixed broadband market is increasingly focused on fiber, which accounted for 71% of all fixed lines at the beginning of 2021; growth in the fiber sector has been stimulated by households securing faster data packages during the pandemic; the number of DSL lines has fallen sharply as customers migrate to fiber infrastructure (2021)
domestic:
nearly 59 per 100 persons for fixed-line and over 110 per 100 for mobile-cellular subscriptions (2021)
international:
country code - 33; landing points for Circe South, TAT-14, INGRID, FLAG Atlantic-1, Apollo, HUGO, IFC-1, ACE, SeaMeWe-3 & 4, Dunant, Africa-1, AAE-1, Atlas Offshore, Hawk, IMEWE, Med Cable, PEACE Cable, and TE North/TGN-Eurasia/SEACOM/Alexandros/Medex submarine cables providing links throughout Europe, Asia, Australia, the Middle East, Southeast Asia, Africa and US; satellite earth stations - more than 3 (2 Intelsat (with total of 5 antennas - 2 for Indian Ocean and 3 for Atlantic Ocean), NA Eutelsat, 1 Inmarsat - Atlantic Ocean region); HF radiotelephone communications with more than 20 countries (2019)
overseas departments: country codes:
French Guiana - 594; landing points for Ella Link, Kanawa, Americas II to South America, Europe, Caribbean and US; Guadeloupe - 590; landing points for GCN, Southern Caribbean Fiber, and ECFS around the Caribbean and US; Martinique - 596; landing points for Americas II, ECFS, and Southern Caribbean Fiber to South America, US and around the Caribbean; Mayotte - 262; landing points for FLY-LION3 and LION2 to East Africa and East African Islands in Indian Ocean; Reunion - 262; landing points for SAFE, METISS, and LION submarine cables to Asia, South and East Africa, Southeast Asia and nearby Indian Ocean Island countries of Mauritius, and Madagascar (2019)
Broadcast media:
a mix of both publicly operated and privately owned TV stations; state-owned France television stations operate 4 networks, one of which is a network of regional stations, and has part-interest in several thematic cable/satellite channels and international channels; a large number of privately owned regional and local TV stations; multi-channel satellite and cable services provide a large number of channels; public broadcaster Radio France operates 7 national networks, a series of regional networks, and operates services for overseas territories and foreign audiences; Radio France Internationale, under the Ministry of Foreign Affairs, is a leading international broadcaster; a large number of commercial FM stations, with many of them consolidating into commercial networks
Internet country code:
metropolitan France - .fr; French Guiana - .gf; Guadeloupe - .gp; Martinique - .mq; Mayotte - .yt; Reunion - .re
Internet users:
total:
55.9 million (2021 est.)
percent of population:
86% (2021 est.)
comparison ranking:
total 19
Broadband - fixed subscriptions:
total:
30.627 million (2020 est.)
subscriptions per 100 inhabitants:
47 (2020 est.)
comparison ranking:
total 7','5d0d3179d3878c46bd8694ce1bbdf8fc729048bbd906e9f52012f5f3db013bfe','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('75f64fed14d19cdb48d9f71a90d91a6db463a8db2d6671a5087ab18f159063e8',2025,'PF','French Polynesia','communications',55,'Telephones - fixed lines:
total subscriptions:
108,051 (2021 est.)
subscriptions per 100 inhabitants:
36 (2021 est.)
comparison ranking:
total subscriptions 136
Telephones - mobile cellular:
total subscriptions:
322,918 (2021 est.)
subscriptions per 100 inhabitants:
106 (2021 est.)
comparison ranking:
total subscriptions 178
Telecommunication systems:
general assessment:
French Polynesia has one of the most advanced telecoms infrastructures in the Pacific Islands region; the remoteness of the country with its scattering of 130 islands and atolls has made connectivity vital for its inhabitants; the first submarine cable was deployed in 2010 and since then additional cables have been connected to the islands, vastly improving French Polynesia’s international connectivity; an additional domestic submarine cable, the Natitua Sud, will connect more remote islands by the end of 2022; French Polynesia is also a hub for satellite communications in the region; a considerable number of consumers access FttP-based services; with the first data center in French Polynesia on the cards, the quality and price of broadband services is expected to improve as content will be able to be cached locally, reducing costs for consumers; for 2022, fixed broadband subscriptions reached an estimated 22%; about 43% of the country’s mobile connections are on 3G networks, while LTE accounts for 12%; by 2025, LTE is expected to account for more than half of all connections; it is also estimated that 77% of mobile subscribers will have smart phones by 2025 (2022)
domestic:
fixed-line subscriptions nearly 36 per 100 persons and mobile-cellular density is roughly 106 per 100 persons (2021)
international:
country code - 689; landing points for the NATITUA, Manatua, and Honotua submarine cables to other French Polynesian Islands, Cook Islands, Niue, Samoa and US; satellite earth station - 1 Intelsat (Pacific Ocean) (2019)
Broadcast media:
French public overseas broadcaster Reseau Outre-Mer provides 2 TV channels and 1 radio station; 1 government-owned TV station; a small number of privately owned radio stations (2019)
Internet country code:
.pf
Internet users:
total:
218,100 (2021 est.)
percent of population:
72.7% (2021 est.)
comparison ranking:
total 180
Broadband - fixed subscriptions:
total:
64,000 (2020 est.)
subscriptions per 100 inhabitants:
23 (2020 est.)
comparison ranking:
total 138','06ec1a16d86d3ac4b867123589e1d1fa0c066229c5ebb88da552066edbc7bb93','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('92719bb5530195a8388062c5e066492a5708ab4577b8d7276ff380621d9521d9',2025,'PF','French Polynesia','communications',65,'Internet country code:
.tf
Communications - note:
has one or more meteorological stations on each possession','e2624e602c03d8f72793956e1e1cf05fb1261220e6c519acf13cca6c88891b2b','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d0e7dfbb062b32a3b2ad2cc5ac0ff2e710b8255ba3ca7a231cb63bbbbce2df55',2025,'GA','Gabon','communications',8,'Telephones - fixed lines:
total subscriptions:
31,708 (2021 est.)
subscriptions per 100 inhabitants:
1 (2021 est.)
comparison ranking:
total subscriptions 166
Telephones - mobile cellular:
total subscriptions:
3,144,609 (2021 est.)
subscriptions per 100 inhabitants:
134 (2021 est.)
comparison ranking:
total subscriptions 140
Telecommunication systems:
general assessment:
the telecom market was liberalized in 1999 when the government awarded three mobile telephony licenses and two ISP licenses and established an independent regulatory authority; in contrast with the mobile market, Gabon’s fixed-line and internet sectors have remained underdeveloped due to a lack of competition and high prices; the country has sufficient international bandwidth on the SAT-3/WASC/SAFE submarine cable; the arrival of the ACE submarine cable, combined with progressing work on the CAB cable, has increased back haul capacity supporting mobile data traffic (2022)
domestic:
fixed-line 1 per 100 subscriptions; mobile cellular subscriptions are 134 per 100 persons (2021)
international:
country code - 241; landing points for the SAT-3/WASC, ACE and Libreville-Port Gentil Cable fiber-optic submarine cable that provides connectivity to Europe and West Africa; satellite earth stations - 3 Intelsat (Atlantic Ocean) (2019)
Broadcast media:
state owns and operates 2 TV stations and 2 radio broadcast stations; a few private radio and TV stations; transmissions of at least 2 international broadcasters are accessible; satellite service subscriptions are available
Internet country code:
.ga
Internet users:
total:
1.656 million (2021 est.)
percent of population:
72% (2021 est.)
comparison ranking:
total 142
Broadband - fixed subscriptions:
total:
44,607 (2020 est.)
subscriptions per 100 inhabitants:
2 (2020 est.)
comparison ranking:
total 144','7f903ddaa365e0b754c4aaccca5d5b469ad52ae7fca7daf4be5cba577fd09f2d','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7f95947ebf34c42ae6f64262cb75126f7f7e65a7cc05e75336dfb053a464bb84',2025,'GA','Gabon','communications',20,'Telephones - fixed lines:
total subscriptions:
60,000 (2021 est.)
subscriptions per 100 inhabitants:
2 (2021 est.)
comparison ranking:
total subscriptions 149
Telephones - mobile cellular:
total subscriptions:
27 million (2021 est.)
subscriptions per 100 inhabitants:
100 (2021 est.)
comparison ranking:
total subscriptions 49
Telecommunication systems:
general assessment:
Gambia’s telecom market has five mobile networks providing effective competition; mobile subscriptions are well above the African average, itself a testament to the poor condition of the fixed-line infrastructure and the lack of availability of fixed services in many rural areas of the country; there are only four licensed ISPs, which are small networks serving local areas, and so competition is minimal; their limited services are complemented by the fixed-wireless offerings of three of the MNOs; the government has embarked on a National Broadband Network program aimed at closing the digital divide affecting many parts of the country; despite efforts to improve internet connectivity, the country ranks among the lowest globally in terms of digital readiness. (2022)
domestic:
fixed-line subscriptions are 2 per 100 and mobile-cellular teledensity nearly 110 per 100 persons (2021)
international:
country code - 220; landing point for the ACE submarine cable to West Africa and Europe; microwave radio relay links to Senegal and Guinea-Bissau; satellite earth station - 1 Intelsat (Atlantic Ocean) (2019)
Broadcast media:
1 state-run TV-channel; one privately-owned TV-station; 1 Online TV-station; three state-owned radio station and 31 privately owned radio stations; eight community radio stations; transmissions of multiple international broadcasters are available, some via shortwave radio; cable and satellite TV subscription services are obtainable in some parts of the country
(2019)
Internet country code:
.gm
Internet users:
total:
858,000 (2021 est.)
percent of population:
33% (2021 est.)
comparison ranking:
total 153
Broadband - fixed subscriptions:
total:
5,000 (2020 est.)
subscriptions per 100 inhabitants:
0.2 (2020 est.)
comparison ranking:
total 187','2ef1a466294222fd820c75da556495829496b8baac4f9991c249f709c1d4a2b8','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7b44c4ba8b44b6afd6ed660fd5417c47b32fbc1a6d0a52b555ea809dc34d01bb',2025,'GA','Gabon','communications',31,'Telephones - fixed lines:
total subscriptions:
485,829 (2021 est.)
subscriptions per 100 inhabitants:
9 (2021 est.)
includes the West Bank
comparison ranking:
total subscriptions 94
Telephones - mobile cellular:
total subscriptions:
4,052,966 (2021 est.)
subscriptions per 100 inhabitants:
78 (2021 est.)
includes the West Bank
comparison ranking:
total subscriptions 132
Telecommunication systems:
general assessment:
Israel, which controls Palestinian frequencies and telecom infrastructure, limits mobile internet speeds in the Palestinian territories to levels that are significantly lower than in Israel and Jewish West Bank settlements; the World Bank urged Israel to let Palestinian cellular companies set up more advanced networks, and to ease restrictions on the import of equipment needed to build and operate them; Israel is rolling out fifth generation technology for its citizens, while the West Bank operates on 3G and Gaza, 2G; Israeli mobile operators don’t officially service Palestinian areas, but many Palestinians use the faster Israeli networks with SIM cards; the Times of Israel reported in November that Israel tentatively agreed to let Palestinian operators launch 4G services
(2022)
domestic:
fixed-line 9 per 100 and mobile-cellular 28 per 100 (includes West Bank) (2021)
international:
country code 970 or 972 (2018)
Broadcast media:
1 TV station and about 10 radio stations; satellite TV accessible
Internet country code:
.ps; note - IANA has designated .ps for the Gaza Strip, same as the West Bank
Internet users:
total:
3,602,452 (2020 est.)
percent of population:
75% (2020 est.)
note:
includes the West Bank
comparison ranking:
total 113
Broadband - fixed subscriptions:
total:
376,911 (2020 est.)
subscriptions per 100 inhabitants:
7 (2020 est.)
note:
includes the West Bank
comparison ranking:
total 100','d048e2ccab89a7b55b93c4dbdf17715695c4e99051bdac7b243e3c1931ba3987','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f9fc0c253bf30363ff6e12c5f2f74e2f7e89c83256aee74c98b268e2687201e0',2025,'GE','Georgia','communications',43,'Telephones - fixed lines:
total subscriptions:
337,923 (2021 est.)
subscriptions per 100 inhabitants:
9 (2021 est.)
comparison ranking:
total subscriptions 106
Telephones - mobile cellular:
total subscriptions:
5,163,558 (2021 est.)
subscriptions per 100 inhabitants:
137 (2021 est.)
comparison ranking:
total subscriptions 123
Telecommunication systems:
general assessment:
the telecom sector has been attempting for many years to overcome the decades of under-investment in its fixed-line infrastructure during the Soviet era; concerted efforts to privatize state-owned enterprises and open up the telecom market have been mostly successful, with a large number of networks now competing in both the fixed-line and the mobile segments; more needs to be done, however, to give investors the confidence to enter a market that has barely moved in terms of revenue growth over the last decade, and where regulatory overreach has sometimes come perilously close to arresting further development; Georgia’s government moved fast following the collapse of the Soviet Union to liberalize the country’s telecom market; this resulted in a relatively high number of networks competing in the under-developed fixed-line segment as well as in the emerging mobile market; both segments remain dominated by just a few companies (2022)
domestic:
fixed-line subscriptions 9 per 100, mobile-cellular teledensity roughly 137 per 100 persons (2021)
international:
country code - 995; landing points for the Georgia-Russia, Diamond Link Global, and Caucasus Cable System fiber-optic submarine cable that provides connectivity to Russia, Romania and Bulgaria; international service is available by microwave, landline, and satellite through the Moscow switch; international electronic mail and telex service are available (2019)
Broadcast media:
The Tbilisi-based Georgian Public Broadcaster (GPB) includes Channel 1, Channel 2, and the Batumi-based Adjara TV, and the State Budget funds all three; there are also a number of independent commercial television broadcasters, such as Imedi, Rustavi 2, Pirveli TV, Maestro, Kavkasia, Georgian Dream Studios (GDS), Obiektivi, Mtavari Arkhi, and a small Russian language operator TOK TV; Tabula and Post TV are web-based television outlets; all of these broadcasters and web-based television outlets, except GDS, carry the news; the Georgian Orthodox Church also operates a satellite-based television station called Unanimity; there are 26 regional television broadcasters across Georgia that are members of the Georgian Association of Regional Broadcasters and/or the Alliance of Georgian Broadcasters; the broadcaster organizations seek to strengthen the regional media’s capacities and distribution of regional products: a nationwide digital switchover occurred in 2015; there are several dozen private radio stations; GPB operates 2 radio stations (2019)
Internet country code:
.ge
Internet users:
total:
2.888 million (2021 est.)
percent of population:
76% (2021 est.)
comparison ranking:
total 123
Broadband - fixed subscriptions:
total:
986,809 (2021 est.)
subscriptions per 100 inhabitants:
25 (2021 est.)
comparison ranking:
total 75','e37e92da75672912fb19ddf43386650af997736db7dee7d2994408ff2204bc12','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1c2cc9e80a8bd063edceda3ab14eb149832c6779911acae237e6363726b13dff',2025,'DE','Germany','communications',54,'Telephones - fixed lines:
total subscriptions:
38.6 million (2021 est.)
subscriptions per 100 inhabitants:
46 (2021 est.)
comparison ranking:
total subscriptions 4
Telephones - mobile cellular:
total subscriptions:
106.4 million (2021 est.)
subscriptions per 100 inhabitants:
128 (2021 est.)
comparison ranking:
total subscriptions 16
Telecommunication systems:
general assessment:
with one of Europe’s largest telecom markets, Germany hosts a number of significant operators which offer effective competition in the mobile and broadband sectors; the German mobile market is driven by mobile data, with the number of mobile broadband subscribers having increased rapidly in recent years; with LTE now effectively universally available, considerable progress has recently been made in building out 5G networks (2022)
domestic:
46 per 100 for fixed-line and 128 per 100 for mobile-cellular subscriptions (2021)
international:
country code - 49; landing points for SeaMeWe-3, TAT-14, AC-1, CONTACT-3, Fehmarn Balt, C-Lion1, GC1, GlobalConnect-KPN, and Germany-Denmark 2 & 3 - submarine cables to Europe, Africa, the Middle East, Asia, Southeast Asia and Australia; as well as earth stations in the Inmarsat, Intelsat, Eutelsat, and Intersputnik satellite systems (2019)
Broadcast media:
a mixture of publicly operated and privately owned TV and radio stations; 70 national and regional public broadcasters compete with nearly 400 privately owned national and regional TV stations; more than 90% of households have cable or satellite TV; hundreds of radio stations including multiple national radio networks, regional radio networks, and a large number of local radio stations
Internet country code:
.de
Internet users:
total:
75.53 million (2021 est.)
percent of population:
91% (2021 est.)
comparison ranking:
total 11
Broadband - fixed subscriptions:
total:
36,215,303 (2020 est.)
subscriptions per 100 inhabitants:
43 (2020 est.)
comparison ranking:
total 5','7e43e0f3c65dae25fa00a0113ad47977f2a5abc49e1f4f5e6f3a087867738a1c','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b96fea46b4dd667b6b3bb2b04f61a92515e4476e2b8b5643f6d3cf32bbb1bb41',2025,'GH','Ghana','communications',67,'Telephones - fixed lines:
total subscriptions:
315,271 (2021 est.)
subscriptions per 100 inhabitants:
1 (2021 est.)
comparison ranking:
total subscriptions 107
Telephones - mobile cellular:
total subscriptions:
40,454,073 (2021 est.)
subscriptions per 100 inhabitants:
123 (2021 est.)
comparison ranking:
total subscriptions 40
Telecommunication systems:
general assessment:
challenged by unreliable electricity and shortage of skilled labor, Ghana seeks to extend telecom services nationally; investment in fiber infrastructure and off-grid solutions provide data coverage to over 23 million people; launch of LTE has improved mobile data services, including m-commerce and banking; moderately competitive Internet market, most through mobile networks; international submarine cables, and terrestrial cables have improved Internet capacity; LTE services are widely available; the relatively high cost of 5G-compatible devices also inhibits most subscribers from migrating from 3G and LTE platforms (2022)
domestic:
fixed-line data less than 1 per 100 subscriptions; mobile-cellular subscriptions 123 per 100 persons (2021)
international:
country code - 233; landing points for the SAT-3/WASC, MainOne, ACE, WACS and GLO-1 fiber-optic submarine cables that provide connectivity to South and West Africa, and Europe; satellite earth stations - 4 Intelsat (Atlantic Ocean); microwave radio relay link to Panaftel system connects Ghana to its neighbors; GhanaSat-1 nanosatellite launched in 2017 (2017)
Broadcast media:
state-owned TV station, 2 state-owned radio networks; several privately owned TV stations and a large number of privately owned radio stations; transmissions of multiple international broadcasters are accessible; several cable and satellite TV subscription services are obtainable
Internet country code:
.gh
Internet users:
total:
22.44 million (2021 est.)
percent of population:
68% (2021 est.)
comparison ranking:
total 38
Broadband - fixed subscriptions:
total:
78,371 (2020 est.)
subscriptions per 100 inhabitants:
0.3 (2020 est.)
comparison ranking:
total 132','eaf9f440f3a2fe93cc5e50a49c1e4b8ef470b99dc10e83cd0f9726576247c7c3','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2fe9c902423348466c6678a5dbda9706d093595778782fd92566f210fe05fa2c',2025,'GI','Gibraltar','communications',8,'Telephones - fixed lines:
total subscriptions:
17,000 (2021 est.)
subscriptions per 100 inhabitants:
53 (2021 est.)
comparison ranking:
total subscriptions 177
Telephones - mobile cellular:
total subscriptions:
34,000 (2021 est.)
subscriptions per 100 inhabitants:
100 (2021 est.)
comparison ranking:
total subscriptions 211
Telecommunication systems:
general assessment:
Gibraltar’s population is urban-based, served by a digital telephone exchange supported by a fiber optic and copper infrastructure; near universal mobile and Internet use (2019)
domestic:
53 per 100 fixed-line and 100 per 100 mobile-cellular (2021)
international:
country code - 350; landing point for the EIG to Europe, Asia, Africa and the Middle East via submarine cables; radiotelephone; microwave radio relay; satellite earth station - 1 Intelsat (Atlantic Ocean) (2019)
Broadcast media:
Gibraltar Broadcasting Corporation (GBC) provides TV and radio broadcasting services via 1 TV station and 4 radio stations; British Forces Broadcasting Service (BFBS) operates 1 radio station; broadcasts from Spanish radio and TV stations are accessible
Internet country code:
.gi
Internet users:
total:
31,152 (2021 est.)
percent of population:
94.4% (2021 est.)
comparison ranking:
total 209
Broadband - fixed subscriptions:
total:
21,009 (2020 est.)
subscriptions per 100 inhabitants:
62 (2020 est.)
comparison ranking:
total 164','a67aa0f729fa33ef6de2b034a92d6fa20206a44a82005b90f5394225bc2386e5','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4fb64ce0bffbcf0ea5566051da5aa9bf3455ee3e38da302eb199dba874a54f4e',2025,'GR','Greece','communications',19,'Telephones - fixed lines:
total subscriptions:
4,913,036 (2021 est.)
subscriptions per 100 inhabitants:
47 (2021 est.)
comparison ranking:
total subscriptions 29
Telephones - mobile cellular:
total subscriptions:
11,494,008 (2021 est.)
subscriptions per 100 inhabitants:
110 (2021 est.)
comparison ranking:
total subscriptions 86
Telecommunication systems:
general assessment:
Greece’s telecom market is susceptible to the country’s volatile economy, and, as a result, revenue among the key networks has been variable; broadband subscriptions in Greece are developing steadily; the main networks are concentrating investment on fiber-based next generation networks, enabling them to reach the European broadband targets for 2025; their work is also supported by government ultra-fast broadband projects, largely funded by the EC and aimed at delivering a service of at least 100Mb/s to under served areas; Greece’s well-developed mobile market is dominated by the three MNOs; Networks continue to invest in LTE infrastructure and technologies to provide networks capable of meeting customer demand for data services; after extensive trials of 5G, the MNOs were able to launch commercial services in early 2021 following the December 2020 allocation of frequencies in a range of bands; the rapid rollout of 5G encouraged the shut down of the 3G network (a process expected to be completed by the end of 2021) and reallocate for LTE and 5G. (2023)
domestic:
47 per 100 subscribers for fixed-line and 110 per 100 for mobile-cellular (2021)
international:
country code - 30; landing points for the SEA-ME-WE-3, Adria-1, Italy-Greece 1, OTEGLOBE, MedNautilus Submarine System, Aphrodite 2, AAE-1 and Silphium optical telecommunications submarine cable that provides links to Europe, the Middle East, Africa, Southeast Asia, Asia and Australia; tropospheric scatter; satellite earth stations - 4 (2 Intelsat - 1 Atlantic Ocean and 1 Indian Ocean, 1 Eutelsat, and 1 Inmarsat - Indian Ocean region) (2019)
Broadcast media:
broadcast media dominated by the private sector; roughly 150 private TV channels, about 10 of which broadcast nationwide; 1 government-owned terrestrial TV channel with national coverage; 3 privately owned satellite channels; multi-channel satellite and cable TV services available; upwards of 1,500 radio stations, all of them privately owned; government-owned broadcaster has 2 national radio stations
Internet country code:
.gr
Internet users:
total:
7.8 million (2021 est.)
percent of population:
78% (2021 est.)
comparison ranking:
total 77
Broadband - fixed subscriptions:
total:
4,257,026 (2020 est.)
subscriptions per 100 inhabitants:
41 (2020 est.)
comparison ranking:
total 35','d1a6d79f0159c1a0726b069f9fbc0a664b3c7b98d86c6e6e2eaf716fee3f2334','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c54c7d419cf203499b6ad1600eba7ac29362c30e380cd8311c20bbbde0ebb71c',2025,'GL','Greenland','communications',32,'Telephones - fixed lines:
total subscriptions:
6,352 (2020 est.)
subscriptions per 100 inhabitants:
11 (2020 est.)
comparison ranking:
total subscriptions 200
Telephones - mobile cellular:
total subscriptions:
66,605 (2021 est.)
subscriptions per 100 inhabitants:
118 (2021 est.)
comparison ranking:
total subscriptions 201
Telecommunication systems:
general assessment:
adequate domestic and international service provided by satellite, cables, and microwave radio relay; the fundamental telecommunications infrastructure consists of a digital radio link from Nanortalik in south Greenland to Uummannaq in north Greenland; satellites cover north and east Greenland for domestic and foreign telecommunications; a marine cable connects south and west Greenland to the rest of the world, extending from Nuuk and Qaqortoq to Canada and Iceland; a contract has been awarded to build a 5G network in Greenland, initially covering three towns, with 10 towns, including Greenland’s capital Nuuk to follow (2022)
domestic:
nearly 11 per 100 for fixed-line subscriptions and 118 per 100 for mobile-cellular (2021)
international:
country code - 299; landing points for Greenland Connect, Greenland Connect North, Nunavut Undersea Fiber System submarine cables to Greenland, Iceland, and Canada; satellite earth stations - 15 (12 Intelsat, 1 Eutelsat, 2 Americom GE-2 (all Atlantic Ocean)) (2019)
Broadcast media:
the Greenland Broadcasting Company provides public radio and TV services throughout the island with a broadcast station and a series of repeaters; a few private local TV and radio stations; Danish public radio rebroadcasts are available (2019)
Internet country code:
.gl
Internet users:
total:
38,920 (2021 est.)
percent of population:
69.5% (2021 est.)
comparison ranking:
total 204
Broadband - fixed subscriptions:
total:
15,649 (2020 est.)
subscriptions per 100 inhabitants:
28 (2020 est.)
comparison ranking:
total 173','65b91aa72153d4e0f16fbc95f9f6f32e8b6087cd95ce995c42f1107cf44d11a3','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('776a6c72a40cda8cb9e68027db8ca5e27af8661be6e3481bde56fcc5591e1a0f',2025,'GD','Grenada','communications',43,'Telephones - fixed lines:
total subscriptions:
26,000 (2021 est.)
subscriptions per 100 inhabitants:
21 (2021 est.)
comparison ranking:
total subscriptions 170
Telephones - mobile cellular:
total subscriptions:
100,000 (2021 est.)
subscriptions per 100 inhabitants:
81 (2021 est.)
comparison ranking:
total subscriptions 191
Telecommunication systems:
general assessment:
the telecom sector has seen a decline in subscriber numbers (particularly for prepaid mobile services the mainstay of short term visitors) and revenue; fixed and mobile broadband services are two areas that have benefited from the crisis as employees and students have resorted to working from home; one area of the telecom market that is not prepared for growth is 5G mobile; governments, regulators, and even the mobile network operators have shown that they have not been investing in 5G opportunities at the present time; network expansion and enhancements remain concentrated around improving LTE coverage (2021)
domestic:
21 per 100 for fixed-line and 81 per 100 for mobile-cellular (2021)
international:
country code - 1-473; landing points for the ECFS, Southern Caribbean Fiber and CARCIP submarine cables with links to 13 Caribbean islands extending from the British Virgin Islands to Trinidad & Tobago including Puerto Rico and Barbados; SHF radiotelephone links to Trinidad and Tobago and Saint Vincent; VHF and UHF radio links to Trinidad (2019)
Broadcast media:
multiple publicly and privately owned television and radio stations; Grenada Information Service (GIS) is government-owned and provides television and radio services; the Grenada Broadcasting Network, jointly owned by the government and the Caribbean Communications Network of Trinidad and Tobago, operates a TV station and 2 radio stations; Meaningful Television (MTV) broadcasts island-wide and is part of a locally-owned media house, Moving Target Company, that also includes an FM radio station and a weekly newspaper; multi-channel cable TV subscription service is provided by Columbus Communications Grenada (FLOW GRENADA) and is available island wide; approximately 25 private radio stations also broadcast throughout the country (2019)
Internet country code:
.gd
Internet users:
total:
93,600 (2021 est.)
percent of population:
78% (2021 est.)
comparison ranking:
total 189
Broadband - fixed subscriptions:
total:
32,000 (2020 est.)
subscriptions per 100 inhabitants:
28 (2020 est.)
comparison ranking:
total 150','04b64ae873a041c77a4f680995fdfcb62b654736b035848828225d06b68f53dc','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('82b42fa1a2f3707cb9b27f234074d8565568125e4ce2d9eb67f7db9af549761b',2025,'GU','Guam','communications',54,'Telephones - fixed lines:
total subscriptions:
70,000 (2021 est.)
subscriptions per 100 inhabitants:
41 (2021 est.)
comparison ranking:
total subscriptions 145
Telephones - mobile cellular:
total subscriptions:
98,000 (2009 est.)
subscriptions per 100 inhabitants:
62 (2009 est.)
comparison ranking:
total subscriptions 193
Telecommunication systems:
general assessment:
Guam’s telecommunications companies provide important services that allow other businesses on island to operate; Guam plays a larger, and growing role, in global telecommunications infrastructure, the submarine fiber optic cables that land on Guam benefit island residents and the local economy; in the Asia-Pacific region the demand for 4G, 5G, and broadband access is rapidly increasing; the 11 submarine cables that currently land on Guam, connecting the U.S. to the Asia-Pacific region, are some of the more than 400 cables that are the backbone of global telecommunications, providing nearly all of the world’s internet and phone service (2021)
domestic:
fixed-line subscriptions 41 per 100 and 62 per 100 mobile-cellular subscriptions in 2004 (2020)
international:
country code - 1-671; major landing points for Atisa, HANTRU1, HK-G, JGA-N, JGA-S, PIPE-1, SEA-US, SxS, Tata TGN-Pacific, AJC, GOKI, AAG, AJC and Mariana-Guam Cable submarine cables between Asia, Australia, and the US (Guam is a transpacific communications hub for major carriers linking the US and Asia); satellite earth stations - 2 Intelsat (Pacific Ocean) (2019)
Broadcast media:
about a dozen TV channels, including digital channels; multi-channel cable TV services are available; roughly 20 radio stations
Internet country code:
.gu
Internet users:
total:
136,850 (2021 est.)
percent of population:
80.5% (2021 est.)
comparison ranking:
total 184
Broadband - fixed subscriptions:
total:
3,000 (2020 est.)
subscriptions per 100 inhabitants:
2 (2020 est.)
comparison ranking:
total 193','80296c0ac82753538805478a49de63bbc7dbfe1e80672836bdd502762fc3d7f7','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('dec09b0881a47692a6cd84631ab8cdb7ab495413796694b0f8ad529d7ead4b36',2025,'GT','Guatemala','communications',65,'Telephones - fixed lines:
total subscriptions:
2,319,643 (2021 est.)
subscriptions per 100 inhabitants:
13 (2021 est.)
comparison ranking:
total subscriptions 51
Telephones - mobile cellular:
total subscriptions:
22,124,839 (2021 est.)
subscriptions per 100 inhabitants:
126 (2021 est.)
comparison ranking:
total subscriptions 57
Telecommunication systems:
general assessment:
Guatemala’s telecom infrastructure has suffered from years of under investment from state and provincial government; the poor state of fixed-line infrastructure has led to Guatemala having one of the lowest fixed-line teledensities in the region; in many rural regions of the country there is no fixed-line access available, and so mobile services are adopted by necessity; private investment has been supported by government and regulatory efforts, resulting in a steady growth in the number of fixed lines which has supported growth in the fixed broadband segment; delays in launching LTE services left the country lagging behind in the development of mobile broadband and the benefits which it can bring to the country’s social and economic growth; two new submarine cables are due for completion by 2022; improved international connectivity should drive further uptake of both fixed and mobile broadband services; intense competition among the networks has helped to improve services and lower prices for end-users; given the commercial impetus of networks, insufficient government financial investment has resulted in many regional areas remaining with poor or non-existent services; the country benefits from one of the most open regulatory frameworks, with all telecom sectors having been open to competition since 1996; mobile subscriptions are on par with the regional average, though the slower growth in the mobile subscriber base suggests a level of market saturation, with the emphasis among networks being on generating revenue via mobile data services (2021)
domestic:
fixed-line teledensity roughly 13 per 100 persons; fixed-line investments are concentrating on improving rural connectivity; mobile-cellular teledensity about 126 per 100 persons (2021)
international:
country code - 502; landing points for the ARCOS, AMX-1, American Movil-Texius West Coast Cable and the SAm-1 fiber-optic submarine cable system that, together, provide connectivity to South and Central America, parts of the Caribbean, and the US; connected to Central American Microwave System; satellite earth station - 1 Intelsat (Atlantic Ocean) (2019)
Broadcast media:
4 privately owned national terrestrial TV channels dominate TV broadcasting; multi-channel satellite and cable services are available; 1 government-owned radio station and hundreds of privately owned radio stations (2019)
Internet country code:
.gt
Internet users:
total:
9.18 million (2021 est.)
percent of population:
51% (2021 est.)
comparison ranking:
total 62
Broadband - fixed subscriptions:
total:
612,000 (2020 est.)
subscriptions per 100 inhabitants:
3 (2020 est.)
comparison ranking:
total 86','9f6a682daa4ba11df59d9db75b069c193dacc9bd2514e0233d470bc2b310854e','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('58413116da88fccb592a5d6cc6a37650849206678dbbcfcfc20dc4cabfa98012',2025,'GG','Guernsey','communications',8,'Telephones - fixed lines:
total subscriptions:
33,930 (2021 est.)
subscriptions per 100 inhabitants:
53 (2021 est.)
comparison ranking:
total subscriptions 165
Telephones - mobile cellular:
total subscriptions:
71,485 (2021 est.)
subscriptions per 100 inhabitants:
112 (2021 est.)
comparison ranking:
total subscriptions 196
Telecommunication systems:
general assessment:
fixed network broadband services are those delivered over physical copper connections, fiber connections and fixed wireless communications links (e.g. WiMax); they do not include services delivered over 2G, 3G and 4G mobile networks (2021)
domestic:
fixed-line 53 per 100 and mobile-cellular 112 per 100 persons (2021)
international:
country code - 44; landing points for Guernsey-Jersey, HUGO, INGRID, Channel Islands -9 Liberty and UK-Channel Islands-7 submarine cable to UK and France (2019)
Broadcast media:
multiple UK terrestrial TV broadcasts are received via a transmitter in Jersey with relays in Jersey, Guernsey, and Alderney; satellite packages are available; BBC Radio Guernsey and 1 other radio station operating
Internet country code:
.gg
Internet users:
total:
55,069 (2021 est.)
percent of population:
86.6% (2021 est.)
comparison ranking:
total 200
Broadband - fixed subscriptions:
total:
25,336 (2020 est.)
subscriptions per 100 inhabitants:
40 (2020 est.)
comparison ranking:
total 158','72534bff6f1282ebebc4da9c5ed4a1e5883a983071a3983fcf986b61a6d3e1e9','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4bbfda94c5d3d1c6b3a901925d5814ac6b0a752680554eb93c04ba2e291608e0',2025,'GN','Guinea','communications',19,'Telephones - fixed lines:
total subscriptions:
0 (2018 est.)
subscriptions per 100 inhabitants:
0 (2018 est.)
comparison ranking:
total subscriptions 223
Telephones - mobile cellular:
total subscriptions:
13.795 million (2020 est.)
subscriptions per 100 inhabitants:
105 (2020 est.)
comparison ranking:
total subscriptions 74
Telecommunication systems:
general assessment:
the number of mobile subscribers grew strongly while revenue also increased steadily; fixed broadband services are still very limited and expensive, though there have been some positive developments in recent years; the landing of the first international submarine cable in 2012, and the setting up of an IXP in mid-2013, increased the bandwidth available to the ISPs, and helped reduce the cost of internet services for end-users; a National Backbone Network was completed in mid-2020, connecting administrative centers across the country; almost all internet connections are made via mobile networks; GSM services account for a dwindling proportion of connections, in line with the greater reach of services based on 3G and LTE (2022)
domestic:
fixed-line teledensity is less than 1 per 100 persons; mobile-cellular subscribership is just over 105 per 100 persons (2020)
international:
country code - 224; ACE submarine cable connecting Guinea with 20 landing points in Western and South Africa and Europe; satellite earth station - 1 Intelsat (Atlantic Ocean (2019)
Broadcast media:
Government maintains marginal control over broadcast media; single state-run TV station; state-run radio broadcast station also operates several stations in rural areas; a dozen private television stations; a steadily increasing number of privately owned radio stations, nearly all in Conakry, and about a dozen community radio stations; foreign TV programming available via satellite and cable subscription services
(2022)
Internet country code:
.gn
Internet users:
total:
4.9 million (2021 est.)
percent of population:
35% (2021 est.)
comparison ranking:
total 93
Broadband - fixed subscriptions:
total:
1,000 (2020 est.)
subscriptions per 100 inhabitants:
0.01 (2020 est.)
comparison ranking:
total 203','2fa7f42853c86374c789bda61984cac413d9519a86a471c2b5ea2779492e7e1c','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('080a3dba6cadceb5f821843dd66fa73308d19ff36c55fb020bfb6f14403be025',2025,'GW','Guinea-Bissau','communications',30,'Telephones - fixed lines:
total subscriptions:
4,800 (2009 est.)
subscriptions per 100 inhabitants:
(2009 est.) less than 1
comparison ranking:
total subscriptions 206
Telephones - mobile cellular:
total subscriptions:
2,236,511 (2021 est.)
subscriptions per 100 inhabitants:
109 (2021 est.)
comparison ranking:
total subscriptions 147
Telecommunication systems:
general assessment:
small system including a combination of microwave radio relay, open-wire lines, radiotelephone, and mobile cellular communications; 2 mobile network operators; one of the poorest countries in the world and this is reflected in the country’s telecommunications development; radio is the most important source of information for the public (2020)
domestic:
fixed-line teledensity less than 1 per 100 persons; mobile cellular teledensity is just over 109 per 100 persons (2021)
international:
country code - 245; ACE submarine cable connecting Guinea-Bissau with 20 landing points in Western and South Africa and Europe (2019)
Broadcast media:
1 state-owned TV station, Televisao da Guine-Bissau (TGB) and a second station, Radio e Televisao de Portugal (RTP) Africa, is operated by Portuguese public broadcaster (RTP); 1 state-owned radio station, several private radio stations, and some community radio stations; multiple international broadcasters are available (2019)
Internet country code:
.gw
Internet users:
total:
735,000 (2021 est.)
percent of population:
35% (2021 est.)
comparison ranking:
total 159
Broadband - fixed subscriptions:
total:
2,383 (2020 est.)
subscriptions per 100 inhabitants:
0.1 (2020 est.)
comparison ranking:
total 198','b3c83b9f425e5537c187fe8dd2894e906cf4f23ebfafbf89058701b96c0aa00e','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7e2412722928e332b46826687fea9a917c497a2fc03ee7139fd16f96dda998ea',2025,'GY','Guyana','communications',41,'Telephones - fixed lines:
total subscriptions:
130,000 (2021 est.)
subscriptions per 100 inhabitants:
16 (2021 est.)
comparison ranking:
total subscriptions 128
Telephones - mobile cellular:
total subscriptions:
860,000 (2021 est.)
subscriptions per 100 inhabitants:
110 (2021 est.)
comparison ranking:
total subscriptions 166
Telecommunication systems:
general assessment:
after many years of delays and legal challenges, the 2016 Telecommunications Act was brought into force in October 2020 by the newly elected government of the People’s Party Progressive (PPP); the Telecommunications Act sets out a framework for enabling competition across all segments of the telecommunications sector in Guyana; the mobile market has been open to competition since 2001; the Telecommunications Act presents the country with the potential to benefit from a more level playing field that may attract new players, but nevertheless Guyana’s relatively small size and low GDP may restrict it from reaching its full potential for some more years to come (2021)
domestic:
fixed-line teledensity is about 16 per 100 persons; mobile-cellular teledensity about 110 per 100 persons (2021)
international:
country code - 592; landing point for the SG-SCS submarine cable to Suriname, and the Caribbean; satellite earth station - 1 Intelsat (Atlantic Ocean) (2019)
Broadcast media:
government-dominated broadcast media; the National Communications Network (NCN) TV is state-owned; a few private TV stations relay satellite services; the state owns and operates 2 radio stations broadcasting on multiple frequencies capable of reaching the entire country; government limits on licensing of new private radio stations has constrained competition in broadcast media
Internet country code:
.gy
Internet users:
total:
680,000 (2021 est.)
percent of population:
85% (2021 est.)
comparison ranking:
total 161
Broadband - fixed subscriptions:
total:
95,000 (2020 est.)
subscriptions per 100 inhabitants:
12 (2020 est.)
comparison ranking:
total 128','a5199c0253ecb971cb1e8803ff10be129b48c21425c768932574634265d989c2','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1be9113ef49d46fba37ac6cff911bb6eda1375d8f5d5a8c70248d000dae2713a',2025,'HT','Haiti','communications',8,'Telephones - fixed lines:
total subscriptions:
6,000 (2021 est.)
subscriptions per 100 inhabitants:
64 (2021 est.) less than 1
comparison ranking:
total subscriptions 204
Telephones - mobile cellular:
total subscriptions:
7.3 million (2021 est.)
subscriptions per 100 inhabitants:
64 (2021 est.)
comparison ranking:
total subscriptions 106
Telecommunication systems:
general assessment:
Haiti is in desperate need of maintaining effective communication services to enable it to keep going through the countless natural disasters, the country’s telecoms sector is really only surviving on the back of international goodwill to repair and replace the systems destroyed in the latest upheaval; Haiti’s fixed-line infrastructure is now practically non-existent, having been torn apart by Hurricane Matthew in 2016; what aid and additional investment has been forthcoming has been directed towards mobile solutions; over half of the country can afford a mobile handset or the cost of a monthly subscription; and mobile broadband subscriptions is half of that again – an estimated 28% in 2022; international aid continues to flow in to try and help the country’s telecoms sector recover – the World Bank has released a further $120 million to go on top of the $60 million grant provided after the last major 7.2 earthquake in August 2021 (2022)
domestic:
fixed-line is less than 1 per 100; mobile-cellular teledensity is nearly 64 per 100 persons (2021)
international:
country code - 509; landing points for the BDSNi and Fibralink submarine cables to 14 points in the Bahamas and Dominican Republic; satellite earth station - 1 Intelsat (Atlantic Ocean) (2019)
Broadcast media:
per 2019 data released by Haitian telecommunications regulator CONATEL (Conseil National des Télécommunications), there are 398 legal sound broadcasting stations on the territory, including about 60 community radio stations, and 7 radio stations on the AM band; the FM band in Haiti is oversaturated by 158 percent; most radio stations broadcast 17 to 19 hours a day; there are 105 television stations operating in Haiti, including 36 TV stations in Port- au- Prince, 41 others in the provinces, and more than 40 radio-television stations; a large number of broadcasting stations operate irregularly and some stations operate with technical parameters that do not comply with established standards, thus causing harmful interference to existing telecommunications systems; VOA Creole Service broadcasts daily on 30 affiliate stations (2019)
Internet country code:
.ht
Internet users:
total:
4.29 million (2021 est.)
percent of population:
39% (2021 est.)
comparison ranking:
total 107
Broadband - fixed subscriptions:
total:
31,000 (2020 est.)
subscriptions per 100 inhabitants:
0.3 (2020 est.)
comparison ranking:
total 152','addf3fa5d8c58645ce443054bd701fcac76a9c9912df655e880c033fdc96b74f','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7a2edda08d87c9b427dcea45eb013e116a9dd12b9480ad71a5b10c1c8f78810d',2025,'HM','Heard Island and McDonald Islands','communications',17,'Internet country code:
.hm','08ed04a192cd13be656e67b3f708beabdc996cc055eef13e9826cbd76c387536','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('816ae78a383beb0e4b35d2a1f61deea548b390c4a57d5586e0423d205575b46a',2025,'HM','Heard Island and McDonald Islands','communications',28,'Telecommunication systems:
general assessment:
the Vatican’s interior telecommunication system is composed of two strongly integrated subsystem: fixed infrastructure and mobile infrastructure; it is important to note that the mobile communication system has been designed to be capable of using satellite connections so that it is possible to ensure the telecommunication services whenever needed, following the Pastoral travels of the Pope; the telephone system operates through an automatic digital exchange (2020)
domestic:
the telephone system operates through an automatic digital exchange (2020)
international:
country code - 39; uses Italian system
Broadcast media:
the Vatican Television Center (CTV) transmits live broadcasts of the Pope’s Sunday and Wednesday audiences, as well as the Pope’s public celebrations; CTV also produces documentaries; Vatican Radio is the Holy See’s official broadcasting service broadcasting via shortwave, AM and FM frequencies, and via satellite and Internet connections; Vatican News website partners with Vatican Radio and provides Catholic news provided by the Vatican (2021)
Internet country code:
.va
Internet users:
total:
383 (2021 est.)
percent of population:
75% (2021 est.)
comparison ranking:
total 232
Communications - note:
the Vatican Apostolic Library is one of the world’s oldest libraries, formally established in 1475, but actually much older; it holds a significant collection of historic texts including 1.1 million printed books and 75,000 codices (manuscript books with handwritten contents); it serves as a research library for history, law, philosophy, science, and theology; the library’s collections have been described as “the world’s greatest treasure house of the writings at the core of Western tradition”','454a8e7ae5c3b85d0baea9c792080be10192367a87af480e3a882fcbc25f443a','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f9ecc80c71a6e40df6c7774670b3386d3270d4974acf4c1652e369e4b71cb07d',2025,'HN','Honduras','communications',38,'Telephones - fixed lines:
total subscriptions:
465,521 (2021 est.)
subscriptions per 100 inhabitants:
5 (2021 est.)
comparison ranking:
total subscriptions 97
Telephones - mobile cellular:
total subscriptions:
7,560,710 (2021 est.)
subscriptions per 100 inhabitants:
74 (2021 est.)
comparison ranking:
total subscriptions 104
Telecommunication systems:
general assessment:
Honduras is among the poorest countries in Central America and has long been plagued by an unstable political framework which has rendered telecom sector reform difficult; this has created real difficulties for telcos as well as consumers; fixed-line teledensity, at only 4.9%, is significantly lower than the Latin American and Caribbean average; poor fixed-line infrastructure has been exacerbated by low investment and topographical difficulties which have made investment in rural areas unattractive or uneconomical; the internet has been slow to develop; DSL and cable modem technologies are available but are relatively expensive, while higher speed services are largely restricted to the major urban centers; the demand for broadband is steadily increasing and there has been some investment in network upgrades to fiber-based infrastructure
(2022)
domestic:
fixed-line teledensity of 5 per 100; mobile-cellular subscribership is roughly 74 per 100 persons (2021)
international:
country code - 504; landing points for both the ARCOS and the MAYA-1 fiber-optic submarine cable systems that together provide connectivity to South and Central America, parts of the Caribbean, and the US; satellite earth stations - 2 Intelsat (Atlantic Ocean); connected to Central American Microwave System (2019)
Broadcast media:
multiple privately owned terrestrial TV networks, supplemented by multiple cable TV networks; Radio Honduras is the lone government-owned radio network; roughly 300 privately owned radio stations (2019)
Internet country code:
.hn
Internet users:
total:
4.8 million (2021 est.)
percent of population:
48% (2021 est.)
comparison ranking:
total 98
Broadband - fixed subscriptions:
total:
396,916 (2020)
subscriptions per 100 inhabitants:
4 (2020 est.)
comparison ranking:
total 97','0b4c3524b44f7e775f3bf966d0f8d64098f1afaad301afe00e1720cf178d5a7a','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b0f10d306d4fcbccfeacc8cc427a20512c1d82bda9bb67f98efde1438f470110',2025,'HK','Hong Kong','communications',49,'Telephones - fixed lines:
total subscriptions:
3,856,180 (2021 est.)
subscriptions per 100 inhabitants:
51 (2021 est.)
comparison ranking:
total subscriptions 33
Telephones - mobile cellular:
total subscriptions:
23,939,650 (2021 est.)
subscriptions per 100 inhabitants:
319 (2021 est.)
comparison ranking:
total subscriptions 53
Telecommunication systems:
general assessment:
Hong Kong’s telecommunications sector continues to stay near the top of world rankings for the industry; it has kept its #1 spot in the Asian region in terms of the maturity of its telecom market – a reflection of the high penetration rates across mobile, mobile broadband, and fixed broadband; even fixed-line teledensity in Hong Kong is impressive at over 50%, although it too has started a gradual decline in keeping with most other telecom markets around the world, as consumers slowly transition over to the mobile platform for all of their communication needs (2022)
domestic:
fixed-line is over 51 per 100 and mobile-cellular is 319 subscriptions per 100 (2021)
international:
country code - 852; landing points for the AAE-1, AAG, APCN-2, APG, ASE, FEA, FNAL, RNAL, H2HE, SeaMeWe-3, SJC and TGN-IA submarine cables that provide connections to Asia, US, Australia, the Middle East, and Europe; satellite earth stations - 3 Intelsat (1 Pacific Ocean and 2 Indian Ocean); coaxial cable to Guangzhou, China (2022)
Broadcast media:
34 commercial terrestrial TV networks each with multiple stations; multi-channel satellite and cable TV systems available; 3 licensed broadcasters of terrestrial radio, one of which is government funded, operate about 12 radio stations; note - 4 digital radio broadcasters operated in Hong Kong from 2010 to 2017, but all digital radio services were terminated in September 2017 due to weak market demand (2019)
Internet country code:
.hk
Internet users:
total:
6.975 million (2021 est.)
percent of population:
93% (2021 est.)
comparison ranking:
total 80
Broadband - fixed subscriptions:
total:
2,885,586 (2020 est.)
subscriptions per 100 inhabitants:
39 (2020 est.)
comparison ranking:
total 47','e4238069a45cf9ac3279bae956e07a1f3f824ba4a2badce6c212555a1698323c','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1b5e150796e4d318cfc8129ef20d4149adfedf01fc771780aeb4f3e8f743a4f6',2025,'HU','Hungary','communications',61,'Telephones - fixed lines:
total subscriptions:
2,955,979 (2021 est.)
subscriptions per 100 inhabitants:
30 (2021 est.)
comparison ranking:
total subscriptions 44
Telephones - mobile cellular:
total subscriptions:
10,248,653 (2021 est.)
subscriptions per 100 inhabitants:
106 (2021 est.)
comparison ranking:
total subscriptions 92
Telecommunication systems:
general assessment:
Hungary benefits from having a developed telecom infrastructure, with a focus among operators to develop the 5G sector and upgrade fixed networks to provide a 1Gb/s service; services based on 5G have been supported by the January 2021 multi-spectrum auction for spectrum in the 900MHz and 1800MHz bands; the number of fixed-lines continues to fall as subscribers migrate to the mobile platform for voice and data services; operators have looked to bundled packages to boost revenue and retain subscribers; the broadband market has effective infrastructure-based competition, with an extensive cable network competing against DSL services and a vibrant and rapidly expanding fiber sector; the regulator has also introduced a number of measures aimed at promoting market competition, which is pushing the drive for higher speed platforms and encouraging operators to invest in technology upgrades; as a result, Hungary now has the highest fixed broadband penetration rate in Eastern Europe; the number of super fast broadband connections (above 30Mb/s) accounted for 78% of all fixed broadband connections (2022)
domestic:
fixed-line connections, with 30 fixed per 100 persons and 106 mobile-cellular subscriptions per 100 (2021)
international:
country code - 36; Hungary has fiber-optic cable connections with all neighboring countries; the international switch is in Budapest; satellite earth stations - 2 Intelsat (Atlantic Ocean and Indian Ocean regions), 1 Inmarsat, 1 (very small aperture terminal) VSAT system of ground terminals
Broadcast media:
mixed system of state-supported public service broadcast media and private broadcasters; the 5 publicly owned TV channels and the 2 main privately owned TV stations are the major national broadcasters; a large number of special interest channels; highly developed market for satellite and cable TV services with about two-thirds of viewers utilizing their services; 4 state-supported public-service radio networks; a large number of local stations including commercial, public service, nonprofit, and community radio stations; digital transition completed at the end of 2013; government-linked businesses have greatly consolidated ownership in broadcast and print media (2019)
Internet country code:
.hu
Internet users:
total:
8.633 million (2021 est.)
percent of population:
89% (2021 est.)
comparison ranking:
total 66
Broadband - fixed subscriptions total:
3,382,136 (2021 est.)
subscriptions per 100 inhabitants:
34.83 (2021 est.)
comparison ranking:
total 42','ebf729a37be60b1aa2e338dfbc240be8f0292df4132fd5111c0be7d444405be2','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d4279f2ab383f0e9d8b77b421f7fa182aea83682d82e3dfec63781a672dba0a4',2025,'IS','Iceland','communications',8,'Telephones - fixed lines:
total subscriptions:
100,482 (2021 est.)
subscriptions per 100 inhabitants:
27 (2021 est.)
comparison ranking:
total subscriptions 138
Telephones - mobile cellular:
total subscriptions:
437,270 (2021 est.)
subscriptions per 100 inhabitants:
118 (2021 est.)
comparison ranking:
total subscriptions 177
Telecommunication systems:
general assessment:
Iceland has one of the smallest yet most progressive telecom markets in Europe; the country in 2020 became the top in Europe for fiber penetration; it aims to provide a fixed broadband service of at least 100Mb/s to 99.9% of the population by the end of 2021, an ambitious target by international standards and one which it is likely to achieve given the progress which operators have made in extending the reach of fiber networks; there is effective competition in the mobile and broadband markets, with a number of players having emerged to challenge the dominance of the two leading operators which have interests across the telecom sectors; the telecom market has shown some resilience in recent years following the significant economic downturn a decade ago, supported by continuing investment in mobile and fixed-line broadband infrastructure by operators and well as by the government’s Telecommunications Fund which is supporting Next Generation Access networks, particularly in rural areas (2022)
domestic:
27 per 100 for fixed line and nearing 118 per 100 for mobile-cellular subscriptions (2021)
international:
country code - 354; landing points for the CANTAT-3, FARICE-1, Greenland Connect and DANICE submarine cable system that provides connectivity to Canada, the Faroe Islands, Greenland, UK, Denmark, and Germany; satellite earth stations - 2 Intelsat (Atlantic Ocean), 1 Inmarsat (Atlantic and Indian Ocean regions); note - Iceland shares the Inmarsat earth station with the other Nordic countries (Denmark, Finland, Norway, and Sweden) (2019)
Broadcast media:
state-owned public TV broadcaster (RUV) operates 21 TV channels nationally (RUV and RUV 2, though RUV 2 is used less frequently); RUV broadcasts nationally, every household in Iceland is required to have RUV as it doubles as the emergency broadcast network; RUV also operates stringer offices in the north (Akureyri) and the east (Egilsstadir) but operations are all run out of RUV headquarters in Reykjavik; there are 3 privately owned TV stations; Stod 2 (Channel 2) is owned by Syn, following 365 Media and Vodafone merger, and is headquartered in Reykjavik; Syn also operates 4 sports channels under Stod 2; N4 is the only television station headquartered outside of Reykjavik, in Akureyri, with local programming for the north, south, and east of Iceland; Hringbraut is the newest station and is headquartered in Reykjavik; all of these television stations have nationwide penetration as 100% of households have multi-channel services though digital and/or fiber-optic connections
RUV operates 3 radio stations (RAS 1, RAS2, and Rondo) as well as 4 regional stations (but they mostly act as range extenders for RUV radio broadcasts nationwide); there is 1 privately owned radio conglomerate, Syn (4 stations), that broadcasts nationwide, and 3 other radio stations that broadcast to the most densely populated regions of the country. In addition, there are upwards of 20 radio stations that operate regionally
(2019)
Internet country code:
.is
Internet users:
total:
370,000 (2021 est.)
percent of population:
100% (2021 est.)
comparison ranking:
total 174
Broadband - fixed subscriptions:
total:
141,816 (2020 est.)
subscriptions per 100 inhabitants:
42 (2020 est.)
comparison ranking:
total 124','a36da844a88189cd3d7c28986974e1b79d497a6cd7c9e13a73739769e0e0eb02','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('727bead39db61afc5e40789f1e66d2a723bf514156cedd328b8ec35ba214ac2d',2025,'IN','India','communications',19,'Telephones - fixed lines:
total subscriptions:
23,773,751 (2021 est.)
subscriptions per 100 inhabitants:
2 (2021 est.)
comparison ranking:
total subscriptions 11
Telephones - mobile cellular:
total subscriptions:
1.15 billion (2021 est.)
subscriptions per 100 inhabitants:
82 (2021 est.)
comparison ranking:
total subscriptions 2
Telecommunication systems:
general assessment:
India’s telecommunications sector has struggled for growth over the last five years; the sector’s lackluster performance has been in spite of concerted efforts by the government to bolster the underlying infrastructure in a bid to achieve universal coverage; instead, the country’s relatively liberal regulatory environment has encouraged fierce competition and price wars among the operators; State-owned as well as private operators have been forced to seek redress from the government in order to avoid bankruptcy; one particular area of contention has been the billions owed by the operators to the government in the form of Adjusted Gross Revenue (AGR) dues – usage and licensing fees charged by the Department of Telecommunications (DoT) – that have been the subject of long-standing court battles over what should be counted as revenue; the government won that battle in the Supreme Court in 2019, but the financial impairment of that decision has pushed a number of telcos to the brink; add the impact of the Covid-19 crisis in 2020 and 2021 to the mix, and the government had to come to the industry’s rescue by introducing a major reform package in September 2021; along with changes to the definition of AGR with regard to non-telecom revenue, the package includes a four-year moratorium on AGR dues and spectrum instalments; the government has also deferred the spectrum auctions for 5G until later in 2022; mobile spectrum in India is already in short supply in terms of providing the necessary capacity to reach universal coverage, but the cash-strapped MNOs may not yet be in a sufficiently strong financial position for which to make the 5G spectrum auction viable (2022)
domestic:
fixed-line subscriptions 2 per 100 and mobile-cellular at nearly 82 per 100 (2021)
international:
country code - 91; a number of major international submarine cable systems, including SEA-ME-WE-3 & 4, AAE-1, BBG, EIG, FALCON, FEA, GBICS, MENA, IMEWE, SEACOM/ Tata TGN-Eurasia, SAFE, WARF, Bharat Lanka Cable System, IOX, Chennai-Andaman & Nicobar Island Cable, SAEx2, Tata TGN-Tata Indicom and i2icn that provide connectivity to Europe, Africa, Asia, the Middle East, South East Asia, numerous Indian Ocean islands including Australia ; satellite earth stations - 8 Intelsat (Indian Ocean) and 1 Inmarsat; Indian Ocean region (2022)
Broadcast media:
Doordarshan, India’s public TV network, has a monopoly on terrestrial broadcasting and operates about 20 national, regional, and local services; a large and increasing number of privately owned TV stations are distributed by cable and satellite service providers; in 2020, 130 million households paid for cable and satellite television across India and as of 2018, cable and satellite TV offered over 850 TV channels; government controls AM radio with All India Radio operating domestic and external networks; news broadcasts via radio are limited to the All India Radio Network; since 2000, privately owned FM stations have been permitted and their numbers have increased rapidly (2020)
Internet country code:
.in
Internet users:
total:
644 million (2021 est.)
percent of population:
46% (2021 est.)
comparison ranking:
total 2
Broadband - fixed subscriptions:
total:
22.95 million (2020 est.)
subscriptions per 100 inhabitants:
2 (2020 est.)
comparison ranking:
total 9','c71da9e848b4c893f0ca33d3be84bfa2876a288843bc2f1c6d51b1005837e1e9','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('02a5bad271ae3d4e1f96611900c7b866179d4c17cf8ab1938989f7edd1632b35',2025,'ID','Indonesia','communications',39,'Telephones - fixed lines:
total subscriptions:
8,998,814 (2021 est.)
subscriptions per 100 inhabitants:
3 (2021 est.)
comparison ranking:
total subscriptions 19
Telephones - mobile cellular:
total subscriptions:
365,872,608 (2021 est.)
subscriptions per 100 inhabitants:
134 (2021 est.)
comparison ranking:
total subscriptions 3
Telecommunication systems:
general assessment:
Indonesia faces more than the usual number of obstacles in terms of enabling widespread access to quality telecommunications services for its population of more than 270 million; the geographical challenges have been further compounded by a variety of social, political, and economic problems over the years that have kept the country’s wealth distributed very thinly; the fixed-line (fiber) and mobile operators have continued to expand and upgrade their networks across the country; Indonesia’s 18,000 islands (many of which, however, are sparsely populated) makes the deployment of fixed-line infrastructure on a broad scale difficult; there has been renewed activity in fiber optic cable, but the bundling of fixed-line telephony with TV and internet services will see the country’s teledensity stabilize; mobile subscriptions have reached more than 130% and is projected to exceed 150% by 2026; with 4G LTE universally available, the major mobile companies have been busy launching 5G services in selected areas; the rollout of 5G will be hampered by the lack of availability of suitable frequencies; the 4G had to be reallocated from broadcasting services, and indications are that the same process is going to have to be followed in order to allow the expansion of 5G into its core frequency bands (3.3 to 4.2GHz) (2022)
domestic:
fixed-line subscribership roughly 3 per 100 and mobile-cellular 134 per 100 persons (2021)
international:
country code - 62; landing points for the SEA-ME-WE-3 & 5, DAMAI, JASUKA, BDM, Dumai-Melaka Cable System, IGG, JIBA, Link 1, 3, 4, & 5, PGASCOM, B3J2, Tanjung Pandam-Sungai Kakap Cable System, JAKABARE, JAYABAYA, INDIGO-West, Matrix Cable System, ASC, SJJK, Jaka2LaDeMa, S-U-B Cable System, JBCS, MKCS, BALOK, Palapa Ring East, West and Middle, SMPCS Packet-1 and 2, LTCS, TSCS, SEA-US and Kamal Domestic Submarine Cable System, 35 submarine cable networks that provide links throughout Asia, the Middle East, Australia, Southeast Asia, Africa and Europe; satellite earth stations - 2 Intelsat (1 Indian Ocean and 1 Pacific Ocean) (2019)
Broadcast media:
mixture of about a dozen national TV networks - 1 public broadcaster, the remainder private broadcasters - each with multiple transmitters; more than 100 local TV stations; widespread use of satellite and cable TV systems; public radio broadcaster operates 6 national networks, as well as regional and local stations; overall, more than 700 radio stations with more than 650 privately operated (2019)
Internet country code:
.id
Internet users:
total:
167.4 million (2021 est.)
percent of population:
62% (2021 est.)
comparison ranking:
total 5
Broadband - fixed subscriptions:
total:
11,722,218 (2020 est.)
subscriptions per 100 inhabitants:
4 (2020 est.)
comparison ranking:
total 17','c92bff1ee8f3dc7e3456b8ad0bebdbe710ac3bd3fe4c1a7e09800d17a3874374','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('589d1de52c9e01733715d767dd2af30501aa1af7a65cddf1e4c3fdec8f569c21',2025,'ID','Indonesia','communications',52,'Telephones - fixed lines:
total subscriptions:
29,306,782 (2021 est.)
subscriptions per 100 inhabitants:
33 (2021 est.)
comparison ranking:
total subscriptions 7
Telephones - mobile cellular:
total subscriptions:
135,899,424 (2021 est.)
subscriptions per 100 inhabitants:
155 (2021 est.)
comparison ranking:
total subscriptions 13
Telecommunication systems:
general assessment:
Iran’s telecom infrastructure has suffered from sanctions in recent years, which prevented the import of equipment and devices and encouraged widespread smuggling, with a consequent loss of tax revenue; to address this, the government introduced a device registration scheme, and bolstered the capacity for domestically manufactured mobile phones; companies have invested in broadening the reach of their LTE networks, which has increased network capacity and improved the quality of mobile broadband services; the country is also looking to 5G; the sector is still limited by low frequency bands; the government is addressing this with plans to reallocate the 3.5GHz band for 5G use; Iran is keen to grow its digital economy; Iran offers significant opportunities for growth in the telecoms sector; the country has one of the largest populations in the Middle East, and there is a high proportion of youthful, tech savvy users having considerable demand for both fixed and mobile telecom services; companies are offering national roaming to improve services in rural areas (2022)
domestic:
approximately 33 per 100 for fixed-line and 155 per 100 for mobile-cellular subscriptions (2021)
international:
country code - 98; landing points for Kuwait-Iran, GBICS & MENA, FALCON, OMRAN/3PEG Cable System, POI and UAE-Iran submarine fiber-optic cable to the Middle East, Africa and India; (TAE) fiber-optic line runs from Azerbaijan through the northern portion of Iran to Turkmenistan with expansion to Georgia and Azerbaijan; HF radio and microwave radio relay to Turkey, Azerbaijan, Pakistan, Afghanistan, Turkmenistan, Syria, Kuwait, Tajikistan, and Uzbekistan; satellite earth stations - 13 (9 Intelsat and 4 Inmarsat) (2019)
Broadcast media:
state-run broadcast media with no private, independent broadcasters; Islamic Republic of Iran Broadcasting (IRIB), the state-run TV broadcaster, operates more than 60 television channels, more than 50 radio stations, and dozens of newspapers and websites; about 20 foreign Persian-language TV stations broadcasting on satellite TV are capable of being seen in Iran; satellite dishes are illegal and, while their use is subjectively tolerated, authorities confiscate satellite dishes from time to time; most major international broadcasters transmit to Iran (2023)
Internet country code:
.ir
Internet users:
total:
69.52 million (2021 est.)
percent of population:
79% (2021 est.)
comparison ranking:
total 13
Broadband - fixed subscriptions:
total:
9,564,195 (2020 est.)
subscriptions per 100 inhabitants:
11 (2020 est.)
comparison ranking:
total 21','2c7c12b63928e4e0c306cf2df545a01ffcff0944de19f9fe98ab04bd74fae107','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1a1e16ed85c84a2d74d25565cd987e342971423ab441015393867664469e4360',2025,'IQ','Iraq','communications',8,'Telephones - fixed lines:
total subscriptions:
3,048,736 (2021 est.)
subscriptions per 100 inhabitants:
7 (2021 est.)
comparison ranking:
total subscriptions 40
Telephones - mobile cellular:
total subscriptions:
37,649,112 (2021 est.)
subscriptions per 100 inhabitants:
86 (2021 est.)
comparison ranking:
total subscriptions 42
Telecommunication systems:
general assessment:
civil stability has made it easier for mobile and fixed-line operators to rebuild telecom services and infrastructure damaged during previous periods of violence; the government extended the licenses held by the MNOs for an additional three years to compensate for the chaos and destruction caused between 2014 and 2017 when Islamic State controlled many areas of the country; the companies have struggled to develop LTE services; most services are still based on GSM and 3G, except in Iraq’s Kurdistan region where LTE is more widely available (2022)
domestic:
about 7 per 100 for fixed-line and 86 per 100 for mobile-cellular subscriptions (2021)
international:
country code - 964; landing points for FALCON, and GBICS/MENA submarine cables providing connections to the Middle East, Africa and India; satellite earth stations - 4 (2 Intelsat - 1 Atlantic Ocean and 1 Indian Ocean, 1 Intersputnik - Atlantic Ocean region, and 1 Arabsat (inoperative)); local microwave radio relay connects border regions to Jordan, Kuwait, Syria, and Turkey (2019)
Broadcast media:
the number of private radio and TV stations has increased rapidly since 2003; government-owned TV and radio stations are operated by the publicly funded Iraqi Media Network; private broadcast media are mostly linked to political, ethnic, or religious groups; satellite TV is available to an estimated 70% of viewers and many of the broadcasters are based abroad; transmissions of multiple international radio broadcasters are accessible (2019)
Internet country code:
.iq
Internet users:
total:
21.56 million (2021 est.)
percent of population:
49% (2021 est.)
comparison ranking:
total 40
Broadband - fixed subscriptions:
total:
6,254,099 (2020 est.)
subscriptions per 100 inhabitants:
16 (2020 est.)
comparison ranking:
total 30','3115af3c4c965eb62b512c13084330708cdb3617c3c42881728a4f19400debb9','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3eb862b44c09094fdbb87aad03716f591bf26f02ef0dc42db12b3314d2a153d6',2025,'IE','Ireland','communications',21,'Telephones - fixed lines:
total subscriptions:
1,595,061 (2021 est.)
subscriptions per 100 inhabitants:
32 (2021 est.)
comparison ranking:
total subscriptions 60
Telephones - mobile cellular:
total subscriptions:
5,373,865 (2021 est.)
subscriptions per 100 inhabitants:
108 (2021 est.)
comparison ranking:
total subscriptions 122
Telecommunication systems:
general assessment:
Ireland’s telecom market has rebounded from a long period in which fiscal constraints inhibited investment in the sector; significant infrastructure projects are underway, including the NBN which aims to deliver a fiber-based service of at least 150Mb/s nationally by the end of 2022; the renewed optimism has been seen in company investment in extending fiber-based networks providing 1Gb/s services; the mobile sector is preparing for a multi-frequency availability later in 2021 which will greatly increase the amount of frequencies available, and provide a boost for 5G services; the MNOs are rapidly expanding the reach of 5G (2021)
domestic:
fixed-line 32 per 100 and mobile-cellular 108 per 100 subscriptions. (2021)
international:
country code - 353; landing point for the AEConnect -1, Celtic-Norse, Havfrue/AEC-2, GTT Express, Celtic, ESAT-1, IFC-1, Solas, Pan European Crossing, ESAT-2, CeltixConnect -1 & 2, GTT Atlantic, Sirius South, Emerald Bridge Fibres and Geo Eirgrid submarine cable with links to the US, Canada, Norway, Isle of Man and UK; satellite earth stations - 81 (2019)
Broadcast media:
publicly owned broadcaster Radio Telefis Eireann (RTE) operates 4 TV stations; commercial TV stations are available; about 75% of households utilize multi-channel satellite and TV services that provide access to a wide range of stations; RTE operates 4 national radio stations and has launched digital audio broadcasts on several stations; a number of commercial broadcast stations operate at the national, regional, and local levels (2019)
Internet country code:
.ie
Internet users:
total:
4.75 million (2021 est.)
percent of population:
95% (2021 est.)
comparison ranking:
total 100
Broadband - fixed subscriptions:
total:
1,516,473 (2020 est.)
subscriptions per 100 inhabitants:
31 (2020 est.)
comparison ranking:
total 65','df058ec18588ee4e73c73274872a37b651876f8d83f45a97c2d451c37d46e7de','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8d969be13d157a9ac4d3e54dc2ea120471b28f3b1fbf47a5a03cfe605a55b485',2025,'IM','Isle of Man','communications',33,'Telecommunication systems:
general assessment:
the Isle of Man has an extensive communications infrastructure consisting of telephone cables, submarine cables, and an array of television and mobile phone transmitters and towers (2022)
domestic:
landline, telefax, mobile cellular telephone system
international:
country code - 44; fiber-optic cable, microwave radio relay, satellite earth station, submarine cable
Broadcast media:
national public radio broadcasts over 3 FM stations and 1 AM station; 2 commercial broadcasters operating with 1 having multiple FM stations; receives radio and TV services via relays from British TV and radio broadcasters
Internet country code:
.im','d3243301fa663bc22573af7619b20ad3e689a3b6f0d775519cdc5becd8777a3b','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ac3e34e34674278de01e45af1d10eaa0a3a429c1d3873f64ace0fc1bbc5ff519',2025,'IL','Israel','communications',44,'Telephones - fixed lines:
total subscriptions:
3.5 million (2021 est.)
subscriptions per 100 inhabitants:
39 (2021 est.)
comparison ranking:
total subscriptions 35
Telephones - mobile cellular:
total subscriptions:
12.5 million (2021 est.)
subscriptions per 100 inhabitants:
140 (2021 est.)
comparison ranking:
total subscriptions 79
Telecommunication systems:
general assessment:
Israel’s developed economy largely revolves around high technology products and services, primarily used in the medical, biotechnology, agricultural, materials, and military industries; the country also attracts investment in its cyber-security industry, and has established itself as a hub for thousands of start-up companies; to underpin these developments, Israel has developed a robust telecoms sector; household broadband subscriptions is high, with a focus on fiber-network deployment; LTE services are almost universally available, while the August 2020 multi-frequency bands also enabled the MNOs to provide services based on 5G; 5G will be supported by moves to close down GSM and 3G networks in stages through to the end of 2025, with the physical assets and frequencies to be repurposed for LTE and 5G use (2023)
domestic:
fixed-line nearly 39 per 100 and nearly 140 per 100 for mobile-cellular subscriptions (2021)
international:
country code - 972; landing points for the MedNautilus Submarine System, Tameres North, Jonah and Lev Submarine System, submarine cables that provide links to Europe, Cyprus, and parts of the Middle East; satellite earth stations - 3 Intelsat (2 Atlantic Ocean and 1 Indian Ocean) (2019)
Broadcast media:
the Israel Broadcasting Corporation (est 2015) broadcasts on 3 channels, two in Hebrew and the other in Arabic; multi- channel satellite and cable TV packages provide access to foreign channels; the Israeli Broadcasting Corporation broadcasts on 8 radio networks with multiple repeaters and Israel Defense Forces Radio broadcasts over multiple stations; about 15 privately owned radio stations; overall more than 100 stations and repeater stations (2019)
Internet country code:
.il
Internet users:
total:
8.01 million (2021 est.)
percent of population:
90% (2021 est.)
comparison ranking:
total 74
Broadband - fixed subscriptions:
total:
2,602,079 (2020 est.)
subscriptions per 100 inhabitants:
30 (2020 est.)
comparison ranking:
total 50','b42eff4e9e7d87f56ced6fc3ef3969ba5c61b18c9d4fcd833e16a8f59f4b03bb','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ae3c8945c396b70312b588f087ea1fe12b051419f1a3d8eb729959b4fcb02d36',2025,'IT','Italy','communications',57,'Telephones - fixed lines:
total subscriptions: 19,994,902 (2021 est.)
subscriptions per 100 inhabitants:
34 (2021 est.)
comparison ranking:
total subscriptions 13
Telephones - mobile cellular:
total subscriptions: 78,114,933 (2021 est.)
subscriptions per 100 inhabitants:
132 (2021 est.)
comparison ranking:
total subscriptions 21
Telecommunication systems:
general assessment: Italy’s large telecom market has one of the most progressive fiber sectors in Europe, with regulatory measures encouraging network sharing; regulatory measures have also been introduced to facilitate access to next generation networks (NGNs), and a number of deals have been brokered which enable the main telcoms to provide bundled services to large numbers of the population; Italy’s vibrant mobile market has one of the highest subscription rates in Europe, though the number of subscribers has fallen in recent years as customers respond to attractive off-net pricing which has reduced the financial benefit of having SIM cards from different providers; network companies were among the first in Europe to trial services based on 5G; the high cost also encouraged the regulator in early 2021 to consider extending the licenses by an additional six years (2021)
domestic:
34 per 100 for fixed-line and nearly 132 per 100 for mobile-cellular subscriptions (2021)
international:
country code - 39; landing points for Italy-Monaco, Italy-Libya, Italy-Malta, Italy-Greece-1, Italy-Croatia, BlueMed, Janna, FEA, SeaMeWe-3 & 4 & 5, Trapani-Kelibia, Columbus-III, Didon, GO-1, HANNIBAL System, MENA, Bridge International, Malta-Italy Interconnector, Melita1, IMEWE, VMSCS, AAE-1, and OTEGLOBE, submarine cables that provide links to Asia, the Middle East, Europe, North Africa, Southeast Asia, Australia and US; satellite earth stations - 3 Intelsat (with a total of 5 antennas - 3 for Atlantic Ocean and 2 for Indian Ocean) (2019)
Broadcast media:
two Italian media giants dominate with 3 national terrestrial stations and privately owned companies with 3 national terrestrial stations; a large number of private stations, a satellite TV network; 3 AM/FM nationwide radio stations; about 1,300 commercial radio stations
Internet country code:
.it
Internet users:
total:
44.25 million (2021 est.)
percent of population:
75% (2021 est.)
comparison ranking:
total 22
Broadband - fixed subscriptions:
total:
18,128,787 (2020 est.)
subscriptions per 100 inhabitants:
30 (2020 est.)
comparison ranking:
total 12','95308f36beef71d74cc3567a9b864ea0a59b6cb747d9338fdece54c878fe6014','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('64d0b701f3047a6aae26a8cb7ab4e14a75e9ee1f28bb9e1cc69658f9d47f9d59',2025,'JM','Jamaica','communications',8,'Telephones - fixed lines:
total subscriptions:
473,617 (2021 est.)
subscriptions per 100 inhabitants:
17 (2021 est.)
comparison ranking:
total subscriptions 95
Telephones - mobile cellular:
total subscriptions:
2,905,408 (2021 est.)
subscriptions per 100 inhabitants:
103 (2021 est.)
comparison ranking:
total subscriptions 142
Telecommunication systems:
general assessment:
Jamaica’s telecom sector has for many years been propped up by the mobile sector, which accounts for the vast majority of internet connections and voice lines; it also accounts for just over half of telecom sector revenue; in December 2020, the government announced the rollout of a national broadband network costing up to $237 million; the funding will be spent on improving connectivity in under served areas, improving access to education, and deploying networks to public locations such as hospitals, municipal institutions, and police stations; to aid in this national broadband effort, the government received a donation of 650km of fiber cabling from local cable TV providers and the two main toll road operators; to encourage the use of digital channels as the country deals with the Covid-19 pandemic (2021)
domestic:
fixed-line subscriptions nearly 17 per 100, cellular-mobile roughly 103 per 100 subscriptions (2021)
international:
country code - 1-876 and 1-658; landing points for the ALBA-1, CFX-1, Fibralink, East-West, and Cayman-Jamaican Fiber System submarine cables providing connections to South America, parts of the Caribbean, Central America and the US; satellite earth stations - 2 Intelsat (Atlantic Ocean) (2019)
Broadcast media:
3 free-to-air TV stations, subscription cable services, and roughly 30 radio stations (2019)
Internet country code:
.jm
Internet users:
total:
2.296 million (2021 est.)
percent of population:
82% (2021 est.)
comparison ranking:
total 131
Broadband - fixed subscriptions:
total:
385,603 (2020 est.)
subscriptions per 100 inhabitants:
13 (2020 est.)
comparison ranking:
total 99','aafd7759a06ab7f3116182cf79f7078402185fd8f4dfeda4afdbf188438ca727','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e01f241cf53aa89819a730c7ccb250e517553613ef200c37fb15696148510939',2025,'JM','Jamaica','communications',17,'Broadcast media:
a coastal radio station has been remotely operated since 1994','97d5986107ee14643c87defab2081aaa9bef50d1fee6f0226eec05d2dcb642cd','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('50f3435310e4fea1f10aa3ba02a2e55120216b9e1c21ccedb65496a04e4ef47b',2025,'JP','Japan','communications',28,'Telephones - fixed lines:
total subscriptions:
61,583,600 (2021 est.)
subscriptions per 100 inhabitants:
49 (2021 est.)
comparison ranking:
total subscriptions 3
Telephones - mobile cellular:
total subscriptions:
200,478,808 (2021 est.)
subscriptions per 100 inhabitants:
161 (2021 est.)
comparison ranking:
total subscriptions 7
Telecommunication systems:
general assessment:
Japan has one of the best developed telecom markets globally, the fixed-line segment remains stagnant and the focus for growth is in the mobile sector; the MNOs have shifted their investment from LTE to 5G, and growth in 5G showed early promise although there have been recent setbacks; these have partly been attributed to the economic difficulties, the impact of restrictions imposed during the pandemic, and unfavorable investment climate (not helped by the delay of the Tokyo Olympics from 2020 to 2021), and to restrictions in the supply of 5G-enabled devices; the fixed broadband market is dominated by fiber, with a strong cable platform also evident; fiber will continue to increase its share of the fixed broadband market, largely at the expense of DSL; the mobile market is dominated by three MNOs, mobile broadband subscriber growth is expected to be relatively low over the next five years, partly due to the high existing subscriptions though growth has been stimulated by measures which have encouraged people to school and work from home; there has also been a boost in accessing entertainment via mobile devices since 2020 (2021)
domestic:
49 per 100 for fixed-line and 161 per 100 for mobile-cellular subscriptions (2021)
international:
country code - 81; numerous submarine cables with landing points for HSCS, JIH, RJCN, APCN-2, JUS, EAC-C2C, PC-1, Tata TGN-Pacific, FLAG North Asia Loop/REACH North Asia Loop, APCN-2, FASTER, SJC, SJC2, Unity/EAC-Pacific, JGA-N, APG, ASE, AJC, JUPITER, MOC, Okinawa Cellular Cable, KJCN, GOKI, KJCN, and SeaMeWE-3, submarine cables provide links throughout Asia, Australia, the Middle East, Europe, Southeast Asia, Africa and US; satellite earth stations - 7 Intelsat (Pacific and Indian Oceans), 1 Intersputnik (Indian Ocean region), 2 Inmarsat (Pacific and Indian Ocean regions), and 8 SkyPerfect JSAT (2019)
Broadcast media:
a mixture of public and commercial broadcast TV and radio stations; 6 national terrestrial TV networks including 1 public broadcaster; the large number of radio and TV stations available provide a wide range of choices; satellite and cable services provide access to international channels (2019)
Internet country code:
.jp
Internet users:
total:
99.6 million (2021 est.)
percent of population:
83% (2021 est.)
comparison ranking:
total 8
Broadband - fixed subscriptions:
total:
44,000,791 (2020 est.)
subscriptions per 100 inhabitants:
35 (2020 est.)
comparison ranking:
total 3','5c44c14bebc5a1f4f7cb49de8d57a06b8024e691ebed8e10f15e1582585994cf','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3b68b929f569f3a61eb1753c52872ffc0befacfe234dbaa8acdcbf07256ca590',2025,'JE','Jersey','communications',40,'Telephones - fixed lines:
total subscriptions:
48,122 (2021 est.)
subscriptions per 100 inhabitants:
47 (2021 est.)
comparison ranking:
total subscriptions 158
Telephones - mobile cellular:
total subscriptions:
124,083 (2021 est.)
subscriptions per 100 inhabitants:
120 (2021 est.)
comparison ranking:
total subscriptions 189
Telecommunication systems:
general assessment:
the telecommunication services comprise of Internet, telephone, broadcasting and postal services, which allow islanders to contact people and receive information; Internet connectivity to the rest of the world is provided by undersea cables linked to Guernsey, the UK and France; (2021)
domestic:
fixed-line 47 per 100 and mobile-cellular 120 per 100 subscriptions (2021)
international:
country code - 44; landing points for the INGRID, UK-Channel Islands-8, and Guernsey-Jersey-4, submarine cable connectivity to Guernsey, the UK, and France (2019)
Broadcast media:
multiple UK terrestrial TV broadcasts are received via a transmitter in Jersey; satellite packages available; BBC Radio Jersey and 1 other radio station operating
Internet country code:
.je
Internet users:
total:
96,038 (2021 est.)
percent of population:
93% (2021 est.)
comparison ranking:
total 188
Broadband - fixed subscriptions:
total:
39,699 (2020 est.)
subscriptions per 100 inhabitants:
37 (2020 est.)
comparison ranking:
total 145','06977382ffb2aca1ddc1fa024030a287570df69a7c7047ae4b7b6072c0a84e6d','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('437370f842b7749a82f87141e3aa901550e54cbca2142aebcd6c3596626d5b6e',2025,'JO','Jordan','communications',51,'Telephones - fixed lines:
total subscriptions:
427,517 (2021 est.)
subscriptions per 100 inhabitants:
4 (2021 est.)
comparison ranking:
total subscriptions 99
Telephones - mobile cellular:
total subscriptions:
7,275,563 (2021 est.)
subscriptions per 100 inhabitants:
65 (2021 est.)
comparison ranking:
total subscriptions 108
Telecommunication systems:
general assessment:
Jordan’s government has focused on the use of ICT in a range of sectors, aimed at transforming the relatively small economy through the use of digital services; this policy has helped the country rise in the league tables for digital connectivity and internet readiness, and it has also attracted investment from foreign companies; during the ongoing global pandemic, the start-up sector has been further encouraged to develop solutions to combat the crisis, while other efforts have facilitated e-government services and encouraged businesses to adapt to new methods of working through their own digital transformation; these developments have been supported by the highly developed mobile sector, led by three major regional players which have near-comprehensive LTE network coverage (2022)
domestic:
fixed-line stands at nearly 4 per 100 persons and mobile cellular subscriptions at 65 per 100 persons (2021)
international:
country code - 962; landing point for the FEA and Taba-Aqaba submarine cable networks providing connectivity to Europe, the Middle East, Southeast Asia and Asia; satellite earth stations - 33 (3 Intelsat, 1 Arabsat, and 29 land and maritime Inmarsat terminals (2019)
Broadcast media:
radio and TV dominated by the government-owned Jordan Radio and Television Corporation (JRTV) that operates a main network, a sports network, a film network, and a satellite channel; first independent TV broadcaster aired in 2007; international satellite TV and Israeli and Syrian TV broadcasts are available; roughly 30 radio stations with JRTV operating the main government-owned station; transmissions of multiple international radio broadcasters are available
Internet country code:
.jo
Internet users:
total:
9.13 million (2021 est.)
percent of population:
83% (2021 est.)
comparison ranking:
total 64
Broadband - fixed subscriptions:
total:
630,545 (2020 est.)
subscriptions per 100 inhabitants:
6 (2020 est.)
comparison ranking:
total 85','024884e846ab7f2f01e3ef9b4c28c50866cb8a6de4625b6d4ee74e7ef3a481e5','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('14b33a27e6314d171b2cbb5b73f4c1ea5159b78c7694658a1b68a02612f3f2a1',2025,'KZ','Kazakhstan','communications',8,'Telephones - fixed lines:
total subscriptions: 2,997,400
(2021 est.)
subscriptions per 100 inhabitants:
16 (2021 est.)
comparison ranking:
total subscriptions 41
Telephones - mobile cellular:
total subscriptions: 24.323
million (2021 est.)
subscriptions per 100 inhabitants:
127 (2021 est.)
comparison ranking:
total subscriptions 52
Telecommunication systems:
general assessment: Kazakhstan
has one of the most developed telecommunications sectors in the Central Asian region; this is especially true of the mobile segment; the principal telcos have successfully generated revenue growth on the back of value-added services and the extended each of LTE and fiber networks; this has resulted in strong growth in mobile fixed line traffic; the mobile segment dominates the telecom sector in Kazakhstan overall, there was a drop in the number of subscribers in 2020; these effects also limited growth in 2021, though the easing of restrictions in 2022 resulted in a stronger recovery; the extensive deployment of LTE networks across the country, and the launch of limited 5G services in mid-2023 will provide a steady increase mobile broadband services (2021)
domestic:
fixed telephone subscriptions are 16 per 100 persons; mobile-cellular subscriber base 127 per 100 persons (2021)
international:
country code - 7; international traffic with other former Soviet republics and China carried by landline and microwave radio relay and with other countries by satellite and by the TAE fiber-optic cable; satellite earth stations - 2 Intelsat
Broadcast media:
the state owns nearly all radio and TV transmission facilities and operates national TV and radio networks; there are 96 TV channels, many of which are owned by the government, and 4 state-run radio stations; some former state-owned media outlets have been privatized; households with satellite dishes have access to foreign media; a small number of commercial radio stations operate along with state-run radio stations; recent legislation requires all media outlets to register with the government and all TV providers to broadcast in digital format by 2018; broadcasts reach some 99% of the population as well as neighboring countries (2018)
Internet country code:
.kz
Internet users:
total: 17.29
million (2021 est.)
percent of population:
91% (2021 est.)
comparison ranking:
total 44
Broadband - fixed subscriptions:
total: 2,620,400
(2020 est.)
subscriptions per 100 inhabitants:
14 (2020 est.)
comparison ranking:
total 48','73227533f8c87100d57f7d5eb475283ae3de663a702ef089881c7a6ef12888c5','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e83bcddf27c7d2cf763622b69809cf5a7720c49c415fa2a6e38088e3f075dd25',2025,'KE','Kenya','communications',20,'Telephones - fixed lines:
total subscriptions: 61,096
(2021 est.)
subscriptions per 100 inhabitants:
(2021 est.) less than 1
comparison ranking:
total subscriptions 148
Telephones - mobile cellular:
total subscriptions: 65,085,720
(2021 est.)
subscriptions per 100 inhabitants:
123 (2021 est.)
comparison ranking:
total subscriptions 26
Telecommunication systems:
general assessment: Kenya’s
telecom market continues to undergo considerable changes in the wake of increased competition, improved international connectivity, and rapid developments in the mobile market; the country is directly connected to a number of submarine cables, and with Mombasa through a terrestrial network, the country serves as a key junction for onward connectivity to the Arabian states and the Far East; numerous competitors are rolling out national and metropolitan backbone networks and wireless access networks to deliver services to population centers across the country; several fiber infrastructure sharing agreements have been forged, and as a result the number of fiber broadband connections has increased sharply in recent years; much of the progress in the broadband segment is due to the government’s revised national broadband strategy, which has been updated with goals through to 2030, and which are largely dependent on mobile broadband platforms based on LTE and 5G (2022)
domestic:
fixed-line subscriptions stand at less than 1 per 100 persons; mobile-cellular subscriptions at 123 per 100 persons (2021)
international:
country code - 254; landing point for the EASSy, TEAMS, LION2, DARE1, PEACE Cable, and SEACOM fiber-optic submarine cable systems covering East, North and South Africa, Europe, the Middle East, and Asia; satellite earth stations - 4 Intelsat; launched first micro satellites in 2018 (2019)
Broadcast media:
about a half-dozen large-scale privately owned media companies with TV and radio stations, as well as a state-owned TV broadcaster, provide service nationwide; satellite and cable TV subscription services available; state-owned radio broadcaster operates 2 national radio channels and provides regional and local radio services in multiple languages; many private radio stations broadcast on a national level along with over 100 private and non-profit regional stations broadcasting in local languages; TV transmissions of all major international broadcasters available, mostly via paid subscriptions; direct radio frequency modulation transmissions available for several foreign government-owned broadcasters (2019)
Internet country code:
.ke
Internet users:
total: 15.37
million (2021 est.)
percent of population:
29% (2021 est.)
comparison ranking:
total 49
Broadband - fixed subscriptions:
total: 674,191
(2020 est.)
subscriptions per 100 inhabitants:
1 (2020 est.)
comparison ranking:
total 82','57c2699a265f598391e7bb7f188c2fba9ee285f7a0a20a74f1b2526a1e0b561a','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3f168c01707b3c6f7589516f6ffdd8705c06b64527cd4fa8c5f06f97ae89322e',2025,'KI','Kiribati','communications',33,'Telephones - fixed lines:
total subscriptions: 10
(2021 est.)
subscriptions per 100 inhabitants:
(2021 est.) less than 1
comparison ranking:
total subscriptions 222
Telephones - mobile cellular:
total subscriptions: 54,527
(2021 est.)
subscriptions per 100 inhabitants:
42 (2021 est.)
comparison ranking:
total subscriptions 206
Telecommunication systems:
general assessment: generally
good national and international service; wireline service available on Tarawa and Kiritimati (Christmas Island); connections to outer islands by HF/VHF radiotelephone; recently formed (mobile network operator) MNO is implementing the first phase of improvements with 3G and 4G upgrades on some islands; islands are connected to each other and the rest of the world via satellite; launch of Kacific-1 in December 2019 will improve telecommunication for Kiribati (2020)
domestic:
fixed-line less than 1 per 100 and mobile-cellular approximately 42 per 100 subscriptions (2021)
international:
country code - 686; landing point for the Southern Cross NEXT submarine cable system from Australia, 7 Pacific Ocean island countries to the US; satellite earth station - 1 Intelsat (Pacific Ocean) (2019)
Broadcast media:
multi-channel TV packages provide access to Australian and US stations; 1 government-operated radio station broadcasts on AM, FM, and shortwave (2017)
Internet country code:
.ki
Internet users:
total: 70,200
(2021 est.)
percent of population:
54% (2021 est.)
comparison ranking:
total 195
Broadband - fixed subscriptions:
total: 185
(2020 est.)
subscriptions per 100 inhabitants:
0.2 (2020 est.)
comparison ranking:
total 213','bd682a518377905fc7ab896848dcbc73a1fac43c4cec5bf1bbffc3cf034a941f','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4a5706c606e84725362d0b6f8d1d346250781641df09d406f57dba9349c0a1e3',2025,'KI','Kiribati','communications',44,'Telephones - fixed lines:
total subscriptions: 1.2
million (2021 est.)
subscriptions per 100 inhabitants:
5 (2021 est.)
comparison ranking:
total subscriptions 67
Telephones - mobile cellular:
total subscriptions: 6
million (2021 est.)
subscriptions per 100 inhabitants:
23 (2021 est.)
comparison ranking:
total subscriptions 118
Telecommunication systems:
general assessment: despite
years of isolationism, economic under-achievement, and international sanctions, North Korea has improved its telecommunications infrastructure in the last decade; Inconsistent electric power supply and likely difficulties procuring new hardware, however, present enduring obstacles to building reliable high-speed telecom networks; mobile phone use is estimated to have increased to nearly 25% of the polulation as of 2018, yet the high cost of ownership makes mobile communications inaccessible to North Koreans of lower socioeconomic status; strict regime censorship and monitoring of telecom systems in North Korea restricts users from legally contacting anyone outside the country or accessing the global Internet; for those citizens living close to China, it has been possible to illegally obtain Chinese handsets and SIM cards, and to connect to towers located just across the border; while this offers access to the outside world and at much lower prices than the state-controlled offerings, the risks are high including steep fines and the possibility of jail time; North Korea has been effective in building an IT sector and a nascent digital economy on the back of a concerted effort to grow a sizeable, well-trained IT workforce; but even here, its capabilities have been directed more towards nefarious activities such as cyber crime and hacking into foreign countries’ computer and financial systems; North Korea’s determination to maintain ideological control of its populace by isolating itself from the rest of the world will probably lead to tighter controls on communications inside and outside of the country (2023)
domestic:
fixed-lines are approximately 5 per 100 and mobile-cellular 23 per 100 persons (2021)
international:
country code - 850; satellite earth stations - 2 (1 Intelsat - Indian Ocean, 1 Russian - Indian Ocean region); other international connections through Moscow and Beijing
Broadcast media:
no independent media; radios and TVs are pre-tuned to government stations; 4 government-owned TV stations; the Korean Workers’ Party owns and operates the Korean Central Broadcasting Station, and the state-run Voice of Korea operates an external broadcast service; the government prohibits listening to and jams foreign broadcasts (2019)
Internet country code:
.kp','58a7e497cefb964ff82ef9360c5194888ec8ab1370c16fe5d84229d66a8e1787','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d9c47826a81a627c61d7266156eae2f7cc17ba56ce8f6683a4944377738a89db',2025,'KW','Kuwait','communications',12,'Telephones - fixed lines:
total subscriptions: 580,000
(2020 est.)
subscriptions per 100 inhabitants:
13 (2020 est.)
comparison ranking:
total subscriptions 86
Telephones - mobile cellular:
total subscriptions: 6,918,180
(2021 est.)
subscriptions per 100 inhabitants:
163 (2021 est.)
comparison ranking:
total subscriptions 111
Telecommunication systems:
general assessment: Kuwait’s
telecom infrastructure is well developed, with a focus on mobile infrastructure and services; the telecom sector is important to the country’s economy, and this will become more pronounced in coming years as the economy is purposefully transitioned away from a dependence on oil and gas to one which is increasingly knowledge-based and focused on ICT and related services; the MNOs have focused investment on 5G networks, which support and promote the growth of data traffic; this in turn has been a catalyst for revenue growth in recent quarters; while Kuwait’s mobile sector shows considerable progress; the country’s fixed broadband system is the lowest in the region; the government has stepped up efforts to build up fixed broadband networks, and ultimately this sector offers a potential future growth opportunity; improvements to the fixed broadband infrastructure will help develop sectors such as e-commerce, along with smart infrastructure developments, and tech start-ups (2022)
domestic:
fixed-line subscriptions are nearly 13 per 100 and mobile-cellular stands at nearly 163 per 100 subscriptions (2021)
international:
country code - 965; landing points for the FOG, GBICS, MENA, Kuwait-Iran, and FALCON submarine cables linking Africa, the Middle East, and Asia; microwave radio relay to Saudi Arabia; satellite earth stations - 6 (3 Intelsat - 1 Atlantic Ocean and 2 Indian Ocean, 1 Inmarsat - Atlantic Ocean, and 2 Arabsat) (2019)
Broadcast media:
state-owned TV broadcaster operates 4 networks and a satellite channel; several private TV broadcasters have emerged; satellite TV available and pan-Arab TV stations are especially popular; state-owned Radio Kuwait broadcasts on a number of channels in Arabic and English; first private radio station emerged in 2005; transmissions of at least 2 international radio broadcasters are available (2019)
Internet country code:
.kw
Internet users:
total: 4.3
million (2021 est.)
percent of population:
100% (2021 est.)
comparison ranking:
total 106
Broadband - fixed subscriptions:
total: 73,948
(2020 est.)
subscriptions per 100 inhabitants:
2 (2020 est.)
comparison ranking:
total 133','569498e10abb2aace4198ac844a01d65b282187033a0bb76d4ee088021bf1445','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('14d5467068a37c63f945dfa1b556316aac64c128cbb5267f55f71426d70c3c09',2025,'KG','Kyrgyzstan','communications',23,'Telephones - fixed lines:
total subscriptions: 300,000
(2021 est.)
subscriptions per 100 inhabitants:
5 (2021 est.)
comparison ranking:
total subscriptions 110
Telephones - mobile cellular:
total subscriptions: 8.5
million (2021 est.)
subscriptions per 100 inhabitants:
130 (2021 est.)
comparison ranking:
total subscriptions 98
Telecommunication systems:
general assessment: the
country’s telecom sector (specifically the mobile segment) has been able to prosper; Kyrgyzstan has opened up its telecom market to competition; the mobile market has achieved high levels of penetration (140% in 2021) along with a fairly competitive operating environment with four major players; mobile broadband has come along strongly, reaching over 125% penetration in 2019 before falling back slightly during the Covid-19 crisis; slow-to-moderate growth is expected for both segments in coming years, supported by the anticipated rollout of 5G services which began testing in 2022 with a pilot service to follow some time in 2023 (2022)
domestic:
fixed-line subscriptions 5 per 100; mobile-cellular subscribership up to over 130 per 100 persons (2021)
international:
country code - 996; connections with other CIS (Commonwealth of Independent States, 9 members post-Soviet Republics in EU) countries by landline or microwave radio relay and with other countries by leased connections with Moscow international gateway switch and by satellite; satellite earth stations - 2 (1 Intersputnik, 1 Intelsat) (2019)
Broadcast media:
state-funded public TV broadcaster KTRK has nationwide coverage; also operates Ala-Too 24 news channel which broadcasts 24/7 and 4 other educational, cultural, and sports channels; ELTR and Channel 5 are state-owned stations with national reach; the switchover to digital TV in 2017 resulted in private TV station growth; approximately 20 stations are struggling to increase their own content up to 50% of airtime, as required by law, instead of rebroadcasting primarily programs from Russian channels or airing unlicensed movies and music; 3 Russian TV stations also broadcast; state-funded radio stations and about 10 significant private radio stations also exist (2019)
Internet country code:
.kg
Internet users:
total: 5.07
million (2021 est.)
percent of population:
78% (2021 est.)
comparison ranking:
total 92
Broadband - fixed subscriptions:
total: 289,000
(2020 est.)
subscriptions per 100 inhabitants:
4 (2020 est.)
comparison ranking:
total 109','81bc632f999b4a686118b94946477c8f6970c35ebf90f977662f534e455938bd','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ca770cc3860ee6576c4b1da217d7e0e2cadd00cc0cf5586aa13a61876b7de90d',2025,'LV','Latvia','communications',10,'Telephones - fixed lines:
total subscriptions:
191,798 (2021 est.)
subscriptions per 100 inhabitants:
10 (2021 est.)
comparison ranking:
total subscriptions 123
Telephones - mobile cellular:
total subscriptions:
2,161,725 (2021 est.)
subscriptions per 100 inhabitants:
115 (2021 est.)
comparison ranking:
total subscriptions 148
Telecommunication systems:
general assessment:
the telecom market continues to benefit from investment and from regulatory measures aimed at developing 5G and fiber-based infrastructure; there is effective competition in the mobile market; these multi-service operators have focused investment on fiber networks and on expanding the reach of 5G (2023)
domestic:
fixed-line roughly 10 per 100 and mobile-cellular nearly 115 per 100 subscriptions (2021)
international:
country code - 371; the Latvian network is now connected via fiber-optic cable to Estonia, Finland, and Sweden
Broadcast media:
several national and regional commercial TV stations are foreign-owned, 2 national TV stations are publicly owned; system supplemented by privately owned regional and local TV stations; cable and satellite multi-channel TV services with domestic and foreign broadcasts available; publicly owned broadcaster operates 4 radio networks with dozens of stations throughout the country; dozens of private broadcasters also operate radio stations
Internet country code:
.lv
Internet users:
total:
1.729 million (2021 est.)
percent of population:
91% (2021 est.)
comparison ranking:
total 141
Broadband - fixed subscriptions:
total:
490,569 (2020 est.)
subscriptions per 100 inhabitants:
26 (2020 est.)
comparison ranking:
total 92','4671f387f4feddd71ac1fcdece0f377c5498fd22e648dfc934887b3e4c916ae5','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('431f0732a74207d1b83814452768f215b05b4c3ffb228e92245783f19aebddb8',2025,'LB','Lebanon','communications',21,'Telephones - fixed lines:
total subscriptions:
880,000 (2021 est.)
subscriptions per 100 inhabitants:
16 (2021 est.)
comparison ranking:
total subscriptions 73
Telephones - mobile cellular:
total subscriptions:
4.3 million (2021 est.)
subscriptions per 100 inhabitants:
77 (2021 est.)
comparison ranking:
total subscriptions 129
Telecommunication systems:
general assessment:
Lebanon’s economic crisis has had a dire effect on the country’s telecom services; although some progress has been made with developing 5G, the poor economic conditions have contributed to an erratic electricity supply and a lack of fuel to maintain generators; this has meant that internet services to areas of the country are not available on a regular basis, frustrating all those who depend on stable connectivity, and stalling business growth; adding to the difficulties is the political crisis; the cabinet went into caretaker status after the National Assembly election in May 2022 meaning it can only engage in routine decision making; there is little confidence on the ground that sectarian-based political horse-trading will give way to responsible governing to improve the lot of the stressed populace (2023)
domestic:
fixed-line is 16 per 100 and 77 per 100 for mobile-cellular subscriptions (2021)
international:
country code - 961; landing points for the IMEWE, BERYTAR AND CADMOS submarine cable links to Europe, Africa, the Middle East and Asia; satellite earth stations - 2 Intelsat (1 Indian Ocean and 1 Atlantic Ocean) (2019)
Broadcast media:
7 TV stations, 1 of which is state owned; more than 30 radio stations, 1 of which is state owned; satellite and cable TV services available; transmissions of at least 2 international broadcasters are accessible through partner stations (2019)
Internet country code:
.lb
Internet users:
total:
4.872 million (2021 est.)
percent of population:
87% (2021 est.)
comparison ranking:
total 95
Broadband - fixed subscriptions:
total:
432,070 (2020 est.)
subscriptions per 100 inhabitants:
6 (2020 est.)
comparison ranking:
total 94','7c7a94af370e25bc1e903e4717df36bd1b46d1883c7a70160640e1477e019797','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7891301f42566a275bdd6a4f28a23a880583755788205cf21cd648bb5d91132b',2025,'LS','Lesotho','communications',33,'Telephones - fixed lines:
total subscriptions:
9,559 (2021 est.)
subscriptions per 100 inhabitants:
(2021 est.) less than 1
comparison ranking:
total subscriptions 192
Telephones - mobile cellular:
total subscriptions:
1,821,374 (2021 est.)
subscriptions per 100 inhabitants:
80 (2021 est.)
comparison ranking:
total subscriptions 154
Telecommunication systems:
general assessment:
until late 2020, Lesotho’s telecom regulator maintained a market duopoly which is focused on fixed-line services; competition was insufficient to promote effective price reductions for consumers, while the regulator had no mechanisms in place to monitor the telcos to ensure quality of service and fair pricing for consumers; the small size of the country’s population provided little incentive for new players to enter the market; a positive outcome for consumers was the deployment in early 2021 of a service to monitor traffic and billing; this ended the practice whereby the regulator was dependent on telcos submitting data about their performance, billing, and other matters; the regulator has also turned its attention to addressing multiple SIM ownership and stem incidences of crimes committed using unregistered SIMs; in May 2022, it instructed the country’s MNOs to begin registering SIM cards on their networks from the following month; fixed-wireless 5G trials began in early 2019 (2022)
domestic:
fixed-line is less than 1 per 100 subscriptions; mobile-cellular service subscribership is 80 per 100 persons (2021)
international:
country code - 266; Internet accessibility has improved with several submarine fiber optic cables that land on African east and west coasts, but the country’s land locked position makes access prices expensive; satellite earth station - 1 Intelsat (Atlantic Ocean) (2019)
Broadcast media:
1 state-owned TV station and 2 state-owned radio stations; government controls most private broadcast media; satellite TV subscription service available; transmissions of multiple international broadcasters obtainable (2019)
Internet country code:
.ls
Internet users:
total:
1.104 million (2021 est.)
percent of population:
48% (2021 est.)
comparison ranking:
total 148
Broadband - fixed subscriptions:
total:
5,060 (2020 est.)
subscriptions per 100 inhabitants:
0.2 (2020 est.)
comparison ranking:
total 185','0fbace4f71a2b72f8955f156568da39e63865253b19ce3edd13f80fbb3a14a49','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c7b85457dfb9dae255ea4c0d56a5a3972b171746baf93f0e3d8e09959f81d80f',2025,'LR','Liberia','communications',44,'Telephones - fixed lines:
total subscriptions:
6,000 (2021 est.)
subscriptions per 100 inhabitants:
(2021 est.) less than 1
comparison ranking:
total subscriptions 203
Telephones - mobile cellular:
total subscriptions:
1.7 million (2021 est.)
subscriptions per 100 inhabitants:
32 (2021 est.)
comparison ranking:
total subscriptions 158
Telecommunication systems:
general assessment:
Liberia has a telecom market which is mainly based on mobile networks; this is due to the civil war which destroyed much of the fixed-line infrastructure; to facilitate LTC Mobile’s market entry, the government in January 2022 set in train amendments to telecom legislation; internet services are available from a number of wireless ISPs as well as the mobile operators; the high cost and limited bandwidth of connections means that internet access is expensive and rates are very low; additional bandwidth is available from an international submarine cable but considerable investment is still needed in domestic fixed-line infrastructure before end-users can make full use of the cable (2022)
domestic:
fixed-line less than 1 per 100; mobile-cellular subscriptions are 32 per 100 persons (2021)
international:
country code - 231; landing point for the ACE submarine cable linking 20 West African countries and Europe; satellite earth station - 1 Intelsat (Atlantic Ocean) (2019)
Broadcast media:
8 private and 1 government-owned TV station; satellite TV service available; 1 state-owned radio station; approximately 20 independent radio stations broadcasting in Monrovia, with approximately 80 more local stations operating in other areas; transmissions of 4 international (including the British Broadcasting Corporation and Radio France Internationale) broadcasters are available (2019)
Internet country code:
.lr
Internet users:
total:
1.768 million (2021 est.)
percent of population:
34% (2021 est.)
comparison ranking:
total 138
Broadband - fixed subscriptions:
total:
13,000 (2020 est.)
subscriptions per 100 inhabitants:
0.3 (2020 est.)
comparison ranking:
total 175','fe4d0c07613197bd095b4eb9a83494bb260d42ffa052e4e5335956ff168e0c9c','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d04c4b64e064ee307132851926be7ee01db26e136ec9750f2ceb84a4fa6a436c',2025,'LY','Libya','communications',8,'Telephones - fixed lines:
total subscriptions:
1.6 million (2021 est.)
subscriptions per 100 inhabitants:
23 (2021 est.)
comparison ranking:
total subscriptions 59
Telephones - mobile cellular:
total subscriptions:
2.9 million (2021 est.)
subscriptions per 100 inhabitants:
43 (2021 est.)
comparison ranking:
total subscriptions 143
Telecommunication systems:
general assessment:
political and security instability in Libya has disrupted its telecom sector; much of its infrastructure remains superior to that in most other African countries; rival operators fight for control; investment in fiber backbone and upgrades to international cables; limited LTE and 5G service; some satellite broadband; in 2021 Libya signed deals and projects with US firms to upgrade portions of its infrastructure, increasing the diversity of its telecommunications networks (2022)
domestic:
nearly 23 per 100 fixed-line and over 43 per 100 mobile-cellular subscriptions; service generally adequate (2021)
international:
country code - 218; landing points for LFON, EIG, Italy-Libya, Silphium and Tobrok-Emasaed submarine cable system connecting Europe, Africa, the Middle East and Asia; satellite earth stations - 4 Intelsat, Arabsat, and Intersputnik; microwave radio relay to Tunisia and Egypt; tropospheric scatter to Greece; participant in Medarabtel (2019)
Broadcast media:
state-funded and private TV stations; some provinces operate local TV stations; pan-Arab satellite TV stations are available; state-funded radio (2019)
Internet country code:
.ly
Internet users:
total:
3,095,400 (2021 est.)
percent of population:
46.2% (2021 est.)
comparison ranking:
total 117
Broadband - fixed subscriptions:
total:
332,000 (2020 est.)
subscriptions per 100 inhabitants:
5 (2020 est.)
comparison ranking:
total 104','6b57cf8ca3d0e103650b91190be3e5163ac8f2f2afba24b50693c72c717b3fc0','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5cc99e2f5ac7d974c33159e9e15635290f590610ceb709ac49ce19f32143404a',2025,'LI','Liechtenstein','communications',20,'Telephones - fixed lines:
total subscriptions:
11,712 (2021 est.)
subscriptions per 100 inhabitants:
30 (2021 est.)
comparison ranking:
total subscriptions 186
Telephones - mobile cellular:
total subscriptions:
49,264 (2021 est.)
subscriptions per 100 inhabitants:
126 (2021 est.)
comparison ranking:
total subscriptions 207
Telecommunication systems:
general assessment:
possesses a number of modern communications systems, some of which are shared with the neighboring country of Switzerland (2022)
domestic:
fixed-line roughly 30 per 100 and mobile-cellular services 126 per 100 (2021)
international:
country code - 423; linked to Swiss networks by cable and microwave radio relay
Broadcast media:
relies on foreign terrestrial and satellite broadcasters for most broadcast media services; first Liechtenstein-based TV station established August 2008; Radio Liechtenstein operates multiple radio stations; a Swiss-based broadcaster operates one radio station in Liechtenstein
Internet country code:
.li
Internet users:
total:
37,440 (2021 est.)
percent of population:
96% (2021 est.)
comparison ranking:
total 206
Broadband - fixed subscriptions:
total:
18,050 (2020 est.)
subscriptions per 100 inhabitants:
47 (2020 est.)
comparison ranking:
total 170','3cb6ba978de824647fe318319b361e864372ccddc954e2bc4d02aabe86e60e21','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b816cb20b64efd0f6caac95c6d4c194fd2ac8f18027b98bfcee89e6466e3706d',2025,'LT','Lithuania','communications',31,'Telephones - fixed lines:
total subscriptions:
290,711 (2021 est.)
subscriptions per 100 inhabitants:
10 (2021 est.)
comparison ranking:
total subscriptions 112
Telephones - mobile cellular:
total subscriptions:
3,726,653 (2021 est.)
subscriptions per 100 inhabitants:
134 (2021 est.)
comparison ranking:
total subscriptions 136
Telecommunication systems:
general assessment:
Lithuania’s small telecoms market is among the more advanced in Europe, particularly given the universal access to LTE infrastructure and the extensive fiber footprint; investment has been focused on fiber broadband and mobile network upgrades; SIM card penetration is relatively high for the region, with a growing proportion of subscribers being on higher-Average Revenue Per User (ARPU) contract plans; while LTE services are available nationally, operators have made steady investments in 5G; the regulator has helped the network operators to develop 5G by allowing them to repurpose spectrum in the 2.1GHz and 2.4GHz bands; the regulator in mid-2022 completed auctions of spectrum in the 700MHz and 3.4GHz bands; service obligations on the licensees include the provision of services to the five main cities by the end of 2023 (2023)
domestic:
nearly 10 per 100 for fixed-line subscriptions; mobile-cellular subscriptions at 134 per 100 persons (2021)
international:
country code - 370; landing points for the BCS East, BCS East-West Interlink and NordBalt connecting Lithuania to Sweden, and Latvia ; further transmission by satellite; landline connections to Latvia and Poland (2019)
Broadcast media:
public broadcaster operates 3 channels with the third channel - a satellite channel - introduced in 2007; various privately owned commercial TV broadcasters operate national and multiple regional channels; many privately owned local TV stations; multi-channel cable and satellite TV services available; publicly owned broadcaster operates 3 radio networks; many privately owned commercial broadcasters, with repeater stations in various regions throughout the country
Internet country code:
.lt
Internet users:
total:
2.436 million (2021 est.)
percent of population:
87% (2021 est.)
comparison ranking:
total 130
Broadband - fixed subscriptions:
total:
796,814 (2020 est.)
subscriptions per 100 inhabitants:
29 (2020 est.)
comparison ranking:
total 77','909e13baeaef11179bf05e27536b9502228e3a1b6f9263ed2f02e76f5fa76219','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('21ac19c243f2efe990a64026c531604332c4528291ade4e5cdf161b960244683',2025,'LU','Luxembourg','communications',43,'Telephones - fixed lines:
total subscriptions:
270,000 (2021 est.)
subscriptions per 100 inhabitants:
42 (2021 est.)
comparison ranking:
total subscriptions 113
Telephones - mobile cellular:
total subscriptions:
880,000 (2021 est.)
subscriptions per 100 inhabitants:
140 (2021 est.)
comparison ranking:
total subscriptions 165
Telecommunication systems:
general assessment:
Luxembourg has a small telecom sector; there remains some pressure from regulatory measures, though no further reductions to fixed and mobile interconnection tariffs have been imposed through to 2024; high mobile penetration has slowed subscriber growth in the mobile market since 2005, though a recent law requiring SIM card registration has not had an adverse effect on the number of mobile subscribers despite network operators deactivating unregistered cards (2021)
domestic:
fixed-line teledensity about 42 per 100 persons; 140 per 100 mobile-cellular subscriptions (2021)
international:
country code - 352
Broadcast media:
Luxembourg has a long tradition of operating radio and TV services for pan-European audiences and is home to Europe’s largest privately owned broadcast media group, the RTL Group, which operates 46 TV stations and 29 radio stations in Europe; also home to Europe’s largest satellite operator, Societe Europeenne des Satellites (SES); domestically, the RTL Group operates TV and radio networks; other domestic private radio and TV operators and French and German stations available; satellite and cable TV services available
Internet country code:
.lu
Internet users:
total:
633,600 (2021 est.)
percent of population:
99% (2021 est.)
comparison ranking:
total 163
Broadband - fixed subscriptions:
total:
235,155 (2020 est.)
subscriptions per 100 inhabitants:
38 (2020 est.)
comparison ranking:
total 113','604cc5eb2e2a6cd0142a226830c7b29cc648d8ebd3449bb77527ec3e156acaa7','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9517d9e68fde219d7dda88bab73da644f12e425154d923320b88c9e3677b23c8',2025,'MG','Madagascar','communications',10,'Telephones - fixed lines:
total subscriptions:
26,271 (2021 est.)
subscriptions per 100 inhabitants:
(2021 est.) less than 1
comparison ranking:
total subscriptions 169
Telephones - mobile cellular:
total subscriptions:
16,279,633 (2021 est.)
subscriptions per 100 inhabitants:
56 (2021 est.)
comparison ranking:
total subscriptions 68
Telecommunication systems:
general assessment:
telecom services in Madagascar have benefited from intensifying competition between the main operators; there have been positive developments with the country’s link to international submarine cables, particularly the METISS cable connecting to South Africa and Mauritius; in addition, the country’s connection to the Africa-1 cable, expected in late 2023, will provide it with links to Kenya, Djibouti, countries in north and south Africa, as well Pakistan, the UAE, Saudi Arabia, and France; a national fiber backbone has been implemented connecting the major cities; in addition, the government has progressed with its five-year plan to develop a digital platform running to 2024; various schemes within the program have been managed by a unit within the President’s office; penetration rates in all market sectors remain below the average for the African region, and so there remains considerable growth potential; much progress was made in 2020, stimulated by the particular conditions related to the pandemic, which encouraged greater use of voice and data services (2022)
domestic:
less than 1 per 100 for fixed-line and mobile-cellular teledensity about 56 per 100 persons (2021)
international:
country code - 261; landing points for the EASSy, METISS, and LION fiber-optic submarine cable systems connecting to numerous Indian Ocean Islands, South Africa, and Eastern African countries; satellite earth stations - 2 (1 Intelsat - Indian Ocean, 1 Intersputnik - Atlantic Ocean region) (2019)
Broadcast media:
state-owned Radio Nationale Malagasy (RNM) and Television Malagasy (TVM) have an extensive national network reach; privately owned radio and TV broadcasters in cities and major towns; state-run radio dominates in rural areas; relays of 2 international broadcasters are available in Antananarivo (2019)
Internet country code:
.mg
Internet users:
total:
5.8 million (2021 est.)
percent of population:
20% (2021 est.)
comparison ranking:
total 82
Broadband - fixed subscriptions:
total:
32,000 (2020 est.)
subscriptions per 100 inhabitants:
0.1 (2020 est.)
comparison ranking:
total 151','a88c5da93334ae344b55caa083a5546c6f4c347f97418b5289b829f61cb5f470','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bee216b9bc6825cf49860c9c3847aac9cb2f88fc266da9a72b5b625a11cfbdd8',2025,'MW','Malawi','communications',21,'Telephones - fixed lines:
total subscriptions:
12,465 (2021 est.)
subscriptions per 100 inhabitants:
(2021 est.) less than 1
comparison ranking:
total subscriptions 184
Telephones - mobile cellular:
total subscriptions:
11,940,135 (2021 est.)
subscriptions per 100 inhabitants:
60 (2021 est.)
comparison ranking:
total subscriptions 83
Telecommunication systems:
general assessment:
with few resources, Malawi is one of the world’s least developed countries; there has been little investment in fixed-line telecom infrastructure, and as a result, the country’s two mobile networks Airtel Malawi and TMN provide the vast majority of connections for voice and data services; both operators have invested in LTE technologies to improve the quality of data services; the lack of market competition, together with limited international internet bandwidth, has also resulted in some of the highest prices for telecom services in the region; the government in late 2020 secured an average 80% reduction in the cost of data bundles offered by the MNOs; following continuing customer complaints, the regulator in mid-2021 ensured that costs were again reduced, this time by about a third; mobile penetration remains low in comparison to the regional average and so there are considerable opportunities for further growth, particularly in the mobile broadband sector; low penetration is partly attributed to the lack of competition, though there is the possibility that a new play come launch services by the end of 2022; the internet sector is reasonably competitive, with about 50 licensed ISPs, though the limited availability and high cost of international bandwidth has held back growth and kept broadband access prices among the highest in the region; these limitations are being addressed, with the second phase of the national fiber backbone having started in mid-2021 (2022)
domestic:
limited fixed-line subscribership less than 1 per 100 households; mobile-cellular subscribership roughly 60 per 100 households (2021)
international:
country code - 265; satellite earth stations - 2 Intelsat (1 Indian Ocean, 1 Atlantic Ocean) (2019)
Broadcast media:
radio is the main broadcast medium; privately owned Zodiak radio has the widest national broadcasting reach, followed by state-run radio; numerous private and community radio stations broadcast in cities and towns around the country; the largest TV network is government-owned, but at least 4 private TV networks broadcast in urban areas; relays of multiple international broadcasters are available (2019)
Internet country code:
.mw
Internet users:
total:
4.8 million (2021 est.)
percent of population:
24% (2021 est.)
comparison ranking:
total 99
Broadband - fixed subscriptions:
total:
12,255 (2020 est.)
subscriptions per 100 inhabitants:
0.1 (2020 est.)
comparison ranking:
total 176','00e28e225ea142b8394e434da111085987a207e3347c9623f3516afc939ac8ed','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('82e747b1eb004f5f204e10061e93e05d029d7c1ec041ee581175134282bb55cd',2025,'MY','Malaysia','communications',32,'Telephones - fixed lines:
total subscriptions:
8,247,100 (2021 est.)
subscriptions per 100 inhabitants:
25 (2021 est.)
comparison ranking:
total subscriptions 20
Telephones - mobile cellular:
total subscriptions:
47,201,700 (2021 est.)
subscriptions per 100 inhabitants:
141 (2021 est.)
comparison ranking:
total subscriptions 34
Telecommunication systems:
general assessment:
as part of a diverse range of initiatives designed to move the country from developing to developed status by 2025, Malaysia has enabled and encouraged open competition in its telecommunications market; the result is very high penetration levels in both the mobile (147%) and mobile broadband (127%) segments, and nearuniversal coverage of 4G LTE networks; steady growth is occurring as more fiber optic cable networks are being deployed around the country; consumers are the main beneficiaries of the highly competitive market; they enjoy widespread access to high-speed mobile services as well as attractive offers on bundles to keep data use up but prices low; the downside is that most of Malaysia’s MNOs and MVNOs have struggled to increase revenue in line with growth in subscriber numbers as well as demand for broadband data; while the operators have been very successful in moving a significant proportion (now over 30%) of customers from prepaid over to higher-value postpaid accounts, ARPU continues to fall year after year as a result of competitive pricing pressures; the mobile market, in particular, has become overcrowded and the government is keen to see further rationalization and consolidation with the operators; while customers will no doubt continue to enjoy high quality services at competitive rates, the new entity will be hopeful of squeezing better margins through improved economies of scale; the government’s next move is to encourage the private mobile operators to sign up to the country’s wholesale 5G network; this will develop and deploy the 5G infrastructure across the country; the government’s stated intent was to avoid duplication of networks and infrastructure, and thus reduce investment costs for the operators; to date, no MNO has agreed to the deal and are instead demanding the development of a dual wholesale network model (one that no doubt offers more flexible terms, at least in the eyes of the MNOs); Malaysia’s 5G rollout has, in effect, come to a standstill while the government tries to find a way to restart negotiations (2022)
domestic:
fixed-line roughly 25 per 100 and mobile-cellular teledensity roughly 141 per 100 persons (2021)
international:
country code - 60; landing points for BBG, FEA, SAFE, SeaMeWe-3 & 4 & 5, AAE-1, JASUKA, BDM, Dumai-Melaka Cable System, BRCS, aCe, AAG, East-West Submarine Cable System, SEAX-1, SKR1M, APCN-2, APG, BtoBe, BaSICS, and Labuan-Brunei Submarine and MCT submarine cables providing connectivity to Asia, the Middle East, Southeast Asia, Australia and Europe; satellite earth stations - 2 Intelsat (1 Indian Ocean, 1 Pacific Ocean); launch of Kacific-1 satellite in 2019 (2019)
Broadcast media:
state-owned TV broadcaster operates 2 TV networks with relays throughout the country, and the leading private commercial media group operates 4 TV stations with numerous relays throughout the country; satellite TV subscription service is available; state-owned radio broadcaster operates multiple national networks, as well as regional and local stations; many private commercial radio broadcasters and some subscription satellite radio services are available; about 55 radio stations overall (2019)
Internet country code:
.my
Internet users:
total:
32.98 million (2021 est.)
percent of population:
97% (2021 est.)
comparison ranking:
total 29
Broadband - fixed subscriptions:
total:
3,358,800 (2020 est.)
subscriptions per 100 inhabitants:
10 (2020 est.)
comparison ranking:
total 43','c2c2ca8d5461c72ff381d271c8ea860645e9a4d2ef5b40662178d0d75dc24229','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c77c1fed49de7b00d9a0426510bf12bf1d25777ddf23f99f2e925f498d4ee166',2025,'MV','Maldives','communications',45,'Telephones - fixed lines:
total subscriptions:
14,005 (2021 est.)
subscriptions per 100 inhabitants:
3 (2021 est.)
comparison ranking:
total subscriptions 182
Telephones - mobile cellular:
total subscriptions:
706,043 (2021 est.)
subscriptions per 100 inhabitants:
135 (2021 est.)
comparison ranking:
total subscriptions 169
Telecommunication systems:
general assessment:
with its economy so heavily dependent on tourism, the Maldives has suffered heavy economic as well as health casualties during the pandemic; the country had a relatively short period of lock down and was willing to welcome visitors back as early as July 2020; but the effective shutdown of international air travel for most of the year resulted in the bottom falling out of the Maldives’ tourism industry, taking GDP down 32% in the process; the economy fared better in 2021, with a return to growth, yet it may still be a few years before the country’s key industries can return to the same level of prosperity that they previously enjoyed; the country’s high number of tourists and expatriate workers has inflated the penetration rate for mobile services, making it one of the highest in the world; that rate crashed in 2020 as demand for SIM cards (primarily prepaid) dried up; however, the number of contract subscribers increased as locals took advantage of competitive pricing offers from operators; everything now rests on a fast return to normality, with tourists helping to boost the nation’s coffers as well as buying up those prepaid SIM cards; with commercial 5G services already launched and fiber networks rapidly expanding around the country, the Maldives is primed to deliver world-class telecommunications services to its domestic and international customers (2021)
domestic:
fixed-line is at nearly 3 per 100 persons and mobile-cellular subscriptions stands at nearly 135 per 100 persons (2021)
international:
country code - 960; landing points for Dhiraagu Cable Network, NaSCOM, Dhiraagu-SLT Submarine Cable Networks and WARF submarine cables providing connections to 8 points in Maldives, India, and Sri Lanka; satellite earth station - 3 Intelsat (Indian Ocean) (2019)
Broadcast media:
state-owned radio and TV monopoly until recently; 4 state-operated and 7 privately owned TV stations and 4 state-operated and 7 privately owned radio stations (2019)
Internet country code:
.mv
Internet users:
total:
447,200 (2021 est.)
percent of population:
86% (2021 est.)
comparison ranking:
total 169
Broadband - fixed subscriptions:
total:
63,685 (2020 est.)
subscriptions per 100 inhabitants:
12 (2020 est.)
comparison ranking:
total 139','22ae1e6c6a97636b2c0bd6fc816d4b718bae76f7a1014137b2e33ac58d8c0523','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('96c074fe9d19ad1bb9a36e27bcde31fec6a5cdc622725286e04b1eae9bfa28e0',2025,'ML','Mali','communications',8,'Telephones - fixed lines:
total subscriptions:
301,055 (2021 est.)
subscriptions per 100 inhabitants:
1 (2021 est.)
comparison ranking:
total subscriptions 109
Telephones - mobile cellular:
total subscriptions:
21,882,251 (2021 est.)
subscriptions per 100 inhabitants:
100 (2021 est.)
comparison ranking:
total subscriptions 59
Telecommunication systems:
general assessment:
Mali’s telecom systems are challenged by recent conflict, geography, areas of low population, poverty, security issues, and high illiteracy; telecom infrastructure is barely adequate in urban areas and not available in most of the country with underinvestment in fixed-line networks; high mobile penetration and potential for mobile broadband service; local plans for IXP; dependent on neighboring countries for international bandwidth and access to submarine cables (2022)
domestic:
fixed-line subscribership is 1 per 100 persons; mobile-cellular subscribership has increased sharply to 100 per 100 persons (2021)
international:
country code - 223; satellite communications center and fiber-optic links to neighboring countries; satellite earth stations - 2 Intelsat (1 Atlantic Ocean, 1 Indian Ocean) (2020)
Broadcast media:
national public TV broadcaster; 2 privately owned companies provide subscription services to foreign multi-channel TV packages; national public radio broadcaster supplemented by a large number of privately owned and community broadcast stations; transmissions of multiple international broadcasters are available (2019)
Internet country code:
.ml
Internet users:
total:
7.48 million (2021 est.)
percent of population:
34% (2021 est.)
comparison ranking:
total 78
Broadband - fixed subscriptions:
total:
243,806 (2020 est.)
subscriptions per 100 inhabitants:
1 (2020 est.)
comparison ranking:
total 112','86bdbc7c1925cbdfe17d0f93f2d31026614ac9d1eabfb19dc2c4ff6570a9859a','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b62e1eab98afad9d885769223fc1ac29846e9c6c644b0df3bc8499328a0c0e0b',2025,'MT','Malta','communications',20,'Telephones - fixed lines:
total subscriptions:
259,439 (2021 est.)
subscriptions per 100 inhabitants:
49 (2021 est.)
comparison ranking:
total subscriptions 117
Telephones - mobile cellular:
total subscriptions:
644,955 (2021 est.)
subscriptions per 100 inhabitants:
122 (2021 est.)
comparison ranking:
total subscriptions 171
Telecommunication systems:
general assessment:
Malta’s small telecom sector is among the most advanced in Europe; this has been helped by the topography, which has made it relatively easy for operators to expand the reach of their fiber infrastructure; with high mobile and broadband penetration rates, the government and regulator have effective strategies in place to capitalize on these infrastructure developments to ensure that the population has among the fastest data rates in Europe, and is well positioned to take advantage of emerging e-commerce opportunities; the sector has also been stimulated by regulatory measures designed to reduce consumer prices; the incumbent telco is investing in a sub sea cable to connect the islands to France and Egypt; expected to be ready for service in 2022, the cable will further enhance Malta’s internet bandwidth and lead to reduced prices for end-users; there has also been some encouragement to increase market competition (2021)
domestic:
fixed-line approximately 49 per 100 persons and mobile-cellular subscribership 122 per 100 persons (2021)
international:
country code - 356; landing points for the Malta-Gozo Cable, VMSCS, GO-1 Mediterranean Cable System, Malta Italy Interconnector, Melita-1, and the Italy-Malta submarine cable connections to Italy; satellite earth station - 1 Intelsat (Atlantic Ocean) (2019)
Broadcast media:
2 publicly owned TV stations, Television Malta broadcasting nationally plus an educational channel; several privately owned national television stations, 2 of which are owned by political parties; Italian and British broadcast programs are available; multi-channel cable and satellite TV services are available; publicly owned radio broadcaster operates 3 stations; roughly 20 commercial radio stations (2019)
Internet country code:
.mt
Internet users:
total:
461,100 (2021 est.)
percent of population:
87% (2021 est.)
comparison ranking:
total 168
Broadband - fixed subscriptions:
total:
213,419 (2020 est.)
subscriptions per 100 inhabitants:
48 (2020 est.)
comparison ranking:
total 117','6c5b6ba81524b9732fed25cba8ac84cc23e7bbfde2378cb799534259a007d3bd','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('77fa5dd215358f82f5f012feff22828e3f78c36904b566a5ff80dcf2d8260301',2025,'MH','Marshall Islands','communications',32,'Telephones - fixed lines:
total subscriptions:
2,361 (2014 est.)
subscriptions per 100 inhabitants:
5 (2014 est.)
comparison ranking:
total subscriptions 214
Telephones - mobile cellular:
total subscriptions:
16,000 (2021 est.)
subscriptions per 100 inhabitants:
38 (2021 est.)
comparison ranking:
total subscriptions 218
Telecommunication systems:
general assessment:
the National Telecommunications Act, through Bill No. 66, ushered in a new era in telecommunications in the Marshall Islands; this will enable an open, competitive market for telecommunications that is regulated by a Telecommunications Commissioner; telecom officials announced that they would be able to offer satellite internet services beginning in mid-2023; the World Bank has been promoting telecommunications reform here for a decade and has a multi-million-dollar telecommunications reform grant program in progress (2022)
domestic:
fixed-line roughly 5 per 100 persons and mobile-cellular is nearly 38 per 100 persons (2021)
international:
country code - 692; satellite earth stations - 2 Intelsat (Pacific Ocean); US Government satellite communications system on Kwajalein
Broadcast media:
no TV broadcast station; a cable network is available on Majuro with programming via videotape replay and satellite relays; 4 radio broadcast stations; American Armed Forces Radio and Television Service (AFRTS) provides satellite radio and television service to Kwajalein Atoll (2019)
Internet country code:
.mh
Internet users:
total:
16,254 (2021 est.)
percent of population:
38.7% (2021 est.)
comparison ranking:
total 214
Broadband - fixed subscriptions:
total:
1,000 (2020 est.)
subscriptions per 100 inhabitants:
2 (2020 est.)
comparison ranking:
total 207
Communications - note:
Kwajalein hosts one of four dedicated ground antennas that assist in the operation of the Global Positioning System (GPS) navigation system (the others are at Cape Canaveral, Florida (US), on Ascension (Saint Helena, Ascension, and Tristan da Cunha), and at Diego Garcia (British Indian Ocean Territory))','f1a8290cfe0a28951d8b7afc84f9ac9e068a6b2ecad6f26ed12bc31d9e007a22','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('03602e79ea85930bae64f4a36d1f423fa33a245232e1859bb649335d494a757b',2025,'MR','Mauritania','communications',43,'Telephones - fixed lines:
total subscriptions:
58,094 (2021 est.)
subscriptions per 100 inhabitants:
1 (2021 est.)
comparison ranking:
total subscriptions 151
Telephones - mobile cellular:
total subscriptions:
6,512,361 (2021 est.)
subscriptions per 100 inhabitants:
141 (2021 est.)
comparison ranking:
total subscriptions 112
Telecommunication systems:
general assessment:
Mauritania’s small population and low economic output has limited the country’s ability to develop sustained growth in the telecom sector; low disposable income has restricted growth in the use of services, and thus of revenue which telcos can hope to gain from subscribers; this has impacted on their ability to invest in network upgrades and improvements to service offerings; this has been reflected in the repeated fines imposed against them by the regulator for failing to ensure a good quality of service; there are also practical challenges relating to transparency and tax burdens which have hindered foreign investment; financial support has been forthcoming from the government as well as the World Bank and European Investment Bank; their efforts have focused on implementing appropriate regulatory measures and promoting the further penetration of fixed-line broadband services by improving the national backbone network, ensuring connectivity to international telecom cables, and facilitating operator access to infrastructure; progress has been made to improve internet bandwidth capacity, including the completion of a cable link at the border with Algeria, and the connection to the EllaLink submarine cable; the final stage of the national backbone network was completed in December 2021, which now runs to some 4,000km; penetration of fixed telephony and broadband service is very low and is expected to remain so in coming years, though growth is anticipated following improvements to backbone infrastructure and the reduction in access pricing; most voice and data services are carried over the mobile networks (2022)
domestic:
fixed-line teledensity 1 per 100 persons; mobile-cellular teledensity of roughly 141 per 100 persons (2021)
international:
country code - 222; landing point for the ACE submarine cable for connectivity to 19 West African countries and 2 European countries; satellite earth stations - 3 (1 Intelsat - Atlantic Ocean, 2 Arabsat) (2019)
Broadcast media:
12 TV stations: 6 government-owned and 6 private (the 6th was started in early 2022, owed by the President of Mauritanian Businessmen); in October 2017, the government suspended most private TV stations due to non-payment of broadcasting fees, but they later negotiated payment options with the government and are back since 2019. There are 19 radio broadcasters: 15 government-owned, 4 (Radio Nouakchott Libre, Radio Tenwir, Radio Kobeni and Mauritanid) private; all 4 private radio stations broadcast from Nouakchott; of the 15 government stations, 4 broadcast from Nouakchott (Radio Mauritanie, Radio Jeunesse, Radio Koran and Mauritanid) and the other 12 broadcast from each of the 12 regions outside Nouakchott; Radio Jeunesse and Radio Koran are now also being re-broadcast in all the regions. (2022)
Internet country code:
.mr
Internet users:
total:
2.714 million (2021 est.)
percent of population:
59% (2021 est.)
comparison ranking:
total 125
Broadband - fixed subscriptions:
total:
18,457 (2020 est.)
subscriptions per 100 inhabitants:
0.4 (2020 est.)
comparison ranking:
total 168','b7c2fa4212bdceb880a5d3463356549ea5185863da967940baa38cf173084421','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('aaefce00f3581c1b5097db6bc8327ae722b1db65a00e8fafaff0a09fa4bed3aa',2025,'MU','Mauritius','communications',55,'Telephones - fixed lines:
total subscriptions:
469,100 (2021 est.)
subscriptions per 100 inhabitants:
36 (2021 est.)
comparison ranking:
total subscriptions 96
Telephones - mobile cellular:
total subscriptions:
1,971,300 (2021 est.)
subscriptions per 100 inhabitants:
152 (2021 est.)
comparison ranking:
total subscriptions 151
Telecommunication systems:
general assessment:
the telecom sector in Mauritius has long been supported by the varied needs of tourists; this has stimulated the mobile market, leading to a particularly high penetration rate; the response of the country’s telcos to tourist requirements also contributed to the country being among the first in the region to provide services based on 3G and WiMAX technologies; the incumbent telco provides comprehensive LTE and fiber broadband coverage, and in late 2021 it launched a gigabit fiber-based broadband service; the country has seen improved international internet capacity in recent years, with direct cables linking to India, Madagascar, and South Africa, as well as other connections to Rodrigues and Reunion; mobile subscribers in Mauritius secured 5G services in mid-2021; this followed the regulator’s award of spectrum in two bands to the MNOs (2022)
domestic:
fixed-line teledensity over 36 per 100 persons and mobile-cellular services teledensity 152 per 100 persons (2021)
international:
country code - 230; landing points for the SAFE, MARS, IOX Cable System, METISS and LION submarine cable system that provides links to Asia, Africa, Southeast Asia, Indian Ocean Islands of Reunion, Madagascar, and Mauritius; satellite earth station - 1 Intelsat (Indian Ocean); new microwave link to Reunion; HF radiotelephone links to several countries (2019)
Broadcast media:
the Mauritius Broadcasting Corporation is the national public television and radio broadcaster; it broadcasts programming in French, English, Hindi, Creole and Chinese, it provides 17 television channels in Mauritius; there are nine Mauritian FM radio stations and two operating on the AM band
(2022)
Internet country code:
.mu
Internet users:
total:
884,000 (2021 est.)
percent of population:
68% (2021 est.)
comparison ranking:
total 150
Broadband - fixed subscriptions:
total:
323,200 (2020 est.)
subscriptions per 100 inhabitants:
25 (2020 est.)
comparison ranking:
total 105','39dcf03fdfeccde3a87bb18fe17867b171b41613c1be17836b55e935c035fac3','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('78a71aa6e9ef19604afa802a9b1a3fed635143cf19c814be1b0a71c4b0a0967d',2025,'MX','Mexico','communications',8,'Telephones - fixed lines:
total subscriptions:
24,366,595 (2021 est.)
subscriptions per 100 inhabitants:
19 (2021 est.)
comparison ranking:
total subscriptions 9
Telephones - mobile cellular:
total subscriptions:
123,920,752 (2021 est.)
subscriptions per 100 inhabitants:
98 (2021 est.)
comparison ranking:
total subscriptions 14
Telecommunication systems:
general assessment:
with a large population and relatively low broadband and mobile penetration, (86 lines for mobile broadband for every 100 habitants in June 2021) Mexico’s telecom sector has potential for growth; adequate telephone service for business and government; improving quality and increasing mobile cellular availability, with mobile subscribers far outnumbering fixed-line subscribers (24.6 million fixed line subscribers and 125 million mobile line subscribers in June 2021); relatively low broadband and mobile penetration, potential for growth and international investment; extensive microwave radio relay network; considerable use of fiber-optic cable and coaxial cable; 5G development slow in part due to high costs (2021)
domestic:
fixed-line teledensity 19 lines per every 100; mobile-cellular teledensity is 98 per 100 persons (2021)
international:
country code - 52; Columbus-2 fiber-optic submarine cable with access to the US, Virgin Islands, Canary Islands, Spain, and Italy; the ARCOS-1 and the MAYA-1 submarine cable system together provide access to Central America, parts of South America and the Caribbean, and the U.S.; Pan-American Crossing (PAC) submarine cable system provides access to Panama, California, U.S., and Costa Rica; Lazaro Cardenas-Manzanillo Santiago submarines cable system (LCMSSCS) provides access to Michoacan, Guerrero, and Colima, Mexico; AMX-1 submarine cable system with access to Colombia, Brazil, Puerto Rico, Gulf of California Cable submarine cable systems that connects La Paz, Baja California Sur and Topolobambo, Sinaloa; and Aurora submarine cable system provides access to Guatemala, Panama, Ecuador, Colombia, Mexico, and the U.S. satellite earth stations - 124 (36 Intelsat, 1 Solidaridad (giving Mexico improved access to South America, Central America, and much of the US as well as enhancing domestic communications), 9 Panamsat, numerous Inmarsat mobile earth stations); linked to Central American Microwave System of trunk connections (2022)
Broadcast media:
telecom reform in 2013 enabled the creation of new broadcast television channels after decades of a quasi-monopoly; Mexico has 885 TV stations and 1,841 radio stations and most are privately owned; the Televisa group once had a virtual monopoly in TV broadcasting, but new broadcasting groups and foreign satellite and cable operators are now available; in 2016, Mexico became the first country in Latin America to complete the transition from analog to digital transmissions, allowing for better image and audio quality and a wider selection of programming from networks (2022)
Internet country code:
.mx
Internet users:
total:
98.8 million (2021 est.)
percent of population:
76% (2021 est.)
comparison ranking:
total 9
Broadband - fixed subscriptions:
total:
21,936,131 (2020 est.)
subscriptions per 100 inhabitants:
17 (2020 est.)
comparison ranking:
total 11','0946702f20b5e21838205e14517f3176151b8a535469f784bcdf4d2b4679a99b','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a2f9bd99651a42ebd966beffec62b8e4021bdbe2856af7482f1ba34184a5b033',2025,'FM','Micronesia, Federated States of','communications',20,'Telephones - fixed lines:
total subscriptions:
7,000 (2021 est.)
subscriptions per 100 inhabitants:
6 (2021 est.)
comparison ranking:
total subscriptions 199
Telephones - mobile cellular:
total subscriptions:
22,000 (2021 est.)
subscriptions per 100 inhabitants:
19 (2021 est.)
comparison ranking:
total subscriptions 215
Telecommunication systems:
general assessment:
Australia, Japan, and the United States are committed to working in partnership with the Federated States of Micronesia (FSM), Kiribati, and Nauru to improve internet connectivity to these three Pacific nations by providing funding to build a new undersea cable; the proposed undersea cable will provide faster, higher quality, and more reliable and secure communications to approximately 100,000 people across three countries; this will support increased economic growth, drive development opportunities, and help to improve living standards as the region recovers from the severe impacts of COVID-19; the new cable will connect Kosrae (FSM), Nauru, and Tarawa (Kiribati) with the existing HANTRU-1 cable at Pohnpei (FSM), providing internet connectivity through a submarine cable for the first time
(2021)
domestic:
fixed line teledensity roughly 6 per 100 and mobile-cellular nearly 19 per 100 (2021)
international:
country code - 691; landing points for the Chuukk-Pohnpei Cable and HANTRU-1 submarine cable system linking the Federated States of Micronesia and the US; satellite earth stations - 5 Intelsat (Pacific Ocean) (2019)
Broadcast media:
no TV broadcast stations; each state has a multi-channel cable service with TV transmissions carrying roughly 95% imported programming and 5% local programming; about a half-dozen radio stations (2009)
Internet country code:
.fm
Internet users:
total:
44,000 (2021 est.)
percent of population:
40% (2021 est.)
comparison ranking:
total 202
Broadband - fixed subscriptions:
total:
6,000 (2020 est.)
subscriptions per 100 inhabitants:
5 (2020 est.)
comparison ranking:
total 183','0dda42d803d326ebaef7a424658ca83f9a42544298407ce921854de1bca9af4d','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2c0a314c0665c09f39036fb44505a652cf55c7fb8668d52be83175844ad5c578',2025,'FM','Micronesia, Federated States of','communications',31,'Telephones - fixed lines:
total subscriptions:
1,000,228 (2021 est.)
subscriptions per 100 inhabitants:
33 (2021 est.)
comparison ranking:
total subscriptions 71
Telephones - mobile cellular:
total subscriptions:
3,900,179 (2021 est.)
subscriptions per 100 inhabitants:
127 (2021 est.)
comparison ranking:
total subscriptions 133
Telecommunication systems:
general assessment:
the telecom market has been affected by a combination of high unemployment and economic difficulties which have led to constraints on consumer spending; this has resulted in telecom revenue having fallen steadily in recent years; this decline continued into 2020, with a 6.3% in revenue from the important mobile sector alone, year-on-year; Moldova’s aspirations to join the EU have encouraged the government and regulator to adopt a range of measures to bring the country’s telecoms sector into line with EU principles and standards; in July 2017 the Electronic Communications Act was amended to accommodate the 2009 European regulatory framework, while further amendments were adopted in December 2017 and additional changes were proposed in 2019; Moldova is also part of the Eastern Partnership group of countries, and as such has set in train a glide path to reducing roaming charges, effective between 2022 and 2026; the country’s broadband strategy through to 2025 has been supported by the ITU and industry counterparts from South Korea; the internet market is developing rapidly; the market is highly competitive, with 101 active ISPs as of early 2021; the number of cable broadband subscribers is increasing steadily, though fiber is now by far the strongest sector; by the end of 2020 fiber accounted for about 72.3% of all fixed broadband connections; the mobile market has also grown rapidly; the near comprehensive geographical reach of their mobile networks, market brand recognition and existing customer relationships will make for steady subscriber growth in coming years (2022)
domestic:
fixed-line service is 33 per 100; mobile-cellular teledensity is 127 per 100 persons (2021)
international:
country code - 373; service through Romania and Russia via landline; satellite earth stations - at least 3 - Intelsat, Eutelsat, and Intersputnik
Broadcast media:
state-owned national radio-TV broadcaster operates 1 TV and 1 radio station; a total of nearly 70 terrestrial TV channels and some 50 radio stations are in operation; Russian and Romanian channels also are available (2019)
Internet country code:
.md
Internet users:
total:
1.891 million (2021 est.)
percent of population:
61% (2021 est.)
comparison ranking:
total 135
Broadband - fixed subscriptions:
total:
719,001 (2020 est.)
subscriptions per 100 inhabitants:
18 (2020 est.)
comparison ranking:
total 80','92799d2912a4c9edce7146849f9e76770f3d50c7b9bdc10ebd5c693d197d2d44','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cfa76e695fe141a48e3a07989a784082944792b064e06a78443f1fab0ea04fed',2025,'MC','Monaco','communications',42,'Telephones - fixed lines:
total subscriptions:
42,812 (2021 est.)
subscriptions per 100 inhabitants:
117 (2021 est.)
comparison ranking:
total subscriptions 161
Telephones - mobile cellular:
total subscriptions:
36,255 (2021 est.)
subscriptions per 100 inhabitants:
99 (2021 est.)
comparison ranking:
total subscriptions 209
Telecommunication systems:
general assessment: modern
automatic telephone system: the country’s sole fixed-line operator offers a full range of services to residential and business customers; competitive mobile telephony market; 4G LTE widely available (2020)
domestic:
fixed-line a little over 117 per 100 and mobile-cellular teledensity is 99 per 100 persons (2021)
international:
country code - 377; landing points for the EIG and Italy-Monaco submarine cables connecting Monaco to Europe, Africa, the Middle East and Asia; no satellite earth stations; connected by cable into the French communications system (2019)
Broadcast media:
TV Monte-Carlo operates a TV network; cable TV available; Radio Monte-Carlo has extensive radio networks in France and Italy with French-language broadcasts to France beginning in the 1960s and Italian-language broadcasts to Italy beginning in the 1970s; other radio stations include Riviera Radio and Radio Monaco
Internet country code:
.mc
Internet users:
total:
31,820 (2021 est.)
percent of population:
86% (2021 est.)
comparison ranking:
total 208
Broadband - fixed subscriptions:
total:
20,877 (2020 est.)
subscriptions per 100 inhabitants:
53 (2020 est.)
comparison ranking:
total 166','1b4d09b8c2e71f5fb2f6b60e5961953d47c771261eb13c01a27ae7f46ddfd369','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('008c801bd2c4c09d7610ffe1c67b50c59829a1f54ff29ba9d538a8c5cd0babdd',2025,'MN','Mongolia','communications',53,'Telephones - fixed lines:
total subscriptions:
399,237 (2021 est.)
subscriptions per 100 inhabitants:
12 (2021 est.)
comparison ranking:
total subscriptions 102
Telephones - mobile cellular:
total subscriptions:
4,687,304 (2021 est.)
subscriptions per 100 inhabitants:
140 (2021 est.)
comparison ranking:
total subscriptions 127
Telecommunication systems:
general assessment:
liberalized and competitive telecoms market comprises of a number of operators; fixed-line penetration increased steadily in the years to 2018 as more people took on fixed-line access for voice calls and to access copper-based broadband services; the number of lines fell in 2019, and again and more sharply in 2020, partly through the economic consequences of the pandemic (GDP fell 5.3% in 2020, year-on-year) and partly due to the migration to the mobile platform and to VoIP; fixed broadband penetration remains low, mainly due to a limited number of fixed lines and the dominance of the mobile platform; the attraction of fixed broadband as a preferred access where it is available is waning as the mobile networks are upgraded with greater capacity and capabilities; the growing popularity of mobile broadband continues to underpin overall broadband and telecom sector growth, with Mongolia’s market very much being dominated by mobile services, supported by widely available LTE; this will largely determine and shape the future direction of Mongolia’s developing digital economy (2021)
domestic:
fixed-line teledensity of 12 per 100; mobile-cellular subscribership is 140 per 100 persons (2021)
international:
country code - 976; satellite earth stations - 7 (2016)
Broadcast media:
following a law passed in 2005, Mongolia’s state-run radio and TV provider converted to a public service provider; also available are 68 radio and 160 TV stations, including multi-channel satellite and cable TV providers; transmissions of multiple international broadcasters are available (2019)
Internet country code:
.mn
Internet users:
total:
2.772 million (2021 est.)
percent of population:
84% (2021 est.)
comparison ranking:
total 124
Broadband - fixed subscriptions:
total:
307,166 (2020 est.)
subscriptions per 100 inhabitants:
9 (2020 est.)
comparison ranking:
total 106','c2b2e458e558198a212acfb0925cbba7767cd7b25bf10cc1b75a0706ea090fa8','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('522774f78f79b04bba52fad7662aee55c3b8c770e73ff973b3cd5d47bcd057ac',2025,'ME','Montenegro','communications',8,'Telephones - fixed lines:
total subscriptions:
189,519 (2021 est.)
subscriptions per 100 inhabitants:
30 (2021 est.)
comparison ranking:
total subscriptions 124
Telephones - mobile cellular:
total subscriptions:
1,120,074 (2021 est.)
subscriptions per 100 inhabitants:
178 (2021 est.)
comparison ranking:
total subscriptions 162
Telecommunication systems:
general assessment:
a small telecom market supported by a population of only 623,000; fixed broadband services are available via a variety of technology platforms, though fiber is the dominant platform, accounting for almost 40% of connections; the growth of fiber has largely been at the expense of DSL as customers are migrated to fiber networks as these are built out progressively; mobile penetration is particularly high, though this is partly due to the significant number of tourists visiting the country seasonally, as also to the popularity of subscribers having multiple prepaid cards; in the wake of the pandemic and associated restrictions on travel, the number of mobile subscribers fell in 2020, as also in the first quarter of 2021, year-on-year; networks support a vibrant mobile broadband services sector, largely based on LTE; two of the MNOs began trialing 5G in May 2021, though commercial services will not gain traction until after the multispectrum auction is completed at the end of 2021; spectrum is available in the 694-790MHz and 3400-3800MHz ranges, as well as in the 26.5-27.5GHz range (2021)
domestic:
fixed-line over 30 per 100 and mobile-cellular 178 per 100 persons (2021)
international:
country code - 382; 2 international switches connect the national system
Broadcast media:
state-funded national radio-TV broadcaster operates 2 terrestrial TV networks, 1 satellite TV channel, and 2 radio networks; 4 local public TV stations and 14 private TV stations; 14 local public radio stations, 35 private radio stations, and several on-line media (2019)
Internet country code:
.me
Internet users:
total:
516,600 (2021 est.)
percent of population:
82% (2021 est.)
comparison ranking:
total 166
Broadband - fixed subscriptions:
total:
184,176 (2020 est.)
subscriptions per 100 inhabitants:
29 (2020 est.)
comparison ranking:
total 121','e820b02b86cac4fa55716a2d8e1799e97983177e03705b25e407c6b37ce64602','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('406153dede275f75bc82b9fef1f85730c1b382b1fccb4235d2d84dfcb128ffc5',2025,'MS','Montserrat','communications',19,'Telephones - fixed lines:
total subscriptions:
3,000 (2020 est.)
subscriptions per 100 inhabitants:
67 (2020 est.)
comparison ranking:
total subscriptions 212
Telephones - mobile cellular:
total subscriptions:
5,000 (2020 est.)
subscriptions per 100 inhabitants:
110 (2020 est.)
comparison ranking:
total subscriptions 222
Telecommunication systems:
general assessment:
telecom market one of growth in Caribbean and fully digitalized; high dependency on tourism and offshore financial services; operators expand FttP (Fiber to Home) services; LTE launches and operators invest in mobile networks; effective competition in all sectors (2020)
domestic:
fixed-line is 67 per 100 and mobile-cellular teledensity is 110 per 100 persons (2020)
international:
country code - 1-664; landing point for the ECFS optic submarine cable with links to 14 other islands in the eastern Caribbean extending from the British Virgin Islands to Trinidad (2019)
Broadcast media:
Radio Montserrat, a public radio broadcaster, transmits on 1 station and has a repeater transmission to a second station; repeater transmissions from the GEM Radio Network of Trinidad and Tobago provide another 2 radio stations; cable and satellite TV available (2007)
Internet country code:
.ms
Internet users:
total:
2,473 (2021 est.)
percent of population:
56.2% (2021 est.)
comparison ranking:
total 226
Broadband - fixed subscriptions:
total:
2,700 (2018 est.)
subscriptions per 100 inhabitants:
55 (2018 est.)
comparison ranking:
total 196','b67becfe63a55fda74a71b073577dd59687e62476627e40069106c4af6c6748d','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('dffafcbbce19dda8d1f439c1aec4d26b0786c62839b1beec84acd69e2bc6ba95',2025,'MA','Morocco','communications',30,'Telephones - fixed lines:
total subscriptions:
2,460,155 (2021 est.)
subscriptions per 100 inhabitants:
7 (2021 est.)
comparison ranking:
total subscriptions 50
Telephones - mobile cellular:
total subscriptions:
52.012 million (2021 est.)
subscriptions per 100 inhabitants:
139 (2021 est.)
comparison ranking:
total subscriptions 32
Telecommunication systems:
general assessment:
national network nearly 100% digital using fiber-optic links; improved rural service employs microwave radio relay; one of the most state-of-the-art markets in Africa; high mobile penetration rates in the region with low cost for broadband Internet access; improvement in LTE reach and capabilities; service providers have all successfully completed 5G proofs of concept and are currently lining up 5G equipment providers for both radio and core technology; regulatory agency expects to conduct the 5G spectrum auction in 2023; mobile Internet accounts for 93% of all Internet connections; World Bank provided funds for Morocco’s digital transformation; government supported digital education during pandemic; submarine cables and satellite provide connectivity to Asia, Africa, the Middle East, Europe, and Australia (2022)
domestic:
fixed-line teledensity is 7 per 100 persons and mobile-cellular subscribership is 139 per 100 persons (2021)
international:
country code - 212; landing point for the Atlas Offshore, Estepona-Tetouan, Canalink and SEA-ME-WE-3 fiber-optic telecommunications undersea cables that provide connectivity to Asia, Africa, the Middle East, Europe and Australia; satellite earth stations - 2 Intelsat (Atlantic Ocean) and 1 Arabsat; microwave radio relay to Gibraltar, Spain, and Western Sahara (2019)
Broadcast media:
2 TV broadcast networks with state-run Radio-Television Marocaine (RTM) operating one network and the state partially owning the other; foreign TV broadcasts are available via satellite dish; 3 radio broadcast networks with RTM operating one; the government-owned network includes 10 regional radio channels in addition to its national service (2019)
Internet country code:
.ma
Internet users:
total:
32.56 million (2021 est.)
percent of population:
88% (2021 est.)
comparison ranking:
total 30
Broadband - fixed subscriptions:
total:
2,102,434 (2020 est.)
subscriptions per 100 inhabitants:
6 (2020 est.)
comparison ranking:
total 57
Communications - note:
the University of al-Quarawiyyin Library in Fez is recognized as the oldest existing, continually operating library in the world, dating back to A.D. 859; among its holdings are approximately 4,000 ancient Islamic manuscripts','c6ca0822f038044e2ec75ec7785deae85e0908aa2ae846c39c2b37d5af80db63','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0ba6cb53fd14c66ad0688939b953af3253a1ba695088a6a86a70ea7f98df683c',2025,'MZ','Mozambique','communications',43,'Telephones - fixed lines:
total subscriptions:
59,682 (2021 est.)
subscriptions per 100 inhabitants:
(2021 est.) less than 1
comparison ranking:
total subscriptions 150
Telephones - mobile cellular:
total subscriptions:
13,686,234 (2021 est.)
subscriptions per 100 inhabitants:
43 (2021 est.)
comparison ranking:
total subscriptions 75
Telecommunication systems:
general assessment:
one of the first countries in the region to embark upon telecom reform and to open the sector to competition; the mobile segment in particular has shown strong growth; additional competition followed in late 2020; a new licensing regime ensured that by mid-2019 all operators had been provided with universal licenses, enabling them to offer all types of telephony and data services; mobile, fixed-line and broadband penetration rates remain far below the average for the region; in recent years the government has enforced the registration of SIM cards, but with varying success; at the end of 2016 almost five million unregistered SIM cards were deactivated but poor monitoring meant that the process was revisited in mid-2019 and again in late 2020; the high cost of international bandwidth had long hampered internet use, though the landing of two international submarine cables (SEACOM and EASSy) has reduced the cost of bandwidth and so led to drastic reductions in broadband retail prices as well as a significant jump in available bandwidth; there is some cross-platform competition, with DSL, cable, fibre, WiMAX, and mobile broadband options available, though fixed broadband options can be limited to urban areas; improvements can be expected from the ongoing rollout of a national fiber backbone networks and of upgrades to mobile infrastructure (2022)
domestic:
fixed-line less than 1 per 100 and nearly 43 per 100 mobile-cellular teledensity (2021)
international:
country code - 258; landing points for the EASSy and SEACOM/ Tata TGN-Eurasia fiber-optic submarine cable systems linking numerous east African countries, the Middle East and Asia ; satellite earth stations - 5 Intelsat (2 Atlantic Ocean and 3 Indian Ocean); TdM contracts for Itelsat for satellite broadband and bulk haul services (2020)
Broadcast media:
1 state-run TV station supplemented by private TV station; Portuguese state TV’s African service, RTP Africa, and Brazilian-owned TV Miramar are available; state-run radio provides nearly 100% territorial coverage and broadcasts in multiple languages; a number of privately owned and community-operated stations; transmissions of multiple international broadcasters are available (2019)
Internet country code:
.mz
Internet users:
total:
5.44 million (2021 est.)
percent of population:
17% (2021 est.)
comparison ranking:
total 86
Broadband - fixed subscriptions:
total:
70,000 (2020 est.)
subscriptions per 100 inhabitants:
0.2 (2020 est.)
comparison ranking:
total 136','5beeca6d23d4063951fd5c2f2d738226f720333a635e0c84197668acb17c808b','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cc732cdb68d3422652bba23bae0bdc166f11877e240064718e3f1e63bf8d0981',2025,'NA','Namibia','communications',8,'Telephones - fixed lines:
total subscriptions:
91,869 (2021 est.)
subscriptions per 100 inhabitants:
4 (2021 est.)
comparison ranking:
total subscriptions 139
Telephones - mobile cellular:
total subscriptions:
2,915,307 (2021 est.)
subscriptions per 100 inhabitants:
115 (2021 est.)
comparison ranking:
total subscriptions 141
Telecommunication systems:
general assessment:
the government’s Broadband Policy aims to provide 95% population coverage by 2024; mobile network coverage has increased sharply in recent years; by 2021, 3G infrastructure provided 89% population coverage while LTE infrastructure provided 79% coverage (compared to only 40% a year earlier); despite the relatively advanced nature of the market, progress towards 5G has been slow, partly due to unsubstantiated public concerns over health implications of the technology which caused the government to order an environmental assessment of 5G in mid-2020; the government has requested the regulator to speed up its 5G development strategy; Namibia’s internet and broadband sector is reasonably competitive, its development was for many years held back by high prices for international bandwidth caused by the lack of a direct connection to international submarine cables; this market situation improved after operators invested in diversifying terrestrial access routes to adjacent countries; by the end of 2022 Namibia is expected to be connected by a 1,050km branch line of cable running between Portugal and South Africa (2022)
domestic:
fixed-line subscribership is 4 per 100 and mobile-cellular roughly 115 per 100 persons (2021)
international:
country code - 264; landing points for the ACE and WACS fiber-optic submarine cable linking southern and western African countries to Europe; satellite earth stations - 4 Intelsat (2019)
Broadcast media:
1 private and 1 state-run TV station; satellite and cable TV service available; state-run radio service broadcasts in multiple languages; about a dozen private radio stations; transmissions of multiple international broadcasters available
Internet country code:
.na
Internet users:
total:
1.325 million (2021 est.)
percent of population:
53% (2021 est.)
comparison ranking:
total 145
Broadband - fixed subscriptions:
total:
71,063 (2020 est.)
subscriptions per 100 inhabitants:
3 (2020 est.)
comparison ranking:
total 135','96c1ff4f6988a00d46401e314ca37447d40260db069ec1a528cf82d2bdcd7c99','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c5a387651a45fc4ba0e46d7d4b96c21ad940fa8fb1c9ab1a1cc4104c30a63818',2025,'NR','Nauru','communications',19,'Telephones - fixed lines:
total subscriptions:
(2018 est.) 0
subscriptions per 100 inhabitants:
(2018 est.) 0
Telephones - mobile cellular:
total subscriptions:
10,000 (2021 est.)
subscriptions per 100 inhabit
ants:
80 (2021 est.)
comparison ranking:
total subscriptions 219
Telecommunication systems:
general assessment:
relies on satellite as the primary Internet service provider and mobile operator; internet connectivity on the island is very limited and unstable due to the vulnerability of the network infrastructure to bad weather and limited network coverage, with several blind spots (2022)
domestic:
fixed-line 0 per 100 and mobile-cellular subscribership approximately 80 per 100 (2021)
international:
country code - 674; satellite earth station - 1 Intelsat (Pacific Ocean)
Broadcast media:
1 government-owned TV station broadcasting programs from New Zealand sent via satellite or on videotape; 1 government-owned radio station, broadcasting on AM and FM, utilizes Australian and British programs (2019)
Internet country code:
.nr
Internet users:
total:
10,920 (2021 est.)
percent of populat
ion:
84% (2021 est.)
comparison ranking:
total 218
Broadband - fixed subscriptions:
total:
950 (2010 est.)
subscriptions per 100 inhabitants:
10 (2010 est.)
comparison ranking:
total 209','9eebbc4616fee7d668ffcd3a03f3ce49733c06d05b5520adda1a08fa02e483c3','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3e2de15da3f074c9cf3c23b805debe109f0b0366b6439bbc8e92b08672221038',2025,'NP','Nepal','communications',38,'Telephones - fixed lines:
total subscriptions:
730,000 (2021 est.)
subscriptions per 100 inhabitants:
2 (2021 est.)
comparison ranking:
total subscriptions 79
Telephones - mobile cellular:
total subscriptions:
38 million (2021 est.)
subscriptions per 100 inhabitants:
130 (2021 est.)
comparison ranking:
total subscriptions 41
Telecommunication systems:
general assessment:
in relation to its telecom sector, Nepal has several topographical and economic constraints which have impeded efforts to expand network infrastructure and improve the quality of service for end-users; the fixed line market remains underdeveloped, and as a result most traffic is channeled via mobile networks; fixed broadband penetration remains very low, though to address this the government has initiated several programs as part of the Digital Nepal Framework and the wider Optical Fiber Backbone Network Expansion Project, started in 2012; supported by the Rural Telecommunications Development Fund, the programs include building out fiber backbone infrastructure and using this to provide broadband to schools and community centers nationally; telcos have also invested in fiber networks, and competition in the market is intensifying; cheap fiber-based services launched in mid-2021 prompted responses from other ISPs to provide faster and more competitively priced offers; Nepal’s mobile market is relatively developed, with a focus on LTE; in 2021, the regulator considered a range of spectrum bands which could be used for 5G (2021)
domestic:
fixed-line is 2 per 100 persons and mobile-cellular nearly 130 per 100 persons (2021)
international:
country code - 977; Nepal, China and Tibet connected across borders with underground and all-dielectric self-supporting (ADSS) fiber-optic cables; radiotelephone communications; microwave and fiber landlines to India; satellite earth station - 1 Intelsat (Indian Ocean) (2019)
Broadcast media:
state operates 3 TV stations, as well as national and regional radio stations; 117 television channels are licensed, among those 71 are cable television channels, three are distributed through Direct-To-Home (DTH) system, and four are digital terrestrial; 736 FM radio stations are licensed and at least 314 of those radio stations are community radio stations (2019)
Internet country code:
.np
Internet users:
total:
15.6 million (2021 est.)
percent of population:
52% (2021 est.)
comparison ranking:
total 48
Broadband - fixed subscriptions:
total:
1.27 million (2020 est.)
subscriptions per 100 inhabitants:
4 (2020 est.)
comparison ranking:
total 69','78c1abb97bf56495e95a8dd3fce7f86896043d07721a5a660e0b10c289b86374','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('07f42887c866e8a0eb0db20ff91e3dd661c6c8b563ce332b1dc2e3eee99f7c5a',2025,'NL','Netherlands','communications',50,'Telephones - fixed lines:
total subscriptions:
5.024 million (2021 est.)
subscriptions per 100 inhabitants:
29 (2021 est.)
comparison ranking:
total subscriptions 28
Telephones - mobile cellular:
total subscriptions:
21.888 million (2021 est.)
subscriptions per 100 inhabitants:
125 (2021 est.)
comparison ranking:
total subscriptions 58
Telecommunication systems:
general assessment:
telecom infrastructure in the Netherlands continues to be upgraded as modernization schemes undertaken by telcos make steady progress; other fiber providers have been supported by regulatory measures which have encouraged municipal governments to intervene with telcos’ fiber builds, facilitating open access networks in a bid to make rollouts cheaper, and completed sooner; while the Mobile Network Operators (MNOs) are also closing down their Global System for Mobile Communication (MSM) and 3G networks and repurposing their spectrum and physical assets for LTE and 5G, the regulator has also encouraged GSM/3G roaming in the interim, thus safeguarding services such as machine to machine and other low data-use applications while individual MNOs disable their own GSM/3G networks; the country has one of the highest fixed broadband penetration rates in the world, with effective cross-platform competition between Digital Subscriber Line (DSL), Hybrid Fiber Coazial (HFC), and fiber networks; in the third quarter of 2020 the number of cable broadband connections fell for the first time, while the DSL segment has long been eclipsed by fiber; by the end of 2021, over a quarter of fixed broadband connections were on fiber infrastructure, while DSL accounted for only about 29%; almost 49% of fixed connections provided data above 100Mb/s, while an additional 43.7% provided data of at least 30Mb/s (2022)
domestic:
fixed-line is 29 per 100 and mobile-cellular at 125 per 100 persons (2021)
international:
country code - 31; landing points for Farland North, TAT-14, Circe North, Concerto, Ulysses 2, AC-1, UK-Netherlands 14, and COBRAcable submarine cables which provide links to the US and Europe; satellite earth stations - 5 (3 Intelsat - 1 Indian Ocean and 2 Atlantic Ocean, 1 Eutelsat, and 1 Inmarsat) (2019)
Broadcast media:
more than 90% of households are connected to cable or satellite TV systems that provide a wide range of domestic and foreign channels; public service broadcast system includes multiple broadcasters, 3 with a national reach and the remainder operating in regional and local markets; 2 major nationwide commercial television companies, each with 3 or more stations, and many commercial TV stations in regional and local markets; nearly 600 radio stations with a mix of public and private stations providing national or regional coverage
Internet country code:
.nl
Internet users:
total:
16.56 million (2021 est.)
percent of population:
92% (2021 est.)
comparison ranking:
total 46
Broadband - fixed subscriptions:
total:
7,525,016 (2020 est.)
subscriptions per 100 inhabitants:
44 (2020 est.)
comparison ranking:
total 29','46a757623f1733da4787c5249bf4db70a53db703088479a8bf43e1f66d98a34e','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6ff6a243bb7c9ce9222ce22d1acf6cc0da2faffac0ea847d700a78f2663811e4',2025,'NC','New Caledonia','communications',63,'Telephones - fixed lines:
total subscriptions:
46,000 (2021 est.)
subscriptions per 100 inhabitants:
16 (2021 est.)
comparison ranking:
total subscriptions 160
Telephones - mobile cellular:
total subscriptions:
260,000 (2021 est.)
subscriptions per 100 inhabitants:
90 (2021 est.)
comparison ranking:
total subscriptions 180
Telecommunication systems:
general assessment:
New Caledonia’s telecom sector provides fixed and mobile voice services, mobile internet, fixed broadband access, and wholesale services for other ISPs; the country is well serviced by extensive 3G and LTE networks, and is considered to have one of the highest smartphone adoption rates in the Pacific region; by 2025, smart phone penetration is expected to reach 71%; while DSL is still the dominant fixed broadband technology, and a nationwide FttP network; the South Pacific region has become a hub for submarine cable system developments in recent years, with further networks scheduled to come online later in 2021 and into 2022; these new cables are expected to increase competition in the region with regards to international capacity; in 2020, the government owned telco commissioned Alcatel Submarine Networks (ASN) to build the Gondwana-2 cable system to provide additional network capacity and complement the Gondwana-1 cable (2022)
domestic:
fixed-line is 16 per 100 and mobile-cellular telephone subscribership 90 per 100 persons (2021)
international:
country code - 687; landing points for the Gondwana-1 and Picot-1 providing connectivity via submarine cables around New Caledonia and to Australia; satellite earth station - 1 Intelsat (Pacific Ocean) (2019)
Broadcast media:
the publicly owned French Overseas Network (RFO), which operates in France’s overseas departments and territories, broadcasts over the RFO Nouvelle-Calédonie TV and radio stations; a small number of privately owned radio stations also broadcast
Internet country code:
.nc
Internet users:
total:
237,800 (2021 est.)
percent of population:
82% (2021 est.)
comparison ranking:
total 178
Broadband - fixed subscriptions:
total:
55,000 (2020 est.)
subscriptions per 100 inhabitants:
19 (2020 est.)
comparison ranking:
total 142','a359de516bfc454c636c347b3c7cc372c09191950165e43f564d992263f58040','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e5b064048045179f11b305df3a5dc4c41fe66e2099d2814ed96de1075f8e2eb0',2025,'NZ','New Zealand','communications',8,'Telephones - fixed lines:
total subscriptions:
651,000 (2021 est.)
subscriptions per 100 inhabitants:
13 (2021 est.)
comparison ranking:
total subscriptions 84
Telephones - mobile cellular:
total subscriptions:
5.846 million (2021 est.)
subscriptions per 100 inhabitants:
114 (2021 est.)
comparison ranking:
total subscriptions 119
Telecommunication systems:
general assessment:
the growth areas in in New Zealand’s telecom market have been in mobile broadband and fiber; New Zealand’s mobile market continues to undergo significant developments; the coverage of LTE networks has been supported by the Rural Broadband Initiative rollout, which added a significant number of mobile sites to new or underserved areas; the market is undergoing additional consolidation; offering fixed and mobile services
(2023)
domestic:
fixed-line roughly 13 per 100 and mobile-cellular telephone subscribership 114 per 100 persons (2021)
international:
country code - 64; landing points for the Southern Cross NEXT, Aqualink, Nelson-Levin, SCCN and Hawaiki submarine cable system providing links to Australia, Fiji, American Samoa, Kiribati, Samo, Tokelau, US and around New Zealand; satellite earth stations - 8 (1 Inmarsat - Pacific Ocean, 7 other) (2019)
Broadcast media:
state-owned Television New Zealand operates multiple TV networks and state-owned Radio New Zealand operates 3 radio networks and an external shortwave radio service to the South Pacific region; a small number of national commercial TV and radio stations and many regional commercial television and radio stations are available; cable and satellite TV systems are available, as are a range of streaming services (2019)
Internet country code:
.nz
Internet users:
total:
4.896 million (2021 est.)
percent of population:
96% (2021 est.)
comparison ranking:
total 94
Broadband - fixed subscriptions:
total:
1,764,984 (2020 est.)
subscriptions per 100 inhabitants:
37 (2020 est.)
comparison ranking:
total 61','434a51861313a10e2e1f75eec104a9db8ea116247883ec96e4d9a6205d87dcb4','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b7721e6744f5f1dba387d26bb1c2e63844d40b602e595b82b71ead0b472ac959',2025,'NI','Nicaragua','communications',21,'Telephones - fixed lines:
total subscriptions:
207,577 (2021 est.)
subscriptions per 100 inhabitants:
3 (2021 est.)
comparison ranking:
total subscriptions 119
Telephones - mobile cellular:
total subscriptions:
6,233,864 (2021 est.)
subscriptions per 100 inhabitants:
91 (2021 est.)
comparison ranking:
total subscriptions 115
Telecommunication systems:
general assessment:
Nicaragua’s telecoms market has mirrored the country’s poor economic achievements, with fixed-line teledensity and mobile penetration also being the lowest in Central America; the fixed line broadband market remains nascent, with population penetration below 4%; most internet users are concentrated in the largest cities, given that rural and marginal areas lack access to the most basic telecom infrastructure; internet cafés provide public access to internet and email services, but these also tend to be restricted to the larger population centers; to address poor infrastructure, the World Bank has funded a project aimed at improving connectivity via a national fiber broadband network; there are separate schemes to improve broadband in eastern regions and provide links to Caribbean submarine cables; the number of mobile subscribers overtook the number of fixed lines in early 2002, and the mobile sector now accounts for most lines in service (2021)
domestic:
fixed-line teledensity is 3 per 100 persons; mobile-cellular telephone subscribership is 91 per 100 persons (2021)
international:
country code - 505; landing point for the ARCOS fiber-optic submarine cable which provides connectivity to South and Central America, parts of the Caribbean, and the US; satellite earth stations - 1 Intersputnik (Atlantic Ocean region) and 1 Intelsat (Atlantic Ocean) (2019)
Broadcast media:
multiple terrestrial TV stations, supplemented by cable TV in most urban areas; nearly all are government-owned or affiliated; more than 300 radio stations, both government-affiliated and privately owned (2019)
Internet country code:
.ni
Internet users:
total:
3.933 million (2021 est.)
percent of population:
57% (2021 est.)
comparison ranking:
total 111
Broadband - fixed subscriptions:
total:
290,351 (2020 est.)
subscriptions per 100 inhabitants:
4 (2020 est.)
comparison ranking:
total 108','c07b9b860d72234db56720e712ac2e5e0e1d217eb5543c04e52f4cba6962d916','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2b18d75583d289ca9263df2a4776c963755488047546a788bde53f33600e3f82',2025,'NE','Niger','communications',33,'Telephones - fixed lines:
total subscriptions:
58,000 (2021)
subscriptions per 100 inhabitants:
(2021 est.) less than 1
comparison ranking:
total subscriptions 152
Telephones - mobile cellular:
total subscriptions:
14 million (2021 est.)
subscriptions per 100 inhabitants:
56 (2021 est.)
comparison ranking:
total subscriptions 73
Telecommunication systems:
general assessment:
Niger is one of the largest countries in West Africa but also one of the poorest in the world; as with many African markets, a lack of fixed telecoms infrastructure has led to growth in mobile services; Niger’s mobile penetration is modest compared to other countries in the region, while fixed broadband penetration is negligible; recent international investment to complete the Trans-Saharan Dorsal optical fibre (SDR) network has extended the reach of fiber infrastructure in the country, and also increased international capacity; new cables linking the country with Chad and Burkina Faso have extended Niger’s connectivity with international cable infrastructure (2022)
domestic:
fixed-line less than 1 per 100 persons and mobile-cellular at nearly 56 per 100 persons (2021)
international:
country code - 227; satellite earth stations - 2 Intelsat (1 Atlantic Ocean and 1 Indian Ocean)
Broadcast media:
state-run TV station; 3 private TV stations provide a mix of local and foreign programming; state-run radio has only radio station with national coverage; about 30 private radio stations operate locally; as many as 100 community radio stations broadcast; transmissions of multiple international broadcasters are available
Internet country code:
.ne
Internet users:
total:
5.5 million (2021 est.)
percent of population:
22% (2021 est.)
comparison ranking:
total 85
Broadband - fixed subscriptions:
total:
12,000 (2020 est.)
subscriptions per 100 inhabitants:
0.1 (2020 est.)
comparison ranking:
total 177','565020553df2af513c3e53e720fd9fa06e52c05ecd7ec96090f1f02afb804bca','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('59de684fdd12f90f1ce0913e3aee6b044ace9cbe91257e8c87e047392e01d814',2025,'NG','Nigeria','communications',45,'Telephones - fixed lines:
total subscriptions:
106,385 (2021 est.)
subscriptions per 100 inhabitants:
(2021 est.) less than 1
comparison ranking:
total subscriptions 137
Telephones - mobile cellular:
total subscriptions:
195,128,265 (2021 est.)
subscriptions per 100 inhabitants:
91 (2021 est.)
comparison ranking:
total subscriptions 8
Telecommunication systems:
general assessment:
one of the larger telecom markets in Africa subject to sporadic access to electricity and vandalism of infrastructure; most Internet connections are via mobile networks; market competition with affordable access; LTE technologies available but GSM is dominant; mobile penetration high due to use of multiple SIM cards and phones; government committed to expanding broadband penetration; operators to deploy fiber optic cable in six geopolitical zones and Lagos; operators invested in base stations to deplete network congestion; submarine cable break in 2020 slowed speeds and interrupted connectivity; Nigeria concluded its first 5G spectrum auction in 2021 and granted licenses to two firms; construction of 5G infrastructure has not yet been completed (2022)
domestic:
fixed-line subscribership remains less than 1 per 100 persons; mobile-cellular subscribership is 91 per 100 persons (2021)
international:
country code - 234; landing point for the SAT-3/WASC, NCSCS, MainOne, Glo-1 & 2, ACE, and Equiano fiber-optic submarine cable that provides connectivity to Europe and South and West Africa; satellite earth stations - 3 Intelsat (2 Atlantic Ocean and 1 Indian Ocean) (2019)
Broadcast media:
nearly 70 federal government-controlled national and regional TV stations; all 36 states operate TV stations; several private TV stations operational; cable and satellite TV subscription services are available; network of federal government-controlled national, regional, and state radio stations; roughly 40 state government-owned radio stations typically carry their own programs except for news broadcasts; about 20 private radio stations; transmissions of international broadcasters are available; digital broadcasting migration process completed in three states in 2018 (2019)
Internet country code:
.ng
Internet users:
total:
115.5 million (2021 est.)
percent of population:
55% (2021 est.)
comparison ranking:
total 7
Broadband - fixed subscriptions:
total:
65,313 (2020 est.)
subscriptions per 100 inhabitants:
0.03 (2020 est.)
comparison ranking:
total 137','35848f014181eba212a056a344050b46eac465412906654dba34e7f7564f6d8b','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('71c24c7a9dd69a9d89d0947afdbf29ba73fa161cac483612f1a1b18a9883098a',2025,'NU','Niue','communications',8,'Telephones - fixed lines:
total subscriptions:
1,000 (2021 est.)
subscriptions per 100 inhabitants:
52 (2021 est.)
comparison ranking:
total subscriptions 219
Telecommunication systems:
general assessment:
in 2020, the Manatua One Polynesia Fiber Cable provided Niue with high speed Internet access for the first time replacing a 4 megabit satellite link with gigabit fiber connectivity; the government set out a strategy to upgrade to a new infrastructure that would be robust enough to operate reliably in a challenging climate: 40 40°C heat, 40% humidity, salty air, frequent power outages during storms, and no air conditioning (2022)
domestic:
single-line (fixed line) telephone system connects all villages on island; fixed teledensity at nearly 52 per 100 (2021)
international:
country code - 683; landing point for the Manatua submarine cable linking Niue to several South Pacific Ocean Islands; expansion of satellite services (2019)
Broadcast media:
1 government-owned TV station with many of the programs supplied by Television New Zealand; 1 government-owned radio station broadcasting in AM and FM (2019)
Internet country code:
.nu
Internet users:
total:
1,512 (2021 est.)
percent of population:
79.6% (2021 est.)
comparison ranking:
total 228','6e78a53bd8c88450b94b726b4e0117d7745caef563b55d7589ab5d95a8a1433b','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6a4953b83aab9a6c8aee6c2cc72caa28c383bb1829f1a351d99391fed7e6dcc5',2025,'NF','Norfolk Island','communications',18,'Telecommunication systems:
general assessment:
the current infrastructure consists of fixed line telephone utilizing copper twisted pair cable and optic fiber, two Satellite Earth Station, GSM Mobile switch with five remote base stations and 2 micro cells, central public exchange which switches international as well as national calls, ADSL Broadband internet connection (Asynchronous Digital Subscriber Line), and an ISP (Internet Service Provider); 3G/4G telecommunications network went live on Tuesday 12 January, 2021 (2021)
domestic:
free local calls
international:
country code - 672; submarine cable links with Australia and New Zealand; satellite earth station - 1
Broadcast media:
1 local radio station; broadcasts of several Australian radio and TV stations available via satellite (2009)
Internet country code:
.nf
Internet users:
total:
806 (2021 est.)
percent of population:
46.1% (2021 est.)
comparison ranking:
total 230','15af4ca5f50871dc38a023865aff03e656c2dca5d14bc6f9e310ad80435db0e6','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('dee271c28864346a326a82696528e0c648dbda79f3824880bf0330983c4ea594',2025,'MK','North Macedonia','communications',29,'Telephones - fixed lines:
total subscriptions:
425,646 (2021 est.)
subscriptions per 100 inhabitants:
20 (2021 est.)
comparison ranking:
total subscriptions 100
Telephones - mobile cellular:
total subscriptions:
1,941,352 (2021 est.)
subscriptions per 100 inhabitants:
92 (2021 est.)
comparison ranking:
total subscriptions 152
Telecommunication systems:
general assessment:
as part of the EU pre-accession process, North Macedonia has built closer economic ties with the Union which accounts for 77.5% of Macedonia’s exports and just over half of its imports; closer regulatory and administrative ties with European Commission (EC) institutions have done much to develop the telecom sector and prepare the market for the competitive environment encouraged in the EU; as part of EU integration legislation North Macedonia has implemented the principles of the EU’s regulatory framework for communications, established an independent regulator and set out several provisions to provide for a competitive telecom market, including wholesale access to the incumbent’s fixed-line network; broadband services are widely available, with effective competition between DSL and cable platforms complemented by wireless broadband and a developing fiber sector; the number of DSL subscribers has continued to fall in recent years as customers are migrated to fiber networks; the MNOs are increasingly focused on expanding their 5G networks, seeking stronger coverage across North Macedonia’s high value urban areas; mobile data services are also becoming increasingly important following investments in LTE network rollouts and in upgrades to LTE-A technology (2022)
domestic:
fixed-line roughly 20 per 100 and mobile-cellular 92 per 100 subscriptions (2021)
international:
country code - 389
Broadcast media:
public service TV broadcaster Macedonian Radio and Television operates 3 national terrestrial TV channels and 2 satellite TV channels; additionally, there are 10 regional TV stations that broadcast nationally using terrestrial transmitters, 54 TV channels with concession for cable TV, 9 regional TV stations with concessions for cable TV; 4 satellite TV channels broadcasting on a national level, 21 local commercial TV channels, and a large number of cable operators that offer domestic and international programming; the public radio broadcaster operates over 3 stations; there are 4 privately owned radio stations that broadcast nationally; 17 regional radio stations, and 49 local commercial radio stations (2019)
Internet country code:
.mk
Internet users:
total:
1.743 million (2021 est.)
percent of population:
83% (2021 est.)
comparison ranking:
total 140
Broadband - fixed subscriptions:
total:
475,569 (2020 est.)
subscriptions per 100 inhabitants:
23 (2020 est.)
comparison ranking:
total 93','af051e4b89b1a940588c7b8eb8965401bebfdf7d24b4d43c28272f90816be5fb','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d05a9282ae25a10d54272c0018830e86e1dce3873e881a7efb38e58ccea3ee1c',2025,'MP','Northern Mariana Islands','communications',41,'Telephones - fixed lines:
total subscriptions:
20,000 (2021 est.)
subscriptions per 100 inhabitants:
40 (2021 est.)
comparison ranking:
total subscriptions 172
Telephones - mobile cellular:
total subscriptions:
20,474 (2004 est.)
subscriptions per 100 inhabitants:
28 (2004)
comparison ranking:
total subscriptions 216
Telecommunication systems:
general assessment:
digital fiber-optic cables and satellites connect the islands to worldwide networks; demand for broadband growing given that mobile services are the source for Internet across region; future launch of 5G (2020)
domestic:
fixed-line teledensity is 40 per 100 persons; mobile cellular subscriptions are 28 per 100 (2021)
international:
country code - 1-670; landing points for the Atisa and Mariana-Guam submarine cables linking Mariana islands to Guam; satellite earth stations - 2 Intelsat (Pacific Ocean) (2019)
Broadcast media:
1 TV broadcast station on Saipan; multi-channel cable TV services are available on Saipan; 9 licensed radio broadcast stations (2009)
Internet country code:
.mp
Internet users:
total:
12,299 (2021 est.)
percent of population:
25.1% (2021 est.)
comparison ranking:
total 216','9363538ab6e1e843b053b3483e402c30605bf0a92cfff733af29c91c39b0e5c5','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('803c18fc525e1c232d7a21637c953813141eca8fb3af6ae31e26501cec42a611',2025,'NO','Norway','communications',52,'Telephones - fixed lines:
total subscriptions:
350,000 (2021 est.)
subscriptions per 100 inhabitants:
7 (2021 est.)
comparison ranking:
total subscriptions 104
Telephones - mobile cellular:
total subscriptions:
5.8 million (2021 est.)
subscriptions per 100 inhabitants:
110 (2021 est.)
comparison ranking:
total subscriptions 120
Telecommunication systems:
general assessment:
Norway has a sophisticated telecom market with high broadband and mobile penetration rates and a highly developed digital media sector. Although not a member of the European Union, the country’s telecoms sector is synchronized with relevant EC legislation; Norway enjoys near comprehensive LTE coverage with upgrades to 5G technologies in the future (2023)
domestic:
fixed-line is 7 per 100 and mobile-cellular nearly 110 per 100 (2021)
international:
country code - 47; landing points for the Svalbard Undersea Cable System, Polar Circle Cable, Bodo-Rost Cable, NOR5KE Viking, Celtic Norse, Tempnet Offshore FOC Network, England Cable, Denmark-Norwary6, Havfrue/AEC-2, Skagerrak 4, and the Skagenfiber West & East submarine cables providing links to other Nordic countries, Europe and the US; satellite earth stations - Eutelsat, Intelsat (Atlantic Ocean), and 1 Inmarsat (Atlantic and Indian Ocean regions); note - Norway shares the Inmarsat earth station with the other Nordic countries (Denmark, Finland, Iceland, and Sweden) (2019)
Broadcast media:
state-owned public radio-TV broadcaster operates 3 nationwide TV stations, 3 nationwide radio stations, and 16 regional radio stations; roughly a dozen privately owned TV stations broadcast nationally and roughly another 25 local TV stations broadcasting; nearly 75% of households have access to multi-channel cable or satellite TV; 2 privately owned radio stations broadcast nationwide and another 240 stations operate locally; Norway is the first country in the world to phase out FM radio in favor of Digital Audio Broadcasting (DAB), a process scheduled for completion in late 2017 (2019)
Internet country code:
.no
Internet users:
total:
5.346 million (2021 est.)
percent of population:
99% (2021 est.)
comparison ranking:
total 88
Broadband - fixed subscriptions:
total:
2,387,661 (2020 est.)
subscriptions per 100 inhabitants:
44 (2020 est.)
comparison ranking:
total 54','4904de1a8575afd4c67e923595041db6813be9ecf60d52d93b3e652760a7dbdd','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('807128773198ad30191a56ce5a345e17440db760eb3a83b90a6a0b8849d91b0e',2025,'OM','Oman','communications',8,'Telephones - fixed lines:
total subscriptions:
572,166 (2021 est.)
subscriptions per 100 inhabitants:
13 (2021 est.)
comparison ranking:
total subscriptions 88
Telephones - mobile cellular:
total subscriptions:
6,115,537 (2021 est.)
subscriptions per 100 inhabitants:
135 (2021 est.)
comparison ranking:
total subscriptions 116
Telecommunication systems:
general assessment:
Oman has a modern mobile sector which comprises substantial coverage of both 3G and LTE networks; in February 2021 commercial 5G services were launched; the Covid-19 pandemic has caused a spike in mobile data traffic; while Oman’s fixed broadband infrastructure penetration is considered low, it is being improved with the building of fiber-based networks as part of Oman’s Vision 2040 program; Oman has also established itself as an important communications hub in the Middle East, with access to numerous submarine cables including the 2Africa submarine cable, which should become available during 2023-2024; the 9,800km Oman Australia Cable running from Muscat to Perth, with the potential for a branch line to Djibouti, is making progress and is expected to be completed in December 2021; this additional infrastructure will provide considerable additional bandwidth (2021)
domestic:
fixed-line is 13 per 100 and mobile-cellular is 135 per 100 (2021)
international:
country code - 968; landing points for GSA, AAE-1, SeaMeWe-5, Tata TGN-Gulf, FALCON, GBICS/MENA, MENA/Guld Bridge International, TW1, BBG, EIG, OMRAN/EPEG, and POI submarine cables providing connectivity to Asia, Africa, the Middle East, Southeast Asia and Europe; satellite earth stations - 2 Intelsat (Indian Ocean) (2019)
Broadcast media:
1 state-run TV broadcaster; TV stations transmitting from Saudi Arabia, the UAE, Iran, and Yemen available via satellite TV; state-run radio operates multiple stations; first private radio station began operating in 2007 and several additional stations now operating (2019)
Internet country code:
.om
Internet users:
total:
4.32 million (2021 est.)
percent of population:
96% (2021 est.)
comparison ranking:
total 104
Broadband - fixed subscriptions:
total:
508,949 (2020 est.)
subscriptions per 100 inhabitants:
11 (2020 est.)
comparison ranking:
total 90','b5a6f1c11c56da679d3c22c2adb89dd06c0cda98e6b990b4bd0b24c22be9d06c','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d0fef3f0cbd9e15530cbb022848ac231e8797d9ab7ef167254fe4181f0d2776e',2025,'PK','Pakistan','communications',9,'Telephones - fixed lines:
total subscriptions:
2,989,133 (2021 est.)
subscriptions per 100 inhabitants:
1 (2021 est.)
comparison ranking:
total subscriptions 42
Telephones - mobile cellular:
total subscriptions:
188,711,452 (2021 est.)
subscriptions per 100 inhabitants:
82 (2021 est.)
comparison ranking:
total subscriptions 9
Telecommunication systems:
general assessment:
Pakistan’s telecom market transitioned from a regulated state-owned monopoly to a deregulated competitive structure in 2003, now aided by foreign investment; moderate growth over the last six years, supported by a young population and a rising use of mobile services; telecom infrastructure is improving, with investments in mobile-cellular networks, fixed-line subscriptions declining; system consists of microwave radio relay, coaxial cable, fiber-optic cable, cellular, and satellite networks; 4G mobile services broadly available; 5G tests ongoing; data centers in major cities; mobile and broadband doing well and dominate over fixed-broadband sector; future growth (in market size as well as revenue) is likely to come from the wider availability of value-added services on top of the expansion of 4G LTE and (from 2023) 5G mobile networks; the Universal Service Fund (USF) continues to direct investment towards the development of mobile broadband (and, to a lesser extent, fiber-based networks) in under-served and even under served areas of the country, with multiple projects being approved to start in 2021 and 2022 (2021)
domestic:
mobile-cellular subscribership has increased; more than 90% of Pakistanis live within areas that have cell phone coverage; fiber-optic networks are being constructed throughout the country to increase broadband access and broadband penetration in Pakistan is increasing--by the end of 2021, 50% of the population had access to broadband services; fixed-line teledensity is a little over 1 per 100 and mobile-cellular roughly 82 per 100 persons (2021)
international:
country code - 92; landing points for the SEA-ME-WE-3, -4, -5, AAE-1, IMEWE, Orient Express, PEACE Cable, and TW1 submarine cable systems that provide links to Europe, Africa, the Middle East, Asia, Southeast Asia, and Australia; satellite earth stations - 3 Intelsat (1 Atlantic Ocean and 2 Indian Ocean); 3 operational international gateway exchanges (1 at Karachi and 2 at Islamabad); microwave radio relay to neighboring countries (2019)
Broadcast media:
television is the most popular and dominant source of news in Pakistan with over 120 satellite tv stations licensed by the country’s electronic media regulatory body, PEMRA, and 42 media companies/channels with landing rights permission; state-run Pakistan Television Corporation (PTV) is the largest television network in the country and serves over 85 percent of the population with the largest terrestrial infrastructure of the country; PTV consists of nine TV Channels and PTV networks give special coverage to Kashmir; Pakistanis have access to over 100 private cable and satellite channels; six channels are considered the leaders for news reporting and current affairs programing in the country; state-owned Pakistan Broadcasting Corporation (PBC or Radio Pakistan) has the largest radio audience in the country, particularly in the rural areas; Radio Pakistan’s AM/SW/FM stations cover 98 percent of the population and 80 percent of the total area in the country; all major newspapers have online editions and all major print publications operate websites; freedom of the press and freedom of speech in the country are fragile (2022)
Internet country code:
.pk
Internet users:
total:
48.3 million (2021 est.)
percent of population:
21% (2021 est.)
comparison ranking:
total 21
Broadband - fixed subscriptions:
total:
2,523,027 (2020 est.)
subscriptions per 100 inhabitants:
1 (2020 est.)
comparison ranking:
total 53','a87b92564f9e214d37a22fd8fdc1c42a22593c58d44d3d29b4eeffcb3d6f1fa3','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('74cc993a47ae124400b9b8d4bad8198741a9e9e41e9e88d4d771b6640275a69c',2025,'PW','Palau','communications',22,'Telephones - fixed lines:
total subscriptions:
8,000 (2021 est.)
subscriptions per 100 inhabitants:
44 (2021 est.)
comparison ranking:
total subscriptions 193
Telephones - mobile cellular:
total subscriptions:
24,000 (2021 est.)
subscriptions per 100 inhabitants:
130 (2021 est.)
comparison ranking:
total subscriptions 214
Telecommunication systems:
general assessment:
Palau telecommunications is a small, formerly unregulated sector undertaking significant growth with the improvement and cost reduction in technology; mobile services have taken over the share of the market from landlines, with both 2-3G cell services throughout the islands; sim cards are easily available and offer 3G and data options; there are pre-paid and post-paid options for both voice and data; there are three data options for using a wireless hotspot network throughout Palau; connection from hotel and restaurant premises is available, enabling users to connect via WiFi throughout the main Islands of Palau (2022)
domestic:
fixed-line nearly 44 per 100 and mobile-cellular services roughly 130 per 100 persons (2021)
international:
country code - 680; landing point for the SEA-US submarine cable linking Palau, Philippines, Micronesia, Indonesia, Hawaii (US), Guam (US) and California (US); satellite earth station - 1 Intelsat (Pacific Ocean) (2019)
Broadcast media:
no broadcast TV stations; a cable TV network covers the major islands and provides access to 4 local cable stations, rebroadcasts (on a delayed basis) of a number of US stations, as well as access to a number of real-time satellite TV channels; about a half dozen radio stations (1 government-owned) (2019)
Internet country code:
.pw
Internet users:
total:
6,696 (2021 est.)
percent of population:
37.2% (2021 est.)
comparison ranking:
total 221
Broadband - fixed subscriptions:
total:
1,224 (2015 est.)
subscriptions per 100 inhabitants:
7 (2015 est.)
comparison ranking:
total 200','8840307130f645ead5ebf1226bfc8a927a5509bfca8495bc14eb7f0a3fc76116','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('62b6d37c2ceca9c602547c07909ef0775a28214434cd60b6c856b57787e9dbbb',2025,'PA','Panama','communications',33,'Telephones - fixed lines:
total subscriptions:
790,486 (2021 est.)
subscriptions per 100 inhabitants:
18 (2021 est.)
comparison ranking:
total subscriptions 76
Telephones - mobile cellular:
total subscriptions:
6,003,255 (2021 est.)
subscriptions per 100 inhabitants:
138 (2021 est.)
comparison ranking:
total subscriptions 117
Telecommunication systems:
general assessment:
Panama has seen a steady increase in revenue from the telecom sector in recent years; mobile services and broadband remain the key growth sectors, with mobile connections accounting for 90% of all connections, and over half of telecom sector revenue; the mobile market has effective competition; internet services have grown in recent years as consumers responded to government fixed-line projects, improved mobile broadband connectivity and mobile applications (2021)
domestic:
fixed-line is 18 per 100 and subscribership of mobile-cellular telephone is 138 per 100 (2021)
international:
country code - 507; landing points for the PAN-AM, ARCOS, SAC, AURORA, PCCS, PAC, and the MAYA-1 submarine cable systems that together provide links to the US and parts of the Caribbean, Central America, and South America; satellite earth stations - 2 Intelsat (Atlantic Ocean); connected to the Central American Microwave System (2019)
Broadcast media:
multiple privately owned TV networks and a government-owned educational TV station; multi-channel cable and satellite TV subscription services are available; more than 100 commercial radio stations (2019)
Internet country code:
.pa
Internet users:
total:
2.992 million (2021 est.)
percent of population:
68% (2021 est.)
comparison ranking:
total 122
Broadband - fixed subscriptions:
total:
562,413 (2020 est.)
subscriptions per 100 inhabitants:
13 (2020 est.)
comparison ranking:
total 88','6d02abc74522c1bba4b38d872cc08faeff42c2dcdbee01a478182981d9ca046c','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ff97436126f898306b6e2ceea8d6a5ff3ca0ea73867679c15ff9af6c22954572',2025,'PG','Papua New Guinea','communications',44,'Telephones - fixed lines:
total subscriptions:
170,000 (2021 est.)
subscriptions per 100 inhabitants:
2 (2021 est.)
comparison ranking:
total subscriptions 125
Telephones - mobile cellular:
total subscriptions:
4.8 million (2021 est.)
subscriptions per 100 inhabitants:
48 (2021 est.)
comparison ranking:
total subscriptions 125
Telecommunication systems:
general assessment:
fixed-line teledensity in Papua New Guinea has seen little change over the past two decades; progress in the country’s telecom sector has come primarily from mobile networks, where accessibility has expanded considerably in recent years, with population coverage increasing from less than 3% in 2006 to more than 90% by early 2021; the MNOs operate networks offering services based on GSM, 3G, and LTE, depending on location; GSM is prevalent in many rural and remote areas, while 3G and LTE are centered more on urban areas; MNOs’ investments in 4G are growing, though GSM still represents the bulk of all mobile connections owing to the low penetration of smartphones and the concentration of high-speed data networks predominantly in high value urban areas; a lack of sufficient competition and investment in the wire line segment has driven up prices and hampered network coverage and quality; infrastructure deployment costs are high, partly due to the relatively low subscriber base, the difficult terrain, and the high proportion of the population living in rural areas; fixed telecom infrastructure is almost non-existent outside urban centers, leaving most of the population under served; PNG is the Pacific region’s largest poorly developed telecom market, with only around 22% of its people connected to the internet; this falls far behind the recommended targets set in the country’s National Broadband Policy drafted in 2013, which aimed to provide broadband access to 90% of the total population by 2018; the existing submarine cable infrastructure is insufficient to serve the country’s needs; low international capacity has meant that internet services are expensive and slow; the cable links PNG to the Solomon Islands and Australia (landing at Sydney); despite the improvement in recent years, the country is still impacted by a connectivity infrastructure deficit, making it reliant on more expensive alternatives such as satellites, also weighing on the affordability of services for end-users (2022)
domestic:
fixed-line nearly 2 per 100 and mobile-cellular is 48 per 100 persons (2021)
international:
country code - 675; landing points for the Kumul Domestic Submarine Cable System, PNG-LNG, APNG-2, CSCS and the PPC-1 submarine cables to Australia, Guam, PNG and Solomon Islands; satellite earth station - 1 Intelsat (Pacific Ocean) (2019)
Broadcast media:
4 TV stations: 1 commercial station operating since 1987, 1 state-run station launched in 2008, 1 digital free-to-view network launched in 2014, and 1 satellite network Click TV (PNGTV) launched in 2015; the state-run National Broadcasting Corporation operates 3 radio networks with multiple repeaters and about 20 provincial stations; several commercial radio stations with multiple transmission points as well as several community stations; transmissions of several international broadcasters are accessible (2018)
Internet country code:
.pg
Internet users:
total:
3.168 million (2021 est.)
percent of population:
32% (2021 est.)
comparison ranking:
total 116
Broadband - fixed subscriptions:
total:
21,000 (2020 est.)
subscriptions per 100 inhabitants:
0.2 (2020 est.)
comparison ranking:
total 165','894a9590f4abd5636a4b7a24f0fe4e4cf6893aedf7a690a4b8132bdf2e118074','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fcd2173c1f819dc37b0e89a58446ba098c6a3ce88a5f6da6123cfcff2ef68af7',2025,'PY','Paraguay','communications',63,'Telephones - fixed lines:
total subscriptions:
203,971 (2021 est.)
subscriptions per 100 inhabitants:
3 (2021 est.)
comparison ranking:
total subscriptions 121
Telephones - mobile cellular:
total subscriptions:
7,975,074 (2021 est.)
subscriptions per 100 inhabitants:
119 (2021 est.)
comparison ranking:
total subscriptions 100
Telecommunication systems:
general assessment:
limited progress on structural reform and deficient infrastructure of the landlocked country are obstacles to the telecom platform; effective competition in mobile market, serving 96% of population through LTE; deployment of fiber; operator enabled 109 free Internet points across the country and is looking to expand to 430 points in 2022; dependent on neighboring countries for access to submarine cables (2022)
domestic:
fixed-line just over 3 per 100 and mobile-cellular is 119 per 100 of the population (2021)
international:
country code - 595; Paraguay’s landlocked position means they must depend on neighbors for interconnection with submarine cable networks, making it cost more for broadband services; satellite earth station - 1 Intelsat (Atlantic Ocean) (2019)
Broadcast media:
6 privately owned TV stations; about 75 commercial and community radio stations; 1 state-owned radio network (2019)
Internet country code:
.py
Internet users:
total:
5.159 million (2021 est.)
percent of population:
77% (2021 est.)
comparison ranking:
total 90
Broadband - fixed subscriptions:
total:
562,369 (2020 est.)
subscriptions per 100 inhabitants:
8 (2020 est.)
comparison ranking:
total 89','724e212eebc32786037a1d55505a10004ef11cd2eaaf7cdf0629c73d6c5fa8d3','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cec3d2d4279fb3184a13c21161b2274bee174726378fad78e266e8b8961fcdde',2025,'PE','Peru','communications',8,'Telephones - fixed lines:
total subscriptions:
2,266,025 (2021 est.)
subscriptions per 100 inhabitants:
7 (2021 est.)
comparison ranking:
total subscriptions 53
Telephones - mobile cellular:
total subscriptions:
43,129,394 (2021 est.)
subscriptions per 100 inhabitants:
128 (2021 est.)
comparison ranking:
total subscriptions 39
Telecommunication systems:
general assessment:
after suffering a sharp retraction in the number of subscriptions and revenue during 2020 due to the pandemic, Peru’s telecom sector managed to stage a small recovery in the first half of 2021; it will likely be two to three years before penetration rates return to the peak levels last seen in 2018; this is especially true given the overwhelming influence of mobile on Peru’s telecommunications market, which now commands almost 95% of all connections; Peru’s fixed-line teledensity continued its slow dropping below 7% at the end of 2021; investment in network infrastructure is mainly focused on rolling out fiber cable for fixed broadband services in (mainly) urban areas; fixed broadband services inched higher to reach 8.4% at the end of 2020, a positive result that reflected the shift to working from home during enforced lock downs at the start of the year; yet Peru has a relatively low level of computer use, and prices for fixed broadband services are among the highest in Latin America; the overwhelmingly preferred internet access platform will remain the smartphone, with a further 8.6% growth in the number of mobile broadband subscriptions expected in 2021 (2021)
domestic:
fixed-line teledensity is 7 per 100 persons; mobile-cellular teledensity is 128 telephones per 100 persons (2021)
international:
country code - 51; landing points for the SAM-1, IGW, American Movil-Telxius, SAC and PAN-AM submarine cable systems that provide links to parts of Central and South America, the Caribbean, and US; satellite earth stations - 2 Intelsat (Atlantic Ocean) (2019)
Broadcast media:
10 major TV networks of which only one, Television Nacional de Peru, is state owned; multi-channel cable TV services are available; in excess of 5,000 radio stations including a substantial number of indigenous language stations (2021)
Internet country code:
.pe
Internet users:
total:
24.14 million (2021 est.)
percent of population:
71% (2021 est.)
comparison ranking:
total 35
Broadband - fixed subscriptions:
total:
3.044 million (2020 est.)
subscriptions per 100 inhabitants:
9 (2020 est.)
comparison ranking:
total 46','cf1a503ad73555b9b4aec6b3b0c33b172a2b01ec8fb3ae15e1873b5d7b92a02c','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a5e1562a917966685738c9ede22ccd02a48b92252aa3472cb0ad52e6d911a4d5',2025,'PH','Philippines','communications',21,'Telephones - fixed lines:
total subscriptions:
5,028,018 (2021 est.)
subscriptions per 100 inhabitants:
4 (2021 est.)
comparison ranking:
total subscriptions 27
Telephones - mobile cellular:
total subscriptions:
163,345,244 (2021 est.)
subscriptions per 100 inhabitants:
143 (2021 est.)
comparison ranking:
total subscriptions 11
Telecommunication systems:
general assessment:
the Covid-19 pandemic had a relatively minor impact on the Philippine’s telecom sector in 2020; subscriber numbers fell in some areas, but this was offset by strong growth in mobile data and broadband usage since a significant proportion of the population transitioned to working or studying from home; major investment programs covering LTE, 5G, and fiber broadband networks suffered slight delays due to holdups in supply chains, but activity has since ramped up in an attempt to complete the roll outs as per the original schedule; the major telecom operators had mixed financial results for the past year; overall, the number of mobile subscribers is expected to grow to 153 million by the end of 2021, with the penetration rate approaching 144%; the government remains keen, and committed, to seeing strong competition, growth, and service excellence in the telecom sector, so there is likely to be continued support (financially as well as through legislation such as enabling mobile tower sharing and number portability) to ensure that the sector remains viable for emerging players; the mobile sector will remain the Philippines’ primary market for telecommunications well into the future; the unique terrain and resulting challenges associated with accessing remote parts of the archipelago means that in many areas fixed networks are neither cost-effective nor logistically viable; the bulk of telecoms investment over the coming years will continue to be in 5G and 5G-enabled LTE networks; coverage of LTE and 5G networks extends to over 95% of the population, and for the vast majority of people mobile will likely remain their only platform for telecom services (2021)
domestic:
fixed-line nearly 4 per 100 and mobile-cellular nearly 143 per 100 (2021)
international:
country code - 63; landing points for the NDTN, TGN-IA, AAG, PLCN, EAC-02C, DFON, SJC, APCN-2, SeaMeWe, Boracay-Palawan Submarine Cable System, Palawa-Illoilo Cable System, NDTN, SEA-US, SSSFOIP, ASE and JUPITAR submarine cables that together provide connectivity to the US, Southeast Asia, Asia, Europe, Africa, the Middle East, and Australia (2019)
Broadcast media:
multiple national private TV and radio networks; multi-channel satellite and cable TV systems available; more than 400 TV stations; about 1,500 cable TV providers with more than 2 million subscribers, and some 1,400 radio stations; the Philippines adopted Japan’s Integrated Service Digital Broadcast – Terrestrial standard for digital terrestrial television in November 2013 and is scheduled to complete the switch from analog to digital broadcasting by the end of 2023 (2019)
Internet country code:
.ph
Internet users:
total:
58.3 million (2021 est.)
percent of population:
53% (2021 est.)
comparison ranking:
total 18
Broadband - fixed subscriptions:
total:
7,936,574 (2020 est.)
subscriptions per 100 inhabitants:
7 (2020 est.)
comparison ranking:
total 25','6bb26d5cac3eb1fb5501bcddc9f2f4353e6d34e3d5c1fbf7b66772a62de09b5c','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('745382d4723b15e6d7ad0c51ee66f5b9a9000f3388dc460fdd15bece3eb53b29',2025,'PH','Philippines','communications',33,'Telecommunication systems:
general assessment:
satellite-based phone services; rural connectivity a challenge; 2G services widespread; demand for mobile broadband due to mobile services providing Internet source; the launch of the Kacific-1 satellite in 2019 will improve telecommunications in the region (2020)
domestic:
local phone service with international connections via Internet (2018)
international:
country code - 872; satellite earth station - 1 Inmarsat
Broadcast media:
satellite TV from Fiji-based Sky Pacific offering a wide range of international channels
Internet country code:
.pn
Internet users:
total:
37 (2021 est.)
percent of population:
96.2% (2021 est.)
comparison ranking:
total 234
Communications - note:
satellite-based local phone service and broadband Internet connections available in all homes','5f312b9300565171065bcde886ac8e0964e3cac0fac7a46c003469d8074cda5b','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ca5e0094552fd0976b15a81a80da761b2056733ef54b05a71c1ea60d2f9570b4',2025,'PL','Poland','communications',44,'Telephones - fixed lines:
total subscriptions:
5,308,497 (2021 est.)
subscriptions per 100 inhabitants:
14 (2021 est.)
comparison ranking:
total subscriptions 25
Telephones - mobile cellular:
total subscriptions:
50,588,785 (2021 est.)
subscriptions per 100 inhabitants:
132 (2021 est.)
comparison ranking:
total subscriptions 33
Telecommunication systems:
general assessment:
the liberalized telecom market has seen considerable development in the broadband and mobile sectors; the regulatory environment has encouraged market competition, partly by encouraging operators to secure spectrum and also by ensuring access to cable and fiber infrastructure; the mobile market in recent years has been characterized by the rapid extension of LTE and 5G networks, and the development of mobile data services based on newly released and re-farmed spectrum; the regulator’s attempts to auction spectrum in a range of bands has been delayed, with spectrum in the 5G-suitable 3.4-3.8GHz range having been put back to later in 2023 as a result of the Covid-19 outbreak and changes to legislation (2021)
domestic:
fixed-line is 14 per 100 (service lags in rural areas), mobile-cellular is 132 per 100 persons (2021)
international:
country code - 48; landing points for the Baltica and the Denmark-Poland2 submarine cables connecting Poland, Denmark and Sweden; international direct dialing with automated exchanges; satellite earth station - 1 with access to Intelsat, Eutelsat, Inmarsat, and Intersputnik (2019)
Broadcast media:
state-run public TV operates 2 national channels supplemented by 16 regional channels and several niche channels; privately owned entities operate several national TV networks and a number of special interest channels; many privately owned channels broadcasting locally; roughly half of all households are linked to either satellite or cable TV systems providing access to foreign television networks; state-run public radio operates 5 national networks and 17 regional radio stations; 2 privately owned national radio networks, several commercial stations broadcasting to multiple cities, and many privately owned local radio stations (2019)
Internet country code:
.pl
Internet users:
total:
32.3 million (2021 est.)
percent of population:
85% (2021 est.)
comparison ranking:
total 31
Broadband - fixed subscriptions:
total:
8,369,218 (2020 est.)
subscriptions per 100 inhabitants:
22 (2020 est.)
comparison ranking:
total 24','e80da99b7f1cf8a0657bdf8868ed980c199643f750c402fa38b07c0cf632368a','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('54d20b0e39a18a563db0a6c655ae742731d84fc0703d09189a5379b4fcd7a291',2025,'PT','Portugal','communications',57,'Telephones - fixed lines:
total subscriptions:
5,318,750 (2021 est.)
subscriptions per 100 inhabitants:
52 (2021 est.)
comparison ranking:
total subscriptions 24
Telephones - mobile cellular:
total subscriptions:
12,476,165 (2021 est.)
subscriptions per 100 inhabitants:
121 (2021 est.)
comparison ranking:
total subscriptions 80
Telecommunication systems:
general assessment:
Portugal has a medium-sized telecom market with a strong mobile sector and a growing broadband customer base; before the pandemic, the country had seen improving economic growth, following several years of austerity measures; revenue among some operators remains under pressure, though investments in network upgrades are continuing in an effort to attract customers to high-end services; Portugal’s broadband services have grown steadily in recent years, largely the result of joint efforts between the regulator and the key market operators which have invested in significant infrastructure upgrades; these operators are focused on fiber-based services, resulting in a migration of subscribers from digital subscriber line DSL infrastructure; the government has also supported open-access wholesale networks; the mobile virtual network operator (MVNO) market remains largely undeveloped, partly because network operators have their own low-cost brands; collectively, MVNOs have about 2.9% share of the market; population coverage by 3G infrastructure is universal, and most investment in the sector is being directed to LTE and 5G technologies; the MNOs have trialed 5G and are looking to launch commercial services (2021)
domestic:
fixed-lineis 52 per 100 persons and mobile-cellular is 121 per 100 persons (2021)
international:
country code - 351; landing points for the Ella Link, BUGIO, EIG, SAT-3/WASC, SeaMeWe-3, Equino, MainOne, Tat TGN-Western Europe, WACS, ACE, Atlantis2 and Columbus-III submarine cables provide connectivity to Europe, Africa, the Middle East, Asia, Southeast Asia, Australia, South America and the US; satellite earth stations - 3 Intelsat (2 Atlantic Ocean and 1 Indian Ocean), NA Eutelsat; tropospheric scatter to Azores (2019)
Broadcast media:
Radio e Televisao de Portugal, the publicly owned TV broadcaster, operates 4 domestic channels and external service channels to Africa; overall, roughly 40 domestic TV stations; viewers have widespread access to international broadcasters with more than half of all households connected to multi-channel cable or satellite TV systems; publicly owned radio operates 3 national networks and provides regional and external services; several privately owned national radio stations and some 300 regional and local commercial radio stations
Internet country code:
.pt
Internet users:
total:
8.2 million (2021 est.)
percent of population:
82% (2021 est.)
comparison ranking:
total 73
Broadband - fixed subscriptions:
total:
4,160,795 (2020 est.)
subscriptions per 100 inhabitants:
41 (2020 est.)
comparison ranking:
total 37','202d7fc16d36dbbdeee9f6d45c606f7e0c37352d1a58cea9c10f84947b31f196','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c1650311d0279d30639166d577791c77aa66d57b7d15a036a938532669fb7150',2025,'PR','Puerto Rico','communications',70,'Telephones - fixed lines:
total subscriptions:
726,739 (2021 est.)
subscriptions per 100 inhabitants:
22 (2021 est.)
comparison ranking:
total subscriptions 80
Telephones - mobile cellular:
total subscriptions:
3,661,176 (2021 est.)
subscriptions per 100 inhabitants:
112 (2021 est.)
comparison ranking:
total subscriptions 137
Telecommunication systems:
general assessment:
Puerto Rico has a small telecom market which in recent years has been deeply affected by a combination of economic mismanagement and natural disasters, including two hurricanes which landed in late 2017 and an earthquake which struck in January 2020; these disasters caused considerable destruction of telecom infrastructure, which in turn led to a marked decline in the number of subscribers for all services; compounding these difficulties have been a long-term economic downturn which encouraged many people not to resume telecom services after these were restored; after some delay, the FCC in late 2019 issued an order relating to the release of funds to help rebuild telecom infrastructure; although Puerto Rico is a US territory it lags well behind the mainland US states in terms of fixed-line and broadband services; this is partly due to high unemployment rates (and consequently low disposable income) and poor telecoms investment in a market; the mobile market has been impacted by several mergers and acquisitions over the last few years; the activities of large multinational telcos continue to impact the Puerto Rican market; operators have secured spectrum in the 600MHz and 3.5GHz bands, thus enabling them to expand the reach of LTE services and launch services based on 5G; the growing number of submarine cables landing in Puerto Rico is helping to drive down the cost of telecom services, creating a demand for streaming content from abroad; the uptake of cloud-based applications for both business and individuals is also creating a heightened demand for affordable services (2021)
domestic:
fixed-line is 22 per 100 and mobile-cellular is 112 per 100 persons (2021)
international:
country code - 1-787, 939; landing points for the GTMO-PR, AMX-1, BRUSA, GCN, PCCS, SAm-1, Southern Caribbean Fiber, Americas-II, Antillas, ARCOS, SMPR-1, and Taino-Carib submarine cables providing connectivity to the mainland US, Caribbean, Central and South America; satellite earth station - 1 Intelsat (2019)
Broadcast media:
more than 30 TV stations operating; cable TV subscription services are available; roughly 125 radio stations
Internet country code:
.pr
Internet users:
total:
2,564,100 (2021 est.)
percent of population:
77.7% (2021 est.)
comparison ranking:
total 127
Broadband - fixed subscriptions:
total:
671,284 (2020 est.)
subscriptions per 100 inhabitants:
24 (2020 est.)
comparison ranking:
total 83','e8212d6a523a42cc557235d6af8c30e356d7d9f754b85e7b6cb023fe935eb1d2','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e5e305210585638df4c87cb7f7ede14ec586cd42b075105145f950310fdcaf9b',2025,'QA','Qatar','communications',8,'Telephones - fixed lines:
total subscriptions:
460,240 (2021 est.)
subscriptions per 100 inhabitants:
17 (2021 est.)
comparison ranking:
total subscriptions 98
Telephones - mobile cellular:
total subscriptions:
3,876,499 (2021 est.)
subscriptions per 100 inhabitants:
144 (2021 est.)
comparison ranking:
total subscriptions 134
Telecommunication systems:
general assessment:
Qatar had developed a mature telecom sector which has been able to absorb the additional data demands made on it during the pandemic; mobile services based on LTE are universally available to migrate to 5G; in combination with a strong fiber rollout, the country is aiming to provide gigabit services nationally; 5G services are largely based on 3.5GHz spectrum made available following an auction in early 2019 (2022)
domestic:
fixed-line is 17 per 100 and mobile-cellular telephone subscribership is 144 telephones per 100 persons (2021)
international:
country code - 974; landing points for the Qatar-UAE Submarine Cable System, AAE-1, FOG, GBICS/East North Africa MENA and the FALCON submarine cable network that provides links to Asia, Africa, the Middle East, Europe and Southeast Asia; tropospheric scatter to Bahrain; microwave radio relay to Saudi Arabia and the UAE; satellite earth stations - 2 Intelsat (1 Atlantic Ocean and 1 Indian Ocean) and 1 Arabsat; retains full ownership of two commercial satellites, Es’hailSat 1 and 2 (2019)
Broadcast media:
TV and radio broadcast licensing and access to local media markets are state controlled; home of the satellite TV channel Al-Jazeera, which was originally owned and financed by the Qatari government but has evolved to independent corporate status; Al-Jazeera claims editorial independence in broadcasting; local radio transmissions include state, private, and international broadcasters on FM frequencies in Doha; in August 2013, Qatar’s satellite company Es’hailSat launched its first communications satellite Es’hail 1 (manufactured in the US), which entered commercial service in December 2013 to provide improved television broadcasting capability and expand availability of voice and Internet; Es’hailSat launched its second commercial satellite in 2018 with aid of SpaceX (2019)
Internet country code:
.qa
Internet users:
total:
2.7 million (2021 est.)
percent of population:
100% (2021 est.)
comparison ranking:
total 126
Broadband - fixed subscriptions:
total:
296,126 (2020 est.)
subscriptions per 100 inhabitants:
10 (2020 est.)
comparison ranking:
total 107','868afe4b5583308bb4d20d93910d2074fc9cbe9212d4588abbef2d87c1ca63d0','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2439352a1e992be2ecd1c43e1836b1ad5806f27244cb25c4c9e7d594c43b754c',2025,'RO','Romania','communications',8,'Telephones - fixed lines:
total subscriptions:
2.606 million (2021 est.)
subscriptions per 100 inhabitants:
13 (2021 est.)
comparison ranking:
total subscriptions 47
Telephones - mobile cellular:
total subscriptions:
22.929 million (2021 est.)
subscriptions per 100 inhabitants:
119 (2021 est.)
comparison ranking:
total subscriptions 55
Telecommunication systems:
general assessment:
Romania’s telecom market has undergone several significant changes in recent years; the mobile market is served by network operators that have extensive LTE networks in place, while services based on 5G have been offered under their existing spectrum concessions since 2019; the delayed multi-spectrum auction, expected to be completed later in 2021, will enable the operators to expand 5G network capacity and enable consumers to make far greater use of the technology’s potential; in line with legislation passed in July 2021 the MNOs will have to replace equipment provided by vendors deemed to be a security risk (2021)
domestic:
fixed-line teledensity is 13 telephones per 100 persons; mobile-cellular teledensity is119 telephones per 100 persons (2021)
international:
country code - 40; landing point for the Diamond Link Global submarine cable linking Romania with Georgia; satellite earth stations - 10; digital, international, direct-dial exchanges operate in Bucharest (2019)
Broadcast media:
a mixture of public and private TV stations; there are 7 public TV stations (2 national, 5 regional) using terrestrial broadcasting and 187 private TV stations (out of which 171 offer local coverage) using terrestrial broadcasting, plus 11 public TV stations using satellite broadcasting and 86 private TV stations using satellite broadcasting; state-owned public radio broadcaster operates 4 national networks and regional and local stations, having in total 20 public radio stations by terrestrial broadcasting plus 4 public radio stations by satellite broadcasting; there are 502 operational private radio stations using terrestrial broadcasting and 26 private radio stations using satellite broadcasting
Internet country code:
.ro
Internet users:
total:
15.96 million (2021 est.)
percent of population:
84% (2021 est.)
comparison ranking:
total 47
Broadband - fixed subscriptions:
total:
5,684,782 (2020 est.)
subscriptions per 100 inhabitants:
30 (2020 est.)
comparison ranking:
total 32','4d7a19180ea42748b3f45db5ef444fb8b6ef652e01f7ccf0db03d70122cdf5a9','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('77fb7180eeb3934cdc23a6ce0b8e978fc2d9375d6e8be10763fd5736dffa450e',2025,'RO','Romania','communications',21,'Telephones - fixed lines:
total subscriptions:
24 million (2021 est.)
subscriptions per 100 inhabitants:
16 (2021 est.)
comparison ranking:
total subscriptions 10
Telephones - mobile cellular:
total subscriptions:
250 million (2021 est.)
subscriptions per 100 inhabitants:
170 (2021 est.)
comparison ranking:
total subscriptions 5
Telecommunication systems:
general assessment:
the telecom market is the largest in Europe, supported by a population approaching 147 million; the overall market is dominated by the western regions, particularly Moscow and St Petersburg which are the main cities and economic centers; all sectors of the market have been liberalized, with competition most prevalent in the two largest regional markets; the fiber broadband sector has shown considerable growth, supported by the government’s program to extend the reach of broadband to outlying regions; the development of 5G services has been stymied by the lack of spectrum; although MNOs have licenses to use 700MHz spectrum for 5G, this spectrum has yet to be released by broadcasters; spectrum in the 3.4GHz range commonly used for 5G in Europe has been restricted for use in Russia by the military and intelligence agencies; despite these limitations, the four principal MNOs each have an equal share in a joint venture aimed at developing a strategy to deploy 5G using shared network and spectrum assets (2022)
domestic:
16 per 100 for fixed-line and mobile-cellular is 170 per 100 persons (2021)
international:
country code - 7; landing points for the Far East Submarine Cable System, HSCS, Sakhalin-Kuril Island Cable, RSCN, BCS North-Phase 2, Kerch Strait Cable and the Georgia-Russian submarine cable system connecting Russia, Japan, Finland, Georgia and Ukraine; satellite earth stations provide access to Intelsat, Intersputnik, Eutelsat, Inmarsat, and Orbita systems (2019)
Broadcast media:
13 national TV stations with the federal government owning 1 and holding a controlling interest in a second; state-owned Gazprom maintains a controlling interest in 2 of the national channels; government-affiliated Bank Rossiya owns controlling interest in a fourth and fifth, while a sixth national channel is owned by the Moscow city administration; the Russian Orthodox Church and the Russian military, respectively, own 2 additional national channels; roughly 3,300 national, regional, and local TV stations with over two-thirds completely or partially controlled by the federal or local governments; satellite TV services are available; 2 state-run national radio networks with a third majority-owned by Gazprom; roughly 2,400 public and commercial radio stations
Internet country code:
.ru; note - Russia also has responsibility for a legacy domain “.su” that was allocated to the Soviet Union and is being phased out
Internet users:
total:
132 million (2021 est.)
percent of population:
88% (2021 est.)
comparison ranking:
total 6
Broadband - fixed subscriptions:
total:
33,893,305 (2020 est.)
subscriptions per 100 inhabitants:
23 (2020 est.)
comparison ranking:
total 6','a1d9f4226b4197d8dd8c82d1b5eb055f885d157ad5e90bc6dca373df21ee8e5b','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3bc6d14db67ddecfa1133ab622e116772fb90e1bc0858d3b249778d58cdd35ec',2025,'RW','Rwanda','communications',34,'Telephones - fixed lines:
total subscriptions:
11,893 (2021 est.)
subscriptions per 100 inhabitants:
(2021 est.) less than 1
comparison ranking:
total subscriptions 185
Telephones - mobile cellular:
total subscriptions:
10,902,989 (2021 est.)
subscriptions per 100 inhabitants:
81 (2021 est.)
comparison ranking:
total subscriptions 89
Telecommunication systems:
general assessment:
Rwanda was slow to liberalize the mobile sector; there was effective competition among three operators; the fixed broadband sector has suffered from limited fixed-line infrastructure and high prices; operators are rolling out national backbone networks which also allow them to connect to the international submarine cables on Africa’s east coast; these cables gave the entire region greater internet bandwidth and ended the dependency on satellites; while the country also has a new cable link with Tanzania, and via Tanzania’s national broadband backbone it has gained connectivity to the networks of several other countries in the region; the number of subscribers on LTE infrastructure has increased sharply, helped by national LTE coverage achieved in mid-2018; mobile remains the dominant platform for voice and data services; the regulator noted that the number of mobile subscribers increased 2.7% in 2021, year-on-year; there was a slight fall in the beginning of 2022 (2022)
domestic:
fixed-line less than 1 per 100 and mobile-cellular telephone density is 81 telephones per 100 persons (2021)
international:
country code - 250; international connections employ microwave radio relay to neighboring countries and satellite communications to more distant countries; satellite earth stations - 1 Intelsat (Indian Ocean) in Kigali (includes telex and telefax service); international submarine fiber-optic cables on the African east coast has brought international bandwidth and lessened the dependency on satellites
Broadcast media:
13 TV stations; 35 radio stations registered, including international broadcasters, government owns most popular TV and radio stations; regional satellite-based TV services available
Internet country code:
.rw
Internet users:
total:
3.9 million (2021 est.)
percent of population:
30% (2021 est.)
comparison ranking:
total 112
Broadband - fixed subscriptions:
total:
17,685 (2020 est.)
subscriptions per 100 inhabitants:
0.1 (2020 est.)
comparison ranking:
total 171','8418893bd0c9d19d81ea2b391c90217e71aa699d003c7f2015ff299be09110b5','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('453f7fb59d39f57e71a3a718e763df61d38cf06acfdc9d2b625c7c4ad8b53d20',2025,'KN','Saint Kitts and Nevis','communications',10,'Telephones - fixed lines:
total subscriptions:
16,000 (2021 est.)
subscriptions per 100 inhabitants:
33 (2021 est.)
comparison ranking:
total subscriptions 179
Telephones - mobile cellular:
total subscriptions:
57,000 (2021 est.)
subscriptions per 100 inhabitants:
120 (2021 est.)
comparison ranking:
total subscriptions 205
Telecommunication systems:
general assessment:
good interisland and international connections; broadband access; expanded FttP (Fiber to the Home) and LTE markets; regulatory development; telecom sector contributes greatly to the overall GDP; telecom sector is a growth area (2020)
domestic:
fixed-line teledensity is 33 per 100 persons; mobile-cellular teledensity is 120 per 100 persons (2021)
international:
country code - 1-869; landing points for the ECFS, Southern Caribbean Fiber and the SSCS submarine cables providing connectivity for numerous Caribbean Islands (2019)
Broadcast media:
the government operates a national TV network that broadcasts on 2 channels; cable subscription services provide access to local and international channels; the government operates a national radio network; a mix of government-owned and privately owned broadcasters operate roughly 15 radio stations (2019)
Internet country code:
.kn
Internet users:
total:
37,920 (2021 est.)
percent of population:
79% (2021 est.)
comparison ranking:
total 205
Broadband - fixed subscriptions:
total:
30,000 (2020 est.)
subscriptions per 100 inhabitants:
56 (2020 est.)
comparison ranking:
total 154','991321cc5ee53110ca6b0d6fc3539ed6c4fa80224f4e01deee5162acdbf645bb','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('14edb23b291f9321999d21ed3e04141fb8420d46c8b8afb504987a0bfe0232a9',2025,'LC','Saint Lucia','communications',21,'Telephones - fixed lines:
total subscriptions:
14,000 (2021 est.)
subscriptions per 100 inhabitants:
8 (2021 est.)
comparison ranking:
total subscriptions 183
Telephones - mobile cellular:
total subscriptions:
170,000 (2021 est.)
subscriptions per 100 inhabitants:
96 (2021 est.)
comparison ranking:
total subscriptions 186
Telecommunication systems:
general assessment:
an adequate system that is automatically switched; good interisland and international connections; broadband access; expanded FttP (Fiber to the Home) and LTE markets; regulatory development; telecom sector contributes to the overall GDP; telecom sector is a growth area (2020)
domestic:
fixed-line teledensity is 8 per 100 persons and mobile-cellular teledensity is roughly 96 per 100 persons (2021)
international:
country code - 1-758; landing points for the ECFS and Southern Caribbean Fiber submarine cables providing connectivity to numerous Caribbean islands; direct microwave radio relay link with Martinique and Saint Vincent and the Grenadines; tropospheric scatter to Barbados (2019)
Broadcast media:
3 privately owned TV stations; 1 public TV station operating on a cable network; multi-channel cable TV service available; a mix of state-owned and privately owned broadcasters operate nearly 25 radio stations including repeater transmission stations (2019)
Internet country code:
.lc
Internet users:
total:
140,400 (2021 est.)
percent of population:
78% (2021 est.)
comparison ranking:
total 183
Broadband - fixed subscriptions:
total:
33,000 (2020 est.)
subscriptions per 100 inhabitants:
18 (2020 est.)
comparison ranking:
total 149','6055867e5baf5b4c8d89e91a27d6f7cf3af50cb101b0ea18771e620da0f5fad7','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6ed175579f50e7a4ed46277eae87040b35639bf0bc75156c28da1761e0b31bca',2025,'LC','Saint Lucia','communications',32,'Telephones - mobile cellular:
total subscriptions:
68,840 (2012 est.)
subscriptions per 100 inhabitants:
196 (2012 est.)
comparison ranking:
total subscriptions 198
Telecommunication systems:
general assessment:
fully integrated access; good interisland and international connections; broadband access; expanded FttP (Fiber to the Home) and LTE markets; regulatory development; telecom sector contributes greatly to the overall GDP; telecom sector is a growth area (2020)
domestic:
direct dial capability with both fixed and wireless systems (2018)
international:
country code - 590; landing points for the SMPR-1, Southern Caribbean Fiber and the Saba, Statia Cable System submarine cables providing connectivity to numerous Caribbean islands (2019)
Broadcast media:
1 local TV station; access to about 20 radio stations, including RFO Guadeloupe radio broadcasts via repeater
Internet country code:
.mf; note - .gp, the Internet country code for Guadeloupe, and .fr, the Internet country code for France, might also be encountered
Internet users:
total:
19,284 (2022 est.)
percent of population:
48.5% (2022 est.)
comparison ranking:
total 212','5789311fe20cc4f91ba0f3c1e39d0f951ec394b321af0a7ce4c38447c98f92b7','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fea3a36ea4ddb6c28f3c18e21ca6e38858028e342786d175da2660d694be6bf4',2025,'PM','Saint Pierre and Miquelon','communications',43,'Telephones - fixed lines:
total subscriptions:
4,800 (2015 est.)
subscriptions per 100 inhabitants:
76 (2015 est.)
comparison ranking:
total subscriptions 207
Telecommunication systems:
general assessment:
adequate (2019)
domestic:
fixed-line teledensity 76 per 100 persons (2019)
international:
country code - 508; landing point for the St Pierre and Miquelon Cable connecting Saint Pierre & Miquelon and Canada; radiotelephone communication with most countries in the world; satellite earth station - 1 in French domestic satellite system (2019)
Broadcast media:
8 TV stations, all part of the French Overseas Network, and local cable provided by SPM Telecom; 3 of 4 radio stations on St. Pierre and on Miquelon are part of the French Overseas Network (2021)
Internet country code:
.pm
Internet users:
total:
5,099 (2022 est.)
percent of population:
88.7% (2022 est.)
comparison ranking:
total 223','f3b44a3d059fe2573da63e9704eb4c095a58992768c12cad2909bd8d494839ab','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b28b340e332de320ec7a51ffe346af56fde80e4405995a12a2af05e696886ca3',2025,'VC','Saint Vincent and the Grenadines','communications',54,'Telephones - fixed lines:
total subscriptions:
11,385 (2021 est.)
subscriptions per 100 inhabitants:
11 (2021 est.)
comparison ranking:
total subscriptions 188
Telephones - mobile cellular:
total subscriptions:
114,892 (2021 est.)
subscriptions per 100 inhabitants:
110 (2021 est.)
comparison ranking:
total subscriptions 190
Telecommunication systems:
general assessment:
adequate island-wide, fully automatic telephone system; broadband access; expanded FttP (Fiber to the Home) markets; LTE launches; regulatory development; telecom sector contributes greatly to the overall GDP; telecom sector is a growth area (2020)
domestic:
fixed-line teledensity is 11 per 100 persons and mobile-cellular teledensity is 110 per 100 persons (2021)
international:
country code - 1-784; landing points for the ECFS, CARCIP and Southern Caribbean Fiber submarine cables providing connectivity to US and Caribbean Islands; connectivity also provided by VHF/UHF radiotelephone from Saint Vincent to Barbados; SHF radiotelephone to Grenada and Saint Lucia; access to Intelsat earth station in Martinique through Saint Lucia (2019)
Broadcast media:
St. Vincent and the Grenadines Broadcasting Corporation operates 1 TV station and 5 repeater stations that provide near total coverage to the multi-island state; multi-channel cable TV service available; a partially government-funded national radio service broadcasts on 1 station and has 2 repeater stations; about a dozen privately owned radio stations and repeater stations
Internet country code:
.vc
Internet users:
total:
85,000 (2021 est.)
percent of population:
85% (2021 est.)
comparison ranking:
total 192
Broadband - fixed subscriptions:
total:
24,733 (2020 est.)
subscriptions per 100 inhabitants:
22 (2020 est.)
comparison ranking:
total 161','81dcbf2274928dbe17eb5a4713470628896f64dbcf31007c554cc3d4264b7bca','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('59cddea07404832e559cde311909ab65889cf125bdb2939b00996cacef84ce53',2025,'WS','Samoa','communications',65,'Telephones - fixed lines:
total subscriptions:
6,000 (2021 est.)
subscriptions per 100 inhabitants:
3 (2021 est.)
comparison ranking:
total subscriptions 202
Telephones - mobile cellular:
total subscriptions:
69,000 (2021 est.)
subscriptions per 100 inhabitants:
32 (2021 est.)
comparison ranking:
total subscriptions 197
Telecommunication systems:
general assessment:
Samoa was one of the first Pacific Island countries to establish a regulatory infrastructure and to liberalize its telecom market; the advent of competition in the mobile market saw prices fall by around 50% and network coverage increase to more than 90% of the population; Samoa also boasts one of the highest rates of mobile phone coverage in the Pacific region; the growth of fixed-line internet has been impeded by factors including the high costs for bandwidth, under investment in fixed-line infrastructure; Samoa’s telecoms sector has been inhibited by a lack of international connectivity; Samoa has had access to the Samoa-America-Samoa (SAS) cable laid in 2009, this cable has insufficient capacity to meet the country’s future bandwidth needs; this issue was addressed with two new submarine cables that became available in 2018 and 2019; combined with the Samoa National Broadband Highway (SNBH), have improved internet data rates and reliability, and have helped to reduce the high costs previously associated with internet access in Samoa; in April 2022, the Samoan government announced its decision to take over control of the Samoa Submarine Cable Company, looking to the cable to generate additional revenue for the state (2022)
domestic:
fixed-line is 3 per 100 and mobile-cellular teledensity 32 telephones per 100 persons (2021)
international:
country code - 685; landing points for the Tui-Samo, Manatua, SAS, and Southern Cross NEXT submarine cables providing connectivity to Samoa, Fiji, Wallis & Futuna, Cook Islands, Niue, French Polynesia, American Samoa, Australia, New Zealand, Kiribati, Los Angeles (US), and Tokelau; satellite earth station - 1 Intelsat (Pacific Ocean) (2019)
Broadcast media:
state-owned TV station privatized in 2008; 4 privately owned television broadcast stations; about a half-dozen privately owned radio stations and one state-owned radio station; TV and radio broadcasts of several stations from American Samoa are available (2019)
Internet country code:
.ws
Internet users:
total:
171,600 (2021 est.)
percent of population:
78% (2021 est.)
comparison ranking:
total 182
Broadband - fixed subscriptions:
total:
1,692 (2020 est.)
subscriptions per 100 inhabitants:
1 (2020 est.)
comparison ranking:
total 199','a369c5a0e21b7ecf88e6daf9a39a00b765f2e2e2ddf1e867c35e387b0e5676fa','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a204430ca7a2583cba52d84dbec192e833177d838841d16510e3f5b875f816e1',2025,'SM','San Marino','communications',8,'Telephones - fixed lines:
total subscriptions:
16,000 (2021 est.)
subscriptions per 100 inhabitants:
47 (2021 est.)
comparison ranking:
total subscriptions 178
Telephones - mobile cellular:
total subscriptions:
40,000 (2021 est.)
subscriptions per 100 inhabitants:
119 (2021 est.)
comparison ranking:
total subscriptions 208
Telecommunication systems:
general assessment:
automatic telephone system completely integrated into Italian system (2018)
domestic:
fixed-line is 47 per 100 and mobile-cellular teledensity is 119 telephones per 100 persons (2021)
international:
country code - 378; connected to Italian international network
Broadcast media:
state-owned public broadcaster operates 1 TV station and 3 radio stations; receives radio and TV broadcasts from Italy (2019)
Internet country code:
.sm
Internet users:
total:
25,500 (2021 est.)
percent of population:
75% (2021 est.)
comparison ranking:
total 210
Broadband - fixed subscriptions:
total:
11,000 (2020 est.)
subscriptions per 100 inhabitants:
32 (2020 est.)
comparison ranking:
total 179','d6ce82fdd8126f5f2977917bcb06de07e453c31c3e825abee36bfb25676d8989','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4d9ccea66502d041170f5311d3d58ae3e1dcabc04f76f974bc48d6960b0c4279',2025,'ST','Sao Tome and Principe','communications',19,'Telephones - fixed lines:
total subscriptions:
2,619 (2021 est.)
subscriptions per 100 inhabitants:
1 (2021 est.)
comparison ranking:
total subscriptions 213
Telephones - mobile cellular:
total subscriptions:
189,239 (2021 est.)
subscriptions per 100 inhabitants:
85 (2021 est.)
comparison ranking:
total subscriptions 183
Telecommunication systems:
general assessment:
local telephone network of adequate quality with most lines connected to digital switches; mobile cellular superior choice to landland; dial-up quality low; broadband expensive (2018)
domestic:
fixed-line is 1 per 100 and mobile-cellular teledensity is 85 telephones per 100 persons (2021)
international:
country code - 239; landing points for the Ultramar GE and ACE submarine cables from South Africa to over 20 West African countries and Europe; satellite earth station - 1 Intelsat (Atlantic Ocean) (2019)
Broadcast media:
1 government-owned TV station; 1 government-owned radio station; 3 independent local radio stations authorized in 2005 with 2 operating at the end of 2006; transmissions of multiple international broadcasters are available
Internet country code:
.st
Internet users:
total:
112,200 (2021 est.)
percent of population:
51% (2021 est.)
comparison ranking:
total 185
Broadband - fixed subscriptions:
total:
2,512 (2020 est.)
subscriptions per 100 inhabitants:
1 (2020 est.)
comparison ranking:
total 197','d2c494f40df2f429fa3bad670eac057836cdbb80889b0d42159442d7b6101eb3','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4bcbbc9e60db29cc2a83ef90df68aa97979cd7f85267663564e6a3a55a48fe5b',2025,'SA','Saudi Arabia','communications',30,'Telephones - fixed lines:
total subscriptions:
6,594,631 (2021 est.)
subscriptions per 100 inhabitants:
18 (2021 est.)
comparison ranking:
total subscriptions 23
Telephones - mobile cellular:
total subscriptions:
45,427,321 (2021 est.)
subscriptions per 100 inhabitants:
126 (2021 est.)
comparison ranking:
total subscriptions 37
Telecommunication systems:
general assessment:
Saudi Arabia’s telecom and ICT sectors continue to benefit from the range of programs aimed at diversifying the economy away from a dependence on oil, and establishing a wider digital transformation over the next decade; an essential element of this has been the widening reach of 5G networks, which by mid-2021 reached about half of the population and the majority of cities; the MNOs have focused investment on upgrading LTE infrastructure and further developing 5G; this in part is aimed at generating additional revenue from mobile data services, and also to their contribution to the Vision 2030 program; the ongoing pandemic has resulted in more people working and schooling from home during periods of restricted travel; this has stimulated growth in mobile data traffic, while the government has encouraged non-cash transactions and so helped develop the vast e-commerce market; while Saudi Arabia’s fixed broadband penetration remains relatively low, there has been a concentration of fiber infrastructure and the Kingdom has developed one of the fastest services in the region (2022)
domestic:
fixed-line are 18 per 100 and mobile-cellular subscribership is 126 per 100 persons (2021)
international:
country code - 966; landing points for the SeaMeWe-3, -4, -5, AAE-1, EIG, FALCON, FEA, IMEWE, MENA/Gulf Bridge International, SEACOM, SAS-1, -2, GBICS/MENA, and the Tata TGN-Gulf submarine cables providing connectivity to Europe, Africa, the Middle East, Asia, Southeast Asia and Australia; microwave radio relay to Bahrain, Jordan, Kuwait, Qatar, UAE, Yemen, and Sudan; coaxial cable to Kuwait and Jordan; satellite earth stations - 5 Intelsat (3 Atlantic Ocean and 2 Indian Ocean), 1 Arabsat, and 1 Inmarsat (Indian Ocean region) (2019)
Broadcast media:
broadcast media are state-controlled; state-run TV operates 4 networks; Saudi Arabia is a major market for pan-Arab satellite TV broadcasters; state-run radio operates several networks; multiple international broadcasters are available
Internet country code:
.sa
Internet users:
total:
36 million (2021 est.)
percent of population:
100% (2021 est.)
comparison ranking:
total 27
Broadband - fixed subscriptions:
total:
7,890,261 (2020 est.)
subscriptions per 100 inhabitants:
23 (2020 est.)
comparison ranking:
total 26
Communications - note:
the innovative King Abdulaziz Center for World Culture (informally known as Ithra, meaning “enrichment”) opened on 1 December 2017 in Dhahran, Eastern Region; its facilities include a grand library, several museums, an archive, an Idea Lab, a theater, a cinema, and an Energy Exhibit, all which are meant to provide visitors an immersive and transformative experience','04642bce895047d83de1bec7af96eb1ee67547bf9d3c808ffbd9739556a52105','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d71dd51fe35727d2612abed0fed70f6e2b91032903e524dc8c7e80e3803cf60b',2025,'SN','Senegal','communications',43,'Telephones - fixed lines:
total subscriptions:
261,440 (2021 est.)
subscriptions per 100 inhabitants:
2 (2021 est.)
comparison ranking:
total subscriptions 116
Telephones - mobile cellular:
total subscriptions:
19,859,981 (2021 est.)
subscriptions per 100 inhabitants:
118 (2021 est.)
comparison ranking:
total subscriptions 62
Telecommunication systems:
general assessment:
Senegal’s telecom market continues to show steady growth in all sectors; this has been supported by the particular demands made on consumers during the pandemic, which resulted in a particularly strong increase in the number of subscribers; the mobile subscriber base increased 6.7% in 2020, year-on-year, and by 4.1% in 2021, while the number of fixed broadband subscribers increased 17.5% year-on-year in 2021; mobile internet platforms account for the vast majority of all internet accesses; quality of service issues continue to plague the market, with the regulator periodically issuing fines to the market players (2022)
domestic:
fixed-line is 2 per 100 and mobile-cellular 118 per 100 persons (2021)
international:
country code - 221; landing points for the ACE, Atlantis-2, MainOne and SAT-3/WASC submarine cables providing connectivity from South Africa, numerous western African countries, Europe and South America; satellite earth station - 1 Intelsat (Atlantic Ocean) (2019)
Broadcast media:
state-run Radiodiffusion Television Senegalaise (RTS) broadcasts TV programs from five cities in Senegal; in most regions of the country, viewers can receive TV programming from at least 7 private broadcasters; a wide range of independent TV programming is available via satellite; RTS operates a national radio network and a number of regional FM stations; at least 7 community radio stations and 18 private-broadcast radio stations are available; transmissions of at least 5 international broadcasters are accessible on FM in Dakar (2019)
Internet country code:
.sn
Internet users:
total:
9.86 million (2021 est.)
percent of population:
58% (2021 est.)
comparison ranking:
total 59
Broadband - fixed subscriptions:
total:
153,813 (2020 est.)
subscriptions per 100 inhabitants:
1 (2020 est.)
comparison ranking:
total 122','9fc357dc0005acb0117f8bf6dd0cf8e55bb509f5b3650d255f9322649175e6dd','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a4047b15b98a6be2d4f030308dfec979c7afbbc0297087383d1a745e2badb1a7',2025,'RS','Serbia','communications',55,'Telephones - fixed lines:
total subscriptions:
2,540,276 (2021 est.)
subscriptions per 100 inhabitants:
37 (2021 est.)
comparison ranking:
total subscriptions 48
Telephones - mobile cellular:
total subscriptions:
8,501,519 (2021 est.)
subscriptions per 100 inhabitants:
124 (2021 est.)
comparison ranking:
total subscriptions 97
Telecommunication systems:
general assessment:
Serbia’s telecom industry has been liberalized in line with the principles of the EU’s regulatory framework for communications, focused on encouraging competition in telecom products and services, and ensuring universal access; considerable network investment has been undertaken in Serbia by incumbent and alternative operators in recent years, despite economic difficulties; this has helped to stimulate internet usage, which has also been bolstered by improved affordability as prices are reduced through competition; the pandemic has stimulated consumer take up of services, particularly mobile data; the government’s various initiatives to improve rural broadband availability have also been supported by European development loans; Serbia’s high mobile services, partly the result of multiple SIM card use, has weighed on revenue growth in recent years, placing further pressure on operators to develop business models which encourage consumer use of mobile data services also in response to the continued substitution of fixed-line for mobile voice calls; the regulator has yet to auction 5G-suitable frequencies, though operators are already investing in their networks in preparation for this next growth frontier; during 2021 the regulator resumed the process towards a 5G spectrum auction, which had been delayed owing to the onset of the covid-19 pandemic (2022)
domestic:
fixed-line over 37 per 100 and mobile-cellular is 124 per 100 persons (2021)
international:
country code - 381
Internet country code:
.rs
Internet users:
total:
5.589 million (2021 est.)
percent of population:
81% (2021 est.)
comparison ranking:
total 85
Broadband - fixed subscriptions:
total:
1,730,496 (2020 est.)
subscriptions per 100 inhabitants:
25 (2020 est.)
comparison ranking:
total 62','d4d15e01d2bc890a83ea48636e1bb10ff0721d6cfbac66d0631ee408ae73bfa1','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('10e1d9a44f88fc8870b46d43ca4aadb8625664376119724e07e6e481138dcf63',2025,'SC','Seychelles','communications',8,'Telephones - fixed lines:
total subscriptions:
18,768 (2021 est.)
subscriptions per 100 inhabitants:
18 (2021 est.)
comparison ranking:
total subscriptions 175
Telephones - mobile cellular:
total subscriptions:
184,161 (2021 est.)
subscriptions per 100 inhabitants:
173 (2021 est.)
comparison ranking:
total subscriptions 184
Telecommunication systems:
general assessment:
effective system; direct international calls to over 100 countries; radiotelephone communications between islands in the archipelago; 3 ISPs; use of Internet cafes’ for access to Internet; 4G services and 5G pending (2020)
domestic:
fixed-line is 18 per 100 and mobile-cellular teledensity is 173 telephones per 100 persons (2021)
international:
country code - 248; landing points for the PEACE and the SEAS submarine cables providing connectivity to Europe, the Middle East, Africa and Asia; direct radiotelephone communications with adjacent island countries and African coastal countries; satellite earth station - 1 Intelsat (Indian Ocean) (2019)
Broadcast media:
the national broadcaster, Seychelles Broadcasting Corporation (SBC), which is funded by taxpayer money, operates the only terrestrial TV station, which provides local programming and airs broadcasts from international services; a privately owned Internet Protocol Television (IPTV) channel also provides local programming multi-channel cable and satellite TV are available through 2 providers; the national broadcaster operates 1 AM and 1 FM radio station; there are 2 privately operated radio stations; transmissions of 2 international broadcasters are accessible in Victoria
(2019)
Internet country code:
.sc
Internet users:
total:
90,200 (2021 est.)
percent of population:
82% (2021 est.)
comparison ranking:
total 190
Broadband - fixed subscriptions:
total:
34,966 (2020 est.)
subscriptions per 100 inhabitants:
36 (2020 est.)
comparison ranking:
total 148','86bf5faf9857a5907d1ddf48d26411c2172c635ddd23b4f7394a577417b19924','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c79d92a032558d85e48df8635c2b3cd32a32bc880d422b8e86c96a6522694e27',2025,'SL','Sierra Leone','communications',19,'Telephones - fixed lines:
total subscriptions:
269 (2021 est.)
subscriptions per 100 inhabitants:
0 (2021 est.)
comparison ranking:
total subscriptions 221
Telephones - mobile cellular:
total subscriptions:
8,227,093 (2021 est.)
subscriptions per 100 inhabitants:
98 (2021 est.)
comparison ranking:
total subscriptions 99
Telecommunication systems:
general assessment:
the telecom sector has only gradually recovered from the destruction caused during the war years, and only since 2019 has there been an effective terrestrial fiber backbone infrastructure, while the cable link to neighboring Guinea was not completed until February 2020; there is considerable available capacity from the ACE submarine cable and the national fiber network, but this is used inefficiently and so the price of internet connectivity remains one of the highest in the region; the theft of equipment and cabling, compounded by neglect, mismanagement, and under investment, means that telcos continue to operate in difficult conditions; the telecom regulator has made efforts to improve the market, including the liberalization of the international gateway and regular checks on QoS; the regulator reduced the price floor for mobile voice calls in early 2020, though consumers objected to the MNOs withdrawing a number of cheap packages as a response; the mobile sector has been the main driver of overall telecom revenue (2022)
domestic:
fixed-line less than 0 per 100 and mobile-cellular just over 98 per 100 (2021)
international:
country code - 232; landing point for the ACE submarine cable linking to South Africa, over 20 western African countries and Europe; satellite earth station - 1 Intelsat (Atlantic Ocean) (2019)
Broadcast media:
1 government-owned TV station; 3 private TV stations; a pay-TV service began operations in late 2007; 1 government-owned national radio station; about two-dozen private radio stations primarily clustered in major cities; transmissions of several international broadcasters are available
(2019)
Internet country code:
.sl
Internet users:
total:
1,047,499 (2022 est.)
percent of population:
12.7% (2022 est.)
comparison ranking:
total 149','09bef1f6d4f8276c19b9ef917a15945c5039f38e2c2d7cbf93b7046377712f60','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e6c395eb82321e5c7ccd9fd74748ea4f34382bab5626fc8e4226b4ec3f3c3095',2025,'SG','Singapore','communications',30,'Telephones - fixed lines:
total subscriptions:
1,887,500 (2021 est.)
subscriptions per 100 inhabitants:
32 (2021 est.)
comparison ranking:
total subscriptions 55
Telephones - mobile cellular:
total subscriptions:
8,660,700 (2021 est.)
subscriptions per 100 inhabitants:
146 (2021 est.)
comparison ranking:
total subscriptions 96
Telecommunication systems:
general assessment:
a wealthy city-state, Singapore has a highly developed ICT infrastructure; government supported near universal home broadband penetration and free public access to wireless network; the government’s telecommunication regulator, Infocomm Media Development Authority (IMDA), issued awards in mid-2020 to telecom operators with the goal of having at least 50% of the city-state covered with a standalone 5G network by the end of 2022; government actively promoting Smart Nation initiative supporting digital innovation; government oversees service providers and controls Internet content; well served by submarine cable and satellite connections (2021)
domestic:
fixed-line is 32 per 100 and mobile-cellular 146 per 100 teledensity (2021)
international:
country code - 65; landing points for INDIGO-West, SeaMeWe -3,-4,-5, SIGMAR, SJC, i2icn, PGASCOM, BSCS, IGG, B3JS, SAEx2, APCN-2, APG, ASC, SEAX-1, ASE, EAC-C2C, Matrix Cable System and SJC2 submarine cables providing links throughout Asia, Southeast Asia, Africa, Australia, the Middle East, and Europe; satellite earth stations - 3, Bukit Timah, Seletar, and Sentosa; supplemented by VSAT coverage (2019)
Broadcast media:
state controls broadcast media; 6 domestic TV stations operated by MediaCorp which is wholly owned by a state investment company; broadcasts from Malaysian and Indonesian stations available; satellite dishes banned; multichannel cable TV services available; a total of 19 domestic radio stations broadcasting, with MediaCorp operating 11, Singapore Press Holdings, also government-linked, another 5, 2 controlled by the Singapore Armed Forces Reservists Association and one owned by BBC Radio; Malaysian and Indonesian radio stations are available as is BBC; a number of Internet service radio stations are also available (2019)
Internet country code:
.sg
Internet users:
total:
5.369 million (2021 est.)
percent of population:
91% (2021 est.)
comparison ranking:
total 88
Broadband - fixed subscriptions:
total:
1,509,700 (2020 est.)
subscriptions per 100 inhabitants:
26 (2020 est.)
comparison ranking:
total 66','e11b76f71e05efc7b09b9cd2eebd0a274935627cb566b030dbb5050abb08756c','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ae9ffbf71ceb311334caaccba451f9683714d48d0b3fb6f9e7d49543a63439b8',2025,'SG','Singapore','communications',43,'Telephones - mobile cellular:
total subscriptions:
68,840 (2012 est.)
subscriptions per 100 inhabitants:
196 (2012 est.)
comparison ranking:
total subscriptions 199
Telecommunication systems:
general assessment:
generally adequate facilities; growth sectors include mobile telephone and data segments; effective competition; LTE expansion; tourism and telecom sector contribute greatly to the GDP (2018)
domestic:
196 per 100 mobile-cellular teledensity (2012)
international:
country code - 1-721; landing points for SMPR-1 and the ECFS submarine cables providing connectivity to the Caribbean; satellite earth stations - 2 Intelsat (Atlantic Ocean) (2019)
Internet country code:
.sx; note - IANA has designated .sx for Sint Maarten, but has not yet assigned it to a sponsoring organization
Internet users:
total:
39,089 (2022)
percent of population:
89.5% (2022)
comparison ranking:
total 203','4bac57adb3bca991886881d1282682e56256540ff3fd3a47c783a5decff06524','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('654fa5db02208877cec80e2d4db586f73ad7a84efa4da070d1926efc5e623fa8',2025,'SK','Slovakia','communications',54,'Telephones - fixed lines:
total subscriptions:
577,390 (2021 est.)
subscriptions per 100 inhabitants:
11 (2021 est.)
comparison ranking:
total subscriptions 87
Telephones - mobile cellular:
total subscriptions:
7,362,325 (2021 est.)
subscriptions per 100 inhabitants:
135 (2021 est.)
comparison ranking:
total subscriptions 105
Telecommunication systems:
general assessment:
the broadband market has shown steady growth in recent years; fiber has become the principal platform for fixed broadband services, followed by DSL; the cable sector is a distant third in terms of subscribers, though cable is particularly strong in urban areas; mobile broadband access and content services are developing rapidly in line with operators having upgraded their networks; the regulator prepared the groundwork for 5G services in line with European Union requirements, with concessions in the 3.5GHz range followed by those in the 700MHz, 900MHz and 1800MHz bands; 5G was launched in late 2021 and is expected to cover about a fifth of the population by the end of 2022 (2021)
domestic:
fixed-line is 11 per 100 and mobile-cellular is 135 per 100 teledensity (2021)
international:
country code - 421; 3 international exchanges (1 in Bratislava and 2 in Banska Bystrica) are available; Slovakia is participating in several international telecommunications projects that will increase the availability of external services; connects to DREAM cable (2017)
Broadcast media:
state-owned public broadcaster, Radio and Television of Slovakia (RTVS), operates 2 national TV stations and multiple national and regional radio networks; roughly 50 privately owned TV stations operating nationally, regionally, and locally; about 40% of households are connected to multi-channel cable or satellite TV; 32 privately owned radio stations
Internet country code:
.sk
Internet users:
total:
4.806 million (2021 est.)
percent of population:
89% (2021 est.)
comparison ranking:
total 98
Broadband - fixed subscriptions:
total:
1,701,561 (2020 est.)
subscriptions per 100 inhabitants:
31 (2020 est.)
comparison ranking:
total 63','34c989716f5719afbc76bd24c1240cc33fb9d642e9d9fc40bfb77f6e2523add9','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('00f0441d4a83d835cbe98e0f97b965ef20ee8d1d705d363a7d754b732c84d105',2025,'SI','Slovenia','communications',8,'Telephones - fixed lines:
total subscriptions:
695,444 (2021 est.)
subscriptions per 100 inhabitants:
33 (2021 est.)
comparison ranking:
total subscriptions 82
Telephones - mobile cellular:
total subscriptions:
2,607,268 (2021 est.)
subscriptions per 100 inhabitants:
123 (2021 est.)
comparison ranking:
total subscriptions 146
Telecommunication systems:
general assessment:
Slovenia’s telecom sector is dominated by four operators; the mobile market has four MNOs and a small number of MVNOs, operating in a country with a potential market of just over two million people; the regulator in recent years has addressed the need for mobile operators to have more spectrum, so enabling them to improve the quality and range of services; a multi-spectrum auction was concluded in mid-2021, aimed at supporting 5G services; the broadband market continues to be dominated by a small number of players; DSL lost its dominance some years ago, being taken over by fiber as subscribers are migrated to new fiber-based networks; fiber accounted for almost half of all fixed broadband connections by March 2022 (2022)
domestic:
fixed-line is 33 per 100 and mobile-cellular is 123 per 100 teledensity (2021)
international:
country code - 386 (2016)
Broadcast media:
public TV broadcaster, Radiotelevizija Slovenija (RTV), operates a system of national and regional TV stations; 35 domestic commercial TV stations operating nationally, regionally, and locally; about 60% of households are connected to multi-channel cable TV; public radio broadcaster operates 3 national and 4 regional stations; more than 75 regional and local commercial and non-commercial radio stations
Internet country code:
.si
Internet users:
total:
1.869 million (2021 est.)
percent of population:
89% (2021 est.)
comparison ranking:
total 136
Broadband - fixed subscriptions:
total:
651,604 (2020 est.)
subscriptions per 100 inhabitants:
31 (2020 est.)
comparison ranking:
total 84','b3aa511ac787000eb1f92ce963c9c7d2b51a7f36e8f93d1d23d087052cb8a744','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('13fdb27ce1f2dc527c6740789a946cdea3ab77b7dca3881a752c561f215a0d31',2025,'SB','Solomon Islands','communications',19,'Telephones - fixed lines:
total subscriptions:
7,000 (2021 est.)
subscriptions per 100 inhabitants:
(2021 est.) less than 1
comparison ranking:
total subscriptions 198
Telephones - mobile cellular:
total subscriptions:
470,000 (2021 est.)
subscriptions per 100 inhabitants:
67 (2021 est.)
comparison ranking:
total subscriptions 175
Telecommunication systems:
general assessment:
mobile services have continually expanded in the Solomon Islands; 3G services became available in 2010, leading to an increase in mobile broadband uptake; Solomon Islands currently host three ISPs; fixed broadband services are largely limited to government, corporations, and educational organizations in the Solomon Islands; telecommunication infrastructure in the Solomon Islands requires significant investment due to the geographical make-up of the islands; this presents a great challenge to rural connectivity in the country; although various international organizations such as the World Bank and the Asian Development Bank have taken a special interest in having communication services improved in both the Solomon Islands and the Pacific region in general, internet and broadband penetration remain low; the provision of broadband infrastructure, particularly to rural areas, is also hindered by land disputes; internet services have, improved with the build-out of the Coral Sea Cable System linking Papua New Guinea to the Solomon Islands, as also with a connecting cable to a landing station at Sydney; the Australian government provided most of the funding for the Coral Sea Cable System, with contributions and support from the Solomon Islands and Papua New Guinea governments; the launch of the Kacific-1 satellite in late 2019 also improved broadband satellite capacity for the region, though for telcos in Solomon Islands satellite services are now largely used as backup for international traffic; in recent years, the country has stabilized both politically and economically and this, along with improvements to mobile infrastructure, has led to a rise in mobile services and the slow uptake of broadband services; while the first LTE services were launched in late 2017 in the capital Honiara, the main platform for mobile voice and data services remains 3G, while in outlying areas GSM is still an important technology for the provision of services (2022)
domestic:
fixed-line is less than 1 per 100 persons and mobile-cellular telephone density 67 per 100 persons (2021)
international:
country code - 677; landing points for the CSCS and ICNS2 submarine cables providing connectivity from Solomon Islands, to PNG, Vanuatu and Australia; satellite earth station - 1 Intelsat (Pacific Ocean) (2019)
Broadcast media:
Solomon Islands Broadcasting Corporation (SIBC) does not broadcast television; multi-channel pay-TV is available; SIBC operates 2 national radio stations and 2 provincial stations; there are 2 local commercial radio stations; Radio Australia is available via satellite feed (since 2009) (2019)
Internet country code:
.sb
Internet users:
total:
255,600 (2021 est.)
percent of population:
36% (2021 est.)
comparison ranking:
total 175
Broadband - fixed subscriptions:
total:
1,000 (2020 est.)
subscriptions per 100 inhabitants:
0.2 (2020 est.)
comparison ranking:
total 206','374a7cdf6f03f47d119e9644d06d975bad610ca08390ba1bf0b19a5694ef4158','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e28e80f2c10c7684b6874fd27109e8e793351097bf4efdd1b49b457687d2829e',2025,'SO','Somalia','communications',30,'Telephones - fixed lines:
total subscriptions:
91,000 (2021 est.)
subscriptions per 100 inhabitants:
1 (2021 est.)
comparison ranking:
total subscriptions 141
Telephones - mobile cellular:
total subscriptions:
8.844 million (2021 est.)
subscriptions per 100 inhabitants:
52 (2021 est.)
comparison ranking:
total subscriptions 95
Telecommunication systems:
general assessment:
Somalia’s economic difficulties in recent years have made it difficult for telcos and the government to sustain investment in infrastructure; the government has also had to contend with militant groups which continue on occasion to force the closure of internet services in many areas of the country; in recent years, though, the government has addressed the lack of guidance which had prevailed since 1991, when a dictatorial regime was overthrown; the National Communications Law was passed in October 2017, aimed at setting a legal and regulatory framework for the telecoms sector, while provision was made in the following year to set up a regulatory authority to oversee the telecom sector; more recently, three types of licenses were mandated to provide clarity to operators, and to bring the market closer into line with international standards; all operators were given until August 2020 to secure one of the three license types; given the poor condition of fixed-line infrastructure, operators have concentrated on mobile connectivity; their investment plans have involved the development of LTE services to provide mobile data and broadband services; the telecom market has flourished; tariffs are among the lowest in Africa, and new cable systems coming on stream in the next few years, as well as planned investments from local operators to bolster the country’s national fiber backbone, will lead to downward pressure on retail pricing; on the consumer side, spending on telecoms services and devices are under pressure from the financial effect of large-scale job losses and the consequent restriction on disposable incomes as the remnants of the impact of the Covid-19 pandemic remain and as global events, such as the Russian invasion of Ukraine, continue to play out; the market is continuing a positive growth trajectory, supported by a slow economic rebound in the country (2022)
domestic:
fixed-line is 1 per 100 and mobile-cellular is 52 per 100 (2021)
international:
country code - 252; landing points for the G2A, DARE1, PEACE, and EASSy fiber-optic submarine cable system linking East Africa, Indian Ocean Islands, the Middle East, North Africa and Europe (2019)
Broadcast media:
2 private TV stations rebroadcast Al-Jazeera and CNN; Somaliland has 1 government-operated TV station and Puntland has 1 private TV station; the transitional government operates Radio Mogadishu; 1 SW and roughly 10 private FM radio stations broadcast in Mogadishu; several radio stations operate in central and southern regions; Somaliland has 1 government-operated radio station; Puntland has roughly a half-dozen private radio stations; transmissions of at least 2 international broadcasters are available (2019)
Internet country code:
.so
Internet users:
total:
2.465 million (2021 est.)
percent of population:
14.5% (2021 est.)
comparison ranking:
total 129
Broadband - fixed subscriptions:
total:
119,000 (2020 est.)
subscriptions per 100 inhabitants:
1 (2020 est.)
comparison ranking:
total 127','a7b1d9e2f0327493d5549861cccf4f606ee367ac40dcc2a498330f98764c614d','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fcc07ac20b36431796622ff2166dc1169b3441694345ee219724b2e55754f2f6',2025,'ZA','South Africa','communications',42,'Telephones - fixed lines:
total subscriptions:
1,472,191 (2021 est.)
subscriptions per 100 inhabitants:
2 (2021 est.)
comparison ranking:
total subscriptions 62
Telephones - mobile cellular:
total subscriptions:
100,328,005 (2021 est.)
subscriptions per 100 inhabitants:
169 (2021 est.)
comparison ranking:
total subscriptions 18
Telecommunication systems:
general assessment:
South Africa’s telecom sector boasts one of the most advanced infrastructures on the continent; the focus in recent years has been on back haul capacity and on fiber and LTE networks to extend and improve internet service connectivity; with the ongoing migration to fiber, the incumbent telco expects to close down its copper network in 2024; the mobile sector has developed strongly in recent years, partly due to the poor availability and level of service of fixed-line networks, which meant that many people had no alternative to mobile networks for voice and data services; the multi-spectrum auction was delayed several times due to legal wrangling, and was finally held in March 2022; the delay caused difficulties for network operators, which were forced to reform spectrum for 3G and LTE use, and provide 5G services on temporary licenses; six qualified bidders acquired spectrum, netting the regulator ZAR14.4 billion in revenues; the market is shrugging off the impact of the pandemic, which had a significant impact on production and supply chains globally, and saw a slowdown in some network expansions, particularly around 5G; on the consumer side, spending on telecoms services and devices remains slightly under pressure amid ongoing macroeconomic challenges facing the country; the crucial nature of telecom services, both for general communication as well as a tool for homeworking, will offset such pressures; in many markets the net effect should be a steady though reduced increase in subscriber growth (2022)
domestic:
fixed-line is 2 per 100 persons and mobile-cellular is 169 telephones per 100 persons (2021)
international:
country code - 27; landing points for the WACS, ACE, SAFE, SAT-3, Equiano, SABR, SAEx1, SAEx2, IOX Cable System, METISS, EASSy, and SEACOM/ Tata TGN-Eurasia fiber-optic submarine cable systems connecting South Africa, East Africa, West Africa, Europe, Southeast Asia, Asia, South America, Indian Ocean Islands, and the US; satellite earth stations - 3 Intelsat (1 Indian Ocean and 2 Atlantic Ocean) (2019)
Broadcast media:
the South African Broadcasting Corporation (SABC) operates 4 TV stations, 3 are free-to-air and 1 is pay TV; e.tv, a private station, is accessible to more than half the population; multiple subscription TV services provide a mix of local and international channels; well-developed mix of public and private radio stations at the national, regional, and local levels; the SABC radio network, state-owned and controlled but nominally independent, operates 18 stations, one for each of the 11 official languages, 4 community stations, and 3 commercial stations; more than 100 community-based stations extend coverage to rural areas
Internet country code:
.za
Internet users:
total:
42.48 million (2021 est.)
percent of population:
72% (2021 est.)
comparison ranking:
total 24
Broadband - fixed subscriptions:
total:
1,303,057 (2020 est.)
subscriptions per 100 inhabitants:
2 (2020 est.)
comparison ranking:
total 68','1d130e879433f220dffe7e6b982298721be4efbb1117a2623a046b4a200ae9f1','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fa3dbf6f89973d79e3e11da3817064899cd6c7095c79d9bfa171ba68ee7b7a0c',2025,'SS','South Sudan','communications',9,'Telephones - fixed lines:
total subscriptions:
(2018 est.)
subscriptions per 100 inhabitants:
(2018 est.)
Telephones - mobile cellular:
total subscriptions:
3.3 million (2021 est.)
subscriptions per 100 inhabitants:
30 (2021 est.)
comparison ranking:
total subscriptions 139
Telecommunication systems:
general assessment:
following a referendum, oil-rich South Sudan seceded from Sudan in 2011 and became an independent nation; having been deprived of investment for decades, it inherited one of the least developed telecom markets in the world; there was once investment activity among mobile network operators who sought to expand their networks in some areas of the country; operators in the telecom sector placed themselves in survival mode and are hoping for a political settlement and a return to some degree of social stability; South Sudan has one of the lowest mobile penetration rates in Africa; growth in the sector in coming years is premised on a resolution to the political crisis and a recovery of the country’s economy; the virtually untapped internet and broadband market also depends to a large extent on the country gaining access to international fiber cables and on a national backbone network being in place; sophisticated infrastructure solutions are needed to reach the 80% of the population that live outside of the main urban centers; some improvement has followed from the cable link in February 2020 which connects Juba directly to the company’s submarine landing station at Mombasa; the cable was South Sudan’s first direct international fiber link, and has helped drive down the price of retail internet services for residential and business customers; a second cable linking to the border with Kenya was completed in December 2021 (2022)
domestic:
fixed-line less than 1 per 100 subscriptions, mobile-cellular is 30 per 100 persons (2021)
international:
country code - 211 (2017)
Broadcast media:
a single TV channel and a radio station are controlled by the government; several community and commercial FM stations are operational, mostly sponsored by outside aid donors; some foreign radio broadcasts are available
(2019)
Internet country code:
.ss
Internet users:
total:
869,000 (2021 est.)
percent of population:
7.9% (2021 est.)
comparison ranking:
total 151
Broadband - fixed subscriptions:
total:
200 (2019 est.)
subscriptions per 100 inhabitants:
(2019 est.)
comparison ranking:
total 212','9121549d66965c92ca0f3ade158b78d6a206d1dd8d3f7d9da31c288d279963b3','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('982f3de40e5c949bc56a84708b6733af54413ce5222ddc9d9e1e17481a9dbb15',2025,'ES','Spain','communications',26,'Telephones - fixed lines:
total subscriptions:
19,075,931 (2021 est.)
subscriptions per 100 inhabitants:
40 (2021 est.)
comparison ranking:
total subscriptions 14
Telephones - mobile cellular:
total subscriptions:
56,805,348 (2021 est.)
subscriptions per 100 inhabitants:
120 (2021 est.)
comparison ranking:
total subscriptions 29
Telecommunication systems:
general assessment:
Spain’s telecom sector has tracked the performance of the overall economy, which has been one of the most heavily impacted by the pandemic in all of Europe; GDP dropped by 10.8% in 2020, while telecom revenue reversed the previous five years’ positive results by falling 5.3%; fixed-line services were the hardest hit, with revenue falling 13.7%; mobile voice services did not fare much better, falling 4.7%; this is despite relatively small shifts in the number of subscribers, though the harsh lockdown conditions resulted in a significant drop in usage; it had appeared that a return to growth might be possible in 2021 following lifting the state of emergency in May, but the most recent surge in cases and the continued restrictions on travel may once again put the brakes on growth until at least 2022; Spain’s fixed-line broadband market managed to extend its decade-long pattern of steady growth into 2020, with a slight increase in demand caused by the need for fast internet access to support working and learning from home; while most of Spain’s larger telcos delivered negative revenue and profit in 2020 (2021)
domestic:
fixed-line is 40 per 100 and mobile-cellular 120 telephones per 100 persons (2021)
international:
country code - 34; landing points for the MAREA, Tata TGN-Western Europe, Pencan-9, SAT-3/WASC, Canalink, Atlantis-2, Columbus -111, Estepona-Tetouan, FLAG Europe-Asia (FEA), Balalink, ORVAL and PENBAL-5 submarine cables providing connectivity to Europe, the Middle East, Africa, South America, Asia, Southeast Asia and the US; satellite earth stations - 2 Intelsat (1 Atlantic Ocean and 1 Indian Ocean), Eutelsat; tropospheric scatter to adjacent countries (2019)
Broadcast media:
a mixture of both publicly operated and privately owned TV and radio stations; overall, hundreds of TV channels are available including national, regional, local, public, and international channels; satellite and cable TV systems available; multiple national radio networks, a large number of regional radio networks, and a larger number of local radio stations; overall, hundreds of radio stations
(2019)
Internet country code:
.es
Internet users:
total:
44.18 million (2021 est.)
percent of population:
94% (2021 est.)
comparison ranking:
total 23
Broadband - fixed subscriptions:
total:
16,188,502 (2020 est.)
subscriptions per 100 inhabitants:
35 (2020 est.)
comparison ranking:
total 15','4aae9248462cdfc7020cb7db41f61ac611db847eeaa3d5e66cf161c199df11cd','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7ca0553a9caa14a415e11e8f5f1ae99ebda05ad024b95aff8cba0a985d1fdaa2',2025,'LK','Sri Lanka','communications',47,'Telephones - fixed lines:
total subscriptions:
2,869,186 (2021 est.)
subscriptions per 100 inhabitants:
13 (2021 est.)
comparison ranking:
total subscriptions 45
Telephones - mobile cellular:
total subscriptions:
30,764,134 (2021 est.)
subscriptions per 100 inhabitants:
141 (2021 est.)
comparison ranking:
total subscriptions 45
Telecommunication systems:
general assessment:
Sri Lanka’s fixed-line telephony market was one of the very few in the world to experience a significant upsurge in subscriptions in 2020; while the country suffers from a relatively poor fixed-line infrastructure and a correspondingly strong mobile sector, demand for traditional phone services increased 14% in 2020; preliminary results suggest a further jump of up to 13% can also be expected in 2021; this will take Sri Lanka’s fixed-line penetration to levels not seen since 2013; the most reason behind the market’s reversal of fortunes is the Covid-19 crisis and Sri Lanka’s ensuring lock downs; these forced much of the population back inside and reverting to ‘traditional’ methods of communication for both voice and data services; the fixed broadband market was equally robust, growing 20% in 2020 alone; Sri Lanka possesses a relatively low number of computers per household so the fixed broadband market’s success comes off a small base; the one area of the telecommunications market that experienced a fall was the mobile segment; up until the start of the pandemic, Sri Lanka had a very high mobile penetration rate of 155%; this nearsaturation level reflected the preponderance for subscribers to carry multiple SIM cards to take advantage of cheaper on-net call rates; the reduction in demand and traffic because of the pandemic led to a sharp drop in the number of active subscriptions, down to just 135% – a 17% decline in just one year; the market is expected to bounce back quickly, as soon as the country eases back on its lock down measures and reduces travel restrictions; it will also be boosted, come 2022, by the anticipated launch of commercial 5G mobile services (2021)
domestic:
fixed-line is 13 per 100 and mobile-cellular is 141 per 100 (2021)
international:
country code - 94; landing points for the SeaMeWe -3,-5, Dhiraagu-SLT Submarine Cable Network, WARF Submarine Cable, Bharat Lanka Cable System and the Bay of Bengal Gateway submarine cables providing connectivity to Asia, Africa, Southeast Asia, Australia, the Middle East, and Europe; satellite earth stations - 2 Intelsat (Indian Ocean) (2019)
Broadcast media:
government operates 5 TV channels and 19 radio channels; multi-channel satellite and cable TV subscription services available; 25 private TV stations and about 43 radio stations; 6 non-profit TV stations and 4 radio stations
Internet country code:
.lk
Internet users:
total:
14.74 million (2021 est.)
percent of population:
67% (2021 est.)
comparison ranking:
total 51
Broadband - fixed subscriptions:
total:
1,781,530 (2020 est.)
subscriptions per 100 inhabitants:
8 (2020 est.)
comparison ranking:
total 60','f9337eb268fa8f42d0c61d12ef803a7eb7b8167948f691f1ee3ca0049a1e01e6','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('00daad239ef4c0fa3bf96d294509e477571727a6319a5251d6eb7a38c34448c0',2025,'SD','Sudan','communications',60,'Telephones - fixed lines:
total subscriptions:
129,408 (2021 est.)
subscriptions per 100 inhabitants:
(2021 est.) less than 1
comparison ranking:
total subscriptions 129
Telephones - mobile cellular:
total subscriptions:
16,688,773 (2021 est.)
subscriptions per 100 inhabitants:
37 (2021 est.)
comparison ranking:
total subscriptions 67
Telecommunication systems:
general assessment:
Sudan emerged as a poorer country when South Sudan separated from it in 2011; although Sudan has about four times the population of South Sudan, the latter benefits from its control of the majority of known oil reserves; the Sudanese economy has been affected by hyperinflation in recent years, partly the result of the loss of oil revenue but also due to domestic volatility and social unrest; the difficult economic conditions have meant that for several years telcos have reported revenue under hyper inflationary reporting standards; pressure on revenue has made it difficult for operators to invest in infrastructure upgrades, and so provide improved services to customers; despite this, the number of mobile subscribers increased 7% in 2021, year-on-year; this level of growth is expected to have been maintained in 2022, though could slow from 2023; the country’s poor fixed-line infrastructure has helped the development of mobile broadband services (2023)
domestic:
teledensity fixed-line is 1 per 100 and mobile-cellular is 37 telephones per 100 persons (2021)
international:
country code - 249; landing points for the EASSy, FALCON and SAS-1,-2, fiber-optic submarine cable systems linking Africa, the Middle East, Indian Ocean Islands and Asia; satellite earth stations - 1 Intelsat (Atlantic Ocean) (2019)
Broadcast media:
Following the establishment of Sudan’s transitional government in August 2019, government-owned broadcasters became increasingly independent from government and military control. Following the October 2021 military takeover, additional restrictions were imposed on these government-owned broadcasters, which now practice a heightened degree of self-censorship but still operate more independently than in the pre-2019 environment. (2022)
Internet country code:
.sd
Internet users:
total:
13.248 million (2021 est.)
percent of population:
28.8% (2021 est.)
comparison ranking:
total 53
Broadband - fixed subscriptions:
total:
28,782 (2020 est.)
subscriptions per 100 inhabitants:
0.1 (2020 est.)
comparison ranking:
total 156','9d31118ac9464c0acdf9f0d077208aa0a55e048b55960243509c46bed18ceaeb','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9612a87f5e024f0d8d7845d42389c0865ae521a35ac35e0a5b1926e5effbaa98',2025,'SR','Suriname','communications',8,'Telephones - fixed lines:
total subscriptions:
119,977 (2021 est.)
subscriptions per 100 inhabitants:
20 (2021 est.)
comparison ranking:
total subscriptions 131
Telephones - mobile cellular:
total subscriptions:
906,170 (2021 est.)
subscriptions per 100 inhabitants:
148 (2021 est.)
comparison ranking:
total subscriptions 164
Telecommunication systems:
general assessment:
Suriname is the smallest nation on the South American continent, with about 580,000 inhabitants; the only Dutch-speaking nation in South America, it has close affinities with the Caribbean, and is a member of the Caribbean Community and Common Market (CARICOM); the country’s fixed-line infrastructure is reasonably reliable in the more populated coastal region, though poor in the interior; fixed teledensity and broadband penetration are slightly lower than average for Latin America and the Caribbean, while mobile penetration is significantly above the regional average and much higher than would be expected given the country’s relatively low GDP per capita; many Surinamese have up to three mobile lines with different providers, which has pushed up penetration figures although the number of subscribers has fallen in recent years as consumers have responded to economic pressures
(2021)
domestic:
fixed-line is 20 per 100 and mobile-cellular teledensity is 148 telephones per 100 persons (2021)
international:
country code - 597; landing point for the SG-SCS submarine cable linking South America with the Caribbean; satellite earth stations - 2 Intelsat (Atlantic Ocean) (2019)
Broadcast media:
2 state-owned TV stations; 1 state-owned radio station; multiple private radio and TV stations (2019)
Internet country code:
.sr
Internet users:
total:
402,600 (2021 est.)
percent of population:
66% (2021 est.)
comparison ranking:
total 172
Broadband - fixed subscriptions:
total:
92,270 (2020 est.)
subscriptions per 100 inhabitants:
16 (2020 est.)
comparison ranking:
total 129','89cefc8615fd113460ee2e8330324ffa257438f2b494a76531fc644a2f4e22e1','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d9c570d74fcb62003dbc5b30932283028dd065e90310a8737e8956316daa5dce',2025,'SR','Suriname','communications',19,'Telecommunication systems:
general assessment:
Svalbard Undersea Cable System is a twin submarine communications cable which connects Svalbard to the mainland of Norway (2022)
domestic:
the Svalbard Satellite Station - connected to the mainland via the Svalbard Undersea Cable System - is the only Arctic ground station that can see low-altitude, polar-orbiting satellites; it provides ground services to more satellites than any other facility in the world (2022)
international:
country code - 47-790; the Svalbard Undersea Cable System is a twin communications cable that connects Svalbard to mainland Norway; the system is the sole telecommunications link to the archipelago (2019)
Broadcast media:
the Norwegian Broadcasting Corporation (NRK) began direct TV transmission to Svalbard via satellite in 1984; Longyearbyen households have access to 3 NRK radio and 2 TV stations
Internet country code:
.sj','d40b6a9dd5c6a089e1a8ec785104c4086791f164cf2f809d0cc77df86750d84a','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2a48a98991f194cb8ace60962874b0cf27898aaa6b94380c3912fcf101f22db3',2025,'SE','Sweden','communications',30,'Telephones - fixed lines:
total subscriptions:
1,382,146 (2021 est.)
subscriptions per 100 inhabitants:
13 (2021 est.)
comparison ranking:
total subscriptions 63
Telephones - mobile cellular:
total subscriptions:
12,843,683 (2021 est.)
subscriptions per 100 inhabitants:
123 (2021 est.)
comparison ranking:
total subscriptions 77
Telecommunication systems:
general assessment:
Sweden’s telecom market includes mature mobile and broadband sectors which have been stimulated by the progressive investment of the main telcos in developing new technologies; the country retains one of the best developed LTE infrastructures in the region, while its MNOs have benefited from the January 2021 auction of spectrum in the 3.5GHz band which will enable them to expand services nationally; the country also has one of the highest fiber broadband penetration rates in Europe; the focus of FttP is aimed at fulfilling the government’s target of providing a 1Gb/s service to 98% of the population by 2025; the methodology to achieve this has rested on regulatory measures supported by public funds, as well as on the auction of spectrum in different bands; in the fixed-line broadband segment, the number of DSL subscribers is falling steadily as customers continue to migrate to fiber networks; there is also competition from HFC infrastructure, offering fiber-based broadband and investing in services based on the DOCSIS3.1 standard; this report assesses key aspects of the Swedish telecom market, providing data on fixed network services and profiling the main players; it also reviews the key regulatory issues, including interconnection, local loop unbundling, number portability, carrier preselection and NGN open access; the report also analyses the mobile market, providing data on network operators and their strategies in a highly competitive environment; in addition, the report considers the fixed and fixed-wireless broadband markets, including analyses of market dynamics and the main operators, as well as providing subscriber forecasts (2021)
domestic:
fixed-line is 13 per 100 and mobile-cellular is 123 per 100 (2021)
international:
country code - 46; landing points for Botina, SFL, SFS-4, Baltic Sea Submarine Cable, Eastern Light, Sweden-Latvia, BCS North-Phase1, EE-S1, LV-SE1, BCS East-West Interlink, NordBalt, Baltica, Denmark-Sweden-15,-17,-18, Scandinavian Ring -North,-South, IP-Only Denmark-Sweden, Donica North, Kattegate-1,-2, Energinet Laeso-Varberg and GC2 submarine cables providing links to other Nordic countries and Europe; satellite earth stations - 1 Intelsat (Atlantic Ocean), 1 Eutelsat, and 1 Inmarsat (Atlantic and Indian Ocean regions); note - Sweden shares the Inmarsat earth station with the other Nordic countries (Denmark, Finland, Iceland, and Norway) (2019)
Broadcast media:
publicly owned TV broadcaster operates 2 terrestrial networks plus regional stations; multiple privately owned TV broadcasters operating nationally, regionally, and locally; about 50 local TV stations; widespread access to pan-Nordic and international broadcasters through multi-channel cable and satellite TV; publicly owned radio broadcaster operates 3 national stations and a network of 25 regional channels; roughly 100 privately owned local radio stations with some consolidating into near national networks; an estimated 900 community and neighborhood radio stations broadcast intermittently
Internet country code:
.se
Internet users:
total:
8.8 million (2021 est.)
percent of population:
88% (2021 est.)
comparison ranking:
total 66
Broadband - fixed subscriptions:
total:
4,179,574 (2020 est.)
subscriptions per 100 inhabitants:
41 (2020 est.)
comparison ranking:
total 36','7a1eab59d1ce508e5062bf3919f7caea2483db00e8f392f24751fd001d432128','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0d0e531ca236611b354eadf3c0de08d454a3bc468523aaa04ef7c362d16ab9ad',2025,'CH','Switzerland','communications',43,'Telephones - fixed lines:
total subscriptions:
2,956,500 (2021 est.)
subscriptions per 100 inhabitants:
34 (2021 est.)
comparison ranking:
total subscriptions 43
Telephones - mobile cellular:
total subscriptions:
11,060,700 (2021 est.)
subscriptions per 100 inhabitants:
127 (2021 est.)
comparison ranking:
total subscriptions 88
Telecommunication systems:
general assessment:
Switzerland has one of the highest broadband penetration rates within Europe, with a focus on services of at least 1Gb/s; this has been supported by sympathetic regulatory measures as well as by cooperative agreements between the main telcos, and with local utilities; fast fiber is complemented by 5G services reaching about 97% of the population by early 2021; together, these networks will soon enable the telcos to provide ultra-fast broadband services nationally, ahead of most other countries in the region; the competitive mobile market is served by three network operators and a small number of MVNOs; 5G services offered by the MNOs offer data rates of up to 2Gb/s, and although various cantons have called a halt to extensions of 5G, citing health concerns, the regulator and environment ministry have put in place measures aimed at ensuring that network roll outs can continue without disruption; with the migration of subscribers to LTE and 5G networks, the MNOs have been able to begin closing down their GSM networks and repurpose physical assets and spectrum; although not a member of the EU, the country’s economic integration has meant that its telecom market deregulation has followed the EU’s liberalization framework, including the recent regulations on international voice roaming; this report presents an analysis of Switzerland’s fixed-line telecom market, including an assessment of network infrastructure (2021)
domestic:
fixed-line is 34 per 100 and mobile-cellular subscribership is 127 per 100 persons (2021)
international:
country code - 41; satellite earth stations - 2 Intelsat (Atlantic Ocean and Indian Ocean)
Broadcast media:
the publicly owned radio and TV broadcaster, Swiss Broadcasting Corporation (SRG/SSR), operates 8 national TV networks, 3 broadcasting in German, 3 in French, and 2 in Italian; private commercial TV stations broadcast regionally and locally; TV broadcasts from stations in Germany, Italy, and France are widely available via multi-channel cable and satellite TV services; SRG/SSR operates 17 radio stations that, along with private broadcasters, provide national to local coverage)
(2019)
Internet country code:
.ch
Internet users:
total:
8.352 million (2021 est.)
percent of population:
96% (2021 est.)
comparison ranking:
total 71
Broadband - fixed subscriptions:
total:
4,028,238 (2020 est.)
subscriptions per 100 inhabitants:
47 (2020 est.)
comparison ranking:
total 38','2b93fa71604efa7111cd9667232e99bdbff12b9011203dab14c59d8d59ee3174','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6bc1a54c98b2e52f0d6a844bc5ada6c2cbb2647d0f09a42212c04994aeecc8c9',2025,'CH','Switzerland','communications',56,'Telephones - fixed lines:
total subscriptions:
2,821,171 (2021 est.)
subscriptions per 100 inhabitants:
13 (2021 est.)
comparison ranking:
total subscriptions 46
Telephones - mobile cellular:
total subscriptions:
16,990,714 (2021 est.)
subscriptions per 100 inhabitants:
80 (2021 est.)
comparison ranking:
total subscriptions 65
Telecommunication systems:
general assessment:
the years of civil war and destruction to infrastructure continue to have a toll on the telecoms sector in Syria; although over the years the major mobile service providers have endeavored to restore and rebuild damaged networks, the operating environment has been difficult; following disputed demands for back taxes, MTN Group in August 2021 exited the country, after its majority stake had been transferred to judicial guardianship; this effectively meant that the mobile market became a monopoly; in February 2022 the regulator awarded a third mobile license following a process which had been ongoing for many years; telecommunication services in Syria are highly regulated; although urban areas can make use of the network built and maintained by the government-owned incumbent, many under served remote areas in the countryside are obliged to rely on satellite communications; the domestic and international fixed-line markets in Syria remain the monopoly of the STE, despite several initiatives over the years aimed at liberalizing the market; mobile broadband penetration in Syria is still quite low, despite quite a high population coverage of 3G networks and some deployment of LTE infrastructure; this may provide potential opportunities for growth once infrastructure and economic reconstruction efforts make headway, and civil issues subside (2022)
domestic:
the number of fixed-line connections is 13 per 100; mobile-cellular service is 80 per 100 persons (2021)
international:
country code - 963; landing points for the Aletar, BERYTAR and UGART submarine cable connections to Egypt, Lebanon, and Cyprus; satellite earth stations - 1 Intelsat (Indian Ocean) and 1 Intersputnik (Atlantic Ocean region); coaxial cable and microwave radio relay to Iraq, Jordan, Lebanon, and Turkey; participant in Medarabtel (2019)
Broadcast media:
state-run TV and radio broadcast networks; state operates 2 TV networks and 5 satellite channels; roughly two-thirds of Syrian homes have a satellite dish providing access to foreign TV broadcasts; 3 state-run radio channels; first private radio station launched in 2005; private radio broadcasters prohibited from transmitting news or political content (2018)
Internet country code:
.sy
Internet users:
total:
8,492,468 (2022 est.)
percent of population:
46.6% (2022 est.)
comparison ranking:
total 69
Broadband - fixed subscriptions:
total:
1,549,356 (2020 est.)
subscriptions per 100 inhabitants:
9 (2020 est.)
comparison ranking:
total 64','f161da72e46ddf04e46cdf4cd33261b5c025dce1de8cb0e6d77d4b1cc9c4bde5','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b0911209d7073cd1ba5a16457e5651f306a3dd6b3aa88da3eaf3ea6abad3e211',2025,'TJ','Tajikistan','communications',10,'Telephones - fixed lines:
total subscriptions:
500,000 (2021 est.)
subscriptions per 100 inhabitants:
5 (2021 est.)
comparison ranking:
total subscriptions 92
Telephones - mobile cellular:
total subscriptions:
12 million (2021 est.)
subscriptions per 100 inhabitants:
120 (2021 est.)
comparison ranking:
total subscriptions 82
Telecommunication systems:
general assessment:
the nation of Tajikistan has had to struggle through economic hardship following the onset of the Covid-19 pandemic; the strain on financial resources inevitably means a continuation of the absence of any meaningful investment or development programs for telecommunications infrastructure; the fixed line telephony and fixed broadband markets continue to languish far behind the mobile sector in terms of teledensity and penetration; with only around 6,000 fixed broadband customers (0.07% penetration), there would appear to be growth potential, but the limited fixed line infrastructure in the country suggests there’s little likelihood of that occurring any time soon; the size of Tajikistan’s mobile market dwarfs the fixed line segment, with an estimated penetration rate of nearly 120%; with a number of private sector companies active in the mobile market, there been more commitment to investment in network upgrades and expansion; three MNOs have all launched commercial 5G services, initially in areas of the capital city Dushanbe; the move towards higher speed mobile services should further underpin the growth in the nascent mobile broadband market, which is still estimated to be at a relatively low penetration level of 42% (at least relative to most other Asian nations) but is predicted to be a strong compound annual growth rate of more than 8% for at least the next five years (2021)
domestic:
fixed-line over 5 per 100 and mobile-cellular over 120 per 100 (2021)
international:
country code - 992; linked by cable and microwave radio relay to other CIS republics and by leased connections to the Moscow international gateway switch; Dushanbe linked by Intelsat to international gateway switch in Ankara (Turkey); 3 satellite earth stations - 2 Intelsat and 1 Orbita
Broadcast media:
state-run TV broadcasters transmit nationally on 9 TV and 10 radio stations, and regionally on 4 stations; 31 independent TV and 20 radio stations broadcast locally and regionally; many households are able to receive Russian and other foreign stations via cable and satellite (2016)
Internet country code:
.tj
Internet users:
total:
3,009,054 (2022 est.)
percent of population:
30.4% (2022 est.)
comparison ranking:
total 121
Broadband - fixed subscriptions:
total:
6,000 (2020 est.)
subscriptions per 100 inhabitants:
0.1 (2020 est.)
comparison ranking:
total 184','a76f6cae61a34438d20ec65ab1e61effcf942d361eefcdc55b78ec3dc338bdaa','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fb328978f0899d1ab2909fc9aa2fb44c12504c425d8287322ea573562d8c07a6',2025,'TJ','Tajikistan','communications',22,'Telephones - fixed lines:
total subscriptions:
72,000 (2021 est.)
subscriptions per 100 inhabitants:
(2021 est.) less than 1
comparison ranking:
total subscriptions 144
Telephones - mobile cellular:
total subscriptions:
54 million (2021 est.)
subscriptions per 100 inhabitants:
85 (2021 est.)
comparison ranking:
total subscriptions 31
Telecommunication systems:
general assessment:
Tanzania’s telecom sector enjoys effective competition, particularly in the mobile segment; the government has encouraged foreign participation to promote economic growth and social development, and policy reforms have led to the country having one of the most liberal telecom sectors in Africa; the government has sought to increase broadband penetration by a range of measures, including the reduction in VAT charged on the sale of smartphones and other devices, and reductions in the cost of data; the MNOs became the leading ISPs following the launch of mobile broadband services based on 3G and LTE technologies; operators are hoping for revenue growth in the mobile data services market, given that the voice market is almost entirely prepaid; the MNOs have invested in network upgrades, which in turn has supported m-mobile data use, as well as m-money transfer services and banking services. Together, these have become a fast-developing source of revenue; the landing of the first international submarine cables in the country some years ago revolutionized the telecom market, which up to that point had entirely depended on expensive satellite connections; the government aims to complete a national fiber backbone network, having signed an agreement; in late 2021, the government announced plans to extend the national backbone network from about 8,300km to 15,000km by 2023, and to provide ongoing connectivity to more countries in the region (2022)
domestic:
fixed-line telephone network less than 1 connection per 100 persons; mobile-cellular service is 85 telephones per 100 persons (2021)
international:
country code - 255; landing points for the EASSy, SEACOM/Tata TGN-Eurasia, and SEAS fiber-optic submarine cable system linking East Africa with the Middle East; satellite earth stations - 2 Intelsat (1 Indian Ocean, 1 Atlantic Ocean) (2019)
Broadcast media:
according to statistics from the Tanzania Communications Regulatory Authority (TCRA), Tanzania had 45 television stations as of 2020; 13 of those stations provided national content services (commercially broadcasting free-to-air television); there are 196 radio stations, most operating at the district level, but also including 5 independent nationally broadcasting stations and 1 state-owned national radio station; international broadcasting is available through satellite television which is becoming increasingly widespread; there are 3 major satellite TV providers (2020)
Internet country code:
.tz
Internet users:
total:
20.48 million (2021 est.)
percent of population:
32% (2021 est.)
comparison ranking:
total 43
Broadband - fixed subscriptions:
total:
1,135,608 (2020 est.)
subscriptions per 100 inhabitants:
2 (2020 est.)
comparison ranking:
total 70','4401279f7c8a32f6034381a142a095509d4472262fa546f06aae7dedbe471526','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('451d001273650319a4e249b93e75ba049c16d59d0cce1b27d723c7fa00026711',2025,'TH','Thailand','communications',34,'Telephones - fixed lines:
total subscriptions:
4.6 million (2021 est.)
subscriptions per 100 inhabitants:
7 (2021 est.)
comparison ranking:
total subscriptions 31
Telephones - mobile cellular:
total subscriptions:
120 million (2021 est.)
subscriptions per 100 inhabitants:
170 (2021 est.)
comparison ranking:
total subscriptions 15
Telecommunication systems:
general assessment:
Thailand’s telecom sector is relatively mature and hosts a mix of public and private sector players; the mobile market is highly developed and has experienced strong growth over the last seven years; the market returned to growth in 2021 after it contracted in 2020 driven by the Covid-19 pandemic, and a steep decline in inbound tourism; it remains highly saturated, owing to overall maturity and the popularity of multiple SIM card use, which has resulted in a particularly high penetration rate; in general, the sector retains considerable potential given the impetus of 5G, the recent spectrum auctions, and continued network deployments by the country’s network operators; further auctions of spectrum in the 700MHz band (being repurposed from digital TV broadcasting), and in the 3.6GHz range will further improve network capacity; in the wire line segment, the decline in fixed-line penetration is expected to continue as subscribers migrate to mobile networks for voice and data services; the emphasis among operators has been to bolster their fiber footprints in key high-value areas; the transition to fiber from DSL and cable has also been facilitated by changes to the regulatory structure that have removed some barriers to investment; this is supporting the cannibalization of older copper-based DSL lines by fiber; the returns from this investment remain a long-term prospect as consumers still favor entry-level packages; there is also strong interest from the government, as well as private vendors, in establishing Thailand as a data center hub to serve the region; the size, capacity and spread of existing data centers in the Greater Mekong Subregion (GMS) outside of Thailand is small; Thailand retains some advantages to attract investment, including improved fiber connectivity and international bandwidth; increasing submarine capacity, such as the SJC2 cable to come online later in 2023, will considerably improve Thailand’s potential as a regional hub (2022)
domestic:
fixed-line is 7 per 100 and mobile-cellular is 170 per 100 (2021)
international:
country code - 66; landing points for the AAE-1, FEA, SeaMeWe-3,-4, APG, SJC2, TIS, MCT and AAG submarine cable systems providing links throughout Asia, Australia, Africa, Middle East, Europe, and US; satellite earth stations - 2 Intelsat (1 Indian Ocean, 1 Pacific Ocean) (2019)
Broadcast media:
26 digital TV stations in Bangkok broadcast nationally, 6 terrestrial TV stations in Bangkok broadcast nationally via relay stations - 2 of the stations are owned by the military, the other 4 are government-owned or controlled, leased to private enterprise, and all are required to broadcast government-produced news programs twice a day; multi-channel satellite and cable TV subscription services are available; radio frequencies have been allotted for more than 500 government and commercial radio stations; many small community radio stations operate with low-power transmitters (2017)
Internet country code:
.th
Internet users:
total:
61.2 million (2021 est.)
percent of population:
85% (2021 est.)
comparison ranking:
total 17
Broadband - fixed subscriptions:
total:
11,478,265 (2020 est.)
subscriptions per 100 inhabitants:
16 (2020 est.)
comparison ranking:
total 18','7c7f8cf49773ccbaa718b07e7d8b06645ce1251ed8957c3272ffd76fc6965503','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2e99341f93cbb00d48336b75d175f563ff7e539185877407f5ac5aa4cd08a440',2025,'TL','Timor-Leste','communications',8,'Telephones - fixed lines:
total subscriptions:
1,900 (2021 est.)
subscriptions per 100 inhabitants:
(2021 est.) less than 1
comparison ranking:
total subscriptions 218
Telephones - mobile cellular:
total subscriptions:
1.4 million (2021 est.)
subscriptions per 100 inhabitants:
100 (2021 est.)
comparison ranking:
total subscriptions 159
Telecommunication systems:
general assessment:
Timor-Leste has been moving forward with the regeneration of its economy and rebuilding key infrastructure, including telecommunications networks, that were destroyed during the years of civil unrest; fixed-line and fixed broadband penetration in Timor-Leste remains extremely low, mainly due to the limited fixed-line infrastructure and the proliferation of mobile connectivity; in an effort to boost e-government services; the number of subscribers through to 2026 is expected to develop steadily, though from a low base; by August 2020, Timor-Leste had three telecom service providers who jointly achieved a 98% network coverage nationally; the mobile broadband market is still at an early stage of development, strong growth is predicted over the next five years; at the end of 2020, the government issued new policy guidelines to maximize the use of spectrum in Timor-Leste; it invited mobile operators to submit applications for the allocation of spectrum in the 1800MHz, 2300MHz and 2600MHz bands; in November 2020, the government approved the deployment of a submarine fiber link connecting the south of the country to Australia via the North Western Cable System (NWCS) (2021)
domestic:
fixed-line services less than 1 per 100 and mobile-cellular services is 100 per 100 (2021)
international:
country code - 670; international service is available; partnership with Australia telecom companies for potential deployment of a submarine fiber-optic link (NWCS); geostationary earth orbit satellite
Broadcast media:
7 TV stations (3 nationwide satellite coverage; 2 terrestrial coverage, mostly in Dili; 2 cable) and 21 radio stations (3 nationwide coverage) (2019)
Internet country code:
.tl
Internet users:
total:
507,000 (2021 est.)
percent of population:
39% (2021 est.)
comparison ranking:
total 167
Broadband - fixed subscriptions:
total:
75 (2020 est.)
subscriptions per 100 inhabitants:
0.01 (2020 est.)
comparison ranking:
total 214','555c8f7b57c69e13ae1e31b23e26a99a6579c51426596bf853ff20f1a0021a8b','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c295a416b741b73d24339060179a05844791ea591b5b75b358add40750ee0d3e',2025,'TG','Togo','communications',19,'Telephones - fixed lines:
total subscriptions:
54,000 (2021 est.)
subscriptions per 100 inhabitants:
(2021 est.) less than 1
comparison ranking:
total subscriptions 153
Telephones - mobile cellular:
total subscriptions:
6.3 million (2021 est.)
subscriptions per 100 inhabitants:
72 (2021 est.)
comparison ranking:
total subscriptions 114
Telecommunication systems:
general assessment:
include radio, television, fixed and mobile telephones, and the Internet (2022)
domestic:
fixed-line less than 1 per 100 and mobile-cellular is 72 telephones per 100 persons (2021)
international:
country code - 228; landing point for the WACS submarine cable, linking countries along the west coast of Africa with each other and with Portugal; satellite earth stations - 1 Intelsat (Atlantic Ocean), 1 Symphonie (2020)
Broadcast media:
1 state-owned TV station with multiple transmission sites; five private TV stations broadcast locally; cable TV service is available; state-owned radio network with two stations (in Lome and Kara); several dozen private radio stations and a few community radio stations; transmissions of multiple international broadcasters available (2019)
Internet country code:
.tg
Internet users:
total:
3.01 million (2021 est.)
percent of population:
35% (2021 est.)
comparison ranking:
total 120
Broadband - fixed subscriptions:
total:
52,706 (2020 est.)
subscriptions per 100 inhabitants:
0.6 (2020 est.)
comparison ranking:
total 143','9e388e84737213cb51422368e6e3ea80cf6c6c2ff489646768ce18c74ad95850','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('534795adc9fdb3bf769b923e5ac3f75796e92df6334f702c8f899a2547a9120d',2025,'TK','Tokelau','communications',30,'Telephones - fixed lines:
total subscriptions:
300 (2010 est.)
subscriptions per 100 inhabitants:
22 (2010 est.)
comparison ranking:
total subscriptions 220
Telecommunication systems:
general assessment:
a new submarine cable between New Zealand and Tokelau will provide high speed, reliable internet to Tokelau for the first time; due for completion in 2022, this will provide Tokelau with affordable, high quality internet and telecommunications, and better, more effective access to digital services and platforms (2021)
domestic:
fixed-line teledensity is 0 per 100 persons (2019)
international:
country code - 690; landing point for the Southern Cross NEXT submarine cable linking Australia, Tokelau, Samoa, Kiribati, Fiji, New Zealand and Los Angeles, CA (USA); radiotelephone service to Samoa; government-regulated telephone service (TeleTok); satellite earth stations - 3 (2020)
Broadcast media:
Sky TV access for around 30% of the population; each atoll operates a radio service that provides shipping news and weather reports (2019)
Internet country code:
.tk
Internet users:
total:
800 (2021 est.)
percent of population:
58.3% (2021 est.)
comparison ranking:
total 231','fa5aa0cc1209a1de17d096b7cc4f39ca9184a4cddb1ee49f1b2dd73dfd5915cd','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2a5645aabd2fba9c8052b68f8a956b79cbbc99aeadbc7551229943bcef78b339',2025,'TO','Tonga','communications',41,'Telephones - fixed lines:
total subscriptions:
11,000 (2021 est.)
subscriptions per 100 inhabitants:
10 (2021 est.)
comparison ranking:
total subscriptions 190
Telephones - mobile cellular:
total subscriptions:
64,000 (2021 est.)
subscriptions per 100 inhabitants:
61 (2021 est.)
comparison ranking:
total subscriptions 202
Telecommunication systems:
general assessment:
Tonga was only connected to the global submarine telecommunication network in the last decade; this system is more stable than other technologies such as satellite and fixed infrastructure (2022)
domestic:
fixed-line 10 per 100 persons and mobile-cellular teledensity 61 telephones per 100 (2021)
international:
country code - 676; landing point for the Tonga Cable and the TDCE connecting to Fiji and 3 separate Tonga islands; satellite earth station - 1 Intelsat (Pacific Ocean) (2020)
Broadcast media:
1 state-owned TV station and 3 privately owned TV stations; satellite and cable TV services are available; 1 state-owned and 5 privately owned radio stations; Radio Australia broadcasts available via satellite (2019)
Internet country code:
.to
Internet users:
total:
73,700 (2021 est.)
percent of population:
67% (2021 est.)
comparison ranking:
total 194
Broadband - fixed subscriptions:
total:
5,000 (2020 est.)
subscriptions per 100 inhabitants:
5 (2020 est.)
comparison ranking:
total 188','ddeae14401f775131b2571957745ce86d50f6d06f3f34378331386731141fd89','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c84d848363343a7d60b3bed057b4733783f66ce045dab808fc0b2093d449508a',2025,'TT','Trinidad and Tobago','communications',52,'Telephones - fixed lines:
total subscriptions:
340,000 (2021)
subscriptions per 100 inhabitants:
22 (2021 est.)
comparison ranking:
total subscriptions 105
Telephones - mobile cellular:
total subscriptions:
2 million (2021 est.)
subscriptions per 100 inhabitants:
130 (2021 est.)
comparison ranking:
total subscriptions 149
Telecommunication systems:
general assessment:
excellent international service; good local service; broadband access; expanded FttP (Fiber to the Home) markets; LTE launch; regulatory development; major growth in mobile telephony and data segments which attacks operation investment in fiber infrastructure; moves to end roaming charges (2020)
domestic:
fixed-line is 22 per 100 persons and mobile-cellular teledensity 130 per 100 persons (2021)
international:
country code - 1-868; landing points for the EC Link, ECFS, Southern Caribbean Fiber, SG-SCS and Americas II submarine cable systems provide connectivity to US, parts of the Caribbean and South America; satellite earth station - 1 Intelsat (Atlantic Ocean); tropospheric scatter to Barbados and Guyana (2020)
Broadcast media:
6 free-to-air TV networks, 2 of which are state-owned; 24 subscription providers (cable and satellite); over 36 radio frequencies (2019)
Internet country code:
.tt
Internet users:
total:
1.185 million (2021 est.)
percent of population:
79% (2021 est.)
comparison ranking:
total 146
Broadband - fixed subscriptions:
total:
376,771 (2020 est.)
subscriptions per 100 inhabitants:
27 (2020 est.)
comparison ranking:
total 101','3891b822e0c3734ac529e41e526b906a13275c252040ec282984a8bfe69cacc6','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2752baa6db0a9b503e85a901c6ed7e27a3a538279633cff957d790e851b6c7a1',2025,'TN','Tunisia','communications',8,'Telephones - fixed lines:
total subscriptions:
1.7 million (2021 est.)
subscriptions per 100 inhabitants:
14 (2021 est.)
comparison ranking:
total subscriptions 57
Telephones - mobile cellular:
total subscriptions:
16 million (2021 est.)
subscriptions per 100 inhabitants:
130 (2021 est.)
comparison ranking:
total subscriptions 69
Telecommunication systems:
general assessment:
Tunisia has one of the most sophisticated telecom infrastructures in North Africa; penetration rates for mobile and Internet services are among the highest in the region; government program of regulation and infrastructure projects aims to improve Internet connectivity to underserved areas; operators built extensive LTE infrastructure in 2019, and continue to discuss plans for future 5G networks and services; one operator has signed an agreement to pursue nano-satellite launches in 2023; internet censorship abolished, though concerns of government surveillance remain; legislation passed in 2017 supporting e-commerce and active e-government; importer of some integrated circuits and broadcasting equipment (including radio, television, and communications transmitters) from the PRC (2022)
domestic:
fixed-line is nearly 14 per 100 and mobile-cellular teledensity is 130 telephones per 100 persons (2021)
international:
country code - 216; landing points for the SEA-ME-WE-4, Didon, HANNIBAL System and Trapani-Kelibia submarine cable systems that provides links to Europe, Africa, the Middle East, Asia and Southeast Asia; satellite earth stations - 1 Intelsat (Atlantic Ocean) and 1 Arabsat; coaxial cable and microwave radio relay to Algeria and Libya; participant in Medarabtel; 2 international gateway digital switches (2020)
Broadcast media:
2 state-owned TV stations; 10 private TV stations broadcast locally; satellite TV service is available; state-owned radio network with 2 stations; several dozen private radio stations and community radio stations; transmissions of multiple international broadcasters available (2019)
Internet country code:
.tn
Internet users:
total:
9.48 million (2021 est.)
percent of population:
79% (2021 est.)
comparison ranking:
total 60
Broadband - fixed subscriptions:
total:
1,334,059 (2020 est.)
subscriptions per 100 inhabitants:
11 (2020 est.)
comparison ranking:
total 67','1b859a79f43b30dfdba851d13b7b4869b79cdd259beb23eaf387d666d499a67c','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e5117ff8939bf4ebc53121a8f5c40d082eac4bccbf51bb65819e0d1e59747251',2025,'TN','Tunisia','communications',21,'Telephones - fixed lines:
total subscriptions:
12 million (2021 est.)
subscriptions per 100 inhabitants:
15 (2021 est.)
comparison ranking:
total subscriptions 17
Telephones - mobile cellular:
total subscriptions:
86 million (2021 est.)
subscriptions per 100 inhabitants:
100 (2021 est.)
comparison ranking:
total subscriptions 19
Telecommunication systems:
general assessment:
Turkey continues to develop its capabilities within its telecom sector, becoming one of the relatively few countries able to build and develop its own communications satellites; with the successful launch of the Turksat 5A and 5B satellites in 2021, the country has vastly increased its bandwidth capacity; these satellites will be joined by the Turksat 6A in 2023; the country’s telcos have invested in fiber infrastructure; deployment of fiber-based broadband networks are well established, with fiber accounting for 26.7% of all fixed broadband connections as of early 2022; the DSL sector still dominates, accounting for about 63% of connections, but its share is steadily declining, year-on-year, while the number of fiber connections has grown strongly; improved fixed and mobile infrastructure is underpinning the country’s initiatives relating to Smart City concepts, which have become a key area of focus for the emerging digital economy and the transformation to a knowledge-based economy; Turkey’s National Smart Cities Strategy and Action Plan runs through to 2023 (2022)
domestic:
fixed-line nearly 15 per 100 and mobile-cellular teledensity is 100 telephones per 100 persons (2021)
international:
country code - 90; landing points for the SeaMeWe-3 & -5, MedNautilus Submarine System, Turcyos-1 & -2 submarine cables providing connectivity to Europe, Africa, the Middle East, Asia, Southeast Asia and Australia ; satellite earth stations - 12 Intelsat; mobile satellite terminals - 328 in the Inmarsat and Eutelsat systems (2020)
Broadcast media:
Turkish Radio and Television Corporation (TRT) operates multiple TV and radio networks and stations; multiple privately owned national television stations and 567 private regional and local television stations; multi-channel cable TV subscriptions available; 1,007 private radio broadcast stations (2019)
Internet country code:
.tr
Internet users:
total:
68.85 million (2021 est.)
percent of population:
81% (2021 est.)
comparison ranking:
total 14
Broadband - fixed subscriptions:
total:
16,734,853 (2020 est.)
subscriptions per 100 inhabitants:
20 (2020 est.)
comparison ranking:
total 13','302a9145838291544b22e6350420da124c9eed3fad875a9878f1ab7d1ebd6091','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5344b33445c90402ac8a86f427327b04f039f2136dd1e556da511d5671d4400c',2025,'TM','Turkmenistan','communications',34,'Telephones - fixed lines:
total subscriptions:
800,000 (2021 est.)
subscriptions per 100 inhabitants:
13 (2021 est.)
comparison ranking:
total subscriptions 75
Telephones - mobile cellular:
total subscriptions:
6.3 million (2021 est.)
subscriptions per 100 inhabitants:
99 (2021 est.)
comparison ranking:
total subscriptions 113
Telecommunication systems:
general assessment:
the nation of Turkmenistan, which rivals only North Korea for its isolationism, continues to keep its telecom sector along with the broader populace under tight control; the country inched up just one point off the bottom of the world rankings for press and internet freedom in the most recent report from Reporters Without Borders; most social networks in the country are blocked, although locals do have access to the government-developed platform released in 2019; all internet users, however, need to identify themselves before logging on, and strict censorship over what can be viewed is in force; the end result is that Turkmenistan has one of the lowest penetration rates for internet access in the world (2022)
domestic:
fixed-line is 13 per 100 and mobile-cellular teledensity is 99 per 100 persons (2021)
international:
country code - 993; linked by fiber-optic cable and microwave radio relay to other CIS republics and to other countries by leased connections to the Moscow international gateway switch; an exchange in Ashgabat switches international traffic through Turkey via Intelsat; satellite earth stations - 1 Orbita and 1 Intelsat (2018)
Broadcast media:
broadcast media is government controlled and censored; 7 state-owned TV and 4 state-owned radio networks; satellite dishes and programming provide an alternative to the state-run media; officials sometimes limit access to satellite TV by removing satellite dishes
Internet country code:
.tm
Internet users:
total:
1,563,023 (2022 est.)
percent of population:
25.3% (2022 est.)
comparison ranking:
total 143
Broadband - fixed subscriptions:
total:
10,000 (2020 est.)
subscriptions per 100 inhabitants:
0.2 (2020 est.)
comparison ranking:
total 180','c2e117d2917e26e488b848604e5a4ceea34a8bb615e3446976ec776aa1e3b8c4','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('de53a9d702f9c632d4c2a0e56e4d15b601e33b99e178968a86c5676f14bcf8ea',2025,'TC','Turks and Caicos Islands','communications',46,'Telephones - fixed lines:
total subscriptions:
4,000 (2021 est.)
subscriptions per 100 inhabitants:
9 (2021 est.)
comparison ranking:
total subscriptions 209
Telephones - mobile cellular:
total subscriptions:
25,085 (2004 est.)
subscriptions per 100 inhabitants:
110 (2004 est.)
comparison ranking:
total subscriptions 213
Telecommunication systems:
general assessment:
is connected to the internet via a single submarine fiber-optic cable (Arcos-1), which links the US and several Caribbean countries (2023)
domestic:
fixed-line teledensity is 9 per 100 persons (2021)
international:
country code - 1-649; landing point for the ARCOS fiber-optic telecommunications submarine cable providing connectivity to South and Central America, parts of the Caribbean, and the US; satellite earth station - 1 Intelsat (Atlantic Ocean) (2020)
Broadcast media:
no local terrestrial TV stations, broadcasts from the Bahamas can be received and multi-channel cable and satellite TV services are available; government-run radio network operates alongside private broadcasters with a total of about 15 stations
Internet country code:
.tc
Internet users:
total:
37,008 (2022)
percent of population:
93.5% (2022)
comparison ranking:
total 207','f355516080cca14b555ac9caca200b6132a67068c6eef8eab5c60deee149d55c','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ea065b935d413814bee6b7c395d434fae3ba50a3b68b87cdc4d125d3649db042',2025,'TV','Tuvalu','communications',57,'Telephones - fixed lines:
total subscriptions:
2,000 (2021 est.)
subscriptions per 100 inhabitants:
18 (2021 est.)
comparison ranking:
total subscriptions 216
Telephones - mobile cellular:
total subscriptions:
9,000 (2021 est.)
subscriptions per 100 inhabitants:
80 (2021 est.)
comparison ranking:
total subscriptions 220
Telecommunication systems:
general assessment:
provides fixed-line telephone communications to subscribers on each of the islands of Tuvalu; each island relies on the use of a satellite dish for inter-island telephone communication, internet access, and mobile phone services (2023)
domestic:
fixed-line teledensity is 18 per 100 and mobile-cellular is 80 per 100 (2021)
international:
country code - 688; international calls can be made by satellite
Broadcast media:
no TV stations; many households use satellite dishes to watch foreign TV stations; 1 government-owned radio station, Radio Tuvalu, includes relays of programming from international broadcasters (2019)
Internet country code:
.tv
Internet users:
total:
7,920 (2021 est.)
percent of population:
49% (2021 est.)
comparison ranking:
total 219
Broadband - fixed subscriptions:
total:
450 (2017 est.)
subscriptions per 100 inhabitants:
4 (2017 est.)
comparison ranking:
total 211','0cf280569241bea7dda6c816a2ff88871682b88960f4c10b1b126071aab13ff0','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('78c3e24cd7149f9a94f5de707a8b9257794c51db17bd1820e2ab9d5f32155c5f',2025,'UG','Uganda','communications',8,'Telephones - fixed lines:
total subscriptions:
110,000 (2021 est.)
subscriptions per 100 inhabitants:
(2021 est.) less than 1
comparison ranking:
total subscriptions 134
Telephones - mobile cellular:
total subscriptions:
30 million (2021 est.)
subscriptions per 100 inhabitants:
66 (2021 est.)
comparison ranking:
total subscriptions 46
Telecommunication systems:
general assessment:
a series of reforms within Uganda’s telecom sector have provided the country with one of the most competitive markets in the region; in line with the regulator’s licensing requirements by which Uganda-based companies should be broadly owned by Ugandans by mid-2022; fixed-line infrastructure remains poor, with low penetration, and as a result fixed-line broadband penetration is also particularly low; consumers have largely depended on mobile infrastructure to provide voice and broadband services; there is sufficient capacity with LTE infrastructure to match data demand during the next few years; Uganda has anticipated the migration to 5G, having held trials in early 2020 though the roll out of 5G is not expected until later in 2022 (2022)
domestic:
fixed-line less than 1 per 100 and mobile cellular systems teledensity is 66 per 100 persons (2021)
international:
country code - 256; satellite earth stations - 1 Intelsat (Atlantic Ocean) and 1 Inmarsat; analog and digital links to Kenya and Tanzania
Broadcast media:
public broadcaster, Uganda Broadcasting Corporation (UBC), operates radio and TV networks; 31 Free-To-Air (FTA) TV stations, 2 digital terrestrial TV stations, 3 cable TV stations, and 5 digital satellite TV stations; 258 operational FM stations
Internet country code:
.ug
Internet users:
total:
4.6 million (2021 est.)
percent of population:
10% (2021 est.)
comparison ranking:
total 102
Broadband - fixed subscriptions:
total:
58,594 (2020 est.)
subscriptions per 100 inhabitants:
0.1 (2020 est.)
comparison ranking:
total 140','859dd20c5afe299a035c66043facbc4df9c797bde101cbcc7d7540a15f4521cd','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f045e4e88810c18963997672f2690fd98e210110502c1c2c51688ae2d7fa5610',2025,'UA','Ukraine','communications',21,'Telephones - fixed lines:
total subscriptions:
2.3 million (2021 est.)
subscriptions per 100 inhabitants:
6 (2021 est.)
comparison ranking:
total subscriptions 52
Telephones - mobile cellular:
total subscriptions:
56 million (2021 est.)
subscriptions per 100 inhabitants:
140 (2021 est.)
comparison ranking:
total subscriptions 30
Telecommunication systems:
general assessment:
there has been considerable damage and destruction to the communications infrastructure in more than 10 out of 24 regions of Ukraine since the war started (2023)
domestic:
fixed-line teledensity is 6 per 100; the mobile-cellular telephone is 140 mobile phones per 100 persons (2021)
international:
country code - 380; landing point for the Kerch Strait Cable connecting Ukraine to Russia; 2 new domestic trunk lines are a part of the fiber-optic TAE system and 3 Ukrainian links have been installed in the fiber-optic TEL project that connects 18 countries; additional international service is provided by the Italy-Turkey-Ukraine-Russia (ITUR) fiberoptic submarine cable and by an unknown number of earth stations in the Intelsat, Inmarsat, and Intersputnik satellite systems
Broadcast media:
Ukraine’s media landscape is dominated by oligarch-owned news outlets, which are often politically motivated and at odds with one another and/or the government; while polls suggest most Ukrainians still receive news from traditional media sources, social media is a crucial component of information dissemination in Ukraine; almost all Ukrainian politicians and opinion leaders communicate with the public via social media and maintain at least one social media page, if not more; this allows them direct communication with audiences, and news often breaks on Facebook or Twitter before being picked up by traditional news outlets; Kyiv created a unified news platform to broadcast news about the war following Russia’s full-scale invasion; the government’s “United News” television marathon is a round-the clock framework which untied the Ukrainian public broadcaster and top commercial TV channels’ programming; Ukraine television serves as the principal source of news; the largest national networks are controlled by oligarchs: Studio 1+1 is owned by Ihor Kolomoyskyy; Inter is owned by Dmytro Firtash and Serhiy Lyovochkin; and StarlightMedia channels (ICTV, STB, and Novyi Kanal) are owned by Victor Pinchuk; a set of 24-hour news channels also have clear political affiliations: pro-Ukrainian government Channel 5 and Pryamyi are linked to President Petro Poroshenko; 24 is owned by opposition, but not pro-Russian, politicians; UA: Suspilne is a public television station under the umbrella of the National Public Broadcasting Company of Ukraine; while it is often praised by media experts for balanced coverage, it lags in popularity; Ukrainian Radio, institutionally linked to UA: Suspilne, is one of only two national talk radio networks, with the other being the privately owned Radio NV (2021)
Internet country code:
.ua
Internet users:
total:
34,596,356 (2021 est.)
percent of population:
79% (2021 est.)
comparison ranking:
total 29
Broadband - fixed subscriptions:
total:
7,769,401 (2020 est.)
subscriptions per 100 inhabitants:
19 (2020 est.)
comparison ranking:
total 27
Communications - note:
a sorting code to expeditiously handle large volumes of mail was first set up in Ukraine in the 1930s (then the Ukrainian Soviet Socialist Republic, part of the Soviet Union); the sophisticated, three-part (number-letter-number) postal code system, referred to as an “index,” was the world’s first postal zip code; the system functioned well and was in use from 1932 to 1939 when it was abruptly discontinued','dfe7d907f81c1029a9b67e4fa0ae26c6eaf268b36ab94505a4075bac83cc8cbf','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('47428eeda1afc2936d394d2a0980d9ff0d301a13f28036542a1725aac669a03c',2025,'AE','United Arab Emirates','communications',33,'Telephones - fixed lines:
total subscriptions:
2.2 million (2021 est.)
subscriptions per 100 inhabitants:
24 (2021 est.)
comparison ranking:
total subscriptions 54
Telephones - mobile cellular:
total subscriptions:
18 million (2021 est.)
subscriptions per 100 inhabitants:
190 (2021 est.)
comparison ranking:
total subscriptions 63
Telecommunication systems:
general assessment:
the UAE has a strong mobile market; while the 5G penetration rate is the second highest globally after China; this has underpinned growth in the mobile broadband sector, and has enabled the strong development in the take-up of rich content and applications, as well as m-commerce; to help increase the capacity of 5G networks in coming years, and so keep up with data demand, the government has allowed for the GSM networks to be closed down and for spectrum and other assets to be re-purposed for 5G by the end of 2022; the fixed-broadband network in the UAE is dominated by fiber, with DSL having a minor and declining presence; this focus on a fully fiber infrastructure has also facilitated growth in e-commerce, and has supported the government’s long-term aim of transitioning the economy from its dependence on oil to being knowledge-based and supported by digital services; the country stands to benefit from having signed the Abraham Accord Declaration with Israel, which aims to normalize relations between the two countries; such benefits can be seen in the agreement to enable local ISPs to access Bezeq International’s submarine cable infrastructure, and so improve direct connectivity to Europe, South East Asia, and Africa; the UAE’s ISPs can also access Bezeq International’s data center in Tel Aviv, improving internet services (2022)
domestic:
fixed-line is 24 per 100 and mobile-cellular is 190 per 100 (2021)
international:
country code - 971; landing points for the FLAG, SEA-ME-WE-3,-4 & -5, Qater UAE Submarine Cable System, FALCON, FOG, Tat TGN-Gulf, OMRAN/EPEG Cable System, AAE-1, BBG, EIG, FEA, GBICS/MENA, IMEWE, Orient Express, TEAMS, TW1 and the UAE-Iran submarine cables, linking to Europe, Africa, the Middle East, Asia, Southeast Asia and Australia; satellite earth stations - 3 Intelsat (1 Atlantic Ocean and 2 Indian) (2020)
Broadcast media:
except for the many organizations now operating in media free zones in Abu Dhabi and Dubai, most TV and radio stations remain government-owned; widespread use of satellite dishes provides access to pan-Arab and other international broadcasts; restrictions since June 2017 on some satellite channels and websites originating from or otherwise linked to Qatar, but in early 2023 Abu Dhabi unblocked several sites, including Al Jazeera (2022)
Internet country code:
.ae
Internet users:
total:
9.4 million (2021 est.)
percent of population:
100% (2021 est.)
comparison ranking:
total 61
Broadband - fixed subscriptions:
total:
3,245,123 (2020 est.)
subscriptions per 100 inhabitants:
33 (2020 est.)
comparison ranking:
total 45','d0feb8ca80e637218f4d4b8f9d031959307e0f3f3bcfa66a229b6cc4ee1f3538','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c6d5282e90111ef7530b3658cc5404ec5204df23dbdf098a8eb50c40e98aa014',2025,'GB','United Kingdom','communications',45,'Telephones - fixed lines:
total subscriptions:
33 million (2021 est.)
subscriptions per 100 inhabitants:
48 (2021 est.)
comparison ranking:
total subscriptions 6
Telephones - mobile cellular:
total subscriptions:
80 million (2021 est.)
subscriptions per 100 inhabitants:
120 (2021 est.)
comparison ranking:
total subscriptions 20
Telecommunication systems:
general assessment:
UK’s telecom market remains one of the largest in Europe, characterized by competition, affordable pricing, and its technologically advanced systems; mobile penetration above the EU average; government to invest in infrastructure and 5G technologies with ambition for a fully-fibered nation by 2033; operators expanded the reach of 5G services in 2020; super-fast broadband available to about 95% of customers; London is developing smart city technology, in collaboration with private, tech, and academic sectors (2021)
domestic:
fixed-line is 48 per 100 and mobile-cellular is 120 per 100 (2021)
international:
country code - 44; Landing points for the GTT Atlantic, Scotland-Northern Ireland -1, & -2, Lanis 1,-2, &-3, Sirius North, BT-MT-1, SHEFA-2, BT Highlands and Islands Submarine Cable System, Northern Lights, FARICE-1, Celtic Norse, Tampnet Offshore FOC Network, England Cable, CC-2, E-LLan, Sirius South, ESAT -1 & -2, Rockabill, Geo-Eirgrid, UK-Netherlands-14, Circle North & South, Ulysses2, Conceto, Farland North, Pan European Crossing, Solas, Swansea-Bream, GTT Express, Tata TGN-Atlantic & -Western Europe, Apollo, EIG, Glo-1, TAT-14, Yellow, Celtic, FLAG Atlantic-1, FEA, Isle of Scilly Cable, UK-Channel Islands-8 and SeaMeWe-3 submarine cables providing links throughout Europe, Asia, Africa, the Middle East, Southeast Asia, Australia, and US; satellite earth stations - 10 Intelsat (7 Atlantic Ocean and 3 Indian Ocean), 1 Inmarsat (Atlantic Ocean region), and 1 Eutelsat; at least 8 large international switching centers (2019)
Broadcast media:
public service broadcaster, British Broadcasting Corporation (BBC), is the largest broadcasting corporation in the world; BBC operates multiple TV networks with regional and local TV service; a mixed system of public and commercial TV broadcasters along with satellite and cable systems provide access to hundreds of TV stations throughout the world; BBC operates multiple national, regional, and local radio networks with multiple transmission sites; a large number of commercial radio stations, as well as satellite radio services are available (2018)
Internet country code:
.uk
Internet users:
total:
64.99 million (2021 est.)
percent of population:
97% (2021 est.)
comparison ranking:
total 16
Broadband - fixed subscriptions:
total:
27,330,297 (2020 est.)
subscriptions per 100 inhabitants:
40 (2020 est.)
comparison ranking:
total 8
Communications - note:
note 1:
the British Library claims to be the largest library in the world with well over 150 million items and in most known languages; it receives copies of all books produced in the UK or Ireland, as well as a significant proportion of overseas titles distributed in the UK; in addition to books (print and digital), holdings include: journals, manuscripts, newspapers, magazines, sound and music recordings, videos, maps, prints, patents, and drawings
note 2:
on 1 May 1840, the United Kingdom led the world with the introduction of postage stamps; the Austrian Empire had examined the idea of an “adhesive tax postmark” for the prepayment of postage in 1835; while the suggestion was reviewed in detail, it was rejected for the time being; other countries (including Austria) soon followed the UK’s example with their own postage stamps; by the 1860s, most countries were issuing stamps; originally, stamps had to be cut from sheets; the UK issued the first postage stamps with perforations in 1854','7b5e9f7126c02bc29ebfaf50ad4186fb3375dc8d10bf4d729900b5c14e17d6ca','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cc28030d75d3cc468075fb5bb7cd3243792f6a9e65699ffa44291135e77c73d2',2025,'US','United States','communications',8,'Telephones - fixed lines:
total subscriptions:
98 million (2021 est.)
subscriptions per 100 inhabitants:
29 (2021 est.)
comparison ranking:
total subscriptions 2
Telephones - mobile cellular:
total subscriptions:
360 million (2021 est.)
subscriptions per 100 inhabitants:
110 (2021 est.)
comparison ranking:
total subscriptions 4
Telecommunication systems:
general assessment:
the US telecom sector adapted well to the particular demands of the pandemic, which has led to strong growth in the number of mobile, mobile broadband, and fixed broadband subscribers since 2020; the level of growth is expected to taper off from late 2022 as the demand for working and schooling from home subsides; the pandemic also encouraged the Federal government to increase its investment in broadband infrastructure; of particular note was the Infrastructure Investment and Jobs Act of November 2021, which provided $65 billion to a range of programs aimed at delivering broadband to unserved areas, providing fiber-based broadband to upgrade existing service areas, and subsidizing the cost of services to low income households; alongside these fiscal efforts have been the several spectrum auctions undertaken during the last two years, which have greatly assisted the main licensees to improve the reach and quality of their offers based on LTE and 5G; some of this spectrum, auctioned during 2021, was only made available to licensees from February 2022; the widening availability of 5G from the main providers has resulted in a dramatic increase in mobile data traffic; in tandem with the focus on 5G, operators have closed down their GSM and CDMA networks, and have either closed down 3G networks (as AT&T did in January 2022), or plan to in coming months; given the size of the US broadband market, and the growing demand for data on both fixed and mobile networks, there is continuous pressure for operators to invest in fiber networks, and to push connectivity closer to consumers; in recent years the US has seen increased activity from regional players as well as the major telcos and cablecos; although there has been considerable investment in DOCSIS4.0, some of the cablecos are looking to ditch HFC in preference for fiber broadband; the process of migrating from copper (HFC and DSL) to fiber is ongoing, but given the scale of the work involved it will take some years; some operators have investment strategies in place through to 2025, which will see the vast majority of their fixed networks being entirely on fiber; service offerings of up to 2Gb/s are becoming more widely available as the process continues (2022)
domestic:
fixed-line just over 29 per 100 and mobile-cellular is 110 per 100 (2021)
international:
country code - 1; landing points for the Quintillion Subsea Cable Network, TERRA SW, AU-Aleutian, KKFL, AKORN, Alaska United -West, & -East & -Southeast, North Star, Lynn Canal Fiber, KetchCar 1, PC-1, SCCN, Tat TGN-Pacific & -Atlantic, Jupiter, Hawaiki, NCP, FASTER, HKA, JUS, AAG, BtoBE, Currie, Southern Cross NEXT, SxS, PLCN, Utility EAC-Pacific, SEA-US, Paniolo Cable Network, HICS, HIFN, ASH, Telstra Endeavor, Honotua, AURORA, ARCOS, AMX-1, Americas -I & -II, Columbus IIb & -III, Maya-1, MAC, GTMO-1, BICS, CFX-1, GlobeNet, Monet, SAm-1, Bahamas 2, PCCS, BRUSA, Dunant, MAREA, SAE x1, TAT 14, Apollo, Gemini Bermuda, Havfrue/AEC-2, Seabras-1, WALL-LI, NYNJ-1, FLAG Atalantic-1, Yellow, Atlantic Crossing-1, AE Connect -1, sea-2shore, Challenger Bermuda-1, and GTT Atlantic submarine cable systems providing international connectivity to Europe, Africa, the Middle East, Asia, Southeast Asia, Australia, New Zealand, Pacific, & Atlantic, and Indian Ocean Islands, Central and South America, Caribbean, Canada and US; satellite earth stations - 61 Intelsat (45 Atlantic Ocean and 16 Pacific Ocean), 5 Intersputnik (Atlantic Ocean region), and 4 Inmarsat (Pacific and Atlantic Ocean regions) (2020)
Broadcast media:
4 major terrestrial TV networks with affiliate stations throughout the country, plus cable and satellite networks, independent stations, and a limited public broadcasting sector that is largely supported by private grants; overall, thousands of TV stations broadcasting; multiple national radio networks with many affiliate stations; while most stations are commercial, National Public Radio (NPR) has a network of some 900 member stations; satellite radio available; in total, over 15,000 radio stations operating (2018)
Internet country code:
.us
Internet users:
total:
312.8 million (2021 est.)
percent of population:
92% (2021 est.)
comparison ranking:
total 3
Broadband - fixed subscriptions:
total:
121.176 million (2020 est.)
subscriptions per 100 inhabitants:
37 (2020 est.)
comparison ranking:
total 2
Communications - note:
note 1: The Library of Congress, Washington DC, USA, claims to be the largest library in the world with more than 167 million items (as of 2018); its collections are universal, not limited by subject, format, or national boundary, and include materials from all parts of the world and in over 450 languages; collections include
:
books, newspapers, magazines, sheet music, sound and video recordings, photographic images, artwork, architectural drawings, and copyright data
note 2:
Cape Canaveral, Florida, USA, hosts one of four dedicated ground antennas that assist in the operation of the Global Positioning System (GPS) navigation system (the others are on Ascension (Saint Helena, Ascension, and Tistan da Cunha), Diego Garcia (British Indian Ocean Territory), and at Kwajalein (Marshall Islands)','94eb6578d0a242d7c0eeb883acc72768fac69164e953b602e5551e7f7b61ecb5','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('82176b07e20a0b76d06f1b86f67710db58523903b8086df01c749cb49d61b586',2025,'UY','Uruguay','communications',29,'Telephones - fixed lines:
total subscriptions:
1.2 million (2021 est.)
subscriptions per 100 inhabitants:
36 (2021 est.)
comparison ranking:
total subscriptions 68
Telephones - mobile cellular:
total subscriptions:
4.7 million (2021 est.)
subscriptions per 100 inhabitants:
140 (2021 est.)
comparison ranking:
total subscriptions 126
Telecommunication systems:
general assessment:
Uruguay has an advanced telecom market, with excellent infrastructure and one of the highest broadband penetration rates in Latin America; fixed-line teledensity is also particularly high for the region, while mobile penetration is the second highest after Panama; in terms of computer penetration, Uruguay tops all other countries in the region by a considerable margin, and this has facilitated growth in fixed-line broadband adoption; the government and telecom regulator have introduced a range of measures to help develop the deployment of fiber infrastructure, partly in a bid to encourage economic growth and stimulate e-commerce; fiber accounted for about 77% of all fixed and fixed-wireless broadband connections as of June 2020; with investment projected to reach $800 million, the state-owned incumbent Antel is expected to provide national FttP coverage by early 2022; together with the FttP network, the opening of the submarine cable system in early 2012 and August 2017 have helped boost Uruguay’s internet bandwidth, and increase the data rate available to end-users; Uruguay is one of the very few Latin American countries where the local fixed-line market is neither privatized nor liberalized; other segments of the telecom market have been opened to competition, including international long-distance telephony, mobile telephony, and fixed-wireless broadband; Uruguay is also one of the few countries in the world where broadband access via cable modem does not exist; although cable networks are well equipped technologically, and digital cable TV is widely available, telecom legislation prohibits data transmission over pay TV networks; the government announced in December 2020 that it intended to introduce changes to the law to permit pay TV providers to offer internet and telephony packages over their own networks; all three operators offer mobile broadband through 3G and LTE networks; operators have achieved nationwide 3G coverage and the number of mobile broadband subscribers continues to grow; at the end of 2019, spectrum in the 5G-suitable range was auctioned, enabling operators to launch 5G services; the regulator is working on a spectrum and connectivity policy that emphasizes 5G (2021)
domestic:
fixed-line is 36 per 100 and mobile-cellular teledensity 140 per 100 persons (2021)
international:
country code - 598; landing points for the Unisor, Tannat, and Bicentenario submarine cable system providing direct connectivity to Brazil and Argentina; Bicentenario 2012 and Tannat 2017 cables helped end-users with Internet bandwidth; satellite earth stations - 2 Intelsat (Atlantic Ocean) (2020)
Broadcast media:
mixture of privately owned and state-run broadcast media; more than 100 commercial radio stations and about 20 TV channels; cable TV is available; many community radio and TV stations; adopted the hybrid Japanese/Brazilian HDTV standard (ISDB-T) in December 2010 (2019)
Internet country code:
.uy
Internet users:
total:
3.06 million (2021 est.)
percent of population:
90% (2021 est.)
comparison ranking:
total 118
Broadband - fixed subscriptions:
total:
1,063,701 (2020 est.)
subscriptions per 100 inhabitants:
31 (2020 est.)
comparison ranking:
total 71','40b31d87519ec3a3d937a1399120bcc67cced8d7caddf8c854466b6b9b4054e7','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6ce556fbeda095abb5364f60a20e5c71a3a35ff0bc5d8c2151857a160710f8f0',2025,'UZ','Uzbekistan','communications',41,'Telephones - fixed lines:
total subscriptions:
3,470,097 (2021 est.)
subscriptions per 100 inhabitants:
17 (2021 est.)
comparison ranking:
total subscriptions 36
Telephones - mobile cellular:
total subscriptions:
35 million (2021 est.)
subscriptions per 100 inhabitants:
100 (2021 est.)
comparison ranking:
total subscriptions 43
Telecommunication systems:
general assessment:
Uzbekistan’s telecom markets both wireline and wireless have been playing “catch up” in terms of their development following the country’s independence from the former Soviet Union; the government has formally adopted the principles of operating as a market economy, many elements of the old centrally planned economic model remain; this has had the effect of reducing the level of interest from foreign companies and investors in building out the necessary underlying infrastructure, which in turn has constrained the rate of growth in the country’s telecoms sector; the last five years has seen an upswing in prospects for the sector as fiber network roll outs continue beyond the main urban centers, while the mobile market experiences some consolidation for stronger, more efficient competitors; growth is present in the fixed broadband segment with penetration projected to reach 24% by 2027 (a 5-year CAGR of 6.2%); despite the promising signs in the fixed markets, it is the mobile segment that continues to dominate Uzbekistan’s telecoms sector in terms of penetration, revenue, and growth; there are four major operators providing a modicum of competition; three of the four are government owned entities; the mobile market is expected to reach 100% penetration in 2023 a 50% increase in the last five years (2022)
domestic:
fixed-line nearly 17 per 100 persons and mobile-cellular teledensity of 100 per 100 persons (2021)
international:
country code - 998; linked by fiber-optic cable or microwave radio relay with CIS member states and to other countries by leased connection via the Moscow international gateway switch; the country also has a link to the Trans-Asia-Europe (TAE) fiber-optic cable; Uzbekistan has supported the national fiber-optic backbone project of Afghanistan since 2008
Broadcast media:
the government controls media; 17 state-owned broadcasters - 13 TV and 4 radio - provide service to virtually the entire country; about 20 privately owned TV stations, overseen by local officials, broadcast to local markets; privately owned TV stations are required to lease transmitters from the government-owned Republic TV and Radio Industry Corporation; in 2019, the Uzbek Agency for Press and Information was reorganized into the Agency of Information and Mass Communications and became part of the Uzbek Presidential Administration (2019)
Internet country code:
.uz
Internet users:
total:
26.18 million (2021 est.)
percent of population:
77% (2021 est.)
comparison ranking:
total 34
Broadband - fixed subscriptions:
total:
4,820,009 (2020 est.)
subscriptions per 100 inhabitants:
14 (2020 est.)
comparison ranking:
total 33','a2beefe01b6370a771989931e96ec32d91c78602f71f62a8ce98ea8fa2ba37f5','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ac79ecc892a487eac1a725cfbc60a0096612445592a115c3b0483ccf9b4c5a21',2025,'VU','Vanuatu','communications',8,'Telephones - fixed lines:
total subscriptions:
3,600 (2021 est.)
subscriptions per 100 inhabitants:
1 (2021 est.)
comparison ranking:
total subscriptions 210
Telephones - mobile cellular:
total subscriptions:
250,000 (2021 est.)
subscriptions per 100 inhabitants:
78 (2021 est.)
comparison ranking:
total subscriptions 182
Telecommunication systems:
general assessment:
for many years, 2G Global System for Mobile Communications was the primary mobile technology for Vanuatu’s 300,000 people; recent infrastructure projects have improved access technologies, with a transition to 3G and, to a limited degree, to LTE; Vanuatu has also benefited from the ICN1 submarine cable and the launch of the Kacific-1 satellite, both of which have considerably improved access to telecom services in recent years; Vanuatu’s telecom sector is liberalized, with the two prominent mobile operators; while fixed broadband penetration remains low, the incumbent operator is slowly exchanging copper fixed-lines for fiber; a number of ongoing submarine cable developments will also assist in increasing data rates and reduce internet pricing in coming years (2021)
domestic:
fixed-line teledensity is 1 per 100 and mobile-cellular 78 per 100 (2021)
international:
country code - 678; landing points for the ICN1 & ICN2 submarine cables providing connectivity to the Solomon Islands and Fiji; cables helped end-users with Internet bandwidth; satellite earth station - 1 Intelsat (Pacific Ocean) (2020)
Broadcast media:
1 state-owned TV station; multi-channel pay TV is available; state-owned Radio Vanuatu operates 2 radio stations; 2 privately owned radio broadcasters; programming from multiple international broadcasters is available
Internet country code:
.vu
Internet users:
total:
211,200 (2021 est.)
percent of population:
66% (2021 est.)
comparison ranking:
total 181
Broadband - fixed subscriptions:
total:
2,785 (2020 est.)
subscriptions per 100 inhabitants:
1 (2020 est.)
comparison ranking:
total 194','cea66bff4442ecf3c128d5df9226f26e50e61e4f8ea3bf3844fe1dba8f2a88e7','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('df7459f88664331003d3b9e9d6d84662a54672ae5168ec7e9b626f92f6f5990f',2025,'VU','Vanuatu','communications',19,'Telephones - fixed lines:
total subscriptions:
3.2 million (2021 est.)
subscriptions per 100 inhabitants:
11 (2021 est.)
comparison ranking:
total subscriptions 38
Telephones - mobile cellular:
total subscriptions:
17 million (2021 est.)
subscriptions per 100 inhabitants:
60 (2021 est.)
comparison ranking:
total subscriptions 64
Telecommunication systems:
general assessment:
Venezuela’s fixed-line teledensity was relatively high for the region before the steady growth in the number of lines came to an end in 2015; since then, the number of lines has plummeted, and by late 2021 teledensity had fallen to about 17.3%; the cause is largely linked to the country’s ongoing economic troubles, which have compelled many people to terminate fixed-line telecom services and others still to flee the country; these pressures have also distorted sector revenue and have placed into disarray operators’ investment plans aimed at improving networks and expanding the reach and capabilities of new technologies and services; the fixed broadband penetration rate is lower than the regional average, while data speeds are also relatively low; there is no effective competition in the provision of DSL, and as a result the state-owned incumbent CANTV has had little incentive to improve services from its meager revenue streams; mobile penetration in Venezuela is also below the regional average; the number of mobile subscribers fell by an estimated 2.4% in 2020, year-on-year, as subscribers terminated services in a bid to reduce discretionary spending, this decline is expected to continue into 2022, with subscriber growth not returning until 2023 (2021)
domestic:
fixed-line is 11 per 100 and mobile-cellular telephone subscribership is 60 per 100 persons (2021)
international:
country code - 58; landing points for the Venezuela Festoon, ARCOS, PAN-AM, SAC, GlobeNet, ALBA-1 and Americas II submarine cable system providing connectivity to the Caribbean, Central and South America, and US; satellite earth stations - 1 Intelsat (Atlantic Ocean) and 1 PanAmSat (2020)
Broadcast media:
Venezuela has a mixture of state-run and private broadcast media that are subject to high levels of regime control, including the shuttering of opposition-leaning media outlets; 13 public service networks, 61 privately owned TV networks, a privately owned news channel with limited national coverage, and a regime-backed Pan-American channel; 3 regimerun radio networks officially control roughly 65 news stations and another 30 stations targeted at specific audiences; regime-sponsored community broadcasters include 235 radio stations and 44 TV stations; the number of private broadcast radio stations has been declining, but many still remain in operation (2021)
Internet country code:
.ve
Internet users:
total:
22,734,162 (2022 est.)
percent of population:
78.7% (2022 est.)
comparison ranking:
total 38
Broadband - fixed subscriptions:
total:
2,561,556 (2020 est.)
subscriptions per 100 inhabitants:
9 (2020 est.)
comparison ranking:
total 52','456effc9684adcc79d9e86fa4bfd65cb7266afbb92220e4cee7a52090baca8bb','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('caba97406744d85abb972c4c1bab55ea80ab92827aa26f68de3693b065aa0935',2025,'VU','Vanuatu','communications',32,'Telephones - fixed lines:
total subscriptions:
3.1 million (2021 est.)
subscriptions per 100 inhabitants:
3 (2021 est.)
comparison ranking:
total subscriptions 39
Telephones - mobile cellular:
total subscriptions:
140 million (2021 est.)
subscriptions per 100 inhabitants:
140 (2021 est.)
comparison ranking:
total subscriptions 12
Telecommunication systems:
general assessment:
even with Covid-19 pandemic-related mobility restrictions in place, Vietnam’s economy has continued to outperform the rest of the region in 2020 and 2021; the telecom sector essentially spent most of this period in a holding pattern, focusing on maintaining service throughout the crisis while preparing for some major changes to come in the mobile market in 2022; both fixed-line telephony and mobile have experienced small drops in subscriber numbers since the start of the pandemic, but the similarities between the two markets end there; fixed-line teledensity continued its downwards trajectory towards virtual oblivion, with just 3% penetration (around 3 million subscribers) at the start of 2021; the mobile market has lost about the same number of subscribers since the end of 2019, but has been sitting on much higher penetration levels around 130% for many years; growth is expected to kick in again in 2022 following the anticipated launch of commercial 5G mobile services along with a range of government-led schemes to move consumers completely off 2G and 3G; one example is the planned redistribution of GSM/3G bandwidth to LTE; in addition to propelling Vietnam into having one of the most advanced mobile markets in the world, this should also spur on the mobile broadband segment; with a penetration level of just over 70%, mobile broadband has considerable room to grow; increasing economic prosperity coupled with the latest smartphone technology and networks should see mobile broadband underwriting the country’s telecommunications sector for at least the next few years; this report includes the regulator’s market data to July 2021, telcos’ financial and operating data updates to June 2021, Telecom Maturity Index charts and analyses, assessment of the global impact of Covid-19 on the telecoms sector, and other recent market developments (2021)
domestic:
fixed-line is 3 per 100 and mobile-cellular is 140 per 100 (2021)
international:
country code - 84; landing points for the SeaMeWe-3, APG, SJC2, AAE-1, AAG and the TGN-IA submarine cable system providing connectivity to Europe, Africa, the Middle East, Asia, Southeast Asia, Australia, and the US; satellite earth stations - 2 Intersputnik (Indian Ocean region) (2020)
Broadcast media:
government controls all broadcast media exercising oversight through the Ministry of Information and Communication (MIC); government-controlled national TV provider, Vietnam Television (VTV), operates a network of several channels with regional broadcasting centers; programming is relayed nationwide via a network of provincial and municipal TV stations; law limits access to satellite TV but many households are able to access foreign programming via home satellite equipment; government-controlled Voice of Vietnam, the national radio broadcaster, broadcasts on several channels and is repeated on AM, FM, and shortwave stations throughout Vietnam (2018)
Internet country code:
.vn
Internet users:
total:
71.78 million (2021 est.)
percent of population:
74% (2021 est.)
comparison ranking:
total 12
Broadband - fixed subscriptions:
total:
16,699,249 (2020 est.)
subscriptions per 100 inhabitants:
17 (2020 est.)
comparison ranking:
total 14','04729499648d27b995bd00a479d0a9dede34a36c3efdaacc9a05de3ca373b86e','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8697fe4d4382a54222b05367332f0230b713d8dc25102fd2989ed763acc2c72e',2025,'VU','Vanuatu','communications',44,'Telephones - fixed lines:
total subscriptions:
76,000 (2021 est.)
subscriptions per 100 inhabitants:
76 (2021 est.)
comparison ranking:
total subscriptions 143
Telephones - mobile cellular:
total subscriptions:
80,000 (2021 est.)
subscriptions per 100 inhabitants:
80 (2021 est.)
comparison ranking:
total subscriptions 195
Telecommunication systems:
general assessment:
modern system with total digital switching, uses fiber-optic cable and microwave radio relay; good interisland and international connections; broadband access; expansion of FttP (Fiber to the Home) markets; LTE launches; regulatory development and expansion in several markets point to investment and focus on data (2020)
domestic:
fixed-line 76 per 100 persons, with mobile-cellular 80 per 100 (2021)
international:
country code - 1-340; landing points for the BSCS, St Thomas-ST Croix System, Southern Caribbean Fiber, Americas II, GCN, MAC, PAN-AM and SAC submarine cable connections to US, the Caribbean, Central and South America; satellite earth stations - NA (2020)
Broadcast media:
about a dozen TV broadcast stations including 1 public TV station; multi-channel cable and satellite TV services are available; 24 radio stations
Internet country code:
.vi
Internet users:
total:
67,508 (2022 est.)
percent of population:
64.8% (2022 est.)
comparison ranking:
total 196','ee66b146582041b937d5639cabcc453aabf6983db78f2cee06d5e2a50e1803f8','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('607787678ead525a5796c191fdebd10a5d80105cb07cb0a54d88ef46aeba17f5',2025,'WF','Wallis and Futuna','communications',8,'Telephones - fixed lines:
total subscriptions:
3,000 (2021 est.)
subscriptions per 100 inhabitants:
26 (2021 est.)
comparison ranking:
total subscriptions 211
Telephones - mobile cellular:
total subscriptions:
0 (2018)
subscriptions per 100 inhabitants:
0 (2019)
comparison ranking:
total subscriptions 225
Telecommunication systems:
general assessment:
2G widespread; bandwidth is limited; mobile subscriber numbers are higher than fixed-line and better suited for islands; good mobile coverage in the capital cities and also reasonable coverage across more remote atolls; recent international interest in infrastructure development; increase in demand for mobile broadband as mobile services serve as primary source for Internet access; broadband satellite launched in 2019 to improve costs and capability (2020)
domestic:
fixed-line teledensity 26 per 100 persons (2021)
international:
country code - 681; landing point for the Tui-Samoa submarine cable network connecting Wallis & Futuna, Samoa and Fiji (2020)
Broadcast media:
the publicly owned French Overseas Network (RFO), which broadcasts to France’s overseas departments, collectivities, and territories, is carried on the RFO Wallis and Fortuna TV and radio stations (2019)
Internet country code:
.wf
Internet users:
total:
5,496 (2021 est.)
percent of population:
45.8% (2021 est.)
comparison ranking:
total 222','1579853e19b2e451d002cc46783bf2303e6b1bc018f264d8410079e6dcb52a52','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('49c9b2045a11f15e8e65aa5e18f81eedb7c08258fa9ef4af1b22ec1a6926c600',2025,'WF','Wallis and Futuna','communications',19,'Telephones - fixed lines:
total subscriptions:
485,829 (2021 est.)
subscriptions per 100 inhabitants:
9 (2021 est.)
note:
includes Gaza Strip
comparison ranking:
total subscriptions 93
Telephones - mobile cellular:
total subscriptions:
4,052,966 (2021 est.)
subscriptions per 100 inhabitants:
78 (2021 est.)
note:
includes Gaza Strip
comparison ranking:
total subscriptions 131
Telecommunication systems:
general assessment:
most telecommunications companies in the West Bank and Gaza import directly from international vendors; the major challenge they face are Israeli restrictions on telecommunication imports that are listed as “Dual Use” products; during a visit to the West Bank in July 2022, U.S. President Joe Biden announced that Israeli and Palestinian teams will work together immediately to roll out an advanced infrastructure for 4G by the end of 2023; currently, only 2G service is available in Gaza (2022)
domestic:
fixed-line 9 per 100 and mobile-cellular subscriptions 78 per 100 (includes Gaza Strip) (2021)
international:
country code 970 or 972; 1 international switch in Ramallah
Broadcast media:
the Palestinian Authority operates 1 TV and 1 radio station; about 20 private TV and 40 radio stations; both Jordanian TV and satellite TV are accessible
Internet country code:
.ps;
note
- IANA has designated .ps for the West Bank, same as Gaza Strip
Internet users:
total:
3,938,199 (2021 est.)
percent of population:
80% (2021 est.)
note:
includes the Gaza Strip
comparison ranking:
total 111
Broadband - fixed subscriptions:
total:
373,050 (2020 est.)
subscriptions per 100 inhabitants:
7 (2020 est.)
note:
includes the Gaza Strip
comparison ranking:
total 102','7f9590e7cd2ee1d1cbf6e3f6128fee324e14c76fc98d09fe74783f467baf0903','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2e440c35144466bc55dc5cbe9fa6bb48f85d6ba0db7a479baa8aa9fd50f09be6',2025,'WF','Wallis and Futuna','communications',33,'Telephones - fixed lines:
total subscriptions:
901,317,598 (2020 est.)
subscriptions per 100 inhabitants:
11 (2021 est.)
Telephones - mobile cellular:
total subscriptions:
8.06 billion (2021 est.)
subscriptions per 100 inhabitants:
110 (2021 est.)
Telecommunication systems:
general assessment:
Information, Communications, and Technology (ICT) is tied to economic growth; business, trade, and foreign direct investment are all based on effective sources of ICT, and development of ICT flourishes with a vigorous economy, open trade, and sound regulation; some 2020 estimates point to a digital economy worth $11.5 trillion globally, equivalent to 15.5% of global GDP (with ICT growing 2.5 times faster than global GDP over the past 15 years); 2020 reports indicate about 7.7 billion global mobile broadband subscriptions, rising from 3.3 billion in five years, and over 1.1 billion fixed broadband subscribers, up from 830 million in 2015
international: economic impact
- telecommunications has been and continues to be one of the world’s fastest growing markets; countries and firms are transitioning from analog to digital broadcasting, increasing automation capabilities and applications, adopting more high-definition technologies, and converting to digital channels
broadcasting typically refers to transmission of information to all devices in a network without any acknowledgment by the receivers; data processing parts and accessories includes many supporting elements to broadcasting equipment, such as monitors, keyboards, printers, etc.
in terms of market size, broadcasting equipment constituted $413 billion in global trade, making it the fifth most traded commodity in 2019; similarly, data processing equipment equaled $230 billion, the eighth most traded commodity globally; the chief exporters and importers of telecommunications commodities remain largely the same:
1) China leads in both broadcasting and data processing equipment exports, $208 billion and $81.5 billion respectively and 2) the United States, conversely, receives the most of both commodities, importing $81.1 billion in broadcasting equipment and $38.3 billion in data processing equipment in 2019
infrastructure
- as of 2021, 428 submarine cables have been laid worldwide with a further 36 planned; the undersea cables connect to 1,245 landing stations
Internet users:
total:
5.3 billion (2022 est.)
percent of population:
66% (2022 est.)
top ten countries by Internet usage (in millions):
854 China; 560 India; 293 United States; 171 Indonesia; 149 Brazil; 123 Nigeria; 119 Japan; 116 Russia; 96 Bangladesh; 88 Mexico (2023)
Broadband - fixed subscriptions:
total:
1.23 billion (2020 est.) the number of fixed broadband subscriptions has been higher than that of fixed telephony since 2017
subscriptions per 100 inhabitants:
17 (2021 est.)
Communications - note:
note 1:
the development of formal postal systems may be traced back thousands of years; the earliest documented organized courier service for the dissemination of written dispatches was set up by the pharaohs of Ancient Egypt (ca. 2400 B.C.); the invention of a true postal system organized for delivery of post to citizens, is credited to Ancient Persia (6th century B.C.); other credible early postal services are those of Ancient India (Mauryan Empire; 4th century B.C.) and Ancient China (Han Dynasty; 3rd century B.C.)
note 2:
data centers consist of a dedicated space within a building or a group of buildings used to house computing resources and other components, such as telecommunications and storage systems; the ongoing worldwide boom in data generation is responsible for the mushrooming of data centers; the three largest data center facilities by area as of the first half of 2022 are:
no. 1.
- the China Telecom data center located in the Inner Mongolia Information Park, Hohhot, China, reportedly covers 1 million sq m (10.7 million sq ft); the largest Internet data center in the World, it has over 50% market share in the Chinese data center market, with an extensive network of over 400 data centers located in prime regions in mainland China and overseas markets
no. 2.
- the China Mobile data center located in the Inner Mongolia Information Park, Hohhot, China, covers 720,000 sq m (7.7 million sq ft); it is one of the World’s biggest cloud computing data centers
no. 3.
- The Citadel data center owned by US-based Switch, in Tahoe Reno, Nevada, covers 670,000 sq m (7.2 million sq ft); called the World’s largest technology ecosystem, the facility runs on 100% renewable (solar and wind) energy (2021)','b43f7f1b039e7567e92a0b4373f8d3d2b18599b83061584d1541d10617394565','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6c33871e84aca8e1d1cb0e53a90e09ae8faf600c3888a6e990c286d3da59c839',2025,'YE','Yemen','communications',8,'Telephones - fixed lines:
total subscriptions:
1.2 million (2021 est.)
subscriptions per 100 inhabitants:
4 (2021 est.)
comparison ranking:
total subscriptions 69
Telephones - mobile cellular:
total subscriptions:
15 million (2021 est.)
subscriptions per 100 inhabitants:
46 (2021 est.)
comparison ranking:
total subscriptions 71
Telecommunication systems:
general assessment:
Yemen continues to provide an exceptionally challenging market for telcos; civil unrest has caused havoc and devastation across most parts of the country, while the threat of sanctions has also made it a challenging environment in which to operate; a large proportion of the population requires humanitarian assistance, and there is little disposable income for services upon which telcos can generate revenue; essential telecom infrastructure, such as mobile towers and fiber cabling, has often been targeted, destroyed, or damaged by the opposing sides in the ongoing conflict; these difficulties have proved to be a disincentive to telcos investing in infrastructure, with the result that the country lacks basic fixed-line infrastructure, and mobile services are based on outdated GSM; this has prevented the development of a mobile broadband sector, or the evolution of mobile data services; the ownership of telecommunication services, and the scrutiny of associated revenues and taxes, have become a political issue in Yemen; until telecom infrastructure can be improved across Yemen, and until civil unrest eases, there will be little progress for the sector (2022)
domestic:
fixed-line teledensity is 4 per 100 but mobile cellular is 46 per 100 (2021)
international:
country code - 967; landing points for the FALCON, SeaMeWe-5, Aden-Djibouti, and the AAE-1 international submarine cable connecting Europe, Africa, the Middle East, Asia and Southeast Asia; satellite earth stations - 3 Intelsat (2 Indian Ocean and 1 Atlantic Ocean), 1 Intersputnik (Atlantic Ocean region), and 2 Arabsat; microwave radio relay to Saudi Arabia and Djibouti (2020)
Broadcast media:
state-run TV with 2 stations; state-run radio with 2 national radio stations and 5 local stations; stations from Oman and Saudi Arabia can be accessed
Internet country code:
.ye
Internet users:
total:
8,229,624 (2022 est.)
percent of population:
26.6% (2022 est.)
comparison ranking:
total 73
Broadband - fixed subscriptions:
total:
391,000 (2020 est.)
subscriptions per 100 inhabitants:
1 (2020 est.)
comparison ranking:
total 98','4b4e1f1a5719e17185bd9578cc054c4ff9d75166a2a6eb120b054eba70f4eddc','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1cae9ed202b337bef26dd5fe6af5379ba0057373aaae38a9f13cabc4c67f38c5',2025,'ZM','Zambia','communications',8,'Telephones - fixed lines:
total subscriptions:
66,000 (2021 est.)
subscriptions per 100 inhabitants:
(2021 est.) less than 1
comparison ranking:
total subscriptions 146
Telephones - mobile cellular:
total subscriptions:
20 million (2021 est.)
subscriptions per 100 inhabitants:
100 (2021 est.)
comparison ranking:
total subscriptions 60
Telecommunication systems:
general assessment:
following elections held in August 2021, the new government immediately established a Ministry of Technology and Science to promote the use of ICT in developing economic growth and social inclusion; this focus on ICT, and on telecoms in particular, has been central to government strategies for some years; as part of the Smart Zambia initiative, investment has been made in data centers, a computer assembly plant, ICT training centers, and a Smart Education program; these efforts have been combined with the extension of broadband access and improved connectivity to international submarine cables; in turn, this has resulted in a considerable reduction in fixed-line and mobile access pricing for end-users; mobile network operators continue to invest in 3G and LTE-based services, the government contracted to upgrade the state-owned mobile infrastructure for 5G services; delays in holding spectrum have stymied the development of 5G thus far; in mid-2021 the regulator completed a consultation of auctioning low, medium, and high band spectrum for 5G, aiming to provide sufficient spectrum to meet the anticipated increase in data traffic in coming years; fixed-line broadband services remain underdeveloped (2022)
domestic:
fixed-line teledensity less than 1 per 100 and mobile-cellular is 100 per 100 (2021)
international:
country code - 260; multiple providers operate overland fiber optic routes via Zimbabwe/South Africa, Botswana/Namibia and Tanzania provide access to the major undersea cables
Broadcast media:
according to the Independent Broadcast Authority, there are 137 radio stations and 47 television stations in Zambia; out of the 137 radio stations, 133 are private (categorized as either commercial or community radio stations), while 4 are public-owned; state-owned Zambia National Broadcasting Corporation (ZNBC) operates 2 television channels and 3 radio stations; ZNBC owns 75% shares in GoTV, 40% in MultiChoice, and 40% in TopStar Communications Company, all of which operate in-country (2019)
Internet country code:
.zm
Internet users:
total:
3.99 million (2021 est.)
percent of population:
21% (2021 est.)
comparison ranking:
total 109
Broadband - fixed subscriptions:
total:
82,317 (2020 est.)
subscriptions per 100 inhabitants:
0.5 (2020 est.)
comparison ranking:
total 131','d9b26e12ed0cd018fb1f45ff0108d212d317e669650db56111b5d677811718e3','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1294e35336390b8b60ddcccff655be42e25fa2d6c5c1c7be19a5c72bb928dd9a',2025,'ZW','Zimbabwe','communications',19,'Telephones - fixed lines:
total subscriptions:
243,421 (2021 est.)
subscriptions per 100 inhabitants:
2 (2021 est.)
comparison ranking:
total subscriptions 118
Telephones - mobile cellular:
total subscriptions:
14,257,590 (2021 est.)
subscriptions per 100 inhabitants:
89 (2021 est.)
comparison ranking:
total subscriptions 72
Telecommunication systems:
general assessment:
Zimbabwe’s telcos continue to be affected by the country’s poor economy; this has been exacerbated by the significant economic difficulties related to the pandemic; revenue has also been under pressure from a number of recent regulatory measures and additional taxes imposed by the cash-strapped government; inflation has become so high that year-on-year revenue comparisons since 2019 have been difficult to assess meaningfully; the three MNOs continue to invest in network upgrades, partly supported by government efforts and cash released from the Universal Service Fund; as a result of these investments, LTE networks have expanded steadily, though services remain concentrated in urban areas; international bandwidth has improved since fiber links to several submarine cables were established via neighboring countries; the expansion of 3G and LTE-based mobile broadband services has meant that most of the population has access to the internet; the government has started a national broadband scheme aimed at delivering a 1Mb/s service nationally by 2030; investment in fixed broadband infrastructure has also resulted in a slow but steady growth in the number of DSL connections, and also fiber subscriptions; during 2021, most growth in the fixed broadband segment has been with fiber connections (2022)
domestic:
fixed-line teledensity is 2 per 100 and mobile-cellular is 89 per 100 (2021)
international:
country code - 263; fiber-optic connections to neighboring states provide access to international networks via undersea cable; satellite earth stations - 2 Intelsat; 5 international digital gateway exchanges
Broadcast media:
government owns all local radio and TV stations; foreign shortwave broadcasts and satellite TV are available to those who can afford antennas and receivers; in rural areas, access to TV broadcasts is extremely limited; analog TV only, no digital service (2017)
Internet country code:
.zw
Internet users:
total:
5.6 million (2021 est.)
percent of population:
35% (2021 est.)
comparison ranking:
total 84
Broadband - fixed subscriptions:
total:
203,461 (2020 est.)
subscriptions per 100 inhabitants:
1 (2020 est.)
comparison ranking:
total 120','7e29f2684903bde1d2dd3bb68fc9b64f7fe7d951fec08057a5a93101fb0562db','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);

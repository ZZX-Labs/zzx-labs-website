SET NAMES utf8mb4;
CREATE TABLE IF NOT EXISTS worldfactbook_chunks (
  chunk_id CHAR(64) NOT NULL,
  edition_year SMALLINT UNSIGNED NOT NULL,
  entity_code VARCHAR(24) NOT NULL DEFAULT '',
  entity_name VARCHAR(160) NOT NULL DEFAULT '',
  category VARCHAR(96) NOT NULL,
  ordinal INT UNSIGNED NOT NULL,
  content MEDIUMTEXT NOT NULL,
  content_sha256 CHAR(64) NOT NULL,
  source_provider VARCHAR(64) NOT NULL,
  source_identifier VARCHAR(255) NOT NULL,
  source_format VARCHAR(32) NOT NULL,
  source_sha256 CHAR(64) NOT NULL,
  source_url TEXT NOT NULL,
  extractor VARCHAR(64) NOT NULL,
  PRIMARY KEY (chunk_id),
  KEY idx_wfb_year_category (edition_year, category),
  KEY idx_wfb_entity_year (entity_code, edition_year),
  KEY idx_wfb_source_sha (source_sha256)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ea3240826cfb02e4a547a9aa97c038190796cc783d983f6071242101d5c10f9e',2025,'ZW','Zimbabwe','communications',19,'Telephones—main lines in use
Telephones—mobile cellular
Telephone system
general assessment
domestic
international
Broadcast media
Internet country code
Internet hosts
Internet users
. Communications—note
Telephones—main lines in use: 356,000(2011)
country comparison to the world: 109
Telephones—mobile celular: 9.2 million
(2011)
country comparison to the world: 81
Telephone system: general assessment: system
was once one of the best in Africa, but now suffers
from poor maintenance
domestic: consists of microwave radio relay links,
open-wire lines, radiotelephone communication
stations, fixed wireless local loop installations,
and a substantial mobile-cellular network; Inter-
net connection is available in Harare and planned
for all major towns and for some of the smaller
ones
international: country code—263; satellite earth
stations—2 Intelsat; 2 international digital gate-
way exchanges (in Harare and Gweru) (2010)
Broadcast media: government owns all local
radio and TV stations; foreign short wave broad-
casts and satellite TV are available to those who
can afford antennas and receivers; in rural areas,
access to TV broadcasts is extremely limited
(2007)
internet country code: .zw
internet hosts: 30,615(2012)
country comparison to the world: 108
Internet users: 1.423 million (2009)
country comparison to the world: 84','ad19d8eb6ece494e715aa62577265f1f59043aa10d48b29d09a07fbb3aade991','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('058d2781951d63a39d732a1e0947c0f4ec90cc9783777f1f602e593f7b7517d9',2025,'AF','Afghanistan','communications',29,'Telephones—main lines in use: 13,500 (2011)
country comparison to the world: 199
Telephones—mobile cellular: 17.558 million
(2011)
country comparison to the world: 50
Telephone system: general assessment: limited
fixed-line telephone service; an increasing number
of Afghans utilize mobile-cellular phone networks
domestic: aided by the presence of multiple pro-
viders, mobile-cellular telephone service contin-
ues to improverapidly; the Afghan Ministry of
Communications and Information claims that
more than 90 percent of the population live in
areas with access to mobile-cellular services
international: country code—93; multiple
VSAT’s provide international and domestic voice
and data connectivity (2012)
Broadcast media: state-owned broadcaster,
Radio Television Afghanistan (RTA), operates a
series of radio and television stations in Kabul and
the provinces; an estimated 150 private radio sta-
tions, 50 TV stations, and about a dozen interna-
tional broadcasters are available (2007)
Internet country code: .af
Internet hosts: 223 (2012)
country comparison to the world: 200
Internet users: 1 million (2009)
country comparison to the world: 101
Communications—note: Internet access is grow-
ing through Internet cafes as well as public “teleki-
osks” in Kabul (2005)','4726ea4599e7ea5c2029c9709672b52ca6c61e6b87f25fe5687b0ea7b07db22c','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ef94b1c35d29dfef0fc459d7a2add470d3cbd512c9964e7b6e388de1b8f57c78',2025,'CY','Cyprus','communications',37,'Broadcast media: British Forces Broadcast Ser-
vice (BFBS) provides multi-channel satellite TV
service as well as BFBS radio broadcasts to the
Akrotiri Sovereign Base (2009)
Military—note: defense is the responsibility of the
UK; Akrotiri has a full RAF base, Headquarters for
British Forces Cyprus, and Episkopi Support Unit
Telephones—main lines in use: 405,000 (2011)
country comparison to the world: 105
Telephones—mobile cellular: 1.09 million
(2011)
country comparison to the world: 154
Telephone system: general assessment: excel-
lent in both area under government control and
area administered by Turkish Cypriots
domestic: open-wire, fiber-optic cable, and
microw ave radio relay
international: country code—357 (area admin-
istered by Turkish Cypriots uses the country code
of Turkey—90); a number of submarine cables,
including the SEA-ME-WE-3, combine to pro-
vide connectivity to Western Europe, the Middle
East, and Asia; tropospheric scatter; satellite earth
stations—8 (3 Intelsat—1 Atlantic Ocean and 2
Indian Ocean, 2 Eutelsat, 2 Intersputnik, and 1
Arabsat)
Broadcast media: mixture of state and privately
run‘TV and radio services; the public broadcaster
operates 2 TV channels and 4 radio stations; 6 pri-
vate TV broadcasters, satellite and cable TV ser-
vices including telecasts from Greece and Turkey,
and a number of private radio stations are avail-
able; in areas administered by Turkish Cypriots,
there are 2 public TV stations, 4 public radio sta-
tions, and privately owned TV and radio broadcast
stations (2007)
internet country code: .cy
internet hosts: 252,013 (2012)
country comparison to the world: 67
Internet users: 433,900 (2009)
country comparison to the world: 120','ebe71c5cd36b1153fde8f419ddfedc81a7dfd73d14241153be72de9b5b01566d','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f1ddc5ad3e4286c2bb8f9679ad4fde18141a3c9932d31a54ddb46a12c4db8232',2025,'AL','Albania','communications',38,'ata a e oe Ý ia
She mee
TIRANA -
*
Telephones—main lines in use: 338,800 (2011)
'' country comparison to the world: 111
Telephones—mobile cellular: 3.1
(2011)
country comparison to the world: 127
Telephone system: general assessment: despite
new investment in fixed lines, teledensity remains
million
low with roughly 10 fixed lines per 100 people;
mobile-cellular telephone use is widespread and
generally effective
domestic: offsetting the shortage of fixed line
capacity, mobile-cellulat phone service has been
available since 1996; by 2011 multiple companies
were providing mobile services and mobile tel-
edensity had reached 100 per 100 persons; Internet
broadband services initiated in 2005 but growth
THE CIA WORLD FACTBOOK
has been slow; Internet cafes are popular in Tirana
and have started to spread outside the capital
international: country code—355; submarine
cable provides connectivity to Italy, Croatia, and
Greece; the Trans-Balkan Line, a combination
submarine cable and land fiber-optic system, pro-
vides additional connectivity to Bulgaria, Macedo-
nia, and Turkey; international traffic carried by
fiber-optic cable and; when necessary, by micro-
wave radio relay from the Tirana exchange to Italy
and Greece (2011)
Broadcast media: 3 public TV networks, one
of which transmits by satellite to Albanian-
language communities in neighboring countries;
more than 60 private TV stations; many view-
ers can pick up Italian and Greek TV broadcasts
via terrestrial reception; cable TV service is
available; 2 public radio networks and roughly
25 private radio stations; several international
broadcasters are available (2010)
Internet country code: .al
Internet hosts: 15,528 (2012)
country comparison to the world: 124
Internet users: 1.3 million (2009)
country comparison to the world: 91','d2f6e6fab6f2bbf718248d3ec6b48bb7a0ec4a78d06386f4c1d30d9abff4ac77','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e5224bb7b65aaff5c8a8db4d72ef5d7bcde6b073249c2e75ede21cc92337056b',2025,'DZ','Algeria','communications',52,'Telephones—main lines in use: 3.059 million
(2011)
country comparison to the world: 50
Telephones—mobile cellular: 35.616 million
(2011)
country comparison to the world: 32
Telephone system: general assessment: pn-
vatization of Algena’s celecommunications sec-
tor began in 2000; three mobile cellular licenses
have been issued and, in 2005, a consortum led by
Egypt’s Orascom Telecom won a 15-year license to
build and operate a fixed-line network in Algeria;
the license will allow Orascom to develop high-
speed data and other specialized services and con-
tribute to meeting the large unfulfilled demand for
basic residential telephony; Intemet broadband
services began in 2003
domestic: a limited network of fixed lines with a
teledensity of less than 10 telephones per 100 per-
sons has been offset by the rapid increase in mobile-
cellular subscribership; in 2011, mobilecellular
teledensity was roughly 100 telephones per 100
persons
international: country code—213; landing point
for the SEA-ME-WE-4 fiber-optic submarine
cable system that provides links to Europe, the
11
Middle East, and Asia; microwave radio relay to
Italy, France, Spain, Morocco, and Tunisia; coax-
ial cable to Morocco and Tunisia; participant in
Medarabtel; satellite earth stations—51 (Intelsat,
Interspurnik, and Arabsat) (2009)
Broadcast media: state-run Radio-Television
Algerienne operates the broadcast media and car-
ties programming in Arabic, Berber dialects, and
French; use of satellite dishes is widespread, provid-
ing easy access to European and Arab satellite sta-
tions; state-run radio operates several national net-
works and roughly 40 regional radio stations (2007)
Internet country code: .dz
Internet hosts: 676 (2012)
country comparison to the world: 178
Internet users: 4.7 million (2009)
country comparison to the world: 49
i TRANSPORTATION
Airports: 142 (2012)
country comparison to the world: 41
Airports—with paved runways: total: 60
over 3,047 m: 12
2,438 to 3,047 m: 28
1,524 to 2,437 m: 15
914 to 1,523 m: 4
under 914 m: 1 (2012)
Airports—with unpaved runways: total: 82
2,438 to 3,047 m: 2
1,524 to 2,437 m: 18
914 to 1,523 m: 39
under 914 m: 23 (2012)
Heliports: 3 (2012)
Pipelines: condensate 2,600 km; gas 16,360 km;
liquid petroleum gas 3,447 km; oil 7,611 km;
refined products 144 km (2010)
Railways: total: 3,973 km
country comparison to the world: 44
THE CIA WORLD FACTBOOK
standard gauge: 2,888 km 1.435-m gauge (283 km
electrified)
narrow gauge: 1,080 km 1.055-m gauge (2008)
Roadways: total: 113,655 km
country comparison to the world: 39
paved: 87,605 km (includes 645 km of expressways)
unpaved: 26,050 km (2010)
Merchant marine: total: 38
country comparison to the world: 78
by type: bulk carrier 6, cargo 8, chemical tanker
3, liquefied gas 11, passenger/cargo 3, petroleum
tanker 4, roll on/roll off 3
foreign-owned: 10 (UK, 10) (2010)
Ports and terminals: Algiers, Annaba, Arzew,
Bejaia, Djendjene, Jijel, Mostaganem, Oran,
Skikda','559674230211508290375f445e2f303917bf378e218b06a1f5074a517eb9f999','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c76950e27c79949d66f20b40d01a61fadc6954dd5ecaec5f2f522b6f482a1ef4',2025,'AS','American Samoa','communications',64,'Telephones—main lines in use: 10,400 (2009)
country comparison to the world: 200
Telephone system: general assessment: good
telex, telegraph, facsimile, and cellular telephone
services
domestic: domestic satellite system with 1 Comsat
earth station
international: country code—l-684; satellite
earth station—1 (Intelsat-Pacific Ocean)
Broadcast media: 3 TV stations; multi-channel
pay TV services are available; about a dozen radio
stations, some of which are repeater stations
(2009)
internet country code: .as
Internet hosts: 2,387 (2012)
country comparison to the world: 161
Internet users: NA','1afd7eb37a155d0f107ef7af5dbb7fdbaf48164ae079804419bf379ec99b7c59','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4d3db8922262d79c5aa55163280ca5b4cb3a11b0abaedd9d0316e00279daf084',2025,'AD','Andorra','communications',73,'Telephones—main lines in use: 38,400 (2011)
country comparisan to the world: 169
Telephones—mobile cellular: 65,000 (2011)
country comparison to the world: 197
Telephone system: general assessment: modern
automatic telephone system p
domestic: modem system with microwave radio
relay connections between exchanges
international: country code—376; landline cir-
cuits to France and Spain (2012)
Broadcast media: 1 public TV station and 2
public radio stations; about 10 commercial radio
stations; good reception of radio and TV broad-
casts from stations in France and Spain; upgraded
hold on power. President DOS SANTOS pushed
through a new constitution in 2010; elections held
in 2012 saw him installed as president.','9368e2a1fc2bf1d4094074ac97da4ddc9a6714e4a22f5d54ed4c423844741506','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4a9ae032029ac0e31b09650a18f6abb12ee7dba0d46f4ee494ffcabb9052a9eb',2025,'AO','Angola','communications',77,'Telephones—main lines in use: 303,200 (2011)
country comparison to the world: 115
Telephones—mobile celluiar: 9.491 million
(2011)
country comparison to the world: 78
Telephone system: general assessment: limited
system; state-owned telecom had monopoly for
fixed-lines until 2005; demand outstripped capac-
ity, prices were high, and services poor; Telecom
Namibia, through an Angolan company, became
the first private licensed operator in Angola’s
fixed-line telephone network; by 2010, the number
of fixed-line providers had expanded to 5; Angola
Telecom established mobile-cellular service in
Luanda in 1993 and the network has been extended
to larger towns; a privately owned, mobile-cellular
service provider began operations in 2001
domestic: only about two fixed-lines per 100
persons; mobile-cellular teledensity about 50 tel-
ephones per 100 persons in 2011
international: country code—244; landing
point for the SAT-3/WASC fiber-optic submarine
cable that provides connectivity to Europe and
Asia; satellite earth stations—29 (2009)
Broadcast media: state controls all broadcast
media with nationwide reach; state-owned Tel-
evisao Popular de Angola (TPA) provides terrestrial
TV service on 2 channels; a third TPA channel is
available via cable and satellite; TV subscription ser-
vices are available; state-owned Radio Nacional de
Angola (RNA) broadcasts on 5 stations; about a half
dozen private radio stations broadcast locally (2008)
Internet country code: .ao
Internet hosts: 20,703 (2012)
country comparison to the world: 116
Internet users: 606,700 (2009)
country comparison to the world: 114','f59388a4060d58cb760e448d3a1d0cb23224c69aa24de38203904b817e4a55f5','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0fc90e8da22e8fc4b6524d4e3d28b2beb02133e2ec3fd15d413e90e5ff29438a',2025,'AI','Anguilla','communications',88,'Telephones—main lines in use: 6,200 (2011)
country comparison to the world: 207
Telephones—mobile ceilular: 26,000 (2011)
country comparison tothe world:208
Telephone system: general assessment: modern
internal telephone system
domestic: fixed-line teledensity is roughly 40 per
100 persons; mobile-cellular teledensity is roughly
170 per 100 persons
international: country code—1-264; landing
point for the East Caribbean Fiber System sub-
marine cable with links to 13 other islands in the
eastern Caribbean extending from the British Vir-
gin Islands to Trinidad; microwave radio relay to
island of Saint Martin/Sint Maarten (2011)
Broadcast media: private TV station; multi-
channel cable TV subscription services ate avail-
able; about 10 radio stations, one of which is
government-owned (2007)
Internet country code: .ai
internet hosts: 269 (2012)
country comparison to the world: 193
Internet users: 3,700 (2009)
country comparison to the world: 208','fe00b258834637116a00df117b5d4b8de82b5edb1edc4d91a2d7f49bb649c0a0','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a19efb7ab2e253f3d26c3086adc6813e0e29e8b100046c8b6f7c0da573620a56',2025,'AG','Antigua and Barbuda','communications',105,'Telephones—main lines in use: 35,500 (2011)
country comparison to the world: 172
Telephones—mobile cellular: 176,000 (2011)
country comparison to the world: 182
Telephone system: general assessment: good
automatic telephone system
domestic: fixed-line teledensity roughly 40 per
100 persons; mobile-cellular teledensity is some
200 per 100 persons
international: country code—1l-268; landing
points for the East Caribbean Fiber System (ECFS)
and the Global Caribbean Network (GCN)
submarine cable systems with links to other islands
in the easter Caribbean extending from the
British Virgin Islands to Trinidad; satellite earth
stations—2; tropospheric scatter to Saba (Nether-
lands) and Guadeloupe (France) (2011)
Broadcast media: state-controlled Antigua and
Barbuda Broadcasting Service (ABS) operates 1
TV station; multichannel cable ‘TV subscription
services are available; ABS operates 1 radio sta-
tion; roughly 15 radio stations, some broadcasting
on multiple frequencies (2007)
Internet country code: .ag
Internet hosts: 11,532 (2012)
country comparison to the world: 130
Internet users: 65,000 (2009)
country comparison to the world: 172','8f8a362600a77a62f68a3e2484f911ef97d570803f26d7ac010294ca024a4869','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b6c7a02a8dbf9811ff381cfcb38a19046a8df724e71642b30a9d75f91f23a033',2025,'AR','Argentina','communications',114,'Telephones—main lines in use: 10.14 million
(2011)
country comparison to the world: 22
Telephones—mobile cellular: 55 million (2011)
country comparison to the world: 24
Telephone system: general assessment: in 1998
Argentina opened its telecommunications market
to competition and foreign investment encourag-
ing the growth of modern telecommunications
technology; fiberoptic cable trunk lines are being
installed between all major cities; major networks
are entirely digital and the availability of tel-
ephone service is improving
domestic: microwave radio relay, fiber-optic
cable, and a domestic satellite system with 40 earth
stations serve the trunk network; fixed-line tel-
edensity is increasing gradually and mobilecellular
subscribership is increasing rapidly; broadband
Internet services are gaining ground
international: country code—54; landing point
for the Atlantis-2, UNISUR, South America-l,
and South American Crossing/Latin American
Nautilus submarine cable systems that provide
links to Europe, Africa, South and Central Amer-
ica, and US; satellite earth stations—112; 2 inter-
national gateways near Buenos Aires (2011)
Broadcast media: government owns a TV sta-
tion and a radio network; more than 2 dozen TV
stations and hundreds of privately-owned radio
stations; high rate of cable TV subscription usage
(2007)
Internet country code: .ar
Internet hosts: 11.232 million (2012)
country comparison to the world: 13
Internet users: 13.694 million (2009)
country comparison to the world: 28','269dcff0def008e7541bd67553f4282774f742d817723c32b4b7faedf8489395','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1f2d6825fedc07732bab7b893ba61d81c292857930676d0059d870e5bb5c11f4',2025,'AM','Armenia','communications',121,'Telephones—main lines in uge: 577,500 (2011)
country comparison to the world: 92
Telephones—mobile cellular: 3.211 million
(2011)
. country comparison to the world: 123
Telephone system: general assessment: tel-
ecommunications investments have made major
inroads in modernizing and upgrading the out-
dated telecommunications network inherited
from the Soviet era; now 100% privately owned
and undergoing modernization and expansion;
mobile-cellular services monopoly terminated
in late 2004 and a second provider began opera-
tions in mid-2005
domestic: reliable modern fixed-line and mobile-
cellular services are available across Yerevan
in major cities and towns; significant but ever-
shrinking gaps remain in mobile-cellular coverage
in rural areas
international: country code—374; Yerevan is
connected to the Trans-Asia-Europe fiber-optic
36
THE CIA WORLD FACTBOOK
''
cable through Iran; additional international ser-
vice is available by microw ave radio relay and
landline connections to the other countries of the
Commonwealth of Independent States, through
the Moscow international switch, and by satellite
to the rest of the world; satellite earth stations—3
(2008)
Broadcast media: 2 public TV networks operat-
ing alongside more than 40 privately-owned TV
stations that provide local to near nationwide
'' coverage; major Russian broadcast stations are
widely available; subscription cable TV services
are available in most regions; Public Radio of
Armenia is a national, state-run broadcast net-
work that operates alongside about 20 privately-
owned radio stations; several major international
broadcasters are available (2008)
internet country code: .am
Internet hosts: 194,142 (2012)
country comparison to the world: 73
Internet users: 208,200 (2009)
country comparison to the world: 138','1dcf8a19f074ea0c6674e9c4bc7c99d62192671f0b4d11fd679fce813066cc7d','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('29bf205bf5b48935048b686b3f90cab8f0107272b45d6a171e0a6bf6cb097c5d',2025,'AW','Aruba','communications',131,'Telephones—main tines in use: (2010)
country comparison to the world: 174
Telephones—mobile cellular: 131,800 (2010)
country comparison to the world: 186
Telephone system: general assessment: modern
fully automatic telecommunications system
domestic: increased competition through privati-
zation; 3 mobile-cellular service providers are now
licensed
international: country code—297; landing site for
the PAN-AM submarine telecommunications cable
system that extends from the US Virgin Islands
through Aruba to Venezuela, Colombia, Panama,
and the west coast of South America; extensive
interisland microwave radio relay links (2007)
Broadcast media: commercial TV stations;
cable TV subscription service provides access to
foreign channels; about 20 commercial radio sta-
tions broadcast (2007)
Internet country code: .aw
Internet hosts: 40,560 (2012)
country comparison to the world: 101
Internet users: 24,000 (2009)
country comparison to the world: 188','2837e09af08ef0da79d42c419f71b12d3119f5af1b8a5c1a0c6f99973adf193c','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5ec14aae41b50a699b1a3d9b62205bdb597a64435fe58c1a8fa3534f1f75ab02',2025,'AU','Australia','communications',142,'Telephones—main lines in use: 10.57 million
(2011)
country comparison to the world: 20
Telephones—mobile cellular: 24.49 million
(2011)
country comparison to the world: 43
Telephone system: general assessment: excel-
lent domestic and international service
domestic: domestic satellite system; significant use
of radiotelephone in areas of low population den-
sity; rapid growth of mobile telephones
international: country code—61; landing point
for the SEA-ME-WE-3 optical telecommunications
submarine cable with links to Asia, the Middle East,
and Europe; the Southern Cross fiber optic subma-
rine cable provides links to New Zealand and the
United States; satellite earth stations—10 Intelsat(4
Indian Ocean and 6 Pacific Ocean), 2 Inmarsat, 2
Globalstar, 5 other) (2007)
44
THE CIA WORLD FACTBOOK
Broadcast media: the Australian Broadcasting
Corporation (ABC) runs multiple national and local
radio networks and TV stations, as well as Australia
Network, a TV service that broadcasts through-
out the Asia-Pacific region and is the main public
broadcaster; Special Broadcasting Service (SBS), a
second large public broadcaster, operates radio and
TV networks broadcasting in multiple languages;
several large national commercial TV networks, a
large number of local commercial TV stations, and
hundreds of commercial radio stations are accessible;
cable and satellite systems are available (2008)
Internet country code: .au
Internet hosts: 17.081 million (2012)
country comparison to the world: 8
Internet users: 15.81 million (2009)
country comparison. to the world: 25
and elsew here via satellite; satellite earth sta-
tion—I (Intelsat) (200!)
Broadcast media: 1 local radio station staffed
by community volunteers; satellite broadcasts of
several Australian radio and TV stations available
(2009)
Internet country code: .cc
Internet hosis. 47.820 (2012)
country comparison to the world: 99
159
Communications—note: automatic weather sta-
tions on many of the isles and reefs relay data to
the mainland
Telephone system: general assessment: adequate
domestic: free local calls
international: country code—672; submarine
cable links with Australia and New Zealand; satel-
lite earth station—1
Broadcast media: 1 local radio station; broad-
casts of several Australian radio and TV stations
available via satellite (2009)
Internet country code:.nf
Internet hosts: 128 (2012)
country comparison to the world: 205','5b1c1ffd81a9ffda17049ccb159825b825a1546a3fb1cc2caff32470c0265e17','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c6b9a0a45829896cf2c9e64a0cbcf1f313415c73c52cfaf542c4102f9daab3ac',2025,'AT','Austria','communications',153,'Telephones—main lines in use: 3.388 million
(2011)
48
THE CIA WORLD FACTBOOK
country comparison to the world: 48
Telephones—mobile cellular: 13.023 million
(2011)
country comparison to the world: 60
Telephone system: general assessment: highly
developed and efficient
domestic: fixed-line subscribership has been
in decline since the mid-1990s with mobile-
cellular subscribership eclipsing it by the late
1990s; the fiber-optic net is very extensive; all
telephone applications and Internet services are
available
international: country code—43; satellite earth
stations—15; in addition, there are about 600
VSATs (very small aperture terminals) (2007)
Broadcast media: Austria''s public broadcaster,
Osterreichischer Rundfunk (ORF), was the main
broadcast source until commercial radio and TV
service was introduced in the 1990s; cable and
satellite TV are available, including German TV
stations (2008)
Internet country code: .at
Internet hosts: 3.512 million (2012)
country comparison to the world: 30
Internet users: 6.143 million (2009)
country comparison to the world: 43
Telephones—main lines in use: 2.289 million
(2011)
country comparison to the world: 55
Telephones—mobile cellular: 13 million (2011)
country comparison to the world: 61
Telephone system: general assessment: privati-
zation and modernization of the Czech telecom-
munication system got a late start but is advanc-
ing steadily; virtually all exchanges now digital;
existing copper subscriber systems enhanced with
Asymmetric Digital Subscriber Line (ADSL)
equipment to accommodate Internet and other
digital signals; trunk systems include fiber-optic
cable and microw ave radio relay
domestic: access to the fixed-line telephone net-
work expanded throughout the 1990s but the
number of fixed line connections has been drop-
ping since then; mobile telephone usage increased
sharply beginning in the mid-1990s and the num-
ber of cellular telephone subscriptions now greatly
exceeds the population
international: country code—420; satellite earth
stations—6 (2 Intersputnik—aAtlantic and Indian
Ocean regions, 1 Intelsat, 1 Eutelsat, 1 Inmarsat, 1
Globalstar) (2011)
Broadcast media: roughly 130 TV broadcast-
ers operating some 350 channels with 4 publicly
operated and the remainder in private hands; 16
TV stations have national coverage with 4 being
publicly operated; cable and satellite TV subscrip-
tion services are available; 63 radio broadcasters
are registered operating roughly 80 radio stations
with 15 stations publicly operated; 10 radio sta-
tions provide national coverage with the remain-
der local or regional (2008)
Interne? country code: .cz
Internet hosts: 4.148 million (2012)
country comparison to the world: 27
Internet users: 6.681 million (2009)
country comparison to the world: 40','ab57d1b99909e17249607c0490260e86cf1ad415954e0852c83feaeea8460254','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('85dff1330cbf8efe47ea0785574c2c3d6643084afede43c0448d2fc6f26224a2',2025,'AZ','Azerbaijan','communications',161,'Telephones—main lines in use: 1.684 million
(2011)
country comparison to the world: 64
Telephones—mobile cellular: million (2011)
country comparison to the world: 76
Telephone system: general assessment: requires
considerable expansion and modernization; fixed-
line telephone and a broad range of other telecom
services are controlled by a state-owned telecom-
munications monopoly and growth has been
stagnant; more competition exists in the mobile-
cellular market with four providers in 2009
domestic: teledensity of 17 fixed lines per 100
persons; mobile-cellular teledensity has increased
and now exceeds 100 telephones per 100 persons;
satellite service connects Baku to a modem switch
in its exclave of Nakhchivan
international: country code—994; the Trans-Asia-
Europe (TAE) fiber-optic link transits Azerbaijan pro-
viding international connectivity to neighboring coun-
tries; the old Soviet system of cable and microwave is
still serviceable; satellite earth stations—2 (2011)
52
THE CIA WORLD FACTBOOK
Broadcast media: 3 state-nm and 1 public TV
channels; 4 domestic commercial TV stations and
about 15 regional TV stations; cable TV services
are available in Baku; 1 state-run and 1 public
radio network operating; a small number of private
commercial radio stations broadcasting; local FM
relays of Baku commercial stations are available
in many localities; local relays of several interna-
tional broadcasters had been available until late
2008 when their broadcasts were banned from FM
frequencies (2010)
Internet country code: .az
Internet hosts: 46,856 (2012)
country comparison to the world: 98
Internet users: 2.42 million (2009) °
country comparison to the world: 70
Telephones—main lines in use: 133,000 (2011)
country comparison to the world: 140
Telephones—mobile cellular: 298,000 (2011)
country comparison to the world: 173
Telephone system: general assessment: modern
facilities
domestic: totally automatic system; highly devel-
oped; the Bahamas Domestic Submarine Network
links 14 of the islands and is designed to satisfy
increasing demand for voice and broadband Inter-
net services `
international: country code—1-242; landing
point for the Americas Region Caribbean Ring
System (ARCOS-1) fiber-optic submarine cable
that provides links to South and Central America,
parts of the Caribbean, and the US; satellite earth
stations—?2 (2007)
Broadcast media: 2 TV stations operated by
government-owned, commercially run Broad-
casting Corporation of the Bahamas (BCB);
multi-channel cable TV subscription service is
available; about 15 radio stations operating with
BCB operating a multi-channel radio broadcast-
ing network alongside privately owned radio sta-
tions (2007)
Internet country code: .bs
Internet hosts: 20,661 (2012)
country comparison to the world: 117
Internet users: 115,800 (2009)
country comparison to the world: 156','39a6fe0cde5d08279831b443351d22f76bbe6d43ac6850caf21d94ad01eb81c4','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7a8a6268b2c67f7254a56ad74da245f765ee558cbb3c53984e9a0dbc303a552c',2025,'BH','Bahrain','communications',172,'Telephones—main lines in use: (2011)
country comparison to the world: 122
Telephones—mobile cellular: 1.694 million
(2011)
country comparison to the world: 146
Telephone system: general assessment: modern
system
domestic: modem fiber-optic integrated services;
digital network with rapidly growing use of mobile-
cellular telephones
international: country code—973; landing
point for the Fiber-Optic Link Around the Globe
(FLAG) submarine cable network that provides
links to Asia, Middle East, Europe, and US; tropo-
spheric scatter to Qatar and UAE; microwave
radio relay to Saudi Arabia; satellite earth sta-
tion—1 (2007)
Broadcast media: state-run Bahrain Radiò ‘and
Television Corporation (BRTC) operates 5 terres-
trial TV networks and several radio stations; sat-
ellite TV systems provide access to international
broadcasts; 1 private FM station directs broadcasts
to Indian listeners; radio and TV broadcasts from
countries in the region are available (2007)
Internet country code:.bh
Internet hosts: 47,727 (2012)
country comparison to the world: 97
Internet users: (2009)
country comparison to the world: 122','694b59cf3e3c1fde8678f0810d474ce2f056a37b7c4c1d685eb25389f7636d88','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('215a86176147cf66e51d5556d484a28045908385163a1290cbf50b957400163a',2025,'BD','Bangladesh','communications',180,'Telephones—main lines in use: 977,700 (2011)
country comparison to the world: 79
Telephones—mobile cellular: 84.369 million
(2011)
country comparison to the world: 15
Telephone system: general assessment: inadequate
for a modern country; introducing digital systems;
trunk systems include VHF and UHF microwave
radio relay links, and some fiber-optic cable in cities
domestic: fixed-line teledensity remains only
about 1 per 100 persons; mobile-cellular telephone
62
THE CIA WORLD FACTBOOK
subscribership has been increasing rapidly and now
exceeds 50 telephones per 100 persons
international: country code—880; landing point
for the SEA-ME-WE-4 fiber-optic submarine cable
system that provides links to Europe, the Middle
East, and Asia; satellite earth stations—6; interna-
tional radiotelephone communications and land-
line service to neighboring countries (2011)
Broadcast media: state-owned Bangladesh Televi-
sion (BTV) operates 1 terrestrial TV station, 3 radio
networks, and about 10 local stations; 8 private sat-
ellite TV stations and 3 private radio stations also
broadcasting; foreign satellite TV stations are gain-
ing audience share in the large cities; several inter-
national radio broadcasters are available (2007)
internet country code: .bd
Internet hosts: 71,164 (2012)
country comparison to the world: 87
Internet users: (2009)
country comparison to the world: 112','edd269ec34732276b3d65bbc1b6815a36288510acbef8e82a44aa61172621922','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('dae1d8914e77875bdfd23018f0cc4ddebdcfe2fbcae639bbb33550e9f2f094c5',2025,'BB','Barbados','communications',191,'Telephones—main lines in use: 140,700 (2011)
country comparison to the world: 137
Telephones—mobile cellular: 347,900 (2011)
country comparison to the world: 171
Telephone system: general assessment: island-
wide automatic telephone system
domestic: fixed-line teledensity of roughly 50 per
100 persons; mobile-cellular telephone density
approaching 125 per 100 persons
international: country code—1-246; landing
point for the East Caribbean Fiber System (ECFS)
submarine cable with links to 13 other islands in
the eastern Caribbean extending from the Brit-
ish Virgin Islands to Trinidad; satellite earth sta-
tions—1 (Intelsat-Atlantic Ocean); tropospheric
scatter to Trinidad and Saint Lucia (2009)
Broadcast media: government-owned Carib-
bean Broadcasting Corporgtion (CBC) operates
the lone terrestrial TV station; CBC also operates
a multi-channel cable TV subscription service;
roughly a dozen radio stations, consisting of a
CBC-operated network operating alongside pri-
vately owned radio stations (2007)
Internet country code: .bb
Internet hosts: 1,524 (2012)
country comparison to the world: 167
Internet users: (2008)
country comparison to the world: 143','a0cdaebbc06d7a76a4bd0d2a01b27321f0edd157b94e2a56aecf64d5d3ded74c','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('017b8ac548ed81e30922393c7c7106ae33a7b29735d05a77d58c5806ed2cb1fa',2025,'BY','Belarus','communications',201,'Telephones—main lines In use: 4.208 million
(2011)
country comparison to the world: 41
Telephones—mobile cellular: 10.695 million
(2011)
country comparison to the world: 71
Telephone system: general assessment: Belarus
lags behind its neighbors in upgrading telecom-
munications infrastructure; modemization of the
network progressing with roughly two-thirds of
switching equipment now digital
domestic: state-owned Beltelcom is the sole
provider of fixed-line local and long distance
service; fixed-line teledensity is improving
although rural areas continue to be under-
served; multiple GSM mobile-cellular networks
are experiencing rapid growth; mobile-cellular
teledensity riow exceeds 100 telephones per
100 persons
international: country code—375; Belarus is a
member of the Trans-European Line (TEL), Trans-
Asia-Europe (TAE) fiber-optic line, and/has access
to the Trans-Siberia Line (TSL); 3 fiber-optic
segments provide connectivity to Latvia, Poland,
Russia, and Ukraine; worldwide service is available
to Belarus through this infrastructure; additional
analog lines to Russia; Intelsat, Eutelsat, and Inter-
éputnik earth stations (2008)
Broadcast media: 4 state-controlled national
TV channels; Polish and Russian TV broadcasts
are available in some areas; state-run Belarusian
Radio operates 3 national networks and an exter-
nal service; Russian and Polish radio broadcasts are
available (2007)
Internet country code: .by
internet hosts: 295,217 (2012)
country comparison to the world: 64
Internet users: 2.643 million (2009)
country comparison to the world: 69','89b0d2c550c289b92217488233ae53dd0b9148c8143684c1e7126f92eb5f9b69','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('234eda01f4e2bef22cd006b16dbf851d8e34f3de05e5ad37e9ae28cdb2894838',2025,'BE','Belgium','communications',211,'Telephones—main lines in use: 4.631 million
(2011)
country comparison to the world: 33
Telephones—mobile cellular: 12.541 million
(2011)
country comparison to the world: 62
Telephone system: general assessment: highly
developed, technologically advanced, and com-
pletely automated domestic and international tel-
ephone and telegraph facilities
domestic: nationwide mobile-cellular telephone
system; extensive cable network; limited micro-
‘wave radio relay network
international: country code—32; landing point
for a number of submarine cables that provide
links to Europe, the Middle East, and Asia; satel-
lite earth stations—7 (Intelsat—3) (2007)
Broadcast media: a segmented market with the
three major communities (Flemish, French, and
German-speaking) each having responsibility for
their own broadcast media; multiple TV channels
exist for each community; additionally, in excess of
90% of households are connected to cable and can
access broadcasts of TV stations from neighboring
countries; each community has a public radio net-
work co-existing with private broadcasters (2007)
Internet country code: .be
Internet hosts: 5.192 million (2012)
country comparison to the world: 21
Internet users: 8.113 million (2009)
country comparison to the world: 36
Telephones—main lines in use: 28,800 (2011)
country comparison to the world: 178
Telephones—mobile cellular: 222,000 (2011)
country comparison to the world: 178
Telephone system: general assessment: above-
average system; trunk network depends primarily
on microwave radio relay
domestic: fixed-line teledensity of slightly less
than 10 per 100 persons; mobile-cellular teleden-
sity approaching 70 per 100 persons
international: country code—501; landing point
for the Americas Region Caribbean Ring System
(ARCOS-1) fiber-optic telecommunications sub-
marine cable that provides links to South and
Central America, parts of the Caribbean, and
the US; satellite earth station—8 (Intelsat—2,
unknown—6) (2011)
Broadcast media: 8 privately owned TV stations;
multi-channel cable TV provides access to foreign
stations; about 25 radio stations broadcasting on
roughly 50 different frequencies; state-run radio
was privatized in 1998 (2007)
Internet country code: .bz
Internet hosts: 3,392 (2012)
country comparison to the world: 152
Internet users: (2009)
country comparison to the world: 178
BASE IZ5E','9187593c5aa89c00c3bd83538a9d4418145753ab2371e9e126553f36b66574c7','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9b808ccbea4d2dd395a67961355e83e80ea8ff082a5a482072305089d3b78d9a',2025,'BJ','Benin','communications',224,'Telephones—main lines in use: 152,700 (2011)
country comparison to the world: 133
Telephones—mobile cellular: 7.765 million
(2011)
country comparison to the world: 91
Telephone system: general assessment: inad-
equate system of open-wire, microwave radio
relay, and cellular connections; fixed-line network
characterized by aging, deteriorating equipment
domestic: fixed-line teledensity only about 2 per
100 persons; spurred by the presence of multiple
mobile-cellular providers, cellular telephone sub-
scribership has been increasing rapidly
international: country code—229; landing point
Tor the sa i-3/wasc Tiber-optic submarine cable
that provides connectivity to Europe and Asia;
long distance fiber-optic links with Togo, Burkina
Faso, Niger, and Nigeria; satellite earth stations—7
(Intelsat-Atlantic Ocean) (2008)
Broadcast media: state-run Office de Radiodif-
fusion et de Television du Benin (ORTB) oper-
ates a TV station with multiple channels giving
it a wide broadcast reach; several privately owned
TV stations broadcast from Cotonou; satellite TV
subscription service is available; state-owned radio,
under ORTB control, includes a national station
supplemented by a number of regional stations; sub-
stantial number of privately owned radio broadcast
stations; transmissions of a few international broad-
casters are available on FM in Cotonou (2007)
Internet country code: .bj
Internet hosts: 491 (2012)
country comparison to the world: 183
Internet users: 200,100 (2009)
country comparison to the world: 139','a649102d393a3c4c200e18c42c97f54b68af70fa1cc4c3aa2c8e6311d663506c','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ecb15f622b58bb732451285ffd2c28d6c2fe420ad399712f5f92989440f68bf8',2025,'BM','Bermuda','communications',234,'Telephones—main lines in use: 57,800 (2010)
country comparison to the world: 160
Telephones—mobile cellular: 88,200 (2010)
country comparison to the world: 194
Telephone system: general assessment: a good,
fully automatic digital telephone system with fiber-
optic trunk lines
domestic: the system has a high fixed-line teleden-
sity coupled with a mobile-cellular teledensity of
roughly 125 per 100 persons
international: country code—1-441; landing
points for the GlobeNet, Gemini Bermuda, and
the Challenger Bermuda-l1 (CB-1)submarine
cables; satellite earth stations—3 (2009)
Broadcast media: 3 TV stations; cable and satel-
lite TV subscription services are available; roughly
10 radio stations operating (2007)
Internet country code: bm
Internet hosts: (2012)
country comparison to the world: 119
Internet users: (2009)
country comparison to the world: 173','584d70af1a9a7d9909e0c203e71807bd8979c1d73314c97c3996568ed246ded6','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7c55f8da1817dc06dfe067d06a56ddaa6dbad062317019e72a2f68fe8c37f11f',2025,'BT','Bhutan','communications',246,'BHUTAN Telephones—main lines in use:
27,500 (2011)
country comparison to the world: 181
Telephones—mobile cellular: 484,200 (2011)
country comparison to the world: 167
Telephone system: general assessment: urban
towns and district headquarters have telecommu-
nications services
domestic: low teledensity; domestic service is poor
especially in rural areas; mobile-cellular service,
started in 2003, is now widely available
international: country code—975; international
telephone and telegraph service via landline and
microwave relay through India; satellite earth sta-
tion—l1 Intelsat (2012)
Broadcast media: state-owned TV station estab-
lished in 1999; cable TV service offers dozens of
Indian and other international channels; first
radio station, privately launched in 1973, is now
state-owned; 5 private radio stations are currently
broadcasting (2012) ; Zo
Internet country code: .br
Internet hosts: (2012)
country comparison to the world: 126
Internet users: 50,000 (2009)
country comparison to the world: 174','bc4a606d70c216f06e20a0eba11e0933391332f034796fccc74435a928e1390b','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('caa5bb40ce62e0043139c1dbd7e9dfa5845b57531f1bbed4c5abdf44197ae1c4',2025,'BR','Brazil','communications',254,'Telephones—main lines in use: 879,000 (2011)
country comparison to the world: 83
Telephones—mobile cellular: 8.355 million
(2011)
country comparison to the world: 85
90
THE CIA WORLD FACTBOOK
Telephone system: general assessment: Boliv-
ian National Telecommunications Company was
privatized in 1995 but re-nationalized in 2007;
the primary trunk system is being expanded and
employs digital microwave radio relay; some
areas are served by fiber-optic cable; system
operations, reliability, and coverage have stead-
ily improved.
domestic: most telephones are concentrated in La
Paz, Santa Cruz, and other capital cities; mobile-
cellular telephone use expanding rapidly and, in
2011, teledensity reached about 80 per 100 persons
international: country code—591; satellite earth
station—1 Intelsat (Atlantic Ocean) (2011)
"Broadcast media: large number of radio and TV
stations broadcasting with private media outlets
dominating; state-owned and private radio and
TV stations generally operating freely, although
both progovernment and anti-government groups
have attacked media outlets in response to their
reporting (2010)
Internet country code: .bo
Internet hosts: 180,988 (2012)
country comparison to the world: 75
Internet users: 1.103 million (2009)
country comparison to the world: 95
Telephones—main lines in use: 43.026 million
(2011)
country comparison to the world: 6
Telephones—mobile cellular: 244.358 million
(2011)
country comparison to the world: 5
Telephone system: general assessment: good
working system including an extensive microwave
radio relay system and a domestic satellite system
with 64 earth stations
domestic: fixed-line connections have remained
relatively stable in recent years and stand at about
20 per 100 persons; less expensive mobile-cellular
technology has been a major driver in expanding
telephone service to the lower-income segments
of the population with mobile-cellular teledensity
roughly 120 per 100 persons
international: country code—55; landing point
for a number of submarine cables, including Ameri-
cas-l, Americas-2, Atlantis-2, GlobeNet, South
America-1, South American Crossing/Latin Ameri-
can Nautilus, and UNISUR that provide direct con-
nectivity to South and Central America, the Carib-
bean, the US, Africa, and Europe; satellite earth
stations—3 Intelsat (Atlantic Ocean), 1 Inmarsat
(Atlantic Ocean region east), connected by micro-
wave relay system to Mercosur Brazilsat B3 satellite
earth station (2011)
Broadcast media: state-run Radiobras operates a
radio and a TV network; more than 1,000 radio
stations and more than 100 TV channels operat-
ing—mostly privately owned; private media own-
ership highly concentrated (2007)
Internet country code: .br
Interne? hosts: 26.577 million (2012)
country comparison to the world: 3 `
Internet users: 75.982 million (2009)
country comparison to the world: 4','eff586ecbfe3fcdf0fefd8ac8e90e8ef11831c02cb86e6227a8de4287c4e4cbf','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('05be87dcebcfbb0006ddb3aecc90d6c13714a2a22bee1c83aa4c90f6fabf8132',2025,'BA','Bosnia and Herzegovina','communications',263,'Telephones—main lines in use: 955,900 (2011)
country comparison to the world: 81
Telephones—mobile celiular: 3.171 million
(2011)
country comparison to the world: 124
Telephone system: general assessment: post-
war reconstruction of the telecommunications
network, aided by a internationally sponsored pro-
gram, resulting in sharp increases in the number of
fixed telephone lines available
domestic: fixed-line teledensity roughly 25 per
100 persons; mobile-cellular subscribership has
been increasing rapidly and, stands at roughly 80
telephones per 100 persons international: country
code—387; no satellite earth stations (2011)
Broadcast media: 3 public TV broadcasters:
Radio and TV of Bosnia and Herzegovina, Fed-
eration TV (operating 2 networks), and Repub-
lika Srpska Radio-TV; a local commercial net-
work of 5 TV stations; 3 private, near-national
TV stations and dozens of small independent
TV stations broadcasting; 3 large public radio
broadcasters and many private radio stations
(2010)
Internet country code: .ba
Internet hosts: 155,252 (2012)
country comparison to the world: 77
Internet users: 1.422 million (2009)
country comparison to the world: 85','2766f2b877570d2336e20fb1d29185ac0a206008471fb95fb3456498980763f9','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('22b7010ca45e9b71a80b84ce839cdce4fb1d04f911c03e8095e2305e08d1e3e7',2025,'BW','Botswana','communications',274,'Telephones—main lines in use: 149,600 (2011)
country comparison to the world: 135
Telephones—mobile cellular: 2.9 million (2011)
country comparison to the world: 130
Telephone system: general assessment; Bot-
swana is participating in regional development
efforts; expanding fully digital system with fiber-
optic cables linking the major population centers
in the east as well as a system of open-wire lines,
microwave radio relays links, and radiotelephone
communication stations
domestic: fixed-line teledensity has declined
in recent years and now stands at roughly 7 tel-
ephones per 100 persons; mobile-cellular teleden-
sity now pushing 140 telephones per 100 persons
international: country code—267; international
calls are made via satellite, using international
direct dialing; 2 international exchanges; digital
microwave radio relay links to Namibia, Zambia,
Zimbabwe, and South Africa; satellite earth sta-
tion—1 Intelsat (Indian Ocean) (2011)
Broadcast media: TV sfations—1 state-owned
and 1 privately owned; privately owned satellite
TV subscription service is available; 2 state-owned
national radio stations; 3 privately owned radio
stations broadcast locally (2007)
Internet country code: .bw
internet hosts: 1,806 (2012)
country comparison to the world: 163
Internet users: 120,000 (2009)
country comparison to the world: 153','e5f0e6a5f756cc5f848ee103b9ef562b3a956425852ccda20931d9e773b56112','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('81ac7e78cb119861ef20fd8fbaf83e7fddc116e991f3e0a3493d3c259d86b1b5',2025,'BV','Bouvet Island','communications',280,'Internet country code: .by
Internet hosts: 6 (2012)
country comparison to the world: 230-
Communications—note: has an automatic mete-
orological station','6c59b7ff90ebc2dc4c4f837dcdc745fbd120f250647852b452d4936e5a877cb6','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0decb0700b633b15d95be7929a2c845193a98e88da86ef6037b500e316898d49',2025,'ID','Indonesia','communications',290,'Telephone system: general assessment: separate
facilities for military and public needs are avail-
able domestic: all commercial telephone services
are available, including connection to the Internet
international: country code (Diego Garcia)—246;
international telephone service is carried by satel-
lite (2000)
Broadcast media: Armed Forces Radio and Tel-
evision Service (AFRTS) broadcasts over 3 sepa-
rate frequencies for US and UK military personnel
stationed on the islands (2009)
Internet country code: .io
Internet hosts: 75,006 (2012)
HE Gita WORLD FACTBOOK
country comparison to the world: 85
Telephones—main lines in use: (2010)
country comparison to the world: 182
Telephones—mobile cellular: 46,800 (2010)
country comparison to the world: 201
Telephone system: general assessment: good
overall telephone service
domestic: fixed line connections exceed 80 per
100 persons and mobile cellular subscribership is
roughly 150 per 100 persons
international: country code—1-284; connected
via submarine cable to Bermuda; the East Carib-
bean Fiber System (ECFS) submarine cable pro-
vides connectivity to 13 other islands in the east-
ern Caribbean (2011)
Broadcast media: private TV station; multi-
channel TV is available from cable and satellite
subscription services; about a half dozen private
radio stations (2007)
Internet country code: .vg
Internet hosts: 505 (2012)
country comparison to the world: 182
Internet users: (2002)
country comparison to the world: 207
Telephones—main lines In use: 79,800 (2011)
country comparison to theworld:151
Telephones—mobile cellular: 443,200 (2011)
country comparison to the world: 168
Telephone system: general assessment: service
throughout the country is good; international ser-
vice is good to Southeast Asia, Middle East, West-
ern Europe, and the US
domestic: every service available
international: country code—673; landing point
for the SEA-ME-WE-3 optical telecommunications
submarine cable that provides links to Asid, the
Middle East, and Europe; the Asia~-America Gate-
way submarine cable network provides new links to
Asia and the US; satellite earth stations—2 Intelsat
(1 Indian Ocean and 1 Pacific Ocean) (2011)
Broadcast media: state-controlled Radio Televi-
sion Brunei (RTB) operates 5 channels; 3 Malay-
sian TV stations are available; foreign TV broad-
casts are available via satellite and cable systems;
RTB operates 5 radio networks and broadcasts
on multiple frequencies; British Forces Broadcast
Service (BFBS) provides radio broadcasts on 2
FM stations; some radio broadcast stations from
Malaysia are available via repeaters (2009)
Internet country code: .bn
Internet hosts: 49,457 (2012)
country comparison to the world: 96
BRUNEI
Internet users: 314,900 (2009)
country comparison to the world: 128
Telephones—main lines in use: 38.618 million
(2011)
country comparison to the world: 8
Telephones—mobile cellular: 249.8 million
(2011)
country comparison to the world: 4
Telephone system: general assessment:domestic
service includes an interisland microwave ‘system,
an HF radio police net, and a domestic satellite
communications system; international service
good
domestic: coverage provided by existing net-
work has been expanded by use of over 200,000
telephone kiosks many located in remote areas;
mobile-cellular subscribership growing rapidly
international: country code—62; landing point
for both the SEA-ME-WE-3 and SEA-ME-WE-4
submarine cable networks that provide links
throughout Asia, the Middle East, and Europe; sat-
ellite earth stations—2 Intelsat (1 Indian Ocean
and 1 Pacific Ocean) (2011)
Broadcast media: mixture of about a dozen
national TV networks—2 public broadcasters, the
remainder private broadcasters—each with multi-
ple transmitters; more than 100 local TV stations;
widespread use of satellite and cable TV systems;
public radio broadcaster operates 6 national net-
works as well as regional and local stations; overall,
more than 700 radio stations with more than 650
privately operated (2008)
Internet country code: .id
Internet hosts: 1.344 million (2012)
country comparison to the world: 42
Internet users: 20 million (2009)
country comparison to the world: 22
Telephones—main lines in use: 27.767 million
(2011)
country comparison to the world: 12
Telephones—mobile cellular: 56.043 million
(2011)
country comparison to the world: 22
Telephone system: general assessment: cur-
rently being modernized and expanded with the
goal of ‘not only improving the efficiency and
increasing the volume of the urban service but also
bringing telephone service to several thousand vil-
lages, not presently connected
domestic: the addition of new fiber cables
and modern switching and exchange systems
installed by Iran’s state-owned telecom com-
pany have improved and expanded the fixed-
line network greatly; fixed-line availability has
more than doubled to more than 27 million lines
since 2000; additionally, mobile-cellular service
has increased dramatically serving roughly 56
million subscribers in 2011; combined fixed and
mobile-cellular subscribership now exceeds 100
per 100 persons
international: country code—98; submarine
fiber-optic cable to UAE with access to Fiber-
Optic Link Around the Globe (FLAG); Trans-
Asia-Europe (TAE) fiber-optic line runs from
Azerbaijan through the northern portion of Iran
to Turkmenistan with expansion to Georgia and
Azerbaijan; HF radio and microwave radio relay to
Turkey, Azerbaijan, Pakistan, Afghanistan, Turk-
menistan, Syria, Kuwait, Tajikistan, and Uzbeki-
stan; satellite earth stations—13 (9 Intelsat and 4
Inmarsat) (2011)
Broadcast media: state-run broadcast media
with no private, independent broadcasters;
Islamic Republic of Iran Broadcasting (IRIB), the
state-run TV broadcaster, operates 5 nationwide
channels, a news channel, about 30 provincial
channels, and several international channels;
about 20 foreign Persian-language TV stations
broadcasting on satellite TV are capable of being
seen in Iran; satellite dishes are illegal and, while
349
their use had been tolerated, authorities began
confiscating satellite dishes following the unrest
stemming from the 2009 presidential election;
IRIB operates 8 nationwide radio networks, a
number of provincial stations, and an external
service; most major international broadcasters
transmit to Iran (2009)
Internet country code: .ir
Internet hosts: 197,804 (2012)
country comparison to the world: 72
Internet users: 8.214 million (2009)
country comparison to the world: 35','d39d245f7ee6049cb0587cda21619e730a145f62be058ececcd1eb1bd2cf60a9','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e81a6221fc83fb32697cf76eae3a76eaa22deb60a60d3725de9025feea41c607',2025,'BG','Bulgaria','communications',304,'Telephones—main lines in use: 2.356 million
(2011) i
country comparison to the world: 54
Telephones—mobile cellular: 10.475 million
(2011)
country comparison to the world: 73
Telephone system: general assessment: inher-
ited an extensive but antiquated telecommu-
nications network from the Soviet era; quality
has improved with a modern digital trunk line
now connecting switching centers in most of the
regions; remaining areas are connected by digital
microwave radio relay
domestic: the Bulgaria Telecommunications Com-
pany’s fixed-line monopoly terminated in 2005 in
an effort to upgrade fixed-line services; mobile-cel-
lular teledensity, fostered by multiple service pro-
viders, has reached 150 telephones per 100 persons
international: country code—359; submarine
cable provides connectivity to Ukraine and Rus-
sia; a combination submarine cable and land fiber-
optic system provides connectivity to Italy, Alba-
nia, and Macedonia; satellite earth stations—3
(1 Intersputnik in the Atlantic Ocean region, 2
Intelsat in the Atlantic and Indian Ocean regions)
(2011)
Broadcast media: national terrestrial TV sta-
tions with 1 state-owned and 3 privately owned; a
vast array of TV stations are available from cable
and satellite TV providers; state-owned national
radio broadcasts over 3 networks; large number of
private radio stations broadcasting, especially in
urban areas (2010)
Internet country code: .bg
Internet hosts: 976,277 (2012)
country comparison to the world: 47
Internet users: 3.395 million (2009)
country comparison to the world: 63','2a3b1f632901a087a69f3cf4904adea7ed1a723851ea4fbfd6f1ea1c8b176326','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a42253988c33fec48f464b09261fc6fd37e722b4beb03ec3fb6c8b5db41d0e4f',2025,'BF','Burkina Faso','communications',318,'Telephones—main lines in use: 141,500 (2011)
country comparison to the world: 136
Telephones—mobile cellular: 7.682 million (2011)
country comparison to the world: 92
Telephone system: general assessment: system
includes microwave radio relay, open-wire, and
radiotelephone communication stations; in 2006
the government sold a 51 percent stake in the
national telephone company and ultimately plans
to retain only a 23 percent stake in the company
domestic: fixed-line connections stand at less than
1 per 100 persons; mobile-cellular usage, fostered
by multiple providers, is increasing rapidly from a
low base
international: country code—226; satellite earth
station—1 Intelsat (Atlantic Ocean) (2011)
Broadcast media: 2 TV stations—l1 state-owned
and 1 privately owned; state-owned radio runs a
national and regional network; substantial number
of privately owned radio stations; transmissions
of several international broadcasters available in
Ouagadougou (2007)
Internet country code: bf
Internet hosts: 1,795 (2012)
country comparison to the world: 164
Internet users: (2009)
country comparison to the world: 144
115
Telephones—main lines In use: 521,100 (2011)
country comparison to the world: 96
Telephones—mobile cellular: 1.244 million
(2011)
country comparison to the world: 151
Telephone system: general assessment: meets
minimum requirements for local and intercity ser-
vice for business and government
domestic: system barely capable of providing basic
service; mobile-cellular phone system is grossly
underdeveloped
international: country code—95; landing point
for the SEA-ME- WE-3 optical telecommunications
submarine cable that provides links to Asia, the
Middle East, and Europe; satellite earth stations—2,
Intelsat (Indian Ocean) and ShinSat (2011)
Broadcast media: government controls all domes-
tic broadcast media; 2 state-controlled TV stations
with 1 of the stations controlled by the armed
forces; 2 pay-TV stations are joint state-private
ventures; access to satellite TV is limited; 1 state-
controlled domestic radio station and 9 FM stations
that are joint state-private ventures; transmissions
of several international broadcasters are available
in parts of Burma; the Voice of America (VOA),
Radio Free Asia (RFA), BBC Burmese service, the
Democratic Voice of Burma (DVB), and Radio
Australia use shortwave to broadcast in Burma;
VOA, RFA, and DVB produce daily TV news pro-
grams that are transmitted by satellite to audiences
in Burma
Internet country code: .mm
internet hosts: 1,055 (2012)
119
country comparison to the world: 172
Internet users: 110,000 (2009)
country comparison to the world: 158','6b972dbdfd8f66696cfb7267b8e5b2d6e998fbc3e70a632f958580d5b7e2e5ac','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5dbec8e38df0eccd3c3b416ee801303815303b1faec562281bdce78bcdf37337',2025,'BI','Burundi','communications',328,'Telephones—main lines in use: (2011)
country comparison to the world: 177
Telephones—mobile cellular: 1.915 million
(2011)
country comparison to the world: 141
Telephone system: general assessment: sparse
system of open-wire, radiotelephone communica-
tions, and low—capacity microwave radio relays
domestic: telephone density one of the lowest in the
world; fixed-line connections stand at well less than
1 per 100 persons; mobile-cellular usage is increas-
ing but remains at roughly 20 per 100 persons
international: country code—257; satellite earth
station—1 Intelsat (Indian Ocean) (2011)
Broadcast media: state-controlled La Radiodiffu-
sion et Television Nationale de Burundi (RTNB)
operates the lone TV station and the only national
radio network; about 10 privately owned radio
123
stations; transmissions of, several international
broadcasters are available in Bujumbura (2007)
Internet country code: .bi
Internet hosts: 229 (2012)
country comparison to the world: 199
Internet users: (2009)
country comparison to the world: 147','100280ad3751ffdb91a5c72bbba13fb81cc2909dc12cc0284ec613a0852cb49d','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('834dfd6e43cff724247b0ad9b4d20e5a02b80cfc759f9e10a2bc73d0b4415527',2025,'KH','Cambodia','communications',336,'Telephones—main tines in use: 530,000 (2011)
country comparison to the world: 95
Telephones—mobile cellular: 13.757 million
(2011)
country comparison to the world: 57
Telephone system: general assessment: adequate
fixed-line and/or cellular service in Phnom Penh
and other provincial cities; mobile-cellular phone
systems are widely used in urban areas to bypass
deficiencies in the fixed-line network; mobile-phone
coverage is rapidly expanding in rural areas
domestic: fixed-line connections stand at about
4 per 100 persons; mobile-cellular usage, aided by
competition among service providers, is increasing
rapidly and stands at 92 per 100 persons
international: country code—855; adequate but
expensive landline and cellular service available to
all countries from Phnom Penh and major provin-
cial cities; satellite earth station—I1 Intersputnik
(Indian Ocean region) (2011)
Broadcast media: mixture of state-owned, joint
public-private, and privately owned broadcast
media; 9 TV broadcast stations with most oper-
ating on multiple channels, including | state-
operated station broadcasting from multiple
locations, 6 stations either jointly operated or pri-
vately owned with some broadcasting from several
locations, and 2 TV relay stations—one relaying
a French TV station and the other relaying a Viet-
namese TV station; multi-channel cable and satel-
lite systems are available; roughly 50 radio broad-
cast stations—1l state-owned broadcaster with
multiple stations and a large mixture of public and
THE CIA WORLD FACTBOOK
private broadcasters; several international broad-
casters are available (2009)
Internet country code: .kh
internet hosts: 13,784 (2012)
country comparison to the world: 129
Internet users: 78,500 (2009)
country comparison to the world: 167','e2358ab8b05733b64ca0fcb2836daf749a787ec44847904afa0cd61e0909a164','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b9b1c58bd4db414d926ee916ee8ca4b4c4904f13b20d6e8f28d8563969cda9f1',2025,'CM','Cameroon','communications',345,'Telephones—main lines in use: 669,000 (2011)
country comparison to the world: 90
Telephones—mobile cellular: 10.486 million
(2011)
country comparison to the world: 72
Telephone system: general assessment: system
includes cable, microwave radio relay, and tropo-
spheric scatter; Camtel, the monopoly provider of
fixed-line service, provides connections for only
about 3 per 100 persons; equipment is old and
outdated, and connections with many parts of the
country are unreliable
domestic: mobile-cellular usage, in part a reflection
of the poor condition and general inadequacy of the
fixed-line network, has increased sharply, reaching
a subscribership base of 50 per 100 persons
international: country code—237; landing point for
the SAT-3/WASC fiber-optic submarine cable that
provides connectivity to Europe and Asia; satellite
earth stations—2 Intelsat (Atlantic Ocean) (2011)
Broadcast media: government maintains tight
control over broadcast media; state-owned Cam-
eroon Radio Television (CRTV), broadcasting on
both a TV and radio network, was the only offi-
cially recognized and fully licensed broadcaster
until August 2007 when the government finally
issued licenses to 2 private TV broadcasters and
1 private radio broadcaster; about 70 privately
owned, unlicensed radio stations operating but
are subject to closure at any time; foreign news
services required to partner with state-owned
national station (2007)
Internet country code: .cm
Internet hosts: 10,207 (2012)
country comparison to the world: 134
Internet users: 749,600 (2009)
country comparison to the world: 106','58eca9faa256f5fbe2f6f193d78929a4f22f81b8f9f294fde470c20f02514d1c','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('94c49e6107739d253fb3a5183798eb00d395ba1cd920cdd45883a2ad600b9019',2025,'CA','Canada','communications',353,'Telephores—main lines in use: 18.201 million
(2011)
country comparison to the world: 16
Telephones—mobile cellular: 27.387 million
(2011)
country comparison to the world: 37
Telephone system: general assessment: excel-
lent service provided by modern technology
domestic: domestic satellite system with about 300
earth stations
international: country code—1; submarine cables
provide links to the US and Europe; satellite earth
stations—7 (5 Intelsat—4 Atlantic Ocean and
1 Pacific Ocean, and 2 Intersputnik—Aclantic
Ocean region) (2011)
Broadcast media: 2 public TV broadcasting
networks each with a large number of network
affiliates; several private-commercial networks
also with multiple network affiliates; overall,
about 150 TV stations; multi-channel satellite
and cable systemis provide access to a wide range of
stations including US stations; mix of public and
commercial radio broadcasters with the Canadian
Broadcasting Corporation (CBC), the public radio
broadcaster, operating 4 radio networks, Radio
Canada International, and radio services to indig-
enous poputations in the north; roughly 2,000
licensed radio stations in Canada (2008)
Internet country code: .ca
Infernet hosts: 8.743 million (2012)
country comparison to the world: 14
Internet users: 26.96 million (2009)
country comparison to the world: 16
Telephones—main lines in use: 74,500 (2011)
country comparison to the world: 155
Telephones—mobile cellular: 396,400 (2011)
country comparison to the world: 170
Telephone system: general assessment: effective
system, extensive modernization from 1996-2000
following partial privatization in 1995
domestic: major service provider is Cabo
Verde Telecom (CVT); fiber-optic ring, com-
pleted in 2001, links all islands providing
Internet access and ISDN services; cellular
service introduced in 1998; broadband services
launched in 2004
international: country code—238; landing
point for the Atlantis-2 fiber-optic transatlan-
tic telephone cable that provides links to South
America, Senegal, and Europe; HF radiotel-
ephone to Senegal and Guinea-Bissau; satel-
lite earth station—l1 Intelsat (Atlantic Ocean)
(2011)
Broadcast media: state-run TV and radio broad-
cast network plus a growing number of private
broadcasters; Portuguese public TV and radio
services for Africa are available; transmissions of a
few international broadcasters are available (2007)
Internet country code: .cv
Internet hosts: 38 (2012)
country comparison to the world: 217
Internet users: 150,000 (2009)
country comparison to the world: 148','aeb7ff570c5efa711a0b4b885bea33faf7ad54cb2f0ffa48a89836861fae946e','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f10916d36414c2b2857747eb0b9068b07f1937e884855aa47a74bd87bc1a1a8c',2025,'KY','Cayman Islands','communications',365,'Telephones—main lines in use: 37,200 (2011)
country comparison to the world: 170
Telephones—mobile cellular: 95,100 (2011)
country comparison to the world: 193
Telephone system: general assessment: reason-
ably good overall telephone system with a high
fixed-line teledensity
domestic: liberalization of telecom market in
2003; introduction of competition in the mobile-
cellular market in 2004
international: country code—1-345; landing
points for the Maya-1, Eastern Caribbean Fiber Sys-
tem (ECFS), and the Cayman-Jamaica Fiber Sys-
tem submarine cables that provide links to the US
and parts of Central and South America; satellite
earth station—1 Intelsat (Atlantic Ocean) (2011)
Internet country code: .ky
Internet hosts: 23,472 (2012)
country comparison to the world: 114
Internet users: 23,000 (2008)
country comparison to the world: 190','af782554cafa8153b1b1810f8c332ce601951999d6c9a15034da2b7d7c1d1450','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f7c67914435a317f1bb47d4ac4b033a91776944cba47c6254cd9052eda73171b',2025,'CF','Central African Republic','communications',375,'Telephones—main lines in use: 5,400 (2011)
country comparison to the world: 209
Telephones—mobile cellular: 1.824 million
(2011)
country comparison to the world: 144
Telephone system: general assessment: net-
work consists principally of microwave radio relay
and low-capacity, low-powered radiotelephone
communication
domestic: limited telephone service with less than
1 fixed-line connection per 100 persons; spurred
by the presence of multiple mobile-cellular ser-
vice providers, cellular usage is increasing from a
low base; most fixed-line and mobile-cellular tel-
ephone services are concentrated in Bangui
international: country code—236; satellite earth
station—lI Intelsat (Atlantic Ocean) (2011)
Broadcast media: government-owned net-
work, Radiodiffusion Television Centrafricaine,
provides domestic TV broadcasting; licenses for
THE CIA WORLD FACTBOOK
2 private TV stations are pending; state-owned
radio network is supplemented by a small number
of privately owned broadcast stations as well as
a few community radio stations; transmissions of
at least 2 international broadcasters are available
(2007)
Internet country code: .cf
internet hosts: 20 (2012)
country comparison to the world: 222
internet users: 22,600 (2009)
country comparison to the world: 192','6f69ee9a346068e4d8b988e67af3904a1e47cedc7de59a6f650ab5b238f1abb8','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('80b57634df57c77a5b49bfe90a86ea5f3996b9fc8f66f8bc24fbcd8cfbcec0e6',2025,'TD','Chad','communications',382,'Telephones—main lines in use: 31,200 (2011)
country comparison to the world: 175
Telephones—mobile cellular: 3.666 million
(2011)
country comparison to the world: 119
Telephone system: general assessment: inad-
equate system of radiotelephone communica-
tion stations with high costs and low telephone
density
domestic: fixed-line connections for less than 1
per 100 persons coupled with mobile-cellular sub-
scribership base of only about 35 per 100 persons
international: country code—235; satellite earth
station—1 Intelsat (Atlantic Ocean) (2011)
Broadcast media: 1 state-owned TV station;
state-owned radio network, Radiodiffusion
Nationale Tchadienne (RNT), operates national
ahd regional stations; about 10 private radio sta-
tions; some stations rebroadcast programs from
international broadcasters (2007)
Internet country code: .td
Internet hosts: 6 (2012)
country comparison to the world: 230
Internet users: 168,100 (2009)
country comparison to the world: 145','835f943c5fb85d9e160721e4a53e92a026f16fcdfe54b2ff2a4b32ca5d279c69','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8529179ec18213bc4534a7c81de9f2e5ed03738908455748672560f3bec54455',2025,'CN','China','communications',397,'Telephones—main lines in use: 285.115 mil-
lion (2011)
country comparison to the world: 1
Telephones—mobile cellular: 986.253 million
(2011)
country comparison to the world: 1
Telephone system: general assessment: domestic
and international services are increasingly. avail-
able for private use; unevenly distributed domestic
system serves principal cities, industrial centers,
and many towns; China continues to develop its
telecommunications infrastructure; China in the
summer of 2008 began a major restructuring of
its telecommunications industry, resulting in the
consolidation of its six telecom service opera-
tors to three, China Telecom, China Mobile and
China Unicom, each providing both fixed-line
and mobile services
domestic: - interprovincial fiber-optic trunk
lines and cellular telephone systems have been
installed; mobile-cellular subscribership is increas-
ing rapidly; the number of Internet users exceeded
564 million by the end of 2012; a domestic satellite
system with several earth stations is in place
international: country code—86; a number of
submarine cables provide connectivity to Asia, the
Middle East, Europe, and the US; satellite earth
stations—7 (5 Intelsat—4 Pacific Ocean and 1
Indian Ocean; 1 Intersputnik—Indian Ocean
region; and 1 Inmarsat—Pacific and Indian Ocean
regions) (2012)
Broadcast media: all broadcast media are owned
by, or affiliated with, the Communist Party of
China or a government agency; no privately
owned TV or radio stations; state-run Chinese
Central TV, provincial, and municipal stations
offer more than 2,000 channels; the Central
Propaganda Department lists subjects that are
off limits to domestic broadcast media with the
government maintaining authority to approve all
programming; foreign-made TV programs must be
approved prior to broadcast
Internet country code: .cn
Internet hosts: 20.602 million (2012)
country comparison to the world: 5
Internet users: 389 million (2009)
country comparison to the world: 1
155
Telephones—main lines In use: 422,100 (2011)
country comparison to the world: 104
Telephones—mobile cellular: 2.213 million
(2011)
country comparison to the world: 137
MACEDONIA
Telephone system: general assessment: com-
petition from the mobile-cellular segment of the
telecommunications market has led to a drop in
fixed-line telephone subscriptions
domestic: combined fixed-line and mobile-cel-
lular telephone subscribership about 130 per 100
persons
International: country code—389 (2012)
Broadcast media: public TV broadcaster oper-
ates 3 national channels and a satellite network; 5
privately owned TV channels broadcast nationally
using terrestrial transmitters and about 15 broad-
cast on national level via satellite; roughly 75 local
commercial TV stations; large number of cable
operators offering domestic and international pro-
gramming; public radio broadcaster operates over
* multiple stations; 3 privately owned radio stations
broadcast nationally; about 70 local commercial
tadio stations (2012)
Internet country code: .mk
Internet hosts: 62,826 (2012)
country comparison to the world: 92
Internet users: 1.057 million (2009)
country comparison to the world: 97','ae2acba780a1a8526e0fbf54a25c7ee9929d9edb25ec9a813379ff75381f67d1','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('444c2624a139f0a69b49c2e3d94666869eee213d7c0ac1be8307e01df539b1a0',2025,'CX','Christmas Island','communications',405,'Telephone system: general assessment: service
provided by the Australian network
domestic: GSM mobile-cellular telephone service
replaced older analog system in February 2005
international: country code—61-8; satellite earth
station—1 (Intelsat provides telephone and telex
service) (2005)
THE CIA WORLD FACTBOOK
Broadcast media: 1 community radio station;
satellite broadcasts of several Australian radio and
TV stations (2009)
Internet country code: .cx
Internet hosts: 3,028 (2012)
country comparison to the world: 155
internet users: 464 (2001)
country comparison to the world: 217','6e2f916b5bb84a9c9183c999e155e1ae23ae14d63fd1734d14ac8f02499f9b16','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a7c9f76a1f065b9b69d73e39a4c0238b7164262344b539a4597ee0480bf15005',2025,'CC','Cocos (Keeling) Islands','communications',411,'Telephone system: general assessment: tel-
ephone service is part of the Australian network;
an operational local mobile-cellular network avail-
able; wireless Internet connectivity available
domestic: NA
international: country code—61; telephone,
telex, and facsimile communications with','f0920db37c78dd493e63262dc02398be876ec0db33a738eb77628b405dcabdb6','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d0f7c979ae1d75d84381158356848298927e72a128c8b79a912d7ae84d516bb4',2025,'CO','Colombia','communications',419,'Telephones—main lines in use: 7.127 million
(2011)
country comparison to the world: 26
Telephones—mobile cellular: 46.2 million
(2011)
country comparison to the world: 29
Telephone system: general assessment: mod-
ern.system in many respects with a nationwide
microwave radio relay system, a domestic satellite
system with 41 earth stations, and a fiber-optic
network linking 50 cities; telecommunications
sector liberalized during the 1990s; multiple
providers of both fixed-line and mobile-cellular
services
domestic: fixed-line connections stand at about
15 per 100 persons; mobile cellular telephone sub-
scribership is about 100 per 100 persons; competi-
tion among cellular service providers is resulting
in falling local and international calling rates and
contributing to the steep decline in the market
share of fixed line services
international: country code—57; multiple subma-
rine cable systems provide links to the US, parts of ‘
the Caribbean, and Central and South America;
satellite earth stations—i0 (6 Intelsat, 1 Inmarsat,
3 fully digitalized international sw itching centers)
(2011)
Broadcast media: combination of state-owned
and privately owned broadcast media provide
service; more than 500 radio stations and many
national, regional, and local TV stations (2007)
Internet country code: .co
Internet hosts: 4.41 million (2012)
country comparison to the world: 24
Internet users: 22.538 million (2009)
country comparison to the world: 18
Telephones—main lines in use: 7.332 million
(2011)
country comparison to the world: 24
Telephones—mobile cellular: 28.782 million
(2011)
country comparison to the world: 35
Telephone system: general assessment: modern
and expanding
domestic: domestic satellite system with 3 earth
stations; recent substantial improvement in tele-
phone service in rural areas; substantial increase in
digitalization of exchanges and trunk lines; instal-
lation of a national interurban fiber-optic network
capable of digital multimedia services; combined
fixed and mobile-cellular telephone subscribership
130 per 100 persons
international: country code—58; submarine
cable systems provide connectivity to the Carib-
bean, Central and South America, and US; sat-
ellite earth stations—1 Intelsat (Atlantic Ocean)
and 1 PanAmSat; participating with Colombia,
Ecuador, Peru, and Bolivia in the construction of
an international fiber-optic network; constructing
submarine cable to provide connectivity to Cuba
with an estimated date of completion in late 2011
(2010)
Broadcast media: government supervises a mixture
of state-run and private broadcast media; 1 state-run
TV network, 4 privately owned TV networks, a pri-
vately owned news channel with limited national
coverage, and a government-backed pan-American
channel; state-run radio network includes 65 news
stations and roughly another 30 stations targeted
at specific audiences; state-sponsored community
broadcasters include 244 radio stations and 36 TV
stations; the number of private broadcast radio sta-
tions has been declining, but many still remain in
operation (2010)
Internet country code: ve
Internet hosts: 1.016 million (2012)
country comparison to the world: 46
Internet users: 8.918 million (2009)
country comparison to the world: 32','6ecede27eae5cef085f70f5ac0da092da6fc994ded63eff6411f58a8cee3d131','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('28a48f61cf8d3386ba383dd4f92ac7e0e334fec3475c4299dceb15e278146f5f',2025,'KM','Comoros','communications',429,'Telephones—main lines In use: 23,600 (2011)
country comparison to the world: 185
Telephones—mobile cellular: 216,400 (2011)
country comparison to the world: 180
Telephone system: general assessment: sparse
system of microwave radio relay and HF radiotel-
ephone communication stations
domestic; fixed-line connections only about 3 per
100 persons; mobile cellular usage about 30 per
100 persons
O cu m
international: country code—269; landing point
for the EASSy fiber-optic submarine cable system
connecting East Africa with Europe and North
America; HF radiotelephone communications to
Madagascar and Reunion (2010)
Broadcast media: national state-owned
TV station and a TV station run by Anjouan
regional government; national state-owned
radio; regional governments on the islands of
Grande Comore and Anjouan each operate a
radio station; a few independent and small com-
munity radio stations operate on the islands
of Grande Comore and Moheli, and these
two islands have access to Mayotte Radio and
French TV (2007)
Internet country code: .km
Internet hosts: 14 (2012)
country comparison to the world: 226
Internet users: 24,300 (2009)
country comparison to the world: 187','b6de7b10ccfbbff27457c76f9dea4996f9424c2eaa1af8061a0105b87f41e0b9','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8ee63ba706d38668bb01f3e371c78d6a29d08784a735ec732ca18d9c1a96a2cd',2025,'ZM','Zambia','communications',435,'Telephones—amain lines in use: 57,000 (2011)
country comparison to the world: 161
Telephones—mobile cellular: 15.645 million
(2011) -—
country comparison to the world: 53
Telephone system: general assessment: barely
adequate wire and microwave radio relay service
in and between urban areas; domestic satellite sys-
tem with 14 earth stations; inadequate fixed line
infrastructure
domestic: state-owned operator providing less
than 1 fixed-line connection pet 1000 persons;
given the backdrop of a wholly inadequate fixed-
line infrastructure, the use of mobile-cellular ser-
vices has surged and mobile teledensity is roughly
20 per 100 persons À
international: country code—243; satellite earth
station—l1 Intelsat (Atlantic Ocean) (2011)
Broadcast media: state-owned TV broadcast
station with near national coverage; more than a
dozen privately owned TV stations with 2 having
near national coverage; 2 state-owned radio sta-
tions are supplemented by more than 100 private
radio stations; transmissions of at least 2 interna-
tional broadcasters are available (2007)
internet country code: .cd
Internet hosts: 2,515 (2012)
country comparison to the world: 159
Internet users: 290,000 (2008)
country comparison to the world: 131
Telephones—main lines in use: 85,700 (2011)
country comparison to the world: 149
Telephones—mobile cellular: 8.165 million
(2011)
country comparison to the world: 87
Telephone system: general assessment: among
the best in sub-Saharan Africa
domestic: high-capacity microwave radio relay
connects most larger towns and cities; several cel-
lular telephone services in operation and network
coverage is improving; domestic satellite system
being installed to improve telephone service in
rural areas; Internet service is widely available;
very small aperture terminal (VSAT) networks are
operated by private firms
international: country code—260; satellite earth
stations—2 Intelsat (1 Indian Ocean and 1 Atlan-
tic Ocean), 3 owned by Zamtel (2010)
Broadcast media: state-owned Zambia National
Broadcasting Corporation (ZNBC) operates 1 TV
station and is the principal local-content provider;
several private TV stations; multi-channel subscrip-
tion TV services are available; ZNBC operates 3
radio networks; about 2 dozen private radio sta-
tions; relays of at least 2 international broadcasters
are accessible in Lusaka and Kitwe (2007)
Internet country code: .2m
Internet hosts: 16,571 (2012)
country comparison, to the world: 122
Internet users: 816,200 (2009)
country comparison to the world: 105','c837ad69b8a9e4aedb7b5e1b3e17f0c749e08759999ad9bfd78f63c107b72017','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ec23215c36005025b70c10b7b1fd58ccd2ffabdece7f31c8253b18c2247390fe',2025,'CK','Cook Islands','communications',444,'Telephones—main lines in use: 7,200 (2009)
country comparison to the world: 205
Telephones—mobile cellular: 7,800 (2009)
country comparison to the world: 211
Telephone system: general assessment: Telecom
Cook Islands offers international direct dialing,
Internet, email, fax, and Telex
domestic: individual islands are connected by a
combination of satellite earth stations, microwave
systems, and VHF and HF radiotelephone; within
the islands, service is provided by small exchanges
connected to subscribers by open-wire, cable, and
fiber-optic cable international: country code—682;
satellite earth station—1 Intelsat (Pacific Ocean)
Broadcast media: privately owned TV station
broadcasts from Rarotonga providing a mix of local
news and overseas-sourced programs; a satellite pro- `
gram package is available; 6 radio stations broadcast
with | reportedly reaching all of the islands (2009)
Internet country code: .ck
Internet hosts: 3,562 (2012)
country comparison to the world: 150
Internet users: 6,000 (2009)
country comparison to the world: 205','78369e15739524d040cb90be5e44f3bdecceab90595ba583985834437d92c4a9','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0e19bbc44e9acceec8493fae1dc93082f7616b35eccbc771f3e01a6c6d6c5be6',2025,'MX','Mexico','communications',460,'Telephones—main lines in use: 268,200 (2011)
country comparison to the world: 124
Telephones—mobile cellular: 17.344 million
(2011)
country comparison to the world: 51
Telephone system: general assessment: well-
developed by African standards; telecommunica-
tions sector privatized in late 1990s and opera-
tional fixed-lines have increased since that time
with two fixed-line providers operating over open-
w ire lines, microwave radio relay, and fiber-optics;
90% digitalized
domestic: with multiple mobile-cellular service
providers competing in the market, usage has
increased sharply to roughly 80 per 100 persons
international: country code—225; landing point
for the SAT-3/WASC fiber-optic submarine cable
that provides connectivity to Europe and Asia; sat-
ellite earth stations—2 Intelsat (1 Atlantic Ocean
and 1 Indian Ocean) (2011)
Broadcast media: state-owned TV stations; no
private terrestrial TV stations, but satellite TV
subscription service is available; 2 state-owned
radio stations; some private radio stations; trans-
missions of several international broadcasters are
available (2007)
Internet country code: .ci
Internet hosts: 9,115 (2012)
country comparison to the world: 137
internet users: 967,300 (2009)
country comparison to the world: 103
Telephones—main lines in use: 19.684 million
(2011)
country comparison to the world: 15
Telephones—mobile cellular: 94.565 million
(2011)
country comparison to the world: 13
Telephone system: general assessment: adequate
telephone service for business and government;
improving quality and increasing mobile cellular
availability, with mobile subscribers far outnum-
bering fixed-line subscribers; domestic satellite sys-
tem with 120 earth stations; extensive microwave
radio relay network; considerable use of fiber-optic
cable and coaxial cable
domestic: despite the opening to competition in
January 1997, Tel mex remains dominant; Fixed-
line tele density is less than 20 per 100 persons;
mohile-cellular tele density is about 80 per 100
persons -g
international: country code—52; Columbus-2
fiber-optic submarine cable with access to the
US, Virgin Islands, Canary Islands, Spain, and
Italy; the Americas Region Caribbean Ring
System(ARCOS-1) and the MAYA-1 submarine
cable system together provide access to Central
America, parts of South America and the Carib-
bean, and the US; satellite earth stations—120 (32
Intelsat, 2 Solidaridad (giving Mexico improved
access to South America, Central America, and
much of the US as well as enhancing domestic
482
THE CiA WORLD FACTBOOK
communications), 1 Panamsat, numerous Inmarsat
mobile earth stations); linked to Central American
Microwave System of trunk connections (2011)
Broadcast media: many TV stations and more than
1,400 radio stations with most privately owned; the
Televisa group once had a virtual monopoly in TV
broadcasting, but new broadcasting groups and for-
eign satellite and cable operators are now available
(2012)
Internet country code: .mx
Internet hosts: 16.233 million (2012)
country comparison to the world: 9
Internet users: 31.2 million (2009)
country comparison to the world: 12
Telephones—main lines in use: 8.500 (2010)
country comparison to the world: 202
Telephones—mobile cellular: 27.500 (2010)
country comparison to the world: 207
Telephone system: general assessment: adequate
system
domestic: islands interconnected by shortwave
radiotelephone (used mostly for government
purposes), satellite (Intelsat) ground stations,
and some coaxial and fiber-optic cable; mobile-
cellular setvice available on Kosrae, Pohnpei,
and Yap
international: country code—691; satellite
earth stations—5 Intelsat (Pacific Ocean)
(2002) Broadcast media: no TV broadcast sta-
tions; each state has a multi-channel cable
service with TV transmissions carrying roughly
95% imported programming and 5% local pro-
gramming; about a half dozen radio stations
(2009) `
Internet country code: .fm
Federated States of Micronesia
Internet hosts: 4,668 (2012)
country comparison to the world: 147
Internet users: 17,000 (2009)
country comparison to the world: 198','570780aae8251fb9da9d75c121517393e38db47a68da53d6d7f60b95ce68e9fa','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6fb23cd71b34aa5c66464722e642a90ec636396832c21b4a84dbb142d274e4e8',2025,'HR','Croatia','communications',471,'Telephones—main lines in use:1.761 million
(2011)
country comparison to the world: 63
Telephones—mobile cellular: 5.115 million
(2011)
country comparison to the world: 103
Telephone system: general assessment: the tel-
ecommunications netw ork has improved steadily
since the mid-1990s, covering much of what were
once inaccessible areas; local lines are digital
domestic: fixed-line teledensity holding steady
at about 40 per 100 persons; mobile-cellular tel-
ephone subscriptions exceed the population
international: country code—385; digital inter-
national service is provided through the main
switch in Zagreb; Croatia participates in the Trans-
Asia-Europe (TEL) fiber-optic project, which
consists of 2 fiber-optic trunk connections with
Slovenia and a fiber-optic trunk line from Rijeka
to Split and Dubrovnik; the ADRIA-1 submarine
cable provides connectivity to Albania and Greece
(2011)
Broadcast media: the national state-owned pub-
lic broadcaster, Croatian Radiotelevision (HRT),
operates 4 terrestrial TV netw orks, a satellite
channel that rebroadcasts programs for Croatians
living abroad, and 6 regional TV centers; 2 private
broadcasters operate national terrestrial netw orks;
roughly 25 privately-owned regional TV stations;
multi-channel cable and satellite TV subscription
services are available; state-owned public broad-
caster operates 3 national radio netw orks and 9
regional radio stations; 2 privately owned national
radio netw orks and more than 170 regional,
county, city, and community radio stations (2012)
Internet country code:.hr
Internet hosts:729,420 (2012)
country comparison to the world: 50
Internet users: 2.234 million (2009)
country comparison to the world: 73','d11fbcee8f01608bb31917cc0ec650f6c624d9463a98ca938f364aa6f9535bd2','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3d060513d170276771071b14680aed573f9208539e99152f5b2572d6f8177a28',2025,'CU','Cuba','communications',480,'Telephones—main lines in use: 1.193 million
(2011)
country comparison to the world: 70
Tetephones—mobile cellular: 1.315 million
(2011)
country comparison to the world: 149
Telephone system: general assessment: greater
investment beginning in 1994 and the establish-
ment of a new Ministry of Information Technol-
ogy and Communications in 2000 has resulted
in improvements in the system; national fiber-
optic system under development; 95% of sw
itches digitized by end of 2006; mobile-cellular
telephone service is expensive and must be paid
in convertible pesos, which effectively limits
subscribership
domestic: fixed-line density remains low at 10 per
100 inhabitants; mobile-cellular service expanding
but remains only about 10 per 100 persons
international: country code—53; fiber-optic
cable laid to but not linked to US netw ork; satel-
lite earth station—1 Intersputnik (Atlantic Ocean
region) (2010)
Broadcast media: government owns and controls
all broadcast media with private ownership of
electronic media prohibited; government operates
4 national TV netw orks and many local TV sta-
tions; government operates 6 national radio netw
orks, an international station, and many local
radio stations; RadioTV Marti is beamed from the
US (2007)
Internet country code: .cu
internet hosts: 3,244 (2012)
country comparison to the world: 154
Internet users: 1.606 million
country comparison to the world: 79
note: private citizens are prohibited from buy-
ing computers or accessing the Internet without
special authorization; foreigners may access the
Internet in large hotels but are subject: to firew
alls; some Cubans buy illegal passw ords on the
black market or take advantage of public outlets
to access limited email and the government-con-
trolled “intranet” (2009)','3000a8299554576c40d8313ca1c614676b4927a51da0a184363a541b883c249b','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('08d9f280bafca230767be7651fab94590fb057922381fdad7b7096a738e52bc4',2025,'DK','Denmark','communications',498,'Telephones—main lines in use: 2.515 million
(2011)
country comparison to the world: 53
Telephones—mobile cellular: 7.159 million
(2011)
country comparison to the world: 94
Telephone system: general assessment: excel-
lent telephone and telegraph services
domestic: buried and submarine cables and micro-
wave radio relay form trunk network, multiple cel-
lular mobile communications systems
international: country code—45; a series of
fiber-optic submarine cables link Denmark with
Canada, Faroe Islands, Germany, Iceland, Nether-
lands, Norway, Poland, Russia, Sweden, and UK;
satellite earth stations—18 (6 Intelsat, 10 Eutelsat,
1 Orion, 1 Inmarsat (Blaavand-Atlantic-East));
note—the Nordic countries (Denmark, Finland,
Iceland, Norway, and Sweden) share the Dan-
ish earth station and the Eik, Norway, station for
worldwide Inmarsat access (2011)
Broadcast media: strong public-sector TV pres-
ence with state-owned Danmarks Radio (DR)
operating 4 channels and publicly owned TV2
operating roughly a half dozen channels; broad-
casts of privately owned stations are available via
satellite and cable feed; DR operates 4 nationwide
FM radio stations, 15 digital audio broadcasting
stations, and about 15 web-based radio stations;
approximately 250 commercial and community
radio stations (2007)
Internet country code: .dk
THE CIA WORLD FACTBOOK
internet hosts: 4.297 million (2012)
country comparison to the world: 25
Internet users: 4.75 million (2009)
country comparison to the world: 48
Broadcast media: British Forces Broadcast Service
(BFBS) provides multi-channel satellite TV service
as well as BFBS radio broadcasts to the Dhekelia
Sovereign Base (2009)','c175a705d32545c9f5f345ab6e277c51bc453f57036953f438baf255549d940d','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ec198d167eff43b28f5d7b18eeb5123de66530ee6735d8c9e134afd221e5f2be',2025,'DJ','Djibouti','communications',512,'Telephones—main lines In use: 18,400 (2011)
country comparison to the world: 193
Telephones—mobile cellular: (2011)
capacity:
205
country comparison to the world: 181
Telephone system: general assessment: telephone
facilities in the city of Djibouti are adequate, as are
the microwave radio relay connections to outlying
areas of the country
domestic: Djibouti Telecom is the sole provider of
telecommunications services and utilizes mostly a
microwave radio relay network; fiber-optic cable is
installed in the capital; rural areas connected via
wireless local loop radio systems; mobile cellular
coverage is primarily limited to the area in and
around Djibouti city .
international: country code—253; landing point
for the SEA-ME-WE-3 and EASSy fiber-optic sub-
marine cable systems providing links to Asia, the
Middle East, Europe and North America; satellite
earth stations—2 (1 Intelsat—Indian Ocean and
1 Arabsat); Medarabtel regional microwave radio
relay telephone network (2009)
Broadcast media: state-owned Radiodiffusion-Tele-
vision de Djibouti (RTD) operates the sole terrestrial
TV station as well as the only 2 domestic radio net-
works; no private TV or radio stations; transmissions of
several international broadcasters are available (2007)
Internet country code: .dj
Internet hosts: 215 (2012)
country comparison to the world: 201
Internet users: 25,900 (2009) country
comparison to the world: 185','500912524668aabbd15412d8e5b85241e1850750ef6693bb50e497e52160b329','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ae61e69a02b49d76fdcf5f015def57d949efe75b415262bb08ace7a8dde1d9aa',2025,'DM','Dominica','communications',522,'Telephones—main lines in use: 15,500 (2010)
country comparison to the world: 195
Telephones—mobile cellular: 111,000 (2011)
country comparison to the world: 190
Telephone system: general assessment: fully
automatic network
domestic: fixed-line connections continued to
decline slowly with the two active operators pro-
viding about 20 fixed-line connections per 100
persons; subscribership among the three mobile-
cellular providers continued to increase with tel-
edensity reaching 150 per 100 persons
international: country code—1-767; landing
points for the East Caribbean Fiber Optic Sys-
tem (ECFS) and the Global Caribbean Network
(GCN) submarine cables providing connectivity
to other islands in the eastern Caribbean extend-
ing from the British Virgin Islands to Trinidad;
microwave radio relay and SHF radiotelephone
links to Martinique and Guadeloupe; VHF and
UHF radiotelephone links to Saint Lucia (2010)
Broadcast media: no terrestrial TV service avail-
able; subscription cable TV provider offers some
locally produced programming plus channels from
the US, Latin America, and the Caribbean; state-
operated radio broadcasts on 6 stations; privately
owned radio broadcasts on about 15 stations (2007)
Internet country code: .dm
Internet hosts: 723 (2012)
country comparison to the world: 175
Internet users: 28,000 (2009)
country comparison to the world: 183','b8a9920f523dad321e250588ed67ec543099758407c9b5e2df6febfe69a09494','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2cf421df85fb9c2f8384ee845039a18374e334a3d49461d16d6d767897856c9a',2025,'DO','Dominican Republic','communications',531,'Telephones—main lines in use: 1.044 million
(2011)
country comparison to the world: 76
Telephones—mobile cellular: 8.77 million
(2011)
country comparison to the world: 83
Telephone system: general assessment: rela-
tively efficient system based on island-wide micro-
wave radio relay network E
domestic: fixed-line teledensity is about 10 per
100 persons; multiple providers of mobile-cellular
service with a subscribership of nearly 90 per 100
persons
international: country code—1-809; landing
point for the Americas Region Caribbean Ring
System (ARCOS-1), Antillas 1, and the Fibralink
submarine cables that provide links to South and
Central America, parts of the Caribbean, and
US; satellite earth station—] Intelsat (Atlantic
Ocean) (2011)
Broadcast media: combination of state-owned
and privately owned broadcast media; 1 state-
owned TV network and a number of private TV
networks; networks operate repeaters to extend
signals throughout country; combination of state-
owned and privately owned radio stations with
more than 300 radio stations operating (2007)
Internet country code: .do
Internet hosts: 404,500 (2012)
country comparison to the world: 55
Internet users: 2.701 million (2009)
country comparison to the world: 68','51bc45421dfc123504e853093da8868eb02bd00364722d7808cd2cd1ecd50e6d','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f4609403ea6a56b3c14f7f86c393d4e79c42a50e173fb1c39d316f07fd8292e3',2025,'EC','Ecuador','communications',536,'Telephones—main lines in use: 2.211 million
(2011)
country comparison to the world: 56
Telephones—mobile cellular: 15.333 million (2011)
country comparison to the world: 54
Telephone system: general assessment: elemen-
tary fixed-line service, but increasingly sophisti-
cated mobilecellular network
domestic: fixed-line services provided by multiple
telecommunications operators; fixed-line teleden-
sity stands at about 15 per 100 persons; mobile-cel-
lular use has surged and subscribership has reached
100 per 100 persons
international: country code—593; landing points
for the PAN-AM and South America-1 submarine
cables that provide links to the west coast of South
America, Panama, Colombia, Venezuela, and
extending onward to Aruba and the US Virgin
Islands in the Caribbean; satellite earth station—1
Intelsat (Atlantic Ocean) (2011)
Broadcast media: Ecuador has multiple TV net-
works and many local channels, as well as more
than 300 radio stations; many TV and radio sta-
tions are privately owned; the government owns
or controls 5 national TV stations and multiple
radio stations; broadcast media required by law to
give the government free air time to broadcast pro-
grams produced by the state (2007)
Internet country code: .ec
Internet hosts: 170,538 (2012)
country comparison to the world: 76
Internet users: 3.352 million (2009)
country comparison to the world: 64','0d30c4e0e39851bb2e2048c72609aaf8c37327daee1251bc86163c778172cdeb','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('87d88de9668686252f690053f0bd74a556038e5beb3b04a17f6bfea0ec4036d1',2025,'EG','Egypt','communications',547,'Telephones—main lines in use: 8.714 million
(2011)
country comparison to the world: 23
Telephones—mobile cellular: 83.425 million
(2011)
country comparison to the world: 16
Telephone system: general assessment: under-
went extensive upgrading during 1990s; princi-
pal centers at Alexandria, Cairo, Al Mansurah,
Ismailia, Suez, and Tanta are connected by coaxial
cable and microwave radio relay
domestic: largest fixed-line system in the region;
as of 2011 there were multiple mobile-cellular
networks with a total of roughly 83 million
subscribers
international: country code—20; landing point
for Aletar, the SEA-ME-WE-3 and SEA-ME-
WE-4 submarine cable networks, Link Around the
Globe (FLAG) Falcon and FLAG FEA; satellite
earth stations—4 (2 Intelsat—Atlantic Ocean and
Indian Ocean, 1 Arabsat, and 1 Inmarsat); tropo-
spheric scatter to Sudan; microwave radio relay to
Israel; a participant in Medarabtel (2011)
Broadcast media: mix of state-run and private
broadcast media; state-run TV operates 2 national
and 6 regional terrestrial networks as well as a
few satellite channels; about 20 private satellite
channels and a large number of Arabic satellite
channels are available via subscription; state-run
radio operates about 70 stations belonging to 8
networks; 2 privately owned radio stations opera-
tional (2008)
Internet country code: .eg
Internet hosts: 200,430 (2012)
country comparison to the world: 71
Internet users: 20.136 million (2009)
country comparison to the world: 21','c7c99534d7d572d61d84a5056bf5315e0beab91fd516d8d6337b043ae4eaabe5','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c8e7a2fc62097f3800a73967a1e72992307c72f46cfb33d5e62db42d382ac289',2025,'SV','El Salvador','communications',559,'Telephones—main lines in use: 1.03 million
(2011)
country comparison to the world; 77
Telephones—mobile cellular: 8.316 million
(2011)
country comparison to the world: 86
Telephone system: general assessment: mul-
tiple mobile-cellular providers are expanding
THE CIA WORLD FACTBOOK
services rapidly and in 2011 teledensity exceeded
135 per 100 persons; growth in fixed-line ser-
vices has slowed in the face of mobile-cellular
competition
domestic: nationwide microwave radio relay
system
international: country code—503; satellite earth
station—1 Intelsat (Atlantic Ocean); connected
to Central American Microwave System (2011)
Broadcast media: multiple privately owned
national terrestrial TV networks, supplemented
by cable TV networks that carry international
channels; hundreds of commercial radio broadcast
stations and 1 government-owned radio broadcast
station (2007)
Internet country code: sv
Internet hosts: 24,070 (2012)
country comparison to the world: 113
Internet users: (2009)
country comparison to the world: 107','06820ecb2268a5846fa4493cbc4a1c7b216a6936a0bacb79769404ae123f2632','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3f4113bd2b52cb8a8d1ac4eb80a21622eb11ebc0fb74d8c92163c26b4bf74f34',2025,'GQ','Equatorial Guinea','communications',565,'Telephones—main lines in use: 13,500 (2010)
country comparison to the world: 198
Telephones—mobile cellular: 426,000 (2011)
country comparison to the world: 169
Telephone system: general assessment: digital
fixed-line network in most major urban areas and
good mobile coverage
domestic: fixed-line density is about 2 per 100
persons; mobile-cellular subscribership has been
increasing and in 2011 stood at about 60 percent
of the population
international: country code—240; international
communications from Bata and Malabo to African
and European countries; satellite earth station—I
Intelsat (Indian Ocean) (2011)
Broadcast media: state maintains control of
broadcast media with domestic broadcast media
limited to 1 state-owned TV station, | state-
owned radio station, and 1 private radio station
owned by the president''s eldest son; satellite TV
service is available; transmissions of multiple
international broadcasters are accessible (2007)
Internet country code: .gq
Internet hosts: 7 (2012)
country comparison to the world: 228
Internet users: 14,400 (2009)
country comparison to the world: 200','91387819b3f94777e51f5ef6ff12a747bbb7f19bce1ef87109b837e8fec4bae2','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('86dbdfdcc2304680676448f9a1d208a227d648970176e590b94471c2c7b706d1',2025,'ET','Ethiopia','communications',573,'Telephones—main lines in use: 58,500 (2011)
country comparison to the world: 159
Telephones—mobile cellular: 241,900 (2011)
country comparison to the world: 175
Telephone system: general assessment: inad-
equate; most fixed-line telephones are in Asmara;
government is seeking international tenders to
improve the system; cell phones in increasing use
throughout the country
domestic: combined fixed-line and mobile-cellular
subscribership is less than 5 per 100 persons
international: country code—291 (2011)
Broadcast media: government controls broad-
cast media with private ownership prohibited; 1
state-owned TV station; state-owned radio oper-
ates 2 networks; purchases of satellite dishes and
subscriptions to international broadcast media are
permitted (2007)
Internet country code: .er
Internet hosts: 701 (2012)
country comparison to the world: 177
Internet users: 200,00 (2008)
country comparison to the world: 140
Telephones—main lines in use: 829,000 (2011) `
country comparison to the world: 86
Telephones—mobile cellular: 14.127 million (2011)
country comparison to the world: 56
Telephone system: general assessment: inad-
equate telephone system with the Ethio Telecom
maintaining a monopoly over telecommunica-
tion services; open-wire, microwave radio relay;
radio communication in the HE VHF and UHF
frequencies; 2 domestic satellites provide the
national trunk service
domestic: the number of fixed lines and mobile
telephones is increasing from a small base; com-
bined fixed and mobile-cellular teledensity is
roughly 15 per 100 persons
238
THE CIA WORLD FACTBOOK
international: country code—251; open-wire
to Sudan and Djibouti; microwave radio relay to
Kenya and Djibouti; satellite earth stations—3
Intelsat (1 Atlantic Ocean and 2 Pacific Ocean)
(2011)
Broadcast media: 1 public TV station broadcast-
ing nationally and 1 public radio broadcaster with
stations in each of the 13 administrative districts; a
few commercial radio stations and roughly a dozen
community radio stations (2009)
Internet country code: .et
Internet hosts: 179 (2012)
country comparison to the world: 204
Interne? users: 447,300 (2009)
country comparison to the world: 119
Telephones—main lines in use: 226 million (2011)
Telephones—mobile cellular: 629 million (2011)
Telephone system: note—see individual country
entries of member states
internet country code: .cu; note—see country
entries of member states for individual country
codes
Internet hosts: 201,116; note—this sum reflects
the number of Internet hosts assigned the .eu
Internet country code (2012)
internet users: 340 million (2009)
Telephones—main lines in use: 2,000 (2010)
country comparison to the world: 217
Telephones—mobile cellular: 3,300 (2011)
country comparison to the world: 215
Telephone system: domestic: government-oper-
ated radiotelephone and private VHF/CB radio-
telephone networks provide effective service to
almost all points on both islands
international: country code—500; satellite earth
station—1 Intelsat (Atlantic Ocean) with links
through London to other countries (2011)
Broadcast media: TV service provided by a
multi-channel service provider; radio services pro-
vided by the public broadcaster, Falkland Islands
Radio Service, broadcasting on both AM and FM
frequencies, and by the British Forces Broadcasting
Service (BFBS) (2007) i
internet country code: .fk
Internet hosts: 110 (2012)
country comparison to the world: 207
Internet users: 2,900 (2009)
country comparison to the world: 209','644fb09a4b5e13ad1669f1791d07fe5cc5a04b0ff3ba20ed41d8568f844682ce','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('99a6068a26776b452f93dbad1101421579d7c5ee2221e891694607cb86ebfe65',2025,'EE','Estonia','communications',583,'Telephones—main lines in use: 471,900 (2011)
country comparison to the world; 101
Telephones—mobile cellular: 1.863 million
(2011)
country comparison to the world: 142
Telephone system: general assessment: foreign
investment in the form of joint business ventures
greatly improved telephone service with a wide
range of high quality voice, data, and Internet ser-
vices available
domestic: substantial fiber-optic cable systems
carry telephone, TV, and radio traffic in.the digital
mode Internet services are widely available schools
and libraries are connected to the Internet, a large
percentage of the population files_income-tax
returns online, and online voting was used for the
first time in the 2005 local elections
international: country code—372; fiber-optic
cables to Finland, Sweden, Latvia, and Russia pro-
vide worldwide packet-switched service; 2 interna-
tional switches are located in Tallinn (2011)
Broadcast media: the publicly owned broad-
caster, Eesti Rahvusringhaaling (ERR), operates 2
TV channels and 5 radio networks; growing num-
ber ‘of private commercial radio stations broad-
casting nationally, regionally, and locally; fully
transitioned to digital television in 2010; national
ptivate TV channels expanding service; a range of
channels are aimed at Russian-speaking viewers;
high penetration rate for cable TV services with
more than half of Estonian households connected
(2008)
Internet country code: .cc
Internet hosts: 865,494 (2012)
country comparison to the world: 49
Internet users: 971,700 (2009)
country comparison to the world: 102','fecab09adf7f8f6cdb069b88bf9159842fe4531a9df41053ee99b65c6a33f15b','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('23a420f0e9ba760ed9cc626d74b9f87fe37cd7d4d43bdeb766371aaaed53d450',2025,'FO','Faroe Islands','communications',600,'Telephones—main lines in use: 20,200 (2009)
country comparison to the world: 189
Telephones—mobile cellular: 59,400 (2009)
country comparison to the world: 198
Telephone system: general assessment: good
international communications; good domestic
facilities
domestic: conversion to digital system completed
in 1998; both NMT (analog) and GSM (digital)
mobile telephone systems are installed
international: country code—298; satellite earth
stations—1 Orion; 1 fiber-optic submarine cable
to the Shetland Islands, linking the Faroe Islands
THE CIA WORLD FACTBOOK
with Denmark and Iceland; fiber-optic submarine
cable connection to Canada-Europe cable (2011)
Broadcast media: 1 publicly owned TV station;
the Faroese telecommunications company distrib-
utes local and international channels through its
digital terrestrial network; publicly owned radio
station supplemented by 2 privately owned sta-
tions broadcasting over multiple frequencies
(2008)
Internet country code: .fo
Internet hosts: 7,575 (2012)
country comparison. to the world: 140
Internet users: 37,500 (2009)
country comparison to the world: 176','46fc2fcfc7e81fa3ca7d2e8ccf81184909ac594d5af4dafbad4adc4fdf838592','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ac40b5cb06adf3b3abb983bac37ffcb2848659b537545a39fe1c09133bb2b3e4',2025,'FJ','Fiji','communications',607,'Telephones—main lines in use: 129,800 (2011)
country comparison to the world: 142
Telephones—mobile cellular: 727,000 (2011)
country comparison to the world: 160 _
Telephone system: general assessment: modern
local, interisland, and international (wire/radio
integrated) public and special-purpose telephone,
telegraph, and teleprinter facilities; regional radio
communications center
domestic: telephone or radio telephone links to
almost all inhabited islands; most towns and large
villages have automatic telephone exchanges and
direct dialing; combined fixed and mobilecellular
teledensity roughly 100 per 100 persons
international: country code—679; access to
important cable links between US and Canada as
well as between NZ and Australia; satellite earth
stations—2 Inmarsat (Pacific Ocean) (2011)
Broadcast media: Fiji TV, a publicly raded company,
operates a free-to-air channel as well as Sky Fiji and
Sky Pacific multi-channel pay-TV services; state-
owned commercial company, Fiji Broadcasting Corpo-
ration, Ltd, operates 6 radio stations—2 public broad-
casters and 4 commercialvbroadcasters with multiple
repeaters; 5 radio stations with repeaters operated by
Communications Fiji, Ltd; transmissions of multiple
international broadcasters are available (2009)
internet country code: fj
Internet hosts: 21,739 (2012)
country comparison to the world: 115
Internet users: 114,200 (2009)
country comparison to the world: 157','b7f2b7a241b9690037e6446232922a35af69bd540507a539b6f2b20bbf125fc3','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8e3322943e26c06ee7621f01ae1d7937766025ad2990a4f04798c3987b8ab9f6',2025,'FI','Finland','communications',614,'Telephones—main lines in use: 1.08 million
(2011)
country comparison to the world: 73
Telephones—mobile callular: 8.94 million (2009)
country comparison to the world: 82
Telephone system: general assessment: modern
system with excellent service
domestic: digital fiber-optic fixed-line network
and an extensive mobile-cellular network provide
domestic needs
international: country code—358; submarine
cables provide links to Estonia and Sweden; sat-
ellite earth stations—access to Intelsat transmis-
sion service via a Swedish satellite earth station,
1 Inmarsat (Atlantic and Indian Ocean regions);
note—Finland shares the Inmarsat earth station
with the other Nordic countries (Denmark, Ice-
land, Norway, and Sweden) (2011)
Broadcast media: a mix of publicly operated TV
stations and privately owned TV stations; the 2
publicly owned TV stations recently expanded
services and the largest private TV station has
introduced several special-interest pay-TV chan-
nels; cable and satellite multi-channel subscription
services are available; all TV signals have been
broadcast digitally since September 2007; analog
broadcasts via cable networks were terminated in
February 2008; public broadcasting maintains a net-
work of 13 national and 25 regional radio stations;
a large number of private radio broadcasters (2008)
Internet country code: .fi; note—Aland Islands
assigned .ax
Internet hosts: 4.763 million (2012)
country comparison to the world: 22
Internet users: 4.393 million (2009)
country comparison to the world: 55','769110a4228f9227fdc9aaed82e1bac6abc35240ac530aa8e4b21b21c5eb3f16','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6969ac25e0ccef34e89b438e06c4a5f9f32f382db86c9734df122052bb79026e',2025,'FR','France','communications',623,'Telephones—main lines in use: 39.883 million
(2011)
country comparison to the world: 7
Telephones—mobile cellular: 59.84 million
(2011)
country comparison to the world: 21
Telephone system: general assessment: highly
developed
domestic: extensive cable and microwave radio
relay; extensive use of fiber-optic cable; domestic
satellite system l
international: country code—33; numerous sub-
marine cables provide links throughout Europe,
Asia, Australia, the Middle East, and US; satel-
lite earth stations—more than 3 (2 Intelsat (with
total of 5 antennas—2 for Indian Ocean and 3
for Atlantic Ocean), NA Eutelsat, 1 Inmarsat—
Atlantic Ocean region); HF radiotelephone com-
munications with more than 20 countries overseas
departments: country codes: French
Guiana—594; Guadeloupe—590; Martinique
—596; Mayotte—262; Reunion—262 (2011)
Broadcast media: a mix of both publicly oper-
ated and privately owned TV stations; state-
owned France Televisions operates 4 networks,
one of which is a network of regional stations,
and has part-interest in several thematic cable/
satellite channels and international channels; a
large number of privately owned regional and local
TV stations; multi-channel satellite and cable
services provide a large number of channels; pub-
lic broadcaster Radio France operates 7 national
networks, a series of regional networks, and oper-
ates services for overseas territories and foreign
audiences; Radio France Internationale (RFI),
under the Ministry of Foreign Affairs, is a leading
international broadcaster; a large number of com-
mercial FM stations, with many of them consoli-
dating into commercial networks (2008)
Internet country code: metropolitan France—.
fr; French Guiana—.gf; Guadeloupe—.gp; Marti-
nique—.mq; Mayotte—.yt; Reunion—.re
Internet hosts: 17.266 million (2012)
country comparison to the world: 7
Internet users: 45.262 million; 44.625 million
(metropolitan France) (2009)
country comparison to the world: 8
Telephone system: general assessment: fully
integrated access
domestic: direct dial capability with both fixed
and wireless systems Š
international: country code—590;
sea fiber-optic cable provides voice and data
connectivity to Puerto Rico and Guadeloupe
(2008)
under-
THE CIA WORLD FACTBOOK
Broadcast media: no local TV broadcasters; 3
FM radio channels (2 via repeater)
Internet country code: .bl; note—.gp, the Internet
country code for Guadeloupe, and.fr, the Internet
country code for France, might also be encountered
Telephones—main lines in use: 3,000 (2011)
country comparison to the world: 215
Telephone system: general assessment: can
communicate worldwide
domestic: automatic digital network
international: country code (Saint Helena) —290,
(Ascension Island) —247;
dialing; satellite voice and data communications;
satellite earth stations—5 {Ascension Island—4,
Saint Helena—t) (2010)
Broadcast media: St. Helena has no local TV
station; 2 local radio stations, one of which is
international direct
relayed to Ascension Island; satellite TV sta-
tions rebroadcast terrestrially; Ascension Island
has no local TV station but has 1 local radio
station and receives relays of broadcasts from
1 radio station on St. Helena; broadcasts from
the British Forces Broadcasting Service (BFBS)
are available, as well as TV services for the US
military; Tristan da Cunha has 1 local radiosta-
tion and receives BFBS TV and radio broadcasts
(2007)
Internet country code: sh; note—Ascension
Island assigned.ac
Internet hosts: 6,729 (2012)
country comparison to the world: 141
Internet users: 900 (2009)
country comparison to the world: 215
Communications—note: South Africa maintains
a meteorological station on Gough Island
Telephone system: general assessment: fully
integrated access
domestic: direct dial capability with both fixed
and wireless systems
international: country code—590;
fiber-optic cable provides voice and data connec-
tivity to Puerto Rico and Guadeloupe (2009)
Broadcast media: 1 local TV station; access to
about 20 radio stations, including RFO Guade-
loupe radio broadcasts via repeater (2008)
Internet country code: mf; note-.gp, the Inter-
net country code for Guadeloupe, and.fr, the
Internet country code for France, might also be
encountered','67d9ed23c707b3876700dccdfd378b2ca6da7be0e3d1dab27c4a9ab1fe0b5000','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4e33d14b92c81479791f90b08e64d99c1c8561aab72a6ad88bd7a9d41eb5fe26',2025,'PF','French Polynesia','communications',631,'Telephones—main lines in use: (2011)
country comparison to the world: 162
Telephones—mobile cellular: 222,800 (2011)
country comparison to the world: 177
Telephone system: domestic: combined fixed
and mobile-cellular density is roughly 100 per 100
persons
international: country code—6839; satellite earth
station—1 Intelsat (Pacific Ocean) (2011)
Broadcast media: the publicly owned French
Overseas Network (RFO), which operates in
France’s overseas departments and territories,
broadcasts on 2 TV channels and 1 radio station; 1
government-owned TV station; a small number of
privately-owned radio stations (2008)
internet country code: .pf
Internet hosts: 37,949 (2012)
country comparison to the world: 103
Internet users: (2009)
country comparison to the world: 153','351a6e95049969ea47064d536c86638a961bfeb523385a9cfcf35b36b42cf216','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0a521b24c85f3eb39d08ca1961d8004d23d4c5ffc2c5f88c04fffafbfd00f628',2025,'GA','Gabon','communications',641,'Telephones—main lines in use: 22,500 (2011)
country comparison to the world: 187
Telephones—mobiie cellular:
(2011)
country comparison to the world: 145
Telephone system: general assessment: ade-
quate system of cable, microwave radio relay,
tropospheric scatter, radiotelephone communica-
tion stations, and a domestic satellite system with
12 earth stations
domestic: a growing mobile-cellular network with
multiple providers is making telephone service
more widely available with mobile-cellular tel-
edensity exceeding 100 per 100 persons
international: country code—241; landing point
for the SAT-3/WASC fiber-optic submarine cable
thar provides connectivity to Europe and Asia; sat-
ellite earth stations—3 Intelsat (Atlantic Ocean)
(2011)
Broadcast media: stare owns and operates 2
TV stations and 2 radio broadcast stations; a few
private radio and TV stations; transmissions of at
least 2 international broadcasters are accessible;
satellite service subscriptions are available (2007)
Internet country code: .ca
imernet hosts: 127 (2012)
country comparison to the world: 206
Internet users: 98,800 (2009)
country comparison to the world: 160
1.8 million
267','2c11aec4149c2de2c8108aeeaa8295451f5c070557997dd63b4a93a66919c998','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0e8062e32f7b6395ecc409f0ad30e075474818c087e31fb8337b0c32ab847405',2025,'SN','Senegal','communications',652,'Telephones—main lines in use: 50,400
(2011) j
country comparison to the world: 163
Telephones—mobile cellular:
(2011)
country comparison to the world: 147
1.4 million
Telephone system: general assessment: ade-
quate microwave radio relay and open-wire net-
work; state-owned Gambia Telecommunications
partially privatized in 2007
domestic: combined fixed-line and mobile-cellular
teledensity, aided by multiple mobile-cellular pro-
viders, is roughly 80 per 100 persons
international: country code—220; microwave
tadio relay links to Senegal and Guinea-Bissau;
a landing station for the Africa Coast to Europe
(ACE) undersea fiber-optic cable is scheduled
for completion in 2011; satellite earth station—1
Intelsat (Atlantic Ocean) (2011)
Broadcast media: state-owned, single-channel
TV service; state-owned radio station and 4 pri-
vately owned radio stations; transmissions of
multiple international broadcasters are available,
some via shortwave radio; cable and satellite TV
subscription services are obtainable in some parts
of the country (2007)
Internet country code: .gm
Internet hosts: 656 (2012)
country comparison to the world: 179
Internet users: (2009)
country comparison to the world: 150
GAMBIA, THE
Telephones—main lines
(includes West Bank) (2010)
country comparison to the world: 113
Telephones—mobile cellular: 2.405 million
(includes West Bank) (2010)
country comparison to the world: 131
Telephone system: general assessment: Gaza
continues to repair the damage to its telecommu-
nications infrastructure caused by fighting in 2009
domestic: Israeli company BEZEK and the Pales-
tinian company PALTEL are responsible for fixed-
line services; the Palestinian JAWWAL company
provides cellular services
international: country code—970 (2009)
Broadcast media: 1 TV station and about 10
radio stations (2008)
Internet country code: .ps; note—same as West Bank
Internet users: 1.379 million (includes West
Bank) (2009)
country comparison to the world: 87
in use:, 337,000
Telephones—main lines in use: 346,400 (2011)
country comparison to the world: 110
640
THE CiA WORLD FACTBOOK
Telephones—mobile cellular: 9.353 million
(2011)
country comparison to the world: 79
Telephone system: general assessment: good sys-
tem with microwave radio relay, coaxial cable and
fiber-optic cable in trunk system
domestic: above-average urban system with a
fiber-optic network; nearly two-thirds of all fixed-
line connections are in Dakar where a call-center
industry is emerging; expansion of fixed-line ser-
vices in rural areas needed; mobile-cellular service
is expanding rapidly
international: country code—221; the SAT-3/
WASC fiber-optic cable provides connectiv-
ity to Europe and Asia while Atlantis-2 pro-
vides connectivity to South America; satel-
lite earth station—Intelsat (Atlantic Ocean)
(2010)
Broadcast media: state-run Radiodiffusion Tel-
evision Senegalaise (RTS) operates 2 TV stations;
a few private TV subscription channels rebroad-
cast foreign channels without providing any local
news or programs; ris operates a national radio
network and a number of regional fm stations;
many community and private-broadcast radio
stations are available; transmissions of at least 2
international broadcasters are accessible on FM in
Dakar (2007)
Internet country code: .sn
Internet hosts: 237 (2012)
country comparison to the World: 198
Internet users: 1.818 million (2009)
countrycomparison to the world: 76','fca8e831fb0266c9502b0310b8616aac9b6aa9dd31df4079f93e23cd2551dd00','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a9f6d98b16816ca55288f28e2e40510ea1d9f1fe6182e37422a4f2e15408ba76',2025,'GE','Georgia','communications',657,'Telephones—main lines in use: 1.345 million
(2011)
country comparison to the world: 67
Telephones—mobile cellular: 4.43 million
(2011)
country comparison to the world: 113
Telephone system: general assessment: fixed-
lihe telecommunications network has limited
coverage outside Tbilisi; multiple mobile-cellular
providers provide services to an increasing sub-
scribership throughout the country
domestic: cellular telephone networks cover
the entire country; mobile-cellular teledensity
roughly 100 per 100 people; intercity facilities
include a fiber-optic line between T’bilisi and
K''ut''aisi
international: country code—995; the Geor-
gia-Russia fiber-optic submarine cable provides
connectivity to Russia; international service
is available by microwave, landline, and satel-
lite through the Moscow. switch; international
electronic mail and telex service are available
(2011)
Broadcast media: 1 public broadcaster in Tbilisi,
1 state-owned broadcaster in Ajaria Autonomous
Republic; 8 privately owned TV stations; state run
public broadcaster operates 2 TV stations; dozens
of cable TV operators, several major commercial
TV stations, and several dozen private radio sta-
tions; state run public broadcaster operates 2 radio
stations (2012)
Internet country code: .ge
Internet hosts: 357,864 (2012)
country comparison to the world: 59
Internet users: 1.3 million (2009)
country comparison to the world: 90','c8f652dddc109fec7d3d8f5df6ca5f9dec3bac831c4eaca5d6f8b6f4841e7f6c','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2c64b4b764208d6c04ae8e56a06072a07fb75240c5b9f1175fd26ae9308ef209',2025,'DE','Germany','communications',667,'Telephones—main lines in use: 51.8 million
(2011)
country comparison to the world: 4
Telephones—mobile cellular: 108.7 million
(2011)
country comparison to the world: 10
Telephone system: general assessment: Ger-
many has one of the world’s most technologically
advanced telecommunications systems; as a result
of intensive capital expenditures since reunifica-
tion; the formerly backward system of the eastern
part of the country, dating back to World War II,
has been modernized and integrated with that of
the western part
domestic: Germany is served by an extensive sys-
tem of automatic telephone exchanges connected
by modern networks of fiber-optic cable, coaxial
cable, microwave radio relay, and a domestic sat-
ellite system; cellular telephone service is widely
available, expanding rapidly, and includes roaming
service to many foreign countries
international: country code—49; Germany''s
international service is excellent worldwide,
consisting of extensive land and undersea cable
facilities as well as earth stations in the Inmarsat,
Intelsat, Eutelsat, and Interspurnik satellite sys-
tems (2011)
Broadcast media: a mixture of publicly
operated and privately owned TV and radio
stations; national and regional public broad-
casters compete with nearly 400 privately
owned national and regional TV stations; more
than 90% of households have cable or satellite
TV; hundreds of radio stations including mul-
tiple national radio networks, regional radio
networks, and a large number of local radio
stations (2008)
Internet country code: .de
Internet hosts: 20.043 million (2012)
country comparison to the world: 6
Internet users: 65.125 million (2009)
country comparison to the world: 5','974e2c9e2b290967052e3cfa26a9a7b38429305524192aa65b64d2ee8f71e5fc','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a1ec70b123d50ed66a563c0473e7f7d8918e57492a086681db91d7628a4a6d2e',2025,'GH','Ghana','communications',676,'Telephones—main lines in use: 284,700 (2011)
country comparison to the world: 119
Telephones—mobile’ cellular: 21.166 million
(2011)
country comparison to the world: 46
Telephone system: general assessment: primar-
ily microwave radio relay; wireless local loop has
been installed; outdated and unreliable fixed-line
infrastructure heavily concentrated in Accra
domestic: competition among multiple mobile-
cellular providers has spurred growth with a sub-
scribership of more than 80 per 100 persons and
rising
international: country code—233; landing point
for the SAT-3/WASC, Main One, and GLO-1
fiber-optic submarine cables that provide con-
nectivity to South Africa, Europe, and Asia; sat-
ellite earth stations—4 Intelsat (Atlantic Ocean);
microwave radio relay link to Panaftel system con-
nects Ghana to its neighbors (2009)
Broadcast media: state-owned TV station, 2
state-owned radio networks; several privately
owned TY stations and a large number of privately
owned radio stations; transmissions of multiple
international broadcasters are accessible; several
cable and satellite TV subscription services are
obtainable (2007)
Internet country code: igh
Internet hosts: 59,086 (2012)
country comparison to the world: 93
internet users: 1.297 million (2009)
country comparison to the world: 93','f6f60830c76eed576b4de1c4f74070e03414469be4313488d025bd7524bb4f07','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7cf4c27467af3fbf7bb302225218735b3f1a9323edd21490fc16b6513a4ed6aa',2025,'ES','Spain','communications',685,'Telephones—main lines in use: 24,000 (2010)
country comparison to the world: 184
Telephones—mobile cellular: 32,500 (2010)
country comparison to the world: 205
Telephone system: general assessment: ade-
quate, automatic domestic system and adequate
international facilities
domestic: automatic exchange facilities
international: country code—350; radiotel-
ephone; microwave radio relay; satellite earth sta-
tion—I Intelsat (Atlantic Ocean)
Broadcast media: Gibraltar Broadcasting Corpo-
ration (GBC) provides TV and radio broadcasting
services via 1 TV station and 4 radio stations; Brit-
ish Forces Broadcasting Service (BFBS) operates 1
radio station; broadcasts from Spanish radio and
TV stations are accessible (2008)
Internet country code: gi
Internet hosts: 3,509 (2012)
Telephones—main lines in use: 19.867 million
(2011)
country comparison to the world: 14
Telephones—mobile cellular: 52.598 million
(2011)
country comparison to the world: 26
Telephone system: general assessment: well-
developed, modern facilities; fixed-line teledensity
exceeds 40 per 100 persons
domestic: combined fixed-line and mobile-cel-
lular teledensity exceeds 150 telephones per 100
persons
international: country code—34; submarine
cables provide connectivity to Europe, Middle
East, Asia, and US; satellite earth stations—2
Intelsat (1 Atlantic Ocean and 1 Indian Ocean),
NA Eutelsat; tropospheric scatter ‘to adjacent
countries (2011)
Broadcast media: a- mixture of both publicly
operated and privately owned TV and radio sta-
tions; overall, hundreds of TV channels are avail-
able including national, regional, local, public,
and international channels; satellite and cable
TV systems available; multiple national radio net-
works, a large number of regional radio networks,
and a larger number of local radio stations; overall,
hundreds of radio stations (2008)
internet country code:.cs
Internet hosts: 4.228 million (2012)
country comparison to the world: 26
Internet users: 28.119 million (2009)
country comparison to the world: 14','588f1acab35d32ab42e01bd1808d4cbe1abf5a9b5e00b8a34659c4fba5e2d24f','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0758829b1f9ecd8ec9e5da92a491588d939bd3838c03063f5edc3f41c1fd41b2',2025,'GI','Gibraltar','communications',686,'country comparison to the world: 151
Internet users: 20,200 (2009)
country comparison to the world: 193','8d115263225c76a419c026f0c433e5a48fb591a7c14de7b5d94faa23a48cadbb','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('07e5e02474cfcfc3315031edc00f4b690c93775b5eaf7f14d0b6efe88b22e670',2025,'GR','Greece','communications',697,'Telephones—moain tines in use: 5.745 million (2011)
country comparison to the world: 29
Telephones—mobile cellular: 12.128 million (2011)
country comparison to the world: 65
Telephone system: general assessment: ade-
quate, modern networks reach all areas; good
mobile telephone and international service
domestic: microwave radio relay trunk system;
extensive open-wire connections; submarine cable
to offshore islands
international: country code—30; landing point
for the SEA-ME-WE-3 optical telecommuni-
cations submarine cable that provides links to
Europe, Middle East, and Asia; a number of smaller
submarine cables provide connectivity to various
parts of Europe, the Middle East, and Cyprus;
tropospheric scatter; satellite earth stations—4 (2
Intelsat—I Atlantic Ocean and 1 Indian Ocean,
1 Eutelsat, and 1 Inmarsat—Indian Ocean region)
Broadcast media: broadcast media dominated
by the private sector; roughly 150 private TV
channels, about a dozen of the private channels
broadcast at the national or regional level; 3 pub-
licly owned terrestrial TV channels with national
coverage, 1 publicly owned satellite channel, and
3 stations designed for digital terrestrial transmis-
sions; multi-channel satellite and cable TV ser-
vices available; upwards of 1,500 radio stations,
nearly all of them privately owned; state-run
broadcaster has 7 national stations, 2 international
stations, and 19 regional stations (2007)
Internet country code: gr
Internet hosts: 3.201 million (2012)
country comparison to the world: 32
Internet users: 4.971 million (2009)
country comparison to the world: 46','5495a241f2c38cc28ca1158d6552cf40914049ecd0e62574a5224fc619576d83','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8110a85a8f7e30c5a2eb9d9ab0341e616ac8e17df57ff712e708c3e4b7292006',2025,'GL','Greenland','communications',702,'Telephones—main lines in use: 19,900 (2011)
country comparison to the world: 190
Telephones—mobile cellular: 58,700 (2011)
country comparison to the world: 199
Telephone system: general assessment: ade-
quate domestic and international service provided
by satellite, cables and microwave radio relay;
totally digital since 1995
domestic: microwave radio relay and satellite
international: country code—299; satellite earth
stations—15 (12 Intelsat, 1 Eutelsat, 2 Americom
GE-2 (all Atlantic Ocean)) (2000)
Broadcast media: the Greenland Broadcasting
Company provides public radio and TV services
throughout the island with a broadcast station and
a series of repeaters; a few private local TV and
radio stations; Danish public radio rebroadcasts are
available (2007)
Internet country code: gl
Internet hosts: 15,645 (2012)
country comparison to the world: 123
293
Internet users: 36,000 (2009)
country comparison to the world: 178','de58b066dba044e2945032382eece451ed7216e84ceac03b388fdd3497a5baf6','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b36234f28980c58c98919dac02abb2bcb9b856e85a1367dc995a7e5febb2e7cb',2025,'GD','Grenada','communications',707,'Telephones—main lines in use: 28,400 (2010)
country comparison to the world: 179
Telephones—mobile cellular: 121,900 (2010)
country comparison to the world: 188
Telephone system: general assessment: auto-
matic, island-wide telephone system
domestic: interisland VHF and UHF radiotel-
ephone links
international: country code—1-473; landing point
for the East Caribbean Fiber Optic System (ECFS)
submarine cable with links to 13 other islands in the
eastern Caribbean extending from the British Vir-
gin Islands to Trinidad; SHF radiotelephone links to
Trinidad and Tobago and Saint Vincent; VHF and
UHF radio links to Trinidad (2009)
Broadcast media: the Grenada Broadcasting
Network, jointly owned by the government and
the Caribbean Communications Network of Trini-
dad and Tobago, operates a TV station and 2 radio
stations; multi-channel cable TV subscription ser-
vice is available; a dozen private radio stations also
broadcast (2007)
Internet country code: .gd
Internet hosts: 80 (2012)
country comparison to the world: 213
Internet users: 25,000 (2009)
country comparison to the world: 186
Telephones—main lines in use: 65,500 (2010)
country comparison to the world: 158
Telephones—mobile cellular: 98,000 (2004)
country comparison to the world: 192
Telephone system: general assessment: modem
system, integrated with US facilities for direct dial-
ing, including free use of 800 numbers
domestic: digital system, including mobile-cellular
service and local access to the Internet
international: country code—1-671; major landing
point for submarine cables between Asia and the
US (Guam is a transpacific communications hub
for major carriers linking the US and Asia); satellite
earth stations—2 Intelsat (Pacific Ocean) (2011)
Broadcast media: about a dozen TV channels,
including digital channels; multi-channel cable
TV services are available; roughly 20 radio stations
(2009)
Internet country code: .gu
Internet hosts: 23 (2012)
country comparison to the world: 220
Internet users: 90,000 (2009)
country comparison to the world: 163','b7cb5316ad3d7ee590b684b0117ab372151d49a4763a9bf4bf9a25f65c7b432e','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('092364811114a89bf8dbec7b7178758c89313380810ac60bebcfc78562bbf58a',2025,'GT','Guatemala','communications',716,'Telephones—main lines in use: 1.626 million
(2011)
country comparison to the world: 65
Telephones—mobile ceilular: 20.716 million
(2011)
country comparison to the world: 47
Telephone system: general assessment:
fairly modern network centered in the city of
domestic: state-owned telecommunications com-
pany privatized in the late 1990s opening the way
for competition; fixed-line teledensity roughly 10
per 100 persons; fixed-line investments are being
concentrated on improving rural connectivity;
mobile-cellular teledensity approaching 150 per
100 persons
international: country code—502; landing point
for both the Americas Region Caribbean Ring
System (ARCOS-1) and the SAM-1 fiber optic
‘submarine cable system that together provide con-
nectivity to South and Central America, parts of
the Caribbean, and the US; connected to Central
American Microwave System; satellite earth sta-
tion—1 Intelsat (Atlantic Ocean) (2011)
Broadcast media: 4 privately owned national
terrestrial TV channels dominate TV broadcast-
ing; multi-channel satellite and cable services are
available; 1 government-owned radio station and
hundreds of privately owned radio stations (2007)
Internet country code: .gt
Internet hosts: 357,552 (2012)
country comparison to the world: 60
Internet users: 2.279 million (2009)
country comparison to the world: 72','3a341ee6cf44279ae604e7e468d3dc4e9ddcd05dad77f47b39e08177911fda90','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ac4e35b195208724c50c29f78bf6e0dee0cc569d22735c7d65644a7765d0ada5',2025,'GG','Guernsey','communications',724,'Telephones—main lines in use: 45,100 (2010)
country comparison to the world: 165
Telephones—mobite cellular: 43,800 (2004)
country comparison to the world: 202
Telephone system: domestic: fixed-line
and mobile-cellular: services widely available;
coal, gasoline, oil,
SIERRA
LEONE','e4c86382f3a2b6b76ad533b6a8cbd3c5703bdece0c3a9c50a068858d390e1536','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('94d8e26c5477e20c6310408f8fc5b5a6f2b3c993cc426c44f3b67d7bd7e4ff67',2025,'GN','Guinea','communications',733,'Telephones—main lines in use: 18,000 (2011)
country comparison to the world: 194
THE CIA WORLD FACTBOOK
Telephones—mobile cellular: 4.5 million (2011)
country comparison to the world: 111
Telephone system: general assessment: inad-
equate system of open-wire lines, small radiotel-
ephone communication stations, and new micro-
wave radio relay system
domestic: Conakry reasonably well-served; cov-
erage elsewhere remains inadequate and large
companies tend to rely on their own systems for
nationwide links; fixed-line teledensity less than
per 100 persons; mobile-cellular subscribership is
expanding and exceeds 40 per 100 persons
international: country code—224; satellite earth
station—l Intelsat (Atlantic Ocean) (2011)
Broadcast media: government maintains mar-
ginal control over broadcast media; single state-
run TV station; state-run radio broadcast station
also operates several stations in rural areas; a stead-
ily increasing number of privately owned radio
stations, nearly all in Conakry, and about a dozen
community radio stations; foreign TV program-
ming available via satellite and cable subscription
services (2011)
Internet country code: .gn
Internet hosts: 15 (2012)
country comparison to the world: 224
Internet users: 95,000 (2009)
country comparison to the world: 161','fe426c066b568c11a1fb366750e21f780181f0df1b530e5806bce7ee14c4facf','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5a42db655e3f7c76bc296f686d1f7a86f36fad90e2a2649af8a05c5390572af6',2025,'GW','Guinea-Bissau','communications',743,'Telephones—main lines in use: 5,000 (2010)
country comparison to the world: 210
Telephones—mobile cellular: 869,000 (2011)
country comparison to the world: 157
Telephone system: general assessment: small
system including a combination of microwave
tadio relay, open-wire lines, radiotelephone, and
mobile-cellular communications
domestic: fixed-line teledensity less than 1 per 100
persons; mobile-cellular teledensity is roughly 50
per 100 persons
international: country code—245 (2011)
Broadcast media: 1 state-owned TV station and
a second station, Radio e Televisao de Portugal
(RTP) Africa, is operated by Portuguese public
broadcaster (RTP); 1 state-owned radio station,
several private radio stations, and some commu-
nity radio stations; multiple international broad-
casters are available (2007)
Internet country code: .cw
Internet hosts: 90 (2012)
country comparison to the world: 212
Internet users: 37,100 (2009)
country comparison to the.world: 177','f0e7be3ac8db3853700b69625246b87329570d3eefcbe9464d8f47adca8bc4f5','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('efcbe28bd3b18c75de9a680a5869df82d67cabdf3f7530e44a525bdbfd7272ce',2025,'GY','Guyana','communications',753,'Telephones—main lines in use: 152,600 (2011)
country comparison to the world: 134
Telephones—mobile cellular: 528,800 (2011)
country comparison to the world: 165
Telephone system: general assessment: fair
system for long-distance service; microwave radio
relay network for trunk lines; many areas still lack
fixed-line telephone services
domestic: fixed-line teledensity is about 20 per
100 persons; mobile-cellular teledensity about 70
per 100 persons in 2011
international: country code—592; tropospheric
scatter to Trinidad; satellite earth station—1 Intel-
sat (Atlantic Ocean) (2011)
Broadcast media: government-dominated broad-
cast media; the National Communications Net-
work (NCN) TV is state-owned; a few private TV
stations relay satellite services; the state owns and
operates 2 radio stations broadcasting on multiple
frequencies capable of reaching the entire coun-
try; government limits on licensing of new private
radio stations continue to constrain competition
in broadcast media (2007)
Internet country code: .gy
Internet hosts: 24,936 (2012)
country comparison to the world: 112
Internet users: 189,600 (2009)
country comparison to the world: 142','9d7e93b9d0854e0a72ab4531e9bffb5b784a07824afbc1890c60c37ab56a37ee','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('05920f201b81ca61463a716d21f208c99e2a9bb2c547d07b48aab10900ff0677',2025,'HT','Haiti','communications',758,'Telephones—main lines in use: 50,000 (2010)
country comparison to the world: 164
Telephones—mobile cellular: 4.2 million (2011)
country comparison to the world: 115
Telephone system: general assessment: telecom-
munications infrastructure is among the least
developed in Latin America and the Caribbean;
domestic facilities barely adequate; international
facilities slightly better
domestic: mobile-cellular telephone services are
expanding rapidly due, in part, to the introduction
of low-cost GSM phones; mobile-cellular teleden-
sity exceeds 40 per 100 persons
international: country code—509; satellite earth
station—l Intelsat (Atlantic Ocean) (2010)
Broadcast media: several TV stations, including 1
government-owned; cable TV subscription service
available; government-owned radio network; more
than 250 private and community radio stations with
about 50 FM stations in Port-au-Prince alone (2007)
Internet country code: .ht
Internet hosts: 555 (2012).
country comparison to the world: 181
internet users: 1 million (2009)
country comparison to the world: 99','baaaa6292f9915e66afe558f25a6118e0fee99c97a5215c7d79e098df57e6bd8','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0334837df768bc2c00b4e5c3bf93c0fa9474d7050ea7eda67eecc359e83fe070',2025,'VA','Holy See (Vatican City State)','communications',771,'Telephone system: general assessment: auto-
matic digital exchange
domestic: connected via fiber optic cable to Tel-
ecom Italia network i
international: country code—39; uses Italian sys-
tem (2012)
Broadcast media: the Vatican Television Center
(CTV) transmits live broadcasts of the Pope’s
Sunday and Wednesday audiences, as well as the
Pope’s public celebrations; CTV also produces
documentaries; Vatican Radio is the Holy See’s
official broadcasting service broadcasting via
shortwave, ÁM and FM frequencies, and via satel-
lite and Internet connections (2008)
Internet country code:.va
Internet hosts: 107 (2012)
country comparison to the world: 208','aade1e09e2e7f35753dacb6eea25648ad0e3463548da876438bd8873c0f984d9','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cd9c09ce307b8f413ef008af9a74cb59a345c2110bbb7dcdd5c33b4c586634e9',2025,'HN','Honduras','communications',779,'Telephones—main lines in use: 609,200 (2011)
country comparison to the world: 91
Telephones—mobile cellular: 8.062 million (2011)
country comparison to the world: 88
Telephone system: general assessment: fixed-
line connections are increasing but still limited;
competition among multiple providers of mobile-
cellular services is contributing to a sharp increase
in subscribership
domestic: beginning in 2003, private sub-oper-
ators allowed to provide fixed-lines in order to
expand telephone coverage contributing to a small
increase in fixed-line teledensity; mobilecellular
subscribership is roughly 100 per 100 persons
international: country code—504; landing point
for both the Americas Region Caribbean Ring Sys-
tem (ARCOS-1) and the MAYA-1 fiber-optic sub-
marine cable system that together provide connec-
tivity to South and Central Americd, parts of the
Caribbean, and the US; satellite earth stations—2
Intelsat (Atlantic Ocean); connected to Central
American Microwave System (2011)
Broadcast media: multiple privately owned ter-
restrial TV networks, supplemented by multiple
cable TV networks; Radio Honduras is the lone
government-owned radio network; roughly 300
privately owned radio stations (2007)
Internet country code:.hn
Internet hosts: 30,955 (2012)
country comparison to the world: 107
Internet users: 731,700 (2009)
country comparison to the world: 108','2da9c715fb4037c73ac8c5d981e280525c78a402722fa3cc53ce08edac81d91a','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('71bb96a6a114ff2515e724307c83a97b585f0ae2c836dd7b809b8f9474fd473d',2025,'HK','Hong Kong','communications',788,'Telephones—main lines In use: 4.342 million
(2011)
country comparison to the world: 38
Telephones—mobile cellular: 15.293 million
(2011)
country comparison to the world: 55
Telephone system: general assessment: modern
facilities provide excellent domestic and interna-
tional services
domestic: microwave radio relay links and exten-
sive fiber-optic network
international: country code—852; multiple
international submarine cables provide connec-
tions to Asia, US, Australia, the Middle East, and
Western Europe; satellite earth stations—3 Intel-
sat (1 Pacific Ocean and 2 Indian Ocean); coaxial
cable to Guangzhou, China (2012)
Broadcast media: 2 commercial terrestrial TV
networks each with multiple stations; multi-
channel satellite and cable TV systems available;
3 radio networks, one of which is government-
funded, operate about 15 radio stations (2012)
Internet country code:.hk
internet hosts: 870,041 (2012)
country comparison to the world: 48
Internet users: 4.873 million (2009)
country comparison to the world: 47','843ff0f9f9558eaf375002a521729774d6d68f5d0aa4b84fe9c22914bad9a7e8','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d2ff60a75179f101477f82006cbdee822bdb54ca74d02ea4db6472cafc1e2f0a',2025,'HU','Hungary','communications',796,'Telephones—main lines in use: 2.933 million
(2011)
country comparison to the world: 52
Telephones—mobile cellular: 69 million (2011)
country comparison to the world: 11.67
Telephone system: general assessment: the tel-
ephone system has been modernized; the system
33]
is digital and highly automated; trunk services are
carried by fiber-optic cable and digital microwave
radio relay; a program for fiber-optic subscriber
connections was initiated in 1996 :
domestic: competition among mobile-cellular ser-
vice providers has led to a sharp increase in the
use of mobile-cellular phones since 2000 and a
decrease in the number of fixed-line connections
international: country code—36; Hungary has
fiber-optic cable connections with all neighbor-
ing countries; the international switch is in Buda-
pest; satellite earth stations—2 Intelsat (Atlantic
Ocean and Indian Ocean regions), 1 Inmarsat, 1
very small aperture terminal (VSAT) system of
ground terminals (2011)
Broadcast media: mixed system of state-sup-
ported public service broadcast media and private
broadcasters; the 3 publicly owned TV channels
and the Z main privately owned TV stations are
the major national broadcasters; a large number of
special interest channels; highly developed market
for satellite and cable TV services with about two-
thirds of viewers utilizing their services; 3 state-sup-
ported public-service radio networks and 2 major
national commercial stations; a large number of
local stations including commercial, public service,
nonprofit, and community radio stations; digital
transition postponed to the end of 2014 (2007)
Internet country code:.hu
Internet hosts: 3.145 million (2012)
country comparison to the world: 33
Interne? users: 6.176 million (2009)
country comparison to the warld: 41','d177c2715b214d003baae14bb094abd48bf79cb61968f299987823509836b022','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3c8d70ee050a882aab8a6da0f4a8eccac37d6094aea20d830634cafce6d5408b',2025,'IS','Iceland','communications',803,'Telephones—moain lines in use: 191,100 (2011)
country comparison to the world: 127
Telephones—mobile cellular: 344,100 (2011)
country comparison to the world: 172
Telephone system: general assessment: telecom-
munications infrastructure is modern and fully
digitized, with satellite-earth stations, fiber-optic
cables, and an extensive broadband network
domestic: liberalization of the telecommunica-
tions sector beginning in the late 1990s has led
to increased competition especially in the mobile
services segment of the market
international: country code—354; the CAN-
TAT-3 and FARICE-1 submarine cable systems
335
provide connectivity to Canada, the Faroe
Islands, UK, Denmark, and Germany; a planned
new section of the Hibernia-Atlantic submarine
cable will provide additional connectivity to Can-
ada, US and Ireland; satellite earth stations—2
Intelsat (Atlantic Ocean) 1 Inmarsat (Atlantic
and Indian Ocean regions); note—Iceland shares
the Inmarsat earth station with the other Nordic
countries (Denmark, Finland, Norway, and Swe-
den) (2011)
Broadcast media: state-owned public TV
broadcaster operates 1 TV channel nationally;
several privately owned TV stations broadcast
nationally and roughly another half-dozen oper-
ate locally; about one-half the households utilize
multi-channel cable or satellite TV services;
state-owned public radio broadcaster operates
2 national networks and 4 regional stations; 2
privately owned radio stations operate nationally
and another 15 provide more limited coverage
(2007)
Internet country code: is
Internet hosts: 369,969 (2012)
country comparison to the world: 56
Internet users: 301,600 (2009)
country comparison to the world: 129','8d5f17d9f2649af73bd56b7eb664c4c8f068a8eaa15503fd9819dc9bd487141f','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9f92c8d4b6441e13890504eacabf07c9099de54a96de903c1c81e13ca80f2dd6',2025,'IN','India','communications',812,'Telephones—main lines in use: 32.685 million
(2011)
country comparison to the world: 10
Telephones—mobile cellular: 893.862 million
(2011)
country comparison to the world: 2
Telephone system: general assessment: sup-
ported by recent deregulation and liberalization of
telecommunications laws and policies, India has
emerged as one of the fastest growing telecom mar-
kets in the world; total telephone subscribership
base exceeded 900 million in 2011, an overall tel-
edensity of roughly 75%, and subscribership is cur-
rently growing more than 20 million per month;
urban teledensity now exceeds 100% and mural
teledensity is steadily growing
domestic: mobile cellular service introduced in
1994 and organized nationwide into four metro-
politan areas and 19 telecom circles each with
multiple private service providers and one or
more state-owned service providers; in recent
years significant trunk capacity added in the form
of fiber-optic cable and one of the world’s largest
domestic satellite systems, the Indian National
Satellite system (INSAT), with 6 satellites sup-
porting 33,000 very small aperture terminals
(VSAT)
international; country code—91; a number of
major international submarine cable systems,
including Sea-Me-We-3 with landing sites at
Cochin and Mumbai (Bombay), Sea-Me-We-4
with a landing site at Chennai, Fiber-Optic Link
Around the Globe (FLAG) with a landing site
at Mumbai (Bombay), South Africa—Far East
(SAFE) with a landing site at Cochin, the i2i
cable network linking to Singapore with land-
ing sites at Mumbai (Bombay) and Chennai
(Madras), and Tata Indicom linking Singapore
and Chennai (Madras), provide a significant
increase in the bandwidth available for both
voice and data traffic; satellite earth stations—8
Intelsat (Indian Ocean) and 1 Inmarsat (Indian
Ocean region); 9 gateway exchanges operating
from Mumbai (Bombay), New Delhi, Kolkata
(Calcutta), Chennai (Madras), Jalandhar, Kan-
pur, Gandhinagar, Hyderabad, and Ernakulam
(2011)
340
THE CIA WORLD. FACTBOOK
Broadcast media: Doordarshan, India’s pub-
lic TV network, operates about 20 national,
regional, and local services; a large and increas-
ing number of privately owned TV stations are
distributed by cable and satellite service provid-
ers; by 2011, more than 100 million homes had
access to cable and satellite TV offering more
than 700 TV channels; government controls AM
radio with All India Radio operating domestic
and external networks; news broadcasts via radio
are limited to the All India Radio Network; since
2000, privately-owned FM stations have been
permitted and their numbers have increased rap-
idly (2007)
Internet country code: in
Internet hosts: 6.746 million (2012)
country comparison to the world: 17
Internet users: 61.338 million (2009)
country comparison to the world: 6','412cc47bc471fe6f2a459a803155bb08b09f98c71b4050d007d14f9f0f1d9509','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4d887b85c3376d0777b7651b9e145ab6444a4b9ec856b9441d48841ab1adbe23',2025,'IQ','Iraq','communications',824,'Telephones—main lines in use: 1.794 million
(2011)
country comparison to the world: 62
Telephones—mobile cellular: 27 million (2012)
country comparison to the world: 38
Telephone system: general assessment: the 2003
liberation of Iraq severely disrupted telecommuni-
cations throughout Iraq including international
connections; widespread government efforts to
rebuild domestic and international communica-
tions through fiber optic links are in progress;
the mobile cellular market has expanded rapidly
ta some 27 million subscribers by the end of 2012
domestic: repairs to switches and lines destroyed
during 2003 continue; additional switching
capacity is improving access; 3 GSM operators
since 2007 have expanded beyond their regional
roots and offer near country-wide access to sec-
ond-generation services; third-generation mobile
services are not available nationwide; wireless
local loop is available in some metropolitan areas
and additional licenses have been issued with
the hope of overcoming the lack of fixed-line
infrastructure
international: country code—964; satellite earth
stations—4 (2 Intelsac—1 Atlantic Ocean and 1
Indian Ocean, 1 Interspurnik—Atlantic Ocean
region, and 1 Arabsat (inoperative)); local micro-
wave radio relay connects border regions to Jordan,
Kuwait, Syria, and Turkey; international terrestrial
fiber-optic connections have been established with
Saudi Arabia, Turkey, Kuwait, Jordan, and Iran;
links to the Fiber-Optic Link Around the Globe
(FLAG) and the Gulf Bridge International (GBI)
submarine fiber-optic cables are planned (2011)
Broadcast media: the number of private radio
and TV stations has increased rapidly since
2003; government-owned TV and radio stations
are operated by the publicly funded Iraqi Public
Broadcasting Service; private broadcast media
are mostly linked to political, ethnic, or religious
groups; satellite TV is available to an estimated
70% of viewers and many of the broadcasters are
based abroad; transmissions of multiple interna-
tional radio broadcasters are accessible (2007)
internet country code: iq
Internet hosts: 26 (2012)
country comparison to the world: 219
Internet users: 325,900 (2009)
country comparison to the world: 126','210ef0006684b747351bd751745659d50e09b01c3b7f47c769c0ec9996e40f96','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a836ac8d1a891ce7b0e791ce6fe4e767848b640d37c582b81cc38b53ec7e10d0',2025,'IE','Ireland','communications',830,'Telephones—main lines in use: 2.047 million
(2011)
country comparison to the world: 57
Telephones—mobile cellular: 4.906 million (2011)
country comparison to the world; 106
Telephone system: general assessment: modern
digital system using cable and microwave radio
relay
domestic: system privatized but dominated by for-
mer state monopoly operator; increasing levels of
broadband access particularly in urban areas
international: country code—353; landing point
for the Hibernia-Atlantic submarine cable with
links to the US, Canada, and UK; satellite earth
station—l1 Intelsat (Atlantic Ocean) (2011)
Broadcast media: publicly owned broadcaster
Radio Telefis Eireann (RTE) operates 2 TV sta-
tions; commercial TV stations are available; about
75% of households utilize multi-channel satellite
and TV services that provide access to a wide
range of stations; RTE operates 4 national radio
stations and has launched digital audio broadcasts
on several stations; a number of commercial broad-
cast stations operate at the national, regional, and
local levels (2007)
Internet country code: .ic
Internet hosts: 1.387 million (2012)
country comparison to the world: 40
Internet users: 3.42 million (2009)
country comparison to the world: 67','32387609ef400521880a377c3bfd67ea8e1bf030c9dfaa603fcc61736c447c4a','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e88001b00233ea929fe403ab459b7a33c92e0be9e9898c906b6403580e7d5d6a',2025,'IM','Isle of Man','communications',839,'Telephone system: domestic: landline, telefax,
mobile cellular telephone system
international: country code—44; fiber-optic
cable, microwave radio relay, satellite earth sta-
tion, submarine cable
Broadcast media: national public radio broad-
casts over 3 FM stations and 1 AM station; 2 com-
mercial broadcasters operating with I having mul-
tiple FM stations; receives radio and TV services
via relays from British TV and radio broadcasters
(2008)
Internet country code: .im
internet hosts: 895 (2012)
_country comparison to the world: 174','e3350eeb6fa4332bc57f6a7681933c86c3d1b895e908fe15a465a10d8e40db58','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c01526543642fbf38bc3dd8a96a43632bd2279c8102abf6cbe4b405fcf3499f2',2025,'IL','Israel','communications',847,'Telephones—main lines in use: 3.5 million
(2011)
country comparison to the world: 47
Telephones—mobile cellular:
(2011)
country comparison to the world: 80
Telephone system: general assessment: most
highly developed system in the Middle East
domestic: good system of coaxial cable and micro-
wave radio relay; all systems are digital; four pri-
vately owned mobile-cellular service providers
with countrywide coverage
9.2 million
364
THE CIA WORLD FACTBOOK
international: country code—972; submarine
cables provide links to Europe, Cyprus, and parts of
the Middle East; satellite earth stations—3 Intelsat
(2 Atlantic Ocean and 1 Indian Ocean) (2011)
Broadcast media: state broadcasting network,
operated by the Israel Broadcasting Authority
(IBA), broadcasts on 2 channels, one in Hebrew
and the other in Arabic; 5 commercial channels
including a channel broadcasting in Russian, a
channel broadcasting Knesset proceedings, and a
music channel supervised by a public body; multi-
channel satellite and cable TV packages provide
access to foreign channels; IBA broadcasts on 8
radio networks with multiple repeaters and Israel
Defense Forces Radio broadcasts over multiple
stations; about 15 privately owned radio stations;
overall more than 100 stations and repeater sta-
tions (2008)
Internet country code: .il
Internet hosts: 2.483 million (2012)
country comparison to the world: 36
Internet users: 4.525 million (2009)
country comparison to the world: 51 .
Telephones—main fines In use: 337,000
(includes Gaza Strip) (2010)
country comparison to the world: 112
Telephones—mobile cellular: 2.405 million
(includes Gaza Strip) (2010)
country comparison to the world: 132
Telephone system: general assessment: continu-
ing political and economic instability has impeded
significant liberalization of the telecommunica-
tions industry
domestic: Israeli company BEZEK and the Pal-
estinian company PALTEL are responsible for
fixed line services; PALTEL plans to establish a
fiber-optic connection to Jordan to route domestic
mobile calls; the Palestinian JAWWAL company
and WATANIYA PALESTINE provide cellular
services
international: country code—970; 1 interna-
tional switch in Ramallah (2009) (2009)
Broadcast media: the Palestinian Authority
operates 1 TV and 1 radio station; about 30 inde-
pendent TV and 25 radio stations; both Jordanian
TV and satellite TV are accessible (2008)
Internet country code: .ps; note—same as Gaza
Strip
Internet users: 1.379 million (includes Gaza
Strip) (2009)
country comparison to the world: 88','f3a81fceecc96e72411e38e65c71ea06a515edb34fae685ad401b59d71426f56','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8d816096ef1e63a21b6dcc278d7fbfd878597138b419697b874a0242f4908f9e',2025,'IT','Italy','communications',857,'Telephones—main lines in use: 22.116 million
(2011)
country comparison to the world: 13
Telephones—mobile cellular: 96.005 miia (2011)
country comparison to the world: 11
Telephone system: general assessment: modern,
well-developed, fast; fully automated telephone,
telex, and data services
domestic: high-capacity cable and microwave
radio relay trunks
international: country code—39; a series of sub-
marine cables provide links to Asia, Middle East,
Europe, North Africa, and US; satellite earth sta-
tions—3 Intelsat (with a total of 5 antennas—3 for
Atlantic Ocean and 2 for Indian Ocean), 1 Inmarsat
(Atlantic Ocean region), and NA Eutelsat (2011)
Broadcast media: two Italian media giants
dominate—the publicly owned Radiotelevisione
Italiana (RAI) with 3 national terrestrial stations
and privately owned Mediaset with 3 national ter-
restrial stations; a large number of private stations
and Sky Italia—a satellite TV network; RAI oper-
ates 3 AM/FM nationwide radio stations; some
1,300 commercial radio stations (2007)
internet country code: it
Internet hosts: 25.662 million (2012)
country comparison to the world: 4
Internet users: 29.235 million (2009)
country comparison to the world: 13','5feaa424ffe203f7b72a3826677e2963cdad4f77e36856f34740790fee62b36f','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b84be9286aa3e3ac40cb9d6af0504782969f6458a8cbfbc138eddddc5f7408db',2025,'JM','Jamaica','communications',865,'Telephones—main lines in use: 272,100 (2011)
country comparison to the world: 123
Telephones—mobile cellular: 2.975 million
varmn
country comparison to the world: 128
Telephone system: general assessment: fully
automatic domestic telephone network
domestic the 1999 agreement to open the market
for telecommunications services resulted in rapid
growth in mobile-cellular telephone usage while
the number of fixed-lines in use has declined; com-
bined mobile-cellular teledensity exceeded 110 per
102 persons m 2011
international: county code—1-876; the
Fibvalink submarine cable network provides
enhanced delivery of business and broadband traf-
fic and is linked ro the Americas Region Carib-
bean Ring Sysrem (ARCOS-!) submarine cable
in the Dominican Republic; the link ro ARCOS-1
provides seamless connectivity to US, parts of the
Canbbean. Central America, and South Amer-
xa; satellwe earth stations—2 Intelsat (Atlantic
Ocean) (2010)
Broadcast media: privately owned Radio Jamaica
Limited and its subsidiaries operate multiple TV
stations, subscription cable services, and radio sta-
tions; 2 other privately owned television stations;
roughly 70 radio stations (2007)
Internet country code: jm
Internet hosts: 3.9C6 (2012)
country comparison to the world: 149
Intemet users: 1.581 million (2009)
country comparison. to the world: 80
Broadcast media: a coastal radio station has been
remotely operated since 1994 (2008)','998d654259001db9d3cce343662ea39ccf0324b9f48dff2e6eac00e047c076a4','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('60890681cfe6a87c4dbbb64b62b3ef238c0f08b7f112e01e88e0702227b807a6',2025,'JP','Japan','communications',879,'Telephones—main lines in use: 64.668 million (2011)
country comparison to the world: 3
Telephones—mobile cellular: 132.76 million (2011)
country comparison to the world: 7
Telephone system: general assessment: excel-
lent domestic and international service
domestic: high level of modern technolégy and
excellent service of every kind
international: country code—81;
submarine cables provide links throughout Asia,
Australia, the Middle East, Europe, and US; satel-
lite earth stations—7 Intelsat (Pacific and Indian
Oceans), 1 Interspumik (Indian Ocean region), 2
Inmarsat (Pacific and Indian Ocean regions), and
8 SkyPerfect JSAT (2012)
Broadcast media: a mixture of public and commer-
cial broadcast TV and radio stations; 6 national ter-
restrial TV networks including 1 public broadcaster;
the large number of radio and TV stations available
provide a wide range of choices; satellite and cable ser-
vices provide access to international channels (2012)
Internet country code: .jp
Internet hosts: 64.453 million (2012)
country comparison to the world: 2
Internet users: 99.182 million (2009)
country comparison to the world; 3','f903e332f948b185439cecb18d2b1ba071924948f3b9ab6c7753f71431a04c97','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6a5c92f27d3197976322a90b745bf6f998936c076f63ba09986d4a5bba256e41',2025,'JE','Jersey','communications',888,'Telephones—main lines in use: 73,800 (2010)
country comparison to the world: 156
Telephones—mobile cellular: 108,000 (2010)
country comparison to the world: 191
Telephone system: general assessment: increas-
ingly modern system, with broadband access
domestic: digital
announced in 2006 now implemented; fixed-line
telephone system launch
and mobile-cellular services widely available; com-
bined fixed and mobile-cellular density exceeds
100 per 100 persons
international; country ` code—44; submarine
cable connectivity to Guernsey, the UK, and
France (2010)
Broadcast media: multiple UK terrestrial tel-
evision broadcasts are received via a transmitter
in Jersey; satellite packages available; BBC
Radio Jersey and 1 other radio station operat-
ing (2009)
Internet country code: je
Internet hosts: 264 (2012)
country comparison to the world: 194
Internet users: 29,500 (2009)
country comparison to the world; 182
Telephones—main lines in use: 75,800 (2011)
country comparison to the world: 154
Telephones—mobile cellular: 766,500 (2011)
country comparison to the world: 158
Telephone system: general assessment: a some-
what modern but not an advanced system
domestic: single source for mobile-cellular service
with a geographic coverage of about 90% and a ris-
ing subscribership base; combined fixed-line and
mobile, cellular teledensity roughly 60 telephones
per 100 persons in 2011; telephone system con-
sists of carrier-equipped, open-wire lines and low-
capacity, microwave radio relay -
international: country code—268; satellite earth
station—I Intelsat (Atlantic Ocean) (2009)
Broadcast media: state-owned TV station; satel-
lite dishes are able to access South African provid-
ers; state-owned radio network with 3 channels; 1
private radio station (2007)
Internet country code: .sz
Internet hosts: 2,744 (2012)
country comparison to the world: 158
Internet users: 90,100 (2009)
country comparison to the world: 162','189d6a3ff60dc30a9c76b60b3769eeced1c18415abe0d8e2c74883f63c80f01f','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('64ada1c933aa90ac9405844618b8ac2ffbf37187795862856f41919b5bce1ca7',2025,'JO','Jordan','communications',896,'Telephones—main lines in use: 465,400 (2011)
country comparison to the world: 102
Telephones—mobile cellular: 7.483 million
(2011)
country comparison to the world: 93
Telephone system: general assessment: service
has improved recently with increased use of digi-
tal switching equipment; microwave radio relay
transmission and coaxial and fiber-optic cable are
employed on trunk lines; growing mobile-cellular
usage in both urban and rural areas is reducing use
of fixed-line services
domestic: -1995
opened all non-fixed-line services to private
telecommunications law
competition; in 2005, monopoly over fixed-line
services terminated and the entire telecommu-
nications sector was opened to competition;
currently multiple mobile-cellular providers
with subscribership reaching 115 per 100 per-
sons in 2011
international: country code—962; landing
point for the Fiber-Optic Link Around the Globe
(FLAG) FEA and FLAG Falcon submarine cable
networks; satellite earth stations—33 (3 Intel-
sat, Arabsat, and 29 land and maritime Inmarsat
terminals); fiber-optic cable to Saudi Arabia and
microwave radio relay link with Egypt and Syria;
participant in Medarabtel (2011)
Broadcast media: radio and TV dominated by the
government-owned Jordan Radio and Television
Corporation (JRTV) that operates a main network, a
sports network, a film network, and a satellite chan-
nel; first independent TV broadcaster aired in 2007;
international satellite TV and Israeli and Syrian TV
broadcasts are available; roughly 30 radio stations
with JRTV operating the main government-owned
station; transmissions of multiple international radio
broadcasters are available (2007)
Internet country code: .jo
Internet hosts: 69,473 (2012)
country comparison to the world: 89
Internet users: 1.642 million (2009)
country comparison to the world: 78','456c2f701c40437fc30de92e3ebce749a1664032dec6de02a4fd3718283c7db8','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d3879848ba0e3025fe59bf1ca512616011e7c0f9796cf0c7a8919d2253805e13',2025,'KZ','Kazakhstan','communications',902,'Telephones—main lines in use: 4.266 million
(2011)
country comparison to the world: 39
Telephones—mobile cellular: 25.24 million
(2011) a
country comparison to the world: 41
Telephone system: general assessment: inher-
ited an outdated telecommunications network
from the Soviet era requiring modernization
domestic: intercity by landline and microwave
radio relay; number of fixed-line connections is
gradually increasing and fixed-line teledensity now
roughly 25 per 100 persons; mobile-cellular usage
has increased rapidly and the subscriber base now
exceeds 140 per 100 persons
international: country code—7; international
traffic with other former Soviet republics and
China carried by landline and microwave radio
relay and with other countries by satellite and by
the Trans-Asia-Europe (TAE) fiber-optic cable;
satellite earth stations—2 Intelsat (2008)
Broadcast media: state owns nearly all radio and
TV transmission facilities and operates national
TV and radio networks; nearly all nationwide
TV networks are wholly or partly owned by the
government; some former state-owned media out-
lets have been privatized; households with satel-
lite dishes have access to foreign media; a small
number of commercial radio stations operate
along with state-run radio stations; recent legisla-
tion requires all media outlets to register with the
government and all TV providers to broadcast in
digital format by 2015 (2008)
Internet country code: .kz
Internet hosts: 67,464 (2012)
country comparison to the world: 90
Internet users: 5.299 million (2009)
country comparison to the world: 44','3a30a4a978ad5e3d41d0942fefcd2fc5d31fef888b711797c564d05d0f25b3ef','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b2670452135704f9a39f121f8053b0ae4499428c16357552565f306b912e03ff',2025,'KE','Kenya','communications',912,'Telephones—main lines In use: 283,500 (2011)
country comparison to the world: 120
Telephones—mobile cellular: 28.08 million
(2011)
country comparison to the world: 36
Telephone system: general assessment: inad-
equate; fixed-line telephone system is small and
inefficient; trunks are primarily microwave radio
relay; business data commonly transferred by a
very small aperture terminal (VSAT) system
domestic: sole fixed-line provider, Telkom Kenya,
is slated for privatization; multiple providers in the
mobile-cellular segment of the market fostering a
390
THE CIA WORLD FACTBOOK
boom in mobile-cellular telephone usage with tel-
edensity reaching 65 per 100 persons in 2011
international: country code—254; landing point
for the EASSy, TEAMS and SEACOM fiber-
optic submarine cable systems; satellite earth sta-
tions—4 Intelsat (2011)
Broadcast media: abour a half-dozen privately
owned TV stations and a state-owned TV broad-
caster that operates channels; satellite and cable
TV subscription services available; state-owned
tadio broadcaster operates 2 national radio chan-
nels and provides regional and local radio services
in multiple languages; a large number of private
radio stations, including provincial stations broad-
casting in local languages; transmissions of several
international broadcasters available (2007)
Internet country code: .ke
internet hosts: 71,018 (2012)
country comparison to the world: 88
Internet users: 3.996 million (2009)
country comparison to the world: 59','f2f202038caee61fd268134c3cd32b2657a713d3bb70b590d0d61487489980db','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2f1c0515205f7103987eca1eb3aa822d1f9fb34b537b6a8198418783fd1be01a',2025,'KI','Kiribati','communications',921,'Telephones—main lines in use: 8,500 (2011)
country comparison to the world: 201
Telephones—mobile cellular: 13,800 (2011)
country comparison to the world: 210
Telephone system: general assessment: generally
good quality national and intemational service
domestic: wire line service available on Tarawa
and Kiritimati (Christmas Island); connections to
outer islands by HF/VHF radiotelephone; wireless
service available in Tarawa since 1999
international: country code—686: Kiribati is
being linked to the Pacific Ocean Cooperative
Network. should
improve telephone service; satellite earth sta-
Telecommunications which
tion—1 Intelsat (Pacific Ocean) (2010)
Broadcast media: 1 TV broadcast station that
provides about 1 hour of local programming Mon-
day-Friday; multi-channel TV packages provide
access to Australian and US stations; 1 govem-
ment-operated radio station broadcasts on AM,
FM, and shortwave (2009)
internet country code: .ki
Internet hosts: 327 (2012)
country comparison to the world: 190
Internet users: 7,800 (2009)
country comparison to the world: 204
Telephones—main lines in use: 1.18 million
(2011)
country comparison to the world: 72
Telephones—mobile cellular: 1 million (2011)
country comparison to the world: 155
Telephone system: general assessment: adequate
system; nationwide fiber-optic network; mobile-
cellular service expanding beyond Pyongyang
domestic: fiber-optic links installed down to the
county level; telephone directories unavailable;
GSM mobile-cellular service initiated in 2002 but
suspended in 2004; Orascom Telecom Holding, an
Egyptian company, launched W-CDMA mobile
service on 15 December 2008 for the Pyongyang
area, has expanded service to several large cities
and now has a 1-million-person subscriber base
international: country code—850; satellite earth
stations—2 (1 Intelsat—Indian Ocean, 1 Rus-
sian—Indian Ocean region); other international
connections through Moscow and Beijing (2011)
Broadcast media: no independent media; radios
and TVs are pre-tuned to government stations;
4 government-owned TV stations; the Korean
Workers’ Party owns and operates the Korean
Central Broadcasting Station, and the state-run
Voice of Korea operates an external broadcast
service; the government prohibits listening to and
jams foreign broadcasts (2008)
Internet country code: .kp
Internet hosts: 8 (2012)
country comparison to the world: 227
Telephones—main lines in use: 29.468 million
(2011)
country comparison to the world: 11
Telephones—mobile cellular: 52.507 million
(2011)
country comparison to the world: 27
Telephone system: general assessment: excel-
lent domestic and international services featuring
rapid incorporation of new technologies
domestic: fixed-line and mobile-cellular services
widely available with a combined telephone sub-
scribership of roughly 170 per 100 persons; rapid
assimilation of a full range of telecommunications
technologies leading to a boom in e-commerce
international: country code—82; numerous sub-
marine cables provide links throughout Asia, Aus-
tralia, the Middle East, Europe, and US; satellite
earth stations—66 (2011)
THE CIA WORLD FACTBOOK
Broadcost media: multiple national TV networks
with 2 of the 3 largest networks publicly operated;
the largest privately owned network, Seoul Broad-
casting Service (SBS), has ties with other com-
mercial TV networks; cable and satellite TV sub-
scription services available; publicly operated radio
broadcast networks and many privately owned
radio broadcasting networks, each with multiple
affiliates, and independent local stations (2010)
Internet country code: .kr
Internet hosts: 315,697 (2012)
country comparison to the world: 62
Internet users: 39.4 million (2009)
country comparison to the world: 11','45cbf9ca5c9b027a0e7265709eb20f4b0d77b9048b719df449140ff610f4aa2e','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c27d78995a0f966a1f63194a555b616cfcff92e74707a1120721104052fb1125',2025,'RS','Serbia','communications',930,'Telephones—main lines in use: 106,300 (2006)
country comparison to the world: 144
Telephones—mobile cellular: (2007)
country comparison to the world: 163
Telephones—main lines in use: 3.03 million
(2011)
country comparison to the world: 51
Telephones—mobile celiular: 10.182 million
(2011)
country comparison to the world: 74
Telephone system: general assessment: replace-
ments of, and upgrades to, telecommunications
equipment damaged during the 1999 war has
resulted in a modern digitalized telecommunica-
tions system
domestic: wireless service, available through mul-
tiple providers with national coverage, is growing
very rapidly; best telecommunications services are
centered in urban centers; 3G mobile network
launched in 2007
international: country code—381 (2011)
Internet country code: .rs
internet hosts: 1.102 million (2012)
country comparison to the world: 44
Internet users: 4.107 million (2009)
country comparison to the world: 57','be8af8be9d90d7d4cae2ca3f91c127958c4d41f7a1b2e20be7fa726b1bfc7913','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('372c4a8161b3e9f238dec7e080559ebab910a8b9d36055a6bf092a412dc8f795',2025,'KW','Kuwait','communications',936,'Telephones—main lines in use: 514,700 (2011)
country comparison to the world: 98
Telephones—mobile cellular: 4.935 million
(2011)
country comparison to the world: 105
Telephone system: general assessment: the
quality of service is excellent
domestic: new telephone exchanges provide a
large capacity for new subscribers; trunk traffic is
catried by microwave radio relay, coaxial cable, and
open-wire and fiber-optic cable; a mobile-cellular
telephone system operates throughout Kuwait, and
the country is well supplied with pay telephones
international: country code—965; linked to intet-
national submarine cable Fiber-Optic Link Around
the Globe (FLAG); linked to Bahrain, Qatar, UAE
via the Fiber-Optic Gulf (FOG) cable; coaxial
cable and microwave radio relay to Saudi Arabia;
satellite earth stations—6 (3 Intelsat—1 Atlantic
Ocean and 2 Indian Ocean, 1 Inmarsat—Atlantic
Ocean, and 2 Arabsat) (2011)
Broadcast media: state-owned TV broadcaster
operates 4 networks and a satellite channel; several
private TV broadcasters have emerged since 2003;
satellite TV available with pan-Arab TV stations
especially popular; state-owned Radio Kuwait
broadcasts on a number of channels in Arabic and
English; first private radio station emerged in 2005;
transmissions of at least 2 international radio broad-
casters are available (2007)
Internet country code: .kw
Internet hosts: 2,771 (2012)
country comparison to the world: 156
Internet users: 1.1 million (2009)
country comparison to the world: 96','5acd0ce00aa90d5d0b6d4062477bc2fec3a6495d4ab7bced8cd81c43555e1409','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('20c4b56bf1316885aa9a9c840fc8f331362aae9405a1028f073ab07f275ea75c',2025,'KG','Kyrgyzstan','communications',947,'Telephones—main lines in use: 502,000 (2011)
country comparison to the world: 99
Telephones—mobile cellular: 6.277 million
(2011)
country comparison to the world: 98
409
Telephone system: general assessment: telecom-
municatioris infrastructure is being upgraded; loans
from the European Bank for Reconstruction and
Development (EBRD) are being used to install a
digital network, digital radio-telay stations, and
fiber-optic links
domestic: fixed-line penetration-remains low and
concentrated in urban areas; multiple mobile-
cellular service providers with growing coverage;
mobile-cellular subscribership was about 115 per
100 persons in 2011
international: country code—-996; connections
with other CIS countries by landline or micro-
wave tadio relay and with other countries by
leased connections with Moscow international
gateway switch and by satellite; satellite earth sta-
tions—2 (1 Intersputnik, 1 Intelsat); connected
internationally by the Trans-Asia-Europe (TAE)
fiber-optic line (2011)
Broadcast media: state-run TV broadcaster
operates: 2 nationwide networks and 6 regional
stations; roughly 20 private TV stations operating
with most rebroadcasting other channels; state-
run radio broadcaster operates 2 networks; about
20 private radio stations (2007)
Internet country code: .kg
Internet hosts: 115,573 (2012)
country comparison to the world: 81
Internet users: 2.195 million (2009)
country comparison to the world: 74
Telephones—imain lines in use: 107,600 (2011)
country comparison to the world: 143
Teilephones—mobile cellular: 5.481 million
(2011)
country comparison to the world: 101
Telephone system: general assessment: service
to general public is improving; the government
relies on a radiotelephone network to communi-
cate with remote areas
domestic 4 service providers with mobile cellular
usage growing very rapidly
‘international: country code—856; satellite earth
station—1l Interspumik (Indian Ocean region)
and a second to be developed by China (2012)
Broadcast media: 6 TV stations operaring out of
Vientiane—3 government-operated and the others
commercial; 17 provincial stations operating with
nearly all programming relayed via satellite from
the government-operated stations in Vientiane;
Chinese and Viemamese programming relayed via
satellite from Lao National TV: broadcasts avail-
able from stations in Thailand and Viemam in
border areas; multi-channel satellite and cable TV
systems provide access to a wide range of foreign
stanons; state-controlled radio with state-operated
Lao National Radio (LNR) broadcasting on 5 fre-
quencies—1 AM, 1 SW, and 3 FM; LNR''s AM and
FM programs are relayed via satellite constituting a
large part of the programming schedules of the pro-
vincial radio stations; Thai radio broadcasts avail-
able in border areas and transmissions of mulriple
international broadcasters are also accessible (2012)
internet country code: la
internet hosts: 1.532 (2012)
country comparison to the world: 166
Internet users: 300,000 (2009)
country comparison to the world: 130','0c7bbb354f55632dbc93d3555c167e7c0054cca30a1e0a1c43505728e9c3729a','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1f7e5ed7ece741d867c585a032fadeebcbb6de923ea77534e4a475f27e903a57',2025,'LV','Latvia','communications',961,'Telephones—main lines in use: 516,300 (2011)
country comparison to the world: 97
Telephones—mobite cellular: 2.309 million
(2011)
country comparison to the world: 134
Telephone system: general assessment: recent
efforts focused on bringing.competition to the tel-
ecommunications sector; the number of fixed lines
is decreasing as mobile-cellular telephone service
expands
domestic: number of telecommunications opera-
tors has grown rapidly since the fixed-line market
opened to competition in 2003; combined fixed-
line and mobile-cellular subscribership roughly
150 per 100 persons
International: country code—371; the Latvian
network is now connected via fiber optic cable to
Estonia, Finland, and Sweden (2008)
Broadcast media: several national and regional
commercial TV stations are foreign-owned, 2
national TV stations are publicly owned; sys-
tem supplemented by privately owned regional
and local TV stations; cable and satellite multi-
channel TV services with domestic and foreign
broadcasts available; publicly owned broadcaster
operates 4 radio networks with dozens of stations
throughout the country; dozens of private broad-
casters also operate radio stations (2007)
Internet country code: lv
Internet hosts: 359,604 (2012)
country comparison to the world: 58
Internet users: 1.504 million (2009)
country comparison to the world: 81','d60fe1f523a053966f033f9b4432a80f27bd7b1536ceb5c04592cf0920e643b8','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1e871518a4a219d8771c74d9164385ea5809ea0a2b2ed506a26c3c838d9826eb',2025,'LB','Lebanon','communications',969,'Telephones—main lines in use: 900,000 (2011)
country comparison to the world: 82
Telephones—mobile cellular: 3.35 million (2011)
country comparison to the world: 121
Telephone system: general assessment: repair of
the telecommunications system, severely damaged
during the civil war, now complete
domestic: two mobile-cellular networks provide
good service; combined fixed-line and mobile-
cellular subscribership roughly 100 per 100 persons
international: country code—961; submarine
cable links to Cyprus, Egypt, and Syria; satellite
earth stations—2 Intelsat (1 Indian Ocean and
1 Atlantic Ocean); coaxial cable to Syria (2011)
Broadcast media: 7 TV stations, 1 of which is
state-owned; more than 30 radio stations, 1 of
which is state-owned; satellite and cable TV ser-
vices available; transmissions of at least 2 interna-
tional broadcasters are accessible through partner
stations (2007)
Internet country code: .|b
Internet hosts: 64,926 (2012)
country comparison to the world: 91
Internet users: | million (2009)
country comparison to the world: 101','a25b2045ed41f47fe5599d29ce16c7d125c6038edd0a79b161736431055c0a5c','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e3b1896d550d338076184aef499785b1cafccb5fee42d8190b8766c9e52ebd02',2025,'LS','Lesotho','communications',978,'Telephones—main lines in use: 38,600 (2011)
country comparison to the world: 168
Telephones—mobile cellular: 1.232 million (2011) -
country comparison to the world: 152
Telephone system: general assessment: rudimen-
tary system consisting of a modest number of lan-
dlines, a small microwave radio relay system, and
a small radiotelephone communication system;
mobile-cellular telephone system is expanding
THE CIA WORLD FACTBOOK
domestic: privatized in 2001, Telecom Lesotho was
tasked with providing an additional 50,000 fixed-
line connections within five years, a target not
met; mobile-cellular service dominates the market
and is expanding with a subscribership roughly 65
per 100 persons in 2011; rural services are scant
international: country code—266; satellite earth
station—l1 Intelsat (Atlantic Ocean) (2011)
Broadcast media: 1 state-owned TV station and
2 state-owned radio stations; government controls
most private broadcast media; satellite TV sub-
scription service available; transmissions of mul-
tiple international broadcasters obtainable (2008)
Internet country code: .ls
Internet hosts: 11,030 (2012)
country comparison to the world: 131
Internet users: 76,800 (2009)
country comparison to the world: 168','89679a662f41cafab68c3d26e6328e48f8aa7d9e8f3bc3a5d708487d7a095d7d','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a416dc67b0844a59f71f29707e5c0a6205819f86dfd23fede0975dd51695ba54',2025,'LR','Liberia','communications',988,'Telephones—main lines in use: 3,200 (2011)
country comparison to the world: 213
Telephones—mobile cellular: 2.03 million
(2011)
country comparison to the world: 140
Telephone system: general assessment: the
limited services available are found almost exclu-
sively in the capital Monrovia; fixed-line service
stagnant and extremely limited; telephone cover-
age extended to a number of other towns and rural
areas by four mobile-cellular network operators
domestic: mobile-cellular subscription base grow-
ing and teledensity reached 50 per 100 persons in
2011
international: country code—231; satellite earth
station—l1 Intelsat (Atlantic Ocean) (2010)
Broadcast media: 3 private TV stations; satellite
TV service available; 1 state-owned radio station;
about 15 independent radio stations broadcasting
in Monrovia, with another 25 local stations oper-
ating in other areas; transmissions of 2 interna-
tional broadcasters are available (2007)
Internet country code: iir -
Internet hosts: 7 (2012)
country comparison to the world: 229
Internet users: 20,000 (2009)
country comparison to the world: 194','56db95b8fdeb3eac36366089b660bbb2ea0f80573da85ec121c2fe1701059d4d','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('665eeb61d30ab4ab4303e3bf9354b96d7e900fceae67e8ddf9ce79200b0caa16',2025,'LY','Libya','communications',997,'Telephones—main lines in use: 1 million
(2011)
country comparison to the world: 78
Telephones—mobile cellular: 10 million (2011)
country comparison to the world: 77
Telephone system: general assessment: telecom-
munications system is state-owned and service is
poor, but investment is being made to upgrade;
state retains monopoly in fixed-line services;
mobile-cellular telephone system became opera-
tional in 1996
domestic: multiple providers for a mobile tel-
ephone system that is growing rapidly; combined
fixed-line and mobile-cellular teledensity has
soared
international; country code—218; satellite earth
stations—4 Intelsat, NA Arabsat, and NA Inter-
sputnik; submarine cable to France and Italy;
microwave radio relay to Tunisia and Egypt; tropo-
spheric scatter to Greece; participant in Medarab-
tèl (2010)
Broadcast media: state-funded and private TV
stations; some provinces operate local TV stations;
pan-Arab satellite TV stations are available; state-
funded radio (2012)
Internet country code: .ly
internet hosts: 17,926 (2012)
country comparison to the world: 121
internet users: 353,900 (2009)
country comparison to the world: 124','bf272897624165042ee1645d34603218f4e56142e9865affe3657db3217e9c11','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d85faefe7ff401a15907fd0532ca9352cb23ae2d68d1d43aeec2f3f2d87f0fbf',2025,'LI','Liechtenstein','communications',1006,'Telephones—main lines in use: 19,600 (2011)
country comparison to the world: 191
Telephones—mobile cellular: 37,000 (2011)
country comparison to the world: 203
Telephone system: general assessment: auto-
matic telephone system
domestic: fixed-line and mobile-cellular services
widely available; combined telephone service sub-
scribership exceeds 150 per 100 persons
international: country code—423; linked to
Swiss networks by cable and microwave radio relay
(2011)
Broadcast media: relies on foreign terrestrial and
satellite broadcasters for most broadcast media ser-
vices; first Liechtenstein-based TV station established
August 2008; Radio Liechtenstein operates multiple
radio stations; a Swiss-based broadcaster operates sev-
eral radio stations in Liechtenstein (2008)
Internet country code:.1i
Internet hosts: 14,278 (2012)
country comparison to the world: 128
Internet users: 23,000 (2009)
country comparison to the world: 189','bfb17b6dca84abe8ae8b9af125535aaa238716681c9e5c77e2d66286d1706d73','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5125c2443af1949032f42aa680e6d801dc9f5628d353c20622a14fdba7d93f69',2025,'LT','Lithuania','communications',1013,'Telephones—main lines In use: 723,000 (2011)
country comparison to the world: 88
Telephones—mobile cellular: 5.004 million (2011)
country comparison to the world: 104
Telephone system: general assessment: adequate;
being modernized to provide improved interna-
tional capability and better residential access
domestic: rapid expansion of mobile-cellular ser-
vices has resulted in a steady decline in the number
of fixed-line connections; mobile-cellular teleden-
sity stands at about 140 per 100 persons
international: country code—370; major inter-
national connections to Denmark, Sweden, and
Norway by submarine cable for further transmis-
sion by satellite} landline connections to Latvia
and Poland (2010)
Broadcast media: public broadcaster operates 3
channels with the third channel—a satellite chan-
nel—introduced in 2007; various privately owned
commercial TV broadcasters operate national and
multiple regional channels; many privately owned
local TV stations; multi-channel cable and satellite
TV services available; publicly owned broadcaster
operates 3 radio networks; many privately owned
commercial broadcasters, many with repeater stations
in various regions throughout the country (2007)
internet country code: it
Internet hosts: 1.205 million (2012)
country comparison to the world: 43
Internet users: 1.964 million (2009)
country comparison to the world: 75','12fe913260d5b4ea6770ebf32ff1e0f5af29b6cdbfffa14fc88dd5ed5fc77d68','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4aa2f32c4665b7027b697121aa90446be6101686404a19b2ec8bc6c3934a42ff',2025,'LU','Luxembourg','communications',1018,'Telephones—main lines in use: 279,100 (2011)
country comparison to the world: 121
Telephones—mobile cellular: 765,000 (2011)
country comparison to the world: 159
Telephone system: general assessment: highly
developed, completely automated and efficient
system, mainly buried cables
domestic: fixed line teledensity over 50 per 100
persons; nationwide mobile-cellular telephone
system with market for mobile-cellular phones
virtually saturated
international: country code—352 (2010)
Broadcast media: Luxembourg has a long tradition
of operating radio and TV services to pan-European
audiences and is home to Europe’s largest privately
owned broadcast media group, the RTL group,
440
THE CIA WORLD FACTBOOK
which operates 46 TV stations and 29 radio stations
in Europe; also home to Europe''s largest satellite
operator, Societe Europeenne des Satellites (SES);
domestically, the RTL group operates TV and radio
networks; other domestic private radio and TV
operators and French and German stations availa-
ble; satellite and cable TV services available (2008)
Internet country code: .lu
Internet hosts: 250,900 (2012)
country comparison to the world: 68
Internet users: 424,500 (2009)
country comparison to the world: 121
Telephones—main lines in use: 165,500 (2011)
country comparison to the world: 131
Telephones—mobile cellular: 1.353 million
(2011)
country comparison to the world: 148
Telephone system: general assessment: fairly
modern communication facilities maintained for
domestic and international services
domestic: termination of monopoly over mobile-cel-
lular telephone services in 2001 spurred sharp increase
in subscriptions with mobile-cellular teledensity
exceeding 200 per 100 persons; fixed-line subscrib-
ership appears to have peaked and is now in decline
international: country code—853; landing point
for the SEA-ME-WE-3 submarine cable network
that provides links to Asia, the Middle East, and
Europe; HF radiotelephone communication facil-
ity; satellite earth station—1 Intelsat (Indian
Ocean) (2011)
Broadcast media: local government dominates
broadcast media; 2 television stations operated by
the government with one broadcasting in Portu-
guese and the other in Cantonese and Mandarin;
1 cable TV and 4 satellite TV services available; 3
radio stations broadcasting, of which 2 are govern-
ment-operated (2012)
(internet country code: .mo
Internet hosts: 327 (2012)
country comparison. to the world: 189
Internet users: 270,200 (2009)
country comparison to the world: 134','72268db45e74b5af0d6c51b933769a739eaa7372533647bd9ff0bf42e30e6564','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('768d9a5070828381236310c5b8ee73e24dcd1bc8ba57c1e1150ad023c8ee4337',2025,'MG','Madagascar','communications',1031,'Telephones—main lines in use: 138,100 (2011)
country comparison to the world: 139
Telephones—mobile cellular: 8.665 million
(2011)
country comparison to the world: 84
Telephone system: general assessment: system is
above average for the region; Antananarivo’s main
telephone exchange modernized in the late 1990s,
but the rest of the analogue-based telephone sys-
tem is poorly developed
domestic: combined fixed-line and mobile-cellular
teledensity about 40 per 100 persons
international: country code—261; landing point
for the EASSy, SEACOM, and LION fiber-optic
submarine cable systems; satellite earth sta-
tions—2 (1 Intelsat—Indian Ocean, 1 Intersput-
nik—Atlantic Ocean region) (2010)
Broadcast media: state-owned Radio Nation-
ale Malagasy (RNM) and Television Malagasy
(TYM) have an extensive national network reach;
privately owned radio and TV broadcasters in cit-
ies and major towns; state-run radio dominates in
tural areas; relays of 2 international broadcasters
are available in Antananarivo (2007)
Internet country code: .mg
Internet hosts: 38,392 (2012)
country comparison to the world: 102
Internet users: 319,900 (2009)
country comparison to the world: 127','8307e64166b8048d4bfd3225c4c618a136f27ad5ec452371c4eee6ccac47d66f','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('224de07648f263b1b55a915b540cda8b206977511c8a9e89342115ad7cf72f6f',2025,'MW','Malawi','communications',1042,'Telephones—main lines in use: 173,500 (2011)
country comparison to the world: 129
Telephones—mobile cellular: 3.952 million (2011)
country comparison to the world: 116
Telephone system: general assessment: rudimen-
tary; privatization of Malawi Telecommunications
(MTL), a necessary step in bringing improvement
to telecommunications services, completed in 2006
domestic: limited fixed-line subscribership of
about 1 per 100 persons; mobile-cellular services
are expanding but network coverage is limited
and is based around the main urban areas; mobile-
cellular subscribership about 25 per 100 persons
international: country code—265; satellite earth
stations—2 Intelsat (1 Indian Ocean, 1 Atlantic
Ocean) (2010)
Broadcast media: radio is the main broadcast
medium; state-run radio has the widest geographic
broadcasting reach, but about a dozen privately
owned radio stations broadcast in major urban
areas; the single TV network is government-
owned; relays of multiple international broadcast-
ers are available (2007)
Internet country code: mw -
Internet hosts: 1,099 (2012)
THE CIA WORLD FACTBOOK
country comparison to the world: 171
Internet users: 716,400 (2009)
country comparison to the world: 109','3ce22dfeb761d0507c276074c941a120edbc760f6dd873f5bea054a50c6d3892','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('afa998cd535c10d6c58c7ca49e8647e3022e16b17707699d9a383add1a7a5851',2025,'MY','Malaysia','communications',1053,'Telephones—main tines in use: 4.243 million
(2011)
country comparison to the world: 40
Telephones—mobile cellular: 36.661 million
(2012) à
country comparison to the world: 30
Telephone system: general assessment: modern
system featuring good intercity service on Peninsu-
lar Malaysia provided mainly by microwave radio
relay and an adequate intercity microwave radio
relay network between Sabah and Sarawak via
Brunei; international service excellent
domestic: domestic satellite system with 2 earth
stations; combined fixed-line and mobilecellular
tele density roughly 140 per 100 persons
international; country code—60; landing point
for several major international submarine cable
networks that provide connectivity to Asia, Middle
East, and Europe; satellite earth stations—2 Intel-
sat (1 Indian Ocean, | Pacific Ocean) (2011)
Broadcast media: state-owned TV broadcaster
operates 2 TV networks with relays throughout
the country, and the leading private commercial
media group operates 4 TV stations with numer-
ous relays throughout the country; satellite TV
subscription service is available; state-owned radio
broadcaster operates multiple national networks as
well as regional and local stations; many private
commercial radio broadcasters and some subscrip-
tion satellite radio services are available; about 55
radio stations overall (2012)
Internet country code: .my
Internet hosts: 422,470 (2012)
country comparison to the world: 53
Interne? users: 15.355 million (2009)
country comparison to the world: 26','cc2825657c896543a04d7918b36287983571dca11971e2649ecce0e04520df94','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1f729314d93a93ad1f9e58aa80495536fcdddd314670c3636e1978adb95afb91',2025,'MV','Maldives','communications',1061,'Telephones—main lines in use: 24,100 (2011)
country comparison to the world: 183
Telephones—mobile cellular: 530,400 (2011)
country comparison to the world: 164
Telephone system: general assessment: tele-
phone services have improved; inter-atoll commu-
nication through microwave links; all inhabited
islands and resorts are connected with telephone
and fax service
domestic: each island now has at least 1 public
telephone, and there are mobile-cellular networks
with a rapidly expanding subscribership that has
reached 135 per 100 persons
international: country code—960; linked to
international submarine cable Fiber-Optic Link
Around the Globe (FLAG); satellite earth sta-
tion—3 Intelsat (Indian Ocean) (2011)
Broadcast media: state-owned radio and TV
monopoly until recently; state-owned TV oper-
ates 2 channels; 3 privately owned TV stations;
state owns Voice of Maldives and operates both
an entertainment and a music-based station; 5 pri-
vately owned radio stations (2012)
Internet country code: mv
Internet hosts: 3,296 (2012)
country comparison to the world: 153
Internet users: 86,400 (2009)
country comparison to the world: 164','bb6208dc070c62d30becd2c1c96c2fd03464c92b9be71093a00cc10f1ef433f6','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e97ba7f6fc3fb40c64824fa364ee3fefd495cc410264e3c4228e65bdbc3fa5ac',2025,'ML','Mali','communications',1071,'Telephones—main lines in use: 104,700 (2011)
country comparison to the world: 145
Telephones—mobile cellular: 10.822 million
(2011)
country comparison to the world: 70
Telephone system: general assessment: domestic
system unreliable but improving; increasing use of
local radio loops to extend network coverage to
remote areas
domestic: fixed-line subscribership remains less
than 1 per 100 persons; mobile-ceilular subscrib-
ership has increased sharply to about 70 per 100
persons
international: country code—223;
communications center and fiber-optic links to
neighboring countries; satellite earth stations—2
Intelsat (1 Atlantic Ocean, 1 Indian Ocean)
(2010)
Broadcast media: national public TV broad-
caster; 2 privately owned companies provide sub-
scription services to foreign multi-channel TV
packages; national public radio broadcaster sup-
plemented by a large number of privately owned
and community broadcast stations; transmissions
of multiple international broadcasters are avail-
able (2007)
satellite
Internet country code: ml
Internet hosts: 437 (2012)
country comparison to the world: 187
Internet users: 249,800 (2009)
country comparison to the world: 135','5bb37eb6d22491ac361cc063f5ec88b7547364d3b16eec909c1f958aacc0d926','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('873d18d0a6cae8d7b86873865d1c321083a14c6266f502e2bfc949b451c5b29b',2025,'MT','Malta','communications',1080,'Telephones—main lines in use: 232,300 (2011)
country comparison to the world: 126
Telephones—mobile cellular: 521,700 (2011)
country comparison to the world: 166
Telephone system: general assessment: auto-
matic system featuring submarine cable and
microwave radio relay between islands
domestic: combined fixed-line and mobile-cellular
subscribership exceeds 180 per 100 persons
international: country code—356; submarine
cable connects to Italy; satellite earth station—1
Intelsat (Atlantic Ocean) (2011)
Broadcast media: 2 publicly owned TV sta-
tions, Television Malta (TVM) broadcasting
nationally plus an educational channel; several
privately owned national television stations, two
of which are owned by political parties; Italian
and British broadcast programs are available;
multi-channel cable and satellite TV services
are available; publicly owned radio broadcaster
operates 1 station; roughly 20 commercial radio
stations (2011 )
Internet country code: .mt
Internet hosts: 14,754 (2012)
country comparison to the world: 125
Internet users: 240,600 (2009)
country comparison to the world: 137','7b813a79d1257023efde42c8d5ff1644a0204282309cec51ee9a31f30bbf47bb','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5fdf697e73840b7310aefe943fccb17b61829d477fec395c1a93fc8a8bcdf109',2025,'MH','Marshall Islands','communications',1090,'Telephones—main lines in use: 4,400 (2010)
country comparison to the world: 212
Telephones—mobile cellular: 3,800 (2010)
country comparison to the world: 214
Telephone system: general assessment: digital
switching equipment; modem services include telex,
cellular, Internet, international calling, caller ID,
and leased data circuits
domestic: Majuro Atoll and Ebeye and Kwaja-
lein islands have regular, seven-digit, direct-dial
telephones; other islands interconnected by high
frequency radiotelephone (used mostly for govern-
ment purposes) and mini-satellite telephones
international: country code—6972; satellite earth
stations—2 Intelsat (Pacific Ocean); US Govern-
ment satellite communications system on Kwaja-
lein (2005)
Broadcast media: no TV broadcast station; a
cable network is available on Majuro with pro-
gramming via videotape replay and satellite relays;
4 radio broadcast stations; American Armed
Forces Radio and Television Service (AFRTS)
provides satellite radio and television service to
Kwajalein Atoll (2009)
Internet country code: .mh
Internet hosts: 3 (2012)
country comparison to the world: 233
Internet users: 2,200 (2009)
country comparison to the world: 210','198978e34cfd0b52390475177c96a8fed4cef09dcfe8218ed4b71fdaf41f7255','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ca30320568229a5d918ebe7e66bf24a7e078c3e736813e879d62b8a79d3437a1',2025,'MR','Mauritania','communications',1094,'Telephones—main lines in use: 72,300 (2011)
country comparison to the world: 157
Telephones—mobile cellular: 3.315 million
(2011)
country comparison to the world: 122
Telephone system: general assessment: lim-
ited systemof cable and open-wire lines, minor
microwave radio relay links, and radiotelephone
communications stations; mobile-cellular ser-
vices expanding rapidly
domestic: Mauritel, the national telecommu-
nications company, was privatized in 2001 but
remains the monopoly provider of fixed-line
services; fixed-line teledensity 2 per 100 persons;
mobile-cellular network coverage extends mainly
to urban areas with a teledensity of roughly 100
per 100 persons; mostly cable and open-wire lines;
a domestic satellite telecommunications system-
links Nouakchott with regional capitals
international: country code—222; satellite
earth stations—3 (1 Intelsat—Atlantic Ocean,
2 Arabsat); fiber-optic and Asymmetric Digital
Subscriber Line (ADSL) cables for Internet access
(2009)
Broadcast media: broadcast media state-owned;
l state-run TV and 1 state-run radio network; Tel-
evision de Mauritanie, the state-run TV station,
has an additional 6 regional TV stations that pro-
vide local programming (2008)
Internet country code: mr
Internet hosts: 22 (2012)
country comparison to the world: 221
Internet users: 75,0 (2009)
country comparison to the world: 170','5924a91012c028cc1f9cc04638017244b68bc0ab48a7e459da7ba30c2791315f','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3e153ff0a066aff5583a92c35b2c51e61f0f50e6927598dce030435c400f6f2c',2025,'MU','Mauritius','communications',1100,'Telephones—main lines in use: 374,600 (2011)
country comparison to the world: 107
Telephones—mobile cellular: 1.294 million
(2011)
country comparison to the world: 150
Telephone system: general assessment: small
system with good service
domestic: monopoly over fixed-line services ter-
minated in 2005; fixed-line teledensity roughly 30
per 100 persons; mobile-cellular services launched
in 1989 with current teledensity roughly 100 per
100 persons È
international: country code—230; landing point
for the SAFE submarine cable that provides links
to Asia and South Africa where it connects to
the SAT-3/WASC submarine cable that provides
further links to parts of East Africa, and Europe;
satellite earth station—I Intelsat (Indian Ocean);
new microwave link to Reunion; HF radiotel-
ephone links to several countries (2011)
Broadcast media: the government maintains
control over TV broadcasting through the Mau-
titius Broadcasting Corporation (MBC), which
operates 3 analog and 10 digital TV stations; MBC
is a shareholder in a local company that operates 2
pay-TV stations; the state retains the largest radio
broadcast network with multiple stations; several
private radio broadcasters have entered the mar-
ket since 2001; transmissions of at least 2 intema-
tional broadcasters are available (2007)
Internet country code: .mu
Internet hosts: 51,139 (2012)
country comparison to the world: 95
Internet users: 290,000 (2009)
country comparison to the world: 132','b81cf3570d6a29358baeb75ad58fb55d29f2247b578565fc20c7d0442b464bdc','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e36da25bfe3562b4adb16406cd3c0097476ddb048e74e61b1de918ceb53931e2',2025,'RO','Romania','communications',1112,'Telephones—main lines in use: 1.18 million
(2011) D
country comparison to the world: 71
Telephones—mobile cellular: 3.715 million
(2011)
country comparison to the world: 118
Telephone system: general assessment: poor
service outside Chisinau; some modernization is
under way
domestic: multiple private operators of GSM
mobile-cellular telephone service are operat-
ing; GPRS system is being introduced; a CDMA
mobile telephone network began operations in
2007; combined fixed-line and mobile-cellular tel-
edensity 100 per 100 persons
international: country code—373; service
through Romania and Russia via landline; satellite
earth stations—at least 3 (Intelsat, Eutelsat, and
Intersputnik) (2011)
Broadcast media: state-owned national radio-TV
broadcaster operates 2 TV and 2 radio stations; a
total of nearly 40 terrestrial TV channels and some
50 radio stations are in operation; Russian and
Romanian channels also are available (2007)
Internet country code: .md
Internet hosts: 711,564 (2012)
country comparison to the world: 51
Internet users: 1.333 million (2009)
country comparison to the world: 89
Telephones—main lines in use: 4.68 million
(2011)
country comparison to the world: 31
Telephones—mobile cellular: 23.4 million
(2011)
country comparison to the world: 44
Telephone system: general assessment: the
telecommunications sector is being expanded
and modernized; domestic and international ser-
vice improving rapidly, especially mobile-cellular
services
domestic: more than 90 percent of telephone net-
work is automatic; fixed-line teledensity exceeds
20 telephones per 100 persons; mobile-cellular tel-
edensity roughly 1 10 telephones per 100 persons
international: country code—40; the Black
Sea Fiber Optic System provides connectivity to
RUSSIA
Bulgaria and Turkey; satellite earth stations—10;
digital, international, direct-dial exchanges oper-
ate in Bucharest (2011) «
Broadcast media: 2 mixture of public and private
TYV stations; the public broadcaster operates multi-
ple stations; roughly 100 private national, regional,
and local stations; more than 75% of households
are connected to multi-channel cable or satellite
TV systems that provide access to Romanian, Euro-
pean, and international stations; state-owned public
radio broadcaster operates 4 national networks and
tegional and local stations; more than 100 private
radio stations (2008)
Internet country code: .ro
Internet hosts: 2.667 million (2012)
scountry comparison to the world: 35
Internet users: 7.787 million (2009)
country comparison to the world: 37
Telephones—main lines in use: 44.152 million
(2011)
country comparison to the world: 5
Telephones—mobilie cellular: 236.7 million
(2011)
country comparison to the world: 6
Telephone system: general assessment: the tel-
ephone system is experiencing significant changes;
there are more than 1,000 companies licensed to
offer communication services; access to digital
lines has improved, particularly in urban centers;
Internet and e-mail services are improving; Russia
has made progress toward building the telecom-
munications infrastructure necessary for a market
economy; the estimated number of mobile sub-
scribers jumped from fewer than 1 million in 1
998 to more than 235 million in 2011; fixed line
service has improved but a large demand remains
domestic: cross-country digital trunk lines run from
Saint Petersburg to Khabarovsk, and from Mos-
cow to Novorossiysk; the telephone systems in 60
regional capitals have modern digital infrastructures;
cellular services, both analog and digital, are avail-
able in many areas; in rural areas, the telephone ser-
vices are still outdated, inadequate, and low density
international: country code—7; Russia is con-
nected internationally by undersea fiber optic
cables; satellite earth stations provide access to
Intelsat, Intersputnik, Eutelsat, Inmarsat, and
Orbita systems (201 1)
Broadcast media: 6 national TV stations with the
federal government owning 1 and holding a con-
trolling interest in a second; state-owned Gazprom
maintains a controlling interest in a third national
channel; government-aftiliated Bank Rossiya owns
controlling interest in a fourth and fifth, while the
sixth national channel is owned by the Moscow city
administration; roughly 3,300 national, regional,
and local TV stations with over two-thirds com-
pletely or partially controlled by the federal or local
governments; satellite TV services are available;
2 state-run national radio networks with a third
majority-owned by Gazprom; roughly 2,400 public
and commercial radio stations (2007)
Internet country code: .ru; note—Russia also has
responsibility for a legacy domain “.su” that was
allocated to the Soviet Union and is being phased
out
Internet hosts: 14.865 million (2012)
country comparison to the world: 10
Internet users: 40.853 million (2009)
country comparison to the world: 10','08f5035055b4fb12640e24325b3e232c96c4fe21b1d368f31cdedbe416c0689d','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('dcde1558eb424e0949540a482797c3dd81b0e7f637b39f4d66215d2d2db52a87',2025,'MC','Monaco','communications',1119,'Telephones—main lines in use: 44,500 (2011)
country comparison to the world: 166
Telephones—mobile cellular: 31,800 (2011)
country comparison to the world: 206
Telephone system: general assessment: modem
automatic telephone system; the country’s sole
fixed line operator offers a full range of services to
residential and business customers
domestic: combined fixed-line and mobile-cellular
teledensity exceeds 200 per 100 persons
international: country code—377; no satellite
earth stations; connected by cable into the French
communications system (2011 )
Broadcast media: TV Monte-Carlo (TMC)
operates a TV network; cable TV available; Radio
Monte-Carlo has extensive radio networks in
France and Italy with French-language broadcasts
to France beginning in the 1960s and Italian-lan-
guage broadcasts to Italy beginning in the 1970s;
other radio stations include Riviera Radio and
Radio Monaco (2012)
Internet country code: .mc
Internet hosts: 26,009 (2012)
country comparison to the world: 111
Internet users: 23,000 (2009)
country comparison to the world: 191','b9a4bb0b1d2e35ca5ee5d110e448cd337f40d41280535e8c45f6ad3906221461','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a9114cdfb327347274b9410f7de6d1f42fd85d0c0a5dce71bec0dce8437724ee',2025,'MN','Mongolia','communications',1124,'Telephones—main lines in use: 187,600 (2011)
country comparison to the world: 128
494
THE CIA WORLD FACTBOOK
Telephones—mobile cellular: 2.942 million
(2011)
country comparison to the world: 129
Telephone system: general assessment: net-
work is improving with international direct
dialing available in many areas; a fiber-optic
network has been installed that is improving
broadband and communication services between
major urban centers with multiple companies
providing inter-city fiber-optic cable services
domestic: very low fixed-line teledensity; there are
multiple mobile-cellular providers and subscriber-
ship is increasing
international: country code—976; satellite earth
stations—7 (2011)
Broadcast media: following a law passed
in 2005, Mongolia’s state-run radio and TV
provider converted to a public service pro-
vider; also available are private radio and TV
broadcasters, as well as multi-channel satellite
and cable TV providers; more than 100 radio
stations, including some 20 via repeaters for
the public broadcaster; transmissions of mul-
tiple international broadcasters are available
(2008)
Internet country code: .mn
Internet hosts: 20,084 (2012)
country comparison to the world: 118
Internet users: 330,000 (2008)
country comparison to the world: 125','a6d09b74acf9584f5f75655863d3b70542df153a2ec686831848dd4155398397','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9e2a35579d38f273834d4b6191436fec5aa1be9069ae2ad3dc9ce21b1c695c24',2025,'ME','Montenegro','communications',1133,'Telephones—main lines in use: 169,500 (2010)
country comparison to the world: 130
`
Telephones—mobile cellular: 1.17 million
(2010)
country comparison to the world: 153
Telephone system: general assessment: modern
telecommunications system with access to Euro-
pean satellites
domestic: GSM mobile-cellular service, available
through multiple providers with national cover-
age, is growing
international: country code—382; 2 interna-
tional switches connect the national system
(2011) Broadcast media: state-funded national
radio-TV broadcaster operates 2 terrestrial TV
` networks, 1 satellite TV channel, and 2 radio net-
works; 4 public TV stations and some 20 private
TV stations; 14 local public radio stations and
more than 40 private radio stations (2007)
Internet country code: .me
Internet hosts: 10,088 (2012)
country comparison to the world: 135
Internet users: 280,000 (2009)
country comparison to the world: 133','895f09912ad4baa8e1d57593b791535cde6b72a4d338e47511dd8a30d77f6651','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e394e7d671fcecaa7cd56526b465f1ecd4b376e0ffad3e5c541c4245e6f771b6',2025,'MS','Montserrat','communications',1143,'Telephones—main lines in use: 2,600 (2010)
country comparison to the world: 216
Jelephones—mobile cellular: 4,200 (2010)
country comparison to the world: 213
Telephone system: general assessment: modern
and fully digitalized
domestic: combined fixed-line and mobile-cellular
teledensity exceeds 100 per 100 persons
international: country code—l!-664; landing
point for the East Caribbean Fiber System (ECFS)
optic submarine cable with links to 13 other
islands in the eastern Caribbean extending from
the British Virgin Islands to Trinidad (2011)
Broadcast media: Radio Montserrat, a public
radio broadcaster, transmits on 1 station and has a
repeater transmission to a second station; repeater
transmissions from the GEM Radio Network of
Trinidad and Tobago provide another 2 radio sta-
tions; cable and satellite TV available (2007)
THE CIA WORLD FACTBOOK
Internet country code: .ms
Internet hosts: 2,431 (2012)
country comparison to the world: 160
Internet users: 1,200 (2009)
country comparison to the world: 213','2b1418d9f4f36fba0908bbd0a5a3c3ff7a4495af80f5341c46506fa8a35142f4','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bc6e14c07f266d1ec82737bacaf13e191db281e622c3a63fcd0eec1cd18e9c9a',2025,'MA','Morocco','communications',1152,'Telephones—main lines in use: 3.566 million
(2011)
country comparison to the world: 45
Telephones—mobile cellular: 36.554 million
(2011)
country comparison to the world: 31
Telephone system: general assessment: good
system composed of open-wire lines, cables, and
microwave radio relay links; principal switching
centers are Casablanca and Rabar; national net-
work nearly 100% digital using fiber-optic links;
improved rural service employs microwave radio
relay; Internet available but expensive
domestic: fixed-line teledensity is roughly 10
per 100 persons; mobile-cellular subscribership
exceeds 100 per 100 persons
international: country code—212; landing point
for the Atlas Offshore, Estepona-Tetouan, Euroaf-
rica, Spain-Morocco, and SEA-ME-WE-3 fiber-
optic telecommunications undersea cables that
provide connectivity to Asia, the Middle East, and
Europe; satellite earth stations—2 Intelsat (Atlan-
tic Ocean) and i Arabsat; microwave radio relay
to Gibraltar, Spain, and Western Sahara; coaxial
cable and microwave radio relay to Algeria; par-
ticipant in Medarabtel; fiber-optic cable link from
Agadir to Algeria and Tunisia (2011)
Broadcast media: 2 TV broadcast networks with
state-run Radio-Television Marocaine (RTM)
operating one network and the state partially own-
ing the other; foreign TV broadcasts are available
via satellite dish; 3 radio broadcast networks with
RTM operating one; the government-owned net-
work includes 10 regional radio channels in addi-
tion to its national service (2007)
Internet country code: .ma
internet hosts: 277,338 (2012)
country comparison to the world: 66
internet users: 13.213 million (2009)
country comparison to the world: 29','6e5bac7a6f379c4046e5f88e9b6dd89cc1e1ad53d0ea8827dea8e31c31282823','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('218d910970211fa59004cbd132a7a0a91cd1469722e8328c7cc76d94c5a99304',2025,'MZ','Mozambique','communications',1162,'Telephones—main lines in use: 88,100 (2011)
country comparison to the world: 147
Telephones—mobile cellular: 7.855 million
(2011)
country comparison to the world: 89
Telephone system: general assessment: a fair
telecommunications system that is shackled with
a heavy state presence, lack of competition, and
high operating costs and charges
domestic: stagnation in the fixed-line network
contrasts with rapid growth in the mobile-cellular
network; mobile-cellular coverage now includes
all the main cities and key roads, including those
from Maputo to the South African and Swaziland
borders, the national highway through Gaza and
Inhambane provinces, the Beira corridor, and
from Nampula to Nacala; extremely low fixed-line
teledensity; despite significant growth in mobile-
cellular services, teledensity remains low at about
35 per 100 persons
international: country code—258; landing point
for the EASSy and SEACOM fiber-optic sub-
marine cable systems; satellite earth stations—5
Intelsat (2 Atlantic Ocean and 3 Indian Ocean)
(2011)
Broadcast media: state-run TV station supple-
mented by private TV station; Portuguese state
TV''s African service, RTP Africa, and Brazilian-
owned TV Miramar are available; state-run radio
provides nearly 100% territorial coverage and
broadcasts in multiple languages; a number of pri-
vately owned and community-operated stations;
transmissions of multiple international broadcast-
ers are available (2007)
internet country code: .mz
Internet hosts: 89,737 (2012)
country comparison to the world: 82
Internet users: 613,600 (2009)
country comparison to the world: 113','540dd8a0da7f77d59397485ada4393604432c7947881010aad82338ac644d5a5','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4cbc9bfd1bb3b71e53044d6cb26e522aeded16355b32b84d752ea6bd0ffdb561',2025,'NA','Namibia','communications',1169,'Telephones—main lines in use: 140,000 (2011)
country comparison to the world: 138
Telephones—mobile cellular: 2.24 million (2011)
country comparison to the world: 136
Telephone system: general assessment: good
ssystem; core fiber-optic network links most centers
and connections are now digital
domestic: multiple mobile-cellular providers with
a combined subscribership of more than 100 tel-
ephones per 100 persons
international: country code—264; fiber-optic
cable to South Africa, microwave radio relay
link to Botswana, direct links to other neighbor-
ing countries; connected to the South African
Far East (SAFE) submarine cable through South
Africa; satellite earth stations—4 Intelsat (2010)
Broadcast media: 1 private and 1 state-run TV
station; satellite and cable TV service is available;
state-run radio service broadcasts in multiple lan-
guages; about a dozen private radio stations; trans-
missions of multiple international broadcasters are
available (2007)
Internet country code:.na
Internet hosts: 78,280 (2012)
country comparison to the world: 84
Internet users: 127,500 (2009)
country comparison to the world: 151','333edc409aaac0454a89c6a500f49f60a85fcbded3bb53917880f3dfecfb1e78','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('faa18ed0895cc634dc4c70df3bf6239429b257fe805bbea15eb791667d40e986',2025,'NR','Nauru','communications',1176,'Telephones—main lines in use: 1,900 (2009)
country comparison to the world: 218
Telephones—mobile cellular: 6,700 (2011)
country comparison to the world: 212
Telephone system: general assessment: adequate
local and international radiotelephone communi-
cation provided via Australian facilities
international: country code—674; satellite earth
station—l| Intelsat (Pacific Ocean)
Broadcast media: 1 government-owned TV sta-
tion broadcasting programs from New Zealand sent
via satellite or on videotape; 1 government-owned
tadio station, broadcasting on AM and FM, utilizes
Australian and British programs (2009)
Internet country code:.nr
Internet hosts: 8,162 (2012)
country comparison to the world: 138','ad53a7dfd4a22ff1d4a5bdedfeeb6474f994411c44add7b0facb72630df9ef5a','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('80fc28ea74f975086ee3377a80cc4d1c602e6a6a79d3a6274551b09819d2a35e',2025,'NP','Nepal','communications',1187,'Telephones—main lines in use: 845,500 (2011) `
country comparison to the world: 85
Telephones—mobile cellular: 13.355 million
(2011)
country comparison to the world: 58
Telephone system: general assessment: poor tel-
ephone and telegraph service; fair radiotelephone
communication service and mobile-cellular tel-
ephone network
domestic: mobile-cellular telephone subscriber-
ship base is increasing with roughly 90% of the
population living in areas covered by mobile
carriers
international: country code—977; radiotele-
phone communications; microwave and fiber lan-
dlines to India; satellite earth station—1 Intelsat
(Indian Ocean) (2011)
Broadcast media:. state operates 2 TV stations
as well as national and regional radio stations;
roughly 30 independent TV channels are regis-
tered with only about half in regular operation;
nearly 400 FM radio stations are licensed with
roughly 300 operational (2007)
internet country code:.np
internet hosts: 41,256 (2012)
country comparison to the world: 100
Internet users: 577,800 (2009)
country comparison to the world: 116','4624ce4cfe6a747cb4df626d9444fb5ddf19cd4078d93745a28a6b422008b6dc','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('dfd3edadb3324a6a2b209c6388a10e082e93c521509ce46f62d85128cf902ae4',2025,'NL','Netherlands','communications',1197,'Telephones—main lines in use: 7.135 million
(2011)
country comparison to the world: 25
Telephones—mobile cellular: 19.835 million
(2011)
country comparison to the world: 48
Telephone system: general assessment: highly
developed and well maintained
domestic: extensive fixed-line fiber-optic network;
large cellular telephone system with 5 major opera-
tors utilizing the third generation of the Global
System for Mobile Communications (GSM) tech-
nology; one in five households now use Voice over
the Internet Protocol (VolP) services
international: country code—31;
cables provide links to the US and Europe; satel-
lite earth stations—5 (3 Intelsat—1 Indian Ocean
and 2 Atlantic Ocean, | Eutelsat, and 1 Inmarsat
(2011)
Broadcast media: more than 90% of households
are connected to cable or satellite TV systems that
provide a wide range of domestic and foreign chan-
nels; public service broadcast system includes mul-
tiple broadcasters, 3 with a national reach and the
remainder operating in regional and local markets;
2 major nationwide commercial television compa-
nies, each with 3 or more stations, and many com-
mercial TV stations in regional and local markets;
nearly 600 radio stations with a mix of public and
private stations providing national or regional cov-
erage (2008)
Internet country code:.ni
Internet hosts: 13.699 million (2012)
submarine
country comparison to the world: 11
Internet users: 14.872 million (2009)
country comparison to the world: 27','74e9dcd9db496328c72485863c91be6bfa0adb31d0aec3ed90511d4bf0ebb5c9','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('01634e37eed334105613130befa2bef5e50220ca3b16adb825cab0eb8df631f8',2025,'NC','New Caledonia','communications',1203,'Telephones—main lines in use: 76,200 (2011)
country comparison to the world: 152
Telephones—mobile cellular: 227,300 (2011)
country comparison to the world: 176
Telephone system: general assessment: a subma-
rine cable network connection between New Cale-
donia and Australia, completed in 2007, increased
network capacity and improved high-speed con-
nectivity and access to international networks
domestic: combined fixed-line and mobile-cellu-
lar telephone subscribership exceeds 100 per 100
persons
international: country code—687; satellite earth
station—1 Intelsat (Pacific Ocean) (2010)
Broadcast media: the publicly owned French
Overseas Network (RFO), which operates in
France’s overseas departments and territories,
broadcasts over the RFO Nouvelle Caledonie TV
and radio stations; a small number of privately
owned radio stations also broadcast (2008)
Internet country code:.nc
Internet hosts: 34,231 (2012)
country comparison to the world: 104
Internet users: 85,0 (2009)
country comparison to the world: 165','e496a80289cf13bea12d98cb06cd457e4bdeba03b25e3c6b7544bccdba164fc0','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c945e42850ed2cc955197372d9c76b20db45116c876cef31e39e962eb41dd9ef',2025,'NZ','New Zealand','communications',1209,'Telephones—main lines in use: 1.88 million
(2011)
country comparison to the world: 60
Telephones—mobile cellular: 4.82 million
(2011)
country comparison to the world: 108
Telephone system: general assessment: excel-
lent domestic and international systems
domestic: combined fixed-line and mobile-cellu-
lar telephone subscribership exceeds 150 per 100
persons
international: country code—64; the Southem
Cross submarine cable system provides links to Aus-
tralia, Fiji, and the US; satellite earth stations—8
(1 Inmarsat—Pacific Ocean, 7 other) (2011)
Broadcast media: state-owned Television New
Zealand operates multiple TV networks and
state-owned Radio New Zealand operates 3 radio
networks and an external shortwave radio service
to the South Pacific region; a small number of
national commercial TV and radio stations and
many regional commercial television and radio
stations are available; cable and satellite TV sys-
tems are available (2008)
Internet country code:.nz
Internet hosts: 3.026 million (2012)
country comparison to the world: 34
Internet users: 3.4 million (2009)
country comparison to the world: 62','f2d47fa9989a513c04f35892a608a0a3cee320050a27d907b5a352f827997c5b','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9010bcc554bc5ffa33cf29427fca711649a5187052ad8e91e6d6970e1204ca07',2025,'NI','Nicaragua','communications',1220,'Telephones—main fines in use: 287,600 (2011)
country comparison to the world: 118
Telephones—mobile cellular: 4.822 million
(2011) i
country comparison to the world: 107
Telephone system: general assessment: system
being upgraded by foreign investment; nearly all
installed telecommunications capacity now uses
digital technology, owing to investments since
privatization of the formerly state-owned telecom-
munications company
domestic: since privatization, access to fixed-line
and mobile-cellular services has improved; fixed-
line teledensity roughly 5 per 100 persons; mobile-
cellular telephone subscribership has increased to
roughly 85 per 100 persons
international: country code—505; the Ameri-
cas Region Caribbean Ring System (ARCOS-1)
fiber optic submarine cable provides connectivity
to South and Central America, parts of the Car-
ibbean, and the US; satellite earth stations—]
Intersputnik (Atlantic Ocean region) and 1 Intel-
sat (Atlantic Ocean) (2011)
Broadcast media: multiple privately owned ter-
restrial TV networks, supplemented by cable TV
in most urban areas; of more than 100 radio sta-
tions, nearly all are privately owned; Radio Nica-
ragua is government-owned and Radio Sandino is
controlled by the Sandinista National Liberation
Front (FSLN) (2007)
Internet country code:.ni
Internet hosts: 296,068 (2012)
country comparison to the world: 63
internet users: 199,800 (2009)
country comparison to the world: 141','34ce81388cf0e7e703875df066c58feffafed25ba019b5f4d66c80fe5fcaad38','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b50617279f76bc280a4cc4b1efb3c48e3db8f23ae63970a99244c190ba29a3da',2025,'NE','Niger','communications',1226,'Telephones—main lines in use: 85.900 (2011)
country comparison to the world: 148
Telephones—mobile cellular; 4.743 million
(2011)
country comparison to the world: 110
Telephone system: general assessment: inad-
equate; small system of wire, radio telephone -
communications, and microwave radio relay links
concentrated in the southwestern area of Niger
domestic: combined fixed-line and mobile-cellular
teledensity remains only about 30 per 100 persons
despite a rapidly increasing cellular subscribership
base; domestic satellite system with 3 earth sta-
tions and 1 planned
international: country code—227; satellite earth
stations—2 Intelsat (1 Atlantic Ocean and 1
Indian Ocean) (2010)
Broadcast media: state-run TV station; 3 private
TV stations provide a mix of local and foreign pro-
gramming; state-run radio has only radio station
with a national reach; about 30 private radio sta-
tions operate locally; as many as 100 community
radio stations broadcast; transmissions of multiple
international broadcasters are available (2007)
Internet country code:.ne
Internet hosts: 454 (2012)
country comparison to the world: 186
Internet users: 115.900 (2009)
country comparison to the world: 155','41ece8123b623e6b301640a2a5c4723e369f542d9333c3c7b71247354166fec0','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0325e859ef7c8c2c55fd2b59428b2d3a05e7c814c5e335c47f412dd7145542ff',2025,'NG','Nigeria','communications',1234,'Telephones—main Jines in use: (2011)
country comparison to the world: 89
Telephones—mobile cellular: 95.167 million
(2011)
country comparison to the world: 12
Telephone system: general assessment: further
expansion and modernization of the fixed-line
telephone network is needed; network quality
remains a problem
domestic: the addition of a second fixed-line
provider in 2002 resulted in faster growth but
subscribership remains only about 1 per 100 per-
sons; mobile-cellular services growing rapidly, in
part responding to the shortcomings of the fixed-
line network; multiple cellular providers operate
nationally with subscribership base approaching
60 per 100 persons
international: country code—234; landing point
for the SAT-3/WASC fiber-optic submarine cable
that provides connectivity to Europe and Asia; sat-
ellite earth stations—3 Intelsat (2 Atlantic Ocean
and 1 Indian Ocean) (2010)
Broadcast media: nearly 70 federal govern-
ment-controlled national and regional TV sta-
tions; all 36 states operate TV stations; several
private TV stations operational; cable and satel-
lice TV subscription services are available; net-
work of federal government-controlled national,
regional, and state radio stations; roughly 40
state government-owned radio stations typically
carry their own programs except for news broad-
casts; about 20 private radio stations; transmis-
sions of international broadcasters are available
(2007)
Internet country code:.ng
internet hosts: 1,234 (2012)
country comparison to the world: 169
Internet users: 43.989 million (2009)
country comparison to the world: 9','6582ded8873dcff00764da4c85a3c7ad5cd885a4872fa03edae956ab4aa02beb','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('96b67296a411754e9ab9e68bda14521f6f850dc94e8085a918d5495fae7121c6',2025,'NU','Niue','communications',1238,'Telephone system: domestic: single-line tel-
ephone system connects all villages on island
international: country code—683 (2001)
Broadcast media: government-owned TV station
with many of the programs supplied by Television
New Zealand; 1 government-owned radio station
broadcasting in AM and FM (2009)
Internet country code:.nu
Internet hosts: 79,508 (2012)
country comparison to the world: 83
Internet users: 1,100 (2009)
country comparison to the world: 214','492d7f7a5c9636d8c118bb3b4d3f0fb91ee065aba5096c6bb4baa7c11471d7a3','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('be8e99feb00041ccdc9d4dced98250c8773d00765503fe58a83bd92e4b8bb167',2025,'NO','Norway','communications',1253,'Telephones—main lines in use: 1.529 million
(2011)
country comparison to the world: 66
Telephones—mobile cellular: 5.7
(2011)
country comparison to the world: 100
Telephone system: general assessment: modern
in all respects; one of the most advanced telecom-
munications networks in Europe
million
548
THE CIA WORLD FACTBOOK
domestic: Norway has a domestic satellite system;
the prevalence of rural areas encourages the w ide
use of mobile-cellular systems
international: country code—47; 2 buried
coaxial cable systems; submarine cables provide
links to other Nordic countries and Europe; sat-
ellite earth stations—NA Eutelsat, NA Intelsat
(Atlantic Ocean), and 1 Inmarsat (Atlantic and
Indian Ocean regions); note—Norway shares
the Inmarsat earth station with the other Nordic
countries (Denmark, Finland, Iceland, and Swe-
den) (2011)
Broadcast media: state-owned public radio-TV
broadcaster operates 3 nationwide TV stations, 3
nationwide radio stations, and 16 regional radio
stations; roughly a dozen privately owned tel-
evision stations broadcast nationally and roughly
another 25 local TV stations broadcasting; nearly
75% of households have access to multi-channel
cable or satellite TV; 2 privately owned radio sta-
tions broadcast nationwide and another 240 sta-
tions operate locally (2008)
Internet country code:.no
Internet hosts: 3.588 million (2012)
country comparison to the world: 29
internet users: 4.431 million (2009)
country comparison to the world: 53','4e929e97ea3037aadb3b93558a55f2ec2048ccb5e9320924204ddabf6278b3fb','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6cdb16f14625cd0f1dcd802a52d54d72fa9165395185c7136abc079b6774773f',2025,'OM','Oman','communications',1260,'Telephones—main lines in use: 302,945 (2012)
country comparison. to the world: 116
Telephones—mobile cellular: 5.2 million
(2012)
country comparison to the world: 102
Telephone system: general assessment: modern
system consisting of open-wire, microwave, and
radiotelephone communication stations; limited
coaxial cable; domestic satellite system with 8
earth stations
domestic: fixed-line and mobile-cellular subscrib-
ership both increasing with fixed-line phone ser-
vice gradually being introduced to remote villages
using wireless local loop systems
international: country code—968; the Fiber-
Optic Link Around the Globe (FLAG) and the
SEA-ME-WE-3 submarine cable provide connec-
tivity to Asia, the Middle East, and Europe; satel-
lite earth stations—2 Intelsat (Indian Ocean), 1
Arabsat (2008)
Broadcast media: state-run TV broadcaster; TV
stations transmitting from Saudi Arabia, the UAE,
and Yemen available via satellite TV; state-run
radio operates multiple stations; first private radio
station began operating in 2007 and 2 additional
stations now operating (2007)
Internet country code:.om
Internet hosts: 14,531 (2012)
country comparison to the world: 127
551
Internet users: 1.465 million (2009)
country comparison to the world: 83','26c74f476cbfcfaa0aee980aa0f86d2d06146d0ff2f408fb281d7f877c5400b4','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6f808b8a0cc18b2b1e782b825545e33cd723b5d25adb1e41bdd17b1cbf9424f7',2025,'PK','Pakistan','communications',1271,'Telephones—main fines in use: 5.722 million
(2011)
country comparison to the world: 30
Telephones—mobile cellular: 111
(2011,
country comparison to the world: 9
Telephone system: general assessment: the tel-
ecommunications infrastructure is improving dra-
matically with foreign and domestic investments
in fixed-line and mobile-cellular networks; system
consists of microwave radio relay, coaxial cable,
fiber-optic cable, cellular, and satellite networks;
domestic: mobile-cellular subscribership has sky-
rocketed, exceeding 110 million by the end of
2011, up from only about 300,000 in 2000; more
than 90 percent of Pakistanis live within areas that
have cell phone coverage and more than half of all
Pakistanis have access to a cell phone; fiber systems
are being constructed throughout the country to
aid in network growth; fixed line availability has
risen only marginally over the same period and
there are still difficulties getting fixed-line service
to rural areas
international: country code—92; landing point
for the SEA-ME-WE-3 and SEA-ME-WE-4 sub-
marine cable systems that provide links to Asia,
the Middfe East, and Europe; satellite earth sta-
tions—3 Intelsat (1 Atlantic Ocean and 2 Indian
Ocean); 3 operational international gateway
exchanges (1 at Karachi and 2 ar Islamabad);
microwave radio relay to neighboring countries
(2011)
Broadcast media: media is government regulated;
—i dominant state-owned TV broadcaster, Pakistan
Television Corporation (PTV), operates a network
consisting of 5 channels; private TV broadcasters
are permitted; to date 69 foreign satellite channels
are operational; the state-owned radio network
operates more than 40 stations; nearly 100 com-
mercially licensed privately owned radio stations
provide programming mostly limited to music and
talk shows (2007)
Internet country code: .pk
million
Internet hosts: 365,813 (2012)
country comparison to the world: 57
Internet users: 20.431 million (2009)
country comparison to the world: 20','c2b9c8975665daae4f6c3926fda5813d5ed8db0f964ea2da7bdb5d39346cc985','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('77fea200c5fecddbaf06b0ba11b60363ddf46d52d480ea10a8d297d5f68a2298',2025,'PW','Palau','communications',1278,'Telephones—main lines in use: 6,900 (2011)
country comparison to the world: 206
Teiephones—mobile cellular: 15,400 (2011)
country comparison to the world: 209
Telephone system: domestic: fixed-line and
mobile-cellular services available with a combined
subscribership of roughly 100 per 100 persons
international: country code—680; satellite earth
station—1 Intelsat (Pacific Ocean) (2009)
Broadcast media: no TV stations; a cable TV
network covers the major islands and provides
access to rebroadcasts, on a delayed basis, of a
number of US stations as well as access to a num-
ber of real-time satellite TV channels; about a half
dozen radio stations with 1 government-owned
(2009)
internet country code: .pw
Internet hosts: 4 (2012)
country comparison to the world: 232','1329d2f9414672bf218f62f471b2414b1bfa83cb69fa2c69aa662f1a01a348cb','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('27a9fcb9d723ab825a08709b6629fe53fd93fd837001cf35b6488ab75a4da6a1',2025,'PA','Panama','communications',1288,'Telephones—main lines in use: 560,200 (2011)
country comparison to the world: 93
Telephones—mobile cellular: 6.735 million
(2011) ''
country comparison to the world: 95
Telephone system: general assessment: domes-
tic and international facilities well-developed
domestic: mobile-cellular telephone subscriber-
ship has increased rapidly
international: country code—507; landing point
for the Americas Region Caribbean Ring System
(ARCOS-1), the MAYA-1, and PAN-AM sub-
marine cable systems that together provide links
to the US and parts of the Caribbean, Central
America, and South America; satellite earth sta-
tions—2 Intelsat (Atlantic Ocean); connected to
the.Central American Microwave System (2011)
Broadcas? media: multiple privately owned TV
networks and a government-owned educational
TV station; multi-channel cable and satellite TV
subscription services are available; more than 100
commercial radio stations (2007)
internet country code: .pa
internet hosts: 11,022 (2012)
country comparison to the world: 132
internet users: 959,800 (2009)
country comparison to the world: 104','3bc92b12e992afa87576e8beb86a9ad4ac7cad1329d7e8506c42454fadfcc49f','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ca25c94bf12262e0fef3722d3c43f0e8ecea72f18f3c0d9ce2f7d42690c23150',2025,'PG','Papua New Guinea','communications',1298,'Telephones—main lines in use: 130,000 (2011)
country comparison to the world: 141
Telephones—mobile cellular:
(2011)
country comparison to the world: 133
2.4 million
Telephone system: general assessment: services
are minimal; facilities provide radiotelephone and
telegraph, coastal radio, aeronautical radio, and
international radio communication services
domestic: access to telephone services is not
widely available although combined fixed-line
and mobile-cellular teledensity has increased to
roughly 40 per 100 persons
international: country code—675; submarine
cables to Australia and Guam; satellite earth sta-
tion—1 Intetsat (Pacific Ocean); international
radio communication service (2009)
Broadcast media: 2 TV stations, 1 commercial
station operating since the late 1980s and 1 state-
run station launched in 2008; satellite and cable
TV services are available; state-run National
Broadcasting Corporation operates 3 radio net-
works with multiple repeaters and about 20 pro-
vincial stations; several commercial radio stations
with multiple transmission points as well as several
community stations; transmissions of several inter-
national broadcasters are accessible (2009)
Internet country code: .pg
Internet hosts: 5,006 (2012)
country comparison to the world: 145. `
Internet users: 125,000 (2009)
country comparison to the world: 152','85e143f04e6b496964506481c2b0c9aef7a709189c4de65c9bf5d2518f1d7940','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('00163612b052fb745e9e5df9ae029ce7a19cb06db271342cc0bea3899f2ff8e6',2025,'PY','Paraguay','communications',1305,'Telephones—main lines in use: 372,400 (2011)
country comparison to the world: 108
Telephones—mobile cellular: 6.529 million
(2011)
country comparison to the world: 96
Telephone system: general assessment: the
fixed-line market is a state monopoly and fixed-
line telephone service is meager; principal switch-
ing center is in Asuncion
domestic: deficiencies in provision of fixed-line
service have resulted in a rapid expansion of
mobile-cellular services fostered by competition
among multiple providers
international: country code—595; satellite earth
station—1 Intelsat (Atlantic Ocean) (2010)
Broadcast media: 6 privately owned TV stations;
about 75 commercial and community radio sta-
tions; Í state-owned radio network (2010)
internet country code: .py
Internet hosts: 280,658 (2012)
country comparison to the world: 65
Internet users: 1.105 million (2009)
country comparison to the world: 94','caa60c040b13da64a83b83d25fbdc40d20e9149d56eacd5eb4d31cb7dc8daabf','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3fa2fd0781cceb4727fdc73ca09348d9ef38dafe0d6889225b812a52c84b1da5',2025,'PE','Peru','communications',1310,'Telephones—main lines in use: 3.688 million
(2011)
-country comparison to the world: 43
Telephones—mobile cellular: 32.461 million
(2011)
country comparison to the world: 33
Telephone system: general assessment: ade-
quate for most requirements; nationwide micro-
wave radio relay system and a domestic satellite
system with 12 earth stations
domestic: fixed-line teledensity is only about
12 per 100 persons; mobile-cellular teledensity,
spurred by competition among multiple providers,
exceeds 100 telephones per 100 persons
international: country code—51; the South
America-l (SAM-1) and Pan American (PAN-
AM) submarine cable systems provide links to parts
of Central and South America, the Caribbean, and
US; satellite earth stations—2 Intelsat (Atlantic
Ocean) (2010)
Broadcast media: 10 major TV networks of
which only one, .Television Nacional de Peru, is
state-owned; multi-channel cable TV services are
available; in excess of 2,000 radio stations includ-
ing a substantial number of indigenous language
stations (2010)
Internet country code: .pe
Internet hosts: 234,102 (2012)
country comparison to the world: 70
Internet users: 9.158 million (2009)
country comparison to the world: 31','91dd82b4c346c83778086ab4816fdded0d29df69174ec113b2e8bc1543351c76','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('16972fb793e25e37c5acfdb6da006d8ad4b127cf3b90b594e87f22d8a1131910',2025,'PH','Philippines','communications',1321,'Telephones—main lines in use: 3.556 million
(2011)
country comparison to the world: 46
Telephones—mobile cellular: 94.19 million
(2011)
country comparison to the world: 14
Telephone system: general assessment: good
international radiotelephone and
cable services; domestic and interisland service
adequate
domestic:
includes
submarine
telecommunications infrastructure
the following platforms: fixed-line,
mobile cellular, cable TV, over-the-air TV, radio
and Very Small Aperture Terminal (VSAT), fiber-
optic cable, and satellite; mobile-cellular commu-
nications now dominate the industry
international: country code—63; a series of sub-
marine cables together provide connectivity to
Asia, US, the Middle East, and Europe; multiple
international gateways (2011)
Broadcast media: multiple national private TV
and radio networks; multi-channel satellite and
cable TV systems available; more than 350 TV
stations—4 major TV networks operating nation-
wide with | being government-owned; some 1100
cable TV providers and some 1,200 radio stations
broadcasting; the Philippines is scheduled to com-
plete the switch from analog to digital broadcast-
ing by the end of 2015 (2012)
Internet country code: .ph
_ Internet hosts: 425,812 (2012)
country comparison to the world: 52
Internet users: 8.278 million (2009)
country comparison to the world: 34','80b1e47065259cc1faf3fe464e9e38e549219d60da795635c9cdd92eb7a2e094','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b13c5d1a106da2abf2ea120e82b4b71f196b4d1516a0a8499887b231ae1939dd',2025,'PL','Poland','communications',1334,'Telephones—main lines in use: 6.853 million
(2011)
country comparison to the world: 27
Telephones—mobile cellular: 50.16 million
(2011)
country comparison to the world: 28
Telephone system: general assessment: mod-
ernization of the telecommunications network has
accelerated with market-based competition; fixed-
line service, dominated by the former state-owned
company, is dwarfed by the growth in mobile-cellu-
lar services
domestic: mobile-cellular service available since
1993 and provided by three nation-wide networks
with a fourth provider beginning operations in late
2006; coverage is generally good with some gaps in
the east; fixed-line service lags in rural areas
international: country code—48; international
direct dialing with automated exchanges; satellite
earth station—1 with access to Intelsat, Eutelsat,
Inmarsat, and Intersputnik (2011)
Broadcast media: state-run public TV operates
2 national channels supplemented by 16 regional
channels and several niche channels; privately
t
owned entities operate several national TV net-
works and a number of special interest channels;
many privately owned channels broadcasting
locally; roughly half of all households are linked
to either satellite or cable TV systems providing
access to foreign television networks; state-run
public radio operates 5 national networks and 17
tegionat radio stations; 2 privately owned national
radio networks, several commercial stations broad-
casting to multiple cities, and many privately
owned local radio stations (2007)
Internet country code: .p|
Internet hosts: 13.265 million (2012)
country comparison to the world: 12
internet users: 22.452 million (2009)
country comparison to the world: 19','46e0c0017f2504757e87e0eb8f5088ff9b87a07b0cf965ce4a13dec680dd25f6','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c34576f0051f3a317369f7c59b30865f80fdf886b60b1cdc3d6284c782af1803',2025,'PT','Portugal','communications',1340,'Telephones—main lines in use: 4.53 million
(2011)
country comparison to the world: 36
Telephones—mobile cellular: 12.335 million
(2011)
country comparison to the world: 64
Telephone system: general assessment: Portu-
gal’s telephone system has a state-of-the-art net-
work with broadband, high-speed capabilities
domestic: integrated network of coaxial cables,
open-wire, microwave radio relay, and domestic
satellite earth stations
international: country code—351; a combina-
tion of submarine cables provide connectivity to
Europe, North and East: Africa, South Africa, the
Middle East, Asia, and the US; satellite earth sta-
tions—3 Intelsat (2 Atlantic Ocean and 1 Indian
Ocean), NA Eutelsat; tropospheric scatter to
Azores (2010)
Broadcast media: Radio e Televisao de Portugal
(RTP),the publicly-owned TV broadcaster, oper-
ates 2 domestic channels and external service
channels to Africa; overall, roughly 40 domestic
TV stations; viewers have widespread access to
international broadcasters with more than half of
all households connected to multi-channel cable
or satellite TV systems; publicly owned radio oper-
ates 3 national networks and provides regional and
external services; several privately owned national
tadio stations and some 300 regional and local
corhmercial radio stations (2008)
Internet country code: .pt
Internet hosts: 3.748 million (2012)
country comparison to the world: 28
Internet users: 5.168 million (2009)
country comparison to the world: 45','582b4843e4e1922fc3c29be6b16c1b28515a3abffdf0dd5850a74522e96982b1','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e3366209fb385fa764ea6c1724987846763fdaab47689c42caff623493698b5b',2025,'PR','Puerto Rico','communications',1347,'Telephones—main lines in use: 826,100 (2011)
country comparison to the world: 87
Telephones—mobile cellular: 3.108 million
(2011)
country comparison to the world: 125
Telephone system: general assessment: mod-
em system integrated with that of the US by
high-capacity submarine cable and Intelsat with
high-speed data capability
domestic: digital telephone system; mobile-cellu-
lar services
international: country code—1-787, 939; subma-
tine cables provide connectivity to the US, Carib-
bean, Central and South America; satellite earth
station—l1 Intelsat (2011)
Broadcast media: more than 30 TV stations
operating; cable TV subscription services are
available; roughly 125 radio stations (2007)
Internet country code: .pr
Internet hosts: 469 (2012)
country comparison to the world; 185
internet users: 1 million (2009)
country comparison to the world: 98
ISLANDS Telephones—main lines in use:
75,800 (2010)
country comparison to the world: 154
Telephones—mobile cellular: 80,300 (2005)
country comparison to the world: 196
Telephone system: general assessment: modern
system with total digital switching, uses fiber-optic
cable and microwave radio relay
domestic: full range of services available
international: country code—1-340; submarine
cable connections to US, the Caribbean, Central
and South America; satellite earth stations—NA
(2010)
Broadcast media: about a dozen TV broadcast
stations including 1 public TV station; multi-chan-
nel cable and satellite TV services are available; 24
tadio stations (2009)
Internet country code: .vi
Internet hosts: 4,790 (2012)
country comparison to the world: 146
Internet users: 30,000 (2009) `
country comparison to the world: 181','affc464d8313f6ec3c7e474c3b62dc1f6d8565e3c35ec4abbe0f2f04be1f4921','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6b672a2d4adb4741acd686460c6c140ce7d1ad535edc2f7be1d012346c8d28cd',2025,'QA','Qatar','communications',1356,'QATAR Telephones—main lines in use: 306,700
(2011)
country comparison to the world: 114
Telephones—mobile cellular: 2.302 million
(2011)
country comparison to the world: 135
Telephone system: general assessment: modern
system centered in Doha
domestic: combined fixed and mobile-cellular tel-
ephone subscribership exceeds 130 telephones per
100 persons
international: country code—974; landing
point for the Fiber-Optic Link Around the Globe
(FLAG) submarine cable network that provides
links to Asia, Middle East, Europe, and the US;
tropospheric scatter to Bahrain; microwave radio
relay to Saudi Arabia and the UAE; satellite
earth stations—2 Intelsat (1 Atlantic Ocean and
1 Indian Ocean) and 1 Arabsat (2011)
Broadcast media: TV and radio broadcast licens-
ing and access to local media markets are state
controlled; home of the satellite TV channel Al-
Jazeera, which was originally’ owned and financed
by the Qatari government, but has evolved to
independent corporate status; Al-Jazeera claims
editorial independence in broadcasting; local
tadio transmissions include state, private, and
international broadcasters on FM frequencies in
Doha (2012)
Internet country code: .qa
Internet hosts: 897 (2012)
country comparison to the world: 173
Internet users: 563,800 (2009)
country comparison to the world: 117','03332bc0dc1631bf08dc73704c40b9c2ead711f2f839edc999f50231ab962b41','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b2d9c371fb18a1c1fa9bec6cd18ff3d26d561a63492469ee6c1510c12edb5b7f',2025,'RW','Rwanda','communications',1370,'Telephones—main lines in use: 38,900 (201 1)
country comparison to the world: 167
telephones—mobile cellular: 4 446 million
(2011)
country comparison to the world: 112
Telephone system: general assessment: small,
inadequate telephone system primarily serves busi-
ness, education, and government
domestic: the capital, Kigali, is connected to the
centers of the provinces by microwave radio relay
and, recently, by cellular telephone service; much
of the network depends on wire and HF radiotel-
ephone; combined fixed-line and mobile-cellular
telephone density has increased and now exceeds
40 telephones per 100 persons
international: country code—250; international
connections employ microwave radio relay to
neighboring countries and satellite communica-
tions to more distant countries; satellite earth
stations—1 Intelsat (Indian Ocean) in Kigali
(includes telex and telefax service) (2010)
Broadcast media: government owns and operates
the only TV station; government-owned and oper-
ated Radio Rwanda has a national reach; 9 private
radio stations; transmissions of multiple interna-
tional broadcasters are available (2007)
Internet country code: .rw
Internet hosts: 1.447 (2012)
country comparison to the world: 168
Internet users: 450,000 (2009)
country comparison to the world: 118
608
THE CIA WORLD FACTBOOK','70f6b3ae76e31632cf479f351f75653a82c7fa1fa0d1b8eed77b9c8c22f3e7c7','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8deeced91295ebc91f7ae90990764e88c94799f096bee0ccc5df166b9351f032',2025,'KN','Saint Kitts and Nevis','communications',1380,'Telephones—main lines in use: 20,600 (2010)
country comparison to the world: 188
Telephones—mobile cellular: 84,600 (2010)
country comparison to the world: 195
Telephone system: general assessment: good
interisland and international connections
“Gros
Islet
fon p *CASTRIES ;
Cul de Sac ae
Donnery,
Vieux Fort”
domestic: interisland links via Eastern Caribbean
Fiber Optic cable; construction of enhanced wire-
less infrastructure launched in November 2004;
fixed-line teledensity about 40 per 100 persons;
mobile-cellular teledensity is roughly 170 per 100
persons
international: country code—1-869; connected
internationally by the East Caribbean Fiber Optic
System (ECFS) and Southern Caribbean Tiber
optic system (SCF) submarine cables (2010)
Broadcast media: the government operates a
national TV network that broadcasts on 2 chan-
nels; cable subscription services provide access to
local and international channels; the government
operates a national radio network; a mix of gov-
etnment-owned and privately owned broadcasters
operate roughly 15 radio stations (2007)
Internet country code: kn
Internet hosts: 54 (2012)
country comparison to the world: 214
internet users: 17,000 (2009)
country comparison to the world: 196','b4d7f7313a85abe9808f07b382cbaf693131292fe4316a48acbf4a70423112ba','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6ce332e715292a910a6024dca1b13835dd66da2757b18be15bacf342d1eafe92',2025,'LC','Saint Lucia','communications',1388,'Telephones—main lines in use: 35,900 (2011)
country comparison to the world: 171
Telephones—mobile cellular: 216,500 (2011)
country comparison to the world: 179
Telephone system: general assessment: an ade-
quate system that is automatically switched
domestic: fixed-line teledensity is 25 per 100 per-
sons and mobile-cellular teledensity is roughly 130
per 100 persons
international: country code—1-758; the East
Caribbean Fiber Optic System (ECFS) and South-
em Caribbean fiber optic system (SCF) submarine
cables, along with Intelsat from Martinique, carry
calls internationally; direct microwave radio relay
link with Martinique and Saint Vincent and the
Grenadines; tropuspheric scatter to Barbados
(2010)
Broadcast media: 3 privately owned TV stations;
1 public TV station operating on a cable network;
multi-channel cable TV service available; a mix
of state-owned and privately owned broadcasters
operate nearly 25 radio stations including repeater
transmission stations (2007)
Internet country code: .Ic
Internet hosts: 100 (2012)
country comparison to the world: 210
Internet users: 142,900 (2009)
country comparison to the world: 149','fbb0947053165630ec9e59eb3412dcfc0f64e8616fcf6658932ef452a2594849','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ed775f83ef7d9c697725d4456c6e0cc13410e2cd7ae9ce555b6106469b5fb8f0',2025,'PM','Saint Pierre and Miquelon','communications',1402,'Telephones—main lines in use: 4,800 (2010)
country comparison to the world: 211
Telephone system: general assessment: adequate
international: country code—508; radiotele-
phone communication with most countries in the
world; satellite earth station—1 in French domes-
tic satellite system
Broadcast media: 2 TV stations with a third
repeater station, all part of the French Overseas
Network; radio stations on St. Pierre and on
621
Miquelon are part of the French Overseas Net-
work (2007)
Internet country code: pm
Internet hosts: 15 (2012)
country comparison to the world: 225','2e0a42b9910d708b4b75c4f46844874cf03da646744b98add670d5d9e0b3d002','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5273399f3715d2d8954d41f7ca3b0bdf47a468c21635bbd716f205a25164e98f',2025,'VC','Saint Vincent and the Grenadines','communications',1410,'Telephones—main lines In use: 22,700 (2011)
country comparison to the world: 186
Telephones—mobile cellular: 131,800 (2011)
country comparison to the world: 185
Telephone system: general assessment: adequate
islandwide, fully automatic telephone system
domestic: fixed-line teledensity exceeds 20 per
100 persons and mobile-cellular teledensity
exceeds 125 per 100 persons
international: country code—1-784; the East
Caribbean Fiber Optic System (ECFS) and
Southern Caribbean fiber optic system (SCF)
submarine cables carry international calls! con-
nectivity also provided by VHF/UHF radiotele-
phone from Saint Vincent to Barbados; SHF radi-
otelephone to Grenada and Saint Lucia; access
to Intelsat earth station in Martinique through
Saint Lucia (2011)
Broadcast media: St. Vincent and the Gren-
adines Broadcasting Corporation operates fÍ
TV station and 5 repeater stations that provide
near total coverage to the multi-island state;
multi-channel cable TV service available; a par-
tially government-funded national radio service
broadcasts on 1 station and has 2 repeater stations;
about a dozen privately owned radio stations and
repeater stations (2007)
Internet country code: .vc
Internet hosts: 305 (2012)
country comparison to the world: 191
Internet users: 76,000 (2009)
country comparison to the world: 169','1cb53e74b0eaeab4011b9860db67ca64f9c67866d5b80b4787f5adaf106000ec','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('aab1cbd3bed857be1eff53d7a13e97ea7194c4301a3a4238a08c7767d42965b3',2025,'WS','Samoa','communications',1417,'Telephones—main lines in use: 35,300 (2010)
country comparison to the world: 173
Telephones—mobile cellular: 167,400 (2010)
country comparison to the world: 183
Telephone
adequate
domestic: combined fixed-line and mobile-cel-
lular teledensity roughly 100 telephones per 100
persons
international; country ` code—685; satel-
lite earth station—1 Intelsat (Pacific Ocean)
(2007) Broadcast media: state-owned TV sta-
tion privatized in 2008; 4 privately-owned tel-
evision broadcast stations; about a half dozen
privately owned radio stations and one state-
owned radio station; TV and radio broadcasts
of several stations from American Samoa are
available (2009)
Internet country code: .ws
Internet hosts: 18,013 (2012)
country comparison to the world: 120
Internet users: 9,000 (2009)
country comparison to the world: 202
i TRANSPORTATION
Airports: 4 (2012)
country comparison to the world: 188
Airports—with paved runways: total: 1
2,438 to 3,047 m: 1 (2012)
Airports—with unpaved runways: total: 3
under 914 m: 3 (2012)
Roadways: total:2,337 km
country comparison to the world: 171
paved: 332 km
unpaved; 2,005 km (2001)
Merchant marine: total: 2
country comparison to the world: 143
by type: cargo 1, passenger/cargo 1
foreign-owned: 1 (NZ 1) (2010)
Ports and terminals: Apia
Military branches: no regular military forces;
Samoa Police Force (2008)
Manpower available for military service:
males age 16-49: 47,906 (201 0 est.)
Manpower fit for military service: males age
16-49: 38,260
females age 16-49: 38,032 (2010 est.)
Manpower reaching militarily significant age
annually: male: 2,221
female: 2,062 (2010 est.)
Military expenditures: NA
Military—note: Samoa has no formal defense
structure or regular armed forces; informal defense
ties exist with NZ, which is required to consider
any Samoan request for assistance under the 1962
Treaty of Friendship','ee61ff9c8a989f75effd794a667ad95cf482d92c4c07705d6c9a772ecf2c4c90','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4d64d1a3f27cdafcb0e6365fe0741c85046b4a073c9d7416f3f1d9657f3b1e80',2025,'SM','San Marino','communications',1422,'Telephones—main lines in use: 18,700 (2011)
country comparison to the world: 192
Telephones—mobile cellular: 35,500 (2011)
country comparison to the world: 204
Telephone system: general assessment: auto-
matic telephone system completely integrated into
Italian system
domestic: combined fixed-line and mobile-cellular
teledensity 170 telephones per 100 persons
international: country code—378; connected to
Italian international network (2011)
Broadcast media: state-owned public broadcaster
operates 1 TV station and 3 radio stations; receives
radio and TV broadcasts from Italy (2012)
Internet country code: sm
THE CiA WORLD FACTBOOK
Internet hosts: 1,015 (2012)
country comparison to the world: 133
Internet users: 17,000 (2009)
country comparison to the world: 197','00aa35cbadbc0f5fce5270852a7789e7e80478402977abf052d9717a70d0b94c','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c5d3827397ce4a34d8cdb4f34a9b1a65af55825a34efdc9949c147d998e99870',2025,'SA','Saudi Arabia','communications',1434,'Telephones—main lines in use: 4.633 million
(2011)
country comparison to the world: 32
Telephones—mobile cellular: 53.706 million
(2011)
country comparison to the world; 25
Telephone system: general assessment: mod-
ern system including a combination of extensive
microwave radio relays, coaxial cables, and fiber-
optic cables
domestic: mobile-cellular subscribership has been
increasing rapidly
international: country code—966; landing point
for the international submarine cable Fiber-Optic
Link Around the Globe (FLAG) and for both the
SEA-ME-WE-3 and SEA-ME-WE-4 submarine
cable networks providing connectivity to Asia,
Middle East, Europe, and US; microwave radio
relay to Bahrain, Jordan, Kuwait, Qatar, UAE,
Yemen, and Sudan; coaxial cable to Kuwait and
Jordan; satellite earth stations—5 Intelsat (3
Atlantic Ocean and 2 Indian Ocean), 1 Arabsat,
and 1 Inmarsat (Indian Ocean region) (2011)
Broadcast media: broadcast media are state-con-
trolled; state-run TV operates 4 networks; Saudi
Arabia is a major market for pan-Arab satellite
TV broadcasters; state-run radio operates several
networks; multiple international broadcasters are
available (2007)
internet country code: .sa
Internet hosts: 145,941 (2012)
country comparison to the world: 79
Internet users: 9.774 million (2009)
country comparison to the world: 30','d6c43c143297b4f822e41a1616ca7c52819d55157751c96dc30fe6d8fb85f22b','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0ec03d875e1aef83732f8d138401cb3bda25665fe80ebc8bf04796f558b51c00',2025,'SC','Seychelles','communications',1443,'Telephones—main lines in use: 27,900 (2011)
country comparison to the world: 180
Telephones—mobile cellular: 126,600 (2011)
country comparison to the world: 187
Telephone system: general assessment: effective
system
domestic: combined fixed-line and mobile-cel-
lular teledensity exceeds 170 telephones per 100
persons; radiotelephone communications between
islands in the archipelago
international: country code—248; direct radio-
telephone communications with adjacent island
countries and African coastal countries; satellite
earth station—1 Intelsat (Indian Ocean) (2011)
Broadcast media: the government operates the
only terrestrial TV station, which provides local
programming and airs broadcasts from interna-
tional services; multi-channel cable and satellite
TV are available; the government operates 1 AM
and 1 FM radio station; transmissions of 2 inter-
national broadcasters are accessible in Victoria
(2007)
Internet country code: .sc
647
Internet hosts: 247 (2012)
country comparison to the world: 196
Internet users: 32,000 (2008)
country comparison to the world: 180','bc3f19941e948d9262926f45536867ad44e2431d391fec1da931dc844156548a','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('973001148e7d41481a77adc1444cf4a788d5bc8c64b0e5ae30c4afd6031d0f8e',2025,'SL','Sierra Leone','communications',1450,'Telephones—main lines in use: 14,000 (2010)
country comparison to the world: 197
Telephones—mobile cellular: 2.137 million
(2011)
country comparison to the world: 139
Telephone system: general assessment: marginal
telephone service with poor infrastructure
domestic: the national microwave radio relay
trunk system connects Freetown to Bo and Ken-
ema; while mobile-cellular service is growing
rapidly from a small base, service area coverage
remains limited
international: country code—232; satellite earth
station—-1 Intelsat (Atlantic Ocean) (2009)
Broadcast media: 0 government-owned TV sta-
tion; 1 private TV station began operating in
2005; a pay-TV service began operations in late
2007; 1 government-owned national radio station;
about two dozen private radio stations primarily
clustered in major cities; transmissions of several
international broadcasters are available (2007)
Internet country code: .si
Internet hosts: 282 (2012)
country comparison to the world: 192
Internet users: 14,900 (2009)
country comparison to the world: 199','9f25eea99bc30fb6474ef58f7f1b62020938ce52c57f32195faeb9eb4d3742e3','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ced8a5e2ed88fb5bf5c601c80d8f463443b4c67a741d146da7df4feae21e1b1e',2025,'SG','Singapore','communications',1455,'Telephones—main lines in use: 2.017 million
(2011)
country comparison to the world: 58
Telephones—mobile cellular: 7.794 million
(2011)
country comparison to the world: 90
Telephone system: general assessment: excel-
lent service
domestic: excellent domestic facilities; launched
3G wireless service in February 2005; combined
fixed-line and mobile-cellular teledensity more
than 180 telephones per 100 persons; multiple
providers of high-speed Internet connectivity and
the government is close to completing an island-
wide roll out of a high-speed fiber-optic broadband
network
international: country code—65; numerous
submarine cables provide links throughout Asia,
THE CIA WORLD FACTBOOK
Australia, the Middle East, Europe, and US; sat-
ellite earth stations—4; supplemented by VSAT
coverage (2011)
Broadcast media: state controls broadcast media;
8 domestic TV stations operated by MediaCorp
which is wholly owned by a state investment com-
pany; broadcasts from Malaysian and Indonesian
stations available; satellite dishes banned; multi-
channel cable TV service available; a total of 18
domestic radio stations broadcasting with Medi-
aCorp operating more than a dozen and another
4 stations are closely linked to the ruling party or
controlled by the Singapore Armed Forces Reserv-
ists Association; many Malaysian and Indonesian
radio stations are available
Internet country code: sg
internet hosts: 1.96 million (2012)
country comparison to the world: 39
Internet users: 3.235 million (2009)
country comparison to the world: 65','c6cdfa53390ce81b1d30ff881c3cf9db4614a73f921b3652d543fd5c7fb19f73','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4f0c7b28422dadec8ae1b716c1afa43741aee02348ee2c0e4ccf56ce09f38db8',2025,'SK','Slovakia','communications',1462,'Telephones—main lines in use: 1.056 million
(2011)
country comparison to the world: 75
Telephones—mobile’ cellular: 5.983 million
(2011)
country comparison to the world: 99
Telephone system: general assessment: Slovakia
has a modern telecommunications system that has
expanded dramatically in recent years with the
growth in cellular services
domestic: analog system is now receiving digital
equipment and is being enlarged with fiber-optic
cable, especially in the larger cities; 3 companies
provide nationwide cellular services
international: country code—421; 3 interna:
tional exchanges (1 in Bratislava and 2 in Banska
Bystrica) are available; Slovakia is participating in
several international telecommunications projects
that will increase the availability of external ser-
vices (2011)
657
Broadcast media: state-owned public broad-
caster, Radio and Television of Slovakia (RTVS),
operates 3 national TV stations and multiple
national and regional radio networks; roughly 35
privately owned TV stations operating nationally,
regionally, and locally; about 40% of households
are connected to multi-channel cable or satellite
TV; moré than 20 privately owned radio stations
(2008)
Internet country code: sk
Internet hosts: 1.384 million (2012)
country comparison to the world: 41
Internet users: 4.063 million (2009)
country comparison to the world: 58','eb630e9f1c5ed5f2ba6242d4e80cd914a9121b5d7eaca319ceec792d95cad1ad','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d30f6b79820a6119d8be8a9d026939265e6383658d512a84cb6ed86a7fdca379',2025,'SI','Slovenia','communications',1468,'Telephones—main lines in use: 872,800 (2011)
country comparison to the world: 84
Telephones—mobile cellular: 2.168 million
(2011)
country comparison to the world: 138
Telephone. system: general assessment: well-
developed telecommunications infrastructure
domestic: combined fixed-line and mobile-cel-
lular teledensity roughly 150 telephones per 100
persons
international: country code—386 (2011)
Broadcast media: public TV broadcaster, Radio-
televizija Slovenija (RTV), operates a system of
national and regional TV stations; 35 domestic
commercial TV stations operating nationally,
regionally, and locally; about 60% of households
are connected to multi-channel cable TV; pub-
lic radio broadcaster operates 3 national and 4
regional stations; more than 75 regional and local
commercial and non-commercial radio stations
(2007)
internet country code: si
Internet hosts: 415,581 (2012)
country comparison to the world: 54
internet users: 1.298 million (2009)
country comparison to the world: 92','ce885074a5b2f5859e7387cbda9951a23506db97d88e1f7424850c6e0d9ca972','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f4d51d709d28e5bb2b5676d51ecbe34a6871e880af194490d28e47cd6f3b2ddd',2025,'SB','Solomon Islands','communications',1476,'Telephones—main lines in use: 8,400 (2011)
country comparison to the world: 203
Telephones—mobile cellular: 274,900 (2011)
country comparison to the world: 174
Telephone system: domestic: mobile-cellular tel-
ephone density is about 50 per 100 persons
international: country code—677; satellite earth
station—1 Intelsat (Pacific Ocean) (2011)
Broadcast media: Solomon Islands Broadcasting
Corporation (SIBC) is the sole TV broadcaster
with 1 station; multi-channel pay-TV is avail-
able; SIBC operates 2 national radio stations and
2 provincial stations; 2 local commercial radio
stations; Radio Australia is available via satellite
feed (2009)
Internet country code: .sb
Internet hosts: 4,370 (2012)
country comparison to the world: 148
Internet users: 10,000 (2009)
country comparison to the world: 201','abb443818a78ff5ffb5415e329c53b83aa62070988ddf7002c880dfdaa019e3b','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('de544a61fe2b4eb6699640d7d13faf0d82062e874e9be9b3e076aced046d8e04',2025,'SO','Somalia','communications',1481,'Telephones—main lines in use: 100,000 (2010)
country comparison to the world: 146
Telephones—mobile cellular: 655,000 (2011)
country comparison to the world: 161
Telephone system: general assessment; the
public telecommunications system was almost
completely destroyed or dismantled during the
civil war; private companies offer limited local
fixed-line service and private wireless com-
panies offer service in most major cities while
charging the lowest international rates on the
continent
domestic: local cellular telephone systems have
been established in Mogadishu and in several
other population centers with one company begin-
ning to provide 3G services in late 2012
international: country code—252; Mogadishu is
a landing point for the EASSy fiber-optic subma-
rine cable system linking East Africa with Europe
and North America (2010)
Broadcast media: 2 private TV stations rebroad-
cast Al-Jazeera and CNN; Somaliland has 1 gov-
ernment-operated TV station and Puntland has 1
private TV station; the transitional government
operates Radio Mogadishu; 1 SW and roughly
10 private FM radio stations broadcast in Moga-
dishu; several radio stations operate in central and
southern regions; Somaliland has 1 government-
operated radio station; Puntland has roughly a
half dozen private radio stations; transmissions of
at least 2 international broadcasters are available
(2007)
Internet country code: .so
Internet hosts: 186 (2012)
country comparison to the world: 203
Internet users: 106,000 (2009)
country comparison to the world: 159
a kwane
f
PRETORIA
ya a }
fri "SHWANE)
Johannesburg” <
`
Richards
t Upington
alae k
L adyan,
iy Nout
F Kimberey”
Bloamionton
Da Aar
.
aes
sSadanna > Pon r,
ape Town , Elizabeth,
668
THE CIA WORLD FACTBOOK','649aed5fc8118d5a97523c31a02f1c9caf2a2d023d2368ce61e875618aa4ce25','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8b03fccac86df535f5f028cf5b78fb78b28ab78ed32a4a01543ae86a8f3c2ec3',2025,'ZA','South Africa','communications',1487,'Telephones—main lines in use: 4.127 million
(2011)
country comparison to the world: 42
Telephones—mobile cellular: 64 million (2011)
country comparison to the world: 20
Telephone system: general assessment: the system
is the best developed and most modern in Africa
domestic: combined fixed-line and mobile-cellu-
lar teledensity is roughly 140 telephones per 100
persons; consists of carrier-equipped open-wire
lines, coaxial cables, microwave radio relay links,
fiber-optic cable, radiotelephone communication
stations, and wireless local loops; key centers are
Bloemfontein, Cape Town, Durban, Johannesburg,
Port Elizabeth, and Pretoria
international: country: code—27; the SAT-3/
WASC and SAFE fiber-optic submarine cable sys-
tems connect South Africa to Europe and Asia; the
EASSy fiber-optic cable system connects with Europe
and North America; satellite earth stations—3 Intel-
sat (1 Indian Ocean and 2 Atlantic Ocean) (2011)
Broadcast media: the South African Broadcasting
Corporation (SABC) operates 4 TV stations, 3 are
free-to-air and is pay TV; e.tv, a private station, is
accessible to more than half the population; multi-
ple subscription TV services provide a-mix of local
and international channels; wel! developed mix of
public and private radio stations at the national,
regional, and local levels; the SABC radio network,
state-owned and controlled but nominally inde-
pendent, operates 18 stations, one for each of the
11 official languages, 4 community stations, and 3
commercial stations; more than 100 community-
based stations extend coverage to rural areas (2007)
Internet country code: .za
Internet hosts: 4.761 million (2012)
country comparison to the world; 23
Internet users: 4.42 million (2009)
country comparison to the world: 54
Telephone system: general assessment: NA
domestic: NA
international: coastal tadiotelephone station at
Grytviken
Internet country code: .gs
internet hosts: 470 (2012)
country comparison to the world: 184','12e4b6b6cf96111cdad78781021adc5186ea2d2aca114e86e89e4a1a4ebb0ade','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8bc47da7ebc6e68fdbe28e3c3820c4adb2d8a219900aacf6126eacfef9dc0bae',2025,'LK','Sri Lanka','communications',1502,'Telephones—main lines in use: 3.608 million
(2011)
country comparison to the world: 44
Telephones—mobile cellular: 18.319 million
(20144
country comparison to the world: 49
Telephone system: general assessment: tel-
ephone services have improved significantly and
are available in most parts of the country
domestic: national trunk network consists mostly
of digital microwave radio relay; fiber-optic links
now in use in Colombo area and fixed wireless
local loops have been installed; competition is
strong in mobile cellular systems and mobile cel-
lular subscribership is increasing
international: country code—94; the SEA-ME-
WE-3 and SEA-ME-WE-4 submarine cables pro-
vide connectivity to Asia, Australia, Middle East,
Europe, US; satellite earth stations—2 Intelsat
(Indian Ocean)(2011)
Broadcast media: government operates 8 TV chan-
nels and a radio network; multi-channel satellite and
cable TV subscription services available; 35 private
TV stations and about 50 radio stations (2012)
Internet country code: lk
Internet hosts: 9,552 (2012)
country comparison to the world: 136
Internet users: 1.777 million (2009)
country comparison to the world: 77','33a853c054f0ccabc1352969d9dea614e909339211a5bc5e07d1fecda0b0a553','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0f0f95100a6963f44de6085ef1ffc566de9fb21924121c509b9b1ad47a4e0393',2025,'SR','Suriname','communications',1518,'Telephones—main lines in use: 85,500 (2011)
country comparison to the world: 150
Telephones—mobile cellular: 947,000 (2011)
country comparison to the world: 156
Telephone system: general assessment: interna-
tional facilities are good
domestic: combined fixed-line and mobile-cellular
teledensity 185 telephones per 100 persons; micro-
wave radio relay network
international: country code—597; satellite earth
stations—2 Intelsat (Atlantic Ocean) (2010)
Broadcast media: 2 state-owned TV stations; 1
state-owned radio station; multiple private radio
and TV stations (2007)
Internet country code: .sr
Internet hosts: 188 (2012)
country comparison to the world: 202
Internet users: 163,000 (2009)
country comparison to the world: 146
Telephone system: general assessment: adequate
domestic: local telephone service
international: country code—47-790; satellite
earth station—1 of unknown type (for commu-
nication with Norwegian mainland only) (2005)
691
Broadcast media: the Norwegian Broadcasting
Corporation (NRK) began direct TV transmission
to Svalbard via satellite in 1984; Longyearbyen
households have access to 3 NRK radio and 2 TV
stations (2008)
Internet country code: .sj','94e8f3953459fefcbe5eb16d8489b2676f4166d1c2c2c113839d3517ee5ec155','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b51054f020ba2f62fda519c51867237ad569f264cf129eb32b6912e86c593b38',2025,'SE','Sweden','communications',1527,'Telephones—main lines In use: 4.6 million
(2011)
country comparison to the world: 35
Telephones—mobile cellular: 11.194 million
(2011)
country comparison to the world: 69
698
THE CIA WORLD FACTBOOK
Telephone system: general assessment: highly
developed telecommunications infrastructure;
ranked among leading countries for fixed-line,
mobile-cellular, Internet and broadband penetration
domestic: coaxial and multiconductor cables carry
most of the voice traffic; parallel microwave radio
relay systems carry some additional telephone
channels
international: country code—46;
cables provide links to other Nordic countries and
Europe; satellite earth stations—1 Intelsat (Atlan-
tic Ocean), 1 Eutedpat, and 1 Inmarsat (Atlantic
and Indian Ocean regions); note—Sweden shares
the Inmarsat earth station with the other Nordic
countries (Denmark, Finland, Iceland, and Nor-
way) (2011)
Broadcast media: publicly owned TV broadcaster
operates 2 terrestrial networks plus regional stations;
multiple privately-owned TV broadcasters operat-
submarine
` ing nationally, regionally, and locally; about 50 local
TV stations; widespread access to pan-Nordic and
intemational broadcasters through multi-channel
cable and satellite TV; publicly owned radio broad-
caster operates 3 national stations and a network of
25 regional channels; roughly 100 privately owned
local radio stations with some consolidating into
near national networks; an estimated 900 com-
munity and neighborhood radio stations broadcast
intermittently (2008)
Internet country code: .se
Internet hosts: 5.978 million (2010)
country comparison to the world: 19
Internet users: 8.398 million (2009)
country comparison to the world: 33','029e4c141f299937c767e0b7fb763bd4ecc6b00215ab5e032fe9c9103fc354ed','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('48061945f018a1f04be37c01079584bbb63acbcadfe33edc41038cefb239b0f7',2025,'CH','Switzerland','communications',1533,'Telephones—main lines in use: 4.613 million
(2011)
country comparison to the world: 34
Telephones—mobile cellular: 10.122 million
(2011)
country comparison to the world: 75
702
THE CIA WORLD FACTBOOK
Telephone system: general assessment: highly
developed telecommunications infrastructure with
excellent domestic and international services
domestic: ranked among leading countries for
fixed-line teledensity and infrastructure; mobile-
cellular subscribership roughly 125 per 100 per-
sons; extensive cable and microwave radio relay
networks
international: country code—41; satellite earth
stations—2 Intelsat (Atlantic Ocean and Indian
Ocean) (2011)
Broadcast media: the publicly owned radio and
TV broadcaster, Swiss Broadcasting Corporation
(SRG/SSR), operates 7 national TV networks,
3 broadcasting in German, 2 in Italian, and 2 in
French; private commercial TV stations broadcast
regionally and locally; TV broadcasts from stations
in Germany, Italy, and France are widely available
via multi-channel cable and satellite TV services;
SRG/SSR operates 18 radio stations that, along
with private broadcasters, provide national to local
coverage (2009)
Internet country code: .ch
Internet hosts: 5.301 million (2012)
country comparison to the world: 20
Internet users: 6.152 million (2009)
country comparison to the world: 42
Telephones—main lines in use: 4.345 million
(2011)
country comparison to the world: 37
Telephones—mobile cellular: 13.117 million
(2011)
country comparison to the world: 59
Telephone system: general assessment: fair sys-
tem currently undergoing significant improvement
and digital upgrades, including fiber-optic technol-
ogy and expansion of the network to rural areas;
the armed insurgency that began in 2011 has led
to major disruptions to the network and has caused
telephone and Internet outages throughout the
country l
domestic: the number of fixed-line connections
has increased markedly since 2000; mobile-cellular
service growing with telephone subscribership
nearly 60 per 100 persons in 2011
international: country code—963; submarine cable
connection to Egypt, Lebanon, and Cyprus; satel-
lite earth stations—l1 Intelsat (Indian Ocean) and 1
Intersputnik (Atlantic Ocean region); coaxial cable
and microwave radio relay to Iraq, Jordan, Lebanon,
and Turkey; participant in Medarabtel (2011)
706
THE CIA WORLD FACTBOOK
Broadcast media: state-run TV and radio broad-
cast networks; state operates 2 TV networks and
a satellite channel; roughly two-thirds of Syrian
homes have a satellite dish providing access to
foreign TV broadcasts; 3 state-run radio channels;
first private radio station launched in 2005; private
radio broadcasters prohibited from transmitting
news or political content (2007)
Internet country code: sy
Internet hosts: 416 (2012)
country comparison to the world: 188
Internet users: 4.469 million (2009)
country comparison to the world: 52
Telephones—moin lines in use: 16.907 million
(2011)
country comparison to the world: 17
Telephones—mobile cellular: 28.865 million
(2011)
country comparison to the world: 34
Telephone system: general assessment: provides
telecommunications service for every business and
private need y
domestic:
digitalized
international: country code—886; roughly
15 submarine fiber cables provide links
throughout Asia, Australia, the Middle
East, Europe, and the US; satellite earth sta-
tions—2 (2011)
thoroughly modern; completely
709
Broadcast media: 5 nationwide television net-
works operating roughly 75 TV stations; about
85% of households utilize multi-channel cable TV;
national and regional radio networks with about
170 radio stations (2008)
Internet country code: .cw
Internet hosts: 6.272 million (2012)
country comparison to the world: 18
Internet users: 16.147 million (2009)
country comparison to the world: 24','96e39fb2a8db0cf0a6dcde25f3ed50ffedf7cdd0a2cd209f605249ae106af119','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('52d00c383c8bdbf964e6bb0dac91583c49c7535d58a4bec9a99c8a6a2ea49d28',2025,'TJ','Tajikistan','communications',1542,'Telephones—main lines in use: 380,000 (2011)
country comparison to the world: 106
Telephones—mobile cellular: 6.324 million
(2011)
country comparison to the world: 97
Telephone system: general assessment: foreign
investment in the telephone system has resulted
in major improvements; conversion of the existing
fixed network from analogue to digital was com-
pleted in 2012
domestic: fixed line availability has not changed
significantly since 1998 while mobile cellular sub-
scribership, aided by competition among multiple
operators, has expanded rapidly; coverage now
extends to all major cities and towns
international: country code—992; linked by
cable and microwave radio relay to other CIS
republics and by leased connections to the Mos-
cow international gateway switch; Dushanbe
linked by Intelsat to international gateway switch
in Ankara (Turkey); satellite earth stations—3 (2
Intelsat and 1 Orbita) (2011)
Broadcast media: state-run TV broadcaster
transmits nationally on 4 stations and regionally
on 4 stations; 11 independent TV stations broad-
cast locally and regionally; some households are
able to receive Russian and other foreign stations
via cable and satellite; state-run radio broadcaster
operates Radio Tajikistan, Voice of Dushanbe, and
several regional stations; a small number of inde-
pendent radio stations (2010)
Internet country code: .tj
Internet hosts: 6,258 (2012)
country comparison to the world: 142
Internet users: 700,000 (2009)
country comparison to the world: 110
Telephones—main lines in use: 161,100 (2011)
country comparison to the world: 132
Telephones—mobile cellular: 25.666 million
(2011)
country comparison to the world: 39
Telephone system: general assessment: telecom-
munications services are marginal; system operat-
ing below capacity and being modernized for bet-
ter service; small aperture terminal (VSAT) system
under construction
domestic: fixed-line telephone network inade-
quate with less than 1 connection per 100 persons;
mobile-cellular service, aided by multiple provid-
ers, is increasing rapidly and in 2011 exceeded a
subscriber base of 50 telephones per 100 persons;
trunk service provided by open-wire, microwave
radio relay, tropospheric scatter, and fiber-optic
cable; some links being made digital
international: country code—255; landing point
for the EASSy fiber-optic submarine cable system
linking East Africa with Europe and North Amer-
ica; satellite ‘earth stations—2 Intelsat (1 Indian
Ocean, 1 Atlantic Ocean) (2010)
Broadcast media: a state-owned TV station and
multiple privately owned TV stations; state-owned
national radio station supplemented by more than
40 privately owned radio stations; transmissions
of several international broadcasters are available
(2007)
Internet country code: .tz
Internet hosts: 26,074 (2012)
country comparison to the world: 110
Internet users: 678,000 (2009)
country comparison to the world: 111','02718dc236e9086ee8b9d7871b7664891be49311342bfdfa5c4501eafed544fb','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7b537a1ae120172c41767d9e0503d9f517f3e411f79752ef7bf9b33d76adabb1',2025,'TH','Thailand','communications',1551,'Telephones—main lines in use: 6.661 million
(2011)
country comparison to the world: 28
Telephones—mobile cellular: 77.605 million
(2011)
country comparison to the world: 18
Telephone system: general assessment: high
quality system, especially in urban areas like
Bangkok j
domestic: fixed line system provided by both a
government-owned and commercial provider;
wireless service expanding rapidly
international: country code—66; connected to
major submarine cable systems providing links
throughout Asia, Australia, Middle East, Europe,
and US; satellite earth stations—2 Intelsat
(1 Indian Ocean, 1 Pacific Ocean) (2011)
Broadcast media: 6 terrestrial TV stations in Bang-
kok broadcast nationally via relay stations—2 of the
networks are owned by the military, the other 4 are
government-owned or controlled, leased to private
enterprise, and all are required to broadcast govem-
ment-produced news programs twice a day; multi-
channel satellite and cable TV subscription services
are available; radio frequencies have been allotted
for more than 500 government and commercial
radio stations; many small community radio stations
operate with low-power transmitters (2008)
Internet country code: .ch
Internet hosts: 3.399 million (2012)
country comparison to the world: 31
Internet users: 17.483 million (2009)
country comparison to the world.” 23','bbb49a017be1a146496f26a914f1f31461c2ad553157156177da0d51f327ae05','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7a2ca90032fa9fa6f523cb7450e9f2ade07cf21d9e18400ba2ff2d87f7b6601d',2025,'TL','Timor-Leste','communications',1559,'Telephones—main lines in use: 3 100 (2011)
country comparison to the world: 214
Telephones—mobile cellular: 614,200 (2011)
country comparison to the world: 162
Telephone system: general assessment: rudimen-
tary service in urban and some rural areas, which is
expanding with the entrance of new competitors
domestic: system suffered significant damage dur-
ing the violence associated with independence;
limited fixed-line services; mobile-cellular services
have been expanding and are now available in
urban and most rural areas
international: country code—670; international
service is available (2012)
Broadcast media: | public TV broadcast station
broadcasting nationally and 1 public radio broad-
caster with stations in each of the 13 administra-
tive districts; | commercial TV broadcast station,
3 éommercial radio stations, and roughly 20 com-
munity radio stations (2012)
Internet country code: .r!
Internet hosts: 252 (2012)
country comparison to the world: 195
Internet users: 2,100 (2009)
country comparison to the world: 211','7d3aa9570aeb10845651c47aa654642de3ce36ca0da208776f68b0d02b564bcb','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('da4f915b53b32cc4c7ca7ce13eedf98148228ec537200599b9b1e1cee7559c2a',2025,'TG','Togo','communications',1566,'Telephones—main lines in use: 240,000 (2011)
country comparison to the world: 125
728
THE CIA WORLD FACTBOOK
Telephones—mobile cellular: 3.105 million
(2011)
country comparison to the world: 126
Telephone system: general assessment: fair sys-
tem based on a network of microwave radio:relay
toutes supplemented by open-wire lines and a
mobile-cellular system
domestic: microwave radio relay and open-wire
lines for conventional system; combined fixed-
line and mobile-cellular teledensity roughly 50
telephones per 100 persons with mobile-cellular
use predominating
international: country code—228; satellite earth
stations—1 Intelsat (Atlantic Ocean), 1 Sympho-
nie (2010)
Broadcast media: state-owned TV stations with
multiple transmission sites; 5 private TV stations
broadcast locally; cable TV service is available;
state-owned radio network with multiple stations;
several dozen private radio stations and a few com-
munity radio stations; transmissions of multiple
international broadcasters available (2007)
Internet country code: .tg
Internet hosts: 1,168 (2012)
country comparison to the world: 170
Internet users: 356,300 (2009)
country comparison to the world: 123','3b897dcd1fa0a61c6f6c5d44315c01c0ceb500a99bb93df76f1a82a4074441f8','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5a8d81aec3055ac463f48272ad9a3a939987a24164334196bc1fd5723093e6f3',2025,'TK','Tokelau','communications',1576,'Telephone system: general assessment: modern
satellite-based communications system
domestic: radiotelephone service between islands
international: country code—690; radiotelephone
service to Samoa; government-regulated telephone
service (TeleTok); satellite earth stations—3 (2009)
Broadcast media: no TV stations; each atoll
operates a radio service that provides shipping
news and weather reports (2009)
Internet country code: .ck
Internet hosts: 2,069 (2012)
country comparison to the world: 162
Internet users: 800 (2008)
country comparison to the world: 216','f205e4a1a17f3104385a28c070fc6b0c31a2d8d93032a97fc0f8df13489b83eb','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c44709e3b32930b0fa81adbafcf1c590a0aac5b9bd2eb886d4db3729d9c0d41a',2025,'TT','Trinidad and Tobago','communications',1584,'Telephones—main lines in use: 292,000 (2011)
country comparison to the world: 117
Telephones—mobile cellular: 1.825 million
(2011)
country comparison to the world: 143
Telephone system: general assessment: excel-
lent international service; good local service
domestic: combined fixed-line and mobile-cel-
lular teledensity roughly 170 telephones per 100
persons l
international: country code—1-868; submarine
cable systems provide connectivity to US and
parts of the Caribbean and South America; satel-
lite earth station—1 Intelsat (Atlantic Ocean);
tropospheric scatter to Barbados and Guyana
(2011)
Broadcast media: 5 TV networks, one of
which is state-owned, broadcast on multiple
stations; multiple cable TV subscription ser-
vice providers; multiple radio networks, one
state-owned, broadcast over about 35 stations
(2007)
Internet country code: .tt
Internet hosts: 241,690 (2012)
country comparison to the world: 69
internet users: 593,000 (2009)
country comparison to the world: 115','b55ced6e573d928727747c380be25ee67bce9c46cad49ec3bddfde84bd209a2f','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9637fb23f367f9efb52dcd313ce24571abb21580b56a782b6f31351d98c21544',2025,'TN','Tunisia','communications',1589,'Telephones—main lines in use: 1.218 million
(2011)
country comparison to the world: 69
Telephones—mobile cellular: 12.388 million
(2011)
country comparison to the world: 63
Telephone system: general assessment:
above the African average and continuing to be
upgraded; key centers are Sfax, Sousse, Bizerte, and
Tunis; telephone network is completely digitized;
Internet access available throughout the country
domestic: in an effort to jumpstart expansion
of the fixed-line network, the goverment has
awarded a concession to build and operate a VSAT
network with international connectivity; rural
areas are served by wireless local loops; competi-
tion between the two mobile-cellular service pro-
yiders has resulted in lower activation and usage
charges and a strong surge in subscribership; a third
mobile, fixed, and ISP operator was licensed in
2009 and began. offering services in 2010; expan-
sion of mobile-cellular services to include multi-
media messaging and email and Internet to mobile
phone services also leading to a surge in subscrib-
ership; overall fixed-line and mobile-cellular','73e4ac2ef94e58911d57ed73912319923382a056c46b6428d2e62db7b812647b','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('be7fabebcdc6941a4417fd030e3e5e53324465de2e98629b88e710dabac27459',2025,'TM','Turkmenistan','communications',1598,'Telephones—main tines in use: 547,000 (2011)
country comparison to the world: 94
Telephones—mobile cellular: 3.511 million
(2011)
country comparison to the world: 120
Telephone system: general assessment: telecom-
munications network remains underdeveloped and
progress toward improvement is slow; strict gov-
ernment control and censorship inhibits liberaliza-
tion and modernization
domestic: Turkmentelekom, in cooperation with
foreign partners, has installed high-speed fiber-
optic lines and has upgraded most of the country’s
telephone exchanges and switching centers with
new digital technology; combined fixed-line and
mobile teledensity is about 80 per 100 persons;
Russia’s Mobile Telesystems, the only foreign
mobile-cellular service provider in Turkmenistan,
had its operating license suspended in Decem-
ber 2010 but was able to resume operations in
September 2012
international: country code—993; linked by fiber-
optic cable and microwave radio relay to other CIS
republics and to other countries by leased connec-
tions to the Moscow international gateway switch;
an exchange in Ashgabat switches international
747
traffic through ‘Turkey via Intelsat; satellite earth
stations—l1 Orbita and 1 Intelsat (2012)
Broadcast media: broadcast media is government
controlled and censored; 7 state-owned TV and 4
state-owned radio networks; satellite dishes and
programming provide an alternative to the state-run
media; officials sometimes limit access to satellite
TV by removing satellite dishes (2007)
Internet country code: tm
Internet hosts: 714 (2012)
country comparison to the world: 176
Internet users: 80,400 (2009)
country comparison to the world: 166','b401cd7f3870cee101f36c91b92664bf81bd8cc23bd583e2f996691ded41118f','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('83e3f18ab9c7380348c7c4f4f409bce64a81efc30583c783b09d2aecc761724f',2025,'TC','Turks and Caicos Islands','communications',1607,'Telephone system: general assessment: fully
digital system with international direct dialing
domestic: full range of services available; GSM
wireless service available
international: country code—1-649; the Ameri-
cas Region Caribbean Ring System (ARCOS-1)
fiber optic telecommunications submarine cable
provides connectivity to South and Central
America, parts of the Caribbean, and the US; sat-
ellite earth station—1 Intelsat (Atlantic Ocean)
(2011)
Broadcast media: no local terrestrial TV stations,
broadcasts from the Bahamas can be received and
multi-channel cable and satellite TV services are
available; government-run radio network operates
alongside private broadcasters with a total of about
15 stations (2007)
Internet country code: .tc
internet hosts: 73,217 (2012)
country comparison to the world: 86','bcae42b26b73f4495abc05a68323acbfee4fbbd7f339f9041f7f46026b8d69a8','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('37362d60d7f704cc6c169d0f3bd185c2a1208954a09d18a423ee95067647422b',2025,'TV','Tuvalu','communications',1614,'Telephones—main lines in use: 1,400 (2011)
country comparison to the world: 219
Telephones—mobile cellular: 2,100 (2011)
country comparison to the world: 216
Telephone system: general assessment: serves
particular needs for internal communications
domestic: radiotelephone communications
between islands
international: country code—688; international
calls can be made by satellite (2007)
Broadcast media: no TV stations; many house-
holds use satellite dishes to watch foreign TV sta-
tions; 1 government-owned radio station, Radio
Tuvalu, includes relays of programming from inter-
national broadcasters (2009)
Internet country code: .tv
Internet hosts: 145,158 (2012)
country comparison to the world: 80
internet users: 4,200 (2008)
country comparison to the world: 206','8204db21e08c4067e283ea5f8fb3218719ff2f745804b1db678fb60c2ae0badd','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7c66dc9bf3857db2ab985007872ac696eade925106879a6fc60b4a23b13c2387',2025,'UG','Uganda','communications',1622,'Telephones—main lines in use: 464,800 (2011)
country comparison to the world: 103
Telephones—mobile cellular: 16.697 million
(2011)
country comparison to the world: 52
Telephone system: general assessment: mobile
cellular service is increasing rapidly, but the num-
ber of main lines is still deficient; work underway
on a national backbone information and commu-
nications technology infrastructure; international
755
phone networks and Internet connectivity pro-
vided through satellite and VSAT applications
domestic: intercity traffic by wire, microwave
radio relay, and radiotelephone communication
stations, fixed and mobile-cellular systems for
short-range traffic; mobile-cellular teledensity
about 50 per 100 persons in 2010
international: country code—256; satellite
earth stations—1 Intelsat (Atlantic Ocean) and
1 Inmarsat; analog links to Kenya and Tanzania
'' (2011)
Broadcast media: public broadcaster, Uganda
Broadcasting Corporation (UBC), operates radio
and TV networks; ‘Uganda first began licensing
privately owned stations in the 1990s; by 2007
there were nearly 150 radio and 35 TV stations,
mostly based in and around Kampala; transmis-
sions of multiple international broadcasters are
available in Kampala (2007)
Internet country code: .ug
Internet hosts: 32,683 (2012)
country comparison to the world: 106
Internet users: 3.2 million (2009)
country comparison to the world: 66','aae83ff2854667d9d1ff94e62c3b45798bdd2074c679540b4cbce81ee0beb56e','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('87d22450d13ea9a1547cbfc78f72031a962a9ffe981417a0cd7fc75b508cb104',2025,'UA','Ukraine','communications',1633,'Telephones—main lines in use: 12.681 million
(2011)
country comparison to the world: 19
Telephones—mobile cellular: 55.576 million
(2011)
country comparison to the world: 23
Telephone system: general assessment:
Ukraine’s telecommunication development plan
emphasizes improving domestic trunk lines, inter-
national connections, and the mobile-cellular
system domestic: at independence in December
1991, Ukraine inherited a telephone system that
was antiquated, inefficient, and in disrepair; more
than 3.5 million applications for telephones could
not be satisfied; telephone density is rising and the
domestic trunk system is being improved; about
one-third of Ukraine’s networks are digital and
a majority of regional centers now have digital
switching stations; improvements in local net-
works and local exchanges continue to lag; the
mobile-cellular telephone system’s expansion has
slowed, largely due to saturation of the market
which has reached 125 mobile phones per 100','6ea938311d565ff296b81afd27d534503b57aa624ff933c997a1af7d40b819c0','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('caa1ce7e402c07543d386518eb69e42fe3814c612c82fa7ed0d3bb1697b67290',2025,'AE','United Arab Emirates','communications',1641,'Telephones—main lines in use: 1.825 million
(2011)
country comparison to the world: 61
Telephones—mobile caliular: 11.727 million (2011)
country comparison to the world: 66
Telephone system: general assessment: modem
fiber-optic integrated services; digital network
with rapidly growing use of mobile-cellular tel-
ephones; key centers are Abu Dhabi and Dubai
domestic: microwave radio relay, fiber optic and
coaxial cable
international: country code—971; linked to the
international submarine cable FLAG (Fiber-Optic
Link Around the Globe); landing point for both
the SEA-ME-WE-3 and SEA-ME-WE-4 subma-
rine cable networks; satellite earth stations—3
Intelsat (1 Atlantic Ocean and 2 Indian Ocean)
and 1 Arabsat; tropospheric scatter to Bahrain;
microwave radio relay to Saudi Arabia (2011)
Broadcast media: except for the many organiza-
tions now operating in Dubai''s Media Free Zone,
most TV and radio stations remain government-
owned; widespread use of satellite dishes provides
access to pan-Arab and other international broad-
casts (2007)
Internet country code: .ae
Internet hosts: 337,804 (2012)
country comparison to the world: 61
Internet users: 3.449 million (2009)
country comparison to the world: 61','8a4911ff6d2cd30c2ad635f65acbead31684ffde19154cb11dc09e2791767a2c','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('02f40ae92252f14c7de797e628d8561ac8f73fa11c1b7520bd2b7dc411994536',2025,'GB','United Kingdom','communications',1650,'Telephones—main lines In use: 33.23 million
(2011)
country comparison to the world: 9
Telephones—mobile cellular: 81.612 million
(2012)
country comparison to the world: 17
Telephone system: general assessment: techno-
logically advanced domestic and international
system
domestic: equal mix of buried cables, microwave
radio relay, and fiber-optic systems
768
THE CIA WORLD FACTBOOK
international: country code—44; numerous sub-
marine cables provide links throughout Europe,
Asia, Australia, the Middle East, and US; satel-
lite earth stations—10 Intelsat (7 Atlantic Ocean
and 3 Indian Ocean), 1 Inmarsat (Atlantic Ocean
region), and 1 Eutelsat; at least 8 large intema-
tional switching centers (2011)
Broadcast media: public service btoadcaster,
British Broadcasting Corporation (BBC), is the
largest broadcasting corporation in the world;
BBC operates multiple TV networks with regional
and local TV service; a mixed system of public
and commercial TV broadcasters along with satel-
lite and cable systems provide access to hundreds
of TV.stations throughout the world; BBC oper-
ates multiple national, regional, and local radio
networks with multiple transmission sites; a large
number of commercial radio stations as well as sat-
ellite radio services are available (2008)
Internet country code: .uk
Internet hosts: 8.107 million (2012)
country comparison to the world: 15
internet users: 51.444 million (2009)
country comparison to the world: 7','95e7d6fe189c5cc4688927b7f2d26454b88e2a035387003753d961b01a40e8ee','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8ab9b8a2594226fc40ded9d22d64b224a2b0c0cbf7ab06c03337b2722ce6e096',2025,'US','United States','communications',1659,'Telephones—main lines in use: 146 million
(2011)
country comparison to the world: 2
Telephones—mobile cellular: 290.3 million
(2011)
country comparison to the world; 3
Telephone system: general assessment: a large,
technologically advanced, multipurpose commu-
nications system
domestic: a large system of fiber-optic cable,
microwave radio relay, coaxial cable, and domestic
satellites carries every form of telephone traffic; a
rapidly growing cellular system carries mobile tel-
éphone traffic throughout the country
international: country code—1; multiple ocean
cable systems provide international connectivity;
satellite earth stations—61 Intelsat (45 Arlan-
tic Ocean and 16 Pacific Ocean), 5 Intersputnik
(Atlantic.Ocean region), and 4 Inmarsat (Pacific
and Atlantic Ocean regions) (2011)
Broadcast media: 4 major terrestrial TV net-
works with affiliate stations throughout the coun-
try, plus cable and satellite networks, independ-
ent stations; and-a limited public broadcasting
sector that is largely supported by private grants;
overall, thousands of TV stations broadcasting;
multiple national radio networks with many affili-
ate stations; while most stations are commercial,
National Public Radio (NPR) has a network of
some 600 member stations; satellite radio avail-
able; overall, nearly
15,000 radio stations operating (2008)
Internet country code: .us
Internet hosts: 505 million (2012); note—the
US Internet total host count includes the follow-
ing top level domain host addresses:.us,.com,.edu,.
gov,.mil,.net, and.org
country comparison to the world: 1
Internet users: 245 million (2009)
country comparison to the world: 2','5682d8864538869d7145ef1ea1170a20ade2d4aab49200c6fed21b3fd1dce649','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('81d230e296807f564d38a147fc02ba441183ea60bf811caf3dc574529b458630',2025,'UY','Uruguay','communications',1666,'Telephones—main lines in use: 964,900 (2011)
country comparison to the world: 80
Telephones—mobite cellular: 4.757 million
(2011)
country comparison to the world: 109
Telephone system: general assessment: fully
digitalized
domestic: most modern facilities concentrated in
Montevideo; nationwide microwave radio relay
network; overall fixed-line and mobile-cellular
teledensity has reached 170 telephones per 100
persons
international: country code—598; the UNISOR
- submarine cable system pravides direct connec-
tivity te Brazil and Argentina; satellite earth sta-
tions—2 Intelsat (Atlantic Ocean) (2011)
Broadcast media: mixture of privately owned and
state-run broadcast media; more than 100 com-
mercial radio stations and about 20 TV channels;
cable TV is available; many community radio and
TV stations; adopted the hybrid Japanese/Brazil-
ian HDTV standard (ISDB-T) in December 2010
(2010)
Internet country code: .uy
Internet hosts: 1.036 million (2012)
country comparison to the world: 45
Internet users: 1.405 million (2009)
country comparison to the world: 86','71bc039036671ee68b573c4fa9914e7b10e5948f880b9749377a220c4c6e34ca','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1efd8a7da653ef5bef853586ec7b01ca822ee17ee31a60464e045cfd88d08bf6',2025,'UZ','Uzbekistan','communications',1675,'Telephones—main lines in use: 1.928 million
(2011)
country comparison to the world: 59
Telephones—mobile cellular: 25.442 million
(2011)
country comparison to the world: 40
Telephone system: general assessment: digital
exchanges in large cities and in rural areas
domestic: the. state-owned telecommunications
company, Uzbektelecom, owner of the fixed line
telecommunications system, has used loans from
the Japanese government and the China Develop-
ment Bank to upgrade fixed-line services including
conversion to digital exchanges; mobile-cellular
services are growing rapidly, with the subscriber
base reaching 25 million in 2011
international: country code—998; linked by
fiber-optic cable or microwave radio relay with
CIS member states and to other countries by
leased connection via the Moscow international
gateway switch; after the completion of the Uzbek
link to the Trans-Asia-Europe (TAE) fiber-optic
cable, Uzbekistan plans to establish a fiber-optic
connection to Afghanistan (2009)
Broadcast media: government controls media;
11 state-owned broadcasters—7 TV and 4 radio—
provide service to virtually the entire country;
about 20 privately owned TV stations, overseen
by local officials, broadcast to local markets;
privately-owned TV stations are required to lease
transmitters from the government-owned Repub-
lic TV and Radio Industry Corporation; about 15
privately owned radio broadcasters are affiliated
with the National Association of Electronic Mass
Media of Uzbekistan, a government sponsored
NGO for private broadcast media
Internet country code: .uz
Internet hosts: 56,075 (2012)
country comparison to the world: 94
` Internet users: 4.689 million (2009)
country comparison to the world: 50','782d657e0d023296e93641d6b14ae4b66dbc04d7df4e27becf2b942e73326bba','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('97409765245dffcda6bec9eee0901a75da6e8733ba9b3ba47b427ccfd63b905e',2025,'VU','Vanuatu','communications',1685,'Telephones—main lines in use: 6,200 (2011)
country comparison to the world: 208
Telephones—mobile cellular: 137,000 (2011)
country comparison to the world: 184
Telephone system: international: country
code—678; satellite earth station—1 Intelsat
(Pacific Ocean)
Broadcast media: | state-owned TV station;
multi-channel pay TV is available; state-owned
Radio Vanuatu operates 2 radio stations; 2 privately-
owned radio broadcasters; programming from multi-
ple international broadcasters is available (2008)
internet country code: .vu
Internet hosts: 5,655 (2012)
country comparison to the world: 143
Internet users: 17,000 (2009)
country comparison to the world; 195','76cb9a935bf682176e436e3d97b859b60ed060480d05a45803f77f74f0c3c87a','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('975ad2a71c3342d634d2159fe0f4d464a2d6a2a3c35cadfb27aa32c0d03d7914',2025,'VN','Viet Nam','communications',1692,'Telephones—main lines in use: 10.175 million
(2011)
country comparison to the world: 21
Telephones—mobile cellular: 127.318 million
(2011)
country comparison to the world: 8
Telephone system: general assessment: Vietnam
is putting considerable effort into modernization
and expansion of its telecommunication system
domestic: all provincial exchanges are digital-
ized and connected to Hanoi, Da Nang, and Ho
Chi Minh City by fiber-optic cable or micro-
wave radio relay networks; main lines have been
increased, and the use of mobile telephones is
growing rapidly
international: country code—84; a landing point
for the SEA-ME-WE-3, the C2C, and Thailand-
Vietnam-Hong Kong submarine cable systems; the
Asia-America Gateway submarine cable system,
completed in 2009, provided new access links to
Asia and the US; satellite earth stations—2 Inter-
sputnik (Indian Ocean region) (2011)
Broadcast media: government controls all broad-
cast media exercising oversight through the Min-
istry of Information and Communication (MIC);
government.controlled national TV provider,
Vietnam Television (VTV), operates a network
of 9 channels with several regional broadcasting
centers; programming is relayed nationwide via a
network of provincial and municipal TV stations;
law limits access to satellite TV but many house-
holds are able to access foreign programming via
home satellite equipment; government-controlled
Voice of Vietnam, the national radio broadcaster,
broadcasts on 6 channels and is repeated on AM,
FM, and shortwave stations throughout Vietnam
(2008)
Internet country code: .vn
Internet hosts: 189,553 (2012)
country comparison to the world: 74
Internet users: 23.382 million (2009)
country comparison to the world: 17','021bf3dde63f85e51c9288d082787a9fc844da7ddde18be27f421abb63ab32e3','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5bbf28f081a60e338bf6386c22b113c892c9678bc7793fa8c517619f66b1dca4',2025,'WF','Wallis and Futuna','communications',1701,'Telephone system: general assessment: sat-
ellite communications; 2 Defense Switched
Network circuits off the Overseas Telephone
System (OTS); located in the Hawaii area
code—808
Broadcast media: American Armed Forces Radio
and Television Service (AFRTS) provides satellite
radio/TV broadcasts (2009)
Telephone system: international: country
code—681
coconuts, breadfruit,
Broadcast media: the publicly owned French
Overseas Network (RFO), which broadcasts to
France’s overseas departments and territories, is
carried on the RFO Wallis ‘and Fortuna TV and
radio stations (2008)
Internet country code: .wf
internet hosts: 2,760 (2012)
country comparison to the world: 157
Internet users: 1,300 (2009)
country comparison to the world: 212','e5d8c5a26990a1de53f3adb0355ef134e58909250f6441403acc705af1f6785c','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('de9dfe10a43e8553140c69abbfc67c159551330aea4ef024a2923d3f3466b272',2025,'EH','Western Sahara','communications',1716,'Telephone system: general assessment: sparse
and limited system domestic: NA
international: country code—212; tied into Moroc-
co''s system, by microwave radio relay, tropospheric
scatter, and satellite; satellite earth stations—2 Intelsat
(Atlantic Ocean) linked to Rabat, Mérocco (2008)
Broadcast media: Morocco’s state-owned broad-
caster, Radio-Television Marocaine (RTM), oper-
ates a radio service from Laayoune and relays
TV service; a Polisario-backed radio station also
broadcasts (2008)
Internet country code: .ch
Telephones—main lines in use: 1.2 billion
(2011)
Telephones—mobile cellular: 6 billion (2011)
Internet users: 2.1 billion (2010)','900228e4353f9382a6d29c5bc3475658a4a3aa6428cd2b50e362fdb666cbed62','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1470285ab475965e41b1a61c8bac7274bd39728f9f6faedb9c10883e62c2c646',2025,'YE','Yemen','communications',1721,'Telephones—main lines in use: 1.075 million
(2011)
country comparison to the world: 74
Telephones—mobile cellular: 11.668 million
(2011).
country comparison to the world: 68
Telephone system: general assessment: since
unification in 1990, efforts have been made to cre-
ate a national telecommunications network
domestic: the national network consists of micro-
wave radio relay, cable, tropospheric scatter, GSM
and CDMA mobile-cellular telephone systems;
fixed-line and mobile-cellular teledensity remains
low by regional standards
international: country code—967; landing
point for the international submarine cable Fibet-
Optic Link Around the Globe (FLAG); satellite
earth stations—3 Intelsat (2 Indian Ocean and 1
Atlantic Ocean), 1 Intersputnik (Atlantic Ocean
region), and 2 Arabsat; microwave radio relay to
Saudi Arabia and Djibouti (2006)
Broadcast media: state-run TV with 2 stations;
state-run radio with 2 national radio stations and 5
local stations; stations from Oman and Saudi Ara-
bia can be accessed (2007)
Internet country code: .ye
Internet hosts: 33,206 (2012)
country comparison to the world: 105
Internet users: 2.349 million (2009)
country comparison to the world: 71','7ca03804be7cac7d268b8459ebe600b681b749bea7cb130dbc8dd0faf32afad3','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);

SET NAMES utf8mb4;
CREATE TABLE IF NOT EXISTS worldfactbook_chunks (
  chunk_id CHAR(64) NOT NULL,
  edition_year SMALLINT UNSIGNED NOT NULL,
  entity_code VARCHAR(24) NOT NULL DEFAULT '',
  entity_name VARCHAR(160) NOT NULL DEFAULT '',
  category VARCHAR(96) NOT NULL,
  ordinal INT UNSIGNED NOT NULL,
  content MEDIUMTEXT NOT NULL,
  content_sha256 CHAR(64) NOT NULL,
  source_provider VARCHAR(64) NOT NULL,
  source_identifier VARCHAR(255) NOT NULL,
  source_format VARCHAR(32) NOT NULL,
  source_sha256 CHAR(64) NOT NULL,
  source_url TEXT NOT NULL,
  extractor VARCHAR(64) NOT NULL,
  PRIMARY KEY (chunk_id),
  KEY idx_wfb_year_category (edition_year, category),
  KEY idx_wfb_entity_year (entity_code, edition_year),
  KEY idx_wfb_source_sha (source_sha256)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c12ae247c27a82b186a3e63501419c0581711ec1be662da70d03994961bb62dd',2025,'ZW','Zimbabwe','energy',18,'Electricity—production
Electricity—consumption
Electricity—exports
Electricity—imports
Electricity—installed
capacity
Electricity—from fossil fuels
Electricity—from nuclear fuels
Electricity—from hydroelectric plants
generating
Electricity—from other renewable
sources
Crude oil—production
Crude oil—exports
Crude oil—im ports
Crude oil—proved reserves
Refined petroleum products—production
Refined petroleum products—
consumption
Refined petroleum products—exports
Refined petroleum products—imports
Natural gas—production
Natural gas—consumption
Natura! gas—exports
Natural gas—imports
Natural gas—proved reserves
Carbon dioxide emissions from con-
sumption of energy
Electricity—production: 7.615 billion kWh
(2009 est.)
country comparison to the world: 101
Electricity—consumption: 12.54 billion kWh
(2009 est.)
country comparison to the world: 83
Electricity—exports: 53 million kWh (2009 est.)
country comparison to the world: 77
Electricity—imports: 5.497 billion kWh (2009
est.)
country comparison to the world: 37
Electricity—installed generating capacity:
2.005 million kW (2009 est.)
country comparison to the world: 101
Electricity—from fossil fuels: 66.1% of total
installed capacity (2009 est.)
country comparison to the world: 121
Electricity—from nuclear fuels: 0% of total
installed capacity (2009 est.)
country comparison to the world: 209
Electricity—from hydroelectric plants: 33.9%
of total installed capacity (2009 est.)
country comparison to the world: 64
Electricity—from other renewable sources: 0%
of total installed capacity (2009 est.)
country comparison to the world: 209
Crude ojl—production: 0 bbl/day (2011 est.)
country comparison to the world: 210
Crude oll—exports: 0 bbi/day (2009 est.)
country comparison to the world: 210
Crude oil—imports: 0 bbl/day (2009 est.)
country comparison to the world: 146
Crude oll—proved reserves: 0 bb! (1 January
2012 est.)
country comparison to the world: 209
Refined petroleum products—production: 0
bbl/day (2008 est.)
country comparison to the world: 212
Refined petroleum products—consumption:
19,030 bbl/day (2011 est.)
country comparison to the world: 132
Refined petroleum products—exports: 0 bbl/
day (2009 est.)
country comparison to the world: 147
Refined petroleum products—imports: 13,140
bbl/day (2008 est.)
country comparison to the world: 125
Natural gas—production; 0 cu m (2010 est.)
country comparison to the world: 213
Natural gas—consumption: 0 cu m (2010 esr.)
country comparison to the world: 213
Natural gas—exports: 0 cu m (2010 est.)
country comparison to the world: 211
Natural gas—imports: 0 cu m (2010 est.)
country comparison to the world: 84
Natural gas—proved reserves: Ocu m (1 Janu-
ary 2012 est.)
country comparison to the world: 210
Carbon dioxide emissions from consumption
of energy: 8.493 million Mr (2010 est.)
country comparison. to the world: 105','342d625ce838d123111b8319153cf3a868b782df17beeeed791c5d90c5db6cbb','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c630036e9897dd3d38e57d6d712f15d85d1fc6bed1e11d75ceb6cee434d5df41',2025,'AF','Afghanistan','energy',28,'Electricity—production: 913.1 million kWh
(2009 est.)
countty comparison to the world: 149
Electricity—consumption: 2.226 billion kWh
(2009 est.)
country comparison to the world: 138
Electricity—exports: 0 kWh (2010 est.)
country comparison to the world: 155
Electricity—imports: 1.377 billion kWh (2009
est.)
country comparison to the world: 57
Electricity—instalied generating capacity:
489,100 kW (2009 est.)
country comparison to the world: 139
Electricity—trom fossil fuels: 23.5% of total
installed capacity (2009 est.)
country comparison to the world: 188
Electricity—from nuclear fuels: 0% of total
installed capacity (2009 est.)
country comparison to the world: 36
Electricity—from hydroelectric plants: 76.5% of
total installed capacity (2009 est.)
country comparison to the world: 17
Electricity—trom other renewable sources: 0%
of total installed capacity (2009 est.)
country comparison to the world: 101
Crude oll—production: 1,950 bbl/day (2012 est.)
country comparison to the world: 93
Crude oll—exports: 0 bbi/day (2009 est.)
country comparison to the world: 74
Crude oll—imports: 0 bbi/day (2009 est.)
country comparison to the world: 149
“Crude oil—proved reserves: 87 million bbl
(1 January 2012 es)
country comparison to the world: 75
Refined petroleum products—production: 0
bbl/day (2008 est.)
country comparison to the world: 119
Refined petroleum products—consumption:
4,229 bbl/day (2011 est.)
country comparison to the world: 175
Refined petroleum products—exports: 0 bbl/
day (2008 est.)
country comparison to the world: 148
Refined petroleum products—imports: 5,193
bbl/day (2008 est.)
country comparison to the world: 154
Natural gas—production: 38 million cu m (2010
est.)
country comparison to the world: 86
Naturai gas—consumption: 30 million cu m
(2010 est.)
country comparison to the world: 110
Natural gas—exports: 0 cu m (2010 est.)
country comparison to the world: 53
Natural gas—imports: cu m (2010 est.)
country comparison to the world: 150
Natural gas—proved reserves: 49.55 billion
cum (1 January 2012 es)
country comparison to the world: 67
Carbon dioxide emissions from consumption of
energy: 790,200 Mt (2010 est.)
country comparison to the world: 173','e11867ec2f9753cfaf1acb1a21da0912ded22204f40b24f263349d61d6c667d3','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3ba148c4c85ff1f27b721b97ec6320c6d88145403b0e27781716281e1b54f3c3',2025,'AL','Albania','energy',44,'Electricity—production: 5.209 billion kWh
(2009 est.)
country comparison to the world: 117
Electricity—consumption: 4.521 billion kWh
(2009 est.)
country comparison to the world: 119
Electricity—exports: 1.906 billion kWh (2010
est.)
country comparison to the world: 42
Electricity—imports: 1.005 billion kWh (2010
est.)
country comparison to the world: 65
Electricity—installed generating capacity:
1.61 million kW (2009 est.)
country comparison to the world: 111
Electricity—from fossil fuels: 9.9% of total
installed capacity {2009 est.)
country comparison to the world: 195
Electricity—from nuclear fuels: 0% of total
installed capacity (2009 est.)
country comparison to the world: 39
Electricity—trom hydroelectric plants: 90.1%
of total installed capacity (2009 est.)
country comparison to the world: 13
Electricity—from other renewable sources: 0%
of total installed capacity (2009 est.)
country comparison to the world: 104
Crude oll—production: 15,520 bbl/day (2011
est.)
country comparison to the world: 77
Crude oli—exports: 6,920 bbl/day (2009 est.)
country comparison to the world: 60
Crude oil—imports: 0 bbl/day (2009 est.)
country comparison to the world: 151
Crude oil—proved reserves: 199.1 million bbl
(1 January 2012 es)
country comparison to the world: 62
Refined petroleum products—production:
6,377 bbl/day (2008 est.)
country comparison to the world: 109
Refined petroleum’ products—consumption:
38,390 bbl/day (2011 est.)
country comparison to the world: 111
Refined petroleum products—exports: 914.5
bbl/day (2008 est.)
country comparison to the world: 112
Refined petroleum products—imports: 24,610
bbl/day (2008 est.)
country comparison to the world: 95
Natural gas—production: 30 million cu m (2010
est.)
country comparison to the world: 87
Natural gas—consumption: 30 million cu m
(2010 est.)
country comparison to the world: 111
Natural gas—exports: 0 cu m (2010 est.)
country comparison to the world: 54
Natural gas—imports: 0 cu m (2010 est.)
country comparison to the world: 153
Natural gas—proved reserves: 849.5 million
cu m (1 January 2012 es)
country comparison to the world: 102
Carbon dioxide emissions from consumption
of energy: 4.893 million Mt (2010 est.)
country comparison to the world: 124','326fa6527cc10722c3fd0cb754afaecc18f9a1ba7d1047ebd2bb4dae36fed202','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('24a7f5c5495651b896837fcd562bc412afe4ec240b24d5896da8a1ae299fa096',2025,'DZ','Algeria','energy',51,'Electricity—production: 40.22 billion kWh
(2009 est.)
country comparison to the world: 59
Electricity—consumption: 31.39 billion kWh
(2009 est.)
country comparison to the world: 61
Electricity—exports: 405 million kWh (2009
est.)
country comparison to the world: 63
Electricity—imports: 369 million kWh (2009
est.)
country comparison to the world: 81
Electricity—instalied generating capacity:
10.38 million kW (2009 est.)
country comparison to the world: 55
Electricity—trom fossil fuels: 97.3% of total
installed capacity (2009 est.)
country comparison to the world: 62
Electricity—from nuclear fuels: 0% of total
installed capacity (2009 est.)
country comparison to the world: 37
Electricity—from hydroelectric plants: 2.7% of
total installed capacity (2009 est.)
country comparison to the world: 133
Electricity—from other renewable sources: 0%
of total installed capacity (2009 est.)
country comparison to the world: 102
Crude oil—production: 1.885 million bbi/day
(2011 est.)
country comparison to the world: 16
Crude oil—exports: 697,500 bbl/day (2009 est)
country comparison to the world: 20
Crude oit—imports: 8,152 bbl/day (2009 est.)
country comparison tothe world: 79
Crude oii—proved reserves: 12.26 bilbon bbt
(1 January 2013 es)
country comparison to the world: 18
Refined petroleum products—production:
447,100 bbl day (2008 est)
country comparison to the world: 34
Refined petroleum products—consumption:
316.400 bbliday (2011 est.)
country comparison to the world: 41
Refined petroleum products—exports: 446,500
bbi/day (2008 est.)
country comparison.to the world: 18
Refined petroleum products—imports: 11,700
bbl/day (2008 esr.)
country comparison to the world: 130
Natural gos—production: 84.61 billion cs m (2010
est.)
country comparison to the world: 11
Natural gas—consumption: 28.82 billion cu m
(2010 est.)
country comparison to the world: 30
Natural gas—exports: 55.79 billion cu m (2010
est.)
country comparison to the world: 7
Natural gas—imports: 0 cu m (2010 est.)
country comparison to the world: 151
Notural gas—proved reserves: 4.502 willion
cum (1 January 2012 es)
country comparison to the world: 11
Carbon dioxide emissions from consumption
of energy: 110.9 million Mt (2010 est.)
country comparison to the world: 39','26f52e18c9f4ea0940a8aee79d0fb4bc7a851433e624157b9ae5d955c2fa3e82','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1b67c0e0a3f48b0c6365e035d5e2dba9d1d3b8668a649facbf4b5cca1757d248',2025,'AS','American Samoa','energy',63,'Electricity—production: 190 million kWh (2009
est.)
14
THE CIA WORLD FACTBOOK
country comparison to the world: 184
Electricity—consumption: 176.7 million kWh
(2009 est.)
country comparison to the world: 189
Electricity—exports: 0 kWh (2010 est.)
country comparison to the world: 157
Electricity—imports: 0 kWh (2010 est.)
country comparison to the world: 156
Electricity—installed generating capacity:
60,000 kW (2009 est.)
country comparison to the world: 178
Electricity—from fossil fuels: 100% of total
installed capacity (2009 est.)
country comparison to the world: 3
Electricity—from nuclear fuels: 0% of total
installed capacity (2009 est.)
country comparison to the world: 41
Electricity—from hydroelectric plants: 0% of
total installed capacity (2009 est.)
country comparison to the world: 155
Electricity—from other renewable sources: 0%
of total installed capacity (2009 est.)
country comparison to the world: 106
Crude oil—production: 0 bbl/day (2011 est.)
country comparison to the world: 107
Crude oil—exports: 0 bbl/day (2009 est.)
country comparison to the world: 76
Crude oii—imports: 0 bbl/day (2009 est.)
country comparison to the world: 154
Crude oil—proved reserves: 0 bbi (1 January
2012 es)
country comparison to the world: 105
Refined petroleum products—production: 0
bbl/day (2008 est.)
country comparison to the world: 121
Refined petroleum products—consumption:
5,115 bbl/day (2011 est.)
country comparison to the world: 168
Refined petroleum products—exports: 0 bbl/
day (2008 est.)
country comparison to the world: 150
Refined petroleum products—imports: 2,697
bbl/day (2008 est.)
country comparison to the world: 172
Natural gas—production: 0 cu m (2010 ese.)
country comparison to the world: 98
Natural gas—consumption: 0 cu m (2010 est.)
country comparison to the world: 116
Natural gas—exports: 0 cu m (2010 est.)
country comparison to the world: 57
Natural gas—imports: 0 cu m (2010 est.)
country comparison to the world: 155
Natural gas—proved reserves: 0 cu m (1 Janu-
ary 2012 es)
country comparison to the world: 108
Carbon dioxide emissions from consumption
of energy: 688,800 Mr (2010 est.)
country comparison to the world: 177','ccb6dce4feb161c4329d481a723a367dcd4b3e86882d6d019274e186e61f9954','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7fd962bf6905582a6d9348640d6be26935f441f24fec33a09c3c7c079e4f8bc1',2025,'AO','Angola','energy',76,'Electricity—production: 4.08 billion kWh (2009
est.)
country comparison to the world: 123
Electricity—consumption: 3.659 billion kWh
(2009 est.)
country comparison to the world: 125
Electricity—exports: 0 kWh (2010 est.)
country comparison to the world: 156
Electricity—Imports: 0 kWh (2010 est.)
country comparison to the world: 155
Electricity—tnstalied generating capacity:
1.155 million kW (2009 est.)
country comparison to the world: 121
Electricity—from fossil fuels: 56.9% of total
installed capacity (2009 est.)
country comparison to the world: 143
Electricity—from nuclear fuels: 0% of total
installed capacity (2009 est.)
country comparison to the world: 40
Electricity—from hydroelectric plants: 43.1%
of total installed capacity (2009 est.)
country comparison to the world: 51
Electricity—from other renewable sources; 0%
of total installed capacity (2009 est.)
country comparison to the world: 105
Crude oil—production: 1.84 million bbl/day
(2012 est.)
country comparison to the world: 17
Crude oil—exports: 1.757 million bbl/day (2009
est.)
country comparison to the world: 9
Crude oli—imports: 0 bbl/day (2009 est.)
country comparison to the world: 153
Crude oil—proved reserves: 15 billion bbl
(1 January 2013 es)
country comparison to the world; 16
Refined petroleum products—production:
37,310 bbl/day (2008 est.)
country comparison to the world: 89
Refined petroleum products—consumption:
79,430 bbl/day (2011 est.)
country comparison to the world: 87
Refined petroleum products—exports: 31,050
bbl/day (2008 est.)
country comparison to the world: 67
20
THE CIA WORLD FACTBOOK
Refined petroleum products—imports: 41,480
bbl/day (2008 est.)
country comparison to the world: 75
Natural gas—production: 734 million cu m
(2010 est.)
country comparison to the world: 69
Natural gas—consumption: 733 million cu m
(2010 est.)
country comparison to the world: 96
Natural gas—exports: 0 cu m (2010 est.)
country comparison to the world: 56
Natural gas—imports: 0 cu m (2010 est.)
country comparison to the world: 154
Natural gas—proved reserves: 310 billion cum
(1 January 2012 es)
country comparison to the world: 39
Carbon dioxide emissions from consumption
of energy: 24.2 million Mt (2010 est.)
country comparison to the world: 80','8cf3bdd0cde857e34c5dcd5733de521e71e385e0d9848d030a1ae9a4b01fbee1','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e31a5d550bd1579db156484467b43b291864bb1ac6d92e3af4cfac2dbdd9cfdd',2025,'AR','Argentina','energy',113,'Electricity—production: 116 billion kWh (2009
est.)
country comparison to the world: 33
Electricity—consumption: 104.2 billion kWh
(2009 est.)
country comparison to the world: 32
Electricity—exports: 701 billion kWh (2010
est.)
country comparison to the world: 45
Electricity—imports: 10.3 billion kWh (2010
est.)
country comparison to the world: 22
Electricity—installed generating capacity: mil-
lion kW (2009 est.)
country comparison to the world: 27
Electricity—from fossil fuels: 65.4% of toral
installed capacity (2009 est.)
country comparison to the world: 125
Electricity—from nuclear fuels: 3.2% of total
installed capacity (2009 est.)
country comparison to the world: 26
Electricity—from hydroelectric plants: 28.3%
of total installed capacity (2009 est.)
country comparison to the world: 80
Electricity—from other renewable sources:
0.1% of total installed capacity (2009 est.)
country comparison to the world: 98
Crude oil—production: 734,000 bbi/day (2011
est.)
country comparison to the world: 27
Crude oil—exports: 93,600 bbl/day (2009 est.)
country comparison to the world: 39
Crude oil—imports: 0 bbl/day (2009 est.)
country comparison to the world: 155
Crude oil—proved reserves: 2.82 billion bbl
(1 January 2013 es)
country comparison to the world: 33
Refined petroleum products—production:
604,200 bbl/day (2008 est.)
country comparison to the world: 31
Refined petroleum products—consumption:
678,100 bbl/day (2011 est.)
country comparison to the world: 28
Refined petroleum products—exports: 66,700
bbl/day (2008 est.)
country comparison to the world: 52
Refined petroleum products—imports: 37,260
bbl/day (2008 est.)
country comparison to the world: 79
Natural gos—production: 40.1 billion cu m
(2010 est.)
country comparison to the world: 26
Natural gas—consumption: 43.29 billion cu m
(2010 est.)
country comparison to the world: 23
Natura! gas—exports: 420 million cu m (2010
est.) i
country comparison to the world: 43
Natural gas—imports: 3.61 billion cu m (2010
est.)
32
THE CIA WORLD FACTBOOK
country comparison to the world: 39
Natural gas—proved reserves: 378.8 billion
cu m (1 January 2012 es)
country comparison to the world: 37
Carbon dioxide emissions from consumption
of energy: 169.8 million Mt (2010 est.)
country comparison to the world: 32','288206e90316d841a3a6fa0414cb917115b5be2b7b862d26559fa60b6d4b6658','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2338a2d39ba1f24f7e6cd060a49763b3945910b319df1da60df629060a3442fa',2025,'AW','Aruba','energy',130,'Electricity—production: 880 million kWh (2009
est.)
country comparison to the world: 150
Electricity—consumption: 818.4 million kWh
(2009 est.)
country comparison to the world: 154
Electricity—exports: 0 kWh (2010 est.)
country comparison to the world: 152
Electricity—imports: 0 kWh (2010 est.)
country comparison to the world: 152
Electricity—installed generating capacity:
266,000 kW (2009 est.)
country comparison to the world: 151
Electricity—from fossil fuels: 88.7% of total
installed capacity (2009 est.)
country comparison to the world: 78
Electricity—from nuclear fuels: 0% of total
installed capacity (2009 est.)
country comparison to the world: 33
Electricity—from hydroeteciric plants: 0% of
total installed capacity (2009 est.)
country comparison to the world: 152
Electricity—from other renewable sources: 3%
of total installed capacity (2009 est.)
country comparison to the world: 22
Crude oli—production: 0 bbl/day (2011 est.)
country comparison to the world: 104
Crude oil—exports: 0 bbl/day (2009 est.)
country comparison to the world: 72
tourism, transshipment facilities,
Crude oll—Iimports: 0 bbl/day (2009 est.)
country comparison to the world: 30
Crude oil—proved reserves: 0 bbl (1 January
2012 es)
country comparison to the world: 102
Refined petroleum products—production:
205,400 bbl/day (2008 est.)
country comparison to the world: 55
Refined petroleum products—consumption:
5,661 bbl/day (2011 est.)
country comparison to the world: 164
Refined petroleum products—exports: 205,400
bbl/day (2008 est.) :
country comparison to the world: 32
Refined petroleum products—imports: 6,646
bbl/day (2008 est.)
country comparison to the world: 144
Natura! gas—production: 1 cu m (2010 est.)
country comparison to the world: 95
Natural gas—consumption: 1 cu m (2010 est.)
country comparison to the world: 114
Natural gas—exports: 1 cu m (2010 est.)
country comparison to the world: 51
Natural gas—imports: 1 cu m (2010 est.)
country comparison to the world: 78
Natural gas—proved reserves: 0 cu m
(1 January 2012 es)
country comparison to the world: 105
Carbon dioxide emissions from consumption
of energy: 1.241 million Mr (2010 est.)
country comparison to the world: 162','8b1729aa7e4f37a29de97a3e6ea46bb8e361a4142c56aead70966c47d3f68659','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a1e3c3eb686fef4690107d82cadd2a379e86b0445a08120cf02fa448fdaeff16',2025,'AU','Australia','energy',141,'Elecirictty—production: 241.5 billion kWh
BOND eat.)
cuentry comparison to the world: 19
Electrichy—consumption: 226.8 billion kWh
2099 est )
country comparison to the world: 18
Electricity—exporte: 0 kWh (2010 est.)
country comparison tu the world: 158
Etectricthy—imports: 0 kWh (2010 est.)
country comparison to the world: 157
Electrichy—instalied generating capacity:
5094 milien kW (2009 est.)
cummniry comparison to the world: 16
Electricity—trom fossil fuels: 79% of rotal
nustutled capacity (2009 ext.)
comntry comparison tw the world: 95
Eluctrictty—trom muciear fuels: 0% of coral
umtalled capacity (2009 eat.)
oumemtry comparison to the world: 42
Electricity—trom hydroelectric plants: 13.7%
uf autal mstalled capacity (2009 est.)
cenenery comparison to the world: 108
Blectricity—trom other renewoble sources:
4.7%. uf total matalled''capactry (2009 est.)
ceuntry comparison to the world: 41
Crude oli—production: 482,500 bbi/day (2011
emt)
cumntry comparison to the world: 32
Crude oli—exports: 250,000 bhi/day (2009
eat}
comumery. comparison to the world: 29
43
Crude oil—imports: 380,900 bbl/day (2009
est.)
country comparison to the world: 23
Crude oil—proved reserves: 1.426 billion bbl
(1 January 2012 es)
country comparison to the world: 38
Refined petroleum products—production:
674,700 bbi/day (2009 est.)
country comparison to the world: 27
Refined petroleum products—consumption:
1.023 million bbl/day (2011 est.)
country comparison to the world: 21
Refined petroleum products—exporis: 64,730
bbl/day (2009 est.)
country comparison to the world: 53
Refined petroleum § products—imports:
332,900 bbl/day (2009 est.)
country comparison to the world: 20
Natural gas—production: 44.99 billion cu m
(2011 est.)
country comparison to the world: 23
Natural gas—consumption: 27.56 billion cu m
(2011 est.) s
country comparison to the world: 31
Natural gas—exports: 25.53 billion cu m (2011
est.)
country comparison to the world: 14
Natural gas—imports: 8.102 billion cu m (2011
est.) i
country comparison to the world: 30
Naturai gas—proved reserves: 788.6 billion
cu m (1 January 2012 ¢s)
country comparišon to the world: 29
Carbon dioxide emissions from consumption of
energy: 405.3 million Mt (2010 est.)
country comparison to the world: 17','d3f70d30b85bdf323bf745cc68085898e180f111f970bb8ddd58d925cd364aaf','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ba42fb678eb1ea4d003f76f924f2f1a971652dca4a932277691e1f506ec1b492',2025,'AZ','Azerbaijan','energy',160,'Electricity—production: 20 billion kWh (2011
est.)
country comparison to the world: 74
Electricity—consumption: 13.48 billion kWh
(2009 est.)
country comparison to the world: 80
Electricity—exports: 380 million kWh (2009
est.)
country comparison to the world; 64
Electricity—imports: 110 million kWh (2009
est.) `
country comparison to the world: 93
Electricity—installed generating capacity:
5.798 million kW (2009 est.)
country comparison to the world: 72
Electricity—from fossil fuels: 82.3% of total
installed capacity (2009 est.)
country comparison to the world: 91
Electriciy—from nuclear fuels: 0% of total
installed capacity (2009 est.)
country comparison to the world: 38
Electricity—from hydroelectric plants: 17.7%
of total installed capacity (2009 est.)
country comparison to the world: 98
Electricity—from other renewable sources: 0%
of total installed capacity (2009 est.)
country comparison to the world: 103
Crude oil—production: 987,000 bbl/day (2011
est.)
country comparison to the world: 21
Crude oil—exports: 821,000 bbl/day (2011 est.)
51
country comparison to the world: 16
Crude oll—imports: 0 bbl/day (2009 est.)
country comparison to the world: 150
Crude oil—proved reserves: 7 billion bbl
(1 January 2012 es)
country comparison to the world: 21
Refined petroleum products—production:
161,100 bbl/day (2008 est.)
country comparison to the world: 63
Refined petroleum products—consumption:
168,000 bbl/day (2011 est.)
country comparison to the world: 64
Refined petroleum products—exports: 63,950
bbl/day (2008 est.)
country comparison to the world: 54
Refined petroleum products—imports: 1,426
bbl/day (2008 est.)
country comparison to the world: 188
Natural gas—production: 16.68 billion cu m
(2010 est.)
country comparison to the world: 37
Natural gas—consumption: 9.921 billion cu m
(2010 est.)
country comparison to the world: 48
Natural gas—exports: 6.755 billion cu m (2010 est.)
country comparison to the world: 28
Natural gas—imports: 0 cu m (2010 est.)
country comparison to the world: 152
Natural gas—proved reserves: 849.5 billion
cu m (1 January 2012 es)
country comparison to the world: 27
Carbon dioxide emissions from consumption
Of energy: 35.12 million Mt (2010 est.)
country comparison to the world: 73
Electricity—production: 1.93 billion kWh (2010
est.)
country comparison to the world: 135
Electricity—consumption: 1.79 billion kWh
(2010 est.)
country comparison to the world: 142
Electricity—exports: 0 kWh (2012 est.)
country comparison to the world: 163
Electricity—imports: 0 kWh (2012 est.)
country comparison to the world: 160
Electricity—installed generating capacity:
490,00 kW (2010 est.)
country comparison to the world: 138
Electricity—from fossil fuels: 100% of total
installed capacity (2012 est.)
country comparison to the world: 7
Electricity—trom nuciear fuels: 0% of toral
installed capacity (2012 est.)
country comparison to the world: 48
Electricity—from hydroelectric plants: 0% of
total installed capacity (2012 est.)
country comparison to the world: 160
Electricity—from other renewable sources: 0%
of total installed capacity (2012 est.)
country comparison to the world: 110
Crude oli—production: 0 bbl/day (2011 est.)
country comparison to the world: 111
Crude oll—exports: 0 bbi/day (2009 est.)
country comparison to the world: 82
Crude oil—imports: 0 bbl/day (2009 est.)
country comparison to the world: 159
Crude oil—proved reserves: 0 bbl (1 January
2012 es)
country comparison to the world: 109
Refined petroleum products—production: 0
bbl/day (2008 est.)
country comparison to the world: 125
Refined petroleum products—consumption:
36,300 bbl/day (2011 est.)
BAHAMAS, THE
country comparison to the world: 113
Refined petroleum products—exports: 41,610
bbl/day (2010 est.)
country comparison to the world: 64
Refined petroleum products—imports: 64,600
bbi/day (2008 est.)
country comparison to the world: 60
Notural gas—production: 0 cu m (2010 est.)
country comparison to the world: 102
Notural gas—consumption: 0 cu m (2010 est.)
country comparison to the world: 119
Natural gas—exports: 0 cu m (2010 est.)
country comparison to the world: 62
Natural gas—imports: 0 cu m (2010 est.)
country comparison to the world: 160
Natural gas—proved reserves: 0 cu m (1 Janu-
ary 2009 es)
country comparison to the world: 112
Carbon dioxide emissions trom consumption
of energy: 5.573 million Mt (2010 est.)
country comparison to the world: 120','7f8ebb25e5a49155cb4422306a9b1b1f56875e052059c1584d9ae2bc877fe357','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5c2d541fdfe39ae7c752cad8c61a773959c45eb23d3dcded2921612e872fb1c9',2025,'BH','Bahrain','energy',171,'Electricity—production: 13.16 billion kWh
(2011 est.)
country comparison to the world: 87
Electricity—consumption: 12.97 billion kWh
(2011 est.)
country comparison to the world: 81
Electricity—exports: 0 kWh (2011 est.)
country comparison to the world: 159
Electricity—imports: 214 million kWh (2011 est.)
country comparison to the world: 87
Electricity—installed generating capacity:
3.168 million kW (2009 est.)
country comparison to the world: 86
Electricity—from fossil fuels: 100% of total
installed capacity (2011 est.)
country comparison to the world: 4
Electricity—from nuclear fuels: 0% of total
installed capacity (2011 est.)
country comparison to the world: 44
Electricity—from hydroelectric plants: 0% of
total installed capacity (2011 est.)
country comparison to the world: 156
Electricity—from other renewable sources: 0%
of total installed capacity (2011 est.)
country comparison to the world: 107
Crude oil—production: 44,800 bbl/day (2012
est.)
country comparison to the world: 63
Crude oll—exports: 152,600 bbl/day (2012 est.)
country comparison to the world: 35
Crude oil—imports: 256,000 bbl/day (2011 est.)
country comparison to the world: 29
Crude oll—proved reserves: 107.2 million bbl
(1 January 2013 es)
country comparison to the world: 71
Refined petroleum products—production:
270,800 bbl/day (2012 est.)
country comparison to the world: 48
Refined petroleum products—consumption:
51,450 bbl/day (2012 est.)
country comparison to the world: 98
Refined petroleum products—exports: 226,000
bbl/day (2012 est.)
country comparison to the world: 29
Refined petroleum products—Imports: 0 bbl/
day (2012 est.)
country comparison. to the world: 209
Natural gas—production: 12.58 billion cu m
(2010 est.)
country comparison to the world: 38
Natural gas—consumption: 12.25 billion cu m
(2010 est.)
country comparison to the world: 44
Natural gas—exports: 0 cu m (2010 est.)
country comparison to the world: 58
Natural gas—imports: 0 cu m (2010 est.)
country comparison to the world: 156
Natural gas—proved reserves: 92.03 billion
cu m (1 January 2012 es)
country comparison to the world: 58
Carbon dioxide emissions trom consumption
of energy: 30.69 million Mt (2010 est.)
country comparison to the world: 77','0c63f129c07463d9015436637547e0ae44472750d4ee57056a2638d33a7833d8','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4cabaf3b45c4c1e60182360e568415e2d9cafe62d55cd6f7d4324fa2c61d394c',2025,'BD','Bangladesh','energy',179,'Electricity—production: 35.7 billion kWh
(2009 est.)
country comparison to the world: 63
Electricity—consumption: 34.83 billion kWh
(2009 est.)
country comparison to the world: 58
Electricity—exports: 0 kWh (2010 est.)
country comparison to the world: 164
Electricity—imports: 0 kWh (2010 est.)
country comparison to the world: 161
Electricity—installed generating capacity:
5.819 million kW(2009 est.)
country comparison to the world: 71
Electricity—from fossil fuels: 95.8% of total
installed capacity (2009 est.)
country comparison to the world: 67
Electricity—trom nuclear fuels: 0% of total
installed capacity (2009 est.)
country comparison to the world: 49
61
Electricity—from hydroelectric plants: 4% of
total installed capacity (2009 est.)
country comparison to the world: 127
Electricity—from other renewable sources:
0.3% of total installed capacity (2009 est.)
country comparison to the world: 84
Crude oil—production: 5,200 bbl/day (2011 est.)
country comparison to the world: 90
Crude oil—exports: 0 bbl/day (2009 est.)
country comparison to the world: 83
Crude oil—imports: 26,460 bbl/day (2009 est.)
country comparison to the world: 66
Crude oil—proved reserves: 28 million bbl
(1 January 2012 es)
country comparison to the world: 85
Refined petroleum products—production:
24,790 bbl/day (2008 est.)
country comparison to the world: 94
Refined petroleum products—consumption:
108,900 bbl/day (2011 est.)
country comparison to the world: 75
Refined petroleum products—exports: 2,928
bbl/day (2010 est.)
country comparison to the world: 102
Refined petroleum products—mports: 77,340
bbl/day (2008 est.)
country comparison to the world: 54
Natural gas—production: 20.13 billion cu m
(2010 est.)
country comparison to the world: 34
. Natural gas—consumption: 20.13 billion cu m
(2010 est.)
country comparison to the world: 37
Natural gas—exports: 0 cu m (2010 est.)
country comparison to the world: 63 ,
Natural gas—imports: 0 cu m (2010 est.).
country comparison to the world: 161
Natural gas—proved reserves: 183.7 billion
cu m (1 January 2012 es)
country comparison to the world: 47
Carbon dioxide emissions from consumption
of energy: 56.74 million Mt (2010 est.)
country comparison to the world: 57','d5b7da7d080ab3f08ae5ad4e11d9ba869d31a5677e9605b07ad891ecdc5c326a','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('320d718e148a91585fdee397b9e2156bb9cc99e950b4066e85f0ea8ad2bd7195',2025,'BB','Barbados','energy',190,'Electricity—production: 1.037 billion kWh
(2010 est.)
country comparison to the world: 145
Electricity—consumption: 955 million kWh
(2009 est.) .
country comparison to the world: 152
Electricity—exports: 0 kWh (2010.est.)
country comparison to the world: 160
Electricity—imports: O kWh (2010 est.)
country comparison to the world: 158
Electricity—installed generating capacity:
239,100 kW (2009 est.)
country comparison to the world: 154
Electricity—from fossil fuels: 100% of total
installed capacity (2009 est.)
country comparison to the world: 5
Electricity—from nuclear fuels: 0% of total
installed capacity (2009 est.)
country comparison to the world: 45
Electricity—from hydroelectric plants: 0% of
total installed capacity (2009 est.)
country comparison to the world: 157
Electricity—from other renewable sources: 0%
of total installed capacity (2009 est.)
country comparison. to the world: 108
Crude oil—production: 1,000 bbl/day (2011
est.)
country comparison to the world: 97
Crude oli—exports: 0 bbl/day (2009 est.)
country comparison to the world: 78
Crude oil—imports: 0 bbl/day (2009 est.)
country comparison to the world: 156
Crude oil—proved reserves: 2.26 million bbl
(1 January 2012 es)
country comparison to the world: 99
Refined petroleum products—production:
O bbl/day (2008 est.)
country comparison to the world: 122
Refined petroleum products—consumption:
8,339 bbl/day (2011 est.)
country comparison to the world: 158
Refined petroleum products—exports: 0 bb!/
day (2008 est.)
country comparison to the world: 151
Refined petroleum products—imports: 7,686
bbli/day (2008 est.)
country comparison to the world: 138
Natural gas—production: 7 million cu m (2010
est.)
country comparison to the world: 88
Natural gas—consumption: 7 million cu m
(2010 est.)
country comparison to the world: 112
Natural gas—exports: 0 cu m (2010 est.)
country comparison to the world: 59
Natural gas—imports: 0 cu m (2010 est.)
country comparison to the world: 157
Natural gas—proved reserves: 113.3 million
cu m (1 January 2012 es)
country comparison to the world: 103
Carbon dioxide emissions from consumption
of energy: 1.57 million Mt (2010 est.)
country comparison to the world: 153','20746e514c30ab4900b0e32a76f14ba5324e803dc4842603b4cec6ff093fc8de','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2d03d244f32b0531933159c0eb5900e824bee78047c9f2511e503fe5730c3b95',2025,'BY','Belarus','energy',200,'Electricity—production: 28.55 billion kWh
(2009 est.)
country comparison to the world: 66
Electricity—consumption: 29.54 billion kWh
(2009 est.)
country comparison to the world: 62
Electricity—exports: 3.933 billion kWh (2009
est.)
country comparison to the world: 32
Electricity—imports: 8404 billion kWh (2009 est)
country comparison to the world: 28
Electricity—installed generating capacity:
8.032 million kW (2009 est.) i
country comparison to the world: 63
Electricity—from fossil fuels: 99.7% of total
installed capacity (2009 est.)
country comparison to the world: 50
Electricity—from nuclear fuels: 0% of total
installed capacity (2009 est.)
country comparison to the world: 55
Electricity—from hydroelectric plants: 0.2% of
total installed capacity (2009 est.)
country comparison to the world: 148
Electricity—from other renewable sources:
0.1% of total installed capacity (2009 est.)
country comparison to the world: 96
Crude oil—production: 30,000 bbi/day (2011
est.)
country comparison to the world: 67
Crude oll—exports: 34,320 bbl/day (2009 est.)
country comparison to the world: 50
Crude olli—imports: 431,300 bbl/day (2009 est.)
country comparison to the world: 19
Crude olli—proved reserves: 198 million bbl
(1 January 2012 es)
country comparison to the world: 63
Refined petroleum products—productidn:
427,800 bbl/day (2008 est.)
country comparison to the world: 36
Refined petroleum products—consumption:
188,800 bbl/day (2011 est.)
country comparison to the world: 60
Refined petroleum products—exports: 302,000
bbl/day (2008 est.)
country comparison to the world: 24
Refined petroleum products—imports: 39,660
bbl/day (2008 est.)
country comparison to the world: 76
Natural gos—production: 220 million cu m
(2010 est.)
country comparison to the world: 77
Natural gas—consumption: 21.82 billion cu m
(2010 est.)
country comparison to the world: 35
Natural gas—exports: 0 cu m (2010 est.)
country comparison to the world: 67
Natural gas—imports: 21.6 billion cu m (2010
est.)
country comparison to the world: 17
Natural gas—proved reserves: 2.832 billion
cu m (1 January 2012 es)
country comparison to the world: 96
Carbon dioxide emissions from consumption
of energy: 68.24 million Mc (2010 est.)
country comparison to the world: 50','62eb44ba56605e89908168bba163d956bdaf26075af01fe4ded53a6e91b12154','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bebf6e1fc13ea0015efeaeb43bf4f0e37b38224443a1be4a4ef01d8c81dd5223',2025,'BE','Belgium','energy',210,'Electricity—production: 89.25 billion kWh
(2010 est.) :
country comparison to the world: 37
Electricity—consumption: 78.53 billion kWh
(2009 est.)
country comparison to the world: 36
Electricity—exports: 84 billion kWh (2010 est.)
country comparison to the world: 17
Electricity—imports: 12.41 billion kWh (2010
est.)
country comparison to the world: 15
Electricity—installed generating capacity:
17.5 million kW (2009 est.)
country comparison to the world: 41
Electricity—from fossil fuels: 46.4% of total
installed capacity (2009 est.)
country comparison to the world: 164
Electricity—from nuclear fuels: 33.7% of total
installed capacity (2009 est.)
country comparison to the world: 2
Electricity—from hydroelectric plants: 0.6% of
total installed capacity (2009 est.)
country comparison to the world: 143
Electricity—from other renewable sources: 7%
of total installed capacity (2009 est.)
country comparison to the world: 21
Crude oil—production: 0 bbl/day (2011 est.)
country comparison to the world: 110
Crude oll—exports: 0 bbi/day (2009 est.)
country comparison to the world: 81
Crude oil—imports: 624,500 bbl/day (2009 est.)
country comparison to the world: 17
Crude oil—proved reserves: 0 bbl (1 January
2012 es)
country comparison to the world: 108
Refined petroleum products—production:
693,500 bbl/day (2009 est.)
country comparison to the world: 26
Refined petroleum products—consumption:
644,400 bbl/day (2011 est.)
country comparison to the world: 29
Refined petroleum products—exports: 353,000
bbl/day (2009 est.)
country comparison to the world: 23
Refined petroleum products—imports: 370,800
bbl/day (2009 est.)
country comparison to the world: 18
Natural gas—production: 0 cu m (2010 est.)
country comparison to the world: 101
Natural gas—consumption: 13.46 billion cu m
(2011 est.)
country comparison to the world: 42
Natural gas—exports: 2.511 billion cu m (2011 est.)
country comparison to the world: 38
Natural gas—imports: 15.94 billion cu m (2011
est.)
country comparison to the world: 19
Natural gas—proved reserves: 0 cu m (1 Janu-
ary 2012 es)
country comparison to the world: 111
Carbon dioxide emissions from consumption
of energy: 127.2 million Mt (2010 est.)
country comparison to the world: 35
Electricity—production: 52.03 million kWh
(2011 est.)
cournitry comparison to the world: 205
Electricity—consumption: 630 million kWh
(2011 est.)
country comparison to the world: 165
Electricity—exports: 0 kWh (2010 est.)
country comparison to the world: 165
Electricity—imports: 0 kWh (2010 est.)
country comparison to the world: 162
Electricity—installed generating capacity:
102,100 kW (2009 est.)
country comparison to the world: 168
Electricity—from fossil fuels: 33.3% of total
installed capacity (2009 est.)
country comparison to the world: 176
Electricity—from nuclear fuels: 0% of total
installed capacity (2009 est.)
country comparison to the world: 50
Electricity—from hydroelectric plants: 37.2%
of total installed capacity (2009 est.)
country comparison to the world: 59
Electricity—from other renewable sources:
29.5% of total installed capacity (2009 est.)
country comparison to the world: 2
Crude oil—production: 4,000 bbi/day (2011
est.)
country comparison to the world: 91
Crude oil—exports: 0 bbl/day (2009 est.)
country comparison to the world: 84
Crude oil—imports: 0 bbi/day (2009 est.)
country comparison to the world: 160
Crude oil—proved reserves: 6.7 million bbl
(1 January 2012 es)
country comparison to the world: 96
Refined petroleum products—production:
0 bbl/day (2008 est.)
country comparison to the world: 126
Refined petroleum products—consumption:
7,044 bbl/day (2011 est.)
country comparison to the world: 162
Refined petroleum products—exports: 0 bbi/
day (2008 est.)
country comparison to the world: 154
Refined petroleum products—imports; 3,553
bbl/day (2008 est.)
country comparison to the world: 165
Natural gas—production: 0 cu m (2010 est.)
country comparison to the world: 103
Natural gas—consumption: 0 cu m (2010 est.)
country comparison to the world: 120
Natural gas—exports: 0 cu m (2010 est.)
country comparison to the world: 64
Natural gas—imports: 0 cu m (2010 est.)
country comparison to the world: 162
Natural gas—proved reserves: 0 cu m (1 Janu-
ary 2012 es)
country comparison to the world: 113
Carbon dioxide emissions from consumption
of energy: Mt (2010 est.)
country comparison to the world: 166','d361f0ababe878b5e9f1d4fe7dbba8f0172d857a7f54c81fff2ccff6eaeebcf9','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('eebfd577fb877067fb47a7088ed578e4d6eec8b25cee278c808463a6ca17272b',2025,'BJ','Benin','energy',223,'Electricity—production: 120 million kWh (2009
est.)
country comparison to the world: 193
Electricity—consumption: 778 million kWh
(2009 est.)
country comparison to the world: 156
Electricity—exports: 0 kWh (2010 est.)
country comparison. to the world: 168
Electricity—imports: 866 million kWh (2009
est.)
country comparison to the world: 68
Electricity—installed generating capacity:
60,000 kW (2009 est.)
country comparison to the world: 177
Electricity—from fossil fuels: 98.3% of total
installed capacity (2009 est.)
country comparison to the world: 60
Electricity—from nuclear fuels: 0% of total
installed capacity (2009 est.)
country comparison to the world: 54
Electricity—from hydroelectric plants: 1.7% of
total installed capacity (2009 est)
country comparison to the world: 139
Electricity—from other renewable sources: 0%
of total Installed capacity (2009 est.)
country comparison to the world: 113
Crude oil—production: 0 bbl/day (2011 est.)
country comparison to the world: 113
foodstuffs, capital
80
THE CIA WORLD FACTBOOK
Crude oil—exports: 0 bbl/day (2009 est.)
country comparison to the world: 87
Crude oil—imports: 0 bbl/day (2009 est.)
country comparison to the world: 162
Crude oll—proved reserves: 8 million bbl
(1 January 2012 es)
country comparison to the world: 95
Refined petroleum products—production: 0
bbl/day (2008 est.)
country comparison to the world: 127
Refined petroleum products—consumption:
29,170 bbl/day (2011 est.)
country comparison to the world: 118
Refined petroleum products—exports: 410 bb!/
day {2008 est.)
country comparison to the world: 85
Refined petroleum products—imports: 35,140
bbl/day (2008 est.)
country comparison to the world: 80
Natural gas—production: 0 cu m (2010 est.)
country comparison to the world: 105
Natural gas—consumption: 0 cu m (2010 est.)
country comparison to the world: 121
Natural gas—exports: 0 cu m (2010 est.)
country comparison to the world: 66
Natural gas—imports; 0 cu m (2010 est.)
country comparison to the world: 165
Natural gas—proved reserves: 1.133 billion
cu m (1 January 2012 es)
country comparison to the world: 99
Carbon dioxide emissions from consumption
of energy: 3.65 million Mt (2010 est.)
country comparison to the world: 133','5e7d6ac221b48d7805a54110ae97e2ad356136638f588a1e053bb26dc030c5ce','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e72078fc7d975f8fe3ae319ef98ac7ba2f724df80863b78647cc78df26ccd3f4',2025,'BM','Bermuda','energy',233,'Electricity—production: 716.8 million kWh
(2011 est.)
country comparison to the world: 156
Electricity—consumption: 636.5 million kWh
(2011 est.)
country comparison to the world: 163
Electricity—exports: 0 kWh (2011 est.)
country comparison to the world: 162
Electricity—imports: 0 kWh (2011 est.)
country comparison to the world: 159
Electricity—installed generating capacity:
165,000 kW (2011 est.)
country comparison to the world: 157
Electricity—from fossil fuels: 98.2% of total
installed capacity (2012 est.)
country comparison to the world: 61
Electricity—from nuclear fuels: 0% of total
installed capacity (2012 est.)
country comparison to the world: 47
Electricity—from hydroelectric plants: 0% of
total installed capacity (2012 est.)
country comparison ta the world: 159
Electricity—from other renewable sources:
1.8% of total installed capacity
country comparison to the world: 61
note: the Tynes Bay Waste Treatment Facility
turns waste to electric energy (2012 est.)
Crude oll—production: 0 bbl/day (2011 est.)
country comparison to the world: 109
Crude oll—exports: 0 bbl/day (2009 est.)
country comparison to the world: 80
Crude oll—imports: 0 bbi/day (2009 est.)
country comparison to the world: 158
Crude oll—proved reserves: 0 bbl (1 January 2012 es)
country comparison to the world: 107
Refined petroleum products—production:
0 bbl/day (2012 est.)
country comparison to the world: 124
reexports of
Refined petroleum products—consumption:
2,747 bbl/day (2012 est.)
country comparison to the world: 186
Refined petroleum products—exports: © bbl/
day (2012 est.)
country comparison to the world: 153 °
Refined petroleum products—imports: 2,747
bbl/day (2012 est.)
country comparison to the world: 171
Natural gas—production: 0 cu m (2012 est.)
country comparison to the world: 100
Natural gas—consumption: 0 cu m (2012 est.)
country comparison to the world: 118
Natural gas—exports: 0 cu m (2012 est.)
country comparison to the world: 61
Natural gas—imports: 0 cu m (2012 est.)
country comparison to the world: 159
Natural gas—proved reserves: 0 cu m (1 Janu-
ary 2012 es)
country comparison to the world: 110
Carbon dioxide emissions from consumption
of energy: Mt (2010 est.)
couniiy compaiison io the woild: 1/1','61793664cf319604b5dcecb6bee48354e28f04c777baf11854b29acaa84e28d1','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0471b43205d5f8fc40fb51086941dd191ae01f1ecf7b463c53ddec75140d0d34',2025,'BT','Bhutan','energy',245,'Electricity—production: 6.826 billion kWh
(2009 est.)
country comparison to the world: 105
Electricity—consumption: 1.161 billion kWh
(2009 est.) 5
country comparison to the world: 150
Electricity—exports: 5.5 billion kWh (2009 est.)
country comparison to the world: 28
Electricity—imports: 20 million kWh (2009 est.)
country comparison to the world: 105
Electricity—installed generating capacity:
1.505 million kW (2009 est.)
country comparison to the world: 112
Electricity—from fossil fuels: 1.1% of total
installed capacity (2009 est.)
country comparison to the world: 205
Electricity—from nuclear fuels: 0% of total
installed capacity (2009 est.)
country comparison to the world: 57
Electricity—from hydroelectric plants: 98.9%
of total installed capacity (2009 est.)
country comparison to the world: 5
Electricity—from other renewable sources: 0%
of total installed capacity (2009 est.)
country comparison to the world: 115
Crude oil—production: 0 bbl/day (2011 est.)
country comparison to the world; 115
Crude oll—exports: 0 bbl/day (2009 est.)
country comparison to the world: 89
Crude oil—imports: 0 bb!/day (2009 est.)
country comparison to the world; 164
Crude oil—proved reserves: 0 bbl (1 January 2012 es)
86
THE CIA WORLD FACTBOOK
country comparison to the world: 112
Refined petroleum products—production: 0
bbl/day (2008 est.)
country comparison to the world: 129
Refined petroleum products—consumption:
1,719 bbl/day (2011 est.)
country comparison to the world: 194
hitps://www.cia.gov/library/publications/
the-world-factboolkgeos/bt.html
Refined petroleum products—exports: 0. bbl/
day (2008 est.)
country comparison to the world: 158
Refined petroleum products—imports: 1,590
bbi/day (2008 est.)
country comparison to the world: 185
Natural gas—production: 0 cu m (2010 est.)
country comparison to the world: 107
Natural gas—consumption: 0 cu m (2010 est.)
country comparison to the world: 123
Natural gas—exports: 0 cu m (2010 est.)
country comparison to the world: 70
Natural gas—imports: 0 cu m (2010 est.)
country comparison to the world: 167
Natural gas—proved reserves: 0 cu m (1 Janu-
ary 2012 es)
country comparison to the world: 116
Carbon dioxide emissions from consumption
of energy: 276,300 Mt (2010 est.)
country comparison to the world: 192','4244665e7fa2fb7b16d6356541106dc229bb76e6be57e20407f3067bbf4940e1','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8a515a0c2b2eb15e57f362ee3997361a554ed8aca5cb708c9eaead2283dbeea9',2025,'BR','Brazil','energy',253,'Electricity—production: 6.94 billion kWh (2012
est.)
country comparison to the world: 104
Electricity—consumption: 6.301 billion kWh
(2011 est.)
country comparison to the world: 102
Electricity—exports: 0 kWh (2010 est.)
country comparison to the world: 166
Electricity—imports: 0 kWh (2010 est.)
country comparison to the world: 163
Electricity—installed generating capacity:
1.317 million kW (2012 est.)
country comparison to the world: 117
Electricity—from fossil fuels: 58.9% of total
installed capacity (2012 est.)
country comparison to the world: 140
89
Electricity—from nuclear fuels: 0% of total
installed capacity (2012 est.)
country comparison to the world: 52
Electricity—from hydroelectric plants: 39.3%
of total installed capacity (2012 est.)
country comparison to the world: 56
Electricity—from other -renewable sources:
1.7% of total installed capacity (2012 est.)
country comparison to the world: 64
Crude oil—production: 40,000 bbl/day (2012
est.)
country comparison to the world: 65
Crude oil—exports: 0 bbl/day (2009 est.)
country comparison to the world: 86
Crude oil—imports: 0.07 bbl/day (2009 est.)
country comparison to the world: 86
Crude oil—proved reserves: 209.8 million bbl
(1 January 2012 es)
country comparison to the world: 60
Refined petroleum products—production:
314,700 bbl/day (2012 est.)
country comparison to the world: 43
Refined petroleum products—consumption:
45,840 bbl/day (2012 est.)
country comparison to the world: 102
Refined petroleum products—exports: 864.7
bbi/day (2012 est.)
country comparison to the world: 113
Refined petroleum products—imports:
14,150 bbl/day (2008 est.)
country comparison to the world: 123
Natura! gas—production: 48.97 billion cu m
(2012 est.)
country comparison to the world: 20
Natura! gas—consumption: 8.59 billion cu m
(2012 est.)
country comparison to the world: 54
Natural gas—exports: 40.28 billion cu m (2012
est.)
country comparison to the world: 11
Natural gas—imports: 0 cu m (2012 est.)
country comparison to the world; 163
Natural gas—proved reserves: 281.5 billion
cu m (1 January 2012 es)
country comparison to the world: 42
Carbon dioxide emissions from consumption
of energy: 13.29 million Mt (2010 est.)
country comparison to the world: 93','fe85a4054aad2152f5d24f764c04206a47b5cc8c8c0c1eff5bf8f657c80c8389','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('37cb4e6951f2e9a5bc4f7803b67ae898882dafe36f50bb2e9f35cc4ab4990f94',2025,'BW','Botswana','energy',273,'Electricity—production: 417 million kWh (2009
est.)
country comparison to the world: 165
Electricity—consumption: 3.118 billion kWh
(2011 est.)
country comparison to the world: 132
Electricity—exports: 0 kWh (2010 est.)
country comparison to the world: 161
Electricity—imports: 2.89 billion kWh (2009 est.)
country comparison to the world: 44
Electricity—installed generating capacity:
132,000 kW (2011 est.)
country comparison to the world: 164
Electricity—from fossil fuels: 100% of total
installed capacity (2009 est.)
country comparison to the world: 6
Electricity—from nuclear fuels: 0% of total
installed capacity (2009 est.) r
country comparison to the world: 46
Electricity—from hydroelectric plants: 0% of
total installed capacity (2009 est.)
country comparison to the world: 158
Electricity—from other renewable sources: 0%
of total installed capacity (2009 est.)
country comparison to the world: 109
Crude oil—production: 0 bbl/day (2011 est.)
country comparison to the world: 108
Crude oil—exports: 0 bbl/day (2009 est.)
country comparison to the world: 79
Crude oil—imports: 0 bbl/day (2009 est.)
country comparison to the world: 157
Crude oil—proved reserves: 0 bbl (1 January
2012 es)
country comparison to the world: 106
Refined petroleum products—production: 0
bbl/day (2008 est.)
country comparison to the world: 123
Refined petroleum products—consumption:
15,420 bbl/day (2011 est.)
copper,
country comparison to the world: 143
Refined petroleum products—exports: 0 bbl/
day (2008 est.)
country comparison to the world: 152
Refined petroleum products—imports: 19,060
bbl/day (2008 est.)
country comparison to the world: 106
Natural gas—production: 0 cu m (2010 est.)
country comparison to the world: 99
Natural gas—consumption: 0 cu m (2010 est.)
country comparison to the world: 117
Natural gas—exports: 0 cu m (2010 est.)
country comparison to the world: 60
Natural gas—imports: 0 cu m (2010 est.)
country comparison to the world: 158
Natural gas—proved reserves: 0 cu m (1 Janu-
ary 2012 es)
country comparison to the world: 109
Carbon dioxide emissions from consumption
of energy: 3.841 million Mt (2010 est.)
country comparison to the world: 131','9dc9a09dcca1d61185df00c056fa11c3df1fdcfe62587715cfeea44f706d1a5d','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ad0722a630292a7c4890fad5d8c02c54077ea720c4f3c1229cf4ae55118e41d8',2025,'ID','Indonesia','energy',297,'Electricity—production: 3.723 billion kWh
(2011 est.)
country comparison to the world: 126
Electricity—consumption: 3.391 billion kWh
(2011 est.)
country comparison to the world: 131
Electricity—exports: 0 kWh (2010 est.)
country comparison to the world: 170
Electricity—Imports:; 0 kWh (2010 est.)
country comparison to the world: 166
Electricity—installed generating capacity:
894,000 kW (2009 est.)
country comparison to the world: 125
Electricity—fromfossii fuels: 100% of total
installed capacity (2009 est.)
country comparison to the world: 9
Electricity—from nuclear fuels: 0% of total
installed capacity (2009 est.)
country comparison to the world: 58
Electricity—from hydroelectric plants: 0% of
total installed capacity (2009 est.)
country comparison to the world: 162
Electricity—from other renewable sources: 0%
of total installed capacity (2009 est.)
country comparison to the world: 116
Crude oil—production: 166,000 bbl/day (2011 est.)
country comparison to the world: 42
Crude oil—exports: 155,000 bbl/day (2011 est.)
country comparison to the world: 34
Crude oil—imports: 0 bbl/day (2011 est.)
country comparison to the world: 165
Crude oil—proved reserves: 1.1 billion bbl
(1 January 2012 es)
country comparison to the world: 41
Refined petroleum products—production:
14,720 bbi/day (2008 est.)
country comparison to the world: 102
Refined petroleum products—consumption:
14,640 bbl/day (2011 est.)
country comparison to the world: 145
Refined petroleum products—exports: 0 bbl/
day (2008 est.)
country comparison to the world: 159
Refined petroleum products—imports: 1,016
bbl/day (2008 est.)
country comparison to the world: 194
Natural gas—production: 11.8 billion cu m
(2010 est.)
country comparison to the world: 41
Natural gas—consumption: 2.97 billion cu m
(2010 est.)
country comparison to the world: 73
Natural gas—exports: 8.83 billion cu m (2010 est.)
country comparison to the world: 23
Natural gas—imports: 0 cu m (2010 est.)
country comparison to the world: 168
Natural gas—proved reserves: 390.8 billion
cu m (1 January 2012 es)
country comparison to the world: 35
Carbon dioxide emissions from consumption
of energy: 8.271 million Mr (2010 est.)
country comparison to the world: 107
Electricity—production: 183.4 billion kWh
(2011 est.)
country comparison to the world: 24
Electricity—consumption: 158 billion kWh
(2011 est.)
country comparison. to the world: 24
Electricity—exports: 0 kWh (2011 est.)
country comparison to the world: 209
Electricity—imports: 2.542 billion kWh (2011
est.)
country comparison to the world: 49
Electricity—installed generating capacity:
39.9 million kW (2011 est.)
country comparison to the world: 23
Electricity—from fossil fuels: 87% of total
installed capacity (2011 est.)
country comparison to the world: 83
Electricity—from nuclear fuels:% of total
installed capacity (2011 est.)
country comparison to the world: 109
Electricity—from hydroelectric plants: 9.9% of
totafinstalled capacity (2011 est.)
country comparison to the world: 116
Electricity—from other renewable sources:
3.1% of total installed capacity (2011 est.)
country comparison to the world: 47
Crude oil—production: 912,100 bbl/day (2011
est.)
country comparison to the world: 24
Crude oil—exports: 371,400 bbl/day (2011 est.)
country comparison to the world: 22
Crude oii—imports: 265,400 bbl/day (2011 est.)
country comparison to the world: 27
Crude oil—proved reserves: 4 billion bbl
(1 January 2013 est.)
country comparison to the world: 29
Refined petroleum products—production:
935,300 bbl/day (2011 est.)
country comparison to the world: 22
Refined petroleum products—consumption:
1.322 million bbl/day (2011 est.)
country comparison to the world: 19
Reiineu peiioleum pioducis—expoiis: 142,400
bbl/day (2008 est.)
country comparison to the world: 39
Refined petroleum products—imports: 407,700
bbl/day (2011 est.)
country comparison to the world: 14
Natural gas—production: 82.8 billion cu m
(2010 est.)
country comparison to the world: 12
Natural gas—consumption: 41.35 billion cu m
(2010 est.)
country comparison to the world: 26
Natural gas—exports: 41.25 billion cu m (2010
est.)
country comparison to the world: 10
Natural gas—imports: cu m (2010 est.)
country comparison to the world: 208
Natural gas—proved reserves: 3.994 trillion cum
(1 January 2012 est.)
country comparison to the world: 12
Carbon dioxide emissions from consumption of
energy: riillion Mt (2011 est.)
<
country comparison to the world: 18','1ba7f96026a386634ba2f8e7e40bcbc12cf599811540677e3d5ee5bb666b03ec','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('86c1bfd92933f4ba56b7e8dd1efb3603b8fe55b547204aec8f856164421b348e',2025,'BG','Bulgaria','energy',303,'Electricity—production: 41.9 billion kWh (2010
est.)
country comparison to the world: 56
Electricity—consumption: 28.1 billion kWh
(2010 est.)
country comparison to the world: 65
Electricity—exports: 12 billion kWh (2011 est.)
country comparison to the world: 16
Electricity—imports: 1.166 billion kWh (2010
est.)
country comparison to the world: 60
Electricity—installed generating capacity: 12
million kW (2010 est.) -
country comparison to the world: 51
Electiiciiy—tiom lossil luels: 46.4% of total
installed capacity (2009 est.)
_ country comparison to the world: 163
Electricity—from nuclear fuels: 20.3% of total
installed capacity (2009 est.)
country comparison to the world; 11
Electricity—from hydroelectric plants: 22.2%
of total installed capacity (2009 est.)
country comparison to the world: 85
Electricity—from other renewable sources:
1.9% of total installed capacity (2009 est.)
country comparison to the world: 59
Crude oil—production: 1,000 bbl/day (2011
est.)
country comparison to the world: 96
Crude oil—exports: 0 bbl/day (2012 est.)
country comparison to the world: 90
Crude oil—imports: 123,400 bbl/day (2009 est.)
country comparison to the world: 45
Crude oli—proved reserves: 15 million bbl
(1 January 2012 es)
country comparison to the world: 87
112
THE CIA WORLD FACTBOOK
Refined petroleum products—production:
120,000 bbl/day (2010 est.)
country comparison to the world: 69
Refined petroleum products—consumption:
112,700 bbl/day (2011 est.)
country comparison to the world: 74
Refined petroleum products—exports: 78,180
bbl/day (2008 est.)
country comparison to the world: 47
Refined petroleum products—imports: 29,940
bbl/day (2008 est.)
country comparison to the world: 88
Natural gas—production: 68,000 cu m (2010
est.)
country comparison to the world: 94
Natural gas—consumption: 2.17 billion cu m
(2010 est.)
country comparison to the world: 78
Natural gas—exports: 0 cu m (2010 est.)
country comparison to the world: 71
Natural gas—imports: 2.48 billion cu m (2010)
country comparison to the world: 47
Natural gas—proved reserves: 5.663 billion
cu m (1 January 2012 es)
country comparison to the world: 88
Carbon dioxide emissions from consumption
of energy: 42.17 million Mt (2010 est.)
~- country comparison to the world: 66','bf19e7d598a6faa9280d8f056994761eb209e690b06e6a47c966948693ee6f5f','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3e70aa8935135395a5062ff599f938796c84c5f4be1d7f2ee4b0275a4d54bd97',2025,'BF','Burkina Faso','energy',317,'Electricity—production: 664.4 million kWh
(2009 est.)
country comparison to the world: 157
Electricity—consumption: 762.5 million kWh
(2009 est.) :
country comparison to the world: 157
Electricity—exports: 0 kWh (2010 est.)-
country comparison to the world: 143
Electricity—imports: 144.6 million kWh (2009 est.)
country comparison to the world: 90
Electricity—instalied generating capacity:
252,000 kW (2009 est.)
country comparison to the world: 153
Electricity—from fossil fuels: 87.3% of total
installed capacity (2009 est.)
country comparison to the world: 82
Electricity—from nuclear fuels: 0% of total
installed capacity (2009 est.)
country comparison to the world: 194
Electricity—from hydroelectric plants: 12.7%
of total installed capacity (2009 est.)
country comparison to the world: 109
Electricity—from other renewable sources: 0%
of total installed capacity (2009 est.)
country comparison to the world: 197
Crude oll—production: 0 bbl/day (2011 est.)
country comparison to the world: 199
Crude oll—exports: 0 bbl/day (2009 est.)
country comparison to the world: 198
Crude oil—imports: 0 bbl/day (2009 est.)
country comparison to the world: 135
Crude oli—proved reserves: 0 bbl (1 January
2012 es) : ;
country comparison to the world: 198
Refined petroleum products—production: 0
bbl/day (2008 est.)
country comparison to the world: 204
Refined petroleum products—consumption:
9,960 bbl/day (2011 est.)
country comparison to the world: 155
Refined petroleum products—exports: 0 bbi/
day (2008 est.)
country comparison to the world: 140
Refined petroleum products—imports: 12,540
bbl/day (2008 est.)
country comparison to the world: 128
Natural gas—production: 0 cu m (2010 est.)
country comparison to the world: 202
Natural gas—consumption: 0 cu m (2010 est.)
country comparison to the world: 203
Natural gas—exports: 0 cu m (2010 est.)
country comparison to the world: 198
Natural gas—imports: 0 cu m (2010 est.)
country comparison to the world: 142
Natural gas—proved reserves: 0 cu m (1 Janu-
ary 2012 es)
country comparison to the world: 200
Carbon dioxide emissions from consumption
of energy: 1.441 million Mt (2010 est.)
country comparison to the world: 157
Electricity—production: 5.708 billion kWh
(2009 est.)
country comparison to the world: 114
Electricity—consumption: 3.794 billion kWh
(2009 est.)
country comparison to the world: 124
Electricity—exports: 0 kWh (2010 est.)
country comparison to the world: 167
Electricity—imports: 0 kWh (2010 est.)
country comparison to the world: 164
Electricity—instalied generating capacity:
1.86 million kW (2009 est.)
country comparison to the world: 104
Electricity—trom fossil fuels: 67.7% of total
installed capacity (2009 est.)
country comparison to the world: 114
Electricity—from nuclear fuels: 0% of total
installed capacity (2009 est.)
country comparison to the world: 53
Electricity—from hydroelectric plants; 32.3%
of total installed capacity (2009 est.)
country comparison to the world; 70
Electricity—from other renewable sources: 0%
of total installed capacity (2009 est.)
country comparison to the world: 112
Crude oil—production: 20,200 bbl/day (2011
est.)
country comparison to the world: 71
Crude oll—exports: 880 bbi/day (2009 est.)
country comparison to the world: 66
Crude ojl—imports: 0 bbl/day (2009 est.)
country comparison to the world: 161
Crude oil—proved reserves: 50 million bbl
(1 January 2012 es)
country comparison to the world: 80
Refined petroleum products—production:
16,700 bbl/day (2008 est.)
country comparison to the world: 100
Refined petroleum products—consumption:
40,620 bbl/day (2011 est.)
country comparison to the world: 108 À
Refined petroleum products—exports: 0 bbl/
day (2008 est.)
country comparison to the world: 156
Refined petroleum products—imports: 12,730
bbl/day (2008 est.)
country comparison to the world: 127
Natural gos—production: 12.1 billion cu m
(2010 est.)
country comparison to the world: 39
Natural gas—consumption: 3.29 billion cu m
(2010 est.)
country comparison to the world: 71
Natural gas—exports: 8.81 billion cu m` (2010
est.)
` country comparison to the world: 24
Natural gas—imports: 0 cu m (2010 est.)
country comparison to the world; 164
Natural gas—proved reserves: 283.2 billion
cum (1 January 2012 es)
country comparison to the world: 41
Carbon dioxide emissions from consumption
of energy: 12.8 million Mt (2010 est.)
country comparison to the world: 95','028f4133f9ebab3aecf2fbd8ec91ce7f6c2b36d719aafca88af4a7e14a8c097c','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('baee5b09ddf01792f3224032d7b2519d6dd5ebbf0cb19c01ca2067d3ecebe195',2025,'BI','Burundi','energy',327,'Electricity—production: 127 million kWh (2009
est.)
country comparison to the world: 190
Electricity—consumption: 198.1 million kWh
(2009 est.) -.
country comparison to the world: 185
Electricity—exports: 0 kWh (2010 est.)
country comparison to the world: 171
Electricity—imports: 80 million kWh (2009 est.)
country comparison to the world: 95
Electricity—installed generating capacity:
52,000 kW (2009 est.)
country comparison to the world: 182
Electricity—from fossil fuels: 1.9% of total
installed capacity (2009 est.)
country comparison to the world: 203
Electricity—from nuclear fuels: 0% of total
installed capacity (2009 est.)
country comparison to the world: 59
Electricity—from hydroelectric plants: 98.1%
of total installed capacity (2009 est.)
country comparison to the world: 7
Electricity—from other renewable sources: 0%
of total installed capacity (2009 est.)
country comparison to the world: 117
Crude oll—production: 0 bbl/day (2011 est.)
country comparison to the world: 116
Crude oil—exports: 0 bbl/day (2009 est.)
country comparison to the world: 91
Crude oil—imports: 0 bbl/day (2009 est.)
country comparison to the world: 166
Crude oil—proved reserves: 0 bb! (1 January
2012 es)
country comparison to the world: 113
Refined petroleum products—production:
0 bbl/day (2008 est.)
country comparison to the world: 130
Refined petroleum products—consumption:
2,290 bbl/day (2011 est.)
country comparison to the world: 188
Refined petroleum products—exports: 0 bbi/
day (2008 est.)
country comparison to the world; 160
Refined petroleum products—imports: 1,334
bbl/day (2008 est.)
country comparison to the world: 189
Natural gas—production: 0 cu m (2010 est.)
country comparison to the world: 108
Natural gas—consumption: 0 cu m (2010 est.)
country comparison to the world: 124
Natural gas—exports: 0 cu m (2010 est.)
country comparison to the world: 72
Natural gas—imports: 0 cu m (2010 est.)
country comparison to the world: 169
Natural gas—proved reserves: 0 cu m (1 Janu-
ary 2012 es)
country comparison to the world: 117
Carbon dioxide emissions from consumption
of energy: Mt (2010 est.)
country comparison to the world: 179','72e299aee725925c4b9140a7a2999f59667321a5bdaec07e9d5f151d548762db','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bdf1848b5e9312bf3abfea0fd3211fef2980ae6b5b573484af127eddebb390da',2025,'KH','Cambodia','energy',335,'Electricity—production: 1.019 billion kWh
(2011 est.)
country comparison to the world: 146
Electricity—consumption: 2.573 billion kWh
(2011 est.)
country comparison to the world: 136
Electricity—exports: 0 kWh (2010 est.)
country comparison to the world: 172
Electricity—imports: 1.83 billion kWh (2011
est.)
country comparison to the world: 53
Electricity—installed generating capacity:
390,900 kW (2009 est.)
country comparison to the world: 145
Electricity—from fossil fuels: 95.2% of total
installed capacity (2009 est.)
country comparison to the world: 68
Electricity—from nuclear fuels: 0% of total
installed capacity (2009 est.)
country comparison to the world: 60
Electricity—from hydroelectric plants: 3.3% of
total installed capacity (2009 est.)
country comparison to the world: 128
Electricity—from other renewable sources: 1.5%
of total installed capacity (2009 est.) s
country comparison to the world: 67
Crude oil—production: 0 bbl/day (2011 est.)
country comparison to the world: 117
Crude oll—exports: 0 bbi/day (2009 est.)
country comparison to the world: 92
Crude oil—imports: 0 bbl/day (2009 est.)
country comparison to the world: 167
Crude oll—proved reserves: 0 bbl (1 January
2012 est.)
country comparison to the world: 114
Refined petroleum products—production: 0
bbl/day (2008 est.)
country comparison to the world: 131
Refined petroleum products—consumption:
39,350 bbl/day (2011 est.)
country comparison to the world: 110
Refined petroleum products—exports: 0 bbl/
day (2008 est.)
country comparison to the world: 161
Refined petroleum products—imports: 34,340
bbl/day (2008 est.)
country comparison to the world: 82
Natural gas—production: 0 cu m (2010 est.)
country comparison to the world: 109
Natural gas—consumption: 0 cu m (2010 est.)
country comparison to the world: 125
127
Natural gas—exports: 0 cu m (2010 est.)
country comparison to the world; 73
Natural gas—imports: 0 cu m (2010 est.)
country comparison to the world: 170
Natural gas—proved reserves: 0 cu m
(1 January 2012 est.)
country comparison to the world: 118
Carbon dioxide emissions from consumption of
energy: 3.59 million Mt (2010 est.)
country comparison to the world: 134','ad936d17c30456131f1489c1a364560929079c30adac8a5218412eca893f53a1','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('85eb5fa5d3c3647e04b3ee362ddeeb7d5822bad55aa04464067f01c27b9bbda0',2025,'CA','Canada','energy',352,'Electricity—production: 580.6 billion kWh
(2010 est.)
country comparison to the world: 8
Electricity—consumption: 504.8 billion kWh
(2009 est.)
country comparison to the world: 9
Electricity—exports: 43.91 billion kWh (2010
est.)
country comparison to the world: 5
Electricity—imports: 18.79 billion kWh (2010
est.)
country comparison to the world: 9
Electricity—instatled generating capacity:
131.5 million kW (2009 est.)
country comparison to the world: 8
Electricity—from fossil fuels: 28.8% of total
installed capacity (2009 est.)
country comparison to the world: 181
Electricity—from nuclear fuels: 10.1% of total
installed capacity (2009 est.)
country comparison to the world: 20
Electricity—from hydroelectric plants: 57% of
total installed capacity (2009 est.)
country comparison to the world: 35
Electricity—from other renewable sources:
3.9% of total installed capacity (2009 est.)
country comparison to the world: 44
Crude oll—production: 3.592 million bbl/day
(2011 est.)
country comparison to the world: 7
Crude oll—exports: 1.355 million bbl/day (2009
est.)
country comparison to the world: 12
Crude oll—imports: 791,100 bbl/day (2009 est.)
country comparison to the world: 16
Crude oll—proved reserves: 173.6 billion bbl
(1 January 2012 est.)
country comparison to the world: 4
Refined petroleum products—production:
1.978 million bbl/day (2009 est.)
country comparison to the world: 11
Refined petroleum products—consumption:
2.259 million bbl/day (2011 est.)
country comparison to the world: 12
Refined petroleum products—exports: 437,300
bbl/day (2009 est.)
country comparison to the world: 19
Refined petroleum products—imports: 282,200
bbl/day (2009 est.)
country comparison to the world: 25
Natural gas—production: 160.1 billion cu m
(2011 est.)
country comparison to the world: 5
Natura! gas—consumption: 103.3 billion cu m
(2011 est.)
country comparison to the world: 8
Natural gas—exports: 92.72 billion cu m (2011
est.)
country comparison to the world: 6
Natural gas—imports: 30.49 billion cu m (2011
est.) n
country comparison to the world: 15
Natural gas—proved reserves: 1.727 trillion
cum (1 January 2012 est.)
country comparison to the world: 22
Carbon dioxide emissions from consumption
of energy: 548.8 million Mt (2010 est.)
country comparison to the world: 10','868189c216d46147ecbcbb8b7adc9c0584e1bb08ab790221b47601e3ec0d05e6','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d4edf672ed8745b5e65c2a37818cd938b47760113e1a575a2d8dbd070fc4c87a',2025,'KY','Cayman Islands','energy',364,'Electricity—production: 593.5 million kWh
(2010 est.)
country comparison to the world: 158
Electricity—consumption: 555.6 million kWh
(2009 est.)
country comparison to the world: 168
Electricity—exports: 0 kWh (2010 est.)
country comparison to the world: 178
Electricity—imports: 0 kWh (2010 est.)
country comparison to the world: 170
Efectricity—installed generating capacity:
152,600 kW (2009 est.)
country comparison to the world: 158
Electricity—from fossil fuels: 100% of total
installed capacity (2009 est.)
country comparison to the world: 11
Electricity—from nuclear fuels: 0% of total
installed capacity (2009 esr.)
country comparison to the world: 66
Electricity—from hydroelectric plants: 0% of
total installed capacity (2009 est.)
country comparison to the world: 164
Electricity—from other renewable sources: 0%
of total installed capacity (2009 est.)
country comparison to the world: 121
Crude oil—production: 0 bbl/day (2011 est.)
country comparison to the world: 119
Crude oll—exports: 0 bbl/day (2009 est.)
country comparison to the world: 95
Crude oil—imports: 0 bbl/day (2009 est.)
country comparison to the world: 171
Crude oil—proved reserves: 0 bbl (1 January
2012 est.)
country comparison to the world: 117
Refined petroleum products—production: 0
bbl/day (2008 est.)
country comparison to the world: 134
Refined petroleum products—consumption:
3,141 bbl/day (2011 est.)
country comparison to the world: 181
Refined petroleum products—exports: 0 bbl/
day (2008 est.)
country comparison to the world: 165
Refined petroleum products—imports: 4,491
bbl/day (2008 est.)
country comparison to the world: 162
Natural gas—production: 0 cu m (2010-est.)
country comparison to the world: 114
Natural gas—consumption: 0 cu m (2010 est.)
country comparison to the world: 130
Natural gas—exports: 0 cu m (2010 est.)
country comparison to the world: 79
Natural gas—imports: 0 cu m (2010 est.)
country comparison to the world: 176
Natural gas—proved reserves: 0 cu m
(1 January 2012 est.)
country comparison to the world: 122
Carbon dioxide emissions from consumption
of energy: 273,300 Mt (2010 est.)
country comparison to the world: 193','683fda24f50be6d273f3bdafed1262dc4ad630641f1d5ef33b2fe9639a34a5ba','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d173448a2d2f8e7045968e0e2547e86401ab0ca35b09490bbe4a4f9a79e1b37b',2025,'CF','Central African Republic','energy',374,'Electricity—production: 160 million kWh (2009
est.)
country comparison to the world: 186
Electricity—consumption: 148.8 million kWh
(2009 est.)
country comparison to the world: 191
Electricity—exports: 0 kWh (2010 est.)
country comparison to the world: 182
Electricity—imports: 0 kWh (2010 est.)
country comparison to the world: 174
Electricity—installed generating capacity:
46,000 kW (2009 est.)
country comparison to the world: 186
Electricity—from fossil fuels: 45.7% of total
installed capacity (2009 est.)
country comparison to the world: 165
Electricity—from nuclear fuels: 0% of total
installed capacity (2009 est.)
country comparison to the world: 71
Electricity—from hydroelectric plants: 54.3%
of total installed capacity (2009 est.)
country comparison to the world: 38
Electricity—from other renewable sources: 0%
of total installed capacity (2009 est.)
country comparison to the world: 124
Crude oll—production: 0 bbl/day (2011 est.)
country comparison to the world: 122
Crude oll—exports: 0 bbi/day (2009 est.)
country comparison to the world: 98
Crude oll—imports: 0 bbl/day (2009 est.)
country comparison to the world: 173
Crude oil—proved reserves: O bbl (1 January
2012 est.)
143
country comparison to the world: 120
Refined petroleum products—production: 0
bbl/day (2008 est.)
country comparison to the world: 136
Refined petroleum products—consumption:
3,175 bbl/day (2011 est.)
country comparison to the world: 180
Refined petroleum products—exports: 0 bbl/
day (2008 est.)
country comparison to the world: 167
Refined petroleum products—imports: 2,481
bbl/day (2008 est.) ’
country comparison to the world: 176
Natural gas—production: 0 cu m (2010 est.)
country comparison to the world: 117
Natural gas—consumption: 0 cu m (2010 est.)
country comparison to the world: 133
Natural gas—exports: 0 cu m (2010 est.)
country comparison to the world: 83
Natural gas—imports: 0 cu m (2010 est.)
country comparison to the world: 180
Natural gas—proved reserves: O cu m
(1 January 2012 est.)
country comparison to the world: 125
Carbon dioxide emissions from consumption
of energy: 227,400 Mt (2010 est.)
country comparison to the world: 195','eb73c77f7fd65dd461f8ed53404ce49c53d3cf3ddf9154e61ecda63350ac6f0c','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8ba91a3d34a50730851c0547c6474c0dc0c3ce1e52dd3dba9bd7964771b7949a',2025,'CN','China','energy',396,'Electricity—production: 4.94 trillion kWh
(2012)
country comparison to the world: 2
Electricity—consumption: 4.693 trillion kWh
(2011)
country comparison to the world: 2
Electricity—exports: 17.65 billion kWh (2012)
country comparison to the world: 10
Eleciricity—imports: 6.874 billion kWh (2012)
country comparison to the world: 33
Electricity—installed generating capacity:
1.146 billion kW (2012 est.)
country comparison to the world: 2
Electricity—from fossil fuels: 69.5% of total
installed capacity (2012 est.)*
country comparison to the world: 109
Electricity—from nuclear fuels: 1.1% of total
installed capacity (2012 est.)
country comparison to the world: 32
Electricity—from hydroelectric plants: 21.8%
of total installed capacity (2012 est.)
country comparison to the world: 87
Electricity—from other renewable sources:
7.6% of total installed capacity (2012 est.)
country comparison to the world: 26
Crude oil—production: 4.15 million bbl/day
(2012 est.)
country comparison to the world: 6
Crude oil—exports: 48,700 bbl/day (2012 est.)
country comparison to the world: 46
Crude oll—imports: 5.422 million bbl/day (2012
est.)
country comparison to the world: 3
Crude oil—proved reserves: 14.8 billion bbl
(1 January 2012 est.)
country comparison to the world: 17
Refined petroleum products—production:
8.992 million bbl/day (2011 est.)
country comparison to the world: 4
Refined petroleum products—consumption:
9.79 million bbl/day (2011 est.)
country comparison to the world: 4
Refined petroleum products—exports: 623,000
bbl/day (2011 est.)
country comparison to the world: 13
Refined petroleum products—imports: 1.571
million bbl/day (2011 est.)
country comparison to the world: 4
Natural gas—production: 107.7 billion cu m
(2011 est.)
country comparison to the world: 8
Natural gas—consumption: 147.1 billion cu m
(2011 est.)
country comparison to the world: 5
Natural gas—exports: 3.21 billion cu m (2011
est.)
country comparison to the world: 34
Natural gas—imports: 42.5 billion cu m (2012
est.)
country comparison to the world: 11
Natural gas—proved reserves: 3.2 trillion cu m
(1 January 2012 est.)
country comparison to the world: 13
Carbon dioxide emissions from consumption of
energy: 8.321 billion Mt (2010 est.)
country comparison to the world: 2
Electricity—production: 5.81 billion kWh (2012
est.)
country comparison to the world: 112
Electricity—consumption: 7.25 billion kWh
(2012 est.)
country comparison to the world: 99
Electricity—exports: 12.82 million kWh (2012
est.)
country comparison to the world: 84
Electricity—imports: 2.692 billion kWh (2012
est.)
country comparison to the world: 47
Electricity—instalied generating capacity:
1.94 million kW (2012 est.)
country comparison to the world: 103
Electricity—from fossil fuels: 65.7% of total
installed capacity (2009 est.)
country comparison to the world: 124
Electricity—from nuclear fuels: 0% of total
installed capacity (2009 est.)
country comparison to the world: 137
Electricity—from hydroelectric plants: 34.3%
of total installed capacity (2009 est.)
country comparison to the world: 63
Electricity—from other renewable sources: 0%
of total installed capacity (2009 est.)
country comparison to the world: 158
Crude oll—production: 0 bbi/day (2012)
country comparison to the world: 165
Crude oll—exports: 0 bbi/day (2012)
country comparison to the world: 151
Crude oil—imports: 18,800 bbl/day (2012)
country comparison to the world: 71
Crude oll—proved reserves: 0 bbl (1 January
2012 est.)
country comparison to the world: 164
Refined petroleum products—production:
21,280 bbl/day (2008 est.)
country comparison to the world: 96
Refined petroleum products—consumption:
17,490 bbl/day (2011 est.)
country comparison to the world: 137
Refined petroleum products—exports: 8,594
bbl/day (2010 est.)
country comparison to the world: 89
Refined petroleum products—imports: 21,530
bbl/day (2010 est.)
country comparison to the world: 104
Natural gas—production: 0 cu m(2012)
country comparison to the world: 165
Natural gas—consumption: 136.6 million cum
(2011)
country comparison to the world: 103
Natural gas—exports: 0 cu m(2012)
country comparison to the world: 144
Natural gas—imports: 136.6 million cù m
£2012)
country comparison to the world: 71
Natural gas—proved reserves: 0 cu m (1 Janu-
ary 2012 est.)
country comparison to the world: 169
- Carbon dioxide emissions from consumption
of energy: 8.231 million Mt (2010 est.)
country comparison to the world: 108','01f50cca32ca5d060c7c90dfc28fac09f24de1bb396094d037b002815d2a3f84','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3e853efe4029264f4e5da0c5dc1d13e16858721ae23926d56e3c29654769219d',2025,'CO','Colombia','energy',418,'Electricity—production: 56.28 billion kWh
(2010 est.)
country comparison to the world: 47
Electricity—consumption: 46.87 billion kWh
(2010 est.)
country comparison to the world: 48
Electricity—exports: 1.294 billion kWh (2011
est.)
country comparison to the world: 51
Electricity—Iimports: 8.22 billion kWh (2011
est.)
country comparison to the world: 29
Electricity—Iinstalled generating capacity:
13.54 million kW (2009 est.)
country comparison to the world: 47
Electricity—from fossil fuels: 32.9% of total
installed capacity (2009 est.)
country comparison to the world: 178
Electricity—from nuclear fuels: 0% of total
installed capacity (2009 est.)
country comparison to the world: 69 *
Electricity—from hydroelectric plants: 66.6%
of total installed capacity (2009 est.)
country comparison to the world: 25
Electricity—from other renewable sources: 0.4%
of total installed capacity (2009 est.)
country comparison to the world: 77
Crude oil—production: 944,000 bbl/day (2012
est.)
country comparison to the world: 22
Crude oil—exports: 777,900 bbl/day (2009)
country comparison to the world: 18
Crude oil—imports: 10 bbl/day (2011 est.)
country comparison to the world: 85
Crude oil—proved reserves: 2.417 billion bbl
(1 January 2013 est.)
country comparison to the world: 34
Refined petroleum products—production:
316,500 bbl/day (2008 est.)
country comparison to the world: 42
Refined petroleum products—consumption:
287,000 bbl/day''(2011 est.)
country comparison to the world: 45
Refined petroleum products—exports: 52,680
bbl/day (2008 est.)
country comparison to the world: 57
Refined petroleum products—imports: 6,045
bbl/day (2008 est.)
country comparison to the world: 148
Natural gas—production: 11.26 billion cu m
(2010 est.)
country comparison to the world: 43
Natural gas—consumption: 9.08 billion cu m
(2010 est.)
country comparison to the world: 51
Natural gas—exports: 2.18 billion cu m (2010
est.)
country comparison to the world: 39
Natural gas—imports: 40,290 cu m (2011 est.)
country comparison to the world: 75
Natural gas—proved reserves: 134.1 billion
cu m (1 January 2012 est.)
country comparison to the world: 51
Carbon dioxide emissions from consumption of
energy: 72.31 million Mt (2010 est.)
country comparison to the world: 46
Electricity—production: 127.6 billion kWh
(2012 est.)
country comparison to the world: 29
Electricity—consumption: 85.5 billion kWh
(2011 est.)
country comparison to the world: 35
Electricity—exports: 633 million kWh (2009
est.)
country comparison to the world: 58
Electricity—imports: 260 million kWh (2009
est.)
country comparison to the world: 85
Electricity—installed generating capacity:
27.5 million kW (2012 est.)
country comparison to the world: 29
Electricity—from fossil fuels: 35.7% of total
installed capacity (2012 est.)
country comparison to the world: 175
Electricity—from nuclear fuels: 0% of total
installed capacity (2012 est.)
country comparison to the world: 198
Electricity—from hydroelectric plants: 64.3%
of total installed capacity (2012 est.)
country comparison. to the world: 27
Electricity—from other renewable sources: 0%
of total installed capacity (2012 est.)
country comparison to the world; 200
Crude oll—production: 2.47 million bbl/day
(2011 est.)
country comparison to the world: 14
Crude oli—exports: 1.645 million bbl/day (2010
est.)
country comparison to the world: 10
Crude oil—imports: 0 bbl/day (2009 est.)
country comparison to the world: 137
Crude oil—proved reserves: 209.4 billion bbl
(1 January 2012 est.)
country comparison to the world: 3
Refined petroleum products—production:
1.176 million bbl/day (2008 est.)
country comparison to the world: 21
Refined petroleum products—consumption:
571,000 bbl/day (2011 est.)
country comparison to the world: 33
Refined petroleum products—exports:
638,000 bbl/day (2010 est.)
country comparison to the world: 11
Refined petroleum products—imports: 16,660
bbl/day (2011 est.)
country comparison to the world: 112
Natural gas—production: 31.2 billion cu m
(2011 est.)
country comparison to the world: 28
Natural gas—consumption: 33.1 billion cu m
(2011 est.)
790
THE CiA WORLD FACTBOOK
country comparison to the world: 29
Natural gas—exports: 0 cu m (2011 est.)
country comparison to the world: 201
Natural gas—imports: 1.446 billion cu m (2011
est.)
country comparison to the world: 53
Natural gas—proved reserves: 5.524 trillion
cu m (1 January 2012 est.)
country comparison to the world: 9
Carbon dioxide emissions from consumption
of energy: 158.4 million Mt (2010 est.)
country comparison to the world: 33','206e372f79a71201cd8e8699d42a9f0cd8de78840ca0bdadc4d1f01c4a818270','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8f51d706de34a95d413c9eb9168058fb410600301d0eb398eff86cfb15247efb',2025,'KM','Comoros','energy',428,'Electricity—production: 52 million kWh (2009
est.)
country comparison to the world: 206
Electricity—consumption: 48.36 million kWh
(2009 est.)
country comparison to the world: 206
ylang-ylang
Electricity—exports: 0 kWh (2010 est.)
country comparison to the world: 180
Electricity—imports: 0 kWh (2010 est.)
country comparison to the world: 172
Electricity—installed generating capacity:
6,000 kW (2009. est.)
country comparison to the world: 206
Electricity—from fossil fuels: 83.3% of total
installed capacity (2009 est.)
country comparison to the world: 89
Electricity—from nuclear fuels: 0% of total
installed capacity (2009 est.)
country comparison.to the world: 68
Electricity—from hydroelectric plants: 16.7%
of total installed capacity (2009 est.)
country comparison to the world: 101
Electricity—from other renewable sources: 0%
of total installed capacity (2009 est.)
country comparison to the world: 123
Crude oll—production: 0 bbi/day (2011 est.)
country comparison to the world: 120
Crude oil—exports: 0 bbl/day (2009 est.)
country comparison to the world: 96
Crude oll—imports: 0 bbl/day (2009 est.)
country comparison to the world: 172
Crude oli—proved reserves: 0 bbl (1 January
2012 est.)
country comparison to the world: 118
Refined petroleum products—production: 0
bbl/day (2008 est.)
country comparison to the world: 135
Refined petroleum products—consumption:
1,025 bbl/day (2011 est.)
country comparison to the world: 200
Refined petroleum products—exports: 0 bbl/
day (2008 est.)
country comparison to the world: 166
Refined petroleum products—imports: 1,009
bbl/day (2008 est.)
country comparison to the world: 195
Natural gas—production: 0 cu m (2010 est.)
country comparison to the world: 115
Natural gas—consumption: 0 cu m (2010 est.)
country comparison to the world: 131
Natural gas—exports: 0 cu m (2010 est.)
country comparison to the world: 81
Natura! gas—Iimports: 0 cu m (2010 est.)
country comparison to the world: 178
Natural gas—proved reserves:
(1 January 2012 esr.)
country comparison to the world: 123
Carbon dioxide emissions from consumption
of energy: 149,600 Mt (2010 est.)
country comparison to the world: 200','f1bf268c1d4406d9b6f9510a677939aa1532696ea240d85d80490030fa94eab2','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4d0384ef936749769670aea9664e7e13ce23310c8566148ca95991a145db11a2',2025,'ZM','Zambia','energy',434,'Electricity—production: 7.75 billion kWh (2009
est.)
country comparison to the world: 100
Electricity—consumption: 6.588 billion kWh
(2009 est.)
country comparison to the world: 101
Electricity—exports: 887 million kWh (2009
est.)
country comparison to the world: 56
Electricity—imports: 105 million kWh (2009
est.)
country comparison to the world: 94
Electricity—installed generating capacity:
2.475 million kW (2009 est.)
country comparison to the world: 96
Electricity—from fossil fuels: 3%
installed capacity (2009 est.)
country comparison to the world: 204
Electricity—from nuclear fuels: 0% of total
installed capacity (2009 est.)
country comparison to the world: 64
Electricity—from hydroelectric plants: 98.7%
of total installed capacity (2009 est.)
country comparison to the world: 6
Electricity—from other renewable sources: 0%
of total installed capacity (2009 est.)
country comparison to the world: 120
Crude oll—production: 20,160 bbi/day (2011
est.)
country comparison to the world: 72
Crude oil—exports: 11,000 bbl/day (2009 est.)
country comparison to the world: 58
Crude oll—imports: 0 bbi/day (2009 est.)
country comparison to the world: 170
Crude oll—proved reserves: 180 million bbl
(1 January 2012 est.)
country comparison to the world: 65
Refined petroleum products—production: 0
bbli/day (2008 est.)
country comparison to the world: 133
Refined petroleum products—consumption:
10,240 bbl/day (2011 est.)
country comparison to the world: 154
Refined petroleum products—exports: 0 bbl/
day (2008 est.)
country comparison to the world: 164
Refined petroleum products—imports: 500 bbl/
day (2008 est.)
country comparison to the world: 131
Natural gas—productlon: 0 cu m (2010 est.)
country comparison to the world: 113
Natural gas—consumption: 0 cu m (2010 est.)
country comparison to the world: 129
Natural gos—exports: 0 cu m (2010 est.)
country comparison to the world: 77
Natural gas—imports: 0 cu m (2010 est.)
country comparison to the world: 175
of total
Natural gas—proved reserves: 991.1 million
cu m (1 January 2012 est.) :
country comparison to the world: 100
Carbon dioxide emissions from consumption
of energy: 2.804 million Mr (2010 est.)
country comparison to the world: 143
Electricity—production: 10.2 billion kWh (2009
est.)
country comparison to the world: 93
Electricity—consumption: 7.704 billion kWh
(2009 est.)
country comparison to the world: 97
Electricity—exports: 110 million kWh (2010)
country comparison to the world: 70
Electricity—imports: 33 million kWh (2010 est.)
country comparison to the world: 102
Electricity—insialled generating capacity:
1.679 million kW (2009 est.)
country comparison to the world: 110
Electricity—from fossil fuels: 0.4% of total
installed capacity (2009 est.)
country comparison to the world: 206
Electricity—from nuclear fuels: 0% of total
installed capacity (2009 est.)
country comparison to the world: 208
Electricity—from hydroelectric plants: 99.6%
of total installed capacity (2009 est.)
country comparison to the world: 4
Electricity—from other renewable sources: 0%
of total installed capacity (2009. est.)
country comparison to the world: 208
Crude oii—production: 0 bbl/day (2011 est.)
country comparison to the world: 209
Crude oil—exports: 0 bb!/day (2009 est.)
country comparison to the world: 209
Crude oll—imports: 10,790 bbl/day (2009 est.)
country comparison to the world: 77
Crude oil—proved reserves: 0 bbl (1 January
2013 est.)
country comparison to the world: 208
Refined petroleum products—production:
9,664 bbl/day (2008 est.)
country comparison to the world: 106
Refined petroleum products—consumption:
19,260 bbl/day (2011 est.)
country comparison to the world: 131
Refined petroieum products—exports: 21.18
bbl/day (2009 est.)
country comparison to the world: 122.
Refined petroleum products—imports: 17,570
bbl/day (2008 est.)
country comparison to the world: 109
Natural gas—production: 0 cu m (2010 est.)
country comparison. to the world: 212
Natural gas—consumption: 0 cu m (2010 est.)
country comparison to the world: 212
Natural gas—exports: 0 cu m (2010 est.)
country comparison to the world: 210
Natural gas—imports: 0 cu m (2010 est.)
country comparison to the world: 83
Natural gas—proved reserves: 0 cu m (1 Janu-
ary 2012 est.)
country comparison to the world: 209
Carbon dioxide emissions from consumption
of energy: 2.416 million Mt (2010 est.)
country comparison to the world: 147','83db83eabefd93a7559bd228062018db26404c958cf18dbd41f5bf249f9f3fb6','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5b453dd3c3bc16605a4291382ade321e1493bef61ce8d6384fc8517239908fc9',2025,'CR','Costa Rica','energy',453,'Electricity—production: 9.47 billion kWh (2010
est.)
country comparison to the world: 96
Electricity—consumption: 8.53 billion kWh
(2010 est.)
country comparison to the world: 93 :
Electricity—exports: 38 million kWh (2010
est.)
country comparison to the world: 80
Electricity—imports: 62 million kWh (2010
est.)
country comparison to the world: 100
Electricity—installed generating cdpacity:
2.49 million kW (2009 est.)
country comparison to the world: 95
Electricity—from fossil fuels: 24.8% of total
installed capacity (2009 est.)
country comparison to the world: 186
Electricity—from nuclear fuels: 0% of total
installed capacity (2009 est.)
country comparison to the world: 70
Electricity—trom hydroelectric plants: 61.5%
of total installed capacity (2009 est.)
country comparison to the world: 29
Electricity—from other renewable sources:
13.7% of total installed capacity (2009 est.)
country comparison to the world: 13
Crude oil—production: 0 bbl/day (2011 est.)
country comparison to the world: 121
Crude oil—exports: 0 bbl/day (2009 est.)
country comparison to the world; 97
Crude oll—imports: 7,361 bbl/day (2009 est.)
country comparison to the world: 80
Crude oil—proved reserves: 0 bbl (1 January
2012 est.)
country comparison to the world: 119
Refined petroleum products—production:
12,090 bbl/day (2008 est.)
country comparison to the world: 104
Refined petroleum products—consumption:
50,200 bbl/day (2011 est.)
country comparison to the world: 100
Refined petroleum products—exports: 737.1
bbl/day (2008 est.)
country comparison to the world: 114
39,200 bbl/day (2008 est.)
country comparison to the world: 77
Natural gas—production: 0 cu m (2010 est.)
country comparison to the world: 116
Natural gas—consumption: 0 cu m (2010
est.)
country comparison to the world: 132
Natural gas—exports: 0 cu m (2010 est.)
country comparison to the world: 82
Natural gas—imports: 0 cu m (2010 est.)
country comparison to the world: 179
Natural gas—proved reserves: 0 cu m
(1 January 2012 est.) ‘
country comparison to the world: 124
Carbon dioxide emissions from consumption
of energy: 6.411 million Mt (2010 est.)
country comparison to the world: 118
177
COMMUNICATIONS TRANSPORTATION
Telephones—main lines in use: 1.234 million
(2011)
country comparison to the world: 68
Telephones—mobile cellular: 4.358 million
(2011)
country comparison to the world: 114
Telephone system: general assessment: good
domestic telephone service in terms of breadth
of coverage; under the terms of CAFTA-DR, the
state-run telecommunications monopoly is sched-
uled to be opened to competition from domestic
and international firms, but has been slow to open
to competition
domestic: point-to-point and point-to-multi-point
microwave, fiber-optic, and coaxial cable link rural
areas; Internet service is available
international: country code—506; landing points
for the Americas Region Caribbean Ring System
(ARCOS-1), MAYA-1, and the Pan American
Crossing submarine cables that provide links to
South and Central America, parts of the Carib-
bean, and the US; connected to Central Ameri-
can Microwave System; satellite earth stations—2
Intelsat (Atlantic Ocean) (2011)
Broadcast media: multiple privately owned TV
stations and 1 publicly owned TV station; cable
network services are widely available; more than
100 privately owned radio stations and a public
radio network (2007)
Internet country code: .cr
Internet hosts: 147,258 (2012)
country comparison to the world: 78
Internet users: 1.485 million (2009)
country comparison to the world: 82
THE CIA WORLD FACTBOOK
Airports: 153 (2012) :
country comparison to the world: 35
Airports—with paved runways: total: 41
2,438 to 3,047 m: 2
1,524 to 2,437 m: 2
914 to 1,523 m: 23
under 914 m: 14 (2012)
Airports—with unpaved runways: total: 112
914 to 1,523 m: 19
under 914 m: 93 (2012)
Pipelines: refined products 662 km (2010)
Railways: total: 278 km
country comparison to the world; 122
narrow gauge: 278 km 1.067-m gauge
note: none of the railway network is in use (2008)
Roadways: total: 38,049 km
country comparison to the world: 92
paved:9,619km
unpaved: 28,430 km (2004)
Waterways: 730 km (seasonally navigable by
small craft) (2011)
country comparison to the world: 75
Merchant marine: total: 1
country comparison to the world: 149
by type: passenger/cargo 1 (2010)
Ports and terminals: Caldera, Puerto Limon','925830861456ec88f84088cc0f8ac5ad4a2a34a3e5c2d2a2b741dfb8a37fc52e','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4ab652b9f5acb575fb40231aca6fba3845f1ffaa11978cc03385ebaa02b8d804',2025,'MX','Mexico','energy',459,'Electricity—production: 5.533 billion kWh
(2009 est.)
country comparison to the world: 116
Electricity—consumption: 3.576 billion kWh
(2009 est.)
country comparison to the world: 129
Electricity—exports: 484 million kWh (2009
est.)
country comparison to the world: 62
Electricity—imports: 0 kWh (2009 est.)
country comparison to the world: 201
Electricity—installed generating
1.222 million kW (2009 est.)
country comparison to the world: 118
Electricity—from fossil fuels: 50.6% of total
installed capacity (2009 est.)
country comparison to the world: 157
Electricity—from nuclear fuels: 0% of total
installed capacity (2009 est.)
country comparison to the world: 113
Electricity—from hydroelectric plants: 49.4%
of total installed capacity (2009 est.)
country comparison to the world: 41
Electricity—from other renewable sources: 0%
of total installed capacity (2009 est.)
country comparison to the world: 140
Crude oll—production: 45,000 bbi/day (2012
est.)
country comparison to the world: 62
Crude oll—exports: 46,340 bbl/day (2009 est.)
country comparison to the world: 47
Crude oil—imports: 70,610 bbl/day (2009 est.)
country comparison to the world: 52
Crude oil—proved reserves: 250 million bbl
(1 January 2013 est.)
country comparison to the world: 59
Refined petroleum products—production:
70,870 bbl/day (2008 est.) i
country comparison to the world: 82
Refined petroleum products—consumption:
24,630 bbl/day (2011 est.) `
country comparison to the world: 125
Refined petroleum products—exports: 49,810
bbl/day (2008 est.)
country comparison to the world: 58
Refined petroleum products—imports: 3,101
bbl/day (2008 est.)
country comparison to the world: 167
Natural gas—production: 1.6 billion cu m (2010
est.)
country comparison to the world: 61
Natura! gas—consumption: 1.6 billion cu m
(2010 est.)
country comparison to the world: 81
Natural gas—exports: 0 cu m (2010 est.)
country comparison to the world: 120
Natural gas—imports: 0 cu m (2010 est.)
country comparison to the world: 209
Natural gas—proved reserves: 28.32 billion
cu m (I January 2012 est.)
capacity:
country comparison to the world: 71
Carbon dioxide emissions from consumption
of energy: 5.936 million Mt (2010 est.)
country comparison to the world: 119
Electricity—production: 254.4 billion kWh
(2010 est.)
country comparison to the world: 17
Electricity—consumption: 203.8 billion kWh
(2009 est.)
country comparison to the world: 19
Electricity—exports: 1.32 billion kWh (2010
est.)
country comparison to the world: 50
Electricity—imports: 624.5 million kWh (2010
est.)
country comparison to the world: 71
Electricity—installed generating somay
59.33 million kW (2009 est.)
country comparison to the world: 15
Electricity—from fossil fuels: 75% of ‘total
installed capacity (2009 est.)
country comparison to the world: 101
Electricity—from nuclear fuels: 2.3% of total
installed capacity (2009 est.)
country comparison to the world: 28
Electricity—from hydroelectric piants: 19.4%
of total installed capacity (2009 est.)
country comparison to the world: 92
Electricity—from other renewable sources:
3.3% of total installed capacity (2009 est.)
country comparison to the world: 45
Crude oll—production: 2.934 million bbl/day
(2011 est.)
country comparison to the world: 9
Crude oll—exports: 1.299 million bbl/day (2009
est.)
country comparison to the world: 13
Crude oil—imports: 0 bbi/day (2009 est.)
48]
country comparison to the world: 102
Crude oil—proved reserves: 12.17 billion bbl
(1 January 2013 est.)
country comparison to the world: 19
Refined petroleum products—production:
1.458 million bbl/day (2009 est.)
country comparison to the world: 17
Refined petroleum products—consumption:
2.133 million bbl/day (2011 est.)
country comparison to the world: 13
Refined petroleum products—exports: 199.0
bbl/day (2009 est.)
country comparison to the world: 33
Refined petroleum products—imports: 496.0
bbl/day (2009 esr.)
country comparison to the world: 12
Natural gas—production: 55.1 billion cu m
(2011 est.)
country comparison to the world: 18
Natural gas—consumption: 59.15 billion cu m
(2011 est.)
country comparison to the world: 15
Natural gas—exports: 13 million cu m (2011
est.)
country comparison to the world; 49
Natural gas—imports: 13.95 billion cu m (2011
est.)
country comparison to the world: 22
Natural gas—proved reserves: 490.3 billion cum
(1 January 2012 est.)
country comparison to the world: 32
Carbon dioxide emissions from consumption
of energy: 445.3 million Mt (2010 est.)
country comparison to the world: 15
Electricity—production: 192 million kWh
(2002)
country comparison to the world: 183
Electricity—consumption: 178.6 million kWh
(2002)
country comparison to the world: 187
Electricity—exports: 0 kWh (2002) 4
country comparison to the world: 195
Electricity—imports: 0 kWh (2002)
country comparison to the world: 187','d7360e04d07d65ef44f056c66d6d936a2ae5e88fa444ddd1dfbf109ccee59c64','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bcf1cb9407d5ef0fbedd5fc462290d9d3a1f034d35a8217bbca5aa6321e77ad7',2025,'HR','Croatia','energy',470,'Electricity—production: 9.281 billion kWh
(2012 est.)
country comparison to the world: 97
Electricity—consumption: billion kWh (2012
est.)
country comparison to the world: 73
Electricity—exports: 1.38 billion kWh (2012
est.)
country comparison to the world: 48
Electricity—imports: 8.799 billion kWh (2012
est.)
country comparison to the world: 25
Electricity—installed generating capacity:
4.021 million kW (2009 est.)
country comparison to the world: 79
Electricity—from fossil fuels: 47.2% of total
installed capacity (2009 est.)
country comparison to the world: 162
Electricity—from nuclear fuels: 0% of total
installed capacity (2009 est.)
country comparison to the world: 107
Electricity—from hydroelectric plants: 44.7%
of total installed capacity (2009 est.)
country comparison to the world: 48
Electricity—from other renewable sources:
0.8% of total installed capacity (2009 est.)
country comparison to the world: 72
Crude oll—production: 28,230 bbl/day (2012
est.)
country comparison to the world: 68
Crude oil—exports: bbl/day (2012 est.)
country comparison to the world: 126
Crude oil—im ports: 53,620 bbl/day (2012 est.)
country comparison to the world: 55
Crude oit—proved reserves: 2.96 million bbl
(1 January 2012 est.)
country comparison to the world: 97
p
Refined petroleum products—production:
77,020 bbl/day (2012 est:)
country comparison to the world: 81
Refined petroleum products—consumption:
74,410 bbl/day (2012 est.)
country comparison to the world: 90
Refined petroleum products—exports: 33,870
bbl/day (2012 est.)
country comparison to the world: 66
Refined petroleum products—imports: 31,250
bbl/day (2012 est.)
country comparison to the world: 87
Natural gas—production: 1.85 billion cu m
(2012 est.)
country comparison to the world: 58
Natural gas—consumption: 2.755 billion cu m
(2012 est.)
country comparison to the world: 77
Natural gas—exports: 222 million cu m (2012
est.)
country comparison to the world: 44
Natural gas—imports: 1.127 billion cu m (2012
est.) ; ;
country comparison to the world: 58
Natural gas—proved reserves: 24.92 billion
cu m (1 January 2012 est.)
country comparison to the world: 75
Carbon dioxide emissions from consumption
of energy: 21.46 million Mt (2012 est.)
country comparison to the world: 81','6e34d838c11bc35887b0019652eff5729a46b10506a5b01debac3e0670a32e61','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9c49666a94e315d195debd27ddb4b50711aa20aaa9cdd25084e825dc3367d7f9',2025,'CU','Cuba','energy',479,'Electricity—production: 17.8 billion kWh (2011
est.)
country comparison to the world: 77
Electricity—consumption: 16.38 billion kWh
(2011 est.)
country comparison to the world: 74
Electricity—exports: 0 kWh (2010 est.)
country comparison to the world: 183
Electricity—imports: 0 kWh (2010 est.)
country comparison to the world: 175
Electricity—installed generating capacity:
5.914 million kW (2011 est.)
country comparison to the world: 69
Electricity—from fossil fuels: 99.3% of total
installed capacity (2011 est.)
country comparison to the world: 56
Electricity—from nuclear fuels: 0% of total
installed capacity (2011 est.)
country comparison to the world: 72
Electricity—from hydroelectric plants: 0.6% of
total installed capacity (2011 est.)
country comparison to the world: 144
Electricity—from other renewable sources:
0.1% of total installed capacity (2011 est.)
country comparison to the world: 95
Crude oli—production: 53,000 bbl/day (2012
est.)
country comparison to the world: 58
Crude oit—exports: 83,000 bbl/day (2012 est.)
country comparison to the world: 41
Crude oil—Iimports: 165,000 bbl/day (2012 est.)
country comparison to the world: 40
Crude oil—proved reserves: 181.5 million bbl
(1 January 2013 est.)
country comparison to the world: 64
Refined petroleum products—production:
104,200 bbl/day (2010 est.)
country comparison to the world: 74
Refined petroleum products—consumption:
150,200 bbl/day (2011 est.)
country comparison to the world: 67
Refined petroleum products—exports: 0 bbl/
day (2012 est.) `
country comparison to the world: 168
Refined petroleum products—imports: 73,000
bbi/day (2008 est.) ; >
country comparison to the world: 56
Natural gas—production:. 1.03 billion cu m
(2012 est.)
country comparison to the world: 64
Natural gas—consumption: 1.03 billion cu m
(2012 est.)
country comparison to the world: 90
Natural gas—exports: 0 cu m (2012 est.)
country comparison to the world: 84
Natural gas—imports: 0 cu m (2012 est.)
country comparison to the world: 181
Natural gas—proved reserves: 70.79 billion
cu m (1 January 2012 est.)
country comparison to the world: 61
Carbon dioxide emissions from consumption
of energy: 34.46 million Mt (2010 est.)
country comparison to the world: 75','f853bcc360d61e5ee14b88fb70b38b50da3c170e4c48bb876203b2b9d933451a','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('28eb0e806a665a0759f782069e82c0b1aa75601215301a7a1f10d6b768a9f2b0',2025,'CY','Cyprus','energy',483,'Electricity—production: 4.887 billion kWh
(2009 est.)
country comparison to the world: 120
Electricity—consumption: 4.698 billion kWh
(2009 est.) ; .
country comparison to the world: 117
Electricity—exports: 0 kWh (2010 est.)
country comparison to the world: 186
Electricity—imports: 0 kWh (2010 est.)
country comparison to the world: 178
Electricity—installed generating capacity:
1.392 million kW (2009 est.)
country comparison to the world: 115
Electricity—trom fossil fuels; 99.7% of total
installed capacity (2009 est.)
country comparison to the world: 55
Electricity—trom nuclear fuels: 0% of total
installed capacity (2009 est.)
country comparison to the world: 75
Electricity—iium nyuiueiecilic plants: 0% of
total installed capacity (2009 est.)
couniry comparison io the world: 167
Electricity—from other renewable sources: 3%
of total installed capacity (2009 est.)
country comparison io the world: 86
Crude oll—production: 0 bbi/day (2011 est.)
country comparison to the world: 125
Crude oli—exports: 0 bbl/day (2009 est.)
country comparison to the world: 101
Crude oll—im ports: 0 bbl/day (2009 est.)
country comparison to the world: 176
Crude oll—proved reserves: O bb! (1 January
2012 est.)
country comparison to the world: 123
Refined petroleum products—production: 0
bbl/day (2008 est.)
country comparison to the world: 139
Refined petroleum products—consumption:
58,430 bbl/day (2011 est.)
country comparison to the world: 95
Refined petroleum products—exports: 0 bbl/
day (2008 est.)
country comparison to the world: 171
Refined petroleum products—imports: 60,310
bbl/day (2008 est.)
country comparison to the world: 62
Natural gas—production: 0 cu m (2010 est.)
country comparison to the world: 120
Natural gas—consumption: 0 cu m (2010 est.)
country comparison to the world: 136
Natural gas—exports: 0 cu m (2010 est.)
country comparison to the world: 87
Natural gas—imports: 0 cu m (2010 est.)
country comparison to the world: 184
Natural gas—proved reserves: 0 cu m
(1 January 2012 est.)
country comparison to the world: 128
Carbon dioxide emissions from consumption
of energy: 9.257 million Mt (2010 est.)
country comparison to the world: 102','e34353e41e30378a9be957221b487e14f4bd621b2e0aec767b257ed6f50939ce','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d65c707e1a8d1151b1113946a7785350dd6ab9c848454b11d890c6256a1676e4',2025,'AT','Austria','energy',489,'Electricity—production: . 80.44 billion kWh
(2010 est.)
country comparison to the world: 39
Electricity—consumption: 58.88 billion kWh
(2009 est.)
country comparison to the world: 43
Electricity—exports: 21.59 billion kWh (2010
est.)
country comparison to the world: 7
Electricity—imports: 6.642 billion kWh (2010
est.)
country comparison to the world: 34
Electricity—installed generating capacity:
18.32 million kW (2009 est.)
country comparison to the world: 39
Electricity—from fossii fuels: 60% of total
installed capacity (2009 est.)
country comparison to the world: 137
Electricity—from nuclear fuels: 20.9% of total
installed capacity (2009 est.)
country comparison to the world: 10
Electricity—from hydroelectric plants: 5.7% of
total installed capacity (2009 est.) 7
country comparison to the world: 125
Electricity—from other renewable sources: 7.1%
of total installed capacity (2009 est.)
country comparison to the world: 28
Crude oil—production: 9,162 bbl/day (2011 est.)
country comparison to the world: 82
Crude oll—exports: 420 bbl/day (2009 est.)
country comparison to the world: 68
CZECH REPUBLIC
Crude oil—im ports: 143,700 bbl/day (2009 est.)
country comparison to the world: 42
Crude oll—proved reserves: 15 million bbl
(1 January 2012 est.)
country comparison to the world: 89
Refined petroleum products—production:
167,000 bbl/day (2009 est.)
country comparison to the world: 61
Refined petroleum products—consumption:
19,000 bbl/day (2011 est.)
country comparison to the world: 59
Refined petroleum products—exports: 25,060
bbl/day (2009 est.)
country comparison to the world: 72
Refined petroleum products—imports: 65,560
bbl/day (2009 est.)
country comparison to the world: 59
Natural gas—production: 185 million cu m
(2011 est.)
country comparison to the world: 78
Natural gas—consumption: 8.944 billion cu m
(2011 est.)
country comparison to the world: 52
Notural gas—exports: 167 million cu m (2011
est.)
country comparison to the world: 45
Natural gas—imports: 9.319 billion cu m (2011
est.)
country comparison to the world: 26
Natural gas—proved reserves: 3.964 billion
cu m (1 January 2011 est.)
country comparison to the world: 93
Carbon dioxide emissions from consumption
of energy: 90.83 million Mt (2010 est.)
country comparison to the world: 41','a25cda8b36f104673bc447d8db85bf431f9730ea49bf11970ebc6777bd4fa30c','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cfce9583129987189a61505dec69f383c8c036daf5a2ff8186db9f4c51b2c115',2025,'DK','Denmark','energy',497,'Electricity—production: 36.39 billion kWh
(2010 est.)
country comparison to the world: 62
Electricity—consumption: 32.42 billion kWh
(2009 est.)
country comparison to the world: 60
Electricity—exports: 11.73 billion kWh (2010
est.) ’
country comparison to the world: 18
Electricity—imports: 10.6 billion kWh (2010 est.)
country comparison to the world: 20
Electricity—installed generating cary:
13.42 million kW (2009 est.)
country comparison to the world: 48
Electricity—from fossil fuels; 65.8% of total
installed capacity (2009 est.)
country comparison to the world: 123
Electricity—from nuclear fuels: 0% of total
installed capacity (2009 est.)
country comparison to the world: 76
Electricity—from hydroelectric plants: 0.1% of
total installed capacity (2009 est.)
country comparison to the world: 151
Electricity—from other renewable sources:
34.2% of total installed capacity (2009 est.)
country comparison to the world; 1
Crude oil—production: 221,100 bbl/day (2011 est.)
country comparison to the world: 39
Crude oll—exports: 171,100 bbi/day (2009 est.)
country comparison to the world: 33
Crude oil—im ports: 70,220 bbl/day (2009 est.)
country comparison to the world: 53
Crude oll—proved reserves: 900 million bbl
(1 January 2012 est.)
country comparison to the world: 43
Refined petroleum products—production:
158,500 bbl/day (2009 est.)
country comparison to the world: 66
Refined petroleum products —consumption:
160,200 bbl/day (2011 est.)
country comparison to the world: 65
Refined petroleum products—exports: 93,890
bbl/day (2010 est.)
country comparison to the world: 42
Refined petroleum products—imports: 177,700
bbl/day (2009 est.)
country comparison to the world: 30
Natural gas—production: 7.069 billion cu m
(2011 est.)
country comparison to the world: 48
Natural gas—consumption: 4.179 billion cu m
(2011 est.)
country comparison to the world: 65
Natural gas—exports: 3.126 billion cu m (2011
est.)
country comparison to the world: 35
201
Natural gas—imports: 369 million cu m (2011
est.)
country comparison. to the world: 70
Natural gas—proved reserves: 51.99 billion cu
m (1 January 2012 est.)
country comparison to the world: 66
Carbon dioxide emissions from consumption
of energy: 45.96 million Mt (2010 est.)
country comparison to the world: 64','a146930645bc474372f32007347200a789e160086a0d6856b5828429bb8c116f','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('11e9d58c472bf834042ef8acc5eb29296464989a202c8a01945cb4ea781d437f',2025,'DJ','Djibouti','energy',511,'Electricity—production: 350 million kWh (2009
est.)
country comparison to the world: 167
Electricity—consumption: 193,000 million kWh
(2009 est.)
country comparison to the world: 171
Electricity—exports: 0 kWh (2010 est.)
country comparison. to the world: 187
Electricity—imports: 0 kWh (2010 est.)
country comparison to the world: 179
Electricity—installed generating
130,000 kW (2009 est.)
country comparison to the world: 166
Electricity—from fossil fuels: 100% of total
installed capacity (2009 est.)
country comparison to the world: 12
Electricity—from nuclear fuels: 0% of total
installed capacity (2009 est.)
country comparison to the world: 77
Eleciricity—from hydroelectric plants: 0% of
total installed capacity (2009 est.)
country comparison. to the world: 168
Electricity—tfrom other renewable sources: 0%
of total installed capacity (2009 est.)
country comparison to the world: 125
Crude oii—production: 0 bbi/day (2011 est.)
country comparison to the world: 126
Crude oil—exports: 0 bbl/day (2009 est.)
country comparison to the world: 102
Crude oil—imports: 0 bbl/day (2009 est.)
country comparison to the world: 177
Crude oil—proved reserves: 0 bbl (1 January
2012 est.)
country comparison to the world: 124
Refined petroleum products—production: 0
bbl/day (2008 est.)
country comparison to the world: 140
Refined petroleum products—consumption:
12,460 bbl/day (2011 est.)
country comparison to the world: 150
Refined petroleum products—exports: 19.18
bbl/day (2008 est.)
country comparison to the world: 123
Refined petroleum products—imports: 7,987
bbl/day (2008 est.) country comparison to the
world: 135
Natural gas—production: 0 cu m (2010 est.)
country comparison to the world: 121
Natura! gas—consumption: 0 cu m (2010 est.)
country comparison to the world: 137
Natural gas—exports: 0 cu m (2010 est.)
country comparison to the world: 88
Natural gas—Iimports: 0 cu m (2010 est.}
country comparison to the world: 185
Natural gas—proved reserves: 0 cu m (1 Janu-
ary 2012 est.)
country comparison to the world: 129
Carbon dioxide emissions from consumption
of energy: 2.352 million Mt (2010 est.)
country comparison to the world: 148','2a7bbc1b40c0ddc395e18d3b819067ff709a1b04975bcb87b958354b9f75dc48','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bc7aa05dd15652842f8b538b53141e6bdad589c6cede0bd94b71d76c8e006515',2025,'DM','Dominica','energy',521,'Electricity—production: 85.5 million kWh
(2009 est.)
country comparison to the world: 200
Electricity—consumption: 79.52 million kWh
(2009 est.)
country comparison to the world: 200
Electricity—exports: 0 kWh (2010 est.)
country comparison to the world: 188
Electricity—imports: 0 kWh (2010 est.)
country comparison to the world: 180
Electricity—instalied generating capacity:
22,200 kW (2009 est.)
country comparison to the world: 194
Electricity—from fossil fuels: 72.1% of total
installed capacity (2009 est.)
country comparison to the world: 102
Electricity—from nuclear fuels: 0% of total
installed capacity (2009 est.)
country comparison to the world: 78
Electricity—trom hydroelectric plants: 27% of
total installed capacity (2009 est.)
country comparison to the world: 81
Electricity—from other renewable sources:
0.9% of total installed capacity (2009 est.)
country comparison to the world: 71
Crude oll—production: 0 bbl/day (2011 est.)
country comparison to the world: 127
Crude oll—exports: 0 bbl/day (2009 est.)
country comparison to the world: 103
Crude oil—imports: 0 bbl/day (2009 est.)
country comparison to the world: 178
Crude oll—proved reserves: 0 bbl (1 January
2012 es)
country comparison to the world: 125
Refined petroleum products—production: 0
bbl/day (2008 est.)
country comparison to the world: 141
Refined petroleum products—consumption:
918 bbl/day (2011 est.)
country comparison to the world: 207
Refined petroleum products—exports: 0 bbl/
day (2008 est.)
country comparison to the world: 172
Refined petroleum products—imports: 911.8
bbl/day (2008 est.)
country comparison to the world: 196
Natural gas—production: 0 cu m (2010 esr.)
country comparison to the world: 122
Natural gas—consumption: 0 cu m (2010 est.)
country comparison to the world: 138
Natural gas—exports: 0 cu m (2010 est.)
country comparison to the world: 89
Natural gas—imports: 0 cu m (2010 est.)
country comparison to the world: 186 \\
Natural gas—proved reserves: 0 cu m (1 Janu-
ary 2012 es)
country comparison to the world: 130
Carbon dioxide emissions from consumption
of energy: 141,200 Mr (2010 est.)
country comparison to the world: 205','49d1d855ef1d9c2a088768f1454dd04bb60afe6f46efb23da330c4132a3d1649','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('302e6a5493d491617fb2c1f79515ab3df3097b46c30938b368bdf644de28d6c6',2025,'DO','Dominican Republic','energy',530,'Electricity—production: 12.3 billion kWh (2010
est.)
country comparison to the world: 90
Electricity—consumption: 9.881 billion kWh
(2009 est.)
country comparison to the world: 91
Electricity—exports: 0 kWh (2010 est.)
country comparison to the world: 189
Electricity—imports: 0 kWh (2010 est.)
country comparison to the world: 181
Electricity—installed generating capacity:
2.973 million kW (2009 est.)
country comparison to the world: 89
Electricity—from fossil fuels: 83% of total
installed capacity (2009 est.)
country comparison to the world: 90
Electricity—from nuclear fuels: 0% of total
installed capacity (2009 est.)
country comparison to the world: 79
Electricity—from hydroelectric plants: 16.6%
of total installed capacity (2009 est.)
country comparison to the world: 102
Electricity—from other renewable sources:
0.3% of total installed capacity (2009 est.)
country comparison to the world: 80
Crude oil—production: 0 bbl/day (2011 est.)
country comparison to the world: 128
Crude oll—exports: 0 bbi/day (2009 est.)
country comparison to the world: 104
Crude oil—imports: 26,150 bbl/day (2009 est.)
country comparison to the world: 67
Crude oll—proved reserves: 0 bbl (1 January
2012 es) :
country comparison to the world: 126
Refined petroleum products—production:
33,800 bbl/day (2008 est.)
country comparison to the world: 91
Refined petroleum products—consumption:
122,300 bbl/day (2011 est.)
country comparison to the world: 73
Refined petroleum products—exports: 0 bbl/
day (2008 est.)
country comparison to the world: 173
212
THE CIA WORLD FACTBOOK
Refined petroleum products—Iimports: 88,480
bbl/day (2008 est.)
country comparison to the world: 52
Natura! gas—production: 0 cu m (2010 est.)
country comparison to the world: 123
Natural gas—consumption: 820 million cu m
(2010 est.)
country comparison to the world: 92
Natural gas—exports: 0 cu m (2010 est.)
country comparison to the world: 90
Natural gas—imports: 820 million cu m (2010
est.)
country comparison to the world: 62
Natural gas—proved reserves: 0 cu m (1 Janu-
ary 2012 es)
country comparison to the world: 131
Carbon dioxide emissions from consumption
of energy: 19.6 million Mr (2010 est.)
country comparison to the world: 84','9e4651218c1904ce78c4004f2217fdc5f2161fb5a89a3748e7a6b2a4fa79f533','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('beed4505b3e1e01eebd21abb81c46fea0487d1301e7f4d5cad3ab10e0de1dfc2',2025,'EC','Ecuador','energy',535,'Electricity—production: 21.84 billion kWh
(2010 est.)
country comparison to the world: 70
Electricity—consumption: 14.92 billion kWh
(2009 est.)
country comparison to the world: 78
Electricity—exports: 14.1 million kWh (2009 est.)
country comparison to the world: 83
215
Electricity—imports: 1.3 billion kWh (2009 est.)
country comparison to the world: 58
Electricity—installed generating capacity:
4.939 million kW (2009 est.)
country comparison to the world: 74
Electricity—from fossil fuels: 56.2% of total
installed capacity (2009 est.)
country comparison to the world: 144
Electricity—from nuclear fuels: 0% of total
installed capacity (2009 est.)
country comparison to the world: 80
Electricity—from hydroelectric plants: 41.7%
of total installed capacity (2009 est.)
country comparison to the world: 53
Electricity—from other renewable sources:
2.1% of total installed capacity (2009 est.)
country comparison to the world: 57
Crude oil—production: 504,000 bbl/day (2012
est.)
country comparison to the world: 30
Crude oll—exports: 366,000 bbi/day (2012
est.)
country comparison to the world: 24
Crude oil—imports: 154,000 bbl/day (2012 est.)
country comparison to the world: 41
Crude oil—proved reserves: 6.573 billion bbl
(1 January 2013 est.)
country comparison to the world: 22
Refined petroleum products—production:
198,700 bbl/day (2012 est.)
country comparison to the world: 57
Refined petroleum products—consumption:
280,000 bbl/day (2012 est.)
country comparison to the world: 46
Refined petroleum products—exports: 28,000
bbl/day (2012 est.)
country comparison to the world: 68
Refined petroleum products—imports: 111,000
bbl/day (2012 est.)
country comparison to the world: 46
Natural gas—production: 330 million cu m
(2010 est.)
country comparison to the world: 75
Natura! gas—consumption: 330 million cu m
(2010 est.)
country comparison to the world: 100
Natural gas—exports: 0 cum (2010 est.)
country comparison to the world: 91
Natural gas—imports: 25,000 cum (2012 est.)
country comparison to the world: 76
Natural gas—proved reserves: 7.985 billion cu
m (1 January 2012 est.)
country comparison to the world: 82
Carbon dioxide emissions from consumption
of energy: 24.43 million Mt (2010 est.)
country comparison to the world: 79
216
THE CIA WORLD FACTBOOK','415950b5dd9efa479298b05fda6b428ee9dba9928baa71c02c638688501f2d4b','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c713f41283de5eb9e60c8f7f82f894fdad6453e205a93b0e297addd1185a65fc',2025,'EG','Egypt','energy',546,'Electricity—production: 136.6 billion KWh
(2010 est.)
country comparison to the world: 28
Electricity—consumption: 115.8 billion KWh
(2009 est.)
country comparison to the world: 28
Electricity—exports: 1.118 billion KWh (2009
est.)
country comparison to the world: 54
Electricity—imports: 183 million kWh (2009
est.)
country comparison to the world: 89
Electricity—installed generating capacity:
24.67 million KW (2009 est.)
country comparison to the world: 34
Electricity—from fossil fuels: 86.9% of total
installed capacity (2009 est.)
country comparison to the world: 84
Electricity—from nuclear fuels: 0% of total
installed capacity (2009 est.)
country comparison to the world: 81
Electricity—from hydroelectric plants: 11.4%
of total installed capacity (2009 est.)
country comparison to the world: 113
Electricity—from other renewable sources:
1.7% of total installed capacity (2009 est.)
country comparison to the world: 65
Crude oil—production: 711,500 bbl/day (2011
est.)
country comparison to the world: 28
Crude oil—exports: 86,720 bbl/day (2009 est.)
country comparison to the world: 40
Crude oil—imports: 48,590 bbl/day (2009 est.)
country comparison to the world: 57
Crude oil—proved reserves: 4.45 billion bbl
(1 January 2013 est.)
country comparison to the world: 28
Refined petroleum products—production:
628,100 bbl/day (2008 est.)
country comparison to the world: 30
Refined petroleum products—consumption:
816,300 bbl/day (2011 est.)
country comparison to the world: 24
Refined petroleum products—exports: 91,680
bbl/day (2008 est.) - ‘
country comparison to the world: 44
Refined petroleum products—imports: 114,600
bbl/day (2008 est.)
country comparison to the world; 45
Natural gas—production: 61.33 billion cu m
(2010 est.)
country comparison to the world: 16
Natural gas—consumption: 46.16 billion cu m
(2010 est.)
country comparison to the world: 19
Natural gas—exports: 15.17 billion cu m (2010 est.)
country comparison to the world: 19
220
THE CIA WORLD FACTBOOK
Natural gas—imports: 0 cu m (2010 est.)
country comparison to the world: 187
Natural gas—proved reserves: 2.186 trillion
cu m (1 January 2012 est.)
country comparison to the world: 17
Carbon dioxide emissions from consumption
of energy: 196.5 million Mt (2010 est.)
country comparison to the world: 28','351899418939b26ce0458cd9d2a8278fd6100775f67132f9f1a17be7a2d25004','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9e29545ccdcd292e683702a788958d2313ded54b719c8d32ae6bd0353d155a5e',2025,'GQ','Equatorial Guinea','energy',564,'Electricity—production: 97 million kWh (2009
est.)
country comparison to the world: 196
Electricity—consumption: 90.21 million kWh
(2009 est.)
country comparison to the world: 197
Electricity—exports: 0 kWh (2010 est.)
country comparison to the world: 190
Electricity—imports: 0 kWh (2010 est.)
country comparison to the world: 182
Electricity—installed generating capacity:
31,000 kW (2009 est.)
country comparison to the world: 190
Electricity—from fossil fuels: 96.8% of total
installed capacity (2009 est.)
country comparison to the world: 66
Electricity—from nuclear fuels: 0% of total
installed capacity (2009 est.)
country comparison to the world: 83
Electricity—from hydroelectric plants: 3.2% of
total installed capacity (2009 est.)
country comparison to the world: 130
Electricity—from other renewable sources: 0%
of total installed capacity (2009 est.)
country comparison to the world: 126
Crude oi!—production: 302,500 bbl/day (2011 est.)
country comparison to the world: 35
Crude oll—exports: 299,400 bbl/day (2009 est.)
country. comparison to the world: 25
Crude oll—imports: 0 bbi/day (2009 ést.)
country comparison to the world: 179
Crude oll—proved reserves: 1.1 billion bbl
(1 January 2012 est.)
country comparison to the world: 40
Refined petroleum products—production: 0
bbl/day (2008 est.)
country comparison to the world: 142
Refined petroleum products—consumption:
1,588 bbl/day (2011 est.)
country comparison to the world: 195
Refined petroleum products—exports: 25,670
bbl/day (2008 est.)
country comparison to the world: 71
Refined petroleum products—imports: 4,561
bbl/day (2008 est.)
country comparison to the world: 161
Natural gas—production: 6.74 billion cu m
(2010 est.)
country comparison to the world: 49
Natural gas—consumption: 1.58 billion cu m
(2010 est.)
country comparison to the world: 82
Natural gos—exports: 5.16 billion cu m (2010
est.)
country comparison to the world: 31
Natural gas—imports: 0 cu m (2010 est.)
‘ country comparison to the world: 188
Natural gas—proved reserves: 36.81 billion
“cum (I January 2012 est.)
country comparison to the world: 70
Carbon dioxide emissions from consumption
of energy: 5.005 million Mr (2010 est.)
country comparison to the world: 123','34fe52c884c7c349605a007257ebd514ae99cc39ac2a1a9149d9e304a9c5f5c1','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('077d9d70bc8ff75be4a5f21b523d5a81aa348a37ed2587b7f07cabd3316786c6',2025,'ET','Ethiopia','energy',572,'Electricity—production: 277 million kWh (2009 est.)
country comparison to the world: 173
Electricity—consumption: 242 million kWh
(2009 est.)
country comparison to the world: 180
Electricity—exports: 0 kWh (2010 est.)
country comparison to the world: 191
Electricity—imports: 0 kWh (2010 est.)
country comparison to the world: 183
Electricity—installed generating capacity:
139,000 kW (2009 est.)
country comparison to the world: 162
Electricity—trom fossil fuels: 99.3% of total
_installed capacity (2009 est.)
country comparison to the world: 57
Electricity—from nuclear fuels:.0% of total
installed capacity (2009 est.)
country comparison to the world: 85
Electricity—from hydroelectric plants: 0% of
total installed capacity (2009 est.)
country comparison to the world: 169
Electricity—from other renewable sources:
0.7% of total installed capacity (2009 est.)
country comparison to the world: 74
Crude oll—production: 0 bbl/day (2011 est.)
country comparison to the world: 130
Crude oll—exports: 0 bbl/day (2009 est.)
country comparison to the world: 107
Crude oll—imports: 0 bbl/day (2009 est.) ''
country comparison to the world: 181
Crude oli—proved reserves: 0 bbl (1 January
2012 est.)
country comparison to the world: 129
Refined petroleum products—production:
O bbl/day (2008 est.)
country comparison to the world: 144
Refined petroleum products—consumption:
4,480 bbl/day (2011 est.)
country comparison to the world: 173
Refined petroleum products—exports: 0 bbl/
day (2008 est.)
country comparison to the world: 175
Refined petroleum products—imports: 2,670
bbi/day (2008 est.)
country comparison to the world: 173
Natural gas—production: 0 cu m (2010 est.)
country comparison to the world: 125
Natural gas—consumption: 0 cu m (2010 est.)
country comparison to the world: 139
Natural gas—exports: 0 cu m (2010 est.)
country comparison to the world: 94
Natural gas—imports: 0 cu m (2010 est.)
country comparison to the world: 189
Natural gas—proved reserves: 0 cu m (1 Janu-
ary 2012 est.)
country comparison to the world: 133
Carbon dioxide emissions from consumption
of energy: 798,200 Mr (2010 est.)
country comparison to the world: 172
Electricity—production: 4.039 billion kWh
(2009 est.)
country comparison to the world: 124
Electricity—consumption: 3.648 billion kWh
(2009 est.)
country comparison to the world: 126
Electricity—exports: 0 kWh (2010 est.)
country comparison to the world: 192
Electricity—imports: 0 kWh (2010 est.)
country comparison to the world: 184
Electricity—installed generating capacity:
1.18 million kW (2009 est.)
country comparison to the world: 120
Electricity—from fossil fuels; 17.2% of total
installed capacity (2009 est.)
country comparison to the world: 192
Electricity—from nuclear fuels: 0% of total
installed capacity (2009 est.)
country comparison to the world: 87
Electricity—from hydroelectric plants: 82.1%
of total installed capacity (2009 est.)
country comparison to the world: 14
Electricity—from other renewable sources:
0.6% of total installed capacity (2009 est.)
country comparison to the world: 75
Crude oli—production: 0 bbl/day (2011 est.)
country comparison to the world: 132
gold,
237
Crude oll—exports: 0 bbl/day (2009 est.)
country comparison to the world: 109
Crude oll—imports: 0 bbl/day (2009 est.)
country comparison to the world: 182
Crude oll—proved reserves: 430,000 bbl
(1 January 2012 es)
country comparison to the world: 101
Refined petroleum products—production:
O bbl/day (2008 est.)
country comparison to the world: 145
Refined petroleum products—consumption:
49,080 bbl/day (2011 est.)
country comparison to the world: 101
Refined petroleum products—exports: 0 bbl/
day (2008 est.)
country comparison to the world: 176
Refined petroleum products—imports: 42,480
bbl/day (2008 est.)
country comparison to the world: 73
Natural gas—production: 0 cu m (2010 est.)
country comparison to the world: 127
Natural gas—consumption: 0 cu m (2010 est.)
country comparison to the world: 141
Natural gas—exports: 0 cu m (2010 est.)
country comparison to the world: 96
Natural gas—imports: 0 cu m (2010 est.)
country comparison to the world: 191
Natural gas—proved reserves: 113 billion cu m
(1 January 2011 es) i x
country comparison to the world: 53
Carbon dioxide emissions from consumption
of energy: 6.74 million Mt (2010 est.)
country comparison to the world: 113
Electricity—production: 19 million kWh (2009
est.)
country comparison to the world: 214
Electricity—consumption: 17.67 million kWh
(2009 est.)
country comparison to the world: 214
Electricity—exports: 0 kWh (2010 est.)
country comparison to the world: 194
Electricity—imports: 0 kWh (2010 est.)
country comparison to the world: 186
Electricity—installed generating capacity:
10,000 kW (2009 est.)
country comparison to the world: 204
Electricity—from fossil fuels: 90% of total
installed capacity (2009 est.)
country comparison to the world: 76
Electricity—from nuclear fuels: 0% of total
installed capacity (2009 est:)
country comparison to the world: 89
Electricity—from hydroelectric plants: 0% of
total installed capacity (2009 est.)
country comparison to the world: 170
Electricity—from other renewable sources:
10% of total installed capacity (2009 est.)
country comparison to the world: 23
Crude ol!—production: 0 bbl/day (2011 est.)
country comparison to the world: 135
Crude oll—exports: 0 bbl/day (2009 est.)
country comparison to the world: 112
Crude oll—imports: 0 bbl/day (2009 est.)
country comparison to the world: 184
Crude oll—proved reserves: 0 bbl (1 January
2012 est.)
country comparison to the world: 133
Refined petroleum products—production: 0
bbl/day (2008 est.)
country comparison to the world: 147
Refined petroleum products—consumption:
300 bbi/day (2011 est.)
country comparison to the world: 209
Refined petroleum products—exports: 0 bbl/
day (2008 est.)
country comparison to the world: 177
Refined petroleum products—imports: 312.5
bbl/day (2008 est.)
country comparison to the world: 204
Natural gas—production: 0 cu m (2010 est.)
country comparison to the world: 130
Natural gas—consumption: 0 cu m (2010 est.)
country comparison to the world: 143
Natural gas—exports: 0 cu m (2010 est.)
country comparison to the world: 99
Natura! gas—imports: 0 cu m (2010 est.)
country comparison to the world: 193
Natural gas—proved reserves: 0 cu m (1 Janu-
ary 2012 est.)
country comparison to the world: 137
Carbon dioxide emissions from consumption
of energy: 45,780 Mt (2010 est.)
country comparison to the world: 206','8c0cd32b6e3f4f71a3b0a8afe68c42a9aafe2f10d4971b6e0c04dd00c871331a','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cad810562e2ae9448cfb9ee24d840edf0fe0a941f9314f1f0761133d3a3575db',2025,'EE','Estonia','energy',582,'Electricity—production: 12.89 billion kWh
(2010 est.)
country comparison to the world: 89
Electricity—consumption: 7.755 billion kWh
(2009 est.)
country comparison to the world: 96
Electricity—exports: 4.354 billion kWh (2010
est.)
country comparison to the-world: 31
Electricity—imports: 1.1 billion kWh (2010 est.)
country comparison to the world: 63
Electricity—instatled generating capacity:
2.661 million kW (2009 est.)
country comparison to the world: 92
Electricity—from fossil fuels: 94.6% of total
installed capacity (2009 est.)
country comparison to the world: 69
Electricity—from nuclear fuels: 0% of total
installed capacity (2009 est.)
country comparison to the world: 84
Electricity—from hydroelectric plants: 0.3% of
total installed capacity (2009 est.)
country comparison to the world: 146
Electricity—from other renewable sources:
5.1% of total installed capacity (2009 est.)
country comparison to the world: 36
Crude oil—production: 7,700 bbl/day (2011 est.)
country comparison to the world: 84
Crude oii—exports: 0 bbl/day (2009 est.)
country Comparison to the world: 106
Crude oil—imports: 0 bbl/day (2009 est.)
country comparison to the world: 180
Crude oli—proved reserves: 0 bbl (1 January
2012 est.)
country comparison to the world: 128
Refined petroleum products—production:
0 bbl/day (2008 est.)
country comparison to the world: 143
Refined petroleum products—consumption:
26,340 bbl/day (2011 est.)
country comparison to the world: 122
Refined petroleum products—exports: 0 bbl/
day (2008 est.)
country comparison to the world: 174
Refined petroleum products—imports: 23,270
bbl/day (2008 est.)
country comparison to the world: 101
Natural gas—production: 0 cu m (2010 est.)
country comparison to the world: 124
Natural gas—consumption: 701 million cu m
(2010 est.)
country comparison to the world: 97
Natural gas—exports: 0 cu m (2010 est.)
234
THE CIA WORLD FACTBOOK
country comparison to the world: 93
Natural gas—imports: 701 million cu m (2010 est.)
country comparison to the world: 65
Natural gas—proved reserves: 0 cu m.(1 Janu-
ary 2012 est.)
country comparison to the world: 132
Carbon dioxide emissions from consumption
of energy: 20.56 million Mt (2010 est.)
country comparison to the world: 82','a088d3bd467c6d175b925ada0b065630f234cd69d607c14eb89545499576d817','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fc7c64e6089395b720e3fb6a6de843b24d0a77f1c3e126fcbd006bd13d097e79',2025,'FO','Faroe Islands','energy',599,'Electricity—production: 280.3 million kWh
(2010 est.)
country comparison to the world: 172
Electricity—consumption: 268.8 million kWh
(2010 est.)
country comparison to the world: 178
Electricity—exports: 0 kWh (2010 est.)
country comparison to the world: 196
Electricity—imports: 0 kWh (2010 est.)
country comparison to the world: 188
Electricity—installed generating capacity:
100,100 kW (2009 est.)
country comparison to the world: 169
Eleciricity—from fossil fuels: 64.9% of total
installed capacity (2009 est.)
country comparison to the world: 129
Electricity—from nuciear fuels: 0% of total
installed capacity (2009 est.)
country comparison to the world: 90
Electricity—from hydroelectric plants: 31% of
total installed capacity (2009 est.)
country comparison to the world: 74
Electricity—from other renewable sources:
4.1% of total installed capacity (2009 est.)
country comparison to the world: 43
Crude oll—production: 0 bbl/day (2011 est.)
country comparison to the world: 136
Crude oil—exports: 0 bbl/day (2009 est.)
country comparison to the world: 113
Crude oll—imports: 0 bbi/day (2009 esr.)
country comparison to the world: 185
Crude oll—proved reserves: 0 bbl (1 January
2012 est.)
country comparison to the world: 134
Refined petroleum products—production: 0
bbl/day (2008 est.)
country comparison to''the world: 148
Refined petroleum products—consumption:
4,871 bbl/day (2011 est.)
country comparison to the world: 171
Refined petroleum products—exports: 0 bbi/
day (2008 est.)
country comparison to the world: 178
Refined petroleum products—imports: 4,859
bbi/day (2008 est.)
country comparison to the world: 158
Natural gas—production: 0 cu m (2010 est.)
country comparison to the world: 131
247
Natural gas—consumption: 0 cu m (2010 est.)
country comparison to the world: 144
Natural gas—exports: 0 cu m (2010 est.)
country comparison to the world: 100
Natural gas—imports: 0 cu m (2010 est.)
country comparison to the world; 194
Natural gas—proved reserves: 0 cu m (1 Janu-
ary 2012 est.)
country comparison to the world: 138
Carbon dioxide emissions from consumption
of energy: 744,400 Mt (2010 est.)
country comparison to the world: 174','ee484e68eef3c3129543ef93aafdf78c21d8120c1e55f7f7fcbc91c382b279ca','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e1330cd67184ae30e19645ee870c574ebe0fbed6ffc981b5fde77091e98d81a4',2025,'FI','Finland','energy',613,'Electricity—production: 76.16 billion kWh
(2010 est.)
country comparison to the world: 40
Electricity—consumption: 77.66 billion kWh
(2009 est.)
country comparison to the world: 37
Electricity—exports: 5.218 billion kWh (2010
est.)
country comparison to the world: 29
Electricity—imports: 15.72 billion kWh (2010 est.)
country comparison to the world: 11
Electricity—installed generating capacity:
16.32 million kW (2009 est.)
country comparison to the world: 44
Electricity—from fossil fuels: 52.5% of total
installed capacity (2009 est.)
country comparison to the world: 153
Electricity—from nuclear fuels: 16.4% of total
installed capacity (2009 est.)
country comparison to the world: 16
Electricity—from hydroelectric plants: 19.1%
of total installed capacity (2009 est.)
country comparison to the world: 93
Electricity—from other renewable sources:
12% of total installed capacity (2009 est.)
country comparison to the world: 20
Crude oil—production: 0 bbl/day (2011 est.)
country comparison to the world: 133
Crude oll—exports: 0 bbl/day (2009 est.)
country comparison to the world: 110
Crude oil—imports: 215,700 bbl/day (2009 est.)
country comparison to the world: 32
Crude oll—proved reserves: 0 bbl (1 January
2012 est.)
country comparison to the world: 131
Refined petroleum products—production:
301,500 bbl/day (2009 est.)
country comparison to the world: 46
Refined petroleum products—consumption:
204,800 bbl/day (2011 est.)
country comparison to the world: 57
Refined petroleum products—exports: 133,600
bbl/day (2009 est.)
country comparison to the world: 40
Refined petroleum products—imports: 103,100
bbl/day (2009 est.)
country comparison to the world: 48
Natural gas—production: 0 cu m (2010 est.)
country comparison to the world: 128
Natural gas—consumption: billion cu m (2011 est.)
country comparison to the world: 66
Natural gas—exports: 0 cu m (2011 est.)
country comparison to the world: 97
Natural gas—imports: 4.101 billion cu m (2011 est.)
country comparison to the world: 36
Natural gas—proved reserves: 0 cu m.(1 Janu-
ary 2012 est.)
country comparison to the world: 135
Carbon dioxide emissions from consumption
of energy: 54.4 million Mt (2010 esr.)
country comparison to the world: 59','83c1ca6ec24e3b9183067c29d7a8d8b0035db0c1199f5baaf64eb3952b3f960f','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('93bc30f0a19f45d17dd4ef23bdbe29903a2f5c66347b44abb2e49c6f54526a23',2025,'PF','French Polynesia','energy',630,'Electricity—production: 725 million kWh (2009
est.)
country comparison to the world: 155
Electricity—tconsumption: 674.3 million kWh
(2009 est.)
country comparison to the world: 161
Electricity—exports: 0 kWh (2010 est.)
country comparison to the world: 197
Electricity—imports: 0 kWh (2010 est.)
country comparison to the world: 189
Electricity—installed generating capacity:
140,000 kW (2009 est.)
country comparison to the world: 161
Electricity—from fossil fuels: 66.4% 6i total
instaneu capacity (2009 est.)
country comparison to the world: 118
Electricity—from nuclear fuels: 6% of total
installed capacity (2669 est.)
country comparison to the world: 91
Electricity—from hydroelectric plants: 33.6%
of total installed capacity (2669 est‘)
country comparison to the world: 65
Electricity—from other renewable sources: 0%
of total installed capacity (2669 est.)
country comparison to the world: 127
Crude oll—production: 0 bbi/day (2611 est.)
country comparison to the world: 137
Crude oil—exports: 0 bbl/day (2009 est.)
country comparison to the world: 114
Crude oil—imports: 0 bbl/day (2669 est.)
country comparison to the world: 186
Crude oil—proved reserves: 0 bbl (1 January
2012 est.) i : $ Í
country comparison to the world: 135
Refined petroleum products—production: 0
bbl/day (2008 est.)
THE CIA WORLD FACTBOOK
country comparison to the world: 149
Refined petroleum products—consumption:
8,000 bbi/day (2011 est.)
country comparison to the world: 159
Refined petroleum products—exports: 0 bbl/
day (2008 est.)
country comparison to the world: 179
Refined petroleum products—imports: 7,246
bbl/day (2008 est.)
country comparison to the world: 139
Natural gas—production: 0 cu m (2010 est.)
country comparison to the world: 132
Natural gas—consumpftion: 0 cu.m (2010 est.)
country comparison to the world: 145
Natural gas—exports: 0 cu m (2010 est.)
country comparison to the world: 161
Natural gas—imports: 0 cu m (2010 est.)
country comparison to the world: 195
Natural gas—proved reserves: 0 cu m (1 Janu-
ary 2012 est.)
country comparison to the world: 139
Carbon dioxide emissions from consumption
of energy: 1.221 million Mt (2010 est.)
country comparison to the world: 163','11b2b2e2e03054641fb7800d6aca47eb8339fed99c4253189322c3a68a3b9d85','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7a8761e1a4cf8474a5c62f83f532b83275c0db019f81d588f22d01a073ff2277',2025,'SN','Senegal','energy',651,'Electricity—production: 240 million kWh (2009
est.)
country comparison to the world: 178
Electricity—consumption: 223.2 million kWh
(2009 est.)
country comparison to the world: 183
Electricity—exports: 0 kWh (2010 est.)
country comparison. to the world: 198
Electricity—imports: 0 kWh (2010 est.)
country comparison to the world: 190
Electricity—installed generating capacity:
53,000 kW (2009 est.)
country comparison to the world: 181
Electricity—from fossil fuels: 100% of total
installed capacity (2009 est.)
country comparison to the world: 13
Electricity—from nuclear fuels: 0% of total
installed capacity (2009 est.)
country comparison to the world: 92
Electricity—from hydroelectric plants: 0% of
total installed capacity (2009 est.)
country comparison to the world: 171
Electricity—from other renewable sources: 0%
of total installed capacity (2009 est.)
country comparison to the world: 128
Crude oil—production: 0 bbl/day (2011 est.)
country comparison to the world: 138
Crude oil—exports: 0 bbi/day (2009 est.)
country comparison to the world: 116
Crude oil—imports: 0 bbl/day (2009 est.)
country comparison to the world: 187
Crude oii—proved reserves: 0 bbl (1 January
2012 est.)
country comparison to the world: 136
Refined petroleum products—production:
O bbl/day (2008 est.)
country comparison to the world: 150
Refined petroleum products—consumption:
3,181 bbl/day (2011 est.)
country comparison to the world: 179
Refined petroleum products—exports: 41.62
bbl/day (2008 est.)
country comparison to the world: 121
Refined petroleum products—imports: 2,913
bbl/day (2008 est.)
country comparison to the world: 169
Natural gas—production: 0 cu m (2010 est.)
country comparison to me worm: 133
Natural gas—consumption: 0 cu m (2010 est.)
country comparison to the world: 146
Natural gas—exports: 0 cu m (2010 est.)
country comparison to the world: 102
Natural gas—imports: 0 cu m (2010 est.)
country comparison to the world: 196
Natural gas—proved reserves: 0 cu m (1 Janu-
ary 2012 est.)
country comparison to the. world: 140
Carbon dioxide emissions from consumption
of energy: 291,000 Mt (2010 est.)
country comparison to the world: 189
Electricity—production: 51,000 kWh (2011 est.)
country comparison to the world: 218
Electricity—consumption: 202,000 kWh (2009)
country comparison to the world: 217
_ Electricity—exports: 0 kWh (2011 est.)
country comparison to the world: 206
Electricity—imports: 193,000 kWh (2011 est.)
country comparison to the world: 107
Crude oil—proved reserves: 0 bbl (1 January
2010 est.)
country comparison to the world: 143
Electricity—production: 2.608 billion kWh
(2009 est.) :
country comparison to the world: 131
Electricity—consumption: 2.123 billion kWh
(2009 est.)
country comparison to the world: 140
Electricity—exports: 0 kWh (2010 est.)
country comparison to the world: 127
Electricity—imports: 0 kWh (2010 est.)
country comparison to the world: 130
Electricity—installed generating capacity:
638,000 kW (2009 est.)
country comparison to the world: 131
639
Electricity—from fossil fuels: 99.7% of total
installed capacity (2009 est.)
country comparison to the world: 49
Electricity—from nuclear fuels: 0% of total
installed capacity (2009 est.)
country comparison to the world: 174
Electricity—from hydroelectric plants: 0% of
total installed capacity (2009 est.)
country comparison to the world: 197
Electricity—from other renewable sources:
0.3% of total installed capacity (2009 est.)
country comparison to the world: 82
Crude oil—production: 0 bbl/day (2011 est.)
country comparison to the world: 185
Crude oll—exports: 0 bbl/day (2009 est.)
country comparison to the world: 180
Crude oil—imports: 13,040 bbl/day (2009 est.)
country comparison to the world: 76
Crude oil—proved reserves: 0 bbl (1 January
2013 est.)
country comparison to the world: 184
Refined petroleum products—production:
16,850 bbl/day (2008 est.)
country comparison to the world: 98
Refined petroleum products—consumption:
40, 600 bbl/day (2011 est.)
country comparison to the world: 109
Refined petroleum products—exports: 7,046
bbl/day (2008 est.)
country comparison to the world; 93
Refined petroleum products—imports: 16,700
1 bbl/day (2008 est.)
country comparison to the world: 111
Natural gas—production: 50 million cu m (2010 est.)
country comparison to the world: 84
Natural gas—consumption: 50 million cu m
(2010 est.)
country comparison to the world: 109
Natural gas—exporfs: 0 cu m (2010 est.)
country comparison to the world: 176
Natural gas—imports: 0 cu m (2010 est.)
country comparison to the world: 127
Natural gas—proved reserves: NA cu m (1 Jan-
uary 2012 est.) (1 January 2012 est.)
Carbon dioxide emissions from consumption
of energy: 6.679 million Mr (2010 est.)
country comparison to the world: 114','2bb97aed9c165b2419da3945dba980a4d960fa1a374e7e34b348a6ebab4b2afb','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('655cb8aeaff5d72faa65219ae9c8b7e756794a7c37e0f519e456e970b3b60161',2025,'GE','Georgia','energy',656,'Electricity—production: . 9.694 billion kWh
(2012 est.)
country comparison to the world: 94
Electricity—consumption: 9.379 billion kWh
(2012 est.)
country comparison to the world; 92
Electricity—exports: 528 million kWh {2012
est.)
country comparison to the world: 59
Electricity—imports: 614 million kWh (2012
est.) f
country comparison to the world: 72
Electricity—installed generating capacity:
4.538 million kW (2009 est.)
country comparison to the world: 75
Electricity—from fossil fuels: 37.2%- of total
installed capacity (2009 est.)
country comparison to the world: 173
Electricity—from nuclear fuels: 0% of total
instalied capacity (2009 est.)
country comparison to the world: 94
Electricity—from hydroelectric plants: 62.8%
of total installed capacity (2009 est.)
country comparison to the world; 28
Electricity—from other renewable sources: 0%
of total installed capacity (2009 est.)
276
THE CIA WORLD FACTBOOK
country comparison to the world: 130
Crude oli—production: 979.5 bbi/day (2012
est.)
country comparison to the world: 99
Crude oil—exports: 531 bbl/day (2012 est.)
country comparison to the world: 67
Crude oll—imports: 0 bbl/day (2012 est.)
country comparison to the world: 189
Crude oil—proved reserves: 33.19 million bbl
(1 January 2012 est.)
country comparison to the world: 83
Refined petroleum products—production: 858
bbl/day (2008 est.)
country comparison to the world: 115
Refined petroleum products—consumption:
17,280 bbl/day (2011 est.)
country comparison to the world: 139
Refined petroleum products—exports: 0 bbl/.
day (2011 est.)
country comparison to the world: 180
Refined ` petroleum = products—imports:
18,500bbl/day (2008 est.)
country comparison to the world: 108
Natural gas—production: 9.151 million cu m
(2012 est.)
country comparison to the world: 91
Natural gas—consumption: 1.97 billion-cu m
(2012 est.)
country comparison to the world: 80
Natural gas—exports: 0 cu m (2012 est.)
country comparison to the world: 104
Natural gas—imports: 1.96 billion cu m (2012
est.)
country comparison to the world: 50
Natural gas—proved reserves: 93.41 billion
cu m (1 January 2012 est.)
country comparison to the world: 57
Carbon dioxide emissions from consumption
of energy: 5.302 million Mt (2010 est.)
country comparison to the world: 122','0a72d3d120f0eea7c58ebb6b60f9d4e308883260d0f71c4e8afdaa82167750ce','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ded76e42624ffc9919c9bb784302524b42381ab3b4361b7825096923aa20e1b3',2025,'DE','Germany','energy',666,'Electricity—production: 558 billion kWh (2010
est.)
country comparison to the world: 9
Electricity—consumption: 549.1 billion kWh
(2010 est.)
country comparison to the world: 8
280
THE CIA WORLD FACTBOOK
Electricity—exports: 57.92 billion kWh (2010 est.)
country comparison to the world: 4
Electricity—imports: 42.96 billion kWh (2010
est.)
country comparison to the world: 5
Electricity—installed generating capacity:
153.2 million kW (2010 est.)
country comparison to the world: 7
Electricity—from fossil fuels: 55% of total
installed capacity (2011 est.)
country comparison to the world: 145
Electricity—from nuclear fuels: 23% of total
installed.capacity (2011 est.)
country comparison to the world:7 -
Electricity—from hydroelectric plants: 3% of
total installed capacity (2011 est.)
country comparison to the world: 131
Electricity—from other renewable sources:
13% of total installed capacity (2011 est.)
country comparison.to the world: 15
Crude oil—production: 165,300 bbl/day (2011
est.)
country comparison to the world: 43
Crude oil—exports: 2,200 bbl/day (2009 est.)
country comparison to the world: 65
Crude oil—imports: 1.961 million bbi/day (2009
est.) ; E
country comparison to the world: 7
Crude oil—proved reserves: 276 million bbl
(1 January 2012 est.)
country comparison to the world: 57
Refined petroleum products—production:
2.348 million bbl/day (2009 est.)
country comparison to the world: 9
Refined petroleum products—consumption:
2.4 million bbl/day (2011 est.)
country comparison to the world: 10
Refined petroleum products—exports: 467,900
bbl/day (2009 est.)
country comparison to the world: 16
Refined petroleum products—imports: 696,400
bbl/day (2009 est.)
country comparison to the world: 10
Natural gas—production: 11.9 billion cu m
(2011 est.)
country comparison to the world: 40
Natural gas—consumption: 78.99 billion cu m
(2011 est.)
country comparison to the world: 11
Natural gas—exports: 19.74 billion cu m (2011
est.)
country comparison to the world: 17
Natural gas—imports: 87.57 billion cu m (2011
est.)
country comparison to the world: 5
Natural gas—proved reserves: 175.6 billion
cu m (1 January 2012 est.)
country comparison to the world: 48
Carbon dioxide emissions from consumption
. Of energy: 793.7 million Mt (2010 est.)
country comparison to the world:7 »','1aa7dc1871ea9f9175651c466303ca0d92137d55cf7d46e72cd587853647c36c','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('020e86914d09a97ee8c5789f04bb443d828072471423e4e541cc28466c1a307f',2025,'GH','Ghana','energy',675,'Electricity—production: 8.764 billion kWh
(2009 est.)
country comparison to the world: 98
Electricity—consumption: 6.122 billion kWh
(2009 est.)
country comparison to the world: 105
Electricity—exports: 752 million kWh (2009
est.) j
country comparison to the world: 57
Electricity—imports: 198 million kWh (2009
est.)
country comparison to the world: 88
Electricity—instalied generating capacity:
1.985 million kW (2009 est.)
country comparison to the world: 102
Electricity—from fossil fuels: 40.6% of total
installed capacity (2009 est.)
country comparison to the world: 169
Electricity—from nuclear fuels: 0% of total
installed capacity (2009 est.)
country comparison to the world: 95
Electricity—from hydroelectric plants: 59.4%
of total installed capacity (2009 est.)
country comparison to the world: 34
Electricity—from other renewable sources: 0%
of total installed capacity (2009 est.)
country comparison to the world: 131
Crude oil—production: 72,580 bbl/day (2011
est.)
country comparison to the world: 54
Crude oll—exports: 14,000 bbl/day (2011 est.)
country comparison to the world: 55
Crude oil—imports: 43,000 bbl/day (2009 est.)
284
THE CIA WORLD FACTBOOK
country comparison to the world: 59
Crude oll—proved reserves: 660 million bbl
(1 January 2012 est.)
country comparison to the world: 45
Refined petroleum products—production:
27,260 bbl/day (2008 est.)
country comparison to the world: 93
Refined petroleum products—consumption:
61,590 bbl/day (2011 est.)
country comparison to the world: 93
Refined petroleum products—exporis: 7,275
bbl/day (2008 est.)
country comparison to the world: 92
Refined petroleum products—imports: 24,390
bbl/day (2008 est.)
country comparison to the world: 96
Natural gas—production: 0 cu m (2010 est.)
country comparison to the world: 134
Natural gas—consumption: 120 million cu m
(2010 est.)
country comparison to the world: 104
Natural gas—exports: 0 cu m (2010 est.)
country comparison to the world: 105
Natural gas—imports: 120 million cu m (2010
est.) ar
country comparison to the world: 73
Natural gas—proved reserves: 22.65 billion
cu m (1 January 2012 est.)
country comparison to the world: 77
Carbon dioxide emissions from consumption
of energy: 10.58 million Mt (2010 est.)
country comparison to the world: 100','b7867b216a1c2727581227d78993c154b1a2b8711bdd576ff6330dbfd16c0a96','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f8e32d38b466b4e23a60e2b2a3ffc3d962b7336b79fb6fae4e0f96bf284733ce',2025,'ES','Spain','energy',684,'Electricity—production: 164 million kWh (2009
est.)
country comparison to the world: 185
Electricity—consumption: 152.5 million kWh
(2009 est.)
country comparison to the world: 190
Electricity—exports: 0 kWh (2010 est.)
country comparison to the world: 200
Etectricity—imports: 0 kWh (2010 est.)
country comparison to the world: 192
Electricity—installed generating capacity:
36,000 kW (2009 est.)
country comparison to the world: 188
Electricity—from fossil fuels: 100% of total
installed capacity (2009 est.)
country comparison to the world: 14
Electricity—from nuclear fuels: 0% of total
installed capacity (2009 est.)
country comparison to the world: 96
Electricity—from hydroelectric plants: 0% of
total installed capacity (2009 est.)
country comparison to the world: 172
Electricity—from other renewable sources: 0%
of total installed capacity (2009 est.)
country comparison to the world: 132
Crude oil—production: 0 bbl/day (2011 est.)
country comparison to the world: 139
Crude oil—exports: 0 bbl/day (2009 est.)
country comparison to the world: 117
Crude oil—imports: 0 bbl/day (2009 est.)
country comparison to the world: 190
Crude oil—proved reserves; O bb! (1 January
2012 est.)
country comparison to the world: 137
Refined petroleum products—production:
O bbl/day (2008 est.)
country comparison to the world: 151
Refined petroleum products—consumption:
24,920 bbl/day (2011 est.)
country comparison to the world: 123
Refined petroleum products—exports: 0 bbl/
day (2008 est.)
country comparison to the world: 181
Refined petroleum products—imports: 27,000
bbi/day (2008 est.)
country comparison to the world: 91
Natural gas—production: 0 cu m (2010 est.)
country comparison to the world: 135
Natural gas—consumption: 0 cu m (2010
est.)
country comparison to the world: 147
Natural gas—exports: 0 cu m (2010 est.)
country comparison to the world: 106
Natural gas—imports: 0 cu m (2010 est.)
country comparison to the world: 198
Natural gas—proved reserves: 0 cu m (1 Janu-
ary 2012 est.)
country comparison to the world: 141
Carbon dioxide emissions from consumption
of energy: 3.908 million Mt (2010 est.)
country comparison to the world: 130','c23b5bd9585b5a5ab04a5110aff00f886324f5990c22537217cc875fa78ee3f6','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('089e476e2ad499eb7fff43b5908bcec6e5291ee1aef4c8f12a0832d868901bfc',2025,'GR','Greece','energy',696,'Electricity—production: 57.11 billion kWh
(2010 est.)
country comparison to the world: 46
Electricity—consumption: 58.71 billion kWh
(2009 est.)
country comparison to the world: 44
Electricity—exports: 2.571 billion kWh (2010
est.)
country comparison to the world: 40
Electricity—imports: 8.517 billion kWh (2010
est.)
country comparison to the world: 27
Electricity—installed generating capacity:
14.36 million kW (2009 est.)
country comparison to the world: 46
Electricity—from fossil fuels: 70.5% of total
installed capacity (2009 est.)
country comparison to the world: 105
Electricity—from nuclear fuels: 0% of total
installed capacity (2009 est.)
country comparison to the world: 100
Electricity—from hydroelectric plants: 17% of
total installed capacity (2009 est.)
country comparison. to the world: 100
Electricity—from other renewable sources:
8.5% of total installed capacity (2009 est.)
country comparison to the world: 24
Crude oll—production: 1,751 bbl/day (2011 est.)
country comparison to the world: 95
Crude oil—exports: 19,960 bbl/day (2009 est.)
country comparison to the world: 53
Crude oll—imports: 355,600 bbl/day (2009 est.)
country comparison to the world: 25
Crude oll—proved reserves: 10 million bbl
(1 January 2012 est.)
country comparison to the world: 93
Refined petroleum products—production:
440,200 bbl/day (2009 est.)
country comparison to the world: 35
Refined petroleum products—consumption:
343,400 bbl/day (2011 est.)
country comparison to the world: 36
Refined petroleum products—exports: 161,400
bbl/day (2009 est.)
country comparison to the world: 36
Refined petroleum products—imports: bbl/day
(2009 est.)
country comparison to the world: 41
Natural gas—production: 1 million cu m (2010 est.)
country comparison to the world: 93
Natural gas—consumption: 4.737 billion cu m
(2011 est.)
country comparison to the world: 63
Natural gas—exports: 0 cu m (2011 est.)
country comparison to the world: 110
Natural gas—imports: 4.762 billion cu m (2011 est.)
country comparison to the world: 34
Natural gos—proved reserves: 991.1 million
cum (1 January 2012 est.)
country comparison to the world: 101
Carbon dioxide emissions from consumption
of energy: 92.99 million Mr (2010 est.)
country comparison to the world: 40','dc27a4310b8ae8f9c0a86d564dad8effbbbc12fe105e1430e4a74033eddbcb8f','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9f8d46a0c2e5d79377aabfbc2c432d598bec187f90bfeb2efc83475326484874',2025,'GL','Greenland','energy',701,'Electricity—production: 276.6 million kWh
(2010 est.)
country comparison to the world: 175
Electricity—consumption: 239.4 million kWh
(2010 est.)
country comparison to the world: 181
Electricity—exports: 0 kWh (2010 est.)
country comparison to the world: 202
Electricity—imports: 0 kWh (2010 est.)
country comparison to the world: 194
Electricity—installed generating capacity:
137,000 kW (2009 est.)
country comparison to the world: 163
Electricity—from fossil fuels: 100% of total
installed capacity (2009 est.)
country comparison to the world: 16
Electricity—from nuciear fuels: 0% of total
installed capacity (2009 est.)
country comparison to the world: 98
Electricity—from hydroelectric plants: 0% of
total installed capacity (2009 est.)
country comparison to the world: 174
Electricity—from other renewable sources: 0%
of total installed capacity (2009 est.)
country comparison to the world: 134
Crude oll—production: 0 bbi/day (2011 est.)
country comparison to the world: 141
Crude oil—exports: 0 bbl/day (2009 est.)
country comparison to the world: 119
Crude oil—imports: 0 bbl/day (2009 est.)
country comparison to the world: 192
Crude oii—proved reserves: 0 bbl (1 January
2012 est.)
country comparison to the world: 139
Refined petroleum products—production:
0 bbl/day (2008 est.)
country comparison to the world: 153
Refined petroleum products—consumption:
3,897 bbl/day (2011 est.)
country comparison to the world: 176
Refined petroleum products—exports: 1,034
bbl/day (2008 est.)
country comparison to the world: 110
Refined petroleum products—imports: 5,376
bbl/day (2008 est.)
country comparison to the world: 152.
Natural gas—production: 0 cu m (2010 est.)
country comparison to the world: 137
Natural gas—consumption: 0 cu m (2010
est.)
country comparison to the world: 149
Natural gas—exports: 0 cu m (2010 est.)
country comparison to the world: 108
Natural gas—imports: 0 cu m (2010 est.)
country comparison to the world: 200
Natural gas—proved reserves: 0 cu m (1 Janu-
ary 2012 est.)
country comparison to the world: 143
Carbon dioxide emissions from consumption
of energy: 555,600 Mt (2010 est.)
country comparison to the world: 178','f0727e23a36db204da7b80a6c7dd52c8a3aa0c98f546809e52d114a9f58a5f9e','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('36160afe8c2b74af7a3d92391d7ce0156af54fe67ded117a2784e7abd1a62d44',2025,'GD','Grenada','energy',714,'Electricity—production: 1.755 billion kWh
(2009 est.)
country comparison to the world: 136
Electricity—consumption: 1.632 billion kWh
(2009 est.)
country comparison to the world: 143
Electricity—exports: 0 kWh (2010 est.)
country comparison to the world: 203
Electricity—imports: 0 kWh (2010 est.)
country comparison to the world: 195
Electricity—installed generating capacity:
553,000 kW (2009 est.)
country comparison to the world: 134
Electricity—from fossil fuels: 100% of total
installed capacity (2009 est.)
country comparison to the world: 17
Electricity—from nuclear fuels: 0% of total
installed capacity (2009 est.)
country comparison to the world: 99
Electricity—from hydroelectric plants: 0% of
total installed capacity (2009 est.)
country comparison to the world: 175
Electricity—from other renewable sources: 0%
of total installed capacity (2009 est.)
country comparison to the world: 135 °
Crude oil—production: 0 bbi/day (2011 est.)
country comparison to the world: 142
Crude oii—exports: 0 bbl/day (2009 est.)
country comparison to the world: 120
Crude oil—imports: 0 bbl/day (2009 esr.)
country comparison to the world: 193
Crude oil—proved reserves: 0 bb! (1 January
2012 est.)
country comparison to the world: 140
Refined petroleum products—production:
0 bbl/day (2008 est.)
country comparison to the world: 154
Refined petroleum products—consumption:
14,490 bbl/day (2011 est.)
country comparison to the world: 146
Refined petroleum products—exports: 0 bbl/
day (2008 est.)
country comparison to the world: 183
Refined petroleum products—imports: 0 bbl/
day (2008 est.)
country comparison to the world: 212
Natural gas—production: 0 cu m (2010 est.)
country comparison to the world: 138
Natural gas—consumption: 0 cu m (2010 est.)
country comparison to the world: 150
Natural gas—exports: 0 cu m (2010 est.)
country comparison to the world: 109
Natural gas—imports: 0 cu m (2010 est.)
country comparison to the world: 201
Natural gas—proved reserves: 0 cu m (1 Janu-
ary 2012 est.)
country comparison to the world: 144
Carbon dioxide emissions from consumption
of energy: 1.451 million Mt (2010 est.)
country comparison to the world: 156','485cf58321d988b90b204b18aeddfe705b57053c13d497648ae4dafe3e271609','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('46e46f2eb4444a7d00e1140b2803054b39b15d2eabcfc3627b3eecf8dbbee7a7',2025,'GT','Guatemala','energy',715,'Electricity—production: 8.146 billion kWh
(2011 est.)
country comparison to the world: 99
Electricity—consumption: 8.161 billion kWh
(2011 est.)
country comparison to the world:94
Electricity—exports: 193.3 million kWh (2011
est.)
country comparison to the world: 67
Electricity—imports: 525.6 million kWh (2011
est.).
country comparison to the world: 77
Electricity—instalied generating capacity:
2.673 million kW (2009 est.)
country comparison to the world: 91
Electricity—from fossil fuels: 58.2% of total
installed capacity (2009 est.)
country comparison to the world: 141
Electricity—from nuclear fuels: 0% of total
installed capacity (2009 est.)
country comparison to the world: 101
Electricity—from hydroelectric plants:% of
total installed capacity (2009 est.)
country comparison to the world: 79
Electricity—from other renewable sources:
12.7% of total installed capacity (2009 est.)
country comparison to the world: 19
Crude oil—production: 10,000 bbl/day (2011
est.) ; -
country comparison to the world: 81
Crude oii—exports: 12,620 bbl/day (2009 est.)
country comparison to the world: 57
Crude oil—imports: 0 bbl/day (2009 est.)
country comparison to the world: 194
Crude oll—proved reserves: 83.07 million bbl
(1 January 2012 est.)
country comparison to the world: 77
Refined petroleum products—production:
1,132 bbl/day (2008 est.)
country comparison to the world: 114
Refined petroleum products—consumption:
80,810 bbl/day (2011 est.)
country comparison to the world: 86
Refined petroleum products—exports: 4,162
bbl/day (2008 est.)
country comparison to the world: 98
Refined petroleum products—imports: 68,910
bbl/day (2008 est.)
country comparison to the world: 57
Natural gas—production: 0 cu m (2010 est.)
country comparison to the world: 139
Natural gas—consumption: 0 cu m (2010 est.)
country comparison to the world: 151
Natural gas—exports: 0 cu m (2010 est.)
country comparison to the world: 111
Natural gas—imports: 0 cu m (2010 est.)
country comparison to the world: 202
Natural gas—proved reserves: 2.96 billion cum
(1 January 2006 est.)
country comparison to the world: 95
Carbon dioxide emissions from consumption
of energy: 12.97 million Mt (2010 est.)
country comparison to the world: 94','2a02383fe5633e0af6d693a46e6122fcde9d58950f72bbe55796587445f29ae8','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('232c2f6b74415544a1d727970c19886a91c073cf6c5b3d9d6d9edfa40395f183',2025,'GN','Guinea','energy',732,'Electricity—production: 955 million kWh (2009 est.)
country comparison to the world: 148
Electricity—consumption: 888.2 million kWh
(2009 est.)
country comparison to the world: 153
Electricity—exports: 0 kWh (2010 est.)
country comparison to the world: 204
Electricity—imports: 0 kWh (2010 est.)
country comparison to the world: 196 _
Electricity—installed generating capacity:
393,000 kW (2009 est.)
country comparison to the world: 144
Electricity—from fossil fuels: 68.7% of total
installed capacity (2009 est.)
country comparison to the world: 111
Electricity—from nuclear fuels: 0% of total
installed capacity (2009 est.) -
country comparison to the world: 102
Electricity—from hydroelectric plants: 31.3%
of total installed capacity (2009 est.)
country comparison to the world: 72
307
Electricity—from other renewable sources: 0%
of total installed capacity (2009 est.)
country comparison to the world: 136
Crude ofl—production: 0 bbl/day (2011 est.)
country comparison to the world: 143
Crude oil—exports: 0 bbl/day (2009 est.)
country comparison to the world: 121
Crude oil—imports: 0 bbl/day (2009 est.)
country comparison to the world: 195
Crude oil—proved reserves: bbl (1 January
2012 est.)
country comparison to the world: 141
Refined petroleum products—production:
0 bbl/day (2008 est.)
country comparison to the world: 155
Refined petroleum products—consumption:
8,671 bbl/day (2011 est.)
country comparison to the world: 157
Refined petroleum products—exports: 0 bbl/
day (2008 est.)
country comparison to the world: 184
Refined petroleum products—imports: 8,970
bbl/day (2008 est.)
country comparison to the world: 134
Natural gas—production: 0 cu m (2010 est.)
country comparison to the world: 140
Natural gas—consumption: 0 cu m (2010 est.)
country comparison to the world: 152
Natural gas—exports: 0 cu m (2010 est.)
country comparison to the world: 112
Natural gas—imports: 0 cu m (2010.est.)
country comparison to the world: 203
Natural gas—proved reserves: 0 cu m (1 Janu-
ary 2012 est.)
country comparison to the world: 145
Carbon dioxide emissions from consumption
of energy: 1.392 million Mt (2010 est.)
country comparison to the world: 158','7a94ee87fc809499c9237fb9ea6b2db77b0bb42fd9b3e08c7335e885e508d910','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('090219e0568bd2e003e2ba0c6ef67e7264263dd9463cb8fbfad59eeac844a8a7',2025,'GY','Guyana','energy',752,'Electricity—production: 817 million kWh (2009
est.)
country comparison to the world: 153
Electricity—consumption: 683 million kWh
(2009 est.)
country comparison to the world: 160
Electricity—exports: 0 kWh (2010 est.)
country comparison to the world: 205
Electricity—imports: 0 kWh (2010 est.)
country comparison to the world: 197
Electricity—installed generating capacity:
343,000 kW (2009 est.)
country comparison to the world: 147
Electricity—from fossil fuels: 99.7% of total
installed capacity (2009 est.)
country comparison to the world: 52
Electricity—from nuclear fuels: 0% of total
installed capacity (2009 est.)
country comparison to the world: 103
Electricity—from hydroelectric plants: 0.3% of
total installed capacity (2009 est.)
country comparison to the world: 147
Electricity—from other renewable sources: 0%
of total installed capacity (2009 est.)
country comparison to the world: 137
Crude oil—production: 0 bbi/day (2011 est.)
_ country comparison to the world: 144
Crude oil—exports: 0 bbl/day (2009 est.)
country comparison to the world: 122
Crude oll—imports: 0 bbl/day (2009 esr.)
country comparison to the world: 196
Crude oil—proved reserves: 0 bbl (1 January
2012 est.)
country comparison to the world: 142
Refined petroleum products—production:
O bbl/day (2008 est.)
country comparison to the world: 156
Refined petroleum products—consumption:
10,910 bbl/day (2011 est.) i
country comparison to the world: 152
Refined petroleum products—exports: © bbl/
day (2008 est.)
country comparison to the world: 185
Refined petroleum products—imports:
10,680 bbl/day (2008 est.)
country comparison to the world: 132
Natural gas—production: 0 cu m (2010 est.)
country comparison to the world: 141
Natural gas—consumption: 0 cu m (2010 est.)
country comparison to the world: 153
Naturat gas—exports: 0 cu m (2010 est.)
country comparison to the world: 113
Natural gas—imports: 0 cu m (2010 est.)
country comparison to the world: 204
Natural gos—proved reserves: 0 cu m (1 Janu-
ary 2012 est.)
country comparison to the world: 146
Carbon dioxide emissions from consumption
of energy: 1.52 million Mt (2010 est.)
country comparison to the world: 154','e2a182d4bc978461e7e549a88ba6b6fa2fed378758166bed2117d6486787d8bc','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('850fd64a59b67e4d64491849c5045e9c44691b0c75ce799d22f937cde815c299',2025,'HN','Honduras','energy',778,'Electricity—production: 6.326 billion kWh
(2009 est.)
country comparison to the world: 111
Electricity—consumption: 4.8 billion kWh
(2009 est.)
country comparison to the world: 115
Electricity—exports: 46 million kWh (2009 est.)
country comparison to the world: 78
Electricity—Iimports: 100,000 kWh (2009 est.)
country comparison to the world: 108
Electricity—installed generating capacity:
1.697 million kW (2009 est.)
country comparison to the world: 109
Electricity—from Tossil fuels: 63.9% of total
installed capacity (2009 est.) À
country comparison to the world: 133
Electricity—from nuclear fuels: 0% of total
installed capacity (2009 est.)
country comparison to the world: 106
Electricity—from hydroelectric plants: 30.8%
of total installed capacity (2009 est.)
country comparison to the world: 76
Electricity—from other renewable sources:
5.4% of total installed capacity (2009 est.)
country comparison to the world: 34
Crude oil—production: 0 bbi/day (2011 est.)
country comparison to the world: 147
Crude oil—exports: 0 bbl/day (2009 est.)
country comparison to the world: 125
Crude ojl—imports: 0 bbl/day (2009 est.)
country comparison to the world: 199
Crude oil—proved reserves: 0 bbl (1 January
2012 est.)
country comparison to the world: 146
Refined petroleum products—production: 0
bbi/day (2008 est.)
country comparison to the world: 159
Refined petroleum products—consumption:
58,150 bbl/day (2011 est.)
country comparison to the world: 96
Refined petroleum products—exports: 8,419
bbl/day (2008 est.)
country comparison to the world: 91
Refined petroleum products—imports: 54,100
bbi/day (2008 est.)
country comparison to the world: 66
Natural gas—production: 0 cu m (2010 est.)
country comparison to the world: 144
Natural gas—consumption: 0 cu m (2010 est.)
country comparison to the world: 155
Natural gas—exports: 0 cu m (2010 est.)
country comparison to the world: 116
Natural gas—imports: 0 cu m (2010 est.)
country comparison to the world: 206
Natural gas—proved reserves: 0 cu m (1 Janu-
ary 2012 est.)
country comparison to the world: 149
Carbon dioxide emissions from consumption
of energy: 8.288 million Mr (2010 est.)
country comparison to the world: 106','f21ee38d5a7540a072cd8c6d9943853c4ca5dd9d3240b17047f8ceda88b27269','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b026d318f67a6003e30b9f73a69d605e41c3f10af9413d9ba4c1d4a6e785156e',2025,'HK','Hong Kong','energy',787,'Electricity—production: 41.3 billion kWh (2012
est.)
country comparison to the world: 57
Electricity—consumption: 45.07 billion kWh
(2012 est.)
country comparison to the world: 50
Electricity—exports: 497.4 million kWh (2012
est.)
country comparison to the world: 61
Electricity—Imports: 11.15 billion kWh (2012
est.)
country comparison to the world: 18
Electricity—installed generating capacity:
10.66 million kW (2012 est.)
country comparison to the world: 53
Electricity—from fossil fuels: 100% of total
installed capacity (2012 est.)
country comparison to the world: 18
Electricity—from nuclear fuels: 0% of total
installed capacity (2012 est.)
country comparison to the world: 105
Electricity—from hydroelectric plants: 0% of
total installed capacity (2012 est.)
country comparison to the world: 176
Electricity—trom other renewable sources: 0%
of total installed capacity (2012 est.)
country comparison to the world: 139
Crude oil—production: 0 bbl/day (2012 est.)
country comparison to the world: 146
Crude oll—exports: 0 bbl/day (2012 est.)
country comparison to the world: 124
Crude oil—imports: 0 bbl/day (2012 est.)
country comparison to the world: 198
Crude oll—proved reserves: 0 bbl (1 January
2012 est.)
country comparison to the world: 145
Refined petroleum products—production: 0
bbl/day (2012 est.)
country comparison to the world: 158
Refined petroleum products—consumption:
337,600 bbl/day (2012 est.)
country comparison to the world: 38
Refined petroleum products—exports: 16,520
bbl/day (2012)
country comparison to the world: 78
Refined petroleum products—imports: 354,100
bbl/day (2012 est.)
country comparison to the world: 19
Natural gas—production: 0 cu m (2012 est.)
country comparison to the world; 143
328
THE CIA WORLD FACTBOOK
Natural gas—consumption: 2.79 billion cu m
(2012 est.)
country comparison to the world: 76
Natural gas—exports: 0 cu m (2012 est.)
country comparison to the world: 115
Natural gas—imports: 2.79 billion cu m (2012
est.)
country comparison to the world: 45
Natural gas—proved reserves: 0 cu m (1 Janu-
ary 2012 est.)
country comparison to the world: 148
Carbon dioxide emissions from consumption
of energy: 39.3 million Mr (2009 est.)
country comparison to the world: 71','596e62d7c9f026874d79ff0616604b153472d8652b356b7427e84fbf5b926ad1','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6b31f07fe04ed2a8f1134d7eace118f1d76a84d636bc4d450942724f3af65e87',2025,'HU','Hungary','energy',795,'Electricity—production: 34.28 billion kWh
(2012 est.)
country comparison to the world: 64
Electricity—consumption: 36.13 billion kWh
(2012 est.)
country comparison to the world: 56
Electricity—exports: 9 billion kWh (2012 est.)
country comparison to the world: 23
Electricity—imports: 16.97 billion kWh (2012
est.) l
country comparison to the world: 10
Electricity—installed generating capacity: 9.9
million kW (2011 est.)
country comparison to the world: 57
Electricity—from fossil fuels: 72% of total
installed capacity (2011 est.)
country comparison to the world: 103
Electricity—from nuclear fuels: 20% of total
installed capacity (2011 est.)
country comparison to the world: 12
Electricity—trom hydroelectric plants: 1% of
total installed capacity (2011 est.)
country comparison to the world: 142
Electricity—from other renewable sources: 7%
of total installed capacity (2011 est.)
country comparison to the world: 29
Crude oil—production: 22,560 bbl/day (2011 est.)
country comparison to the world: 70
Crude oil—exports: 0 bbi/day (2009 est.)
country comparison to the world: 127
Crude oil—imports: 108,500 bbl/day (2009 est.)
country comparison to the world: 48
Crude oil—proved reserves: 31.72 million bbl
(1 January 2012 est.)
country comparison to the world: 84
Refined petroleum products—production:
167,900 bbl/day (2009 est.)
country comparison to the world: 60
Refined petroleum products—consumption:
141,100 bbl/day (2011 est.)
country comparison to the world: 71
Refined petroleum products—exports: 49,010
bbl/day (2010 est.)
country comparison to the world: 61
Refined petroleum products—imports: 171,600
bbl/day (2009 est.)
country comparison to the world: 32
Natural gas—production: 2.072 billion cu m
¢(2012 est.)
country comparison to the world: 56
Natural gos—consumption: 11.9 billion cu m
(2012 est.)
country comparison to the world: 45
Natural gas—exports: 835 million cu m (2012
est.)
country comparison to the world: 41
Natural gos—imports: 8.173 billion cu m (2012 est.)
country comparison to the world: 29
Natural gos—proved reserves: 3.014 billion cu m
(1 January 2013 est.)
country comparison to the world: 94
Carbon dioxide emissions from consumption
of energy: 50.39 million Mt (2010 est.)
country comparison to the world: 61','bf27e23b5d9219e278078587c4ef6a0a843cef993423ba3ee892dacd5fbf0fc4','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1a09c4cc132e92ffb43614637e05a7cda53cbd1cbb8a5f084ff3561d902cb0e1',2025,'IN','India','energy',811,'Electricity—production: 880 billion kWh (2010
est.)
country comparison to the world: 7
Electricity—consumption: 637.6 billion kWh
(2009 est.)
country comparison to the world: 7
Electricity—exports: 519 million kWh (2009
est.)
country comparison to the world: 60
Electricity—imports: 10.53 billion kWh (2009 est.)
country comparison to the world: 21
Electricity—installed generating capacity:
189.3 million kW (2009 est.)
country comparison to the world: 6
Electricity—from fossil fuels: 69.9% of total
installed capacity (2009 est.)
country comparison to the world: 107
Electricity—from nuclear fuels: 2.2% of total
installed capacity (2009 est.)
country comparison to the world: 29
Electricity—from hydroelectric plants: 20.9%
of total installed capacity (2009 est.)
country comparison to the world: 90
Electricity—from other renewable sources: 7%
of total installed capacity (2009 est.)
country comparison to the world: 30
Crude oll—production: 897,300 bbl/day (2011
est.)
country comparison to the world: 25
Crude oll—exports: 0 bbl/day (2009 est.)
country comparison to the world: 129
Crude oll—imports: 2.768 million bbl/day (2009
est.)
country comparison to the world: 5
Crude oll—proved reserves: 8.935 billion bbl
(1 January 2012 est.)
country comparison to the world: 20
Refined petroleum products—production:
3,226 million bbl/day (2008 est.)
country comparison to the world: 7
Refined petroleum products—consumption:
3.292 million bbl/day (2011 est.)
country comparison to the world: 7
Refined petroleum products—exports: 812,100
bbl/day (2008 est.)
339
country comparison to the world: 9
Refined petroleum products—jmports: 380,900
bbl/day (2008 est.)
country comparison to the world: 16
Natural gas—production: 46.1 billion cu m
(2011 est.)
country comparison to the world: 22
Natural gas—consumption: 61.1 billion cu m
(2011 est.)
country comparison to the world: 13
Natural gas—exports: 0 cu m (2011 est.)
country comparison to the world: 118
Natural gos—imports: 12.15 billion cu m (2011 est.)
country comparison to the world: 24
Natural gas—proved reserves: 1.154 trillion cum
(1 January 2012 est.)
country comparison to the world: 25
Carbon dioxide emissions from consumption
of energy: 1.696 billion Mt (2010 est.)
country comparison to the world: 4','84b92b7b3cbe9bc933a52f328120cabb6e048666699dbd448d5e79d555293c16','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('87285bd6d02174b41a500c28da4b1f01c917b2e3b82a5efe8e529f2c47f7d942',2025,'IQ','Iraq','energy',823,'Electricity—production: 47.4 billion kWh (2010
est.)
country comparison to the''world: 53
Electricity—consumption: 35.12 billion kWh
(2010 est.)
. country comparison to the world: 57
Electricity—exports: 0 kWh (2012 est.)
country comparison to the world: 210
Electricity—imports: 12.28 billion kWh (2012
est.)
country comparison to the world: 16
Electricity—instailed generating capacity:
10.11 million kW (2012 est.)
country comparison to the world: 56
Electricity—from fossil fuels: 69% of total
installed capacity (2012 est.)
country comparison to the world: 110
Electricity—from nuclear fuels: 0% of total
installed capacity (2012 est.)
country comparison to the world: 114
Electricity—from hydroelectric plants: 31% of
total installed capacity (2012 est.)
country comparison to the world: 73
Electricity—from other renewable sources: 0%
of total installed capacity (2012 est.) `
country comparison to the world: 141
Crude oil—production: million bbl/day (2012
est.)
country comparison to the world: 10
Crude oll—exports: million bbl/day (2012 est.)
country comparison to the world: 4
Crude olli—imports: bbl/day (2012 est.)
country comparison to the world: 202
Crude oil—proved reserves: 143.1 billion bbl
(1 January 2012 est.)
country comparison to the world: 6
Refined petroteum products—production:
410,500 bbl/day (2008 est.)
country comparison to the world: 38
Refined petroleum products—consumption:
818,000 bbl/day (2011 est.)
food,
medicine,
354
THE CIA WORLD FACTBOOK
country comparison to the world: 23
Refined petroleum products—exports: bbl/day
(2008 est.)
country comparison to the world: 187
Refined petroleum products—imports: 144,100
bbl/day (2008 est.)
country comparison to the world: 40
Natural gas—production: 1.303 billion cu m
(2010 est.)
country comparison to the world: 63
Natural gas—consumption: billion cu m (2010
est.)
country comparison to the world: 85
Natural gas—exports: 0 cu m (2010 esr.)
country comparison to the world: 121
Natural gas—imports: 0 cu m (2010 est.)
country comparison to the world: 210
Natural gas—proved reserves: trillion cu m
, (1 January 2012 est.)
country comparison to the world: 14
Carbon dioxide emissions from consumption
of energy: 118.3 million Mt (2010 est.)
country comparison to the world: 36','6c113bf7c692a6aa718abb21435255e602699f3aebc70fcd69bbaa3bb67ddb2a','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1aa2c1deeba0ce41e36b143c92ed49dd2211cf0fb20643fa5e200d5b0906ff84',2025,'IE','Ireland','energy',829,'Electricity—production: 26.35 billion kWh
(2011 est.)
country comparison to the world: 69
Electricity—consumption: 26.1 billion kWh -
(2011 est.)
country comparison to the world: 67
Electricity—exports: 242 million kWh (2011 est.)
country comparison to the world: 66
Electricity—imports: 732 million kWh (2011 est.)
country comparison to the world: 69
Electricity—installed generating capacity:
7.401 million kW (2009 est.)
country comparison to the world: 65
Electricity—from fossil fuels: 75.3% of total
installed capacity (2009 est.)
country comparison to the world: 99
Electricity—from nuclear fuels: 0% of total
installed capacity (2009 est.)
country comparison to the world: 82
Electricity—from hydroelectric plants: 3.2% of
total installed capacity (2009 est.)
country comparison to the world: 129
Electricity—from other renewable sources:
17.5% of total installed capacity (2009 est.)
country comparison to the world: 8
Crude oil—production: 0 bbl/day (2011 est.)
country comparison to the world: 129
Crude oil—exports: 0 bbl/day (2009 est.)
country comparison to the world: 105
Crude oll—imports: 53,560 bbl/day (2009 est.)
country comparison to the world: 56
Crude oll—proved reserves: 0 bbl (1 January
2012 est.)
country comparison to the world: 127
Refined petroleum products—production:
55,340 bbl/day (2009 est.)
country comparison to the world: 84
Refined petroleum products—consumption:
144,000 bbl/day (2011 est.)
country comparison to the world: 70
Refined petroleum products—exports: 17,480
bbl/day (2010 est.)
country comparison to the world: 76
358
THE CIA WORLD FACTBOOK
Refined petroleum products—imports: 166,000
bbl/day (2009 est.)
country comparison to the world: 34
Natural gas—production: 346 million cu m
(2011 est.)
country comparison to the world: 73
Natural gas—consumption: 4.981 billion cu m
(2011 est.)
country comparison to the world: 60
Natural gas—exports: 0 cu m (2011 est.)
country comparison to the world: 92
Natural gas—imports: 4.633 billion cu m (2011
est.)
country comparison to the world: 35
Natural gas—proved reserves: 9.911 billion cum
(1 January 2012 est.)
country comparison to the world: 81
Carbon dioxide emissions from consumption
of energy: 40.48 million Mt (2010 est.)
country comparison to the world: 69','c8676392b3a8f767ff1fd5c3a42566387ccb4ebe7d7a9314fab55a8d14fb8c91','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('84af9e7c576a3a845ee1dc6721d04a74c8bcfef14aec7b9bcdcf837a7859674a',2025,'IT','Italy','energy',856,'Electricity—production: 302.6 billion kWh
(2011 est.)
country comparison to the world: 14
Electricity—consumption: 313.8 billion kWh
(2011 est.)
country comparison to the world: 14
Electricity—exports: 1.787 billion kWh (2011 est.)
country comparison to the world: 44
Electricity—imports: 47.52 billion kWh (2011 est.)
country comparison to the world: 3
Electricity—installed generating capacity:
122.3 million kW (2011 est.)
country comparison to the world: 9
Electricity—from fossil fuels: 65% of total
installed capacity (2011 est.)
country comparison to the world: 128
Electricity—from nuclear fuels: 0% of total
installed capacity (2011 est.)
country comparison to the world: 112
Electricity—from hydroelectric plants: 18% of
total installed capacity (2011 est.)
country comparison to the world: 97
Electricity—from other renewable sources:
15.8% of total installed capacity (2011 est.)
country comparison to the world: 9
Crude oll—production: 99,200 bbl/day (2011 est.)
country comparison to the world: 50
Crude oll—exports: 6,300 bbl/day (2010 est.)
country comparison to the world: 61
Crude oil—imports: 1.591 million bbl/day (2010
est.)
country comparison to the world: 8
Crude oll—proved reserves: 523.2 million bbl
(1 January 2012 est.)
country comparison to the world: 51
Refined petroleum products—production:
1.887 million bbl/day (2010 est.)
country comparison to the world: 13
Refined petroleum products—consumption:
1.454 million bbl/day (2011 est.)
country comparison to the world: 17
Refined petroleum products—exports: 628,000
bbl/day (2010 est.)
country comparison to the world; 12
Refined petroleum products—imports: 393,300
bbl/day (2010 est.)
country comparison to the world: 15
368
THE CIA WORLD FACTBOOK
Natural gas—production: 8.364 billion cu m
(2011 est.)
country comparison to the world: 47
Natural gas—consumpftion: 77.83 billion cu m
(2011 est.) ,
country comparison to the world: 12
Natural gas—exports: 123 million cu m (2011 est.)
country comparison to the world: 46
Natural gas—imports: 70.37 billion cu m (2011
est.)
country comparison to the world: 6
Natural gas—proved reserves: billion cu m
(1 January 2012 est.)
country comparison to the world: 62
Carbon dioxide emissions from consumption
of energy: 416.4 million Mt (2010 est.)
country comparison to the world: 16','4b496352c85979da504e2cdf305f42dcf5e0ad10f4b65a1119f8b034c8bc48fb','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8bbe3eda7e9169af39147f617b2dd1bc40e0b63698594ccbb6926c36679d8127',2025,'JM','Jamaica','energy',864,'Electricity—production: 5.208 billion kWh
(2009 est.)
country comparison to the world: 118
Electricity—consumption: 4.801 billion kWh
(2009 est.)
country comparison to the world: 114
Electricity—exports: 0 kWh (2010 est.)
country Comparison to the world: 212
Electricity—imports: 0 kWh (2010 est}
country comparison to the world: 203
Electricity—installed generating capacity:
1.198 million kW (2009 est.)
country comparison to the world: 119
Electricity—trom fossil fuels: 93.5% of total
installed capacity (2009 est.)
country comparison to the world: 71
Electricity—from nuclear fuels: 0% of toral
installed capacity (2009 est.)
country comparison to the world: 115
Electricity—from hydroelectric plants: 1.8% of
total installed capacity (2009 est.)
country comparison to the world: 138
Electricity—from other renewable sources:
4.7% of total installed capacity (2009 est.)
country comparison to the world: 40
Crude oil—production: 0 bbi/day (2011 est.)
country comparison to the world: 149
Crude oll—exports: 0 bbi/day (2009 est.)
country comparison to the world: 132
Crude oil—imports: 23,780 bbl/day (2009 est.)
country comparison to the world: 69
Crude oil—proved reserves: 0 bbl (1 January
2012 est.)
country comparison to the world: 148
Refined petroleum products—production:
22,790 bbl/day (2008 est.)
country comparison to the world: 95
Refined petroleum products—consumption:
78,520 bbl/day (2011 est.)
country comparison to the world: 89
Refined petroleum products—exports: 9,145
bbl/day (2008 est.)
country comparison to the world: 87
Refined petroleum products—imports: 68.410
bbl/day (2008 est.)
country comparison to the world: 58
Natural gas—production: 0 cu m (2010 est.)
country comparison to the world: 146
Natural gas—consumption: 0 cu m (2010 est.)
country comparison to the world: 157
Natural gos—exports: 0 cu m (2010 est.)
country comparison to the world: 123
Natural gos—imports: 0 cu m (2010 est.)
country comparison to thé world: 211
Natural gos—proved reserves: 0 cu m (1 Janu-
ary 2012 est.)
country comparison to the world: 151
Carbon dioxide emissions from consumption
of energy: 9.217 million Mt (2010 est.)
country comparison to the world: 103','b070bbeffc343c0aba115599ae9c07a0d538b3b21212cd3f29662c6f06ec298b','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6292359ae44954a209787ee27df0cee2aca8e0a715e4f1c49463f93a5b7be766',2025,'JP','Japan','energy',878,'Electricity—production: 936.2 billion kWh
(2012 est.)
country comparison to the world: 6
Electricity—consumption; 859.7 billion kWh
(2012 est.)
country comparison to the world: 6
Electricity—exports: 0 kWh (2012 est.)
country comparison to the world: 211
Electricity—imports: 0 kWh (2012 est.)
country comparison. to the world: 202
Electricity—installed generating capacity: -
284.5 million kW (2009 est.)
country comparison to the world: 4
Electricity—from fossil fuels: 63.9% of total
installed capacity (2009 est.)
country comparison to the world: 132
Electricity—from nuclear fuels: 17.2% of total
installed capacity (2009 est.)
country comparison to the world: 14
Electricity—from hydroelectric plants: 7.7% of
total installed capacity (2009 est.)
country comparison to the world: 120
Electricity—from other renewable sources:
2.3% of total installed capacity (2009 est.)
country comparison to the world: 55
Crude oil—production: 17,480 bbi/day (2011
est.)
country comparison to the world: 75
Crude oil—exports: 0 bbl/day (2009 est.)
country comparison to the world: 131
Crude oll—imports: 3.384 million bbl/day (2009
est.)
country comparison to the world: 4
Crude oll—proved reserves: 44.12 million bbl
(1 January 2012 est.)
country comparison to the world: 81
Refined petroleum products—production:
3.861 million bbl/day (2009 est.)
country comparison. to the world: 6
Refined petroleum products—consumption:
4.464 million bbl/day (2011 est.)
country comparison to the world: 5
Refined petroleum products—exports: 366,800
bbl/day (2009 est.)
country comparison to the world: 22
Refined petroleum products—imports: 949,800
bbl/day (2009 est.)
country comparison to the world: 7
Natural gas—production: 3.276 billion cu m
(2012 est.)
country comparison to the world: 54
375
Natural gas—consumption: 112.6 billion cu m
(2011 est.)
country comparison to the world: 7
Natura! gas—exports: 0 cu m (2011 est.)
country comparison to the world: 122
Natural gas—imports: 109.9 billion cu m (2011 est.)
country comparison to the world: 3
Natural gas—proved reserves: 20.9 billion cu m
(1 January 2012 est.)
country comparison to the world: 78
Carbon dioxide emissions from consumption
of energy: 1.164 billion Mt (2010 est.)
country comparison to the world: 6','099dae0565b9ff1c79a4f0f31822b1e1e44bff7389abf659e8e20ca123345dd4','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e685dadf3ee48db2a118d0159f3cb0ca135b8d23fab215bd671bd8b346bf9749',2025,'JE','Jersey','energy',887,'Electricity—consumption: 630.1 million kWh
(2004 est.)
country comparison to the world: 164
Electricity—production: 450 million kWh (2009
est.)
country comparison to the world: 164
Electricity—consumption: 1.175 billion kWh
(2009 est.)
country comparison to the world: 149
Electricity—exports: 0 kWh (2010)
country comparison to the world: 150
Electricity—imports: 597 million kWh (2010 est.)
country comparison to the world: 73
Electricity—installed generating capacity:
130,000 kW (2009 est.)
country comparison to the world: 165
Electricity—from fossil fuels: 67.7% of total
installed capacity (2009 est.)
country comparison to the world: 113
Electricity—from nuclear fuels: 0% of total
installed capacity (2009 est.)
country comparison to the world: 206
Electricity—from hydroelectric plants: 32.3%
of total installed capacity (2009 est.)
country comparison to the world: 69
Electricity—from other renewable sources: 0%
of total installed capacity (2009 est.)
country comparison to the world: 206
Crude oli—production: 0 bbi/day (2011 est.)
country comparison to the world: 208
Crude oil—exports: 0 bbl/day (2009 est.)
country comparison to the world: 208
Crude oll—imports: 0 bbl/day (2009 est.)
country comparison to the world: 144
Crude oil—proved reserves: 0 bbl (1 January
2010 es)
" country comparison to the world: 207
Refined petroleum products—production: 0
bbl/day (2008 est.)
country comparison to the world: 211
Refined petroleum products—consumption:
4,567 bbl/day (2011 est.)
country comparison to the world: 172
Refined petroleum products—exports: 0 bbl/
day (2008 est.)
country comparison to the world: 146
Refined petroleum products—imports: 4,898
bbl/day (2008 est.)
country comparison to the world: 157
Natural gas—production: 0 cu m (2010 est.)
country comparison to the world: 211
Natural gas—consumption: 0 cu m (2010 est.)
country comparison to the world: 211
Natural gas—exports: 0 cu m (2010 est.)
country comparison to the world: 209
Natural gas—imports: 0 cu m (2010 est.)
country comparison to the world: 81
Natural gas—proved reserves: 0 cu m (1 Janu-
ary 2012 es)
country comparison to the world: 208
Carbon dioxide emissions from consumption
of energy: 1.113 million Mt (2010 est.)
country comparison to the world: 165','e8ae2e525452b0efa73432cbd2695872b47e81252a4c354ac5918835a8a50b81','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('556fe6ffefaaa6bf3bb63d0d3a3bc7a26a68d71289f7b435cbb52465269b161a',2025,'JO','Jordan','energy',895,'Electricity—production: 14.64 billion kWh
(2011 est.)
country comparison to the world: 86
Electricity—consumption: 13.54 billion kWh
(2011 est.)
country comparison to the world: 79
Electricity—exports: 86 million kWh (2011 est.)
country comparison to the world: 74
Electricity—imports: 1.738 billion kWh (2011
est.)
country comparison to the world: 54
Electricity—installed generating capacity:
3.14 million kW (2010 est.)
country comparison to the world: 87
Electricity—trom fossil fuels: 99.3% of total
installed capacity (2009 est.)
country comparison to the world: 58
Electricity—from nuclear fuels: 0% of total
installed capacity (2009 est.) `
country comparison to the world: 116
Electricity—from hydroelectric plants: 0.5% of
total installed capacity (2009 est.)
country comparison to the world: 145
Electricity—from other renewable sources:
0.2% of total installed capacity (2009 est.)
country comparison to the world: 89
Crude oil—production: 20 bbl/day (2011 est.)
country comparison to the world: 102
Crude oil—exports: 0 bbi/day (2011 est.)
country comparison to the world: 133
Crude ojl—imports: 29,310 bbl/day (2009 est.)
country comparison to the world: 65
Crude oll—proved reserves: 1 million bbl
(1 January 2012 est.)
country comparison to the world: 100
Refined petroleum —products—production:
79,190 bbl/day (2008 est.)
country comparison to the world: 80
Refined petroleum products—consumption:
107,000 bbl/day (2011 est.)
country comparison to the world: 76
Refined petroleum products—exports: 0 bbl/
day (2008 est.)
country comparison to the world: 188
Refined petroleum products—imports: 18,620
bbi/day (2008 est.)
country comparison to the world: 107
Natural gas—production: 226.5 million cu m
(2011 est.)
country comparison to the world: 76
Natural gas—consumption: 1.4 billion cu m
(2011 est.)
country comparison to the world: 84
Natural gas—exports: 0 cu m (2010 est.)
country comparison to the world: 124
Natural gas—imports: 793 million cu m (2011 est.)
country comparison to the world: 63
Natural gas—proved reserves: 6.031 billion cum
(1 January 2012 est.)
country comparison to the world: 86
Carbon dioxide emissions from consumption
of energy: 19.7 million Mt (2010 est.)
country comparison to the world: 85','73d82e845c40c60543e7e38cbfa150782271236a16e7544d7d30d640d45e7ef8','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c633bee2ed3db74621428806de11ebcd5820ad34a8e922fb1c913ff1e9b17122',2025,'KE','Kenya','energy',911,'Electricity—production: 6.573 billion kWh
(2009 est.)
country comparison to the world: 106
Electricity—consumption: 5.516 billion kWh
(2009 est.)
country comparison to the world: 111
Electricity—exports: 27 million kWh (2009 est.)
country comparison to the world: 81
Electricity—imports: 38 million kWh (2009 est.)
country comparison to the world: 101
Electricity—installed generating capacity:
1.706 million kW (2009 est.)
country comparison to the world: 107 .
Electricity—from fossil fuels: 43.3% of total
installed capacity (2009 est.)
country comparison to the world: 167
Electricity—from nuctear fuels: 0% of total
installed capacity {2009 est.)
389
country comparison to the world: 117
Electricity—from hydroelectric plants: 43.8%
of total installed capacity (2009 est.)
country comparison to the world: 50
Electricity—from other renewable sources:
12.9% of total installed capacity (2009 est.)
country comparison to the world: 16
Crude oil—production: 0 bbi/day (2011 est.)
country comparison to the world: 150
Crude oil—exports: 0 bbl/day (2009 est.)
country comparison to the world: 134
Crude oil—imports: 32,560 bbl/day (2009 est.)
country comparison to the world: 63
Crude oil—proved reserves: 0 bbl (1 January
2012 est.)
country comparison to the world: 149
Refined petroleum products—production:
30,960 bbl/day (2008 est.)
country comparison to the world: 92
Refined petroleum products—consumption:
79,410 bbl/day (2011 est.)
country comparison to the world: 88
Refined petroleum products—exports: 1,065
bbl/day (2008 est.)
country comparison to the world: 108
Refined petroleum products—imports: 34,990
bbl/day (2008 est.)
country comparison to the world: 81
Natural gas—production: 0 cu m (2010 est.)
country comparison to the world: 147
Natural gas—consumption: 0 cu m (2010 est.)
country comparison to the world: 158
Natural gas—exports: 0 cu m (2010 est.)
country comparison to the world: 125
Natural gas—imports: 0 cu m (2010 est.)
country comparison to the world: 212
Natural gas—proved reserves: 0 cu m (1 Janu-
ary 2012 est.)
country comparison to the world: 152
Carbon dioxide emissions from consumption
of energy: 12.25 million Mt (2010 est.)
country comparison to the world: 96','3468542ab4964b7fdf7c1e37e40dfa25104ad4f668d97024a4853c5c3d9a0a0f','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fadba6bd72861c7a4e8e88125c9b66ba1b6759367a823510268fc7f4f253c5de',2025,'KI','Kiribati','energy',920,'Electricity—production: 21 million kWh (2009
est.)
country comparison to the world: 213
Electricity—consumption: 19.53 million kWh
(2009 est.)
country comparison to the world: 213
Electricity—exports: 0 kWh (2010 est.)
country comparison to the world: 214
Electricity—imports: 0 kWh (2010 est.)
country comparison to the world: 205
Electricity—installed generating capacity:
6,000 kW (2009 est.)
country comparison to the world: 207
Electricity—from fossil fuels: 100% of total
installed capacity (2009 est.)
country comparison to the world: 19
Electricity—from nuclear fuels: 0% of total
installed capacity (2009 est.)
country comparison to the world: 120
Electricity—from hydroelectric plants: 0% of
total installed capacity (2009 est.)
country comparison to the world: 177
Electricity—from other renewable sources: 0%
of total installed capacity (2009 est.)
country comparison to the world: 144
Crude oil—production: 0 bbl/day (2011 est.)
country comparison to the world: 152
Crude oli—exports: 0 bbl/day (2009 est.)
country comparison to the world: 137
Crude oil—imports: 0 bbl/day (2009 est.)
country comparison to the world: 203
Crude oil—proved reserves: 0 bbl (1 january
2012 est.)
country comparison to the world: 151
Refined petroleum products—production: 0
bbl/day (2008 est.)
country comparison to the world: 161
Refined petroleum products—consumption:
300 bbl/day (2011 est.)
country comparison to the world: 210
Refined petroleum products—exports: 0 bbl/
day (2008 est.)
country comparison to the world: 190
Refined petroleum products—imports: 260.8
bbl/day (2008 est.)
country comparison to the world: 205
Natural gas—production: 0 cu m (2010 est.)
country comparison to the world: 149
Natural gas—consumption: 0 cu m (2010 est.)
country comparison to the world: 160
Natural gas—exports: 0 cu m (2010 est.)
country comparison to the world: 127
Natural gas—imports: 0 cu m (2010 est.)
country comparison to the world: 86
Natural gas—proved reserves: 0 cu m (1 Janu-
ary 2012 est.)
country comparison to the world: 154
Carbon dioxide emissions from consumption
of energy: 43,690 Mr (2010 est.)
country comparison to the world: 207
Electricity—production: 20.45 billion kWh
(2009 est.) F
country comparison to the world: 72
Electricity—consumption: 17.12 billion kWh
(2009 est.) :
country comparison to the world: 72
Electricity—exports: 0 kWh (2010 est.)
country comparison to the world: 213
Electricity—imports: 0 kWh (2010 est.)
country comparison to the world: 204
Electricity—instalied generating capacity: 9.5
million kW (2009 est.)
country comparison to the world: 58
Electricity—from fossil fuels: 47.4% of total
installed capacity (2009 est.)
country comparison to the world: 161
Electricity—from nuclear fuels: 0% of total
installed capacity (2009 est.)
country comparison to the world: 119
Electricity--from hydroelectric plants: 52.6%
of total installed capacity (2009 est.)
country comparison to the world: 39
Electricity—from other renewable sources: 0%
of total installed capacity (2009 est.)
country comparison to the world: 143
Crude oil—production: 0 bbl/day (2011 est.)
country comparison to the world: 151
Crude oli—exports: 0 bbl/day (2009 est.)
country comparison to the world: 136
Crude oll—imports: 8,432 bbli/day (2009 est.)
country comparison to the world: 78
Crude oil—proved reserves: 0 bbl (1 January
2012 est.) y
country comparison to the world: 150
Refined petroleum products—production:
9,133 bbl/day (2008 est.)
country comparison to the world: 107
Refined petroleum products—consumption:
15,070 bbl/day (2011 est.)
country comparison to the world: 144
Refined petroteum products—exports: 0 bbl/
day (2008 est.)
country comparison to the world: 189
Refined petroleum products—imports: 7,967
bbl/day (2008 est.)
country comparison to the world: 136
Natural gas—production: 0 cu m (2010 est.)
country comparison to the world: 148
Natural gas—consumption: 0 cu m (2010 est.)
country comparison to the world: 159
Natural gas—exports: 0 cu m (2010 est.)
country comparison to the world: 126
Natural gas—imports: 0 cu m (2010 est.)
country comparison to the world: 85
396
THE CIA WORLD FACTBOOK
Natural gas—proved reserves: 0 cu m (1 Janu-
ary 2012 est.)
country comparison to the world: 153
Carbon dioxide emissions from consumption
of energy: 63.69 million Mt (2010 est.)
country comparison to the world: 52
Electricity—production: billion kWh (2011 est.)
country comparison to the world: 12
Electricity—consumption: 455.1 billion kWh
(2011 est.) 3
country comparison to the world: 10
Etectricity—exports: 0 kWh (2011)
country comparison to the world: 215
Electricity—imports: 0 kWh (2011)
country comparison to the world: 206
Electricity—installed generating capacity:
80.59 million kW (2009 est.)
country comparison to the world: 14
Electricity—from fossil fuels: 69.9% of total
installed capacity (2009 est.)
country comparison to the world: 106
Electricity—from nuclear fuels: 22% of total
installed capacity (2009 est.)
country comparison to the world: 8
Electricity—from hydroelectric plants: 2% of
total installed capacity (2009 est.)
country comparison to the world: 136
Electricity—from other renewable sources:
1.3% of total installed capacity (2009 est.)
country comparison to the world: 69
Crude oil—production: 19,990 bbl/day (2011 est.)
country comparison to the world: 73
Crude oil—exports: 0 bbl/day (2009 est.)
country comparison to the world: 138
Crude oll—imports: 2.59 million bbl/day (2012
est.)
country comparison to the world: 6
Crude oil—proved reserves: NA bbl
Refined petroleum products—production: 2.83
million bbl/day (2012 est.)
399
country comparison to the world: 8
Refined petroleum products—consumption:
2.26 million bbl/day (2012 est.)
country comparison to the world: 11
Refined petroleum products—exports: 907,100
bbl/day (2009 est.) : 1
country comparison to the world: 8
Refined petroleum products—imports: 753,900
bbl/day (2009 est.)
country comparison to the world: 9
Natural gas—production: 539.3 million cu m
(2010 est.)
country comparison to the world: 72
Natural gas—consumption: 45.9 billion cu m
(2011 est.)
country comparison to the world: 20
Natural gas—exports: 0 cu m (2011 est.)
country comparison to the world: 128
Natural gas—imports: 46.83 billion cu m (2011
est.)
country comparison to the world: 9
Natural gas—proved reserves: 5.748 billion
cu m (1 January 2013 est.)
country comparison to the world: 87
Carbon dioxide emissions from consumption
of energy: 579 million Mt (2010 est.)
country comparison to the world: 8','2aa11f0d9b3e157bbdfd5659de9e68b1d8176bca3ff07fa6e594189d9da0ec63','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1e735e5dce18db3d0e2fbe6d7c94cb3495091b9a36acbe3f51fe2b0ba32f26cf',2025,'RS','Serbia','energy',929,'Electricity—production: 5.16 billion kWh
(2011)
KUWAIT Sag
chy .
Ash Shuyeykhw, As Sélimiyah
A Jana” samme Hawaii s:
ash Shuyukn
Mind’ al Ahmadi,
$ Mina *
x ins Metal
\\ Az Zawr
{ (Minà Sa’od)*
SANO eee \\ ‘A Wetran ”
Ric
Electricity—production: 37.86 billion kWh
(2012)
country comparison to the world: 61
Electricity—consumption: 37.37 billion kWh
(2012) M
country comparison to the world: 55
Electricity—exports: 1.24 billion kWh (2012
est.) a i
country comparison to the world: 53
Electricity—imports: 1.5 billion kWh (2012)
country comparison to the world: 56
Electricity—instalied generating capacity:
8.359 million kW (2009 est.)
country comparison to the world: 61
Electricity—from fossil fuels:% of total installed,
capacity (2009 ést.)
country comparison to the world: 119
‘Electricity—from nuclear fuels: 0% of total
installed capacity (2009 est.)
country comparison to the world: 166
Electricity—from hydroelectric plants: 26.6%
of total installed capacity (2009 est.)
country comparison to the world: 83
Electricity—from other renewable sources: 0%
of total installed capacity (2009 est.)
country comparison to the world: 178
Crude oll—production: 13,160 bbi/day (2011
est.)
country comparison to the world: 78
Crude oil—exports: 0 bbl/day (2009 est.)
country comparison to the world: 172
Crude oll—imports: 45.0 bbl/day (2009 est.)
country comparison to the world; 58
Crude oll—proved reserves: 77.5 million bbl
(1 January 2012 est.)
country comparison to the world: 78
Refined petroleum products—production:
55,960 bbl/day (2008 est.)
country comparison to the world: 83
Refined petroleum products—consumption:
81,440 bbl/day (2011 est.)
country comparison to the world: 85
Refined petroleum products—exports: 3,981
bbl/day (2011 est.)
country comparison to the world: 99
Refined petroleum products—imports: 27,330
bbl/day (2008 est.)
country comparison to the world: 90
Natural gos—production: 557 million cu m
(2012 est.)
country comparison to the world: 71
Natural gas—consumption: 2.84 billion cu m
(2012 est.)
country comparison to the world: 75
Natura! gas—exports: 0 cu m (2012 est.)
country comparison to the world: 166
Natural gas—imports: 2.61 billion cu m (2012
est.)
country comparison to the world: 46
Natural gas—proved reserves: 4 billion cu m
(1 January 2012 est.)
country comparison to the world: 68
Carbon dioxide emissions from consumption
of energy: 49.92 million Mt (2010 est.)
country comparison to the world: 63','9b0c80144e7b6a9e969a0b09963fbbc371a981045c144bd86fa4e35ecb1665ee','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('eb33e87ec1bbb745797718ed222ea42fea0bb868e3929dc990f78f04b1a62920',2025,'KW','Kuwait','energy',935,'Electricity—production: 51.32 billion kWh
(2010 est.)
country comparison to the world: 51
Electricity—consumption: 43.41 billion kWh
(2009 est.)
country comparison to the world: 51
Electricity—exports: 0 kWh (2010 est.)
country comparison to the world: 90
Electricity—imports: 0 kWh (2010 est.)
country comparison to the world: 207
Electricity—instalied generating capacity:
10.94 million kW (2009 est.)
country comparison to the world: 52
Electricity—from fossil fuels: 100% of total
installed capacity (2009 est.)
country comparison to the world: 20
Electricity—from nuclear fuels: 0% of total
installed capacity (2009 est.)
country comparison to the world: 121
Electricity—from hydroelectric plants: 0% of
total installed capacity (2009 est.) -
country comparison to the world: 178
Electricity—from other renewable sources: 0% of
total installed capacity (2009 est.)
country comparison to the world: 145
Crude oil—production; 2.682 million bbl/day
(2011 est.) l
country comparison to the world: 11
Crude oii—exports: 1.365 million bbl/day (2009
est.)
country comparison to the world: 11
Crude oil—imports: 0 bbl/day (2009 est.)
country comparison to the world: 204
Crude oil—proved reserves: 101.5 billion bbl
(1 January 2013 est.)
country comparison to the world: 7
Refined petroleum products—production:
902,000 bbl/day (2008 est.)
country comparison to the world: 25
Refined petroleum products—consumption:
339,000 bbl/day (2011 est.)
country comparison to the world: 37
Refined petroleum products—exports: 717,700
bbl/day (2008 est.)
country comparison to the world: 10
Refined petroleum products—imports: 0 bbl/
day (2008 est.)
country comparison to the world: 211
Natural gas—production: 11.73 billion cu m
(2010 est.)
country comparison to the world: 42
Natural gas—consumption: 12.62 billion cu m
(2010 est.)
country comparison to the world: 43
Natural gas—exports: 0 cu m (2010 est.)
country comparison to the world: 129
406
THE CIA WORLD FACTBOOK
Natural gas—imports: 890 million cu m (2010
est.)
country comparison to the world: 60
Natural gas—proved reserves: 1.798 trillion
cu m (1 January 2012 est.)
country comparison to the world: 21
Carbon dioxide emissions from consumption
of energy: 81.33 million Mt (2010 est.)
country comparison to the world: 43:','9d98ac54ad2b85d7bb15b4b1873813ed530ad7858a98d2ace5b3e4b10b1047b0','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0f65bb30572d38e3935fdf91b6ba8e6de1afe8135b06082fe6aae7569efa6281',2025,'KG','Kyrgyzstan','energy',946,'Electricity—production: 14.9 billion kWh (2011
est.)
country comparison to the world: 83
Electricity—consumption: 7.29 billion kWh
(2009 est.)
country comparison to the world: 98
Electricity—exports: 2.62 billion kWh (2011
est.)
country comparison to the world: 39
Etectricity—imports: 535 million kWh (2008
est.)
country comparison to the world: 76
Electricity—installed generating capacity:
3.64 million kW (2009 est.)
country comparison to the world: 83
Electricity—trom fossil fuels: 20.1% of total
installed capacity (2009 est.)
country comparison to the world: 191
Electricity—from nuclear fuels: 0% of total
installed capacity (2009 est.)
country comparison to the world: 118
Electricity—from hydroelectric plants: 79.9%
of total installed capacity (2009 est.)
country comparison to the world: 15
Electricity—from other renewable sources: 0%
of total installed capacity (2009 est.)
country comparison to the world: 142
Crude oil—production: 1,000 bbl/day (2011 est.)
country comparison to the world: 98
Crude oil—exports: 0 bbl/day (2009 est.)
country comparison to the world: 135
Crude oil—imports: 2,387 bbl/day (2009 est.)
cauntry comparison to the world: 83
Crude oil—proved reserves: 40 million bbl
(1 January 2012 est.)
country comparison to the world: 82
Refined petroleum products—production:
2,607 bbl/day (2008 est.)
country comparison to the world: 113
Refined petroleum products—consumption:
16,640 bbl/day (2011 est.)
country comparison to the world: 141
Refined petroleum products—exports: 5,902
bbl/day (2008 est.)
country comparison to the world: 95
Refined petroleum products—imports: 28,940
bbl/day (2008 est.)
country comparison to the world: 89
Natural gas—production: 12..5 million cu m
(2010 est.)
country comparison to the world; 90
Natural gas—consumption: 462.5 million cu m
(2010 est.)
country comparison to the world: 99
Natural gas—exports: NA (2010 est.)
Natural gas—imports: 450 million cu m (2010
est.)
country comparison to the world: 68
Natural gas—proved reserves: 5.663 billion
cum (1 January 2012 est.)
country comparison to the world: 90
Carbon dioxide emissions from consumption
of energy: 4.131 million Mt (2010 est.)
country comparison to the world: 129','e7d0a6d755d16fb50cd0ca60e671b3aaa2d322a75bdd368ddf43bd4ee9d94288','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('730a729bf662f3d8f7e358112a4aa7ed6e975a38477439b5caf4e0bc009b4c18',2025,'LV','Latvia','energy',960,'Electricity—production: 6.46 billion kWh (2010
est.)
country comparison to the world: 109
Electricity—consumption: 6.215 billion kWh
(2010 est.)
country comparison to the world: 104
Electricity—exports: 3.1 billion kWh (2010 est.)
country comparison to the world: 37
Electricity—imports: 3.973 billion kWh (2010 est.)
country comparison to the world: 40
Electricity—installed generating capacity:
2.164 million kW (2009 est.)
country comparison to the world: 100
Electricity—from fossil fuels: 27.3% of total
installed capacity (2009 est.)
country comparison to the world: 185
Electricity—from nuclear fuels: 0% of total
installed capacity (2009 est.)
country comparison to the world: 125
Electricity—from hydroelectric plants: 71% of
total installed capacity (2009 est.)
country comparison to the world: 22
Electricity—from other renewable sources:
1.8% of total installed capacity (2009 est.)
country comparison to the world: 63
Crude oil—production: 0 bbl/day (2011 est.)
country comparison to the world: 155
Crude oll—exports: 0 bbi/day (2009 est.)
country comparison to the world: 141
Crude oil—imports: 0 bbl/day (2009 est.)
country comparison to the world: 207
Crude oil—proved reserves: 0 bbl (1 January
2012 est.)
country comparison to the world: 154
Refined petroleum products—production: 0
bttfday (2008 est.)
country comparison to the world: 165
Refined petroleum products—consumption:
31,340 bbl/day (2011 est.)
country comparison to the world: 114
Refined petroleum products—exports: 3,126
bbl/day (2010 est.)
country comparison to the world: 101
Refined petroleum products—imports: 33,730
bbl/day (2008 est.)
country comparison to the world: 84
Natural gas—production: 0 cu m (2010 est.)
country comparison to the world: 153
Natural gos—consumption: 1.52 billion cu m
(2010 est.)
country comparison to the world: 83
Natural gas—exports: 0 cu m (2010 est.)
country comparison to the world: 132
Natural gas—imports: 1.52 billion cu m (2010
est.)
country comparison to the world: 52
Natural gas—proved reserves: 0 cu m (1 Janu-
ary 2012 est.)
country comparison to the world: 157
Carbon dioxide emissions from consumption
of energy: 9.066 million Mt (2010 est.)
country comparison to the world: 104','01ac635f73ce82a58fb8392b7358398de1cf5a2a5195010e76c65afcabb40dea','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c68f95f529b0566e7f73fe5782dd183a93217af384372404b479b35691489693',2025,'LB','Lebanon','energy',968,'Electricity—production: 12.98 billion kWh
(2009 est.)
country comparison to the world: 88
Electricity—consumption: 12.34 billion kWh
(2009 est.)
country comparison to the world: 84
Electricity—exports: 0 kWh (2010 est.)
country comparison to the world: 91
Electricity—imports: 1.155 billion kWh (2009 est.)
country comparison to the world: 61
Electricity—installed generating capacity:
2.314 million kW (2009 est.)
country comparison to the world: 98
Electricity—from fossil fuels: 87.9% of total
installed capacity (2009 est.)
country comparison to the world: 81
Electricity—from nuclear fuels: 0% of total
installed capacity (2009 est.)
country comparison to the world: 124
Electricity—from hydroelectric plants: 12.1%
of total installed capacity (2009 est.)
country comparison to the world: 110
Electricity—from other renewable sources: 0%
of total installed capacity (2009 est.)
country comparison to the world: 148
Crude oll—production: 0 bbl/day (2011 est.)
country comparison to the world: 154
Crude olli—exports: 0 bbl/day (2009 est.)
country comparison to the world: 140
Crude oil—imports: 0 bbl/day (2009 est.)
country comparison to the world: 206
Crude oil—proved reserves: 0 bbl (1 January
2012 est.)
country comparison to the world: 153
Refined petroleum products—production: 0
bbl/day (2008 est.)
country comparison to the world: 164
Refined petroleum products—consumption:
106,700 bbi/day (2011 est.)
country comparison to the world: 77
Refined petroleum products—exports: 0 bbl/
day (2008 est.)
country comparison to the world: 192
Refined petroleum products—imports: 102,300
bbl/day (2008 est.)
country comparison to the world: 49
Natural gas—production: 0 cu m (2010 est.)
country comparison to the world: 152
Natural gas—consumption: 0 cu m (2010 est.)
country comparison to the world: 163
Natural gas—exports: 0 cu m (2010 est.)
country comparison to the world: 131
Natural gas—imports: 0 cu m (2010 est.)
country comparison to the world: 88
Notural gas—proved reserves: cu m (1 January
2012 est.)
country comparison to the world: 156
Carbon dioxide emissions from consumption
of energy: 15.24 million Mr (2010 est.)
country comparison to the world: 90','2ab58f1d500dd5f5ebdeb2b9ec646d850897f4513c902c94ab9b18c446154732','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a2158914fa897ef6d2a67f131fce1deb0777292f2bc63f112da5fb6a28d9bf67',2025,'LS','Lesotho','energy',977,'Electricity—production: 200 million kWh (2009
est.)
country comparison to the world: 182
Electricity—consumption: 293 million kWh
(2009 est.) .
country comparison to the world: 176
Electricity—exports: 0 kWh (2010 est.)
country comparison to the world: 93
Electricity—imports: 121 million kWh (2010
est.)
country comparison to the world: 92
Electricity—installed generating capacity:
76,000 kW (2009 est.)
country comparison to the world: 175
Electricity—from fossli fuels: 0% of toral
installed capacity (2009 est.)
country comparison to the world: 209
Electricity—from nuclear fuels: 0% of total
installed capacity (2009 est.)
country comparison to the world: 127
Electricity—from hydroelectric plants: 100% of
total installed capacity (2009 est.)
country comparison to the world: 1
Electricity—from other renewable sources: 0%
of total installed capacity (2009 est.)
country comparison to the world: 150
Crude oil—production: 0 bbi/day (2011 est.)
country comparison to the world: 157
Crude ofl—exports: 0 bbl/day (2009 esr.)
country comparison to the world: 143
Crude oil—imports: 0 bbl/day (2009 est.)
country comparison to the world: 209
Crude oil—proved reserves: 0 bbl (1 January
2012 est.)
country comparison to the world: 156
423
Refined petroleum products—production: 0
bbl/day (2008 est.)
country comparison to the world: 167
Refined petroleum products—consumption:
1,777 bbl/day (2011 est.)
country comparison to the world: 192
Refined petroleum products—exports: 0 bbl/
day (2008 est.)
country comparison to the world: 194
Refined petroleum products—imports: 1,813
bbl/day (2008 est.)
country comparison to the world: 181
Natural gas—production: 0 cu m (2010 est.)
country comparison to the world: 156
Natural gas—consumption: 0 cu m (2010 est.)
country comparison to the world: 165
Natural gas—exports: 0 cu m (2010 est.)
country comparison to the world: 135
Natural gas—imports: 0 cu m (2010 est.)
country comparison to the world: 90
Natural gas-—proved reserves: 0 cu m (1 Janu-
ary 2012 est.)
country comparison to the world: 160
Carbon dioxide emissions from consumption
of energy: 282,100 Mt (2010 est.)
country comparison to the world: 191','49eeb3db259d06fc1d8e774e88875486ef094e2c6fbc58cd9ef16d8c8bfd46b6','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('11ec5337f46f322f6dabfaacb7b2261663d7016f3583ac7a7b5c4abc8289d7f6',2025,'LR','Liberia','energy',987,'Electricity—production: 335 million kWh (2009
est.)
country comparison to the world: 168
Electricity—consumption: 311.6 million kWh
(2009 ést.)
country comparison to the world: 173 :
Electricity—exports: 0 kWh (2010 est.)
country comparison to the world: 92
Electricity—imports: 0 kWh (2010 est.)
country comparison to the world: 208
Electricity—instailed generating capacity:
197,000 kW (2009 est.)
country comparison to the world: 156
Electricity—trom fossil fuels: 100% of total
installed capacity (2009 est.)
country comparison to the world: 21
Electricity—from nuclear fuels: 0% of total
installed capacity (2009 est.)
country comparison to the world: 126
Electricity—from hydroelectric piants: 0% of
total installed capacity (2009 est.)
country comparison to the world: 179
Electricity—from other renewable sources: 0%
of total installed capacity (2009 est.)
country comparison to the world: 149
Crude oil—production: 0 bbl/day (2011 est.)
country comparison to the world: 156
Crude oil—exports: 0 bbi/day (2009 est.)
country comparison to the world: 142
Crude oil—imports: 0 bbl/day (2009 est.)
country comparison to the world: 208
Crude oil—proved reserves: 0 bbl (1 January
2012 est.)
country comparison to the world: 155
Refined petroleum products—production: 0
bbl/day (2008 est.)
country comparison to the world: 166
Refined petroleum products—consumption:
3,533 bbl/day (2011 est.)
country comparison to the world: 177
Refined petroleum products—exports: 0 bbl/
day (2008 est.)
country comparison to the world: 193
Refined petroleum products—imports: 4,041
bbl/day (2008 est.)
country comparison to the world: 163
Natural gas—production: 0 cu m (2010 est.)
country comparison to the world: 155
Natural gas—consumption: 0 cu m (2010 est.)
country comparison to the world: 164
Natural gas—exports: 0 cu m (2010 est.)
country comparison to the world: 134
Natural gas—imports: Q cu m (2010 est.)
country comparison to the world: 89
Natural gas—proved reserves: 0 cu m (1 Janu-
ary 2012 est.)
country comparison to the world: 159
Carbon dioxide emissions from consumption
of energy: 738,000 Mt (2010 est.)
country comparison to the world: 175','0f2993e4e39dfb457e4e25fee65af9a9cda2070fa8cbd28f873e6c8ab0bbc448','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a7546c39590b43d106cf7579211486a49b2f2744d723eae649ce60915c4dea3f',2025,'LY','Libya','energy',996,'Electricity—production: 28.6 billion kWh (2009
est.)
country comparison to the world: 65
Electricity—consumption: 24.29 billion kWh
(2009 est.)
country comparison to the world: 68
Electricity—exports: 124 million kWh (2009
est.)
country comparison to the world: 69
Electricity—imports: 73 million kWh (2009 est.)
country comparison to the world: 98
Electricity—installed generating capacity:
6.766 million kW (2009 est.)
country comparison to the world: 67
Electricity—from fossil fuels: 100% of total
installed capacity (2009 est.)
country comparison to the world: 22
Electricity—from nuclear fuels: 0% of toral
installed capacity (2009 est.)
country comparison to the world: 129
Electricity—from hydroelectric plants: 0% of
total installed capacity (2009 est.)
country comparison to the world: 180
Electricity—from other renewable sources: 0%
of total installed capacity (2009 est.)
country comparison to the world: 151
Crude ojl—production: 502,400 bbl/day (2011
est.)
country comparison to the world: 31
Crude oit—exports: 1.039 million bbl/day (2009 est.)
country comparison to the world: 15
Crude ofl—imports: 0 bbl/day (2009 est.)
country comparison to the world: 88
Crude oil—proved reserves: 48.08 billion bbl
(1 January 2013 est.)
country comparison to the world: 10
Refined petroleum products—production:
309,000 bbl/day (2008 est.)
country comparison to the world: 44
Refined petroleum products—consumption:
314,000 bbl/day (2011 est.)
country comparison to the world: 44
Refined petroleum products—exports: 84,490
bbl/day (2008 est.)
country comparison to the world: 45
Refined petroleum products—imports: 575.3
bbl/day (2008 est.)
country comparison to the world: 201
Natural gas—production: 16.81 billion cu m
(2010 est.)
country comparison to the world: 36
Natural gos—consumption: 6.844 billion cu m
(2010 est.)
country comparison to the world: 55
Natural gas—exports: 9.97 billion cu m (2010
est.)
country comparison to the world: 22
Natural gas—imports: 0 cu m (2011 est.)
country comparison to the world: 91
Natural gas—proved reserves: 1.495 trillion
cu m (1 January 2012 est.)
country comparison to the world: 23
Carbon dioxide emissions from consumption
of energy: 60.6 million Mt (2010 est.)
country comparison to the world: 56','123518564463516d3f4c42b72d96f74e3617c23f1854a30b9a9d58101b896216','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1d52e7d5015c8ff352a2a8747c5fa8bcd3b4dd02c514e15b2afa30cfcb5fa82f',2025,'LT','Lithuania','energy',1012,'Electricity—production: 12.27 billion kWh
(2012 est.)
country comparison to the world: 91
Electricity—consumption: 10.3 billion kWh
(2012 est.)
country comparison to the world: 87
Electricity—exports: 186 million kWh (2012
est.)
country comparison to the world: 68
Electricity—imports: 1.17 billion kWh (2012
est.)
country comparison to the world: 59
Electricity—instalied generating capacity:
3.82 million kW (2011 est.)
country comparison to the world: 81
Electricity—from fossil fuels: 53.8% of total
installed capacity (2009 est.)
country comparison to the world: 149
436
THE CIA WORLD FACTBOOK
Electricity—from nuclear fuels: 25.2% of total
installed capacity (2009 est.)
country comparison to the world: 5
Electricity—from hydroelectric plants: 2.4% of
total installed capacity (2009 est.)
country comparison to the world: 134
Electricity—from other renewable sources:
2.4% of total installed capacity (2009 est.)
country comparison to the world: 53
Crude oil—production: 2,000 bbi/day (2011 est.)
country comparison to the world: 92
Crude oil—exports: 2,260 bbl/day (2009 est.)
country comparison to the world: 64
Crude oll—imports: 168,300 bbi/day (2009 est.)
country comparison to the world: 39
Crude oll—proved reserves: 12 million bbl
(1 January 2012 est.)
country comparison to the world: 91
Refined petroleum products—production:
202,600 bbl/day (2008 est.)
country comparison to the world: 56
Refined petroleum products—consumption:
70,390 bbl/day (2011 est.) l
country comparison to the world: 92
Refined petroleum products—exports: 149,900
bbl/day (2008 est.)
country comparison to the world: 37
Refined petroleum products—imports: 15,670
bbl/day (2008 est.)
country comparison to the world: 117
Natural gas—production: 0 cu m (2012 est.)
country comparison to the world: 154
Natural gas—consumption: 3.3 billion cu m
(2012 est.)
country comparison to the world: 70
Natural gas—exports: 0 cu m (2012 est.)
country comparison to the world: 133
Natural gas—imports: 3.1 billion cu m (2010
est.)
country comparison to the world: 42
Natural gas—proved reserves: 0 cu m (1 Janu-
ary 2012 est,)
country comparison to the world: 158
Carbon dioxide emissions from consumption
of energy: 15.98 million Mt (2010 est.)
country comparison to the world: 88','403775d4213475791e832c5c33878fd1e8c6ae7e0fe60cb1e9d1b491eb3cc581','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('811a4145483246b41e2b57751a77f8ebf9ee70a0d3f5eaf08c9359e748e27544',2025,'LU','Luxembourg','energy',1017,'Electricity—production: 2.49 billion kWh (2010
est.)
country comparison to the world: 132
Electricity—consumption: 5.973 billion kWh
(2009 est.)
country.comparison to the world: 106
Electricity—exports: 3.216 billion kWh (2010
est.)
country comparison to the world: 35
Electricity—imports: 7.28 billion kWh (2010 est.)
country comparison to the world: 31
Electricity—instalied generating capacity:
1.702 million kW (2009 est.)
country comparison to the world: 108
Electricity—from fossil fuels: 28.4% of total
installed capacity (2009 est.)
country comparison to the world: 182
Electricity—from nuclear fuels: 0% of total
installed capacity (2009 est.)
country comparison to the world: 128
Electricity—from hydroelectric plants: 2% of
total installed capacity (2009 est.)
country comparison to the world: 135
Electricity—from other renewable sources; 5%
of total installed capacity (2009 est.)
country comparison to the world: 37
crude oll—production: 0 bbl/day (2011 est.)
country comparison to the world: 158
Crude oll—exports: 0 bbi/day (2009 est.)
country comparison to the world: 144
Crude oli—imports: 0 bbl/day (2009 est.)
country comparison to the world: 210
Crude oll—proved reserves: 0 bb! (1 January
2012 est.)
country comparison to the world: 157
Refined petroleum products—production: 0
bbl/day (2009 est.)
country comparison to the world: 168
Refined petroleum products—consumption:
61,380 bbl/day (2011 est.)
country comparison to the world: 94
Refined petroleum enna a 686.3
bbl/day (2009 est.)
country comparison to the world: 116
Refined petroleum products—imports: 51,930
bbl/day (2009 est.)
country comparison to the world: 67
439
Natural gas—production: 0 cu m (2010 est.)
country comparison to the world: 157
Natural gas—consumption: 1.183 billion cu m
(2011 est.)
country comparison to the world: 87
Natural gas—exports: 0 cu m (2011 est.)
country comparison to the world: 136
Natural gas—imports: 1.183 billion cum (2011 est.)
country comparison to the world: 56
Natural gas—proved reserves: 0 cu m (1 Janu-
ary 2012 est.)
country comparison to the world: 161
Carbon dioxide emissions from consumption
of energy: 10.8 million Mt (2010 est.)
country comparison to the world: 99
Electricity—production: 561 million kWh (2012
est.)
country comparison to the world: 159
Electricity—consumption: 4.214 billion kWh
(2012 est.)
country comparison to the world: 122
Electricity—exports: 0 kWh (2012 est.)
country comparison to the world: 95
Electricity—imports: 3.86 billion kWh (2012 est.)
country comparison to the world: 41
Electricity—installed generating capacity:
472,000 kW (2012 est.)
country comparison to the world: 140
Electricity—ftrom fossil fuels: 100% of total
installed capacity (2012 est.)
country comparison to the world: 23
Electricity—from nuclear fuels: 0% of total
installed capacity (2012 est.)
country comparison to the world: 131
Electricity—from hydroelectric plants: 0% of
total installed capacity (2012 est.)
country comparison to the world: 181
Electricity—from other renewable sources: 0%
of total installed capacity (2012 est.)
country comparison to the world: 153
MACAU
Crude oil—production: 0 bbl/day (2012 est.)
Crude oil—exports: 0 bbl/day (2012 est.)
country comparison to the world: 146
Crude oll—imports: 0 bbl/day (2012 est.)
country comparison to the world:90 `
Crude oll—proved reserves: 0 bbl (1 January
2012 est.)
country comparison to the world: 159
Refined petroleum products—production: 0
bbl/day (2012 est.)
country comparison to the world: 170
Refined petroleum products—consumption:
7,522 bbi/day (2012 est.)
country comparison to the world: 161
Refined petroleum products—exports: 0 bbl/
day (2012 est.)
country comparison to the world: 196
Refined petroleum products—imports: 5,948
bbl/day (2012 est.) :
country comparison to the world: 149
Natural gas—production: 0 cu m (2012 est.)
country comparison to the world: 159
Natural gas—consumption: 0 cu m(2012)
country comparison to the world: 167
Natural gas—exports: 0 cu m (2012 est.)
country comparison to the world: 138
Natural gas—imports: 0 cu m (2012 est.)
country comparison to the world: 93
Natural gas—proved reserves: 0 cu m (1 Janu-
ary 2012 est.)
country comparison to the world: 163
Carbon dioxide emissions from consumption
of energy: 2.537 million Mt (2010 est.)
country comparison to theavorld: 145','14ac44c3e09f2fb08b6807f61b795456bd3262705f7b213e028f1a977e517207','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('eb49c16f90b18dfbd44fa7798841cd4f12a4a46ed8e2b84d63adc5f1859f9aa2',2025,'MG','Madagascar','energy',1030,'Electricity—production: 1.35 billion kWh (2009
est.)
country comparison to the world: 143
Electricity—consumption: 1.256 billion kWh
(2009 est.)
country comparison to the world: 148
Electricity—exports: 0 kWh (2010 est.)
country comparison to the world: 94
Electricity—imports: 0 kWh (2010 est.)
country comparison to the world: 209
Electricity—instailed generating capacity:
406, 000 kW (2009 est.)
country comparison to the world: 143
Electricity—from fossil fuels: 69.5% of total
installed capacity (2009 est.)
country comparison to the world: 108
Electricity—from nuciear fuels: 0% of total
installed capacity (2009 est.)
country comparison to the world: 130
450
THE CIA WORLD FACTBOOK
Electricity—from hydroelectric plants: 30.5%
of total installed capacity (2009 est.)
country comparison to the world: 77
Electricity—from other renewable sources: 0%
of total installed capacity (2009 est.)
country comparison to the world: 152
Crude oil—production: 0 bbl/day (2011 est.)
country comparison to the world: 159
Crude oil—exports: 0 bbi/day (2009 est.)
country comparison to the world: 145
Crude oil—imponts: 0 bbl/day (2009 est.)
country comparison to the world: 89
Crude oll—proved reserves: 0 bbl (1 January
2012 est.)
country comparison to the world: 158
Refined petroleum products—production: 0
bbl/day (2008 est.)
country comparison to the world: 169
Refined petroleum products—consumption:
17,480 bbl/day (2011 est.)
country comparison. to the world: 138
Refined petroleum products—exports: 0 bbl/
day (2008 est.)
country comparison to the world: 195
Refined petroleum products—imports: 14,250
bbl/day (2008 est.)
country comparison to the world: 122
Natural gas—production: 0 cu m (2010 est.)
country comparison to the world: 158
Natural gas—consumption: 0 cu m (2010 est.)
country comparison to the world: 166
Natural gas—exports: 0 cu m (2010 est.)
country comparison to the world: 137
Natura! gas—imports: 0 cu m (2010 est.)
country comparison to the world: 92
Natural gas—proved reserves: 0 cu m (1 Janu-
ary 2006 est.)
country comparison to.the world: 162
Carbon dioxide emissions from consumption
of energy: 3.384 million Mt (2010 est.)
country comparison to the world: 135','deeafa5c112a13adecf8371d60adae54448bd578ff39719b899348d9332edfb2','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ddaea7b0deffdc43db53eb0dc816f84f3135ffeda60bb6be3c975eeb3818d406',2025,'MW','Malawi','energy',1041,'Electricity—production: 1.736 billion kWh
(2009 est.)
country comparison to the world: 137
Electricity—consumption: 1.614 billion kWh
(2009 est.)
country comparison to the world: 144
Electricity—exports: 0 kWh (2010 est.)
country comparison to the world: 99
Electricity—imports: 0 kWh (2010 est.)
country comparison to the world: 211
Electricity—installed generating capacity: kW _
(2009 est.)
country comparison to the world: 150
Electricity—trom fossil fuels: 5.7% of total
installed capacity (2009 est.)
country comparison to the world: 198
Electricity—from nuclear fuels: 0% of total
installed capacity (2009 est.)
country comparison to the world: 135
Electricity—from hydroelectric plants: 94.3%
of total installed capacity (2009 est.)
country comparison to the world: 9
Electricity—from other renewable sources: 0%
of total installed capacity (2009 est.)
country comparison to the world: 156
Crude oil—production: 0 bbl/day (2011 est.)
country comparison to the world: 163
Crude oil—exports: 0 bbl/day (2009 est.)
country comparison to the world: 149
Crude oll—imports: 0 bbl/day (2009 est.)
country comparison to the world: 94
Crude oil—proved reserves: 0 bb! (1 January
2012 est.)
country comparison to the world: 162
Refined petroleum products—production: 0
bbl/day (2008 est.)
country comparison to the world: 173
Refined petroleum products—consumption:
12,060 bbl/day (2011 est.)
country comparison to the world: 151
Refined petroleum products—exports: 0 bbl/
day (2008 est.)
country comparison to the world: 199
Refined petroleum products—Iimports: 7,209
bbl/day (2008 est.) ‘
country comparison to the world: 140
Natural gas—production: 0 cu m (2010 est.)
country comparison to the world: 163
Natural gas—consumption: 0 cu m (2010 est.)
country comparison to the world: 170
Natural gas—exports: 0 cu m (2010 est.)
country comparison to the world: 142
Natural gas—imports: 0 cu m (2010 est.)
country comparison to the world: 95
Natural gas—proved reserves: 0 cu m (1 Janu-
ary 2012 est.)
country comparison to the world: 167
Carbon dioxide emissions from consumption
of energy: 1.358 million Mt (2010 est.)
country comparison to the world: 159
453','84fbc56cd497b37c0176a110761484f0088cd1ec21bd78bfa7ad4e0e6aed4c4c','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('71e08d2c0effa8338aa2b02c67596b10be04301ce6bb5dbb0152f08e468239e3',2025,'MY','Malaysia','energy',1052,'Electricity—production: 118 billion kWh (2012 est.)
country comparison to the world: 31
Electricity—consumption: 112 billion kWh
(2012 est.) i
country comparison to the world: 29
Electricity—exports: 88 million kWh (2010 est.)
country comparison to the world: 73
Electricity—imports: 33 million kWh (2010 est.)
country comparison to the world: 103
Electricity—installed generating capacity:
25.24 million kW (2009 est.)
country comparison to the world: 32
Electricity—from fossil fuels: 91.7% of total
installed capacity (2009 est.)
country comparison to the world: 73
Electricity—from nuclear fuels: 0% of total
installed capacity (2009 est.)
country comparison to the world: 145
Electricity—trom hydroelectric plants: 8.3% of
total installed capacity (2009 est.)
country comparison to the world: 118
Electricity—from other renewable sources: 0%
of total installed capacity (2009 est.)
country comparison to the world: 163
Crude oil—production: 603,400 bbl/day (2011
est.)
country comparison to the world: 29
Crude oil—exports: 269,000 bbi/day (2012 est.)
country comparison to the world: 27
Crude oil—imports: 199,100 bbl/day (2009 est.)
country comparison to the world: 34
Crude oll—proved reserves: 2.9 billion bbl
(1 January 2013 est.)
country comparison to the world: 30
Refined petroleum products—production:
649,700 bbl/day (2008 est.) :
country comparison to the world: 28
Refined petroleum products—consumption:
542,900 bbl/day (2011 est.)
country comparison to the world: 34
Refined petroleum products—exports: 213,800
bbl/day (2008 est.)
country comparison to the world: 30
Refined petroleum products—imports: 178,200
bhl/day (2008 est.)
country comparison to the world: 29
Natural gas—production: 66.5 billion cu m
(2010 est.)
country comparison to the world: 14
Natural gas—consumption: 35.7 billion cu m
(2010 est.)
country comparison to the world: 27
Natural gas—exports: 31.99 billion cu m (2010
est.) i
country comparison to the world: 13
Natural gas—imports: 2.94 billion cu m (2010
est.)
country comparison to the world: 44
Natural gas—proved reserves: 2.35 trillion cum
(1 January 2012 est.)
country comparison to the world: 16
Carbon dioxide emissions from consumption
of energy: 181.9 million Mt (2010 est.)
country comparison to the world: 30','fade850cb7cb92ff26e2fe68d2e22978163842c871407d9b550f404657b098c9','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('19f4d5a7a1d1ab220fecc9bdd5fe2d8c3473c49d70ba45769140a1e7aaa3ffb0',2025,'MV','Maldives','energy',1060,'Electricity—production: 300 million kWh (2009
est.) 3
country comparison to the world: 171
Electricity—consumption: 279 million kWh
(2009 est.)
country comparison to the world: 177
Electricity—exports: 0 kWh (2012 est.)
country comparison to the world: 107
Electricity—imports: 0 kWh (2012 est.)
country comparison to the world: 111
Electricity—installed generating capacity:
62,010 kW (2009 est.)
country comparison to the world: 176
Electricity—from fossil fuels: 100% of total
installed: capacity (2009 est.)
country comparison to the world: 26
Electricity—trom nuclear fuels: 0% of total
installed capacity (2009 est.)
country comparison to the world: 144
Electricity—from hydroelectric plants: 0% of
total installed capacity (2009 est.)
country comparison to the world: 186
Electricity—from other renewable sources: 0%
of total installed capacity (2009 est.)
country comparison to the world: 162
Crude oll—production: 0 bbl/day (2012 est.)
country comparison to the world: 169
Crude oil—exports: 0 bbi/day (2012 est.)
country comparison to the world: 156
Crude oil—imports: 0 bbl/day (2012 est.)
country comparison to the world: 101
Crude oll—proved reserves: 0 bbl (i January
2012 est.)
country comparison to the world: 168
Refined petroleum products—production: 0
bbl/day (2012 est.)
country comparison to the world: 179
Refined petroleum products—consumption:
6,875 bbl/day (2011 est.)
country comparison to the world: 163
Refined petroleum products—exports: 0 bbl/
day (2009 est.)
country comparison to the world: 204
Refined petroleum products—imports: 6,088
bbl/day (2012 est.)
country comparison to the world: 147
Natural gas—production: 0 cu m (2012 est.)
country comparison to the world: 170
Natural gos—consumption: 0 cu m (2012 est.)
country comparison to the world: 176
Natural gas—exports: 0 cu m (2012 est.)
country comparison to the world: 150
Natural gas—imports: 0 cu m (2012 est.)
country comparison to the world: 101
Natural gas—proved reserves: 0 cu m (1 Janu-
ary 2012 est.)
country comparison to the world: 173
Carbon dioxide emissions from consumption
of energy: 919,00 Mt (2010 est.)
country comparison to the world: 167','54dd889465e0d2c9e59acaa24d0dda6262da0496ec7071613688ee6243313992','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ee3856eaa78265abcd39d443d5b58f227639fd8510c4f6ccf7af339ac3292f84',2025,'ML','Mali','energy',1070,'Electricity—production: 520 million kWh (2009
est.)
country comparison to the world: 161
Electricity—consumption: 483.6 million kWh
(2009 est.)
country comparison to the world: 169
Electricity—exports: 0 kWh (2010 est.)
country comparison to the world: 101
Electricity—imports: 0 kWh (2010 est.)
country comparison to the world: 212
Electricity—installed generating capacity:
304,000 kW (2009 est.)
country comparison to the world: 149
Electricity—from fossil fuels: 48.4% of total
installed capacity (2009 est.)
country comparison to the world: 159
Electricity—from nuclear fuels: 0% of total
installed capacity (2009 est.)
country comparison to the world: 138
Electricity—from hydroelectric plants: 51.6%
of total installed capacity (2009 est.)
country comparison to the world: 40
Electricity—from other renewable sources: 0%
of total installed capacity (2009 est.)
country comparison to the world: 159
Crude oil—production: 0 bbi/day (2011 est.)
country comparison to the world: 166
Crude oil—exports: 0 bbl/day (2009 est.)
country comparison to the world: 152
Crude oll—imports: 0 bbl/day (2009 est.)
country comparison to the world: 96
Crude oil—proved reserves: 0 bbl (1 January
2012 est.)
country comparison to the world: 165
Refined petroleum products—production: 0
bbl/day (2008 est.)
country comparison to the world: 175
Refined petroleum products—consumption:
4,994 bbi/day (2011 est.)
country comparison to the world: 170
Refined petroleum products—exports: 0 bbl/
day (2008 est.)
country comparison to the world: 201
Refined petroleum products—imports: 4,568
bbl/day (2008 est.)
country comparison to the world: 160
Natural gos—production: 0 cu m (2010 est.)
country comparison to the world: 166
Natural gas—consumption: 0 cu m (2010 est.)
country comparison to the world: 172
Natural gas—exports: 0 cu m (2010 est.)
country comparison to the world: 145
Natural gos—imports: 0 cu m (2010 est.)
country comparison to the world: 97 *
Natural gas—proved reserves: cu m (1 January
2012 est.)
country comparison to the world: 170
Carbon dioxide emissions from consumption of
energy: 893,700 Mc (2010 est.)
country comparison to the world: 169','da329c3525b437c005d3b8f5cdeac198d03b4d31277782399bd546814d6d977e','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('811a53c0fe825fc154cb6992dffe87cec626ba299986375874af68164b525eeb',2025,'MT','Malta','energy',1079,'Electricity—production: 2.168 billion kWh
(2011)
country comparison to the world: 134
Electricity—consumption: 1.991 billion kWh
(2010)
country comparison to the world: 141
Electricity—exports: 0 kWh (2011 est.)
country comparison to the world: 105
Etectricity—imports: 0 kWh (2011 est.)
country comparison to the world: 215
Electricity—installed generating capacity:
573,000 kW (2010 est.)
country comparison to the world: 132
Electricity—from fossil fuels: 99.7% of total
installed capacity (2010 est.)
country comparison to the world: 51
Electricity—from nuclear fuels: 0% of total
installed capacity (2010 est.)
country comparison to the world: 142
Electricity—from hydroelectric plants: 0% of
total installed capacity (2010 est.)
country comparison to the world: 184
Electricity—from other renewable sources: 0.3%
of total installed capacity (2010 est.)
country comparison to the world: 83
Crude oil—production: 0 bbi/day (2011 est.)
country comparison to the world: 168
Crude oll—exports: 0 bbi/day (2011 est.)
country comparison to the world: 155
Crude oil—imports: 0 bbl/day (2011 est.)
country comparison to the world: 99
Crude oil—proved reserves: O bbl (1 January
2012 est.)
country comparison to the world: 167
Refined petroleum products—production: 0
bbl/day (2008 est.)
country comparison to the world: 178
Refined petroleum products—consumption:
19,520 bbl/day (2011 est.)
country comparison to the world: 130
Refined petroleum products—exports: NA
(2010 est.)
Refined petroleum products—imports: 47,050
bbi/day (2008 est.)
country comparison to the world: 70
Natural gas—production: 0 cu m (2010 est.)
country comparison to the world: 169
Natural gas—consumption: 0 cu m (2010 est.)
country comparison to the world: 175
Natural gas—exports: 0 cu m (2010 est.)
country comparison to the world: 149
Natural gas—imports: 0 cu m (2010 est.)
country comparison to the world: 100
Natural gas—proved reserves: 0 cu m (1 Janu-
ary 20{2 est.)
country comparison to the world: 172
Carbon dioxide emissions from consumption
of energy: 3.114 million Mt (2010 est.)
country comparison to the world: 140','f6d7ae63f5955c398671ac7016a3474e632a4f016fb574d8315e2e83b51cbb3f','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a3b90fd6b31db77deb7bf977b30717ba713be1325a3041c4e3d8b7af3e34fa53',2025,'MU','Mauritius','energy',1099,'Electricity—production: 2.889 billion kWh
(2009 est.)
country comparison to the world: 129
Electricity—consumption: 2.687 billion kWh
(2009 est.)
country comparison to the world: 135
Electricity—exports: 0 kWh (2010 est.)
country comparison to the world: 103
Electricity—imports: 0 kWh (2010 est.)
country comparison to the world: 213
Electricity—installed generating capacity:
885,200 kW (2009 est.)
477
country comparison to the world: 126
Electricity—from fossil fuels: 75.2% of total
installed capacity (2009 ese.)
country comparison to the world: 100
Electricity—from nuclear fuels: 0% of total
installed capacity (2009 est.)
country comparison to the world: 140
Electricity—from hydroelectric plants: 6.7% of
total installed capacity {2009 est.)
country comparison to the world: 122
Electricity—from other renewable sources:
18.1% of total installed capacity (2009 est.)
country comparison to the world: 7
Crude oil—production: 0 bbi/day (2011 est.)
country comparison to the world: 167
Crude oil—exports: 0 bbi/day (2009 esr.)
country comparison to the world: 154
Crude oll—imports:0 bbl/day (2009 est.)
country comparison to the world: 97
Crude oll—proved reserves: 0 bb! (1 January
2012 est.)
country comparison to the world: 166
Refined petroleum products—production: 0
bbl/day (2008 est.)
country comparison to the world: 176
Refined petroleum products—consumption:
24,710 bbl/day (2011 est.)
country comparison to the world: 124
Refined petroleum products—exports: 0 bbi/
day (2008 est.)
country comparison to the world: 202
Refined petroleum products—imports: 22,750
bbi/day (2008 est.)
country comparison to the world: 102
Natural gas—production: 0 cu m (2010 est.)
country comparison to the world: 167
Natural gas—consumption: 0 cu m (2010 est.)
country comparison to the world: 173
Natural gas—exports: 0 cu m (2010 est.)
country comparison to the world: 147
Natural gas—imports: 0 cu m (2010 est.)
country comparison to the world: 98
Natural gas—proved reserves: 0 cu m (1 Janu-
ary 2012 est.)','97aaf9378023dcfab32ca112e68cd603908cdc72b02d1bae62f1c7570a452b87','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('dce993859e1fe5a40af5c72e92f7ae2610156d4186b47ec7a0b65929e21f901a',2025,'MN','Mongolia','energy',1123,'Electricity—production: 4.48 billion kWh (2010
est.)
country comparison to the world: 122
Electricity—consumption: 4.217 billion kWh
(2010)
country comparison to the world: 121
Electricity—exports: 0 kWh (2012 est.)
country comparison to the world: 97
Electricity—imports: 262.9 million kWh (2010)
country comparison to the world: 84
Electricity—installed generating capacity:
833,200 kW (2009 est.)
country comparison to the world: 128
Electricity—from fossil fuels: 99.9% of total
installed capacity (2009 est.)
country comparison to the world: 47
Electricity—from nuclear fuels: 0% of oral
installed capacity (2009 est.)
493
country comparison to the world: 133
Electricity—from hydroelectric plants: 0% of
total installed capacity (2009 est.)
country comparison to the world: 182
Electricity—from other renewable sources:
0.1% of total installed capacity (2009 est.)
country comparison to the world: 93
Crude ojl—production: 6,983 bbl/day (2011
est.)
country comparison to the world: 85
Crude oli—exports: 5,260 bbl/day (2009 est.)
country comparison to the world: 62
Crude oil—im ports: 0 bbl/day (2009 est.)
country comparison to the world: 92
Crude oil—proved reserves: NA bbl
Refined petroleum products—production: 0
bbl/day (2008 est.)
country comparison to the world: 171
Refined petroleum products—consumption:
21,610 bbl/day (2011 est.)
country comparison to the world: 127
Refined petroleum products—exports: 0 bbl/
day (2010 est.)
country comparison to the world: 197
Refined petroleum products—imports: 15,730
bbl/day (2008 est.)
country comparison to the world: 116
Natural gas—production: 0 cu m (2010 est.)
country comparison to the world: 161
Natural gas—consumption: 0 cu m (2010
est.)
country comparison to the world: 168
Natural gas—exports: 0 cu m (2010 est.)
country comparison to the world: 140
Natural gas—imports: 11,790 cu m (2010
est.)
country comparison to the world: 77
Natural gas—proved reserves: 0 cu m (1 Janu-
ary 2012 est.) l
country comparison to the world: 165
Carbon dioxide emissions from consumption of
energy: 9.436 million Mt (2010 est.)
countrycomparison to the world: 101','c398155c33e9096e43488bf07b70d5eeeaaab0fc99c01b82f360b329ce29975f','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('351f08b4bf48cf9c2c1721015288dcc262e55afa1e8622e2f0919e9b00b80593',2025,'MS','Montserrat','energy',1142,'Electricity—production: 22 million kWh (2009
est.)
country comparison to the world; 212
Electricity—consumption: 20.46 million kWh
(2009 est.)
country comparison to the world: 212
Electricity—exports: 0 kWh (2010 est.)
country comparison to the world: 98
Electricity—imports: 0 kWh (2010 est.)
country comparison to the world: 210
Electricity—instatied generating capacity:
10,000 kW (2009 est.)
country comparison to the world: 203
Electricity—from fossil fuels: 100% of total
installed capacity (2009 est.)
country comparison to the world: 24
Electricity—from nuclear fuels: 0% of total
installed capacity (2009 est.)
country comparison to the world: 134
Electricity—from hydroelectric plants: 0% of
total installed capacity (2009 est.)
country comparison to the world: 183
Electricity—from other renewable sources: 0%
of total installed capacity (2009 est.)
country comparison to the world: 155
Crude oil—production: 0 bbl/day (2011 est.)
country comparison to the world: 162
Crude oil—exports: 0 bbl/day (2009 est.)
country comparison tothe world: 148
Crude oii—imports: 0 bbl/day (2009 est.)
country comparison to the world: 93
Crude oil—proved reserves: 0 bbl (1 January
2012 est.)
country comparison to the world: 161
Refined petroleum products—production: 0
bbl/day (2008 est.)
country comparison to the world: 172
Refined petroleum products—consumption:
1,000 bbl/day (2011 est.)
country comparison to the world: 202
Refined petroleum products—exports: 0 bbi/
day (2008 est.)
country comparison to the world: 198
Refined petroleum products—imports: 572.6
bbl/day (2008 est.)
country comparison to the world: 202
Natura! gas—production: 0 cu m (2010 est.)
country comparison to the world: 162
Natural gas—consumption: 0 cu m (2010
est.)
country comparison to the world:69
Natural gas—exports: 0 cu m (2010 est.)
country comparison to the world: 141
Natural gas—imponts: 0 cu m (2010 est.)
country comparison to the world: 94
Natural gas—proved reserves: 0 cu m (1 Janu-
ary 2012 est.)
country comparison to the world: 166
Carbon dioxide emissions from consumption of
energy: 147,100 Mr (2010 est.)
country comparison to the world: 203
499','ae4b29e9455766b36373c8140002c9bcc00b50b7d20d4b09c5692b95174b6e87','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1e01d9bfb179bea7cdcc2d5f8e62bff7acc85b5795b040eb52b7487ef6710047',2025,'MA','Morocco','energy',1151,'Electricity—production: 20.9 billion kWh (2009
est.)
country comparison to the world: 73
Electricity—consumption: 22.21 billion kWh
(2009 est.)
country comparison to the world: 69
Electricity—exports: 0 kWh (2010 est.)
country comparison to the world: 102
Electricity—imports: 4.623 billion kWh (2009
est.)
country comparison to the world: 39
Electricity—instalied generating capacity:
6.164 million kW (2009 est.)*
country comparison to the world: 68
Electricity—from fossiil fuels: 67.6% of total
installed capacity (2009 est.)
country comparison to the world: 115
Electricity—from nuclear fuels: 0% of total
installed capacity (2009 est.)
country comparison to the world: 139
Electricity—from hydroelectric plants: 20.8%
of total installed capacity (2009 est.)
country comparison to the world: 91
Electricity—from other renewabie sources:
4.1% of total installed capacity (2009 est.)
country comparison to the world: 42
Crude oil—production: 5,500 bbl/day (2011 est.)
country comparison to the world: 89
Crude oli—exports: 0 bbl/day (2009 est.)
country comparison to the world: 153
Crude oi}—imports: 95,460 bbi/day (2009 esr.)
country comparison to the world: 50
Crude oil—proved reserves: 100 million bbl
(1 January 2012 est.)
country comparison to the world: 72
Refined petroleum products—production:
113,300 bbl/day (2008 est.)
country comparison to the world: 70
Refined petroleum products—consumption:
203,600 bbl/day (2011 est.)
country comparison to the world: 58
Refined petroleum products—exports: 15,100
bbl/day (2008 est.)
country comparison to the world: 81
Refined petroleum products—imports: 107,000
bbl/day (2008 est.)
country comparison to the world: 47
Natural gas—production: 70 million cu m (2010
est.)
country comparison to the world: 82
Natural gas—consumption: 570 million cu m
(2010 est.)
country comparison to the world: 98
Natural gos—exports: 0 cu m (2010 est.)
country comparison to the world: 146
Natural gas—imports: 500 million cu m (2010
est.)
country comparison to the world: 67
Natural ges—proved reserves: 1.444 billion cum
(1 January 2012 est.)
country comparison to the world: 98
Carbon dioxide emissions from consumption of
energy: 35.66 million Mt (2010 est.)
country comparison to the world: 72','1016692120bb81080cfe46d15b0b57c674e28bffd55b67db6275bb76805741e0','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3d5694ea7e7ce847c8b3ba5a9244f6fbaf1d569e221c162ce5d4fd430202cb79',2025,'MZ','Mozambique','energy',1161,'Electricity—production: 14.83 billion kWh
(2012 est.) : f
country comparison to the world: 84
Electricity—consumption: 10.19 billion kWh
(2012 est.)
country comparison to the world: 88
Electricity—exports: 9.462 billion kWh (2012
est.)
country comparison to the world: 22
Electricity—imports: 8.537 billion kWh (2012
est.)
country comparison to the world: 26
Electricity—instalied generating capacity:
2.28 million kW (2012 est.)
country comparison to the world: 99
Electricity—from fossii fuels: 0.1% of total
installed capacity (2012 est.)
country comparison to the world: 207
Electricity—from nuciear fuels: 0% of total
installed capacity (2012 est.)
country comparison to the world: 146
Electricity—from hydroelectric plants: 99.9%
of total installed capacity (2012 est.)
country comparison to the world: 2
Electricity—from other renewable sources: 0% of
total installed capacity (2012 est.)
country comparison to the world: 164
Crude oli—production: 0 bbi/day (2011 est.)
country comparison to the world: 170
Crude oll—exports: 0 bbl/day (2009 est.)
country comparison to the world: 157
Crude olli—imports: 0 bbi/day (2009 est.)
country comparison to the world: 103
Crude olt—proved reserves: 0 bb! (1 January
2013 est.) .
country comparison to the world: 169
Refined petroleum products—production: 0
bbl/day (2008 est.)
country comparison to the world: 180
Refined petroleum products—consumption:
19,580 bbl/day (2011 est.)
country comparison to the world: 129
Refined petroleum products—exports: 0 bbi/
day (2008 est.)
country comparison to the world: 205
Refined petroleum products—Iimports: 13,200
bbl/day (2008 est.)
country comparison to the world: 124
Natural gaos—production: 3.12 billion cu m
(2010 est.)
country comparison to the world: 55
Natural gas—consumption: 80 million cu m
(2010 est.)
country comparison to the world: 108
“ Natural gas—exports: 3.4 billion cu m (2010
est.)
country comparison to the world: 36
Natural gas—imports: 0 cu m (2010 est.)
country comparison to the world: 102
Natural gas—proved reserves: 127.4 billion cum
(1 January 2012 est.)
country comparison to the world: 52
Carbon dioxide emissions from consumption
of energy: 2.728 million Mt (2010 est.)
country comparison to the world; 144','93b95c918f8163b6cf4f375d6a3c999c5d7d2150c0187203bab2f4ba02cf6e95','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3eb9c77edb8f1b015dbf890ab0d489670c06605da6610299947c27a8093653cc',2025,'NA','Namibia','energy',1168,'Electricity—production: 1.643 billion kWh
(2012 est.)
country comparison to the world: 139
Electricity—consumption: 3.635 billion kWh
(2012 est.)
country comparison to the world: 127
Electricity—exports: 91 million kWh (2012
est.)
country comparison to the world: 72
Electricity—imports: 2.519 billion kWh (2012
est.)
country comparison to the world: 50
Electricity—installed generating capacity:
508,000 kW (2012 est.)
country comparison to the world: 137
Electricity—from fossil fuels: 33.3% of total
installed capacity (2012 est.)
country comparison to the world: 177
Electricity—from nuclear fuels; 0% of total
installed capacity (2012 est.)
country comparison to the world: 202
Electricity—from hydroelectric plants:
66.7% of total installed capacity (2012 est.)
country comparison to the world: 24
Electricity—trom other renewable sources: 0% of
total installed capacity (2012 est.)
country comparison to the world: 203
Crude oil—production: 0 bbl/day (2012 est.)
country comparison to the world: 204
Crude oil—exports: 0 bbi/day (2012 est.)
country comparison to the world: 204
Crude oil—imports: 0 bbi/day (2012 est.)
country comparison to the world: 140
Crude oil—proved reserves: 0 bbl (1 January
2012 est.)
country comparison to the world: 203
Refined petroleum products—production: 0
bbl/day (2012 est.)
country comparison to the world: 207
Refined petroleum products—consumption:
22,990 bbl/day (2011 est.)
country comparison to the world: 126
Refined petroleum products—exports: 0 bbl/
day (2010 est.)
country comparison to the world: 143
Refined petroleum products—imports: 20,810
bbl/day (2012 est.)
country comparison to the world: 105
Natural gas—production: 0 cu m (2012 est.)
country comparison to the world: 207
Natural gas—consumption: 0 cu m (2012 est.)
country comparison to the world: 207
Natural gas—exports: 0 cu m (2012 est.)
country comparison to the world: 205
Natural gas—imports: 0 cu m (2012 est.)
country comparison to the world: 147
Natural gas—proved reserves: 36.81 billion
cu m (1 January 2013 est.)
country comparison to the world: 69
Carbon dioxide emissions from consumption
of energy: 3.812 million Mt (2010 est.)
country comparison to the world: 132
Electricity—production: 33 million kWh (2009 est.)
country comparison to the world: 209
Electricity—consumption: 30.69 million kWh
(2009 est.)
country comparison to the world: 209
Electricity—exports: 0 kWh (2010 est.)
country comparison to the world: 114
Electricity—imports: 0 kWh (2010 est.)
country comparison to the world: 116
Electricity—installed generating capacity:
11,000 kW (2009 est.)
country comparison to the world: 201
Electricity—from fossil fuels: 100% of total
installed capacity (2009 est.)
country comparison to the world: 30
Electricity—from nuciear fuels: 0% of total
installed capacity (2009 est.)
country comparison to the world: 154
Electricity—from hydroelectric plants: 0% of
total installed capacity (2009 est.)','d1557c16cd554f52d9ab8f9e4fe8a05e26618ba2e000fd915654528c0a0621ab','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4fcd80d154dee01b7171f8e1584553eee8c44a7cb2397bb71589a929123a8515',2025,'NR','Nauru','energy',1175,'country comparison to the world: 190
Electricity—from other renewable sources: 0%
of total installed capacity (2009 est.)
country comparison to the world: 170
Crude oll—production: 0 bbi/day (2011 est.)
country comparison to the world: 175
Crude oil—exports: 0 bbl/day (2009 est.)
country comparison to the world: 163
Crude oil—imports: 0 bbl/day (2009 est.)
country comparison to the world: 110
Crude oil—proved reserves: 0 bbl (1 January
2012 est.)
country comparison to the world: 174
Refined petroleum products—production: 0
_bbl/day (2008 est.)
country comparison to the world: 186
Refined petroleum products—consumption:
1,000 bbl/day (2011 est.)
country comparison to the world: 201
Refined petroleum products—exports: 0 bbl/
day (2008 est.)
country comparison to the world: 210
Refined petroleum products—imports: 1,044
bbl/day (2008 est.)
country comparison to the world: 192
Natural gas—production: 0 cu m (2010 est.)
country comparison to the world: 176
Natural gas—consumption: 0 cu m (2010 est.)
country comparison to the world: 182
Natural gas—exports: 0 cu m (2010 est.)
country comparison to the world: 156
Natural gas—imports: 0 cu m (2010 est.)
country comparison to the world: 110
Natural gas—proved reserves: 0 cu m (1 Janu-
ary 2012 est.)
country comparison to the world: 179
Carbon dioxide emissions from consumption
of energy: 219,700 Mt (2010 est.)
country comparison to the world: 196','1dbbb90b81dd6dbf6bb474dde4eb174be42d38564c51ace25ad12759c65d6a94','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f3defa7a756215679303159f3a23a0d0b9fd1a294dd98b911f411f867058c4ed',2025,'NP','Nepal','energy',1186,'Electricity—production: 3.431 billion kWh
(2012 est.)
country comparison to the world: 127
Electricity—consumption: 5.349 billion kWh
(2012 est.)
country comparison to the world: 112
Electricity—exports: 0 kWh (2010 est.)
country comparison to the world: 113
Electricity—imports: 74 million kWh (2012 est.)
country comparison to the world: 97
Electricity—instailed generating capacity:
717,000 kW (2009 est.)
country comparison to the world: 129
Electricity—from fossil fuels: 7.9% of total
installed capacity (2009 est.)
country comparison to the world: 197
Electricity—from nuclear fuels: 0% of total
installed capacity (2009 est.)
country comparison to the world: 153
Electricity—from hydroelectric plants: 92.1%
of total installed capacity (2009 est.)
country comparison to the world: 10
Electricity—from other renewable sources: 0%
of total installed capacity (2009 est.)
country comparison to the world: 169
Crude oli—production: 0 bbl/day (2011 est.)
country comparison to the world: 174
Crude oil—exports: 0 bbl/day (2009 est.)
country comparison to the world: 162
Crude oil—Iimports: 0 bbl/day (2009 est.)
country comparison to the world: 109
Crude oll—proved reserves: 0 bbl (1 January
2012 est.)
country comparison to the world: 173
Refined petroleum products—production: 0
‘bbl/day (2008 est.)
country comparison to the world: 185
Refined petroleum products—consumption:
18,430 bbl/day (2011 est.)
¥
country comparison to the world: 133
Refined petroleum products—exports: 0 bbl/
day (2008 est.)
country comparison to the world: 209
Refined petroleum products—imports: 17,250
bbl/day (2008 est.)
country comparison to the world: 110
Natural gas—production: 0 cu m (2010 est.)
country comparison to the world: 175
Natural gas—consumption: 0 cu m (2010 est.)
country comparison to the world: 181
Natural gas—exports: 0 cu m (2010 est.)
country comparison to the world: 155
Natura! gas—imports: 0 cu m (2010 est.)
country comparison to the world: 109
Natural gas—proved reserves: 0 cu m (1 Janu-
ary 2012 est.)
country comparison to the world: 178
Carbon dioxide emissions from consumption
of energy: 3.359 million Mt (2010 est.)
country comparison to the world: 137','185054c2c8a8233b56f269747b9ef514b2d5bcf2aa5affa5883ec9db8383e2e1','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('16af1e7581c2902967a74c89dba6dfbc3d31fd984df701df06e92d5f4e5ecf03',2025,'NL','Netherlands','energy',1196,'Electricity—production: 108 billion kWh (2010
est.) .
country comparison to the world: 34
Electricity—consumption: 107.4 billion kWh
(2009 est.)
country comparison to the world: 31
Electricity—exports: 12.81 billion kWh (2010
est.)
country comparison to the world: 15
Electricity—imports: 15.58 billion kWh (2010
est.)
country Comparison to the world: 12
Electricity—installed generating capacity:
25.99 million kW (2009 est.)
country comparison to the world: 31
Electricity—from fossil fuels: 84.1% of total
installed capacity (2009 est.)
country comparison to the world: 88
Electricity—from nuclear fuels: 2% of total
installed capacity (2009 est.)
country comparison to the world: 30
Electricity—from hydroelectric plants: 0.1% of
total installed capacity (2009 est.)
country comparison to the world: 150
Electricity—from other renewable sources:
13.7% of total installed capacity (2009 est.)
country comparison to the world: 12
Crude oll—production: 41,990 bbi/day (2011
est.)
country comparison to the world: 64
Crude oll—exports: 13,140 bbl/day (2009 est.)
country comparison to the world: 56
Crude oil—Imports: 964,100 bbl/day (2009 est.)
country comparison to the world: 11
fuels,
Crude oll—proved reserves: 287.4 million bbl
(1 January 2012 est.)
country comparison to the world: 56
Refined petroleum products—production:
1.239 million bbl/day (2009 est.)
country comparison to the world: 19
Refined petroleum products—consumption:
1.01 million bbl/day (2011 est.)
country comparison to the world: 22
Refined petroleum products—exports: 1.858
million bbl/day (2009 est.)
country comparison to the world: 5
Refined petroleum products—imports: 1.61
million bbl/day (2009 est.)
country comparison to the world: 3
Natural gas—production: 81.09 billion cum
(2011 est.)
country comparison to the world: 13
Natural gas—consumption: 49.05 billion cum
(2011 est.)
country comparison to the world: 17
Natural gas—exports: 54.8 billion cum (2011
est.)
country comparison to the world: 8
Natural gas—imports: 22.76 billion cu m (2011
est.)
country comparison to the world: 16
Natural gas—proved reserves: 1.303 trillion
cu m (1 January 2012 est.)
country comparison to the world: 24
Carbon dioxide emissions from consumption
of energy: 263.4 million Mt (2010 est.)
country comparison to the world: 25','0967b94aacb534f5e4f4017ae5b374102a2bac8bad77172d9d8f801843470cba','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('edfa20032bf7f1f6db77c08049b19a60283c5496940edc6c70ad5b9ad6a53479',2025,'NC','New Caledonia','energy',1202,'Electricity—production: 1.675 billion kWh
(2009 est.)
country comparison to the world: 138
Electricity—consumption: 1.558 billion kWh
(2009 est.)
country comparison to the world: 145
Electricity—exports: 0 kWh (2010 est.)
country comparison to the world: 108
Electricity—imports: 0 kWh (2010 est.)
country comparison to the world: 112
Electricity—instailed generating capacity:
421,000 kW (2009 est.)
country comparison to the world: 141
Electricity—from fossil fuels: 79.1% of total
installed capacity (2009 est.)
country comparison to the world: 93
Electricity—trom nuciear fuels: 0% of total
installed capacity (2009 est.)
country comparison to the world: 147
Electricity—trom hydroelectric plants: 18.5%
of total installed capacity (2009 est.)
country comparison to the world: 94
523
Electricity—from other renewable sources:
2.4% of total installed capacity (2009 est.)
country comparison to the world: 54
Crude oli—production: 0 bbl/day (2011 est.) .
country comparison to the world: 171
Crude oil—exports: 0 bbl/day (2009 est.)
country comparison to the world: 158
Crude oll—imports: 0 bbl/day (2009 est.)
country comparison to the world: 104
Crude oil—proved reserves: 0 bbl (1 January
2012 est.)
country comparison to the world: 170
Refined petroleum products—production: 0
bbl/day (2008 esr.)
country comparison to the world: 181
Refined petroleum products—consumption:
13,640 bbl/day (2011 est.)
country comparison to the world: 149
Refined petroleum products—exports: 730 bbl/
day (2008 est.)
country comparison to the world: 115
Refined petroleum products—imports: 14,550
bbl/day (2008 est.)
country comparison to the world: 121
Natural gas—production: 0 cu m (2010 est.)
country comparison to the world: 171
Natural gas—consumption: 0 cu m (2010 est.)
country comparison to the world: 177
Natural gas—exports: 0 cu m (2010 est.)
country comparison to the world: 151
Natura! gas—imports: 0 cu m (2010 est.)
country comparison to the world: 103
Natural gas—proved reserves: 0 cu m (1 Janu-
ary 2012 est.)
THE CIA WORLD FACTBOOK
country comparison to the world: 174
Carbon dioxide emissions from consumption
of energy: 3.027 million Mt (2010 est.)
country comparison to the world: 141','bb28b8ae32a315793dd3a138a845896af3eb43d3d04a1830d14b807014b73992','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2311af2d2fbc7c066a32c0fd8ea312579856a0a03e6e9eaaf76dedd7b613738c',2025,'NZ','New Zealand','energy',1208,'Electricity—production: 43.4 billion kWh (2010
est.)
country comparison to the world: 55
Electricity—consumption: 38.96 billion kWh
(2009 est.) 2 bi.
country comparison to the world: 54
Electricity—exports: 0 kWh (2010 est.)
country comparison to the world: 116
Electricity—imports: 0 kWh (2010 est.)
country comparison to the world: 118
Electricity—installed generating capacity:
9.482 million kW (2009 est.)
country comparison to the world: 59
Electricity—from fossil fuels: 30% of total
installed capacity (2009 est.)
country comparison to the world: 180
Electricity—from nuclear fuels: 0% of total
installed capacity (2009 est.)
country comparison to the world: 157
Electricity—trom hydroelectric plants: 56.7%
of total installed capacity (2009 est.)
country comparison to the world: 36
Electricity—from other renewable sources:
13.3% of total installed capacity (2009 est.)
country comparison to the world: 14
Crude oil—production: 49,730 bbl/day (2011
est.)
country comparison to the world: 59
Crude oli—exports: 45,180 bbl/day (2009 est.)
country comparison to the world: 48
Crude oil—imports: 90,840 bbl/day (2009 est.)
country comparison to the world: 51
Crude oll—proved reserves: 96.1 million bbl
(1 January 2012 est.)
country comparison to the world: 73
Refined petroleum products—production:
106,000 bbi/day (2009 est.)
country comparison to the world: 73
Refined petroleum products—consumption:
148,900 bbl/day (2011 est.)
country comparison to the world: 68
Refined petroleum products—exports: 2,883
bbl/day (2009 est.)
country comparison to the world: 103
Refined petroleum products—imports: 46,780
bbi/day (2009 est.)
country comparison to the world: 71
Natural gas—production: 4.367 billion cu m
(2011 est.)
country comparison to the world: 52 |
Natural gas—consumption: 4.278 billion cu m
(2011 est.)
country comparison to the world: 64
Natural gas—exports: 0 cu m (2011 est.)
country comparison to the world: 159
Natural gas—imports: 0 cu m (2011 est.)
country comparison to the world: 113
Natural gas—proved reserves: 27.64 billion
cu m (1 January 2012 est.)
country comparison to the world: 74
Carbon dioxide emissions from consumption
of energy: 39.58 million Mt (2010 est.)
country comparison to the world: 70','e92710534536f0cba8d4d90755ab1f0bb3fdecda6cdc985018f3d8bd5a2e02b6','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6ef001ed431b0462acf01ddd3bc73187d2d907675808da089984b6808e635975',2025,'NI','Nicaragua','energy',1219,'Electricity—production: 3.824 billion kWh
(2011 est.)
country comparison to the world: 125
Electricity—consumption: 2.941 billion kWh
(2011 est.)
country comparison to the world: 134
Electricity—exports: 40,560 kWh (2011 est.)
country comparison to the world: 89
Electricity—imports: 9,930 kWh (2011 est.)
country comparison to the world: 109
Eleetricity—installed generating capacity:,
1.108 million kW (2011 est.)
country comparison to the world: 123
Electricity—from fossil fuels: 66% of toral
installed capacity (2011 est.)
country comparison to the world: 122
Electricity—from nuclear fuels: 0% of total
installed capacity (2011 est.)
country comparison to the world: 156
Electricity—trom hydroelectric plants: 9.5% of
total installed capacity (2011 est.)
country comparison to the world: 117
Electricity—from other renewable sources:
24.5% of total installed capacity (2011 est.)
country comparison to the world: 3
Crude oil—production: 0 bbl/day (2011 est.)
country comparison to the world: 176
Crude oil—exports: 0 bbl/day (2011 est.)
country comparison to the world: 165
Crude oll—imports: 16,020 bbl/day (2011 est.)
country comparison to the world: 73
Crude oit—proved reserves: 0 bbl (1 January 2012 es)
country comparison to the world: 175
Refined petroleum products—production:
14,680 bbl/day (2008 est.)
country comparison to the world: 103
Refined petroleum products—consumption:
30,690 bbl/day (2011 est.)
country comparison to the world: 115
Refined petroleum products—exports: 999.6
bbl/day (2011 est.)
country comparison to the world: 111
Refined petroleum products—imports: 15,830
bbl/day (2011 est.)
country comparison to the world: 114
Natural gas—production: 0 cu m (2012 est.)
country comparison to the world: 178
Natural gas—consumption: 0 cu m (2012 est.)
country comparison to the world: 184
Natural gas—exports: 0 cu m (2012 est.)
country comparison to the world: 158
Natural gas—imports: 0 cu m (2012 est.)
country comparison to the world: 112
Natural gas—proved reserves: 0 cu m (1 Janu-
ary 2012 es)
country comparison to the world: 181
Carbon dioxide emissions from consumption
of energy: 4.825 million Mt (2010 est.)
country comparison to the world: 125','c4ada49783b532c2bff4323a0ce56e3394dfb057876df6a33d42f79d32b670ba','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e15919e279c38f6e7fc0d47722155085cd498a7909f61d431f8664f740463903',2025,'NE','Niger','energy',1225,'Electricity—production: 210 million kWh (2009
est.)
country comparison to the world: 179
Electricity—consumption: 695.3 million kWh
(2009 est.)
country comparison to the world: 159
Electricity—exports: 0 kWh (2010 est.)
country comparison to the world: 110
Electricity—imports: 500 million kWh (2009
est.)
country comparison to the world: 78
Electricity—instalied generating capacity:
145,9 kW (2009 est.) `
country comparison to the world: 159
Electricity—from fossil fuels: 100% of total
installed capacity (2009 est.)
country comparison to the world: 28
Electricity—from nuctear fuels: 0% of total
installed capacity (2009 est.)
country comparison to the world: 149
Electricity—from hydroelectric plants: 0% of
total installed capacity (2009 est.)
country comparison to the world: 188
Electricity—from other renewable sources: 0%
of total installed capacity (2009 est.)
country comparison to the world: 166
Crude oll—production: 6,712 bbi/day (2011 est.)
country comparison to the world: 86
Crude oil—exports: 0 bbl/day (2009 est.)
country comparison to the world: 160
Crude oil—imports: 0 bbl/day (2009 est.)
country comparison to the world: 106
Crude oll—proved reserves: NA bbl (1 January
2012 est.)
Refined petroleum products—production: 0
bbl/day (2008 est.)
country comparison to the world: 183
Refined petroleum products—consumption:
5,629 bbi/day (2011 est.)
country comparison to the world: 166
Refined petroleum products—exports: 0 bb!/
day (2008 est.)
country comparison to the world: 207
Refined petroleum products—imports: 3,330
bbl/day (2008 est.)
country comparison to the world: 166
Natural gas—production: 0 cu m (2010 est.)
country comparison to the world: 173
Natural gas—consumption: 0 cu m (2010 est.)
country comparison to the world: 179
Natural gas—exports: 0 cu m (2010 est.)
country comparison to the world: 153
Notural gas—imports: 0 cu m (2010 est.)
country comparison to the world: 105
Natural gas—proved reserves: 0 cu m (1 Janu-
ary 2012 est.)
country comparison to the world: 176
Carbon dioxide emissions from consumption
of energy: 1.796 million Mt (2010 est.)
country comparison to the world: 152','302578ffa0d7eb321a33fca24bbdebd852b414ffb7f32b33566643c8688c61d5','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4f5411ee20e5e210b26b9a25fa59fd7569392adf81a0e9070630ca2c0a037cb0',2025,'NG','Nigeria','energy',1233,'Electricity—production: 18.82 billion kWh
(2009 est.)
country comparison to the world: 75
Electricity—consumption: 17.66 billion kWh
(2009 est.) |
country comparison to the world: 71
Electricity—exports: 0 kWh (2010 est.)
country comparison to theworld: 112
Electricity—Iimports: 0 kWh (2010 est.)
country comparison to the world: 115
Electricity—instalied generating capacity:
5.898 million kW (2009 est.)
country comparison to the world: 70
Electricity—from fossil fuels: 67.1% of total
installed capacity (2009 est.)
country comparison to the world: 116
Electricity—from nuclear fuels: 0% of total
installed capacity (2009 est.)
country comparison to the world: 151
Electricity—from hydroelectric plants: 32.9%
of total installed capacity (2009 est.)
country comparison to the world: 66
Electricity—from other renewable sources: 0%
of total installed capacity (2009 est.)
country comparison to the world: 168
Crude oil—production: 2.525 million bbl/day
(2011 est.)
country comparison to the world: 13
Crude oil—exports: 2 million bbl/day (2009 est.)
country comparison to the world: 6
Crude oil—imports: 0 bbl/day (2009 est.)
country comparison to the world: 108
Crude olli—proved reserves: 38.5 billion bbl
(1 January 2012 est.)
country comparison to the world: 11
Refined petroleum products—production:
102,100 bbl/day (2008 est.)
country comparison to the world: 76
Refined petroleum products—consumption:
271,600 bbl/day (2011 est.) ''
country comparison to the world: 47
Refined petroleum products—exports: 15,470
bbl/day (2008 est.)
country comparison to the world: 79
Refined petroleum products—Iimports: 133,400
bbl/day (2008 est.)
country comparison to the world: 42
Natural gas—production: 29 billion cu m (2010
est.)
country comparison to the world: 30
Natural gas—consumption: 4.97 billion cum
(2010 est.)
country comparison to the world: 61
Natural gas—exports: 24.02 billion cu m (2010
est.)
country comparison to the world: 15
Natural gas—imports: 0 cu m (2010 est.)
country comparison to the world: 107
Natural gas—proved reserves: 5.11 trillion
cu m (1 January 2012 est.)
country comparison to the world: 10
Carbon dioxide emissions from consumption
of energy: 80.51 million Mt (2010 est.)
country comparison to the world: 44
Electricity—production: 3 million kWh (2009
est.)
country comparison to the world: 216
Electricity—consumption: 2.79 million kWh
(2009 est.)
country comparison to the world: 216
Electricity—exports: 0 kWh (2010 est.)
country comparison to the world: 109
Electricity—imports: 0 kWh (2010 est.)
country comparison to the world: 113
Electricity—installed generating capacity:
1,000 kW (2009 est.)
country comparison to the world: 209
Etectricity—from fossil fuels: 100% of. total
installed capacity (2009 est.)
country comparison to the world: 27
Electricity—from nuclear fuels: 0% of total
installed capacity (2009 est.)
country comparison to the world: 148
Electricity—from hydroelectric plants: 0% of
total installed capacity (2009 est.)
country comparison to the world: 187','75d1e41aed771afb002546558e2affb77b53c8ad32d5fad39e5ad40b7443ef02','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f0280591d9f9459612a1e0d621adc3489b2fdb51e49c70f71c1a0c29dd354b8f',2025,'NU','Niue','energy',1237,'Electricity—from other renewable sources: 0%
of total installed capacity (2009 est.)
country comparison to the world: 165
Crude olli—production: 0 bbi/day (2011 est.)
country comparison to the world: 172
Crude oil—exports: 0 bbl/day (2009 est.)
country comparison to the world: 159
Crude olli—imports: 0 bbl/day (2009 est.)
country comparison to the world: 105
Crude oil—proved reserves: bbl (1 January
2013 est.)
country comparison to the world: 171
Refined petroleum products—production: bbl/
day (2008 est.)
country comparison to the world: 182
Refined petroleum products—consumption:
NA bbl/day (2011 est.)
Refined petroleum products—exports: bbl/day
(2008 est.)
country comparison to the world: 206
Refined petroleum products—imports: 22.57
bbl/day (2008 est.)
country comparison to the world: 208
Natural gas—production: 0 cu m (2010 est.)
country comparison to the world: 172
Natural gas—consumption: 0 cu m (2010 est.)
country comparison to the world: 178
Natural gas—exports: 0 cu m (2010 est.)
country comparison to the world: 152
Natural gas—imports: 0 cu m (2010 est.)
country comparison to the world: 104
Natural gas—proved reserves: 0 cu m (1 Janu-
ary 2012 est.) s
country comparison to the world: 175
Carbon dioxide emissions from consumption
of energy: 6,220 Mt (2010 est.)
country comparison to the world: 210','2578e2be8b0c746d497b6ab32a42d2d46fdbd6a1af27952b5c1c4b76b04baf25','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('701e26757528d0f7e9170ffc3fa29449d09e857484368116651678ee4d7071ad',2025,'MP','Northern Mariana Islands','energy',1248,'Electricity—production: 60,600 kWh (January
2009)
country comparison to the world: 217
Electricity—consumption: 48,300 kWh (Janu-
ary 2009)
country comparison to the world: 218
Electricity—exports: 0 kWh (January 2009 est.)
country comparison to the world: 181
Electricity—imports: 0 kWh (January 2009 est.)
country comparison to the world: 173
Telephone system: international: country
code—I -670; satellite earth stations—2 Intelsat
(Pacific Ocean) Broadcast media: 0 TV broad-
cast station on Saipan; multi-channel cable TV
services are available on Saipan; 9 licensed radio
broadcast stations (2009)
Internet country code:.mp
Internet hosts: 17 (2012)
country comparison to the world: 223
Airports: 5(2012)
country comparison to the world: 180
Alrports—with paved runways: total: 3
2,438 to 3,047 m: 2
1,524 to 2,437 m: 1 (2012)
Airports—with unpaved runways: total: 2
2,438 to 3,047 m: 1
under 914 m: 1 (2012)
Heliports: (2012)
Roadways: total: 536 km (2008)
country comparison to the world: 193
NORTHERN MARIANA
Ports and terminals: Saipan, Tinian, Rota','06f69e000e4c71b34285099cdbc57d6cf8a2fe93ba5f92a3a7ea8a3fbdfcc234','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3ceb87d3165889e6b072fda51e0eaeaa550d6c3b214c3b46f2fc0b121d6cbfc8',2025,'NO','Norway','energy',1252,'Electricity—production: 122.2 billion kWh
(2010 est.)
country comparison to the world: 30
Electricity—consumption: 110.8 billion kWh
(2009 est.)
country comparison to the world: 30
Electricity—exports: 7.123 billion kWh (2010
est.)
country comparison to the world: 24
Electricity—imports: 14.67 billion kWh (2010
est.)
country comparison to the world: 14
Electricity—installed generating capacity:
30.95 million kW (2009 est.)
country comparison to the world: 28
Electricity—from fossil fuels: 2.6% of total
installed capacity (2009 est.)
country comparison to the world: 201
547
Electricity—from nuclear fuels: 0% of total
installed capacity (2009 est.)
country comparison to the world: 152
Electricity—from hydroelectric plants: 91.1%
of total installed capacity (2009 est.)
country comparison to the world: 11
Electricity—from other renewable sources: 2%
of total installed capacity (2009 est.)
country comparison to the world: 58
Crude oil—production: 1.998 million bbl/day `
(2011 est.)
country comparison to the world: 15
Crude oll—exports: 1.759 million bbl/day (2009
est.)
country comparison to the world: 8
Crude oll—imports: 19,960 bbl/day (2009 est.)
country comparison to the world: 70
Crude oll—proved reserves: 5.32 billion bbl
(1 January 2010 est.)
country comparison to the world: 24
Refined petroleum products—production:
324.0 bbl/day (2009 est.)
country comparison to the world: 41
Refined petroleum products—consumption:
255,200 bbl/day (2011 est.)
country comparison to the world: 52
Refined petroleum products—exports: 412,600
bbl/day (2009 est.)
country comparison to the world: 20
Refined petroleum products—imports: 98,340
bbl/day (2009 est.)
country comparison to the world: 50
Natural gas—production: 103.1 billion cu m
(2011 est.)
country comparison to the world: 9
Natural gas—consumption: 4.809 billion cu m
(2011 est.)
country comparison to the world: 62
Natural gas—exports: 98.3 billion cu m (2011
est.)
country comparison to the world: 4
Natural gas—imports: o cu m (2011 est.)
country comparison to the world: 108
Natural gas—proved reserves: 2.7 trillion cu m
(1 January 2012 est.)
country comparison to the world: 19
Carbon dioxide emissions from consumption
of energy: 41.8 million Mt (2010 est.)
country comparison to the world: 68','c50fa2555a01a43020cfc9fbebc0b790cff5811ae297d9b61f2b4f764a28baec','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b0de4834ac8a157c36fb95a592a68b8dbc57ad1e54349cf0b5f4d5fa1809f803',2025,'OM','Oman','energy',1259,'Electricity—production: 18.59 billion kWh
(2010 est.)
country comparison to the world: 76
Electricity—consumption: 15.34 billion kWh
(2009 est.)
country comparison to the world: 77
Electricity—exports: 0 kWh (2010 est.)
country comparison to the world: 106
Electricity—imports: 0 kWh (2010 est.)
country comparison to the world: 110
Electricity—installed generating capacity:
4.202 million kW (2009 est.)
country comparison to the world: 78
Electricity—from fossil fuels: 100% of total
installed capacity (2009 est.)
country comparison to the world: 25
Electricity—from nuclear fuels: 0% of cotal
installed capacity (2009 est.)
country comparison to the world: 143
Electricity—trom hydroelectric plants:,0% of
total installed capacity (2009 est.)
country comparison to the world: 185
Electricity—from other renewable sources: 0%
of total installed capacity (2009 est.)
country comparison to the world: 161
Crude olli—production: 915,600 bbl/day (2012
est.)
country comparison to the world: 23
Crude oll—exports: 253,100 bbl/day (2012 est.)
country comparison to the world: 28
Crude oil—im ports: 0 bbl/day (2009 est.)
country comparison to the world: 100
Crude oil—proved reserves: 4.902 billion bbl
(1 January 2012 est.)
country comparison to the world: 26
Refined petroleum products—production:
106.0 bbl/day (2008 esr.)
country comparison to the world: 72
Refined petroleum products—consumption:
98.0 bbl/day (2011 est.)
country comparison to the world: 80
Refined petroleum products—exports: 19,680
bbl/day (2008 est.)
country comparison to the world: 73
Refined petroleum products—imports: 33,150
bbl/day (2008 est.)
country comparison to the world: 85
Natural gas—production: 35.94 billion cum
(2012 est.)
country comparison to the world: 27
Natural gos—consumption: 17.53 billion cum
(2011 est.)
country comparison to the world: 38
Natural gas—exports: 11.49 billion cu m (2010
est.)
country comparison to the world: 21
Natural gas—imports: 1.9 billion cum (2010
est.)
country comparison to the world: 51
Natural gas—proved reserves: 849.5 billion
cum (1 January 2012 est.)
country comparison to the world: 28
Carbon dioxide emissions from consumption
of energy: 55.2 million Mt (2010 est.)
country comparison to the world; 58','f383830b2f42e9199127c9f9a3221fd919563e7667c62dc3d5b9e67ccff2f738','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('57a1bba562e6401bf5e81bcccf240e689efd81ec788a33660c297665fe7751be',2025,'PK','Pakistan','energy',1270,'Electricity—production: 94.65 billion kWh
(2011 est.)
country comparison to the world: 35
Electricity—consumption: 70.1 billion kWh
(2011 est.)
country comparison to the world: 39
Electricity—exports: 0 kWh (2011 est.)
country comparison to the world: 118
Electricity—imports: 0 kWh (2010 est.)
country comparison to the world: 120
Electricity—installed generating capacity:
20.2 million kW (2009 est.)
country comparison to the world: 37
Electricity—from fossil fuels: 65.2% of total
installed capacity (2009 est.)
country comparison to the world: 127
Electricity—from nuciear fuels: 2.3% of total
installed capacity (2009 est.)
country comparison to the world: 27
Electricity—from hydroelectric plants: 32.5%
of total installed capacity (2009 est.)
country comparison to the world: 67
Electricity—from other renewable sources: 0%
of total installed capacity (2009 est.)
country comparison to the world: 174
Crude oll—production: 63,080 bbl/day (2011
est.)
country comparison to the world: 56
Crude oll—exports: 0 bbl/day (2009 est.)
country comparison to the world: 167
Crude oll—imports: 183,000 bbl/day (2009 est.)
country comparison to the world: 36
Crude oil—proved reserves: 480.9 million bbl
(1 January 2013 est.)
country comparison to the world: 52
Refined petroleum products—production:
215,900 bbl/day (2008 est.)
country comparison to the world: 53
Refined petroleum products—consumption:
426,700 bbl/day (2011 est.)
country comparison to the world: 35
Refined petroleum products—exports: 26,830
bbl/day (2008 est.)
country comparison to the world: 70
Refined petroleum products—Imports: 195,700
bbl /day (2008 est.)
country comparison to the world: 26
Natural gas—production: 42.9 billion cu m
(2011 est.)
country comparison to the world: 24
Natural gas—consumption: 42.9 billion cu m
(2011 est.)
country comparison to the world: 24
Natural gas—exports: 0 cu m (2010 est.)
country comparison to the world: 161
Natural gas—imports: 0 cu m (2010 est.) coun-
try comparison to the world: 116
Natural gas—proved reserves: 753.8 billion
cu m (1 January 2012 est.)
country comparison to the world: 30
Carbon dioxide emissions from consumption
of energy: 151.6 million Mr (2010 est.)
country comparison to the world: 34','8260d65fe4d2ba4f7627872c9cade657b955ca32e9ecb92b519c8337d6d47564','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('42d8bfe20623120379400ff8442d0f5da9a8653a7e019cca77d126a7b4d78bd1',2025,'PA','Panama','energy',1287,'Electricity—production: 6.546 billion kWh
(2010 est.)
country comparison to the world: 107
Electricity—consumption: 5.805 billion kWh
(2010 est.)
_ country comparison to the world: 107
Electricity—exports: 39 million kWh (2010 est.)
country comparison to the world: 79
Electricity—imports: 71 million kWh (2010 est.)
country comparison to the world: 99
Electricity—instailed generating capacity:
1.815 million kW (2009 est.)
country comparison to the world: 106
Electricity—from fossil fuels: 51.6% of total
installed capacity (2009 est.)
country comparison to the world: 154
Electricity—from nuclear fuels: 0% of total
installed capacity (2009 est.)
country comparison to the world: 161
Electricity—from hydroelectric plants: 48.4%
of total installed capacity (2009 est.)
country comparison to the world: 44
Electricity—from other renewable sources: 0%
of total installed capacity (2009 est.)
country comparison to the world: 175
Crude-oil—production: 0 bbl/day (2011 est.)
country comparison to the world; 178
Crude oil—exports: 0 bbi/day (2009 est.)
country comparison to the world: 168
Crude oi/—imports: 0 bbl/day (2009 est.)
country comparison to the world: 112
Crude oii—proved reserves: 0 bb! (1 January
2010 est.)
country comparison to the world: 177
Refined petroleum products—production: 0
bbl/day (2008 est.)
country comparison to the world: 188
Refined petroleum products—consumption:
98,890 bbl/day (2011 est.) š
country comparison to the world: 79
Refined petroleum products—exports: 0 bbl/
day (2008 est.)
country comparison to the world: 125
Refined petroleum products—imports: 46,370
bbl/day (2008 est.) p
country comparison to the world: 72
Natural gas—production: 0 cu m (2010 est.)
country comparison to the world: 180
Natural gas—consumption: 0 cu m (2010 est.)
“country comparison to the world: 186
Natural gas—exports: 0 cu m (2010 est.)
country comparison to the world: 162
Natural gas—imports: 0 cu m (2010 est.)
country comparison to the world: 117
Natural gas—proved reserves: 0 cu m (1 Janu-
ary 2012 est.)
country comparison to the world: 183
Carbon dioxide emissions from consumption
of energy: 15.46 million Mt (2010 est.)
country comparison to the world: 89','5cf766673a36eb3007848ee1036b041588374dec5130ca4876d9bc6dac63f8e2','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('85d965e8c91e7c9285b9d0a2c92b715628f557eb0d7e161ade5bed0b4e421d80',2025,'PG','Papua New Guinea','energy',1297,'Electricity—production: 3.331 billion kWh
(2009 est.)
country comparison to the world: 128
Electricity—consumption: 3.098 billion kWh
(2009 est.)
country comparison to the world: 133
Electricity—exports: 0 kWh (2010 est.)
country comparison to the world: 119
Electricity—imports: 0 kWh (2010 est.)
country comparison to the world: 121
Electricity—installed generating capacity:
700,000 kW (2009 est.)
country comparison to the world: 130
Electricity—from fossil fuels: 61.1% of toral
installed capacity (2009 est.)
country comparison to the world: 136
Electricity—from nuclear fuels: 0% of total
installed capacity (2009 est.) je f
country comparison to the world: 163
Electricity—from hydroelectric plants: 30.9%
of total installed capacity (2009 est.)
country comparison to the world: 75
Electricity—from other renewable sources: 8%
of total installed capacity (2009 est.)
country comparison to the world: 25
Crude oil—production: 30,000 bbl/day (2011
est.)
country comparison to the world: 66
Crude oil—exports: 0 bbl/day (2009 est.)
country comparison to the world: 170
Crude oil—im ports: 15,100 bbl/day (2009 est.)
country. comparison to the world: 74
Crude oil—proved reserves: 170 million bbl
(1 January 2012 est.)
country comparison to the world: 66
Refined petroleum products—production:
16,080 bbl/day (2008 est.)
country comparison to the world: 101
Refined petroleum products—consumption:
36,320 bbl/day (2011 est.)
country comparison to the world: 112
Refined petroleum products—exports: 3,536
bbl/day (2008 est.)
country comparison to the world: 100
Refined petroleum products—imports: 7,201
bbi/day (2008 est.)
country comparison to the world: 141
Natural gas—production: 110 million cu m
(2010 est.)
country comparison to the world: 80
Natural gas—consumption: 110 million cu m
(2010 est.)
country comparison to the world: 105
Natural gas—exports: 0 cu m (2010 est.)
country comparison to the world: 164
Natural gas—imports: 0 cu m (2010 est.)
country comparison to the world: 118
Natural gas—proved reserves: 155.3 billion
cu m (1 January 2012 est.)
country comparison to the world: 49
Carbon dioxide emissions from consumption
of energy: 5.306 million Mt (2010 est.)
country comparison to the world: 121','5a6d631c0d0408e5d906eb870c6f4a65b78b7eb2d823c6160d9ef17e46d4d1a5','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('09fc59dd2b5288231aa7676ca0c1c03bf4ae1b13ca2585bbb1ed6d543c50fcd7',2025,'PE','Peru','energy',1309,'Electricity—production: 38.7 billion kWh (2011
est.)
country comparison to the world: 60
Electricity—consumption: 34.25 billion kWh
(2011 est.)
country comparison to the world: 59
Electricity—exports: 0 kWh (2011 est.)
country comparison to the world: 117
Electricity—imports: 6 million kWh (2011 est.)
country comparison to the world: 106
Electricity—instalied generating capacity:
7.982 million kW (2009 est.)
country comparison to the world: 64
Electricity—from fossil fuels: 59% of total
installed capacity (2009 est.)
country comparison to the world: 139
Electricity—from nuclear fuels: 0% of total
installed capacity (2009 est.)
country comparison to the world: 159
Electricity—from hydroelectric plants: 41% of
total installed capacity (2009 est.)
country comparison to the world: 55
Electricity—from other renewable sources: 0%
of total installed capacity {2009 est.)
country comparison to the world: 173
Crude oil—production: 152,600 bbl/day (2011
est.) ` :
country comparison to the world: 45
Crude oil—exports: 18,880 bbl/day (2009 est.)
country comparison to the world: 54
Crude oll—imports: 99,590 bbl/day (2009 est.)
country comparison to the world: 49
Crude oil—proved reserves: 586.1 million bbl
(1 January 2012 est.)
country comparison to the world: 49
Refined petroleum products—production:
173,700 bbl/day (2008 est.)
country comparison to the world: 59
Refined petroleum products—consumption:
172,600 bbl/day (2011 est.)
country comparison to the world: 62
Refined petroleum products—exports: 60,720
bbl/day (2008 est.)
country comparison to the world: 55
Refined petroleum products—imports: 38,390
bbl/day (2008 est.)
country comparison to the world: 78
Natural gas—production: 31.12 billion cu m
(2011)
country comparison to the world: 29
Natural gas—consumption: 5.41 billion cu m
(2010 est.)
country comparison to the world: 57
Natural gos—exports: 3.59 billion cu m (2010
est.)
country comparison to the world: 33
Natural gas—imports: 0 cu m (2011)
country comparison to the world: 115
Natural gas—proved reserves: 352.8 billion
cu m (1 January 2012 est.)
country comparison to the world: 38
Carbon dioxide emissions from consumption
of energy: 41.88 million Mt (2010 est.)
country comparison to the world: 67','c3fb7f2870ab5cf9fba0a4d22f1413ee79369ff56f69be3c718adf25f324920f','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4edccccf4e49f9183e61b10b8710554ef60ffb548b9a8b72ec80d1fab566944b',2025,'PH','Philippines','energy',1320,'Electricity—production: 67.74 billion kWh
(2010 est.)
country comparison to the world: 42
Electricity—consumption: 64.52 billion kWh
(2010 est.)
country comparison to the world: 40
Electricity—exports: 0 kWh (2010 est.)
country comparison to the world: 121
Electricity—imports: 0 kWh (2010 est.)
country comparison to the world: 124
Electricity—installed generating capacity:
16.36 million kW (2010 est.)
country comparison to the world: 43
Electricity—from fossil ‘fuels: 66.1% of total
installed capacity (2009 est.)
country comparison to the world: 120
Electricity—from nuclear fuels: 0% of total
installed capacity (2009 est.)
country comparison to the world: 167
Electricity—from hydroelectric plants: 21.1%
of total installed capacity (2009 est.) :
country comparison to the world: 88
Electricity—from other renewable sources:
12.8% of total installed capacity (2009 est.)
country comparison to the world: 18
Crude oll—production: 26,640 bbl/day (2011 est.)
country comparison to the world: 69
Crude oil—exports: 28,090 bbl/day (2010 est.)
country comparison to the world: 52
Crude oil—imports: 176,000 bbl/day (2009 est.)
country comparison to the world: 37
Crude oill—proved reserves: 138.5 million bbl
(1 January 2013 est.) n
country comparison to the world: 70
Refined petroleum products—production:
181,300 bbl/day (2010 est.)
country comparison to the world: 58
Refined petroleum products—consumption:
315,600 bbl/day (2011 est.)
country comparison to the world: 43
Refined petroleum products—exports: 17,810
bbl/day (2010 est.)
country comparison to the world: 75
Refined petroleum products—imports: 147,900
bbl/day (2010 est.)
country comparison to the world: 39
Natural gas—production: 3.91 billion cu m
(2012 est.)
country comparison to the world: 53
Natural gas—consumption: 2.86 billion cu m
(2010)
country comparison to the world: 74
Natural gas—exports: 0 cu m(2010)
country comparison to the world: 168
Natural gas—imports: 0 cu m(2010)
country comparison to.the world: 121
Natural gas—proved reserves: 98.54 billion
cum (1 January 2012 est.)
country comparison to the world: 54
Carbon dioxide emissions from consumption
of energy: 85.63 million Mt (2010 est.)
country comparison to the world: 42','5a589ebf46765c5ec223df69e1d555ee3a9d5b8ea13817877cf0c495ff92dcda','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('df7128241deb7af3f479de4435f8b4d10e81d77fdf1aa9da3bf3ea68cff6855a',2025,'PL','Poland','energy',1333,'Electricity—production: 156.4 billion kWh
(2010 est)
country comparison to the world: 26
Electricity—consumption: 155 billion kWh
(2010 est.)
country comparison to the world: 26
Electricity—exports: 6.61 billion kWh (2010)
country comparison to the world: 25
Electricity—imports: 5.52 billion kWh (2010 est.)
country comparison to the world: 36
Electricity—installed— generating capacity:
35.76 million kW (2010 est.)
country comparison to the world: 24
Electricity—from fossil fuels: 91.2% of total
installed capacity (2010 est.)
country comparison to the world: 74
Electricity—trom nuclear fuels: 0% of total
installed capacity (2010 est.)
country comparison to the world: 160
Electricity—from hydroelectric plants: 6.1% of
total installed capacity (2010 est.)
country comparison to the world: 124
Electricity—from other renewable sources:
2.7% of total installed capacity (2010 est.)
country comparison to the world: 50
Crude oil—production: 12,90 bbl/day (2011 est.)
country comparison to the world: 80
Crude oil—exports: 3,615 bbl/day (2011 est.)
country comparison to the world: 63
Crude oil—imports: 547,900 bbl/day (2011 est.)
country comparison to the world: 18
Crude oli—proved reserves: 155 million bbl
(1 January 2010 est.) .
country comparison to the world: 67
Refined petroleum products—production:
636,000 bbl/day (2012 est.)
country comparison to the world: 29
Refined petroleum products—consumption:
576,600 bbl/day (2011 est.)
country comparison to the world: 31
Refined petroleum products—exports: 45,860
bbl/day (2009 est.)
country comparison to the world: 62
Refined petroleum products—imports: 129,800
bbl/day (2009 est.)
country comparison to the world: 43
Natural gos—production: 6.247 billion cu m
(2011 est.)
country comparison to the world: 50
Natural gas—consumption: 14.38 billion cu m
(2011 est.)
country comparison to the world: 40
Natural gas—exports: 29 million cu m (2011 est.)
country comparison to the world: 48
Natural gas—imports: 10.91 billion cu m (2011
est.)
country comparison to the world: 25
Natural gas—proved reserves: 95 billion cu m
(1 January 2012 est.)
country comparison to the world: 56
Carbon dioxide emissions from consumption
of energy: 309.9 million Mt (2010 est.)
country comparison to the world: 21','003037e2b4036de2f435f4430edd99d490124d0f81792025ba2b3ce20dba5354','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('964a5e416ebee080ae19879376036c7a22a92693b9ebbe33a4c617a7acb1121e',2025,'PT','Portugal','energy',1339,'Electricity—production: 50.3 billion kWh (2010
est
a comparison to the world: 52
Electricity—consumption: 47.81 billion kWh
(2009 est.)
country comparison to the world: 47
Electricity—exports: 3.191 billion kWh (2010
est.)
country comparison to the world: 36
Electricity—imports: 5.814 billion kWh (2010
est. E
A comparison to the world: 35
Electricity—installed generating capacity:
17.39 million kW (2009 est.)
country comparison to the world: 42
Electricity—from fossil fuels: 48.3% of total
installed capacity (2009 est.)
country comparison to the world: 160
Electricity—from nuclear fuels: 0% of total
installed capacity (2009 est.)
country comparison to the world: 162
Electricity—from hydroelectric plants: 23.3%
of total installed capacity (2009 est.)
country comparison to the world: 84
Electricity—trom other renewable sources:
22.5% of total installed capacity (2009 est.)
country comparison to the world: 5
Crude oll—production: 1,926 bbi/day (2011 est.)
country comparison to the world: 94
Crude oll—exports: 0 bbi/day (2009 est.)
country comparison to the world; 169
Crude oll—imports: 205,400 bbl/day (2009
est.)
country comparison to the world: 33
Crude oll—proved reserves: NA bbl (1 January
2012 est.)
Refined petroleum preducts—production:
237,000 bbl/day (2009 est.)
country comparison to the world: 52
Refined petroleum products—consumption:
259,700 bbl/day (2011 est.)
country comparison to the world: 49
Refined petroleum products—exports: 49,650
bbl/day (2009 est.)
country comparison to the world: 59
Refined petroleum products—imports: 83,520
bbl/day (2009 est.)
country comparison to the world: 53
Natural gas—production: 0 cu m (2010 est.)
country comparison to the world: 181
Natural gas—consumption: 5.212 billion cu m
(2011 est.)
country comparison to the world: 59
Natural gas—exports: 0 cu m (2011 est.)
country comparison to the world: 163
Natural gas—imports: 5.181 billion cu m (2011
est.)
country comparison to the world: 33
Natural gas—proved reservés: 0 cu m (1 Janu-
ary 2012 est.)
country comparison to the world: 184
Carbon dioxide emissions from consumption
of energy: 51.43 million Mt (2010 est.)
country comparison to the world: 60','07632a0b381b2c71886b07c4b91ee6597e87ac0bf8ba61c12bb0eeebbfd35ae4','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b4324878dda882bdd0140393474c428a58267b1cff8363eb8439e0e392b6a807',2025,'QA','Qatar','energy',1355,'Electricity—production: 28.14 billion kWh
(2010 est.)
country comparison to the world: 67
Electricity—consumption: 26.38 billion kWh
(2010 est.)
country comparison to the world: 66
Electricity—exports: 200,000 kWh (2010 est.)
country comparison to the world: 88
Electricity—imports: 0 kWh (2010 est.)
country comparison to the world: 123
Electricity—installed generating capacity:
3.893 million kW (2009 est.)
country comparison to the world: 80
Electricity—from fossil fuels: 100% of total
installed capacity (2009 est.)
country comparison to the world: 32
Electricity—from nuclear fuels: 0% of total
installed capacity (2009 est.)
country comparison to the world: 165
Eiectricity—from hydroelectric plants: 0% of
total installed capacity (2009 est.)
country comparison to the world: 192
Electricity—from other renewable sources: 0%
of total installed capacity (2009 est.)
country comparison to the world: 177
Crude oil—production: 1.631 million bbl/day
(2011 est.)
country comparison to the world: 19
Crude oli—exports: 704,300 bbl/day (2009 est.)
country comparison to the world: 19
Crude oil-—imports: 0 bbl/day (2009 est.)
country comparison to the world: 114
Crude oil—proved reserves: 25.57 billion bbl
(1 January 2012 est.)
country comparison to the world: 14
Refined petroleum products—production:
153,800 bbl/day (2008 est.)
country comparison to the world: 67
Refined petroleum products—consumption:
169,900 bbl/day (2011 est.)
country comparison to the world: 63
Refined petroleum products—exports: 53,230
bbl/day {2008 est.)
country comparison to the world: 56
Refined petroleum products—imports: 11,940
bbl/day (2008 est.)
country comparison to the world: 129
Natural gas—production: 116.7 billion cu m
(2010 est.)
country comparison to the world: 7
Natural gas—consumption: 21:8 billion cu m
(2010 est.) sem
country comparison to the world: 36
Natural gas—exports: 113.4 billion cu m (2011
est.) a
country comparison to the world: 3
Natural gas—imports: 0 cu m (2010 est.)
country comparison to the world: 120
Natural gas—proved reserves: 25.2 trillion
cu m (1 January 2012 est.)
country comparison to the world: 4
Carbon dioxide emissions from consumption
of energy: 64.68 million Mr (2010 est.)
country comparison to the world: 51','f37bf766f64c8eaccd1016f7ea054e1926a7a8d4c6fe59537c4b956544781c37','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9b9fb0d89ccdb9317c75a33539d3dd84a594279f2ae9e652d32f0cea788b1620',2025,'RO','Romania','energy',1362,'Electricity—production: 60.39 billion kWh
(2011 est.)
country comparison to the world: 44
Electricity—consumption: 53.74 billion kWh
(2011 est.)
country comparison to the world: 45
Electricity—exports: 2.94 billion kWh (2011
est.)
country comparison to the world: 38
Electricity—imports: billion kWh (2011 est.)
country comparison to the world: 64
Electricity—installed generating capacity:
24.98 million kW (2011 est.)
country comparison to the world: 33
Electricity—from fossil fuels: 61.7% of total
installed capacity (2011 est.)
country comparison to the world: 135
Electricity—from nuclear fuels: 9.4% of total
installed capacity (2011 est.)
country comparison to the world: 22
Electricity—from hydroelectric plants: 27% of
total installed capacity (2011 est.)
country comparison to the world: 82
Electricity—from other renewable sources:
1.9% of total installed capacity (2011 est.)
country comparison to the world: 60
Crude oll—production: 92,140 bbl/day (2011
est.)
country comparison to the world: 51
Crude oil—exports: 0 bbl/day (2009 est.)
country comparison to the world: 173
Crude oil—imports: 169,000 bbl/day (2009 est.)
country comparison to the world: 38
Crude oil—proved reserves: 600 million bbl
(1 January 2013 est.)
country comparison to the world: 47
Refined petroleum products—production:
298,200 bbl/day (2008 est.)
country comparison to the world: 47
Refined petroleum products—consumption:
218,200 bbi/day (2011 est.)
country comparison to the world: 55
Refined petroleum products—exports: 107,300
bbl/day (2008 est.)
country comparison to the world: 41
Refined petroleum products—imports: 34,250
bbli/day (2008 est.)
country comparison to the world: 83
Natural gas—production: 11.08 billion cum
+ (2011 est.)
country comparison to the world: 44
Natural gas—consumption: 14.2 billion cum
(2011 est.)
country comparison to the world: 41
Natural gas—exports: 0 cu m (2011 est.)
country comparison to the world: 167
Notural gas—imports: 3.12 billion cum (2011
est.)
casuatry comparison to the world: 41
Natural gas—proved reserves: 63 billion cum
(1 January 2012 est.)
country comparison to the world: 64
Carbon dioxide emissions from consumption
of energy: 78.43 million Mr (2010 est.)
country comparison to the world: 45
Electricity—production: 1.064 trillion kWh
(2012 est.)
country comparison to the world: 5
Electricity—consumption: trillion kWh (2012
est.)
country comparison to the world: 5
Electricity—exports: 19.14 billion kWh (2012
est.
“i comparison to the world: 9
Electricity—imports: 2.661 billion kWh (2012
est.)
country comparison to the world: 48
RUSSIA
Electricity—installed generating capacity: mil-
lion kW (2012 est.)
country comparison to the world: 5
Electricity—from fossil fuels: 67.7% of total
installed capacity (2012 est.)
country comparison to the world: 112
Electricity—trom nuclear fuels: 17.2% of total
installed capacity (2012 est.)
country comparison to the world: 13
Electricity—trom hydroelectric plants: 15.1%
of total installed capacity (2012 est.)
country comparison to the world: 104
Electricity—trom other renewable sources: 0%
of total installed capacity (2012 est.)
cauntry comparison to the world: 180
Crude oil—production: 10.37 million bbl/day
(2012 est.)
country comparison to the world: 2
Crude oil—exports: 4.69 million bbl/day (2012
est.) ; i
country comparison to the world: 3
Crude oil—imports: 16,380 bbl/day (2012 est.)
country comparison to the world: 72
Crude oil—proved reserves: 60 billion bbl
(1 January 2012 est.)
country comparison to the world: 9
Refined petroleum products—production:
4.802 million bbl/day (2008 est.)
country comparison to the world: 5
Refined petroleum products—consumption:
3.341 million bbl/day (2012 est.)
country comparison to the world: 6
Refined petroleum products—exports: 2.699
million bbi/day (2012 est.)
country comparison to the world: 2
Refined petroleum products—imports: 24,300
bbi/day (2012 est.)
country comparison to the world: 97
Natural gas—production: 653 billion cum
(2012 est.)
country comparison to the world: 2
Natural gas—consumption: 460 billion cum
(2012 est.)
country comparison to the world: 3
Natural gas—exports: 200.1 billion cu m (2012
est.)
country comparison to the world: 2
Natural gas—imports: 32.5 billion cum (2012
est.)
country comparison to the world: 14
Natural gas—proved reserves: 47.57 trillion
cu m (1 January 2012 est.)
country comparison to the world: 2
Carbon dioxide emissions from consumption
of energy: 1.634 billion Mr (2010 est.)
country comparison to the world: 5','34137263f78336ee67c1e3d72a125933fc186785aab2dc7c83ebf558e18d4b1d','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c4107a7a442053c388983305703f96741ef0a5316dc8542f66b18e974c3f94d1',2025,'RW','Rwanda','energy',1369,'Electricity—production: 240.2 million kWh
(2009 est.)
country comparison to the world: 177
Electricity—consumption: 301.4 million kWh
(2009 est.)
country comparison to the world: 174
Electricity—exports: 2 million kWh (2009 est.)
country comparison to the world: 85
Electricity—imports: 80 million kWh (2009 est.)
country comparison to the world: 96
Electricity—installed generating capacity:
56,250 kW (2009 est.)
country comparison to the world: 180
Electricity—from fossil fuels: 53.3% of total
installed capacity (2009 est.)
country comparison to the world: 150
Electricity—from nuclear fuels: 0% of total
installed capacity (2009 est.)
country comparison to the world: 169
Electricity—from hydroelectric plants: 46.2%
of total installed capacity (2009 est.)
country comparison to the world: 46
Electricity—from other renewable sources:
0.4% of total installed capacity (2009 est.)
country comparison to the world: 79
Crude oijl—production: 0 bbi/day (2011 est.)
country comparison to the world: 181
Crude oil—exports: 0 bbl/day (2009 est.)
country comparison to the world: 175
Crude oil—imports: 0 bbl/day (2009 est.)
country comparison to the world: 115
Crude oil—proved reserves: 0 bbl (1 January
2012 est.)
country comparison to the world: 180
Refined petroleum products—production: 0
bbl/day (2008 est.)
country comparison to the world: 190
Refined petroleum products—consumption:
5,245 bbl/day (2011 est.)
country comparison to the world: 167
Refined petroleum products—exports: 0 bbl/
day (2008 est.)
country comparison to the world: 127
Refined petroleum products—imports: 5,125
bbl/day (2008 est.)
country comparison to the world: 156
Natural gas—production: 0 cu m (2010 est.)
country comparison to the world: 184
Natural gas—consumption: 0 cu m (2010 est.)
country comparison to the world: 188
Natural gas—exports: 0 cu m (2010 est.)
country comparison to the world: 170
Natural gas—imports: 0 cu m (2010 est.)
country comparison to the world: 122
Natural gas—proved reserves: 56.63 billion
cum (1 January 2012 est.)
country comparison to the world: 65
607
Carbon dioxide emissions from consumption
of energy: 869,400 Mr (2010 est.)
country comparison to the world: 170','7429b18235370fec94ed0fe8c9e0387fb734c9866786d41bf54bcd3f2dac246c','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4ca1c7ff98cf21806df4ec4ff2edcbd9a261296ac4fd63b369a0ad9b6d23f128',2025,'FR','France','energy',1373,'Electricity—production: 8 million kWh (2009
est.)
country comparison to the world: 215
Electricity—consumption: 7.44 million kWh
(2009 est.)
country comparison to the world: 215
Electricity—exports: 0 kWh (2010 est.)
country comparison to the world: 128
Electricity—imports: 0 kWh (2010 est.)
country comparison to the world: 131
Electricity—installed generating capacity:
4,000 kW (2009 est.)
country comparison to the world: 208
Electricity—from fossil fuels: 100% of total
installed capacity (2009 est.)
country comparison to the world: 37
Electricity—from nuclear fuels: 0% of total
installed capacity (2009 est.)
country comparison to the world: 175
Electricity—from hydroelectric plants: 0% of
total installed capacity (2009 est.)
country comparison to the world: 198
Electricity—from other renewable sources: 0%
of total installed capacity (2009 est.)
country comparison to the world: 185
O bbl/day (2011 est.)
country comparison to the world: 186
Crude oil—exports: 0 bbl/day (2009 est.)
country comparison to the world: 181
Crude oil—imports: 0 bbl/day (2009 est.)
country comparison to the world: 120
beverages,
THE CIA WORLD FACTBOOK
Crude oll—proved reserves: 0 bbl (1 January
2012 est.)
country comparison to the world: 185
Refined petroleum products—production: 0
bbl/day (2008 est.)
country comparison to the world: 194
Refined petroleum products—consumption:
100 bbl/day (2011 est.)
country comparison to the world: 211
Refined petroleum products—exports: 0 bbl/
day (2008 est.)
country comparison to the world: 131
Refined petroleum products—imports: 66.05
bbl/day (2008 est.)
country comparison to the world: 207
Natural gas—production: 0 cu m (2010 est.)
country comparison tò the world: 188
Natural gas—consumption: 0 cu m (2010 est.)
country comparison to the world: 192
Natural gas—exports: 0 cu m (2010 est.)
country comparison to the world: 177
Natural gas—imports: 0 cu m (2010 est.)
country comparison to the world: 128
Natural gas—proved reserves: 0 cu m (1 Janu-
ary 2012 est.)
country comparison to the world: 190
Carbon dioxide emissions from consumption
of energy: 15,060 Mt (2010 est.)
country comparison to the world: 209','18e4f37275452f60d11c2a6a7b044e62c98e384d814b771f27c85275f83e5fa2','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('33e7cb5623c7494d34d47409ed71b175c5c6e8d4e34fd8f8102054ec7ba436a4',2025,'KN','Saint Kitts and Nevis','energy',1379,'Electricity—production: 135 million kWh (2009
est.)
country comparison to the world: 187
Electricity—consumption: 125.6 million kWh
(2009 est.)
country comparison to the world: 192
Electricity—exports: 0 kWh (2010 est.)
country comparison to the world: 125
Electricity—imports: 0 kWh (2010 est.)
country comparison to the world: 128
Electricity—installed generating capacity:
22,000 kW (2009 est.)
country comparison to the world: 195
Electricity—from fossil fuels: 100% of total
installed capacity (2009 est.)
country comparison to the world: 35
Electricity—from nuclear fuels: 0% of total
installed capacity (2009 est.)
country comparison to the world: 172
Electricity—from hydroelectric plants: 0% of
total installed capacity (2009 est.)
country comparison to the world: 195
Electricity—from other renewable sources: 0%
of total installed capacity (2009 est.)
country comparison to the world: 183
Crude oll—production: 0 bbl/day (2011 est.)
country comparison to the world: 183
Crude oli—exports: 0 bbi/day (2009 est.)
country comparison to the world: 177
Crude oil—imports: 0 bbl/day (2009 est.)
country comparison to the world: 118
Crude oil—proved reserves: 0 bbl (1 January
2012 est.)
country comparison to the world: 182
Refined petroleum products—production: 0
bbl/day- (2008 est.)
country comparison to the world: 192
Refined petroleum products—consumption:
1,496 bbi/day (2011 est.)
country comparison to the world: 196
Refined petroleum products—exports: 0 bbl/
day (2008 est.)
country comparison to the world: 129
Refined petroleum products—imports: 1,699
bbl/day (2008 est.)
country comparison to the world: 184
Natural gas—production: 0 cu m (2010 est.)
country comparison to the world: 186
Natural gas—consumption: 0 cu m (2010
est.)
country comparison to the world: 190
Natural gas—exports: 0 cu m (2010 est.)
country comparison to the world: 173
Natural gas—imports: 0 cu m (2010 est.)
country comparison to the world: 125
Natural gas—proved reserves: 0 cu m (1 Janu-
ary 2012 est.)
country comparison to the world: 188
Carbon dioxide emissions trom consumption
of energy: 303,500 Mt (2010 est.)
country comparison to the world: 187','0e90f7f30dde9c07a5461d3bd9bbe829aa85bf3d0626954b2b90b21bf399319a','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f3e1b59245f25f1abe0ce9f2df4d0b8d42f3d07879cefbfeb5481dc793222902',2025,'PM','Saint Pierre and Miquelon','energy',1401,'Electricity—production: 53 million kWh (2009
est.)
country comparison to the world: 204
Electricity—consumption: 49.29 million kWh
(2009 est.)
country comparison to the world: 205
Electricity—exports: 0 kWh (2010 est.)
country comparison to the world: 124
Electricity—imports: 0 kWh (2010 est.)
country comparison to the world: 127
Electricity—installed generating capacity:
27,000 kW (2009 est.)
country comparison to the world: 193
Electricity—from fossil fuels; 100% of. total
installed capacity (2009 est.)
country comparison to the world: 34
Electricity—from nuclear fuels: 0% of total
installed capacity (2009 est.)
country comparison to the world: 171
Electricity—from hydroelectric plants: 0% of
total installed capacity (2009 est.)
country comparison to the world: 194
Electricity—from other renewable sources: 0% of
total installed capacity (2009 est.)
country comparison to the world: 182
Crude oil—production: 0 bbl/day (2011 est.)
country comparison to the world: 182
Crude oil—exports: 0 bbl/day (2009 est.)
country comparison to the world: 176
Crude oill—imports: 0 bbl/day (2009 est.)
country comparison to the world: 117
Crude oil—proved reserves: 0 bbl (1 January
2012 est.)
country comparison to the world: 181
Refined petroleum products—production: 0
bbi/day (2008 est.)
country comparison to the world: 191
Refined petroleum products—consumption:
974.1 bbl/day (2011 est.)
country comparison to the world: 205
Refined petroleum products—exports: 0 bbl/
day (2008 est.)
country comparison to the world: 128
Refined petroleum products—imports: 584 bbl/
day (2008 est.)
country comparison to the world: 200
Natural gas—production: 0 cu m (2010 est.)
country comparison. to the world: 185
Natural gas—consumption: 0 cu m (2010 est.)
country comparison to the world: 189
Natural gas—exports: 0 cu m (2010 est.)
country comparison to the world: 172
Natural gas—imports: 0 cu m (2010 est.)
country comparison to the world: 124
Natural gas—proved reserves: 0 cu m (1 Janu-
ary 2012 est.)
country comparison to the world; 187
Carbon dioxide emissions from consumption of
energy: 152,600 Mr (2010 est.)
country comparison to the world: 198','af6eb0f2d29e0ad47334ce0495c2f31eb6b54f077989627e0e5079852121db0c','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('36e9a279a17877e0ed3df39ab70d531b81c373cf3c475011d5f2083fc1ab75c9',2025,'VC','Saint Vincent and the Grenadines','energy',1409,'Electricity—production: 132 million kWh (2009
est.)
country comparison to the world: 188
Electricity—consumption: 122.8 million kWh
(2009 est.)
country comparison to the world: 193
Electricity—exports: 0 kWh (2010 est.)
country comparison to the world: 144
Electricity—imports: 0 kWh (2010 est.)
country comparison to the world: 146
Electricity—instalied generating capacity:
49,000 kW (2009 est.)
country comparison to the world: 185
Electricity—from fossil fuels: 81.6% of total
installed capacity (2009 est.)
country comparison to the world: 92
Electricity—from nuclear fuels: 0% of total
installed capacity (2009 est.)
country comparison to the world: 197
624
THE CIA WORLD FACTBOOK
Electricity—from hydroelectric plants: 18.4%
of total installed capacity (2009 est.)
country comparison to the world: 96
Electricity—trom other renewable sources: 0%
of total installed capacity (2009 est.)
country comparison to the world: 199
Crude oil—production: 0 bbl/day (2011 est.)
country comparison to the world: 201
Crude oil—exports: 0 bbl/day (2009 est.)
country comparison to the world: 201
Crude oil—imports: 0 bbl/day (2009 est.)
country comparison to the world: 136
Crude oil—proved reserves: 0 bb! (1 January
2012 est.)
country comparison to the world: 200
Refined petroleum products—production: 0
bbl/day (2008 est.)
country comparison to the world: 205
Refined petroleum products—consumption:
1,948 bbl/day (2011 est.)
country comparison to the world: 190
Refined petroleum products—exports: 0 bbl/
day (2008 est.)
country comparison to the world: 141
Refined petroleum products—imports: 1,474
bbl/day (2008 est.)
country comparison to the world: 186
Natural gas—production: 0 cu m (2010 est.)
country comparison to the world: 204
Natural gas—consumption: 0 cu m (2010 est.)
country comparison to the world: 204
Natural gas~~exports: 0 cu m (2010 est.)
country comparison to the world: 200
Natural gas—imports: 0 cu m (2010 est.)
country comparison to the world: 144
Natural gas—proved reserves: 0 cu m (1 Janu-
ary 2012 est.)
country comparison to the world: 202
Carbon dioxide emissions from consumption
of energy: 332,600 Mt (2010 est.)
country comparison to the world: 185','339047bc38831d2de4a242b0c938676103a0ab321f08b5de872c41c3b963b227','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5636230e1c5d38a35799976a0febea46420ea29bed6db5da3f13c401c432f669',2025,'SA','Saudi Arabia','energy',1433,'Electricity—production: 212.3 billion kWh
(2010 est.)
country comparison to the world: 21
Electricity—consumption: 186.1 billion kWh
(2009 est.)
country comparison to the world: 20
Electricity—exports: 0 kWh (2010 est.)
country comparison to the world: 123
Electricity—imports: 0 kWh (2010 est.)
country comparison to the world: 126
Electricity—instalied generating capacity:
44.49 million kW (2009 est.)
country comparison to the world: 21
Electricity—from fossil fuels: 100% of total
installed capacity (2009 est.)
country comparison to the world; 33
Electricity—from nuclear fuels: 0% of total
installed capacity (2009 est.)
country comparison to the world: 170
Electricity—trom hydroelectric plants: 0% of
total installed capacity (2009 est.)
country comparison to the world: 193
Electricity—from other renewable sources: 0%
of total installed capacity (2009 est.)
country comparison to the world: 181
Crude oll—production: 10 million bbl/day (2012
est.)
country comparison to the world: 3
Crude oil—exports: 6.88 million bbl/day (2011
est.)
country comparison to the world: 2
Crude oil—imports: 0 bbi/day (2011 est.)
country comparison to the world: 116
Crude oll—proved reserves: 264.6 billion bbl
(1 January 2012 est.)
country comparison to the world: 2
Refined petroleum products—production:
1.914 million bbl/day (2010 est.)
636
THE CIA WORLD FACTBOOK
country comparison to the world: 12
Refined petroleum products—consumption:
2.817 million bbl/day (2011 est.)
country comparison to the world: 8
Refined petroleum products—exports: 951,000
bbl/day (2008 est.)
country comparison to the world: 7
Refined petroleum products—imports: 160,100
bbl/day (2010 est.)
country comparison to the world: 36
Natural gas—production: 99.23 billion cu m
(2011 est.)
country comparison to the world: 10
Natural gas—consumption: 99.23 billion cu m
(2011 est.)
country comparison to the world: 9
Natural gas—exports: 0 cu m (2011 est.)
country comparison to the world: 171
Natural gas—imporis: 0 cu m (2011 est.)
country comparison to the world: 123
Natural gas—proved reserves: 8.028 trillion
cum (1 January 2012 est.)
country comparison to the world: 6
Carbon dioxide emissions from consumption
of energy: 478.4 million Mt (2010 est.)
country comparison to the world: 12','92dc6f80bb41cc0840200ded439877e4ebb8665c70e4e38a44f3a2519c44ee74','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('865fd9b35875bd5e64baa1d2f79f2beabdd464a4879e04be127175ea93545f6e',2025,'SC','Seychelles','energy',1442,'Electricity—production: 245 million kWh (2009
est.)
country comparison to the world: 176
Electricity—consumption: 227.9 million kWh
(2009 est.)
country comparison to the world: 182
Electricity—exports: 0 kWh (2010 est.)
country comparison to the world: 126
Electricity—imports: 0 kWh (2010 est.)
country comparison to the world: 129
Electricity—installed generating capacity:
95,000 kW (2009 est.)
country comparison to the world: 170
Electricity—from fossil fuels: 100% of total
installed capacity (2009 est.)
country comparison to the world: 36
Electricity—from nuclear fuels: 0% of total
installed capacity (2009 est.)
country comparison to the world: 173
Electricity—from hydroelectric plants: 0% of
total installed capacity (2009 est.)
country comparison to the world: 196
Electricity—from other renewable sources: 0%
of total installed capacity (2009 est.)
country comparison to the world: 184
Crude oll—production; 0 bbl/day (2011 est.)
country comparison to the world: 184
Crude oll—exports: 0 bbl/day (2009 est.)
country comparison to the world: 178
Crude oil—imports: 0 bbl/day (2009 est.)
country comparison to the world: 119
Crude oll—proved reserves: © bbl (1 January
2010 est.) 1
country comparison to the world: 183
Refined petroleum products—production: ©
bbl/day (2008 est.)
country comparison to the world; 193
Refined petroleum products—consumption:
7,793 bbl/day (2011 est.)
country comparison to the world: 160
Refined petroleum products—exports: 0 bbl/
day (2008 est.)
country comparison to the world: 130
Refined petroleum products—imports: 6,923
bbl/day (2008 est.)
country comparison to the world: 142
Natural gas—production: 0 cu m (2010 est.)
country comparison to the world: 187
Natural gas—consumption: 0 cu m (2010 est.)
country comparison to the world: 191
Naturai gas—exports: 0 cu m (2010 est.)
country comparison to the world: 174
Natural gas—imports: 0 cu m (2010 est.)
country comparison to the world: 126
Natural gas—proved reserves: 0 cu m (1 Janu-
ary 2012 est.)
country comparison to the world: 189
Carbon dioxide emissions from consumption
of energy: 1.245 million Mr (2010 est.)
country comparison to the world: 161','26a918dc0f10ac373b88420abf1f6dc584c0b45199a44b3155614b6cd605ec13','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ef32b08cd822dbd14652c39929f36deb13eb3aac62ecd05091a31f373712e7c9',2025,'SL','Sierra Leone','energy',1449,'Electricity—production: 120 million kWh (2009
est.)
country comparison to the world: 192
Electricity—consumption: 111.6 million kWh
(2009 est.)
country comparison to the world: 194
Electricity—exports: 0 kWh (2010 est.)
country comparison to the world: 129
Electricity—imports: 0 kWh (2010 est.)
country comparison to the world: 132
Electricity—installed generating capacity:
52,000 kW (2009 est.)
country comparison to the world: 183
Electricity—from fossil fuels: 92.3% of total
installed capacity (2009 est.)
country comparison to the world: 72
Electricity—from nuciear fuels: 0% of total
installed capacity (2009 est.)
country comparison to the world: 176
. Electricity—from hydroelectric plants: 7.7% of
total installed capacity (2009 est.)
country comparison to the world: 119
Electricity—from other renewable sources: 0%
of total installed capacity (2009 est.)
country comparison to the world: 186
Crude oll—production: 0 bbl/day (2011 est.)
country comparison to the world: 187
Crude oil—exports: 0 bbl/day (2009 est.)
country comparison to the world: 183
Crude ofl—imports: 0 bbi/day (2009 est.)
country comparison to the world: 122
Crude oil—proved reserves: 0 bbl (1 January
2012 est.)
country comparison to the world: 186
Refined petroleum products—production:
4,381 bbl/day (2008 est.)
country comparison to the world: 110
Refined petroleum products—consumption:
8,768 bbl/day (2011 est.)
country comparison to the world: 156
Refined petroleum products—exports: 522.9
bbl/day (2008 est.)
_ country comparison to the world: 117
Refined petroleum products—imports: 6,117
bbl/day (2008 est.)
country comparison to the world: 146
Natural gas—production: 0 cu m (2010 est.)
country comparison to the world: 189
Notural gas—consumption: 0 cu m (2010 est.)
country comparison to the world: 193
Natural gas—exports: 0 cu m (2010 est.)
country comparison to the world: 179
Natural gas—imports: 0 cu m (2010 est.)
country comparison to the world; 129
Natural gas—proved reserves: 0 cu m (1 Janu-
ary 2012 est.)
country comparison to the world: 191
Carbon dioxide emissions from consumption
of energy: 1.335 million Mt (2010 est.)
country comparison to the world: 160','674ea4c76336e16e5e23b3dd8faffb759efbafd4ea6a19c74752f1d5a49da406','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6d824eac7acc2ad4f78f56277578eef458ee3634cb9a93d29c8cad5fb52e3a44',2025,'SG','Singapore','energy',1454,'Electricity—production: 45.37 billion kWh
(2010 est.)
country comparison to the world: 54
Electricity—consumption: 41.2 billion kWh
(2010 est.)
country comparison to the world: 53
Electricity—exports: 0 kWh (2010 est.)
country comparison to the world: 130
Electricity—imports: 0 kWh (2010 est.)
country comparison to the world: 133
Electricity—installed generating capacity:
10.47 million kW (2009 est.)
country comparison to the world: 54
Electricity—from fossil fuels: 99.8% of total
installed capacity (2009 est.)
country comparison to the world: 48
Electricity—from nuciear fuels: 0% of total
installed capacity (2009 est.)
country comparison to the world: 177
Electricity—from hydroelectric plants: 0% of
total installed capacity (2009 est.)
country comparison to the world: 199
Electricity—from other renewable sources:
0.2% of total installed capacity (2009 est.)
country comparison to the world: 90
Crude olli—production: 0 bbl/day (2011 est.)
country comparison to the world: 188
Crude oll—exports: 0 bbl/day (2011 est.)
country comparison to the world: 184
653
Crude oil—imports: 883,500 bbl/day (2009 est.)
country comparison to the world: 13
Crude oil—proved reserves: 0 bbl (i January
2012 est.)
country comparison to the world: 187
Refined petroleum products—production:
1.357 million bbl/day (2011 est.)
country comparison to the world: 18
Refined petroleum products—consumption:
1.25 million bbl/day (2011 est.)
country comparison to the world: 20
Refined petroleum products—exports: 1.14
million bbl/day (2010 est.)
country comparison to the world: 6
Refined petroleum products—Iimports: 1.348
million bbl/day (2010 est.)
country comparison to the world: 5
Natural gas—production: 0 cu m (2011 est.)
country comparison to the world: 190
Natural gas—consumption: 8.778 billion cu m
(2011 est.)
country comparison to the world: 53
Natural gas—exports: 0 cu m (2011 est.)
country comparison to the world: 180
Natural gas—imports: 8.778 billion cu m (2011
est.)
country comparison to the world: 28
Natural gas—proved reserves: 0 cu m (1 Janu-
ary 2012 est.)
country comparison to the world: 192
Carbon dioxide emissions from consumption
of energy: 172.2 million Mt (2010 est.)
country comparison to the world: 31','65201ccba8ca5b8d850358f6936d98c13954ea0f5a2e1fcf56f6919468b11918','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('689672187ec8285b0adda46f6baccdb32d8d11711c66006c8c17c75af3b0cdc8',2025,'SI','Slovenia','energy',1467,'Electricity—production: 15.61 billion kWh
(2010 est.)
country comparison to the world: 80
Electricity—consumption: 11.6 billion kWh
(2009 est.) :
country comparison to the world: 85
Electricity—exports: 10.14 billion kWh (2010
est.) f .
country comparison to the world: 21
Electricity—imports: 8.014 billion kWh (2010
est.)
country comparison to the world: 30
Electricity—installed generating capacity: 3.4
million kW (2040 est.)
country comparison to the world: 84
Electricity—from fossil fuels: 42.2% of total
installed capacity (2009 est.)
country comparison to the world: 168
Electricity—trom nuclear fuels: 21.5% of total
installed capacity (2009 est.)
country comparison to the world: 9
Electricity—trom hydroelectric plants: 34.5%
of total installed capacity (2009 est.)
country comparison to the world: 62
Electricity—trom other renewable sources:
1.8% of total installed capacity (2009 est.)
country comparison to the world: 62
Crude oil—production: 5 bbi/day (2011 est.)
country comparison to the world: 103
Crude oll—exports: 0 bbl/day (2009 est.)
country comparison to the world: 182
Crude oli—imports: 0 bbl/day (2009 est.)
country comparison to the world: 121
Crude oll—proved reserves: NA bbl (1 January
2012 es)
Refined petroleum products—production: O
bbl/day (2008 est.)
country comparison to the world: 195
Refined petroleum products—consumption:
52,930 bbi/day (2011 est.)
country comparison to the world: 97
Refined petroleum products—exports: 11,500
bbl/day (2009 est.)
country comparison to the world: 84
Refined petroleum products—imports: 60,270
bbł/day (2008 est.)
country comparison to the world: 64
Natural gas—production: 7. million ca m (2010
est.)
country comparison to the world: 92
Natura! gas—consumption: 1.06 billion cu m
(2010 est.)
country comparison to the world: 89
Natural gas—exports: 0 cu m (2010 est.)
country comparison to the world: 178
Natural gas—imports: 1.053 billion cu m (2010
est.) s
country comparison to the world: 59
Natural gas—proved reserves: NA cu m (1 Jan-
uary 2012 es)
Carbon dioxide emissions from consumption
of energy: 17.42 million Mt (2010 est.)
country comparison to the world: 87','f2da0a94d3716b46922b341d27095bcd3a88a5f21da8bb03d6e49de1feb3cd63','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a74f213df2e86877844e62563ffe970d66927884e1cbc4970da0b6d54825ffbc',2025,'SB','Solomon Islands','energy',1475,'Electricity—production: 82 million kWh (2009
est.)
country comparison to the world: 201
Electricity—consumption: 76.26 million kWh
(2009 est.)
country comparison to the world: 201
Electricity—exports: 0 kWh (2010 est.)
country comparison to the world: 169
Electricity—imports: 0 kWh (2010 est.)
country comparison to the world: 165
Electricity—installed generating capacity:
14,000 kW (2009 est.)
country comparison to the world: 197
Electricity—from fossil fuels: 100% of total
installed capacity (2009 est.)
country comparison to the world: 8
Electricity—from nuclear fuels: 0% of total
installed capacity (2009 est.)
country comparison to the world: 56
Electricity—from hydroelectric plants: 0% of
total installed capacity (2009 est.)
country comparison to the world: 161
Electricity—from other renewable sources: 0%
of total installed capacity (2009 est.)
country comparison to the world: 114
Crude oil—production: 0 bbl/day (2011 est.)
country comparison to the world: 114
Crude oll—exports: 0 bbi/day (2009 est.)
country comparison to the world: 88
Crude oil—imports: 0 bbi/day (2009 esr.)
country comparison to the world: 163
Crude oll—proved reserves: 0 bb! (1 January
2012 est.) i
country comparison to the world: 111
Refined petroleum products—production: 0
bbl/day (2008 est.)
country comparison to the world: 128
Refined petroleum products—consumption:
1,728 bbl/day (2011 est.)
country comparison to the world: 193
Refined petroleum products—exports: 0 bbl/
day (2008 est.)
country comparison to the world: 157
Refined petroleum products—imports: 1,433
bbl/day (2008 est.)
country comparison to the world: 187
Natural gas—production: 0 cu m (2010 est.)
country comparison to the world: 106
Natural gas—consumption: 0 cu m (2010 est.)
country comparison to the world: 122
Natura! gas—exports: 0 cu m (2010 est.)
country comparison to the world: 68
Notural gas—imports: 0 cu m (2010 est.)
country comparison to the world: 166
Natural gas—proved reserves: 0 cu m (1 Janu-
ary 2012 est.)
country comparison to the world: 115
Carbon dioxide emissions from consumption
of energy: 359,000 Mt (2010 est.)
country comparison to the world: 184','384ef85d7bf1ce7d1e4e2cd6a8acdd1ec20b8df0165d16a3a414b5ece108e654','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('97cf3f24cbba68ea68f3dfb7f72b678e5577cb246e5ea50438e9b984d43346f6',2025,'SO','Somalia','energy',1480,'Electricity—production: 315 million kWh (2009
est.)
country comparison to the world: 169
Electricity—consumption: 293 million kWh
(2009 est.)
country comparison to the world: 175
Electricity—exports: 0 kWh (2010 est.)
country comparison to the world: 131
Electricity—imports: 0 kWh (2010 est.)
O kWh (20 IU COL)
country comparison to the world: 134
Electricity—installed generating capacity:
80,000 kW (2009 est.)
country comparison to the world: 173
Electricity—from fossil fuels: 93.8% of total
installed capacity (2009 est.)
country comparison to the world: 70
Electricity—from nuclear fuels: 0% of total
installed capacity (2009 est.)
country comparison to the world: 178
Electricity—from hydroelectric plants: 6.3% of
total installed capacity (2009 est.)
country comparison to the world: 123
Electricity—from other renewable sources: 0%
of total installed capacity (2009 est.)
country comparison to the world: 187
Crude oil—production: 0 bbl/day (2011 est.)
country comparison to the world: 189
Crude oil—exports: 0 bbl/day (2009 est.)
country comparison to the world: 185
Crude oil—imports: 1.0 bbl/day (2009 est.)
country comparison to the world: 84
Crude oil—proved reserves: 0 bbl (1 January
2012 est.)
country comparison to the world; 188
Refined petroleum products—production:
3,666 bbl/day (2008 est.)
country comparison to the world: 111
Refined petroleum products—consumption:
5,659 bbl/day (2011 est.)
country comparison to the world: 165
Refined petroleum products—exports: 1,109
bbl/day (2008 est.)
country comparison to the world: 107
Refined petroleum products—Iimports: 2,905
bbl/day (2008 est.)
country comparison to the world: 170
Natural gas—production: 0 cu m (2010 est.)
country comparison to the world: 191
Natural gas—consumption: 0 cu m (2010 est.)
country comparison to the world: 194
Natura! gas—exports: 0 cu m (2010 est.)
country comparison to the world: 181
Natural gas—imports: 0 cu m (2010 est.)
country comparison to the world: 130
Natural gas—proved reserves: 5.663 billion
cu m (1 January 2012 est.)
667
country comparison to the world: 89
Carbon dioxide emissions from consumption
of energy: 897,500 Mt (2010 est.)
country comparison to the world: 168','0c423f30c0822e741ae20ccd40899a1d8155523d16cb9bdfc9e91189e71e538a','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2a95b18d01a05bc51941b9c690eb1d92208ee1040e96996a0ebb6905b1a80809',2025,'LK','Sri Lanka','energy',1501,'Electricity—production: 11.52 billion kWh (2011
est.)
country comparison to the world: 92
Electricity—consumption: 10 billion kWh (2011 est.)
country comparison to the world: 90
Electricity—exports: 0 kWh (2012 est.)
country comparison to the world: 175
Electricity—imports: 0 kWh (2012 est.)
country comparison to the world: 169
Electricity—installed generating capacity:
3.139 million kW (2011 est.)
country comparison to the world: 88
Electricity—from fossil fuels: 53.8% of total
installed capacity (2011 est.)
country comparison to the world: 148
Electricity—from nuclear fuels: 0% of total
installed capacity (2011 est.)
country comparison to the world: 62
Electricity—from hydroelectric plants: 44.6%
of total installed capacity (2011 est.)
country comparison to the world: 49
Electricity—from other renewable sources:
1.6% of toral installed capacity (2011 est.)
country comparison to the world: 66
Crude oll—production: 0 bbl/day (2012 est.)
country comparison to the world: 118
Crude olt—exports: 0 bbi/day (2012 est.)
country comparison to the world: 93
Crude oil—imports: 41,000 bbl/day (2012 est.)
country comparison to the world: 60
Crude oll—proved reserves: 0 bbl (1 January
2012 est.)
country comparison to the world: 116
Refined petroleum products—production:
50,000 bbl/day (2012 est.) -
country comparison to the world: 85
Refined petroleum products—consumption:
89,620 bbl/day (2011 est.)
country comparison to the world: 82
Refined petroleum products—exports: 0 bbl/
day (2008 est.)
country comparison to the world: 163
Refined petroleum products—imports: 48,140
bbl /day (2012 est.). .
country comparison to the world: 69
Natural gas—production: 0 cu m (2012 est.)
country comparison to the world: 112
Natural gas—consumption: 0 cu m (2012 est.)
country comparison to the world: 128
Natural gas—exports: 0 cu m (2012 est.)
country comparison to the world: 76
Natural gas—imports: 0 cu m (2012 est.)
country comparison to the world: 173
Natural gas—proved reserves: 0 cu m (1 Janu-
ary 2012 est.)
country comparison to the world: 121
Carbon dioxide emissions from consumption
of energy: 14.09 million Mt (2010 est.)
country comparison to the world: 91','7e6281cfb82998b43c66aea76607e9026438c7d1ea753eb92fb96e7afa62a460','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('54efd5c17a1e46efe4ccb987e8f2efe448c8922f78153bf4f938acaeb5bc782a',2025,'SD','Sudan','energy',1510,'Electricity—production: 6.509 billion kWh
(2009 est.)
country comparison to the world: 108
armaments, automo-
686
THE CIA WORLD FACTBOOK
Electricity—consumption: 4.611 billion kWh
(2009 est.)
country comparison to the world; 118
Electricity—exports: 0 kWh (2010 est.)
country comparison to the world: 133
Electricity—imports: 0 kWh (2010 est.)
country comparison to the world: 136
Electricity—installed generating AE
2.338 million kW (2009 est.)
country comparison to the world: 97
Electricity—from fossil fuels: 30.7% of total
installed capacity (2009 est.)
. country comparison to the world: 179
Electricity—from nuclear fuels: 0% of total
installed capacity (2009 est.)
country comparison to the world: 180
Electricity—from hydroelectric plants: 66.3%
of total installed capacity (2009 est.)
country comparison to the world: 26
Electricity—from other renewable sources: 3%
of total installed capacity (2009 est.)
country comparison to the world: 48
Crude oil—production: 12,000 bbl/day (2012
est.)
country comparison to the world: 48
Crude oil—exports: 370,700 bbl/day (2009 est.)
country comparison to the world: 23
Crude oil—imports: 0 bbl/day (2009 est.)
country comparison to the world: 124
Crude oil—proved reserves: 5 billion bbl
(1 January 2012 est.)
country comparison to the world: 25
Refined petroleum products—production:
85,890 bbi/day (2008 est.)
country comparison to the world: 78
Refined petroleum products—consumption:
95,450 bbl/day (2011 est.)
country comparison to the world: 81
Refined petroleum products—exports: 14,950
bbl/day (2008 est.)
country comparison to the world: 82
Refined petroleum products—imports: 24,820
bbl/day (2008 est.)
country comparison to the world: 94
Natural gas—production: 0 cu m (2010 est.)
country comparison to the world: 193
Natural gas—consumption: 0 cu m (2010 est.)
country comparison to the world: 196
Natural gas—exports: 0 cu m (2010 est.)
country comparison to the world: 183
Natural gas—imports: 0 cu m (2010 est.)
country comparison to the world: 132
Natural gas—proved reserves: 84.95 billion
cu m (1 January 2012 est.)
country comparison to the world: 60
Carbon dioxide emissions from consumption |
of energy: 13.79 million Mt (2010 est.)
country comparison to the world: 92
Telephones—main lines in use: 483,600 (2011)
country comparison to the world: 100
Telephones—mobile cellular: 25.056 million
(2011)
country comparison to the world; 42
Telephone system: general assessment: well-
equipped system by regional standards and being
upgraded; cellular communications started in 1996
and have expanded substantially with wide cover-
age of most major cities
domestic: consists of microwave radio relay, cable,
fiber optic, radiotelephone communications, trop-
ospheric scatter, and a domestic satellite system
with 14 earth stations
international: country code—249; linked to the
EASSy and FLAG fiber-optic submarine cable sys-
tems; satellite earth stations—I Intelsat (Atlantic
Ocean), 1 Arabsat (2010)
Broadcast media: the Sudanese Government
directly controls TV and radio requiring that both
media reflect government policies; TV has a per-
manent military censor; a private radio station is
in operation (2007)
Internet country code: .sd
Internet hosts: 99 (2012)
country comparison to the world: 211
Internet users: 4.2 million (2008)
country comparison to the world: 56','b068acf797a8970bb2ce75de22cba8414417b7ee5dbb46c3d0b421254b35f190','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c57d0cf93cd3ac0ce0dd97739d568caf521ba72d118ce1f809562ad75761710a',2025,'SR','Suriname','energy',1517,'Electricity—production: 1.603 billion kWh
(2009 est.)
country comparison to the world: 141
Electricity—consumption: 1.463 billion kWh
(2009 est.)
country comparison to the world: 146
Electricity—exports: 0 kWh (2010 est.)
country comparison to the world: 115
Electricity—imports: 0 kWh (2010 est.)
country comparison to the world: 117
Electricity—installed generating capacity:
389,000 kW (2009 est.) i
country comparison to the world: 146
Electricity—from fossil fuels: 51.4% of total
installed capacity (2009 est.)
country comparison to the world: 155
690
THE CIA WORLD FACTBOOK
Electricity—from nuclear fuels: 0% of total
installed capacity (2009 est.)
country comparison to the world: 155
Electricity—from hydroelectric plants: 48.6%
of total installed capacity (2009 est.)
country comparison to the world: 43
Electricity—from other renewable sources: 0%
of total installed capacity (2009 est.)
country comparison to the world: 171
Crude oil—production: 16,000 bbl/day (2011 est.)
country comparison to the world; 76
Crude oll—exports: 0 bbi/day (2009 est.)
country comparison to the world: 164
Crude oill—imports: 0 bbl/day (2009 est.)
country comparison to the world: 111
Crude olli—proved reserves: 72 million bbl
(1 January 2012 est.)
country comparison to the world: 79
Refined petroleum products—production:
7,407 bbl/day (2008 est.)
country comparison to the world: 108
Refined petroleum products—consumption:
14,100 bbl/day (2011 est.)
country comparison to the world: 147
Refined petroleum products—exports: 1,058
bbl/day (2008 est.)
country comparison to the world: 109
Refined petroleum products—imports: 6,430
bbl/day (2008 est.)
country comparison to the world: 145
Natural gas—production: 0 cu m (2010 est.)
country comparison to the world: 177
Natural gas—consumption: 0 cu m (2010 est.)
country comparison to the world: 183
Natural gas—exports: 0 cu m (2010 est.)
country comparison to the world: 157
Natural gas—imports: 0 cu m (2010 est.)
country comparison to the world: 111
Natural gas—proved reserves: 0 cu m (1 Janu-
ary 2011 est.)
country comparison to the world: 180
Carbon dioxide emissions from consumption
of energy: 2.343 million Mt (2010 est.)
country comparison to the world: 149','469b26dc8eb589056fc9df8bd53fc58e6702d052567ac803c545040ac1d484f6','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('96528d1c5dda315a4ea7b2bba2d07a8debda15845e99a4fa76be2fcec8ebffd4',2025,'SE','Sweden','energy',1526,'Electricity—production: 147.8 billion kWh
(2010 est.)
country comparison to the world: 27
Electricity—consumption: 127.1 billion kWh
(2009 est.)
country comparison to the world: 27
Electricity—exports: 12.85 billion kWh (2010 est.)
country comparison to the world: 14
Electricity—imports: 14.93 billion kWh (2010
est.)
country comparison to the world: 13
Electricity—instailed generating capacity:
35.29 million kW (2009 est.)
country comparison to the world: 25
697
Electricity—from fossil fuels: 12.5% of total
installed capacity (2009 est.)
country comparison to the world: 194
Electricity—from nuclear fuels: 25% of total
installed capacity (2009 est.)
country comparison to the-world: 6
Electricity—from hydroelectric plants: 46.9%
of total installed capacity (2009 est.)
country comparison to the world: 45
Electricity—from other renewable sources:
15.2% of total installed capacity (2009 est.)
country comparison to the world: 11
Crude oil—production: 0 bbl/day (2011 est.)
country comparison to the world: 191
Crude oil—exports: 0 bbi/day (2009 est.)
country comparison to the world: 188
Crude oil—imports: 380,100 bbl/day (2009 est.)
country comparison to the world: 24
Crude oil—proved reserves: O bbl (1 January
2012 est.)
country comparison to the world: 190
Refined petroleum products—production:
413,300 bbl/day (2009 est.)
country comparison to the world: 37
Refined petroleum products—consumption:
316,000 bbl/day (2011 est.)
country comparison to the world: 42
Refined petroleum products—exports: 243,200
bbl/day (2009 est.)
country comparison to the world: 27
Refined petroleum products—imports: 166,000
bbl/day (2009 est.)
country comparison, to the world: 33
Natural gas—production: 0 cu m (2010 est.)
country comparison to the world: 194
Natural gas—consumption: 1.296 billion cu m
(2011 est.)
country comparison to the world: 86
Natural gas—exports: 0 cu m (2011 est.)
country comparison to the world; 184
Natural gas—imports: 1.296 billion cu m (2011
est.)
country comparison to the world: 54
Natural gas—proved reserves: 0 cu m (1 Janu-
ary 2012 est.)
country comparison to the world: 194
Carbon dioxide emissions from consumption
of energy: 62.74 million Mt (2010 est.)
country comparison to the world: 54','faf1a211e694d50ce344429d8f1f20a1c59a38d28bbc5d1b1a47dc64ff197bac','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5e0028b9765ea055d5c9500a5e2ac3474a621efcd75f941423688397fec800bd',2025,'CH','Switzerland','energy',1532,'Eiectricity—production: 62.88 billion kWh
(2011 est.)
country comparison to the world: 43
Electricity—consumption: 60.42 billion kWh
(2011 est.)
country comparison to the world: 42
Electricity—exports: 80.71 billion kWh (2011
est.)
country comparison to the world: 2
Electricity—imports: 83.3 billion kWh (2011
est.)
country comparison to the world: 2
Electricity—installed generating capacity:
17.7 million kW (2010 est.)
country comparison to the world: 40
Electricity—from fossil fuels: 2.5% of total
installed capacity (2009 est.)
country comparison to the world: 202
701
Electricity—from nuclear fuels: 16.6% of total
installed capacity (2009 est.)
country comparison. to the world: 15
Electricity—from hydroelectric plants: 69.2%
of total installed capacity (2009 est.)
country comparison to the world: 23
Electricity—from other renewable sources:
2.5% of total installed capacity (2009 est.)
country comparison to the world: 52
Crude oil—production: 0 bbl/day (2011 est.)
country comparison to the world: 192
Crude ojl—exports: 0 bbl/day (2011 est.)
country comparison to the world: 189
Crude oil—imports: 258,200 bbl/day (2011 est.)
country comparison to the world: 28
Crude oill—proved reserves: 0 bbl (1 January
2012 est.)
country comparison to the world: 191
Refined petroleum products—production:
103,500 bbl/day (2009 est.)
country comparison to the world: 75
Refined petroleum products—consumption:
258,200 bbl/day (2011 est.)
country comparison to the world: 51
Refined petroleum products—exports: 9,851
bbl/day (2009 est.)
country comparison to the world: 86
Refined petroleum products—imports: 176,500
bbl/day (2009 est.) . s TE
country comparison to the world: 31
Natural gas—production: 0 cu m (2011 est.)
country comparison to the world: 195
Natural gas—consumption: 3.681 billion cu m
_ (2011 est.)
country comparison to the world: 68
Natural gas—exports: 0 cu m (2011 est.)
country comparison to the world: 186
Natural gas—imports: 3.681 billion cu m (2011
est.)
country comparison to the world: 38
Natural gas—proved reserves: 0 cu m (1 Janu-
ary 2011 est.)
country comparison to the world: 195
Carbon dioxide emissions from consumption
of energy: 45.55 million Mt (2010 est.)
country comparison to the world: 65
Electricity—production: 40.86 billion kWh
(2009 esr.)
country comparison to the world: 58
Electricity—consumption: 28.87 billion kWh
(2009 est.)
country comparison to the world: 63
Electricity—exports: 0 kWh (2010 est.)
country comparison to the world: 134
Electricity—imports: 0 kWh (2010 est.)
country comparison to the world: 137
Electricity—instatled generating capacity: 8.2
million kW (2009 est.)
country comparison to the world: 62
Electricity—from fossil fuels: 84.8% of total
installed capacity (2009 est.)
country comparison to the world: 87
Electricity—trom nuclear fuels: 0% of toral
installed capacity (2009 est.)
country comparison to the world: 181
Electricity—from hydroelectric piants: 15.2%
of total installed capacity (2009 est.)
country comparison to the world: 103
Electricity—from other renewable sources: 0%
of total installed capacity (2009 est.)
country comparison to the world: 189
705
Crude ofl—production: 333,900 bbl/day (2011 est.)
country comparison to the world: 34
Crude oil—exports: 144,000 bbl/day (2009 est.)
country comparison to the world: 36
Crude oil—imports: 0 bbl/day (2009 est.)
country comparison to the world: 125
Crude oill—proved reserves: 2.183 billion bbl
(1 January 2012 est.)
country comparison to the world: 35
Refined petroleum products—production:
255,600 bbl/day (2008 est.)
country comparison to the world: 50 .
Refined petroleum products—consumption:
258,800 bbl/day (2011 est.)
country comparison to the world: 50
Refined petroieum products—exports: 14,540
bbl/day (2008 est.)''
country comparison to the world: 83
Refined petroleum products—imports: 58,160
bbl/day (2008 est.)
country comparison to the world: 65
Natura! gas—production: 8.94 billion cu m
(2010 est.)
country comparison to the world: 46
Natural gas—consumption: 9.63 billion cu m
(2010 est.)
country comparison to the world: 49
Natural gas—exports: 0 cu m (2010 est.)
country comparison to the world: 185
Natural gas—imports: 690 million cu m (2010 est.)
country comparison to the world: 66
Natural gas—proved reserves: 240.7 billion
cu m (1 January 2012 est.)
country comparison to the world: 45
Carbon dioxide emissions from consumption
of energy: 63.1 million Mt (2010 est.)
country comparison to the world: 53','10a616a4c600313fa2ee2bd751cc8f198b6674d40c39e81950fd73844ddc9364','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('056a324c915378192b25b1877cf08776691b2faa5e2f4d9632ff8c2f069cafd2',2025,'TJ','Tajikistan','energy',1541,'Electricity—production: 16.9 billion kWh (2012
est.)
country comparison to the world: 78
Electricity—consumption: 15.9 billion kWh
(2012 est.)
country comparison to the world: 76
Electricity—exports: | billion kWh (2012 est.)
country comparison to the world: 55
Electricity—imports: 300.5 million kWh (2012
est.)
country comparison to the world: 82
Electricity—instatled generating capacity: 4.5
million kW (2012 est.)
country comparison to the world: 76
e
Electricity—from fossil fuels: 9% of total
installed capacity (2012 est.)
country comparison to the world: 196
Electricity—from nuclear fueis:.0% of total
installed capacity (2012 est.)
country comparison to the world: 184
Electricity—from hydroelectric plants: 91% of
total installed.capacity (2012 est.)
country comparison to the world: 12
Electricity—from other renewable sources: 0%
of total installed capacity (2012 est.)
country comparison to the world: 190
Crude olli—production: 215 bbl/day (2012 est.)
country comparison to the world: 100
Crude oll—exports: 80 bbl/day (2009 est.)
country comparison to the world: 71
Crude oil—imports: 0 bbl/day (2009 est.)
country comparison to the world: 126
Crude oil—proved reserves: 12 million bbl
(1 January 2013 est.)
country comparison to the world: 90
Refined petroleum products—production: NA
bbl/day
Refined petroleum products—consumption:
45,810 bbl/day (2011 est.)
country comparison to the world: 103
Refined petroleum products—exports: 225,200
bbl/day (2012 est.)
country comparison to the world: 119
Refined petroleum products—imports: 7,758
bbl/day (2008 est.)
country comparison to the world: 137
Natural gas—production: 40 million cu m (2012
est.) j
country comparison to the world: 85
Natural gas—consumption: 172 million cu m
(2012 est.)
country comparison to the world: 102
Natural gas—exports: 0 cu m (2012 est.)
country comparison to the world: 188
Natural gas—imports: 132.4 million cu m (2012
est.)
country comparison to the world: 72
Natura! gas—proved reserves: 5.663 billion
cum (1 January 2012 est.)
country comparison to the world: 91
Carbon dioxide emissions from consumption
of energy: 6.678 million Mr (2010 est.)
country comparison to the world: 115','d4fb5b5125741aa01d1094ff76231aa5e5533ca057e78e858bd780d01840add4','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1d90482a88c32cb93025adb37e39f5e8fad78391a47c300debda8fc5bf7a863d',2025,'TH','Thailand','energy',1550,'Electricity—production: 173.3 billion kWh
(2012 est.)
country comparison to the world: 25
Electricity—consumption: 169.4 billion kWh
(2012 est.)
country comparison to the world: 23
Electricity—exports: 1.535 billion kWh (2012
est.)
country comparison to the world: 47
Electricity—imports: 9.575 billion kWh (2012
T est.)
country comparison to the world: 24
Electricity—installed generating capacity:
32.6 million kW (2012 est.)
country comparison to the world: 26
Electricity—trom fossil fuels: 89% of total
installed capacity (2012 est.) :
country comparison to the world: 77
Electricity—from nuclear fuels: 0% of toral
installed capacity (2012 est.)
country comparison to the world: 183
Electricity—from hydroelectric plants: 10.9%
of total installed capacity (2012 est.)
country comparison to the world: 114
Electricity—from other renewable sources: 0.2%
of total installed capacity (2012 est.)
country comparison to the world: 88
Crude oll—production: 213,000 bbi/day (2011 est.)
country comparison to the world: 40
Crude oit—exports: 32,200 bbl/day (2011 est.) i
country comparison to the world: 51
Crude oil—imports: 793,900 bbl/day (2011 est.)
country comparison to the world: 15
Crude oli—proved reserves: 442 million bbl
(1 January 2012 est.)
country comparison to the world: 53
Refined petroleum products—production:
913,600 bbl/day (2011 est.)
country comparison to the world: 24
Refined petroleum products—consumption:
721,100 bbl/day (2011 est.)
country comparison to the world: 26
Refined petroleum products—exports: 192,400
bbl/day (2011 est.)
country comparison to the world: 34
Refined petroleum products—imports: 41,700
bbl/day (2011 est.)
country comparison to the world: 74
Natural gas—production: 28.21 billion cu m
(2011 est.)
country comparison to the world: 31
Natural gas—consumption: 45.8 billion cu m
(2010 est.) _
country comparison to the world: 21
Natural gas—exports: 0 cu m (2010 est.)
country comparison to the world: 187
Natural gas—imports: 8.81 billion cu m (2010
est.)
country comparison to the world: 27
Natural gas—proved reserves: 299.8 billion
cu m (1 January 2012 est.)
country comparison to the world: 40
Carbon dioxide emissions from consumption of
energy: 278.5 million Mt (2010 est.)
country comparison to the world: 22','5e5ef9b88df5f04f68199b36110365a2d3c19a52c242b0477b11e8108bd46c5e','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('20db66ff1b03a357aa7e55b797a3fc358be91dc8fc52b308752ec420996bbb21',2025,'TL','Timor-Leste','energy',1558,'Electricity—production: 131.7 million kWh
(2011 est.)
country comparison to the world: 189
Electricity—consumption: 67.59 million kWh
(2011 est.)
country comparison to the world: 202
Electricity—exports: 0 kWh (2011 est.)
country comparison to the world: 140
Electricity—imports: 0 kWh (2011 est.)
country comparison to the world: 142
“Crude oil—production: 83,740 bbl/day (2011
est.)
country comparison to the world: 52
Crude oil—exports: 96,270 bbl/day (2009 est.)
country comparison to the world: 38
Crude oil—imports: 0 bbl/day (2009 est.)
country comparison to the world: 131
Crude oil—proved reserves: 553.8 million bbl
(1 January 2012 est.)
country comparison to the world: 50
Refined petroleum products—production: 0
bbl/day (2008 est.)
country comparison to the world: 201
Refined petroleum products—consumption:
2,755 bbl/day (2011 est.)
country comparison to the world: 185
Refined petroleum products—exports: 0 bbl/
day (2009 est.)
country comparison to the world: 137
Refined petroleum products—imports: 2,205
bbi/day (2008 est.)
country comparison to the world: 178
Natural gas—production: 0 cu m (2010 est.)
country comparison to the world: 200
Natural gas—consumption: 0 cu m (2010 est.)
country comparison to the world: 201
Natural gas—exports: 0 cu m (2010 est.)
country comparison to the world: 194
Natural gas—imports: 0 cu m (2010 est.)
country comparison to the world: 138
Natural gas—proved reserves: 200 billion cum
(1 January 2006 est.)
country comparison to the world: 46
Carbon dioxide emissions from consumption
of energy: 395,300 Mr (2010 esr.)
country comparison to the world: 183','5bf61a8bcaf156144680c364b516d7b29b313d85e000092392aadac1ac8604b5','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('35e78ea7e1faba9d68e1ed5e9065747dc67253d5b2e6ec4372ed511e14e32ee8',2025,'TK','Tokelau','energy',1575,'Crude oll—proved reserves: O bbl (1 January
2012 est.)
country comparison to the world: 193','aa1b7ae45ab6e9007c5436a8d01a257f8a8053af508ebd317909354a8abce79d','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8c7edbaddcc76f8c4ea8382d4bb95a7798958085d2acfe19e627c2e7c9e41a82',2025,'TO','Tonga','energy',1580,'Electricity—production: 41 million kWh (2009
est.) l . f
country comparison to the world: 208
Electrieity—consumption: 38.13 million kWh
(2009 est.)
country comparison to the world: 208
Electricity—exports: 0 kWh (2010)
country comparison to the world: 137
Electricity—imports: 0 kWh (2010 est.)
country comparison to the world: 140
Electricity—installed generating capacity:
12,000 kW (2009 est.)
country comparison to the world: 199
Electricity—from fossil fuels: 100% of total
installed capacity (2009 est.)
country comparison to the world: 40
Electricity—from nuclear fuels: 0% of total
installed capacity (2009 est.)
country comparison to the world: 186
Electricity—from hydroelectric plants: 0% of
total installed capacity (2009 est.)
country comparison to the world: 203
Electricity—from other renewable sources: 0%
of total installed capacity (2009 est.)
country comparison to the world: 192
Crude oil—production: 0 UUl/day (2011 est.)
country comparison to the world: 194
Crude oil—exports: 0 UUl/day (2009 est.)
country comparison to the world: 191
Crude oii—im ports: 0 UUl/day (2009 est.)
country comparison to the world: 128
Crude oii—proved reserves: 0 UUI (1 January
2010 est.)
country comparison to the world: 194
Refined petroleum products—production: 0
UUl/day (2008 est.)
country comparison to the world: 198
Refined petroleum products—consumption:
1,221 UUl/day (2011 est.)
country comparison to the world: 197
Refined petroleum products—exports; 0 UUI
day (2008 ''est.)
country comparison to the world: 134
Refined petroleum products—imports: 1,202
UUl/day (2008 est.)
country comparison to the world: 190
Natural gas—production: 0 cu m (2010 est.)
country comparison to the world: 197
Natural gas—consumption: 0 cu m (2010 est.)
country comparison to the world: 198
Natural gas—exports: 0 cu m (2010 est.)
country comparison to the world: 190
Natural gas—imports: O cu m (2010 est.)
country comparison to the world: 135
Natural gas—proved reserves: 0 cu m (1 Janu-
ary 2012 est.)
country comparison to the world: 197
Carbon dioxide emissions from consumption of
energy: 155,000 Mt (2010 est.)
country comparison to the world: 197
Telephones—main lines in use: 30.0 (2011)
country comparison to the world: 176
Telephones—mobile cellular: 55.0 (2011)
country comparison to the world: 200
Telephone system: general assessment: com-
petition between Tonga Telecommunications
Corporation (TCC) and Shoreline Communi-
cations Tonga (SCT) is accelerating expansion
of telecommunications; SCT granted approval
to introduce high-speed digital service for tel-
ephone, Internet, and television while TCC has
exclusive rights to operate the mobile-phone
network; international telecom services are pro-
vided by government-owned Tonga Telecom-
munications International domestic: combined
fixed-line and mobile-cellular teledensity about
80 telephones per 100 persons; fully automatic
switched network
international: country code—676; satellite earth
station—1 Intelsat (Pacific Ocean) (2011)
Broadcast media: 2 state-owned TV stations
and 2 privately owned TV stations; satellite and
cable TV services are available; 2 state-owned and
3 privately owned radio stations; Radio Australia
broadcasts available via satellite (2009)
Internet country code: .to
Internet hosts: 5,367 (2012)
country comparison to the world: 144
Internet users: 8,400 (2009)
country comparison to the world: 203','3daa1fe68bd516225867e4b0f09cf34e58cdcb22a7cdf17d79afa562f15d2f0b','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('dfa2ec02a0e93e4361a29934b843a8c5671196375ac84168475364dcdc9450e3',2025,'TT','Trinidad and Tobago','energy',1583,'Electricity—production: 7.271 billion kWh
(2009 est.)
country comparison to the world: 103
Electricity—consumption: 7.102 billion kWh
(2009 est.)
country comparison to the world: 100
Electricity—exports: 0 kWh (2010 est.)
country comparison to the world: 135
Electricity—imports: 0 kWh (2010 est.)
country comparison to the world: 138
Electricity—installed generating capacity:
1.429 million kW (2009 est.)
country comparison to the world: 114
Electricity—from fossil fuels: 99.7% of total
installed capacity (2009 est.)
country comparison to the world: 54
Electricity—from nuclear fuels: 0% of total
installed capacity (2009 est.)
country comparison to the world: 182
Electricity—from hydroelectric plants: 0% of
total installed capacity (2009 est.)
country comparison to the world: 201
Electricity—from other renewable sources:
0.3% of total installed capacity (2009 est.)
country comparison to the world: 85
Crude oli—production: 135,900 bbl/day (2011
est.)
country comparison to the world: 46
Crude oll—exports: 55,240 bbl/day (2009 est.)
country comparison to the world: 45
Crude oll—imports: 56,540 bbl/day (2009 est.)
country comparison to the world: 54
Crude oil—proved reserves: 728.3 million bbl
(1 January 2012 est.)
country comparison to the world: 44
Refined petroleum products—production:
165,100 bbl/day (2008 est.)
country comparison to the world: 62
Refined petroleum products—consumption:
41,000 bbl/day (2011 est.)
country comparison to the world: 107
736
THE CIA WORLD FACTBOOK
Refined petroleum products—exports: 148,600
bbl/day (2008 est.)
country comparison to the world: 38
Refined petroleum products—imports: 242.3
bbl/day (2008 est.)
country comparison to the world: 206
Natural gas—production: 42.46 billion cu m
(2010 est.)
country comparison to the world: 25
Natura! gas—consumption: 22.8 billion cu m
(2010 est.)
country comparison to the world: 34
Natural gas—exports: 20.38 billion cu m (2010
est.)
country comparison to the world: 16
Natural gas—imports: 0 cu m (2010 est.)
country comparison to the world: 133
Natural gas—proved reserves: 381.1 billion
cu m (1 January 2012 est.)
country comparison to the world: 36
Carbon dioxide emissions from consumption
of energy: 49.93 million Mt (2010 est.}
country comparison to the world: 62 `','6a9d1df459fbca7cb31b0de6525befcd2a1da41583baa0e2371fb8568592add0','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2a97ba366471daabfd9ac0cd0bc019ae2cc2eb9917369b43324ca064d662e8d8',2025,'TM','Turkmenistan','energy',1597,'Electricity—production: 15.02 billion kWh
(2009 est.)
country comparison to the world: 82
Electricity—consumption: 11.22 billion kWh
(2009 est.)
country comparison to the world: 86
Electricity—exports: 1.568 billion kWh (2009
est.)
country comparison to the world: 46
Electricity—Iimports: 0 kWh (2009 est.)
country comparison to the world: 144
Electricity—instalied generating capacity:
2.852 million kW (2009 est.)
country comparison to the world: 90
Electricity—from fossil fuels: 100% of total
installed capacity (2009 est.)
country comparison to the world: 41
Electricity—trom nuclear fuels: 0% of total
installed capacity (2009 est.)
country comparison to the world: 191
Electricity—from hydroelectric plants: 0% of
total installed capacity (2009 est.)
country comparison to the world: 204
Electricity—from other renewable sources: 0%
of total installed capacity (2009 est.)
country comparison to the world: 195
Crude ol!—production: 222,200 bbl/day (2011
est.)
country comparison to the world: 38
Crude oil—exports: 67,000 bbl/day (2012 est.)
country comparison to the world: 42
Crude oil—imports: 0 bbl/day (2009 est.)
country comparison to the world: 132
Crude oll—proved reserves: 600 million bbl
(1 January 2012 est.)
country comparison to the world: 46
Refined petroleum products—production:
160,300 bbl/day (2008 est.)
country comparison to the world: 64
Refined petroleum products—consumption:
145,000 bbl/day (2011 est.)
country comparison to the world: 69
Refined petroleum products—exports: 74,430
bbl/day (2008 est.)
country comparison to the world: 49
Refined petroleum products—imports: 2,542
bbl/day (2008 est.)
country comparison to the world: 175
Natural gas—production: 59.5 billion cu m
(2011 est.)
country comparison to the world: 17
Natural gas—consumption: 25 billion cu m
(2011 est.)
country comparison to the world: 33
Natural gas—exports: 34.5 billion cu m (2011
est.)
country comparison to the world: 12
Natural gas—imports: 0 cu m (2011 est.)
country comparison to the world: 139
Natural gas—proved reserves: 24.3 trillion cu
m (June 2012 est.)
country comparison to the world: 5
Carbon dioxide emissions from consumption of
energy: 62.5 million Mt (2010 est.)
country comparison. to the world: 55','e920144f2327b05ed381f9dac0e4078a85da299dde25beb43594fc056f02166a','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5dc30d3cd8dd7d4a04e5cc460dbf22829ae4e3288b76e8b15672c72bf10ae59c',2025,'TC','Turks and Caicos Islands','energy',1606,'Electricity—production: 200 million kWh (2009
est.)
country comparison to the world: 181
Electricity—consumption: 186 million kWh
(2009 est.) j
country comparison to the world: 186
749
Electricity—exports: 0 kWh (2010 est.)
country comparison to the world: 136
Electricity—imports: 0 kWh (2010 est.)
country comparison to the world: 139
Electricity—instalied generating capacity:
50,000 kW (2009 est.)
country comparison to the world: 184
Electricity—from fossil fuels: 100% of total
installed capacity (2009 est.)
country comparison to the world: 39
Electricity—from nuclear fuels: 0% of total
installed capacity (2009 est.)
country comparison to the world: 185
Electricity—from hydroelectric plants: 0% of
total installed capacity (2009 est.)
country comparison to the world: 202
Electricity—from other renewable sources: 0%
of total installed capacity (2009 est.)
country comparison to the world: 191
Crude oil—production: 0 bbl/day (2011 est.)
country comparison to the world: 193
Crude olt—exports: 0 bbl/day (2009 est.)
country comparison to the world: 190
Crude oil—imports: 0 bbi/day (2009 est.)
country comparison to the world: 127
Crude oil—proved reserves: 0 bbl (1 January
2012 est.)
country comparison to the world: 192
Refined petroleumproducts—production: 0
bbl/day (2008 est.)
country comparison to the world: 197
Refined petroleum products—consumption:
bbl/day (2011 est.)
country comparison to the world: 204
Refined petroleum products—exports: 0 bbi/
day (2008 est.)
country comparison to the world: 133
THE CIA WORLD FACTBOOK
Refined petroleum products—imports: 1,042
bbl/day (2008 est.)
country comparison to the world: 193
Natura! gas—production: 0 cu m (2010 est.)
country comparison to the world: 196
Natural gas—consumption: 0 cu m (2010 est.)
country comparison to the world: 197
Natural gas—exports: 0 cu m (2010 est.)
country comparison to the world: 189
Natural gas—imports: 0 cu m (2010 est.)
country comparison to the world: 134
Natural gas—proved reserves: 0 cu m (i Janu-
ary 2012 est.)
country comparison to the world: 196
Carbon dioxide emissions from consumption
of energy: 38,880 Mr (2010 est.)
country comparison to the world: 208','aedf9e99e4e0435f740cc21f5c74867a24d83556a0fb7e60f5dd841fa250a8a8','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6573e91997a1374016e5b5a81d05114925e345fcf610cbeadb55af4cf2b970b7',2025,'UG','Uganda','energy',1621,'Electricity—production: 2.445 billion kWh
(2009 est.)
country comparison to the world: 133
Electricity—consumption: 2.217 billion kWh
(2009 est.)
country comparison to the world: 139
Electricity—exports: 75 million kWh (2010)
country comparison to the world: 76
Electricity—imports: 29 million kWh (2014 est.)
country comparison to the world: 104
Electricity—installied generating capacity:
529,000 kW (2009 est.)
country comparison to the world: 136
Electricity—from fossil fuels: 37.8% of total
installed capacity (2009 est.)
country comparison to the world: 172
Electricity—from nuclear fuels: 0% of total
installed capacity (2009 est.) `“
country comparison to the world: 193
Electricity—from hydroelectric plants: 59.5%
of total installed capacity (2009 est.)
country comparison to the world: 33
Electricity—from other renewable sources:
2.6% of total installed capacity (2009 est.)
country comparison to the world: 51
Crude oil—production: 0 bbi/day (2011 est.)
country comparison to the world: 198
Crude oil—exports: 0 bbl/day (2009 est.)
country comparison to the world: 197
Crude oil—imports: 0 bbl/day (2009 est.)
country comparison to the world: 134
Crude oil—proved reserves: 0 billion bbl (1
January 2010 est.)
country comparison to the world: 42
Refined petroleum products—production: 0
bbl/day (2008 est.)
country comparison to the world: 203
Refined petroleum products—consumption:
16,930 bbl/day (2011 est.)
country comparison to the world: 140
Refined petroleum products—exports: 0 bbl/
day (2008 est.)
country comparison to the world: 139
Refined petroleum products—imports: 23,950
bbl/day (2008 est.)
country comparison to the world: 98
Natural gas—production: 0 cu m (2010 est.)
country comparison to the world: 201
Natura! gas—consumption: 0 cu m (2010 est.)
country comparison to the world: 202
Natural gas—exports: 0 cu m (2010 est.)
country comparison to the world: 197
Natural gas—imports: 0 cu m (2010 est.)
country comparison to the world: 141
Natural gas—proved reserves: 6 billion cu m (1
January 2012 est.)
country comparison to the world: 80
Carbon dioxide emissions from consumption
of energy: 2.014 million Mt (2010 est.)
country comparison to the world: 150','396f7b1863aeac3c2bac9c09ac9d3a2a14bc56f7f471ef453e0deb3eb1375740','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a303a73ad5a826e5b163087463d61ae83ff91837882cd522c495c179589d6ec2',2025,'UA','Ukraine','energy',1632,'Electricity—production: 198.1 billion kWh
(2012 est.)
country comparison to the world: 23
Electricity—consumption: 175.3 billion kWh
(2012 est.)
country comparison to the world: 21
Electricity—exports: 3.852 billion kWh (2012
est.)
country comparison to the world: 33
Electricity—imports: 1.894 billion kWh (2009
est.)
country comparison to the world: 52
Electricity—installed generating capacity:
54.38 million kW (2009 est.)
country comparison to the world: 18
Electricity—from fossil fuels: 64.4% of total
installed capacity (2009 est.)
country comparison to the world: 130
Electricity—trom nuclear fuels: 25.4% of total
installed capacity (2009 est.)
country comparison to the world: 3
Electricity—from hydroelectric plants: 10% of
total installed capacity (2009 est.)
country comparison to the world: 115
Electricity—from other renewable sources:
0.1% of total installed capacity (2009 est.)
country comparison to the world: 92
Crude oil—production: 73,180 bbl/day (2011
est.)
country comparison to the world: 53
Crude oll—exports: 160 bbl/day (2009 est.)
country comparison to the world; 70
Crude oli—imports: 143,600 bbl/day (2009 est.)
country comparison to the world: 43
Crude oil—proved reserves: 395 million bbl (1
January 2012 es)
country comparison to the world: 55
Refined petroleum products—production:
262,200 bbl/day (2008 est.)
country comparison to the world: 49
Refined petroleum products—consumption:
320,600 bbl/day (2011 est.)
country comparison to the world: 40
Refined petroleum products—exports: 76,140
bbl/day (2008 est.)
country comparison to the world: 48
Refined petroleum products—imports: 148,900
bbl/day (2008 est.)
country comparison to the world: 38
Natural gos—production: 19.36 billion cu m
(2010 est.)
country comparison to the world: 35
759
Natural gas—consumption: 53.16 billion cu m
(2010 est.) ''
country comparison to the world: 16
Natural gas—exports: 2.6 billion cu m (2010
est.)
country comparison to the world: 37
Natural gas—imports: 36.4 billion cu m (2010
est.)
country comparison to the world: 12
Natural gas—proved reserves: 1.104 trillion
cum (1 January 2012 est.)
country comparison to the world: 26
Carbon dioxide emissions from consumption
of energy: 275.5 million Mt (2010 est.)
country comparison to the world: 23','63cd39e4e09d8087a93f74c1edff7138c25ba943f1aa5e948d03a42a24c3e8f2','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b3cb5e5ac73b29edff860d3006383811c9696545e85f53204225171fef7a825c',2025,'US','United States','energy',1658,'Electricity—production: 4.12 trillion kWh (2010
est.)
country comparison to the world: 3
Electricity—consumption: 3.889 trillion kWh
(2010 est.)
country comparison to the world: 3
Electricity—exports: 19.41 billion kWh (2010
est.)
country comparison to the world: 8
Electricity—imports: 45.23 billion kWh (2010
est.)
country comparison to the world: 4
Electricity—installed generating capacity:
1.025 billion kW (2010 est.)
country comparison to the world: 3
Electricity—from fossil fuels: 75.5% of total
installed capacity (2010 est.)
country comparison to the world: 97
Electricity—from nuclear fuels: 9.9% of total
installed capacity (2010 est.)
country comparison to the world: 21
Electricity—from hydroelectric plants: 7.7% of
total installed capacity (2010 esr.)
country comparison to the world: 121
Electricity—from other renewable sources:
4.8% of toral installed capacity (2010 est.)
country comparison to the world: 39
Crude oil—production: 9.23 million bbl/day
(2011 est.)
country comparison to the world: 4
Crude oil—exports: 43,800 bbl/day (2009 est.)
country comparison to the world: 49
Crude oll—imports: 9.013 million bbl/day (2009
est.)
country comparison to the world: 2
Crude oll—proved reserves: 20.68 billion bbl (1
January 2012 est.)
country comparison to the world: 15
Refined petroleum products—production:
17.88 million bbl/day (2009 est.)
country comparison to the world: 2
Refined petroleum products—consumption:
18.84 million bbl/day (2011 est.)
country comparison to the world: 2
Refined petroleum products—exports: 1.876
million bbl/day (2009 est.)
country comparison to the world: 4
Refined petroleum products—imports: 1.255
million bbl/day (2009 est.)
country comparison to the world: 6
Natural gas—production: 651.3 billion cu m
_ (2011 est.)
country comparison to the world: 3
Natura! gas—consumption: 689.9 billion cu m
(2011 est.)
country-comparison to the world: 2
Natural gas—exports: 42.67 billion cu m (2011
est.)
country comparison to the world: 9
Natural gas—imports: 97.86 billion cu m (2011
est.)
country comparison to the world: 4
Natural gas—proved reserves: 7.716 trillion
cu m (1 January 2009 est.)
country comparison to the world: 7
Carbon dioxide emissions from consumption
of energy: 5.61 billion Mt (2010 est.)
country comparison to the world: 3','d2ea6a379a2986fb450fcf21906c3537d24409c903f08e06ce6045f55fa6d33c','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2340092db26383707ae0aa94be33a3d765d4da10b373ca38debd7335def58e39',2025,'UY','Uruguay','energy',1665,'Electricity—production: 9.5 billion kWh (2011
est.)
country comparison to the world: 95
Electricity—consumption: 7.96 billion kWh
(2011 est.)
country comparison to the world: 95
Electricity—exports: 18.9 million kWh (2011
est.)
country comparison to the world: 82
Electricity—imports: 470 million kWh (2011
est.)
country comparison to the world: 80
Electricity—installed generating capacity:
2.516 million kW (2009 est.)
country comparison to the world: 94
Electricity—from fossil fuels: 38.5% of total
installed capacity (2009 est.)
country comparison to the world: 171
Electricity—from nuclear fuels: 0% of total
installed capacity (2009 est.)
country comparison to the world: 195
Electricity—from hydroelectric plants: 61.1%
of total installed capacity (2009 est.)
country comparison to the world: 30
Electricity—from other renewable sources:
0.4% of total installed capacity (2009 est.)
country comparison to the world: 78
Crude oll—production: 0 bbl/day (2011 est.)
country comparison to the world: 200
Crude oll—exports: 0 bbi/day (2009 est.)
country comparison to the world: 199
Crude ojl—imports: 38,720 bbl/day (2009 est.)
country comparison to the world: 62
Crude oil—proved reserves: 0 bbl (1 January
2009 est.)
country comparison to the world: 199
Refined petroleum products—production:
43,370 bbl/day (2008 est.)
country comparison to the world: 86
Refined petroleum . products—consumption:
51,100 bbl/day (2011 esr.)
country comparison to the world: 99
Refined petroleum products—exports: 6,093
bbl/day (2008 est.)
country comparison to the world: 94
Refined petroleum products—imports: 22,060
bbl/day (2008 est.)
country comparison to the world: 103
Natural gas—production: 0 cu m (2011 est.)
country comparison to the world: 203
Natural gas—consumption: 80 million cu m
(2010 est.)
country comparison to the world: 106
Natural gas—exports: 0 cu m (2011 est.)
country comparison to the world: 199
Natural gas—imports: 86.4 million cu m (2011
est.)
country comparison to the world: 74
Natural gas—proved reserves: 0 cu m (1 Janu-
ary 2012 est.)
country comparison to the world: 201
Carbon dioxide emissions from consumption
of energy: 7.265 million Mr (2010 est.)
country comparison to the world: 112','c7c325796afef2443e651da691d1e5f356b4ebb07d0896f0aad55c422fccf3e6','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8e7312a61e9a79e443ce20112e4ad086c66efc596f5007fd8b55485b85f3df83',2025,'UZ','Uzbekistan','energy',1674,'Electricity—production: 52.53 billion kWh:
(2012 est.)
country comparison to the world: 50
Electricity—consumption: 42.9 billion kWh
(2009 est.)
country comparison to the world: 52
Electricity—exports: 11.66 billion kWh (2009
est.)
country comparison to the world: 19
Electricity—imports: 11.58 billion kWh (2009
est.)
country comparison to the world: 17
Electricity—instatled generating capacity:
12.4 million kW (2012 est.)
country comparison to the world: 49
Electricity—from fossil fuels: 85.2% of total
installed capacity (2009 est.)
country comparison to the world: 86
Electricity—from nuclear fuels: 0% of total
installed capacity (2009 est.)
country comparison to the world: 196
Electricity—from hydroelectric plants: 14.8%
of total installed capacity (2009 est.)
782
THE CIA WORLD FACTBOOK
country comparison to the world: 105
Electricity—from other renewable sources: 0%
of total installed capacity (2009 est.)
country comparison to the world: 198
Crude oil—production: 104,400 bbli/day (2011
est.)
country comparison to the world: 49
Crude oil—exports: 0 bbl/day (2009 est.)
country comparison to the world: 200
Crude oli—imports: 5,000 bbl/day (2012 est.)
country comparison to the world: 81
Crude oil—proved reserves: 594 million bbl (1
January 2012 est.)
country comparison to the world: 48
Refined petroleum products—production:
90,690 bbl/day (2008 est.)
country comparison to the world: 77
Refined petroleum products—consumption:
137,100 bbl/day (2011 est.)
country comparison to the world: 72
Refined petroleum products—exports: 5,488
bbi/day (2008 est.)
country comparison to the world: 96
Refined petroleum products—imports: 0 bbl/
day (2008 est.)
country comparison to the world: 210
Natural gas—production: 62.9 billion cu m
(2012 est.)
country comparison to the world: 15
Natural gas—consumption: 46.8 billion cu m
(2012 est.)
country comparison to the world: 18
Natural gas—exports: 13.4 billion cu m (2012
est.)
country comparison to the world: 20
Natural gas—imports: 0 cu m (2012 est.)
country comparison to the world: 143
Natural gas—proved reserves: 1.841 trillion .
cu m (1 January 2012 est.)
country comparison. to the world: 20
Carbon dioxide emissions trom consumption
of energy: 114.3 million Mt (2010 est.)
country comparison to the world: 37','f7a8562ad71ec032add2a1e1be39272424d23625d7556a2ac5e1cc7ef18a7e5b','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('02154d18b4c988a306f7be9e65572592021f963ca01ae3756f10e1642cae92fd',2025,'VU','Vanuatu','energy',1684,'Electricity—production: 55 million kWh (2009 est.)
country comparison to the world: 203
Electricity—consumption: 51.15 million kWh
(2009 est.)
country comparison to the world: 204
Electricity—exports: 0 kWh (2010 est.)
country comparison to the world; 111
Electricity—imports: 0 kWh (2010 est.)
country comparison to the world: 114
Electricity—installed generating capacity:
12,000 kW (2009 est.)
country comparison to the world: 200
Electricity—from fossil fuels: 100% of total
installed capacity (2009 est.)
country comparison to the world: 29
Electricity—from nuclear fuels: 0% of total
installed capacity (2009 est.)
country comparison to the world: 150
_ Electricity—from hydroelectric plants: 0% of
total installed capacity (2009 est.)
country comparison to the world: 189°
Electricity—from other renewable sources: 0%
of total installed capacity (2009 est.)
country comparison to the world: 167
Crude oll—production: 0 bbi/day (2011 est.)
country comparison to the world: 173
Crude oil—exports: 0 bbl/day (2009 est.)
country comparison to the world: 161
Crude oil—imports: 0 bbl/day (2009 est.)
country comparison to the world: 107
Crude oil—proved reserves: 0 bbl (1 January
2012 est.)
country comparison to the world: 172
Refined petroleum products—production: 0
bbl/day (2008 est.)
country comparison to the world: 184
Refined petroleum products—consumption:
1,170 bbl/day (2011 est.)
country comparison to the world: 198
Refined petroleum products—exports: 0 bbi/
day (2008 est.)
country comparison to the world: 208
Refined petroleum products—imports: 676.4
bbl/day (2008 est.)
country comparison to the world: 199
Natural gas—production: 0 cu m (2010 est.)
country comparison tò the world: 174
Natural gas—consumption: 0 cu m (2010 est.)
country comparison to the world: 180
Natural gas—exports: 0 cu m (2010 est.)
country comparison to the world: 154
Natural gas—imports: 0 cu m (2010 est.)
country comparison to the world: 106
Naturai gas—proved reserves: 0 cu m (1 Janu-
ary 2012 est.)
country comparison to the world: 177
Carbon dioxide emissions from consumption of
energy: 146,500 Mr (2010 est.)
country comparison to the world: 204','ef3256e29cd1a2025e28240c67f7a353c1e0cb83618b8b7622f9283bc8cfb72c','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c629b87075429266b4c1de8591b7a1f06a98ee08593ce5e276170e6771c6f748',2025,'VN','Viet Nam','energy',1691,'Electricity—production: 117 billion kWh (2012
est.)
country comparison to the world: 32
Electricity—consumption: 104 billion kWh
(2012 est.)
country comparison to the world: 33
Electricity—exports: 1.555 million kWh (2012
est.)
country comparison to the world: 86
794
THE CIA WORLD FACTBOOK
Electricity-imports: 2.7 billion kWh (2012 est.)
country comparison to the world: 46
Electricity—instalied generating capacity:
26.3 million kW (2012 est.)
country comparison to the world: 30
Electricity—from fossil fuels: 55% of total
installed capacity (2012 est.)
country comparison to the world: 146
Electricity—from nuclear fuels: 0% of total
installed capacity (2012 est.)
country comparison to the world: 200
Electricity—from hydroelectric plants: 45%
of total installed capacity (2012 est.)
country comparison to the world: 47
Electricity—from other renewable sources:
0.1% of total installed capacity (2012 est.)
country comparison to the world: 91
Crude oli—production: 336,100 bbl/day (2012
est.)
country comparison to the world: 33
Crude oil—exports: 188,000 bbi/day (2012 est.)
country comparison to the world: 32
Crude oll—imports: 0 bbl/day (2012 est.)
country comparison to the world: 139
Crude oii—proved reserves: 4.7 billion bbl
(1 January 2013 est.)
country comparison to the world: 27
Refined petroleum products—production:
112,000 bbl/day (2012 est.)
country comparison to the world: 71
Refined petroleum products—consumption:
259,900 bbl/day (2012 est.)
country comparison to the world: 48
Refined petroleum products—exports: 37,050
bbl/day (2012 est.)
country comparison to the world: 65 .
Refined petroleum products—imports: 184,900
bbl/day (2012 est.)
country comparison to the world: 28
Natural gas—production: 9.3 billion cu m (2012
est.)
country comparison to the world: 45
Natural gas—consumption: 10.2 billion cu m
(2012 est.)
country comparison to the world: 46
Natural gas—exports: 0 cu m (2012 est.)
country comparison to the world: 203
Natural gas—imports: 890 million cu m (2012
est.)
country comparison to the world: 61
Natural gas—proved reserves: 699.4 billion
cu m (1 January 2012 est.)
country comparison to the world: 31
Carbon dioxide emissions from consumption
of energy: 112.8 million Mt (2010 est.)
country comparison to the world: 38','72d789ecb7830b3697e5d2b3b22da9ccea3afcc5536746eb566b5780ed6bf8ca','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8a51c868033f0e33748596f2912ecc2fa011a703431f814bc831fc72c085b3db',2025,'PR','Puerto Rico','energy',1699,'Electricity—production: 872 million kWh (2009
est.)
country comparison to the world: 151
Electricity—consumption:, 811 million kWh
(2009 est.)
country comparison to the world: 155
Electricity—exports: 0 kWh (2010 est.)
country comparison to the world: 146
Electricity—Imports: 0 kWh (2010 est.)
country comparison to the world: 148
Electricity—installed generating capacity:
323,000 kW (2009 est.)
country comparison to the world: 148
Electricity—from fossil fuels: 100% of total
installed capacity (2009 est.)
country comparison to the world: 43
Electricity—from nuclear fuels: 0% of total
installed capacity (2009 est.)
country comparison to the world: 201
refined petroleum
Electricity—from hydroelectric plants: 0% of
total installed capacity (2009 est.)
country comparison to the world: 206
Flectricity—from other renewable sources: 0%
of total installed capacity (2009 est.)
country comparison to the world: 202
Crude oil—production: 0 bbl/day (2011 est.)
country comparison to the world: 203
Crude oil—exports: 0 bbl/day (2009 est.)
country comparison to the world: 203
Crude oil—imports: 425,000 bbl/day (2009 est.)
country comparison to the world: 20
Crude oil—proved reserves: 0 bbl (1 January
2013 est.)
country comparison to the world: 202
Refined petroleum products—production:
493,200 bbl/day (2008 est.)
country comparison to the world: 33
Refined petroleum products—consumption:
106,100 bbl/day (2011 est.)
country comparison to the world: 78
Refined petroleum products—exports: 390,000
bbl/day (2008 est.)
country comparison to the world: 21
Refined petroleum products—imports: 5,180
bbl/day (2008 est.)
country comparison to the world; 155
Natural gas—production: 0 cu m (2010 est.)
country comparison to the world: 206
Natural gas—consumption: 0 cu m (2010 est.)
VIRGIN ISLANDS
country comparison to the world: 206
Natural gas—exports: 0 cu m (2010 est.)
country comparison to the world: 204
Natural gas—imports: 0 cu m (2010 est.)
country comparison to the world: 146
Natural gas—proved reserves: 0 cu m (1 Janu-
ary 2012 est.)
country comparison to the world: 204
Carbon dioxide emissions from consumption
of energy: 11.95 million Mt (2010 est.)
country comparison to the world: 97','8befc2a33eda1cf60b988622865a1e45d512db15c7d9ce9169648fdb2807e8ec','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2b2d4c95b17baa2fbf905c50302401abbe7738c5f1e4a4a4941c8f95506bd075',2025,'IL','Israel','energy',1708,'Electricity—production: 470 million kWh (2009
est.) E i
country comparison to the world: 163
Electricity—consumption: 4.42 billion kWh
(2009 est.)
country comparison to the world: 120
802
THE CIA WORLD FACTBOOK
Electricity—exports: 0 kWh (2011)
country comparison to the world: 147
Electricity—imports: 550 million kWh (2011
est.)
country comparison to the world: 75
Electricity—installed generating capacity:
140,000 kW
country comparison to the world: 160
note: includes Gaza Strip (2009 est.)
Electricity—tfrom fossil fuels: 100% of total
installed capacity (2009 est.)
country comparison to the world: 44
Electricity—from nuclear fuels: 0% of total
installed capacity (2009 est.)
country comparison to the world: 203
Electricity—from hydroelectric plants: 0% of
total installed capacity (2009 est.)
country comparison to the world: 207
Electricity—from other renewable sources: 0%
of total installed capacity (2009 est.)
country comparison to the world: 204
Crude oll—production: 0 bbi/day (2011 est.)
country comparison to the world: 205
Crude oll—exports: 0 bbl/day (2009 est.)
country comparison to the world: 205
Crude oil—imports: 0 bbi/day (2009 est.)
country comparison to the world: 141
Crude oli—proved reserves: 0 bbl (i January
2009 est.)
country comparison to the world: 204
Refined petroleum products—production: 0
bbl/day (2008 est.)
country comparison to the world: 208
Refined petroleum products—consumption:
29,310 bbl/day (2011 est.)
country comparison to the world: 117
Refined petroleum products—exports: 1.92
bbl/day (2008 est.)
country comparison to the world: 124
Refined petroleum products—imports: 15,420
bbl/day (2008 est.)
country comparison to the world: 119
Natural gas—production: 0 cu m (2010 est.)
country comparison to the world: 208
Natural gas—consumption: 0 cu m (2010 est.)
country comparison to the world: 208
Natural gas—exports: 0 cu m (2010 est.)
country comparison. to the world: 206
Natural gas—imports: 0 cu m (2010 est.)
country comparison to the world: 148
Natural gas—proved reserves: 0 cu m (1 Janu-
ary 2012 est.)
country comparison to the world: 205
Carbon dioxide emissions from consumption
of energy: 3.382 million Mt (2010 est.)
country comparison to the world: 136','c9e1ba3080c1e3a643262329cf785f370e59a0196fbc52db413186019d811652','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('152dc86821e96778531a23cbd2520ef73fac8462b8b7010ae76e281d0555b4a3',2025,'EH','Western Sahara','energy',1715,'Electricity—production: 90 million kWh (2009
est.)
country comparison to the world: 199
Electricity—consumption: 83.7 million kWh
(2009 est.)
country comparison to the world: 199
Electricity—exports: 0 kWh (2010 est.)
country comparison to the world: 148
Electricity—imports: 0 kWh (2010 est.)
country comparison to the world: 149
Electricity—installed generating capacity:
58,000 kW (2009 est.)
country comparison to the world: 179
Eliectricity—from fossil fuels: 100% of total
installed capacity (2009 est.)
country comparison to the world: 45 °
Electricity—from nuclear fuels: 0% of total
installed capacity (2009 est.)
country comparison to the world: 204
Electricity—from hydroelectric plants: 0% of
total installed capacity (2009 est.)
country comparison to the world: 208
Electricity—from other renewable sources: 0%
of total installed capacity (2009 est.)
country comparison to the world: 205
Crude oil—production: 0 bbl/day (2011 est.)
country comparison to the world: 206
Crude oll—exports: 0 bbl/day (2009 est.)
country comparison to the world: 206
Crude oli—imports: 0 bbi/day (2009 est.)
country comparison to the world: 142
Crude oil—proved reserves: 0 bbl (1 January
2012 es)
country comparison to the world: 205
Refined petroleum products—production: 0
bbl/day (2008 est.)
country comparison to the world: 209
Refined petroleum products—consumption:
1,948 bbl/day (2011 est.)
country comparison to the world: 189
Refined petroleum products—exports: 0 bbl/
day (2008 est.)
country comparison to the world: 144
Refined petroleum products—imports: 1,702
bbl/day (2008 est.)
country comparison to the world: 183
Natural gas—production: 0 cu m (2010 est.)
country comparison to the world: 209
Natural gas—consumption: 0 cu m (2010 est.)
country comparison to the world: 209
Natural gas—exports: 0 cu m (2010 est.)
country comparison to the world: 207
Natural gas—imports: 0 cu m (2010 est.)
country comparison to the world: 79
Natural gas—proved reserves: 0 cu m (1 Janu-
ary 2012 est.)
country comparison to the world: 206
Carbon dioxide emissions from consumption
of energy: 314,600 Mr (201G-est.)
country comparison to the world: 186
Electricity—production: 21.33 trillion kWh
(2010 est.)
Electricity—consumption: 19.54 trillion kWh
(2009 est.)
Electricity—exports: 631.4 billion kWh (2010
est.)
Electricity—imports: 696.6 billion kWh (2010
est.)
Electricity—installed generating capacity:
5.144 billion kW (2009 est.)
Electricity—from fossil fuels: 66.6% of total
installed capacity (2009 est.)
Electricity—from nuclear fuels: 7.9% of total
installed capacity (2009 est.)
Electricity—from hydroelectric plants: 18.5%
of total installed capacity (2009 est.)
Electricity—from other renewable sources:
4.9% of total installed capacity (2009 est.)
Crude oil—production: 84.53 million bbl/day
(2011 est.)
Crude oll—exports: 41.01 million bbl/day (2009
est.)
Crude oll—imports: 43.78 million bbl/day (2009
est.)
Crude oil—proved reserves: 1.532 trillion bbl
(1 January 2012 es)
Refined petroleum: products—production:
82.96 million bbl/day (2008 est.)
Refined petroleum products—consumption:
87.63 million bbl/day (2011 est.)
Refined petroleum products—exports: 22.81
million bbl/day (2008 est.)
Refined petroleum products—imports: 21.35
million bbl/day (2008 est.)
Natural gas—production: 3.401 trillion cu m
(2010 est.)
Natural gas—consumption: 3.294 trillion cu m
(2010 est.)
Natural gas—exports: 1.15 trillion cu m (2010
est.) `
Natural gas—imports: 1.448 trillion cu m (2010
est.)
Natural gas—proved reserves: 208.4 trillion
cu m (1 January 2011 es)
Carbon dioxide emissions from consumption
of energy: 31.68 billion Mt (2010 est.)','6195d0815ae68d4081045343522224ed4fd44a3ce07cc4671922e2126b9fb45c','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);

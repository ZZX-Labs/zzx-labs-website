SET NAMES utf8mb4;
CREATE TABLE IF NOT EXISTS worldfactbook_chunks (
  chunk_id CHAR(64) NOT NULL,
  edition_year SMALLINT UNSIGNED NOT NULL,
  entity_code VARCHAR(24) NOT NULL DEFAULT '',
  entity_name VARCHAR(160) NOT NULL DEFAULT '',
  category VARCHAR(96) NOT NULL,
  ordinal INT UNSIGNED NOT NULL,
  content MEDIUMTEXT NOT NULL,
  content_sha256 CHAR(64) NOT NULL,
  source_provider VARCHAR(64) NOT NULL,
  source_identifier VARCHAR(255) NOT NULL,
  source_format VARCHAR(32) NOT NULL,
  source_sha256 CHAR(64) NOT NULL,
  source_url TEXT NOT NULL,
  extractor VARCHAR(64) NOT NULL,
  PRIMARY KEY (chunk_id),
  KEY idx_wfb_year_category (edition_year, category),
  KEY idx_wfb_entity_year (entity_code, edition_year),
  KEY idx_wfb_source_sha (source_sha256)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1ec43e8395c2006db16cbb746835ac4ca071ce118b39a1f058f096098c5efb3c',2025,'AF','Afghanistan','energy',7,'Electricity access:
electrification - total population:
97.7% (2021)
electrification - urban areas:
99.5% (2021)
electrification - rural areas:
97% (2021)
Electricity:
installed generating capacity:
776,000 kW (2020 est.)
consumption:
5.913 billion kWh (2019 est.)
exports:
0 kWh (2019 est.)
imports:
4.912 billion kWh (2019 est.)
transmission/distribution losses:
61.6 million kWh (2019 est.)
comparison rankings:
installed generating capacity 140; transmission/distribution losses 168; imports 40; exports 131; consumption 119
Electricity generation sources:
fossil fuels:
15.9% of total installed capacity (2020 est.)
nuclear:
0% of total installed capacity (2020 est.)
solar:
5.1% of total installed capacity (2020 est.)
wind:
0% of total installed capacity (2020 est.)
hydroelectricity:
79.1% of total installed capacity (2020 est.)
tide and wave:
0% of total installed capacity (2020 est.)
geothermal:
0% of total installed capacity (2020 est.)
biomass and waste:
0% of total installed capacity (2020 est.)
Coal:
production:
2.096 million metric tons (2020 est.)
consumption:
2.096 million metric tons (2020 est.)
exports:
0 metric tons (2020 est.)
imports:
0 metric tons (2020 est.)
proven reserves:
66 million metric tons (2019 est.)
Petroleum:
total petroleum production:
0 bbl/day (2021 est.)
refined petroleum consumption:
24,300 bbl/day (2019 est.)
crude oil and lease condensate exports:
0 bbl/day (2018 est.)
crude oil and lease condensate imports:
0 bbl/day (2018 est.)
crude oil estimated reserves:
0 barrels (2021 est.)
Refined petroleum products - production:
0 bbl/day (2015 est.)
comparison ranking:
130
Refined petroleum products - exports:
0 bbl/day (2015 est.)
comparison ranking:
197
Refined petroleum products - imports:
34,210 bbl/day (2015 est.)
comparison ranking:
97
Natural gas:
production:
80.193 million cubic meters (2020 est.)
consumption:
80.193 million cubic meters (2020 est.)
exports:
0 cubic meters (2021 est.)
imports:
0 cubic meters (2021 est.)
proven reserves:
49.554 billion cubic meters (2021 est.)
Carbon dioxide emissions:
7.893 million metric tonnes of CO2 (2019 est.)
from coal and metallurgical coke:
4.158 million metric tonnes of CO2 (2019 est.)
from petroleum and other liquids:
3.468 million metric tonnes of CO2 (2019 est.)
from consumed natural gas:
267,000 metric tonnes of CO2 (2019 est.)
comparison ranking:
total emissions 117
Energy consumption per capita:
3.227 million Btu/person (2019 est.)
comparison ranking:
180','9f5f2997ef0bc5bab5bc43d714f77e9a92a2f4177ff1a21348087ed5186770e5','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('933c1b59733cf9dbd041f7a9cd4b70dbf8d0cba351e23afd090d1b437cb37978',2025,'AL','Albania','energy',28,'Electricity access:
electrification - total population:
100% (2020)
Electricity:
installed generating capacity:
2.531 million kW (2020 est.)
consumption:
6,527,980,000 kWh (2019 est.)
exports:
963 million kWh (2020 est.)
imports:
3.239 billion kWh (2020 est.)
transmission/distribution losses:
1.054 billion kWh (2019 est.)
comparison rankings:
imports 51; exports 64; installed generating capacity 113; transmission/distribution losses 111; consumption 112
Electricity generation sources:
fossil fuels:
0% of total installed capacity (2020 est.)
nuclear:
0% of total installed capacity (2020 est.)
solar:
0.6% of total installed capacity (2020 est.)
wind:
0% of total installed capacity (2020 est.)
hydroelectricity:
99.4% of total installed capacity (2020 est.)
tide and wave:
0% of total installed capacity (2020 est.)
geothermal:
0% of total installed capacity (2020 est.)
biomass and waste:
0% of total installed capacity (2020 est.)
Coal:
production:
9,000 metric tons (2020 est.)
consumption:
119,000 metric tons (2020 est.)
exports:
0 metric tons (2020 est.)
imports:
110,000 metric tons (2020 est.)
proven reserves:
522 million metric tons (2019 est.)
Petroleum:
total petroleum production:
16,100 bbl/day (2021 est.)
refined petroleum consumption:
26,400 bbl/day (2019 est.)
crude oil and lease condensate exports:
10,500 bbl/day (2018 est.)
crude oil and lease condensate imports:
0 bbl/day (2018 est.)
crude oil estimated reserves:
150 million barrels (2021 est.)
Refined petroleum products - production:
5,638 bbl/day (2015 est.)
comparison ranking:
103
Refined petroleum products - exports:
3,250 bbl/day (2015 est.)
comparison ranking:
98
Refined petroleum products - imports:
26,660 bbl/day (2015 est.)
comparison ranking:
103
Natural gas:
production:
42.05 million cubic meters (2019 est.)
consumption:
42.05 million cubic meters (2019 est.)
exports:
0 cubic meters (2021 est.)
imports:
0 cubic meters (2021 est.)
proven reserves:
5.692 billion cubic meters (2021 est.)
Carbon dioxide emissions:
3.794 million metric tonnes of CO2 (2019 est.)
from coal and metallurgical coke:
235,000 metric tonnes of CO2 (2019 est.)
from petroleum and other liquids:
3.482 million metric tonnes of CO2 (2019 est.)
from consumed natural gas:
78,000 metric tonnes of CO2 (2019 est.)
comparison ranking:
total emissions 144
Energy consumption per capita:
38.442 million Btu/person (2019 est.)
comparison ranking:
110','ea1a30d55fee4a636ae6d255d9844aa148355e726b0e5bdccb44f554df7dd5fb','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0b45844d311647cb2f13b2a779326ce4b042ff7a442a015f118618f246045275',2025,'DZ','Algeria','energy',40,'Electricity access:
electrification - total population:
99.8% (2021)
electrification - urban areas:
99.6% (2021)
electrification - rural areas:
99.2% (2021)
Electricity:
installed generating capacity:
21.694 million kW (2020 est.)
consumption:
66.646 billion kWh (2019 est.)
exports:
673 million kWh (2019 est.)
imports:
531 million kWh (2019 est.)
transmission/distribution losses:
9.897 billion kWh (2019 est.)
comparison rankings:
installed generating capacity 44; transmission/distribution losses 33; imports 85; exports 68; consumption 43
Electricity generation sources:
fossil fuels:
98.9% of total installed capacity (2020 est.)
nuclear:
0% of total installed capacity (2020 est.)
solar:
0.9% of total installed capacity (2020 est.)
wind:
0% of total installed capacity (2020 est.)
hydroelectricity:
0.1% of total installed capacity (2020 est.)
tide and wave:
0% of total installed capacity (2020 est.)
geothermal:
0% of total installed capacity (2020 est.)
biomass and waste:
0% of total installed capacity (2020 est.)
Coal:
production:
0 metric tons (2020 est.)
consumption:
85,000 metric tons (2020 est.)
exports:
0 metric tons (2020 est.)
imports:
85,000 metric tons (2020 est.)
proven reserves:
59 million metric tons (2019 est.)
Petroleum:
total petroleum production:
1,414,800 bbl/day (2021 est.)
refined petroleum consumption:
450,500 bbl/day (2019 est.)
crude oil and lease condensate exports:
633,500 bbl/day (2018 est.)
crude oil and lease condensate imports:
4,100 bbl/day (2018 est.)
crude oil estimated reserves:
12.2 billion barrels (2021 est.)
Refined petroleum products - production:
627,900 bbl/day (2015 est.)
comparison ranking:
29
Refined petroleum products - exports:
578,800 bbl/day (2015 est.)
comparison ranking:
15
Refined petroleum products - imports:
82,930 bbl/day (2015 est.)
comparison ranking:
61
Natural gas:
production:
87,853,976,000 cubic meters (2019 est.)
consumption:
46,945,035,000 cubic meters (2019 est.)
exports:
42,667,386,000 cubic meters (2019 est.)
imports:
0 cubic meters (2021 est.)
proven reserves:
4,503,900,000,000 cubic meters (2021 est.)
Carbon dioxide emissions:
151.633 million metric tonnes of CO2 (2019 est.)
from coal and metallurgical coke:
352,000 metric tonnes of CO2 (2019 est.)
from petroleum and other liquids:
57.867 million metric tonnes of CO2 (2019 est.)
from consumed natural gas:
93.414 million metric tonnes of CO2 (2019 est.)
comparison ranking:
total emissions 34
Energy consumption per capita:
61.433 million Btu/person (2019 est.)
comparison ranking:
91','1aecee936cd1635e818e5ffe29c05c11bfba4c94870b4670123dcbea18240db0','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('92afcfc2554759c7aec5cc3c0e5100599edf0f0c90a00edd10b2be5e5fef2578',2025,'AS','American Samoa','energy',53,'Electricity access:
electrification - total population:
59% (2020)
electrification - urban areas:
60% (2020)
electrification - rural areas:
45% (2020)
Electricity:
installed generating capacity:
47,000 kW (2020 est.)
consumption:
151 million kWh (2019 est.)
exports:
0 kWh (2020 est.)
imports:
0 kWh (2020 est.)
transmission/distribution losses:
12 million kWh (2019 est.)
comparison rankings:
imports 202; exports 202; installed generating capacity 193; transmission/distribution losses 192; consumption 189
Electricity generation sources:
fossil fuels:
100% of total installed capacity (2020 est.)
Petroleum:
total petroleum production:
0 bbl/day (2021 est.)
refined petroleum consumption:
2,300 bbl/day (2019 est.)
crude oil and lease condensate exports:
0 bbl/day (2018 est.)
crude oil and lease condensate imports:
0 bbl/day (2018 est.)
crude oil estimated reserves:
0 barrels (2021 est.)
Refined petroleum products - production:
0 bbl/day (2015 est.)
comparison ranking:
194
Refined petroleum products - exports:
0 bbl/day (2015 est.)
comparison ranking:
153
Refined petroleum products - imports:
2,346 bbl/day (2015 est.)
comparison ranking:
188
Carbon dioxide emissions:
355,000 metric tonnes of CO2 (2019 est.)
from petroleum and other liquids:
355,000 metric tonnes of CO2 (2019 est.)
Energy consumption per capita:
88.796 million Btu/person (2019 est.)
comparison ranking:
65','f80369b45fde71101a0e560d94381bafbe5a93a60ef6908a9cca650e0729aed1','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('774604209465d8c3fd88aefe59b58141ef07e947a3388e9ced4ecbbfd3855bc7',2025,'AD','Andorra','energy',64,'Electricity access:
electrification - total population:
100% (2021)
Refined petroleum products - production:
0 bbl/day (2016)
comparison ranking:
115','eb5d2aec1c922c22ae491be7b478c6d52c3e2215edd68796ae5947744de60855','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d75ecf20059e62cdd310424c41e407e2bd29f5893c9a7720b0d5f7045d3a2ee0',2025,'AO','Angola','energy',7,'Electricity access:
population without electricity:
18 million (2020)
electrification - total population:
48.2% (2021)
electrification - urban areas:
74.9% (2021)
electrification - rural areas:
7.3% (2018)
Electricity:
installed generating capacity:
7.344 million kW (2020 est.)
consumption:
11.815 billion kWh (2019 est.)
exports:
0 kWh (2019 est.)
imports:
0 kWh (2019 est.)
transmission/distribution losses:
1.741 billion kWh (2019 est.)
comparison rankings installed generating capacity 76; transmission/distribution losses 92; imports 141; exports 124; consumption 93
Electricity generation sources:
fossil fuels:
28.4% of total installed capacity (2020 est.)
nuclear:
0% of total installed capacity (2020 est.)
solar:
0.1% of total installed capacity (2020 est.)
wind:
0% of total installed capacity (2020 est.)
hydroelectricity:
70.1% of total installed capacity (2020 est.)
tide and wave:
0% of total installed capacity (2020 est.)
geothermal:
0% of total installed capacity (2020 est.)
biomass and waste:
1.4% of total installed capacity (2020 est.)
Coal:
production:
0 metric tons (2020 est.)
consumption:
0 metric tons (2020 est.)
exports:
0 metric tons (2020 est.)
imports:
0 metric tons (2020 est.)
proven reserves:
0 metric tons (2019 est.)
Petroleum:
total petroleum production:
1,197,600 bbl/day (2021 est.)
refined petroleum consumption:
133,400 bbl/day (2019 est.)
crude oil and lease condensate exports:
1,367,400 bbl/day (2018 est.)
crude oil and lease condensate imports:
0 bbl/day (2018 est.)
crude oil estimated reserves:
7.783 billion barrels (2021 est.)
Refined petroleum products - production:
53,480 bbl/day (2015 est.)
comparison ranking:
80
Refined petroleum products - exports:
30,340 bbl/day (2015 est.)
comparison ranking:
62
Refined petroleum products - imports:
111,600 bbl/day (2015 est.)
comparison ranking:
50
Natural gas:
production:
6,767,715,000 cubic meters (2019 est.)
consumption:
860.887 million cubic meters (2019 est.)
exports:
5,877,945,000 cubic meters (2019 est.)
imports:
0 cubic meters (2021 est.)
proven reserves:
343.001 billion cubic meters (2021 est.)
Carbon dioxide emissions:
19.362 million metric tonnes of CO2 (2019 est.)
from coal and metallurgical coke:
0 metric tonnes of CO2 (2019 est.)
from petroleum and other liquids:
17.673 million metric tonnes of CO2 (2019 est.)
from consumed natural gas:
1.689 million metric tonnes of CO2 (2019 est.)
comparison ranking:
total emissions 84
Energy consumption per capita:
11.693 million Btu/person (2019 est.)
comparison ranking:
147','e1d3fa45797e07d675aed08c3cba6f848da8c696dad6c80f892c6d8ca1db4cb4','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3426b7e3e74ed41877ff6fda5fea387c36dbf617dd67195aba0d048f9e4ee08c',2025,'AI','Anguilla','energy',19,'Electricity access:
electrification - total population:
100% (2020)','f19c1aa7203d6ea427235fb7e96fbf45b715f77b838592e0afc6ec8249a29ce0','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7dd40f8f2b4759e873b37503a12e72708fd4f7db9f0dd68c3b8827e12799f8dc',2025,'AQ','Antarctica','energy',29,'Electricity:
installed generating capacity:
0 kW (2020 est.)
transmission/distribution losses:
0 kWh (2019 est.)
comparison rankings:
imports 133; exports 116; installed generating capacity 212; transmission/distribution losses 211; consumption 210
Petroleum:
total petroleum production:
0 bbl/day (2021 est.)
refined petroleum consumption:
100 bbl/day (2019 est.)
Carbon dioxide emissions:
28,000 metric tonnes of CO2 (2019 est.)
from petroleum and other liquids:
28,000 metric tonnes of CO2 (2019 est.)
comparison ranking:
total emissions 214
Energy consumption per capita:
0 Btu/person (2019 est.)
comparison ranking:
206','fec411dee4094c262e8220489f10796cb34c418208516e423d289ac2b408137d','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('78e9837c6be421cc0c583116645d178d3cde9ebe9365868e1a0c2d4a9d51fdd5',2025,'AG','Antigua and Barbuda','energy',40,'Electricity access:
electrification - total population:
100% (2021)
Electricity:
installed generating capacity:
117,000 kW (2020 est.)
consumption:
278 million kWh (2019 est.)
exports:
0 kWh (2020 est.)
imports:
0 kWh (2020 est.)
transmission/distribution losses:
65 million kWh (2019 est.)
comparison rankings:
imports 149; exports 137; installed generating capacity 182; transmission/distribution losses 166; consumption 182
Electricity generation sources:
fossil fuels:
95.4% of total installed capacity (2020 est.)
solar:
4.6% of total installed capacity (2020 est.)
Petroleum:
total petroleum production:
0 bbl/day (2021 est.)
refined petroleum consumption:
5,000 bbl/day (2019 est.)
Refined petroleum products - production:
0 bbl/day (2015 est.)
comparison ranking:
180
Refined petroleum products - exports:
91 bbl/day (2015 est.)
comparison ranking:
119
Refined petroleum products - imports:
5,065 bbl/day (2015 est.)
comparison ranking:
172
Carbon dioxide emissions:
729,000 metric tonnes of CO2 (2019 est.)
from petroleum and other liquids:
729,000 metric tonnes of CO2 (2019 est.)
comparison ranking:
total emissions 182
Energy consumption per capita:
107.154 million Btu/person (2019 est.)
comparison ranking:
52','ccc5d849bfb9db73689b93edbfdadd51932625a5f366565e63e38f5c8b28a1dc','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('219114d4e6e3f2517b700ab9b25775ba86b17f35b2bb29f9c473d4eed34d4f8e',2025,'AR','Argentina','energy',57,'Electricity access:
electrification - total population:
100% (2021)
Electricity:
installed generating capacity:
44.731 million kW (2020 est.)
consumption:
121,563,940,000 kWh (2020 est.)
exports:
261 million kWh (2020 est.)
imports:
7.802 billion kWh (2020 est.)
transmission/distribution losses:
20.74 billion kWh (2020 est.)
comparison rankings:
transmission/distribution losses 21; imports 30; exports 83; consumption 31; installed generating capacity 27
Electricity generation sources:
fossil fuels:
65.8% of total installed capacity (2020 est.)
nuclear:
7.3% of total installed capacity (2020 est.)
solar:
1% of total installed capacity (2020 est.)
wind:
6.8% of total installed capacity (2020 est.)
hydroelectricity:
17.6% of total installed capacity (2020 est.)
tide and wave:
0% of total installed capacity (2020 est.)
geothermal:
0% of total installed capacity (2020 est.)
biomass and waste:
1.5% of total installed capacity (2020 est.)
Nuclear energy: Number of operational nuclear reactors:
3 (2023)
Number of nuclear reactors under construction:
1
Net capacity of operational nuclear reactors:
1.64GW (2023)
Percent of total electricity production:
7.2% (2021)
Percent of total energy produced:
3.6% (2021)
Number of nuclear reactors permanently shut down:
0 Coal
:
production:
829,000 metric tons (2020 est.)
consumption:
1.55 million metric tons (2020 est.)
exports:
4,000 metric tons (2020 est.)
imports:
990,000 metric tons (2020 est.)
proven reserves:
500 million metric tons (2019 est.)
Petroleum:
total petroleum production:
690,200 bbl/day (2021 est.)
refined petroleum consumption:
680,000 bbl/day (2019 est.)
crude oil and lease condensate exports:
59,100 bbl/day (2018 est.)
crude oil and lease condensate imports:
11,400 bbl/day (2018 est.)
crude oil estimated reserves:
2,482,700,000 barrels (2021 est.)
Refined petroleum products - production:
669,800 bbl/day (2015 est.)
comparison ranking:
26
Refined petroleum products - exports:
58,360 bbl/day (2015 est.)
comparison ranking:
51
Refined petroleum products - imports:
121,400 bbl/day (2015 est.)
comparison ranking:
49
Natural gas:
production:
41,194,148,000 cubic meters (2020 est.)
consumption:
49,476,585,000 cubic meters (2019 est.)
exports:
691.241 million cubic meters (2019 est.)
imports:
6,865,323,000 cubic meters (2019 est.)
proven reserves:
396.464 billion cubic meters (2021 est.)
Carbon dioxide emissions:
193.205 million metric tonnes of CO2 (2019 est.)
from coal and metallurgical coke:
2.122 million metric tonnes of CO2 (2019 est.)
from petroleum and other liquids:
94.208 million metric tonnes of CO2 (2019 est.)
from consumed natural gas:
96.875 million metric tonnes of CO2 (2019 est.)
comparison ranking:
total emissions 32
Energy consumption per capita:
79.083 million Btu/person (2019 est.)
comparison ranking:
77','07d1c5ed6ac596db1f24558239a7e84a1aecc2f3f6524009f1ac0f5a7b248cca','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9b03a0432ffb88990c2bc057abc033c603cc6185ca2f8b5083a97741d6622511',2025,'AM','Armenia','energy',70,'Electricity access:
electrification - total population:
100% (2021)
Electricity:
installed generating capacity:
3.633 million kW (2020 est.)
consumption:
5,758,470,000 kWh (2019 est.)
exports:
1.251 billion kWh (2020 est.)
imports:
320 million kWh (2020 est.)
transmission/distribution losses:
548 million kWh (2019 est.)
comparison rankings:
imports 95; exports 56; installed generating capacity 101; transmission/distribution losses 128; consumption 120
Electricity generation sources:
fossil fuels:
40.6% of total installed capacity (2020 est.)
nuclear:
34.8% of total installed capacity (2020 est.)
solar:
0.3% of total installed capacity (2020 est.)
wind:
0% of total installed capacity (2020 est.)
hydroelectricity:
24.3% of total installed capacity (2020 est.)
tide and wave:
0% of total installed capacity (2020 est.)
geothermal:
0% of total installed capacity (2020 est.)
biomass and waste:
0% of total installed capacity (2020 est.)
Nuclear energy: Number of operational nuclear reactors:
1 (2023)
Number of nuclear reactors under construction:
0
Net capacity of operational nuclear reactors:
0.42GW (2023)
Percent of total electricity production:
25.3% (2021)
Percent of total energy produced:
52.3% (2021)
Number of nuclear reactors permanently shut down:
0
Coal:
production:
0 metric tons (2020 est.)
consumption:
12,000 metric tons (2020 est.)
exports:
0 metric tons (2020 est.)
imports:
12,000 metric tons (2020 est.)
proven reserves:
163 million metric tons (2019 est.)
Petroleum:
total petroleum production:
0 bbl/day (2021 est.)
refined petroleum consumption:
10,900 bbl/day (2019 est.)
crude oil and lease condensate exports:
0 bbl/day (2018 est.)
crude oil and lease condensate imports:
0 bbl/day (2018 est.)
crude oil estimated reserves:
0 barrels (2021 est.)
Refined petroleum products - production:
0 bbl/day (2015 est.)
comparison ranking:
193
Refined petroleum products - exports:
0 bbl/day (2015 est.)
comparison ranking:
167
Refined petroleum products - imports:
7,145 bbl/day (2015 est.)
comparison ranking:
158
Natural gas:
production:
0 cubic meters (2021 est.)
consumption:
2,537,497,000 cubic meters (2019 est.)
exports:
0 cubic meters (2021 est.)
imports:
2,514,220,000 cubic meters (2019 est.)
proven reserves:
0 cubic meters (2021 est.)
Carbon dioxide emissions:
6.354 million metric tonnes of CO2 (2019 est.)
from coal and metallurgical coke:
12,000 metric tonnes of CO2 (2019 est.)
from petroleum and other liquids:
1.364 million metric tonnes of CO2 (2019 est.)
from consumed natural gas:
4.978 million metric tonnes of CO2 (2019 est.)
comparison ranking:
total emissions 130
Energy consumption per capita:
53.019 million Btu/person (2019 est.)
comparison ranking:
98','4974a8bf969e3931fb2507336f07f373ff528efd75c6526fae5ec7b0be8f5504','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9fca59c7283ae738877c9b2a8696f640e4257f4b1cfa88a6af6c4050d75c5c95',2025,'AW','Aruba','energy',7,'Electricity access:
electrification - total population:
100% (2021)
Electricity:
installed generating capacity:
296,000 kW (2020 est.)
consumption:
909.442 million kWh (2019 est.)
exports:
0 kWh (2020 est.)
imports:
0 kWh (2020 est.)
transmission/distribution losses:
10.27 million kWh (2019 est.)
comparison rankings:
imports 169; exports 161; installed generating capacity 161; transmission/distribution losses 196; consumption 163
Electricity generation sources:
fossil fuels:
83.3% of total installed capacity (2020 est.)
nuclear:
0% of total installed capacity (2020 est.)
solar:
1.2% of total installed capacity (2020 est.)
wind:
15.4% of total installed capacity (2020 est.)
Petroleum:
total petroleum production:
0 bbl/day (2021 est.)
refined petroleum consumption:
8,100 bbl/day (2019 est.)
Refined petroleum products - imports:
7,891 bbl/day (2015 est.)
comparison ranking:
153
Carbon dioxide emissions:
1.254 million metric tonnes of CO2 (2019 est.)
from petroleum and other liquids:
1.254 million metric tonnes of CO2 (2019 est.)
comparison ranking:
total emissions 168
Energy consumption per capita:
174.629 million Btu/person (2019 est.)
comparison ranking:
26','32c413d44dc1a24e1afa58724181c37b514a79967cb61f930e4e0de1e3cc338e','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('627dbe01a12a842bd609363b29231a57bab7306fc0edba281ffd66c9f40220fa',2025,'AU','Australia','energy',33,'Electricity access:
electrification - total population:
100% (2021)
Electricity:
installed generating capacity:
82.517 million kW (2020 est.)
consumption:
237,388,272,000 kWh (2019 est.)
exports:
0 kWh (2020 est.)
imports:
0 kWh (2020 est.)
transmission/distribution losses:
12,607,778,000 kWh (2019 est.)
comparison rankings:
imports 151; exports 139; installed generating capacity 16; transmission/distribution losses 28; consumption 19
Electricity generation sources:
fossil fuels:
75.4% of total installed capacity (2020 est.)
nuclear:
0% of total installed capacity (2020 est.)
solar:
8.6% of total installed capacity (2020 est.)
wind:
8.4% of total installed capacity (2020 est.)
hydroelectricity:
6.2% of total installed capacity (2020 est.)
tide and wave:
0% of total installed capacity (2020 est.)
geothermal:
0% of total installed capacity (2020 est.)
biomass and waste:
1.4% of total installed capacity (2020 est.)
Coal:
production:
504.051 million metric tons (2020 est.)
consumption:
99.048 million metric tons (2020 est.)
exports:
390.808 million metric tons (2020 est.)
imports:
583,000 metric tons (2020 est.)
proven reserves:
149.079 billion metric tons (2019 est.)
Petroleum:
total petroleum production:
442,500 bbl/day (2021 est.)
refined petroleum consumption:
1,174,100 bbl/day (2019 est.)
crude oil and lease condensate exports:
197,700 bbl/day (2018 est.)
crude oil and lease condensate imports:
356,900 bbl/day (2018 est.)
crude oil estimated reserves:
2.446 billion barrels (2021 est.)
Refined petroleum products - production:
462,500 bbl/day (2017 est.)
comparison ranking:
35
Refined petroleum products - exports:
64,120 bbl/day (2017 est.)
comparison ranking:
48
Refined petroleum products - imports:
619,600 bbl/day (2017 est.)
comparison ranking:
12
Natural gas:
production:
142,104,321,000 cubic meters (2020 est.)
consumption:
41,905,381,000 cubic meters (2020 est.)
exports:
101,766,728,000 cubic meters (2020 est.)
imports:
6,295,646,000 cubic meters (2020 est.)
proven reserves:
3,228,115,000,000 cubic meters (2021 est.)
note:
Australia was the largest exporter of LNG in the world in 2020.
Carbon dioxide emissions:
417.87 million metric tonnes of CO2 (2019 est.)
from coal and metallurgical coke:
162.26 million metric tonnes of CO2 (2019 est.)
from petroleum and other liquids:
158.668 million metric tonnes of CO2 (2019 est.)
from consumed natural gas:
96.942 million metric tonnes of CO2 (2019 est.)
comparison ranking:
total emissions 15
Energy consumption per capita:
241.004 million Btu/person (2019 est.)
comparison ranking:
16','97ff56cd9bd1d236b98fa38cc182bd820f8610308148c00b2daf57251e9b607a','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('888f277d0dcacd1cc0658c4a6a1ef3e1f5358839baf7a5cae8648998afa997ac',2025,'AT','Austria','energy',46,'Electricity access:
electrification - total population:
100% (2021)
Electricity:
installed generating capacity:
28.376 million kW (2020 est.)
consumption:
69,905,200,000 kWh (2020 est.)
exports:
22,918,265,000 kWh (2020 est.)
imports:
24.522 billion kWh (2020 est.)
transmission/distribution losses:
3.192 billion kWh (2020 est.)
comparison rankings:
transmission/distribution losses 64; imports 7; exports 10; consumption 41; installed generating capacity 36
Electricity generation sources:
fossil fuels:
17.4% of total installed capacity (2020 est.)
nuclear:
0% of total installed capacity (2020 est.)
solar:
2.8% of total installed capacity (2020 est.)
wind:
9.4% of total installed capacity (2020 est.)
hydroelectricity:
62.9% of total installed capacity (2020 est.)
tide and wave:
0% of total installed capacity (2020 est.)
geothermal:
0% of total installed capacity (2020 est.)
biomass and waste:
7.4% of total installed capacity (2020 est.)
Coal:
production:
1.327 million metric tons (2020 est.)
consumption:
4.899 million metric tons (2020 est.)
exports:
1,000 metric tons (2020 est.)
imports:
3.667 million metric tons (2020 est.)
proven reserves:
0 metric tons (2019 est.)
Petroleum:
total petroleum production:
20,100 bbl/day (2021 est.)
refined petroleum consumption:
278,700 bbl/day (2019 est.)
crude oil and lease condensate exports:
0 bbl/day (2018 est.)
crude oil and lease condensate imports:
168,300 bbl/day (2018 est.)
crude oil estimated reserves:
35.2 million barrels (2021 est.)
Refined petroleum products - production:
186,500 bbl/day (2017 est.)
comparison ranking:
54
Refined petroleum products - exports:
49,960 bbl/day (2017 est.)
comparison ranking:
55
Refined petroleum products - imports:
135,500 bbl/day (2017 est.)
comparison ranking:
42
Natural gas:
production:
924.5 million cubic meters (2019 est.)
consumption:
9.208 billion cubic meters (2019 est.)
exports:
2.8 billion cubic meters (2019 est.)
imports:
14.11 billion cubic meters (2019 est.)
proven reserves:
5.04 billion cubic meters (2021 est.)
Carbon dioxide emissions:
65.54 million metric tonnes of CO2 (2019 est.)
from coal and metallurgical coke:
10.508 million metric tonnes of CO2 (2019 est.)
from petroleum and other liquids:
37.336 million metric tonnes of CO2 (2019 est.)
from consumed natural gas:
17.695 million metric tonnes of CO2 (2019 est.)
comparison ranking:
total emissions 52
Energy consumption per capita:
171.299 million Btu/person (2019 est.)
comparison ranking:
28','31d2b05f9ce026f9d8f9c2e02e15e7a6e2207941c2add42021779ff15883c813','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ee5b577d5d530ab79817529d71b2f0e6bb00f4a0d1bb4767daddb014600bb9e8',2025,'AZ','Azerbaijan','energy',59,'Electricity access:
electrification - total population:
100% (2021)
Electricity:
installed generating capacity:
7.677 million kW (2020 est.)
consumption:
21.027 billion kWh (2019 est.)
exports:
1.491 billion kWh (2020 est.)
imports:
137 million kWh (2020 est.)
transmission/distribution losses:
2.226 billion kWh (2019 est.)
comparison rankings:
imports 105; exports 55; installed generating capacity 74; transmission/distribution losses 84; consumption 71
Electricity generation sources:
fossil fuels:
94.2% of total installed capacity (2020 est.)
nuclear:
0% of total installed capacity (2020 est.)
solar:
0.2% of total installed capacity (2020 est.)
wind:
0.4% of total installed capacity (2020 est.)
hydroelectricity:
4.4% of total installed capacity (2020 est.)
tide and wave:
0% of total installed capacity (2020 est.)
geothermal:
0% of total installed capacity (2020 est.)
biomass and waste:
0.8% of total installed capacity (2020 est.)
Coal:
production:
0 metric tons (2020 est.)
consumption:
19,000 metric tons (2020 est.)
exports:
0 metric tons (2020 est.)
imports:
19,000 metric tons (2020 est.)
proven reserves:
0 metric tons (2019 est.)
Petroleum:
total petroleum production:
711,700 bbl/day (2021 est.)
refined petroleum consumption:
107,500 bbl/day (2019 est.)
crude oil and lease condensate exports:
679,900 bbl/day (2018 est.)
crude oil and lease condensate imports:
0 bbl/day (2018 est.)
crude oil estimated reserves:
7 billion barrels (2021 est.)
Refined petroleum products - production:
138,900 bbl/day (2015 est.)
comparison ranking:
61
Refined petroleum products - exports:
46,480 bbl/day (2015 est.)
comparison ranking:
57
Refined petroleum products - imports:
5,576 bbl/day (2015 est.)
comparison ranking:
168
Natural gas:
production:
23.075 billion cubic meters (2019 est.)
consumption:
11.468 billion cubic meters (2019 est.)
exports:
11.586 billion cubic meters (2019 est.)
imports:
1.233 billion cubic meters (2019 est.)
proven reserves:
1.699 trillion cubic meters (2021 est.)
Carbon dioxide emissions:
35.389 million metric tonnes of CO2 (2019 est.)
from coal and metallurgical coke:
29,000 metric tonnes of CO2 (2019 est.)
from petroleum and other liquids:
12.863 million metric tonnes of CO2 (2019 est.)
from consumed natural gas:
22.497 million metric tonnes of CO2 (2019 est.)
comparison ranking:
total emissions 72
Energy consumption per capita:
64.416 million Btu/person (2019 est.)
comparison ranking:
86','603c4f54f3db91fdfa1ce15b44f8c6631fee346d8d37605b5822fcbac89f7ac2','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d913a63fdaa50b7319bec508b22c2c731689178c223ddb7cf2b2d5bab25c6821',2025,'BH','Bahrain','energy',9,'Electricity access:
electrification - total population:
100% (2021)
Electricity:
installed generating capacity:
6.982 million kW (2020 est.)
consumption:
31,038,250,000 kWh (2019 est.)
exports:
447 million kWh (2019 est.)
imports:
652 million kWh (2019 est.)
transmission/distribution losses:
611 million kWh (2019 est.)
comparison rankings:
installed generating capacity 79; transmission/distribution losses 125; imports 80; exports 76; consumption 62
Electricity generation sources:
fossil fuels:
100% of total installed capacity (2020 est.)
Petroleum:
total petroleum production:
185,300 bbl/day (2021 est.)
refined petroleum consumption:
73,200 bbl/day (2019 est.)
crude oil and lease condensate exports:
0 bbl/day (2018 est.)
crude oil and lease condensate imports:
228,800 bbl/day (2018 est.)
crude oil estimated reserves:
186.5 million barrels (2021 est.)
Refined petroleum products - production:
274,500 bbl/day (2015 est.)
comparison ranking:
45
Refined petroleum products - exports:
245,300 bbl/day (2015 est.)
comparison ranking:
30
Refined petroleum products - imports:
14,530 bbl/day (2015 est.)
comparison ranking:
136
Natural gas:
production:
18,271,840,000 cubic meters (2019 est.)
consumption:
18,251,140,000 cubic meters (2019 est.)
exports:
0 cubic meters (2021 est.)
imports:
0 cubic meters (2021 est.)
proven reserves:
81.382 billion cubic meters (2021 est.)
Carbon dioxide emissions:
43.112 million metric tonnes of CO2 (2019 est.)
from coal and metallurgical coke:
0 metric tonnes of CO2 (2019 est.)
from petroleum and other liquids:
7.308 million metric tonnes of CO2 (2019 est.)
from consumed natural gas:
35.804 million metric tonnes of CO2 (2019 est.)
comparison ranking:
total emissions 61
Energy consumption per capita:
547.976 million Btu/person (2019 est.)
comparison ranking:
3','65fb3391c7770c6afd6f5bfe053105aefa4a3f38676a78cb1fbe0367af3a2f4b','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b3c193da3ff270d10dac796dca8ae1d03c2f0f13ebdc660f8ffe8b69e64963dc',2025,'BD','Bangladesh','energy',22,'Electricity access:
population without electricity:
11 million (2020)
electrification - total population:
98.9% (2021)
electrification - urban areas:
99.7% (2021)
electrification - rural areas:
98.5% (2021)
Electricity:
installed generating capacity:
18.461 million kW (2020 est.)
consumption:
76,849,877,000 kWh (2019 est.)
exports:
0 kWh (2019 est.)
imports:
6.786 billion kWh (2019 est.)
transmission/distribution losses:
9.537 billion kWh (2019 est.)
comparison rankings:
installed generating capacity 51; transmission/distribution losses 35; imports 34; exports 201; consumption 39
Electricity generation sources:
fossil fuels:
98.6% of total installed capacity (2020 est.)
solar:
0.6% of total installed capacity (2020 est.)
hydroelectricity:
0.8% of total installed capacity (2020 est.)
Nuclear energy: Number of operational nuclear reactors:
0
Number of nuclear reactors under construction:
2 (2023)
Net capacity of operational nuclear reactors:
0 GW
Percent of total electricity production:
0%
Percent of total energy produced:
0%
Number of nuclear reactors permanently shut down:
0
Coal:
production:
1.016 million metric tons (2020 est.)
consumption:
9.345 million metric tons (2020 est.)
exports:
0 metric tons (2020 est.)
imports:
8.329 million metric tons (2020 est.)
proven reserves:
293 million metric tons (2019 est.)
Petroleum:
total petroleum production:
13,500 bbl/day (2021 est.)
refined petroleum consumption:
122,500 bbl/day (2019 est.)
crude oil and lease condensate exports:
0 bbl/day (2018 est.)
crude oil and lease condensate imports:
21,600 bbl/day (2018 est.)
crude oil estimated reserves:
28 million barrels (2021 est.)
Refined petroleum products - production:
26,280 bbl/day (2015 est.)
comparison ranking:
86
Refined petroleum products - exports:
901 bbl/day (2015 est.)
comparison ranking:
108
Refined petroleum products - imports:
81,570 bbl/day (2015 est.)
comparison ranking:
63
Natural gas:
production:
28,629,927,000 cubic meters (2019 est.)
consumption:
31,268,968,000 cubic meters (2019 est.)
exports:
0 cubic meters (2021 est.)
imports:
2,639,041,000 cubic meters (2019 est.)
proven reserves:
126.293 billion cubic meters (2021 est.)
Carbon dioxide emissions:
96.18 million metric tonnes of CO2 (2019 est.)
from coal and metallurgical coke:
16.538 million metric tonnes of CO2 (2019 est.)
from petroleum and other liquids:
18.535 million metric tonnes of CO2 (2019 est.)
from consumed natural gas:
61.107 million metric tonnes of CO2 (2019 est.)
comparison ranking:
total emissions 44
Energy consumption per capita:
9.917 million Btu/person (2019 est.)
comparison ranking:
155','43c9a63688d275b752c8c2a64c336baab140ce1f4902a8ed7603ea0a6eb7515f','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('79517ea115d62751113b85eb907477b5f2bea29cc3f601cfc081dca82739952f',2025,'BB','Barbados','energy',35,'Electricity access:
electrification - total population:
100% (2021)
Electricity:
installed generating capacity:
311,000 kW (2020 est.)
consumption:
1 billion kWh (2019 est.)
exports:
0 kWh (2019 est.)
imports:
0 kWh (2019 est.)
transmission/distribution losses:
20 million kWh (2019 est.)
comparison rankings:
installed generating capacity 160; transmission/distribution losses 185; imports 174; exports 166;
consumption:
160
Electricity generation sources:
fossil fuels:
95.9% of total installed capacity (2020 est.)
solar:
4.1% of total installed capacity (2020 est.)
Petroleum:
total petroleum production:
1,000 bbl/day (2021 est.)
refined petroleum consumption:
10,800 bbl/day (2019 est.)
crude oil and lease condensate exports:
700 bbl/day (2018 est.)
crude oil and lease condensate imports:
0 bbl/day (2018 est.)
crude oil estimated reserves:
2 million barrels (2021 est.)
Refined petroleum products - production:
0 bbl/day (2015 est.)
comparison ranking:
175
Refined petroleum products - exports:
0 bbl/day (2015 est.)
comparison ranking:
183
Refined petroleum products - imports:
10,630 bbl/day (2015 est.)
comparison ranking:
147
Natural gas:
production:
14.923 million cubic meters (2019 est.)
consumption:
20.954 million cubic meters (2019 est.)
exports:
0 cubic meters (2021 est.)
imports:
6.031 million cubic meters (2019 est.)
proven reserves:
113 million cubic meters (2021 est.)
Carbon dioxide emissions:
1.703 million metric tonnes of CO2 (2019 est.)
from coal and metallurgical coke:
0 metric tonnes of CO2 (2019 est.)
from petroleum and other liquids:
1.662 million metric tonnes of CO2 (2019 est.)
from consumed natural gas:
41,000 metric tonnes of CO2 (2019 est.)
comparison ranking:
total emissions 163
Energy consumption per capita:
83.723 million Btu/person (2019 est.)
comparison ranking:
68','10f6169548a130163623a4f3980bdda1ecf11c018cfb33ebffd111a427908ac1','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cea05d0cae8fbe1ba8d22eab150aa5f0fa8b9807d4c713e7dfb86ab93eb21c0b',2025,'BY','Belarus','energy',46,'Electricity access:
electrification - total population:
100% (2021)
Electricity:
installed generating capacity:
11.36 million kW (2020 est.)
consumption:
32,665,500,000 kWh (2019 est.)
exports:
4.777 billion kWh (2020 est.)
imports:
4.277 billion kWh (2020 est.)
transmission/distribution losses:
2.711 billion kWh (2019 est.)
comparison rankings:
imports 44; exports 37; installed generating capacity 60; transmission/distribution losses 72; consumption 60
Electricity generation sources:
fossil fuels:
95.8% of total installed capacity (2020 est.)
nuclear:
0.9% of total installed capacity (2020 est.)
solar:
0.5% of total installed capacity (2020 est.)
wind:
0.5% of total installed capacity (2020 est.)
hydroelectricity:
1.1% of total installed capacity (2020 est.)
tide and wave:
0% of total installed capacity (2020 est.)
geothermal:
0% of total installed capacity (2020 est.)
biomass and waste:
1.2% of total installed capacity (2020 est.)
Nuclear energy: Number of operational nuclear reactors:
2 (2023)
Number of nuclear reactors under construction:
0
Net capacity of operational nuclear reactors:
2.22GW (2023)
Percent of total electricity production:
14.1% (2021)
Percent of total energy produced:
40.8% (2021)
Number of nuclear reactors permanently shut down:
0
Coal:
production:
0 metric tons (2020 est.)
consumption:
621,000 metric tons (2020 est.)
exports:
1.574 million metric tons (2020 est.)
imports:
2.117 million metric tons (2020 est.)
proven reserves:
0 metric tons (2019 est.)
Petroleum:
total petroleum production:
34,300 bbl/day (2021 est.)
refined petroleum consumption:
134,600 bbl/day (2019 est.)
crude oil and lease condensate exports:
32,200 bbl/day (2018 est.)
crude oil and lease condensate imports:
383,200 bbl/day (2018 est.)
crude oil estimated reserves:
198 million barrels (2021 est.)
Refined petroleum products - production:
477,200 bbl/day (2015 est.)
comparison ranking:
34
Refined petroleum products - exports:
351,200 bbl/day (2015 est.)
comparison ranking:
25
Refined petroleum products - imports:
14,630 bbl/day (2015 est.)
comparison ranking:
135
Natural gas:
production:
68.951 million cubic meters (2019 est.)
consumption:
18,639,590,000 cubic meters (2019 est.)
exports:
0 cubic meters (2021 est.)
imports:
18,673,429,000 cubic meters (2019 est.)
proven reserves:
2.832 billion cubic meters (2021 est.)
Carbon dioxide emissions:
54.695 million metric tonnes of CO2 (2019 est.)
from coal and metallurgical coke:
1.623 million metric tonnes of CO2 (2019 est.)
from petroleum and other liquids:
16.856 million metric tonnes of CO2 (2019 est.)
from consumed natural gas:
36.217 million metric tonnes of CO2 (2019 est.)
comparison ranking:
total emissions 56
Energy consumption per capita:
102.558 million Btu/person (2019 est.)
comparison ranking:
56','a74c841cb89be7fae683054eed72c2ab78299ddb996a79e59f99aad964d1534c','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2e0a44b27141e0e9d962d0bf19a5fe0189f37be810c4953d11e8f0bfcaa09b23',2025,'BE','Belgium','energy',58,'Electricity access:
electrification - total population:
100% (2021)
Electricity:
installed generating capacity:
26.929 million kW (2020 est.)
consumption:
81,171,300,000 kWh (2020 est.)
exports:
14.053 billion kWh (2020 est.)
imports:
13.394 billion kWh (2020 est.)
transmission/distribution losses:
3.444 billion kWh (2020 est.)
comparison rankings:
transmission/distribution losses 59; imports 17; exports 16; consumption 36; installed generating capacity 39
Electricity generation sources:
fossil fuels:
33.1% of total installed capacity (2020 est.)
nuclear:
38.1% of total installed capacity (2020 est.)
solar:
5.8% of total installed capacity (2020 est.)
wind:
15% of total installed capacity (2020 est.)
hydroelectricity:
0.3% of total installed capacity (2020 est.)
tide and wave:
0% of total installed capacity (2020 est.)
geothermal:
0% of total installed capacity (2020 est.)
biomass and waste:
7.7% of total installed capacity (2020 est.)
Nuclear energy: Number of operational nuclear reactors:
5 (2023)
Number of nuclear reactors under construction:
0
Net capacity of operational nuclear reactors:
3.93GW (2023)
Percent of total electricity production:
50.8% (2021)
Percent of total energy produced:
71% (2021)
Number of nuclear reactors permanently shut down:
2
Coal:
production:
1.105 million metric tons (2020 est.)
consumption:
4.167 million metric tons (2020 est.)
exports:
504,000 metric tons (2020 est.)
imports:
3.467 million metric tons (2020 est.)
proven reserves:
0 metric tons (2019 est.)
Petroleum:
total petroleum production:
11,400 bbl/day (2021 est.)
refined petroleum consumption:
642,300 bbl/day (2019 est.)
crude oil and lease condensate exports:
0 bbl/day (2018 est.)
crude oil and lease condensate imports:
666,700 bbl/day (2018 est.)
crude oil estimated reserves:
0 barrels (2021 est.)
Refined petroleum products - production:
731,700 bbl/day (2017 est.)
comparison ranking:
25
Refined petroleum products - exports:
680,800 bbl/day (2017 est.)
comparison ranking:
12
Refined petroleum products - imports:
601,400 bbl/day (2017 est.)
comparison ranking:
14
Natural gas:
production:
0 cubic meters (2021 est.)
consumption:
18.17 billion cubic meters (2019 est.)
exports:
3.943 billion cubic meters (2019 est.)
imports:
22.61 billion cubic meters (2019 est.)
proven reserves:
0 cubic meters (2021 est.)
Carbon dioxide emissions:
128.247 million metric tonnes of CO2 (2019 est.)
from coal and metallurgical coke:
10.301 million metric tonnes of CO2 (2019 est.)
from petroleum and other liquids:
83.474 million metric tonnes of CO2 (2019 est.)
from consumed natural gas:
34.472 million metric tonnes of CO2 (2019 est.)
comparison ranking:
total emissions 37
Energy consumption per capita:
234.216 million Btu/person (2019 est.)
comparison ranking:
17','00845da18bdf686e92c8a3a5f949b3aa4b4e1d7c880ed71c677b0bfc76760e39','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9a12a9f7021c8174f6ecac1c11a1bd3bfd6b118767f0b8064bd37926ec5f29bf',2025,'BZ','Belize','energy',7,'Electricity access:
electrification - total population:
97.7% (2021)
electrification - urban areas:
98.4% (2021)
electrification - rural areas:
97% (2021)
Electricity:
installed generating capacity:
204,000 kW (2020 est.)
consumption:
992.305 million kWh (2019 est.)
exports:
0 kWh (2019 est.)
imports:
240 million kWh (2019 est.)
transmission/distribution losses:
80.3 million kWh (2019 est.)
comparison rankings:
installed generating capacity 171; transmission/distribution losses 163; imports 100; exports 154; consumption 161
Electricity generation sources:
fossil fuels:
63.6% of total installed capacity (2020 est.)
solar:
0.2% of total installed capacity (2020 est.)
hydroelectricity:
13.4% of total installed capacity (2020 est.)
biomass and waste:
22.9% of total installed capacity (2020 est.)
Petroleum:
total petroleum production:
1,300 bbl/day (2021 est.)
refined petroleum consumption:
3,900 bbl/day (2019 est.)
crude oil and lease condensate exports:
1,200 bbl/day (2018 est.)
crude oil and lease condensate imports:
0 bbl/day (2018 est.)
crude oil estimated reserves:
6.7 million barrels (2021 est.)
Refined petroleum products - production:
36 bbl/day (2015 est.)
comparison ranking:
109
Refined petroleum products - exports:
0 bbl/day (2015 est.)
comparison ranking:
180
Refined petroleum products - imports:
4,161 bbl/day (2015 est.)
comparison ranking:
176
Carbon dioxide emissions:
541,000 metric tonnes of CO2 (2019 est.)
from petroleum and other liquids:
541,000 metric tonnes of CO2 (2019 est.)
comparison ranking:
total emissions 188
Energy consumption per capita:
31.552 million Btu/person (2019 est.)
comparison ranking:
120','4e06a03ca2d6d8e1a88171311ed54bb831c5cc00b26f3fac12eedfa3bda667e7','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('28a41e681004e471fe3543b857c2ca0947d73737dd94fbd9420cfcb6db7b63d3',2025,'BJ','Benin','energy',18,'Electricity access:
population without electricity:
8 million (2020)
electrification - total population:
41.9% (2021)
electrification - urban areas:
66.9% (2021)
electrification - rural areas:
17.9% (2021)
Electricity:
installed generating capacity:
475,000 kW (2020 est.)
consumption:
524.08 million kWh (2020 est.)
exports:
2 million kWh (2020 est.)
imports:
646 million kWh (2020 est.)
transmission/distribution losses:
346 million kWh (2020 est.)
comparison rankings:
transmission/distribution losses 137; imports 81; exports 98; consumption 171; installed generating capacity 152
Electricity generation sources:
fossil fuels:
96.9% of total installed capacity (2020 est.)
solar:
3.1% of total installed capacity (2020 est.)
Coal:
production:
0 metric tons (2020 est.)
consumption:
78,000 metric tons (2020 est.)
exports:
0 metric tons (2020 est.)
imports:
78,000 metric tons (2020 est.)
proven reserves:
0 metric tons (2019 est.)
Petroleum:
total petroleum production:
0 bbl/day (2021 est.)
refined petroleum consumption:
46,300 bbl/day (2019 est.)
crude oil and lease condensate exports:
0 bbl/day (2018 est.)
crude oil and lease condensate imports:
0 bbl/day (2018 est.)
crude oil estimated reserves:
8 million barrels (2021 est.)
Refined petroleum products - production:
0 bbl/day (2015 est.)
comparison ranking:
156
Refined petroleum products - exports:
1,514 bbl/day (2015 est.)
comparison ranking:
107
Refined petroleum products - imports:
38,040 bbl/day (2015 est.)
comparison ranking:
93
Natural gas:
production:
0 cubic meters (2021 est.)
consumption:
19.057 million cubic meters (2019 est.)
exports:
0 cubic meters (2021 est.)
imports:
19.057 million cubic meters (2019 est.)
proven reserves:
1.133 billion cubic meters (2021 est.)
Carbon dioxide emissions:
6.903 million metric tonnes of CO2 (2019 est.)
from coal and metallurgical coke:
274,000 metric tonnes of CO2 (2019 est.)
from petroleum and other liquids:
6.592 million metric tonnes of CO2 (2019 est.)
from consumed natural gas:
37,000 metric tonnes of CO2 (2019 est.)
comparison ranking:
total emissions 126
Energy consumption per capita:
8.468 million Btu/person (2019 est.)
comparison ranking:
159','9319892c143e24fccf860e3495ed04eda4dddbdf77006aeff8fcfd3da5eed868','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c84578858a2f0987b7a566180fb896381a92df2b4e76ccb91b3197a54e029d70',2025,'BM','Bermuda','energy',30,'Electricity access:
electrification - total population:
100% (2021)
Electricity:
installed generating capacity:
172,000 kW (2020 est.)
consumption:
533.434 million kWh (2019 est.)
exports:
0 kWh (2020 est.)
imports:
0 kWh (2020 est.)
transmission/distribution losses:
41 million kWh (2019 est.)
comparison rankings:
imports 213; exports 213; installed generating capacity 176; transmission/distribution losses 173; consumption 169
Electricity generation sources:
fossil fuels:
100% of total installed capacity (2020 est.)
Petroleum:
total petroleum production:
0 bbl/day (2021 est.)
refined petroleum consumption:
5,200 bbl/day (2019 est.)
Refined petroleum products - imports:
3,939 bbl/day (2015 est.)
comparison ranking:
178
Carbon dioxide emissions:
796,000 metric tonnes of CO2 (2019 est.)
from petroleum and other liquids:
796,000 metric tonnes of CO2 (2019 est.)
comparison ranking:
total emissions 180
Energy consumption per capita:
176.312 million Btu/person (2019 est.)
comparison ranking:
24','2ef32e195fa596e7f8fbbd6cf1521284b1551e7a7e1dc8d2651522867a54726a','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9ba77b14ebe75ab37f8e593ce5c1ab603b80afd7f80c57d5da7b7907d224d817',2025,'BT','Bhutan','energy',41,'Electricity access:
electrification - total population:
100% (2021)
Electricity:
installed generating capacity:
2.334 million kW (2020 est.)
consumption:
4.315 billion kWh (2019 est.)
exports:
4.6 billion kWh (2019 est.)
imports:
22.85 million kWh (2019 est.)
transmission/distribution losses:
60 million kWh (2019 est.)
comparison rankings:
installed generating capacity 116; transmission/distribution losses 170; imports 115; exports 38; consumption 130
Electricity generation sources:
hydroelectricity:
100% of total installed capacity (2020 est.)
Coal:
production:
174,000 metric tons (2020 est.)
consumption:
211,000 metric tons (2020 est.)
exports:
0 metric tons (2020 est.)
imports:
37,000 metric tons (2020 est.)
proven reserves:
0 metric tons (2019 est.)
Petroleum:
total petroleum production:
0 bbl/day (2021 est.)
refined petroleum consumption:
4,400 bbl/day (2019 est.)
Refined petroleum products - production:
0 bbl/day (2017 est.)
comparison ranking:
185
Refined petroleum products - exports:
0 bbl/day (2015 est.)
comparison ranking:
126
Refined petroleum products - imports:
3,120 bbl/day (2015 est.)
comparison ranking:
183
Carbon dioxide emissions:
934,000 metric tonnes of CO2 (2019 est.)
from coal and metallurgical coke:
328,000 metric tonnes of CO2 (2019 est.)
from petroleum and other liquids:
606,000 metric tonnes of CO2 (2019 est.)
comparison ranking:
total emissions 174
Energy consumption per capita:
100.135 million Btu/person (2019 est.)
comparison ranking:
59','941b8f0646a5ec82fcaad9d113fc3305b997ef3bf7d4525e3bfdbcd0ba8c1c38','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cad68d4553b32f931e48557a6b255a14532bdfcc4d461e421f8288cbea36f3d8',2025,'BT','Bhutan','energy',53,'Electricity access:
population without electricity:
2 million (2020)
electrification - total population:
98.5% (2021)
electrification - urban areas:
100% (2021)
electrification - rural areas:
95.1% (2021)
Electricity:
installed generating capacity:
3.834 million kW (2020 est.)
consumption:
8,756,690,000 kWh (2019 est.)
exports:
0 kWh (2019 est.)
imports:
0 kWh (2019 est.)
transmission/distribution losses:
1.227 billion kWh (2019 est.)
comparison rankings:
installed generating capacity 98; transmission/distribution losses 105; imports 126; exports 106; consumption 105
Electricity generation sources:
fossil fuels:
64.4% of total installed capacity (2020 est.)
solar:
2.6% of total installed capacity (2020 est.)
wind:
0.7% of total installed capacity (2020 est.)
hydroelectricity:
30.5% of total installed capacity (2020 est.)
biomass and waste:
1.8% of total installed capacity (2020 est.)
Coal:
proven reserves:
1 million metric tons (2019 est.)
Petroleum:
total petroleum production:
65,400 bbl/day (2021 est.)
refined petroleum consumption:
87,800 bbl/day (2019 est.)
crude oil and lease condensate exports:
0 bbl/day (2018 est.)
crude oil and lease condensate imports:
0 bbl/day (2018 est.)
crude oil estimated reserves:
240.9 million barrels (2021 est.)
Refined petroleum products - production:
65,960 bbl/day (2015 est.)
comparison ranking:
75
Refined petroleum products - exports:
9,686 bbl/day (2015 est.)
comparison ranking:
82
Refined petroleum products - imports:
20,620 bbl/day (2015 est.)
comparison ranking:
118
Natural gas:
production:
15,328,422,000 cubic meters (2019 est.)
consumption:
2,918,839,000 cubic meters (2019 est.)
exports:
11,818,215,000 cubic meters (2019 est.)
imports:
0 cubic meters (2021 est.)
proven reserves:
302.99 billion cubic meters (2021 est.)
Carbon dioxide emissions:
17.786 million metric tonnes of CO2 (2019 est.)
from coal and metallurgical coke:
0 metric tonnes of CO2 (2019 est.)
from petroleum and other liquids:
12.071 million metric tonnes of CO2 (2019 est.)
from consumed natural gas:
5.715 million metric tonnes of CO2 (2019 est.)
comparison ranking:
total emissions 89
Energy consumption per capita:
27.094 million Btu/person (2019 est.)
comparison ranking:
126','d24008a20d00c9a0f82d232b945fda73cc2579e53f41d103f921305d3e43f7b3','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('54626ef6e7810d0cc0c16d51ecae8af8e03f3f2a0bd3859f33279e5850fe8a32',2025,'BA','Bosnia and Herzegovina','energy',65,'Electricity access:
electrification - total population:
100% (2021)
Electricity:
installed generating capacity:
4.775 million kW (2020 est.)
consumption:
11,657,450,000 kWh (2019 est.)
exports:
7.316 billion kWh (2020 est.)
imports:
3.266 billion kWh (2020 est.)
transmission/distribution losses:
1.257 billion kWh (2019 est.)
comparison rankings:
imports 50; exports 26; installed generating capacity 90; transmission/distribution losses 104; consumption 94
Electricity generation sources:
fossil fuels:
62.8% of total installed capacity (2020 est.)
solar:
0.3% of total installed capacity (2020 est.)
wind:
1.5% of total installed capacity (2020 est.)
hydroelectricity:
35.4% of total installed capacity (2020 est.)
biomass and waste:
0.1% of total installed capacity (2020 est.)
Coal:
production:
6.966 million metric tons (2020 est.)
consumption:
7.752 million metric tons (2020 est.)
exports:
525,000 metric tons (2020 est.)
imports:
1.366 million metric tons (2020 est.)
proven reserves:
2.264 billion metric tons (2019 est.)
Petroleum:
total petroleum production:
0 bbl/day (2021 est.)
refined petroleum consumption:
34,700 bbl/day (2019 est.)
crude oil and lease condensate exports:
0 bbl/day (2018 est.)
crude oil and lease condensate imports:
13,900 bbl/day (2018 est.)
crude oil estimated reserves:
0 barrels (2021 est.)
Refined petroleum products - production:
0 bbl/day (2015 est.)
comparison ranking:
213
Refined petroleum products - exports:
4,603 bbl/day (2015 est.)
comparison ranking:
92
Refined petroleum products - imports:
18,280 bbl/day (2015 est.)
comparison ranking:
129
Natural gas:
production:
0 cubic meters (2021 est.)
consumption:
218.266 million cubic meters (2019 est.)
exports:
0 cubic meters (2021 est.)
imports:
218.266 million cubic meters (2019 est.)
proven reserves:
0 cubic meters (2021 est.)
Carbon dioxide emissions:
16.209 million metric tonnes of CO2 (2019 est.)
from coal and metallurgical coke:
10.923 million metric tonnes of CO2 (2019 est.)
from petroleum and other liquids:
4.871 million metric tonnes of CO2 (2019 est.)
from consumed natural gas:
415,000 metric tonnes of CO2 (2019 est.)
comparison ranking:
total emissions 95
Energy consumption per capita:
71.815 million Btu/person (2019 est.)
comparison ranking:
83','723e31dcf7d5035c652e0b6f7dd3bfbcc58c6e6c039a64080e62761bcdfdd6fd','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4f96c6cee777915a0a4e6b1943e5c21047b8204f67a79b07c7a8682bdfe67179',2025,'BW','Botswana','energy',7,'Electricity access:
electrification - total population:
73.7% (2021)
electrification - urban areas:
93% (2021)
electrification - rural areas:
24.9% (2021)
Electricity:
installed generating capacity:
766,000 kW (2020 est.)
consumption:
3,515,900,000 kWh (2019 est.)
exports:
0 kWh (2019 est.)
imports:
1.101 billion kWh (2019 est.)
transmission/distribution losses:
631 million kWh (2019 est.)
comparison rankings:
installed generating capacity 141; transmission/distribution losses 124; imports 71; exports 195; consumption 135
Electricity generation sources:
fossil fuels:
99.8% of total installed capacity (2020 est.)
solar:
0.2% of total installed capacity (2020 est.)
Coal:
production:
1.876 million metric tons (2020 est.)
consumption:
1.416 million metric tons (2020 est.)
exports:
497,000 metric tons (2020 est.)
imports:
0 metric tons (2020 est.)
proven reserves:
1.66 billion metric tons (2019 est.)
Petroleum:
total petroleum production:
0 bbl/day (2021 est.)
refined petroleum consumption:
21,700 bbl/day (2019 est.)
Refined petroleum products - imports:
21,090 bbl/day (2015 est.)
comparison ranking:
116
Carbon dioxide emissions:
5.965 million metric tonnes of CO2 (2019 est.)
from coal and metallurgical coke:
2.922 million metric tonnes of CO2 (2019 est.)
from petroleum and other liquids:
3.042 million metric tonnes of CO2 (2019 est.)
from consumed natural gas:
0 metric tonnes of CO2 (2019 est.)
comparison ranking:
total emissions 131
Energy consumption per capita:
34.095 million Btu/person (2019 est.)
comparison ranking:
117','15737247ebad94aaa6f9a207fb5da62e01f912090f23e355da523370f8837d71','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('14f1e990191c5b681f4b033674c942114823fb282a2e0033e9b2363570147655',2025,'BR','Brazil','energy',28,'Electricity access:
electrification - total population:
99.4% (2021)
electrification - urban areas:
99.7% (2021)
electrification - rural areas:
97.3% (2021)
Electricity:
installed generating capacity:
195.037 million kW (2020 est.)
consumption:
540,997,340,000 kWh (2020 est.)
exports:
395 million kWh (2020 est.)
imports:
25.113 billion kWh (2020 est.)
transmission/distribution losses:
105.727 billion kWh (2020 est.)
comparison rankings:
transmission/distribution losses 4; imports 6; exports 78; consumption 6; installed generating capacity 7
Electricity generation sources:
fossil fuels:
11.8% of total installed capacity (2020 est.)
nuclear:
2.3% of total installed capacity (2020 est.)
solar:
1.7% of total installed capacity (2020 est.)
wind:
9.2% of total installed capacity (2020 est.)
hydroelectricity:
65.8% of total installed capacity (2020 est.)
biomass and waste:
9.2% of total installed capacity (2020 est.)
Nuclear energy: Number of operational nuclear reactors:
2 (2023)
Number of nuclear reactors under construction:
1
Net capacity of operational nuclear reactors:
1.88GW (2023)
Percent of total electricity production:
2.5% (2021)
Percent of total energy produced:
1% (2021)
Number of nuclear reactors permanently shut down:
0
Coal:
production:
13.993 million metric tons (2020 est.)
consumption:
31.841 million metric tons (2020 est.)
exports:
16,000 metric tons (2020 est.)
imports:
19.217 million metric tons (2020 est.)
proven reserves:
6.596 billion metric tons (2019 est.)
Petroleum:
total petroleum production:
3,629,100 bbl/day (2021 est.)
refined petroleum consumption:
3,142,300 bbl/day (2019 est.)
crude oil and lease condensate exports:
1,123,300 bbl/day (2018 est.)
crude oil and lease condensate imports:
186,200 bbl/day (2018 est.)
crude oil estimated reserves:
12,714,600,000 barrels (2021 est.)
Refined petroleum products - production:
2.811 million bbl/day (2015 est.)
comparison ranking:
7
Refined petroleum products - exports:
279,000 bbl/day (2015 est.)
comparison ranking:
28
Refined petroleum products - imports:
490,400 bbl/day (2015 est.)
comparison ranking:
17
Natural gas:
production:
25,395,979,000 cubic meters (2019 est.)
consumption:
35,253,198,000 cubic meters (2019 est.)
exports:
0 cubic meters (2021 est.)
imports:
9,724,017,000 cubic meters (2019 est.)
proven reserves:
363.984 billion cubic meters (2021 est.)
Carbon dioxide emissions:
456.67 million metric tonnes of CO2 (2019 est.)
from coal and metallurgical coke:
63.53 million metric tonnes of CO2 (2019 est.)
from petroleum and other liquids:
328.824 million metric tonnes of CO2 (2019 est.)
from consumed natural gas:
64.316 million metric tonnes of CO2 (2019 est.)
comparison ranking:
total emissions 14
Energy consumption per capita:
59.444 million Btu/person (2019 est.)
comparison ranking:
93','70cc29f98dff396572a99f81523955bcab1e12c0e3274b19cfd166a5d01105e7','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9a4499f6641c49b7e2eddb4f915ed7c961d0d1434addb982a0aeb2d002de7d63',2025,'IO','British Indian Ocean Territory','energy',51,'Electricity access:
electrification - total population:
100% (2021)
Electricity:
installed generating capacity:
33,000 kW (2020 est.)
consumption:
116.298 million kWh (2019 est.)
exports:
0 kWh (2020 est.)
imports:
0 kWh (2020 est.)
transmission/distribution losses:
22.5 million kWh (2019 est.)
comparison rankings:
imports 148; exports 136; installed generating capacity 200; transmission/distribution losses 183; consumption 194
Electricity generation sources:
fossil fuels:
98.8% of total installed capacity (2020 est.)
solar:
0.2% of total installed capacity (2020 est.)
wind:
1% of total installed capacity (2020 est.)
Petroleum:
total petroleum production:
0 bbl/day (2021 est.)
refined petroleum consumption:
1,200 bbl/day (2019 est.)
Refined petroleum products - imports:
1,227 bbl/day (2015 est.)
comparison ranking:
199
Carbon dioxide emissions:
173,000 metric tonnes of CO2 (2019 est.)
from petroleum and other liquids:
173,000 metric tonnes of CO2 (2019 est.)
comparison ranking:
total emissions 205
Energy consumption per capita:
80.136 million Btu/person (2019 est.)
comparison ranking:
74','63871a440a441e9868f8677588214573455a78f41dfd25b2c8340734785e4ecf','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0ce00951cc121c90d9250ef4057754b0c42b8fa1c6fdc87a13d24753e1fb8294',2025,'IO','British Indian Ocean Territory','energy',62,'Electricity access:
electrification - total population:
100% (2021)
Electricity:
installed generating capacity:
1.261 million kW (2020 est.)
consumption:
4,140,140,000 kWh (2019 est.)
exports:
0 kWh (2019 est.)
imports:
0 kWh (2019 est.)
transmission/distribution losses:
497 million kWh (2019 est.)
comparison rankings:
installed generating capacity 130; transmission/distribution losses 130; imports 140; exports 123; consumption 132
Electricity generation sources:
fossil fuels:
100% of total installed capacity (2020 est.)
solar:
0.1% of total installed capacity (2020 est.)
Petroleum:
total petroleum production:
107,300 bbl/day (2021 est.)
refined petroleum consumption:
18,800 bbl/day (2019 est.)
crude oil and lease condensate exports:
103,100 bbl/day (2018 est.)
crude oil and lease condensate imports:
0 bbl/day (2018 est.)
crude oil estimated reserves:
1.1 billion barrels (2021 est.)
Refined petroleum products - production:
10,310 bbl/day (2015 est.)
comparison ranking:
100
Refined petroleum products - exports:
0 bbl/day (2015 est.)
comparison ranking:
132
Refined petroleum products - imports:
6,948 bbl/day (2015 est.)
comparison ranking:
159
Natural gas:
production:
12,498,299,000 cubic meters (2020 est.)
consumption:
4,166,987,000 cubic meters (2020 est.)
exports:
7,774,406,000 cubic meters (2020 est.)
imports:
0 cubic meters (2021 est.)
proven reserves:
260.515 billion cubic meters (2021 est.)
Carbon dioxide emissions:
9.956 million metric tonnes of CO2 (2019 est.)
from coal and metallurgical coke:
0 metric tonnes of CO2 (2019 est.)
from petroleum and other liquids:
2.387 million metric tonnes of CO2 (2019 est.)
from consumed natural gas:
7.569 million metric tonnes of CO2 (2019 est.)
comparison ranking:
total emissions 107
Energy consumption per capita:
415.184 million Btu/person (2019 est.)
comparison ranking:
5','287eade8185965e195241748b554f91620c9665ff854453c053d571f011ff895','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7674b4f92d15bcbd8ea9f1e17a4d1ee99694724702b3e76d8aeb74f7effb0eb4',2025,'BG','Bulgaria','energy',7,'Electricity access:
electrification - total population:
99.8% (2021)
electrification - urban areas:
99.9% (2021)
electrification - rural areas:
99.5% (2021)
Electricity:
installed generating capacity:
11.097 million kW (2020 est.)
consumption:
30,905,170,000 kWh (2019 est.)
exports:
7.115 billion kWh (2020 est.)
imports:
3.707 billion kWh (2020 est.)
transmission/distribution losses:
2.767 billion kWh (2019 est.)
comparison rankings:
imports 46; exports 27; installed generating capacity 61; transmission/distribution losses 70; consumption 63
Electricity generation sources:
fossil fuels:
36.5% of total installed capacity (2020 est.)
nuclear:
44.7% of total installed capacity (2020 est.)
solar:
4% of total installed capacity (2020 est.)
wind:
4% of total installed capacity (2020 est.)
hydroelectricity:
9.1% of total installed capacity (2020 est.)
biomass and waste:
1.9% of total installed capacity (2020 est.)
Nuclear energy: Number of operational nuclear reactors:
2 (2023)
Number of nuclear reactors under construction:
0
Net capacity of operational nuclear reactors:
2.01GW (2023)
Percent of total electricity production:
34.6% (2021)
Percent of total energy produced:
40% (2021)
Number of nuclear reactors permanently shut down:
2
Coal:
production:
22.298 million metric tons (2020 est.)
consumption:
23.213 million metric tons (2020 est.)
exports:
35,000 metric tons (2020 est.)
imports:
675,000 metric tons (2020 est.)
proven reserves:
2.366 billion metric tons (2019 est.)
Petroleum:
total petroleum production:
4,500 bbl/day (2021 est.)
refined petroleum consumption:
97,800 bbl/day (2019 est.)
crude oil and lease condensate exports:
0 bbl/day (2018 est.)
crude oil and lease condensate imports:
119,800 bbl/day (2018 est.)
crude oil estimated reserves:
15 million barrels (2021 est.)
Refined petroleum products - production:
144,300 bbl/day (2015 est.)
comparison ranking:
60
Refined petroleum products - exports:
92,720 bbl/day (2015 est.)
comparison ranking:
45
Refined petroleum products - imports:
49,260 bbl/day (2015 est.)
comparison ranking:
83
Natural gas:
production:
62.439 million cubic meters (2020 est.)
consumption:
2,929,401,000 cubic meters (2019 est.)
exports:
2.747 million cubic meters (2020 est.)
imports:
2,950,157,000 cubic meters (2019 est.)
proven reserves:
5.663 billion cubic meters (2021 est.)
Carbon dioxide emissions:
38.373 million metric tonnes of CO2 (2019 est.)
from coal and metallurgical coke:
20.483 million metric tonnes of CO2 (2019 est.)
from petroleum and other liquids:
12.248 million metric tonnes of CO2 (2019 est.)
from consumed natural gas:
5.642 million metric tonnes of CO2 (2019 est.)
comparison ranking:
total emissions 67
Energy consumption per capita:
103.924 million Btu/person (2019 est.)
comparison ranking:
55','b39db922c2aadc7cf152c3c8cca3c3ee73e4263454a497773f4c7c739627cb05','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7ed11dfa84e10d465d04d01273c1b6b8eb9d1bd4902ef4d2dd651230042d5477',2025,'BF','Burkina Faso','energy',20,'Electricity access:
population without electricity:
16 million (2020)
electrification - total population:
18.9% (2021)
electrification - urban areas:
67.6% (2021)
electrification - rural areas:
4.7% (2014)
Electricity:
installed generating capacity:
392,000 kW (2020 est.)
consumption:
2,033,520,000 kWh (2019 est.)
exports:
0 kWh (2019 est.)
imports:
600 million kWh (2019 est.)
transmission/distribution losses:
248 million kWh (2019 est.)
comparison rankings:
installed generating capacity 155; transmission/distribution losses 143; imports 83; exports 109;
consumption:
148
Electricity generation sources:
fossil fuels:
89.4% of total installed capacity (2020 est.)
nuclear:
0% of total installed capacity (2020 est.)
solar:
3.3% of total installed capacity (2020 est.)
hydroelectricity:
6.9% of total installed capacity (2020 est.)
biomass and waste:
0.4% of total installed capacity (2020 est.)
Petroleum:
total petroleum production:
0 bbl/day (2021 est.)
refined petroleum consumption:
30,800 bbl/day (2019 est.)
Refined petroleum products - production:
0 bbl/day (2015 est.)
comparison ranking:
160
Refined petroleum products - exports:
0 bbl/day (2015 est.)
comparison ranking:
158
Refined petroleum products - imports:
23,580 bbl/day (2015 est.)
comparison ranking:
110
Carbon dioxide emissions:
4.444 million metric tonnes of CO2 (2019 est.)
from petroleum and other liquids:
4.444 million metric tonnes of CO2 (2019 est.)
comparison ranking:
total emissions 139
Energy consumption per capita:
3.23 million Btu/person (2019 est.)
comparison ranking:
179','577f9568c4fa417fd0dd62a6431c18650c78d4b997aeba4a06903a7c560dfe44','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('41ea5b2d8b7cbcfa33246b5190ae86c696d65d2225f65c6329bbc14a2dac5b12',2025,'BF','Burkina Faso','energy',32,'Electricity access:
population without electricity:
26 million (2020)
electrification - total population:
72.4% (2021)
electrification - urban areas:
93.6% (2021)
electrification - rural areas:
62.7% (2021)
Electricity:
installed generating capacity:
7.247 million kW (2020 est.)
consumption:
20,474,380,000 kWh (2019 est.)
exports:
1.002 billion kWh (2019 est.)
imports:
0 kWh (2019 est.)
transmission/distribution losses:
3.405 billion kWh (2019 est.)
comparison rankings:
installed generating capacity 77; transmission/distribution losses 61; imports 172; exports 60; consumption 72
Electricity generation sources:
fossil fuels:
52.6% of total installed capacity (2020 est.)
solar:
0.1% of total installed capacity (2020 est.)
hydroelectricity:
47.3% of total installed capacity (2020 est.)
Coal:
production:
1.468 million metric tons (2020 est.)
consumption:
1.981 million metric tons (2020 est.)
exports:
1,000 metric tons (2020 est.)
imports:
514,000 metric tons (2020 est.)
proven reserves:
6 million metric tons (2019 est.)
Petroleum:
total petroleum production:
7,800 bbl/day (2021 est.)
refined petroleum consumption:
146,200 bbl/day (2019 est.)
crude oil and lease condensate exports:
4,700 bbl/day (2018 est.)
crude oil and lease condensate imports:
0 bbl/day (2018 est.)
crude oil estimated reserves:
139 million barrels (2021 est.)
Refined petroleum products - production:
13,330 bbl/day (2017 est.)
comparison ranking:
97
Refined petroleum products - exports:
0 bbl/day (2015 est.)
comparison ranking:
176
Refined petroleum products - imports:
102,600 bbl/day (2015 est.)
comparison ranking:
53
Natural gas:
production:
17,710,912,000 cubic meters (2019 est.)
consumption:
3,612,431,000 cubic meters (2019 est.)
exports:
14,188,161,000 cubic meters (2019 est.)
imports:
475.156 million cubic meters (2020 est.)
proven reserves:
637.128 billion cubic meters (2021 est.)
Carbon dioxide emissions:
31.848 million metric tonnes of CO2 (2019 est.)
from coal and metallurgical coke:
3.881 million metric tonnes of CO2 (2019 est.)
from petroleum and other liquids:
20.832 million metric tonnes of CO2 (2019 est.)
from consumed natural gas:
7.134 million metric tonnes of CO2 (2019 est.)
comparison ranking:
total emissions 75
Energy consumption per capita:
10.679 million Btu/person (2019 est.)
comparison ranking:
154','b249a071c6156e8af5249a24d3cf0492b370111e61f608f46dbbaef879450b5f','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2962794242e41a1bfc5cd4d0a5c8ee2be35e74d9da7402a7c70d5e309a5c48b3',2025,'BI','Burundi','energy',43,'Electricity access:
population without electricity:
11 million (2020)
electrification - total population:
10.2% (2021)
electrification - urban areas:
62.8% (2021)
electrification - rural areas:
1.6% (2021)
Electricity:
installed generating capacity:
100,000 kW (2020 est.)
consumption:
440.774 million kWh (2019 est.)
exports:
0 kWh (2019 est.)
imports:
100 million kWh (2019 est.)
transmission/distribution losses:
15.96 million kWh (2019 est.)
comparison rankings:
installed generating capacity 183; transmission/distribution losses 188; imports 108; exports 165; consumption 174
Electricity generation sources:
fossil fuels:
33.3% of total installed capacity (2020 est.)
solar:
2.3% of total installed capacity (2020 est.)
hydroelectricity:
62.8% of total installed capacity (2020 est.)
biomass and waste:
1.7% of total installed capacity (2020 est.)
Petroleum:
total petroleum production:
0 bbl/day (2021 est.)
refined petroleum consumption:
5,000 bbl/day (2019 est.)
Refined petroleum products - imports:
1,374 bbl/day (2015 est.)
comparison ranking:
195
Carbon dioxide emissions:
715,000 metric tonnes of CO2 (2019 est.)
from petroleum and other liquids:
715,000 metric tonnes of CO2 (2019 est.)
comparison ranking:
total emissions 183
Energy consumption per capita:
1.087 million Btu/person (2019 est.)
comparison ranking:
194','fc1f5ebec2278bd37881694b6d6d822eadbeeacb96588cb07a7270f67340c980','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9797af8217541e1fb146dfbdb49314bbf1271f1def1859214883c89a7669008e',2025,'CV','Cabo Verde','energy',7,'Electricity access:
electrification - total population:
95.2% (2021)
electrification - urban areas:
94.8% (2021)
electrification - rural areas:
96.8% (2021)
Electricity:
installed generating capacity:
205,000 kW (2020 est.)
consumption:
436.854 million kWh (2019 est.)
exports:
0 kWh (2019 est.)
imports:
0 kWh (2019 est.)
transmission/distribution losses:
32.146 million kWh (2019 est.)
comparison rankings:
installed generating capacity 170; transmission/distribution losses 177; imports 171; exports 163; consumption 175
Electricity generation sources:
fossil fuels:
80.2% of total installed capacity (2020 est.)
solar:
2% of total installed capacity (2020 est.)
wind:
17.8% of total installed capacity (2020 est.)
Petroleum:
total petroleum production:
0 bbl/day (2021 est.)
refined petroleum consumption:
6,500 bbl/day (2019 est.)
crude oil and lease condensate exports:
0 bbl/day (2018 est.)
crude oil and lease condensate imports:
0 bbl/day (2018 est.)
crude oil estimated reserves:
0 barrels (2021 est.)
Refined petroleum products - imports:
5,607 bbl/day (2015 est.)
comparison ranking:
166
Carbon dioxide emissions:
1.002 million metric tonnes of CO2 (2019 est.)
from petroleum and other liquids:
1.002 million metric tonnes of CO2 (2019 est.)
comparison ranking:
total emissions 173
Energy consumption per capita:
26.539 million Btu/person (2019 est.)
comparison ranking:
128','5feaf32a47b65a8a09bd91960c738931693f50179470fb292d8674841f210203','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1d5b05817c012151fc801b7dd83c1dbe1f78afd49129d43b446ff45d46b5eca8',2025,'KH','Cambodia','energy',18,'Electricity access:
population without electricity:
4 million (2020)
electrification - total population:
82.5% (2021)
electrification - urban areas:
98.9% (2021)
electrification - rural areas:
77.1% (2021)
Electricity:
installed generating capacity:
2.954 million kW (2020 est.)
consumption:
10,288,340,000 kWh (2019 est.)
exports:
0 kWh (2019 est.)
imports:
3.063 billion kWh (2019 est.)
transmission/distribution losses:
1.187 billion kWh (2019 est.)
comparison rankings:
installed generating capacity 109; transmission/distribution losses 106; imports 52; exports 156; consumption 100
Electricity generation sources:
fossil fuels:
52% of total installed capacity (2020 est.)
solar:
1.2% of total installed capacity (2020 est.)
hydroelectricity:
45.6% of total installed capacity (2020 est.)
biomass and waste:
1.2% of total installed capacity (2020 est.)
Coal:
production:
0 metric tons (2020 est.)
consumption:
2.974 million metric tons (2020 est.)
exports:
0 metric tons (2020 est.)
imports:
3.311 million metric tons (2020 est.)
proven reserves:
0 metric tons (2019 est.)
Petroleum:
total petroleum production:
0 bbl/day (2021 est.)
refined petroleum consumption:
64,100 bbl/day (2019 est.)
crude oil estimated reserves:
0 barrels (2021 est.)
Refined petroleum products - imports:
43,030 bbl/day (2015 est.)
comparison ranking:
86
Carbon dioxide emissions:
13.844 million metric tonnes of CO2 (2019 est.)
from coal and metallurgical coke:
4.837 million metric tonnes of CO2 (2019 est.)
from petroleum and other liquids:
9.007 million metric tonnes of CO2 (2019 est.)
comparison ranking:
total emissions 98
Energy consumption per capita:
13.629 million Btu/person (2019 est.)
comparison ranking:
142','61c4242e672e7a0b3108dda66e24067061c1715b43375ee31071af1360230608','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f3e78ebe31c68cc6bb59147e8dfbdff96af340e5a232a6656c60ab8d4e59afef',2025,'CM','Cameroon','energy',29,'Electricity access:
population without electricity:
10 million (2020)
electrification - total population:
65.4% (2021)
electrification - urban areas:
94.6% (2021)
electrification - rural areas:
24.8% (2021)
Electricity:
installed generating capacity:
1.754 million kW (2020 est.)
consumption:
6,508,840,000 kWh (2019 est.)
exports:
0 kWh (2019 est.)
imports:
19 million kWh (2019 est.)
transmission/distribution losses:
1.864 billion kWh (2019 est.)
comparison rankings:
installed generating capacity 124; transmission/distribution losses 90; imports 117; exports 188; consumption 114
Electricity generation sources:
fossil fuels:
32.5% of total installed capacity (2020 est.)
solar:
0.2% of total installed capacity (2020 est.)
hydroelectricity:
67.3% of total installed capacity (2020 est.)
Petroleum:
total petroleum production:
63,200 bbl/day (2021 est.)
refined petroleum consumption:
37,900 bbl/day (2019 est.)
crude oil and lease condensate exports:
62,200 bbl/day (2018 est.)
crude oil and lease condensate imports:
20,200 bbl/day (2018 est.)
crude oil estimated reserves:
200 million barrels (2021 est.)
Refined petroleum products - production:
39,080 bbl/day (2015 est.)
comparison ranking:
82
Refined petroleum products - exports:
8,545 bbl/day (2015 est.)
comparison ranking:
84
Refined petroleum products - imports:
14,090 bbl/day (2015 est.)
comparison ranking:
138
Natural gas:
production:
2,678,486,000 cubic meters (2019 est.)
consumption:
986.189 million cubic meters (2019 est.)
exports:
1,603,156,000 cubic meters (2019 est.)
imports:
0 cubic meters (2021 est.)
proven reserves:
135.071 billion cubic meters (2021 est.)
Carbon dioxide emissions:
7.105 million metric tonnes of CO2 (2019 est.)
from petroleum and other liquids:
5.171 million metric tonnes of CO2 (2019 est.)
from consumed natural gas:
1.935 million metric tonnes of CO2 (2019 est.)
comparison ranking:
total emissions 125
Energy consumption per capita:
6.187 million Btu/person (2019 est.)
comparison ranking:
167','4d0b9080ac8fb161d6999fc51590c8948cac0c667db881cd0be1eebc38c191b2','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6f7f5cd87cdbea65ee629e1155ae1002c27b48378d731d26d9bfc81947ecda15',2025,'CA','Canada','energy',41,'Electricity access:
electrification - total population:
100% (2021)
Electricity:
installed generating capacity:
153.251 million kW (2020 est.)
consumption:
539.695 billion kWh (2020 est.)
exports:
67.2 billion kWh (2020 est.)
imports:
9.8 billion kWh (2020 est.)
transmission/distribution losses:
32.937 billion kWh (2020 est.)
comparison rankings:
transmission/distribution losses 12; imports 26; exports 1; consumption 7; installed generating capacity 8
Electricity generation sources:
fossil fuels:
16.5% of total installed capacity (2020 est.)
nuclear:
14.7% of total installed capacity (2020 est.)
solar:
0.7% of total installed capacity (2020 est.)
wind:
5.7% of total installed capacity (2020 est.)
hydroelectricity:
60.8% of total installed capacity (2020 est.)
biomass and waste:
1.6% of total installed capacity (2020 est.)
Nuclear energy: Number of operational nuclear reactors:
19 (2023)
Number of nuclear reactors under construction:
0
Net capacity of operational nuclear reactors:
13.62GW (2023)
Percent of total electricity production:
15% (2021)
Percent of total energy produced:
4% (2021)
Number of nuclear reactors permanently shut down:
2
Coal:
production:
48.328 million metric tons (2020 est.)
consumption:
25.642 million metric tons (2020 est.)
exports:
32.026 million metric tons (2020 est.)
imports:
7.577 million metric tons (2020 est.)
proven reserves:
6.582 billion metric tons (2019 est.)
Petroleum:
total petroleum production:
5,468,100 bbl/day (2021 est.)
refined petroleum consumption:
2,629,300 bbl/day (2019 est.)
crude oil and lease condensate exports:
3.177 million bbl/day (2018 est.)
crude oil and lease condensate imports:
793,800 bbl/day (2018 est.)
crude oil estimated reserves:
170.3 billion barrels (2021 est.)
Refined petroleum products - production:
2.009 million bbl/day (2017 est.)
comparison ranking:
10
Refined petroleum products - exports:
1.115 million bbl/day (2017 est.)
comparison ranking:
8
Refined petroleum products - imports:
405,700 bbl/day (2017 est.)
comparison ranking:
21
Natural gas:
production:
178,723,494,000 cubic meters (2019 est.)
consumption:
124,502,315,000 cubic meters (2019 est.)
exports:
76,094,066,000 cubic meters (2019 est.)
imports:
28,026,440,000 cubic meters (2019 est.)
proven reserves:
2,067,126,000,000 cubic meters (2021 est.)
Carbon dioxide emissions:
612.084 million metric tonnes of CO2 (2019 est.)
from coal and metallurgical coke:
56.087 million metric tonnes of CO2 (2019 est.)
from petroleum and other liquids:
311.336 million metric tonnes of CO2 (2019 est.)
from consumed natural gas:
244.66 million metric tonnes of CO2 (2019 est.)
comparison ranking:
total emissions 9
Energy consumption per capita:
403.7 million Btu/person (2019 est.)
comparison ranking:
6','0899171c96b2b68d8b5b16b0aace733ec6ed19c42422f71fa05d6fce8ba1179d','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('64e163e01adc2041a5079c8d35ddb4331020c14e950d7524ec1292c7748c116d',2025,'KY','Cayman Islands','energy',54,'Electricity access:
electrification - total population:
100% (2021)
Electricity:
installed generating capacity:
174,000 kW (2020 est.)
consumption:
655.165 million kWh (2019 est.)
exports:
0 kWh (2020 est.)
imports:
0 kWh (2020 est.)
transmission/distribution losses:
40 million kWh (2019 est.)
comparison rankings:
imports 138; exports 121; installed generating capacity 175; transmission/distribution losses 174; consumption 165
Electricity generation sources:
fossil fuels:
97.6% of total installed capacity (2020 est.)
solar:
2.4% of total installed capacity (2020 est.)
Petroleum:
total petroleum production:
0 bbl/day (2021 est.)
refined petroleum consumption:
5,500 bbl/day (2019 est.)
Refined petroleum products - imports:
4,285 bbl/day (2015 est.)
comparison ranking:
175
Carbon dioxide emissions:
808,000 metric tonnes of CO2 (2019 est.)
from petroleum and other liquids:
808,000 metric tonnes of CO2 (2019 est.)
comparison ranking:
total emissions 178
Energy consumption per capita:
175.578 million Btu/person (2019 est.)
comparison ranking:
25','a5c263bf45b1f3006dc58fefdcdf45bf2fb1d4e602e74d857a70c421552adf1b','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2bb3ef4ad177887506620a9583c0885309cc147cc615b04385872feb458a3548',2025,'CF','Central African Republic','energy',65,'Electricity access:
population without electricity:
5 million (2020)
electrification - total population:
15.6% (2021)
electrification - urban areas:
34.6% (2021)
electrification - rural areas:
1.5% (2021)
Electricity:
installed generating capacity:
38,000 kW (2020 est.)
consumption:
140.44 million kWh (2019 est.)
exports:
0 kWh (2019 est.)
imports:
0 kWh (2019 est.)
transmission/distribution losses:
10.5 million kWh (2019 est.)
comparison rankings:
installed generating capacity 197; transmission/distribution losses 195; imports 195; exports 193; consumption 190
Electricity generation sources:
fossil fuels:
0.7% of total installed capacity (2020 est.)
hydroelectricity:
99.3% of total installed capacity (2020 est.)
Coal:
proven reserves:
3 million metric tons (2019 est.)
Petroleum:
total petroleum production:
0 bbl/day (2021 est.)
refined petroleum consumption:
2,000 bbl/day (2019 est.)
Refined petroleum products - imports:
2,799 bbl/day (2015 est.)
comparison ranking:
185
Carbon dioxide emissions:
285,000 metric tonnes of CO2 (2019 est.)
from petroleum and other liquids:
285,000 metric tonnes of CO2 (2019 est.)
comparison ranking:
total emissions 198
Energy consumption per capita:
1.121 million Btu/person (2019 est.)
comparison ranking:
193','789d1f9eaa8554ac2bda1f7833ae68e64a0dbab752043f1e8328f71a5852d624','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5624c89107415dd6e26693112e0e84260a79c013be73cd469c628368e8fc077c',2025,'TD','Chad','energy',7,'Electricity access:
population without electricity:
15 million (2020)
electrification - total population:
11.2% (2021)
electrification - urban areas:
43.2% (2021)
electrification - rural areas:
1.3% (2021)
Electricity:
installed generating capacity:
87,000 kW (2020 est.)
consumption:
188.46 million kWh (2019 est.)
exports:
0 kWh (2019 est.)
imports:
0 kWh (2019 est.)
transmission/distribution losses:
111 million kWh (2019 est.)
comparison rankings:
installed generating capacity 186; transmission/distribution losses 159; imports 190; exports 185; consumption 187
Electricity generation sources:
fossil fuels:
96.8% of total installed capacity (2020 est.)
wind:
3.2% of total installed capacity (2020 est.)
Petroleum:
total petroleum production:
87,900 bbl/day (2021 est.)
refined petroleum consumption:
12,600 bbl/day (2019 est.)
crude oil and lease condensate exports:
116,000 bbl/day (2018 est.)
crude oil and lease condensate imports:
0 bbl/day (2018 est.)
crude oil estimated reserves:
1.5 billion barrels (2021 est.)
Refined petroleum products - imports:
2,285 bbl/day (2015 est.)
comparison ranking:
189
Carbon dioxide emissions:
1.771 million metric tonnes of CO2 (2019 est.)
from petroleum and other liquids:
1.771 million metric tonnes of CO2 (2019 est.)
comparison ranking:
total emissions 162
Energy consumption per capita:
1.575 million Btu/person (2019 est.)
comparison ranking:
190','84bee508448be57012a8a384efe4b7a6fe7188932a1619521f897a658d7557e6','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1bc5487504438acadc0aaee992620bbb6d00fd7b7b66a0e035f0dd2e89e996f7',2025,'CL','Chile','energy',19,'Electricity access:
electrification - total population:
100% (2021)
Electricity:
installed generating capacity:
29.808 million kW (2020 est.)
consumption:
75.302 billion kWh (2020 est.)
exports:
0 kWh (2020 est.)
imports:
0 kWh (2020 est.)
transmission/distribution losses:
4.62 billion kWh (2020 est.)
comparison rankings:
transmission/distribution losses 48; imports 187; exports 181; consumption 40; installed generating capacity 35
Electricity generation sources:
fossil fuels:
51.9% of total installed capacity (2020 est.)
solar:
9.5% of total installed capacity (2020 est.)
wind:
6.9% of total installed capacity (2020 est.)
hydroelectricity:
26% of total installed capacity (2020 est.)
geothermal:
0.3% of total installed capacity (2020 est.)
biomass and waste:
5.4% of total installed capacity (2020 est.)
Coal:
production:
542,000 metric tons (2020 est.)
consumption:
10.573 million metric tons (2020 est.)
exports:
134,000 metric tons (2020 est.)
imports:
10.607 million metric tons (2020 est.)
proven reserves:
1.181 billion metric tons (2019 est.)
Petroleum:
total petroleum production:
11,900 bbl/day (2021 est.)
refined petroleum consumption:
361,700 bbl/day (2019 est.)
crude oil and lease condensate exports:
0 bbl/day (2018 est.)
crude oil and lease condensate imports:
172,700 bbl/day (2018 est.)
crude oil estimated reserves:
150 million barrels (2021 est.)
Refined petroleum products - production:
216,200 bbl/day (2017 est.)
comparison ranking:
49
Refined petroleum products - exports:
7,359 bbl/day (2017 est.)
comparison ranking:
87
Refined petroleum products - imports:
166,400 bbl/day (2017 est.)
comparison ranking:
38
Natural gas:
production:
1,109,962,000 cubic meters (2020 est.)
consumption:
6,558,312,000 cubic meters (2020 est.)
exports:
0 cubic meters (2021 est.)
imports:
4,602,471,000 cubic meters (2020 est.)
proven reserves:
97.976 billion cubic meters (2021 est.)
Carbon dioxide emissions:
88.333 million metric tonnes of CO2 (2019 est.)
from coal and metallurgical coke:
24.217 million metric tonnes of CO2 (2019 est.)
from petroleum and other liquids:
51.228 million metric tonnes of CO2 (2019 est.)
from consumed natural gas:
12.888 million metric tonnes of CO2 (2019 est.)
comparison ranking:
total emissions 47
Energy consumption per capita:
81.953 million Btu/person (2019 est.)
comparison ranking:
72','988238a811b10a775a1637959d9462c472c656613be1f9fddf998442e93386b3','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2e4bc0596aea510fe49a806bca01475443d5ec7f7fb285e9163c8692a56e2301',2025,'CN','China','energy',31,'Electricity access:
electrification - total population:
100% (2021)
Electricity:
installed generating capacity:
2,217,925,000 kW (2020 est.)
consumption:
6,875,088,640,000 kWh (2019 est.)
exports:
21.655 billion kWh (2019 est.)
imports:
4.858 billion kWh (2019 est.)
transmission/distribution losses:
333.01 billion kWh (2019 est.)
comparison rankings:
installed generating capacity 1; transmission/distribution losses 1; imports 41; exports 12; consumption 1
Electricity generation sources:
fossil fuels:
66% of total installed capacity (2020 est.)
nuclear:
4.8% of total installed capacity (2020 est.)
solar:
3.5% of total installed capacity (2020 est.)
wind:
6.2% of total installed capacity (2020 est.)
hydroelectricity:
17.8% of total installed capacity (2020 est.)
tide and wave:
0% of total installed capacity (2020 est.)
geothermal:
0% of total installed capacity (2020 est.)
biomass and waste:
1.6% of total installed capacity (2020 est.)
Nuclear energy: Number of operational nuclear reactors:
55 (2023)
Number of nuclear reactors under construction:
21
Net capacity of operational nuclear reactors:
53.18GW (2021)
Percent of total electricity production:
5.02% (2021)
Percent of total energy produced:
3% (2021)
Number of nuclear reactors permanently shut down:
0
Coal:
production:
4,314,681,000 metric tons (2020 est.)
consumption:
4,506,387,000 metric tons (2020 est.)
exports:
6.652 million metric tons (2020 est.)
imports:
307.047 million metric tons (2020 est.)
proven reserves:
141.595 billion metric tons (2019 est.)
Petroleum:
total petroleum production:
4,712,200 bbl/day (2021 est.)
refined petroleum consumption:
14,007,500 bbl/day (2019 est.)
crude oil and lease condensate exports:
52,500 bbl/day (2018 est.)
crude oil and lease condensate imports:
9,238,100 bbl/day (2018 est.)
crude oil estimated reserves:
26,022,600,000 barrels (2021 est.)
Refined petroleum products - production:
11.51 million bbl/day (2015 est.)
comparison ranking:
2
Refined petroleum products - exports:
848,400 bbl/day (2015 est.)
comparison ranking:
9
Refined petroleum products - imports:
1.16 million bbl/day (2015 est.)
comparison ranking:
4
Natural gas:
production:
179,317,495,000 cubic meters (2019 est.)
consumption:
306,576,649,000 cubic meters (2019 est.)
exports:
3,548,831,000 cubic meters (2019 est.)
imports:
131,608,161,000 cubic meters (2019 est.)
proven reserves:
6,654,250,000,000 cubic meters (2021 est.)
Carbon dioxide emissions:
10,773,248,000 metric tonnes of CO2 (2019 est.)
from coal and metallurgical coke:
8,652,419,000 metric tonnes of CO2 (2019 est.)
from petroleum and other liquids:
1,520,552,000 metric tonnes of CO2 (2019 est.)
from consumed natural gas:
600.276 million metric tonnes of CO2 (2019 est.)
comparison ranking:
total emissions 1
Energy consumption per capita:
105.687 million Btu/person (2019 est.)
comparison ranking:
54','5fb15f7e9374df55945217825867505e5756b8782671143dabed62c242bda7be','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3e3b2006c5761ee917713115318551ab807a8a12bb7ca73fdc4855c25baba50c',2025,'CO','Colombia','energy',71,'Electricity access:
population without electricity:
2 million (2020)
electrification - total population:
99.9% (2021)
electrification - urban areas:
100% (2021)
electrification - rural areas:
99.9% (2021)
Electricity:
installed generating capacity:
19.769 million kW (2020 est.)
consumption:
69,856,680,000 kWh (2019 est.)
exports:
251 million kWh (2020 est.)
imports:
1.302 billion kWh (2020 est.)
transmission/distribution losses:
5.724 billion kWh (2019 est.)
comparison rankings:
imports 68; exports 86; installed generating capacity 48; transmission/distribution losses 44; consumption 42
Electricity generation sources:
fossil fuels:
32.9% of total installed capacity (2020 est.)
solar:
0.3% of total installed capacity (2020 est.)
wind:
0.1% of total installed capacity (2020 est.)
hydroelectricity:
65.7% of total installed capacity (2020 est.)
biomass and waste:
1% of total installed capacity (2020 est.)
Coal:
production:
51.395 million metric tons (2020 est.)
consumption:
8.547 million metric tons (2020 est.)
exports:
69.861 million metric tons (2020 est.)
imports:
79,000 metric tons (2020 est.)
proven reserves:
4.554 billion metric tons (2019 est.)
Petroleum:
total petroleum production:
756,400 bbl/day (2021 est.)
refined petroleum consumption:
352,400 bbl/day (2019 est.)
crude oil and lease condensate exports:
481,300 bbl/day (2018 est.)
crude oil and lease condensate imports:
0 bbl/day (2018 est.)
crude oil estimated reserves:
2.036 billion barrels (2021 est.)
Refined petroleum products - production:
303,600 bbl/day (2015 est.)
comparison ranking:
41
Refined petroleum products - exports:
56,900 bbl/day (2015 est.)
comparison ranking:
52
Refined petroleum products - imports:
57,170 bbl/day (2015 est.)
comparison ranking:
74
Natural gas:
production:
11,305,086,000 cubic meters (2020 est.)
consumption:
11,708,232,000 cubic meters (2020 est.)
exports:
0 cubic meters (2020 est.)
imports:
403.146 million cubic meters (2020 est.)
proven reserves:
87.782 billion cubic meters (2021 est.)
Carbon dioxide emissions:
81.007 million metric tonnes of CO2 (2019 est.)
from coal and metallurgical coke:
12.666 million metric tonnes of CO2 (2019 est.)
from petroleum and other liquids:
47.679 million metric tonnes of CO2 (2019 est.)
from consumed natural gas:
20.662 million metric tonnes of CO2 (2019 est.)
comparison ranking:
total emissions 48
Energy consumption per capita:
34.703 million Btu/person (2019 est.)
comparison ranking:
116','5f0d413a6fa9dd541d708272eb5300ce3516634e249cddf75cbe6e8429bbec82','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1f7eae86a2cfb6e6412f01525361bd904ba62993abd9d753280c8ca45054bfa1',2025,'KM','Comoros','energy',7,'Electricity access:
population without electricity:
(2020) less than 1 million
electrification - total population:
87.9% (2021)
electrification - urban areas:
100% (2021)
electrification - rural areas:
82.8% (2021)
Electricity:
installed generating capacity:
35,000 kW (2020 est.)
consumption:
96.248 million kWh (2019 est.)
exports:
0 kWh (2019 est.)
imports:
0 kWh (2019 est.)
transmission/distribution losses:
6.048 million kWh (2019 est.)
comparison rankings:
installed generating capacity 199; transmission/distribution losses 199; imports 203; exports 203; consumption 195
Electricity generation sources:
fossil fuels:
100% of total installed capacity (2020 est.)
Petroleum:
total petroleum production:
0 bbl/day (2021 est.)
refined petroleum consumption:
2,200 bbl/day (2019 est.)
Refined petroleum products - imports:
1,241 bbl/day (2015 est.)
comparison ranking:
197
Carbon dioxide emissions:
326,000 metric tonnes of CO2 (2019 est.)
from petroleum and other liquids:
326,000 metric tonnes of CO2 (2019 est.)
comparison ranking:
total emissions 195
Energy consumption per capita:
5.346 million Btu/person (2019 est.)
comparison ranking:
170','52598d049e32033f92766b4b62a55be68e54565620e7d1e3d47b1a9371e196f0','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('65a39b86a904b6c0ee02f1813051daee2908009e4e3283136a3cc1e0881ec7c2',2025,'KM','Comoros','energy',18,'Electricity access:
population without electricity:
82 million (2020)
electrification - total population:
20.7% (2021)
electrification - urban areas:
43.7% (2021)
electrification - rural areas:
1% (2021)
Electricity:
installed generating capacity:
2.919 million kW (2020 est.)
consumption:
7,181,700,000 kWh (2019 est.)
exports:
248 million kWh (2019 est.)
imports:
385 million kWh (2019 est.)
transmission/distribution losses:
2.142 billion kWh (2019 est.)
comparison rankings:
installed generating capacity 110; transmission/distribution losses 87; imports 93; exports 87; consumption 110
Electricity generation sources:
fossil fuels:
0.1% of total installed capacity (2020 est.)
solar:
0.1% of total installed capacity (2020 est.)
hydroelectricity:
99.6% of total installed capacity (2020 est.)
biomass and waste:
0.3% of total installed capacity (2020 est.)
Coal:
production:
0 metric tons (2020 est.)
consumption:
10,000 metric tons (2020 est.)
exports:
0 metric tons (2020 est.)
imports:
10,000 metric tons (2020 est.)
proven reserves:
88 million metric tons (2019 est.)
Petroleum:
total petroleum production:
22,000 bbl/day (2021 est.)
refined petroleum consumption:
17,900 bbl/day (2019 est.)
crude oil and lease condensate exports:
21,300 bbl/day (2018 est.)
crude oil and lease condensate imports:
0 bbl/day (2018 est.)
crude oil estimated reserves:
180 million barrels (2021 est.)
Refined petroleum products - production:
0 bbl/day (2017 est.)
comparison ranking:
127
Refined petroleum products - exports:
0 bbl/day (2015 est.)
comparison ranking:
130
Refined petroleum products - imports:
21,140 bbl/day (2015 est.)
comparison ranking:
115
Natural gas:
production:
368,000 cubic meters (2019 est.)
consumption:
368,000 cubic meters (2019 est.)
exports:
0 cubic meters (2021 est.)
imports:
0 cubic meters (2021 est.)
proven reserves:
991 million cubic meters (2021 est.)
Carbon dioxide emissions:
2.653 million metric tonnes of CO2 (2019 est.)
from coal and metallurgical coke:
44,000 metric tonnes of CO2 (2019 est.)
from petroleum and other liquids:
2.608 million metric tonnes of CO2 (2019 est.)
from consumed natural gas:
1,000 metric tonnes of CO2 (2019 est.)
comparison ranking:
total emissions 151
Energy consumption per capita:
1.371 million Btu/person (2019 est.)
comparison ranking:
192','011d7683f977530702958ce7cad57c62c0f2be882cf05a2fff25c734d678a93f','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('37eee731ab23c5b5cf9e95db4818dbcae809778a59f6333961b691bdcc770e20',2025,'KM','Comoros','energy',30,'Electricity access:
population without electricity:
3 million (2020)
electrification - total population:
49.6% (2021)
electrification - urban areas:
66.9% (2021)
electrification - rural areas:
12.3% (2021)
Electricity:
installed generating capacity:
629,000 kW (2020 est.)
consumption:
2,065,580,000 kWh (2019 est.)
exports:
44 million kWh (2019 est.)
imports:
23 million kWh (2019 est.)
transmission/distribution losses:
1.623 billion kWh (2019 est.)
comparison rankings:
installed generating capacity 144; transmission/distribution losses 94; imports 114; exports 93; consumption 147
Electricity generation sources:
fossil fuels:
70.1% of total installed capacity (2020 est.)
hydroelectricity:
29.9% of total installed capacity (2020 est.)
Petroleum:
total petroleum production:
270,900 bbl/day (2021 est.)
refined petroleum consumption:
12,600 bbl/day (2019 est.)
crude oil and lease condensate exports:
331,700 bbl/day (2018 est.)
crude oil and lease condensate imports:
0 bbl/day (2018 est.)
crude oil estimated reserves:
2.882 billion barrels (2021 est.)
Refined petroleum products - production:
15,760 bbl/day (2015 est.)
comparison ranking:
93
Refined petroleum products - exports:
5,766 bbl/day (2015 est.)
comparison ranking:
89
Refined petroleum products - imports:
7,162 bbl/day (2015 est.)
comparison ranking:
156
Natural gas:
production:
1.4 billion cubic meters (2019 est.)
consumption:
1.4 billion cubic meters (2019 est.)
proven reserves:
283.989 billion cubic meters (2021 est.)
Carbon dioxide emissions:
4.523 million metric tonnes of CO2 (2019 est.)
from petroleum and other liquids:
1.777 million metric tonnes of CO2 (2019 est.)
from consumed natural gas:
2.747 million metric tonnes of CO2 (2019 est.)
comparison ranking:
total emissions 138
Energy consumption per capita:
16.156 million Btu/person (2019 est.)
comparison ranking:
139','fb15f49f19839ba8789e55049a891f9c730fd6b39f00f6113a0d4f6df76f3008','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('adef4a86ff00edf6240f3c5ed645ce2c0a7d4a14521063ce617e6e574d60ea70',2025,'CK','Cook Islands','energy',41,'Electricity:
installed generating capacity:
18,000 kW (2020 est.)
consumption:
38.729 million kWh (2019 est.)
exports:
0 kWh (2020 est.)
imports:
0 kWh (2020 est.)
transmission/distribution losses:
3 million kWh (2019 est.)
comparison rankings:
imports 189; exports 184; installed generating capacity 205; transmission/distribution losses 204; consumption 203
Electricity generation sources:
fossil fuels:
70% of total installed capacity (2020 est.)
solar:
30% of total installed capacity (2020 est.)
Petroleum:
total petroleum production:
0 bbl/day (2021 est.)
refined petroleum consumption:
800 bbl/day (2019 est.)
Refined petroleum products - imports:
611 bbl/day (2015 est.)
comparison ranking:
204
Carbon dioxide emissions:
114,000 metric tonnes of CO2 (2019 est.)
from petroleum and other liquids:
114,000 metric tonnes of CO2 (2019 est.)
comparison ranking:
total emissions 208
Energy consumption per capita:
0 Btu/person (2019 est.)
comparison ranking:
197','d3888c6981af056c1882f51ad167fff4e16ddd3878039291f36ae40a9066c3ba','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('00d11ab34a4d526132123cf2231443f8a8a1688a6efae0e78dc6b9eb4cb933a1',2025,'CR','Costa Rica','energy',61,'Electricity access:
electrification - total population:
100% (2021)
Electricity:
installed generating capacity:
3.674 million kW (2020 est.)
consumption:
10,072,472,000 kWh (2019 est.)
exports:
712 million kWh (2019 est.)
imports:
733 million kWh (2019 est.)
transmission/distribution losses:
1,321,498,000 kWh (2019 est.)
comparison rankings:
installed generating capacity 100; transmission/distribution losses 102; imports 79; exports 67; consumption 101
Electricity generation sources:
fossil fuels:
0.2% of total installed capacity (2020 est.)
solar:
0.6% of total installed capacity (2020 est.)
wind:
12.5% of total installed capacity (2020 est.)
hydroelectricity:
71.1% of total installed capacity (2020 est.)
geothermal:
14.5% of total installed capacity (2020 est.)
biomass and waste:
1.2% of total installed capacity (2020 est.)
Petroleum:
total petroleum production:
400 bbl/day (2021 est.)
refined petroleum consumption:
63,300 bbl/day (2019 est.)
crude oil estimated reserves:
0 barrels (2021 est.)
Refined petroleum products - imports:
51,320 bbl/day (2015 est.)
comparison ranking:
80
Carbon dioxide emissions:
8.115 million metric tonnes of CO2 (2019 est.)
from coal and metallurgical coke:
1,000 metric tonnes of CO2 (2019 est.)
from petroleum and other liquids:
8.114 million metric tonnes of CO2 (2019 est.)
comparison ranking:
total emissions 111
Energy consumption per capita:
44.899 million Btu/person (2019 est.)
comparison ranking:
103','8583d80a93c035fb77c569b32478d379372b163dd3f42e11f3ad05da84d1341f','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('82a251e8dde545ea906fb4f31ae5c71031f7ddb43eb90c756b86206aa45285fc',2025,'CR','Costa Rica','energy',73,'Electricity access:
population without electricity:
6 million (2020)
electrification - total population:
71.1% (2021)
electrification - urban areas:
94.9% (2021)
electrification - rural areas:
45.1% (2021)
Electricity:
installed generating capacity:
2.197 million kW (2020 est.)
consumption:
5,924,320,000 kWh (2019 est.)
exports:
1.178 billion kWh (2019 est.)
imports:
172 million kWh (2019 est.)
transmission/distribution losses:
1.957 billion kWh (2019 est.)
comparison rankings:
installed generating capacity 117; transmission/distribution losses 88; imports 104; exports 57; consumption 118
Electricity generation sources:
fossil fuels:
75.6% of total installed capacity (2020 est.)
solar:
0.2% of total installed capacity (2020 est.)
hydroelectricity:
24.2% of total installed capacity (2020 est.)
Petroleum:
total petroleum production:
33,000 bbl/day (2021 est.)
refined petroleum consumption:
56,500 bbl/day (2019 est.)
crude oil and lease condensate exports:
30,200 bbl/day (2018 est.)
crude oil and lease condensate imports:
69,200 bbl/day (2018 est.)
crude oil estimated reserves:
100 million barrels (2021 est.)
Refined petroleum products - production:
69,360 bbl/day (2017 est.)
comparison ranking:
72
Refined petroleum products - exports:
31,450 bbl/day (2015 est.)
comparison ranking:
61
Refined petroleum products - imports:
7,405 bbl/day (2015 est.)
comparison ranking:
154
Natural gas:
production:
2.425 billion cubic meters (2019 est.)
consumption:
2.425 billion cubic meters (2019 est.)
proven reserves:
28.317 billion cubic meters (2021 est.)
Carbon dioxide emissions:
11.88 million metric tonnes of CO2 (2019 est.)
from coal and metallurgical coke:
0 metric tonnes of CO2 (2019 est.)
from petroleum and other liquids:
7.332 million metric tonnes of CO2 (2019 est.)
from consumed natural gas:
4.548 million metric tonnes of CO2 (2019 est.)
comparison ranking:
total emissions 100
Energy consumption per capita:
8.225 million Btu/person (2019 est.)
comparison ranking:
161','a8b7a12856f95d465b0e11bb275a3a5276ae2c17ecae2556f04611f37f876ff4','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b2a762c3e01c1b0d3fd26a3bdddfeec556574a4beaf7644ae32952f15d965a67',2025,'HR','Croatia','energy',7,'Electricity access:
electrification - total population:
100% (2021)
Electricity:
installed generating capacity:
4.94 million kW (2020 est.)
consumption:
16,790,680,000 kWh (2019 est.)
exports:
5.852 billion kWh (2020 est.)
imports:
10.491 billion kWh (2020 est.)
transmission/distribution losses:
1.659 billion kWh (2019 est.)
comparison rankings:
imports 23; exports 34; installed generating capacity 88; transmission/distribution losses 93; consumption 76
Electricity generation sources:
fossil fuels:
41% of total installed capacity (2020 est.)
solar:
0.9% of total installed capacity (2020 est.)
wind:
16.1% of total installed capacity (2020 est.)
hydroelectricity:
31.8% of total installed capacity (2020 est.)
geothermal:
0.9% of total installed capacity (2020 est.)
biomass and waste:
9.3% of total installed capacity (2020 est.)
Coal:
production:
0 metric tons (2020 est.)
consumption:
643,000 metric tons (2020 est.)
exports:
2,000 metric tons (2020 est.)
imports:
644,000 metric tons (2020 est.)
proven reserves:
0 metric tons (2019 est.)
Petroleum:
total petroleum production:
12,200 bbl/day (2021 est.)
refined petroleum consumption:
71,500 bbl/day (2019 est.)
crude oil and lease condensate exports:
0 bbl/day (2018 est.)
crude oil and lease condensate imports:
65,200 bbl/day (2018 est.)
crude oil estimated reserves:
71 million barrels (2021 est.)
Refined petroleum products - production:
74,620 bbl/day (2015 est.)
comparison ranking:
70
Refined petroleum products - exports:
40,530 bbl/day (2015 est.)
comparison ranking:
58
Refined petroleum products - imports:
35,530 bbl/day (2015 est.)
comparison ranking:
94
Natural gas:
production:
851.005 million cubic meters (2020 est.)
consumption:
3,009,113,000 cubic meters (2020 est.)
exports:
34.462 million cubic meters (2020 est.)
imports:
2,131,802,000 cubic meters (2020 est.)
proven reserves:
24.919 billion cubic meters (2021 est.)
Carbon dioxide emissions:
16.752 million metric tonnes of CO2 (2019 est.)
from coal and metallurgical coke:
1.674 million metric tonnes of CO2 (2019 est.)
from petroleum and other liquids:
9.4 million metric tonnes of CO2 (2019 est.)
from consumed natural gas:
5.678 million metric tonnes of CO2 (2019 est.)
comparison ranking:
total emissions 93
Energy consumption per capita:
89.733 million Btu/person (2019 est.)
comparison ranking:
64','3831ab004a394be269b1aaf375ef9204d43a88507319b4fd49d4818cebe973de','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('98186e697dc381e814e23a39b478650bc2da2594a976a7c0f7fd90634e34da27',2025,'CU','Cuba','energy',18,'Electricity access:
electrification - total population:
100% (2021)
Electricity:
installed generating capacity:
7.479 million kW (2020 est.)
consumption:
16,097,460,000 kWh (2019 est.)
exports:
0 kWh (2020 est.)
imports:
0 kWh (2020 est.)
transmission/distribution losses:
3.429 billion kWh (2019 est.)
comparison rankings:
imports 167; exports 159; installed generating capacity 75; transmission/distribution losses 60; consumption 79
Electricity generation sources:
fossil fuels:
95.5% of total installed capacity (2020 est.)
solar:
1.4% of total installed capacity (2020 est.)
wind:
0.1% of total installed capacity (2020 est.)
hydroelectricity:
0.3% of total installed capacity (2020 est.)
biomass and waste:
2.7% of total installed capacity (2020 est.)
Coal:
production:
0 metric tons (2020 est.)
consumption:
4,000 metric tons (2020 est.)
exports:
0 metric tons (2020 est.)
imports:
4,000 metric tons (2020 est.)
proven reserves:
0 metric tons (2019 est.)
Petroleum:
total petroleum production:
38,400 bbl/day (2021 est.)
refined petroleum consumption:
164,100 bbl/day (2019 est.)
crude oil and lease condensate exports:
0 bbl/day (2018 est.)
crude oil and lease condensate imports:
48,500 bbl/day (2018 est.)
crude oil estimated reserves:
124 million barrels (2021 est.)
Refined petroleum products - production:
104,100 bbl/day (2015 est.)
comparison ranking:
67
Refined petroleum products - exports:
24,190 bbl/day (2015 est.)
comparison ranking:
69
Refined petroleum products - imports:
52,750 bbl/day (2015 est.)
comparison ranking:
78
Natural gas:
production:
976.023 million cubic meters (2019 est.)
consumption:
976.023 million cubic meters (2019 est.)
proven reserves:
70.792 billion cubic meters (2021 est.)
Carbon dioxide emissions:
16.478 million metric tonnes of CO2 (2019 est.)
from coal and metallurgical coke:
28,000 metric tonnes of CO2 (2019 est.)
from petroleum and other liquids:
14.636 million metric tonnes of CO2 (2019 est.)
from consumed natural gas:
1.814 million metric tonnes of CO2 (2019 est.)
comparison ranking:
total emissions 94
Energy consumption per capita:
32.785 million Btu/person (2019 est.)
comparison ranking:
119','6d7083a297355cebf67753dc763680ed3a3a83dcbe25cb2277e49b5782559308','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('df72c2a4b298cbde4f11bcf419c602d2546feecc6f5ed098fb54483276e3ecfe',2025,'CU','Cuba','energy',29,'Electricity access:
electrification - total population:
100% (2020)
Refined petroleum products - production:
189,800 bbl/day (2015 est.)
comparison ranking:
53
Refined petroleum products - exports:
167,500 bbl/day (2015 est.)
comparison ranking:
33
Refined petroleum products - imports:
45,800 bbl/day (2015 est.)
comparison ranking:
85','e65d93a959690c179288421ad38e2b2977160da303765ab53c1d31afb75b8808','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1d035f2ec25c406e737b99f6b5efa984c632e8f7cae6618fae728a987486a0f6',2025,'CY','Cyprus','energy',40,'Electricity access:
electrification - total population:
100% (2021)
Electricity:
installed generating capacity:
1.881 million kW (2020 est.)
consumption:
4.733 billion kWh (2019 est.)
exports:
0 kWh (2019 est.)
imports:
0 kWh (2019 est.)
transmission/distribution losses:
184 million kWh (2019 est.)
comparison rankings:
installed generating capacity 121; transmission/distribution losses 148; imports 176; exports 167; consumption 127
Electricity generation sources:
fossil fuels:
86.8% of total installed capacity (2020 est.)
solar:
6.9% of total installed capacity (2020 est.)
wind:
5.1% of total installed capacity (2020 est.)
biomass and waste:
1.3% of total installed capacity (2020 est.)
Petroleum:
total petroleum production:
0 bbl/day (2021 est.)
refined petroleum consumption:
54,400 bbl/day (2019 est.)
Refined petroleum products - exports:
500 bbl/day (2015 est.)
comparison ranking:
110
Refined petroleum products - imports:
49,240 bbl/day (2015 est.)
comparison ranking:
84
Carbon dioxide emissions:
8.024 million metric tonnes of CO2 (2019 est.)
from petroleum and other liquids:
8.024 million metric tonnes of CO2 (2019 est.)
comparison ranking:
total emissions 113
Energy consumption per capita:
133.92 million Btu/person (2019 est.)
comparison ranking:
40','75eda7e368310d01bffe1f25b5e7fa50edf5753d3e2cc18e2881fe5d458f673c','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('93e771ad109f0a68a865269278467d9d73f9d0c69db3f2135ef703bb52763b13',2025,'CZ','Czechia','energy',52,'Electricity access:
electrification - total population:
100% (2021)
Electricity:
installed generating capacity:
22.485 million kW (2020 est.)
consumption:
60.814 billion kWh (2020 est.)
exports:
23.521 billion kWh (2020 est.)
imports:
13.368 billion kWh (2020 est.)
transmission/distribution losses:
4.117 billion kWh (2020 est.)
comparison rankings:
transmission/distribution losses 54; imports 18; exports 9; consumption 45; installed generating capacity 42
Electricity generation sources:
fossil fuels:
47% of total installed capacity (2020 est.)
nuclear:
37.6% of total installed capacity (2020 est.)
solar:
3% of total installed capacity (2020 est.)
wind:
0.9% of total installed capacity (2020 est.)
hydroelectricity:
4.5% of total installed capacity (2020 est.)
biomass and waste:
7% of total installed capacity (2020 est.)
Nuclear energy: Number of operational nuclear reactors:
6 (2023)
Number of nuclear reactors under construction:
0
Net capacity of operational nuclear reactors:
3.93GW (2023)
Percent of total electricity production:
36.7% (2021)
Percent of total energy produced:
38.3% (2021)
Number of nuclear reactors permanently shut down:
0
Coal:
production:
33.806 million metric tons (2020 est.)
consumption:
37.212 million metric tons (2020 est.)
exports:
1.885 million metric tons (2020 est.)
imports:
3.795 million metric tons (2020 est.)
proven reserves:
2.927 billion metric tons (2019 est.)
Petroleum:
total petroleum production:
6,300 bbl/day (2021 est.)
refined petroleum consumption:
219,500 bbl/day (2019 est.)
crude oil and lease condensate exports:
400 bbl/day (2018 est.)
crude oil and lease condensate imports:
150,200 bbl/day (2018 est.)
crude oil estimated reserves:
15 million barrels (2021 est.)
Refined petroleum products - production:
177,500 bbl/day (2017 est.)
comparison ranking:
56
Refined petroleum products - exports:
52,200 bbl/day (2017 est.)
comparison ranking:
54
Refined petroleum products - imports:
83,860 bbl/day (2017 est.)
comparison ranking:
60
Natural gas:
production:
189.185 million cubic meters (2020 est.)
consumption:
8,815,133,000 cubic meters (2020 est.)
exports:
0 cubic meters (2020 est.)
imports:
7,590,318,000 cubic meters (2020 est.)
proven reserves:
3.964 billion cubic meters (2021 est.)
Carbon dioxide emissions:
99.533 million metric tonnes of CO2 (2019 est.)
from coal and metallurgical coke:
57.268 million metric tonnes of CO2 (2019 est.)
from petroleum and other liquids:
25.526 million metric tonnes of CO2 (2019 est.)
from consumed natural gas:
16.739 million metric tonnes of CO2 (2019 est.)
comparison ranking:
total emissions 43
Energy consumption per capita:
161.972 million Btu/person (2019 est.)
comparison ranking:
30','c6895c927dffc5e4c8f85c2e9ee1f350e34edc59ce044c356d3a58b2aaaad48e','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('11956847275fc6df5d220ee6764e6d370d8711d549699d9981375089e1260e3e',2025,'DK','Denmark','energy',7,'Electricity access:
electrification - total population:
100% (2021)
Electricity:
installed generating capacity:
17.655 million kW (2020 est.)
consumption:
33.081 billion kWh (2020 est.)
exports:
12.694 billion kWh (2020 est.)
imports:
18.891 billion kWh (2020 est.)
transmission/distribution losses:
1.573 billion kWh (2020 est.)
comparison rankings:
transmission/distribution losses 98; imports 14; exports 18; consumption 59; installed generating capacity 52
Electricity generation sources:
fossil fuels:
14.8% of total installed capacity (2020 est.)
solar:
4.2% of total installed capacity (2020 est.)
wind:
57.5% of total installed capacity (2020 est.)
hydroelectricity:
0.1% of total installed capacity (2020 est.)
biomass and waste:
23.5% of total installed capacity (2020 est.)
Coal:
production:
0 metric tons (2020 est.)
consumption:
1.249 million metric tons (2020 est.)
exports:
194,000 metric tons (2020 est.)
imports:
1.122 million metric tons (2020 est.)
proven reserves:
0 metric tons (2019 est.)
Petroleum:
total petroleum production:
69,000 bbl/day (2021 est.)
refined petroleum consumption:
165,400 bbl/day (2019 est.)
crude oil and lease condensate exports:
56,700 bbl/day (2018 est.)
crude oil and lease condensate imports:
95,200 bbl/day (2018 est.)
crude oil estimated reserves:
441 million barrels (2021 est.)
Refined petroleum products - production:
183,900 bbl/day (2017 est.)
comparison ranking:
55
Refined petroleum products - exports:
133,700 bbl/day (2017 est.)
comparison ranking:
38
Refined petroleum products - imports:
109,700 bbl/day (2017 est.)
comparison ranking:
51
Natural gas:
production:
1.315 billion cubic meters (2020 est.)
consumption:
2.188 billion cubic meters (2020 est.)
exports:
1.701 billion cubic meters (2020 est.)
imports:
2.646 billion cubic meters (2020 est.)
proven reserves:
29.534 billion cubic meters (2021 est.)
Carbon dioxide emissions:
33.85 million metric tonnes of CO2 (2019 est.)
from coal and metallurgical coke:
3.455 million metric tonnes of CO2 (2019 est.)
from petroleum and other liquids:
24.621 million metric tonnes of CO2 (2019 est.)
from consumed natural gas:
5.775 million metric tonnes of CO2 (2019 est.)
comparison ranking:
total emissions 73
Energy consumption per capita:
124.163 million Btu/person (2019 est.)
comparison ranking:
43','344b5e5076560e1f797da33afff03e52984173dd5fbbd647a3fed84e9271715d','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('72afb5aaa2e1ac4bf8dfddb30bc3cf8e6965f4c106126654a258975e105a1840',2025,'DJ','Djibouti','energy',28,'Electricity access:
population without electricity:
(2020) less than 1 million
electrification - total population:
65.4% (2021)
electrification - urban areas:
73.4% (2019)
electrification - rural areas:
36.5% (2021)
Electricity:
installed generating capacity:
130,000 kW (2020 est.)
consumption:
-62.6 million kWh (2019 est.)
exports:
0 kWh (2019 est.)
imports:
0 kWh (2019 est.)
transmission/distribution losses:
120 million kWh (2019 est.)
comparison rankings:
installed generating capacity 179; transmission/distribution losses 158; imports 144; exports 127; consumption 212
Electricity generation sources:
fossil fuels:
98.2% of total installed capacity (2020 est.)
solar:
1.8% of total installed capacity (2020 est.)
Petroleum:
total petroleum production:
0 bbl/day (2021 est.)
refined petroleum consumption:
4,300 bbl/day (2019 est.)
Refined petroleum products - exports:
403 bbl/day (2015 est.)
comparison ranking:
112
Refined petroleum products - imports:
6,692 bbl/day (2015 est.)
comparison ranking:
161
Carbon dioxide emissions:
610,000 metric tonnes of CO2 (2019 est.)
from petroleum and other liquids:
610,000 metric tonnes of CO2 (2019 est.)
comparison ranking:
total emissions 185
Energy consumption per capita:
8.869 million Btu/person (2019 est.)
comparison ranking:
158','5aad5c5001c8247626fdc5281fea90936462031dece796378515514f59a4493a','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ca2a2a1bb2fa55d2f6dff9d67fd5ee64f5facf910774f0a3c638692de2728b29',2025,'DM','Dominica','energy',40,'Electricity access:
electrification - total population:
100% (2021)
Electricity:
installed generating capacity:
42,000 kW (2020 est.)
consumption:
82.078 million kWh (2019 est.)
exports:
0 kWh (2019 est.)
imports:
0 kWh (2019 est.)
transmission/distribution losses:
8.1 million kWh (2019 est.)
comparison rankings:
installed generating capacity 195; transmission/distribution losses 197; imports 136; exports 119; consumption 197
Electricity generation sources:
fossil fuels:
74.8% of total installed capacity (2020 est.)
solar:
0.1% of total installed capacity (2020 est.)
wind:
0.6% of total installed capacity (2020 est.)
hydroelectricity:
24.5% of total installed capacity (2020 est.)
Petroleum:
total petroleum production:
0 bbl/day (2021 est.)
refined petroleum consumption:
1,200 bbl/day (2019 est.)
Refined petroleum products - imports:
1,237 bbl/day (2015 est.)
comparison ranking:
198
Carbon dioxide emissions:
182,000 metric tonnes of CO2 (2019 est.)
from petroleum and other liquids:
182,000 metric tonnes of CO2 (2019 est.)
comparison ranking:
total emissions 203
Energy consumption per capita:
37.513 million Btu/person (2019 est.)
comparison ranking:
111','a2ee3dd4aeb344e611353b9d52e302027a8e30e1fd3fefb3ad7ac937048e860d','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7aaa398ac700d207ebae7d833cc1cd209104525795afbfb0ecb3f7ba776e5812',2025,'DO','Dominican Republic','energy',51,'Electricity access:
population without electricity:
(2020) less than 1 million
electrification - total population:
98.1% (2021)
electrification - urban areas:
98.7% (2021)
electrification - rural areas:
94.8% (2021)
Electricity:
installed generating capacity:
5.674 million kW (2020 est.)
consumption:
16,330,980,000 kWh (2019 est.)
exports:
0 kWh (2019 est.)
imports:
0 kWh (2019 est.)
transmission/distribution losses:
2.576 billion kWh (2019 est.)
comparison rankings:
installed generating capacity 82; transmission/distribution losses 74; imports 198; exports 197; consumption 78
Electricity generation sources:
fossil fuels:
93.4% of total installed capacity (2020 est.)
solar:
1.5% of total installed capacity (2020 est.)
wind:
3.2% of total installed capacity (2020 est.)
hydroelectricity:
0.7% of total installed capacity (2020 est.)
biomass and waste:
1.2% of total installed capacity (2020 est.)
Coal:
production:
0 metric tons (2020 est.)
consumption:
1.791 million metric tons (2020 est.)
exports:
0 metric tons (2020 est.)
imports:
2.359 million metric tons (2020 est.)
proven reserves:
0 metric tons (2019 est.)
Petroleum:
total petroleum production:
0 bbl/day (2021 est.)
refined petroleum consumption:
148,200 bbl/day (2019 est.)
crude oil and lease condensate exports:
0 bbl/day (2018 est.)
crude oil and lease condensate imports:
24,900 bbl/day (2018 est.)
crude oil estimated reserves:
0 barrels (2021 est.)
Refined petroleum products - production:
16,060 bbl/day (2015 est.)
comparison ranking:
92
Refined petroleum products - exports:
0 bbl/day (2015 est.)
comparison ranking:
206
Refined petroleum products - imports:
108,500 bbl/day (2015 est.)
comparison ranking:
52
Natural gas:
production:
0 cubic meters (2021 est.)
consumption:
1,602,759,000 cubic meters (2019 est.)
exports:
28.657 million cubic meters (2019 est.)
imports:
1,586,449,000 cubic meters (2019 est.)
proven reserves:
0 cubic meters (2021 est.)
Carbon dioxide emissions:
26.808 million metric tonnes of CO2 (2019 est.)
from coal and metallurgical coke:
4.713 million metric tonnes of CO2 (2019 est.)
from petroleum and other liquids:
18.951 million metric tonnes of CO2 (2019 est.)
from consumed natural gas:
3.144 million metric tonnes of CO2 (2019 est.)
comparison ranking:
total emissions 77
Energy consumption per capita:
39.016 million Btu/person (2019 est.)
comparison ranking:
109','b3bdb391ad5e60fffb5c606da980a64bfa24e8adaa9d893b90df8f5d1f02570d','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f9e9c60404de242431409f0b9505060e3d80fdaf385c25b418d875bbf37ea454',2025,'EC','Ecuador','energy',7,'Electricity access:
electrification - total population:
100% (2021)
Electricity:
installed generating capacity:
9.354 million kW (2020 est.)
consumption:
26,353,430,000 kWh (2019 est.)
exports:
1.826 billion kWh (2019 est.)
imports:
6 million kWh (2019 est.)
transmission/distribution losses:
4.303 billion kWh (2019 est.)
comparison rankings:
installed generating capacity 67; transmission/distribution losses 52; imports 118; exports 53; consumption 68
Electricity generation sources:
fossil fuels:
21% of total installed capacity (2020 est.)
solar:
0.1% of total installed capacity (2020 est.)
wind:
0.2% of total installed capacity (2020 est.)
hydroelectricity:
77.2% of total installed capacity (2020 est.)
biomass and waste:
1.5% of total installed capacity (2020 est.)
Coal:
production:
0 metric tons (2020 est.)
consumption:
10,000 metric tons (2020 est.)
exports:
0 metric tons (2020 est.)
imports:
10,000 metric tons (2020 est.)
proven reserves:
24 million metric tons (2019 est.)
Petroleum:
total petroleum production:
478,000 bbl/day (2021 est.)
refined petroleum consumption:
259,000 bbl/day (2019 est.)
crude oil and lease condensate exports:
349,400 bbl/day (2018 est.)
crude oil and lease condensate imports:
0 bbl/day (2018 est.)
crude oil estimated reserves:
8.273 billion barrels (2021 est.)
Refined petroleum products - production:
137,400 bbl/day (2015 est.)
comparison ranking:
62
Refined petroleum products - exports:
25,870 bbl/day (2015 est.)
comparison ranking:
66
Refined petroleum products - imports:
153,900 bbl/day (2015 est.)
comparison ranking:
40
Natural gas:
production:
342.407 million cubic meters (2019 est.)
consumption:
342.407 million cubic meters (2019 est.)
exports:
0 cubic meters (2021 est.)
imports:
0 cubic meters (2021 est.)
proven reserves:
10.902 billion cubic meters (2021 est.)
Carbon dioxide emissions:
36.051 million metric tonnes of CO2 (2019 est.)
from coal and metallurgical coke:
45,000 metric tonnes of CO2 (2019 est.)
from petroleum and other liquids:
35.329 million metric tonnes of CO2 (2019 est.)
from consumed natural gas:
677,000 metric tonnes of CO2 (2019 est.)
comparison ranking:
total emissions 70
Energy consumption per capita:
42.564 million Btu/person (2019 est.)
comparison ranking:
104','19064b4fab80772f589ffc7dd4cccaeb85322b2aed800cb1a41473494a3dcc96','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ef3e5ca0d3ee4189e1070873524c0d2b68fd204e5e3f7fda93492195538f4ca3',2025,'EG','Egypt','energy',19,'Electricity access:
electrification - total population:
100% (2021)
Electricity:
installed generating capacity:
59.826 million kW (2020 est.)
consumption:
149,079,120,000 kWh (2019 est.)
exports:
360 million kWh (2019 est.)
imports:
74 million kWh (2019 est.)
transmission/distribution losses:
33.623 billion kWh (2019 est.)
comparison rankings:
installed generating capacity 22; transmission/distribution losses 11; imports 111; exports 79; consumption 26
Electricity generation sources:
fossil fuels:
88.7% of total installed capacity (2020 est.)
solar:
1% of total installed capacity (2020 est.)
wind:
2.5% of total installed capacity (2020 est.)
hydroelectricity:
7.7% of total installed capacity (2020 est.)
biomass and waste:
0.2% of total installed capacity (2020 est.)
Nuclear energy: Number of operational nuclear reactors:
0
Number of nuclear reactors under construction:
3 (2023)
Net capacity of operational nuclear reactors:
0GW
Percent of total electricity production:
0%
Percent of total energy produced:
0%
Number of nuclear reactors permanently shut down:
0
Coal:
production:
262,000 metric tons (2020 est.)
consumption:
2.31 million metric tons (2020 est.)
exports:
86,000 metric tons (2020 est.)
imports:
2.134 million metric tons (2020 est.)
proven reserves:
16 million metric tons (2019 est.)
Petroleum:
total petroleum production:
660,800 bbl/day (2021 est.)
refined petroleum consumption:
810,200 bbl/day (2019 est.)
crude oil and lease condensate exports:
204,100 bbl/day (2018 est.)
crude oil and lease condensate imports:
117,400 bbl/day (2018 est.)
crude oil estimated reserves:
3.3 billion barrels (2021 est.)
Refined petroleum products - production:
547,500 bbl/day (2015 est.)
comparison ranking:
31
Refined petroleum products - exports:
47,360 bbl/day (2015 est.)
comparison ranking:
56
Refined petroleum products - imports:
280,200 bbl/day (2015 est.)
comparison ranking:
26
Natural gas:
production:
64,292,955,000 cubic meters (2019 est.)
consumption:
58,176,781,000 cubic meters (2019 est.)
exports:
5,009,100,000 cubic meters (2019 est.)
imports:
83.563 million cubic meters (2019 est.)
proven reserves:
1,783,958,000,000 cubic meters (2021 est.)
Carbon dioxide emissions:
235.137 million metric tonnes of CO2 (2019 est.)
from coal and metallurgical coke:
8.728 million metric tonnes of CO2 (2019 est.)
from petroleum and other liquids:
112.281 million metric tonnes of CO2 (2019 est.)
from consumed natural gas:
114.128 million metric tonnes of CO2 (2019 est.)
comparison ranking:
total emissions 29
Energy consumption per capita:
40.063 million Btu/person (2019 est.)
comparison ranking:
106','4a929374cfb9308100cfe5098cd42422161e1729f90e391970e3c792faefe24c','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2df08cfff1ef178f315b0b446e995fa6a8807e071689cccc19091134499ebaca',2025,'SV','El Salvador','energy',32,'Electricity access:
population without electricity:
(2020) less than 1 million
electrification - total population:
97.8% (2021)
electrification - urban areas:
99.2% (2021)
electrification - rural areas:
94% (2021)
Electricity:
installed generating capacity:
2.586 million kW (2020 est.)
consumption:
6,443,200,000 kWh (2019 est.)
exports:
158 million kWh (2019 est.)
imports:
1.45 billion kWh (2019 est.)
transmission/distribution losses:
795.8 million kWh (2019 est.)
comparison rankings:
installed generating capacity 112; transmission/distribution losses 120; imports 65; exports 88; consumption 115
Electricity generation sources:
fossil fuels:
28.2% of total installed capacity (2020 est.)
solar:
7.5% of total installed capacity (2020 est.)
hydroelectricity:
30% of total installed capacity (2020 est.)
geothermal:
22.2% of total installed capacity (2020 est.)
biomass and waste:
12.1% of total installed capacity (2020 est.)
Coal:
production:
0 metric tons (2020 est.)
consumption:
1,000 metric tons (2020 est.)
exports:
0 metric tons (2020 est.)
imports:
1,000 metric tons (2020 est.)
proven reserves:
0 metric tons (2019 est.)
Petroleum:
total petroleum production:
0 bbl/day (2021 est.)
refined petroleum consumption:
59,100 bbl/day (2019 est.)
crude oil estimated reserves:
0 barrels (2021 est.)
Refined petroleum products - production:
0 bbl/day (2015 est.)
comparison ranking:
170
Refined petroleum products - exports:
347 bbl/day (2015 est.)
comparison ranking:
115
Refined petroleum products - imports:
49,280 bbl/day (2015 est.)
comparison ranking:
82
Carbon dioxide emissions:
7.632 million metric tonnes of CO2 (2019 est.)
from coal and metallurgical coke:
2,000 metric tonnes of CO2 (2019 est.)
from petroleum and other liquids:
7.63 million metric tonnes of CO2 (2019 est.)
comparison ranking:
total emissions 122
Energy consumption per capita:
24.124 million Btu/person (2019 est.)
comparison ranking:
131','5fbc490e3d38406d53751d85082469251f1829c56623b70ff9d1b7eacb9ebeee','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c1ff5b4f97a519943be1d5a1766ad44867eabba5df9f47d9f8a23e1eed1ba62c',2025,'GQ','Equatorial Guinea','energy',44,'Electricity access:
electrification - total population:
66.7% (2021)
electrification - urban areas:
90.3% (2021)
electrification - rural areas:
47% (2020)
Electricity:
installed generating capacity:
349,000 kW (2020 est.)
consumption:
1,002,960,000 kWh (2019 est.)
exports:
0 kWh (2019 est.)
imports:
0 kWh (2019 est.)
transmission/distribution losses:
183 million kWh (2019 est.)
comparison rankings:
installed generating capacity 157; transmission/distribution losses 149; imports 143; exports 126; consumption 159
Electricity generation sources:
fossil fuels:
89.4% of total installed capacity (2020 est.)
hydroelectricity:
10.6% of total installed capacity (2020 est.)
Petroleum:
total petroleum production:
142,600 bbl/day (2021 est.)
refined petroleum consumption:
22,300 bbl/day (2019 est.)
crude oil and lease condensate exports:
184,500 bbl/day (2018 est.)
crude oil and lease condensate imports:
0 bbl/day (2018 est.)
crude oil estimated reserves:
1.1 billion barrels (2021 est.)
Refined petroleum products - imports:
5,094 bbl/day (2015 est.)
comparison ranking:
171
Natural gas:
production:
4,569,369,000 cubic meters (2019 est.)
consumption:
1,080,003,000 cubic meters (2019 est.)
exports:
3,568,030,000 cubic meters (2019 est.)
imports:
0 cubic meters (2021 est.)
proven reserves:
139.007 billion cubic meters (2021 est.)
Carbon dioxide emissions:
4.528 million metric tonnes of CO2 (2019 est.)
from coal and metallurgical coke:
0 metric tonnes of CO2 (2019 est.)
from petroleum and other liquids:
2.409 million metric tonnes of CO2 (2019 est.)
from consumed natural gas:
2.119 million metric tonnes of CO2 (2019 est.)
comparison ranking:
total emissions 137
Energy consumption per capita:
57.596 million Btu/person (2019 est.)
comparison ranking:
95','7496443c6ac7815919b421e54013c0278f1b5457a097e2eff55222a7ca4b3fe9','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('442ddc0b469461f1e7345f4cca25fa6fd9b5dff7f5b7139ced332c926cf996f9',2025,'ER','Eritrea','energy',55,'Electricity access:
population without electricity:
3 million (2020)
electrification - total population:
52.5% (2021)
electrification - urban areas:
75.6% (2019)
electrification - rural areas:
35.7% (2021)
Electricity:
installed generating capacity:
228,000 kW (2020 est.)
consumption:
394.46 million kWh (2019 est.)
exports:
0 kWh (2019 est.)
imports:
0 kWh (2019 est.)
transmission/distribution losses:
61 million kWh (2019 est.)
comparison rankings:
installed generating capacity 166; transmission/distribution losses 169; imports 178; exports 170; consumption 176
Electricity generation sources:
fossil fuels:
93.8% of total installed capacity (2020 est.)
solar:
5.7% of total installed capacity (2020 est.)
wind:
0.5% of total installed capacity (2020 est.)
Petroleum:
total petroleum production:
0 bbl/day (2021 est.)
refined petroleum consumption:
5,200 bbl/day (2019 est.)
Refined petroleum products - imports:
3,897 bbl/day (2015 est.)
comparison ranking:
179
Carbon dioxide emissions:
798,000 metric tonnes of CO2 (2019 est.)
from petroleum and other liquids:
798,000 metric tonnes of CO2 (2019 est.)
comparison ranking:
total emissions 179
Energy consumption per capita:
3.217 million Btu/person (2019 est.)
comparison ranking:
182','2b9727673727668c5d590a401b728c7448c73ca6e1fbe495bd3e65440aa3080b','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('eef0f3a35a83a0fa855f06f74678cddf9bf8927a2a4ac93505047ea764b94003',2025,'EE','Estonia','energy',7,'Electricity access:
electrification - total population:
100% (2021)
Electricity:
installed generating capacity:
3.03 million kW (2020 est.)
consumption:
9.172 billion kWh (2020 est.)
exports:
3.722 billion kWh (2020 est.)
imports:
7.367 billion kWh (2020 est.)
transmission/distribution losses:
375 million kWh (2020 est.)
comparison rankings:
transmission/distribution losses 136; imports 32; exports 41; consumption 104; installed generating capacity 107
Electricity generation sources:
fossil fuels:
55.8% of total installed capacity (2020 est.)
solar:
2% of total installed capacity (2020 est.)
wind:
14.3% of total installed capacity (2020 est.)
hydroelectricity:
0.7% of total installed capacity (2020 est.)
biomass and waste:
27.2% of total installed capacity (2020 est.)
Coal:
production:
0 metric tons (2020 est.)
consumption:
3,000 metric tons (2020 est.)
exports:
0 metric tons (2020 est.)
imports:
3,000 metric tons (2020 est.)
proven reserves:
0 metric tons (2019 est.)
Petroleum:
total petroleum production:
21,800 bbl/day (2021 est.)
refined petroleum consumption:
27,500 bbl/day (2019 est.)
Refined petroleum products - exports:
27,150 bbl/day (2017 est.)
comparison ranking:
64
Refined petroleum products - imports:
35,520 bbl/day (2017 est.)
comparison ranking:
95
Natural gas:
production:
0 cubic meters (2021 est.)
consumption:
417.106 million cubic meters (2020 est.)
exports:
0 cubic meters (2021 est.)
imports:
417.276 million cubic meters (2020 est.)
proven reserves:
0 cubic meters (2021 est.)
Carbon dioxide emissions:
4.924 million metric tonnes of CO2 (2019 est.)
from coal and metallurgical coke:
44,000 metric tonnes of CO2 (2019 est.)
from petroleum and other liquids:
3.979 million metric tonnes of CO2 (2019 est.)
from consumed natural gas:
901,000 metric tonnes of CO2 (2019 est.)
comparison ranking:
total emissions 135
Energy consumption per capita:
76.329 million Btu/person (2019 est.)
comparison ranking:
80','3d992a26ce45fceacdda6a0aeb94c3e42a00e9aea63f63d6120dc441f4baa0ce','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a6e16f3f9f191d6919bf70d11784a714c5f1dddd41f3d1f781d931fb6bc1ebb2',2025,'SZ','Eswatini','energy',18,'Electricity access:
population without electricity:
(2020) less than 1 million
electrification - total population:
82.9% (2021)
electrification - urban areas:
94.5% (2021)
electrification - rural areas:
79.1% (2021)
Electricity:
installed generating capacity:
286,000 kW (2020 est.)
consumption:
1,448,308,000 kWh (2019 est.)
exports:
0 kWh (2019 est.)
imports:
942 million kWh (2019 est.)
transmission/distribution losses:
154.7 million kWh (2019 est.)
comparison rankings:
installed generating capacity 162; transmission/distribution losses 153; imports 74; exports 174; consumption 153
Electricity generation sources:
fossil fuels:
44.1% of total installed capacity (2020 est.)
solar:
0.2% of total installed capacity (2020 est.)
hydroelectricity:
24.8% of total installed capacity (2020 est.)
biomass and waste:
31% of total installed capacity (2020 est.)
Coal:
production:
108,000 metric tons (2020 est.)
consumption:
169,000 metric tons (2020 est.)
exports:
163,000 metric tons (2020 est.)
imports:
135,000 metric tons (2020 est.)
proven reserves:
144 million metric tons (2019 est.)
Petroleum:
total petroleum production:
0 bbl/day (2021 est.)
refined petroleum consumption:
6,000 bbl/day (2019 est.)
Refined petroleum products - imports:
5,279 bbl/day (2015 est.)
comparison ranking:
169
Carbon dioxide emissions:
1.224 million metric tonnes of CO2 (2019 est.)
from coal and metallurgical coke:
350,000 metric tonnes of CO2 (2019 est.)
from petroleum and other liquids:
875,000 metric tonnes of CO2 (2019 est.)
comparison ranking:
total emissions 169
Energy consumption per capita:
19.371 million Btu/person (2019 est.)
comparison ranking:
136','fd883efd56e4158113f49ecd9539bec1bc01727faf520480607404be4a2d87b8','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1723e3ba61ca68b9eae59bfa0ddba7c9842499a24227dee8a276159996d4bd01',2025,'ET','Ethiopia','energy',29,'Electricity access:
population without electricity:
59 million (2020)
electrification - total population:
54.1% (2021)
electrification - urban areas:
94.3% (2019)
electrification - rural areas:
42.7% (2021)
Electricity:
installed generating capacity:
4.856 million kW (2020 est.)
consumption:
9,778,100,000 kWh (2019 est.)
exports:
1 billion kWh (2019 est.)
imports:
0 kWh (2019 est.)
transmission/distribution losses:
3.374 billion kWh (2019 est.)
comparison rankings:
installed generating capacity 89; transmission/distribution losses 62; imports 201; exports 61; consumption 102
Electricity generation sources:
solar:
0.1% of total installed capacity (2020 est.)
wind:
3.8% of total installed capacity (2020 est.)
hydroelectricity:
95.8% of total installed capacity (2020 est.)
biomass and waste:
0.3% of total installed capacity (2020 est.)
Coal:
production:
0 metric tons (2020 est.)
consumption:
689,000 metric tons (2020 est.)
exports:
0 metric tons (2020 est.)
imports:
528,000 metric tons (2020 est.)
proven reserves:
0 metric tons (2019 est.)
Petroleum:
total petroleum production:
0 bbl/day (2021 est.)
refined petroleum consumption:
107,900 bbl/day (2019 est.)
crude oil estimated reserves:
400,000 barrels (2021 est.)
Refined petroleum products - imports:
69,970 bbl/day (2015 est.)
comparison ranking:
67
Natural gas:
proven reserves:
24.919 billion cubic meters (2021 est.)
Carbon dioxide emissions:
16.798 million metric tonnes of CO2 (2019 est.)
from coal and metallurgical coke:
1.474 million metric tonnes of CO2 (2019 est.)
from petroleum and other liquids:
15.324 million metric tonnes of CO2 (2019 est.)
from consumed natural gas:
0 metric tonnes of CO2 (2019 est.)
comparison ranking:
total emissions 92
Energy consumption per capita:
3.219 million Btu/person (2019 est.)
comparison ranking:
181','5221cd241d01df706306d3d045363009ddab3846000c28813e8a18b1ca1382bd','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('42c2b94c6e16a6e022be6ec06066fe522ea263adab18424aafe2ac43b2861868',2025,'ET','Ethiopia','energy',42,'Electricity access:
electrification - total population: 99.9% (2021)
electrification - urban areas:
99.9% (2021)
electrification - rural areas:
99.9% (2021)
Refined petroleum products - production:
11.66 million bbl/day (2016 est.)
Refined petroleum products - exports:
2.196 million bbl/day (2017 est.)
Refined petroleum products - imports:
8.613 million bbl/day (2017 est.)
Carbon dioxide emissions:
3.475 billion metric tonnes of CO2 (2015 est.)','3644ef6e4ae90a2d3d03ec254ff9c60ba558ad84031785d76435e79ebe37cfa2','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1afa27aeb549503442126eed4c6ec10fb6ca30a14814af2280c934d626458c97',2025,'FO','Faroe Islands','energy',8,'Electricity access:
electrification - total population:
100% (2021)
Electricity:
installed generating capacity:
128,000 kW (2020 est.)
consumption:
358.64 million kWh (2019 est.)
exports:
0 kWh (2020 est.)
imports:
0 kWh (2020 est.)
transmission/distribution losses:
23.16 million kWh (2019 est.)
comparison rankings:
imports 162; exports 149; installed generating capacity 180; transmission/distribution losses 182; consumption 177
Electricity generation sources:
fossil fuels:
58.9% of total installed capacity (2020 est.)
wind:
15.1% of total installed capacity (2020 est.)
hydroelectricity:
26% of total installed capacity (2020 est.)
Petroleum:
total petroleum production:
0 bbl/day (2021 est.)
refined petroleum consumption:
5,500 bbl/day (2019 est.)
Refined petroleum products - imports:
4,555 bbl/day (2015 est.)
comparison ranking:
174
Carbon dioxide emissions:
870,000 metric tonnes of CO2 (2019 est.)
from petroleum and other liquids:
870,000 metric tonnes of CO2 (2019 est.)
comparison ranking:
total emissions 177
Energy consumption per capita:
0 Btu/person (2019 est.)
comparison ranking:
212','bc768aeef894eea58c72a3f91ea357254ea3c960e8ea0629d13a32f219116948','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b34bb2e6f35c7d5c57059d7cbbae1d2cc5d9151541104bb0d56922f9ca3226dd',2025,'FJ','Fiji','energy',19,'Electricity access:
electrification - total population:
92.1% (2021)
electrification - urban areas:
96% (2021)
electrification - rural areas:
86.7% (2021)
Electricity:
installed generating capacity:
393,000 kW (2020 est.)
consumption:
1,022,955,000 kWh (2019 est.)
exports:
0 kWh (2020 est.)
imports:
0 kWh (2020 est.)
transmission/distribution losses:
90 million kWh (2019 est.)
comparison rankings:
imports 158; exports 144; installed generating capacity 154; transmission/distribution losses 161; consumption 157
Electricity generation sources:
fossil fuels:
41.9% of total installed capacity (2020 est.)
solar:
1.6% of total installed capacity (2020 est.)
wind:
0.3% of total installed capacity (2020 est.)
hydroelectricity:
50.2% of total installed capacity (2020 est.)
biomass and waste:
6% of total installed capacity (2020 est.)
Petroleum:
total petroleum production:
0 bbl/day (2021 est.)
refined petroleum consumption:
11,500 bbl/day (2019 est.)
Refined petroleum products - imports:
17,460 bbl/day (2015 est.)
comparison ranking:
132
Carbon dioxide emissions:
1.691 million metric tonnes of CO2 (2019 est.)
from petroleum and other liquids:
1.691 million metric tonnes of CO2 (2019 est.)
comparison ranking:
total emissions 164
Energy consumption per capita:
32.901 million Btu/person (2019 est.)
comparison ranking:
118','2dfe81b0c55011a0e4e3f446a0b1af6f201e37db1a397a752f53a3bde4749dfc','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('32e8d14144055662bdeece299104d6bd5b0573372e4560a3c72cbc30470b8db8',2025,'FI','Finland','energy',30,'Electricity access:
electrification - total population:
100% (2021)
Electricity:
installed generating capacity:
20.418 million kW (2020 est.)
consumption:
79.356 billion kWh (2020 est.)
exports:
6.666 billion kWh (2020 est.)
imports:
21.615 billion kWh (2020 est.)
transmission/distribution losses:
2.574 billion kWh (2020 est.)
comparison rankings:
transmission/distribution losses 75; imports 9; exports 28; consumption 37; installed generating capacity 47
Electricity generation sources:
fossil fuels:
13.4% of total installed capacity (2020 est.)
nuclear:
33.4% of total installed capacity (2020 est.)
solar:
0.4% of total installed capacity (2020 est.)
wind:
11.9% of total installed capacity (2020 est.)
hydroelectricity:
23.2% of total installed capacity (2020 est.)
biomass and waste:
17.8% of total installed capacity (2020 est.)
Nuclear energy: Number of operational nuclear reactors:
5 (2023)
Number of nuclear reactors under construction:
0
Net capacity of operational nuclear reactors:
4.39GW (2023)
Percent of total electricity production:
32.8% (2021)
Percent of total energy produced:
41.3% (2021)
Number of nuclear reactors permanently shut down:
0
Coal:
production:
762,000 metric tons (2020 est.)
consumption:
3.552 million metric tons (2020 est.)
exports:
101,000 metric tons (2020 est.)
imports:
2.661 million metric tons (2020 est.)
proven reserves:
0 metric tons (2019 est.)
Petroleum:
total petroleum production:
8,300 bbl/day (2021 est.)
refined petroleum consumption:
207,400 bbl/day (2019 est.)
crude oil and lease condensate exports:
0 bbl/day (2018 est.)
crude oil and lease condensate imports:
232,400 bbl/day (2018 est.)
crude oil estimated reserves:
0 barrels (2021 est.)
Refined petroleum products - production:
310,600 bbl/day (2017 est.)
comparison ranking:
40
Refined petroleum products - exports:
166,200 bbl/day (2017 est.)
comparison ranking:
34
Refined petroleum products - imports:
122,200 bbl/day (2017 est.)
comparison ranking:
48
Natural gas:
production:
0 cubic meters (2021 est.)
consumption:
2.393 billion cubic meters (2020 est.)
exports:
181.143 million cubic meters (2020 est.)
imports:
2.569 billion cubic meters (2020 est.)
proven reserves:
0 cubic meters (2021 est.)
Carbon dioxide emissions:
41.996 million metric tonnes of CO2 (2019 est.)
from coal and metallurgical coke:
9.377 million metric tonnes of CO2 (2019 est.)
from petroleum and other liquids:
27.737 million metric tonnes of CO2 (2019 est.)
from consumed natural gas:
4.882 million metric tonnes of CO2 (2019 est.)
comparison ranking:
total emissions 62
Energy consumption per capita:
216.571 million Btu/person (2019 est.)
comparison ranking:
20','11e1654cc88f8ab368a626322d11efcb427db711aaa4fb61f2a702ad475cd718','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('74baeede78058ae3df892ad44afefd4592c36b7f1cef7d85f4bfd02e7787e6fc',2025,'FR','France','energy',41,'Electricity access:
electrification - total population:
100% (2021)
Electricity:
installed generating capacity:
138.611 million kW (2020 est.)
consumption:
472.699 billion kWh (2020 est.)
exports:
64.425 billion kWh (2020 est.)
imports:
19.613 billion kWh (2020 est.)
transmission/distribution losses:
36.203 billion kWh (2020 est.)
comparison rankings:
transmission/distribution losses 9; imports 12; exports 3; consumption 10; installed generating capacity 9
Electricity generation sources:
fossil fuels:
8% of total installed capacity (2020 est.)
nuclear:
68.4% of total installed capacity (2020 est.)
solar:
2.5% of total installed capacity (2020 est.)
wind:
7.3% of total installed capacity (2020 est.)
hydroelectricity:
11.7% of total installed capacity (2020 est.)
tide and wave:
0.2% of total installed capacity (2020 est.)
geothermal:
0% of total installed capacity (2020 est.)
biomass and waste:
2% of total installed capacity (2020 est.)
Nuclear energy: Number of operational nuclear reactors:
56 (2023)
Number of nuclear reactors under construction:
1
Net capacity of operational nuclear reactors:
61.37GW (2021)
Percent of total electricity production:
70% (2021)
Percent of total energy produced:
77% (2021)
Number of nuclear reactors permanently shut down:
6
Coal:
production:
2.312 million metric tons (2020 est.)
consumption:
10.712 million metric tons (2020 est.)
exports:
35,000 metric tons (2020 est.)
imports:
7.891 million metric tons (2020 est.)
proven reserves:
0 metric tons (2019 est.)
Petroleum:
total petroleum production:
81,500 bbl/day (2021 est.)
refined petroleum consumption:
1,688,500 bbl/day (2019 est.)
crude oil and lease condensate exports:
0 bbl/day (2018 est.)
crude oil and lease condensate imports:
1,064,700 bbl/day (2018 est.)
crude oil estimated reserves:
61.7 million barrels (2021 est.)
Refined petroleum products - production:
1.311 million bbl/day (2017 est.)
comparison ranking:
15
Refined petroleum products - exports:
440,600 bbl/day (2017 est.)
comparison ranking:
19
Refined petroleum products - imports:
886,800 bbl/day (2017 est.)
comparison ranking:
8
Natural gas:
production:
16.226 million cubic meters (2019 est.)
consumption:
38.192 billion cubic meters (2020 est.)
exports:
9.104 billion cubic meters (2020 est.)
imports:
46.11 billion cubic meters (2020 est.)
proven reserves:
7.787 billion cubic meters (2021 est.)
Carbon dioxide emissions:
338.425 million metric tonnes of CO2 (2019 est.)
from coal and metallurgical coke:
26.971 million metric tonnes of CO2 (2019 est.)
from petroleum and other liquids:
225.865 million metric tonnes of CO2 (2019 est.)
from consumed natural gas:
85.589 million metric tonnes of CO2 (2019 est.)
comparison ranking:
total emissions 18
Energy consumption per capita:
151.053 million Btu/person (2019 est.)
comparison ranking:
34','808d92a7b2764d4eb23c2a061e034b7047d81df209ed73296fb64102dcc7e171','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('39509387f8d3ce619e7d08557348eb8ea1cadcae1c7c8f1de21d781bd6d051a0',2025,'PF','French Polynesia','energy',54,'Electricity access:
electrification - total population:
100% (2020)
Electricity:
installed generating capacity:
272,000 kW (2020 est.)
consumption:
639.7 million kWh (2019 est.)
exports:
0 kWh (2019 est.)
imports:
0 kWh (2019 est.)
transmission/distribution losses:
41 million kWh (2019 est.)
comparison rankings:
installed generating capacity 164; transmission/distribution losses 172; imports 152; exports 140; consumption 166
Electricity generation sources:
fossil fuels:
66.5% of total installed capacity (2020 est.)
solar:
6.1% of total installed capacity (2020 est.)
hydroelectricity:
27.4% of total installed capacity (2020 est.)
Petroleum:
total petroleum production:
0 bbl/day (2021 est.)
refined petroleum consumption:
6,700 bbl/day (2019 est.)
Refined petroleum products - imports:
6,785 bbl/day (2015 est.)
comparison ranking:
160
Carbon dioxide emissions:
1.03 million metric tonnes of CO2 (2019 est.)
from petroleum and other liquids:
1.03 million metric tonnes of CO2 (2019 est.)
comparison ranking:
total emissions 172
Energy consumption per capita:
0 Btu/person (2019 est.)
comparison ranking:
204','55a8e2025f78d082bc72f9f2af27be77aba6fc8e10019d121b69e96935e7a674','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('39e07f2d134084711d6a2ffc1673408203a7748dcaf0fa2fd6bed4c34903e0ec',2025,'GA','Gabon','energy',7,'Electricity access:
population without electricity:
(2020) less than 1 million
electrification - total population:
91.8% (2021)
electrification - urban areas:
98.6% (2021)
electrification - rural areas:
26.7% (2021)
Electricity:
installed generating capacity:
784,000 kW (2020 est.)
consumption:
3.134 billion kWh (2019 est.)
exports:
0 kWh (2019 est.)
imports:
511 million kWh (2019 est.)
transmission/distribution losses:
389 million kWh (2019 est.)
comparison rankings:
installed generating capacity 138; transmission/distribution losses 134; imports 87; exports 128; consumption 138
Electricity generation sources:
fossil fuels:
40.6% of total installed capacity (2020 est.)
solar:
0.1% of total installed capacity (2020 est.)
hydroelectricity:
59% of total installed capacity (2020 est.)
biomass and waste:
0.3% of total installed capacity (2020 est.)
Petroleum:
total petroleum production:
175,000 bbl/day (2021 est.)
refined petroleum consumption:
14,400 bbl/day (2019 est.)
crude oil and lease condensate exports:
178,400 bbl/day (2018 est.)
crude oil and lease condensate imports:
0 bbl/day (2018 est.)
crude oil estimated reserves:
2 billion barrels (2021 est.)
Refined petroleum products - production:
16,580 bbl/day (2017 est.)
comparison ranking:
91
Refined petroleum products - exports:
4,662 bbl/day (2015 est.)
comparison ranking:
91
Refined petroleum products - imports:
10,680 bbl/day (2015 est.)
comparison ranking:
146
Natural gas:
production:
319.102 million cubic meters (2019 est.)
consumption:
319.102 million cubic meters (2019 est.)
proven reserves:
25.995 billion cubic meters (2021 est.)
Carbon dioxide emissions:
2.651 million metric tonnes of CO2 (2019 est.)
from coal and metallurgical coke:
0 metric tonnes of CO2 (2019 est.)
from petroleum and other liquids:
2.025 million metric tonnes of CO2 (2019 est.)
from consumed natural gas:
626,000 metric tonnes of CO2 (2019 est.)
comparison ranking:
total emissions 152
Energy consumption per capita:
26.786 million Btu/person (2019 est.)
comparison ranking:
127','e4abbf43855a48db4d455b9a97d8333296135e2d1b666846713ffffe66f87ef2','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6ac6ff1bd312fc23c2a4892f502febdfb4367a222a44431c48d88f26b7e6d90b',2025,'GA','Gabon','energy',19,'Electricity access:
population without electricity:
(2020) less than 1 million
electrification - total population:
63.6% (2021)
electrification - urban areas:
82.5% (2021)
electrification - rural areas:
31.2% (2021)
Electricity:
installed generating capacity:
137,000 kW (2020 est.)
consumption:
235.035 million kWh (2019 est.)
exports:
0 kWh (2019 est.)
imports:
0 kWh (2019 est.)
transmission/distribution losses:
69.8 million kWh (2019 est.)
comparison rankings:
installed generating capacity 178; transmission/distribution losses 165; imports 122; exports 102; consumption 183
Electricity generation sources:
fossil fuels:
98.9% of total installed capacity (2020 est.)
solar:
1% of total installed capacity (2020 est.)
Petroleum:
total petroleum production:
0 bbl/day (2021 est.)
refined petroleum consumption:
3,900 bbl/day (2019 est.)
Refined petroleum products - exports:
42 bbl/day (2015 est.)
comparison ranking:
122
Refined petroleum products - imports:
3,738 bbl/day (2015 est.)
comparison ranking:
181
Carbon dioxide emissions:
606,000 metric tonnes of CO2 (2019 est.)
from petroleum and other liquids:
606,000 metric tonnes of CO2 (2019 est.)
comparison ranking:
total emissions 186
Energy consumption per capita:
3.547 million Btu/person (2019 est.)
comparison ranking:
177','006c38d09ad169e6862219eb871948e9bb11e0c318781fceb51ba012c7942122','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b56591344cdf21188228cc375ad2fd19ba6b9d7eab652a3e9ee3bff7dc5f782c',2025,'GA','Gabon','energy',30,'Electricity access:
electrification - total population:
100% (2021)
note:
data for Gaza Strip and West Bank combined
Electricity:
installed generating capacity:
215,000 kW (2020 est.)
consumption:
5,702,816,000 kWh (2019 est.)
imports:
5.9 billion kWh (2019 est.)
transmission/distribution losses:
847 million kWh (2019 est.)
comparison rankings:
installed generating capacity 168; transmission/distribution losses 119; imports 37; exports 157; consumption 122
Electricity generation sources:
fossil fuels:
100% of total installed capacity (2020 est.)
Petroleum:
total petroleum production:
0 bbl/day (2021 est.)
refined petroleum consumption:
24,600 bbl/day (2019 est.)
Carbon dioxide emissions:
3.341 million metric tonnes of CO2 (2019 est.)
from petroleum and other liquids:
3.341 million metric tonnes of CO2 (2019 est.)
comparison ranking:
total emissions 145
Energy consumption per capita:
13.604 million Btu/person (2019 est.)
comparison ranking:
143','c1de64cf81a10c5c10d8ffd61d6bba5e4d7646d853426077097595ee27b3d7fd','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('84324eb5bed2f7edb6815a3baf58f87e841312da7153458820566ae9f44292fa',2025,'GE','Georgia','energy',42,'Electricity access:
electrification - total population:
100% (2021)
Electricity:
installed generating capacity:
4.579 million kW (2020 est.)
consumption:
12,062,080,000 kWh (2019 est.)
exports:
256 million kWh (2020 est.)
imports:
1.712 billion kWh (2020 est.)
transmission/distribution losses:
918.2 million kWh (2019 est.)
comparison rankings:
imports 62; exports 85; installed generating capacity 92; transmission/distribution losses 115; consumption 92
Electricity generation sources:
fossil fuels:
25.3% of total installed capacity (2020 est.)
wind:
0.8% of total installed capacity (2020 est.)
hydroelectricity:
73.9% of total installed capacity (2020 est.)
Coal:
production:
99,000 metric tons (2020 est.)
consumption:
362,000 metric tons (2020 est.)
exports:
1,000 metric tons (2020 est.)
imports:
277,000 metric tons (2020 est.)
proven reserves:
201 million metric tons (2019 est.)
Petroleum:
total petroleum production:
300 bbl/day (2021 est.)
refined petroleum consumption:
32,400 bbl/day (2019 est.)
crude oil and lease condensate exports:
100 bbl/day (2018 est.)
crude oil and lease condensate imports:
0 bbl/day (2018 est.)
crude oil estimated reserves:
35 million barrels (2021 est.)
Refined petroleum products - production:
247 bbl/day (2017 est.)
comparison ranking:
106
Refined petroleum products - exports:
2,052 bbl/day (2015 est.)
comparison ranking:
104
Refined petroleum products - imports:
28,490 bbl/day (2015 est.)
comparison ranking:
101
Natural gas:
production:
6.088 million cubic meters (2020 est.)
consumption:
2.54 billion cubic meters (2020 est.)
exports:
0 cubic meters (2021 est.)
imports:
2.535 billion cubic meters (2020 est.)
proven reserves:
8.495 billion cubic meters (2021 est.)
Carbon dioxide emissions:
10.299 million metric tonnes of CO2 (2019 est.)
from coal and metallurgical coke:
1.063 million metric tonnes of CO2 (2019 est.)
from petroleum and other liquids:
4.245 million metric tonnes of CO2 (2019 est.)
from consumed natural gas:
4.992 million metric tonnes of CO2 (2019 est.)
comparison ranking:
total emissions 104
Energy consumption per capita:
63.286 million Btu/person (2019 est.)
comparison ranking:
87','1948ee5f4786193de67b8866b0b46a3f11d2ef64020b223ac13c31960c542c86','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ad38bca486cd8a6678b98d17b947f860926159d28ca5e7eed62c8211b72570b0',2025,'DE','Germany','energy',53,'Electricity access:
electrification - total population:
100% (2021)
Electricity:
installed generating capacity:
248.265 million kW (2020 est.)
consumption:
500.35 billion kWh (2020 est.)
exports:
66.931 billion kWh (2020 est.)
imports:
48.047 billion kWh (2020 est.)
transmission/distribution losses:
25.97 billion kWh (2020 est.)
comparison rankings:
transmission/distribution losses 17; imports 2; exports 2; consumption 9; installed generating capacity 6
Electricity generation sources:
fossil fuels:
40.5% of total installed capacity (2020 est.)
nuclear:
11.1% of total installed capacity (2020 est.)
solar:
9.2% of total installed capacity (2020 est.)
wind:
23.9% of total installed capacity (2020 est.)
hydroelectricity:
4.5% of total installed capacity (2020 est.)
tide and wave:
0.2% of total installed capacity (2020 est.)
geothermal:
0% of total installed capacity (2020 est.)
biomass and waste:
10.4% of total installed capacity (2020 est.)
note:
as of April 2023, Germany has closed its three remaining nuclear power plants
Nuclear energy: Number of operational nuclear reactors:
0
Number of nuclear reactors under construction:
0
Net capacity of operational nuclear reactors:
0GW
Percent of total electricity production:
0%
Percent of total energy produced:
0%
Number of nuclear reactors permanently shut down:
33
Coal:
production:
114.86 million metric tons (2020 est.)
consumption:
145.379 million metric tons (2020 est.)
exports:
2.317 million metric tons (2020 est.)
imports:
31.503 million metric tons (2020 est.)
proven reserves:
35.9 billion metric tons (2019 est.)
Petroleum:
total petroleum production:
135,000 bbl/day (2021 est.)
refined petroleum consumption:
2,346,500 bbl/day (2019 est.)
crude oil and lease condensate exports:
0 bbl/day (2018 est.)
crude oil and lease condensate imports:
1,720,600 bbl/day (2018 est.)
crude oil estimated reserves:
115.2 million barrels (2021 est.)
Refined petroleum products - production:
2.158 million bbl/day (2017 est.)
comparison ranking:
9
Refined petroleum products - exports:
494,000 bbl/day (2017 est.)
comparison ranking:
17
Refined petroleum products - imports:
883,800 bbl/day (2017 est.)
comparison ranking:
9
Natural gas:
production:
5.129 billion cubic meters (2020 est.)
consumption:
8.755 billion cubic meters (2020 est.)
exports:
0 cubic meters (2020 est.)
imports:
83.12 billion cubic meters (2020 est.)
proven reserves:
23.39 billion cubic meters (2021 est.)
Carbon dioxide emissions:
726.881 million metric tonnes of CO2 (2019 est.)
from coal and metallurgical coke:
218.636 million metric tonnes of CO2 (2019 est.)
from petroleum and other liquids:
316.064 million metric tonnes of CO2 (2019 est.)
from consumed natural gas:
192.181 million metric tonnes of CO2 (2019 est.)
comparison ranking:
total emissions 6
Energy consumption per capita:
161.174 million Btu/person (2019 est.)
comparison ranking:
31','e2ec688ca7c35fafe6773ff4e86262c14036b2b5a7d2f1ccb7c62f6a1abba71d','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7e09a8e0762e65ff34a5bede5352b2320508c77de3b60274461871d56a477e22',2025,'GH','Ghana','energy',66,'Electricity access:
population without electricity:
5 million (2020)
electrification - total population:
86.3% (2021)
electrification - urban areas:
95.2% (2021)
electrification - rural areas:
74% (2021)
Electricity:
installed generating capacity:
5.312 million kW (2020 est.)
consumption:
13,107,757,000 kWh (2019 est.)
exports:
1.801 billion kWh (2020 est.)
imports:
58 million kWh (2020 est.)
transmission/distribution losses:
2.474 billion kWh (2019 est.)
comparison rankings:
imports 113; exports 54; installed generating capacity 85; transmission/distribution losses 78; consumption 87
Electricity generation sources:
fossil fuels:
63.8% of total installed capacity (2020 est.)
solar:
0.3% of total installed capacity (2020 est.)
hydroelectricity:
35.9% of total installed capacity (2020 est.)
biomass and waste:
0.1% of total installed capacity (2020 est.)
Coal:
production:
0 metric tons (2020 est.)
consumption:
48,000 metric tons (2020 est.)
exports:
0 metric tons (2020 est.)
imports:
48,000 metric tons (2020 est.)
proven reserves:
0 metric tons (2019 est.)
Petroleum:
total petroleum production:
185,700 bbl/day (2021 est.)
refined petroleum consumption:
98,000 bbl/day (2019 est.)
crude oil and lease condensate exports:
176,800 bbl/day (2018 est.)
crude oil and lease condensate imports:
3,900 bbl/day (2018 est.)
crude oil estimated reserves:
660 million barrels (2021 est.)
Refined petroleum products - production:
2,073 bbl/day (2015 est.)
comparison ranking:
104
Refined petroleum products - exports:
2,654 bbl/day (2015 est.)
comparison ranking:
100
Refined petroleum products - imports:
85,110 bbl/day (2015 est.)
comparison ranking:
59
Natural gas:
production:
1,598,653,000 cubic meters (2019 est.)
consumption:
2,224,568,000 cubic meters (2019 est.)
exports:
0 cubic meters (2021 est.)
imports:
625.915 million cubic meters (2019 est.)
proven reserves:
22.653 billion cubic meters (2021 est.)
Carbon dioxide emissions:
18.093 million metric tonnes of CO2 (2019 est.)
from coal and metallurgical coke:
160,000 metric tonnes of CO2 (2019 est.)
from petroleum and other liquids:
13.569 million metric tonnes of CO2 (2019 est.)
from consumed natural gas:
4.364 million metric tonnes of CO2 (2019 est.)
comparison ranking:
total emissions 88
Energy consumption per capita:
11.239 million Btu/person (2019 est.)
comparison ranking:
152','a68d8a731c0a3164f0c065937414612b0136d1539e5bc81fc7f49f99d0149f3d','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8fb5786eb0830c4e5432e16e776468596339a5893eb832581129bf1171b80bd5',2025,'GI','Gibraltar','energy',7,'Electricity access:
electrification - total population:
100% (2021)
Electricity:
installed generating capacity:
43,000 kW (2020 est.)
consumption:
198.86 million kWh (2019 est.)
exports:
0 kWh (2019 est.)
imports:
0 kWh (2019 est.)
transmission/distribution losses:
7 million kWh (2019 est.)
comparison rankings:
installed generating capacity 194; transmission/distribution losses 198; imports 163; exports 150; consumption 185
Electricity generation sources:
fossil fuels:
100% of total installed capacity (2020 est.)
Petroleum:
total petroleum production:
0 bbl/day (2021 est.)
refined petroleum consumption:
83,700 bbl/day (2019 est.)
Refined petroleum products - imports:
74,200 bbl/day (2015 est.)
comparison ranking:
66
Natural gas:
production:
0 cubic meters (2021 est.)
consumption:
74.756 million cubic meters (2020 est.)
exports:
0 cubic meters (2021 est.)
imports:
56.719 million cubic meters (2019 est.)
proven reserves:
0 cubic meters (2021 est.)
Carbon dioxide emissions:
14.256 million metric tonnes of CO2 (2019 est.)
from coal and metallurgical coke:
0 metric tonnes of CO2 (2019 est.)
from petroleum and other liquids:
14.146 million metric tonnes of CO2 (2019 est.)
from consumed natural gas:
111,000 metric tonnes of CO2 (2019 est.)
comparison ranking:
total emissions 97
Energy consumption per capita:
0 Btu/person (2019 est.)
comparison ranking:
209','4fadaea91eae816985231ad041c780fac58396d28c273f5df0fe403ec979125c','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0c7b47ed59d0755ce350e69dfe4bf7d3432be456abb3ed588b375b3f6c3fe8bf',2025,'GR','Greece','energy',18,'Electricity access:
electrification - total population:
100% (2021)
Electricity:
installed generating capacity:
21.545 million kW (2020 est.)
consumption:
46.18 billion kWh (2020 est.)
exports:
967 million kWh (2020 est.)
imports:
9.831 billion kWh (2020 est.)
transmission/distribution losses:
3.256 billion kWh (2020 est.)
comparison rankings:
transmission/distribution losses 63; imports 25; exports 63; consumption 54; installed generating capacity 45
Electricity generation sources:
fossil fuels:
56.5% of total installed capacity (2020 est.)
nuclear:
0% of total installed capacity (2020 est.)
solar:
10.7% of total installed capacity (2020 est.)
wind:
23% of total installed capacity (2020 est.)
hydroelectricity:
8.5% of total installed capacity (2020 est.)
tide and wave:
0% of total installed capacity (2020 est.)
geothermal:
0% of total installed capacity (2020 est.)
biomass and waste:
1.4% of total installed capacity (2020 est.)
Coal:
production:
13.851 million metric tons (2020 est.)
consumption:
13.828 million metric tons (2020 est.)
exports:
7,000 metric tons (2020 est.)
imports:
305,000 metric tons (2020 est.)
proven reserves:
2.876 billion metric tons (2019 est.)
Petroleum:
total petroleum production:
4,800 bbl/day (2021 est.)
refined petroleum consumption:
309,600 bbl/day (2019 est.)
crude oil and lease condensate exports:
4,100 bbl/day (2018 est.)
crude oil and lease condensate imports:
491,300 bbl/day (2018 est.)
crude oil estimated reserves:
10 million barrels (2021 est.)
Refined petroleum products - production:
655,400 bbl/day (2017 est.)
comparison ranking:
28
Refined petroleum products - exports:
371,900 bbl/day (2017 est.)
comparison ranking:
22
Refined petroleum products - imports:
192,200 bbl/day (2017 est.)
comparison ranking:
35
Natural gas:
production:
5.748 million cubic meters (2019 est.)
consumption:
5,831,987,000 cubic meters (2020 est.)
exports:
33.244 million cubic meters (2020 est.)
imports:
5,219,409,000 cubic meters (2019 est.)
proven reserves:
991 million cubic meters (2021 est.)
Carbon dioxide emissions:
70.163 million metric tonnes of CO2 (2019 est.)
from coal and metallurgical coke:
13.404 million metric tonnes of CO2 (2019 est.)
from petroleum and other liquids:
46.401 million metric tonnes of CO2 (2019 est.)
from consumed natural gas:
10.358 million metric tonnes of CO2 (2019 est.)
comparison ranking:
total emissions 50
Energy consumption per capita:
108.022 million Btu/person (2019 est.)
comparison ranking:
51','0134cd96b77b84bda7ce1821a2ea2e82ade45684be532aedb2d647d17daa643f','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('05e27b41c0b313113ae4b784ef290bcaa09771ce1e2f6bf6f4e42ff053a0b2e5',2025,'GL','Greenland','energy',31,'Electricity access:
electrification - total population:
100% (2021)
Electricity:
installed generating capacity:
187,000 kW (2020 est.)
consumption:
481.7 million kWh (2019 est.)
exports:
0 kWh (2020 est.)
imports:
0 kWh (2020 est.)
transmission/distribution losses:
17 million kWh (2019 est.)
comparison rankings:
imports 188; exports 182; installed generating capacity 173; transmission/distribution losses 187; consumption 172
Electricity generation sources:
fossil fuels:
15.8% of total installed capacity (2020 est.)
hydroelectricity:
84.2% of total installed capacity (2020 est.)
Coal:
proven reserves:
183 million metric tons (2019 est.)
Petroleum:
total petroleum production:
0 bbl/day (2021 est.)
refined petroleum consumption:
4,000 bbl/day (2019 est.)
Refined petroleum products - imports:
3,973 bbl/day (2015 est.)
comparison ranking:
177
Carbon dioxide emissions:
605,000 metric tonnes of CO2 (2019 est.)
from petroleum and other liquids:
605,000 metric tonnes of CO2 (2019 est.)
comparison ranking:
total emissions 187','a5455bd38c3b74d8880ce032c8ed45c5ee0a6e0b5ac6c9df86da93daa3c80a68','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5a471dce9052cb94af11d64323b2ff5f6828e4e81c5e9e2bb8dfd95c5e872fff',2025,'GD','Grenada','energy',42,'Electricity access:
electrification - total population:
93.7% (2021)
electrification - urban areas:
93% (2020)
electrification - rural areas:
96% (2020)
Electricity:
installed generating capacity:
55,000 kW (2020 est.)
consumption:
194.495 million kWh (2019 est.)
exports:
0 kWh (2020 est.)
imports:
0 kWh (2020 est.)
transmission/distribution losses:
19 million kWh (2019 est.)
comparison rankings:
imports 145; exports 130; installed generating capacity 190; transmission/distribution losses 186; consumption 186
Electricity generation sources:
fossil fuels:
98.3% of total installed capacity (2020 est.)
solar:
1.6% of total installed capacity (2020 est.)
wind:
0.1% of total installed capacity (2020 est.)
Petroleum:
total petroleum production:
0 bbl/day (2021 est.)
refined petroleum consumption:
2,200 bbl/day (2019 est.)
Refined petroleum products - imports:
1,886 bbl/day (2015 est.)
comparison ranking:
191
Natural gas:
production:
0 cubic meters (2021 est.)
consumption:
0 cubic meters (2021 est.)
exports:
0 cubic meters (2021 est.)
imports:
0 cubic meters (2021 est.)
proven reserves:
0 cubic meters (2021 est.)
Carbon dioxide emissions:
316,000 metric tonnes of CO2 (2019 est.)
from petroleum and other liquids:
316,000 metric tonnes of CO2 (2019 est.)
comparison ranking:
total emissions 196
Energy consumption per capita:
39.799 million Btu/person (2019 est.)
comparison ranking:
107','4f7079dec0f003fbcef175c9eeff61a3260e03224de1a810630148f8e1a1c49e','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5fc1bde7e70084338f192b935b432cb86eda0875df46eecbcf79c593c41679a8',2025,'GU','Guam','energy',53,'Electricity access:
electrification - total population:
100% (2021)
Electricity:
installed generating capacity:
455,000 kW (2020 est.)
consumption:
1.683 billion kWh (2019 est.)
exports:
0 kWh (2020 est.)
imports:
0 kWh (2020 est.)
transmission/distribution losses:
85 million kWh (2019 est.)
comparison rankings:
imports 205; exports 205; installed generating capacity 153; transmission/distribution losses 162; consumption 151
Electricity generation sources:
fossil fuels:
96% of total installed capacity (2020 est.)
solar:
4% of total installed capacity (2020 est.)
Petroleum:
total petroleum production:
0 bbl/day (2021 est.)
refined petroleum consumption:
2,100 bbl/day (2019 est.) Data represented includes both Guam and Northern Mariana Islands
Refined petroleum products - imports:
13,500 bbl/day (2015 est.)
comparison ranking:
141
Carbon dioxide emissions:
1.828 million metric tonnes of CO2 (2019 est.)
from petroleum and other liquids:
1.828 million metric tonnes of CO2 (2019 est.)
comparison ranking:
total emissions 160
Energy consumption per capita:
152.767 million Btu/person (2019 est.)
comparison ranking:
33','8277405f63d1f0bcc2a649ece1b521db7ec23726d03ff5435b06d8726e6abef1','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('01c8b533965a19e387252ca4dbe06963e390a49c67f0195c8351a31cecbc0d37',2025,'GT','Guatemala','energy',64,'Electricity access:
population without electricity:
1 million (2020)
electrification - total population:
97.8% (2021)
electrification - urban areas:
97.6% (2021)
electrification - rural areas:
98.1% (2021)
Electricity:
installed generating capacity:
5.185 million kW (2020 est.)
consumption:
10,793,650,000 kWh (2019 est.)
exports:
2.19 billion kWh (2019 est.)
imports:
1.141 billion kWh (2019 est.)
transmission/distribution losses:
1.587 billion kWh (2019 est.)
comparison rankings:
installed generating capacity 87; transmission/distribution losses 97; imports 70; exports 49; consumption 99
Electricity generation sources:
fossil fuels:
39.4% of total installed capacity (2020 est.)
solar:
1.5% of total installed capacity (2020 est.)
wind:
2.1% of total installed capacity (2020 est.)
hydroelectricity:
38% of total installed capacity (2020 est.)
geothermal:
2.2% of total installed capacity (2020 est.)
biomass and waste:
17% of total installed capacity (2020 est.)
Coal:
production:
0 metric tons (2020 est.)
consumption:
2.28 million metric tons (2020 est.)
exports:
0 metric tons (2020 est.)
imports:
2.376 million metric tons (2020 est.)
proven reserves:
0 metric tons (2019 est.)
Petroleum:
total petroleum production:
10,300 bbl/day (2021 est.)
refined petroleum consumption:
112,600 bbl/day (2019 est.)
crude oil and lease condensate exports:
6,700 bbl/day (2018 est.)
crude oil and lease condensate imports:
0 bbl/day (2018 est.)
crude oil estimated reserves:
86.1 million barrels (2021 est.)
Refined petroleum products - production:
1,162 bbl/day (2015 est.)
comparison ranking:
105
Refined petroleum products - exports:
10,810 bbl/day (2015 est.)
comparison ranking:
80
Refined petroleum products - imports:
97,900 bbl/day (2015 est.)
comparison ranking:
55
Carbon dioxide emissions:
19.041 million metric tonnes of CO2 (2019 est.)
from coal and metallurgical coke:
5.037 million metric tonnes of CO2 (2019 est.)
from petroleum and other liquids:
14.004 million metric tonnes of CO2 (2019 est.)
comparison ranking:
total emissions 85
Energy consumption per capita:
19.411 million Btu/person (2019 est.)
comparison ranking:
135','ec111180796b8e9192eba181b043cba3b5289316988617bc237750043ce82a45','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3281bc33ccabe1eeaae49f5f269d3b5fecf4a0896a208b1b5a4d28618274571c',2025,'GG','Guernsey','energy',7,'Electricity access:
electrification - total population:
100% (2021)','a05175d18d3663ad25c80fce0a2f9d8c3948b2fa4d1a94432259d1d8804cb39b','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c9ece40c51b427558a0ffbb9858e7a8ef85389582c7d0307bfb75b38c82fd422',2025,'GN','Guinea','energy',18,'Electricity access:
population without electricity:
7 million (2020)
electrification - total population:
46.8% (2021)
electrification - urban areas:
89.8% (2021)
electrification - rural areas:
21.2% (2021)
Electricity:
installed generating capacity:
992,000 kW (2020 est.)
consumption:
1.781 billion kWh (2019 est.)
exports:
0 kWh (2019 est.)
imports:
0 kWh (2019 est.)
transmission/distribution losses:
280 million kWh (2019 est.)
comparison rankings:
installed generating capacity 135; transmission/distribution losses 141; imports 135; exports 118; consumption 149
Electricity generation sources:
fossil fuels:
22.2% of total installed capacity (2020 est.)
solar:
0.7% of total installed capacity (2020 est.)
hydroelectricity:
77.1% of total installed capacity (2020 est.)
Petroleum:
total petroleum production:
0 bbl/day (2021 est.)
refined petroleum consumption:
19,800 bbl/day (2019 est.)
Refined petroleum products - imports:
18,460 bbl/day (2015 est.)
comparison ranking:
128
Carbon dioxide emissions:
2.981 million metric tonnes of CO2 (2019 est.)
comparison ranking:
total emissions 149
Energy consumption per capita:
4.133 million Btu/person (2019 est.)
comparison ranking:
173','396e5da080cf3d8d388f6c8822cb97fdb1a66f3f0d7f14c5cf0a774f1e656658','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('45f661276cf7331ffa8191eab727796e5a5a0af1a70fd7524c51d847fca34170',2025,'GW','Guinea-Bissau','energy',29,'Electricity access:
population without electricity:
1 million (2020)
electrification - total population:
35.7% (2021)
electrification - urban areas:
60.5% (2021)
electrification - rural areas:
15.8% (2021)
Electricity:
installed generating capacity:
28,000 kW (2020 est.)
consumption:
76.458 million kWh (2019 est.)
exports:
0 kWh (2019 est.)
imports:
0 kWh (2019 est.)
transmission/distribution losses:
6 million kWh (2019 est.)
comparison rankings:
installed generating capacity 202; transmission/distribution losses 200; imports 183; exports 176; consumption 199
Electricity generation sources:
fossil fuels:
97.6% of total installed capacity (2020 est.)
solar:
2.4% of total installed capacity (2020 est.)
Petroleum:
total petroleum production:
0 bbl/day (2021 est.)
refined petroleum consumption:
2,200 bbl/day (2019 est.)
Refined petroleum products - imports:
2,625 bbl/day (2015 est.)
comparison ranking:
186
Carbon dioxide emissions:
342,000 metric tonnes of CO2 (2019 est.)
from petroleum and other liquids:
342,000 metric tonnes of CO2 (2019 est.)
comparison ranking:
total emissions 193
Energy consumption per capita:
2.46 million Btu/person (2019 est.)
comparison ranking:
184','10f768469499bd4b46ed6de924c6d8dc082bd5ac8941866a99717da6540cfadd','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('05f1f37e781cc79325c2ae484b1b9d4a9e5f80c07466b69b37a49fec7fd9b669',2025,'GY','Guyana','energy',40,'Electricity access:
electrification - total population:
92.8% (2021)
electrification - urban areas:
97.5% (2021)
electrification - rural areas:
91.1% (2021.)
Electricity:
installed generating capacity:
380,000 kW (2020 est.)
consumption:
905.4 million kWh (2019 est.)
exports:
0 kWh (2019 est.)
imports:
0 kWh (2019 est.)
transmission/distribution losses:
247 million kWh (2019 est.)
comparison rankings:
installed generating capacity 156; transmission/distribution losses 144; imports 177; exports 169; consumption 164
Electricity generation sources:
fossil fuels:
97.4% of total installed capacity (2020 est.)
solar:
1.6% of total installed capacity (2020 est.)
biomass and waste:
0.9% of total installed capacity (2020 est.)
Petroleum:
total petroleum production:
110,200 bbl/day (2021 est.)
refined petroleum consumption:
18,100 bbl/day (2019 est.)
Refined petroleum products - imports:
13,720 bbl/day (2015 est.)
comparison ranking:
140
Carbon dioxide emissions:
2.743 million metric tonnes of CO2 (2019 est.)
from petroleum and other liquids:
2.743 million metric tonnes of CO2 (2019 est.)
comparison ranking:
total emissions 150
Energy consumption per capita:
48.608 million Btu/person (2019 est.)
comparison ranking:
102','59f701ed58a87268cba22d88441b142e77f633ed0615dcf5893a1a49a02885f0','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6cfbd5d254b052a2550dbee955161524360ad44b23a7271977fc8142fdccfb91',2025,'HT','Haiti','energy',7,'Electricity access:
population without electricity:
7 million (2020)
electrification - total population:
47.1% (2021)
electrification - urban areas:
81.8% (2021)
electrification - rural areas:
3% (2020)
Electricity:
installed generating capacity:
3.453 million kW (2020 est.)
consumption:
339 million kWh (2019 est.)
exports:
0 kWh (2019 est.)
imports:
0 kWh (2019 est.)
transmission/distribution losses:
643 million kWh (2019 est.)
comparison rankings:
installed generating capacity 103; transmission/distribution losses 123; imports 121; exports 101; consumption 178
Electricity generation sources:
fossil fuels:
85.8% of total installed capacity (2020 est.)
solar:
0.3% of total installed capacity (2020 est.)
hydroelectricity:
13.9% of total installed capacity (2020 est.)
Petroleum:
total petroleum production:
0 bbl/day (2021 est.)
refined petroleum consumption:
21,100 bbl/day (2019 est.)
Refined petroleum products - imports:
20,030 bbl/day (2015 est.)
comparison ranking:
122
Natural gas:
production:
0 cubic meters (2021 est.)
consumption:
3.341 million cubic meters (2020 est.)
exports:
0 cubic meters (2021 est.)
imports:
3.341 million cubic meters (2020 est.)
proven reserves:
0 cubic meters (2021 est.)
Carbon dioxide emissions:
3.139 million metric tonnes of CO2 (2019 est.)
from petroleum and other liquids:
3.137 million metric tonnes of CO2 (2019 est.)
from consumed natural gas:
2,000 metric tonnes of CO2 (2019 est.)
comparison ranking:
total emissions 148
Energy consumption per capita:
3.97 million Btu/person (2019 est.)
comparison ranking:
175','ff229c975498f8385d801d547c0caff6e28cae6439865a6d7881eef96a0f253e','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('662ae7d7436a4d8a29c951ddf1029a8149cf0f7820b903d95a7c2fc9ef4f98ae',2025,'HM','Heard Island and McDonald Islands','energy',27,'Electricity access:
electrification - total population:
100% (2021)','a05175d18d3663ad25c80fce0a2f9d8c3948b2fa4d1a94432259d1d8804cb39b','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b0cb65c7a23ff4286f0cd78eb29af49ca5faaf7e196f3bbe15face8a7a608b56',2025,'HN','Honduras','energy',37,'Electricity access:
population without electricity:
1 million (2020)
electrification - total population:
94.1% (2021)
electrification - urban areas:
100% (2021)
electrification - rural areas:
85.6% (2021)
Electricity:
installed generating capacity:
3.991 million kW (2020 est.)
consumption:
8,140,480,000 kWh (2019 est.)
exports:
540 million kWh (2019 est.)
imports:
787 million kWh (2019 est.)
transmission/distribution losses:
3.16 billion kWh (2019 est.)
comparison rankings:
installed generating capacity 97; transmission/distribution losses 65; imports 78; exports 74; consumption 108
Electricity generation sources:
fossil fuels:
46.7% of total installed capacity (2020 est.)
solar:
10.3% of total installed capacity (2020 est.)
wind:
7.5% of total installed capacity (2020 est.)
hydroelectricity:
24.7% of total installed capacity (2020 est.)
geothermal:
2.7% of total installed capacity (2020 est.)
biomass and waste:
8.1% of total installed capacity (2020 est.)
Coal:
production:
0 metric tons (2020 est.)
consumption:
25,000 metric tons (2020 est.)
exports:
0 metric tons (2020 est.)
imports:
25,000 metric tons (2020 est.)
proven reserves:
0 metric tons (2019 est.)
Petroleum:
total petroleum production:
0 bbl/day (2021 est.)
refined petroleum consumption:
66,800 bbl/day (2019 est.)
Refined petroleum products - exports:
12,870 bbl/day (2015 est.)
comparison ranking:
77
Refined petroleum products - imports:
56,120 bbl/day (2015 est.)
comparison ranking:
75
Carbon dioxide emissions:
8.523 million metric tonnes of CO2 (2019 est.)
from coal and metallurgical coke:
61,000 metric tonnes of CO2 (2019 est.)
from petroleum and other liquids:
8.462 million metric tonnes of CO2 (2019 est.)
comparison ranking:
total emissions 109
Energy consumption per capita:
19.8 million Btu/person (2019 est.)
comparison ranking:
134','75a044d810afcf060aba1947a4261e8613ed70a10c5662cc6cb2b376edd18c4e','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('83d3551baef7756ea151049c8e407e2ca7db38ae7183b88791cab4eb9dfd0053',2025,'HK','Hong Kong','energy',48,'Electricity access:
electrification - total population:
100% (2021)
Electricity:
installed generating capacity:
14.168 million kW (2020 est.)
consumption:
44,183,900,000 kWh (2020 est.)
exports:
0 kWh (2020 est.)
imports:
12.7 billion kWh (2020 est.)
transmission/distribution losses:
1.622 billion kWh (2020 est.)
comparison rankings:
transmission/distribution losses 95; imports 20; exports 110; consumption 55; installed generating capacity 56
Electricity generation sources:
fossil fuels:
99.6% of total installed capacity (2020 est.)
biomass and waste:
0.4% of total installed capacity (2020 est.)
Coal:
production:
0 metric tons (2020 est.)
consumption:
5.485 million metric tons (2020 est.)
exports:
0 metric tons (2020 est.)
imports:
5.485 million metric tons (2020 est.)
proven reserves:
0 metric tons (2019 est.)
Petroleum:
total petroleum production:
100 bbl/day (2021 est.)
refined petroleum consumption:
404,600 bbl/day (2019 est.)
Refined petroleum products - exports:
13,570 bbl/day (2015 est.)
comparison ranking:
76
Refined petroleum products - imports:
402,100 bbl/day (2015 est.)
comparison ranking:
22
Natural gas:
production:
0 cubic meters (2021 est.)
consumption:
4,913,021,000 cubic meters (2020 est.)
exports:
0 cubic meters (2021 est.)
imports:
4,913,021,000 cubic meters (2020 est.)
proven reserves:
0 cubic meters (2021 est.)
Carbon dioxide emissions:
92.493 million metric tonnes of CO2 (2019 est.)
from coal and metallurgical coke:
23.557 million metric tonnes of CO2 (2019 est.)
from petroleum and other liquids:
62.451 million metric tonnes of CO2 (2019 est.)
from consumed natural gas:
6.484 million metric tonnes of CO2 (2019 est.)
comparison ranking:
total emissions 46
Energy consumption per capita:
172.009 million Btu/person (2019 est.)
comparison ranking:
27','79782e0630b3dc36df66f9663c1af7f7a176adac1e9c655404dfb5e07993956b','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ea608fd2fa21f8f3addfbae3991681ffd3e8647657bc4aff57934e8fd3ea735a',2025,'HU','Hungary','energy',60,'Electricity access:
electrification - total population:
100% (2021)
Electricity:
installed generating capacity:
10.873 million kW (2020 est.)
consumption:
41.533 billion kWh (2020 est.)
exports:
7.498 billion kWh (2020 est.)
imports:
19.176 billion kWh (2020 est.)
transmission/distribution losses:
3.139 billion kWh (2020 est.)
comparison rankings:
transmission/distribution losses 66; imports 13; exports 24; consumption 57; installed generating capacity 62
Electricity generation sources:
fossil fuels:
36.1% of total installed capacity (2020 est.)
nuclear:
46% of total installed capacity (2020 est.)
solar:
7.4% of total installed capacity (2020 est.)
wind:
2% of total installed capacity (2020 est.)
hydroelectricity:
0.7% of total installed capacity (2020 est.)
tide and wave:
0.5% of total installed capacity (2020 est.)
geothermal:
0.1% of total installed capacity (2020 est.)
biomass and waste:
7.3% of total installed capacity (2020 est.)
Nuclear energy: Number of operational nuclear reactors:
4 (2023)
Number of nuclear reactors under construction:
0
Net capacity of operational nuclear reactors:
1.92GW (2023)
Percent of total electricity production:
46.8% (2021)
Percent of total energy produced:
44% (2021)
Number of nuclear reactors permanently shut down:
0
Coal:
production:
6.956 million metric tons (2020 est.)
consumption:
8.079 million metric tons (2020 est.)
exports:
230,000 metric tons (2020 est.)
imports:
1.395 million metric tons (2020 est.)
proven reserves:
2.909 billion metric tons (2019 est.)
Petroleum:
total petroleum production:
35,200 bbl/day (2021 est.)
refined petroleum consumption:
180,600 bbl/day (2019 est.)
crude oil and lease condensate exports:
8,000 bbl/day (2018 est.)
crude oil and lease condensate imports:
134,800 bbl/day (2018 est.)
crude oil estimated reserves:
12.1 million barrels (2021 est.)
Refined petroleum products - production:
152,400 bbl/day (2017 est.)
comparison ranking:
59
Refined petroleum products - exports:
58,720 bbl/day (2017 est.)
comparison ranking:
50
Refined petroleum products - imports:
82,110 bbl/day (2017 est.)
comparison ranking:
62
Natural gas:
production:
1.685 billion cubic meters (2020 est.)
consumption:
10.545 billion cubic meters (2020 est.)
exports:
3.758 billion cubic meters (2020 est.)
imports:
11.678 billion cubic meters (2020 est.)
proven reserves:
3.738 billion cubic meters (2021 est.)
Carbon dioxide emissions:
48.589 million metric tonnes of CO2 (2019 est.)
from coal and metallurgical coke:
7.501 million metric tonnes of CO2 (2019 est.)
from petroleum and other liquids:
21.568 million metric tonnes of CO2 (2019 est.)
from consumed natural gas:
19.52 million metric tonnes of CO2 (2019 est.)
comparison ranking:
total emissions 58
Energy consumption per capita:
108.212 million Btu/person (2019 est.)
comparison ranking:
50','96429aef4248eec1e2406eb4538bc115fac748bd312ac6258eb515d953b0a65c','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0ac72f97a750aaa3194566d8236e5b79ca1c9ce828487c5aa994f1d1e44d5b62',2025,'IS','Iceland','energy',7,'Electricity access:
electrification - total population:
100% (2021)
Electricity:
installed generating capacity:
2.967 million kW (2020 est.)
consumption:
17,912,066,000 kWh (2020 est.)
exports:
0 kWh (2020 est.)
imports:
0 kWh (2020 est.)
transmission/distribution losses:
519 million kWh (2020 est.)
comparison rankings:
transmission/distribution losses 129; imports 120; exports 100; consumption 74; installed generating capacity 108
Electricity generation sources:
hydroelectricity:
67.6% of total installed capacity (2020 est.)
geothermal:
32.3% of total installed capacity (2020 est.)
Coal:
production:
0 metric tons (2020 est.)
consumption:
142,000 metric tons (2020 est.)
exports:
0 metric tons (2020 est.)
imports:
136,000 metric tons (2020 est.)
proven reserves:
0 metric tons (2019 est.)
Petroleum:
total petroleum production:
0 bbl/day (2021 est.)
refined petroleum consumption:
19,700 bbl/day (2019 est.)
Refined petroleum products - exports:
2,530 bbl/day (2017 est.)
comparison ranking:
101
Refined petroleum products - imports:
20,220 bbl/day (2017 est.)
comparison ranking:
120
Carbon dioxide emissions:
3.337 million metric tonnes of CO2 (2019 est.)
from coal and metallurgical coke:
459,000 metric tonnes of CO2 (2019 est.)
from petroleum and other liquids:
2.879 million metric tonnes of CO2 (2019 est.)
comparison ranking:
total emissions 147','693e119acbcc04b2fe4dd14bb2250509053ff817cedf7110ea67e62af84a1889','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ed0b0b352e207710a31010e03baff2a6e633a583ef415c43936ccabe02bc14eb',2025,'IN','India','energy',18,'Electricity access:
population without electricity:
3 million (2020)
electrification - total population:
99.5% (2021)
electrification - urban areas:
100% (2021)
electrification - rural areas:
99.3% (2021)
Electricity:
installed generating capacity:
432.768 million kW (2020 est.)
consumption:
1,229,387,712,000 kWh (2019 est.)
exports:
9.491 billion kWh (2019 est.)
imports:
5.794 billion kWh (2019 est.)
transmission/distribution losses:
270.701 billion kWh (2019 est.)
comparison rankings:
installed generating capacity 3; transmission/distribution losses 2; imports 38; exports 21; consumption 3
Electricity generation sources:
fossil fuels:
75.5% of total installed capacity (2020 est.)
nuclear:
2.8% of total installed capacity (2020 est.)
solar:
4.2% of total installed capacity (2020 est.)
wind:
4.6% of total installed capacity (2020 est.)
hydroelectricity:
10.7% of total installed capacity (2020 est.)
biomass and waste:
2.3% of total installed capacity (2020 est.)
Nuclear energy: Number of operational nuclear reactors:
19 (2023)
Number of nuclear reactors under construction:
8
Net capacity of operational nuclear reactors:
6.29GW (2023)
Percent of total electricity production:
3% (2021)
Percent of total energy produced:
2.7% (2021)
Number of nuclear reactors permanently shut down:
0
Coal:
production:
743.214 million metric tons (2020 est.)
consumption:
883.979 million metric tons (2020 est.)
exports:
1.029 million metric tons (2020 est.)
imports:
219.212 million metric tons (2020 est.)
proven reserves:
105.931 billion metric tons (2019 est.)
Petroleum:
total petroleum production:
771,400 bbl/day (2021 est.)
refined petroleum consumption:
4,920,100 bbl/day (2019 est.)
crude oil and lease condensate exports:
0 bbl/day (2018 est.)
crude oil and lease condensate imports:
4.53 million bbl/day (2018 est.)
crude oil estimated reserves:
4,604,900,000 barrels (2021 est.)
Refined petroleum products - production:
4.897 million bbl/day (2015 est.)
comparison ranking:
4
Refined petroleum products - exports:
1.305 million bbl/day (2015 est.)
comparison ranking:
7
Refined petroleum products - imports:
653,300 bbl/day (2015 est.)
comparison ranking:
11
Natural gas:
production:
27,734,833,000 cubic meters (2020 est.)
consumption:
61,646,806,000 cubic meters (2020 est.)
exports:
91.916 million cubic meters (2019 est.)
imports:
33,911,973,000 cubic meters (2020 est.)
proven reserves:
1,380,614,000,000 cubic meters (2021 est.)
Carbon dioxide emissions:
2,314,738,000 metric tonnes of CO2 (2019 est.)
from coal and metallurgical coke:
1,574,331,000 metric tonnes of CO2 (2019 est.)
from petroleum and other liquids:
615.903 million metric tonnes of CO2 (2019 est.)
from consumed natural gas:
124.505 million metric tonnes of CO2 (2019 est.)
comparison ranking:
total emissions 3
Energy consumption per capita:
23.231 million Btu/person (2019 est.)
comparison ranking:
132','62b23d7f4cdfbc5093780058c6ba3eea8def8b075a2ea922e0471f37d78b3d67','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('57472697986272bbd53769e4332fca932e4a1a75f554c5442369b987b2d95dcb',2025,'ID','Indonesia','energy',38,'Electricity access:
population without electricity:
(2020) less than 1 million
electrification - total population:
99.2% (2021)
electrification - urban areas:
99.9% (2021)
electrification - rural areas:
98.2% (2021)
Electricity:
installed generating capacity:
69.065 million kW (2020 est.)
consumption:
256,742,190,000 kWh (2019 est.)
exports:
0 kWh (2020 est.)
imports:
1.553 billion kWh (2020 est.)
transmission/distribution losses:
25.08 billion kWh (2019 est.)
comparison rankings:
imports 64; exports 151; installed generating capacity 19; transmission/distribution losses 18; consumption 18
Electricity generation sources:
fossil fuels:
82.3% of total installed capacity (2020 est.)
wind:
0.2% of total installed capacity (2020 est.)
hydroelectricity:
6.8% of total installed capacity (2020 est.)
geothermal:
5.7% of total installed capacity (2020 est.)
biomass and waste:
5% of total installed capacity (2020 est.)
Coal:
production:
563.728 million metric tons (2020 est.)
consumption:
132.548 million metric tons (2020 est.)
exports:
409.892 million metric tons (2020 est.)
imports:
8.95 million metric tons (2020 est.)
proven reserves:
39.891 billion metric tons (2019 est.)
Petroleum:
total petroleum production:
842,300 bbl/day (2021 est.)
refined petroleum consumption:
1.649 million bbl/day (2019 est.)
crude oil and lease condensate exports:
204,000 bbl/day (2018 est.)
crude oil and lease condensate imports:
309,700 bbl/day (2018 est.)
crude oil estimated reserves:
2.48 billion barrels (2021 est.)
Refined petroleum products - production:
950,000 bbl/day (2015 est.)
comparison ranking:
18
Refined petroleum products - exports:
79,930 bbl/day (2015 est.)
comparison ranking:
47
Refined petroleum products - imports:
591,500 bbl/day (2015 est.)
comparison ranking:
15
Natural gas:
production:
62,612,013,000 cubic meters (2020 est.)
consumption:
38,673,953,000 cubic meters (2020 est.)
exports:
23,938,060,000 cubic meters (2020 est.)
imports:
0 cubic meters (2021 est.)
proven reserves:
1,408,478,000,000 cubic meters (2021 est.)
Carbon dioxide emissions:
563.543 million metric tonnes of CO2 (2019 est.)
from coal and metallurgical coke:
267.326 million metric tonnes of CO2 (2019 est.)
from petroleum and other liquids:
209.279 million metric tonnes of CO2 (2019 est.)
from consumed natural gas:
86.938 million metric tonnes of CO2 (2019 est.)
comparison ranking:
total emissions 11
Energy consumption per capita:
29.68 million Btu/person (2019 est.)
comparison ranking:
122','7ab93b63f3ca40e7931ba7144cb619ca3d4a8500aab7ea7f906705fde5a6c85b','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3f0126a7c84e723eafbf865d4ade4fb36614fb4b24a2bca1d9492051c125db29',2025,'ID','Indonesia','energy',51,'Electricity access:
electrification - total population:
100% (2021)
Electricity:
installed generating capacity:
80.553 million kW (2020 est.)
consumption:
279,826,390,000 kWh (2019 est.)
exports:
6.365 billion kWh (2019 est.)
imports:
2.738 billion kWh (2019 est.)
transmission/distribution losses:
34.303 billion kWh (2019 est.)
comparison rankings:
installed generating capacity 17; transmission/distribution losses 10; imports 54; exports 29; consumption 14
Electricity generation sources:
fossil fuels:
88.7% of total installed capacity (2020 est.)
nuclear:
1.9% of total installed capacity (2020 est.)
solar:
0.1% of total installed capacity (2020 est.)
wind:
0.2% of total installed capacity (2020 est.)
hydroelectricity:
9.1% of total installed capacity (2020 est.)
tide and wave:
0% of total installed capacity (2020 est.)
geothermal:
0% of total installed capacity (2020 est.)
biomass and waste:
0% of total installed capacity (2020 est.)
Nuclear energy: Number of operational nuclear reactors:
1 (2023)
Number of nuclear reactors under construction:
1
Net capacity of operational nuclear reactors:
0.92GW (2023)
Percent of total electricity production:
0.1% (2021)
Percent of total energy produced:
0.19% (2021)
Number of nuclear reactors permanently shut down:
0
Coal:
production:
2.783 million metric tons (2020 est.)
consumption:
2.794 million metric tons (2020 est.)
exports:
76,000 metric tons (2020 est.)
imports:
87,000 metric tons (2020 est.)
proven reserves:
1.203 billion metric tons (2019 est.)
Petroleum:
total petroleum production:
3,450,300 bbl/day (2021 est.)
refined petroleum consumption:
1.934 million bbl/day (2019 est.)
crude oil and lease condensate exports:
2,230,900 bbl/day (2018 est.)
crude oil and lease condensate imports:
33,500 bbl/day (2018 est.)
crude oil estimated reserves:
208.6 billion barrels (2021 est.)
Refined petroleum products - production:
1.764 million bbl/day (2015 est.)
comparison ranking:
11
Refined petroleum products - exports:
397,200 bbl/day (2015 est.)
comparison ranking:
21
Refined petroleum products - imports:
64,160 bbl/day (2015 est.)
comparison ranking:
72
Natural gas:
production:
237,561,415,000 cubic meters (2019 est.)
consumption:
220,704,282,000 cubic meters (2019 est.)
exports:
17,607,046,000 cubic meters (2019 est.)
imports:
1,153,457,000 cubic meters (2019 est.)
proven reserves:
33,987,296,000,000 cubic meters (2021 est.)
Carbon dioxide emissions:
646.038 million metric tonnes of CO2 (2019 est.)
from coal and metallurgical coke:
5.142 million metric tonnes of CO2 (2019 est.)
from petroleum and other liquids:
204.21 million metric tonnes of CO2 (2019 est.)
from consumed natural gas:
436.687 million metric tonnes of CO2 (2019 est.)
comparison ranking:
total emissions 8
Energy consumption per capita:
145.54 million Btu/person (2019 est.)
comparison ranking:
36','835b79f7eb8e59a9da6b87052ed8c58b13833cbdf46e946c5ca0374e76e9d525','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6aafb60a4df8b76a5aee1cb2748a5819e042d9a2b1c9dacb9f2625bbdb86a93c',2025,'IQ','Iraq','energy',7,'Electricity access:
electrification - total population:
100% (2021)
Electricity:
installed generating capacity:
28.369 million kW (2020 est.)
consumption:
46.493 billion kWh (2019 est.)
exports:
0 kWh (2019 est.)
imports:
14.18 billion kWh (2019 est.)
transmission/distribution losses:
58.502 billion kWh (2019 est.)
comparison rankings:
installed generating capacity 37; transmission/distribution losses 6; imports 16; exports 132; consumption 53
Electricity generation sources:
fossil fuels:
97.8% of total installed capacity (2020 est.)
solar:
0.1% of total installed capacity (2020 est.)
hydroelectricity:
2.1% of total installed capacity (2020 est.)
Petroleum:
total petroleum production:
4.162 million bbl/day (2021 est.)
refined petroleum consumption:
863,300 bbl/day (2019 est.)
crude oil and lease condensate exports:
3.976 million bbl/day (2018 est.)
crude oil and lease condensate imports:
0 bbl/day (2018 est.)
crude oil estimated reserves:
145.019 billion barrels (2021 est.)
Refined petroleum products - production:
398,000 bbl/day (2015 est.)
comparison ranking:
37
Refined petroleum products - exports:
8,284 bbl/day (2015 est.)
comparison ranking:
86
Refined petroleum products - imports:
255,100 bbl/day (2015 est.)
comparison ranking:
28
Natural gas:
production:
10.711 billion cubic meters (2019 est.)
consumption:
18.014 billion cubic meters (2019 est.)
exports:
0 cubic meters (2021 est.)
imports:
7.303 billion cubic meters (2019 est.)
proven reserves:
3.729 trillion cubic meters (2021 est.)
Carbon dioxide emissions:
143.479 million metric tonnes of CO2 (2019 est.)
from coal and metallurgical coke:
0 metric tonnes of CO2 (2019 est.)
from petroleum and other liquids:
108.14 million metric tonnes of CO2 (2019 est.)
from consumed natural gas:
35.339 million metric tonnes of CO2 (2019 est.)
comparison ranking:
total emissions 35
Energy consumption per capita:
63.174 million Btu/person (2019 est.)
comparison ranking:
88','448c15dd82ef1e89f941424b49c261ba3f608a868cdc1b8d6b849a76d304a9b5','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('657d320e243a8b08484d188fbaa9ed4d90bbd637c1262c37169293caafd4396d',2025,'IE','Ireland','energy',20,'Electricity access:
electrification - total population:
100% (2021)
Electricity:
installed generating capacity:
11.43 million kW (2020 est.)
consumption:
30.627 billion kWh (2020 est.)
exports:
1.913 billion kWh (2020 est.)
imports:
1.761 billion kWh (2020 est.)
transmission/distribution losses:
2.309 billion kWh (2020 est.)
comparison rankings:
transmission/distribution losses 80; imports 59; exports 52; consumption 64; installed generating capacity 59
Electricity generation sources:
fossil fuels:
57.8% of total installed capacity (2020 est.)
solar:
0.2% of total installed capacity (2020 est.)
wind:
34.8% of total installed capacity (2020 est.)
hydroelectricity:
3.7% of total installed capacity (2020 est.)
biomass and waste:
3.6% of total installed capacity (2020 est.)
Coal:
production:
0 metric tons (2020 est.)
consumption:
351,000 metric tons (2020 est.)
exports:
132,000 metric tons (2020 est.)
imports:
408,000 metric tons (2020 est.)
proven reserves:
14 million metric tons (2019 est.)
Petroleum:
total petroleum production:
600 bbl/day (2021 est.)
refined petroleum consumption:
159,100 bbl/day (2019 est.)
crude oil and lease condensate exports:
0 bbl/day (2018 est.)
crude oil and lease condensate imports:
60,300 bbl/day (2018 est.)
crude oil estimated reserves:
0 barrels (2021 est.)
Refined petroleum products - production:
64,970 bbl/day (2017 est.)
comparison ranking:
76
Refined petroleum products - exports:
37,040 bbl/day (2017 est.)
comparison ranking:
59
Refined petroleum products - imports:
126,600 bbl/day (2017 est.)
comparison ranking:
47
Natural gas:
production:
2.652 billion cubic meters (2019 est.)
consumption:
5.492 billion cubic meters (2019 est.)
exports:
0 cubic meters (2021 est.)
imports:
2.847 billion cubic meters (2019 est.)
proven reserves:
9.911 billion cubic meters (2021 est.)
Carbon dioxide emissions:
35.475 million metric tonnes of CO2 (2019 est.)
from coal and metallurgical coke:
1.43 million metric tonnes of CO2 (2019 est.)
from petroleum and other liquids:
23.08 million metric tonnes of CO2 (2019 est.)
from consumed natural gas:
10.965 million metric tonnes of CO2 (2019 est.)
comparison ranking:
total emissions 71
Energy consumption per capita:
133.674 million Btu/person (2019 est.)
comparison ranking:
41','eb71f08cbae2ea7542f623edcd5963b9743cffe6ffea04f0fa398d72e07e12da','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f72404d2c992765e47ce065b631964b4156235ff9c2ebda5245d6c76b75115f6',2025,'IM','Isle of Man','energy',32,'Electricity access:
electrification - total population:
100% (2021)','a05175d18d3663ad25c80fce0a2f9d8c3948b2fa4d1a94432259d1d8804cb39b','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('86a4cb0dd6c7b6be8f407ae543106cbbf3171cee4e2056c8b6be8d90ab38a046',2025,'IL','Israel','energy',43,'Electricity access:
electrification - total population:
100% (2021)
Electricity:
installed generating capacity:
18.993 million kW (2020 est.)
consumption:
59,192,500,000 kWh (2019 est.)
exports:
6.243 billion kWh (2020 est.)
imports:
0 kWh (2020 est.)
transmission/distribution losses:
2.642 billion kWh (2019 est.)
comparison rankings:
imports 175; exports 30; installed generating capacity 50; transmission/distribution losses 73; consumption 46
Electricity generation sources:
fossil fuels:
93.7% of total installed capacity (2020 est.)
solar:
5.9% of total installed capacity (2020 est.)
wind:
0.3% of total installed capacity (2020 est.)
Coal:
production:
0 metric tons (2020 est.)
consumption:
5.089 million metric tons (2020 est.)
exports:
0 metric tons (2020 est.)
imports:
5.565 million metric tons (2020 est.)
proven reserves:
0 metric tons (2019 est.)
Petroleum:
total petroleum production:
0 bbl/day (2021 est.)
refined petroleum consumption:
232,400 bbl/day (2019 est.)
crude oil and lease condensate exports:
0 bbl/day (2018 est.)
crude oil and lease condensate imports:
232,900 bbl/day (2018 est.)
crude oil estimated reserves:
12.7 million barrels (2021 est.)
Refined petroleum products - production:
294,300 bbl/day (2017 est.)
comparison ranking:
42
Refined petroleum products - exports:
111,700 bbl/day (2017 est.)
comparison ranking:
39
Refined petroleum products - imports:
98,860 bbl/day (2017 est.)
comparison ranking:
54
Natural gas:
production:
10.474 billion cubic meters (2019 est.)
consumption:
9.442 billion cubic meters (2019 est.)
exports:
0 cubic meters (2021 est.)
imports:
820.508 million cubic meters (2019 est.)
proven reserves:
176.017 billion cubic meters (2021 est.)
Carbon dioxide emissions:
61.092 million metric tonnes of CO2 (2019 est.)
from coal and metallurgical coke:
13.653 million metric tonnes of CO2 (2019 est.)
from petroleum and other liquids:
29.416 million metric tonnes of CO2 (2019 est.)
from consumed natural gas:
18.023 million metric tonnes of CO2 (2019 est.)
comparison ranking:
total emissions 53
Energy consumption per capita:
113.273 million Btu/person (2019 est.)
comparison ranking:
47','e1daae509af825bc3707261bc552b7d572962abea3ee1acb0d311d8ba8abc6c5','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('be3e64e384ba75eea1ee0e4250888eb5cf555960029f8c2ec439d375c024f645',2025,'IT','Italy','energy',56,'Electricity access:
electrification - total population: 100% (2021)
Electricity:
installed generating capacity: 121.442 million kW (2020 est.)
consumption:
286.375 billion kWh (2020 est.)
exports:
7.587 billion kWh (2020 est.)
imports:
39.787 billion kWh (2020 est.)
transmission/distribution losses:
17.702 billion kWh (2020 est.)
comparison rankings:
transmission/distribution losses 23; imports 3; exports 23; consumption 13; installed generating capacity 11
Electricity generation sources:
fossil fuels: 55.9% of total installed capacity (2020 est.)
solar:
9.2% of total installed capacity (2020 est.)
wind:
6.9% of total installed capacity (2020 est.)
hydroelectricity:
17.5% of total installed capacity (2020 est.)
tide and wave:
0.2% of total installed capacity (2020 est.)
geothermal:
2.2% of total installed capacity (2020 est.)
biomass and waste:
8.1% of total installed capacity (2020 est.)
Nuclear energy: Number of operational nuclear reactors:
0
Number of nuclear reactors under construction:
0
Net capacity of operational nuclear reactors:
0GW
Percent of total electricity production:
0%
Percent of total energy produced:
0%
Number of nuclear reactors permanently shut down:
4
Coal:
production: 1.456 million metric tons (2020 est.)
consumption:
9.335 million metric tons (2020 est.)
exports:
368,000 metric tons (2020 est.)
imports:
8.235 million metric tons (2020 est.)
proven reserves:
17 million metric tons (2019 est.)
Petroleum:
total petroleum production: 107,700 bbl/day (2021 est.)
refined petroleum consumption:
1,255,100 bbl/day (2019 est.)
crude oil and lease condensate exports:
10,100 bbl/day (2018 est.)
crude oil and lease condensate imports:
1.253 million bbl/day (2018 est.)
crude oil estimated reserves:
497.9 million barrels (2021 est.)
Refined petroleum products - production:
1.607 million bbl/day (2017 est.)
comparison ranking:
12
Refined petroleum products - exports:
615,900 bbl/day (2017 est.)
comparison ranking:
13
Refined petroleum products - imports:
422,500 bbl/day (2017 est.)
comparison ranking:
19
Natural gas:
production: 3,888,491,000 cubic meters (2020 est.)
consumption:
74,313,109,000 cubic meters (2019 est.)
exports:
314.656 million cubic meters (2020 est.)
imports:
70,908,014,000 cubic meters (2019 est.)
proven reserves:
45.76 billion cubic meters (2021 est.)
Carbon dioxide emissions:
332.041 million metric tonnes of CO2 (2019 est.)
from coal and metallurgical coke:
27.194 million metric tonnes of CO2 (2019 est.)
from petroleum and other liquids:
162.472 million metric tonnes of CO2 (2019 est.)
from consumed natural gas:
142.375 million metric tonnes of CO2 (2019 est.)
comparison ranking:
total emissions 19
Energy consumption per capita:
112.606 million Btu/person (2019 est.)
comparison ranking:
49','325fb3ad9d4d77643d0c641f8c991548d4e4d9ed40dc04dc0a42f6ae3013447e','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('094b4c838a3009daa374b8d3dc82ce41b81d3be5f5772b838c8793444ec2aae9',2025,'JM','Jamaica','energy',7,'Electricity access:
electrification - total population:
100% (2021)
Electricity:
installed generating capacity:
1.216 million kW (2020 est.)
consumption:
3,050,780,000 kWh (2019 est.)
exports:
0 kWh (2020 est.)
imports:
0 kWh (2020 est.)
transmission/distribution losses:
1.149 billion kWh (2019 est.)
comparison rankings:
imports 161; exports 148; installed generating capacity 131; transmission/distribution losses 109; consumption 139
Electricity generation sources:
fossil fuels:
87.5% of total installed capacity (2020 est.)
solar:
1.2% of total installed capacity (2020 est.)
wind:
6.8% of total installed capacity (2020 est.)
hydroelectricity:
4% of total installed capacity (2020 est.)
biomass and waste:
0.6% of total installed capacity (2020 est.)
Coal:
production:
0 metric tons (2020 est.)
consumption:
61,000 metric tons (2020 est.)
exports:
0 metric tons (2020 est.)
imports:
82,000 metric tons (2020 est.)
proven reserves:
0 metric tons (2019 est.)
Petroleum:
total petroleum production:
3,000 bbl/day (2021 est.)
refined petroleum consumption:
61,100 bbl/day (2019 est.)
crude oil and lease condensate exports:
0 bbl/day (2018 est.)
crude oil and lease condensate imports:
20,100 bbl/day (2018 est.)
crude oil estimated reserves:
0 barrels (2021 est.)
Refined petroleum products - production:
24,250 bbl/day (2017 est.)
comparison ranking:
87
Refined petroleum products - exports:
823 bbl/day (2015 est.)
comparison ranking:
109
Refined petroleum products - imports:
30,580 bbl/day (2015 est.)
comparison ranking:
100
Natural gas:
production:
0 cubic meters (2021 est.)
consumption:
693.422 million cubic meters (2020 est.)
exports:
0 cubic meters (2021 est.)
imports:
667.115 million cubic meters (2020 est.)
proven reserves:
0 cubic meters (2021 est.)
Carbon dioxide emissions:
10.002 million metric tonnes of CO2 (2019 est.)
from coal and metallurgical coke:
177,000 metric tonnes of CO2 (2019 est.)
from petroleum and other liquids:
9.276 million metric tonnes of CO2 (2019 est.)
from consumed natural gas:
549,000 metric tonnes of CO2 (2019 est.)
comparison ranking:
total emissions 106
Energy consumption per capita:
49.7 million Btu/person (2019 est.)
comparison ranking:
101','cc7b0e8f420b043439627595192d24f120cbb21cd0440f1282b24aaf29eca2ae','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('016896c9119401546eaf16e3677c2d2cf6dd868753ab8a1cd8a71d27ce87cc34',2025,'JP','Japan','energy',27,'Electricity access:
electrification - total population:
100% (2021)
Electricity:
installed generating capacity:
348.666 million kW (2020 est.)
consumption:
903,698,740,000 kWh (2019 est.)
exports:
0 kWh (2020 est.)
imports:
0 kWh (2020 est.)
transmission/distribution losses:
44.094 billion kWh (2019 est.)
comparison rankings:
imports 156; exports 143; installed generating capacity 4; transmission/distribution losses 7; consumption 5
Electricity generation sources:
fossil fuels:
73.5% of total installed capacity (2020 est.)
nuclear:
4.8% of total installed capacity (2020 est.)
solar:
8.8% of total installed capacity (2020 est.)
wind:
1% of total installed capacity (2020 est.)
hydroelectricity:
10% of total installed capacity (2020 est.)
geothermal:
0.3% of total installed capacity (2020 est.)
biomass and waste:
1.6% of total installed capacity (2020 est.)
Nuclear energy: Number of operational nuclear reactors:
10 (2023)
Number of nuclear reactors under construction:
2
Net capacity of operational nuclear reactors:
9.49GW (2023)
Percent of total electricity production:
7% (2018)
Percent of total energy produced:
24% (2021)
Number of nuclear reactors permanently shut down:
17
Coal:
production:
29.84 million metric tons (2020 est.)
consumption:
210.882 million metric tons (2020 est.)
exports:
3.201 million metric tons (2020 est.)
imports:
174.486 million metric tons (2020 est.)
proven reserves:
350 million metric tons (2019 est.)
Petroleum:
total petroleum production:
10,200 bbl/day (2021 est.)
refined petroleum consumption:
3,739,300 bbl/day (2019 est.)
crude oil and lease condensate exports:
0 bbl/day (2018 est.)
crude oil and lease condensate imports:
3,012,800 bbl/day (2018 est.)
crude oil estimated reserves:
44.1 million barrels (2021 est.)
Refined petroleum products - production:
3.467 million bbl/day (2017 est.)
comparison ranking:
5
Refined petroleum products - exports:
370,900 bbl/day (2017 est.)
comparison ranking:
24
Refined petroleum products - imports:
1.1 million bbl/day (2017 est.)
comparison ranking:
5
Natural gas:
production:
1,928,431,000 cubic meters (2020 est.)
consumption:
102,108,738,000 cubic meters (2019 est.)
exports:
28,000 cubic meters (2019 est.)
imports:
105,255,103,000 cubic meters (2019 est.)
proven reserves:
20.898 billion cubic meters (2021 est.)
note:
Japan had been the largest global liquefied natural gas (LNG) importer until 2021 when it was exceeded by China; prior to 2021, Japan had been the largest importer of LNG for 51 years; Japan has the largest LNG storage tank capacity in the world, or about 643 million cubic feet (MMcf) as of early 2020; in 2019, Japan sourced 28% of its LNG imports from regional suppliers in Southeast Asia and 39% from Australia
Carbon dioxide emissions:
1,103,234,000 metric tonnes of CO2 (2019 est.)
from coal and metallurgical coke:
439.243 million metric tonnes of CO2 (2019 est.)
from petroleum and other liquids:
444.271 million metric tonnes of CO2 (2019 est.)
from consumed natural gas:
219.72 million metric tonnes of CO2 (2019 est.)
comparison ranking:
total emissions 5
Energy consumption per capita:
147.107 million Btu/person (2019 est.)
comparison ranking:
35','f4a16f283e0a3ec0af935fa3915953dae48e3a4cfd62141a80ded1eee502c7da','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('279f5a1fab74a1858b7309289510ce773cedddc492f74160523d0d740df19c01',2025,'JE','Jersey','energy',39,'Electricity access:
electrification - total population:
100% (2021)
Carbon dioxide emissions:
450,000 metric tonnes of CO2 (2012 est.)
comparison ranking:
total emissions 190','f7d237d94480028bbc5eb3a233c0119e53844fce2cd6b2674f23962d2d652b25','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('994dad2ca1ad4e81390bf5f5229cc1749af5adb9a2b63b1895c918ad24b357a8',2025,'JO','Jordan','energy',50,'Electricity access:
population without electricity:
(2020) less than 1 million
electrification - total population:
99.9% (2021)
electrification - urban areas:
100% (2021)
electrification - rural areas:
98.8% (2021)
Electricity:
installed generating capacity:
5.644 million kW (2020 est.)
consumption:
17.366 billion kWh (2019 est.)
exports:
98 million kWh (2019 est.)
imports:
239 million kWh (2019 est.)
transmission/distribution losses:
2.249 billion kWh (2019 est.)
comparison rankings:
installed generating capacity 83; transmission/distribution losses 83; imports 101; exports 92; consumption 75
Electricity generation sources:
fossil fuels:
83.5% of total installed capacity (2020 est.)
solar:
11.7% of total installed capacity (2020 est.)
wind:
4.6% of total installed capacity (2020 est.)
hydroelectricity:
0.2% of total installed capacity (2020 est.)
Coal:
production:
0 metric tons (2020 est.)
consumption:
219,000 metric tons (2020 est.)
exports:
0 metric tons (2020 est.)
imports:
219,000 metric tons (2020 est.)
proven reserves:
0 metric tons (2019 est.)
Petroleum:
total petroleum production:
0 bbl/day (2021 est.)
refined petroleum consumption:
114,800 bbl/day (2019 est.)
crude oil and lease condensate exports:
0 bbl/day (2018 est.)
crude oil and lease condensate imports:
47,400 bbl/day (2018 est.)
crude oil estimated reserves:
1 million barrels (2021 est.)
Refined petroleum products - production:
67,240 bbl/day (2015 est.)
comparison ranking:
73
Refined petroleum products - imports:
68,460 bbl/day (2015 est.)
comparison ranking:
68
Natural gas:
production:
115.872 million cubic meters (2019 est.)
consumption:
4.651 billion cubic meters (2019 est.)
exports:
375.849 million cubic meters (2019 est.)
imports:
4.911 billion cubic meters (2019 est.)
proven reserves:
6.031 billion cubic meters (2021 est.)
Carbon dioxide emissions:
23.47 million metric tonnes of CO2 (2019 est.)
from coal and metallurgical coke:
381,000 metric tonnes of CO2 (2019 est.)
from petroleum and other liquids:
15.786 million metric tonnes of CO2 (2019 est.)
from consumed natural gas:
7.303 million metric tonnes of CO2 (2019 est.)
comparison ranking:
total emissions 82
Energy consumption per capita:
39.331 million Btu/person (2019 est.)
comparison ranking:
108','dbd965f63e24e5c39543e5122ef2eca1e1eebcdd93e23abce4ef5a9022cd65b5','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('742bb13212d28bcd0b593679126c00959dbea7854231c06651759e8f820edf41',2025,'KZ','Kazakhstan','energy',7,'Electricity access:
electrification - total population: 100%
(2021)
Electricity:
installed generating capacity: 25.022
million kW (2020 est.)
consumption:
92,133,960,000 kWh (2019 est.)
exports:
2.419 billion kWh (2019 est.)
imports:
1.935 billion kWh (2019 est.)
transmission/distribution losses:
9.689 billion kWh (2019 est.)
comparison rankings:
installed generating capacity 40; transmission/distribution losses 34; imports 57; exports 48; consumption 34
Electricity generation sources:
fossil fuels: 88.2%
of total installed capacity (2020 est.)
solar:
0.9% of total installed capacity (2020 est.)
wind:
0.7% of total installed capacity (2020 est.)
hydroelectricity:
10.1% of total installed capacity (2020 est.)
Nuclear energy: Number of operational nuclear reactors:
0
Number of nuclear reactors under construction:
0
Net capacity of operational nuclear reactors:
0GW
Percent of total electricity production:
0%
Percent of total energy produced:
0%
Number of nuclear reactors permanently shut down:
1
Coal:
production: 102.338
million metric tons (2020 est.)
consumption:
74.819 million metric tons (2020 est.)
exports:
3.002 million metric tons (2020 est.)
imports:
993,000 metric tons (2020 est.)
proven reserves:
25.605 billion metric tons (2019 est.)
Petroleum:
total petroleum production: 1,864,900
bbl/day (2021 est.)
refined petroleum consumption:
320,600 bbl/day (2019 est.)
crude oil and lease condensate exports:
1,531,600 bbl/day (2018 est.)
crude oil and lease condensate imports:
500 bbl/day (2018 est.)
crude oil estimated reserves:
30 billion barrels (2021 est.)
Refined petroleum products - production:
290,700 bbl/day (2015 est.)
comparison ranking:
44
Refined petroleum products - exports:
105,900 bbl/day (2015 est.)
comparison ranking:
41
Refined petroleum products - imports:
39,120 bbl/day (2015 est.)
comparison ranking:
90
Natural gas:
production: 25.786
billion cubic meters (2019 est.)
consumption:
14.557 billion cubic meters (2019 est.)
exports:
16.418 billion cubic meters (2019 est.)
imports:
7.714 billion cubic meters (2019 est.)
proven reserves:
2.407 trillion cubic meters (2021 est.)
Carbon dioxide emissions:
263.689 million metric tonnes of CO2 (2019 est.)
from coal and metallurgical coke:
195.926 million metric tonnes of CO2 (2019 est.)
from petroleum and other liquids:
39.205 million metric tonnes of CO2 (2019 est.)
from consumed natural gas:
28.557 million metric tonnes of CO2 (2019 est.)
comparison ranking:
total emissions 25
Energy consumption per capita:
180.726 million Btu/person (2019 est.)
comparison ranking:
23','46e3ffdd3490492bbed0df5e3ca2a82d8235b4179caca1ecd766a0468cffbbd5','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9c1b04f181094aee109a05383174cd268b093f9c0c587362ab58bcbd55d7eb25',2025,'KE','Kenya','energy',19,'Electricity access:
population without electricity: 12
million (2020)
electrification - total population:
76.5% (2021)
electrification - urban areas:
97.5% (2021)
electrification - rural areas:
68.1% (2021)
Electricity:
installed generating capacity: 3.304
million kW (2020 est.)
consumption:
8.243 billion kWh (2019 est.)
exports:
16 million kWh (2019 est.)
imports:
277 million kWh (2019 est.)
transmission/distribution losses:
2.724 billion kWh (2019 est.)
comparison rankings:
installed generating capacity 104; transmission/distribution losses 71; imports 97; exports 95; consumption 106
Electricity generation sources:
fossil fuels: 8.3%
of total installed capacity (2020 est.)
solar:
1% of total installed capacity (2020 est.)
wind:
10.7% of total installed capacity (2020 est.)
hydroelectricity:
32.6% of total installed capacity (2020 est.)
geothermal:
46.2% of total installed capacity (2020 est.)
biomass and waste:
1.2% of total installed capacity (2020 est.)
Coal:
production: 0
metric tons (2020 est.)
consumption:
821,000 metric tons (2020 est.)
exports:
0 metric tons (2020 est.)
imports:
822,000 metric tons (2020 est.)
proven reserves:
0 metric tons (2019 est.)
Petroleum:
total petroleum production: 0
bbl/day (2021 est.)
refined petroleum consumption:
116,400 bbl/day (2019 est.)
Refined petroleum products - production:
13,960 bbl/day (2015 est.)
comparison ranking:
96
Refined petroleum products - exports:
173 bbl/day (2015 est.)
comparison ranking:
118
Refined petroleum products - imports:
90,620 bbl/day (2015 est.)
comparison ranking:
57
Natural gas:
production: 0
cubic meters (2021 est.)
consumption:
0 cubic meters (2021 est.)
exports:
0 cubic meters (2021 est.)
imports:
0 cubic meters (2021 est.)
proven reserves:
0 cubic meters (2021 est.)
Carbon dioxide emissions:
17.709 million metric tonnes of CO2 (2019 est.)
from coal and metallurgical coke:
1.25 million metric tonnes of CO2 (2019 est.)
from petroleum and other liquids:
16.459 million metric tonnes of CO2 (2019 est.)
from consumed natural gas:
0 metric tonnes of CO2 (2019 est.)
comparison ranking:
total emissions 90
Energy consumption per capita:
6.31 million Btu/person (2019 est.)
comparison ranking:
166','1d7056cca49533c5eb37bdc8a985b653e7e1f9fdeab872645694f74d6b5beb2d','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('890db15a67b491f075652b06c53ab3bf72b4b65190570a4902ca24bcea9a0a86',2025,'KI','Kiribati','energy',32,'Electricity access:
electrification - total population: 92.8%
(2020)
electrification - urban areas:
88.2% (2021)
Electricity:
installed generating capacity: 11,000
kW (2020 est.)
consumption:
25.137 million kWh (2019 est.)
exports:
0 kWh (2020 est.)
imports:
0 kWh (2020 est.)
transmission/distribution losses:
4.7 million kWh (2019 est.)
comparison rankings:
imports 160; exports 146; installed generating capacity 207; transmission/distribution losses 203; consumption 205
Electricity generation sources:
fossil fuels: 84.9%
of total installed capacity (2020 est.)
solar:
15.1% of total installed capacity (2020 est.)
Petroleum:
total petroleum production: 0
bbl/day (2021 est.)
refined petroleum consumption:
500 bbl/day (2019 est.)
Refined petroleum products - imports:
420 bbl/day (2015 est.)
comparison ranking:
206
Carbon dioxide emissions:
76,000 metric tonnes of CO2 (2019 est.)
from petroleum and other liquids:
76,000 metric tonnes of CO2 (2019 est.)
comparison ranking:
total emissions 210
Energy consumption per capita:
9.335 million Btu/person (2019 est.)
comparison ranking:
156','64e3dda799f311d74d66838aa5a7385b707e97f4df8da0a05b6884da0d974731','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9a818faf7a95f64e9c6d8863e330be6ac58d51208226045e4508c8cea52c95c5',2025,'KI','Kiribati','energy',43,'Electricity access:
population without electricity: 19
million (2020)
electrification - total population:
52.6% (2021)
electrification - urban areas:
36% (2020)
electrification - rural areas:
11% (2020)
Electricity:
installed generating capacity: 8.413
million kW (2020 est.)
consumption:
13,930,320,000 kWh (2019 est.)
exports:
0 kWh (2020 est.)
imports:
0 kWh (2020 est.)
transmission/distribution losses:
2.146 billion kWh (2019 est.)
comparison rankings:
imports 191; exports 186; installed generating capacity 72; transmission/distribution losses 86; consumption 84
Electricity generation sources:
fossil fuels: 15.8%
of total installed capacity (2020 est.)
solar:
0.1% of total installed capacity (2020 est.)
hydroelectricity:
84.1% of total installed capacity (2020 est.)
Coal:
production: 16.376
million metric tons (2020 est.)
consumption:
6.698 million metric tons (2020 est.)
exports:
0 metric tons (2020 est.)
imports:
22,000 metric tons (2020 est.)
proven reserves:
600 million metric tons (2019 est.)
Petroleum:
total petroleum production: 0
bbl/day (2021 est.)
refined petroleum consumption:
20,300 bbl/day (2019 est.)
crude oil and lease condensate exports:
0 bbl/day (2018 est.)
crude oil and lease condensate imports:
10,600 bbl/day (2018 est.)
crude oil estimated reserves:
0 barrels (2021 est.)
Refined petroleum products - production:
11,270 bbl/day (2015 est.)
comparison ranking:
99
Refined petroleum products - exports:
0 bbl/day (2015 est.)
comparison ranking:
156
Refined petroleum products - imports:
8,260 bbl/day (2015 est.)
comparison ranking:
151
Carbon dioxide emissions:
18.465 million metric tonnes of CO2 (2019 est.)
from coal and metallurgical coke:
15.252 million metric tonnes of CO2 (2019 est.)
from petroleum and other liquids:
3.213 million metric tonnes of CO2 (2019 est.)
comparison ranking:
total emissions 87
Energy consumption per capita:
12.61 million Btu/person (2019 est.)
comparison ranking:
146','5220ac8232b8bc88654fcb1aca3993fd23be0954091de27c20e164b268514110','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8e38b40d591182c4c0155b732b314f14c2d5ba302053f843d27f622adea14fb7',2025,'KW','Kuwait','energy',11,'Electricity access:
electrification - total population: 100%
(2021)
Electricity:
installed generating capacity: 19.371
million kW (2020 est.)
consumption:
63,802,360,000 kWh (2019 est.)
exports:
0 kWh (2019 est.)
imports:
0 kWh (2019 est.)
transmission/distribution losses:
6.701 billion kWh (2019 est.)
comparison rankings:
installed generating capacity 49; transmission/distribution losses 41; imports 130; exports 111; consumption 44
Electricity generation sources:
fossil fuels: 99.9%
of total installed capacity (2020 est.)
nuclear:
0% of total installed capacity (2020 est.)
solar:
0% of total installed capacity (2020 est.)
wind:
0.1% of total installed capacity (2020 est.)
hydroelectricity:
0% of total installed capacity (2020 est.)
tide and wave:
0% of total installed capacity (2020 est.)
geothermal:
0% of total installed capacity (2020 est.)
biomass and waste:
0% of total installed capacity (2020 est.)
Coal:
production: 0
metric tons (2020 est.)
consumption:
68,000 metric tons (2020 est.)
exports:
0 metric tons (2020 est.)
imports:
68,000 metric tons (2020 est.)
proven reserves:
0 metric tons (2019 est.)
Petroleum:
total petroleum production: 2,720,500
bbl/day (2021 est.)
refined petroleum consumption:
342,000 bbl/day (2019 est.)
crude oil and lease condensate exports:
1,837,900 bbl/day (2018 est.)
crude oil and lease condensate imports:
0 bbl/day (2018 est.)
crude oil estimated reserves:
101.5 billion barrels (2021 est.)
Refined petroleum products - production:
915,800 bbl/day (2015 est.)
comparison ranking:
22
Refined petroleum products - exports:
705,500 bbl/day (2015 est.)
comparison ranking:
11
Refined petroleum products - imports:
0 bbl/day (2015 est.)
comparison ranking:
212
Natural gas:
production: 19,509,907,000
cubic meters (2019 est.)
consumption:
24,322,970,000 cubic meters (2019 est.)
exports:
0 cubic meters (2021 est.)
imports:
4,805,531,000 cubic meters (2019 est.)
proven reserves:
1,783,958,000,000 cubic meters (2021 est.)
Carbon dioxide emissions:
92.582 million metric tonnes of CO2 (2019 est.)
from coal and metallurgical coke:
578,000 metric tonnes of CO2 (2019 est.)
from petroleum and other liquids:
44.288 million metric tonnes of CO2 (2019 est.)
from consumed natural gas:
47.715 million metric tonnes of CO2 (2019 est.)
comparison ranking:
total emissions 45
Energy consumption per capita:
381.985 million Btu/person (2019 est.)
comparison ranking:
7','2098b45622fa0effdb22b7094c5bf436cdd2325fc981acaccf0033eb65397967','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('24d55337a9b24d26634118245327df6a428ff1e1dde8f2aa0db6770df43e85f1',2025,'KG','Kyrgyzstan','energy',22,'Electricity access:
electrification - total population: 99.6%
(2021)
electrification - urban areas:
99.8% (2021)
electrification - rural areas:
99.5% (2021)
Electricity:
installed generating capacity: 4.626
million kW (2020 est.)
consumption:
12,324,140,000 kWh (2019 est.)
exports:
271 million kWh (2019 est.)
imports:
269 million kWh (2019 est.)
transmission/distribution losses:
2.514 billion kWh (2019 est.)
comparison rankings:
installed generating capacity 91; transmission/distribution losses 76; imports 98; exports 82; consumption 91
Electricity generation sources:
fossil fuels: 8.5%
of total installed capacity (2020 est.)
nuclear:
0% of total installed capacity (2020 est.)
solar:
0% of total installed capacity (2020 est.)
wind:
0% of total installed capacity (2020 est.)
hydroelectricity:
91.5% of total installed capacity (2020 est.)
tide and wave:
0% of total installed capacity (2020 est.)
geothermal:
0% of total installed capacity (2020 est.)
biomass and waste:
0% of total installed capacity (2020 est.)
Coal:
production: 2.287
million metric tons (2020 est.)
consumption:
1.717 million metric tons (2020 est.)
exports:
984,000 metric tons (2020 est.)
imports:
481,000 metric tons (2020 est.)
proven reserves:
971 million metric tons (2019 est.)
Petroleum:
total petroleum production: 700
bbl/day (2021 est.)
refined petroleum consumption:
32,100 bbl/day (2019 est.)
crude oil and lease condensate exports:
1,400 bbl/day (2018 est.)
crude oil and lease condensate imports:
8,200 bbl/day (2018 est.)
crude oil estimated reserves:
40 million barrels (2021 est.)
Refined petroleum products - production:
6,996 bbl/day (2015 est.)
comparison ranking:
102
Refined petroleum products - exports:
2,290 bbl/day (2015 est.)
comparison ranking:
103
Refined petroleum products - imports:
34,280 bbl/day (2015 est.)
comparison ranking:
96
Natural gas:
production: 25.542
million cubic meters (2019 est.)
consumption:
207.845 million cubic meters (2019 est.)
exports:
0 cubic meters (2021 est.)
imports:
191.478 million cubic meters (2019 est.)
proven reserves:
5.663 billion cubic meters (2021 est.)
Carbon dioxide emissions:
7.88 million metric tonnes of CO2 (2019 est.)
from coal and metallurgical coke:
2.967 million metric tonnes of CO2 (2019 est.)
from petroleum and other liquids:
4.505 million metric tonnes of CO2 (2019 est.)
from consumed natural gas:
408,000 metric tonnes of CO2 (2019 est.)
comparison ranking:
total emissions 118
Energy consumption per capita:
35.059 million Btu/person (2019 est.)
comparison ranking:
115','8c0bcb0baf046d5ebb32dc42f48991a5717de78313dffd398128dde74105b73f','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('572ab88852ee45f2fe6dbd4c70ff2a04b8a7b5fbb5e44f4c93604bc36886cf25',2025,'LV','Latvia','energy',9,'Electricity access:
electrification - total population:
100% (2021)
Electricity:
installed generating capacity:
3.089 million kW (2020 est.)
consumption:
6.706 billion kWh (2020 est.)
exports:
2.548 billion kWh (2020 est.)
imports:
4.173 billion kWh (2020 est.)
transmission/distribution losses:
377 million kWh (2020 est.)
comparison rankings:
transmission/distribution losses 135; imports 45; exports 46; consumption 111; installed generating capacity 105
Electricity generation sources:
fossil fuels:
33.4% of total installed capacity (2020 est.)
solar:
0.1% of total installed capacity (2020 est.)
wind:
3.2% of total installed capacity (2020 est.)
hydroelectricity:
47.5% of total installed capacity (2020 est.)
biomass and waste:
15.9% of total installed capacity (2020 est.)
Coal:
production:
0 metric tons (2020 est.)
consumption:
39,000 metric tons (2020 est.)
exports:
3,000 metric tons (2020 est.)
imports:
40,000 metric tons (2020 est.)
proven reserves:
0 metric tons (2019 est.)
Petroleum:
total petroleum production:
1,600 bbl/day (2021 est.)
refined petroleum consumption:
39,900 bbl/day (2019 est.)
Refined petroleum products - exports:
16,180 bbl/day (2017 est.)
comparison ranking:
72
Refined petroleum products - imports:
54,370 bbl/day (2017 est.)
comparison ranking:
77
Natural gas:
production:
0 cubic meters (2021 est.)
consumption:
1.068 billion cubic meters (2020 est.)
exports:
0 cubic meters (2021 est.)
imports:
1.068 billion cubic meters (2020 est.)
proven reserves:
0 cubic meters (2021 est.)
Carbon dioxide emissions:
8.45 million metric tonnes of CO2 (2019 est.)
from coal and metallurgical coke:
149,000 metric tonnes of CO2 (2019 est.)
from petroleum and other liquids:
5.693 million metric tonnes of CO2 (2019 est.)
from consumed natural gas:
2.608 million metric tonnes of CO2 (2019 est.)
comparison ranking:
total emissions 110
Energy consumption per capita:
86.645 million Btu/person (2019 est.)
comparison ranking:
66','707aacd6b864ec6c6c88fedc74b4496f9bcf889802484e681b8d5a6cead4e6f4','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e3ab9d48e7a9807af6ecb644e0e4bf92177c7add6ee129a4dfa8c37e1703f1aa',2025,'LB','Lebanon','energy',20,'Electricity access:
electrification - total population:
100% (2021)
Electricity:
installed generating capacity:
3.768 million kW (2020 est.)
consumption:
18,715,620,000 kWh (2019 est.)
exports:
0 kWh (2019 est.)
imports:
900 million kWh (2019 est.)
transmission/distribution losses:
2.219 billion kWh (2019 est.)
comparison rankings:
installed generating capacity 99; transmission/distribution losses 85; imports 75; exports 200; consumption 73
Electricity generation sources:
fossil fuels:
94.3% of total installed capacity (2020 est.)
solar:
0.5% of total installed capacity (2020 est.)
hydroelectricity:
5% of total installed capacity (2020 est.)
Coal:
production:
0 metric tons (2020 est.)
consumption:
268,000 metric tons (2020 est.)
exports:
0 metric tons (2020 est.)
imports:
268,000 metric tons (2020 est.)
proven reserves:
0 metric tons (2019 est.)
Petroleum:
total petroleum production:
0 bbl/day (2021 est.)
refined petroleum consumption:
168,500 bbl/day (2019 est.)
Refined petroleum products - imports:
151,100 bbl/day (2015 est.)
comparison ranking:
41
Carbon dioxide emissions:
25.838 million metric tonnes of CO2 (2019 est.)
from coal and metallurgical coke:
563,000 metric tonnes of CO2 (2019 est.)
from petroleum and other liquids:
25.275 million metric tonnes of CO2 (2019 est.)
comparison ranking:
total emissions 78
Energy consumption per capita:
53.528 million Btu/person (2019 est.)
comparison ranking:
97','6c109e4d8c224e53b8334ae8d9fa15a41dcb7f2eaeba14e50cdaa5f548c5a660','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('dd9c9d64053f4db105aaa503f748b4f6da49acdfaec086395d61f1467d518204',2025,'LS','Lesotho','energy',32,'Electricity access:
population without electricity:
1 million (2020)
electrification - total population:
50.3% (2021)
electrification - urban areas:
80.6% (2021)
electrification - rural areas:
37.7% (2021)
Electricity:
installed generating capacity:
74,000 kW (2020 est.)
consumption:
912.8 million kWh (2019 est.)
exports:
0 kWh (2019 est.)
imports:
541.7 million kWh (2019 est.)
transmission/distribution losses:
129.9 million kWh (2019 est.)
comparison rankings:
installed generating capacity 188; transmission/distribution losses 157; imports 84; exports 138; consumption 162
Electricity generation sources:
solar:
0.2% of total installed capacity (2020 est.)
hydroelectricity:
99.8% of total installed capacity (2020 est.)
Petroleum:
total petroleum production:
0 bbl/day (2021 est.)
refined petroleum consumption:
5,100 bbl/day (2019 est.)
Refined petroleum products - imports:
5,118 bbl/day (2015 est.)
comparison ranking:
170
Carbon dioxide emissions:
736,000 metric tonnes of CO2 (2019 est.)
from petroleum and other liquids:
736,000 metric tonnes of CO2 (2019 est.)
comparison ranking:
total emissions 181
Energy consumption per capita:
7.823 million Btu/person (2019 est.)
comparison ranking:
164','858baee460da337590f735dc34fcb30b3b272a71d38de7e70c4feab3057b272a','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ca2a8e843b3df562d9378f04f5d03ad13ca68c4695e1462ab093994feb87dda3',2025,'LR','Liberia','energy',43,'Electricity access:
population without electricity:
4 million (2020)
electrification - total population:
29.8% (2021)
electrification - urban areas:
49.5% (2021)
electrification - rural areas:
8% (2021)
Electricity:
installed generating capacity:
196,000 kW (2020 est.)
consumption:
292 million kWh (2019 est.)
exports:
0 kWh (2019 est.)
imports:
0 kWh (2019 est.)
transmission/distribution losses:
26 million kWh (2019 est.)
comparison rankings:
installed generating capacity 172; transmission/distribution losses 181; imports 197; exports 196;
consumption 181
Electricity generation sources:
fossil fuels:
40.5% of total installed capacity (2020 est.)
solar:
0.5% of total installed capacity (2020 est.)
hydroelectricity:
59.1% of total installed capacity (2020 est.)
Petroleum:
total petroleum production:
0 bbl/day (2021 est.)
refined petroleum consumption:
9,200 bbl/day (2019 est.)
Refined petroleum products - imports:
8,181 bbl/day (2015 est.)
comparison ranking:
152
Carbon dioxide emissions:
1.346 million metric tonnes of CO2 (2019 est.)
from petroleum and other liquids:
1.346 million metric tonnes of CO2 (2019 est.)
comparison ranking:
total emissions 166
Energy consumption per capita:
3.79 million Btu/person (2019 est.)
comparison ranking:
176','1222350f8c0d3b917616c3a0b69363af1b5b1c3fdf56a10fcac06e9084dbb7d6','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9d1177c7530721204052f39fc606bac88b0f55ce7d8ac20b27bdcc77c7e9041f',2025,'LY','Libya','energy',7,'Electricity access:
electrification - total population:
70.2% (2021)
electrification - urban areas:
100% (2021)
Electricity:
installed generating capacity:
10.516 million kW (2020 est.)
consumption:
25,360,340,000 kWh (2019 est.)
exports:
0 kWh (2019 est.)
imports:
465 million kWh (2019 est.)
transmission/distribution losses:
6.801 billion kWh (2019 est.)
comparison rankings:
installed generating capacity 64; transmission/distribution losses 39; imports 90; exports 192; consumption 69
Electricity generation sources:
fossil fuels:
100% of total installed capacity (2020 est.)
Petroleum:
total petroleum production:
1,252,800 bbl/day (2021 est.)
refined petroleum consumption:
219,700 bbl/day (2019 est.)
crude oil and lease condensate exports:
1,067,400 bbl/day (2018 est.)
crude oil and lease condensate imports:
0 bbl/day (2018 est.)
crude oil estimated reserves:
48.363 billion barrels (2021 est.)
Refined petroleum products - production:
89,620 bbl/day (2015 est.)
comparison ranking:
69
Refined petroleum products - exports:
16,880 bbl/day (2015 est.)
comparison ranking:
71
Refined petroleum products - imports:
168,200 bbl/day (2015 est.)
comparison ranking:
36
Natural gas:
production:
12,414,736,000 cubic meters (2020 est.)
consumption:
7,669,690,000 cubic meters (2019 est.)
exports:
4,441,150,000 cubic meters (2020 est.)
imports:
0 cubic meters (2021 est.)
proven reserves:
1,504,868,000,000 cubic meters (2021 est.)
Carbon dioxide emissions:
38.297 million metric tonnes of CO2 (2019 est.)
from coal and metallurgical coke:
0 metric tonnes of CO2 (2019 est.)
from petroleum and other liquids:
30.018 million metric tonnes of CO2 (2019 est.)
from consumed natural gas:
8.279 million metric tonnes of CO2 (2019 est.)
comparison ranking:
total emissions 68
Energy consumption per capita:
107.118 million Btu/person (2019 est.)
comparison ranking:
53','3cb910f3ee319c60e0267d67340b9dd38f1345b5c778526a73fe0464133c9283','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a2a331765d30fe1f2b78e9ecd30480d8abe4855698b7009ce24580982a68a6ab',2025,'LI','Liechtenstein','energy',19,'Electricity access:
electrification - total population:
100% (2021)','a05175d18d3663ad25c80fce0a2f9d8c3948b2fa4d1a94432259d1d8804cb39b','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('075fe0fa434c49f2ccad07f4905d961f67f381849be86b3e3cf4715b76cc1a8e',2025,'LT','Lithuania','energy',30,'Electricity access:
electrification - total population:
100% (2021)
Electricity:
installed generating capacity:
3.512 million kW (2020 est.)
consumption:
11.063 billion kWh (2020 est.)
exports:
4.105 billion kWh (2020 est.)
imports:
12.013 billion kWh (2020 est.)
transmission/distribution losses:
951 million kWh (2020 est.)
comparison rankings:
transmission/distribution losses 114; imports 21; exports 40; consumption 96; installed generating capacity 102
Electricity generation sources:
fossil fuels:
38% of total installed capacity (2020 est.)
solar:
3% of total installed capacity (2020 est.)
wind:
35.5% of total installed capacity (2020 est.)
hydroelectricity:
6.9% of total installed capacity (2020 est.)
biomass and waste:
16.7% of total installed capacity (2020 est.)
Nuclear energy: Number of operational nuclear reactors:
0
Number of nuclear reactors under construction:
0
Net capacity of operational nuclear reactors:
0GW
Percent of total electricity production:
0%
Percent of total energy produced:
0%
Number of nuclear reactors permanently shut down:
2
Coal:
production:
0 metric tons (2020 est.)
consumption:
221,000 metric tons (2020 est.)
exports:
75,000 metric tons (2020 est.)
imports:
268,000 metric tons (2020 est.)
proven reserves:
0 metric tons (2019 est.)
Petroleum:
total petroleum production:
4,000 bbl/day (2021 est.)
refined petroleum consumption:
68,000 bbl/day (2019 est.)
crude oil and lease condensate exports:
900 bbl/day (2018 est.)
crude oil and lease condensate imports:
194,900 bbl/day (2018 est.)
crude oil estimated reserves:
12 million barrels (2021 est.)
Refined petroleum products - production:
196,500 bbl/day (2015 est.)
comparison ranking:
51
Refined petroleum products - exports:
174,800 bbl/day (2015 est.)
comparison ranking:
32
Refined petroleum products - imports:
42,490 bbl/day (2015 est.)
comparison ranking:
87
Natural gas:
production:
0 cubic meters (2021 est.)
consumption:
2.231 billion cubic meters (2019 est.)
exports:
497.923 million cubic meters (2020 est.)
imports:
2.819 billion cubic meters (2020 est.)
proven reserves:
0 cubic meters (2021 est.)
Carbon dioxide emissions:
14.503 million metric tonnes of CO2 (2019 est.)
from coal and metallurgical coke:
693,000 metric tonnes of CO2 (2019 est.)
from petroleum and other liquids:
9.488 million metric tonnes of CO2 (2019 est.)
from consumed natural gas:
4.322 million metric tonnes of CO2 (2019 est.)
comparison ranking:
total emissions 96
Energy consumption per capita:
101.651 million Btu/person (2019 est.)
comparison ranking:
58','a9cb96eccf2ea98fd588a186d772847de8e4fe231215d78cbb6926be30b170d0','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('40bc95d80ef0a17257d4bbe897a9c2fcceb7e68c2acc7fc933cf6818fce5f48e',2025,'LU','Luxembourg','energy',42,'Electricity access:
electrification - total population:
100% (2021)
Electricity:
installed generating capacity:
1.899 million kW (2020 est.)
consumption:
6.188 billion kWh (2020 est.)
exports:
1.079 billion kWh (2020 est.)
imports:
6.543 billion kWh (2020 est.)
transmission/distribution losses:
156 million kWh (2020 est.)
comparison rankings:
transmission/distribution losses 152; imports 35; exports 59; consumption 117; installed generating capacity 120
Electricity generation sources:
fossil fuels:
13.8% of total installed capacity (2020 est.)
solar:
14.6% of total installed capacity (2020 est.)
wind:
27.7% of total installed capacity (2020 est.)
hydroelectricity:
7.5% of total installed capacity (2020 est.)
biomass and waste:
36.4% of total installed capacity (2020 est.)
Coal:
production:
0 metric tons (2020 est.)
consumption:
65,000 metric tons (2020 est.)
exports:
0 metric tons (2020 est.)
imports:
74,000 metric tons (2020 est.)
proven reserves:
0 metric tons (2019 est.)
Petroleum:
total petroleum production:
0 bbl/day (2021 est.)
refined petroleum consumption:
63,900 bbl/day (2019 est.)
Refined petroleum products - imports:
59,020 bbl/day (2017 est.)
comparison ranking:
73
Natural gas:
production:
0 cubic meters (2021 est.)
consumption:
776.022 million cubic meters (2019 est.)
exports:
0 cubic meters (2021 est.)
imports:
772.624 million cubic meters (2019 est.)
proven reserves:
0 cubic meters (2021 est.)
Carbon dioxide emissions:
11.308 million metric tonnes of CO2 (2019 est.)
from coal and metallurgical coke:
149,000 metric tonnes of CO2 (2019 est.)
from petroleum and other liquids:
9.564 million metric tonnes of CO2 (2019 est.)
from consumed natural gas:
1.594 million metric tonnes of CO2 (2019 est.)
comparison ranking:
total emissions 102
Energy consumption per capita:
310.068 million Btu/person (2019 est.)
comparison ranking:
10','7275de91706b616cf86c8b7fe2a2362a8ef862e9d6c5a20a2f89aa520bb57a00','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c4df074536fb2e5af532406162e96d39cac35a5a8eb544a8fc330603556fe972',2025,'MG','Madagascar','energy',9,'Electricity access:
population without electricity:
20 million (2020)
electrification - total population:
35.1% (2021)
electrification - urban areas:
72.6% (2021)
electrification - rural areas:
10.9% (2021)
Electricity:
installed generating capacity:
587,000 kW (2020 est.)
consumption:
1,720,140,000 kWh (2019 est.)
exports:
0 kWh (2020 est.)
imports:
0 kWh (2020 est.)
transmission/distribution losses:
131 million kWh (2019 est.)
comparison rankings:
imports 192; exports 189; installed generating capacity 147; transmission/distribution losses 156; consumption 150
Electricity generation sources:
fossil fuels:
59.8% of total installed capacity (2020 est.)
solar:
1.1% of total installed capacity (2020 est.)
hydroelectricity:
38.2% of total installed capacity (2020 est.)
biomass and waste:
1% of total installed capacity (2020 est.)
Coal:
production:
0 metric tons (2020 est.)
consumption:
107,000 metric tons (2020 est.)
exports:
0 metric tons (2020 est.)
imports:
115,000 metric tons (2020 est.)
proven reserves:
0 metric tons (2019 est.)
Petroleum:
total petroleum production:
0 bbl/day (2021 est.)
refined petroleum consumption:
21,100 bbl/day (2019 est.)
Refined petroleum products - imports:
18,880 bbl/day (2015 est.)
comparison ranking:
125
Carbon dioxide emissions:
4.218 million metric tonnes of CO2 (2019 est.)
from coal and metallurgical coke:
1.044 million metric tonnes of CO2 (2019 est.)
from petroleum and other liquids:
3.175 million metric tonnes of CO2 (2019 est.)
comparison ranking:
total emissions 140
Energy consumption per capita:
2.307 million Btu/person (2019 est.)
comparison ranking:
186','9bf29b123dec625aa14014b9034833281029ec0279a072e8a4c4d4f4bc8a556e','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('23824d01237649c5a5e13991ecc86baf9fe4ea0b8d18296ec0959741d3e21a93',2025,'MW','Malawi','energy',20,'Electricity access:
population without electricity:
17 million (2020)
electrification - total population:
14.1% (2021)
electrification - urban areas:
54.2% (2021)
electrification - rural areas:
5.5% (2021)
Electricity:
installed generating capacity:
618,000 kW (2020 est.)
consumption:
1,117,378,000 kWh (2019 est.)
exports:
0 kWh (2019 est.)
imports:
0 kWh (2019 est.)
transmission/distribution losses:
460 million kWh (2019 est.)
comparison rankings:
installed generating capacity 145; transmission/distribution losses 132; imports 211; exports 211; consumption 156
Electricity generation sources:
fossil fuels:
11.8% of total installed capacity (2020 est.)
solar:
3.2% of total installed capacity (2020 est.)
hydroelectricity:
81.9% of total installed capacity (2020 est.)
biomass and waste:
3.2% of total installed capacity (2020 est.)
Coal:
production:
48,000 metric tons (2020 est.)
consumption:
47,000 metric tons (2020 est.)
exports:
0 metric tons (2020 est.)
imports:
0 metric tons (2020 est.)
proven reserves:
2 million metric tons (2019 est.)
Petroleum:
total petroleum production:
0 bbl/day (2021 est.)
refined petroleum consumption:
9,400 bbl/day (2019 est.)
Refined petroleum products - imports:
4,769 bbl/day (2015 est.)
comparison ranking:
173
Carbon dioxide emissions:
1.542 million metric tonnes of CO2 (2019 est.)
from coal and metallurgical coke:
203,000 metric tonnes of CO2 (2019 est.)
from petroleum and other liquids:
1.339 million metric tonnes of CO2 (2019 est.)
comparison ranking:
total emissions 165
Energy consumption per capita:
1.809 million Btu/person (2019 est.)
comparison ranking:
187','711888888c8470ff44e40e515689db112bac98686f36413b23755c74c28d2047','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('42d196a5a2f339716684c716f480bf21c7f9f51051469326328b1d141d099b68',2025,'MY','Malaysia','energy',31,'Electricity access:
electrification - total population:
100% (2021)
Electricity:
installed generating capacity:
34.959 million kW (2020 est.)
consumption:
150.062 billion kWh (2019 est.)
exports:
669 million kWh (2019 est.)
imports:
19 million kWh (2019 est.)
transmission/distribution losses:
12.124 billion kWh (2019 est.)
comparison rankings:
installed generating capacity 33; transmission/distribution losses 29; imports 116; exports 69; consumption 24
Electricity generation sources:
fossil fuels:
87.5% of total installed capacity (2020 est.)
solar:
0.7% of total installed capacity (2020 est.)
hydroelectricity:
10.9% of total installed capacity (2020 est.)
biomass and waste:
1% of total installed capacity (2020 est.)
Coal:
production:
2.977 million metric tons (2020 est.)
consumption:
35.268 million metric tons (2020 est.)
exports:
17,000 metric tons (2020 est.)
imports:
37.295 million metric tons (2020 est.)
proven reserves:
226 million metric tons (2019 est.)
Petroleum:
total petroleum production:
593,800 bbl/day (2021 est.)
refined petroleum consumption:
718,600 bbl/day (2019 est.)
crude oil and lease condensate exports:
303,600 bbl/day (2018 est.)
crude oil and lease condensate imports:
182,300 bbl/day (2018 est.)
crude oil estimated reserves:
3.6 billion barrels (2021 est.)
Refined petroleum products - production:
528,300 bbl/day (2015 est.)
comparison ranking:
32
Refined petroleum products - exports:
208,400 bbl/day (2015 est.)
comparison ranking:
31
Refined petroleum products - imports:
304,600 bbl/day (2015 est.)
comparison ranking:
24
Natural gas:
production:
74,985,350,000 cubic meters (2019 est.)
consumption:
39,586,915,000 cubic meters (2019 est.)
exports:
34,197,548,000 cubic meters (2020 est.)
imports:
4,008,073,000 cubic meters (2020 est.)
proven reserves:
1,189,306,000,000 cubic meters (2021 est.)
Carbon dioxide emissions:
254.764 million metric tonnes of CO2 (2019 est.)
from coal and metallurgical coke:
81.726 million metric tonnes of CO2 (2019 est.)
from petroleum and other liquids:
94.934 million metric tonnes of CO2 (2019 est.)
from consumed natural gas:
78.104 million metric tonnes of CO2 (2019 est.)
comparison ranking:
total emissions 26
Energy consumption per capita:
123.755 million Btu/person (2019 est.)
comparison ranking:
44','aaa1ffdda7aa6f2101243b2c19aa65a39b89b4bc83030220990dcd88d9f4cccd','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2e0c3bf6b760d1dd9225e1de1ffcdf959de769801667d6fab63dbe986f12a358',2025,'MV','Maldives','energy',44,'Electricity access:
electrification - total population:
100% (2021)
Electricity:
installed generating capacity:
545,000 kW (2020 est.)
consumption:
586.5 million kWh (2019 est.)
exports:
0 kWh (2020 est.)
imports:
0 kWh (2020 est.)
transmission/distribution losses:
21 million kWh (2019 est.)
comparison rankings:
imports 137; exports 120; installed generating capacity 149; transmission/distribution losses 184; consumption 167
Electricity generation sources:
fossil fuels:
99.6% of total installed capacity (2020 est.)
wind:
0.4% of total installed capacity (2020 est.)
Petroleum:
total petroleum production:
0 bbl/day (2021 est.)
refined petroleum consumption:
15,300 bbl/day (2019 est.)
Refined petroleum products - imports:
10,840 bbl/day (2015 est.)
comparison ranking:
144
Carbon dioxide emissions:
2.286 million metric tonnes of CO2 (2019 est.)
from petroleum and other liquids:
2.286 million metric tonnes of CO2 (2019 est.)
comparison ranking:
total emissions 157
Energy consumption per capita:
59.69 million Btu/person (2019 est.)
comparison ranking:
92','ebbfd4f05c3e0308417b31bbf63ca9f049328f777157cf32e3da7a944ba367f8','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3aab17c89c8aa77e6cefdc72d17c90f4f4062f17f3d8947c761a96ce754da0e2',2025,'ML','Mali','energy',7,'Electricity access:
population without electricity:
10 million (2020)
electrification - total population:
53.3% (2021)
electrification - urban areas:
96.8% (2021)
electrification - rural areas:
18.2% (2021)
Electricity:
installed generating capacity:
890,000 kW (2020 est.)
consumption:
2,620,980,000 kWh (2019 est.)
exports:
550 million kWh (2019 est.)
imports:
200 million kWh (2019 est.)
transmission/distribution losses:
346 million kWh (2019 est.)
comparison rankings:
installed generating capacity 137; transmission/distribution losses 138; imports 102; exports 73; consumption 144
Electricity generation sources:
fossil fuels:
67.4% of total installed capacity (2020 est.)
solar:
1% of total installed capacity (2020 est.)
hydroelectricity:
29.7% of total installed capacity (2020 est.)
biomass and waste:
1.9% of total installed capacity (2020 est.)
Petroleum:
total petroleum production:
0 bbl/day (2021 est.)
refined petroleum consumption:
37,600 bbl/day (2019 est.)
Refined petroleum products - imports:
20,610 bbl/day (2015 est.)
comparison ranking:
119
Carbon dioxide emissions:
5.679 million metric tonnes of CO2 (2019 est.)
from petroleum and other liquids:
5.679 million metric tonnes of CO2 (2019 est.)
comparison ranking:
total emissions 134
Energy consumption per capita:
4.396 million Btu/person (2019 est.)
comparison ranking:
172','c74cc9b4daebf102726ccbc355831de2e7fbfb17a3d3c70a9d857f5c075e53a5','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ec0f03bdd9b56ec8757ac9c09239f7d2d43ea74c879ec784bbf00d3f040e6cd6',2025,'MT','Malta','energy',19,'Electricity access:
electrification - total population:
100% (2021)
Electricity:
installed generating capacity:
784,000 kW (2020 est.)
consumption:
2,497,143,000 kWh (2019 est.)
exports:
4 million kWh (2020 est.)
imports:
420 million kWh (2020 est.)
transmission/distribution losses:
158 million kWh (2019 est.)
comparison rankings:
imports 92; exports 97; installed generating capacity 139; transmission/distribution losses 151; consumption 145
Electricity generation sources:
fossil fuels:
88.5% of total installed capacity (2020 est.)
solar:
11.2% of total installed capacity (2020 est.)
biomass and waste:
0.3% of total installed capacity (2020 est.)
Petroleum:
total petroleum production:
0 bbl/day (2021 est.)
refined petroleum consumption:
54,000 bbl/day (2019 est.)
Refined petroleum products - exports:
10,400 bbl/day (2015 est.)
comparison ranking:
81
Refined petroleum products - imports:
52,290 bbl/day (2015 est.)
comparison ranking:
79
Natural gas:
production:
0 cubic meters (2021 est.)
consumption:
415.606 million cubic meters (2020 est.)
exports:
0 cubic meters (2021 est.)
imports:
415.606 million cubic meters (2020 est.)
proven reserves:
0 cubic meters (2021 est.)
Carbon dioxide emissions:
9.576 million metric tonnes of CO2 (2019 est.)
from coal and metallurgical coke:
0 metric tonnes of CO2 (2019 est.)
from petroleum and other liquids:
8.831 million metric tonnes of CO2 (2019 est.)
from consumed natural gas:
745,000 metric tonnes of CO2 (2019 est.)
comparison ranking:
total emissions 108
Energy consumption per capita:
267.739 million Btu/person (2019 est.)
comparison ranking:
14','ecd0810eb8caa2e2ee3fe2ab1f2d0a22ad1768960bf8f11cd17c02594fd5c92d','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ac2071464fc03a0fd5bcf0cdaf10943acbc692fe8d71fa705c45e0753be31820',2025,'MH','Marshall Islands','energy',31,'Electricity access:
electrification - total population:
99.7% (2021)
electrification - urban areas:
96% (2021)
electrification - rural areas:
92% (2020)
Refined petroleum products - imports:
2,060 bbl/day (2015 est.)
comparison ranking:
190
Carbon dioxide emissions:
293,700 metric tonnes of CO2 (2017 est.)
comparison ranking:
total emissions 197','d78d4798253ca38996407ec584a67b75ee04ed7d0c7ded3b0ec75cd03c835e68','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('27ebef2617dd3232507f3811fabd1221da011bf2e149cd8102f0f80bfc863e9b',2025,'MR','Mauritania','energy',42,'Electricity access:
population without electricity:
3 million (2020)
electrification - total population:
47.6% (2021)
electrification - urban areas:
89.6% (2021)
electrification - rural areas:
1% (2020)
Electricity:
installed generating capacity:
656,000 kW (2020 est.)
consumption:
1.577 billion kWh (2019 est.)
exports:
0 kWh (2019 est.)
imports:
0 kWh (2019 est.)
transmission/distribution losses:
245 million kWh (2019 est.)
comparison rankings:
installed generating capacity 142; transmission/distribution losses 145; imports 210; exports 210; consumption 152
Electricity generation sources:
fossil fuels:
73.2% of total installed capacity (2020 est.)
solar:
8.1% of total installed capacity (2020 est.)
wind:
6.8% of total installed capacity (2020 est.)
hydroelectricity:
11.9% of total installed capacity (2020 est.)
Petroleum:
total petroleum production:
0 bbl/day (2021 est.)
refined petroleum consumption:
27,500 bbl/day (2019 est.)
crude oil and lease condensate exports:
4,800 bbl/day (2018 est.)
crude oil and lease condensate imports:
0 bbl/day (2018 est.)
crude oil estimated reserves:
20 million barrels (2021 est.)
Refined petroleum products - imports:
17,290 bbl/day (2015 est.)
comparison ranking:
133
Natural gas:
proven reserves:
28.317 billion cubic meters (2021 est.)
Carbon dioxide emissions:
4.041 million metric tonnes of CO2 (2019 est.)
from petroleum and other liquids:
4.041 million metric tonnes of CO2 (2019 est.)
comparison ranking:
total emissions 141
Energy consumption per capita:
13.558 million Btu/person (2019 est.)
comparison ranking:
145','2e6f64970c93e3c7ecb7fdc6dffc6fb5921bd29ad5ec5a13bc27f4e88c42ee57','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('261b39793ef8b476299ad94fb7e49d578032a05dddf05cee318c4581c180fa52',2025,'MU','Mauritius','energy',54,'Electricity access:
electrification - total population:
99.6% (2020)
electrification - urban areas:
99.2% (2021)
electrification - rural areas:
99.8% (2021)
Electricity:
installed generating capacity:
936,000 kW (2020 est.)
consumption:
2,904,500,000 kWh (2019 est.)
exports:
0 kWh (2019 est.)
imports:
0 kWh (2019 est.)
transmission/distribution losses:
182.4 million kWh (2019 est.)
comparison rankings:
installed generating capacity 136; transmission/distribution losses 150; imports 168; exports 160; consumption 142
Electricity generation sources:
fossil fuels:
75.4% of total installed capacity (2020 est.)
solar:
5.3% of total installed capacity (2020 est.)
wind:
0.7% of total installed capacity (2020 est.)
hydroelectricity:
3.7% of total installed capacity (2020 est.)
biomass and waste:
15% of total installed capacity (2020 est.)
Coal:
production:
0 metric tons (2020 est.)
consumption:
661,000 metric tons (2020 est.)
exports:
0 metric tons (2020 est.)
imports:
1.189 million metric tons (2020 est.)
proven reserves:
0 metric tons (2019 est.)
Petroleum:
total petroleum production:
0 bbl/day (2021 est.)
refined petroleum consumption:
36,700 bbl/day (2019 est.)
Refined petroleum products - imports:
26,960 bbl/day (2015 est.)
comparison ranking:
102
Carbon dioxide emissions:
7.191 million metric tonnes of CO2 (2019 est.)
from coal and metallurgical coke:
1.595 million metric tonnes of CO2 (2019 est.)
from petroleum and other liquids:
5.596 million metric tonnes of CO2 (2019 est.)
comparison ranking:
total emissions 124
Energy consumption per capita:
79.448 million Btu/person (2019 est.)
comparison ranking:
75','3fc3ed37b0c7925c732c2c5dac960d688cbdec56d07e9830616d3714e3ff3ba8','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b9fa2f772e50c1818a00dece2ae96ded7a998c8a1cd4a5b004a6069b18a51c1a',2025,'MX','Mexico','energy',7,'Electricity access:
electrification - total population:
100% (2021)
Electricity:
installed generating capacity:
93.43 million kW (2020 est.)
consumption:
267.34 billion kWh (2020 est.)
exports:
5.954 billion kWh (2020 est.)
imports:
9.965 billion kWh (2020 est.)
transmission/distribution losses:
42.121 billion kWh (2020 est.)
comparison rankings:
transmission/distribution losses 8; imports 24; exports 32; consumption 16; installed generating capacity 15
Electricity generation sources:
fossil fuels:
75.7% of total installed capacity (2020 est.)
nuclear:
3.6% of total installed capacity (2020 est.)
solar:
4.4% of total installed capacity (2020 est.)
wind:
6.5% of total installed capacity (2020 est.)
hydroelectricity:
7.6% of total installed capacity (2020 est.)
geothermal:
1.5% of total installed capacity (2020 est.)
biomass and waste:
0.8% of total installed capacity (2020 est.)
Nuclear energy: Number of operational nuclear reactors:
2 (2023)
Number of nuclear reactors under construction:
0
Net capacity of operational nuclear reactors:
1.55GW (2023)
Percent of total electricity production:
5.3% (2021)
Percent of total energy produced:
1.9% (2021)
Number of nuclear reactors permanently shut down:
0
Coal:
production:
9.886 million metric tons (2020 est.)
consumption:
10.241 million metric tons (2020 est.)
exports:
3,000 metric tons (2020 est.)
imports:
5.182 million metric tons (2020 est.)
proven reserves:
1.211 billion metric tons (2019 est.)
Petroleum:
total petroleum production:
1,905,500 bbl/day (2021 est.)
refined petroleum consumption:
1,928,800 bbl/day (2019 est.)
crude oil and lease condensate exports:
1,283,300 bbl/day (2018 est.)
crude oil and lease condensate imports:
3,900 bbl/day (2018 est.)
crude oil estimated reserves:
5,786,100,000 barrels (2021 est.)
Refined petroleum products - production:
844,600 bbl/day (2017 est.)
comparison ranking:
23
Refined petroleum products - exports:
155,800 bbl/day (2017 est.)
comparison ranking:
35
Refined petroleum products - imports:
867,500 bbl/day (2017 est.)
comparison ranking:
10
Natural gas:
production:
27,037,730,000 cubic meters (2019 est.)
consumption:
86,101,223,000 cubic meters (2019 est.)
exports:
53.037 million cubic meters (2019 est.)
imports:
59,119,362,000 cubic meters (2019 est.)
proven reserves:
180.321 billion cubic meters (2021 est.)
Carbon dioxide emissions:
463.739 million metric tonnes of CO2 (2019 est.)
from coal and metallurgical coke:
43.24 million metric tonnes of CO2 (2019 est.)
from petroleum and other liquids:
260.311 million metric tonnes of CO2 (2019 est.)
from consumed natural gas:
160.188 million metric tonnes of CO2 (2019 est.)
comparison ranking:
total emissions 13
Energy consumption per capita:
61.597 million Btu/person (2019 est.)
comparison ranking:
90','8e0240570a7c26ae9469b535cd6cf6125fcfa8ace14f31d7fdea264f2bef8e25','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('40735d5f4685670f4fbdc283061d47a1e48cff5d44f581ed4ea256d06779e260',2025,'FM','Micronesia, Federated States of','energy',19,'Electricity access:
electrification - total population:
83.6% (2021)
electrification - urban areas:
97.5% (2021)
electrification - rural areas:
79.4% (2021)
Petroleum:
refined petroleum consumption:
1,200 bbl/day (2019 est.)
Carbon dioxide emissions:
177,000 metric tonnes of CO2 (2019 est.)
from petroleum and other liquids:
177,000 metric tonnes of CO2 (2019 est.)
comparison ranking:
total emissions 204
Energy consumption per capita:
0 Btu/person (2019 est.)
comparison ranking:
203','15ad1c4d17d1b177ceb776c8acc5876358e0da56135933823653cc4953dabed1','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f21647ce5bf3a2eeba004597694aa5d922217a509069b75be6aed43b8a0560cf',2025,'FM','Micronesia, Federated States of','energy',30,'Electricity access:
electrification - total population:
100% (2021)
Electricity:
installed generating capacity:
594,000 kW (2020 est.)
consumption:
4.591 billion kWh (2019 est.)
exports:
0 kWh (2020 est.)
imports:
629 million kWh (2020 est.)
transmission/distribution losses:
571 million kWh (2019 est.)
comparison rankings:
imports 82; exports 129; installed generating capacity 146; transmission/distribution losses 126; consumption 129
Electricity generation sources:
fossil fuels:
93.6% of total installed capacity (2020 est.)
solar:
0.1% of total installed capacity (2020 est.)
wind:
1.2% of total installed capacity (2020 est.)
hydroelectricity:
4.5% of total installed capacity (2020 est.)
biomass and waste:
0.6% of total installed capacity (2020 est.)
Coal:
production:
0 metric tons (2020 est.)
consumption:
133,000 metric tons (2020 est.)
exports:
0 metric tons (2020 est.)
imports:
133,000 metric tons (2020 est.)
proven reserves:
0 metric tons (2019 est.)
Petroleum:
total petroleum production:
0 bbl/day (2021 est.)
refined petroleum consumption:
22,000 bbl/day (2019 est.)
Refined petroleum products - production:
232 bbl/day (2015 est.)
comparison ranking:
107
Refined petroleum products - exports:
275 bbl/day (2015 est.)
comparison ranking:
116
Refined petroleum products - imports:
18,160 bbl/day (2015 est.)
comparison ranking:
130
Natural gas:
production:
57,000 cubic meters (2019 est.)
consumption:
2.802 billion cubic meters (2019 est.)
exports:
0 cubic meters (2021 est.)
imports:
2.802 billion cubic meters (2019 est.)
proven reserves:
0 cubic meters (2021 est.)
Carbon dioxide emissions:
8.114 million metric tonnes of CO2 (2019 est.)
from coal and metallurgical coke:
374,000 metric tonnes of CO2 (2019 est.)
from petroleum and other liquids:
2.968 million metric tonnes of CO2 (2019 est.)
from consumed natural gas:
4.773 million metric tonnes of CO2 (2019 est.)
comparison ranking:
total emissions 112
Energy consumption per capita:
40.398 million Btu/person (2019 est.)
comparison ranking:
105','3113010a54e047011e3cb0811e8652a6b51e8006d1360132c1c191b8ca895303','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('67be721f33c648c60c10cb79f2dd6719120514d9798a1f2790573c5c2650183e',2025,'MC','Monaco','energy',41,'Electricity access:
electrification - total population:
100% (2021)','a05175d18d3663ad25c80fce0a2f9d8c3948b2fa4d1a94432259d1d8804cb39b','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5bcedab836ef6815b474ebb98f60c0913b69641d75f1512bd434f99a13fe1c1f',2025,'MN','Mongolia','energy',52,'Electricity access:
electrification - total population:
100% (2021)
Electricity:
installed generating capacity:
1.479 million kW (2020 est.)
consumption:
7,336,520,000 kWh (2019 est.)
exports:
24 million kWh (2019 est.)
imports:
1.723 billion kWh (2019 est.)
transmission/distribution losses:
892 million kWh (2019 est.)
comparison rankings:
installed generating capacity 126; transmission/distribution losses 116; imports 61; exports 94; consumption 109
Electricity generation sources:
fossil fuels:
89.2% of total installed capacity (2020 est.)
solar:
1.3% of total installed capacity (2020 est.)
wind:
8.1% of total installed capacity (2020 est.)
hydroelectricity:
1.3% of total installed capacity (2020 est.)
Coal:
production:
43.904 million metric tons (2020 est.)
consumption:
8.818 million metric tons (2020 est.)
exports:
28.551 million metric tons (2020 est.)
imports:
1,000 metric tons (2020 est.)
proven reserves:
2.52 billion metric tons (2019 est.)
Petroleum:
total petroleum production:
16,700 bbl/day (2021 est.)
refined petroleum consumption:
35,800 bbl/day (2019 est.)
crude oil and lease condensate exports:
14,700 bbl/day (2018 est.)
crude oil and lease condensate imports:
0 bbl/day (2018 est.)
Refined petroleum products - imports:
24,190 bbl/day (2015 est.)
comparison ranking:
109
Carbon dioxide emissions:
22.74 million metric tonnes of CO2 (2019 est.)
from coal and metallurgical coke:
17.445 million metric tonnes of CO2 (2019 est.)
from petroleum and other liquids:
5.295 million metric tonnes of CO2 (2019 est.)
comparison ranking:
total emissions 83
Energy consumption per capita:
83.045 million Btu/person (2019 est.)
comparison ranking:
69','88aa95e2385a1d5f3c998078e905b82e76009626a1a5de889aac0816de8fe002','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3cbce554f7e8c51fe74fd66713082d90095c169e010052c7c094fcc6147cef25',2025,'ME','Montenegro','energy',7,'Electricity access:
electrification - total population:
99.7% (2021)
electrification - urban areas:
100% (2021)
electrification - rural areas:
99.3% (2021)
Electricity:
installed generating capacity:
1.007 million kW (2020 est.)
consumption:
3,246,760,000 kWh (2019 est.)
exports:
943 million kWh (2019 est.)
imports:
1.196 billion kWh (2019 est.)
transmission/distribution losses:
493 million kWh (2019 est.)
comparison rankings:
installed generating capacity 134; transmission/distribution losses 131; imports 69; exports 65; consumption 136
Electricity generation sources:
fossil fuels:
42.3% of total installed capacity (2020 est.)
wind:
10.5% of total installed capacity (2020 est.)
hydroelectricity:
47.2% of total installed capacity (2020 est.)
Coal:
production:
1.456 million metric tons (2020 est.)
consumption:
1.351 million metric tons (2020 est.)
exports:
96,000 metric tons (2020 est.)
imports:
1,000 metric tons (2020 est.)
proven reserves:
142 million metric tons (2019 est.)
Petroleum:
total petroleum production:
0 bbl/day (2021 est.)
refined petroleum consumption:
7,600 bbl/day (2019 est.)
Refined petroleum products - exports:
357 bbl/day (2015 est.)
comparison ranking:
114
Refined petroleum products - imports:
6,448 bbl/day (2015 est.)
comparison ranking:
163
Carbon dioxide emissions:
2.447 million metric tonnes of CO2 (2019 est.)
from coal and metallurgical coke:
1.333 million metric tonnes of CO2 (2019 est.)
from petroleum and other liquids:
1.114 million metric tonnes of CO2 (2019 est.)
comparison ranking:
total emissions 153
Energy consumption per capita:
77.286 million Btu/person (2019 est.)
comparison ranking:
78','affb8a26cadeee2da4b8c928824f3ecb61d9986fdde5c6da59065db897e00725','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6e99ecd4550d32ecc6c02232638754c5d629c3830a465a3a03ea4c7d80c73d4f',2025,'MS','Montserrat','energy',18,'Electricity access:
electrification - total population:
100% (2020)
Electricity:
installed generating capacity:
5,000 kW (2020 est.)
consumption:
21.56 million kWh (2019 est.)
exports:
0 kWh (2020 est.)
imports:
0 kWh (2020 est.)
transmission/distribution losses:
1 million kWh (2019 est.)
comparison rankings:
imports 127; exports 107; installed generating capacity 210; transmission/distribution losses 207; consumption 206
Electricity generation sources:
fossil fuels:
100% of total installed capacity (2020 est.)
Petroleum:
total petroleum production:
0 bbl/day (2021 est.)
refined petroleum consumption:
200 bbl/day (2019 est.)
Refined petroleum products - imports:
406 bbl/day (2015 est.)
comparison ranking:
207
Carbon dioxide emissions:
33,000 metric tonnes of CO2 (2019 est.)
from petroleum and other liquids:
33,000 metric tonnes of CO2 (2019 est.)
comparison ranking:
total emissions 213
Energy consumption per capita:
0 Btu/person (2019 est.)
comparison ranking:
198','18cb862596924b4f9100ba55c882e59cc3b6e037c9d2f65b3acb43abdb93642c','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('64be15f043e3354f871af12ac812fffe69165d9b4d5fe0734d0d980646be29bc',2025,'MA','Morocco','energy',29,'Electricity access:
electrification - total population:
100% (2021)
Electricity:
installed generating capacity:
14.187 million kW (2020 est.)
consumption:
29,447,883,000 kWh (2019 est.)
exports:
624 million kWh (2020 est.)
imports:
856 million kWh (2020 est.)
transmission/distribution losses:
6.703 billion kWh (2019 est.)
comparison rankings:
imports 76; exports 72; installed generating capacity 55; transmission/distribution losses 40; consumption 66
Electricity generation sources:
fossil fuels:
81.6% of total installed capacity (2020 est.)
nuclear:
0% of total installed capacity (2020 est.)
solar:
1.1% of total installed capacity (2020 est.)
wind:
13% of total installed capacity (2020 est.)
hydroelectricity:
4.4% of total installed capacity (2020 est.)
Coal:
production:
0 metric tons (2020 est.)
consumption:
9.321 million metric tons (2020 est.)
exports:
0 metric tons (2020 est.)
imports:
9.321 million metric tons (2020 est.)
proven reserves:
14 million metric tons (2019 est.)
Petroleum:
total petroleum production:
0 bbl/day (2021 est.)
refined petroleum consumption:
307,500 bbl/day (2019 est.)
crude oil and lease condensate exports:
0 bbl/day (2018 est.)
crude oil and lease condensate imports:
0 bbl/day (2018 est.)
crude oil estimated reserves:
700,000 barrels (2021 est.)
Refined petroleum products - production:
66,230 bbl/day (2017 est.)
comparison ranking:
74
Refined petroleum products - exports:
9,504 bbl/day (2015 est.)
comparison ranking:
83
Refined petroleum products - imports:
229,300 bbl/day (2015 est.)
comparison ranking:
30
Natural gas:
production:
105.678 million cubic meters (2019 est.)
consumption:
1,051,658,000 cubic meters (2019 est.)
exports:
0 cubic meters (2021 est.)
imports:
950.765 million cubic meters (2019 est.)
proven reserves:
1.444 billion cubic meters (2021 est.)
Carbon dioxide emissions:
60.2 million metric tonnes of CO2 (2019 est.)
from coal and metallurgical coke:
20.267 million metric tonnes of CO2 (2019 est.)
from petroleum and other liquids:
37.834 million metric tonnes of CO2 (2019 est.)
from consumed natural gas:
2.099 million metric tonnes of CO2 (2019 est.)
comparison ranking:
total emissions 54
Energy consumption per capita:
24.59 million Btu/person (2019 est.)
comparison ranking:
129','c34302c38f1923930a8ae11dd823d146669830761a74ee58acf5e0ff7a21ffaa','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2e4f2a6569fc7d53e0a09f1bb0675aa44409769385aaa3861c2a162249f9806b',2025,'MZ','Mozambique','energy',42,'Electricity access:
population without electricity:
19 million (2020)
electrification - total population:
31.4% (2021)
electrification - urban areas:
77.3% (2021)
electrification - rural areas:
3.8% (2021)
Electricity:
installed generating capacity:
2.765 million kW (2020 est.)
consumption:
12,724,100,000 kWh (2019 est.)
exports:
10.771 billion kWh (2019 est.)
imports:
8.276 billion kWh (2019 est.)
transmission/distribution losses:
2.768 billion kWh (2019 est.)
comparison rankings:
installed generating capacity 111; transmission/distribution losses 69; imports 27; exports 20; consumption 89
Electricity generation sources:
fossil fuels:
19.6% of total installed capacity (2020 est.)
solar:
0.2% of total installed capacity (2020 est.)
hydroelectricity:
79.6% of total installed capacity (2020 est.)
biomass and waste:
0.6% of total installed capacity (2020 est.)
Coal:
production:
7.25 million metric tons (2020 est.)
consumption:
46,000 metric tons (2020 est.)
exports:
8.355 million metric tons (2020 est.)
imports:
48,000 metric tons (2020 est.)
proven reserves:
1.792 billion metric tons (2019 est.)
Petroleum:
total petroleum production:
0 bbl/day (2021 est.)
refined petroleum consumption:
35,400 bbl/day (2019 est.)
Refined petroleum products - imports:
25,130 bbl/day (2015 est.)
comparison ranking:
107
Natural gas:
production:
5,423,828,000 cubic meters (2019 est.)
consumption:
1,397,604,000 cubic meters (2019 est.)
exports:
4,067,255,000 cubic meters (2019 est.)
imports:
0 cubic meters (2021 est.)
proven reserves:
2,831,680,000,000 cubic meters (2021 est.)
Carbon dioxide emissions:
7.753 million metric tonnes of CO2 (2019 est.)
from coal and metallurgical coke:
109,000 metric tonnes of CO2 (2019 est.)
from petroleum and other liquids:
4.743 million metric tonnes of CO2 (2019 est.)
from consumed natural gas:
2.901 million metric tonnes of CO2 (2019 est.)
comparison ranking:
total emissions 119
Energy consumption per capita:
8.107 million Btu/person (2019 est.)
comparison ranking:
162','42a6b3e36cb0947c020677725c74be05dd08707f60c852785dc4a2108b20773d','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bcffd77c280d0a13f88663fbff872ac4305e612d1e7f0ef094eda6ed4a2c0e34',2025,'NA','Namibia','energy',7,'Electricity access:
population without electricity:
1 million (2020)
electrification - total population:
55.2% (2021)
electrification - urban areas:
74.7% (2021)
electrification - rural areas:
33.2% (2021)
Electricity:
installed generating capacity:
640,000 kW (2020 est.)
consumption:
4,065,360,000 kWh (2019 est.)
exports:
119 million kWh (2019 est.)
imports:
3.417 billion kWh (2019 est.)
transmission/distribution losses:
270 million kWh (2019 est.)
comparison rankings:
installed generating capacity 143; transmission/distribution losses 142; imports 47; exports 89;
Electricity generation sources:
fossil fuels:
6.1% of total installed capacity (2020 est.)
solar:
4.7% of total installed capacity (2020 est.)
wind:
0.5% of total installed capacity (2020 est.)
hydroelectricity:
88.8% of total installed capacity (2020 est.)
Coal:
production:
0 metric tons (2020 est.)
consumption:
38,000 metric tons (2020 est.)
exports:
0 metric tons (2020 est.)
imports:
59,000 metric tons (2020 est.)
proven reserves:
0 metric tons (2019 est.)
Petroleum:
total petroleum production:
0 bbl/day (2021 est.)
refined petroleum consumption:
26,500 bbl/day (2019 est.)
Refined petroleum products - exports:
80 bbl/day (2015 est.)
comparison ranking:
120
Refined petroleum products - imports:
26,270 bbl/day (2015 est.)
comparison ranking:
105
Natural gas:
proven reserves:
62.297 billion cubic meters (2021 est.)
Carbon dioxide emissions:
3.831 million metric tonnes of CO2 (2019 est.)
from coal and metallurgical coke:
66,000 metric tonnes of CO2 (2019 est.)
from petroleum and other liquids:
3.764 million metric tonnes of CO2 (2019 est.)
comparison ranking:
total emissions 143
Energy consumption per capita:
29.811 million Btu/person (2019 est.)
comparison ranking:
121','3c7265d3ad6ba62b01fa5928f0976579a74471b4c14777ca47e7323db2bcbda8','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fe2f1d01f981f37dccbc66bbdd12d9abdedfabb25fd10f2bdc946a715e8fc72c',2025,'NR','Nauru','energy',18,'Electricity access:
electrification - total population:
100% (2021)
Electricity:
installed generating capacity:
15,000 kW (2020 est.)
consumption:
34.216 million kWh (2019 est.)
exports:
0 kWh (2020 est.)
imports:
0 kWh (2020 est.)
transmission/distribution losses:
0 kWh (2019 est.)
comparison rankings:
imports 194; exports 191; installed generating capacity 206; transmission/distribution losses 212; consumption 204
Electricity generation sources:
fossil fuels:
100% of total installed capacity (2020 est.)
Petroleum:
total petroleum production:
0 bbl/day (2021 est.)
refined petroleum consumption:
400 bbl/day (2019 est.)
Refined petroleum products - imports:
449 bbl/day (2015 est.)
comparison ranking:
205
Carbon dioxide emissions:
66,000 metric tonnes of CO2 (2019 est.)
from petroleum and other liquids:
66,000 metric tonnes of CO2 (2019 est.)
comparison ranking:
total emissions 211
Energy consumption per capita:
0 Btu/person (2019 est.)
comparison ranking:
201','140c9a64745893d53bd1519aead2fb593c6f4adf1b743023559ef31f564b5941','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bd185536ec581e83c7a5500a92f890e64d5b82a585a892c5927bc734c1b08bdb',2025,'NP','Nepal','energy',37,'Electricity access:
population without electricity:
1 million (2020)
electrification - total population:
89.9% (2021)
electrification - urban areas:
94.2% (2021)
electrification - rural areas:
97% (2020)
Electricity:
installed generating capacity:
1.392 million kW (2020 est.)
consumption:
4.676 billion kWh (2019 est.)
exports:
107 million kWh (2019 est.)
imports:
1.729 billion kWh (2019 est.)
transmission/distribution losses:
1.183 billion kWh (2019 est.)
comparison rankings:
installed generating capacity 128; transmission/distribution losses 107; imports 60; exports 91; consumption 128
Electricity generation sources:
solar:
2.6% of total installed capacity (2020 est.)
wind:
0.2% of total installed capacity (2020 est.)
hydroelectricity:
97.2% of total installed capacity (2020 est.)
Coal:
production:
28,000 metric tons (2020 est.)
consumption:
839,000 metric tons (2020 est.)
exports:
0 metric tons (2020 est.)
imports:
811,000 metric tons (2020 est.)
proven reserves:
1 million metric tons (2019 est.)
Petroleum:
total petroleum production:
0 bbl/day (2021 est.)
refined petroleum consumption:
49,400 bbl/day (2019 est.)
Refined petroleum products - imports:
26,120 bbl/day (2015 est.)
comparison ranking:
106
Carbon dioxide emissions:
7.708 million metric tonnes of CO2 (2019 est.)
from coal and metallurgical coke:
1.051 million metric tonnes of CO2 (2019 est.)
from petroleum and other liquids:
6.657 million metric tonnes of CO2 (2019 est.)
comparison ranking:
total emissions 120
Energy consumption per capita:
5.219 million Btu/person (2019 est.)
comparison ranking:
171','a5da896e976798326455383197e6c8420a065cebf01a670fbc75085a10de11fe','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1b4ecf0f43803252be23c68bf4565361a375e151f987cd9e471b4b7fb8bbca4d',2025,'NL','Netherlands','energy',49,'Electricity access:
electrification - total population:
100% (2021)
Electricity:
installed generating capacity:
43.409 million kW (2020 est.)
consumption:
109.796 billion kWh (2020 est.)
exports:
22.433 billion kWh (2020 est.)
imports:
19.773 billion kWh (2020 est.)
transmission/distribution losses:
5.059 billion kWh (2020 est.)
comparison rankings:
transmission/distribution losses 46; imports 11; exports 11; consumption 32; installed generating capacity 29
Electricity generation sources:
fossil fuels:
68.3% of total installed capacity (2020 est.)
nuclear:
3.3% of total installed capacity (2020 est.)
solar:
6.8% of total installed capacity (2020 est.)
wind:
13.1% of total installed capacity (2020 est.)
biomass and waste:
8.5% of total installed capacity (2020 est.)
Nuclear energy: Number of operational nuclear reactors:
1 (2023)
Number of nuclear reactors under construction:
0
Net capacity of operational nuclear reactors:
0.48GW (2023)
Percent of total electricity production:
3.1% (2021)
Percent of total energy produced:
3% (2021)
Number of nuclear reactors permanently shut down:
0
Coal:
production:
1.879 million metric tons (2020 est.)
consumption:
8.241 million metric tons (2020 est.)
exports:
20.164 million metric tons (2020 est.)
imports:
21.552 million metric tons (2020 est.)
proven reserves:
497 million metric tons (2019 est.)
Petroleum:
total petroleum production:
76,100 bbl/day (2021 est.)
refined petroleum consumption:
915,200 bbl/day (2019 est.)
crude oil and lease condensate exports:
8,800 bbl/day (2018 est.)
crude oil and lease condensate imports:
1,096,500 bbl/day (2018 est.)
crude oil estimated reserves:
137.7 million barrels (2021 est.)
Refined petroleum products - production:
1.282 million bbl/day (2017 est.)
comparison ranking:
17
Refined petroleum products - exports:
2.406 million bbl/day (2017 est.)
comparison ranking:
3
Refined petroleum products - imports:
2.148 million bbl/day (2017 est.)
comparison ranking:
3
Natural gas:
production:
32.858 billion cubic meters (2019 est.)
consumption:
44.753 billion cubic meters (2019 est.)
exports:
42.827 billion cubic meters (2019 est.)
imports:
55.767 billion cubic meters (2019 est.)
proven reserves:
132.608 billion cubic meters (2021 est.)
Carbon dioxide emissions:
214.416 million metric tonnes of CO2 (2019 est.)
from coal and metallurgical coke:
23.15 million metric tonnes of CO2 (2019 est.)
from petroleum and other liquids:
116.24 million metric tonnes of CO2 (2019 est.)
from consumed natural gas:
75.027 million metric tonnes of CO2 (2019 est.)
comparison ranking:
total emissions 30
Energy consumption per capita:
219.606 million Btu/person (2019 est.)
comparison ranking:
19','1bb3e3f759e00f257697c92258b080d6eb814f08aea2b66878b41fe35cbdb001','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('253098eca751d2f1166b1fbcd90c0217a3df7caeada9db7fecc3b1d3d7f7f387',2025,'NC','New Caledonia','energy',62,'Electricity access:
electrification - total population:
100% (2021)
Electricity:
installed generating capacity:
1.071 million kW (2020 est.)
consumption:
2,940,707,000 kWh (2019 est.)
exports:
0 kWh (2020 est.)
imports:
0 kWh (2020 est.)
transmission/distribution losses:
64.293 million kWh (2019 est.)
comparison rankings:
imports 139; exports 122; installed generating capacity 133; transmission/distribution losses 167; consumption 140
Electricity generation sources:
fossil fuels:
91.2% of total installed capacity (2020 est.)
wind:
1.5% of total installed capacity (2020 est.)
hydroelectricity:
7.4% of total installed capacity (2020 est.)
Coal:
production:
0 metric tons (2020 est.)
consumption:
1.151 million metric tons (2020 est.)
exports:
0 metric tons (2020 est.)
imports:
1.151 million metric tons (2020 est.)
proven reserves:
2 million metric tons (2019 est.)
Petroleum:
total petroleum production:
0 bbl/day (2021 est.)
refined petroleum consumption:
19,300 bbl/day (2019 est.)
Refined petroleum products - imports:
19,100 bbl/day (2015 est.)
comparison ranking:
124
Carbon dioxide emissions:
5.886 million metric tonnes of CO2 (2019 est.)
from coal and metallurgical coke:
2.879 million metric tonnes of CO2 (2019 est.)
from petroleum and other liquids:
3.007 million metric tonnes of CO2 (2019 est.)
comparison ranking:
total emissions 132
Energy consumption per capita:
0 Btu/person (2019 est.)
comparison ranking:
202','7a88eb80d7be4fe418a60237b572e035dac67a68241e084fe20b0444155766bb','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5deb367820e0a757de8aeecfa73966297f7d2c0ff2153559affc5466eb353950',2025,'NZ','New Zealand','energy',7,'Electricity access:
electrification - total population:
100% (2021)
Electricity:
installed generating capacity:
9.615 million kW (2020 est.)
consumption:
41,169,838,000 kWh (2019 est.)
exports:
0 kWh (2020 est.)
imports:
0 kWh (2020 est.)
transmission/distribution losses:
2,256,332,000 kWh (2019 est.)
comparison rankings:
imports 184; exports 177; installed generating capacity 66; transmission/distribution losses 82; consumption 58
Electricity generation sources:
fossil fuels:
19.5% of total installed capacity (2020 est.)
solar:
0.4% of total installed capacity (2020 est.)
wind:
5.3% of total installed capacity (2020 est.)
hydroelectricity:
54.8% of total installed capacity (2020 est.)
tide and wave:
0.1% of total installed capacity (2020 est.)
geothermal:
18.6% of total installed capacity (2020 est.)
biomass and waste:
1.4% of total installed capacity (2020 est.)
Coal:
production:
3.226 million metric tons (2020 est.)
consumption:
3.001 million metric tons (2020 est.)
exports:
1.14 million metric tons (2020 est.)
imports:
1.09 million metric tons (2020 est.)
proven reserves:
7.575 billion metric tons (2019 est.)
Petroleum:
total petroleum production:
13,400 bbl/day (2021 est.)
refined petroleum consumption:
184,600 bbl/day (2019 est.)
crude oil and lease condensate exports:
21,600 bbl/day (2018 est.)
crude oil and lease condensate imports:
99,900 bbl/day (2018 est.)
crude oil estimated reserves:
41 million barrels (2021 est.)
Refined petroleum products - production:
115,100 bbl/day (2017 est.)
comparison ranking:
65
Refined petroleum products - exports:
1,782 bbl/day (2017 est.)
comparison ranking:
106
Refined petroleum products - imports:
56,000 bbl/day (2017 est.)
comparison ranking:
76
Natural gas:
production:
4,771,126,000 cubic meters (2019 est.)
consumption:
4,946,237,000 cubic meters (2019 est.)
exports:
0 cubic meters (2021 est.)
imports:
0 cubic meters (2021 est.)
proven reserves:
31.148 billion cubic meters (2021 est.)
Carbon dioxide emissions:
40.344 million metric tonnes of CO2 (2019 est.)
from coal and metallurgical coke:
5.139 million metric tonnes of CO2 (2019 est.)
from petroleum and other liquids:
25.76 million metric tonnes of CO2 (2019 est.)
from consumed natural gas:
9.445 million metric tonnes of CO2 (2019 est.)
comparison ranking:
total emissions 64
Energy consumption per capita:
186.804 million Btu/person (2019 est.)
comparison ranking:
22','642d684afa15b3de0c04ea73dd4002ce81da33daa0543b2b6c3992158d0890e0','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('373a1af4f9ce6466646510bf247116caad8fbfe538b2c367892f0d15f4b8b7ab',2025,'NI','Nicaragua','energy',20,'Electricity access:
population without electricity:
(2020) less than 1 million
electrification - total population:
86.2% (2021)
electrification - urban areas:
100% (2021)
electrification - rural areas:
66.3% (2021)
Electricity:
installed generating capacity:
1.837 million kW (2020 est.)
consumption:
3,182,620,000 kWh (2019 est.)
exports:
0 kWh (2019 est.)
imports:
434 million kWh (2019 est.)
transmission/distribution losses:
1.89 billion kWh (2019 est.)
comparison rankings:
installed generating capacity 122; transmission/distribution losses 89; imports 91; exports 187; consumption 137
Electricity generation sources:
fossil fuels:
37.8% of total installed capacity (2020 est.)
solar:
0.5% of total installed capacity (2020 est.)
wind:
15.7% of total installed capacity (2020 est.)
hydroelectricity:
12.2% of total installed capacity (2020 est.)
geothermal:
16.7% of total installed capacity (2020 est.)
biomass and waste:
17.2% of total installed capacity (2020 est.)
Petroleum:
total petroleum production:
200 bbl/day (2021 est.)
refined petroleum consumption:
35,100 bbl/day (2019 est.)
crude oil and lease condensate exports:
0 bbl/day (2018 est.)
crude oil and lease condensate imports:
13,000 bbl/day (2018 est.)
crude oil estimated reserves:
0 barrels (2021 est.)
Refined petroleum products - production:
14,720 bbl/day (2015 est.)
comparison ranking:
95
Refined petroleum products - exports:
460 bbl/day (2015 est.)
comparison ranking:
111
Refined petroleum products - imports:
20,120 bbl/day (2015 est.)
comparison ranking:
121
Carbon dioxide emissions:
4.851 million metric tonnes of CO2 (2019 est.)
from petroleum and other liquids:
4.851 million metric tonnes of CO2 (2019 est.)
comparison ranking:
total emissions 136
Energy consumption per capita:
14.916 million Btu/person (2019 est.)
comparison ranking:
141','fadb9e30da76c92fb88ba37c012be1623bb573aa4fcc8828b83b78a19ed245a6','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('90ce0a7aa503b5aa8ee0fe462f254e635bfc5f0cb82fc7d0bd02f3ed5fe86dc1',2025,'NE','Niger','energy',32,'Electricity access:
population without electricity:
21 million (2020)
electrification - total population:
18.6% (2021)
electrification - urban areas:
65.9% (2021)
electrification - rural areas:
9% (2021)
Electricity:
installed generating capacity:
324,000 kW (2020 est.)
consumption:
1,325,420,000 kWh (2019 est.)
exports:
0 kWh (2019 est.)
imports:
1.057 billion kWh (2019 est.)
transmission/distribution losses:
313 million kWh (2019 est.)
comparison rankings:
installed generating capacity 158; transmission/distribution losses 140; imports 72; exports 115; consumption 154
Electricity generation sources:
fossil fuels:
94.1% of total installed capacity (2020 est.)
solar:
5.9% of total installed capacity (2020 est.)
Coal:
production:
224,000 metric tons (2020 est.)
consumption:
224,000 metric tons (2020 est.)
exports:
0 metric tons (2020 est.)
imports:
0 metric tons (2020 est.)
proven reserves:
6 million metric tons (2019 est.)
Petroleum:
total petroleum production:
8,000 bbl/day (2021 est.)
refined petroleum consumption:
13,800 bbl/day (2019 est.)
crude oil and lease condensate exports:
0 bbl/day (2018 est.)
crude oil and lease condensate imports:
0 bbl/day (2018 est.)
crude oil estimated reserves:
150 million barrels (2021 est.)
Refined petroleum products - production:
15,280 bbl/day (2015 est.)
comparison ranking:
94
Refined petroleum products - exports:
5,422 bbl/day (2015 est.)
comparison ranking:
90
Refined petroleum products - imports:
3,799 bbl/day (2015 est.)
comparison ranking:
180
Carbon dioxide emissions:
2.374 million metric tonnes of CO2 (2019 est.)
from coal and metallurgical coke:
499,000 metric tonnes of CO2 (2019 est.)
from petroleum and other liquids:
1.875 million metric tonnes of CO2 (2019 est.)
from consumed natural gas:
0 metric tonnes of CO2 (2019 est.)
comparison ranking:
total emissions 155
Energy consumption per capita:
1.54 million Btu/person (2019 est.)
comparison ranking:
191','8cbdb4ffbf2f9c8790b068c92c79be4d1387150d8cb6a12c10dabbfe0cf0d22b','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4f0e7b547eeb8a31c491334ef027bb64ab1bbb53f44498b65394400d6a4754fb',2025,'NG','Nigeria','energy',44,'Electricity access:
population without electricity:
66 million (2020)
electrification - total population:
59.6% (2021)
electrification - urban areas:
89.2% (2021)
electrification - rural areas:
26.3% (2021)
Electricity:
installed generating capacity:
11.691 million kW (2020 est.)
consumption:
24,611,480,000 kWh (2019 est.)
exports:
0 kWh (2019 est.)
imports:
0 kWh (2019 est.)
transmission/distribution losses:
4.713 billion kWh (2019 est.)
comparison rankings:
installed generating capacity 58; transmission/distribution losses 47; imports 173; exports 164; consumption 70
Electricity generation sources:
fossil fuels:
78.1% of total installed capacity (2020 est.)
solar:
0.2% of total installed capacity (2020 est.)
hydroelectricity:
21.7% of total installed capacity (2020 est.)
biomass and waste:
0.1% of total installed capacity (2020 est.)
Coal:
production:
44,000 metric tons (2020 est.)
consumption:
85,000 metric tons (2020 est.)
exports:
12,000 metric tons (2020 est.)
imports:
77,000 metric tons (2020 est.)
proven reserves:
344 million metric tons (2019 est.)
Petroleum:
total petroleum production:
1,646,900 bbl/day (2021 est.)
refined petroleum consumption:
483,100 bbl/day (2019 est.)
crude oil and lease condensate exports:
1,889,100 bbl/day (2018 est.)
crude oil and lease condensate imports:
0 bbl/day (2018 est.)
crude oil estimated reserves:
36.89 billion barrels (2021 est.)
Refined petroleum products - production:
35,010 bbl/day (2017 est.)
comparison ranking:
83
Refined petroleum products - exports:
2,332 bbl/day (2015 est.)
comparison ranking:
102
Refined petroleum products - imports:
223,400 bbl/day (2015 est.)
comparison ranking:
31
Natural gas:
production:
46,296,835,000 cubic meters (2019 est.)
consumption:
18,787,602,000 cubic meters (2019 est.)
exports:
27,509,177,000 cubic meters (2019 est.)
imports:
0 cubic meters (2021 est.)
proven reserves:
5,760,883,000,000 cubic meters (2021 est.)
Carbon dioxide emissions:
104.494 million metric tonnes of CO2 (2019 est.)
from coal and metallurgical coke:
231,000 metric tonnes of CO2 (2019 est.)
from petroleum and other liquids:
67.406 million metric tonnes of CO2 (2019 est.)
from consumed natural gas:
36.856 million metric tonnes of CO2 (2019 est.)
comparison ranking:
total emissions 40
Energy consumption per capita:
8.466 million Btu/person (2019 est.)
comparison ranking:
160','93f8d3259cba190b0654926cb6aa33c2658fc3ba44ef8897b098e3830f3db3df','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a535344ad085e48e8bb3e5e15e6d7486acb9962d208a878afacacf66e01a9293',2025,'NU','Niue','energy',7,'Electricity:
installed generating capacity:
3,000 kW (2020 est.)
consumption:
2.6 million kWh (2019 est.)
exports:
0 kWh (2020 est.)
imports:
0 kWh (2020 est.)
transmission/distribution losses:
400,000 kWh (2019 est.)
comparison rankings:
imports 142; exports 125; installed generating capacity 211; transmission/distribution losses 209; consumption 209
Electricity generation sources:
fossil fuels:
100% of total installed capacity (2020 est.)
Petroleum:
total petroleum production:
0 bbl/day (2021 est.)
refined petroleum consumption:
100 bbl/day (2019 est.)
Refined petroleum products - imports:
54 bbl/day (2015 est.)
comparison ranking:
210
Carbon dioxide emissions:
8,000 metric tonnes of CO2 (2019 est.)
from petroleum and other liquids:
8,000 metric tonnes of CO2 (2019 est.)
comparison ranking:
total emissions 216
Energy consumption per capita:
0 Btu/person (2019 est.)
comparison ranking:
210','44f3ad92bb35366d307769d2f99bbde7382eb90d4e819b2159b046c8218fff57','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3c6a6532d93aab7d906f77cc6a7e6a9e421fa1cce2cefbf50b93006efcd7b361',2025,'MK','North Macedonia','energy',28,'Electricity access:
electrification - total population:
100% (2021)
Electricity:
installed generating capacity:
1.928 million kW (2020 est.)
consumption:
6,350,982,000 kWh (2019 est.)
exports:
639 million kWh (2020 est.)
imports:
2.965 billion kWh (2020 est.)
transmission/distribution losses:
979 million kWh (2019 est.)
comparison rankings:
imports 53; exports 70; installed generating capacity 119; transmission/distribution losses 112; consumption 116
Electricity generation sources:
fossil fuels:
71.4% of total installed capacity (2020 est.)
solar:
0.5% of total installed capacity (2020 est.)
wind:
2.3% of total installed capacity (2020 est.)
hydroelectricity:
24.7% of total installed capacity (2020 est.)
biomass and waste:
1.1% of total installed capacity (2020 est.)
Coal:
production:
5.026 million metric tons (2020 est.)
consumption:
5.211 million metric tons (2020 est.)
exports:
1,000 metric tons (2020 est.)
imports:
174,000 metric tons (2020 est.)
proven reserves:
332 million metric tons (2019 est.)
Petroleum:
total petroleum production:
0 bbl/day (2021 est.)
refined petroleum consumption:
22,700 bbl/day (2019 est.)
Refined petroleum products - exports:
3,065 bbl/day (2015 est.)
comparison ranking:
99
Refined petroleum products - imports:
23,560 bbl/day (2015 est.)
comparison ranking:
111
Natural gas:
production:
0 cubic meters (2021 est.)
consumption:
218.917 million cubic meters (2019 est.)
exports:
0 cubic meters (2021 est.)
imports:
218.917 million cubic meters (2019 est.)
proven reserves:
0 cubic meters (2021 est.)
Carbon dioxide emissions:
7.383 million metric tonnes of CO2 (2019 est.)
from coal and metallurgical coke:
3.866 million metric tonnes of CO2 (2019 est.)
from petroleum and other liquids:
3.094 million metric tonnes of CO2 (2019 est.)
from consumed natural gas:
423,000 metric tonnes of CO2 (2019 est.)
comparison ranking:
total emissions 123
Energy consumption per capita:
53.572 million Btu/person (2019 est.)
comparison ranking:
96','22b1f832982812757bcd8a26b9c5f2fb5740ebb95d693c0f23fed2282c99a688','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('981e95562e46dfbba41ba14d2220948edc93edb3443d4a5e2f3960d65a2c371d',2025,'MP','Northern Mariana Islands','energy',40,'Electricity access:
electrification - total population:
100% (2021)
Petroleum:
total petroleum production:
0 bbl/day (2021 est.) Data represented includes both Guam and Northern Mariana Islands
refined petroleum consumption:
2,100 bbl/day (2019 est.) Data represented includes both Guam and Northern Mariana Islands
Carbon dioxide emissions:
0 metric tonnes of CO2 (2019 est.)
comparison ranking:
total emissions 217
Energy consumption per capita:
0 Btu/person (2019 est.)
comparison ranking:
196','dda5970067a57b397290ac30f7575f5b0b16a81e99e3faa49fc38f67f296beb8','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0102b7524b14ca0a145687b2bacebda129af304d889a94a99328c60b2bc9e326',2025,'NO','Norway','energy',51,'Electricity access:
electrification - total population:
100% (2021)
Electricity:
installed generating capacity:
38.36 million kW (2020 est.)
consumption:
124.288 billion kWh (2020 est.)
exports:
24.968 billion kWh (2020 est.)
imports:
4.496 billion kWh (2020 est.)
transmission/distribution losses:
8.909 billion kWh (2020 est.)
comparison rankings:
transmission/distribution losses 37; imports 43; exports 7; consumption 29; installed generating capacity 31
Electricity generation sources:
fossil fuels:
1.2% of total installed capacity (2020 est.)
wind:
6.4% of total installed capacity (2020 est.)
hydroelectricity:
92.1% of total installed capacity (2020 est.)
biomass and waste:
0.3% of total installed capacity (2020 est.)
Coal:
production:
69,000 metric tons (2020 est.)
consumption:
1.13 million metric tons (2020 est.)
exports:
46,000 metric tons (2020 est.)
imports:
1.172 million metric tons (2020 est.)
proven reserves:
2 million metric tons (2019 est.)
Petroleum:
total petroleum production:
2.026 million bbl/day (2021 est.)
refined petroleum consumption:
215,900 bbl/day (2019 est.)
crude oil and lease condensate exports:
1,242,500 bbl/day (2018 est.)
crude oil and lease condensate imports:
66,300 bbl/day (2018 est.)
crude oil estimated reserves:
8,122,200,000 barrels (2021 est.)
Refined petroleum products - production:
371,600 bbl/day (2017 est.)
comparison ranking:
38
Refined petroleum products - exports:
432,800 bbl/day (2017 est.)
comparison ranking:
20
Refined petroleum products - imports:
135,300 bbl/day (2017 est.)
comparison ranking:
43
Natural gas:
production:
112,052,523,000 cubic meters (2020 est.)
consumption:
3,980,351,000 cubic meters (2020 est.)
exports:
107,337,690,000 cubic meters (2020 est.)
imports:
32.196 million cubic meters (2020 est.)
proven reserves:
1,544,455,000,000 cubic meters (2021 est.)
Carbon dioxide emissions:
36.731 million metric tonnes of CO2 (2019 est.)
from coal and metallurgical coke:
3.182 million metric tonnes of CO2 (2019 est.)
from petroleum and other liquids:
25.256 million metric tonnes of CO2 (2019 est.)
from consumed natural gas:
8.294 million metric tonnes of CO2 (2019 est.)
comparison ranking:
total emissions 69
Energy consumption per capita:
333.833 million Btu/person (2019 est.)
comparison ranking:
8','719fda170430bcb7480148e8310c2b38e72d89327e6be116e3e43823834edc83','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d098a61c3d99828c4f244fd43402e3dd9c54f5ac909cf758e3892f3611221a8c',2025,'OM','Oman','energy',7,'Electricity access:
electrification - total population:
100% (2021)
Electricity:
installed generating capacity:
8.601 million kW (2020 est.)
consumption:
32,320,020,000 kWh (2019 est.)
exports:
0 kWh (2019 est.)
imports:
0 kWh (2019 est.)
transmission/distribution losses:
3.717 billion kWh (2019 est.)
comparison rankings:
installed generating capacity 71; transmission/distribution losses 56; imports 134; exports 117; consumption 61
Electricity generation sources:
fossil fuels:
100% of total installed capacity (2020 est.)
Coal:
production:
0 metric tons (2020 est.)
consumption:
115,000 metric tons (2020 est.)
exports:
0 metric tons (2020 est.)
imports:
115,000 metric tons (2020 est.)
proven reserves:
0 metric tons (2019 est.)
Petroleum:
total petroleum production:
978,800 bbl/day (2021 est.)
refined petroleum consumption:
234,200 bbl/day (2019 est.)
crude oil and lease condensate exports:
779,000 bbl/day (2018 est.)
crude oil and lease condensate imports:
0 bbl/day (2018 est.)
crude oil estimated reserves:
5.373 billion barrels (2021 est.)
Refined petroleum products - production:
229,600 bbl/day (2015 est.)
comparison ranking:
48
Refined petroleum products - exports:
33,700 bbl/day (2015 est.)
comparison ranking:
60
Refined petroleum products - imports:
6,041 bbl/day (2015 est.)
comparison ranking:
165
Natural gas:
production:
36,596,746,000 cubic meters (2019 est.)
consumption:
24,279,419,000 cubic meters (2019 est.)
exports:
13,798,040,000 cubic meters (2019 est.)
imports:
1,605,959,000 cubic meters (2019 est.)
proven reserves:
651.286 billion cubic meters (2021 est.)
Carbon dioxide emissions:
76.321 million metric tonnes of CO2 (2019 est.)
from coal and metallurgical coke:
191,000 metric tonnes of CO2 (2019 est.)
from petroleum and other liquids:
29.682 million metric tonnes of CO2 (2019 est.)
from consumed natural gas:
46.447 million metric tonnes of CO2 (2019 est.)
comparison ranking:
total emissions 49
Energy consumption per capita:
292.022 million Btu/person (2019 est.)
comparison ranking:
13','a4d2ce2840aefa27b0f778cc65882f619c2433b31e32cd11007d56f40d14c871','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('18141a52ead260a3e820a5ef6f7aec0fb68718e1ed3ec9bdd75a394abfd2a496',2025,'PK','Pakistan','energy',8,'Electricity access:
population without electricity:
46 million (2020)
electrification - total population:
94.9% (2021)
electrification - urban areas:
99.9% (2021)
electrification - rural areas:
91.9% (2021)
Electricity:
installed generating capacity:
39.925 million kW (2020 est.)
consumption:
103,493,520,000 kWh (2019 est.)
exports:
0 kWh (2019 est.)
imports:
487 million kWh (2019 est.)
transmission/distribution losses:
17.389 billion kWh (2019 est.)
comparison rankings:
installed generating capacity 30; transmission/distribution losses 24; imports 88; exports 178; consumption 33
Electricity generation sources:
fossil fuels:
55.2% of total installed capacity (2020 est.)
nuclear:
8.2% of total installed capacity (2020 est.)
solar:
1% of total installed capacity (2020 est.)
wind:
2.8% of total installed capacity (2020 est.)
hydroelectricity:
31.9% of total installed capacity (2020 est.)
biomass and waste:
0.8% of total installed capacity (2020 est.)
Nuclear energy: Number of operational nuclear reactors:
6 (2023)
Number of nuclear reactors under construction:
0
Net capacity of operational nuclear reactors:
3.26GW (2023)
Percent of total electricity production:
10.6% (2021)
Percent of total energy produced:
8.7% (2021)
Number of nuclear reactors permanently shut down:
0
Coal:
production:
4.855 million metric tons (2020 est.)
consumption:
21.012 million metric tons (2020 est.)
exports:
1,000 metric tons (2020 est.)
imports:
17.239 million metric tons (2020 est.)
proven reserves:
3.064 billion metric tons (2019 est.)
Petroleum:
total petroleum production:
100,700 bbl/day (2021 est.)
refined petroleum consumption:
493,400 bbl/day (2019 est.)
crude oil and lease condensate exports:
7,800 bbl/day (2018 est.)
crude oil and lease condensate imports:
198,400 bbl/day (2018 est.)
crude oil estimated reserves:
540 million barrels (2021 est.)
Refined petroleum products - production:
291,200 bbl/day (2015 est.)
comparison ranking:
43
Refined petroleum products - exports:
25,510 bbl/day (2015 est.)
comparison ranking:
68
Refined petroleum products - imports:
264,500 bbl/day (2015 est.)
comparison ranking:
27
Natural gas:
production:
38,056,250,000 cubic meters (2019 est.)
consumption:
48,391,627,000 cubic meters (2019 est.)
exports:
0 cubic meters (2021 est.)
imports:
10,743,167,000 cubic meters (2019 est.)
proven reserves:
592.218 billion cubic meters (2021 est.)
Carbon dioxide emissions:
193.869 million metric tonnes of CO2 (2019 est.)
from coal and metallurgical coke:
47.468 million metric tonnes of CO2 (2019 est.)
from petroleum and other liquids:
67.789 million metric tonnes of CO2 (2019 est.)
from consumed natural gas:
78.611 million metric tonnes of CO2 (2019 est.)
comparison ranking:
total emissions 31
Energy consumption per capita:
15.859 million Btu/person (2019 est.)
comparison ranking:
140','795517d9984e4018c1239ec823f05c9737b7bd5c1c54b63ced03150dcb736fb5','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('977fe32c3f5f1e2dde38204419cbf3b1bb607133dbb1e8abaa89e72d03b48020',2025,'PW','Palau','energy',21,'Electricity access:
electrification - total population:
100% (2021)','a05175d18d3663ad25c80fce0a2f9d8c3948b2fa4d1a94432259d1d8804cb39b','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('32d07d6b9a81b7f49453ce659cc623e10b66a920c3259e1be335829587d490a5',2025,'PA','Panama','energy',32,'Electricity access:
population without electricity:
(2020) less than 1 million
electrification - total population:
95.2% (2021)
electrification - urban areas:
99.7% (2021)
electrification - rural areas:
85.6% (2020)
Electricity:
installed generating capacity:
4.106 million kW (2020 est.)
consumption:
10,808,780,000 kWh (2019 est.)
exports:
427 million kWh (2019 est.)
imports:
77 million kWh (2019 est.)
transmission/distribution losses:
1.309 billion kWh (2019 est.)
comparison rankings:
installed generating capacity 95; transmission/distribution losses 103; imports 110; exports 77;
Electricity generation sources:
fossil fuels:
24.5% of total installed capacity (2020 est.)
solar:
2.7% of total installed capacity (2020 est.)
wind:
6.4% of total installed capacity (2020 est.)
hydroelectricity:
66.2% of total installed capacity (2020 est.)
biomass and waste:
0.2% of total installed capacity (2020 est.)
Coal:
production:
0 metric tons (2020 est.)
consumption:
1.118 million metric tons (2020 est.)
exports:
0 metric tons (2020 est.)
imports:
1.15 million metric tons (2020 est.)
proven reserves:
0 metric tons (2019 est.)
Petroleum:
total petroleum production:
0 bbl/day (2021 est.)
refined petroleum consumption:
143,700 bbl/day (2019 est.)
Refined petroleum products - exports:
66 bbl/day (2015 est.)
comparison ranking:
121
Refined petroleum products - imports:
129,200 bbl/day (2015 est.)
comparison ranking:
45
Natural gas:
production:
0 cubic meters (2021 est.)
consumption:
552.744 million cubic meters (2019 est.)
exports:
0 cubic meters (2021 est.)
imports:
552.744 million cubic meters (2019 est.)
proven reserves:
0 cubic meters (2021 est.)
Carbon dioxide emissions:
25.263 million metric tonnes of CO2 (2019 est.)
from coal and metallurgical coke:
1.905 million metric tonnes of CO2 (2019 est.)
from petroleum and other liquids:
22.281 million metric tonnes of CO2 (2019 est.)
from consumed natural gas:
1.077 million metric tonnes of CO2 (2019 est.)
comparison ranking:
total emissions 79
Energy consumption per capita:
98.946 million Btu/person (2019 est.)
comparison ranking:
60','e4763760ec76ddf91a5eeecffbf55531350826a1bc04ec93b01dad31a3ee3571','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b2c1ea910409ee2e6ee2c02ef3fc48d8d4efdeda3fafd26e499e547e5bd56c06',2025,'PG','Papua New Guinea','energy',43,'Electricity access:
electrification - total population:
20.9% (2021)
electrification - urban areas:
65.1% (2021)
electrification - rural areas:
14% (2021)
Electricity:
installed generating capacity:
1.139 million kW (2020 est.)
consumption:
3,701,693,000 kWh (2019 est.)
exports:
0 kWh (2019 est.)
imports:
0 kWh (2019 est.)
transmission/distribution losses:
340 million kWh (2019 est.)
comparison rankings:
installed generating capacity 132; transmission/distribution losses 139; imports 147; exports 134; consumption 134
Electricity generation sources:
fossil fuels:
80.2% of total installed capacity (2020 est.)
hydroelectricity:
18.9% of total installed capacity (2020 est.)
biomass and waste:
1% of total installed capacity (2020 est.)
Petroleum:
total petroleum production:
37,200 bbl/day (2021 est.)
refined petroleum consumption:
38,200 bbl/day (2019 est.)
crude oil and lease condensate exports:
60,300 bbl/day (2018 est.)
crude oil and lease condensate imports:
27,400 bbl/day (2018 est.)
crude oil estimated reserves:
159.7 million barrels (2021 est.)
Refined petroleum products - production:
22,170 bbl/day (2015 est.)
comparison ranking:
88
Refined petroleum products - exports:
0 bbl/day (2015 est.)
comparison ranking:
185
Refined petroleum products - imports:
17,110 bbl/day (2015 est.)
comparison ranking:
134
Natural gas:
production:
11,784,065,000 cubic meters (2020 est.)
consumption:
166.984 million cubic meters (2020 est.)
exports:
11,764,498,000 cubic meters (2020 est.)
imports:
0 cubic meters (2021 est.)
proven reserves:
183.125 billion cubic meters (2021 est.)
Carbon dioxide emissions:
6.491 million metric tonnes of CO2 (2019 est.)
from petroleum and other liquids:
5.965 million metric tonnes of CO2 (2019 est.)
from consumed natural gas:
526,000 metric tonnes of CO2 (2019 est.)
comparison ranking:
total emissions 128
Energy consumption per capita:
11.316 million Btu/person (2019 est.)
comparison ranking:
151','c43ddcac2714c4f0422e269d0735056cc0b5b6e08f58e61ab510160f534403d2','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('154e7bf23a934759da5afdc3efeecc11ffb75f142666bd1a1026af71db999965',2025,'PY','Paraguay','energy',62,'Electricity access:
electrification - total population:
100% (2021)
Electricity:
installed generating capacity:
8.831 million kW (2020 est.)
consumption:
12,718,590,000 kWh (2019 est.)
exports:
31.748 billion kWh (2019 est.)
imports:
0 kWh (2019 est.)
transmission/distribution losses:
4.47 billion kWh (2019 est.)
comparison rankings:
installed generating capacity 70; transmission/distribution losses 50; imports 155; exports 6; consumption 90
Electricity generation sources:
hydroelectricity:
100% of total installed capacity (2020 est.)
Petroleum:
total petroleum production:
2,000 bbl/day (2021 est.)
refined petroleum consumption:
56,900 bbl/day (2019 est.)
Refined petroleum products - imports:
40,760 bbl/day (2015 est.)
comparison ranking:
89
Carbon dioxide emissions:
7.896 million metric tonnes of CO2 (2019 est.)
from coal and metallurgical coke:
3,000 metric tonnes of CO2 (2019 est.)
from petroleum and other liquids:
7.893 million metric tonnes of CO2 (2019 est.)
comparison ranking:
total emissions 116
Energy consumption per capita:
62.775 million Btu/person (2019 est.)
comparison ranking:
89','b790dd7e94c2e0202b8d006ec2ec33fed2db4d7601db083159d8c45db0b7afa7','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1044946acb34090ba0b3eb52ac6ebb633da1dbba0abdfa68614afe08be5bdb73',2025,'PE','Peru','energy',7,'Electricity access:
population without electricity:
(2020) less than 1 million
electrification - total population:
95.6% (2021)
electrification - urban areas:
98.9% (2021)
electrification - rural areas:
83.5% (2021)
Electricity:
installed generating capacity:
15.34 million kW (2020 est.)
consumption:
49,121,370,000 kWh (2019 est.)
exports:
0 kWh (2019 est.)
imports:
60 million kWh (2019 est.)
transmission/distribution losses:
6.408 billion kWh (2019 est.)
comparison rankings:
installed generating capacity 54; transmission/distribution losses 43; imports 112; exports 135; consumption 51
Electricity generation sources:
fossil fuels:
38.5% of total installed capacity (2020 est.)
solar:
1.5% of total installed capacity (2020 est.)
wind:
3.5% of total installed capacity (2020 est.)
hydroelectricity:
55.4% of total installed capacity (2020 est.)
biomass and waste:
1.1% of total installed capacity (2020 est.)
Coal:
production:
696,000 metric tons (2020 est.)
consumption:
396,000 metric tons (2020 est.)
exports:
252,000 metric tons (2020 est.)
imports:
262,000 metric tons (2020 est.)
proven reserves:
102 million metric tons (2019 est.)
Petroleum:
total petroleum production:
122,500 bbl/day (2021 est.)
refined petroleum consumption:
265,500 bbl/day (2019 est.)
crude oil and lease condensate exports:
6,500 bbl/day (2018 est.)
crude oil and lease condensate imports:
112,900 bbl/day (2018 est.)
crude oil estimated reserves:
858.9 million barrels (2021 est.)
Refined petroleum products - production:
166,600 bbl/day (2015 est.)
comparison ranking:
57
Refined petroleum products - exports:
62,640 bbl/day (2015 est.)
comparison ranking:
49
Refined petroleum products - imports:
65,400 bbl/day (2015 est.)
comparison ranking:
71
Natural gas:
production:
12,079,211,000 cubic meters (2020 est.)
consumption:
8,278,048,000 cubic meters (2019 est.)
exports:
5.446 billion cubic meters (2019 est.)
imports:
0 cubic meters (2021 est.)
proven reserves:
300.158 billion cubic meters (2021 est.)
Carbon dioxide emissions:
54.996 million metric tonnes of CO2 (2019 est.)
from coal and metallurgical coke:
1.171 million metric tonnes of CO2 (2019 est.)
from petroleum and other liquids:
35.119 million metric tonnes of CO2 (2019 est.)
from consumed natural gas:
18.706 million metric tonnes of CO2 (2019 est.)
comparison ranking:
total emissions 55
Energy consumption per capita:
36.465 million Btu/person (2019 est.)
comparison ranking:
112','3b74c8cc89ffce2e2e31ac29fc7bfc645570efbf1edf3339da3c75626db7532b','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('eac7ab0f9532335b761d4e0122c2ad9bff3444c3b7ec8bfdd5b6d32d90bd9cdb',2025,'PH','Philippines','energy',20,'Electricity access:
population without electricity:
3 million (2020)
electrification - total population:
97.4% (2021)
electrification - urban areas:
98.6% (2021)
electrification - rural areas:
96.4% (2021)
Electricity:
installed generating capacity:
27.885 million kW (2020 est.)
consumption:
90,926,990,000 kWh (2019 est.)
exports:
0 kWh (2020 est.)
imports:
0 kWh (2020 est.)
transmission/distribution losses:
9.994 billion kWh (2019 est.)
comparison rankings:
imports 209; exports 209; installed generating capacity 38; transmission/distribution losses 32; consumption 35
Electricity generation sources:
fossil fuels:
77.6% of total installed capacity (2020 est.)
solar:
1.3% of total installed capacity (2020 est.)
wind:
1.1% of total installed capacity (2020 est.)
hydroelectricity:
8% of total installed capacity (2020 est.)
geothermal:
11% of total installed capacity (2020 est.)
biomass and waste:
1.1% of total installed capacity (2020 est.)
Coal:
production:
13.752 million metric tons (2020 est.)
consumption:
32.855 million metric tons (2020 est.)
exports:
7.554 million metric tons (2020 est.)
imports:
28.358 million metric tons (2020 est.)
proven reserves:
361 million metric tons (2019 est.)
Petroleum:
total petroleum production:
10,300 bbl/day (2021 est.)
refined petroleum consumption:
527,400 bbl/day (2019 est.)
crude oil and lease condensate exports:
12,400 bbl/day (2018 est.)
crude oil and lease condensate imports:
232,500 bbl/day (2018 est.)
crude oil estimated reserves:
138.5 million barrels (2021 est.)
Refined petroleum products - production:
215,500 bbl/day (2015 est.)
comparison ranking:
50
Refined petroleum products - exports:
26,710 bbl/day (2015 est.)
comparison ranking:
65
Refined petroleum products - imports:
211,400 bbl/day (2015 est.)
comparison ranking:
33
Natural gas:
production:
3,632,507,000 cubic meters (2019 est.)
consumption:
3,632,507,000 cubic meters (2019 est.)
exports:
0 cubic meters (2021 est.)
imports:
0 cubic meters (2021 est.)
proven reserves:
98.542 billion cubic meters (2021 est.)
Carbon dioxide emissions:
142.282 million metric tonnes of CO2 (2019 est.)
from coal and metallurgical coke:
70.82 million metric tonnes of CO2 (2019 est.)
from petroleum and other liquids:
64.418 million metric tonnes of CO2 (2019 est.)
from consumed natural gas:
7.044 million metric tonnes of CO2 (2019 est.)
comparison ranking:
total emissions 36
Energy consumption per capita:
19.261 million Btu/person (2019 est.)
comparison ranking:
137','3bc59ae0d7c3a9c19de55881479ba2791cc0b0cdbbf0aa4c45feeca13f482742','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4b692bbfdc3346776906c39a9e5af05055cc519c93ba3791c4a720ffd7ceed85',2025,'PL','Poland','energy',43,'Electricity access:
electrification - total population:
100% (2021)
Electricity:
installed generating capacity:
47.269 million kW (2020 est.)
consumption:
149.203 billion kWh (2020 est.)
exports:
7.357 billion kWh (2020 est.)
imports:
20.624 billion kWh (2020 est.)
transmission/distribution losses:
9.995 billion kWh (2020 est.)
comparison rankings:
transmission/distribution losses 31; imports 10; exports 25; consumption 25; installed generating capacity 26
Electricity generation sources:
fossil fuels:
79.8% of total installed capacity (2020 est.)
solar:
1.4% of total installed capacity (2020 est.)
wind:
10.8% of total installed capacity (2020 est.)
hydroelectricity:
2% of total installed capacity (2020 est.)
biomass and waste:
6% of total installed capacity (2020 est.)
Coal:
production:
108.152 million metric tons (2020 est.)
consumption:
110.674 million metric tons (2020 est.)
exports:
11.063 million metric tons (2020 est.)
imports:
13.281 million metric tons (2020 est.)
proven reserves:
26.932 billion metric tons (2019 est.)
Petroleum:
total petroleum production:
28,400 bbl/day (2021 est.)
refined petroleum consumption:
697,700 bbl/day (2019 est.)
crude oil and lease condensate exports:
6,000 bbl/day (2018 est.)
crude oil and lease condensate imports:
542,100 bbl/day (2018 est.)
crude oil estimated reserves:
113 million barrels (2021 est.)
Refined petroleum products - production:
554,200 bbl/day (2017 est.)
comparison ranking:
30
Refined petroleum products - exports:
104,800 bbl/day (2017 est.)
comparison ranking:
43
Refined petroleum products - imports:
222,300 bbl/day (2017 est.)
comparison ranking:
32
Natural gas:
production:
5.667 billion cubic meters (2020 est.)
consumption:
21.464 billion cubic meters (2020 est.)
exports:
704.975 million cubic meters (2019 est.)
imports:
16.633 billion cubic meters (2020 est.)
proven reserves:
91.492 billion cubic meters (2021 est.)
Carbon dioxide emissions:
304.04 million metric tonnes of CO2 (2019 est.)
from coal and metallurgical coke:
176.938 million metric tonnes of CO2 (2019 est.)
from petroleum and other liquids:
89.944 million metric tonnes of CO2 (2019 est.)
from consumed natural gas:
37.158 million metric tonnes of CO2 (2019 est.)
comparison ranking:
total emissions 21
Energy consumption per capita:
112.831 million Btu/person (2019 est.)
comparison ranking:
48','b991a546d6b3a4161200cc9e5da605abb6213b31dcc82621637f98ec030e5783','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c5e86f9ac8de0744e886e6335d6d264f4a34caebc4696dca63dbcb37ce0918b1',2025,'PT','Portugal','energy',56,'Electricity access:
electrification - total population:
100% (2021)
Electricity:
installed generating capacity:
22.364 million kW (2020 est.)
consumption:
48.409 billion kWh (2020 est.)
exports:
6.097 billion kWh (2020 est.)
imports:
7.553 billion kWh (2020 est.)
transmission/distribution losses:
5.269 billion kWh (2020 est.)
comparison rankings:
transmission/distribution losses 45; imports 31; exports 31; consumption 52; installed generating capacity 43
Electricity generation sources:
fossil fuels:
39% of total installed capacity (2020 est.)
solar:
3.2% of total installed capacity (2020 est.)
wind:
23.3% of total installed capacity (2020 est.)
hydroelectricity:
26.5% of total installed capacity (2020 est.)
geothermal:
0.4% of total installed capacity (2020 est.)
biomass and waste:
7.7% of total installed capacity (2020 est.)
Coal:
production:
0 metric tons (2020 est.)
consumption:
957,000 metric tons (2020 est.)
exports:
1,000 metric tons (2020 est.)
imports:
238,000 metric tons (2020 est.)
proven reserves:
36 million metric tons (2019 est.)
Petroleum:
total petroleum production:
8,000 bbl/day (2021 est.)
refined petroleum consumption:
249,100 bbl/day (2019 est.)
crude oil and lease condensate exports:
0 bbl/day (2018 est.)
crude oil and lease condensate imports:
255,400 bbl/day (2018 est.)
crude oil estimated reserves:
0 barrels (2021 est.)
Refined petroleum products - production:
323,000 bbl/day (2017 est.)
comparison ranking:
39
Refined petroleum products - exports:
143,500 bbl/day (2017 est.)
comparison ranking:
36
Refined petroleum products - imports:
78,700 bbl/day (2017 est.)
comparison ranking:
64
Natural gas:
production:
0 cubic meters (2021 est.)
consumption:
5.94 billion cubic meters (2020 est.)
exports:
0 cubic meters (2021 est.)
imports:
6.09 billion cubic meters (2020 est.)
proven reserves:
0 cubic meters (2021 est.)
Carbon dioxide emissions:
50.37 million metric tonnes of CO2 (2019 est.)
from coal and metallurgical coke:
4.882 million metric tonnes of CO2 (2019 est.)
from petroleum and other liquids:
33.429 million metric tonnes of CO2 (2019 est.)
from consumed natural gas:
12.059 million metric tonnes of CO2 (2019 est.)
comparison ranking:
total emissions 57
Energy consumption per capita:
101.734 million Btu/person (2019 est.)
comparison ranking:
57','68c042c3c44f17f87d13c87dc9911527821697aba1087d903f375a397d704c2d','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('161503744e9fd8e547164cb7a5417fa127cecdd03866e948ec43d02fac7309b2',2025,'PR','Puerto Rico','energy',69,'Electricity access:
electrification - total population:
100% (2021)
Electricity:
installed generating capacity:
6.18 million kW (2020 est.)
consumption:
15,203,140,000 kWh (2019 est.)
exports:
0 kWh (2020 est.)
imports:
0 kWh (2020 est.)
transmission/distribution losses:
2.5 billion kWh (2019 est.)
comparison rankings:
imports 180; exports 172; installed generating capacity 80; transmission/distribution losses 77; consumption 80
Electricity generation sources:
fossil fuels:
94.8% of total installed capacity (2020 est.)
solar:
1.4% of total installed capacity (2020 est.)
wind:
3.4% of total installed capacity (2020 est.)
hydroelectricity:
0.3% of total installed capacity (2020 est.)
biomass and waste:
0.1% of total installed capacity (2020 est.)
Coal:
production:
0 metric tons (2020 est.)
consumption:
1.361 million metric tons (2020 est.)
exports:
0 metric tons (2020 est.)
imports:
1.502 million metric tons (2020 est.)
proven reserves:
0 metric tons (2019 est.)
Petroleum:
total petroleum production:
0 bbl/day (2021 est.)
refined petroleum consumption:
79,000 bbl/day (2019 est.)
Refined petroleum products - exports:
18,420 bbl/day (2015 est.)
comparison ranking:
70
Refined petroleum products - imports:
127,100 bbl/day (2015 est.)
comparison ranking:
46
Natural gas:
production:
0 cubic meters (2021 est.)
consumption:
1,366,512,000 cubic meters (2020 est.)
exports:
0 cubic meters (2021 est.)
imports:
1,366,512,000 cubic meters (2020 est.)
proven reserves:
0 cubic meters (2021 est.)
Carbon dioxide emissions:
18.999 million metric tonnes of CO2 (2019 est.)
from coal and metallurgical coke:
3.774 million metric tonnes of CO2 (2019 est.)
from petroleum and other liquids:
11.407 million metric tonnes of CO2 (2019 est.)
from consumed natural gas:
3.818 million metric tonnes of CO2 (2019 est.)
comparison ranking:
total emissions 86
Energy consumption per capita:
94.379 million Btu/person (2019 est.)
comparison ranking:
63','3b592f9d74d9b9af10f42079bee1d7e4d4d2a969d04da71e24e26c37ddfc8a4d','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4a8714fcfd0cd3bc2ef8516b89c60cb227816cf42e79d923f7798ab1ac10bc3d',2025,'QA','Qatar','energy',7,'Electricity access:
electrification - total population:
100% (2021)
Electricity:
installed generating capacity:
10.633 million kW (2020 est.)
consumption:
44,116,984,000 kWh (2019 est.)
exports:
0 kWh (2019 est.)
imports:
0 kWh (2019 est.)
transmission/distribution losses:
2.772 billion kWh (2019 est.)
comparison rankings:
installed generating capacity 63; transmission/distribution losses 68; imports 181; exports 173; consumption 56
Electricity generation sources:
fossil fuels:
100% of total installed capacity (2020 est.)
Petroleum:
total petroleum production:
1,815,100 bbl/day (2021 est.)
refined petroleum consumption:
293,800 bbl/day (2019 est.)
crude oil and lease condensate exports:
1,264,400 bbl/day (2018 est.)
crude oil and lease condensate imports:
0 bbl/day (2018 est.)
crude oil estimated reserves:
25.244 billion barrels (2021 est.)
Refined petroleum products - production:
273,800 bbl/day (2015 est.)
comparison ranking:
46
Refined petroleum products - exports:
485,000 bbl/day (2015 est.)
comparison ranking:
18
Refined petroleum products - imports:
12,300 bbl/day (2015 est.)
comparison ranking:
143
Natural gas:
production:
167,460,996,000 cubic meters (2019 est.)
consumption:
37,701,809,000 cubic meters (2019 est.)
exports:
126,749,621,000 cubic meters (2019 est.)
imports:
0 cubic meters (2021 est.)
proven reserves:
23,860,500,000,000 cubic meters (2021 est.)
Carbon dioxide emissions:
111.922 million metric tonnes of CO2 (2019 est.)
from petroleum and other liquids:
33.44 million metric tonnes of CO2 (2019 est.)
from consumed natural gas:
78.482 million metric tonnes of CO2 (2019 est.)
comparison ranking:
total emissions 38
Energy consumption per capita:
723.582 million Btu/person (2019 est.)
comparison ranking:
1','70145d33a80897a07e5cc21d9910b22d53c20ab3250403d1166760cb33a4ae2a','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d4994953fb6e9c925e2d6ac295b486bc6536a82664a67293b699cf508d1ff44f',2025,'RO','Romania','energy',7,'Electricity access:
electrification - total population:
100% (2021)
Electricity:
installed generating capacity:
20.528 million kW (2020 est.)
consumption:
50,039,421,000 kWh (2019 est.)
exports:
5.459 billion kWh (2020 est.)
imports:
8.252 billion kWh (2020 est.)
transmission/distribution losses:
6.501 billion kWh (2019 est.)
comparison rankings:
imports 28; exports 35; installed generating capacity 46; transmission/distribution losses 42; consumption 50
Electricity generation sources:
fossil fuels:
32.1% of total installed capacity (2020 est.)
nuclear:
20.4% of total installed capacity (2020 est.)
solar:
3.4% of total installed capacity (2020 est.)
wind:
13.4% of total installed capacity (2020 est.)
hydroelectricity:
29.9% of total installed capacity (2020 est.)
biomass and waste:
0.9% of total installed capacity (2020 est.)
Nuclear energy: Number of operational nuclear reactors:
2 (2023)
Number of nuclear reactors under construction:
0
Net capacity of operational nuclear reactors:
1.3GW (2023)
Percent of total electricity production:
18.5% (2021)
Percent of total energy produced:
12.9% (2021)
Number of nuclear reactors permanently shut down:
0
Coal:
production:
15.002 million metric tons (2020 est.)
consumption:
16.412 million metric tons (2020 est.)
exports:
2,000 metric tons (2020 est.)
imports:
1.384 million metric tons (2020 est.)
proven reserves:
291 million metric tons (2019 est.)
Petroleum:
total petroleum production:
74,000 bbl/day (2021 est.)
refined petroleum consumption:
222,200 bbl/day (2019 est.)
crude oil and lease condensate exports:
1,400 bbl/day (2018 est.)
crude oil and lease condensate imports:
161,600 bbl/day (2018 est.)
crude oil estimated reserves:
600 million barrels (2021 est.)
Refined petroleum products - production:
232,600 bbl/day (2015 est.)
comparison ranking:
47
Refined petroleum products - exports:
103,000 bbl/day (2015 est.)
comparison ranking:
44
Refined petroleum products - imports:
49,420 bbl/day (2015 est.)
comparison ranking:
81
Natural gas:
production:
10,367,941,000 cubic meters (2019 est.)
consumption:
11,087,528,000 cubic meters (2019 est.)
exports:
11.185 million cubic meters (2019 est.)
imports:
2,800,985,000 cubic meters (2019 est.)
proven reserves:
105.48 billion cubic meters (2021 est.)
Carbon dioxide emissions:
68.746 million metric tonnes of CO2 (2019 est.)
from coal and metallurgical coke:
20.891 million metric tonnes of CO2 (2019 est.)
from petroleum and other liquids:
27.268 million metric tonnes of CO2 (2019 est.)
from consumed natural gas:
20.588 million metric tonnes of CO2 (2019 est.)
comparison ranking:
total emissions 51
Energy consumption per capita:
71.736 million Btu/person (2019 est.)
comparison ranking:
84','f27b61f62050ac5b8cbb3c3e094f69c88037fde5868207c867c3affcbbb67e5b','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e31e7c6f6248ba95b137a3545e594b3cdf4d0f5afa77e81aba0af7df9f0824a4',2025,'RO','Romania','energy',20,'Electricity access:
electrification - total population:
100% (2021)
Electricity:
installed generating capacity:
276.463 million kW (2020 est.)
consumption:
942.895 billion kWh (2019 est.)
exports:
12.116 billion kWh (2020 est.)
imports:
1.377 billion kWh (2020 est.)
transmission/distribution losses:
99.077 billion kWh (2019 est.)
comparison rankings:
imports 66; exports 19; installed generating capacity 5; transmission/distribution losses 5; consumption 4
Electricity generation sources:
fossil fuels:
59.4% of total installed capacity (2020 est.)
nuclear:
21% of total installed capacity (2020 est.)
solar:
0.2% of total installed capacity (2020 est.)
hydroelectricity:
19.1% of total installed capacity (2020 est.)
biomass and waste:
0.3% of total installed capacity (2020 est.)
Nuclear energy: Number of operational nuclear reactors:
37 (2023)
Number of nuclear reactors under construction:
3
Net capacity of operational nuclear reactors:
27.73GW (2021)
Percent of total electricity production:
20.7% (2021)
Percent of total energy produced:
3.6% (2021)
Number of nuclear reactors permanently shut down:
4
Coal:
production:
447.332 million metric tons (2020 est.)
consumption:
266.038 million metric tons (2020 est.)
exports:
224.324 million metric tons (2020 est.)
imports:
24.027 million metric tons (2020 est.)
proven reserves:
162.166 billion metric tons (2019 est.)
Petroleum:
total petroleum production:
10,749,500 bbl/day (2021 est.)
refined petroleum consumption:
3.699 million bbl/day (2019 est.)
crude oil and lease condensate exports:
5.196 million bbl/day (2018 est.)
crude oil and lease condensate imports:
14,200 bbl/day (2018 est.)
crude oil estimated reserves:
80 billion barrels (2021 est.)
Refined petroleum products - production:
6.076 million bbl/day (2015 est.)
comparison ranking:
3
Refined petroleum products - exports:
2.671 million bbl/day (2015 est.)
comparison ranking:
2
Refined petroleum products - imports:
41,920 bbl/day (2015 est.)
comparison ranking:
88
Natural gas:
production:
701.544 billion cubic meters (2021 est.)
consumption:
460.612 billion cubic meters (2020 est.)
exports:
250.855 billion cubic meters (2021 est.)
imports:
16.112 billion cubic meters (2019 est.)
proven reserves:
47.805 trillion cubic meters (2021 est.)
Carbon dioxide emissions:
1,848,070,000 metric tonnes of CO2 (2019 est.)
from coal and metallurgical coke:
456.033 million metric tonnes of CO2 (2019 est.)
from petroleum and other liquids:
470.289 million metric tonnes of CO2 (2019 est.)
from consumed natural gas:
921.748 million metric tonnes of CO2 (2019 est.)
comparison ranking:
total emissions 4
Energy consumption per capita:
227.898 million Btu/person (2019 est.)
comparison ranking:
18','e488ffc12191fbd524b8a8512d2d08fdba7d4ec00b1b37c3e88df613665dd22f','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9c8c136f560fbc0732288527eeea64044c3901832961ab0d2a220ee3e69414b0',2025,'RW','Rwanda','energy',33,'Electricity access:
population without electricity:
5.8 million (2020)
electrification - total population:
48.7% (2021)
electrification - urban areas:
97.9% (2021)
electrification - rural areas:
38.1% (2021)
Electricity:
installed generating capacity:
265,000 kW (2020 est.)
consumption:
1,007,300,000 kWh (2019 est.)
exports:
4.5 million kWh (2019 est.)
imports:
93.96 million kWh (2019 est.)
transmission/distribution losses:
142 million kWh (2019 est.)
comparison rankings:
installed generating capacity 165; transmission/distribution losses 154; imports 109; exports 96; consumption 158
Electricity generation sources:
fossil fuels:
39% of total installed capacity (2020 est.)
solar:
6.5% of total installed capacity (2020 est.)
hydroelectricity:
53.9% of total installed capacity (2020 est.)
biomass and waste:
0.6% of total installed capacity (2020 est.)
Petroleum:
total petroleum production:
0 bbl/day (2021 est.)
refined petroleum consumption:
8,300 bbl/day (2019 est.)
Refined petroleum products - imports:
6,628 bbl/day (2015 est.)
comparison ranking:
162
Natural gas:
proven reserves:
56.634 billion cubic meters (2021 est.)
Carbon dioxide emissions:
1.189 million metric tonnes of CO2 (2019 est.)
from petroleum and other liquids:
1.189 million metric tonnes of CO2 (2019 est.)
comparison ranking:
total emissions 170
Energy consumption per capita:
1.704 million Btu/person (2019 est.)
comparison ranking:
189','f949bc2dc52bfc46f93f95dd4ec1cddc2954c7f167e0f338667124fd096c1502','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f52ca9052e6f460f0928a48c07260cb52ce7e7d2e3be46040a63d438cf50614d',2025,'KN','Saint Kitts and Nevis','energy',9,'Electricity access:
electrification - total population:
100% (2021)
Electricity:
installed generating capacity:
71,000 kW (2020 est.)
consumption:
175.34 million kWh (2019 est.)
exports:
0 kWh (2020 est.)
imports:
0 kWh (2020 est.)
transmission/distribution losses:
40 million kWh (2019 est.)
comparison rankings:
imports 208; exports 208; installed generating capacity 189; transmission/distribution losses 175; consumption 188
Electricity generation sources:
fossil fuels:
96.3% of total installed capacity (2020 est.)
wind:
3.7% of total installed capacity (2020 est.)
Petroleum:
total petroleum production:
0 bbl/day (2021 est.)
refined petroleum consumption:
1,800 bbl/day (2019 est.)
Refined petroleum products - imports:
1,743 bbl/day (2015 est.)
comparison ranking:
192
Carbon dioxide emissions:
268,000 metric tonnes of CO2 (2019 est.)
from petroleum and other liquids:
268,000 metric tonnes of CO2 (2019 est.)
comparison ranking:
total emissions 199
Energy consumption per capita:
71.96 million Btu/person (2019 est.)
comparison ranking:
82','cea1ac713876ad4d419be58930d4f40cfd3200cdb48fb375727b86a6fb498304','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b8036575d9c426838a1e178173f6054fccd4c2d5875578535a3255469a6b804e',2025,'LC','Saint Lucia','energy',20,'Electricity access:
electrification - total population:
100% (2021)
Electricity:
installed generating capacity:
92,000 kW (2020 est.)
consumption:
322.506 million kWh (2019 est.)
exports:
0 kWh (2020 est.)
imports:
0 kWh (2020 est.)
transmission/distribution losses:
27.568 million kWh (2019 est.)
comparison rankings:
imports 166; exports 155; installed generating capacity 184; transmission/distribution losses 179; consumption 179
Electricity generation sources:
fossil fuels:
99.1% of total installed capacity (2020 est.)
solar:
1% of total installed capacity (2020 est.)
Petroleum:
total petroleum production:
0 bbl/day (2021 est.)
refined petroleum consumption:
4,500 bbl/day (2019 est.)
Refined petroleum products - imports:
3,113 bbl/day (2015 est.)
comparison ranking:
184
Carbon dioxide emissions:
659,000 metric tonnes of CO2 (2019 est.)
from petroleum and other liquids:
659,000 metric tonnes of CO2 (2019 est.)
comparison ranking:
total emissions 184
Energy consumption per capita:
50.872 million Btu/person (2019 est.)
comparison ranking:
100','c0fab050ef148a590c1a5e848a9ffffd2366759ab9138442184e10f058777b1d','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2c738e0de15924a9034b2e3ed788a65b5d8bb879d3daa703dd5afa8211b0223a',2025,'LC','Saint Lucia','energy',31,'Electricity access:
electrification - total population:
100% (2021)','a05175d18d3663ad25c80fce0a2f9d8c3948b2fa4d1a94432259d1d8804cb39b','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a52c0b845e2e0dd7b688f793fcf5599434aa5c49ef897d52bc0f2a06edb0a807',2025,'PM','Saint Pierre and Miquelon','energy',42,'Electricity:
installed generating capacity:
26,000 kW (2020 est.)
consumption:
47.267 million kWh (2019 est.)
exports:
0 kWh (2020 est.)
imports:
0 kWh (2020 est.)
transmission/distribution losses:
1.733 million kWh (2019 est.)
comparison rankings:
imports 204; exports 204; installed generating capacity 204; transmission/distribution losses 205; consumption 202
Electricity generation sources:
fossil fuels:
100% of total installed capacity (2020 est.)
Petroleum:
total petroleum production:
0 bbl/day (2021 est.)
refined petroleum consumption:
600 bbl/day (2019 est.)
Refined petroleum products - imports:
650 bbl/day (2015 est.)
comparison ranking:
203
Carbon dioxide emissions:
84,000 metric tonnes of CO2 (2019 est.)
from petroleum and other liquids:
84,000 metric tonnes of CO2 (2019 est.)
comparison ranking:
total emissions 209
Energy consumption per capita:
0 Btu/person (2019 est.)
comparison ranking:
205','f84400229242841afb6f47939951fc67fd6bfb4ac8f6c81aedab6b33d209c171','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7bafd19a7501cc77e6054922798d25db5bd5b5a17140002d878c764d3a668eae',2025,'VC','Saint Vincent and the Grenadines','energy',53,'Electricity access:
electrification - total population:
100% (2021)
Electricity:
installed generating capacity:
49,000 kW (2020 est.)
consumption:
133.917 million kWh (2019 est.)
exports:
0 kWh (2020 est.)
imports:
0 kWh (2020 est.)
transmission/distribution losses:
11.083 million kWh (2019 est.)
comparison rankings:
imports 179; exports 171; installed generating capacity 192; transmission/distribution losses 194;
Electricity generation sources:
fossil fuels:
73.5% of total installed capacity (2020 est.)
solar:
0.7% of total installed capacity (2020 est.)
hydroelectricity:
25.8% of total installed capacity (2020 est.)
Petroleum:
total petroleum production:
0 bbl/day (2021 est.)
refined petroleum consumption:
1,500 bbl/day (2019 est.)
Refined petroleum products - imports:
1,621 bbl/day (2015 est.)
comparison ranking:
193
Carbon dioxide emissions:
202,000 metric tonnes of CO2 (2019 est.)
from petroleum and other liquids:
202,000 metric tonnes of CO2 (2019 est.)
comparison ranking:
total emissions 202
Energy consumption per capita:
27.821 million Btu/person (2019 est.)
comparison ranking:
123','530153af31525b17cd4b41a932e4872b868c55267f7110a82d084f76766c1364','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9771bde868ae3996a62144b5b789de555a4e05bac23525daded3c956cfb14d2c',2025,'WS','Samoa','energy',64,'Electricity access:
electrification - total population:
98.3% (2021)
electrification - urban areas:
100% (2021)
electrification - rural areas:
97.9% (2021)
Electricity:
installed generating capacity:
50,000 kW (2020 est.)
consumption:
120.13 million kWh (2019 est.)
exports:
0 kWh (2020 est.)
imports:
0 kWh (2020 est.)
transmission/distribution losses:
15 million kWh (2019 est.)
comparison rankings:
imports 182; exports 175; installed generating capacity 191; transmission/distribution losses 189; consumption 193
Electricity generation sources:
fossil fuels:
72.7% of total installed capacity (2020 est.)
wind:
0.1% of total installed capacity (2020 est.)
hydroelectricity:
27.2% of total installed capacity (2020 est.)
Petroleum:
total petroleum production:
0 bbl/day (2021 est.)
refined petroleum consumption:
2,500 bbl/day (2019 est.)
Refined petroleum products - imports:
2,363 bbl/day (2015 est.)
comparison ranking:
187
Carbon dioxide emissions:
355,000 metric tonnes of CO2 (2019 est.)
from petroleum and other liquids:
355,000 metric tonnes of CO2 (2019 est.)
comparison ranking:
total emissions 191
Energy consumption per capita:
27.111 million Btu/person (2019 est.)
comparison ranking:
125','4c1e2b6a33b7c97715ce5ecaeeb5d138f7e1073fe476bf3e68713c4ae71aa8d6','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f965fe8e90e238b79cb959ecb13aab815c2e4480f15392f0eae251e20c6c0969',2025,'SM','San Marino','energy',7,'Electricity access:
electrification - total population:
100% (2021)','a05175d18d3663ad25c80fce0a2f9d8c3948b2fa4d1a94432259d1d8804cb39b','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('52da45c72b45a87ec13f1d30605ffdafae953adb51aa003954cc31566f6303d9',2025,'ST','Sao Tome and Principe','energy',18,'Electricity access:
population without electricity:
(2020) less than 1 million
electrification - total population:
78.4% (2021)
electrification - urban areas:
80% (2021)
electrification - rural areas:
73.7% (2021)
Electricity:
installed generating capacity:
28,000 kW (2020 est.)
consumption:
78 million kWh (2019 est.)
exports:
0 kWh (2020 est.)
imports:
0 kWh (2020 est.)
transmission/distribution losses:
11.9 million kWh (2019 est.)
comparison rankings:
imports 125; exports 105; installed generating capacity 201; transmission/distribution losses 193; consumption 198
Electricity generation sources:
fossil fuels:
89.5% of total installed capacity (2020 est.)
hydroelectricity:
10.5% of total installed capacity (2020 est.)
Petroleum:
total petroleum production:
0 bbl/day (2021 est.)
refined petroleum consumption:
1,200 bbl/day (2019 est.)
Refined petroleum products - imports:
1,027 bbl/day (2015 est.)
comparison ranking:
201
Carbon dioxide emissions:
173,000 metric tonnes of CO2 (2019 est.)
from petroleum and other liquids:
173,000 metric tonnes of CO2 (2019 est.)
comparison ranking:
total emissions 206
Energy consumption per capita:
11.636 million Btu/person (2019 est.)
comparison ranking:
148','bdcac176887a24c4abf7e4448a0709260c6a96f9559d39a52a0b5c773fb8dd47','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d5aaa20d07a1a60ab74ffc3da2383ba71744fccd5d32587e56784b0d0a42e2e5',2025,'SA','Saudi Arabia','energy',29,'Electricity access:
electrification - total population:
100% (2021)
Electricity:
installed generating capacity:
76.785 million kW (2020 est.)
consumption:
331,381,500,000 kWh (2019 est.)
exports:
0 kWh (2020 est.)
imports:
0 kWh (2020 est.)
transmission/distribution losses:
31.055 billion kWh (2019 est.)
comparison rankings:
imports 193; exports 190; installed generating capacity 18; transmission/distribution losses 13; consumption 11
Electricity generation sources:
fossil fuels:
99.9% of total installed capacity (2020 est.)
solar:
0.2% of total installed capacity (2020 est.)
Coal:
production:
0 metric tons (2020 est.)
consumption:
73,000 metric tons (2020 est.)
exports:
0 metric tons (2020 est.)
imports:
73,000 metric tons (2020 est.)
proven reserves:
0 metric tons (2019 est.)
Petroleum:
total petroleum production:
10,815,700 bbl/day (2021 est.)
refined petroleum consumption:
3,182,300 bbl/day (2019 est.)
crude oil and lease condensate exports:
7,340,800 bbl/day (2018 est.)
crude oil and lease condensate imports:
0 bbl/day (2018 est.)
crude oil estimated reserves:
258.6 billion barrels (2021 est.)
Refined petroleum products - production:
2.476 million bbl/day (2015 est.)
comparison ranking:
8
Refined petroleum products - exports:
1.784 million bbl/day (2015 est.)
comparison ranking:
5
Refined petroleum products - imports:
609,600 bbl/day (2015 est.)
comparison ranking:
13
Natural gas:
production:
113,776,648,000 cubic meters (2020 est.)
consumption:
113,776,648,000 cubic meters (2020 est.)
exports:
0 cubic meters (2021 est.)
imports:
0 cubic meters (2021 est.)
proven reserves:
9,422,812,000,000 cubic meters (2021 est.)
Carbon dioxide emissions:
579.925 million metric tonnes of CO2 (2019 est.)
from coal and metallurgical coke:
300,000 metric tonnes of CO2 (2019 est.)
from petroleum and other liquids:
358.414 million metric tonnes of CO2 (2019 est.)
from consumed natural gas:
221.211 million metric tonnes of CO2 (2019 est.)
comparison ranking:
total emissions 10
Energy consumption per capita:
296.949 million Btu/person (2019 est.)
comparison ranking:
12','7e18dffeef9c6da7a5f055b02a07d316e82331393935fc8fb6345ce8f1532952','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b5376082a5bfa0a6aea6b9a03232b0a038baeb26cb02cf2a2e5f464f1d4bb641',2025,'SN','Senegal','energy',42,'Electricity access:
population without electricity:
5 million (2020)
electrification - total population:
67.9% (2021)
electrification - urban areas:
93.9% (2021)
electrification - rural areas:
43.4% (2021)
Electricity:
installed generating capacity:
1.312 million kW (2020 est.)
consumption:
4,735,980,000 kWh (2019 est.)
exports:
0 kWh (2019 est.)
imports:
324 million kWh (2019 est.)
transmission/distribution losses:
764 million kWh (2019 est.)
comparison rankings:
installed generating capacity 129; transmission/distribution losses 121; imports 94; exports 113; consumption 126
Electricity generation sources:
fossil fuels:
84.8% of total installed capacity (2020 est.)
solar:
6% of total installed capacity (2020 est.)
wind:
0.5% of total installed capacity (2020 est.)
hydroelectricity:
6.3% of total installed capacity (2020 est.)
biomass and waste:
2.4% of total installed capacity (2020 est.)
Coal:
production:
0 metric tons (2020 est.)
consumption:
894,000 metric tons (2020 est.)
exports:
0 metric tons (2020 est.)
imports:
894,000 metric tons (2020 est.)
proven reserves:
0 metric tons (2019 est.)
Petroleum:
total petroleum production:
0 bbl/day (2021 est.)
refined petroleum consumption:
57,500 bbl/day (2019 est.)
crude oil and lease condensate exports:
0 bbl/day (2018 est.)
crude oil and lease condensate imports:
20,500 bbl/day (2018 est.)
crude oil estimated reserves:
0 barrels (2021 est.)
Refined petroleum products - production:
17,590 bbl/day (2015 est.)
comparison ranking:
90
Refined petroleum products - exports:
4,063 bbl/day (2015 est.)
comparison ranking:
94
Refined petroleum products - imports:
32,050 bbl/day (2015 est.)
comparison ranking:
98
Natural gas:
production:
60.003 million cubic meters (2019 est.)
consumption:
60.003 million cubic meters (2019 est.)
Carbon dioxide emissions:
10.696 million metric tonnes of CO2 (2019 est.)
from coal and metallurgical coke:
1.955 million metric tonnes of CO2 (2019 est.)
from petroleum and other liquids:
8.64 million metric tonnes of CO2 (2019 est.)
from consumed natural gas:
101,000 metric tonnes of CO2 (2019 est.)
comparison ranking:
total emissions 103
Energy consumption per capita:
9.221 million Btu/person (2019 est.)
comparison ranking:
157','6de1401ceee9dc3986d4900111ea2e262df994d90a962749bed15e797edd7f54','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cd4d0b2ef237c3306777bf044378ab9fefa85d96ec9f029015b340f9f69ee1f0',2025,'RS','Serbia','energy',54,'Electricity access:
electrification - total population:
100% (2021)
Electricity:
installed generating capacity:
8.986 million kW (2020 est.)
consumption:
29,933,262,000 kWh (2019 est.)
exports:
5.943 billion kWh (2020 est.)
imports:
5.002 billion kWh (2020 est.)
transmission/distribution losses:
4.332 billion kWh (2019 est.)
comparison rankings:
imports 39; exports 33; installed generating capacity 69; transmission/distribution losses 51; consumption 65
Electricity generation sources:
fossil fuels:
69.2% of total installed capacity (2020 est.)
wind:
2.9% of total installed capacity (2020 est.)
hydroelectricity:
27.3% of total installed capacity (2020 est.)
biomass and waste:
0.5% of total installed capacity (2020 est.)
Coal:
production:
39.673 million metric tons (2020 est.)
consumption:
40.83 million metric tons (2020 est.)
exports:
72,000 metric tons (2020 est.)
imports:
987,000 metric tons (2020 est.)
proven reserves:
7.514 billion metric tons (2019 est.)
Petroleum:
total petroleum production:
15,200 bbl/day (2021 est.)
refined petroleum consumption:
79,200 bbl/day (2019 est.)
crude oil and lease condensate exports:
200 bbl/day (2018 est.)
crude oil and lease condensate imports:
53,800 bbl/day (2018 est.)
crude oil estimated reserves:
77.5 million barrels (2021 est.)
Refined petroleum products - production:
74,350 bbl/day (2015 est.)
comparison ranking:
71
Refined petroleum products - exports:
15,750 bbl/day (2015 est.)
comparison ranking:
73
Refined petroleum products - imports:
18,720 bbl/day (2015 est.)
comparison ranking:
126
Natural gas:
production:
455.787 million cubic meters (2019 est.)
consumption:
2,619,191,000 cubic meters (2019 est.)
exports:
0 cubic meters (2021 est.)
imports:
1,980,647,000 cubic meters (2019 est.)
proven reserves:
48.139 billion cubic meters (2021 est.)
Carbon dioxide emissions:
47.735 million metric tonnes of CO2 (2019 est.)
from coal and metallurgical coke:
32.686 million metric tonnes of CO2 (2019 est.)
from petroleum and other liquids:
10.17 million metric tonnes of CO2 (2019 est.)
from consumed natural gas:
4.878 million metric tonnes of CO2 (2019 est.)
comparison ranking:
total emissions 60
Energy consumption per capita:
98.195 million Btu/person (2019 est.)
comparison ranking:
62','a02731c9af43f996a142c42b6b56a90a5359b2768cecadda948dea8037719fc2','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('25267266d3044774400eb13cb38910e7ec478f54687990653536a7966f704691',2025,'SC','Seychelles','energy',7,'Electricity access:
electrification - total population:
100% (2021)
Electricity:
installed generating capacity:
157,000 kW (2020 est.)
consumption:
463.894 million kWh (2019 est.)
exports:
0 kWh (2020 est.)
imports:
0 kWh (2020 est.)
transmission/distribution losses:
30 million kWh (2019 est.)
comparison rankings:
imports 164; exports 152; installed generating capacity 177; transmission/distribution losses 178; consumption 173
Electricity generation sources:
fossil fuels:
99.1% of total installed capacity (2020 est.)
solar:
0.9% of total installed capacity (2020 est.)
Petroleum:
total petroleum production:
0 bbl/day (2021 est.)
refined petroleum consumption:
7,500 bbl/day (2019 est.)
Refined petroleum products - imports:
7,225 bbl/day (2015 est.)
comparison ranking:
155
Carbon dioxide emissions:
1.156 million metric tonnes of CO2 (2019 est.)
from petroleum and other liquids:
1.156 million metric tonnes of CO2 (2019 est.)
comparison ranking:
total emissions 171
Energy consumption per capita:
163.06 million Btu/person (2019 est.)
comparison ranking:
29','248c29570eacf81610e8b6a1e23df3016267d7a91da10e5d0ce8827f41ca817e','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9d45e6faecb4248aa9820f7c003d589e8bb57b87e68546d7a012aa75ceec6c71',2025,'SL','Sierra Leone','energy',18,'Electricity access:
population without electricity:
6 million (2020)
electrification - total population:
27.4% (2021)
electrification - urban areas:
56.9% (2021)
electrification - rural areas:
4.9% (2021)
Electricity:
installed generating capacity:
180,000 kW (2020 est.)
consumption:
130.708 million kWh (2019 est.)
exports:
0 kWh (2019 est.)
imports:
0 kWh (2020 est.)
transmission/distribution losses:
77 million kWh (2019 est.)
comparison rankings:
imports 165; installed generating capacity 174; transmission/distribution losses 164; exports 153; consumption 192
Electricity generation sources:
fossil fuels:
8.2% of total installed capacity (2020 est.)
solar:
2.9% of total installed capacity (2020 est.)
hydroelectricity:
87% of total installed capacity (2020 est.)
biomass and waste:
1.9% of total installed capacity (2020 est.)
Petroleum:
total petroleum production:
0 bbl/day (2021 est.)
refined petroleum consumption:
5,900 bbl/day (2019 est.)
Refined petroleum products - imports:
6,439 bbl/day (2015 est.)
comparison ranking:
164
Carbon dioxide emissions:
899,000 metric tonnes of CO2 (2019 est.)
from petroleum and other liquids:
899,000 metric tonnes of CO2 (2019 est.)
comparison ranking:
total emissions 175
Energy consumption per capita:
1.803 million Btu/person (2019 est.)
comparison ranking:
188','874e011939741ad16130a180de9567602d21f965b66b2de2f4d1bf195296ecd1','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e8c5f7a991b1fee93a3cd1250723a330e889f424e7eb071aa4878a678b8fa763',2025,'SG','Singapore','energy',29,'Electricity access:
electrification - total population:
100% (2021)
Electricity:
installed generating capacity:
12.24 million kW (2020 est.)
consumption:
50,742,380,000 kWh (2019 est.)
exports:
0 kWh (2019 est.)
imports:
0 kWh (2020 est.)
transmission/distribution losses:
571 million kWh (2019 est.)
comparison rankings:
imports 154; installed generating capacity 57; transmission/distribution losses 127; exports 142; consumption 49
Electricity generation sources:
fossil fuels:
96.5% of total installed capacity (2020 est.)
solar:
1.2% of total installed capacity (2020 est.)
biomass and waste:
2.3% of total installed capacity (2020 est.)
Coal:
production:
0 metric tons (2020 est.)
consumption:
423,000 metric tons (2020 est.)
exports:
1,000 metric tons (2020 est.)
imports:
424,000 metric tons (2020 est.)
proven reserves:
0 metric tons (2019 est.)
Petroleum:
total petroleum production:
0 bbl/day (2021 est.)
refined petroleum consumption:
1.448 million bbl/day (2019 est.)
crude oil and lease condensate exports:
13,000 bbl/day (2018 est.)
crude oil and lease condensate imports:
1,121,200 bbl/day (2018 est.)
crude oil estimated reserves:
0 barrels (2021 est.)
Refined petroleum products - production:
755,000 bbl/day (2015 est.)
comparison ranking:
24
Refined petroleum products - exports:
1.82 million bbl/day (2015 est.)
comparison ranking:
4
Refined petroleum products - imports:
2.335 million bbl/day (2015 est.)
comparison ranking:
1
Natural gas:
production:
0 cubic meters (2021 est.)
consumption:
13,396,282,000 cubic meters (2019 est.)
exports:
550.818 million cubic meters (2020 est.)
imports:
14,727,709,000 cubic meters (2020 est.)
proven reserves:
0 cubic meters (2021 est.)
Carbon dioxide emissions:
238.983 million metric tonnes of CO2 (2019 est.)
from coal and metallurgical coke:
1.588 million metric tonnes of CO2 (2019 est.)
from petroleum and other liquids:
211.115 million metric tonnes of CO2 (2019 est.)
from consumed natural gas:
26.28 million metric tonnes of CO2 (2019 est.)
comparison ranking:
total emissions 28
Energy consumption per capita:
639.951 million Btu/person (2019 est.)
comparison ranking:
2','6f80ef00c820e1725b12886e11bfb67d56844d9e989d36cf2346729861ab0413','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('14276bf51f364040e3ea0c24154f68791cdac4983cbe261945304c9a2115e5f1',2025,'SG','Singapore','energy',42,'Electricity access:
electrification - total population:
100% (2021)
Refined petroleum products - imports:
10,440 bbl/day (2015 est.)
comparison ranking:
148','8414a704c56c896dee6c3fb7ee084d90afe67b716a5b142e148942c5ffe6cdc7','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7016775ffb0dd6535b6ff7cb2b3cbbd52ea11359e20ca80f61839e716c7b727e',2025,'SK','Slovakia','energy',53,'Electricity access:
electrification - total population:
100% (2021)
Electricity:
installed generating capacity:
7.868 million kW (2020 est.)
consumption:
26.503 billion kWh (2020 est.)
exports:
12.97 billion kWh (2020 est.)
imports:
13.288 billion kWh (2020 est.)
transmission/distribution losses:
1.589 billion kWh (2020 est.)
comparison rankings:
transmission/distribution losses 96; imports 19; exports 17; consumption 67; installed generating capacity 73
Electricity generation sources:
fossil fuels:
19.7% of total installed capacity (2020 est.)
nuclear:
55.4% of total installed capacity (2020 est.)
solar:
2.4% of total installed capacity (2020 est.)
hydroelectricity:
16.8% of total installed capacity (2020 est.)
tide and wave:
0.2% of total installed capacity (2020 est.)
biomass and waste:
5.6% of total installed capacity (2020 est.)
Nuclear energy: Number of operational nuclear reactors:
5 (2023)
Number of nuclear reactors under construction:
1
Net capacity of operational nuclear reactors:
2.31GW (2023)
Percent of total electricity production:
52.3% (2021)
Percent of total energy produced:
70.4% (2021)
Number of nuclear reactors permanently shut down:
1
Coal:
production:
2.148 million metric tons (2020 est.)
consumption:
5.371 million metric tons (2020 est.)
exports:
1,000 metric tons (2020 est.)
imports:
3.111 million metric tons (2020 est.)
proven reserves:
135 million metric tons (2019 est.)
Petroleum:
total petroleum production:
3,800 bbl/day (2021 est.)
refined petroleum consumption:
85,200 bbl/day (2019 est.)
crude oil and lease condensate exports:
100 bbl/day (2018 est.)
crude oil and lease condensate imports:
109,800 bbl/day (2018 est.)
crude oil estimated reserves:
9 million barrels (2021 est.)
Refined petroleum products - production:
131,300 bbl/day (2017 est.)
comparison ranking:
64
Refined petroleum products - exports:
81,100 bbl/day (2017 est.)
comparison ranking:
46
Refined petroleum products - imports:
38,340 bbl/day (2017 est.)
comparison ranking:
91
Natural gas:
production:
62.495 million cubic meters (2020 est.)
consumption:
4.928 billion cubic meters (2020 est.)
exports:
0 cubic meters (2020 est.)
imports:
4.361 billion cubic meters (2020 est.)
proven reserves:
14.158 billion cubic meters (2021 est.)
Carbon dioxide emissions:
32.506 million metric tonnes of CO2 (2019 est.)
from coal and metallurgical coke:
11.521 million metric tonnes of CO2 (2019 est.)
from petroleum and other liquids:
11.747 million metric tonnes of CO2 (2019 est.)
from consumed natural gas:
9.238 million metric tonnes of CO2 (2019 est.)
comparison ranking:
total emissions 74
Energy consumption per capita:
129.665 million Btu/person (2019 est.)
comparison ranking:
42','b0a4e555868606dcf44d80a3ac4fb580f8eeab2d7adec740657078046bbb9b3a','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9cc448c2f248d5f15319712a12f2b82ad6f1cc9a81137093379814d98fd3f376',2025,'SI','Slovenia','energy',7,'Electricity access:
electrification - total population:
100% (2021)
Electricity:
installed generating capacity:
4.062 million kW (2020 est.)
consumption:
13.447 billion kWh (2020 est.)
exports:
9.123 billion kWh (2020 est.)
imports:
7.12 billion kWh (2020 est.)
transmission/distribution losses:
848 million kWh (2020 est.)
comparison rankings:
transmission/distribution losses 117; imports 33; exports 22; consumption 85; installed generating capacity 96
Electricity generation sources:
fossil fuels:
27.2% of total installed capacity (2020 est.)
nuclear:
36.8% of total installed capacity (2020 est.)
solar:
2.2% of total installed capacity (2020 est.)
hydroelectricity:
32% of total installed capacity (2020 est.)
biomass and waste:
1.7% of total installed capacity (2020 est.)
Nuclear energy: Number of operational nuclear reactors:
1 (2023)
Number of nuclear reactors under construction:
0
Net capacity of operational nuclear reactors:
0.69GW (2023)
Percent of total electricity production:
36.9% (2021)
Percent of total energy produced:
40.6% (2021)
Number of nuclear reactors permanently shut down:
0
Coal:
production:
3.175 million metric tons (2020 est.)
consumption:
3.502 million metric tons (2020 est.)
exports:
3,000 metric tons (2020 est.)
imports:
335,000 metric tons (2020 est.)
proven reserves:
371 million metric tons (2019 est.)
Petroleum:
total petroleum production:
0 bbl/day (2021 est.)
refined petroleum consumption:
54,900 bbl/day (2019 est.)
Refined petroleum products - exports:
29,350 bbl/day (2017 est.)
comparison ranking:
63
Refined petroleum products - imports:
93,060 bbl/day (2017 est.)
comparison ranking:
56
Natural gas:
production:
4.899 million cubic meters (2020 est.)
consumption:
904.439 million cubic meters (2020 est.)
exports:
0 cubic meters (2020 est.)
imports:
903.108 million cubic meters (2020 est.)
proven reserves:
0 cubic meters (2021 est.)
Carbon dioxide emissions:
13.553 million metric tonnes of CO2 (2019 est.)
from coal and metallurgical coke:
4.08 million metric tonnes of CO2 (2019 est.)
from petroleum and other liquids:
7.967 million metric tonnes of CO2 (2019 est.)
from consumed natural gas:
1.506 million metric tonnes of CO2 (2019 est.)
comparison ranking:
total emissions 99
Energy consumption per capita:
134.836 million Btu/person (2019 est.)
comparison ranking:
39','7668a9fac687297c4038882467f13f9dd85d8e7a7efb63ff45a79d5d0e095551','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8754ad278259225be648138dd15ec27e2fa4784c000519be5ecbc6d5326af578',2025,'SB','Solomon Islands','energy',18,'Electricity access:
electrification - total population:
76.3% (2021)
electrification - urban areas:
79.2% (2021)
electrification - rural areas:
75.3% (2021)
Electricity:
installed generating capacity:
40,000 kW (2020 est.)
consumption:
93.527 million kWh (2019 est.)
exports:
0 kWh (2020 est.)
imports:
0 kWh (2020 est.)
transmission/distribution losses:
14 million kWh (2019 est.)
comparison rankings:
imports 146; exports 133; installed generating capacity 196; transmission/distribution losses 190; consumption 196
Electricity generation sources:
fossil fuels:
94.8% of total installed capacity (2020 est.)
solar:
2.7% of total installed capacity (2020 est.)
biomass and waste:
2.6% of total installed capacity (2020 est.)
Petroleum:
total petroleum production:
0 bbl/day (2021 est.)
refined petroleum consumption:
2,200 bbl/day (2019 est.)
Refined petroleum products - imports:
1,577 bbl/day (2015 est.)
comparison ranking:
194
Carbon dioxide emissions:
333,000 metric tonnes of CO2 (2019 est.)
from petroleum and other liquids:
333,000 metric tonnes of CO2 (2019 est.)
comparison ranking:
total emissions 194
Energy consumption per capita:
6.955 million Btu/person (2019 est.)
comparison ranking:
165','d645acd8fe8fde7924cce2523dd9e9b49cbc933dba7dd1b4d04813e821977724','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ff3209cedc31dd22a8e065adf6f89caa73cd37b0f024b4e4fd039f010eb6a8f8',2025,'SO','Somalia','energy',29,'Electricity access:
population without electricity:
10 million (2020)
electrification - total population:
49.3% (2021)
electrification - urban areas:
70.6% (2021)
electrification - rural areas:
30.6% (2021)
Electricity:
installed generating capacity:
91,000 kW (2020 est.)
consumption:
311.2 million kWh (2019 est.)
exports:
0 kWh (2019 est.)
imports:
0 kWh (2019 est.)
transmission/distribution losses:
35 million kWh (2019 est.)
comparison rankings:
installed generating capacity 185; transmission/distribution losses 176; imports 124; exports 104; consumption 180
Electricity generation sources:
fossil fuels:
95.3% of total installed capacity (2020 est.)
solar:
3% of total installed capacity (2020 est.)
wind:
1.7% of total installed capacity (2020 est.)
Petroleum:
total petroleum production:
0 bbl/day (2021 est.)
refined petroleum consumption:
5,900 bbl/day (2019 est.)
Refined petroleum products - imports:
5,590 bbl/day (2015 est.)
comparison ranking:
167
Natural gas:
proven reserves:
5.663 billion cubic meters (2021 est.)
Carbon dioxide emissions:
882,000 metric tonnes of CO2 (2019 est.)
from petroleum and other liquids:
882,000 metric tonnes of CO2 (2019 est.)
comparison ranking:
total emissions 176
Energy consumption per capita:
802,000 Btu/person (2019 est.)
comparison ranking:
195','a41e7538f6443dac8d5b634350f826915b4ff59a83d758f03a82a73af8add133','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('13e0643534ed9a91596b257c4561bece514432ecb78aff694098409828e82e8c',2025,'ZA','South Africa','energy',41,'Electricity access:
population without electricity:
3 million (2020)
electrification - total population:
89.3% (2021)
electrification - urban areas:
87.3% (2021)
electrification - rural areas:
93.3% (2019)
Electricity:
installed generating capacity:
62.728 million kW (2020 est.)
consumption:
202,285,870,000 kWh (2019 est.)
exports:
14.482 billion kWh (2019 est.)
imports:
7.823 billion kWh (2019 est.)
transmission/distribution losses:
22.904 billion kWh (2019 est.)
comparison rankings:
installed generating capacity 21; transmission/distribution losses 20; imports 29; exports 14; consumption 21
Electricity generation sources:
fossil fuels:
87.9% of total installed capacity (2020 est.)
nuclear:
5.2% of total installed capacity (2020 est.)
solar:
1.6% of total installed capacity (2020 est.)
wind:
2.6% of total installed capacity (2020 est.)
hydroelectricity:
2.5% of total installed capacity (2020 est.)
biomass and waste:
0.2% of total installed capacity (2020 est.)
Nuclear energy: Number of operational nuclear reactors:
2 (2023)
Number of nuclear reactors under construction:
0
Net capacity of operational nuclear reactors:
1.85GW (2023)
Percent of total electricity production:
6% (2021)
Percent of total energy produced:
2.3% (2021)
Number of nuclear reactors permanently shut down:
0
Coal:
production:
248.388 million metric tons (2020 est.)
consumption:
170.308 million metric tons (2020 est.)
exports:
74.965 million metric tons (2020 est.)
imports:
2.054 million metric tons (2020 est.)
proven reserves:
9.893 billion metric tons (2019 est.)
Petroleum:
total petroleum production:
97,900 bbl/day (2021 est.)
refined petroleum consumption:
622,500 bbl/day (2019 est.)
crude oil and lease condensate exports:
9,000 bbl/day (2018 est.)
crude oil and lease condensate imports:
397,700 bbl/day (2018 est.)
crude oil estimated reserves:
15 million barrels (2021 est.)
Refined petroleum products - production:
487,100 bbl/day (2015 est.)
comparison ranking:
33
Refined petroleum products - exports:
105,600 bbl/day (2015 est.)
comparison ranking:
42
Refined petroleum products - imports:
195,200 bbl/day (2015 est.)
comparison ranking:
34
Natural gas:
production:
1,229,544,000 cubic meters (2019 est.)
consumption:
4,771,551,000 cubic meters (2019 est.)
exports:
0 cubic meters (2021 est.)
imports:
3,542,007,000 cubic meters (2019 est.)
proven reserves:
0 cubic meters (2021 est.)
Carbon dioxide emissions:
470.358 million metric tonnes of CO2 (2019 est.)
from coal and metallurgical coke:
387.835 million metric tonnes of CO2 (2019 est.)
from petroleum and other liquids:
73.163 million metric tonnes of CO2 (2019 est.)
from consumed natural gas:
9.361 million metric tonnes of CO2 (2019 est.)
comparison ranking:
total emissions 12
Energy consumption per capita:
98.474 million Btu/person (2019 est.)
comparison ranking:
61','13c8af383dba5e77bff1b149428fe4ea604680d6e024f8ea4221a03bd72172e6','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d5f250d04a257073e6872f2a6d76c60b66a0a246114a56c6778f6264dbd0ce65',2025,'SS','South Sudan','energy',8,'Electricity access:
population without electricity:
10 million (2020)
electrification - total population:
7.7% (2021)
electrification - urban areas:
15.5% (2021)
electrification - rural areas:
5.7% (2021)
Electricity:
installed generating capacity:
121,000 kW (2020 est.)
consumption:
531.66 million kWh (2019 est.)
exports:
0 kWh (2019 est.)
imports:
0 kWh (2019 est.)
transmission/distribution losses:
26 million kWh (2019 est.)
comparison rankings:
installed generating capacity 181; transmission/distribution losses 180; imports 123; exports 103; consumption 170
Electricity generation sources:
fossil fuels:
99.2% of total installed capacity (2020 est.)
solar:
0.8% of total installed capacity (2020 est.)
Petroleum:
total petroleum production:
157,100 bbl/day (2021 est.)
refined petroleum consumption:
12,900 bbl/day (2019 est.)
crude oil and lease condensate exports:
126,500 bbl/day (2018 est.)
Refined petroleum products - imports:
7,160 bbl/day (2015 est.)
comparison ranking:
157
Carbon dioxide emissions:
1.778 million metric tonnes of CO2 (2019 est.)
from petroleum and other liquids:
1.778 million metric tonnes of CO2 (2019 est.)
comparison ranking:
total emissions 161
Energy consumption per capita:
2.404 million Btu/person (2019 est.)
comparison ranking:
185','dbcfc9ee92e4b20de61d7ed6bf3067c8b645c82395dcdc484ef927af5fc828a2','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d2cc5586f5a5c3e2a5df5ef9de4f855bf8d51004612c4c6e7ee27a498c8625a2',2025,'ES','Spain','energy',25,'Electricity access:
electrification - total population:
100% (2021)
Electricity:
installed generating capacity:
115.837 million kW (2020 est.)
consumption:
233.267 billion kWh (2020 est.)
exports:
14.649 billion kWh (2020 est.)
imports:
17.928 billion kWh (2020 est.)
transmission/distribution losses:
23.999 billion kWh (2020 est.)
comparison rankings:
transmission/distribution losses 19; imports 15; exports 13; consumption 20; installed generating capacity 12
Electricity generation sources:
fossil fuels:
32.4% of total installed capacity (2020 est.)
nuclear:
21.9% of total installed capacity (2020 est.)
solar:
8.1% of total installed capacity (2020 est.)
wind:
22.1% of total installed capacity (2020 est.)
hydroelectricity:
13.1% of total installed capacity (2020 est.)
biomass and waste:
2.6% of total installed capacity (2020 est.)
Nuclear energy: Number of operational nuclear reactors:
7 (2023)
Number of nuclear reactors under construction:
0
Net capacity of operational nuclear reactors:
7.12GW (2023)
Percent of total electricity production:
21.38% (2016)
Percent of total energy produced:
33.2% (2021)
Number of nuclear reactors permanently shut down:
1
Coal:
production:
546,000 metric tons (2020 est.)
consumption:
4.918 million metric tons (2020 est.)
exports:
2.083 million metric tons (2020 est.)
imports:
4.857 million metric tons (2020 est.)
proven reserves:
1.187 billion metric tons (2019 est.)
Petroleum:
total petroleum production:
47,200 bbl/day (2021 est.)
refined petroleum consumption:
1.328 million bbl/day (2019 est.)
crude oil and lease condensate exports:
0 bbl/day (2018 est.)
crude oil and lease condensate imports:
1,364,700 bbl/day (2018 est.)
crude oil estimated reserves:
150 million barrels (2021 est.)
Refined petroleum products - production:
1.361 million bbl/day (2017 est.)
comparison ranking:
13
Refined petroleum products - exports:
562,400 bbl/day (2017 est.)
comparison ranking:
16
Refined petroleum products - imports:
464,800 bbl/day (2017 est.)
comparison ranking:
18
Natural gas:
production:
57.99 million cubic meters (2020 est.)
consumption:
32.03 billion cubic meters (2020 est.)
exports:
1.185 billion cubic meters (2020 est.)
imports:
32.489 billion cubic meters (2020 est.)
proven reserves:
2.549 billion cubic meters (2021 est.)
Carbon dioxide emissions:
280.624 million metric tonnes of CO2 (2019 est.)
from coal and metallurgical coke:
16.743 million metric tonnes of CO2 (2019 est.)
from petroleum and other liquids:
191.299 million metric tonnes of CO2 (2019 est.)
from consumed natural gas:
72.582 million metric tonnes of CO2 (2019 est.)
comparison ranking:
total emissions 22
Energy consumption per capita:
122.673 million Btu/person (2019 est.)
comparison ranking:
45','a305bf2e4c7f348df739c7adef38bf400b255a163933971a9503a63c2b9092af','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ab59ce3129b36caaa5d344bea82212b521f8b41379afbe5b9f5af5098474ef0c',2025,'LK','Sri Lanka','energy',46,'Electricity access:
electrification - total population:
100% (2021)
Electricity:
installed generating capacity:
4.527 million kW (2020 est.)
consumption:
13,991,420,000 kWh (2019 est.)
exports:
0 kWh (2020 est.)
imports:
0 kWh (2020 est.)
transmission/distribution losses:
1.337 billion kWh (2019 est.)
comparison rankings:
imports 212; exports 212; installed generating capacity 93; transmission/distribution losses 100; consumption 83
Electricity generation sources:
fossil fuels:
64% of total installed capacity (2020 est.)
solar:
0.7% of total installed capacity (2020 est.)
wind:
2.3% of total installed capacity (2020 est.)
hydroelectricity:
32.2% of total installed capacity (2020 est.)
Coal:
production:
0 metric tons (2020 est.)
consumption:
2.237 million metric tons (2020 est.)
exports:
0 metric tons (2020 est.)
imports:
2.586 million metric tons (2020 est.)
proven reserves:
0 metric tons (2019 est.)
Petroleum:
total petroleum production:
0 bbl/day (2021 est.)
refined petroleum consumption:
131,100 bbl/day (2019 est.)
crude oil and lease condensate exports:
0 bbl/day (2018 est.)
crude oil and lease condensate imports:
35,300 bbl/day (2018 est.)
crude oil estimated reserves:
0 barrels (2021 est.)
Refined petroleum products - production:
34,210 bbl/day (2017 est.)
comparison ranking:
84
Refined petroleum products - exports:
3,871 bbl/day (2015 est.)
comparison ranking:
96
Refined petroleum products - imports:
66,280 bbl/day (2015 est.)
comparison ranking:
70
Carbon dioxide emissions:
23.939 million metric tonnes of CO2 (2019 est.)
from coal and metallurgical coke:
5.546 million metric tonnes of CO2 (2019 est.)
from petroleum and other liquids:
18.393 million metric tonnes of CO2 (2019 est.)
comparison ranking:
total emissions 80
Energy consumption per capita:
17.268 million Btu/person (2019 est.)
comparison ranking:
138','c44bfbb6416b3666ea97a6e6c5f5badbc1939897aa4c0e28cdfb562a1194027f','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('471a5f2cff484526d467d0e47319003ea83dc3b827853ea2a0fc6fd37128721b',2025,'SD','Sudan','energy',59,'Electricity access:
population without electricity:
23 million (2020)
electrification - total population:
61.7% (2021)
electrification - urban areas:
84.2% (2021)
electrification - rural areas:
49.3% (2021)
Electricity:
installed generating capacity:
4.354 million kW (2020 est.)
consumption:
9,682,060,000 kWh (2019 est.)
exports:
0 kWh (2019 est.)
imports:
0 kWh (2019 est.)
transmission/distribution losses:
4.599 billion kWh (2019 est.)
comparison rankings:
installed generating capacity 94; transmission/distribution losses 49; imports 129; exports 108; consumption 103
Electricity generation sources:
fossil fuels:
43.5% of total installed capacity (2020 est.)
solar:
0.1% of total installed capacity (2020 est.)
hydroelectricity:
55.5% of total installed capacity (2020 est.)
biomass and waste:
0.9% of total installed capacity (2020 est.)
Petroleum:
total petroleum production:
66,900 bbl/day (2021 est.)
refined petroleum consumption:
137,700 bbl/day (2019 est.)
crude oil and lease condensate exports:
12,900 bbl/day (2018 est.)
crude oil and lease condensate imports:
9,000 bbl/day (2018 est.)
crude oil estimated reserves:
5 billion barrels (2021 est.)
Refined petroleum products - production:
94,830 bbl/day (2015 est.)
comparison ranking:
68
Refined petroleum products - exports:
8,541 bbl/day (2015 est.)
comparison ranking:
85
Refined petroleum products - imports:
24,340 bbl/day (2015 est.)
comparison ranking:
108
Natural gas:
proven reserves:
84.95 billion cubic meters (2021 est.)
Carbon dioxide emissions:
17.319 million metric tonnes of CO2 (2019 est.)
from petroleum and other liquids:
17.319 million metric tonnes of CO2 (2019 est.)
comparison ranking:
total emissions 91
Energy consumption per capita:
8.047 million Btu/person (2019 est.)
comparison ranking:
163','6197bbcd6793abc23e320b4f8b723f10aed6fd3af65184c7c91fca2df620b137','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7d759533170434af219e968fac6ccd6cdd0ecbc434b82788e34f5b8924ab369a',2025,'SR','Suriname','energy',7,'Electricity access:
electrification - total population:
98.8% (2021)
electrification - urban areas:
99.5% (2021)
electrification - rural areas:
97.4% (2021)
Electricity:
installed generating capacity:
542,000 kW (2020 est.)
consumption:
2,938,391,000 kWh (2019 est.)
exports:
0 kWh (2019 est.)
imports:
808 million kWh (2019 est.)
transmission/distribution losses:
234 million kWh (2019 est.)
comparison rankings:
installed generating capacity 150; transmission/distribution losses 146; imports 77; exports 183; consumption 141
Electricity generation sources:
fossil fuels:
40.5% of total installed capacity (2020 est.)
solar:
0.4% of total installed capacity (2020 est.)
hydroelectricity:
58.8% of total installed capacity (2020 est.)
biomass and waste:
0.3% of total installed capacity (2020 est.)
Petroleum:
total petroleum production:
14,800 bbl/day (2021 est.)
refined petroleum consumption:
15,800 bbl/day (2019 est.)
crude oil and lease condensate exports:
0 bbl/day (2018 est.)
crude oil and lease condensate imports:
200 bbl/day (2018 est.)
crude oil estimated reserves:
89 million barrels (2021 est.)
Refined petroleum products - production:
7,571 bbl/day (2015 est.)
comparison ranking:
101
Refined petroleum products - exports:
14,000 bbl/day (2015 est.)
comparison ranking:
74
Refined petroleum products - imports:
10,700 bbl/day (2015 est.)
comparison ranking:
145
Carbon dioxide emissions:
2.372 million metric tonnes of CO2 (2019 est.)
from petroleum and other liquids:
2.361 million metric tonnes of CO2 (2019 est.)
from consumed natural gas:
11,000 metric tonnes of CO2 (2019 est.)
comparison ranking:
total emissions 156
Energy consumption per capita:
82.356 million Btu/person (2019 est.)
comparison ranking:
71','773bf444b358e646494e740e94063e167a2afa53eb68baac21bd3db82d98f592','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e17813c372253e56fc1f01a7c10c6f1acf6436e2751428d5d33daf55aa4ccc35',2025,'SR','Suriname','energy',18,'Refined petroleum products - exports:
4,488 bbl/day (2012 est.)
comparison ranking:
93
Refined petroleum products - imports:
18,600 bbl/day (2012 est.)
comparison ranking:
127','ff1875481f7f758de2c1f921fc50e4b5bc4268ec14844651bd956f1c5a4dde78','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d74e979a0912626c8a0786f6cefc253c0f41617998ffbef6c0b9107f74ad5b50',2025,'SE','Sweden','energy',29,'Electricity access:
electrification - total population:
100% (2021)
Electricity:
installed generating capacity:
43.499 million kW (2020 est.)
consumption:
124.609 billion kWh (2020 est.)
exports:
36.824 billion kWh (2020 est.)
imports:
11.827 billion kWh (2020 est.)
transmission/distribution losses:
10.434 billion kWh (2020 est.)
comparison rankings:
transmission/distribution losses 30; imports 22; exports 4; consumption 27; installed generating capacity 28
Electricity generation sources:
fossil fuels:
1% of total installed capacity (2020 est.)
nuclear:
29.5% of total installed capacity (2020 est.)
solar:
0.7% of total installed capacity (2020 est.)
wind:
17.2% of total installed capacity (2020 est.)
hydroelectricity:
44.7% of total installed capacity (2020 est.)
biomass and waste:
6.9% of total installed capacity (2020 est.)
Nuclear energy: Number of operational nuclear reactors:
6 (2023)
Number of nuclear reactors under construction:
0
Net capacity of operational nuclear reactors:
6.94GW (2023)
Percent of total electricity production:
30.8% (2021)
Percent of total energy produced:
34% (2021)
Number of nuclear reactors permanently shut down:
4
Coal:
production:
1.07 million metric tons (2020 est.)
consumption:
3.328 million metric tons (2020 est.)
exports:
24,000 metric tons (2020 est.)
imports:
2.144 million metric tons (2020 est.)
proven reserves:
1 million metric tons (2019 est.)
Petroleum:
total petroleum production:
10,600 bbl/day (2021 est.)
refined petroleum consumption:
295,800 bbl/day (2019 est.)
crude oil and lease condensate exports:
0 bbl/day (2018 est.)
crude oil and lease condensate imports:
403,200 bbl/day (2018 est.)
crude oil estimated reserves:
0 barrels (2021 est.)
Refined petroleum products - production:
413,200 bbl/day (2017 est.)
comparison ranking:
36
Refined petroleum products - exports:
371,100 bbl/day (2017 est.)
comparison ranking:
23
Refined petroleum products - imports:
229,600 bbl/day (2017 est.)
comparison ranking:
29
Natural gas:
production:
0 cubic meters (2021 est.)
consumption:
1,275,785,000 cubic meters (2020 est.)
exports:
34.886 million cubic meters (2020 est.)
imports:
1,310,671,000 cubic meters (2020 est.)
proven reserves:
0 cubic meters (2021 est.)
Carbon dioxide emissions:
48.144 million metric tonnes of CO2 (2019 est.)
from coal and metallurgical coke:
7.38 million metric tonnes of CO2 (2019 est.)
from petroleum and other liquids:
38.406 million metric tonnes of CO2 (2019 est.)
from consumed natural gas:
2.359 million metric tonnes of CO2 (2019 est.)
comparison ranking:
total emissions 59
Energy consumption per capita:
210.882 million Btu/person (2019 est.)
comparison ranking:
21','7a700c1925dd36bc5d1b5f9e035e78e459dad9b1a7f2705cd6fc2ab80e4daaf8','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('454ebd412fa046f7798d30a8e449540a89e8f6fad6f7ea242d9858a9d0b77627',2025,'CH','Switzerland','energy',42,'Electricity access:
electrification - total population:
100% (2021)
Electricity:
installed generating capacity:
22.921 million kW (2020 est.)
consumption:
56.407 billion kWh (2020 est.)
exports:
32.549 billion kWh (2020 est.)
imports:
26.988 billion kWh (2020 est.)
transmission/distribution losses:
4.19 billion kWh (2020 est.)
comparison rankings:
transmission/distribution losses 53; imports 5; exports 5; consumption 48; installed generating capacity 41
Electricity generation sources:
fossil fuels:
0.8% of total installed capacity (2020 est.)
nuclear:
34.2% of total installed capacity (2020 est.)
solar:
3.8% of total installed capacity (2020 est.)
wind:
0.2% of total installed capacity (2020 est.)
hydroelectricity:
56.3% of total installed capacity (2020 est.)
biomass and waste:
4.7% of total installed capacity (2020 est.)
Nuclear energy: Number of operational nuclear reactors:
4 (2023)
Number of nuclear reactors under construction:
0
Net capacity of operational nuclear reactors:
2.97GW (2023)
Percent of total electricity production:
28.8% (2021)
Percent of total energy produced:
34.2% (2021)
Number of nuclear reactors permanently shut down:
1
Coal:
production:
0 metric tons (2020 est.)
consumption:
150,000 metric tons (2020 est.)
exports:
0 metric tons (2020 est.)
imports:
139,000 metric tons (2020 est.)
proven reserves:
0 metric tons (2019 est.)
Petroleum:
total petroleum production:
300 bbl/day (2021 est.)
refined petroleum consumption:
220,000 bbl/day (2019 est.)
crude oil and lease condensate exports:
0 bbl/day (2018 est.)
crude oil and lease condensate imports:
60,900 bbl/day (2018 est.)
crude oil estimated reserves:
0 barrels (2021 est.)
Refined petroleum products - production:
61,550 bbl/day (2017 est.)
comparison ranking:
79
Refined petroleum products - exports:
7,345 bbl/day (2017 est.)
comparison ranking:
88
Refined petroleum products - imports:
165,100 bbl/day (2017 est.)
comparison ranking:
39
Natural gas:
production:
0 cubic meters (2021 est.)
consumption:
3,616,169,000 cubic meters (2019 est.)
exports:
0 cubic meters (2021 est.)
imports:
3,577,884,000 cubic meters (2019 est.)
proven reserves:
0 cubic meters (2021 est.)
Carbon dioxide emissions:
38.739 million metric tonnes of CO2 (2019 est.)
from coal and metallurgical coke:
319,000 metric tonnes of CO2 (2019 est.)
from petroleum and other liquids:
31.494 million metric tonnes of CO2 (2019 est.)
from consumed natural gas:
6.926 million metric tonnes of CO2 (2019 est.)
comparison ranking:
total emissions 66
Energy consumption per capita:
137.918 million Btu/person (2019 est.)
comparison ranking:
38','411c5df9aafd99d79cd79047e9e08ba286f71ca4b7752c75c29e30502d039f9b','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('131c6482cac9e1250db2efaf1f34d92cbd6d29d7bf932f3c71f5a28650ced85c',2025,'CH','Switzerland','energy',55,'Electricity access:
population without electricity:
(2020) 2 million
electrification - total population:
88.8% (2021)
electrification - urban areas:
100% (2021)
electrification - rural areas:
74.5% (2021)
Electricity:
installed generating capacity:
10.082 million kW (2020 est.)
consumption:
13,071,080,000 kWh (2019 est.)
exports:
347 million kWh (2019 est.)
imports:
0 kWh (2019 est.)
transmission/distribution losses:
3.687 billion kWh (2019 est.)
comparison rankings:
installed generating capacity 65; transmission/distribution losses 57; imports 150; exports 80; consumption 88
Electricity generation sources:
fossil fuels:
95.1% of total installed capacity (2020 est.)
hydroelectricity:
4.8% of total installed capacity (2020 est.)
biomass and waste:
0.2% of total installed capacity (2020 est.)
Coal:
production:
0 metric tons (2020 est.)
consumption:
38,000 metric tons (2020 est.)
exports:
0 metric tons (2020 est.)
imports:
38,000 metric tons (2020 est.)
proven reserves:
0 metric tons (2019 est.)
Petroleum:
total petroleum production:
80,800 bbl/day (2021 est.)
refined petroleum consumption:
137,900 bbl/day (2019 est.)
crude oil and lease condensate exports:
0 bbl/day (2018 est.)
crude oil and lease condensate imports:
129,100 bbl/day (2018 est.)
crude oil estimated reserves:
2.5 billion barrels (2021 est.)
Refined petroleum products - production:
111,600 bbl/day (2015 est.)
comparison ranking:
66
Refined petroleum products - exports:
12,520 bbl/day (2015 est.)
comparison ranking:
79
Refined petroleum products - imports:
38,080 bbl/day (2015 est.)
comparison ranking:
92
Natural gas:
production:
3,531,077,000 cubic meters (2019 est.)
consumption:
3,531,077,000 cubic meters (2019 est.)
proven reserves:
240.693 billion cubic meters (2021 est.)
Carbon dioxide emissions:
26.893 million metric tonnes of CO2 (2019 est.)
from coal and metallurgical coke:
46,000 metric tonnes of CO2 (2019 est.)
from petroleum and other liquids:
19.92 million metric tonnes of CO2 (2019 est.)
from consumed natural gas:
6.927 million metric tonnes of CO2 (2019 est.)
comparison ranking:
total emissions 76
Energy consumption per capita:
24.567 million Btu/person (2019 est.)
comparison ranking:
130','c03795f06090d43fc5417064d96714bf2a535eaa3ecb9b8d6ea57f4162ce44cc','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('15e12f97ea159399c89331dc450b336a19bd1c7dc0d65b8348160d1f3d2b0ca4',2025,'TJ','Tajikistan','energy',9,'Electricity access:
electrification - total population:
99.5% (2021)
electrification - urban areas:
98.9% (2021)
electrification - rural areas:
99.8% (2021)
Electricity:
installed generating capacity:
7.114 million kW (2020 est.)
consumption:
15.071 billion kWh (2019 est.)
exports:
3.175 billion kWh (2019 est.)
imports:
281 million kWh (2019 est.)
transmission/distribution losses:
2.429 billion kWh (2019 est.)
comparison rankings:
installed generating capacity 78; transmission/distribution losses 79; imports 96; exports 43; consumption 82
Electricity generation sources:
fossil fuels:
8.7% of total installed capacity (2020 est.)
hydroelectricity:
91.3% of total installed capacity (2020 est.)
Coal:
production:
2.103 million metric tons (2020 est.)
consumption:
2.16 million metric tons (2020 est.)
exports:
0 metric tons (2020 est.)
imports:
57,000 metric tons (2020 est.)
proven reserves:
375 million metric tons (2019 est.)
Petroleum:
total petroleum production:
300 bbl/day (2021 est.)
refined petroleum consumption:
26,200 bbl/day (2019 est.)
crude oil and lease condensate exports:
0 bbl/day (2018 est.)
crude oil and lease condensate imports:
900 bbl/day (2018 est.)
crude oil estimated reserves:
12 million barrels (2021 est.)
Refined petroleum products - production:
172 bbl/day (2015 est.)
comparison ranking:
108
Refined petroleum products - exports:
0 bbl/day (2015 est.)
comparison ranking:
151
Refined petroleum products - imports:
22,460 bbl/day (2015 est.)
comparison ranking:
114
Natural gas:
production:
18.208 million cubic meters (2019 est.)
consumption:
157.611 million cubic meters (2019 est.)
exports:
0 cubic meters (2021 est.)
imports:
139.375 million cubic meters (2019 est.)
proven reserves:
5.663 billion cubic meters (2021 est.)
Carbon dioxide emissions:
7.643 million metric tonnes of CO2 (2019 est.)
from coal and metallurgical coke:
4.362 million metric tonnes of CO2 (2019 est.)
from petroleum and other liquids:
2.971 million metric tonnes of CO2 (2019 est.)
from consumed natural gas:
309,000 metric tonnes of CO2 (2019 est.)
comparison ranking:
total emissions 121
Energy consumption per capita:
27.651 million Btu/person (2019 est.)
comparison ranking:
124','5405c2991d779de6fde64568ad2e29f565f9172e78c2a6c6f4053f683c277c19','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5994c28621f2dcc99fab72d1ea1481be5dc1f38232807f0e3991b769a2189767',2025,'TJ','Tajikistan','energy',21,'Electricity access:
population without electricity:
(2020) 37 million
electrification - total population:
42.7% (2021)
electrification - urban areas:
77.3% (2021)
electrification - rural areas:
23.3% (2021)
Electricity:
installed generating capacity:
1.623 million kW (2020 est.)
consumption:
6,522,440,000 kWh (2019 est.)
exports:
0 kWh (2019 est.)
imports:
113 million kWh (2019 est.)
transmission/distribution losses:
974 million kWh (2019 est.)
comparison rankings:
installed generating capacity 125; transmission/distribution losses 113; imports 106; exports 158; consumption 113
Electricity generation sources:
fossil fuels:
65% of total installed capacity (2020 est.)
solar:
1.3% of total installed capacity (2020 est.)
hydroelectricity:
32.8% of total installed capacity (2020 est.)
biomass and waste:
1% of total installed capacity (2020 est.)
Coal:
production:
712,000 metric tons (2020 est.)
consumption:
577,000 metric tons (2020 est.)
exports:
126,000 metric tons (2020 est.)
imports:
0 metric tons (2020 est.)
proven reserves:
269 million metric tons (2019 est.)
Petroleum:
total petroleum production:
0 bbl/day (2021 est.)
refined petroleum consumption:
52,800 bbl/day (2019 est.)
Refined petroleum products - imports:
67,830 bbl/day (2015 est.)
comparison ranking:
69
Natural gas:
production:
1,378,773,000 cubic meters (2019 est.)
consumption:
1,378,773,000 cubic meters (2019 est.)
exports:
0 cubic meters (2021 est.)
imports:
0 cubic meters (2021 est.)
proven reserves:
6.513 billion cubic meters (2021 est.)
Carbon dioxide emissions:
11.491 million metric tonnes of CO2 (2019 est.)
from coal and metallurgical coke:
1.32 million metric tonnes of CO2 (2019 est.)
from petroleum and other liquids:
7.466 million metric tonnes of CO2 (2019 est.)
from consumed natural gas:
2.705 million metric tonnes of CO2 (2019 est.)
comparison ranking:
total emissions 101
Energy consumption per capita:
3.334 million Btu/person (2019 est.)
comparison ranking:
178','f8d5ea9ee0ee57ab7b1acae85d21848cf30edb752eaa23ac29e5480edf482286','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a51d81c4d9cfd8ef72bc3a76ccd88a0963d0f3bee616efa002e5fcd3878c5b83',2025,'TH','Thailand','energy',33,'Electricity access:
electrification - total population:
100% (2021)
Electricity:
installed generating capacity:
53.13 million kW (2020 est.)
consumption:
190,569,262,000 kWh (2019 est.)
exports:
2,617,583,000 kWh (2020 est.)
imports:
29,550,571,000 kWh (2020 est.)
transmission/distribution losses:
13.286 billion kWh (2019 est.)
comparison rankings:
imports 4; exports 45; installed generating capacity 25; transmission/distribution losses 27; consumption 23
Electricity generation sources:
fossil fuels:
83.3% of total installed capacity (2020 est.)
solar:
2.8% of total installed capacity (2020 est.)
wind:
1.7% of total installed capacity (2020 est.)
hydroelectricity:
2.6% of total installed capacity (2020 est.)
biomass and waste:
9.6% of total installed capacity (2020 est.)
Coal:
production:
13.251 million metric tons (2020 est.)
consumption:
35.761 million metric tons (2020 est.)
exports:
63,000 metric tons (2020 est.)
imports:
23.899 million metric tons (2020 est.)
proven reserves:
1.063 billion metric tons (2019 est.)
Petroleum:
total petroleum production:
438,200 bbl/day (2021 est.)
refined petroleum consumption:
1,284,800 bbl/day (2019 est.)
crude oil and lease condensate exports:
28,600 bbl/day (2018 est.)
crude oil and lease condensate imports:
979,800 bbl/day (2018 est.)
crude oil estimated reserves:
252.8 million barrels (2021 est.)
Refined petroleum products - production:
1.328 million bbl/day (2015 est.)
comparison ranking:
14
Refined petroleum products - exports:
278,300 bbl/day (2015 est.)
comparison ranking:
29
Refined petroleum products - imports:
134,200 bbl/day (2015 est.)
comparison ranking:
44
Natural gas:
production:
38,420,517,000 cubic meters (2019 est.)
consumption:
54,802,466,000 cubic meters (2019 est.)
exports:
0 cubic meters (2021 est.)
imports:
14,944,842,000 cubic meters (2019 est.)
proven reserves:
138.243 billion cubic meters (2021 est.)
Carbon dioxide emissions:
305.273 million metric tonnes of CO2 (2019 est.)
from coal and metallurgical coke:
58.78 million metric tonnes of CO2 (2019 est.)
from petroleum and other liquids:
146.172 million metric tonnes of CO2 (2019 est.)
from consumed natural gas:
100.321 million metric tonnes of CO2 (2019 est.)
comparison ranking:
total emissions 20
Energy consumption per capita:
76.714 million Btu/person (2019 est.)
comparison ranking:
79','8eeeaa69c9b2c6f157c3c67f40b819409ec720914fa1dadf3cf8255eabfc0ba6','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0f767cae2d72e1eb9a9e54bef88e0fbb261127c30d8fe07ec87241ff01f650a2',2025,'TL','Timor-Leste','energy',7,'Electricity access:
electrification - total population:
100% (2021)
Electricity:
installed generating capacity:
284,000 kW (2020 est.)
consumption:
-103 million kWh (2019 est.)
exports:
0 kWh (2019 est.)
imports:
0 kWh (2019 est.)
transmission/distribution losses:
103 million kWh (2019 est.)
comparison rankings:
installed generating capacity 163; transmission/distribution losses 160; imports 132; exports 114; consumption 213
Electricity generation sources:
fossil fuels:
100% of total installed capacity (2020 est.)
Petroleum:
total petroleum production:
14,000 bbl/day (2021 est.)
refined petroleum consumption:
3,500 bbl/day (2019 est.)
crude oil and lease condensate exports:
32,900 bbl/day (2018 est.)
Refined petroleum products - imports:
3,481 bbl/day (2015 est.)
comparison ranking:
182
Natural gas:
production:
5,104,670,000 cubic meters (2019 est.)
consumption:
0 cubic meters (2021 est.)
exports:
5,104,670,000 cubic meters (2019 est.)
imports:
0 cubic meters (2021 est.)
proven reserves:
0 cubic meters (2021 est.)
Carbon dioxide emissions:
538,000 metric tonnes of CO2 (2019 est.)
from petroleum and other liquids:
538,000 metric tonnes of CO2 (2019 est.)
comparison ranking:
total emissions 189
Energy consumption per capita:
5.74 million Btu/person (2019 est.)
comparison ranking:
168','d28c746fb5010c1674ca9a0eacb9c6d52c8b036d02fa46a53be886af5c720de9','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4a8ba37ec87e9d7e0ec96b43b93b1283db3685a806827b2c571de45a260f8783',2025,'TG','Togo','energy',18,'Electricity access:
population without electricity:
(2020) 5 million
electrification - total population:
55.7% (2021)
electrification - urban areas:
96.3% (2021)
electrification - rural areas:
24.6% (2021)
Electricity:
installed generating capacity:
210,000 kW (2020 est.)
consumption:
1,180,140,000 kWh (2019 est.)
exports:
118 million kWh (2019 est.)
imports:
963 million kWh (2019 est.)
transmission/distribution losses:
210 million kWh (2019 est.)
comparison rankings:
installed generating capacity 169; transmission/distribution losses 147; imports 73; exports 90; consumption 155
Electricity generation sources:
fossil fuels:
82.2% of total installed capacity (2020 est.)
solar:
0.6% of total installed capacity (2020 est.)
hydroelectricity:
17.2% of total installed capacity (2020 est.)
Coal:
production:
0 metric tons (2020 est.)
consumption:
46,000 metric tons (2020 est.)
exports:
0 metric tons (2020 est.)
imports:
46,000 metric tons (2020 est.)
proven reserves:
0 metric tons (2019 est.)
Petroleum:
total petroleum production:
0 bbl/day (2021 est.)
refined petroleum consumption:
10,000 bbl/day (2019 est.)
Refined petroleum products - imports:
13,100 bbl/day (2015 est.)
comparison ranking:
142
Natural gas:
production:
0 cubic meters (2021 est.)
consumption:
0 cubic meters (2020 est.)
exports:
0 cubic meters (2021 est.)
imports:
44.797 million cubic meters (2019 est.)
proven reserves:
0 cubic meters (2021 est.)
Carbon dioxide emissions:
2.244 million metric tonnes of CO2 (2019 est.)
from coal and metallurgical coke:
706,000 metric tonnes of CO2 (2019 est.)
from petroleum and other liquids:
1.451 million metric tonnes of CO2 (2019 est.)
from consumed natural gas:
87,000 metric tonnes of CO2 (2019 est.)
comparison ranking:
total emissions 158
Energy consumption per capita:
4.113 million Btu/person (2019 est.)
comparison ranking:
174','50ecd5411e3588aa48548e6f5e2bc9032422be6a05444e1ba4da3559b968bd34','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('207b430a3c19b773abc1bbcaac58e86fc0b801b8a15670bdf28236feb3480e00',2025,'TO','Tonga','energy',40,'Electricity access:
electrification - total population:
100% (2021)
Electricity:
installed generating capacity:
26,000 kW (2020 est.)
consumption:
54.448 million kWh (2019 est.)
exports:
0 kWh (2019 est.)
imports:
0 kWh (2019 est.)
transmission/distribution losses:
5.9 million kWh (2019 est.)
comparison rankings:
installed generating capacity 203; transmission/distribution losses 201; imports 170; exports 162; consumption 201
Electricity generation sources:
fossil fuels:
100% of total installed capacity (2020 est.)
Petroleum:
total petroleum production:
0 bbl/day (2021 est.)
refined petroleum consumption:
1,200 bbl/day (2019 est.)
crude oil and lease condensate exports:
0 bbl/day (2018 est.)
crude oil and lease condensate imports:
0 bbl/day (2018 est.)
crude oil estimated reserves:
0 barrels (2021 est.)
Refined petroleum products - production:
0 bbl/day (2017 est.)
comparison ranking:
114
Refined petroleum products - exports:
0 bbl/day (2015 est.)
comparison ranking:
127
Refined petroleum products - imports:
910 bbl/day (2015 est.)
comparison ranking:
202
Carbon dioxide emissions:
171,000 metric tonnes of CO2 (2019 est.)
from petroleum and other liquids:
171,000 metric tonnes of CO2 (2019 est.)
comparison ranking:
total emissions 207
Energy consumption per capita:
22.841 million Btu/person (2019 est.)
comparison ranking:
133','243929222d30bfd2cc2bf61e9acda9eb1412ceb536bb3b5cb628ada83b8a959b','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7d843ac53e541bb8e79c989c6c12440e13c66be66d9689be7548ffe2eefb1bd6',2025,'TT','Trinidad and Tobago','energy',51,'Electricity access:
electrification - total population:
100% (2021)
Electricity:
installed generating capacity:
2.123 million kW (2020 est.)
consumption:
8,213,020,000 kWh (2019 est.)
exports:
0 kWh (2019 est.)
imports:
0 kWh (2019 est.)
transmission/distribution losses:
424 million kWh (2019 est.)
comparison rankings:
installed generating capacity 118; transmission/distribution losses 133; imports 186; exports 180; consumption 107
Electricity generation sources:
fossil fuels:
99.9% of total installed capacity (2020 est.)
solar:
0.1% of total installed capacity (2020 est.)
Coal:
production:
0 metric tons (2020 est.)
consumption:
1,000 metric tons (2020 est.)
exports:
0 metric tons (2020 est.)
imports:
1,000 metric tons (2020 est.)
proven reserves:
0 metric tons (2019 est.)
Petroleum:
total petroleum production:
81,000 bbl/day (2021 est.)
refined petroleum consumption:
35,500 bbl/day (2019 est.)
crude oil and lease condensate exports:
22,100 bbl/day (2018 est.)
crude oil and lease condensate imports:
64,700 bbl/day (2018 est.)
crude oil estimated reserves:
243 million barrels (2021 est.)
Refined petroleum products - production:
134,700 bbl/day (2015 est.)
comparison ranking:
63
Refined petroleum products - exports:
106,100 bbl/day (2015 est.)
comparison ranking:
40
Refined petroleum products - imports:
0 bbl/day (2015 est.)
comparison ranking:
211
Natural gas:
production:
30,886,691,000 cubic meters (2020 est.)
consumption:
16,247,415,000 cubic meters (2020 est.)
exports:
14,662,269,000 cubic meters (2020 est.)
imports:
0 cubic meters (2021 est.)
proven reserves:
298.063 billion cubic meters (2021 est.)
Carbon dioxide emissions:
39.652 million metric tonnes of CO2 (2019 est.)
from coal and metallurgical coke:
10,000 metric tonnes of CO2 (2019 est.)
from petroleum and other liquids:
4.631 million metric tonnes of CO2 (2019 est.)
from consumed natural gas:
35.011 million metric tonnes of CO2 (2019 est.)
comparison ranking:
total emissions 65','6d0a7fece9b7de22144e265f49614ba62dd36c82e1565a2597ad9b3edfe0ee57','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e2f1edd2d7f3e2d180b0aae132498d43f071233a215f04dd022179634da99510',2025,'TN','Tunisia','energy',7,'Electricity access:
population without electricity:
(2020) less than 1 million
electrification - total population:
99.9% (2020)
electrification - urban areas:
100% (2021)
electrification - rural areas:
99.6% (2021)
Electricity:
installed generating capacity:
5.777 million kW (2020 est.)
consumption:
16,737,180,000 kWh (2019 est.)
exports:
631 million kWh (2019 est.)
imports:
472 million kWh (2019 est.)
transmission/distribution losses:
3.641 billion kWh (2019 est.)
comparison rankings:
installed generating capacity 81; transmission/distribution losses 58; imports 89; exports 71; consumption 77
Electricity generation sources:
fossil fuels:
95.9% of total installed capacity (2020 est.)
solar:
1.3% of total installed capacity (2020 est.)
wind:
2.6% of total installed capacity (2020 est.)
hydroelectricity:
0.3% of total installed capacity (2020 est.)
Coal:
production:
0 metric tons (2020 est.)
consumption:
5,000 metric tons (2020 est.)
exports:
0 metric tons (2020 est.)
imports:
5,000 metric tons (2020 est.)
proven reserves:
0 metric tons (2019 est.)
Petroleum:
total petroleum production:
42,500 bbl/day (2021 est.)
refined petroleum consumption:
107,700 bbl/day (2019 est.)
crude oil and lease condensate exports:
29,400 bbl/day (2018 est.)
crude oil and lease condensate imports:
10,200 bbl/day (2018 est.)
crude oil estimated reserves:
425 million barrels (2021 est.)
Refined petroleum products - production:
27,770 bbl/day (2015 est.)
comparison ranking:
85
Refined petroleum products - exports:
13,660 bbl/day (2015 est.)
comparison ranking:
75
Refined petroleum products - imports:
85,340 bbl/day (2015 est.)
comparison ranking:
58
Natural gas:
production:
1,025,974,000 cubic meters (2019 est.)
consumption:
5,279,951,000 cubic meters (2019 est.)
exports:
0 cubic meters (2021 est.)
imports:
4,305,994,000 cubic meters (2019 est.)
proven reserves:
65.129 billion cubic meters (2021 est.)
Carbon dioxide emissions:
23.692 million metric tonnes of CO2 (2019 est.)
from coal and metallurgical coke:
16,000 metric tonnes of CO2 (2019 est.)
from petroleum and other liquids:
12.982 million metric tonnes of CO2 (2019 est.)
from consumed natural gas:
10.694 million metric tonnes of CO2 (2019 est.)
comparison ranking:
total emissions 81
Energy consumption per capita:
35.62 million Btu/person (2019 est.)
comparison ranking:
114','2d37abe7fec18626292b7b70cdef513e0c10054a85d47e98604472fa6035c901','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6fed34f1e7b72f5de225363732a337583dc941fd8ed2fc551b0e2fe32831f14f',2025,'TN','Tunisia','energy',20,'Electricity access:
electrification - total population:
100% (2021)
Electricity:
installed generating capacity:
96.846 million kW (2020 est.)
consumption:
263.952 billion kWh (2020 est.)
exports:
2.484 billion kWh (2020 est.)
imports:
1.888 billion kWh (2020 est.)
transmission/distribution losses:
29.275 billion kWh (2020 est.)
comparison rankings:
transmission/distribution losses 14; imports 58; exports 47; consumption 17; installed generating capacity 14
Electricity generation sources:
fossil fuels:
56.2% of total installed capacity (2020 est.)
solar:
3.8% of total installed capacity (2020 est.)
wind:
8.4% of total installed capacity (2020 est.)
hydroelectricity:
26.3% of total installed capacity (2020 est.)
tide and wave:
0.4% of total installed capacity (2020 est.)
geothermal:
3.4% of total installed capacity (2020 est.)
biomass and waste:
1.5% of total installed capacity (2020 est.)
Nuclear energy: Number of operational nuclear reactors:
0
Number of nuclear reactors under construction:
4 (2023)
Net capacity of operational nuclear reactors:
0GW
Percent of total electricity production:
0%
Percent of total energy produced:
0%
Number of nuclear reactors permanently shut down:
0
Coal:
production:
78.871 million metric tons (2020 est.)
consumption:
108.271 million metric tons (2020 est.)
exports:
54,000 metric tons (2020 est.)
imports:
40.919 million metric tons (2020 est.)
proven reserves:
11.525 billion metric tons (2019 est.)
Petroleum:
total petroleum production:
70,300 bbl/day (2021 est.)
refined petroleum consumption:
987,300 bbl/day (2019 est.)
crude oil and lease condensate exports:
0 bbl/day (2018 est.)
crude oil and lease condensate imports:
423,500 bbl/day (2018 est.)
crude oil estimated reserves:
366 million barrels (2021 est.)
Refined petroleum products - production:
657,900 bbl/day (2017 est.)
comparison ranking:
27
Refined petroleum products - exports:
141,600 bbl/day (2017 est.)
comparison ranking:
37
Refined petroleum products - imports:
560,000 bbl/day (2017 est.)
comparison ranking:
16
Natural gas:
production:
469.464 million cubic meters (2019 est.)
consumption:
44,605,473,000 cubic meters (2019 est.)
exports:
759.372 million cubic meters (2019 est.)
imports:
45,091,248,000 cubic meters (2019 est.)
proven reserves:
3.794 billion cubic meters (2021 est.)
Carbon dioxide emissions:
391.792 million metric tonnes of CO2 (2019 est.)
from coal and metallurgical coke:
172.298 million metric tonnes of CO2 (2019 est.)
from petroleum and other liquids:
133.587 million metric tonnes of CO2 (2019 est.)
from consumed natural gas:
85.907 million metric tonnes of CO2 (2019 est.)
comparison ranking:
total emissions 17
Energy consumption per capita:
79.126 million Btu/person (2019 est.)
comparison ranking:
76','d49dc5caf9cb0c4a0964fdec2a29c1fd86c1b867c0377d707201034454b8a2d9','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8365ec87c9f400fd50a333939b9a5e2e80a95591e6b96d876ce9966ca8860b30',2025,'TM','Turkmenistan','energy',33,'Electricity access:
electrification - total population:
100% (2021)
Electricity:
installed generating capacity:
5.205 million kW (2020 est.)
consumption:
15.09 billion kWh (2019 est.)
exports:
3.2 billion kWh (2019 est.)
imports:
0 kWh (2019 est.)
transmission/distribution losses:
2.892 billion kWh (2019 est.)
comparison rankings:
installed generating capacity 86; transmission/distribution losses 67; imports 128; exports 42; consumption 81
Electricity generation sources:
fossil fuels:
100% of total installed capacity (2020 est.)
Petroleum:
total petroleum production:
235,300 bbl/day (2021 est.)
refined petroleum consumption:
153,400 bbl/day (2019 est.)
crude oil and lease condensate exports:
59,900 bbl/day (2018 est.)
crude oil and lease condensate imports:
0 bbl/day (2018 est.)
crude oil estimated reserves:
600 million barrels (2021 est.)
Refined petroleum products - production:
191,100 bbl/day (2015 est.)
comparison ranking:
52
Refined petroleum products - exports:
53,780 bbl/day (2015 est.)
comparison ranking:
53
Refined petroleum products - imports:
0 bbl/day (2015 est.)
comparison ranking:
213
Natural gas:
production:
83.623 billion cubic meters (2019 est.)
consumption:
45.399 billion cubic meters (2019 est.)
exports:
38.224 billion cubic meters (2019 est.)
imports:
0 cubic meters (2021 est.)
proven reserves:
11.327 trillion cubic meters (2021 est.)
Carbon dioxide emissions:
109.037 million metric tonnes of CO2 (2019 est.)
from petroleum and other liquids:
19.977 million metric tonnes of CO2 (2019 est.)
from consumed natural gas:
89.06 million metric tonnes of CO2 (2019 est.)
comparison ranking:
total emissions 39
Energy consumption per capita:
330.507 million Btu/person (2019 est.)
comparison ranking:
9','82ca38df4c7d41df24730ba15417dc2e1130fedc2c3381653b6882a0d53aa6e7','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bfd6fce4d0442e7c07b4243af762d2442c96436e5ec5f9514206239336503639',2025,'TC','Turks and Caicos Islands','energy',45,'Electricity access:
electrification - total population:
100% (2021)
Electricity:
installed generating capacity:
85,000 kW (2020 est.)
consumption:
231.618 million kWh (2019 est.)
exports:
0 kWh (2020 est.)
imports:
0 kWh (2020 est.)
transmission/distribution losses:
12.5 million kWh (2019 est.)
comparison rankings:
imports 131; exports 112; installed generating capacity 187; transmission/distribution losses 191; consumption 184
Electricity generation sources:
fossil fuels:
100% of total installed capacity (2020 est.)
Petroleum:
total petroleum production:
0 bbl/day (2021 est.)
refined petroleum consumption:
1,600 bbl/day (2019 est.)
Refined petroleum products - imports:
1,369 bbl/day (2015 est.)
comparison ranking:
196
Carbon dioxide emissions:
245,000 metric tonnes of CO2 (2019 est.)
from petroleum and other liquids:
245,000 metric tonnes of CO2 (2019 est.)
comparison ranking:
total emissions 200
Energy consumption per capita:
0 Btu/person (2019 est.)
comparison ranking:
199','d0a7648186f1d08edf20eb9bbbdfd9da9b400ff362ba2c820cfd58bce5bb4d23','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6476ef911b25c902c3eb92b9bea95a52170acc2b53bf3e92a5585d0bd0975db9',2025,'TV','Tuvalu','energy',56,'Electricity access:
electrification - total population:
99.6% (2021)
electrification - urban areas:
100% (2021)
electrification - rural areas:
99% (2021)
Energy consumption per capita:
0 Btu/person (2019 est.)
comparison ranking:
208','cd0ef7f4052f47e943eaa1aa973bb2c6a25d202562bd677f4a12566dbf58b6f1','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('038370ad3fec6596ceebaf6cefda700f0dd9aecd6f5b748b5c0fb1318216b106',2025,'UG','Uganda','energy',7,'Electricity access:
population without electricity:
(2020) 34 million
electrification - total population:
45.2% (2021)
electrification - urban areas:
72.2% (2021)
electrification - rural areas:
35.9% (2021)
Electricity:
installed generating capacity:
2.397 million kW (2020 est.)
consumption:
4,207,040,000 kWh (2019 est.)
exports:
299.2 million kWh (2019 est.)
imports:
104.2 million kWh (2019 est.)
transmission/distribution losses:
1.157 billion kWh (2019 est.)
comparison rankings:
installed generating capacity 115; transmission/distribution losses 108; imports 107; exports 81; consumption 131
Electricity generation sources:
fossil fuels:
1.3% of total installed capacity (2020 est.)
solar:
1.6% of total installed capacity (2020 est.)
hydroelectricity:
86.4% of total installed capacity (2020 est.)
biomass and waste:
10.8% of total installed capacity (2020 est.)
Petroleum:
total petroleum production:
0 bbl/day (2021 est.)
refined petroleum consumption:
40,900 bbl/day (2019 est.)
crude oil and lease condensate exports:
0 bbl/day (2018 est.)
crude oil and lease condensate imports:
0 bbl/day (2018 est.)
crude oil estimated reserves:
2.5 billion barrels (2021 est.)
Refined petroleum products - imports:
31,490 bbl/day (2015 est.)
comparison ranking:
99
proven reserves:
14.158 billion cubic meters (2021 est.)
Carbon dioxide emissions:
5.841 million metric tonnes of CO2 (2019 est.)
from petroleum and other liquids:
5.841 million metric tonnes of CO2 (2019 est.)
comparison ranking:
total emissions 133
Energy consumption per capita:
2.943 million Btu/person (2019 est.)
comparison ranking:
183','bc912e23635e49c278e8ca55b9fe9c6ff417869e5d133904ee4e84a35b00d51b','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9551ad76f692f092d6ef105d62eadb155be72563db80d77f4338817c23f0b694',2025,'UA','Ukraine','energy',20,'Electricity access:
electrification - total population:
100% (2021)
note:
pre-war numbers
Electricity:
installed generating capacity:
56.816 million kW (2020 est.)
consumption:
124,533,790,000 kWh (2019 est.)
exports:
5.139 billion kWh (2020 est.)
imports:
2.72 billion kWh (2020 est.)
transmission/distribution losses:
16.434 billion kWh (2019 est.)
comparison rankings:
imports 55; exports 36; installed generating capacity 24; transmission/distribution losses 25; consumption 28
Electricity generation sources:
fossil fuels:
37.6% of total installed capacity (2020 est.)
nuclear:
55.9% of total installed capacity (2020 est.)
solar:
1.2% of total installed capacity (2020 est.)
wind:
1.4% of total installed capacity (2020 est.)
hydroelectricity:
3.6% of total installed capacity (2020 est.)
biomass and waste:
0.3% of total installed capacity (2020 est.)
Nuclear energy: Number of operational nuclear reactors:
15 (2023)
Number of nuclear reactors under construction:
2
Net capacity of operational nuclear reactors:
13.11GW (2023)
Percent of total electricity production:
53.9% (2019)
Percent of total energy produced:
37% (2021)
note
- This information does not take into account the effects from the current conflict in Ukraine and should be considered the prewar status
Coal:
production:
23.908 million metric tons (2020 est.)
consumption:
41.181 million metric tons (2020 est.)
exports:
61,000 metric tons (2020 est.)
imports:
17.333 million metric tons (2020 est.)
proven reserves:
34.375 billion metric tons (2019 est.)
Petroleum:
total petroleum production:
57,700 bbl/day (2021 est.)
refined petroleum consumption:
248,100 bbl/day (2019 est.)
crude oil and lease condensate exports:
700 bbl/day (2018 est.)
crude oil and lease condensate imports:
6,500 bbl/day (2018 est.)
crude oil estimated reserves:
395 million barrels (2021 est.)
Refined petroleum products - production:
63,670 bbl/day (2017 est.)
comparison ranking:
77
Refined petroleum products - exports:
1,828 bbl/day (2015 est.)
comparison ranking:
105
Refined petroleum products - imports:
167,000 bbl/day (2015 est.)
comparison ranking:
37
Natural gas:
production:
19,511,040,000 cubic meters (2019 est.)
consumption:
26,413,486,000 cubic meters (2019 est.)
exports:
0 cubic meters (2021 est.)
imports:
10,740,619,000 cubic meters (2019 est.)
proven reserves:
1,104,355,000,000 cubic meters (2021 est.)
Carbon dioxide emissions:
185.686 million metric tonnes of CO2 (2019 est.)
from coal and metallurgical coke:
105.929 million metric tonnes of CO2 (2019 est.)
from petroleum and other liquids:
30.365 million metric tonnes of CO2 (2019 est.)
from consumed natural gas:
49.392 million metric tonnes of CO2 (2019 est.)
comparison ranking:
total emissions 33
Energy consumption per capita:
82.571 million Btu/person (2019 est.)
comparison ranking:
70','f3e77b52d4f7f388a44adf68e2f3da3ebb4359176ec3a93db14ca0dc0628ebba','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('558cd32d57733507a0073b27cd4a00c70bc68c739f0b6b396b1f2e9ec623a46e',2025,'AE','United Arab Emirates','energy',32,'Electricity access:
electrification - total population:
100% (2021)
Electricity:
installed generating capacity:
35.173 million kW (2020 est.)
consumption:
122.386 billion kWh (2019 est.)
exports:
257 million kWh (2019 est.)
imports:
245 million kWh (2019 est.)
transmission/distribution losses:
7.011 billion kWh (2019 est.)
comparison rankings:
installed generating capacity 32; transmission/distribution losses 38; imports 99; exports 84; consumption 30
Electricity generation sources:
fossil fuels:
95.7% of total installed capacity (2020 est.)
nuclear:
1.3% of total installed capacity (2020 est.)
solar:
3% of total installed capacity (2020 est.)
Nuclear energy: Number of operational nuclear reactors:
3 (2023)
Number of nuclear reactors under construction:
1
Net capacity of operational nuclear reactors:
4.01GW (2023)
Percent of total electricity production:
1.3% (2021)
Percent of total energy produced:
0.17% (2021)
Number of nuclear reactors permanently shut down:
0
Coal:
production:
0 metric tons (2020 est.)
consumption:
2.563 million metric tons (2020 est.)
exports:
2,000 metric tons (2020 est.)
imports:
2.565 million metric tons (2020 est.)
proven reserves:
0 metric tons (2019 est.)
Petroleum:
total petroleum production:
3,769,100 bbl/day (2021 est.)
refined petroleum consumption:
863,700 bbl/day (2019 est.)
crude oil and lease condensate exports:
2,427,200 bbl/day (2018 est.)
crude oil and lease condensate imports:
172,900 bbl/day (2018 est.)
crude oil estimated reserves:
97.8 billion barrels (2021 est.)
Refined petroleum products - production:
943,500 bbl/day (2017 est.)
comparison ranking:
19
Refined petroleum products - exports:
817,700 bbl/day (2015 est.)
comparison ranking:
10
Refined petroleum products - imports:
392,000 bbl/day (2015 est.)
comparison ranking:
23
Natural gas:
production:
62,889,064,000 cubic meters (2019 est.)
consumption:
73,750,936,000 cubic meters (2019 est.)
exports:
7,673,768,000 cubic meters (2019 est.)
imports:
20,041,951,000 cubic meters (2019 est.)
proven reserves:
6,090,887,000,000 cubic meters (2021 est.)
Carbon dioxide emissions:
276.236 million metric tonnes of CO2 (2019 est.)
from coal and metallurgical coke:
5.032 million metric tonnes of CO2 (2019 est.)
from petroleum and other liquids:
126.524 million metric tonnes of CO2 (2019 est.)
from consumed natural gas:
144.681 million metric tonnes of CO2 (2019 est.)
comparison ranking:
total emissions 24
Energy consumption per capita:
471.788 million Btu/person (2019 est.)
comparison ranking:
4','e290fe661f30aa799829239773d80a5668d44199fc44d0ddd68432eabd9b6a33','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b2cb36d022cc2d66063b827f0689bd6c479255e2d800f822f6916cc038dc6ca2',2025,'GB','United Kingdom','energy',44,'Electricity access:
electrification - total population:
100% (2021)
Electricity:
installed generating capacity:
113.153 million kW (2020 est.)
consumption:
289.688 billion kWh (2020 est.)
exports:
4.481 billion kWh (2020 est.)
imports:
22.391 billion kWh (2020 est.)
transmission/distribution losses:
27.746 billion kWh (2020 est.)
comparison rankings:
transmission/distribution losses 15; imports 8; exports 39; consumption 12; installed generating capacity 13
Electricity generation sources:
fossil fuels:
37.8% of total installed capacity (2020 est.)
nuclear:
15.2% of total installed capacity (2020 est.)
solar:
4.3% of total installed capacity (2020 est.)
wind:
25.2% of total installed capacity (2020 est.)
hydroelectricity:
2.6% of total installed capacity (2020 est.)
biomass and waste:
15% of total installed capacity (2020 est.)
Nuclear energy:
Number of operational nuclear reactors:
9 (2023)
Number of nuclear reactors under construction:
2
Net capacity of operational nuclear reactors:
5.88GW (2023)
Percent of total electricity production:
14.8% (2021)
Percent of total energy produced:
8% (2021)
Number of nuclear reactors permanently shut down:
8
Coal:
production:
2.892 million metric tons (2020 est.)
consumption:
9.401 million metric tons (2020 est.)
exports:
1.309 million metric tons (2020 est.)
imports:
5.537 million metric tons (2020 est.)
proven reserves:
26 million metric tons (2019 est.)
Petroleum:
total petroleum production:
890,400 bbl/day (2021 est.)
refined petroleum consumption:
1,578,100 bbl/day (2019 est.)
crude oil and lease condensate exports:
818,200 bbl/day (2018 est.)
crude oil and lease condensate imports:
891,700 bbl/day (2018 est.)
crude oil estimated reserves:
2.5 billion barrels (2021 est.)
Refined petroleum products - production:
1.29 million bbl/day (2017 est.)
comparison ranking:
16
Refined petroleum products - exports:
613,800 bbl/day (2017 est.)
comparison ranking:
14
Refined petroleum products - imports:
907,500 bbl/day (2017 est.)
comparison ranking:
7
Natural gas:
production:
32.48 billion cubic meters (2021 est.)
consumption:
75.7 billion cubic meters (2021 est.)
exports:
6.873 billion cubic meters (2021 est.)
imports:
51,050,178,000 cubic meters (2021 est.)
proven reserves:
180.661 billion cubic meters (2021 est.)
Carbon dioxide emissions:
398.084 million metric tonnes of CO2 (2019 est.)
from coal and metallurgical coke:
23.5 million metric tonnes of CO2 (2019 est.)
from petroleum and other liquids:
216.237 million metric tonnes of CO2 (2019 est.)
from consumed natural gas:
158.346 million metric tonnes of CO2 (2019 est.)
comparison ranking:
total emissions 16
Energy consumption per capita:
119.894 million Btu/person (2019 est.)
comparison ranking:
46','7eccbebbbb6707e241142d36f684b6003f5ed96a19b6f67d4a8768be8ff29c24','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f9131365761e013dc9d6c2d3b145f606c691dc381ece13416cdf8e357655c543',2025,'US','United States','energy',7,'Electricity access:
electrification - total population:
100% (2021)
Electricity:
installed generating capacity:
1,143,266,000 kW (2020 est.)
consumption:
3,897,886,551,000 kWh (2020 est.)
exports:
14,134,679,000 kWh (2020 est.)
imports:
61,448,863,000 kWh (2020 est.)
transmission/distribution losses:
198,085,480,000 kWh (2020 est.)
comparison rankings:
transmission/distribution losses 3; imports 1; exports 15; consumption 2; installed generating capacity 2
Electricity generation sources:
fossil fuels:
59.9% of total installed capacity (2020 est.)
nuclear:
19.5% of total installed capacity (2020 est.)
solar:
3.2% of total installed capacity (2020 est.)
wind:
8.3% of total installed capacity (2020 est.)
hydroelectricity:
7% of total installed capacity (2020 est.)
geothermal:
0.4% of total installed capacity (2020 est.)
biomass and waste:
1.7% of total installed capacity (2020 est.)
Nuclear energy: Number of operational nuclear reactors:
93 (2023)
Number of nuclear reactors under construction:
1
Net capacity of operational nuclear reactors:
95.83GW (2021)
Percent of total electricity production:
20% (2021)
Percent of total energy produced:
8.2% (2021)
Number of nuclear reactors permanently shut down:
20
note:
The US has the World’s largest nuclear energy program with 26% of the World’s net capacity of nuclear reactors
Coal:
production:
495.13 million metric tons (2020 est.)
consumption:
441.968 million metric tons (2020 est.)
exports:
63.276 million metric tons (2020 est.)
imports:
4.808 million metric tons (2020 est.)
proven reserves:
228.662 billion metric tons (2019 est.)
Petroleum:
total petroleum production:
17,924,200 bbl/day (2021 est.)
refined petroleum consumption:
20,542,900 bbl/day (2019 est.)
crude oil and lease condensate exports:
2,048,100 bbl/day (2018 est.)
crude oil and lease condensate imports:
7,768,500 bbl/day (2018 est.)
crude oil estimated reserves:
47.107 billion barrels (2020 est.)
Refined petroleum products - production:
20.3 million bbl/day (2017 est.)
comparison ranking:
1
Refined petroleum products - exports:
5.218 million bbl/day (2017 est.)
comparison ranking:
1
Refined petroleum products - imports:
2.175 million bbl/day (2017 est.)
comparison ranking:
2
Natural gas:
production:
967,144,362,000 cubic meters (2021 est.)
consumption:
857,542,658,000 cubic meters (2021 est.)
exports:
188,401,779,000 cubic meters (2021 est.)
imports:
79,512,470,000 cubic meters (2021 est.)
proven reserves:
13,178,780,000,000 cubic meters (2020 est.)
Carbon dioxide emissions:
5,144,361,000 metric tonnes of CO2 (2019 est.)
from coal and metallurgical coke:
1,077,520,000 metric tonnes of CO2 (2019 est.)
from petroleum and other liquids:
2,382,833,000 metric tonnes of CO2 (2019 est.)
from consumed natural gas:
1,684,008,000 metric tonnes of CO2 (2019 est.)
comparison ranking:
total emissions 2
Energy consumption per capita:
304.414 million Btu/person (2019 est.)
comparison ranking:
11','fe9ead1dd4efb163dc0f1d51bcc9c78ef6f5352eaaf54d14904b4bf283e5749b','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c92cf04b664ee7846ab419a2c32759d859801f1a482cc7c841a72015a7bde2f1',2025,'UY','Uruguay','energy',28,'Electricity access:
electrification - total population:
100% (2021)
Electricity:
installed generating capacity:
5.348 million kW (2020 est.)
consumption:
11,461,960,000 kWh (2019 est.)
exports:
1.148 billion kWh (2020 est.)
imports:
515 million kWh (2020 est.)
transmission/distribution losses:
1,329,700,000 kWh (2019 est.)
comparison rankings:
imports 86; exports 58; installed generating capacity 84; transmission/distribution losses 101; consumption 95
Electricity generation sources:
fossil fuels:
2% of total installed capacity (2020 est.)
solar:
3.6% of total installed capacity (2020 est.)
wind:
42.2% of total installed capacity (2020 est.)
hydroelectricity:
30.6% of total installed capacity (2020 est.)
biomass and waste:
21.6% of total installed capacity (2020 est.)
Petroleum:
total petroleum production:
400 bbl/day (2021 est.)
refined petroleum consumption:
50,200 bbl/day (2019 est.)
crude oil and lease condensate exports:
0 bbl/day (2018 est.)
crude oil and lease condensate imports:
41,500 bbl/day (2018 est.)
crude oil estimated reserves:
0 barrels (2021 est.)
Refined petroleum products - production:
42,220 bbl/day (2015 est.)
comparison ranking:
81
Refined petroleum products - exports:
0 bbl/day (2015 est.)
comparison ranking:
208
Refined petroleum products - imports:
9,591 bbl/day (2015 est.)
comparison ranking:
150
Natural gas:
production:
0 cubic meters (2021 est.)
consumption:
96.872 million cubic meters (2019 est.)
exports:
0 cubic meters (2021 est.)
imports:
96.872 million cubic meters (2019 est.)
proven reserves:
0 cubic meters (2021 est.)
Carbon dioxide emissions:
6.45 million metric tonnes of CO2 (2019 est.)
from petroleum and other liquids:
6.259 million metric tonnes of CO2 (2019 est.)
from consumed natural gas:
190,000 metric tonnes of CO2 (2019 est.)
comparison ranking:
total emissions 129
Energy consumption per capita:
66.909 million Btu/person (2019 est.)
comparison ranking:
85','594eba9c6be35065811ebbf8ca5a6c555ee5924ce3070f4db465f907d7625579','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('86f8d0cd0f106bf9e09421f572802c29a7fe25330c2a9e2b12aaea85033befc8',2025,'UZ','Uzbekistan','energy',40,'Electricity access:
electrification - total population:
99.9% (2020)
electrification - urban areas:
100% (2021)
electrification - rural areas:
99.7% (2021)
Electricity:
installed generating capacity:
16.042 million kW (2020 est.)
consumption:
57,605,687,000 kWh (2019 est.)
exports:
2.067 billion kWh (2019 est.)
imports:
3.379 billion kWh (2019 est.)
transmission/distribution losses:
3.858 billion kWh (2019 est.)
comparison rankings:
installed generating capacity 53; transmission/distribution losses 55; imports 48; exports 50; consumption 47
Electricity generation sources:
fossil fuels:
88.1% of total installed capacity (2020 est.)
hydroelectricity:
11.9% of total installed capacity (2020 est.)
Coal:
production:
3.98 million metric tons (2020 est.)
consumption:
5.668 million metric tons (2020 est.)
exports:
1,000 metric tons (2020 est.)
imports:
2.995 million metric tons (2020 est.)
proven reserves:
1.375 billion metric tons (2019 est.)
Petroleum:
total petroleum production:
5,200 bbl/day (2021 est.)
refined petroleum consumption:
98,200 bbl/day (2019 est.)
crude oil and lease condensate exports:
0 bbl/day (2018 est.)
crude oil and lease condensate imports:
24,000 bbl/day (2018 est.)
crude oil estimated reserves:
594 million barrels (2021 est.)
Refined petroleum products - production:
61,740 bbl/day (2015 est.)
comparison ranking:
78
Refined petroleum products - exports:
3,977 bbl/day (2015 est.)
comparison ranking:
95
Refined petroleum products - imports:
0 bbl/day (2015 est.)
comparison ranking:
214
Natural gas:
production:
46,968,227,000 cubic meters (2020 est.)
consumption:
43,882,007,000 cubic meters (2019 est.)
exports:
13,283,524,000 cubic meters (2019 est.)
imports:
0 cubic meters (2020 est.)
proven reserves:
1,840,592,000,000 cubic meters (2021 est.)
Carbon dioxide emissions:
102.965 million metric tonnes of CO2 (2019 est.)
from coal and metallurgical coke:
7.816 million metric tonnes of CO2 (2019 est.)
from petroleum and other liquids:
11.53 million metric tonnes of CO2 (2019 est.)
from consumed natural gas:
83.619 million metric tonnes of CO2 (2019 est.)
comparison ranking:
total emissions 42
Energy consumption per capita:
57.709 million Btu/person (2019 est.)
comparison ranking:
94','d6bf303b24d5db526d042d370435ba67c84dd1a37aba3545fc2012b7e577d6e4','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d5a7ed03cfcba00297d1bd3557cbf7bea1867d9640dda9a3a1fdb5641802b3ca',2025,'VU','Vanuatu','energy',7,'Electricity access:
electrification - total population:
70% (2021)
electrification - urban areas:
97% (2021)
electrification - rural areas:
60.7% (2021)
Electricity:
installed generating capacity:
35,000 kW (2020 est.)
consumption:
62.926 million kWh (2019 est.)
exports:
0 kWh (2020 est.)
imports:
0 kWh (2020 est.)
transmission/distribution losses:
5 million kWh (2019 est.)
comparison rankings:
imports 153; exports 141; installed generating capacity 198; transmission/distribution losses 202; consumption 200
Electricity generation sources:
fossil fuels:
84.5% of total installed capacity (2020 est.)
solar:
8.2% of total installed capacity (2020 est.)
wind:
7.4% of total installed capacity (2020 est.)
Petroleum:
total petroleum production:
0 bbl/day (2021 est.)
refined petroleum consumption:
1,500 bbl/day (2019 est.)
Refined petroleum products - imports:
1,073 bbl/day (2015 est.)
comparison ranking:
200
Carbon dioxide emissions:
225,000 metric tonnes of CO2 (2019 est.)
from petroleum and other liquids:
225,000 metric tonnes of CO2 (2019 est.)
comparison ranking:
total emissions 201
Energy consumption per capita:
10.878 million Btu/person (2019 est.)
comparison ranking:
153','d837e33cf71665acf3aaa082aef388de2af9bf0e51a2f61ef9e13a4fe5788255','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7d277495627d3aed4278dfc4838e4d6db7736ce70c24d5e4d984608da47b2a91',2025,'VU','Vanuatu','energy',18,'Electricity access:
population without electricity:
(2020) less than 1 million
electrification - total population:
99.9% (2021)
electrification - urban areas:
100% (2021)
electrification - rural areas:
99.8% (2021)
Electricity:
installed generating capacity:
32.956 million kW (2020 est.)
consumption:
78,082,020,000 kWh (2019 est.)
exports:
870 million kWh (2019 est.)
imports:
0 kWh (2019 est.)
transmission/distribution losses:
26.452 billion kWh (2019 est.)
comparison rankings:
installed generating capacity 34; transmission/distribution losses 16; imports 157; exports 66; consumption 38
Electricity generation sources:
fossil fuels:
30.5% of total installed capacity (2020 est.)
wind:
0.1% of total installed capacity (2020 est.)
hydroelectricity:
69.4% of total installed capacity (2020 est.)
Coal:
production:
396,000 metric tons (2020 est.)
consumption:
33,000 metric tons (2020 est.)
exports:
685,000 metric tons (2020 est.)
imports:
1,000 metric tons (2020 est.)
proven reserves:
731 million metric tons (2019 est.)
Petroleum:
total petroleum production:
604,800 bbl/day (2021 est.)
refined petroleum consumption:
470,600 bbl/day (2019 est.)
crude oil and lease condensate exports:
1,002,700 bbl/day (2018 est.)
crude oil and lease condensate imports:
0 bbl/day (2018 est.)
crude oil estimated reserves:
303.806 billion barrels (2021 est.)
Refined petroleum products - production:
926,300 bbl/day (2015 est.)
comparison ranking:
20
Refined petroleum products - exports:
325,800 bbl/day (2015 est.)
comparison ranking:
27
Refined petroleum products - imports:
20,640 bbl/day (2015 est.)
comparison ranking:
117
Natural gas:
production:
22,694,584,000 cubic meters (2019 est.)
consumption:
22,694,584,000 cubic meters (2019 est.)
exports:
0 cubic meters (2021 est.)
imports:
0 cubic meters (2020 est.)
proven reserves:
5,673,894,000,000 cubic meters (2021 est.)
Carbon dioxide emissions:
103.708 million metric tonnes of CO2 (2019 est.)
from coal and metallurgical coke:
108,000 metric tonnes of CO2 (2019 est.)
from petroleum and other liquids:
57.378 million metric tonnes of CO2 (2019 est.)
from consumed natural gas:
46.222 million metric tonnes of CO2 (2019 est.)
comparison ranking:
total emissions 41
Energy consumption per capita:
85.829 million Btu/person (2019 est.)
comparison ranking:
67','cfed9fc10c3ebe7001707c08a45ea95337ed4c585f62e2330ddf89f69a2e28cb','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('82d016acb6c13a021cbae532c403ca2da611533f925e0347a2cefb25f930d5bc',2025,'VU','Vanuatu','energy',31,'Electricity access:
electrification - total population:
100% (2021)
Electricity:
installed generating capacity:
65.283 million kW (2020 est.)
consumption:
199,846,440,000 kWh (2019 est.)
exports:
2.067 billion kWh (2019 est.)
imports:
3.316 billion kWh (2019 est.)
transmission/distribution losses:
15.479 billion kWh (2019 est.)
comparison rankings:
installed generating capacity 20; transmission/distribution losses 26; imports 49; exports 51; consumption 22
Electricity generation sources:
fossil fuels:
70.7% of total installed capacity (2020 est.)
solar:
2.4% of total installed capacity (2020 est.)
wind:
0.4% of total installed capacity (2020 est.)
hydroelectricity:
25.2% of total installed capacity (2020 est.)
biomass and waste:
1.4% of total installed capacity (2020 est.)
Coal:
production:
47.789 million metric tons (2020 est.)
consumption:
80.568 million metric tons (2020 est.)
exports:
902,000 metric tons (2020 est.)
imports:
55 million metric tons (2020 est.)
proven reserves:
3.36 billion metric tons (2019 est.)
Petroleum:
total petroleum production:
197,700 bbl/day (2021 est.)
refined petroleum consumption:
495,500 bbl/day (2019 est.)
crude oil and lease condensate exports:
66,900 bbl/day (2018 est.)
crude oil and lease condensate imports:
103,500 bbl/day (2018 est.)
crude oil estimated reserves:
4.4 billion barrels (2021 est.)
Refined petroleum products - production:
153,800 bbl/day (2015 est.)
comparison ranking:
58
Refined petroleum products - exports:
25,620 bbl/day (2015 est.)
comparison ranking:
67
Refined petroleum products - imports:
282,800 bbl/day (2015 est.)
comparison ranking:
25
Natural gas:
production:
8,438,095,000 cubic meters (2019 est.)
consumption:
8,438,095,000 cubic meters (2019 est.)
exports:
0 cubic meters (2021 est.)
imports:
0 cubic meters (2021 est.)
proven reserves:
699.425 billion cubic meters (2021 est.)
Carbon dioxide emissions:
249.929 million metric tonnes of CO2 (2019 est.)
from coal and metallurgical coke:
165.775 million metric tonnes of CO2 (2019 est.)
from petroleum and other liquids:
67.775 million metric tonnes of CO2 (2019 est.)
from consumed natural gas:
16.379 million metric tonnes of CO2 (2019 est.)
comparison ranking:
total emissions 27
Energy consumption per capita:
36.392 million Btu/person (2019 est.)
comparison ranking:
113','5a4097cd507f44deaef4dcddc3ea55b124843a21a5af02fefce5b09759c85824','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9858594764111678a8d5b6e893bae8e2a941d1fb922bdc411973dfdb8ae2b762',2025,'VU','Vanuatu','energy',43,'Electricity access:
electrification - total population:
100% (2021)
Electricity:
installed generating capacity:
321,000 kW (2020 est.)
consumption:
561.24 million kWh (2019 est.)
exports:
0 kWh (2020 est.)
imports:
0 kWh (2020 est.)
transmission/distribution losses:
51 million kWh (2019 est.)
comparison rankings:
imports 200; exports 199; installed generating capacity 159; transmission/distribution losses 171; consumption 168
Electricity generation sources:
fossil fuels:
98.9% of total installed capacity (2020 est.)
solar:
1.1% of total installed capacity (2020 est.)
Petroleum:
total petroleum production:
0 bbl/day (2021 est.)
refined petroleum consumption:
16,400 bbl/day (2019 est.)
Refined petroleum products - exports:
3,285 bbl/day (2015 est.)
comparison ranking:
97
Refined petroleum products - imports:
23,480 bbl/day (2015 est.)
comparison ranking:
112
Carbon dioxide emissions:
2.438 million metric tonnes of CO2 (2019 est.)
from petroleum and other liquids:
2.438 million metric tonnes of CO2 (2019 est.)
comparison ranking:
total emissions 154','48b7a8547ddf403c5a25912890d7d22d077277a669b4b61f39a7890b4d58e09c','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4dbcdf3f792a44569abd9d3ef9e18f16f626f6e021c7918bb463be12ce2d85f0',2025,'WF','Wallis and Futuna','energy',18,'Electricity access:
electrification - total population:
100% (2021)
note:
data for West Bank and Gaza Strip combined
Electricity:
installed generating capacity:
215,000 kW (2020 est.) Data represented includes both the Gaza Strip and West Bank
consumption:
5,702,816,000 kWh (2019 est.)
exports:
0 kWh (2019 est.)
imports:
5.9 billion kWh (2019 est.)
transmission/distribution losses:
847 million kWh (2019 est.)
comparison rankings:
installed generating capacity 167; transmission/distribution losses 118; imports 36; exports 147; consumption 121
Electricity generation sources:
fossil fuels:
100% of total installed capacity (2020 est.) Data represented includes both the Gaza Strip and West Bank
Petroleum:
total petroleum production:
0 bbl/day (2021 est.) Data represented includes both the Gaza Strip and West Bank
refined petroleum consumption:
24,600 bbl/day (2019 est.)
Refined petroleum products - exports:
19 bbl/day (2015 est.)
comparison ranking:
123
Refined petroleum products - imports:
22,740 bbl/day (2015 est.)
comparison ranking:
113
Carbon dioxide emissions:
3.341 million metric tonnes of CO2 (2019 est.) Data represented includes both the Gaza Strip and West Bank
from petroleum and other liquids:
3.341 million metric tonnes of CO2 (2019 est.)
comparison ranking:
total emissions 146
Energy consumption per capita:
13.604 million Btu/person (2019 est.) Data represented includes both the Gaza Strip and West Bank
comparison ranking:
144','09e82cf383a3886c493e6c628f90340d04533a4affb4147a7a9682c5b0ba716e','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('99a7be6d3045793ba6755a37547faa472f620a0e3dffb38a99c37f1faa5d859e',2025,'WF','Wallis and Futuna','energy',32,'Electricity access:
population without electricity:
(2020) 757 million
electrification - total population:
91.4% (2021)
electrification - urban areas:
97.6% (2021)
electrification - rural areas:
84.4% (2021)
note:
sub-Saharan Africa remains the region with the largest number of people without access to electricity with 77% of the World’s total
Electricity generation sources:
fossil fuels:
60.6% of total installed capacity (2020 est.)
nuclear:
10.3% of total installed capacity (2020 est.)
solar:
3.3% of total installed capacity (2020 est.)
wind:
6.2% of total installed capacity (2020 est.)
hydroelectricity:
17% of total installed capacity (2020 est.)
tide and wave:
0% of total installed capacity (2020 est.)
geothermal:
0.4% of total installed capacity (2020 est.)
biomass and waste:
2.4% of total installed capacity (2020 est.)
Nuclear energy: Number of operational nuclear reactors:
410 (2023)
Number of nuclear reactors under construction:
57
Net capacity of operational nuclear reactors:
368.61GW (2023)
Percent of total electricity production:
10% (2021)
Percent of total energy produced:
4.6% (2021)
note:
Three countries, the US, France, and China, have 57% of the World’s net capacity of operational nuclear reactors
Refined petroleum products - production:
88.4 million bbl/day (2014 est.)
Refined petroleum products - exports:
29.66 million bbl/day (2014 est.)
Refined petroleum products - imports:
28.62 million bbl/day (2014 est.)
Carbon dioxide emissions:
35,551,713,000 metric tonnes of CO2 (2019 est.)
from coal and metallurgical coke:
15,587,834,000 metric tonnes of CO2 (2019 est.)
from petroleum and other liquids:
12,195,793,000 metric tonnes of CO2 (2019 est.)
from consumed natural gas:
7,768,086,000 metric tonnes of CO2 (2019 est.)','58ed2c1bc58e068a3044130b468231999ce3976369f47b2f3fc3f188e0eda551','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1f203814c4bd86a420bd70c7559226e1312b56293027b5a08a969edcefcfd418',2025,'YE','Yemen','energy',7,'Electricity access:
population without electricity:
16 million (2020) 17 million
electrification - total population:
74.8% (2021)
electrification - urban areas:
93.1% (2021)
electrification - rural areas:
63.4% (2021)
Electricity:
installed generating capacity:
1.772 million kW (2020 est.)
consumption:
2,677,920,000 kWh (2019 est.)
exports:
0 kWh (2020 est.)
imports:
0 kWh (2020 est.)
transmission/distribution losses:
753 million kWh (2019 est.)
comparison rankings:
imports 199; exports 198; installed generating capacity 123; transmission/distribution losses 122; consumption 143
Electricity generation sources:
fossil fuels:
84.6% of total installed capacity (2020 est.)
solar:
15.4% of total installed capacity (2020 est.)
Coal:
production:
0 metric tons (2020 est.)
consumption:
22,000 metric tons (2020 est.)
exports:
0 metric tons (2020 est.)
imports:
22,000 metric tons (2020 est.)
proven reserves:
0 metric tons (2019 est.)
Petroleum:
total petroleum production:
70,100 bbl/day (2021 est.)
refined petroleum consumption:
75,700 bbl/day (2019 est.)
crude oil and lease condensate exports:
0 bbl/day (2018 est.)
crude oil and lease condensate imports:
0 bbl/day (2018 est.)
crude oil estimated reserves:
3 billion barrels (2021 est.)
Refined petroleum products - production:
20,180 bbl/day (2015 est.)
comparison ranking:
89
Refined petroleum products - exports:
12,670 bbl/day (2015 est.)
comparison ranking:
78
Refined petroleum products - imports:
75,940 bbl/day (2015 est.)
comparison ranking:
65
Natural gas:
production:
89.906 million cubic meters (2019 est.)
consumption:
89.906 million cubic meters (2019 est.)
proven reserves:
478.554 billion cubic meters (2021 est.)
Carbon dioxide emissions:
10.158 million metric tonnes of CO2 (2019 est.)
from coal and metallurgical coke:
79,000 metric tonnes of CO2 (2019 est.)
from petroleum and other liquids:
9.896 million metric tonnes of CO2 (2019 est.)
from consumed natural gas:
183,000 metric tonnes of CO2 (2019 est.)
comparison ranking:
total emissions 105
Energy consumption per capita:
5.453 million Btu/person (2019 est.)
comparison ranking:
169','e12205de0c2faf27aae7930d66b8a88d24a84769d2903fafee7b5c132aec1049','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b49a49da2924c0ffe96097889b4e53f4481a6025b5886f12ce3b871c930a4daa',2025,'ZM','Zambia','energy',7,'Electricity access:
population without electricity:
(2020) 12 million
electrification - total population:
46.6% (2021)
electrification - urban areas:
85.7% (2021)
electrification - rural areas:
14.5% (2021)
Electricity:
installed generating capacity:
3.065 million kW (2020 est.)
consumption:
13,409,685,000 kWh (2019 est.)
exports:
976 million kWh (2019 est.)
imports:
198 million kWh (2019 est.)
transmission/distribution losses:
1,811,480,000 kWh (2019 est.)
comparison rankings:
installed generating capacity 106; transmission/distribution losses 91; imports 103; exports 62; consumption 86
Electricity generation sources:
fossil fuels:
13% of total installed capacity (2020 est.)
solar:
0.9% of total installed capacity (2020 est.)
hydroelectricity:
85.5% of total installed capacity (2020 est.)
biomass and waste:
0.5% of total installed capacity (2020 est.)
Coal:
production:
1.116 million metric tons (2020 est.)
consumption:
1.176 million metric tons (2020 est.)
exports:
39,000 metric tons (2020 est.)
imports:
99,000 metric tons (2020 est.)
proven reserves:
45 million metric tons (2019 est.)
Petroleum:
total petroleum production:
0 bbl/day (2021 est.)
refined petroleum consumption:
25,300 bbl/day (2019 est.)
crude oil and lease condensate exports:
0 bbl/day (2018 est.)
crude oil and lease condensate imports:
12,400 bbl/day (2018 est.)
crude oil estimated reserves:
0 barrels (2021 est.)
Refined petroleum products - production:
13,120 bbl/day (2015 est.)
comparison ranking:
98
Refined petroleum products - exports:
371 bbl/day (2015 est.)
comparison ranking:
113
Refined petroleum products - imports:
10,150 bbl/day (2015 est.)
comparison ranking:
149
Carbon dioxide emissions:
6.798 million metric tonnes of CO2 (2019 est.)
from coal and metallurgical coke:
3.186 million metric tonnes of CO2 (2019 est.)
from petroleum and other liquids:
3.612 million metric tonnes of CO2 (2019 est.)
from consumed natural gas:
0 metric tonnes of CO2 (2019 est.)
comparison ranking:
total emissions 127
Energy consumption per capita:
11.595 million Btu/person (2019 est.)
comparison ranking:
149','4050131a8a48d4bbf2aa48ae74f9222f2ef52f290a5519e8c46f9cc5c63449c9','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3e9c7181c98d57bce06e70dd3caa12df5ef9b8e8967da8a125cec34538b4a681',2025,'ZW','Zimbabwe','energy',18,'Electricity access:
population without electricity:
(2020) 7 million
electrification - total population:
48.9% (2021)
electrification - urban areas:
85.3% (2021)
electrification - rural areas:
31.6% (2021)
Electricity:
installed generating capacity:
2.473 million kW (2020 est.)
consumption:
10,928,240,000 kWh (2019 est.)
exports:
504 million kWh (2019 est.)
imports:
1.612 billion kWh (2019 est.)
transmission/distribution losses:
1.491 billion kWh (2019 est.)
comparison rankings:
installed generating capacity 114; transmission/distribution losses 99; imports 63; exports 75; consumption 97
Electricity generation sources:
fossil fuels:
32.9% of total installed capacity (2020 est.)
solar:
0.1% of total installed capacity (2020 est.)
hydroelectricity:
65.3% of total installed capacity (2020 est.)
biomass and waste:
1.7% of total installed capacity (2020 est.)
Coal:
production:
3.888 million metric tons (2020 est.)
consumption:
3.579 million metric tons (2020 est.)
exports:
327,000 metric tons (2020 est.)
imports:
0 metric tons (2020 est.)
proven reserves:
502 million metric tons (2019 est.)
Petroleum:
total petroleum production:
800 bbl/day (2021 est.)
refined petroleum consumption:
27,300 bbl/day (2019 est.)
Refined petroleum products - imports:
26,400 bbl/day (2015 est.)
comparison ranking:
104
Carbon dioxide emissions:
7.902 million metric tonnes of CO2 (2019 est.)
from coal and metallurgical coke:
3.963 million metric tonnes of CO2 (2019 est.)
from petroleum and other liquids:
3.94 million metric tonnes of CO2 (2019 est.)
comparison ranking:
total emissions 115
Energy consumption per capita:
11.516 million Btu/person (2019 est.)
comparison ranking:
150','f172b5edd55188d7cb1fc502af29e74af860523cf9f003c89cd33e0e448c8d70','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);

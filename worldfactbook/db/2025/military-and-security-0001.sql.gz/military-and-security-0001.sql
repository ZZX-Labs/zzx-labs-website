SET NAMES utf8mb4;
CREATE TABLE IF NOT EXISTS worldfactbook_chunks (
  chunk_id CHAR(64) NOT NULL,
  edition_year SMALLINT UNSIGNED NOT NULL,
  entity_code VARCHAR(24) NOT NULL DEFAULT '',
  entity_name VARCHAR(160) NOT NULL DEFAULT '',
  category VARCHAR(96) NOT NULL,
  ordinal INT UNSIGNED NOT NULL,
  content MEDIUMTEXT NOT NULL,
  content_sha256 CHAR(64) NOT NULL,
  source_provider VARCHAR(64) NOT NULL,
  source_identifier VARCHAR(255) NOT NULL,
  source_format VARCHAR(32) NOT NULL,
  source_sha256 CHAR(64) NOT NULL,
  source_url TEXT NOT NULL,
  extractor VARCHAR(64) NOT NULL,
  PRIMARY KEY (chunk_id),
  KEY idx_wfb_year_category (edition_year, category),
  KEY idx_wfb_entity_year (entity_code, edition_year),
  KEY idx_wfb_source_sha (source_sha256)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4ec9b3536325b8d8afd124e3dd14455186ca37f200a15bef61d71b5cbac42e28',2025,'AF','Afghanistan','military-and-security',31,'Military branches: Afghan Armed Forces:
Afghan National Army (ANA, includes Afghan
Air Force (AAF)) (2011)
Military service age and obligation: 22 years
of age; inductees are contracted into service for a
4-year term (2005)
Manpower available for military service:
males age 16-49: 7,056,339
females age 16-49: 6,653,419 (2010 est.)
Manpower fit for military service: males age
16-49: 4,050,222
females age 16-49: 3,797,087 (2010 est.)
Manpower reaching militarily significant age
annually: male: 392,116
female: 370,295 (2010 est.)
Military expenditures: 10% of GDP (2012)
country comparison to the world: 2','3f12533ba43e23801d05b6b4086c5c25dabcc11ef1f7d99450b72ccd4a35dadb','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1b9041df786d49e02d2a6ddff6df3fde52b80d520c5816bd8914922828a45a93',2025,'AL','Albania','military-and-security',46,'Military branches: Land Forces Command, Air
Forces Command, Training and Doctrine Com-
mand (2012)
Military service age and obligation: 19 years
of age (2004)
Manpower available for military service:
males age 16-49: 731,111
females age 16-49: 780,216 (2010 est.)
Manpower fit for military service: males age
16-49: 622,379
females age 16-49: 660,715 (2010 est.)
Manpower reaching militarily significant age
annually: male: 31,986
female: 29,533 (2010 est.)
Military expenditures: 1.49% of GDP (2005 est.)
country comparison to the world: 104','35539c63e9c9d6f3a0cfb55d8f59976efe82a3d1a1b86317d6fa5ad585e7e2a8','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c5f69e99694aba4a7f21231c27fa07c41a97c7d5206d0ecce691e08504fc52dd',2025,'DZ','Algeria','military-and-security',53,'Military branches: People’s National Army
(Armee Nationale Populaire, ANP), Land Forces
(Forces Terrestres, FT), Navy of the Republic of
Algeria (Marine de la Republique Algerienne,
MRA), Air Force (Al-Quww at al-Jaw wiya al-
Jaza’eriya, QJJ), Territorial Air Defense Force
(2009)
Military service age and obligation: 19-30 years
of age for compulsory military service; -conscript
service obligation—18 months (6 months basic
training, 12 months civil projects) (2006)
Manpower available for military service:
males age 16-49: 10,273,129
females age 16-49: 10,114,002 (2010 est.)
Manpower fit for military service: males age
16-49: 8,622,897
females age 16-49: 8,626,222 (2010 est.)
Manpower reaching militarily significant age
annually: male: 342,895
female: 330,098 (2010 est.)
Military expenditures: 4.3% of GDP (2012)
, country comparison to the world: 23','02ead06b2b49018aca089e9c54458466ed2527b5b09d17c8738179558e720026','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ed52b17fe8aac03a6dc23b8cb3372f4d00e772a6e625145dfe060935827a7e26',2025,'AS','American Samoa','military-and-security',66,'Manpower fit for military service: niales age
16-49: 14,562
females age 16-49: 14,129 (2010 est.)
Manpower reaching militarily significant age
annually: male: 775
female: 762 (2010 est.)
Military—note: defense is the responsibility of
the US','7643017d2e14dac04a402be19db9608b59838bdada28e11d801d8819e5e67d34','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('253dea7d56d147200e3cb8143828d25bf8e4ff8931e305061cf66edd4b046765',2025,'AD','Andorra','military-and-security',74,'Military branches: no regular military forces,
Police Service of Andorra (2011)
Manpower available for military service:
males age 16-49: 22,390 (2010 est.)
Manpower fit for military service: males age
16-49: 17,977
females age 16-49: 17,069 (2010 est.)
Manpower reaching militarily significant age
annually: male: 397
female: 347 (2010 est.)
Military—note: defense is the responsibility of
France and Spain','b3d0970aef357ec306a99348fd29d85bab30308f7c28d58c87f76699d3312bf6','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b8070e78b1fbe9fc45d0601c8c7bf83899e1c25e1773598f7e63085d40209c9d',2025,'AO','Angola','military-and-security',79,'Military branches: Angolan Armed Forces
(Forcas Armadas Angolanas, FAA): Army, Navy
(Marinha de Guerra Angola, MGA), Angolan
National Air Force (Forca Aerea Nacional Ango-
` lana, FANA; under operational control of the
Army) (2012)
Military service age and obligation; 20-45
years of age for compulsory male and 18-45 years
for voluntary male military service (registration
at age 18 is mandatory); 20-45 years of age for
voluntary female service; conscript service obliga-
tion—2 years; Angolan citizenship required; the
Navy (MGA) is entirely staffed with volunteers
(2013)
Manpower available for military service:
males age 16-49: 3,062,438
females age 16-49: 2,964,262 (2010 est.)
Manpower fit for military service:
males age 16-49: 1,546,781
females age 16-49: 1,492,308 (2010 est.)
Manpower reaching militarily significant age
annually: male: 155,476
female: 152,054 (2010 est.)
Military expenditures: 3% of GDP (2012)
country comparison to the world: 40','100a8f099dae92f6f4f7ee879542a4fdaefa82b2a4ab832249d30d70b62d76ba','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b9d517cd39cc3d50510d0b579517ffa8a49c29478b76740a7986f027cf2c794a',2025,'AI','Anguilla','military-and-security',90,'Manpower avaHable for military service:
males age 16-49: 3,641 (2010 est.)
Manpower fit tor military service: males age
16-49: 3,009 ,
females age 16-49: 3,397 (2010 est.)
Manpower reaching militarily significant age
annually: male: 111
female: 113 (2010 est.)
Military—note: defense is the responsibility of ,
the UK','8e096acc2cbaab114c055c4946367991d4ad2e7e4e9cf9789aacc2146cd31940','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8daabdb8ee01e8ff32ae47432cdaa36a0d7ec76dd34af7ce0253e74b51d96b4c',2025,'AQ','Antarctica','military-and-security',98,'Military—note: the Antarctic Treaty prohib-
its any measures of a military nature, such as the
establishment of military bases and fortifications,
the carrying out of military maneuvers, or the
testing of any type of weapon; it permits the use
of military personnel or equipment for scientific
research or for any other peaceful purposes','40cd6768e1230ae49ab613ccf69ff4a385b3049a91cb468d03a5bd64e18106e3','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('22321968c84345871748a54d98875a24b348a646e6d34d260bc01078c1526b3c',2025,'AG','Antigua and Barbuda','military-and-security',107,'Military branches: Ministry of National Secu-
rity, Royal Antigua and Barbuda Defense Force
(includes Antigua and Barbuda Coast Guard)
(2012)
Military service age and obligation: years of
age for voluntary military service; no conscription
(2012)
Manpower available for military service:
males age 16-49; 21,141
females age 16-49; 24,056 (2010 est.)
Manpower fit for military service: males age
16-49: 17,676
females age 16-49: 19,960 (2010 est.)
Manpower reaching militarily significant age
annually: male: 806
female: 799 (2010 est.)
Military expenditures: 3.3% of GDP (2011)
country comparison to the world: 36','21501df54659952a90f50f0068298cda168c4878ad8fdf0046fe8328a9ee6338','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a4a16133e1d0e5969622faa6958b38ffa1798c788df62d00de8ef8ab9d5386a1',2025,'AR','Argentina','military-and-security',116,'Military branches: Argentine Army (Ejercito
Argentino), Navy of the Argentine Republic
(Armada Republica; includes naval aviation and
naval infantry), Argentine Air Force (Fuerza
Aerea Argentina, FAA) (2013)
Military service age and obligation: 18-24 years
of age for voluntary military service (18-21 requires
parental consent); no conscription (2001)
Manpower available for military service:
males age 16-49. 10,038,967
females age 16-49: 9,959,134 (2010 est.)
Manpower fit for military service: males age
16-49: 8,458,362
females age 16-49: 8,414,460 (2010 esr.)
Manpower reaching militarily significant age
annually: male: 339,503
female: 323,170 (2010 est.)
Military expenditures: 0.5% of GDP (2012)
country comparison to the world: 163
Military—note: the Argentine military is a
well-organized force constrained by the country''s
prolonged economic hardship; the country has
recently experienced a strong recovery, and the
military is implementing a modernization plan
aimed at making the ground forces lighter and
more responsive (2008)','28b395641f31b9c060f2225fd46277e49488e7fd9ebcf3f12560157400e20fe7','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d2080bdd90ae63499060638212ef3e3b683c488264e565e18d1d90007f0a84e6',2025,'AM','Armenia','military-and-security',123,'Military branches; Armenian Armed Forces:
Ground Forces, Air Force and Air Defense;
“Nagorno-Karabakh Republic”: Nagorno-Kara-
bakh Self-Defense Force (NKSDF) (2011)
Military service age and obligation: 18-27 years
of age for voluntary or compulsory military service;
2-year conscript service obligation (2010)
Manpower available for military service:
males age 16-49: 805,847
females age 16-49: 854,296 (2010 est.)
Manpower fit for military service: males age
16-49: 644,372
females age 16-49: 717,272 (2010 est.)
Manpower reaching militarily significant age
annually: male: 23,470
female: 21,417 (2010 est.)
Military expenditures: 2.8% of GDP (2010)
country comparison to the world: 46','67ad5532f0fc7c4b8ec22b2fc0920a9904fa86840f417067ab2810aff25a1c31','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cf2112f01df230bdada8f28e9084b6bc71f9f4f3b0215dde00a910cc8f32849f',2025,'AW','Aruba','military-and-security',133,'Military branches: no regular military forces
(2011)
Manpower available for military service:
males age 16-49: 24,891
females age 16-49: 26,202 (2010 est.)
Manpower fit for military service: males age
16-49: 20,527
females age 16-49: 21,493 (2010 est.)
Manpower reaching militarily significant age
annually: male: 767
female: 743 (2010 est:)
Mititary—note: defense is the responsibility of
the Netherlands; the Aruba security services focus
on organized crime and terrorism (2011)','89d536b5031faa546e378a6d90ee7c66acab06ed03d4b5c93ceed99cc33e76f7','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('621c5d45ab91f6546b8700837d371b55966187fddb40f3c907cf032893730f30',2025,'AU','Australia','military-and-security',144,'Military branches: Australian Defense Force
(ADF): Australian Army, Royal Australian Navy,
Royal Australian Air Force, Special Operations
Command (2006)
Military service age and obligation: 17 years
of age for voluntary military service (with paren-
tal consent); no conscription; women allow ed to
serve in most combat roles, except the Army spe-
cial forces (2013)
Manpower available for military service:
males age 16-49: 5,316,464
females age 16-49: 5,116,722 (2010 est.)
Manpower fit for military service: males age
16-49: 4,411,958
females age 16-49: 4,239,985 (2010 est.)
Manpower reaching militarily significant age
annually: male: 143,565
female: 135,800 (2010 est.)
Military expenditures: 3% of GDP (2012)
country comparison to the world: 40
Military—note: defense is the responsibility of
Australia; the territory has a five-person police force','846fbee47857bdd1592bddb293a102ca18dc02455407c3cc51888b502003ce9d','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9f7bed703e3eb1db730dd1c5b72004296d79d49c06447088231244c73ebd665c',2025,'AT','Austria','military-and-security',155,'Military branches: Land Forces (KdoLdSK), Air
Forces (KdoLuSK)
Military service age and obligation: registration
requirement at age 17; males under the age of 35
must complete basic military training (6 month
duration); males 17 to 50 years old in the militia or
inactive reserve are subject to compulsory military
service (2011)
Manpower available for military service:
males age 16-49: 1,941,110
females age 16-49: 1,910,434 (2010 est.)
Manpower fit for military service: males age
16-49: 1,579,862
females age 16-49: 1,554,130 (2010 est.)
Manpower reaching militarily significant age
annually: male: 48,108
female: 45,752 (2010 est.)
Military expenditures: 0.8% of GDP (2009)
country comparison to the world: 147
Military branches: Army of the Czech Republic
(Armada Ceske Republiky): Joint Forces Com-
mand (Spolocene Sily; includes Land Forces
(Pozemni Sily) and Air Forces (Vzdusne Sily)
note: the Ministry of Defense plans to abolish
the Joint Forces Command in 2012 and reestab-
lish, separate Land and Air Forces Commands
(2011)
Military service age and obligation: 18-28 years
of age for male and female voluntary military ser-
vice; no conscription (2012)
Manpower availabie for military service:
males age 16-49: 2,506,826
females age 16-49: 2,407,634 (2010 est.)
Manpower fit for military service: males age
16-49: 2,072,267
females age 16-49: 1,988,839 (2010 est.)
Manpower reaching militarily significant age
annually: male: 49,999.
female: 47,501 (2010 est.)
197
Military expenditures: 1% of GDP (2011 est.)
country comparison to the world: 125','c4f593fad462b65d3ecab6272c4ec1c211a2d7b397241e73ebe2fe89ae015fbf','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8b76cddcd74b76c3bd2cca194c01be91f95dd9f6aed59e63425ca3b9aa1d6a02',2025,'AZ','Azerbaijan','military-and-security',163,'Military branches: Army, Navy, Air, and Air
Defense Forces (2010)
Military service age and obligation: men between
18 and 35 are liable for military service; 18 years of
age for voluntary military service; length of military
service is 18 months and 12 months for university
graduates (2006)
Manpower available for military service:
males age 16-49: 2,354,249
females age 16-49: 2,334,632 (2010 est.)
Manpower fit for military service: males age
16-49: 1,773,993
females age 16-49: 1,964,012 (2010 est.)
Manpower reaching militarily significant age
annually: male: 76,923
female: 71,024 (2010 est.)
Military expenditures: 2.6% of GDP (2005 ést.)
country comparison to the world: 50
Military branches: Royal Bahamas Defense
Force: Land Force, Navy, Air Wing (2011)
Military service age and obligation: 17 1/2-25
years of age for voluntary male and female service;
no conscription (2012)
Manpower available for military service:
males age 16-49: 85,568 (2010 est.)
Manpower fit for military service: males age
16-49: 63,429
females age 16-49: 64,645 (2010 est.)
Manpower reaching militarily significant age
annually: male: 2,829
female: 2,750 (2010 est.)
Military expenditures: 0.6% of GDP (2011)
country comparison to the world: 156','f286c19e47a12d60bec21a13f3d93a773310b8fd43f6f627da28a033d5d8e759','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0644622043d979860c8bbe739968a688618057c8346ee866e927ebdf9a0bd04e',2025,'BH','Bahrain','military-and-security',174,'Military branches: Bahrain Defense Force
(BDF): Royal Bahraini Army (RBA), Royal
Bahraini Navy (RBN), Royal Bahraini Air Force
(RBAF), Royal Bahraini Air Defense Force
` (RBADF) (2013)
Military service age and obligation: 17 years of
age for voluntary military service; 15 years of age
for NCOs, technicians, and cadets; no conscrip-
tion (2010)
Manpower available for military service:
males age 16-49: 508,863
females age 16-49: 290,801 (2010 est.)
Manpower fit for military service: males age
16-49: 423,757
females age 16-49: 245,302 (2010 est.)
Manpower reaching militarily significant age
annually: male: 8,988
female: 8,117 (2010 est.)
Military expenditures: 4.5% of GDP (2006)
country comparison to the world: 20','b8003cfe6c453bcaf184965826df7a43614c731e0dec2da281d585385471cc1b','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e389b67bbc15df4707b8c514a5e6097130b9766cff68a0f49d5286418c970cdc',2025,'BD','Bangladesh','military-and-security',182,'Military branches: Bangladesh Defense Force:
Bangladesh Army (Sena Bahini), Banglatlesh
Navy (Noh Bahini, BN), Bangladesh Air Force
(Biman Bahini, BAF) (2010)
Military service age and obligation: 17-19 years
of age for voluntary enlisted military service; Bang-
ladeshi birth and 10th grade education required;
intial obligation 15 years (2012)
Manpower available for military service:
males age 16-49: 36,520,491 (2010 est.)
Manpower fit for military service: males age
16-49: 30,486,086
females age 16-49: 35,616,093 (2010 est.)
Manpower reaching militarily significant age
annually: male: 1,606,963
female: 1,689,442 (2010 est.)
Military expenditures: 1.4% of GDP (2012)
country comparison to the world: 106','70702ce2e4cc2b2be712165c2d1c5fb81b3f74928b4b1b975b6f5fb52907f11c','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d6ff412d3bbfb6ae5ebd62ecf2b304de5f6ca17027e79b298edce2320489906f',2025,'BB','Barbados','military-and-security',193,'Military branches: Royal Barbados Defense
Force: Troops Command, Barbados Coast Guard
(2011)
Military service age and obligation: 17 years of
age for voluntary military service, or earlier with
parental consent; no conscription (2013)
Manpower available for military service:
males age 16-49: 73,820
females age 16-49: 73,835 (2010 est.)
Manpower fit for military service: males age
16-49; 58,125
females age 16-49: 58,016 (2010 est.)
Manpower reaching militarily significant age
annually: male: 1,842
female: 1,849 (2010 est.)
Military expenditures: 0.8% of GDP (2011)
country comparison to the world: 146
Military—note: the Royal Barbados Defense
Force includes a land-based Troop Command and
a small Coast Guard; the primary role of the land
element is island defense against external aggres-
sion; the Command consists of a single, part-time
battalion with a small regular cadre deployed
throughout the island; the cadre increasingly
supports the police in patrolling the coastline for
smuggling and other illicit activities (2007)','b230826131b535a2cd8f2dd60ff27f2b0fa67302caf3e3711356593b22df9a04','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a595ccbd624293206ef3e93be178c7c991f78a1c38bf861091125656c9b21062',2025,'BY','Belarus','military-and-security',203,'Military branches: Belarus Armed Forces; Land
Force, Air and Air Defense Force, Special Opera-
tions Force (2013)
Military service age and obligation: 18-27 years
of age for compulsory military service; conscript
service obligation—12-18 months, depending on
academic qualifications (2010)
Manpower available for military service:
males age 16-49: 2,401,785
females age 16-49: 2,429,653 (2010 est.)
Manpower fit for military service: maks age
16-49: 1,693,626
females age 16-49: 2,012,401 (2010 P
Manpower reaching militarily significant age
annually: male; 51,855
female: 48,760 (2010 est.)
Military expenditures: 1.4% of GDP (2005
est.)
country comparison to the world: 107','82ffb68b5a02bf573f3824744714ac542ae53bd763bccf76be427bdd2fcd1863','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f06dacfececc347c8162b2bef3df906a6e1081d3b1282e57ecdf178b528063b3',2025,'BE','Belgium','military-and-security',213,'Military branches: Belgian Armed Forces: Land
Operations Command, Naval Operations Com-
mand, Air Operations Command (2012)
Military service age and obligation: 18 years of
age for male and female voluntary military service;
conscription abolished in 1994 (2012)
Manpower available for military service:
males age 16-49: 2,359,232
females age 16-49: 2,291,689 (2010 est.)
Manpower fit for military service: males age
16-49: 1,934,957
females age 16-49: 1,877,268 (2010 est.)
Manpower reaching militarily significant age
annually: male: 59,665
female: 57,142 (2010 est.)
Military expenditures: 1.3% of GDP (2005
est.)
country comparison to the world: 109
Military branches: Belize Defense Force (BDF):
Army, BDF Air Wing (includes Special Boat
Unit), BDF Volunteer Guard (2011)
Military service age and obligation: years
of age for voluntary military service; laws allow
for conscription only if volunteers are insuf-
ficient; conscription has never been imple-
mented; volunteers typically outnumber avail-
able positions by 3:1; initial service obligation
12 years (2012)
Manpower available for military service:
males age 16-49: 81,284
females age 16-49: 79,185 (2010 est.)
Manpower fit for military service: males age
16-49: 59,431
females age 16-49: 57,221 (2010 est.)
Manpower reaching militarily significant age
annually: male: 3,723
female: 3,584 (2010 est.)
Military expenditures: 1.2% of GDP (2012)
country comparison to the world: 117','b6e874cd3f75dd28d64834a9ba10465774f32383a58e48bfc118d6af3423ba5b','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ee3da7c2b1a09c7625a3b37365f2e101b4094d6c06dcbf1859e1715e0f509dcc',2025,'BJ','Benin','military-and-security',226,'Military branches: Benin Armed Forces {Forces
Armees Beninoises, FAB): Army (l’Arme de
Terre), Benin Navy (Forces Navales Beninois,
FNB), Benin Air Force (Force Aerienne du Benin,
FAB) (2013)
Military service age and obligation: 18-35
years of age for selective compulsory and volun-
tary military service; a higher education diploma
is required; both sexes are eligible for military ser-
vice; conscript tour of dury—18 months (2013)
Manpower available for military service:
males age 16-49: 2,095,373
females age 16-49: 2,038,351 (2010 est.)
Manpower fit for military service: males age
16-49; 1,385,065
females age 16-49: 1,400,045 (2010 est.)
Manpower reaching militarily significant age
annually: male: 108,496
female: 104,526 (2010 est.)
Military expenditures: 1.5% of GDP (2011)
country comparison to the world: 97','dd6952d71e50ab3895909d8ae5a3bd72e5fa833aa5ed96c1617b257338619ad5','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('064a96c7f2d47571a13b0299d5aa724579cedb5462930c0a15c80f0ac0e23234',2025,'BM','Bermuda','military-and-security',236,'Military branches: Bermuda Regiment (2012)
Military service age and obligation: 18-45 years
of age for voluntary male or female enlistment in
the Bermuda Regiment; males must register at age
18 and may be subject to conscription; term of
service is 38 months for volunteers or conscripts
(2012) l
Manpower available for military service:
males age 16-49: 15,081 (2010 est.)
Manpower fit for military service: males age
16-49: 12,323
females age 16-49: 12,174 (2010 est.)
Manpower reaching militarily significant age
annually: male: 433
female: 410 (2010 est.)
Military expenditures: 0.11% of GDP (2005
est.)
country comparison to the world: 169
Military—note: defense is the responsibility of
the UK','9fd3598ea1bda3abb924defdfcf4aca56df9bf76bf38bde251cdf1437693cc92','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3dbd0b44be0a87117ae39be243a2904bdae29704cd52cd2a4f9c0efa501a88a2',2025,'BT','Bhutan','military-and-security',248,'Military branches: Royal Bhutan Army
(includes Royal Bodyguard and Royal Bhutan
Police) (2009)
Military service age and obligation: 18 years
of age for voluntary military service; no conscrip-
tion; militia training is compulsory for males aged
20-25, over a 3-year period (2011)
Manpower available for military service:
males age 16-49: 202,407
females age 16-49: 180,349 (2010 est.)
Manpower fit for military service: males age
16-49: 157,664
females age 16-49: 144,861 (2010 est.)
Manpower reaching militarily significant age
annually: male: 7,363
female: 7,095 (2010 est.) .
Military expenditures: 1% of GDP (2005 est.)
country comparison to the world: 126','5aee8ea7901ecd9559ab7be5667bbf9931306d9d18b98b0968868d50a6bf890c','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ee21dd81c5cca2e0947951cb63b1933973616d047b5b2918ae20173841356675',2025,'PY','Paraguay','military-and-security',256,'Military branches: Bolivian Armed Forces:
Bolivian Army (Ejercito Boliviano, EB), Boliv-
ian Naval Force (Fuerza Naval Boliviana, FNB;
includes Marines), Bolivian Air Force (Fuerza
Aerea Boliviana, FAB) (2011)
Military service age and obligation: 18-49 years
of age for 12-month compulsory male and female
military service; Bolivian citizenship required; 17
years of age for voluntary service; when annual
number of volunteers falls short of goal, compul-
sory recruitment is effected, including conscription
of boys as young as 14; 15-19 years of age for volun-
„tary premilitary service, provides exemption from
further military service (2013)
Manpower available for military service: males
age 16-49: 2,472,490
females age 16-49; 2,535,768 (2010 est.)
Manpower fit for military service: males age
16-49: 1,762,260
females age 16-49: 2,013,281 (2010 est.)
Manpower reaching militarily significant age
annually: male: 108,334
female: 104,945 (2010 est.)
Military expenditures: 0.9% of GDP (2012)
country comparison to the world: 135
Military branches: Armed Forces Command
(Commando delas Fuerzas Militares): Army,
National Navy (Armada Nacional, includes
Marine Corps, Naval Aviation, and Coast Guard),
Paraguayan Air Force (Fuerza Aerea Paraguay,
FAP), Logistics Command, War Materiel Direc-
torate (2012) i
Military service age and obligation: 18 years of
age for compulsory and voluntary military service;
conscript service obligation is 12 months for Army,
24 months for Navy; volunteers for the Air Force
must be younger than 22 years of age with a sec-
ondary school diploma (2012)
Manpower available for military service:
males age 16-49. 1,678,335
females age 16-49: 1,675,352 (2010 est.)
Manpower fit for military service: males age
16-49: 1,409,859
females age 16-49: 1,433,037 (2010 est.) ,
Manpower reaching militarily significant age
annually: male: 73,367
female: 71,801 (2010 est.)
Military expenditures: 1.5% of GDP (2012)
country comparison to the world: 103','63607aeb6b19677ae3fab0525de1fd51df2c8328b29baf5708f52235c703a3e1','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3f59cf2e61cfe7d411dcda4ccdd616b05447ce19c62fe6d32811116ff6a62bbf',2025,'BA','Bosnia and Herzegovina','military-and-security',265,'Military branches: Armed Forces of Bosnia and
Herzegovina (AFBiH): Army of Bosnia and Her-
zegovina, Air and Air Defense Forces of Bosnia
and Herzegovina (Zrakoplovstvo i Protuzracna
Obrana, ZPO) (2013)
Military service age and obligation: 18 years of
age for voluntary military service; mandatory retire-
ment at age 35 or after 15 years of service (2013)
Manpower available for military service:
males age 16-49: 1,180,829
females age 16-49: 1,143,919 (2010 est.)
Manpower fit for military service: males age
16-49: 968,242
females age 16-49: 937,327 (2010 est.)
Manpower reaching militarily significant age
annually: male: 26,601. .
female: 24,879 (2010 est.)
Military expenditures: 1.4% of GDP (2005 est.)
country comparison to the world: 105','f9ce1d1cac8e77d9cfdc288d3af82489d93c8abfa63d384c65c09f2d4096ea29','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('72c56248258ba0d17c5d15a3c1b7c48e72e462399df6eed221886a4740e53ccc',2025,'BW','Botswana','military-and-security',276,'Military branches: Botswana Defense Force
(BDF): Ground Forces Command, Air Wing
THE CIA WORLD FACTBOOK
Command, Defense Logistics Command, Special
Forces Group (2013)
Military service age and obligation: 18 is the
apparent age of voluntary military service; official
minimum age is unknown (2001)
Manpower available for military service:
males age 16-49: 557,647
females age 16-49: 531,095 (2010 est.)
Manpower fit for military service: males age
16-49: 340,949
females age 16-49: 302,332 (2010 est.)
Manpower reaching militarily significant age
annually: male: 23,649
female: 23,063 (2010 est.)
Military expenditures: 2.8% of GDP (2012)
country comparison to the world: 44','9774cf6f988942892540c3bad15f682ab35b18e66882a9e948bd1585d3b0a5fb','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('99f9ba65ae5c2393bba8db10be8040b724cb2c1a6de5643b9f8c8da86eee7c76',2025,'BR','Brazil','military-and-security',284,'Military branches: Brazilian Army (Exercito
Brasileiro, EB), Brazilian Navy (Marinha do Brasil
(MB), includes Naval Air and Marine Corps
(Corpo de Fuzileiros Navais)), Brazilian Air Force
(Forca Aerea Brasileira, FAB) (2011)
Military service age and obligation: 21-45 years
of age for compulsory military service; conscript
service obligation—9 to 12 months; 17-45 years
of age for voluntary service; an increasing per-
centage of the ranks are “long-service” volunteer
e
professionals; women were allowed to serve in the
armed forces beginning in early 1980s when the
Brazilian Army became the first army in South
America to accept women into career ranks;
women serve in Navy and Air Force only in Wom-
en’s Reserve Corps (2001) -
Manpower available for military service:
males age 16-49: 53,350,703
females age 16-49: 53,433,918 (2010 est.)
Manpower fit tor military service: males age
16-49: 38,993,989
females age 16-49: 44,841,661 (2010 est.)
Manpower reaching militarily significant age
annually: male: 1,733,168
female: 1,672,477 (2010 est.)
Military expenditures: 1.3% of GDP (2012)
country comparison to the world: 113','26984f460386080f6b2fbcfaf4a78f752f97632981abdac01b1f982f40fdb0d1','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c97c1bb4772f674fd6346f4505005b0b36d554ecb575d000cbee64de9f45f958',2025,'ID','Indonesia','military-and-security',292,'Military branches: no regular military forces (2013)
Military—note: defense is the responsibility of the
UK; the US lease on Diego Garcia expires in 2016
Military branches: Royal Brunei Armed Forces:
Royal Brunei Land Forces, Royal Brunei Navy,
Royal Brunei Air Force (Tentera Udara Diraja
Brunei) (2013)
Military service age and obligation: 17 years of
age for voluntary military service; non-Malays are
ineligible to serve; recruits from the army, navy,
and air force all undergo 43-week initial training
(2013)
Manpower avallable for military service:
males age 16-49: 112,688
females age 16-49: 117,536 (2010 est.)
Manpower fit for military service: males age
16-49: 95,141
females age 16-49: 99,386 (2010 est.)
Manpower reaching militarily significant age
annually: male: 3,572
female: 3,465 (2010 est.)
Military expenditures: 2.4% of GDP (2011)
country comparison to the world: 59
Military branches: Indonesian Armed Forces
(Tentara Nasional Indonesia, TNI): Army (TNI-
Angkatan Darat (TNI-AD)), Navy (TNI-Ang-
katan Laut (TNI-AL); includes marines (Korps
Marinir, KorMar), naval air arm), Air Force
(TNi-Angkatan Udara (TNI-AU)), National
Air Defense Command (Kommando Pertahanan
Udara Nasional (Kohanudnas)) (2013)
Military service age and obligation: 18-45 years
of age for voluntary military service, with selective
conscription authorized; 2-year service obligation,
with reserve obligation to age 45 (officers); Indo-
nesian citizens only (2012)
Manpower available for military service:
males age 16-49: 65,847,171
females age 16-49: 63,228,017 (2010 est.)
Manpower fit for military service: males age
16-49; 54,264,299
females age 16-49: 53,274,361 (2010 est.)
Manpower reaching militarily significant age
annually: male: 2,263,892
female: 2,191,267 (2010 est.)
Military expenditures: 0.9% of GDP (2012)
country comparison to the world: 130
Military branches: Islamic Republic of Iran
Regular Forces (Artesh): Ground Forces, Navy,
Air Force (IRIAF), Khatemolanbia Air Defense
Headquarters; Islamic Revolutionary Guard Corps
(Sepah-e Pasdaran-e Engelab-e Eslami, IRGC):
Ground Resistance Forces, Navy, Aerospace Force,
Quds Force (special operations); Law Enforcement
Forces (2011)
Military service age and obligation: 18 years
of age for compulsory military service; 16 years of
age for volunteers; 17 years of age for Law Enforce-
ment Forces; 15 years of age for Basij Forces (Popu-
lar Mobilization Army); conscript military service
obligation is 18 months; women exempt from mili-
tary service (2012)
Manpower available for military service:
males age 16-49: 23,619,215
females age 16-49: 22,628,341 (2010 est.)
Manpower fit for military service: males age
16-49: 20,149,222.
females age 16-49: 19,417,275 (2010 est.)
Manpower reaching militarily significant age
annually: male: 715,111
female: 677,372 (2010 est.)
Military expenditures: 2.5% of GDP (2006)
country comparison to the world: 57','d72e45eb9580eba99cbcd3f307a0fcf32712779e3397496fb16fa3331d776541','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('24d570055970e2ff23f05410113a99d6ad504f42971b44dbd02529d59a22aa60',2025,'BG','Bulgaria','military-and-security',306,'Military branches: Bulgarian Armed Forces:
Ground Forces, Naval Forces, Bulgarian Air Forces
(Bulgarski Voennovazdyshni Sily, BVVS) (2011)
Military service age and obligation: 18-27 years
of age for voluntary military service; conscription
ended in January 2008; service obligation 6-9
months (2012)
Manpower available for military service:
males age 16-49: 1,637,470
females age 16-49: 1,621,352 (2010 est.)
Manpower fit for military service: males age
16-49: 1,320,955
females age 16-49: 1,337,616 (2010 est.)
Manpower reaching militarily significant age
annually: male: 33,444
female: 32,075 (2010 est.)
Military expenditures: 2.6% of GDP (2005 est.)
country comparison to the world: 49','e283a94b592041abd0f56b77b45febc8c5a1f0db7f593943eefd14a950e813be','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c04f1fed9e32eb33eb2cd9b3c88e2fe225a426b0c3f6a4a8de223701fff1c358',2025,'BF','Burkina Faso','military-and-security',320,'Military branches: Army, Air Force of Burkina
Faso (Force Aerienne de Burkina Faso, FABF),
National Gendarmerie (2011)
THE CIA WORLD FACTBOOK
Military service age and obligation: 18 years
of age for voluntary military service; women may
serve in supporting roles (2009)
Manpower available for military service:
males age 16-49: 3,735,735 (2010 est.)
Manpower fit for military service: males age
16-49: 2,366,168
females age 16-49: 2,367,673 (2010 est.)
Manpower reaching militarily significant age
annually: male: 193,905
female: 191,662 (2010 est.)
Military expenditures: 1.1% of GDP (2011)
country comparison to the world: 120
Military branches: Myanmar Armed Forces
(Tatmadaw): Army (Tatmadaw Kyi), Navy (Tat-
madaw Yay), Air Force (Tatmadaw Lay)(2013)
Military service age and obligation: 18-35
years of age (men) and 18-27 years of age
(women) for compulsory military service; ser-
vice obligation 2 years; male (ages 18-45) and
female (ages 18-35) professionals (including doc-
tors, engineers, mechanics) serve up to 3 years;
120
THE CIA WORLD FACTBOOK
service terms may be stretched to 5 years in an
officially declared emergency; Burma signed the
Convention on the Rights of the Child (CRC)
on 15 August 1991; on 27 June 2012, the regime
signed a Joint Action Plan on prevention of
child recruitment; in February 2013, the military
formed a new task force to address force child
conscription (2013)
Manpower available for military service:
males age 16-49: 14,747,845 | `
females age 16-49: 14,710,871 (2010 est.)
Manpower fit for military service: males age
16-49: 10,451,515
females age 16-49: 11,181,537 (2010 est.)
Manpower reaching militarily significant age
annually: male: 522,478
female: 506,388 (2010 est.)
Military expenditures: 4.8% of GDP (2012)
country comparison to the world: 17','e3b9465241f1073df01be85bc024cfdd83b28341c24f71a93460beafa10ab6de','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('50bdad59e8c32e67788438674a7b830c83d26f35f267ee322bcadd58226fea71',2025,'BI','Burundi','military-and-security',330,'Military branches: National Defense Forces
(Forces de Defense Nationale, FDN): Army
(includes naval detachment, Air Wing, atid Coast
Guard), National Gendarmerie (2011)
Military service age and obligation: military
service is voluntary; the arméd forces law of 31
December 2004 did not specify a minimum age for
enlistment, but the government claimed that no
one younger than 18 was being recruited; manda-
tory retirement age 45 (enlisted), 50 (NCOs), and
” 55 (officers) (2011)
Manpower availabie for military service:
males age 16-49: 2,182,327
females age 16-49: 2,202,125 (2010 est.)
Manpower fit for military service: males age
16-49: 1,398,769
females age 16-49: 1,481,417 (2010 est.)
Manpower reaching militarily significant age
annually: male: 117,956
female: 116,956 (2010 est.)
Military expenditures: 5.9% of GDP (2006 est.)
country comparison to the world: 12','cad3dee3edcf6b2383698a1c76f4cc2d5eccdd5cdcd8006e538cd0ff9c1966c7','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('209c3925599e30297e1141493fc6519bdb7e7d92c2ef709ceda44edc88c5f121',2025,'KH','Cambodia','military-and-security',338,'Military branches: Royal Cambodian Armed
Forces: Royal Cambodian Army, Royal Khmer
Navy, Royal Cambodian Air Force (2013)
Military service age and obligation: 18 is the
legal minimum age for compulsory and voluntary
military service (2012)
Manpower available for military service:
males age 16-49: 3,883,724
females age 16-49: 4,003,585 (2010 est.)
Manpower fit for military service: males age
16-49: 2,638,167
females age 16-49: 2,965,328 (2010 est.)
Manpower reaching militarily significant age
annually:
male: 151,143
female: 154,542 (2010 est.)
Military expenditures: 2.4% of GDP (2012)
country comparison to the world: 58','3c8d2c6c22ed813e388dc59cc78b3479b6e17a105862797075acee0db15026d6','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('de2e7aa32dad11c107a660eeb6edd9800c89a9e2f83dc349106630f260379ff7',2025,'CM','Cameroon','military-and-security',347,'Military branches: Cameroon Armed Forces
(Forces Armees Camerounaises, FAC), Army
(Armee de Terre), Navy (Marine Nationale
Republique (MNR), includes naval infantry), Air
Force (Armee de l''Air du Cameroun, AAC), Fire
Fighter Corps, Gendarmerie (2012)
Military service age and obligation: 18-23
years of age for male and female voluntary military
service; no conscription; high school graduation
required; service obligation 4 years; the govern-
ment makes periodic calls for volunteers (2012)
Manpower available for military service:
males age 16-49: 4,667,251
females age 16-49: 4,548,909 (2010 est.)
Manpower fit for military service: males age
16-49: 2,794,998
females age 16-49: 2,718,110 (2010 est.)
Manpower reaching militarily significant age
annually: male: 215,248
female: 211,636 (2010 est.)
131
Military expenditures: 1.3% of GDP (2009)
country comparison to the world: 111
Disputes—international: Joint Border Com-
mission with Nigeria reviewed 2002 IC] ruling
on the entire boundary and bilaterally resolved
THE CIA WORLD FACTBOOK
differences, including June 2006 Greentree Agree-
ment that immediately ceded sovereignty of the
Bakassi Peninsula to Cameroon with a full phase-
out of Nigerian control and patriation of residents
in 2008; Cameroon and Nigeria agreed on mari-
time delimitation in March 2008; sovereignty dis-
pute between Equatorial Guinea and Cameroon ,
over an island at the mouth of the Ntem River;
only Nigeria and Cameroon have heeded the
Lake Chad Commission’s admonition to ratify the
delimitation treaty, which also includes the Chad-
Niger and Niger-Nigeria boundaries
Refugees and internally displaced persons:
refugees (country of origin): 5,251 (Chad)
(2011); 87,092 (Central African Republic) (2013)','64bdc67b4544b7094cb63945d027f53c36c17a9400e6809aa9a3516afc4db2da','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('dbb709488e5c44ac0c4b8ad9a3cd29a6f812cc46b41747f0c39289b92a8a052f',2025,'CA','Canada','military-and-security',355,'Military branches: Canadian Forces: Canadian
Army, Royal Canadian Navy, Royal Canadian Air
Force, Canada Command (homeland security)
(2011)
Military service age and obligation: 17 years
of age for voluntary male and female military set-
vice (with parental consent); 16 years of age for
Reserve and Military College applicants; Cana-
dian citizenship or permanent residence status
required; maximum 34 years of age; service obliga-
tion 3-9 years (2012)
Manpower available for military service: males
age 16-49: 8,031,266
females age 16-49: 7,755,550 (2010 est.)
Manpower fit for military service: males age
16-49: 6,633,472
females age 16-49: 6,389,669 (2010 est.)
Manpower reaching militarily significant age
annually: male: 218,069
female: 206,195 (2010 est.)
Military expenditures: 1.1% of GDP (2005 est.)
country comparison to the world: 119
Military branches: Armed Forces: Army (also
called the National Guard, GN), Cape Verde
Coast Guard (Guardia Costeira de Cabo Verde,
GCCYV; includes naval infantry) (2012)
Military service age and obligation: 18 is the
legal minimum age for compulsory military service;
17 year olds may be conscripted in times of war;
14-month conscript service obligation; 17 is the
legal minimum age for voluntary service (2012)
Manpower available for military service:
males age 16-49: 132,087
females age 16-49: 136,956 (2010 est.)
Manpower fit for military service: males age
16-49: 106,864
females age 16-49; 117,518 (2010 est.)
Manpower reaching militarily significant age
annually: male: 6,029
female: 6,026 (2010 est.)
Military expenditures: 0.4% of GDP (2011)
country comparison to the world: 167','a7e060ddfe65437a4bdbdf7f7c7cfadab72a30805954b46f7822911b9b20e221','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('425f9ee48fda852bf64eac3d248bf4cace881819ec36af37291159c279839018',2025,'KY','Cayman Islands','military-and-security',367,'Military branches: no regular military forces;
Royal Cayman Islands Police Force (2012)
Manpower available for military service:
males age 16-49: 12,238 (2010 est.),
Manpower fit for military service: males age
16-49: 9,981
females age 16-49: 10,417 (2010 est.)
Manpower reaching militarily significant age
annually: male: 333
female: 342 (2010 est.)
Military—note: defense is the responsibility of
the UK','00fcbcdbc1843c07f624616c98cedb1008270cdebf84144ddbc1f6e2d08c7132','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('826975cd1b3cdd74eb60c168ccdea7455f6b364259664e77541d3150fc98c428',2025,'CF','Central African Republic','military-and-security',377,'Military branches: Central African Armed
Forces (Forces Armees Centrafricaines, FACA):
Ground Forces (includes Military Air Service),
General Directorate of Gendarmerie Inspection
(DGIG), National Police (2011)
Military service age and obligation: 18 years of
age for selective military service; 2-year conscript
service obligation (2012)
Manpower available for military service:
males age 16-49: 1,149,856
females age 16-49: 1,145,897 (2010 est.)
Manpower fit for military service: males age
16-49: 655,875
females age 16-49: 661,308 (2010 est.)
Manpower reaching militarily significant age
_ annually: male: 54,843
female: 53,999 (2010 est.)
Military expenditures: 2.6% of GDP (2011)
country comparison to the world: 48','6a4221cded6a9da110adea23283bc93ecfca9050c35391e9ea8c5997bdc5bb51','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9b2fc86da06ef508cdcfa33a36f0d05ceb246349c68e9a75dd43b37079cc39e2',2025,'TD','Chad','military-and-security',384,'Military branches: Chadian National Army
(Armee Nationale du Tchad, ANT): Ground
Forces (l''Armee de Terre, AdT), Chadian Air
Force’ (l''Armee de l''Air Tchadienne, AAT),
National Gendarmerie, National and Nomadic
Guard of Chad (GNNT) (2013)
Military service age and obligation: 20 is the legal
minimum age for compulsory military service, with a
3-year service obligation; 18 is the legal minimum
age for voluntary service; no minimum age restric-
tion for volunteers with consent from a parent or
guardian; women are subject to | year of compulsory
military or civic service at age of 21 (2012)
Manpower available for military service:
males age 16-49: 2,090,244
females age 16-49: 2,441,321 (2010 est.)
Manpower fit for military service: males age
16-49: 1,183,242
females age 16-49: 1,395,811 (2010 est.)
Manpower reaching militarily significant age
annually: male: 128,723
female: 128,244 (2010 est.)
Military expenditures: 1.6% of GDP (2011)
country comparison to the world: 89','22c3cb2f62b80ca55b7e96d4344318dbe4cfdc126d33366877452b7c92112cd4','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('df65b7313dcaa5e81ecd7ffab208d597d236580ff0184e09ea99f11a8b180b35',2025,'CL','Chile','military-and-security',390,'Military branches: Army of the Nation, Chilean
Navy (Armada de Chile, includes Naval Aviation,
Marine Corps, and Maritime Territory and Mer-
chant Marine Directorate (Directemar)), Chilean
Air Force (Fuerza Aerea de Chile, FACh), Carabi-
neros Corps (Cuerpo de Carabineros) (2011)
Military service age and obligation: 18-45 years
of age for voluntary male and female military ser-
vice, although the right to compulsory recruitment
of males 18-45 is retained; service obligation is 12
months for Army and 22 months for Navy and Air
Force (2012)
Manpower available for military service:
males age 16-49: 4,324,732
females age 16-49: 4,251,954 (2010 est.)
THE CIA WORLD FACTBOOK
Manpower fit for military service: males age
16-49: 3,621,475
females age 16-49: 3,561,099 (2010 est.)
Manpower reaching militarily significant age
annually: male: 141,500
female: 135,709 (2010 est.)
Military expenditures: 2.1% of GDP (2012)
country comparison to the world: 64','bf908c5517513d3168dd3ca155e0c2b382c10c1cc0efbbd960c1ab336325c87c','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('54f8e9cfb0464085a50a1c4f49e2accf27aa58a15542e46296bb995f44d60537',2025,'CO','Colombia','military-and-security',421,'Military branches: National Army (Ejercito
Nacional), Republic of Colombia Navy (Armada
Republica de Colombia, ARC, includes Naval
Aviation, Naval Infantry (Infanteria de Marina,
IM), and Coast Guard), Colombian Air Force
(Fuerza Aerea de Colombia, FAC) (2012)
Military service age and obligation: 18-24 years
of age for compulsory and voluntary military ser-
vice; service obligation is 18 months (2012)
Manpower available for military service:
~ males age 16-49: 11,692,647
females age 16-49; 11,727,625 (2010 est.)
Manpower fit for military service: males age
16-49: 9,150,400
females age 16-49: 9,861,760 (2010 est.)
Manpower reaching militarily significant age
annually: male: 430,634
female: 413,974 (2010 est.)
THE CIA WORLD FACTBOOK
Military expenditures: 3.8% of GDP (2012)
country comparison to the world: 26
Military branches: Bolivarian National Armed
Forces (Fuerza Armada Nacional Bolivariana,
FANB): Bolivarian Army (Ejercito Bolivariano,
EB), Bolivarian Navy (Armada Bolivariana, AB;
includes Naval Infantry, Coast Guard, Naval
Aviation), Bolivarian Military Aviation (Aviacion
Militar Bolivariana, AMB; includes Air National
Guard), Bolivarian National Guard (Guardia
Nacional Bolivaria, GNB) (2013)
Military service age and obligation: 18-30 years
of age for compulsory and voluntary military ser-
vice; 30-month conscript service obligation; Navy
requires 6th-grade education for enlisted person-
nel; all citizens of military service age (18-60 years
old) are obligated to register for military service
(2012)
Manpower available for military service:
males age 16-49: 7,013,854
females age 16-49: 7,165,661 (2010 est.)
Manpower fit for military service:
males age 16-49: 5,614,743
females age 16-49: 6,074,834 (2010 est.)
Manpower reaching militarily significant age
annually: male: 277,210
female: 273,353 (2010 est.)
Military expenditures
0.7% of GDP (2012)
country comparison to the world: 153','51ef8f12bb62ac5a798a4dfbb0e428d9377ec94dd74f5f38e260c7264811644a','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ca7618d2178b868abd600438f1de64f32af0353d3bb271c22e945332235e6e6d',2025,'KM','Comoros','military-and-security',431,'Military branches: Army of National Develop-
ment (l''Armee du Developpement Nationale,
AND): Comoran Security Force (also called
Comoran Defense Force (Force Comorienne de
Defense FCD, includes Gendarmerie)), Comoran
Coast Guard, Comoran Federal Police (2011)
Military service age and obligation: 18 years of
age for 2-year voluntary military service; no con-
scription; women first inducted into the Army in
2004 (2012)
Manpower available for military service:
males age 16-49: 184,236
females age 16-49: 183,363 (2010 est.)
Manpower fit for military service: males age
16-49: 134,562
females age 16-49: 145,797 (2010 est.)
Manpower reaching militarily significant age
annually: male: 8,831
female: 8,809 (2010 est.)
Military expenditures: 2.8% of GDP (2006)
country comparison to the world: 45','9657b4b4e17542b466efeaa8852699a7b9c22341f8cdd7154f5726259dc300d0','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b58e7aeb98ea8ad85d6d10c13e2fb1e902ff5d564ca5d7cb658c86f833c58e84',2025,'ZM','Zambia','military-and-security',437,'Military branches: Armed Forces of the Demo-
cratic Republic of the Congo (Forces d’Armees de
la Republique Democratique du Congo, FARDC):
Army, National Navy (La Marine Nationale),
Congolese Air Force (Force Aerienne Congolaise,
FAC) (2011)
Military service age and obligation: 18-45 years
of age for voluntary and compulsory military ser-
vice (2012)
Manpower available for military service:
males age 16-49: 15,980,106 (2010 est.)
Manpower fit for military service: males age
16-49: 10,168,258
females age 16-49: 10,331,693 (2010 est.)
Manpower reaching militarily significant age
annually: male: 877,684
female: 871,880 (2010 est.)
Military expenditures: 1.2% of GDP (2012)
country comparison to the world: 115','3c7c7e52c2e18eae2dbf6b950e9bb1a1a15c596cef50455142e5ac9ce703c655','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d403f8f4b05afff96cadde3568a50efdfc24c746f5921d48c4b70af5eb9f6947',2025,'CK','Cook Islands','military-and-security',446,'Military branches: no regular military forces;
National Police Department (2009)
Manpower fit for military service: males age
16-49: 2,198
females age 16-49: 2,156 (2010 est.)
Manpower reaching militarily significant age
annually: male: 127
female: 107 (2010 est.)
Military—note: defense is the responsibility
of New Zealand in consultation with the Cook
Islands and at its request','c0800dba79821507fddb65c8c5e487f2e500b6e356e65b5f83de8bda48956cbc','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('294b0ad73d230fb69aa21a7e838ab4300f8b3b78029d6ebf1d44c514fbe566ca',2025,'CR','Costa Rica','military-and-security',454,'Military branches: no regular military forces;
Ministry of Public Security, Government, and
Police (2011) ;
Manpower available for military service:
males age 16-49: 1,255,798
females age 16-49: 1,230,202 (2010 est.)
Manpower fit for military service: males age
16-49: 1,058,419
females age 16-49: 1,037,053 (2010 est.)
Manpower reaching militarily significant age
annually: male: 42,20!
female: 40,444 (2010 est.)
Military expenditures: 0.8% of GDP
country comparison to the world: 145
note: includes public security and police expendi-
tures (2012)','720c1a0e86e7692372836a01ae29193f7ecfe42d0124a9a68eeea8a5da8cdfca','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('17dfd75696dcb487b02bdfee220fd13f31a1b4593529f62caef8c9baa44a11b9',2025,'MX','Mexico','military-and-security',462,'Military branches: Republican Forces of Cote
dIvoire (Force Republiques de Cote d''Ivoire,
FRCI): Army, Navy, Cote d''Ivoire Air Force
(Force Aerienne de la Cote d''lvoire)
note: FRC] is the former Armed Forces of the New
Forces (FAFN) (2013)
Military service age and obligation: 18-25
years of age for compulsory and voluntary male
and female military service; conscription is not
enforced; voluntary recruitment of former rebels
into the new national army is’ restricted to ages
22-29 (2012)
THE CIA WORLD FACTBOOK
Manpower available for military service:
males age 16-49: 5,247,522
females age 16-49: 5,047,901 (2010 est.)
Manpower fit for military service: males age
16-49: 3,360,087
females age 16-49: 3,196,033 (2010 est.)
Manpower reaching militarily significant age
annually: male: 247,011
female: 242,958 (2010 est.)
Military expenditures: 1.5% of GDP (2009)
country comparison to the world: 103
Military branches: Secretariat of National Defense
(Secretaria de Defensa Nacional, Sedena): Army
(Ejercito), Mexican Air Force (Fuerza Aerea Mexi-
cana, FAM); Secretariat of the Navy (Secretaria
de Marina, Semar): Mexican Navy (Armada de
Mexico (ARM), includes Naval Air Force (FAN),
Mexican Marine Corps (Cuerpo de Infanteria de
Marina, Mexmar or CIM)) (2011)
Military service age and obligation: 18 years of
age for compulsory military service, conscript ser-
vice obligation is 12 months; 16 years of age with
consent for voluntary enlistment; conscripts serve
only in the Army; Navy and Air Force service is
all voluntary; women are eligible for voluntary
military service; cadets enrolled in military schools
from the age of 15 are considered members of the
armed forces (2012)
Manpower available for military service:
males age 16-49: 28,815,506 females age 16-49:
30,363,558 (2010 est.)
Manpower fit for military service: males age
16-49: 23,239,866 females age 16-49: 25,642,549
(2010 est.)
Manpower reaching militarily significant age
annually: male: 1,105,371 female: 1,067,007
(2010 est.)
Military expenditures: 0.5% of GDP (2012)
country comparison to the world: 161 i
Military branches: no regular military forces
(2012)
Manpower available for military service: males
age 16-49: 26,712 (2010 est.)
Manpower fit for military service: males age
16-49: 22,008 females age 16-49: 23,501 (201C
est.)
Manpower reaching militarily significant age
annually: male: 1,276
female: 1,253 (2010 est.)
Military—note: defense is the responsibility of
the US','d71c9c67deaddbb153108bdf64b65949ae0622297d1cc62f12695ce6305e43b0','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fb06c641799816149a0484e1a496c90577e3ec843d27f8d877bbec5bf9213077',2025,'HR','Croatia','military-and-security',473,'CROATIA Military branches: Armed Forces
of the Republic of Croatia (Oruzane Snage
Republike Hrvatske, OSRH), consists of five
major commands directly subordinate to a Gen-
eral Staff; Ground Forces (Hrvatska Kopnena
Vojska, HKoV), Naval Forces (Hrvatska Ratna
Mornarica, HRM; includes coast guard), Air
Force and Air Defense Command (Hrvatsko
Ratno Zrakoplovstvo | Protuzracna Obrana),
Joint Education and Training Command, Logis-
tics Command; Military Police Force supports
each of the three Croatian military forces
(2010)
Military service age and obligation: 18-27 years
of age for voluntary military service; 6-month ser-
vice obligation (2012)
Manpower available for military service:
males age 16-49: 1,016,234
females age 16-49: 1,017,355 (2010 est.)
Manpower fit for military service: males age
16-49: 770,710
females age 16-49: 839,732 (2010 est.)
Manpower reaching militarily significant age
annually: male: 28,334
female: 27,015 (2010 est.)
185
Military expenditures: 1.5% of GDP (2012)
country comparison to the world: 94','b4e0f303e5f13cc059242e163f1fc22b7e80b569e4f386394078ed388ed810d8','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('dd8b6fc3909c9560bf7e7ca7dfecfe3fa9a72052d7d1e111c6c7f02416b54182',2025,'CY','Cyprus','military-and-security',485,'Military branches: Republic of Cyprus: Greek
Cypriot National Guard (Ethniki Froura, EF;
includes naval and air elements); Northern
Cyprus: Turkish Cypriot Security Force (GKK)
(2013)
Military service age and obligation: Greek
Cypriot National Guard (GCNG): 18-50 years
of age for compulsory military service for all
Greek Cypriot males; 17 years of age for volun-
tary service; length of service obligation is 25
months; women may volunteer for a 3-year term
(2013)
Manpower available for military service:
Greek Cypriot National Guard (GCNG):
males age 16-49: 327,875
females age 16-49: 287,891 (2010 est.)
Manpower fit for military service: Greek Cyp-
riot National Guard (GCNG): males age 16-49:
275,842
females age 16-49: 239,862 (2010 est.)
Manpower reaching militarily significant age
annually: male: 8,167
female: 7,398 (2010 est.)
Military expenditures: 2% of GDP (2012) (U)
country comparison to the world: 67
Disputes—international: hostilities in 1974
divided the island into two de facto autonomous
entities, the internationally recognized Cypriot
Government and a Turkish-Cypriot community
(north Cyprus); the 1,000-strong UN Peacekeep-
ing Force in Cyprus (UNFICYP) has served in
Cyprus since 1964 and maintains the buffer zone
betw een north and south; on 1 May 2004, Cyprus
entered the European Union still divided, with
the EU''s body of legislation and standards (acquis
communitaire) suspended in the north; Turkey
protests Cypriot Government creating hydrocar-
bon blocks and maritime boundary with Lebanon
in March 2007
Refugees and internally displaced persons:
IDPs: 208,000 (both Turkish and Greek Cypri-
ots; many displaced since 1974) (2012)
ltlicit drugs: minor transit point for heroin and
hashish via air routes and container traffic to
Europe, especially from Lebanon and Turkey; some
cocaine transits as well; despite a strengthening of
anti-money-laundering legislation, remains vul-
nerable to money laundering; reporting of suspi-
cious transactions in offshore sector remains weak
(2008)
CZECH REPUBLIC','a45283659f99fdfef87c3c5b573162864f195ed1547458c928cc85af1e533a5a','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('575d8ea664aec2da46dc55f6d62fef36b3c74f31602704648d3fb8e4e6e829eb',2025,'PL','Poland','military-and-security',486,'Deging® va Snake
a Liberec
Hradec g
Králové, Sow
° ~ ¢
PRAGUE, Y
À
ii x!
ostrava y 4
As,
3° Olomouc, Maa
Conka uoa S AE, al
~ Bude juice Bmo
porn”
Military branches: Polish Armed Forces: Land
Forces, Navy, Air and Air Defense Aviation
Forces, Special Forces (2013)
Military service age and obligation: 18-28
years of age for male and female voluntary
military service; conscription phased out in
2009-12; service obligation shortened from 12
to 9 months in 2005; women only allowed to
serve as officers and noncommissioned officers
(2013) i
Manpower available for military service:
males age 16-49: 9,531,855
females age 16-49: 9,298,593 (2010 est.)
Manpower fit for military service: males age
16-49: 7,817,556
females age 16-49: 7,766,361 (2010 est.)
Manpower reaching militarily significant age
annually: male: 221,889
female: 211,172 (2010 est.)
Military expenditures: 1.9% of GDP (2005
est.)
country comparison to the world: 70','0c1e73f5639e78a60839a94cf7d5761e75c3f270be7a732d01931655f04f5e7c','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('31c6351ae7bc5e5357497473e24baa475085865b563fb94a63ebf8bea89fb9ad',2025,'DK','Denmark','military-and-security',500,'Military branches; Defense Command: Army
Operational Command, Admiral Danish Fleer,
Arctic Command, Tactical Air Command, Home
Guard (2010)
Military service age and obligation: 18 years of
age for compulsory and voluntary military service;
conscripts serve an initial training period that var-
jes from 4 to 12 months according to specializa-
tion; reservists are assigned to mobilization units
following completion of their conscript service;
women eligible to volunteer for military service
(2012)
Manpower available for military service:
males age 16-49: 1,236,337
females age 16-49: 1,224,182 (2010 est.)
Manpower fit for military service:
males age 16-49: 1,014,560
females age 16-49: 1,003,921 (2010 est.)
Manpower reaching militarily significant age
annually: male: 37,913
female: 35,865 (2010 est.)
Military expenditures: 1.3% of GDP (2007 est.)
country comparison to the world: 112
Military—note: defense is the responsibility of
the UK; includes Dhekelia Garrison and Ayios
Nikolaos Station connected by a roadway
Disputes—international: managed dispute
between Canada and Denmark over Hans Island
in the Kennedy Channel berween Canada’s Elles-
mere Island and Greenland; Denmark (Green-
land) and Norway have made submissions to the
Commission on the Limits of the Continental
shelf (CLCS) and Russia is collecting additional
data to augment its 2001 CLCS submission
NORTH
ATLANTIC
OCEAN
Mount
Catherine +
=
Gouyave, °
7
Grenville,
SAINT .
Font Saines P FORGES
PELAN
Aiport i
a','0f3d5bf12d8e0f47a96ee001c252d4f5d25a90a8243ba856ea9ac2530f298875','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e7fbc21561874e48c48c1314ce40e30a5d02b737690bb8e1f91af997d54e2776',2025,'DJ','Djibouti','military-and-security',503,'oR
D 4
f
i eS Khon Angar®
ETHIOPIA 7
4 * Baio
Tadjoura,
Military branches: Djibouti Armed Forces
(Forces Armees Djiboutiennes, FAD): Djibouti
National Army (includes Navy, Djiboutian Air
Force (Force Aerienne Djiboutienne, FAD),
National Gendarmerie (GN)) (2013)
Military service age and obligation: 18 years of
age for voluntary military service; 16-25 years of
age for voluntary military training; no conscrip-
tion (2012)
Manpower available for military service:
males age 16-49: 170,386
females age 16-49: 221,411 (2010 est.)
Manpower fit for military service:
males age 16-49: 114,557
females age 16-49: 154,173 (2010 est.)
Manpower reaching militarily significant age
annually:
male: 8,360
female: 8,602 (2010 est.)
Military expenditures: 3.6% of GDP (2011)
country comparison to the world: 32','c0bc3b6bf11780175c50f3a03b1a4ced3a2fa8f1679ac68e75e2ecf0bfa0778b','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('78563fa25b3804d57a72f2e1a09e586f539c8af429eabe1f3cc8316421296a22',2025,'DM','Dominica','military-and-security',524,'Military branches: no regular military forces;
Commonwealth of Dominica Police Force
(includes Coast Guard) (2012)
Manpower available for military service:
males age 16-49: 19,075 (2010 est.)
Manpower fit for military service: males age
16-49: 16,035
females age 16-49: 15,499 (2010 est.)
Manpower reaching militarily significdnt age
annually: male: 675
female: 636 (2010 est.)
Military expenditures: NA','19d9076f4e93c2b134d5ecbdc951a12ec4096e93ade314a03f5a4ba0780fbb6c','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('df2e140a351f86988d657d3650be2a2a109a6742f3820b10a0760e50b2483dfc',2025,'DO','Dominican Republic','military-and-security',533,'Military .branches: Army, Navy (Marina de
Guerra, includes naval infantry), Air Force (Fuerza
Aerea Dominicana, FAD) (2011)
Military service age and obligation: 17-21 years
of age for voluntary military service; recruits must
(Boca
have completed primary school and be Dominican
Republic citizens; women may volunteer (2012)
Manpower available for military service:
males age 16-49: 2,580,083
females age 16-49: 2,464,698 (2010 est.)
Manpower fit for military service: males age
16-49: 2,188,358
females age 16-49; 2,090,180 (2010 est.)
Manpower reaching militarily significant age
annually: male: 100,047
female: 96,302 (2010 est.)
Military expenditures: 0.7% of GDP (2012)
country comparison to the world: 152','304b19db858e43d2b519b34bb2de60a186d255c7657859b3f01ddbcdc4efb361','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('28fb6c01a4cc118248f9258408ba2f0da37bb31b4f3069b23c7b5392dcee647a',2025,'EC','Ecuador','military-and-security',538,'Military branches: Ecuadorian Armed Forces:
Ecuadorian Land Force (Fuerza Terrestre Ecuato-
riana, FTE), Ecuadorian Navy (Fuerza Naval del
Ecuador (FNE), includes Naval Infantry, Naval
Aviation, Coast Guard), Ecuadorian Air Force
(Fuerza Aerea Ecuatoriana, FAE) (2012)
Military service age and obligation: 18 years
of age for selective conscript military service; con-
scription has been suspended; 18 years of age for
voluntary military service; Air Force 18-22 years
of age, Ecadorian birth requirement; 1-year service
obligation (2012)
Manpower available for military service:
males age 16-49: 3,728,906
females age 16-49: 3,844,918 (2010 est.)
Manpower fit for military service: males age
16-49: 2,834,213
females age 16-49: 3,269,535 (2010 est.)
Manpower reaching militarily significant age
annually: male: 152,593
female: 147,143 (2010 est.)
Military expenditures: 2.3% of GDP (2012)
, country comparison to the world: 61','b8c1795480015e066eb63c015d6db06eab01aa2852b47d14e23b1279dc703e47','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('872f7522d3fd64f14ad9ceb1f3ed69476dbb18a15d3d7bd114187cbaa3361e18',2025,'EG','Egypt','military-and-security',549,'Military branches: Army, Navy, Egyptian Air
Force (Al-Quw wat al-Jaw wiya il-Misriya), Egyp-
tian Air Defense Command (2013)
Military service age and obligation: 18-30 years
of age for male conscript military service; service
obligation—18-36 months, followed by a 9-year
reserve obligation; voluntary enlistment possible
from age 16 (2012)
Manpower available for military service:
males age 16-49: 21,012,199
females age 16-49: 20,145,021 (2010 est.)
Manpower fit for military service: males age
16-49: 18,060,543
females age 16-49: 17,244,838 (2010 est.)
Manpower reaching militarily significant age
annually: male: 783,405
female: 748,647 (2010 est.)
Military expenditures: 2.2% of GDP (2012)
country comparison to the world: 62','fac0e947e9e98213cb2ea51b5177105294fa9cca03cc0010a5e44866234e9af1','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('be22d68f4a1a6e55ba57d96194bc397c5edf65a91de919167449ca2b34a1b233',2025,'SV','El Salvador','military-and-security',561,'Military branches: Salvadoran Armed Forces
(FAES): Salvadoran Army (ES), Salvadoran Navy
(FNES), Salvadoran Air Force (Fuerza Aerea Sal-
vadorena, FAS) (2011)
Military service age and obligation: 18 years
of age for selective compulsory military service;
16-22 years of age for voluntary male or female
service; service obligation is 12 months, with
11 months for officers and NCOs (2012)
Manpower available for military service:
males age 16-49: 1,449,214
females age 16-49: 1,611,248 (2010 est.)
Manpower fit for military service: males age
16-49: 1,079,038
females age 16-49: 1,373,368 (2010 est.)
Manpower reaching militarily significant age
annually: male: 71,530
female: 68,971 (2010 est.)
Military expenditures: 0.6% of GDP (2012)
country comparison to the world: 158','c3de2a02f41882eec13f1e5784d6d66ddd28164563814233c16ede5f9170dc03','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('69658dbcae8c70bf5676a93de102e5a6f5554bc8f5be29ad77aaa33362063388',2025,'GQ','Equatorial Guinea','military-and-security',567,'Military branches: Equatorial Guinea Armed
‘Forces (FAGE): Equatorial Guinea National
Guard (Guardia Nacional de Guinea Ecuatoria,
GNGE (Anny), with Coast Guard (Navy) and Air
Wing) (2013)
Military service age and obligation: 18 years
of age for selective compulsory military service,
although conscription is rare in practice; 18 is the
legal minimum age for voluntary service; 2-year
service obligation; women hold only administra-
tive positions in the Coast Guard (2013)
Manpower available for military service:
males age 16-49: 151,147
females age 16-49: 150,345 (2010 est.)
Manpower fit for military service: males age
16-49: 113,277
females age 16-49: 115,320 (2010 est.)
Manpower reaching militarily significant age
annually: male: 7,398
female: 7,126 (2010 est.)
Military expenditures: 0.1% of GDP (2011)
country comparison to the world: 170','9b6e81edc5a5238dd646d36afe4b96e109cf54d92df04def74c5ea3ea7e94b5a','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d4a4b900eadccbd439c3bf9bead6d7cd52bfaacbdb4292d9b493662adc3c7e18',2025,'EE','Estonia','military-and-security',585,'Military branche: Estonian Defense Forces (Eesti
Kaitsevagi): Land Force (Maavagi), Navy (Merev-
agi), Air Force (Ohuvagi), Defense League (Kait-
seliit) (2012)
Military service age and obligation: 60 for com-
pulsory service, “conscription likely” ages 18-27;
conscript service requirement 8 months; NCOs,
reserve officers, and specialists serve 11 months
(2013)
Manpower available for military service:
males age 16-49: 291,801
females age 16-49: 302,696 (2010 est.)
Manpower fit for military service: males age
16-49: 210,854
females age 16-49: 251,185 (2010 est.)
Manpower reaching militarily significant age
annually: male: 6,668
female: 6,309 (2010 est.)
Military expenditures: 2% of GDP (2005 est.)
country comparison to the world: 66','7101933bcef83bd8d8a1d171ff7bf4db21197b6e27e315e4f033eb0c4bd585ff','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5bbbbc967ff762ed0ae567d0731bb1a46723d922511fda76777e633806808f63',2025,'SO','Somalia','military-and-security',591,'Military branches: Ethiopian National Defense
Force (ENDF): Ground Forces, Ethiopian Air
Force (Ye Iryopya Ayer Hayl, ETAF) (2013)
Military service age and obligation: 18 years of
age for voluntary military service; no compulsory
military service, but the military can conduct cal-
lups when necessary and compliance is compulsory
(2012)
Manpower available for military service:
males age 16-49: 19,067,499
females age 16-49: 19,726,816 (2010 est.)
Manpower fit for military service: males age
16-49; 11,868,084
females age 16-49: 12,889,260 (2010 est.)
Manpower reaching militarily significant age
annually: male: 967,411
female: 981,714 (2010 est.)
Military expenditures: 0.9% of GDP (2012)
country comparison to the world: 143
Military branches: National Security Force
(NSF): Somali Army (2011)
Military service age and obligation: 18 is the
legal minimum age for compulsory and voluntary
military service (2012)
Manpower available for military service:
males age 16-49: 2,260,175
females age 16-49: 2,159,293 (2010 est.)
Manpower fit for military service: males age
16-49: 1,331,894
females age 16-49: 1,357,051 (2010 est.)
Manpower reaching militarily significant age
annually: male: 101,634
female: 101,072 (2010 est.)
Military expenditures: 0.9% of GDP (2005 est.)
country comparison to the world: 134','75463c76679ad06ff3fa7e06a371ab6d1fb25e22c04214bc07afb9c7357edc0a','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d994e3d430cd5a51b8d2c5ca7a03479c75d21f84f6f91f1f2aa7e7475bb55f82',2025,'ET','Ethiopia','military-and-security',595,'Military—note: the five-nation Eurocorps—cre-
ated in 1992 by France, Germany, Belgium, Spain,
and Luxembourg—has deployed troops and police
on peacekeeping missions to Bosnia-Herzegovina,
Macedonia, and the Democratic Republic of the
Congo and assumed command of the ISAF in
Afghanistan in August 2004; Eurocorps directly
commands the 5,000-man Franco-German Bri-
gade, the Multinational Command Support Bri-
gade, and EUFOR in Bosnia and Herzegovina;
in November 2004, the EU Council of Ministers
formally committed to creating 131,500-man bat-
tle groups by the end of 2007, to respond to inter-
national crises on a rotating basis; 22 of the EU''s
27 nations have agreed to supply troops; France,
Italy, and the UK formed the first of three battle
groups in 2005; Norway, Sweden, Estonia, end Fin-
land established the Nordic Battle Group effective
1 January 2008; nine other groups are to be formed;
a rapid-reaction naval EU Maritime Task Group
was stood up in March 2007 (2007)
Military branches: no regular military forces
Military expenditures: NA
Military—note: defense is the responsibility of
the UK','8214e6ebf2cd459be420224d37c1ee4744fc294e6593a01826f957505c667b58','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3f737445773b2d1a99a0be6d3616b0ed549e52d9d791aa3018f3eacd80b16ef2',2025,'FJ','Fiji','military-and-security',609,'Military branches: Republic of Fiji Military
Forces (RFMF): Land Forces, Naval Forces (2011)
Military service age and obligation: 18 is the
legal minimum age for voluntary military service;
no conscription (2012)
Manpower available for military service:
males age 16-49: 233,240
females age 16-49: 222,587 (2010 est.)
Manpower fit for military service: males age
16-49: 183,730
females age 16-49: 188,325 (2010 est.)
Manpower reaching militarily significant age
annually: male: 8,403
female: 8,039 (2010 est.)
Military expenditures: 1.6% of GDP (2012)
country comparison to the world: 88
Disputes—international: none','477233e3e6f9edbf1807bf37c8a19b0aef31503e976f88795572290fdf309cee','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0f9af2388f2932ad34d218c0fc40aca1238736ae724aec794f8756b580926dc3',2025,'FI','Finland','military-and-security',616,'Military branches: Finnish Defense Forces
(FDF): Army, Navy (includes Coastal Defense
Forces), Air Force (Suomen Ilmavoimat) (2011)
Military service age and obligation: 18 years
of age for male voluntary and compulsory—and
female voluntary—national military and nonmili-
tary service; service obligation 6-12 months; mili-
tary obligation to age 60 (2012)
Manpower available for military service:
males age 16-49: 1,155,368
females age 16-49: 1,106,193 (2010 est.)
Manpower fit for military service: males age
16-49:955,151
females age 16-49: 912,983 (2010 est.)
Manpower reaching militarily significant age
annually: male: 32,599
female: 31,416 (2010 est.)
Military expenditures: 2% of GDP (2005 est.)
country comparison to the world: 68','36a4e57b0bccb881f1ceffd8ddd82a47e82c84ff6de274ba702c549832097b16','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5a72ef181db051bf44f962f2e2ed835208faa14a3319102963b401841efdab38',2025,'FR','France','military-and-security',625,'Military branches: Army (Armee de Terre;
includes Marines, Foreign Legion, Army Light
Aviation), Navy (Marine Nationale), Air Force
(Armee de l''Air (AdIA); includes Air Defense)
(2011)
259
Military service age and obligation: 17-40
years of age for male and female voluntary military
service (with parental consent); no conscription;
l-year service obligation; women serve in non-
combat posts (2013)
Manpower available for military service:
males age 16-49: 14,563,662
females age 16-49: 14,238,434 (2010 est.)
Manpower fit for military service: males age
16-49; 12,025,341
females age 16-49: 11,721,827 (2010 est.)
Manpower reaching militarily significant age
annually: male: 396,050
female: 377,839 (2010 est.)
THE CIA WORLD FACTBOOK
Military expenditures; 2.6% of GDP (2005 est.)
country comparison to the world: 51
Military—note: defense is the responsibility of
Manpower fit for military service: males age
16-49: 1,495
females age 16-49: 1,263 (2010 est.)
Manpower reaching militarily significant age
annually: male:23 ` i
female: 21 (2010 est.)
Military—note: defense is the responsibility of France
SAINT HELENA, ASCENSION, AND TRISTAN DA CUNHA
Saint Helena »
JAMESTOWN
TRISTAN DA CUNHA
Menge
Soret Oe Marys Peak
“A Taustan da Cunha
NIGH TINGA: $
Manpower fit for military service: males age
16-49: 6,435
females age 16-49: 6,967 (2010 est.)
Manpower reaching militarily significant age
annually: male: 168 : j
female: 168 (2010 est.)
Military—note: defense is.the responsibility of
undersea
619
THE CIA WORLD FACTBOOK','5a28d5d2ceb57dd5fbbe7f116a593d1d4b8d5dbceb97b6293e050738a8d1e48e','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ecf722d652083c08f05a9ef6ccc00ce0dc01a3e46fcabd61b44a7c59f23445c0',2025,'PF','French Polynesia','military-and-security',633,'Military branches: no regular military forces (2011)
Manpower available for military service:
males age 16-49: 82,722 (2010 est.)
Manpower fit for military service: males age
16-49:67,363
females age 16-49: 66,053 (2010 est.)
Manpower reaching militarily significant age
annually: male: 2,498
female: 2,390 (2010 est.)
Military—note: defense is the responsibility of','e614eec556875e5ea6b7de7f232819e0c0f1f6b46a836b127b10c66db41c8943','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('774700965deeb45d97602e63c97d54cbb73b265e05a1f9580b5d09ce04a4df00',2025,'GA','Gabon','military-and-security',643,'Military branches: Gabonese Defense Forces
(Forces de Defense Gabonaise): Land Force (Force
Terrestre), Gabonese Navy (Marine Gabonaise),
Gabonese Air Forces (Forces Aerienne Gabo-
naises, FAG) (2012)
Military service age and obligation: 20 years
of age for voluntary military service; no conscrip-
tion (2012)
Manpower available for military service:
males age 16-49: 350,640
females age 16-49: 351,718 (2010 est.)
Manpower fit for military service: males age
16-49: 202,404
females age 16-49: 195,389 (2010 est.)
Manpower reaching militarily significant age
annually: male: 17,638
female: 17,614 (2010 est.)
Military expenditures: 1.8% of GDP (2011)
country comparison to the world: 79','f6aaa47c4aee556e09b759826d4b38b40592b3c047d5543a81a8f350784b3f3d','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('33ae01216c0b482deb1ddee0c2463777ed096a4b7ab582d37abbdc986cad4ca2',2025,'SN','Senegal','military-and-security',654,'Military branches: Office of the Chief of Defense
Staff: Gambian National Army (GNA), Gambian
Navy (GN), Republican National Guard (RNG)
(2010)
Military service age and obligation: 18 years of
age for male and female voluntary military service;
no conscription (2012)
Manpower available for military service:
males age 16-49: 423,306
females age 16-49: 438,641 (2010 est.)
Manpower fit for military service: males age
16-49: 315,176
females age 16-49: 347,017 (2010 est.)
Manpower reaching militarily significant age
annually: male: 20,508
female: 20,853 (2010 est.)
Military expenditures: 0.7% of GDP (2011)
country comparison to the world: 154
Military branches: Hamas does not have a con-
ventional military in the Gaza Strip, but maintains
INTRODCTION
Background: The region of present day Georgia
contained the ancient kingdoms of Colchis and
Kartli-Iberia. The area came under Roman influ-
ence in the first centuries A.D., and Christianity
became the state religion in the 330s. Domina-
tion by Persians, Arabs, and Turks was followed
by a Georgian golden age (11th-13th centuries)
that was cut short by the Mongol invasion of
1236. Subsequently, the Ottoman and Persian
empires competed for influence in the region.
Georgia was absorbed into the Russian Empire
in the 19th century. Independent for three years
(1918-1921) following the Russian revolution, it
was forcibly incorporated into the USSR in 1921
and regained its independence when the Soviet
Union dissolved in 1991. Mounting public dis-
content over rampant corruption and ineffective
government services, followed by an attempt by
the incumbent Georgian Government to manipu-
late national legislative elections in November
2003 touched off widespread protests that led to
the resignation of Eduard SHEVARDNADZE,
president since 1995. In the aftermath of that
popular movement, which became known as the
“Rose Revolution,” new elections in early 2004
swept Mikheil SAAKASHVILI into power along
with his United National Movement (UNM)
party. Progress on market reforms and democrati-
zation has been made in the years since independ-
ence, but this progress has been complicated by
Russian assistance and support to the separatist
regions of Abkhazia and South Ossetia. Periodic
flare-ups in tension and violence culminated in
a five-day conflict in August 2008 between Rus-
sia and Georgia, including the invasion of large
portions of undisputed Georgian territory. Russian
troops pledged to pull back from most occupied
Georgian territory, but in late August 2008 Russia
GAZA STRIP
security forces in addition to its military wing, the ‘Izz
al-Din al-Qassam Brigades; the military wing reports
to the external Hamas Political Bureau leadership,
which has been in exile in Cairo and Doha since clos-
ing its Damascus headquarters in late 2011 (2013)
Manpower available for military service:
males age 16-49: 385,961 (2010 est.)
Manpower fit for military service: males age
16-49: 335,820
females age 16-49: 319,847 (2010 est.)
Manpower reaching militarily significant age
annually: male: 18,805
female: 17,903 (2010 est.)
Military expenditures: NA
unilaterally recognized the independence of Abk-
hazia and South Ossetia, and Russian military
forces remain in those regions. Billionaire phi-
lanthropist Bidzina IVANISHVILI’s unexpected
entry into politics in October 2011 brought the
divided opposition together under his Georgian
Dream coalition, which won a majority of seats
in the October 2012 parliamentary election and
removed UNM from power. A new constitution
shifting many powers from the president to the
prime minister and parliament, including the
power to name the prime minister and govern-
ment ministers, does not go into effect until after
anew president is elected in the fall of 2013. Con-
ceding defeat, SAAKASHVILI named IVAN-
ISHVILI as prime minister and allowed Georgian
Dream to create a new government. Tensions
remain high as IVANISHVILI, SAAKASHVILI,
and their supporters struggle to co-exist until the
end of the president’s term.
Military branches: Senegalese Armed Forces:
Amny, Senegalese National Navy (Marine Senega-
laise, MNS), Senegalese Air Force (Armee de l''Air
du Senegal) (2013)
Military service age and obligation: 18 years of
age for voluntary military service; 20 years of age
for selective conscript service; service obligation is
2 years; women have been accepted into military
service since 2008 (2013)
Manpower available for military service:
males age 16-49: 2,699,196
females age 16-49: 3,018,565 (2010 est.)
Manpower fit for military service: males age
16-49: 1,788,493
females age 16-49: 2,133,370 (2010 est.)
Manpower reaching militarily significant age
annually: male: 145,509
female: 145,064 (2010 est.)
Military expenditures: 1.6% of GDP (2011)
country comparison to the world: 92','257e312b777aec53dfcd8fe19463d8cef75b99a7f7d54613a409e1ea2ae4a122','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d4bfc54676871e04eb9ebf41cf3ffce70eb1a7bf92b5b2ccc1fe2db468f88f07',2025,'GE','Georgia','military-and-security',659,'Military branches: Georgian Armed Forces:
Land Forces (include Air and Air Defense
Forces); separatist Abkhazia Armed Forces:
Ground Forces, Air Forces; separatist South Osse-
tia Armed Forces
note: Georgian naval forces have been incorpo-
tated into the coast guard, which is not part of the
Defense Ministry (2011)
Military service age and obligation: 18 to 34
years of age for compulsory and voluntary active
duty military service; conscript service obligation
is 18 months (2012)
Manpower available for military service:
males age 16-49: 1,080,840 j -
females age 16-49: 1,122,031 (2010 est.)
Manpower fit for military service: males age
16-49: 893,003
females age 16-49: 931,683 (2010 est.)
Manpower reaching militarily significant age
annually: male: 29,723
female: 27,242 (2010 est.)
Hehe
s-eKatest une
. Stuttgart
r
%
Numbery”
i
Mamen,
D a ae ere','be5e32630ad48bd0ea4abb1dcabfc60d14bfefc06ab0c1287db46a817c9c5ce0','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5687e63caa3c52424e0ef2992f75759b16b34d98ca31963f742ad80d010186d5',2025,'GH','Ghana','military-and-security',678,'Military branches: Ghana Army, Ghana Navy,
Ghana Air Force (2012)
Military service age and obligation: 18-26 years
of age for voluntary military service, with basic
education certificate; no conscription; must be
HIV/AIDS negative (2012)
Manpower available for military service:
males age 16-49: 6,268,191
females age 16-49: 6,194,339 (2010 est.)
Manpower fit for military service: males age
16-49: 4,136,406
females age 16-49: 4,220,761 (2010 est.)
Manpower reaching militarily significant age
annually: male: 267,896
female: 260,992 (2010 est.)
Military expenditures: 1.7% of GDP (2009)
country comparison to the world: 85','412473e501a456dbd8b8bd2fbd981814ad65198d9945bcf7849920bdd5ad12a6','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('38d2a651ebfdde7be1296df8a39f8fca3b849286c350aa89ec457a1e7b943e5c',2025,'GI','Gibraltar','military-and-security',688,'Military branches: Royal Gibraltar Regiment
(2011)
Manpower available for military service:
males age 16-49: 7,037 (2010 est.)
Manpower fit for military service: males age
16-49. 6,017
females age 16-49: 5,706 (2010 est.)
Manpower reaching militarily. significant age
annually: male:228
female: 220 (2010 est.)
Military—note: defense is the responsibility of
the UK; the Royal Gibraltar Regiment replaced
the last British regular infantry forces in 1992','4a24c2fe520d910466b4ab3579a431d2ae974c2621c80397b599026ef6f6bbf0','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cc9145c0e5217522366134d5bea634534f1767b90846a07d97240046ce380ebd',2025,'GR','Greece','military-and-security',699,'Military branches: Hellenic Army (Ellinikos
Stratos, ES), Hellenic Navy (Elliniko Polemiko
Navtiko, EPN), Hellenic Air Force (Elliniki Pole-
miki Aeroporia, EPA) (2013)
Military service age and obligation: 19-45
years of age for compulsory military service; during
wartime the law allows for recruitment beginning
January of the year of inductee’s 18th birthday,
thus including 17 year olds; 18 years of age for vol-
unteers; conscript service obligation is 1 year for all
` services; women are eligible for voluntary military
service (2012)','d87a73391162f4ae6cd4dd06a28433b5426e6a33ff2dc2bd5437cc616d824108','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4eab516b478a43ae645975d0c7f6375e503bcaf04d099a22861252f1c0364160',2025,'GL','Greenland','military-and-security',704,'Military branches: no regular military forces
Manpower available for military service:
males age 16-49: 15,280 (2010 est.)
Manpower fit for military service: males age
16-49: 10,765
females age 16-49: 11,399 (2010 est.)
Manpower reaching militarily significant age
annually: male: 488
female: 478 (2010 est.)
Military—note: defense is the responsibility of','eacd771a4a03bbdb0aac90b4dfa26b385864e348581af6ffeb37281de5fe74cb','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5980a039fa323db387ade50d247e9b3e189dd1dc8315255c6a660ae29950a035',2025,'GD','Grenada','military-and-security',709,'Military branches: no regular military forces;
Royal Grenada Police Force (includes Coast
Guard) (2010)
Manpower available for military service:
males age 16-49: 27,468 (2010 est.)
Manpower fit for military service: males age
16-49: 22,596
females age 16-49: 22,588 (2010 est.)
Monpower reaching militarily significant age
annually: male: 995
female: 1,002 (2010 est.)
Military expenditures: NA
Manpower fit for military service: males age
16-49: 38,358
females age 16-49: 36,869 (2010 est.)
Manpower reaching militarily significant age
annually: male: 1,701
female: 1,608 (2010 est.)
Military—note: defense is the responsibility of
the US','360d81894ebb7762999b70263fd65e95bf7510d8733a2a3816871cfc127a4745','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1b20d4853942fbd618e047d6b87e0184dc64d4995a172a7aaae62a16b13216fb',2025,'GT','Guatemala','military-and-security',718,'Military branches: National Army of Guatemala
{Ejercito Nacional de Guatemala, ENG; includes
Guatemalan Navy (Marina Nacional, including
Marines), Guatemalan Air Force (Fuerza Aerea
Guatemalteca, FAG)) (2013)
Military service age and obligation: all male
citizens between the ages of 18 and 50 are liable
for military service; in practice, a selective draft
system is employed, with only a small portion of
18-year-olds conscripted; conscript service obliga-
tion varies from | to 2 years; women can serve as
officers (2013)
Manpower available for military service:
males age 16-49: 3,165,870
females age 16-49: 3,371,217 (2010 est.)
Manpower fit for military service: males age
16-49: 2,590,843
females age 16-49: 2,926,544 (2010 est.)
Manpower reaching militarily significant age
annually: male: 171,092
female: 168,151 (2010 est.)
Military expenditures: 0.4% of GDP (2009)
country comparison to the world; 166','5246e282f89587ef0c8f216bd60d46b4aaf91807c593743ac4353ccda48d8655','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6a0e0119d23146e546abf5a130d5a778465a6dd14c38bef92c8d2f1a588d4f8a',2025,'SL','Sierra Leone','military-and-security',727,'Manpower fit for military service: males age
16-49: 12,493
females age 16-49: 12,272 (2010 est.)
Manpower reaching militarily significant age
annually: male: 354
female: 342 (2010 est.)
Military—note: defense is the responsibility of
the UK
Military branches: Republic of Sierra Leone
Armed Forces (RSLAF): Army (includes Maritime
Wing and Air Wing) (2013)
Military service age and obligation: 18 is the
legal minimum age for voluntary military service
(younger with parental consent); women are eli-
gible to serve; no conscription; candidates must be
HIV negative (2012)
Manpower available for military service:
males age 16-49: 1,183,093 (2010 est.)
Manpower fit for military service: males age
16-49: 731,898
females age 16-49; 838,032 (2010 est.)
Manpower reaching militarily significant age
annually: male: 54,212
female: 57,154 (2010 est.)
Military expenditures: 0.6% of GDP (2011)
country comparison to the world: 159','bb534861fe27904ebcccc7c57e1917c885433527b38ee2dc7b7f55edd02b6918','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('92af6656e3895d25bea7f9df060073e925d57a71bd768fb07e342ef269ce888f',2025,'GN','Guinea','military-and-security',735,'Military branches: National Armed Forces:
Army, Navy (Armee de Mer or Marine Guineenne,
includes Marines), Guinean Air Force (Force Aer-
ienne de Guinee) (2009)
Military service age and obligation: 18-25 years
of age for compulsory and voluntary military ser-
vice; 18-month conscript service obligation (2012)
Manpower availabie for military service:
males age 16-49: 2,359,203
females age 16-49: 2,329,784 (2010 est.)
Manpower fit for military service: males age
16-49: 1,493,991
females age 16-49: 1,535,418 (2010 est.)
Manpower reaching militarily significant age
annually: male: 118,443
female: 115,901 (2010 est.)
Military expenditures: 3.4% of GDP (2011)
country comparison to the world: 35','c974d36e8f86fc5ef07559595974af71707307229f0ac3e56947f705e1b8fbb0','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('992f96ff0668c424932c47bfeaaf4b78013ce8a7bdb9e64a59cdde1b2321d26d',2025,'GW','Guinea-Bissau','military-and-security',745,'Military branches: People’s Revolutionary
Armed Force (FARP): Army, Navy, National Air
Force (Forca Aerea Nacional); Presidential Guard
(2012)
Military service age and obligation: 18-25 years
of age for selective compulsory military service
(Air Force service is voluntary); 16 years of age
or younger, with parental consent, for voluntary
service (2013)
Manpower available for military service:
males age 16-49: 370,790
females age 16-49: 372,171 (2010 est.)
Manpower fit for. military service: males age
16-49: 205,460
females age 16-49: 212,277 (2010 est.)
Manpower reaching militarily significant age
annually: male: 17,639
female: 17,865 (2010 est.)
Military expenditures: 4.3% of GDP (2011)
country comparison to the world: 22','410d31ce56b26f97045c897a27e0faec7980bd79b23ba296b376ae6f6b8ece3d','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('43e2c8386a5447f67c1971b00b34aa095432c0d3473076d4985e64708fa2e39d',2025,'GY','Guyana','military-and-security',755,'Military branches: Guyana Defense
Force: Army (includes Air Corps, Coast Guard)
(2012) i
Military service age and obligation: 16 years of
age or younger for voluntary military service; no
conscription (2013)
Manpower available for military service:
males age 16-49: 189,840 (2010 est.)
Manpower fit for milltary service: males age
16-49: 133,239
females age 16-49: 147,719 (2010 est.)
Manpower reaching militarily significant age
annually: male: 8,849
female: 8,460 (2010 est.)
Military expenditures: 1.9% of GDP (2011)
country comparison to the world: 69','e1f6d28161fcf54018c10b8604f04422be86efc0df4791a7a0c1c0cf3a342c7f','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8e1687dacbefd2c0148aeaeb2854c95856ddc53bf67b9e92076b77b4176c9360',2025,'HT','Haiti','military-and-security',760,'Military branches: no regular military forces—
small Coast Guard; a Ministry of National Defense
established May 2012; the regular Haitian Armed
Forces (FAdH)—Army, Navy, and Air Force—
have been demobilized but still exist on paper
until or unless they are constitutionally abolished
(2011)
Manpower avaliable for military service:
males age 16-49: 2,398,804
females age 16-49; 2,415,039 (2010 est.)
Manpower fit for military service: males age
16-49: 1,666,324
females age 16-49: 1,704,364 (2010 est.)
Manpower reaching militarily significant age
annually: male: 115,246
female: 115,282 (2010 est.)
Military expenditures: 0.4% of GDP (2006)
country comparison to the world: 165','06b5465f32d9d8c7d804918d6391544a722c7b3c6d740eab657c990fa32db577','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('194e9e2b27a4ba06357896940412a4ed23e5326baf3523b323cee8bbdb1e25bd',2025,'VA','Holy See (Vatican City State)','military-and-security',772,'Military branches: Pontifical Swiss Guard Corps
(Corpo della Guardia Svizzera Pontificia) (2013)
Military service age and obligation: Pontifical
Swiss Guard Corps (Corpo della Guardia Svizzera
Pontificia): 19-30 years of age for voluntary mili-
tary service; no conscription; must be Roman
Catholic, a Swiss citizen, with a secondary educa-
tion (2013)
Military—note: defense is the responsibility of
Italy; ceremonial and limited security duties per-
formed by Pontifical Swiss Guard','3e49a92f27804127987f602055a7595648c9a00a3ee073c7ec6ddfadf7db7d32','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5c282dce148c04fd1e50342e5f81a4b340f0cef226fea4a499b03741ab3ca83f',2025,'HN','Honduras','military-and-security',781,'Military branches: Honduran Armed Forces
(Fuerzas Armadas de Honduras, FFAA): Army,
Navy (includes Naval Infantry), Honduran Air
Force (Fuerza Aerea Hondurena, FAH) (2012)
Military service age and obligation: 18 years of
age for voluntary 2-to 3-year military service; no
conscription (2012)
Manpower available for military service:
males age 16-49: 2,045,914
females age 16-49: 1,991,418 (2010 est.)
Manpower fit for military service: males age
16-49: 1,525,578
females age 16-49: 1,539,688 (2010 est.)
Manpower reaching militarily significant age
annually: male: 95,895
female: 92,087 (2010 est.)
Military expenditures: 1.5% of GDP (2012)
country comparison to the world: 95','7c74603c1538b5eca784690788a35a926365cb3e40038732ddf798168aa21fd7','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0c8a677a7b32072d44dddea2b65dae444c3d561700b61fed9fc418b2dc06ebf5',2025,'HK','Hong Kong','military-and-security',791,'Military branches: no regular indigenous military
forces; Hong Kong garrison of China’s People’s
Liberation Army (PLA) includes elements of the
PLA Ground Forces, PLA Navy, and PLA Air
Force; these forces are under the direct leadership
of the Central Military Commission in Beijing
and under administrative control of the adjacent
Guangzhou Military Region (2012)
Manpower available for military service:
males age 16-49: 1,704,090
females age 16-49: 1,873,175 (2010 est.)
Manpower fit for military service: males age
16-49: 1,387,213
females age 16-49: 1,505,875 (2010 est.)
Manpower reaching militarily significant age
annually: male: 39,579
female: 36,554 (2010 est.)
Military expenditures: NA
Mititary—note: defense is the responsibility of','ec4952aad2f9e41bb50c18bdf6769456ae414c65ffc9e1609fa891a41bf8fbd9','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f4e86b58a55ac1cd91f56abf90f7750ab18177b2f0cc0c246efbc684a38aba4a',2025,'HU','Hungary','military-and-security',798,'Military branches: Hungarian Defense Forces:
Land Forces, Hungarian Air Force (Magyar Legi-
ero, ML) (2011)
Military service age and obligation: 18-25 years
of age for voluntary military service; no conscrip-
tion; 6-month service obligation (2012)
Manpower available for military service:
males age 16-49: 2,349,948 - r
females age 16-49: 2,290,568 (2010 est.)
Manpower fit for military service: males age
16-49: 1,902,639
females age 16-49: 1,897,378 (2010 est.)
Manpower reaching militarily significant age
annually: male: 59,237 j
female: 55,533 (2010 est.)
Military expenditures: 1.75% of GDP (2005 est.)
country comparison to the world: 83','7d5af823484813cc1d5a90e637a19d3b8bbe849f73d8217a60ebcc4f66df465d','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('79e7fc0f1a33f153fc707e580c59be54eff7d40cf23ddb0afc5ce8318232ad4d',2025,'IS','Iceland','military-and-security',805,'Military branches: no regular military forces; Icelan-
dic National Police; Icelandic Coast Guard (2013)
Manpower available for military service:
males age 16-49: 75,337 (2010 est.)
Manpower fit for military service: males age
16-49: 62,781
females age 16-49: 61,511 (2010 est.)
Manpower reaching militarily significant age
annually: male: 2,277
female: 2,200 (2010 est.)
Military expenditures: 0% of GDP (2005 est.)
country comparison to the world: 173
Military—note: Iceland has no standing mili-
tary force; all US military forces in Iceland were
withdrawn as of October 2006; defense of Iceland
remains a NATO commitment and NATO main-
tains an air policing presence in Icelandic airspace;
Iceland participates in international peacekeeping
missions with the civilian-manned Icelandic Crisis
Response Unit (ICRU) (2011)','a6e2fdadf43758a2db3ace3f4c9a8fe583abdab2c8f6fa4e5270ea2c4464af98','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9f3e2789d18b91b23e4a31789bc6cb68e56e169c70cb58359e62e9d56a6ad023',2025,'IN','India','military-and-security',814,'Military branches: Army, Navy (includes naval
air arm), Air Force, Coast Guard (2011)
Military service age and obligation: 16-18
years of age for voluntary military service (Army
171/2, Air Force 17, Navy 161/2); no conscription;
women may join as officers, but for noncombat
roles only (2012)
Manpower available for military service:
males age 16-49: 319,129,420
females age 16-49: 296,071,637 (2010 est.)
Manpower fit for military service: males age
16-49: 249,531,562
females age 16-49: 240,039,958 (2010 est.)
Manpower reaching militarily significant age
annually: male: 12,151,065
female: 10,745,891 (2010 est.)
Military expenditures: 1.8% of GDP (2012)
country comparison to the world: 81
TRANSNATIONAL
Disputes—international: since China and
India launched a security and foreign policy dia-
logue in 2005, consolidated discussions related
to the dispute over most of their rugged, mili-
tarized boundary, regional nuclear proliferation,
Indian claims that China transferred missiles
to Pakistan, and other matters continue; Kash-
mir remains the site of the world’s largest and
most militarized territorial dispute with por-
tions under the de facto administration of China
(Aksai Chin), India (Jammu and Kashmir), and
Pakistan (Azad Kashmir and Northern Areas);
India and Pakistan resumed bilateral dialogue
in February 2011 after a two-year hiatus, have
maintained the 2003 cease-fire in Kashmir, and
continue to have disputes over water sharing of
the Indus River and its tributaries; UN Military
Observer Group in India and Pakistan has main-
tained a small group of peacekeepers since 1949;
India does not recognize Pakistan’s ceding his-
toric Kashmir lands to China in 1964; to defuse
tensions and prepare for discussions on a mari-
time boundary, India and Pakistan seek techni-
cal resolution of the disputed boundary in Sir
Creek estuary at the mouth of the Rann of Kutch
in the Arabian Sea; Pakistani maps continue to
show its Junagadh claim in Indian Gujarat State;
Prime Minister Singh''s September 2011 visit to
Bangladesh resulted in the signing of a Protocol
to the 1974 Land Boundary Agreement between
India and Bangladesh, which had called for the
settlement of longstanding boundary disputes
over undemarcated areas and the exchange of
territorial enclaves, but which had never been
implemented; Bangladesh referred its maritime
boundary claims with Burma and India to the
International Tribunal on the Law of the Sea;
Joint Border Committee with Nepal continues
to examine contested boundary sections, includ-
ing the 400 square kilometer dispute over the
source of the Kalapani River; India maintains
a strict border regime to keep out Maoist insur-
gents and control illegal cross-border activities
from Nepal
Refugees and internally displaced persons:
refugees (country of origin): 100,003 (Tibet/
Chiria); 68,152 (Sri Lanka); 9,161 (Afghanistan):
6,621 (Burma) (2011)
IDPs: at least 506,000 (about half are Kashmiri .
Pandits from Jammu and Kashmir) (2012)
liticit drugs: world’s largest producer of licit
opium for the pharmaceutical trade, but an
_ undetermined quantity of opium is diverted to
illicit international drug markets; transit point for
illicit narcotics produced in neighboring countries
and throughout Southwest Asia; illicit producer
of methaqualone; vulnerable to narcotics money
laundering through the hawala system; licit keta-
mine and precursor production
INDIAN OCEAN','8fb73f42dbb04617de06534e58de7406bea55ff5eab404f89e7493fd94646ae5','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('53a2ffe96ea79223e7c84d4550b92acd7809c27ab931ac8fb6eef3fa430b9dc5',2025,'IQ','Iraq','military-and-security',826,'Military branches: Counterterrorism Ser-
vice Forces: Countertertorism Command; Iraqi
Special Operations Forces (ISOF); Ministry of
Defense Forces: Iraqi Army (includes Army Avia-
tion Directorate, former National Guard Iraqi
Intervention Forces, and Strategic Infrastructure
Battalions), Iraqi Navy (former Iraqi Coastal
Defense Force, includes Iraq Marine Force), Iraqi
Air Force (Al-Quwwat al-Jawwiya al-lragiya)
(2011) :
Military service age and obligation: 18-40 years
of age for voluntary military service; no conscrip- `
tion (2012)
Manpower available for military service:
males age 16-49: 7,767,329
females age 16-49: 7,461,766 (2010 est.)
Manpower -fit for military service: males age
16-49: 6,591,185
females age 16-49: 6,421,717 (2010 est.)
Manpower reaching militarily significant age
annually: male: 332,194
female: 322,010 (2010 est.)
Military expenditures: 8.6% of GDP (2006)
country comparison to the world: 6','3e49bd65b8118b993f1421e0c047f3286a2c02ff0aede561c114108d00adebda','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5dd7884b8c3e8a79c23c29f55ba31961e02e44fa8a2a7da3e4e0a763191928b2',2025,'IE','Ireland','military-and-security',832,'Military branches: Irish Defense Forces (Oglaigh
na h-Eireannn), Permanent Defence Force: Army,
Naval Service, Air Corps (2012)
Military service age and obligation: 17-25
years of age for male and female voluntary mili-
tary service (17-27 years of age for the Naval Ser-
vice); enlistees 16 years of age can be recruited for
apprentice specialist positions; 17-35 years of age
for the Reserve Defense Forces (RDF); maximum
obligation 12 years (5 years IDE 7 years RDF); EU
citizenship or 5-year residence in Ireland required
(2012)
Manpower available for military service:
males age 16-49: 1,179,125
females age 16-49: 1,163,728 (2010 est.)
Manpower fit for military service: males age
16-49: 977,631
females age 16-49: 965,900 (2010 est.)
Manpower reaching militarily significant age
annually: male: 28,564
female: 27,197 (2010 est.)
Military expenditures: 0.9% of GDP (2005 est.)
country comparison to the world: 139','be430b3e110fa792e7804a042e0aeaa9dcb9427ecd3eaa099aae4b9a2f4b24a7','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('04af838f44a1820d4753d47e50da9ceb1d68a44a9910bd783629c2c76647d234',2025,'IM','Isle of Man','military-and-security',841,'Manpower fit for military service: males age
16-49: 15,206
females age 16-49: 15,127 (2010 est.)
Manpower reaching militarily significant age
annually: male: 507
female: 494 (2010 est.)
Military—note: defense is the responsibility of
the UK','78ab3fb8d3d7fd2f9bdc3172c215e747216bad97cb57a46bf11aced65db7f9c4','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ead36d1692ef6d3ea8e84420171ebc5c38dae44c119e2a14f4a0c6593b1a68ed',2025,'IL','Israel','military-and-security',849,'Military branches: Israel Defense Forces (IDF),
Israel Naval Force (IN), Israel Air Force (LAF) (2010)
Military service age and obligation: 18 years of
age for compulsory (Jews, Druzes) military service;
17 years of age for voluntary (Christians, Muslims,
Circassians) military service; both sexes are obli-
gated to military service; conscript service obli-
gation—36 months for enlisted men, 21 months
for enlisted women, 48 months for officers; pilots
commit to 9 years service; reserve obligation to age
41-51 (men), 24 (women) (2013)
Manpower available for military service:
males age 16-49: 1,797,960
females age 16-49: 1,713,230 (2010 est.)
Manpower fit for military service: males age
16-49: 1,517,510
females age 16-49: 1,446,132 (2010 est.)
Manpower reoching militarily significant age
annually: male: 62,304
female: 59,418 (2010 est.)
Military expenditures: 7.4% of GDP (2012)
country comparison to the world: 7
Manpower fit for military service:
males age 16-49: 579,248
females age 16-49: 547,782 (2010 est.)
Manpower reaching militarily significant age
annuaily: male: 30,925
female: 29,440 (2010 est.)
Military expenditures: NA','fcad7b773012d6cb912588df1e59e13dd3ed9139f824b8d84a6dc8aa69b8f84c','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bd1af1f6f538f71f6c56cf977ed50418029da0f6dbc1823dc81ee7bf781d0ad8',2025,'IT','Italy','military-and-security',859,'Military branches: Italian Armed Forces: Army
(Esercito Italiano, EI), Navy (Marina Militare
Italiana, MMI), Italian Air Force (Aeronautica
Militare Italiana, AMI), Carabinieri Corps (Arma
dei Carabinieri, CC) (2011)
Military service age and obligation: 18-25 years
of age for voluntary military service; women may
serve in any military branch; Italian citizenship
required; 12-month service obligation (2013)
Manpower available for military service:
males age 16-49: 13,865,688
females age 16-49: 14,003,755 (2010 est.)
Manpower fit for military service: males age
16-49: 11,247,446
females age 16-49: 11,348,695 (2010 est.)
Manpower reaching militarily significant age
annually: male: 288,188
female: 281,671 (2010 est.)
Military expenditures: 1.8% of GDP (2005 est.)
country comparison to the world: 80','8afc66f2c6edfe4ee97a2358f18cd36686abefd551aed96162715d9644e102e3','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e1d98e65cadd927826d20c5c32f6ba07a1c3e457027019954aefdd80c08d6f5d',2025,'JP','Japan','military-and-security',881,'Military branches: Japanese Ministry of Defense
(MOD): Ground Self-Defense Force (Rikujou Jiei-
tai, GSDF), Maritime Self-Defense Force (Kaijou
Jieitai, MSDF), Air Self-Defense Force (Koukuu
Jieitai, ASDF) (2011)
Military service age and obligation: 18 years of
age for voluntary-military service; no conscription;
mandatory retirement at age 53 for senior enlisted
personnel and at 62 years for senior service offic-
ers (2012)
Manpower available for military service:
males age 16-49: 27,301,443
females age 16-49: 26,307,003 (2010 est.)
Manpower fit for military service: males age
16-49: 22,390,431
females age 16-49: 21,540,322 (2010 est.)
Manpower reaching militarily significant age
annually: male: 623,365
female: 591,253 (2010 est.)
Military expenditures: 1% of GDP (2012)
country comparison to the world: 124','1494ae6a6d130f104b867389d8d0d0a502a2c0ec2e6514cc2a0c694f248919c4','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f6bf4ebe5d04e4ea9a1ffab9811633c23c29bcf7e484bd179bb3750c30d5fb8b',2025,'JE','Jersey','military-and-security',890,'Manpower fit for military service: males age
16-49: 18,688
females age 16-49: 18,615 (2010 est.)
Manpower reaching militarily significant age
annually: male: 664
female: 590 (2010 est.)
Military—note: defense is the responsibility of
the UK
Military branches: Umbutfo Swaziland Defense
Force (USDF): Ground Force (includes Air Wing)
(2013)
Military service age and obligation: 18-30 years
of age for male and female voluntary military service;
no conscription; compulsory HIV testing required,
only HIV-negative applicants accepted (2010)
Manpower available for military service:
males age 16-49: 344,038 (2010 est.)
rejected the introduction of the euro in a 2003
referendum.','79ce8817d2ad65eb3c63415003da77cf86ad91dc604b4bac5cd36bee44187af9','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0762e09eef40685bfca726f3f6bf5072b14534c5bebf7e3bdf5690105d4aeb4a',2025,'JO','Jordan','military-and-security',898,'Military branches: Jordanian Armed Forces
(JAF): Royal Jordanian Land Force (RJLF), Royal
Jordanian Navy, Royal Jordanian Air Force {Al-
Quwwat al-Jawwiya al-Malakiya al-Urduniya,
RJAF), Special Operations Command (Socom);
Public Security Directorate (normally falls under
Ministry of Interior, but comes under JAF in war-
time or crisis) (2013)
Military service age and obligation: 17 years of
age for voluntary male military service; initial service
term 2 years, with option to reenlist for 18 years; con-
scription at age 18 suspended in 1999; women not
subject to conscription, but can volunteer to serve in
noncombat military positions in the Royal Jordanian
Arab Army Women’s Corps and RJAF (2013)
Manpower available for military service:
males age 16-49: 1,674,260
females age 16-49: 1,611,315 (2010 est.)
Manpower fit for military service: males age
16-49: 1,439,192
females age 16-49: 1,384,500 (2010 est.)
Manpower reaching militarily significant age
annually: male: 73,574
female: 69,420 (2010 est.)
Military expenditures: 9.5% of GDP (2012)
country comparison to the world: 4','b3d25bbc820a0f7d9c9b584f3258ff728ab973c6f456ec458a15daab7082cf83','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4368ca7359a72cf8ac464a28053841438a78b65c5e9e0d5abd605fcad509d8b2',2025,'KZ','Kazakhstan','military-and-security',904,'Military branches: Kazakhstan Armed Forces:
Ground Forces, Navy, Air Mobile Forces, Air
Defense Forces (2013)
Military service age and obligation: 18 years
of age for compulsory military service; conscript
service obligation—-2 years; minimum age for
volunteers NA (2004)
Manpower available for military service:
males age 16-49: 4,163,629
females age 16-49: 4,179,051 (2010 est.)
Manpower fit for military service: males age
16-49: 2,909,999
females age 16-49: 3,528,169 (2010 est.)
Manpower reaching militarily significant age
annually: male: 125,322
female: 119,541 (2010 est.)
Military expenditures: 1.1% of GDP (2010)
country comparison to the world: 121','aaf118b14bf91c5308aff82d52c43721cc1aa759e24787a653b0480f3943d918','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f7ac2d1d09da3784728d6f8fd35a28ccc0fa990e3a32312b8f5edac8708c02d0',2025,'KE','Kenya','military-and-security',914,'Military branches: Kenya Defence Forces: Kenya
Army, Kenya Air Force, Kenya Navy (2012)
Military service age and obligation: 18-26
years of age for male and female voluntary service
(under 18 with parental consent), with a 9-year
obligation (7 years for Kenyan Navy); applicants
must be Kenyan citizens and provide a national
identity card (obtained at age 18) and a school-
leaving certificate; women serve under the same
terms and conditions as men; mandatory retire-
ment at age 55 (2012)
Manpower available for military service:
males age 16-49: 9,768,140
females age 16-49: 9,466,257 (2010 est.)
Manpower fit for military service: males age
16-49: 6,361,268
females age 16-49: 6,106,870 (2010 est.)
Manpower reaching militarily significant age
annually: male: 422,104 :
female: 416,927 (2010 est.)
Military expenditures: 1.8% of GDP (2012)
country comparison to the world: 78','c8767a23d68e008f60046524d38a18eafadaaeff249632b94c5955ec265e9329','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7058f8b61ae8da177977d7cc26af3214887a1b485f1eec86d4ad125407ef3dea',2025,'KI','Kiribati','military-and-security',923,'Military branches: no regular military forces
(establishment prevented by the constitution);
Police Force (2011)
Manpower available for military service:
males.age 16-49: 25,190 (2010 est.)
Manpower fit for military service: males age
16-49: 18,364
females age 16-49: 20,302 (2010 est.)
Manpower recching militarily significant age
annually: male: 1,132
female: 1,120 (2010 est.)
Military expenditures: NA
Military—note: Kiribati does not have military
forces; defense assistance is provided by Australia
and NZ
TRAWSNATIONAL ISSUES
Disputes—international: none
bom
Sonka;
S Naps?
Ch ongin,
f e
Hyasan
Kanggye
af Kimeh ack,
J
* Sna
Hamnung,
"Hungaam
punch on i
PYONGYANG Siitan
Nampo, „Sonanim
*Sanwon
Kaesong .
Hacu”
x Pane oom m
as,
Military branches: North Korean People’s
Army:Ground Forces, Navy, Air Force; civil secu-
rity forces (2005)
Military service age and obligation: 18 is pre-
sumed to be the legal minimum age for compulsory
military service; 16-17 is the presumed legal mini-
mum age for voluntary service (2012)
Manpower available for military service:
males age 16-49: 6,515,279
females age 16-49: 6,418,693 (2010 est.)
Manpower fit for military service: males age
16-49: 4,836,567
females age 16-49: 5,230,137 (2010 est.)
Manpower reaching militarily significant age
annually: male: 207,737
female: 204,553 (2010 est.)
Military expenditures: NA
Military branches: Republic of Korea Army,
Navy (includes Marine Corps), Air Force (2011)
Military service age and obligation: 20-30 years
of age for compulsory military service, with middle
school education required; conscript service obli-
gation—2] months (Army, Marines), 23 months
(Navy), 24 months (Air Force); 18-26 years of age
for voluntary military service; women, in service
since 1950, admitted to 7 service branches, includ-
ing infantry, but excluded from artillery, armor,
anti-air, and chaplaincy corps; HIV-positive indi-
viduals are exempt from military service (2012)
Manpower available for military service:
males age 16-49: 13,185,794
females age 16-49: 12,423,496 (2010 est.)
Manpower fit for military service: males age
16-49: 10,864,566
females age 16-49: 10,168,709 (2010 est.)
Manpower reaching militarily significant age
annually: male: 365,760
female: 321,225 (2010 est.)
Military expenditures: 2.7% of GDP (2006)
country comparison to the world: 47','55768d2cd41082321b436f9cbc731003f2108f642738812cc8e85a9af6fd0dee','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('332fa686b568620386730e9d1fafac2cb6675c9423fad3107c14749fe02b3cef',2025,'KW','Kuwait','military-and-security',938,'Military branches: Kuwaiti Land Forces (KLF),
Kuwaiti Navy, Kuwaiti Air Force (Al-Quwwat
al-Jawwiya al-Kuwaitiya; includes Kuwaiti Air
Defense Force, KADF), Kuwaiti National Guard
(KNG) (2013)
Military service age and obligation: 17-21 years
of age. for voluntary military service; ‘conscription
suspended (2012) i
Manpower available for military service:
males age 16-49: 1,002,480
females age 16-49: 616,958 (2010 est.)
Manpower fit for military service: males age
16-49: 840,912
females age 16-49: 523,206 (2010 est.)
Manpower reaching militarily significant age
annually: male: 17,653
female: 16,232 (2010 est.)
Military expenditures: 3.7% of GDP (2012)
country comparison to the world: 30','79fd509d3c66dc8552f21f49899e159b1653e332f01f62f06b340948c5a62cb2','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0ab087a0ea920d374304b60d9e820fd19d886b2717e470fd735ad4734762243a',2025,'KG','Kyrgyzstan','military-and-security',949,'Military branches: Ground Forces, Air Force
(includes Air Defense Forces) (2013)
Military service age and obligation: 18-27 years
of ‘age for compulsory or voluntary male military
service in the Armed Forces or Interior Ministry;
service obligation—1 year, with optional fee-based
3-year service in the callup mobilization reserve;
women may volunteer at age 19; 16-17 years of age
for military cadets, who cannot take part in mili-
tary operations (2013)
Manpower available for military service:
males age 16-49: 1,456,881
females age 16-49: 1,470,317 (2010 est.)
Monpower fit for military service: males age
16-49: 1,119,224
females age 16-49: 1,257,263 (2010 est.)
Manpower reaching militarily significant age
annually: male: 56,606
female: 54,056 (2010 est.)
Military expenditures: 2.8% of GDP (2011)
country comparison to the world: 43','113f5e36495fbd7bc7449c635c0db77885ac66e9451ea77edc2bfd02603087ac','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5a4ef6dd212853b8c777ed3329e1bb44a9e82188fcddd2fe253ca045ddb7f5a0',2025,'LV','Latvia','military-and-security',963,'Military branches: National Armed Forces
(Nacionalo Brunoto Speku): Land Forces (Latvi-
jas Sauszemes Speki), Navy (Latvijas Juras Speki;
includes Coast Guard (Latvijas Kara Flotes), Lat-
vian Air Force (Latvijas Gaisa Speki), Latvian
Home Guard (Latvijas Zemessardze) (2011)
Military service age and obligation: 18 years
of age for voluntary male and female military ser-
vice; no conscription; under current law, every
citizen is entitled to serve in the armed forces for
life (2012)
Manpower available for military service:
males age 16-49: 546,090
females age 16-49: 540,810 (2010 est.)
Manpower fit for military service: males age
16-49: 401,691
females age 16-49: 447,638 (2010 est.)
Manpower reaching militarily significant age
annually: male: 10,482
female: 9,858 (2010 est.)
Military expenditures: 1.1% of GDP (2005 est.)
country comparison to the world: 122','977c77869b6b92e2b4a10aac54f2f91928d63f6e84ac75f3de5e7e74cff82e76','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('14a726332292f8c82a05c6a203b6fb13284bdddebc2313ca73d61c9879d6763e',2025,'LB','Lebanon','military-and-security',971,'Military branches: Lebanese Armed Forces
(LAF): Lebanese Army ((Al Jaysh al Lubnani)','159d623aa8f3c1c538544b7607dfc3b68eb84864db60cc5d26b069be83aacba7','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9e969365c82696c2150b429649e8744b5e7f850c4a89076856e4ae211201bf69',2025,'ZA','South Africa','military-and-security',972,'Em
i Lamine
. f feyaieyaneng
x MASERU
fe
-F
a1 Mateter 9
\\
RON EY
0 fm hn
p a
Military branches: South African National
Defenge Force (SANDF): South African Army,
South African Navy (SAN), South African Air
Force (SAAF), Joint Operations Command, Mili-
tary Intelligence, South African Military Health
Services (2009)
Military service age and obligation: 18 years.of
age for voluntary military service; women are eli-
gible to serve in noncombat roles; 2-year service
obligation (2012)
Manpower available for military service:
males age 16-49: 13,439,781
females age 16-49: 12,473,641 (2010 est.)
Manpower fit for military service: males age
16-49: 7,617,063
females age 16-49: 6,476,264 (2010 est.)
Manpower reaching militarily significant age
annually: male: 482,122
female: 485,017 (2010 est.)
Military expenditures: 1.7% of GDP (2006)
country comparison to the world: 87
Military—note: with the end of apartheid
and the establishment of majority rule, former
military, black homelands forces, and ex-oppo-
sition forces were integrated into the South
African National Defense Force (SANDF); as
of 2003 the integration process was considered
complete','248bfd1c7c88ea5087907f05764af08f3d5028392c270b58c5c84fc2399fd580','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d4117d7a53ef048f0c48c42580fc5b67db0d6222be3fde07df24247a4d312603',2025,'LS','Lesotho','military-and-security',980,'Military branches: Lesotho Defense Force (LDF):
Army (includes Air Wing) (2012)
Military service age and obligation: 18-24
years of age for voluntary military service; no con-
scription; women serve as commissioned officers
(2012)
Manpower available for military service:
males age 16-49: 472,456
females age 16-49: 508,953 (2010 est.)
Manpower fit for military service: males age
16-49: 270,184
females age 16-49: 275,734 (2010 est.)
Manpower reaching militarily significant age
annually: male: 19,110
female: 20,037 (2010 est.)
Military expenditures: 1.9% of GDP (2012)
country comparison to the world: 71
Militory—note: Lesotho’s declared policy is
maintenance of its independent sovereignty and
preservation of internal security; in practice,
external security is guaranteed by South Africa;
restructuring of the Lesotho Defense Force (LDF)
and Ministry of Defense and Public Service over
the past five years has focused on subordinating
the defense apparatus to civilian control and
restoring the LDF''’s cohesion; the restructuring
has considerably improved capabilities and pro-
fessionalism, but the LDF is disproportionately
large for a small, poor country; the government
has outlined a reduction to a planned 1,500-man
strength, but these plans have met with vociferous
resistance from the political opposition and from
inside the LDF (2008)','21b475bf5f307c7437f5408c68ece110ccb9d092791891ca8cd0a06173ff675e','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('271de5fd74697e41b54c2b828e38969058c3a601e777cc82e8b33aa452ba9877',2025,'LR','Liberia','military-and-security',990,'Military branches: Armed Forces of Liberia
(AFL): Army, Navy, Air Force
Military service age and obligation: 18 years of
age for voluntary military service; no conscription
(2012)
Manpower available for military service:
males age 16-49: 815,826
females age 16-49: 828,484 (2010 est.)
Manpower fit for military service: males age
16-49; 524,243
females age 16-49: 544,349 (2010 est.)
Manpower reaching militarily significant age
annually: male: 36,585
female: 38,516 (2010 est.)
Military expenditures: 0.8% of GDP (2011)
country comparison to the world: 151','e1769d9160a474966d450bb50917693cf48a7000ebc9f00bf20d12fccad28c34','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('00e585069f4341ca93cafc0a87c747a16f079136646e76cbaf21c0f7fe3f2d90',2025,'LY','Libya','military-and-security',999,'Military branches: note—in transition; govern-
ment attempting to staff a new national army with
anti-QADAFI militia fighters and former members
of QADAFI’s military (2008)
Military service age and obligation: 18 years of
age for mandatory or voluntary service (2012)
Manpower available for military service:
males age 16-49: 1,775,078
females age 16-49: 1,714,194 (2010 est.)
Manpower fit for military service: males age
16-49: 1,511,144
females age 16-49: 1,458,934 (2010 est)
Manpower reaching militarily significant age
annually: male: 59,547
female: 57,070 (2010 est.)
Military expenditures: 3.1% of GDP (2012)
country comparison to the world: 39','6a6dac872294606760fe03e90a25008b0886999666dfa6e5bb05775b5f460a5e','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3f6f5597ff1df1ca524d70d74d08d0b45140d0f3b1ed1f5b127c56de06b12b47',2025,'LI','Liechtenstein','military-and-security',1008,'Military branches: no regular military forces;
National Police maintains close relations with
neighboring forces (2013)
Manpower available for military service:
males age 16-49: 8,009 (2010 est.)
Manpower fit for military service: males age
16-49: 6,538
females age 16-49: 6,746 (2010 est.)
Manpower reaching militarily significant age
annually: male: 219
female: 211 (2010 est.)
Military—note: Liechtenstein has no military
forces, but the modern National Police maintains
close relations with neighboring forces. (2013)','d1d9de51e6521927ed68b9d067d4c1cf89422fa1891070d74b9571aa4d66ed91','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b804d87cec6925d6ff65ad133be2d74918f74edba48f6ca8d9727732fcb52fb0',2025,'LT','Lithuania','military-and-security',1015,'Military branches: Lithuanian Armed Forces
(Lietuvos Ginkluotosios Pajegos): Ground Forces
(Sausumos Pajegos), Naval Forces (Karines Juru
Pajegos), Air Forces (Karines Oro Pajegos),
National Defense Volunteer Forces (Krasto Apsau-
gos Savanoriu Pajegos) (2011)
Military service age and obligation: 18 years of
age for voluntary military service; service obliga-
tion 1 year; Lithuania converted to a professional
military in the fall of 2008, although the decision
continues under judicial review (2012)
Manpower available for military service:
males age 16-49: 890,074
females age 16-49: 875,780 (2010 est.)
Manpower fit for military service: males age
16-49: 669,111
females age 16-49: 724,803 (2010 est.)
Manpower reaching militarily significant: age
annually: male: 20,425
female: 19,527 (2010 est.)
Military expenditures: 0.9% of GDP (2007 est.)
country comparison to the world: 131','b0a18bbfb27227eb4a55f934f10661937c101728c4e2983dd573fea028d73058','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f5e54cb904831194381f5be1bfd3231e32397a27a6a68a7d39326b7ee8bf47a1',2025,'LU','Luxembourg','military-and-security',1020,'Military branches: Army (2010)
Military service age and obligation: 18-24
years of age for male and female voluntary military
service; no conscription; Luxembourg citizen or
EU citizen with 3-year residence in Luxembourg
(2012)
Manpower available for military service:
males age 16-49: 118,665
females age 16-49: 117,456 (2010 est.)
Manpower fit for military service: males age
16- 49: 97,290
females age 16-49: 96,361 (2010 est.)
Manpower reaching militarily significant age
annually: male: 3,263
female: 3,084 (2010 est.)
Military expenditures: 0.9% of GDP (2005 est.)
country comparison to the world: 143
Military branches: no regular military forces
Manpower available for military service:
males age 16-49: 150,780 (2010 est.)
Manpower fit for military service: males age
16-49: 124,189
females age 16-49: 149,514 (2010 est.)
Manpower reaching militarily significant age
annually: male: 4,274
female: 3,674 (2010 est.)
Military—note: defense is the responsibility of','1bebc2cd807b519227bdd8b592b81d3e714c9bc0a2ebd1653ada24fc77d4d3dd','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3077480d4824188b67ae50cf2380c5712520e4ebebbbc8f65b8f14a9af8edfa1',2025,'CN','China','military-and-security',1025,'Military branches: Army of the Republic of
Macedonia (ARM; includes General Staff and
subordinate Joint Operational Command, Train-
ing and Doctrine Command, Special Operations
Regiment) (2012)
Military service age and obligation: 18 years
of age for voluntary military service; conscription
abolished in 2008 (2013)
Manpower - available for military service:
males age 16-49: 532,196
females age 16-49: 511,964 (2010 est.)
Manpower fit for military service: males age
16-49: 443,843
females age 16-49: 426,251 (2010 est.)
Manpower reaching militarily significant age
annually: male: 16,144
female: 14,920 (2010 est.)
Military expenditures: 6% of GDP (2005 est.)
country comparison to the world: 11','f65c42b58c5226b4a3c6713de2f7b906d654236b3e6139365a7db954f6f91c79','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('13e363854841dbc2cb5a43a85175b877a6d4b51cc221d1f997135fa64de61ecc',2025,'MG','Madagascar','military-and-security',1033,'Military branches: People’s Armed Forces: Inter-
vention Force, Development Force, and Aero-
naval Force (navy and air); National Gendarmerie
Military service age and obligation: 18-25 years
of age for male-only voluntary military service; no
conscription; service obligation is 18 months for
military or equivalent civil service; 20-30 years of
age for National Gendarmerie recruits and 35 years
of age for those with military experience (2012)
Manpower available for military service:
males age 16-49: 4,900,729
females age 16-49: 4,909,061 (2010 est.)
Manpower fit for military service: males age
16-49: 3,390,071
females age 16-49: 3,682,180 (2010 est.)
Manpower reaching militarily significant age
annually: male: 248,184
female: 246,769 (2010 est.)
Military expenditures: 5.1% of GDP (2011)
country comparison to the world: 15','8b6d621486df407cde2ef37e7d805761fa8f48d0a63ad79f491ac2b97c6582b1','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6afc2a661e079386fef92e5470bb80c04cfe32ff9f766735f0b7ab7db9b5b120',2025,'MW','Malawi','military-and-security',1044,'Military branches: Malawi Defense Forces (MDF):
Army (includes Air Wing, Marine Unit) (2012)
Military service age and obligation: 18 years of
age for voluntary military service; standard obliga-
tion is 2 years of active duty and 5 years reserve
service (2012)
Manpower available for military service:
males age 16-49: 3,514,809 (2010 est.)
Manpower fit for military service: males age
16-49: 2,132,909
females age 16-49: 2,043,925 (2010 est.)
Manpower reaching militarily significant age
annually: male: 183,683
female: 183,028 (2010 est.)
Military expenditures: 0.8% of GDP (2012)
country comparison to the world: 149','d6f1c7e81b3ffe04b792b60be297c29e8a9ba4e933b2852f741685b9ec8539bb','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('41b2747ae2769d04d85ca944015b69d8a833b6e6170aae7456bcf92121f38bc9',2025,'MY','Malaysia','military-and-security',1055,'Milltary branches: Malaysian Armed Forces
(Angkatan Tentera Malaysia, ATM): Malaysian
Army (Tentera Darat Malaysia), Royal Malaysian
Navy (Tentera Laut Diraja Malaysia, TLDM),
Royal Malaysian Air Force (Tentera Udara Diraja
Malaysia, TUDM) (2011) i
Military service age and obligation: 17 years
6 months of age for voluntary military service
(younger with parental consent and proof of age);
mandatory retirement age 60; women serve in the
Malaysian Armed Forces; no conscription (2013)
Manpower available for military service:
males age 16-49: 7,501,518
females age 16-49: 7,315,999 (2010 est.)
Manpower fit for military service: males age
16-49: 6 247 306 ;
females age 16-49: 6,175,274 (2010 est.)
Manpower reaching militarily significant age
annually: male: 265,008
female: 254,812 (2010 est.)
Military expenditures: 2.03% of GDP (2005 est.)
country comparison to''the world: 65','dc97d97b24126844df5a416ca2bb765140e04e41ab23c54c90b152711a9b6fa0','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2dc3b1dc625aac3ead69f25faa318caca3e4cb778f5cceef833a31a041d5d787',2025,'MR','Mauritania','military-and-security',1065,'Military branches: Maldives National Defense
Force (MNDF): Marine Corps, Security Protec-
tion Group, Coast Guard (2010)
Military service age and obligation: 18-28 years _
of age for voluntary service; no conscription; 10th
grade or equivalent education required; must not
be a member of a political party (2012)
Manpower available for military service:
males age 16-49: 156,319
females age 16-49: 98,815 (2010 est.)
Manpower fit for military service: males age
16-49: 135,374
females age 16-49: 85,181 (2010 est.)
insecurity in host communities. A military inter-
vention to retake the three northern regions began
in January 2013 and within a month most of the
north had been retaken. Democratic elections are
scheduled for mid-2013.
Location: ‘interior Western Africa, southwest
of Algeria, north of Guinea, Cote d''lvoire, and
Burkina Faso, west of Niger
Geographic coordinates: 17 00 N, 400 W
Map references: Africa
Area: total: 1,240,192 sq km
country comparison to the world: 24
land: 1,220,190 sq km
water: 20,002 sq km
Area—comparative: slightly less than twice the
size of Texas
Land boundaries: total: 7,243 km
border countries: Algeria 1,376 km, Burkina Faso
1,000 km, Guinea 858 km, Cote d''Ivoire 532 km,
Mauritania 2,237 km, Niger 821 km, Senegal 419
km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
Climate: subtropical to arid; hot and dry (February
to June); rainy, humid, and mild (June to Novem-
ber); cool and dry (November to February)
Terrain; mostly flat to rolling northern plains
covered by sand; savanna in south, rugged hills in
northeast
Elevation extremes: lowest point: Senegal River
23m
highest point: Hombori Tondo 1,155 m
Natural resources: gold, phosphates, kaolin, salt,
limestone, uranium, gypsum, granite, hydropower
note: bauxite, iron ore, manganese, tin, and copper
deposits are known but not exploited
Land use: arable land: 5.53%
permanent crops: 0.1%
other: 94.37% (2011)
Irrigated land: 2,358 sq km (2003)
Total renewable water resources: 100 cu km
(2011)
Freshwater withdrawal (domestic/industrial/
agricultural): total: 6.55 cu km/yr (9%/1%/90%)
Manpower reaching militarily significant age
annually: male: 4,167
female: 3,595 (2010 est.)
Military expenditures: 5% of GDP (2009)
country comparison to the world: 16
Military—note: the Maldives National Defense
Force (MNDF), with its small size and with little
serviceable equipment, is inadequate to prevent
external aggression and is primarily tasked to
reinforce the Maldives Police Service (MPS) and
ensure security in the exclusive economic zone
(2000)
THANSNATIONAL ISSUES
Disputes—international: none
per capita: 545.4 cu m/yr (2000)
Natural hazards: hot, dust-laden harmattan haze
common during dry seasons; recurring droughts;
occasional Niger River flooding
Environment—current issues: deforestation;
soil erosion; desertification; inadequate supplies of
potable water; poaching =
Environment—international agreements:
party to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Endan-
gered Species, Hazardous Wastes, Law of the Sea,
Ozone Layer Protection, Wetlands, Whaling
signed, but not ratified: none of the selected
agreements
Geography—note: landlocked; divided into three
natural zones: the southem, cultivated Sudanese;
the central, semiarid Sahelian; and the northern,
arid Saharan
Military branches: Mauritanian Armed Forces:
Army, Mauritanian Navy {Marine Mauritanienne;
includes naval infantry), Islamic Air Force of Mau-
titania (Force Aerienne Islamique de Mauritanie,
FAIM) (2010)
Military service age and obligation: 18 is the
legal minimum age for voluntary military service;
no conscription (2012)
Manpower available for military service:
males age 16-49: 718,713
females age 16-49: 804,622 (2010 est.)
Manpower fit for military service: males age
16-49: 480,042
females age 16-49: 581,473 (2010 est.)
Manpower reaching militarily significant age
annually: male: 36,116
female: 36,826 (2010 est.)
Military expenditures: 5.5% of GDP (2006)
country comparison to the world: 13','4aba585f8cec77a8b5bf47c3e402bcbdae08e692ac8ca902a9ada59acd9ddb50','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('134419b60dd0dbc6c4723aca9e8870d545803d557634038daa3968ae69627939',2025,'ML','Mali','military-and-security',1073,'Military branches: Malian Armed Forces: Army
(Armee de Terre), Republic of Mali Air Force
(Force Aerienne de ka Republique du Mali,
FARM), National Guard (Garde National du
Mali) (2008)
Military service age and obligation: 17 years of
age for selective compulsory and voluntary mili-
tary service; conscript service obligation—z2 years
(2012)
Manpower available for military service:
males age 16-49: 2,848,412
females age 16-49: 2,981,106 (2010 est.)
Manpower fit for military service: males age
16-49: 1,825,779
females age 16-49: 1,968,563 (2010 est.)
Manpower reaching militarity significant age
annually: male: 158,031
female: 159,733 (2010 est.)
Military expenditures: 1.3% of GDP (2012)
country comparison to the world: 113','c11bda8a49f51aaeaa5f818b60108a44c82894a6d63d14e8b08f0f3a6385e91b','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7946a59095de51509cd6c007b8cdd37355c9e06d207eecfc6b130906a078dcb5',2025,'MT','Malta','military-and-security',1082,'Military branches: Armed Forces of Malta (AFM;
includes air and maritime elements) (2010)
Military service age and obligation: 17 years
6 months of age for voluntary military service; no
conscription (2013)
Manpower available for military service:
males age 16-49: 95,499
females age 16-49: 90,919 (2010 est.)
Manpower fit for military service: males age
16-49: 79,645
females age 16-49: 75,684 (2010 est.)
Manpower reaching militarily significant age
annually: male: 2,554
female: 2,385 (2010 est.)
Military expenditures: 0% of GDP (2012)
country comparison to the world: 172','b4f8ec56a7e4e34a422e5c40632d704a257d8abf1dbb7b3198387b323df65bee','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2711aca4069872483a0288a38b292ba884b3fb22a43160b0c2e41cee79d62656',2025,'MH','Marshall Islands','military-and-security',1092,'Military branches: no regular military forces;
Marshall Islands Police (2012)
Manpower available for military service: males
age, 16-49: 16,446 (2010 est.)
Manpower fit for military service: males age
16-49; 13,568
females age 16-49: 13,606 (2010 est.)
Manpower reaching militarily significant age
annually: male: 653
female: 631 (2010 est.)
Military expenditures: NA
Military—note: defense is the responsibility of
the US','1d2c23de987fc5e14c84e59eddd2b260212d2ed4b5719de4e0a0bd6717ca1342','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('778b85984878a3e5b7e43ea4d3689f5547d587c67a7f7955e53cb89433a4344f',2025,'MU','Mauritius','military-and-security',1102,'Military branches: no regular military forces;
Mauritius Police Force, Special Mobile Force,
National Coast Guard (2011)
Manpower available for military service:
males age 16-49: 343,628 (2010 est.)
Manpower fit for military service: males age
16-49: 280,596
females age 16-49: 283,317 (2010 est.)
Manpower reaching militarily significant age
annually: male: 10,193
female: 10,104 (2010 est.)
Military expenditures: 0.1% of GDP (2012)
country comparison to the world: 171','ff1a48f0ba4fac438375d9de1424b3b184bcda3faa83dc3e35a776ac57ba70a4','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f799bc215d87e91686f365cf33135f8ae5ca8387628bfcba480788da5fd955e0',2025,'RO','Romania','military-and-security',1114,'Military branches: National Army: Land Forces
Command, Air Forces Command (includes air
defense unit), Logistics Command (2013)
Military service age and obligation: 18 years of
age for compulsory or voluntary military service;
male registration required at age 16;
O.year service obligation (2012)
Manpower available for military service: males
age 16-49: 1,143,440 females age 16-49: 1,156,958
(2010 est.)
Manpower fit for military service: males age
16-49: 875,224 females age 16-49: 969,903 (2010
est.)
Manpower reaching militarily significant age
annually: male: 28,213
female: 26,614 (2010 est.)
Military expenditures: 0.4% of GDP (2005 est.)
country comparison to the world: 165
Military branches; Land Forces, Naval Forces
(Fortele Naval, FN), Romanian Air Force (Fortele
Aeriene Romane, FAR) (2013)
Military service age and obligation; 20-35
years of age for compulsory male military service;
conscription ended 2006, but military service
remains mandatory; 18 years of age for male and
female voluntary service; all military inductees
(including women) contract for an initial 5-year
term of service, with subsequent successive 3-year
terms until age 36 (2012)
Manpower available for military service:
males age 16-49: 5,601,234
females age 16-49: 5,428,939 (2010 est.)
Manpower fit for military service:
males age 16-49: 4,550,409
females age 16-49: 4,507,880 (2010 est.)
Manpower reaching militarily significant age
annually: male: 117,798
female: 1 11,607 (2010 est.)
Military expenditures: 1.9% of GDP (2007 est.)
country comparison to the world: 73
Military branches: Ground Forces (Sukhoput-
nyye Voyskia, SV), Navy (Voyenno-Morskoy Flot,
VMF), Air Forces (Voyenno-Vozdushniye Sily,
VVS); Airborne Troops (Vozdushno-Desantnyye
Voyska, VDV), Strategic Rocket Forces (Raket-
nyye Voyska Strategicheskogo _Naznacheniya,
RVSN), and Aerospace Defense Troops (Voyska
Vozdushno-Kosmicheskoy Oborony or Voyska
VKO) are independent “combat arms,” not sub-
ordinate to any of the three branches; Russian
Ground Forces include the following combat arms:
motorized-rifle troops, tank troops, missile and
artillery troops, air defense of the ground troops ‘
(2012)
Military service age and obligation: 18-27 years
of age for compulsory or voluntary military service;
males are registered for the draft at 17 years of age;
service obligation is 1 year (conscripts can only be
sent to combat zones after 6 months of training);
reserve obligation to age 50; enrollment in mili-
tary schools from the age of 16, cadets classified as
members of the armed forces
604
THE CIA WORLD FACTBOOK
note: the chief of the General Staff Mobilization
Directorate announced in March 2009 that for
health reasons, only 65% of draftees in 2008 were
fit for military service, and over half of these had
health-induced restrictions on deployment; the
deputy chief of the Russian Army General Staff
confirmed in May 2011 that over 30% of potential
conscripts were turned down on health grounds;
61% of draft-age Russian males receive some type
of deferment each draft cycle (2012)
Manpower available for military service: males
age 16-49: 34,132,156
females age 16-49: 34,985,1 15 (2010 est.)
Manpower fit for military service:
males age 16-49; 20,431,035
females age 16-49: 26,381,518 (2010 est.)
Manpower reaching militarily significant age
annually: male: 693,843
female: 660,359 (2010 est.)
Military expenditures: 3.9% of GDP (2005)
country comparison to the world: 25','d8ed79afd3bf5454ff582c102a5e6c6e18662115898d1e13939a566d10e75dfa','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5f198879b5bcb1103b695fcc343d7f1ef9e07ce59d3339e7d65fb6296b1c096a',2025,'MC','Monaco','military-and-security',1121,'Military branches: no regular military forces;
Directorate of Public Security (2012)
Manpower available for. military service:
males age 16-49: 5,749 (2010 est.)
Manpower fit for military service: males age
16-49: 4,629
females age 16-49: 4,597 (2010 est.)
Manpower reaching militarily significant age
annually: male: 153
female: 141 (2010 est.)
Military—note: defense is the responsibility of','14cd1d54d6e24b60798408c91d9da3feb955cdba56c624652d3b45c266ada43f','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d844aa90c182b0c34c4e7666bee4a2ba38f8926681e9e80a4956b279c870117f',2025,'MN','Mongolia','military-and-security',1126,'Military branches: Mongolian Armed Forces:
Mongolian Arvy, Mongolian Air Force; there is
no navy (2010)
Military service age and obligation: 18-25 years
of age for compulsory and voluntary military ser-
vice; conscript service obligation is 12 months in
land or air defense forces or police; a small portion
of Mongolian land forces (2.5 percent) is comprised
of contract soldiers; women cannot be deployed
overseas for military operations (2012)
Manpower available for military service:
males age 16-49: 898,546
females age 16-49: 891,192 (2010 est.)
Manpower fit for military service: males age
16-49: 726,199
females age 16-49: 756,628 (2010 est.)
Manpower reaching militarily significant age
annually: male: 30,829
female: 29,648 (2010 est.)
Military expenditures: 0.8% of GDP (2012)
country comparison to the world: 150','33b9f737da1c274aa48b67529ed96841652a2b26797e9504694bd63e5d8393a1','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('88bd7870b489091f485f1879752b68579d2ec00a656c4ef835e74cff80c41680',2025,'ME','Montenegro','military-and-security',1135,'Military branches: Armed Forces of the Republic
of Montenegro: Army of Montenegro (includes
Montenegrin Navy (Mornarica Crne Gore,
MCG)), Air Force (2011)
Military service age and obligation: 18 is the
legal minimum age for voluntary military service;
no conscription (2012)
Manpower fit for military service: males age
16-49: 149,159
females age 16-49: 131,823 (2010 est.)
Manpower reaching Military significant age
annually: male:3,120
female: 3,677 (2010 est.)','6ada609b634044705242f1aa4c487395969373f8791cb8891fc55f1389e36e57','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('72fc67d85cd121abb6204ac8af114018f86f1b49e913d0e33c4736d3d0714827',2025,'MS','Montserrat','military-and-security',1145,'Military branches: no regular military forces;
Royal Montserrat Police Force (2011)
Manpower available for military service:
males age 16-49: 1,3 53 (2010 est.)
Manpower fit for military service: males age
16-49: 1,135
females age 16-49: 1,223 (2010 est.)
Manpower reaching militarily significant age
annually: male: 35
female: 34 (2010 est.)
Military—note: defense is the responsibility of
the UK','3d0684728184c77f987d9f8f1705f97939d9b9809db3952d490e7c1186be0af2','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('84adb83c0d1df846c54f2665d2d78138a5b3a588f2b8151bc7d74cf417fb5367',2025,'MA','Morocco','military-and-security',1154,'Military branches: Royal Armed Forces (Forces
Armees Royales, FAR): Royal Moroccan Army
(includes Air Defense), Royal Moroccan Navy
(includes Coast Guard, Marines), Royal Moroc-
can Air Force (Al Quwwat al Jawyiya al Malakiya
503
Marakishiya; Force Aerienne Royale Marocaine)
(2010)
Military service age and obligation: 20 years of
age for voluntary military service; no conscription;
service obligation—18 months (2012)
Manpower available for military service:
males age 16-49: 8,252,682
females age 16-49: 8,691,419 (2010 est.)
Manpower fit for military service: males age
16-49: 7,026,016
females age 16-49: 7,377,045 (2010 est.)
Manpower reaching militarily significant age
annually: male: 300,327
female: 298,366 (2010 est.)
A
THE CIA WORLD FACTBOOK
Military expenditures: 4.8% of GDP (2012)
country comparison to the world: 18','998761cba7cd2767ecde37761e479162e998546ce250b83feb061ec81e8e44b2','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('36fcb90b8e74cb3ecac3fefbc15936df4c58229718bb8598cb5d82df583472eb',2025,'MZ','Mozambique','military-and-security',1164,'Military branches: Mozambique Armed Defense
Forces (Forças Armadas de Defesa de Mocam-
bique, FADM): Mozambique Army, Mozambique
Navy (Marinha de Guerra de Mocambique,
MGM), Mozambique Air Force (Forca Aerea de
Mocambique, FAM) (2012)
Military service age and obligation: registration
for military service is mandatory for all males and
females at 18 years of age; 18-35 years of age for
selective compulsory military service; 18 years of
age for voluntary service; 2-year service obligation;
women may serve as officers or enlisted (2012)
Manpower available for military service:
males age 16-49: 4,613,367 (2010 est.)
Manpower fit for military service: males age
16-49: 2,677,473
females age 16-49: 2,941,073 (2010 est.)
Manpower reaching militarily significant age
annually: male:274,602
female: 280,008 (2010 est.)
Military expenditures; 0.6% of GDP (2012)
country comparison to the world: 157','2b746518bd1483bdbc946303c8249191166fb03db752244a96ba3e75e52fe41b','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4b9a3546a3545111811bba15535743d365d12039986f80a1dbde52d194a2c4f8',2025,'NA','Namibia','military-and-security',1172,'Military branches: Namibian Defense Force
(NDF): Army, Navy, Air Force (2013)
Military service age and obligation: 18 years of
age for voluntary military service; no conscription
(2012)
Manpower available for military service:
males age 16-49: 568,231 (2010 est.)
Manpower fit for military service: males age
16-49: 351,431
Map references: Oceania
Area: total:21 sq km
country comparison to the world: 240
land: 21 sq km
water: 0 sq km
Area—comporative: about 0.1 times the size of
Washington, DC
Land boundaries: 0 km
Coastline: 30 km
Maritime claims: territorial sea: 12 nm
contiguous zone: 24 nm
exclusive economic zone: 200 nm
Climate: tropical with a monsoonal pattern; rainy
season (November to February)
Terrain: sandy beach rises to fertile ring around
raised coral reefs with phosphate plateau in center
Elevation extremes: lowest point: Pacific Ocean
Om
highest point: unnamed elevation along plateau
rim 61 m
Natural resources: phosphates, fish
Land use: arable land:0%
permanent crops: 20%
other: 80% (2011)
Irrigated land: NA
Natural hazards: periodic droughts
Environment—current issues: limited natural
freshwater resources, roof storage tanks collect
rainwater but mostly dependent on a single, aging
desalination plant; intensive phosphate mining
during the past 90 years—-mainly by a UK, Aus-
tralia, and NZ consortium—has left the central
90% of Nauru a wasteland and threatens limited
remaining land resources
Environment—international agreements:
party to: Biodiversity, Climate Change, Climate
females age 16-49: 311,513 (2010 est.)
Manpower reaching militarily significant age
annually: male; 26,413
female: 26,038 (2010 est.)
Military expenditures: 3.7% of GDP (2006)
country comparison to the world: 29','0ce92d90fa7a101bc77493e0dcaa3aa229da83ef6410930ce82b20f523bfcd35','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f4d84c7f3b88a5875f9113ff92f498a293bc78e38130b7f56a17df2ddb10521f',2025,'NR','Nauru','military-and-security',1178,'Military branches: no regular military forces
(2012)
Manpower available for military service:
males age 16-49: 2,542 (2010 est.)
Manpower fit for military service: males age
16-49: 1,823
females age 16-49: 2,034 (2010 est.)
Manpower reaching militarily significant age
annually: male: 74
female: 78 (2010 est.) à
Military expenditures: NA
Military—note: Nauru maintains no defense
forces; under an informal agreement, defense is the `
responsibility of Australia
Military—note: defense is the responsibility of
the US','c475a0c107e4069228cadc53e8c96a66736197d4cce7e61451471103c5816280','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e592f10884114b95ed2f6df1c000dcfc229b184cf449dfd9fe43d822a2db0340',2025,'NP','Nepal','military-and-security',1189,'Military branches: Nepal Army (2012)
Military service age and obligation: 18 years of
age for voluntary military service; 15 years of age
for military training; no conscription (2012)
Manpower available for military service:
males age 16-49: 6,941,152
females age 16-49: 7,618,397 (2010 est.)
THE CiA WORLD FACTBOOK
Manpower fit for military service: males age
16-49: 5,260,878
females age 16-49: 5,947,512 (2010 est.)
Manpower reaching militarily significant age
annually: male: 380,172
female: 367,103 (2010 est.)
Military expenditures: 1.3% of GDP (2012)
country comparison to the world: 114','580e863f839f158dea2579bdf79d3768d39e7597641b0358e2adc293938ea36f','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f0194b0fe1af778b382a494c6f8ad453b472fec76c656f9f35b57c5149dbe977',2025,'NL','Netherlands','military-and-security',1199,'Military branches: Royal Netherlands Army,
Royal Netherlands Navy (includes Naval Air
Service and Marine Corps), Royal Netherlands
Air Force (Koninklijke Luchtmacht, KLu), Royal
Military Police (2012)
Military service age and obligation: 17 years of
age for an all-volunteer force (2012)
Manpower available for military service:
males age 16-49: 3,911,098
females age 16-49: 3,817,031 (2010 est.)
Manpower fit for military service: males age
16-49: 3,201,328
females age 16-49: 3,122,889 (2010 est.)
Manpower reaching militarily significant age
annually: male: 103,462
female: 98,383 (2010 est.)
521
Military expenditures: 1.6% of GDP (2005 est.)
country comparison to the world: 90','3577e15326c78186763e6f4e6cf39853cb0b6fe135142a645a4eea106c64562f','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f081f4e72fe96bfd233fb41b5753eefc8870738ed365c64163e00ec3bdcd859f',2025,'NC','New Caledonia','military-and-security',1205,'Military branches: no regular military forces;
French military, police, and gendarmerie (2012)
Manpower available for military service:
males age 16-49: 68,219 (2010 est.)
Monpower fit for military service: males age
16-49: 56,233
females age 16-49: 55,983 (2010 est.)
Manpower reaching militarily significant age
annually: male: 2,272
female:2,167 (2010 est.)
Military expenditures: NA
Military—note: defense is the responsibility of','429a21cd9e367b40ded3d9f49fcbd7bd18cdd7754bac5fe592c2824ac8c1c89a','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0d2d497c8efc18f61362eec005b737ffaff47f6f3fb02247fec9d904e0f00674',2025,'NZ','New Zealand','military-and-security',1211,'Military branches: New Zealand Defense Force
(NZDF): New Zealand Army, Royal New Zealand
Navy, Royal New Zealand Air Force (Te Hokow-
hitu o Kahurangi, RNZAF) (2013)
Military service age and obligation: 17 years of
age for voluntary military service; soldiers cannot
be deployed until the age of 18; no conscription; 3
527
years of secondary education required; must be a
citizen of NZ, the UK, Australia, Canada, or the
US, and resident of NZ for the previous 5 years
(2013)
Manpower available for military service:
males age 16-49: 1,019,798
females age 16-49: 1,003,429 (2010 est.)
THE CiA WORLD FACTBOOK
Manpower fit for military service: males age
16-49; 843,526
females age 16-49:828,779 (2010 est.)
Manpower reaching militarily significant age
annually: male: 30,846
female: 28,825 (2010 est.)
Military expenditures: 1.5% of GDP (2012)
country comparison to the world: 101','afb1bf67053707fd0dee34f4db2cb1f59e53959e9b7abff3de2d9edcb239471b','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3cbfa34bd08923369c6428c98d061f99956315ea61edb496077822c1dec552e8',2025,'NI','Nicaragua','military-and-security',1222,'Military branches: National Army of Nicaragua
(Ejercito Nacional de Nicaragua, ENN; includes
Navy, Air Force) (2011)
Military service age and obligation: 18-30 years
of age for voluntary military service; tour of duty
18-36 months; requires Nicaraguan nationality
and 6th-grade education (2008)
Manpower available for military service:
males age 16-49: 1,452,107
females age 16-49: 1,552,698 (2010 est.)
Manpower fit for military service: males age
16-49: 1,227,757
females age 16-49: 1,335,653 (2010 est.)
Manpower reaching militarily significant age
annually: male: 69,093
female: 67,522 (2010 est.)
Military expenditures: 0.9% of GDP (2012)
country comparison to the world: 138','57b41789852bdad3db57c742905435250a170356f1527c5cd9c6590fb4d79340','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bdb53509b6c3d6152c1ca139b6c8d8126e506827f5ed2b685389f38bb0618e48',2025,'NE','Niger','military-and-security',1228,'Military branches: Nigerien Armed Forces
(Forces Armees Nigeriennes, FAN): Anny,
Nigerien Air Force (Force Aerienne du Niger)
(2010)
Military service age and obligation: 18 is the
presumed legal minimum age for compulsory or
voluntary military service; enlistees must be Nige-
rien citizens and unmarried; 2-year service term;
women may serve in health care (2012)
Manpower avaliable for military service:
males age 16-49: 3,329,184
females age 16-49: 3,267,669 (2010 est.)
Manpower fit for military service: males age
16-49: 2,194,570
females age 16-49: 2,219,416 (2010 est.)
Manpower reaching militarily significant age
annually: male: 186,348
female: 180,779 (2010 est.)
Military expenditures: 0.9% of GDP (2012)
country comparison to the world: 141','7c2792eff8735eb9319459aecacf8292d9ada3975c7faa5a8df90defdeb7867b','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5b02c5dc66187ba6e0465be9756993d247f37d3c01e317fa9aeedd4d3f67b678',2025,'NG','Nigeria','military-and-security',1236,'Military branches: Nigerian Armed Forces
(Forces Armees Nigeriennes, FAN): Army, Nige-
rien Air Force (Force Aerienne du Niger) (2008)
Military service age and obligation: 18 years of
age for voluntary military service; no conscription
(2012)
Manpower available for military service:
males age 16-49: 37,087,711
females age 16-49: 35,232,127 (2010 est.)
Manpower fit for military service: males age
16-49: 20,839,976
females age 16-49: 19,867,683 (2010 est.)
Manpower reaching militarily significant age
annually: male: 1,767,428
female: 1,687,719 (2010 est.)
Military expenditures: 0.9% of GDP (2012)
country comparison to the world: 140','2b904527b8f3c3e35e5d7cb9da7156e9954f0b5e19a5cca2bf0d98aea1b16c38','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('745e0f17996192db4ccba296b312f12119c2b0edbaf410f94a14695bb08840c8',2025,'MP','Northern Mariana Islands','military-and-security',1249,'Manpower fit for military service: males age
16-49; 8,793
females age 16-49: 11,569 (2010 est.)
Manpower reaching militarily significant age
annually: male: 410
ISLANDS
female: 306 (2010 est.)
Mititary—note: defense is the responsibility of
the US','1101987630910fdd870b4a1482ee636a50a4066719699a2c18ba518866ac0f6e','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cce7965be3994d383610f8564fe3ecc41e88c8330c17e8659420a315a945974c',2025,'NO','Norway','military-and-security',1255,'Military branches: Norwegian Army (Haeren),
Royal Norwegian Navy (Kongelige Norske Sjoe-
forsvaret, RNoN; includes Coastal Rangers and
Coast Guard (Kystvakt)), Royal Norw egian Air
Force (Kongelige Norske Luftforsvaret, RNoAF),
Home Guard (Heimevernet, HV) (2011)
Military service age and obligation: 19-35 years
of age for male compulsory military service; 16
years of age in wartime; 17 years of age for male
volunteers; 18 years of age for women; l-year ser-
vice obligation followed by 4-5 refresher training
periods through ages 35-60, totalling 18 months
(2012)
Manpower available for military service:
males age 16-49: 1,079,043
females age 16-49: 1,051,210 (2010 est.)
Manpower fit for military service: males age
16-49: 888,761
females age 16-49: 865,697 (2010 est.)
Manpower reaching militarily significant age
annually: male: 32,290
female: 30,777 (2010 est.)
Military expenditures: 1.9% of GDP (2005 est.)
country comparison to the world: 72','ecc58515af0485c8bfb40825bc0dcc80730275062c6019aea95ea00f042399bf','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3140a12644d50716e2fef27d2f50f19b57a4ab436b4359aa182a230e1f422149',2025,'OM','Oman','military-and-security',1262,'Military branches: Sultan’s Armed Forces (SAF):
Royal Army of Oman, Royal Navy of Oman, Royal
Air Force of Oman (al-Quww at al-Jawwiya al-Sul-
tanat Oman) (2013)
Military service age and obligation: 18-30 years
of age for voluntary military service; no conscrip-
tion (2012)
Manpower available for military service:
males age 16-49: 985,957
females age 16-49: 737,812 (2010 est.)
Manpower fit for military service: males age
16-49: 837,886
females age 16-49: 642,427 (2010 est.)
Manpower reaching militarily significant age
annually: male: 31,959
female: 30,264 (2010 est.)
Military expenditures: 4% of GDP (2005 est.)
country comparison to the world: 1','fb319b2a02ba22808ea35c627dfcf8f9a2860c82c30021f1693f8053a28e32b4','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ae1a70f84b64506d6c150c4b060c17430300f3f5848b957e8a6bc16cfc7f5683',2025,'PK','Pakistan','military-and-security',1273,'Military branches: Pakistan Army (includes
National Guard), Pakistan Navy. (includes
Marines and Maritime Security Agency); Pakistan
Air Force (Pakistan Fiza’ya) (2013)
Military service age and obligation: 17-23
years of age for voluntary military service; soldiers
cannot be deployed for combat until age 18; the
Pakistani Air Force and Pakistani Navy have
inducted their first female pilots and sailors; the
Pakistan Air Force recruits aviation technicians
at age 15; service obligation (Navy) 10-18 years;
retirement required after 18-30 years service or age
40-52 (2012)
Manpower available for military service:
males age 16-49: 48,453,305
females age 16-49: 44,898,096 (2010 est.)
Manpower fit for military service: males age
16-49: 37,945,440
females age 16-49: 37,381,549 (2010 est.)
km of
Manpower reaching militarily significant age
annually: male: 2,237,723
female: 2,104,906 (2010 est.)
Military expenditures: 3.1% of GDP (2012)
country comparison to the world: 39','d0e6147dcda8e15d04924eda105b862f1d319119cc883568a37cf7e8d629b86b','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ba058bdaf4d0bc2df29b269d0efb504d370750c5cbb736c6bd5607de2497134e',2025,'PW','Palau','military-and-security',1280,'Military branches: no’ regular military forces;
Palau National Police (2009)
THE CIA WORLD FACTBOOK
Manpower available for military service:
males age 16-49: 6,987 (2010 est.)
Manpower fit for military service: males age
16-49: 5,272
females age 16-49; 3,969 (2010 est.)
Manpower reaching militarily significant age
annually: male: 216
female: 222 (2010 est.)
Military expenditures: NA
Military—note: defense is the responsibility of
the US; under a Compact of Free Association
between Palau and the US, the US military is
granted access to the islands for 50 years, but it has
not stationed any military forces there (2008)','d86dc638eacfc55673e65f694939e55b8e15b4ad45626d93908f43a7580f96e9','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('922ed3aaa522a2e4792ee6705f4a62d8a67b47027e7311db4b4515a4c04e59b2',2025,'PA','Panama','military-and-security',1290,'Military branches: no regular military forces;
Panamanian Public Security Forces (subordinate
to the Ministry of Public Security), comprising the
National Police (PNP), National Air-Naval Ser-
vice (SENAN), National Border Service (SENA-
FRONT) (2013)
Manpower available for military service:
males age 16-49: 890,006 (2010 est.)
Manpower fit for military service: males age
16-49: 731,254
females age 16-49: 728,329 (2010 est.)
Manpower reaching militarily significant age
annually: male: 32,142
female: 30,879 (2010 est.)
Military expenditures: 1% of GDP (2012)
country comparison to the world: 128
Military—note: on 10 February 1990, the gov-
ernment of then President ENDARA abolished
Panama''s military and reformed the security
apparatus by creating the Panamanian Public
Forces; in October 1994, Panama’s Legislative
Assembly approved a constitutional amendment
prohibiting the creation of a standing military
force but allowing the temporary establishment of
special police units to counter acts of “external
aggression”','85d51773287121e96719585e73f6c292c8bb76239542fd5d06384dc788433202','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e35ef775f64afdccc1377994b3081a79883d126eb4bc60861e9780f6ea0247f2',2025,'PG','Papua New Guinea','military-and-security',1300,'Military branches: Papua New Guinea Defense
Force (PNGDF; includes Maritime Operations
Element, Air Operations Element) (2013)
Military service age and obligation: 16 years of
age for voluntary military service (with parental
consent); no conscription; graduation from grade
12 required (2013) z
Manpower available for military service:
males age 16-49: 1,568,210
females age 16-49: 1,478,965 (2010 est.)
Manpower fit for military service: males age
16-49: 1,130,951
females age 16-49: 1,137,753 (2010 est.)
Manpower reaching militarily significant age
annually: male: 67,781
female: 65,820 (2010 est.)
Military expenditures: 0.5% of GDP (2012)
country comparison to the world: 160
Military—note: occupied by China','70b8839b482e2e98d530303ace02814739790d9719d7c2cc8f615b50782286ae','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fdf3349fe1bbed8713efd41bf4ba78c17967faf9a88b3ed606f3f64c6d50f43a',2025,'PE','Peru','military-and-security',1312,'Military branches: Peruvian Army (Ejercito Peru-
ano), Peruvian Navy (Marina de Guerra del Peru,
MGP (includes naval air, naval infantry, and Coast
Guard)), Air Force of Peru (Fuerza Aerea del Peru,
FAP) (2011)
Military service age and obligation: 18-50 years
of age for male and 18-45 years of age for female
voluntary military service; no conscription (2012)
Manpower avaiiable for military service:
males age 16-49: 7,385,588
females age 16-49: 7,727,623 (2010 est.)
Manpower fit for military service: males age
16-49: 5,788,629
females age 16-49: 6,565,097 (2010 est.)
Manpower reaching militarily significant age
annually: male: 304,094
female: 298,447 (2010 est.)
Military expenditures: 1% of GDP (2012)
country comparison to the world: 129','ab0d942baa611181c7fa45aeb2b95697549f7138c6d52d006925604fbb8d63ab','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ad49cbd37240d34ae56b05df7d592945487cc16cfee5cd70577e0f61d5f69c3e',2025,'PH','Philippines','military-and-security',1323,'Military branches: Armed Forces of the Phil-
ippines (AFP): Army, Navy (includes Marine
Corps), Air Force (2013)
Military service age and obligation: 17-23 years
of age (officers 20-24) for voluntary military ser-
vice; no conscription; applicants must be single
male or female Philippine citizens with either 72
THE CIA WORLD FACTBOOK
college credit hours (enlisted) or a baccalaureate
degree (officers) (2013)
Manpower available for military service:
males age 16-49: 25,614,135
females age 16-49: 25,035,061 (2010 est.)
Manpower fit for military service: males age
16-49: 20,142,940
females age 16-49: 21,427,792 (2010 est.)
Manpower reaching militarily significant age
annually: male: 1,060,319
female: 1,021,069 (2010 est.)
Military expenditures: 0.9% of GDP (2005
est.)
country comparison to the world: 135
Military—note: Spratly Islands consist of more
than 100 small islands or reefs of which about 45
are claimed and occupied by China, Malaysia, the
Philippines, Taiwan, and Vietnam','74f3ce12e2f85f39d6e80ced3cba06974317e62ffbd8c25c3a8b987f800b9f55','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b97be9ec317890a2ed53f1d828f2503baa7e496dfac028e109e98f1b247752f4',2025,'PT','Portugal','military-and-security',1342,'Military branches: Portuguese Army (Exercito
Portuguesa), Portuguese Navy (Marinha Portu-
guesa; includes Marine Corps), Portuguese Air
Force (Forca Aerea Portuguesa, FAP) (2010)
Military service age and obligation: 18-30 years
of age for voluntary military service; no compulsory
military service, but conscription possible if insuf-
ficient volunteers available; women serve in the
armed forces, on naval ships since 1993, but are
prohibited from serving in some combatant special-
ties; reserve obligation to age 35 (2012)
Manpower available for military service:
males age 16-49: 2,566,264
females age 16-49: 2,458,297 (2010 est.)
Manpower fit for military service: males age
16-49: 2,103,080
females age 16-49: 2,018,004 (2010 est.)
Manpower reaching militarily significant age
annually: male: 62,208
female: 54,786 (2010 est.)
Military expenditures: 2.3% of GDP (2005 est.)
country comparison to the world: 60','637d7727ca358e0c5e72722ec781d3513715d24dd447dff081c0be39ca92e363','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7f53d77d1a61b71c62fe0f7fbba03cd442f89105adace928313a15281158e953',2025,'PR','Puerto Rico','military-and-security',1349,'Military branches: no regular indigenous military
forces; paramilitary National Guard, Police Force
Manpower fit for military service: males age
16-49: 700,443
females age 16- 49: 786,035 (2010 est.)
Manpower reaching militarily significant age
annually: male: 30,517
female: 29,010 (2010 est.)
Military—note: defense: is the responsibility of
the US
Manpower fit for military service:
males age 16-49: 17,542
females age 16-49: 20,946 (2010 est.)
Manpower reaching militarily significant age
annually: male: 744
female: 788 (2010 est.)
Military—nofe: defense is the responsibility of
the US','3887da4841af43ce5bf3342d8b3fad9478e172c3d71330845ba17bef4940575d','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('507515d470c3c627df2f51b4cd0e2c6975f6c1d709c9fdf25e1b75331aa554e8',2025,'QA','Qatar','military-and-security',1358,'Military branches: Qatari Emiri Land Force
(QELF), Qatari Emiri Navy (QEN), Qatari Emiri
Air Force (QEAF) (2013)
Military service age and obligation: 18 years of
age for voluntary military service; no conscription
(2013)
Manpower available for military service:
males age 16-49: 389,487
females age 16-49: 165,572 (2010 est.)
Manpower fit for military service:
males age 16-49; 321,974
females age 16-49: 140,176 (2010 est.)
Manpower reaching militarily significant age
annually: male: 6,429
female: 5,162 (2010 est.)
Military expenditures: 10% of GDP (2005 est.)
country comparison to the world: 3','ffb11ed4bbe901b5037f7fbe06bc388e00fa1dec2e9128984f950486ad08e17b','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1f4e267a5d84c8406882e7d24d7a7f928095e0b9a255859d1f0e7cc8fa3af801',2025,'RW','Rwanda','military-and-security',1372,'Military branches: Rwanda Defense Force
(RDF): Rwanda Army (Rwanda Land Force),
Rwanda Air Force (2012)
Military service age and obligation: 18 years of
age for voluntary military service; no conscription;
Rwandan citizenship is required, as is a 9th grade edu-
cation for enlisted recruits and an A-level certificate
for officer candidates; enlistment is either as contract
(5-years, renewable twice) or career; retirement (for
officers and senior NCOs) after 20 years of service or
at 40-60 years of age) (2012)
Manpower available for military service: males
age 16-49: 2,625,91 7 females age 16-49: 2,608,110
(2010 est.) F aE
Manpower fit for military service:
males age 16-49: 1,685,066
females age 16-49: 1,749,580 (2010 est.)
Manpower reaching militarily significant age
annually: male: 110,736
female: 1 10,328 (2010 est.)
Military expenditures: 1.3% of GDP (2012)
country comparison to the world: 108','fde30ab65bf6bf407b34da1ebd7fd7fad3c2d1514f8e3900486972b96e88266f','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('104e44d0ba74574b025741926369908864d0353e568069cfcc4bdc75293d46e3',2025,'TT','Trinidad and Tobago','military-and-security',1382,'Military branches: Ministry of Foreign Affairs,
National Security, Labour, Immigration, and
Social Security: Royal Saint Kitts and Nevis
Defense Force (includes Coast Guard), Royal
Saint Kitts and Nevis Police Force (2013)
Military service age and obligation: 17 years of
age for voluntary military service; no conscription
(2012)
Manpower available for military service:
males age 16-49: 13,506
females age 16-49: 13,089 (2010 est.)
Manpower fit for military service: males age
16-49: 10,742
females age 16-49: 10,923 (2010 esr.)
Manpower reaching militarily significant age
annually: male: 380
female: 422 (2010 est.)
Military expenditures: NA
Military branches: Trinidad and Tobago Defense
Force (TTDF): Trinidad and Tobago Army, Coast
Guard, Air Guard, Defense Force Reserves (2010)
Military service age and obligation: 18-25
years of age for voluntary military service (16
years of age with parental consent); no con-
scription; Trinidad and Tobago citizenship
and completion of secondary school required
(2012)
Manpower available for military service:
males age 16-49: 341,764
females age 16-49: 317,899 (2010 est.)
Manpower fit for military service: males age
16-49: 269,824
females age 16-49: 261,735 (2010 est.)
Manpower reaching militarily significant age
annually: male: 8,164
female: 7,503 (2010 est.)
Military expenditures: 0.6% of GDP (2011)
country comparison to the world: 155','166c040707591c1830784f5af7c9f8974778897ad0bf8dadedba9887504bb345','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fc48fc615a364a655b09b68720231d3922ffcff4e85c827fcb2475ffc38af7d2',2025,'LC','Saint Lucia','military-and-security',1391,'Military branches: no regular military forces;
Royal Saint Lucia Police Force (includes Special
Service Unit, Marine Unit) (2012)
Military service age and obligation: 18 years
of age for voluntary security service; no national
army (2012)
Manpower available for military service:
males age 16-49: 41,414 (2010 est.)
Manpower fit for military service: males age
16-49: 32,688
females age 16-49: 36,289 (2010 est.)
Manpower reaching militarily significant age
annually: male: 1,574
female: 1,502 (2010 est.)
Military expenditures: NA','f5a412e322d415daa00674698acedd31002f99abd2e096774b46b3672d65a8d7','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b9e141708a8cd388343d0bb0ab7d22b687a6fdbd3b667fa742408a9ea8224aef',2025,'PM','Saint Pierre and Miquelon','military-and-security',1395,'Miquelon”
Langlade ‘~y
(Petite Miquelon)
he Saint-Pierre
* SAINT-PIERRE
Manpower fit for military service: males age
1A-4Q: 1064
females age 16-49: 1,069 (2010 est.)
Manpower reaching militarily significant age
annually: male: 34
female: 32 (2010 est.)
Military—note: defense is the responsibility of','de24ee686b4c802d39b57743963b5fd6334c38e8834512c36951db254a31b4fe','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('35a7fcea2b345cece4138c8c1df3578d8927f891894f238f18845e4fd45f2cb8',2025,'VC','Saint Vincent and the Grenadines','military-and-security',1412,'Military branches: no regular military forces;
Royal Saint Vincent and the Grenadines Police
Force (RSVPF) (2013)
“Manpower available for military service:
males age 16-49: 27,809 (2010 est.)
Manpower fit for military service: males age
16-49: 22,875
females age 16-49: 22,015 (2010 est.)
Manpower reaching militarily significant age
annually: male: 964
female: 953 (2010 est.)
Military expenditures: NA','a3393bfd6c0f572c3109d0167ab764b5c0d1027b1e4a2d1eabc668448770b32d','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('632ed8cc9c38e5365a860b7c450ddab168b1b61060a1f2ef14358e77fb51de04',2025,'SM','San Marino','military-and-security',1424,'Military branches: no regular military forces; vol-
untary Military Corps (Corpi Militari) performs
ceremonial duties and limited police support func-
tions (2010)
Military service age and obligation: 18 is the
legal minimum age for voluntary military service;
no conscription; government has the authority to
call up all San Marino citizens from 16-60 years of
age to service in the military (2012)
Manpower available for military service:
males age 16-49: 6,892 (2010 est.)
Manpower fit for military service: males age
16-49: 5,565 : Jee
females age 16-49: 6,067 (2010 est.)
Manpower reaching militarily significant age
annually: male: 186
female: 166 (2010 est.)
Military expenditures: NA
Mititary—note: defense is the responsibility of','bdced73d78c40fd69d5a0439791dd00fcd462a6a4ab4cadf58e6f6e1933a4083','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ca4a8b30081a2c88dfa112c128bd46da9870598c4684ac1ceb0dd4432271b1d6',2025,'ST','Sao Tome and Principe','military-and-security',1428,'Military branches: Armed Forces of Sao Tome
and Principe (Forcas Armadas de Sao Tome e
Principe, FASTP): Army, Coast Guard of Sao
Tome e Principe (Guarda Costeira de Sao Tome e
Principe, GCSTP); also called “Navy”), Presiden-
tial Guard (2011)
Military service age and obligation: 18 is the
legal minimum age for compulsory military service;
17 is the legal minimum age for voluntary service
(2012)
Manpower available for military service:
males age 16-49: 39,182
females age 16-49: 39,845 (2010 est.)
Manpower fit for military service: males age
16-49: 27,310
females age 16-49: 29,279 (2010 est.)
Manpower reaching militarily significant age
annually: male: 2,076
female: 2,003 (2010 est.)
Military expenditures: 0.5% of GDP (2011)
country comparison to the world: 162 „
Military—note: Sao Tome and Principe’s army
is a tiny force with almost no resources at its dis-
posal and would be wholly ineffective operating
unilaterally; infantry equipment is considered
simple to operate and maintain but may require
refurbishment or replacement after 25 years in
tropical climates; poor pay, working conditions,
and alleged nepotism in the promotion of offic-
ers have been problems in the past, as reflected
in the 1995 and 2003 coups; these issues are
being addressed with foreign assistance aimed
at improving the army and its focus on realistic
security concerns; command is exercised from the
president, through the Minister of Defense, to the
Chief of the Armed Forces staff (2005)','8a8040ac1bb97e6eff01e2546f1b3b580165e23a4b8386196b2b59d9dab7e58b','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('98f75596331ec652a7ca74188da1e69a4e6bd051102d0dddc45ad65cb2ffd71a',2025,'SA','Saudi Arabia','military-and-security',1436,'Military branches: Ministry of Defense and Avia-
tion Forces: Royal Saudi Land Forces, Royal Saudi
Naval Forces (includes Marine Forces and Spe-
cial Forces), Royal Saudi Air Force (Al-Quwwat
al-Jawwiya al-Malakiya as-Sa’udiya), Royal Saudi
Air Defense Forces, Royal Saudi Strategic Rocket
Forces, Saudi Arabian National Guard (SANG)
Military service age and obligation: 17 is the
legal minimum age for voluntary military service;
no conscription (2012)
Manpower available for military service:
males age 16-49: 8,644,522
females age 16-49: 6,601,985 (2010 est.)
Manpower fit for military service: males age
16-49: 7,365,624
females age 16-49: 5,677,819 (2010 est.)
Manpower reaching militarily significant age
annually: male: 261,105
female: 244,763 (2010 est.)
Military expenditures: 9.1% of GDP (2012)
country comparison to the world: 5','979fa45cc551761df9b337556c20a57dbaef2f49ec3d46027f9aa26f88d3e77c','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9b3345b596fe28400d2ca8db5efe3380a5d56885c98e2def4f016cbe7735b3b9',2025,'RS','Serbia','military-and-security',1438,'Military branches: Serbian Armed Forces (Vojska
Srbije, VS): Land Forces Command (includes Riv-
erine Component, consisting of a river flotilla on
the Danube), Air and Air Defense Forces Com-
mand (2012)
Military service age and obligation:
18 years of age for voluntary military service;
conscription abolished December 2010; reserve
obligation to age 60 for men and age 50 for
women (2013)
Manpower fit for military service: males age
16-49: 1,395,426
females age 16-49: 1,356,415 (2010 est.)
Manpower reaching militarily significant age
annually: male: 43,945
female: 41,080 (2010 est.)','c8804467735d0a02d1f7c47129abaf475e2a879250a9f009130fc17578fd4139','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f24bb8750436a0735a0aa0cc29ce7a248eec9dc8203867ebaf2a236cbe03fa2e',2025,'SC','Seychelles','military-and-security',1445,'Military branches: Seychelles Defense Force:
Army, Coast Guard (includes Naval Wing, Air
Wing), National Guard (2005)
Military service age and obligation: 18 years
of age for voluntary military service (younger with
parental consent); no conscription (2012)
Manpower available for military service:
males age 16-49: 26,257
females age 16-49: 23,996 (2010 est.)
Manpower fit for military service: males age
16-49; 20,231
females age 16-49: 19,891 (2010 est.)
Manpower reaching militarily significant age
annually: male: 686
female: 650 (2010 est.)
Military expenditures: 0.8% of GDP (2011)
country comparison to the world: 148','8c30ae2c9b0c22faaa9b20b326938b0ed421a253baaf9b4be114172b95321a7f','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f91d85b1539d6bfab40d49c73512c177d166bc344c284c8cda7b96420ee8aa9a',2025,'SK','Slovakia','military-and-security',1464,'Military branches: Armed Forces of the Slovak
Republic (Ozbrojene Sily Slovenskej Republiky):
Land Forces (Pozemne Sily), Air Forces (Vzdusne
Sily) (2010)
Military service age and obligation: 18-30 years
of age for voluntary military service; conscription
in peacetime suspended in 2006; women are eligi-
ble to serve (2012)
Manpower available for military service:
males age 16-49: 1,405,310
females age 16-49: 1,369,897 (2010 est.)
Manpower fit for military service: males age
16-49: 1,156,113
females age 16-49: 1,139,380 (2010 est.)
Manpower reaching militarily significant age
annually: male: 31,646
female: 30,219 (2010 est.)
Military expenditures: 1.08% of GDP (2005 est.)
country comparison to the world: 123','7d3cb9ae42e8ce297af88818e6f1bfc4a4b12c1d787c165102ac380fcde17b67','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('54a594be0f8130b19276e06edb6d614fc52916cf944dbf41f37c1325620f812f',2025,'SI','Slovenia','military-and-security',1470,'Military branches: Slovenian Armed Forces
(Slovenska Vojska, SV): Forces Command (with
ground units, naval element, air and air defense
brigade); Administration for Civil Protection and
Disaster Relief (ACPDR) (2013)
Military service age and obligation: 18-25 years
of age for voluntary military service; conscription
abolished in 2003 (2012)
Manpower available for military service:
males age 16-49: 477,592
females age 16-49: 464,301 (2010 est.)
Manpower fit for military service: males age
16-49: 392,075
females age 16-49: 380,077 (2010 est.)
Manpower reaching militarily significant age
annually: male: 9,818
female: 9,395 (2010 est.)
Military expenditures: 1.7% of GDP (2005 est.)
country comparison to the world: 86','09bbe302ad2e81646126aead561c96ff5824998f77378ad3f788867b8f18de55','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('58c59b8fd4fe61d04c2d84d915f6fabef3775c2529721f38a88945187d12ce6d',2025,'SB','Solomon Islands','military-and-security',1478,'Military branches: no regular military forces;
Royal Solomon Islands Police Force (2013)
Manpower available for military service: males
age 16-49: 142,913 (2010 est.)
Manpower fit for military service: males age
16-49: 118,921
.
females age 16-49: 118,164 (2010 est.)
Manpower reaching militarily significant age
annually: male: 6,483
female: 6,098 (2010 est.)
Military expenditures: 3.7% of GDP (2007)
country comparison to the world: 28','95faffa71e11eef6ebceb3d6208ee95893af184d101eeabbf7a3ff08cf25aa50','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bbad841a1aa00628c06ecc6cb7d929ee8aeabf69f68ba2d64820079c49137543',2025,'LK','Sri Lanka','military-and-security',1504,'Military branches: Sri Lanka Army, Sri Lanka
Navy, Sri Lanka Air Force (2013)
Military service age and obligation: 18-22 years
of age for voluntary military service; no conscrip-
tion; 5-year service obligation (Air Force) (2012)
Manpower available for military service:
males age 16-49; 5,342,147
females age 16-49: 5,466,409 (2010 est.)
Manpower fit for military service: males age
16-49: 4,177,432
females age 16-49: 4,574,833 (2010 est.)
Manpower reaching militarily significant age
annually: male: 167,026
female: 162,587 (2010 est.)
Military expenditures: 2.9% of GDP (2012)
country comparison to the world: 42','179b3e1ca2ef07c30382ecbf20ef225a03960bc5e0700c25f63e7774048e2978','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4845be778549531e9058858c205d703db2d386332fe850ad07468e32372a9816',2025,'SR','Suriname','military-and-security',1520,'Military branches: Suriname Armed Forces:
Ground Forces, Naval Forces, Air Forces (2010)
Military service age and obligation: 18 is the
legal minimum age for voluntary military service;
no conscription; personnel drawn almost exclu-
sively from the Creole community (2012)
Manpower available for military service:
males age 16-49: 134,218
females age 16-49: 134,439 (2010 est.)
Manpower fit for military service: males age
16-49: 109,445
females age 16-49: 112,538 (2010 est.)
Manpower reaching militarily significant age
annually: male: 4,119
female: 4,106 (2010 est.)
Military expenditures: 1.2% of GDP (2011)
country comparison to the world: 116','467cc8807c90047959138a03b9f8d40192de433d08d1554666bc62a9cc9aab37','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8be661762d772efb62fa29d810ea2ba7ffad0683283c2bec579f3fe69b50e5c4',2025,'SE','Sweden','military-and-security',1529,'Military branches: Swedish Armed Forces (For-
svarsmakten): Army (Armen), Royal Swedish
Navy. (Marinen), Swedish Air Force (Svenska
Flygvapnet) (2010)
Military service age and obligation: 18-47
- years of age for male and female voluntary military
service; service obligation: 7.5 months (Army),
7-15 months (Navy), 8-12 months (Air Force);
the Swedish Parliament has abolished compul-
sory military service, with exclusively voluntary
recruitment as of July 2010; conscription remains
an option in emergencies; after completing initial
service, soldiers have a reserve commitment until
age 47 (2012)
Manpower available for military service:
males age 16-49: 2,065,691
females age 16-49: 1,996,764 (2010 est.)
Manpower fit for military service: males age
16-49: 1,709,055 i «
females age 16-49: 1,650,432 (2010 est.)
Manpower reaching militarily significant age
annually: male: 54,960
female: 52,275 (2010 est.)
Military expenditures: 1.5% of GDP (2005 est.)
country comparison to the world: 100','5d4314a94bf706e38e2bcdc4794f52ebad1309a1078c7f3dd6b868aedf79aee9','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f8ddfc72b2504ae0905674882689838b865e266ff1f34a781caadf7d0a8dfe3d',2025,'CH','Switzerland','military-and-security',1535,'Military branches: Swiss Armed Forces: Land
Forces, Swiss Air Force (Schweizer Luftwaffe)
(2013)
Military service age and obligation: 19-26 years
of age for male compulsory military service; 18
years of age for voluntary male and female mili-
tary service; every Swiss male has to serve at least
260 days in the armed forces; conscripts receive 18
weeks of mandatory training, followed by seven
3-week intermittent recalls for training during the
next 10 years (2012)
Manpower available for military service:
males age 16-49: 1,828,043
females age 16-49: 1,786,552 (2010 est.)
Manpower fit for military service: males age
16-49: 1,493,509
females age 16-49: 1,459,450 (2010 est.)
Manpower reaching militarily significant age
annually: male: 46,562
female: 42,585 (2010 est.)
Military expenditures: 1% of GDP (2005 esr.)
country comparison to the world: 127
Military branches: Syrian Armed Forces: Syr-
ian Arab Army, Syrian. Arab Navy, Syrian Arab
Air and Air Defense Forces (includes Air Defense
Command) (2008)
Military service age and obligation: years of
age for compulsory and voluntary military service;
conscript service obligation is 18 months; women
are not conscripted but may volunteer to serve;
re-enlistment obligation 5 years, with retirement’
after 15 years or age 40 (enlisted) or 20 years or age
45 (NCOs) (2012)
Manpower available for military service:
males age 16-49: 5,889,837
females age 16-49: 5,660,751 (2010 est.)
Manpower fit for military service: males age
16-49: 5,055,510
females age 16-49: 4,884,151 (2010 est.)
Manpower reaching militarily significant age
annually: male: 256,698
female: 244,712 (2010 est.)
Military expenditures: 3.6% of GDP (2011)
country comparison to the world: 31
Military branches: Army, Navy (includes Marine
Corps), Air Force, Coast Guard Administration,
Armed Forces Reserve Command, Combined
Service Forces Command, Armed Forces Police
Command j
Military service age and obligation: 19-35
years of age for compulsory and voluntary military
service; service obligation 2 years; women may
enlist; women in Air Force service are restricted
to noncombat roles; reserve obligation to age 30
(Army); the Ministry of Defense is in the process of
implementing a voluntary enlistment system over
the period 2010-2015, although non volunteers will
still be required to perform alternative service or go
through 4 months of military training (2012)
Manpower available for military service:
males age 16-49: 6,183,567
females age 16-49: 6,006,676 (2010 est.)
Manpower fit for military service: males age
16-49: 5,074,173
females age 16-49: 4,951,088 (2010 est.)
Manpower reaching militarily significant age
annually: male: 166,190
female: 155,306 (2010 est.)
Military expenditures: 2.2% of GDP (2012)
country comparison to the world: 62','5954f7e92054039726b026bc876d35e9a62d2102da75c6c373d39d007a33baa2','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('698d31e89716362b0833d7430f9a40160a506f986f941abf57c80f90dc3c2eac',2025,'TJ','Tajikistan','military-and-security',1544,'Military branches: Ground Forces, Air and Air
Defense Forces, Mobile Forces (2013)
Military service age and obligation: 18-27 years
of age for compulsory or voluntary military service;
2-year conscript service obligation; males required
to undergo compulsory militąry training between
ages 16 and 55; males can enroll in military schools
from at least age 15 (2012)
Manpower available for military service:
males age 16-49: 2,012,790
females age 16-49: 2,020,618 (2010 est.)
Manpower fit for military service:
males age 16-49: 1,490,267
females age 16-49: 1,675,083 (2010 est.)
Manpower reaching militarily significant age
annually: male: 76,430
female: 74,038 (2010 est.)
Military expenditures; 1.5% of GDP (2010)
country comparison to the world: 99
713
Military branches: Tanzania People’s Defense
Force (Jeshi la Wananchi la Tanzania, JWTZ):
Army, Naval Wing (includes Coast Guard), Air
Defense Command (includes Air Wing), National
Service (2007)
Military service age and obligation: 18 years of
age for voluntary military service; no conscription
(2012)
Manpower available for military service:
males age 16-49: 9,985,445 (2010 est.)
Manpower fit for military service: males age
16-49: 5,860,339
females age 16-49: 5,882,279 (2010 est.)
Manpower reaching militarily significant age
annually: male: 512,294
female: 514,164 (2010 est.)
Military expenditures: 0.9% of GDP (2012)
country comparison to the world: 136','c193ea6a4543168b49b75b20bbe2cc523966e81d3eb3042891ace8a75dc00fc8','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('822bc3b4312c5107506a60994f3e8db995f5fbc13c26118b8150f74263b629cf',2025,'TH','Thailand','military-and-security',1553,'Military branches: Royal Thai Army (Kongthap
Bok Thai, RTA), Royal Thai Navy (Kongthap Ruea
Thai, RTN, includes Royal Thai Marine Corps),
Royal Thai Air Force (Kongthap Agard Thai, RTAF)
(2013)
Military service age and obligation: 21 years
of age for compulsory military service; 18 years of
age for voluntary military service; males register at
18 years of age; 2-year conscript service obligation
(2012)
Manpower available for military service:
males age 16-49: 17,689,921
females age 16-49: 17,754,795 (2010 est.)
Manpower fit for military service: males age
16-49: 13,308,372
females age 16-49: 14,182,567 (2010 est.)
721
Manpower reaching militarily significant age
annually: male: 533,424
female: 509,780 (2010 est.)
Military expenditures: 1.8% of GDP (2005 est.)
country comparison to the world: 77','0a4be941534f0327a0ee2c04c8fe6795244cc3dccd1133d8f04875e6a93e48b5','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('659c42ead86bcee7b10ea900ed34a1cf15fac01867edb540605a0f21eb459514',2025,'TL','Timor-Leste','military-and-security',1561,'Military branches: Timor-Leste Defense Force
(Falintil-Forcas de Defesa de Timor-Leste, Falintil
(F-FDTL)): Army, Navy (Armada) (2013)
Military service age and obligation: 18 years
of age for voluntary military service; 18-month
service obligation; no conscription but,as of May
2013, introduction of conscription was under dis-
cussion (2013)
Manpower available for military service:
males age 16-49: 305,643
females age 16-49: 293,052 (2010 est.)
Manpower fit for military service: males age ''
16-49: 243,120
females age 16-49: 251,061 (2010 est.)
Manpower reaching militarily significant age
annually: male: 12,737
female: 12,389 (2010 est.)
Military expenditures: NA','66b06462fc102062b576c03295a2346246f381cd1b865bc5273d37458f933a07','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d939c96c413134347f27253f26ada68059a078558f19d88daccba7eb21ff572b',2025,'TG','Togo','military-and-security',1568,'Military branches: Togolese Armed Forces
(Forces Armees Togolaise, FAT): Ground Forces,
Togolese Navy (Marine du Togo), Togolese Air
Force (Force Aerienne Togolaise, TAF), National
Gendarmerie (2011)
Military service age and obligation: 18 years of
age for compulsory and voluntary military service;
2-year service obligation (2012)
Manpower available for military service:
males age 16-49: 1,577,572
females age 16-49: 1,589,715 (2010 est.)
Manpower fit for military service: males age
16-49: 1,104,536
females age 16-49: 1,158,061 (2010 est.)
Manpower reaching militarily significant age
annually: male: 74,036
female: 73,515 (2010 est.)
Military expenditures: 1.9% of GDP (2011)
country comparison to the world: 74','dcbd4606117f5a1b9f0f78b52026e2e44329b87215e6efb41b01e14c020a43b4','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('347123c97e83ae9c24976569dcfae4b81dcc30636116a55e1b8ff45490f7949f',2025,'TN','Tunisia','military-and-security',1592,'Military branches: Tunisian Armed Forces
(Forces Armees Tunisiens, FAT): Tunisian
Army (includes Tunisian Air Defense Force),
Tunisian Navy, Republic of Tunisia Air Force
(Al-Quwwat al-Jawwiya al-Jamahiriyah
At’Tunisia) (2012)
Military service age and obligation: 20-23
years of age for compulsory service, one year ser-
vice obligation; 18-23 years of age for voluntary
service; Tunisian nationality required (2012)
Manpower available for military service:
males age 16-49: 2,846,572
females age 16-49: 2,952,180 (2010 est.)
Manpower fit for military service: males age
16-49: 2,397,716
females age 16-49: 2,484,097 (2010 est.)
Manpower reaching militarily significant age
annually: male: 90,436
female: 87,346 (2010 est.)
Military expenditures; 1.5% of GDP (2012)
country comparison to the world: 98
Military branches: Turkish Armed Forces (TSK):
Turkish Land Forces (Turk Kara Kuvvetleri), Turk-
ish Naval Forces (Turk Deniz Kuvvetleri; includes
naval air and naval infantry), Turkish Air Force
(Turk Hava Kuvvetleri) (2010) .
Military service age and obligation: -41 years of
age for male compulsory military service; 18 years of
age for voluntary service; 15 months conscript obli-
gation for non-university graduates, 6-12 months for
university graduates; conscripts are called to register
at age 20, for service at 21; women serve in the Turk-
ish Armed Forces only as officers; reserve obligation
to age 41; under a law passed in November 2011,
men aged 30 and older who have worked 3 years in
foreign countries may pay $16,200 in lieu of manda-
tary military service (2012)
Manpower available for military service:
males age 16-49: 21,079,077
females age 16-49: 20,558,696 (2010 est.)
Manpower fit for military service: males age
16-49: 17,664,510
females age 16-49: 17,340,816 (2010 est.)
Manpower reaching militarily significant age
annually: male: 700,079
female: 670,328 (2010 est.)
Military expenditures: 5.3% of GDP (2005 est.)
country comparison to the world: 14
Military—note: the ruling Justice and Develop-
ment Party (AKP) has incrementally asserted its
supremacy over the military since first taking power
in 2002 and has reduced the role of the Turkish
Armed Forces (TSK) in internal security, increas-
ing the responsibility of the Turkish National
Police (TNP) in combating its Kurdish insurgency;
the TSK leadership continues to play a role in poli-
tics and considers itself guardian of Turkey''s secular
state; primary domestic threats are listed as fun-
damentalism (with the definition in some dispute
with the civilian government), separatism (Kurd-
ish discontent), and the extreme left wing; Ankara
strongly opposed establishment of an autonomous
Kurdish region; an overhaul of the Turkish Land
Forces Command (TLFC) taking place under
the “Force 2014” program is to produce 20-30%
smaller, more highly trained forces characterized by
greater mobility and firepower and capable of joint
and combined operations; the TLFC has taken on
increasing international peacekeeping responsi-
bilities, and took charge of a NATO International
Security Assistance Force (ISAF) command in
Afghanistan in April 2007; the Turkish Navy is
a regional naval power that wants to develop the
capability to project power beyond Turkey’s coastal
waters; the Navy is heavily involved in NATO,
multinational, and UN operations; its roles include
control of territorial waters and security for sea lines
of communications; the Turkish Air Force adopted
an “Aerospace and Missile Defense Concept” in
2002 and has initiated project work on an inte-
grated missile defense system; Air Force priorities
include attaining a modern deployable, survivable,
and sustainable force structure, and establishing a
sustainable command and control system (2008)','ad2cc64154d5732a73d08fd6e0fda9eedbd4669c6eaa404d82643394303420b6','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b5a31822672c211a5364fb0013cfed93b954f4ccdd658f975d58600303caba5f',2025,'TM','Turkmenistan','military-and-security',1600,'Military branches: Turkmen Armed Forces:
Ground Forces, Navy, Air and Air Defense Forces
(2013)
Military service age and obligation: 18-27 years
of age for compulsory male military service; 2-year
conscript service obligation, or 1 year for univer-
sity students; 20 years of age for voluntary service;
males may enroll in military schools from age 15
(2013)
Manpower available for military service:
males age 16-49: 1,380,794
females age 16-49: 1,387,211 (2010 est.)
Manpower fit for military service: males age
16-49: 1,066,649
females age 16-49: 1,185,538 (2010 est.)
Manpower reaching militarily significant age
annually: male: 53,829
female: 52,988 (2010 est.)
Military expenditures: 1.6% of GDP (2011)
country comparison to the world: 93','6e4decda727bdaf5c68eb89a388d8d232b42e35b95509da17d726f86dcbce76f','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ff5ec01c24f31528b208b57dc5df4aafa3546c483cdc54139decf475fa70d0d4',2025,'TC','Turks and Caicos Islands','military-and-security',1609,'Manpower fit for military service: males age
16-49: 11,842
females age 16-49: 11,755 (2010 est.)
Manpower reaching militarily significant age
annually: male: 338
female: 342 (2010 est.)
Military—note: defense is the responsibility of
the UK','716159ad29aa93566a0bdbf5f4a6bab77ba1f13c4af36fd2d0cef496954ee701','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cc07b9e7aa9309e408bd3683e7a8edd42ae3d035cfddc5b599f3198b450057c3',2025,'TV','Tuvalu','military-and-security',1616,'Military branches: no regular military forces;
_ Tuvalu Police Force (2012) i
Manpower fit for military service: males age
16-49: 2,021
females age 16-49: 2,026 (2010 est.)
Manpower reaching militarily significant age
annually: 11 19
female: 111 (2010 est.)
Military expenditures: NA','3e24954387c7101e10f554729619190fa937794464ee232a5cec9ce8e37ed782','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('aafb5b63a6cc1a0e20727ca6859236e0d3194f23a1bfb1027921173e2d454a4e',2025,'UG','Uganda','military-and-security',1625,'Military branches: Uganda Peoples Defense
Force (UPDF): Army (includes Marine Unit),
Uganda Air Force (2013)
Military service age and obligation: 18-26 years
of age for voluntary military duty; 18-30 years of
age for professionals; no conscription; 9-year ser-
vice obligation; the government has stated that
while recruitment under 18 years of age could
occur with proper consent, “no person under the
apparent age of 18 years shall be enrolled in the
armed forces”; Ugandan citizenship and secondary
_ education required (2012)
Manpower available for military service:
males age 16-49: 7,249,271
of czarist Russia in 1917, Ukraine was able to
achieve a short-lived period of independence
(1917-20), but was reconquered and forced to
endure a brutal Soviet rule that engineered two
forced famines (1921-22 and 1932-33) in which
over 8 million died. In World War II, German
and Soviet armies were responsible for some 7 to
8 million more deaths. Although final independ-
ence for Ukraine was achieved in 1991 with the
dissolution of the USSR, democracy and prosper-
ity remained elusive as the legacy of state control
and endemic corruption stalled efforts at eco-
nomic reform, privatization, and civil liberties.
A peaceful mass protest “Orange Revolution” in
the closing months of 2004 forced the authorities
to overturn a rigged presidential election and to
allow a new internationally monitored vote that
swept into power a reformist slate under Viktor
YUSHCHENKO. Subsequent internal squabbles
in the YUSHCHENKO camp allowed his rival
Viktor YANUKOVYCH to stage a comeback
in parliamentary elections and become prime
minister in August of 2006. An early legisla-
tive election, brought on by a political crisis in
the spring of 2007, saw Yuliya TYMOSHENKO,
as head of an “Orange” coalition, installed as
a new prime minister in December 2007. Vik-
tor YANUKOVUYCH was elected president in
a February 2010 run-off election that observers
females age 16-49; 7,025,439 (2010 est.)
Manpower fit for military service: males age
16-49: 4,313,068
females age 16-49: 4,200,901 (2010 est.)
Manpower reaching militarily significant age
annually: male: 423,923
- female: 420,236 (2010 est.)
Military expenditures: 1.8% of GDP (2012)
country comparison to the world: 76','72d3b8e9155a1906a11f12217cb1ecc9f4dd1aef0fb37873c6f745d63468a175','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('45cbc81193236474154a9fbc907b58bce3a62594945ff642676ac063e5809177',2025,'UA','Ukraine','military-and-security',1635,'Military branches: Ground Forces, Naval Forces,
Air Forces (2013)
Military service age and obligation: 18-25
years of age for compulsory and voluntary military
service; conscript service obligation is 12 months
for Army and Air Force, 18 months for Navy
(2012)
Manpower available for military service:
males age 16-49: 10,984,394
females age 16-49: 11.26 million (2010 est.)
Monpower fit for military service: males age
16-49: 6,893,551
females age 16-49: 8,792,504 (2010 est.)
Manpower reaching militarily significant age
annually: male: 246,397
female: 234,916 (2010 est.)
Military expenditures: 1.6% of GDP (2012)
country comparison to the world: 91','b4109e86bd0b94279bada21fdc60966f1695e4c1a5deaf9f6dd9ea470e34d743','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('031d014e0eba504e0b9201f5d944845c9fd99ff64923b2bfd7d905c1c090582a',2025,'AE','United Arab Emirates','military-and-security',1643,'Military branches: United Arab Emirates Armed
Forces: Critical Infrastructure Coastal Patrol
Agency (CNIA), Land Forces, Navy, Air Force
and Air Defense, Border and Coast Guard Direc-
torate (BCGD) (2012)
Military service age and obligation: 18 years of
age for voluntary military service; 18 years of age
for officers and women; no conscription; 16-22
years of age for candidates for the UAE Naval Col-
lege (2012) ;
Manpower available for military service: males
age 16-49: 2,676,928 (includes non-nationals)
females age 16-49: 981,649 (2010 est.)
Manpower fit for military service: males age
16-49: 2,229,366
females age 16-49: 842,759 (2010 est.)
Manpower reaching militarily significant age
annually: male: 27,439
female: 24,419 (2010 est.)
Military expenditures: 6.4% of GDP (2012)
country comparison to the world: 9','360974dadd171a9e925be6e7faa208f5d2e2bddc0bf6ec82793e7f19233194a8','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('968d2ae04de0f2a74a614a33b38fc58c1ebff11e2123b7bf86d3d088be6533ed',2025,'GB','United Kingdom','military-and-security',1652,'Military branches: Army, Royal Navy (includes
Royal Marines), Royal Air Force (2010)
Military service age and obligation: 16-33
years of age (officers 17-28) for voluntary mili-
tary service (with parental consent under 18); no
conscription; women serve in military services,
but are excluded from ground combat positions
and some naval postings; as of October 2009,
women comprised 12.1% of officers and 9% of
enlisted personnel in the regular forces; must be
citizen of the UK, Commonwealth, or Republic
of Ireland; reservists serve a minimum of 3 years,
to age 45 or 55; 17 years 6 months of age for vol-
untary military service by Nepalese citizens in
the Brigade of Gurkhas; 16-34 years of age for
voluntary military service by Papua New Guin-
ean citizens (2012)
Manpower available for military service: males
age 16-49: 14,856,917
females age 16-49: 14,307,316 (2010 est.)
Manpower fit for military service: males age
16-49: 12,255,452
females age 16-49: 11,779,679 (2010 est.)
Manpower reaching militarily significant age
annually: male: 383,989
female: 365,491 (2010 est.)
Military expenditures: 2.5% of GDP (2012)
country comparison to the world: 56','f883567d2a615001b1822d6cd61398f88a1beab230a359fdb71d02ff4f1a18a4','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d09a872085a7d894c59df0813ee17d889a0f843122c58aeea7b28523cabad9e2',2025,'US','United States','military-and-security',1661,'Military branches: United States Armed Forces:
US Army, US Navy (includes Marine Corps), US
Air Force, US Coast Guard; note—Coast Guard
administered in peacetime by the Department of
Homeland Security, but in wartime reports to the
Department of the Navy (2013)
Military service age and obligation: 18 years
of age (17 years of age with parental consent) for
male and female voluntary service; no conscrip-
tion; maximum enlistment age 42 (Army), 27
(Air Force), 34 (Navy), 28 (Marines); service
obligation 8 years, including 2-5 years active
duty (Army), 2 years active (Navy), 4 years
active (Air Force, Marines); DoD is eliminating
prohibitions restricting women from assignments
in units smaller than brigades or near combat
units (2013)
Manpower available for military service:
males age 16-49: 73,270,043
females age 16-49: 71,941,969 (2010 est.)
Manpower fit for military service:
males age 16-49: 60,620,143
females age 16-49: 59,401,941 (2010 est.)
Manpower reaching militarily significant age
annually: male: 2,161,727
female: 2,055,685 (2010 est.)
Military expenditures: 4.6% of GDP (2010)
country comparison to the world; 19
Militory—note: defense is the responsibility of
the US','b453a7adedf45b09f086f0ee3614ba03f619764bfba96ec1b516bb79d47cbcdb','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1d9df1a52561a97b8cb9a8fe4d6ea1190c941c4606999712b56db6bf0f3f5313',2025,'UY','Uruguay','military-and-security',1668,'Military branches: Uruguayan Armed Forces:
Uruguayan National Army (Ejercito Nacional Uru-
guaya, ENU), Uruguayan National Navy (Armada
Nacional del Uruguay; includes naval air arm, Naval
Rifle Corps (Cuerpo de Fusileros Navales, Fusna),
Maritime Prefecture in wartime), Uruguayan Air
Force (Fuerza Aerea Uruguaya, FAU) (2012)
Military service age and obligation: 18-30 years
of age (18-22 years of age for Navy) for male or
female voluntary military service; up to 40 years
of age for specialists; enlistment is voluntary in
peacetime, but the government has the author-
ity to conscript in emergencies; minimum 6-year
education (2012)
Manpower available for military service:
males age 16-49: 771,159
females age 16-49: 780,932 (2010 est.)
Manpower fit for military service:
males age 16-49: 649,025
females age 16-49: 654,903 (2010 est.)
Manpower reaching militarily significant age
annually: male: 27,564
female: 26,811 (2010 est.)
Military expenditures: 0.9% of GDP (2012)
country comparison to the world: 132','4206a4c34d704a98e59da0dd67496d146aabd8eb4e874bb702aa8ebaa0e4c76c','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0bc48a253603c29727adae9e1eb23790ba57b7fa8ab2c8bc4712acad748e1a37',2025,'UZ','Uzbekistan','military-and-security',1677,'Military branches: Army, Air and Air Defense
Forces (2013)
Military service age and obligation: 18 years
of age for compulsory military service; 1-year con-
script service obligation; moving toward a profes-
sional military, but conscription will continue;
the military cannot accommodate everyone who
wishes to enlist, and competition for entrance
into the military is similar to the competition for
admission to universities (2012)
Manpower available for military service:
males age 16-49: 7,887,292
females age 16-49: 7,886,459 (2010 est.)
Manpower fit for military service:
males age 16-49: 6,566,118
females age 16-49: 6,745,818 (2010 est.)
Manpower reaching militarily significant age
annually: male: 306,404
female: 295,456 (2010 est.)
Military expenditures: 3.5% of GDP (2010)
country comparison to the world: 34','008063596aedf784f7044a29cd38a175ecc540343e477360008dee501dd3cc08','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6006b528c53ebe880aef682bab7861135448c6f4e29fa092378d458f28dd63c0',2025,'VU','Vanuatu','military-and-security',1687,'Military branches: no regular military forces;
Vanuatu Police Force (VPF), Vanuatu Mobile
Force (VMF; includes Police Maritime Wing
(PMW)) (2013)
Manpower available for military service:
males age 16-49: 62,216 (2010 est.)
Manpower fit for military service: males age
16-49, 43,331
females age 16-49: 44,927 (2010 est.)
Manpower reaching militarily significant age
annually: male: 2,323
female: 2,230 (2010 est.)
Military expenditures: NA','fdd7e58e87880a2564da84e8a5f77c59120de1e80465e4fe68510f700c983673','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1af02fce2256ca62e29988e3185cb7a72c42b3f0c2f8ea5d5de79789a4e307a8',2025,'VN','Viet Nam','military-and-security',1694,'Military branches: People’s Armed Forces: Peo-
ple’s Army of Vietnam (PAVN; includes Vietnam
People’s Navy (with Naval Infantry), Vietnam
People’s Air and Air Defense Force, Border
Defense Command) (2013)
Military service age and obligation: 18-25
years of age for male compulsory and voluntary
military service; females may volunteer for active
duty military service; conscription typically takes
place twice annually and service obligation is 18
months (Army, Air Defense), 2 years (Navy and
Air Force); 18-45 years of age (male) or 18-40
years of age (female) for Militia Force or Self
VIETNAM
Defense Force service; males may enroll in mili-
tary schools at age 17 (2013)
Manpower avallable for military sarvica;
males age 16-49: 25,649,738
females age 16-49: 24,995,692 (2010 est.)
Manpower fit for military service:
males age 16-49: 20,405,847
females age 16-49: 21,098,102 (2010 est.)
Manpower reaching militarily significant age -
annually: male: 847,743
female: 787,341 (2010 est.)
Military expenditures: 2.5% of GDP (2005 est.)
country comparison to the world: 54','f138b6a96b3dac45829e90716d44f26254f0d7f02cb998f6c10c71ce771ea3bf','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9a284f8703b9ca5d2945ddc4e5e7853c15676ed7893af11d5eb5cf7c0cdca2ed',2025,'WF','Wallis and Futuna','military-and-security',1703,'Military—note: defense is the responsibility of
the US; the US Air Force is responsible for overall
administration and operation of the island facili-
ties; the launch support facility is administered by
the US Missile Defense Agency (MDA)
Manpower fit for military service:
males age 16-49: 3,376
females age 16-49: 3,314 (2010 est.)
Manpower reaching militarily significant age
annually: male: 168
female: 139 (2010 est.)
Military—note: defense is the responsibility of','f4af3b7909cd70c5265bb1c245230a8eb79ddeb5c0d4a0622a8cc671cd5a39d8','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7627e72294a8347c7d6c737100b4696eb4d24da3678899e6dc56ca0aea820ed6',2025,'EH','Western Sahara','military-and-security',1718,'Manpower fit for military service:
males age 16-49: 79,489
females age 16-49: 87,362 (2010 est.)
Manpower reaching militarily significant age
annually: male: 5,523
female: 5,429 (2010 est.)
Military expenditures: roughly 2.1% of GDP of
gross world product (2012 est.)','eda8450114d447d4605f68a80c1ddd81bf6965a84443372f7c555c2d5244d5ec','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9d95c082d0aef4689b96a7fd2415d87dc03ad682703d6b47eb4b33a89e236ba3',2025,'YE','Yemen','military-and-security',1723,'Military branches: Land Forces, Naval and
Coastal Defense Forces (includes Marines), Air
and Air Defense Force (al-Quwwat al-Jawwiya
al-Yemeniya), Border Guards, Stategic Reserve
Forces (2013)
Military service age and obligation: 18 is the
legal minimum age for voluntary military service;
no conscription; 2-year service obligation (2012)
Manpower available for military service:
males age 16-49; 5,652,256
females age 16-49: 5,387,160 (2010 est.)
Manpower fit for military service: males age
16-49: 4,056,944
females age 16-49: 4,1 16,895 (2010 est.)
Manpower reaching militarily significant age
annually: male:287,141 ''
female: 277,612 (2010 est.)
Military expenditures: 6.6% of GDP (2006)
country comparison. to the world: 8
Military—note: a Coast Guard was established
in 2002
TRANSNATIONAL (SSUES
Disputes—international: Saudi Arabia has rein-
forced its concrete-filled security barrier along sec-
tions of the fully demarcated border with Yemen to
stem illegal cross-border activities
Refugees and internally displaced persons:
refugees (country of origin): 4,686 (Ethiopia)
(2011); 229,447 (Somalia) (2013)
IDPs: at least 431,000 (conflict in Sa''ada gover-
norate; clashes between AQAP and government
forces) (2012)
813
‘alae ic. - ca
REPUBLIC OF THE =~ Vanam ag
CONGO i P
Kosar,
seeps
ma
{
k-
Kapiri Mposhi,
*
x
LUSAKA, ie
v
\\ ZIMBABWE
BOTSWANA he
$90 200 arr
area','9fcbc3a82825ff55080b08ed1cb57b997fceea37db777c65b66ed81222598cd4','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('26203a7f988c191486c75d36cf66b4d3231f10d3ecd66f934e8845a4bc2c0862',2025,'ZW','Zimbabwe','military-and-security',1728,'Military branches: Zambian National Defense Force
(ZNDF): Zambia Army, Zambia Air Force, National
Service (paramilitary youth organization) (2012)
Military service age and obligation: national
registration required at age 16; 18-25 years of age
for male and female voluntary military service
(16 years“of age with parental consent); no con-
scription; Zambian citizenship required; grade 12
certification required; mandatory HIV testing on
enlistment; mandatory retirement for officers at
age 65 (Army, Air Force) (2012)
Manpower available for military service:
males age 16-49: 3,041,069
females age 16-49: 2,948,291 (2010 est.)
Manpower fit for military service: males age
16-49: 1,745,656
females age 16-49: 1,688,670 (2010 est.)
Manpower reaching militarily significant age
annually: male: 158,592
female: 158,805 (2010 est.)
Military expenditures: 1.8% of GDP (2012)
country comparison to the world: 82
Military branches: Zimbabwe Defense Forces
(ZDF): Zimbabwe National Army (ZNA), Air
Force of Zimbabwe (AFZ), Zimbabwe Republic
Police (ZRP) (2009)
Military service age and obligation: 18-24 years
of age for voluntary-military service; no conscrip-
tion; women are eligible to serve (2012)
Manpower available for military service:
males age 16-49:2,616,051
females age 16-49: 2,868,376 (2010 est.)
Manpower fit for military service: males age
16-49: 1,528,166 ‘
females age 16-49: 1,646,041 (2010 est.) `
Manpower reaching militarily significant age
annually: male: 154,870
female: 152,550 (2010 est.)
Military expenditures: 3.8% of GDP (2006)
country comparison to the world: 27','aaaaed97803f995eef8659a7ed0e06dfb4be1bb50736233f2396581b2ab50aec','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);

SET NAMES utf8mb4;
CREATE TABLE IF NOT EXISTS worldfactbook_chunks (
  chunk_id CHAR(64) NOT NULL,
  edition_year SMALLINT UNSIGNED NOT NULL,
  entity_code VARCHAR(24) NOT NULL DEFAULT '',
  entity_name VARCHAR(160) NOT NULL DEFAULT '',
  category VARCHAR(96) NOT NULL,
  ordinal INT UNSIGNED NOT NULL,
  content MEDIUMTEXT NOT NULL,
  content_sha256 CHAR(64) NOT NULL,
  source_provider VARCHAR(64) NOT NULL,
  source_identifier VARCHAR(255) NOT NULL,
  source_format VARCHAR(32) NOT NULL,
  source_sha256 CHAR(64) NOT NULL,
  source_url TEXT NOT NULL,
  extractor VARCHAR(64) NOT NULL,
  PRIMARY KEY (chunk_id),
  KEY idx_wfb_year_category (edition_year, category),
  KEY idx_wfb_entity_year (entity_code, edition_year),
  KEY idx_wfb_source_sha (source_sha256)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ab389de15348fd5a93651633f6d170a4b083bac9b7e89103648333cdbe9797f0',2025,'CH','Switzerland','space',1793,'tons, shipping cubic meters of permanently enclosed cargo 1.189 307 574
tons, short avoirdupois pounds 2,000
tons, short kilograms 907.184 74
tons, short long hundredweights 17.857 14
tons, short long tons 0.892 857 1
tons, short metric tons 0.907 184 74
tons, short short hundredweights 20
townships (US) sections 36
townships (US) square kilometers 93.239 572
townships (US) square statute miles 36
miles, square statute acres 640
miles, square statute hectares 258.998 811 033 6
miles, square statute square feet 27,878,400
miles, square statute square meters 2,589,988.110 336
miles, square statute square yards 3,097,600
yards centimeters 91.44
yards feet 3
yards inches 36
yards meters 0.914 4
yards miles 0.000 568 18
yards, cubic bushels 21.696 227
yards, cubic cubic feet 27
yards, cubic cubic inches
912
46,656
WEIGHTS AND MEASURES
?
Conversion Factors = = To l Multiply By
To Convert From -
yards, cubic cubic meters 0.764 554 857 984
yards, cubic gallons 201.974 0
yards, cubic liters 764.554 857 984
yards, cubic pecks 86.784 91
yards, square . acres 0.000 206 611 6
yards, square _ hectares 0.000 083 612 736
yards, square square centimeters 8,361.273 6
yards, square square feet 9
yards, square square inches « 1,296
yards, square square meters 0.836 127 36
- yards, square . square miles 0.000 000 322 830 6
913
rae
AZORES |
(PORTUGAL) ~
_.. PORTUGAL
Lisbon y {
Algiers .
MADEIRA ISLANDS
y] Oran,
(PORTUQAL) —
ean o
Rabat _7@ Constantine
Casablanc. }
oh e
CANARY ISLANDS j
SFAI)','e1af9a69867cc0f5268de998a3ad2f4fa1a33675f48d40da420c990d5ac6df8b','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('76e01a9048d04b967efd25a1f990ae6afee08f8b5bda46e99b3948f62ced5041',2025,'GW','Guinea-Bissau','space',1794,'Conakry,
Freetown
SIERRA LEONE 7}
Bamako
*
GUINEA |
al;
| EQUATORIAL QUINEA
AFRICA
Tunis siy
SAOTOME | ;
AND PRINCIPE Yr a Lib
São Tomé
Annobdn
(QUA. QUI.)
Braz
Pointe-Noire
H','1b31e90a539577b5c2a97eb1d3b40177a4c1a04326dc9a990d644240e07f24c9','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('140d59fefaae5d779aeabcd05ffa6bdff18dc7fb377934da3af8befee8b0b1f4',2025,'AO','Angola','space',1795,'Cabinda)
Ascension
St. Helena
Salnt Helena, Ascension,
and Tristan da Cunha
(U.K)
TRISTAN
DA CUNHA
Gough Island
914
qrvanda i
» ANGOLA
Namibe, Lubango
‘
Windhoek
Walvis Baya W
Cape Town,
d + E
‘mm © CYPRUS IEB
g DEM. REP.
OF THE CONGO
Mbuji-Mayi « XN
Beirut
aa letuseló Wha nian
‘>
. x n * é
z Ahu
BAHR. i
Dhahi
Riyadh y GATAR B N ni
SAUDI
ARABIA
Kisangani Kampale
Bukavu i
Dar es
Salaam
{ D] 4 COMOROS: Cloriose islands
nS
Í
ial i','c91215aff1d5b09a450184d3647ca857599b0b1999620f7ed7cc01fb138d5c2b','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('311d6682895f39923afd4f6730c2835ca7fb9b0df1c376780b6badd387cd4005',2025,'SC','Seychelles','space',1796,'é
Luby
A
gMoronl —— RANCE)
Mayotte —) P
TAR 8} Gaston 5
My ike Nowa g
ns “apes:
BIQUE memanng
®antananarivo Por
bee, S Denis, A
AIG, ue MADAGASCAR nemer’
(PRANCE)
Imilian Ocean
Port Elizabeth
Scale 1:51,400,000
Azimuthal Equal-Area Projection
0 800 Kilometers
h_e :
o 800 Miles
Boundary representation is
not necessarily authoritative.
603535Al (G00392) 6-12
REFERENCE MAPS
ANTARCTIC REGION
aR pmi
i — ` Port Flizabeth ae 7 MT
i,
® Year-round research station a i | Di 9 f NEREA” A
soúthlatlantic << ~~
Scale 1:68.000,000
Animatii Bqual-Ance Projection - =
D WO Wm '' ! Ocean `S
=. ” A Ary,
E iar so '' 1000 Mha = panene Te / Ss
‘Twenny-ome of DS artarak comeallathe comar hurt — | a ee Ym, f ; S
made ma chskns ty AMARIK leery na Rik and "= as È
+ Ue ae amr ree pe nap a A ` . `
~ ~~ they do dt recogrine the chalews of the other i Bouvet hand B
ox MORAN : PRINCE EDWARD RDANDS
v4 i OSOURH APHITAY `,
send Deana aud Pi
a Senate SANDART tan BRITISH S N,
f a CLAM ooe = H oon ;
zd ages an sents 5 " \\
i i" southern fras
a 1 | NORWEGIAN CLAIM ` k oe
$ `, n F «eae a a
A ARGENTINE s N en po ese Joe T ont `
Serot pian k CLAM E p — ae, 1 : b
Satsa Maly $ ` g pS Soap f E a
‘ Se: ” man á Onadas ` ` SANAE n 2 french uthe:
stamens e H vaia een JE ARGENTINA; = Neumayer psti Novolazarevska En, oni AA aes
SeSTHOWNEY 7 ARMAN ARICA a RUSA 1
ls N Rak
= p s a Y 7 A — ? Sw 2 .RAPAM) a a
3 met ~ > Be '' am Aloldezhaaya A š
7 EO Queen Med Land é pas has
angeencot 3 . ety Abit: uth / 4 VERRES = KERGUELEN: g
3 ES Epey. Kà d - \\
t . at Mawson H 4
n Aaa O VAUSYRAIA bona Wians \\
‘ n a” tye VADSTALID |
i d Fi oA ee ae
\\, thong shami AN .
\\ Progress iRtISsa4} BA pere
| TR: . indian
: | A a|
apm ma ane k i
{ Vostok RUSS Veean |
Í g EUSA j- la £ 4
Marte tard < Fa “ Concordia (3 «3% weonne
ures N urmarce an f= g l
— i i @ITALY) f4 ;
i ~
A us ;
f
? /
d È ’ f
Viton Lra i f
5 pA E aaa ol mainan durite :
— i . á \\ RACE) Ae y
g A k .. b -N
x AULENY + w ve , k
EAN : ” FRENCH nie 74
Southern ‘ \\ CLAIM at f
cae te ,
EALAN, = i acl . s
O CLAM a >i P
AAmpamrke (chinnd T “ 5 j
STRAY
South oars X #
Sou \\
NEW EALO MA KLANI Te ¢ “
Pacitl« Z O EIEE i Tes asanla a
Alhan O Fa ELN
K ’ i f Š i aa =a : ndaika ‘|
? s sg P setbourne
NEW W E oy y
4 seth ‘ ‘i 4
CUATHAAEISANDS ae a Me ~4 hind \\ Canberra
PW UAN meharra ''
Wellington, / N AUSTRALIA
j ngi E g. me. Pa
2 E North istand 1 a
EVIA T2A) (ROZ207) 8-
915
916
THE CIA WORLD FACTBOOK
PHYSICAL MAP OF ARCTIC REGION
POLITICAL MAP OF ARCTIC REGION
T a
REFERENCE MAPS
Py ite
o Provideniya,
ate hay romp
Wrongel ™ =e”
tsiand ai
í 4 *. PRS
j x
Aret ie Ocean S PY Anadyy
| À ast sewn ~
a SEVERNAYA
bie s 2EMLIA za i Sherskly.
Magadan® ’.
a Petropavlovsk-
Kamchatskiy s
x 5 ~l
Yakutsk®
PUG SIN ee P
oy
Yekaterinburg: SS Qeeuphed by ihe Soviet Union In 2845,
w i ~ ii administered by
Chelyabinsk A A F cdulmed by Japas
'' Sakhalin
Khabarovsk, i
Harbin
Changchun, i *Viadivostok
Shenyang,
Belji 3
Mey ó Dahan
o- ym
alywan ‘Qingdao
AFGHANISTAN N
Kabul”,
-Philippine
sea
zon
l jey
Antal RA]
siit Bay of
LAKSHADWEEP k
UNDIAN Bengal','270313534549fe37ba78446a01a3dfaad5f9df676d43df575e9342e9bcc7f7f3','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b7182110eed239022255bd96c84890415400511bbe9a6b9ff7552c5417eb6c48',2025,'MV','Maldives','space',1797,'* Male
a a M J À
Scale 1:48,000,000 ] LN D-O-N E 1 A o
'' Azimuthal Equal-Area Projection | Jakarta ae eat gh TMORLESTE
Timer
D ; Indian - =i?
{ j P 7
re on . Ocean i o pri
g ’ Cocos 2 i y
Boundary representation Is ta À L : © AUSTRALIA
not necessarily authoritative,
803537A! (G00543) 6-12
917
Gulfiof Mexico
| A
I
North
Pacific
Ocean
pio dt Core
Scale 1: 12,500,000 “New
Lambert Conformal Conic Projection,
Handard parallels 7°N and 24° N
918
N Buas
gil toro cole,
=
Prt ag PAN AMA
oe
a
THE CIA WORLD FACTBOOK
at
wao
THE BAHAMAS
REFUBUC','d5b413e78c51a0e4a86ba1742fae207789ea8818f47de1c40a6d147e8f066854','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9fa17975b82270498cdbdf14e775f74f0fe14f0dc366d04076d70b2c3bc2eff5',2025,'AW','Aruba','space',1798,'inean
Oranjestad g,
nl
Hie
“re
Sarrangallay
Cartagena,
city
Noden,
wan COLOMBIA
Perei,
Armena,
Muenaventura
cah
Curacao
weenie
CENTRAL AMERICA AND THE CARIBBEAN
North
Atlantic
Ocean
tne
Fort de saci TE
Cta
wm LUCA
Kingrtowe y
SAINT VAK TT AND
THE GRENADINES
Mare
ome
e- a REFERENCE MAPS
Sdit
Barents
‘ (NORWAY) ep \\ i, Sea \\
E k A
C
NUJ
o
. KA
Pe iG A
‘
,
K
p 4
©" yarkhangel''sk
— i
bi Faroe Islands Ga i pd a
* sl SV A O J
% (DENMARK) : í DA _ font a
SHETLAND go wom ao
_ 2 Saint Petersburg eh
ISLANDS. f 3
M
or a A KJ .
Atlantic
E N
$ Kaliningrad, pussia
Bornholm.
Guernsey Uny
Jersey t a
Black
sea
"Florence IN
Adnan = S
ITALY N
Rome ~-
VATICAN
Madrid, , “parcelona aw `
oe i 7 Naples
SPAIN valencia, ` 4 -< _Sardinta’
BALEARIC gwliart
ISLANDS 2
Letra one
a l >
SM algters J Scale 1:19,300,000
Maia ©;
sam O''A Lambert Conformal Conic aks pee
iy MALTA standard parallels 40°N and 68°N
ALGERIA 300 Kilometers
803539AI (GO0772) 6-12
919
THE CIA WORLD FACTBOOK
MIDDLE EAST
} <> UKR Ary E A
f Sevastopolj — aa re
Sconstanya A
Nicosia k
CYPRUS `‘
ihe
iterranean | sea
t e
al Bajin ain PerstaiL
Gulf ae
„Buraydah Ad TORRE
AR Abu
im Riya dh oha -
"A SAUDI *
Halaib y Fai ARABIA
“Mecca','bbfcebf4645a1adfc3a0a7e9b1cd7fc6f084f8de7efd2dd7618a4f8ffc0cda23','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2a2fac47c7fb9b7761339ad2e71589993d29324042ab5f47e7dc45af05efe5f3',2025,'SD','Sudan','space',1799,', Omdurmany Khartoum
p Kassala,) f
~A wad
Medani f R s Arabian Sea
= eorr
(YEMEN)
Scale 1:21,000,000 a Ala ae Pomme m
Lambert Conformal Conic Projection, Ee -e eee SEE . : rbera ——t ea ani iae-oscupied with cure satus subject to |
° oe: [the tsrae!l-Palestintan interim tt
standard parallels 12°N and 38°N Ad dis Ababa, H cami ean aa un status |
o 300 Kilometers -
’ , i : A ~ f The status of the Gaza Strip Is a final status issue tb be
0 300 Miles ; Beale : a resolved through negotiations.
Boundary representation is z E T H 10 2e H y" di israel proclaimed jerusalem as Its capital in 1950, bul the
not necessarily authoritative. `}. i i E ta ime ` u Hike nearly all other countries, maintains its Embassy In
g Aviv-Yato
803540A! (G00412) 6-12
920
REFERENCE MAPS
NORTH AMERICA
Ps veer
—_—
Minneapolis”
| Salt Lake city Omaha,
San Francisco, sseeramenio
Los Angeles
San Diego
Kansas City?
5 i A T E S.
Phoenix "Albuquerque
i
}
a i; 5 wy P
er Matamoros
Scale: 1:36,000,000
Lambert Conformal Conic Projection,
standard parallels 25°N and 77°N
o 300 / 600 kilometers
o 300 600 miles
alas vekna
UN I T E D Chicagos Foe Pittsburg!
A 3
¿louis
~f
nE jacksonville,
‘$
o 5
Austin, Hoyston >. PRD ad
Jan Mayen
reenfan? Ser
noRway)
bs
Osemark
E Sirat
j Qaqorte
(lulianehab)
Ns
Vita
island of
Newfoundland
St Piere
and Miquelon
PRANCE)
Sydney
Wiottetown
on
“Halifax
À phn
Boston
SProvidence
“Hartford
#New York
h Philadelphia
ed
dshington, D.C.
ea “Virginia Beach
"Louisville ° \\ E
Nashville T
Ici Niama Y
“Birmingham £
a
Buffalo
Saint
North
Atlantic
a GRESS 41
iA" Orlando,
ampa
Miami, *
THE BAHAMAS
Nassau.
,
eC UBA arnt
> “a
vag hsingston','71ff7f6bd07b304abf271cf0aa8c4ae4d4e35ea66f644913d8ffad84751ace92','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c02ad68e560cec11b0444c34b3eb613f662942a0a3c7c477aa6f54d74a286e26',2025,'SV','El Salvador','space',1800,'803541A1(G00694)6-12
921
THE CIA WORLD FACTBOOK
OCEANIA
Weston?
CHINA ius,
guanin Joint
Northern
Marlana
tanur At
- Saipan, Islands :
Maysins |
PHILS? PEE S os
pe, ae E. ‘ * MARSHALL
foe FEDERATED STATE''S OF MICRONESIA - 7 ISLANDS
elo
he i
Palihi
Stare
hin
PALAU SARDINI MANDS `,
amiar
Taawa, orerar
aypa
Yaren (valrtet
NALH
eaan
imwa ak
PAPUA NEW QUINTA KIRIBATI waar)
ayr nena:
LNDIONESI AT, E E š SOLOMON
ni. mi a ISLANDS alunan KIRIBATI <
- z Massa
a” monies pot : ani ssanie TUVALU
Moresby ` Bavin
yor
+
4 wea
a re YOR Paga
MAN latae Apa? ahago
'' hall Utu Arrera mn
yA UÍ VANUATU FIL > s
Coral Sea a: 4
Islands
Maust ap LANSIRALA T ` TONGA
Shuki Alofa 2 French Polynesia
j THANE:
Sane gs','ce657bb5127e5da3f72b26e7026e94dc88eac8c0d2168972ff3fea7e034e1154','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('367104028272adbbde85835e16078a7b3a534888e4bbe99c0577ff47cf92dc5f',2025,'AU','Australia','space',1801,'PERT
siew
paih prar ni
z * and Hone eat
pantar 7 Precio
wag er
tatone, Deine
NEW wefan Shoes
ZEALAND Z aa
a
Wellingion
iar, Tuno d p Scale 1 41 009,000
Eronu conceal
mened,
"South istand ;
canes Thune p oe
BSAA. (50''577. O12
922
. REFERENCE MAPS
| PHYSICAL MAP OF THE WORLD
: E .
As . srl
-È = Te
A Baatit wt a =<
e''s . }
Kai
923
924
THE CIA WORLD FACTBOOK
PHYSICAL MAP OF SOUTH AMERICA
_POLITICAL MAP OF SOUTH AMERICA
a. = i
BRAZIL °
Aua n
i A kä m p
é
ee
REFERENCE MAPS .
PHYSICAL MAP OF SOUTHEAST ASIA
Y
vo
:
eee, OS
wnt, ome
ini
we
E
—
=
Philippine
Hewett
925
‘
THE CIA WORLD FACTBOOK
(Pree a wamere amg stoa at
en
Tr ee
yma
nt me arre ee mm te ew a am U
wt SSS
926
REFERENCE MAPS
_ UNITED STATES
i
j
H
th
en
i T
Providenlya sr
\\ FA
Gulf of Alaska
Scale 1:37,000,000
o 400 Kilometers
400 Miles
(RO2418)
Nurth takata
hri EU A ot
i Minnesota.
St Paul |
“Ss Wiscbesin
| 4
i \\ Lans
} a TR \\ } nee i *
hf Detro! Nir Peansylvania §
towa yChicagoy Ls af ; Philadelphi e
\\
c] 7
Des Moines `
bis- "3
a ae er
3 _ Springfie ld, [Indianapojis
kaain th St tod
e
Kansas | Jefferson City |
Missouri
y”
North
Eni P
Atlanti
New Mexico a fe i |
ta 7 f Y
j
Sath y
y~ Ank Y Santafe j | : \\ TA ennessee Mo H7 )
i R nge \\ ry ° j | ipana geen n <i caleba
Pp Ocean
i. Pacitic .
Ocean
}
f
i
Scale 1: 27 000,000 \\
| -Albers Equal-Area Projection Y f
standard parallels 28°30''N and 45 “30m j of Ff Méxizo
$00 Kilometers v l &
SA cae ee Se eee t
kut Miles
Teo
id . i
fer North Pacific Ocean
{
. Kauni
7 42% Honolulu
Scale 1:34,000,000 | adhu © a
400 Kilometers |
400 Miles E> i j í | (R024119)
3 802907 Al 6-02
927
THE CIA WORLD FACTBOOK
CENTRAL BALKAN REGION
:
`
L aT T i
HUNGARY coe
Pee
veawre f
i Via :
x rei
“ae
ange’ Riyals
tlie Sipha oe f
BOSNIA Seda ¢
f
i pam SERBIA
_ HERZEGOVINA
GAT trey Se a
A ` p4
ferra
-ALBANIA
Vanini y tomate”
irder tatiy Roeedory
Ring (84)
(eytes egrectoret hae?
Sale 1D.eOO UK
Lowder Compre! Com Prepatie
Ranmeheonl prasiet: RIES N ond ato 1S &
a ea terete oe,
ROMA Gr) 6 Oe
928
Reference
JHE COUNTRYBYCOUNTRYG E TO THE W.
T OF SEVENTY YEARS OF CIA INTELLIGENCE
From Afghanistan to Zimbabwe, T/ tbook < offers complete
and up-to-date information on the world’s nations. This comprehensive guide is
packed with detailed information on the politics, populations, military expendi-
tures, and economics of 2014.
For each country,
Factbook 2014 includes:
Detailed maps with new geopolitical data
Statistics on the population of each country, with details on literacy rates,
HIV prevalence, and age structure
New data on military expenditures and capabilities
Information on each country’s climate and natural hazards
Details on prominent political parties, and contact information for
diplomatic consultation
Facts on transportation and communication infrastructure
And much more!
Also included are appendixes with useful abbreviations, international environ-
mental agreements, international organizations and groups, weight and measure
conversions, and more. Originally intended for use by government officials, this is
a must-have resource for students, travelers, journalists, and businesspeople with
a desire to know more about their world.
The ‘al j is an independent agency responsible for pro-
viding national security intelligence to senior US policymakers. The CIA is separat-
ed into four basic components: the National Clandestine Service, the Directorate
of Intelligence, the Directorate of Science & pb seas a sie Uiraniornta of
Support. They carry out “the intelligence cycle,”
yt" wit i i int |
ing, and disseminating intelligence il iit i"
J 781 626300 730
0/23/2019 7:43-2
Skyhorse Publishing, Inc. rina
New York, New York i |
0730
www.skyhorsepublishing.com
Printed in Canada 9"781626"36','1217e5ef4db029f466e8c9afafb8a07720573f778d2ad672d6a458152a92c8d4','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);

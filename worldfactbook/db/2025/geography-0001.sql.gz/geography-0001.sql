SET NAMES utf8mb4;
CREATE TABLE IF NOT EXISTS worldfactbook_chunks (
  chunk_id CHAR(64) NOT NULL,
  edition_year SMALLINT UNSIGNED NOT NULL,
  entity_code VARCHAR(24) NOT NULL DEFAULT '',
  entity_name VARCHAR(160) NOT NULL DEFAULT '',
  category VARCHAR(96) NOT NULL,
  ordinal INT UNSIGNED NOT NULL,
  content MEDIUMTEXT NOT NULL,
  content_sha256 CHAR(64) NOT NULL,
  source_provider VARCHAR(64) NOT NULL,
  source_identifier VARCHAR(255) NOT NULL,
  source_format VARCHAR(32) NOT NULL,
  source_sha256 CHAR(64) NOT NULL,
  source_url TEXT NOT NULL,
  extractor VARCHAR(64) NOT NULL,
  PRIMARY KEY (chunk_id),
  KEY idx_wfb_year_category (edition_year, category),
  KEY idx_wfb_entity_year (entity_code, edition_year),
  KEY idx_wfb_source_sha (source_sha256)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('353d554adbd3d1dbd2223677d425cf38040698a9af44bb1e00d5927ed21c832d',2025,'AF','Afghanistan','geography',24,'Location: Southern Asia, north and west of Paki-
stan, east of Iran
Geographic coordinates: 33 00 N, 65 00 E
Map references: Asia
Area: total: 652,230 sq km
country comparison to the world: 41
land: 652,230 sq km
water: 0 sq km
Area—comporative: slightly smaller than Texas
Land boundaries: total: 5,529 km
border countries: China 76 km, Iran 936 km,
Pakistan 2,430 km, Tajikistan 1,206 km, Turk-
menistan 744 km, Uzbekistan 137 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
Climate: arid to semiarid; cold winters and hot
summers
Terrain: mostly rugged mountains; plains in north
and southwest
Elevation extremes: lowest point: Amu Darya
258 m
highest point: Noshak 7,485 m
Natural resources: natural gas, petroleum, coal,
copper, chromite, talc, barites, sulfur, lead, zinc,
iron ore, salt, precious and semiprecious stones
Land use: arable land: 11.95%
permanent crops: 0.18%
other: 87.87% (2011)
Irrigated land: 32,080 sq km (2003)
Total renewabie water resources: 65.33 cu km
(2011)
Freshwater withdrawal (domestic/industrial/
agricultural): toral:20.28 cu km/yr (1%/1%/98%)
per capita: 823.1 cu m/yr (2005)
Natural hazards: damaging earthquakes occur in
Hindu Kush mountains; flooding; droughts
Environment—current issues: limited natural
freshwater resources; inadequate supplies of pota-
ble water; soil degradation; overgrazing; deforesta-
tion (much of the remaining forests are being cut
down for fuel and building materials); desertifica-
tion; air and water pollution
Environment—international agreements:
party to: Biodiversity, Climate Change, Deser-
tification, Endangered Species, Environmental
Modification, Marine Dumping, Ozone Layer
Protection .
signed, but not ratified: Hazardous Wastes, Law of
the Sea, Marine Life Conservation
Geography—note: landlocked; the Hindu Kush
mountains that run northeast to southwest divide
the northern provinces from the rest of the coun-
try; the highest peaks are in the northem Vakhan
(Wakhan Corridor)','d73b9755a13ca90106cc4a157cd8b0fb2ca02635987ef4a6ca4e226bfdb48ee4','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4ec4888170625062a8a5fdf5bbc55fdb48b9e191b23197661f77c325478bfb78',2025,'CY','Cyprus','geography',33,'Location: Eastern Mediterranean, peninsula on
the southwest coast of Cyprus
Geographic coordinates: 34 37 N, 32 58 E
Map references: Europe
Area: total: 123 sq km
4
country comparison to the world: 224
note: includes a salt lake and wetlands
Area—comparative: about 0.7 times the size of
Washington, DC
Land boundaries: total: 47.4 km
border countries: Cyprus 47.4 km
Coastline: 56.3 km
Climate: temperate; Mediterranean with hot, dry
summers and cool winters
Environment—current issues: hunting around the
salt lake; note—breeding place for loggerhead and
green turtles; only remaining colony of griffon vul-
tures is on the hase
Geography—note: British extraterritorial .rights
also extended to several small off-post sites scat-
tered across Cyprus; of the Sovereign Base Area
(SBA) land, 60% is privately owned and farmed,
20% is owned by the Ministry of Defense, and 20%
is SBA Crown land','57fcb2bc93d6cc7b5202eaeacf21ba87d2c6cfa5897afacbb0c3f9350a8e6b41','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('452a7c49eb41a171f39076bf3a78793fa76d43c21462a741fccb779d5fa2b434',2025,'AL','Albania','geography',40,'Location: Southeastern Europe, bordering the
Adriatic Sea and Ionian Sea, between Greece
in the south and Montenegro and Kosovo to the
north
Geographic coordinates: 41 00 N, 20 00 E
Map references: Europe `
Area: total: 28,748 sq km
country comparison to the world: 145
land: 27,398 sq km
water: 1,350 sq km
Area—comparative:
Maryland
Land boundaries: total: 717 km
border countries Greece 282 km. Macedonia 151
km, Montenegro 172 km, Kosovo 112 km
Coastline: 362 km
Maritime claims: territorial sea: 12 nm
continental shelf: 200 m depth or to the depth of
exploitation
slightly than
smaller
Climate: mild temperate; cool, cloudy, wet win-
ters; hot, clear, dry summers; interior is cooler and
wetter
Terrain: mostly mountains and hills; small plains
along coast
Elevation extremes: lowest point: Adriatic Sea
Om ;
highest point: Maja e Korabit (Golem Korab)
2,764 m
Natural resources: petroleum, natural gas, coal,
bauxite, chromite, copper, iron ore, nickel, salt,
timber, hydropower
Lond use: arable land: 21.63%
permanent crops: 2.57%
other: 75.79% (2011)
Irrigated land: 1,884 sq km (2006)
Total renewabie water resources: 41.7 cu km
(2011)
Freshwater withdrawal (domestic/indus-
triaW/agricultural): total: 1.31 cu km/yr
(43%/18%/39%)
per capita: 413.6 cu m/yr (2006)
Naturai hazards: destructive earthquakes; tsu-
namis occur along southwestern coast; floods;
drought
Environment—current issues: deforestation;
soil erosion; water pollution from industrial and
domestic effluents
Environment—international agreements:
party to: Air Pollution, Biodiversity, Climate
Change, Climate Change-Kyoto Protocol, Deser-
tification, Endangered Species, Hazardous Wastes,
Law of the Sea, Ozone Layer Protection, Wetlands
signed, but not ratified: none of the selected
agreements
Geography—note: strategic location along Strait
of Otranto (links Adriatic Sea to Ionian Sea and
Mediterranean Sea)
Location: Northern Africa, bordering the Medi-
terranean Sea, between Morocco and Tunisia
Geographic coordinates: 28 00 N, 3 00 E
Mop references: Africa
Area: total: 2,381,741 sq km
country comparison to the world: 10
land: 2,381,741 sq km
water:-0 sq km
Area—comparative: slightly less than 3.5 times
the size of Texas
Land boundaries: total: 6,343 km
border countries: Libya 982 km, Mali 1,376 km,
Mauritania 463 km, Morocco 1,009 km, Niger 906
km, Tunisia 960 km, Western Sahara 42 km
Coastline: 998 km
Maritime claims: territorial sea: 12 nm
exclusive fishing zone: 32-02 nm
Climate: arid to semiarid; mild, wet winters with
hor, dry summers along coast; drier with cold win-
ters and hot summers on high plateau; sirocco is
a hot, dust/sand-laden wind especially common in
summer
Terrain: mostly high plateau and desert; some
mountains; narrow, disconfinuous coastal plain
Elevation extremes: lowest point: Chott Melrhir
-40 m
highest point: Tahat 3,003 m
Natural resources: petroleum, natural gas, iron
ore, phosphates, uranium, lead, zinc
Land use: arable land: 3.10%
permanent crops: 0.38%
other: 96.46% (2011)
irrigated land: 5,694 sq km (2003)
Total renewable water resources: 11.67 cu km
(2011)
Freshwoter withdrawal (domestic/indus-
triaW/agricuitural); total: 5.72 cu km/yr
(26%/16%/08%)
per capita: 182 cu m/yr (2000)
Natural hazards: mountainous areas subject to
severe earthquakes; mudslides and floods in rainy
season
Environment—current issues: soil
from overgrazing and other poor farming prac-
tices; desertification; dumping of raw sew age,
petroleum refining wastes, and other industrial
effluents is leading to the pollution of rivers and
coastal waters; Mediterranean Sea, in particular,
becoming polluted from oil wastes, soil erosion,
and fertilizer runoff; inadequate supplies of pota-
ble water
Environment—international = agreements:
party to: Biodiversity, Climate Change, Climate
erosion','9e3b3e458249395c8df904aea3b2db6928b60e25c6a2f03b8ad52c70315d99de','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('298f469143230a7035134f9ee3ae7bfea7d15ec85963052abcc3d90a1c75e1e0',2025,'DZ','Algeria','geography',48,'Change-Kyoto Protocol, Desertification, Endan-
gered Species, Environmental Modification,
Hazardous Wastes, Law of the Sea, Ozone Layer
Protection, Ship Pollution, Wetlands
signed, but not ratified: none of the selected
agreements
Geography—note: largest country in Africa','b47b52599ed4ad6e281e934d8a045a2b8f7be4af30d06a91f587688ffb5bc601','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c6379ef5adaae7da6015d44b240090ef5382c25ade5ef89dd446dcd70a401efe',2025,'AS','American Samoa','geography',57,'Location: Oceania, group of islands in the South
Pacific Ocean, about half way between Hawaii and','b14f2300783241adb4fb59b3019b9fb19f99dbda143f99f4909718a8f0149bc0','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3d28cb8ecd357880762fdf2db16f3f1f65b201133ec39146977f94e1ff482d07',2025,'NZ','New Zealand','geography',58,'Geographic coordinates: 14 20S, 170 00 W
Map references: Oceania
Area: total: 199 sq km
country comparison to the world: 216
land: 199 sq km
water: 0 sq km
note: includes Rose Island and Swains Island
Area—comporative: slightly larger than Wash-
ington, DC
Land boundaries: 0 km
Coastline: 116 km
Maritime claims: territorial sea: 12 nm
exclusive economic zone: 200 nm
Climate: tropical marine, moderated by southeast
trade winds; annual rainfall averages about 3 m;
rainy season (November to April), dry season
(May to October); little seasonal temperature
variation
Terrain: five volcanic islands with rugged peaks
and limited coastal plains, two coral atolls (Rose
Island, Swains Island)
Elevation extremes: lowest point: Pacific Ocean
Om
highest point: Lata Mountain 964 m
Natural resources: pumice, pumicite
Land use: arable land: 9.5%
permanent crops: 15%
other: 75.5% (2011)
irrigated land: NA
Natural hazards:
December to March
volcanism: limited volcanic activity on the Ofu
and Olosega Islands; neither has erupted since the
19th century
Environment—current issues: limited natural
freshwater resources; the water division of the gov-
ernment has spent substantial funds in the past few
years to improve water catchments and pipelines
Geography—note: Pago Pago has one of the best
natural deepwater harbors in the South Pacific
Ocean, sheltered by shape from rough seas and
typhoons common from
protected by peripheral mountains from high
winds; strategic location in the South Pacific
Ocean
Geographic coordinates: 13 35 S, 172 20 W
Mop references: Oceania
Area: total: 2,83} sq km
country comparison to the world: 178
land: 2,821 sq km
water: 10 sq km
Area—comparative: slightly smaller than Rhode
Island
Land boundaries: 0 km
Coastline: 403 km
Maritime claims: territorial sea; 12 nm
contiguous zone: 24 nm
exclusive economic zone: 200 nm
Climate: tropical; rainy season (November to
April), dry season (May to October)
Terrain: two main islands (Savaii, Upolu) and sev-
eral smaller islands and uninhabited islets; narrow
coastal plain with volcanic, rocky, rugged moun-
tains in interior
Elevation extremes: lowest point: Pacific Ocean
Om
highest point: Mount Silisili 1,857 m
Natural resources: hardwood forests, fish,
hydropower
Land use: arable land: 2.82%
permanent crops: 7.75%
other: 89.44% (2011)
Irrigated land: NA
Natural hazards: occasional typhoons; active
volcanism
*','ba055525966052989448e95123fe15fdedc9342fd5eda7c1666c8cbb51192270','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b0dbd0002b86890ed03e24369f5bc4df34e8a06dabfb6f1d399532458e6df29b',2025,'AD','Andorra','geography',69,'Location: Southwestern Europe, Pyrenees moun-
tains, on the border between France and Spain
Geographic coordinates: 42 30 N, 1 30E
Map references: Europe
Area: total: 468 sq km
country comparison to the world: 196
land: 468 sq km
water: 0 sq km
Area—comparative: 2.5 times the size of Wash-
ington, DC
Land boundaries: total: 120.3 km
border countries: France 56.6 km, Spain 63.7 km
Coastline: 0 km (landlocked)
Maritime claims: none (iandlocked)
Climate: temperate; snowy, cold winters and
warm, dry summers
Terrain: rugged mountain’ dissected by narrow
valleys
Elevation extremes: lowest point: Riu Runer
840 m
highest point: Pic de Coma Pedrosa 2,946 m
Natural resources: hydropower, mineral water,
timber, iron ore, lead
Land use: arable land: 5.32%
permanent crops: 0%
other: 94.68% (2011)
Irrigated land: NA
Natural hazards: avalanches
Environment—current issues: deforestation;
overgrazing of mountain meadows contributes to
soil erosion; air pollution; wastewater treatment
and solid waste disposal
Environment—international agreements:
party to: Biodiversity, Desertification, Hazardous
Wastes, Ozone Layer Protection
signed, but not ratified: none of the selected
agreements
Geography—note: landlocked; straddles a num-
ber of important crossroads in the Pyrenees
Location: Southern Africa, bordering the South
Atlantic Ocean, between Namibia and Demo-
cratic Republic of the Congo
Geographic coordinates: 12 30 S, 18 30 E
Map references: Africa
Area: total: 1,246,700 sq km
country comparison to the world: 23
land: 1,246,700 sq km
water: 0 sq km
Area—comparative: slightly less than twice the
size of Texas
Land boundaries: total: 5,198 km
border countries: Democratic Republic of the
Congo 2,511 km (of which 225 km is the bound-
ary of discontiguous Cabinda Province), Republic
of the Congo 201 km, Namibia 1,376 km, Zambia
1,110 km
Coastline: 1,600 km
Maritime claims: territorial sea: 12 nm
contiguous zone: 24 nm
exclusive economic zone: 200 nm
Climate: semiarid in south and along coast to
Luanda; north has cool, dry season (May to Octo-
ber) and hot, rainy season (November to April)
Terrain: narrow coastal plain rises abruptly to vast
interior plateau
to terrestrial digital TV broadcasting in 2007;
roughly 25 international TV channels available
(2012)
Internet country code: .ad
Internet hosts: 28,383 (2012)
country comparison to the world: 109
Internet users: 67,100 (2009)
country comparison to the world: 171','51d7c8048ffadb6f873636c0052d046b1e02756d6fa4d870bb8ce213ab802567','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('373f5c37225104837725b253e9004c4367b757da11c636d9b0de5a7a3bbc8ff8',2025,'AO','Angola','geography',82,'Location: Caribbean, islands between the Car-
ibbean Sea and North Atlantic Ocean, east of
Location: Southern Africa, bordering the South
Atlantic Ocean, between Angola and South
Africa
Geographic coordinates: 22 00 S, 17 00 E
Map references: Africa
Area: total: 824,292 sq km
country comparison to the world: 34
land: 823,290 sq km
water: 1,002 sq km
Area—compoarative: slightly more than half the
size of Alaska
Land boundaries: total: 3,936 km
border countries: Angola 1,376 km, Botswana
1,360 km, South Africa 967 km, Zambia 233 km
Coastline: 1,572 km
Maritime claims: territorial sea: 12 nm
contiguous zone: 24 nm
exclusive economic zone: 200 nm
Climate: desert; hot, dry; rainfall sparse and erratic
Terrain: mostly high plateau; Namib Desert along
coast; Kalahari Desert in east
Elevation extremes: lowest point: Atlantic
Ocean 0 m
highest point: Konigstein 2,606 m
Natural resources: diamonds, copper, uranium,
gold, silver, lead, tin, lithium, cadmium, tungsten,
zinc, salt, hydropower, fish
508','70d5358eabbc7a091c9aa78ae47da3816ec6dbe67da449b1a6d1c5c729d83704','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('859a434038a6dc902957254847cfe34c75d9820345d43689e58a6dda58589ee9',2025,'PR','Puerto Rico','geography',83,'Geographic coordinates: 18 15 N, 63 10 W
Map references: Central America and the
Caribbean
Area: total: 91 sq km
country comparison to the world: 227
land: 91 sq km
water: 0 sq km
Area—comparative: about one-half the size of
Washington, DC
Land boundaries: 0 km
Coastline: 61 km
Maritime claims: territorial sea: 3 nm
exclusive fishing zone: 200 nm
Climate: tropical; moderated by northeast trade
winds
Terrain: flat and low-lying island of coral and
limestone
Elevation extremes: lowest point: Caribbean
Sea 0 m
highest point: Crocus Hill 65 m
Natural resources: salt, fish, lobster
Land use: arable land: 0%
permanent crops: 0%
other: 100% (mostly rock with sparse scrub oak,
few trees, some commercial salt ponds) (2011)
Irrigated land: NA
Natural hazards: frequent hurricanes and other
tropical storms (July to October)
Location: Middle East, peninsula bordering the
Persian Gulf and Saudi Arabia
Geographic coordinates: 25 30 N, 51 15 E
Map references: Middle East
592
Geographic coordinates: 18 20 N, 64 50 W
Map references: Central America and the
Caribbean
Area: total: 1,910 sq km
a
country comparison to the world: 182
land: 346 sq km
water: 1,564 sq km
Area—comparotive: twice the size of Washing-
ton, DC
Land boundaries: 0 km
Coastline: 188 km
Maritime claims: territorial sea: 12 nm
exclusive economic zone: 200 nm
Climate: subtropical, tempered by easterly trade
winds, relatively. low humidity, little seasonal
temperature variation; rainy season September to
November
Terrain: mostly hilly to rugged and mountainous
with little level land
Elevation extremes: lowest point: Caribbean
Sea 0m
highest point: Crown Mountain 474 m
Natural resources: sun, sand, sea, surf
Land use: arable land: 2.86%
permanent crops: 2.86%
other: 94.29% (2011)
Irrigated land: ! sq km (2011)
Natural hazards: several hurricanes in recent
years; frequent and severe droughts and floods;
occasional earthquakes
Environment—current issues: lack of natural
freshwater resources
Geography—note: important location along the
Anegada Passage—a key shipping lane for the
Panama Canal; Saint Thomas has one of the best
natural deepwater harbors in the Caribbean
Location: Oceania, atoll in the North Pacific
Ocean, about two-thirds of the way from Hawaii
to the Northern Mariana Islands
Geographic coordinates: 19 17 N, 166 39 E
Map references: Oceania
Area: total: 6.5 sq km
country comparison to the world: 244
land: 6.5 sq km
water: 0 sq km
Area—comparative: about 11 times the size of
The Mall in Washington, DC
Land boundaries: 0 km
Coastline: 19.3 km
Maritime claims: territorial sea: 12 nm
exclusive economic zone: 200 nm
Climate: tropical
Terrain: atoll of three low coral islands, Peale,
Wake, and Wilkes, built up on an underwater vol-
cano; central lagoon is former crater, islands are
part of the rim
Elevation extremes: lowest point: Pacific Ocean
Om
highest point: unnamed location 6 m
Natural resources: none
Land use: arable land: 0%
permanent crops; 0%
other: 100% (2011)
Irrigated land: 0 sq km (2011)
Natural hazards: occasional typhoons
Environment—current issues: NA
Geography—note: strategic location in the
North Pacific Ocean; emergency landing location
for transpacific flights','5d89804d610e08a9357579fc8004589f38960d9eb6efc78fb2019099a2f71da2','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('563a8554782c72bc19b7cfad61b9fbea907b5f518876279a156cdcbfd1386425',2025,'AI','Anguilla','geography',84,'Environment—current issues: supplies of
potable water sometimes cannot meet increasing
demand largely because of poor distribution system
Geography—note: the most northerly of the
Leew ard Islands in the Lesser Antilles','9db8ae7d5ecd10652eae37b874cce9c929cc14ed021d74ce296e5b1320f6fe30','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8d96f16860ca807f469668e60f0749ff96c516e51dd24a8eea0e7116573969be',2025,'AQ','Antarctica','geography',93,'Location: continent mostly south of the Antarctic
Circle
Geographic coordinates: 90 00 S, 0 00 E
Map references: Antarctic Region
Area: total: 14 million sq km
land: 14 million sq km (280,000 sq km ice-free,
13.72 million sq km ice-covered) (est.)
note: fifth-largest continent, following Asia,
Africa, North America, and South America, but
larger than Australia and the subcontinent of
Europe
Area—comparative: slightly less than 1.5 times
the size of the US
Land boundaries: 0 km
note: see entry on Disputes—international
Coastline: 17,968 km
Maritime claims: Australia, Chile, and Argen-
tina claim Exclusive Economic Zone (EEZ) rights
or similar over 200 nm extensions seaw ard from
their continental claims, but like the claims them-
selves, these zones are not accepted by other coun-
tries: 21 of 28 Antarctic consultative nations have
''
made no claims to Antarctic territory (although
Russia and the US have reserved the right to do
so) and do not recognize the claims of the other
nations; also see the Disputes—international entry
Climate: severe low temperatures vary with lati-
tude, elevation, and distance from the ocean; East
Antarctica is colder than West Antarctica because
of its higher elevation; Antarctic Peninsula has
the most moderate climate; higher temperatures
occur in January along the coast and average
slightly below freezing
Terrain: about 98% thick continental ice sheet
and 2% barren rock, with average elevations
between 2,000 and 4,000 meters; mountain ranges
up to nearly 5,000 meters; ice-free coastal areas
include parts of southern Victoria Land, Wilkes
Land, the Antarctic Peninsula area, and parts of
Ross Island on McMurdo Sound; glaciers form ice
shelves along about half of the coastline, and float-
ing ice shelves constitute 11% of the area of the
continent
Elevation extremes: lowest point: Bentley Sub-
glacial Trench -2,540 m t
highest point: Vinson Massif 4,897 m
note: the lowest known land point in Antarctica
is hidden in the Bentley Subglacial Trench; at its
surface is the deepest ice yet discovered and the
world’s lowest elevation not under seawater
Natural resources: iron ore, chromium, copper,
gold, nickel, platinum and other minerals, and coal
and hydrocarbons have been found in small non-
commercial quantities; none’ presently exploited;
krill, finfish, and crab have been taken by commer-
cial fisheries
Land use: arable land: 0% perm anent crops: 0%
other: 100% (ice 98%, barren rock 2%) (2011)
Notural hazards: karabatic (gravity-driven)
winds blow coastw ard from the high interior; fre-
quent blizzards form near the foot of the plateau;
cyclonic storms form over the ocean and move
clockwise along the coast; volcanism on Decep-
tion Island and isolated areas of West Antarctica;
other seismic activity rare and weak; large icebergs
may calve from ice shelf
Environment—current issues: in 1998, NASA
satellite data show ed that the Antarctic ozone
hole was the largest on record, covering 27 mil-
lion square kilometers; researchers in 1997 found
that increased ultraviolet light passing through the
hole damages the DNA of icefish, an Antarctic
fish lacking hemoglobin; ozone depletion earlier
was shown to harm one-celled Antarctic marine
plants; in 2002, significant areas of ice shelves dis-
integrated in response to regional warming
Geography—note: the coldest, windiest, highest
(on average), and driest continent; during sum-
mer, more solar radiation reaches the surface at the
South Pole than is received at the Equator in an
equivalent period; mostly uninhabitable','dfd0c7a7ad708551c4924ebf0e0d672e665324c8dd495a257b44922f7f751c1c','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f8126f9d2e4e841e038b2048f0789bd12bd076ae90d818d7c7ffbacfb06a5a0c',2025,'AG','Antigua and Barbuda','geography',101,'Location: Caribbean, islands between the Carib-
bean Sea and the North Atlantic Ocean, east-
southeast of Puerto Rico
Geographic coordinates: 03 N, 61 48 W
Map references: Central America and the
Caribbean
Area: total: 442.6 sq km (Antigua 280 sq km; Bar-
buda 161 sq km)
country comparison to the world: 201
land: 442.6 sq km water: 0 sq km
note: includes Redonda, 1.6.sq km
Area—comparative: times the size of Washing-
ton, DC
Land boundaries: 0 km
Coastline: 153 km
Maritime claims: territorial sea: 12 nm
contiguous zone: 24 nm
exclusive economic zone: 200 nm
continental shelf: 200 nm or to the edge of the
continental margin
Climate: tropical maritime; little seasonal tem-
perature variation i
Terrain: mostly low-lying limestone and coral
islands, with some higher volcanic areas
Elevation extremes: lowest point: Caribbean
Sea 0 m
highest point: Boggy Peak 402 m
Natural resources: NEGL; pleasant climate fos-
ters tourism
Land use: arable land: 9.09%
permanent crops: 2.27%
other: 88.64% (2011)
Irrigated land: 1.3 sq km (2003)
Total renewable water resources: 0.05 cu km
(2011)
Freshwater withdrawal (domestic/indus-
trial/agricultural): total: 0.01 cu km/yr
(63%/21%/15%)
per capita: 97.67 cu m/yr (2005)
Natural hazards: hurricanes and tropical storms
(July to October); periodic droughts
Environment—current issues: water manage-
ment—a major concern because of limited natural
freshwater resources—is further hampered by the
clearing of trees to increase crop production, caus-
ing rainfall to run off quickly
Environment—international agreements:
party to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Endan-
gered Species, Environmental Modification, Haz-
ardous Wastes, Law of the Sea, Marine Dumping,
Ozone Layer Protection, Ship Pollution, Wet-
lands, Whaling
signed, but not ratified: none of the selected
agreements
Geography—note: Antigua has a deeply indented
shoreline with many natural harbors and beaches;
Barbuda has a large western harbor
Location: body of water between Europe, Asia,
and North America, mostly north of the Arctic
Circle
Geographic coordinates: 90 00 N, 0 00 E
Map references: Arctic
Area: total: 14.056 million sq km
note: includes Baffin Bay, Barents Sea, Beaufort
Sea, Chukchi Sea, East Siberian Sea, Greenland
Sea, Hudson Bay, Hudson Strait, Kara Sea, Laptev
THE CIA WORLD FACTBOOK
ARCTIC OCEAN
Sea, Northwest Passage, and other tributary water
bodies j
Area—comparative: slightly less than 1.5 times
the size of the US
Coastline: 45,389 km
Climate: polar climate characterized by persistent
cold and relatively narrow annual temperature
ranges; winters characterized by continuous dark-
ness, cold and stable weather conditions, and clear
skies; summers characterized by continuous day-
light, damp and foggy weather, and weak cyclones
with rain or snow
Terrain: central surface covered by a perennial
drifting polar icepack that, on average, is about 3
meters thick, although pressure ridges may be three
times that thickness; clockwise drift pattern in the
Beaufort Gyral Stream, but nearly straight-line
movement from the New Siberian Islands (Rus-
sia) to Denmark Strait (between Greenland and
Iceland); the icepack is surrounded by open seas
during the summer, but more than doubles in size
during the winter and extends to the encircling
landmasses; the ocean floor is about 50% conti-
nental shelf (highest percentage of any ocean)
with the remainder a central basin interrupted by
three submarine ridges (Alpha Cordillera, Nansen
Cordillera, and Lomonosov Ridge)
Elevation extremes: lowest point: Fram Basin
-4,665 m
highest point: sea level 0 m
Natura! resources: sand and gravel aggregates,
placer deposits, polymetallic nodules, oil and gas
fields, fish, marine mammals (seals and whales)
Natural hazards: ice islands occasionally break
away from northern Ellesmere Island; icebergs
calved from glaciers in western Greenland and
extreme northeastern Canada;
islands; virtually ice locked from October to June;
ships subject to superstructure icing from October
to May
Environment—current issues:
marine species include walruses and whales; fragile
endangered
permafrost in ''
ecosystem slow to change and slow to recover from
disruptions or damage; thinning polar icepack
Geography—note: major chokepoint is the
southem Chukchi Sea (northern access to the
Pacific Ocean via the Bering Strait); strategic loca-
tion between North America and Russia; shortest
marine link between the extremes of eastern and
western Russia; floating research stations operated
by the US and Russia; maximum snow cover in
March or April about 20 to 50 centimeters over
the frozen ocean; snow cover lasts about 10 months
Location: Southern South America, bordering
the South Atlantic Ocean, between Chile and','58f7ef76bbac69c103a9c36809c2d68de81a9725a3d89f5fa903e5e5c4ff018d','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9d016ae82ecfaa2a0166c4612d0605b8f1f34be252d8df809c554f5136ed6717',2025,'UY','Uruguay','geography',109,'Geographic coordinates: 34 00 S, 64 00 W
Map references: South America
Area: total: 2,780,400 sq km
country comparison to the world: 8
land: 2,736,690 sq km
water: 43,710 sq km
Area—comparative: slightly less than three-
tenths the size of the US
Land boundaries: total: 9,861 km
border countries: Bolivia 832 km, Brazil 1,261
km, Chile 5,308 km, Paraguay 1,880 km, Uruguay
580 km
Coastline: 4,989 km
Maritime claims: territorial sea: 12 nm
contiguous zone: 24 nm
exclusive economic zone: 200 nm
continental shelf: 200 nm or to the edge of the
continental margin
Climate: mostly temperate; arid in southeast; sub-
antarctic in southwest Terrain: rich plains of the
Pampas in northern half, flat to rolling plateau of
Patagonia in south, rugged Andes along western
border
Elevation extremes: lowest point: Laguna del
Carbon-105 m (located between Puerto San Julian
and Comandante Luis Piedra Buena in the prov-
ince of Santa Cruz)
highest point: Cerro Aconcagua 6,960 m (located
in the northwestern corner of the province of Men-
doza; highest point in South America)
Natural resources: fertile plains of the pampas,
lead, zinc, tin, copper, iron ore, manganese, petro-
leum, uranium
Land use: arable land: 13.68%
permanent crops 0.36%
other: 85.96% (2011)
Irrigated land: 15,500 sq km (2003)
Total renewable water resources: 814 cu km
(2011)
Freshwater withdrawal (domestic/indus-
triaVagricultural): total: 32.57 cu km/yr
(23%/13%/64%)
per capita: 864.9 cu m/yr (2005)
Natural hazards: San Miguel de Tucuman and
Mendoza areas in the Andes subject to earth-
quakes; pamperos are violent windstorms that can
strike the pampas and northeast; heavy flooding in
some areas
volcanism: volcanic activity in the Andes Moun-
tains along the Chilean border; Copahue (elev.
2,997 m) last erupted in 2000; other historically
active volcanoes include Llullaillaco, Maipo, Plan-
chon-Peterda, San Jose, Tromen, Tupungatito, and
Viedma
Environment—current issues: environmen-
tal problems (urban and’ rural) typical of an
Location: Central Asia, north of Turkmenistan,
south of Kazakhstan
Geographic coordinates: 41 00 N, 64 00 E
Map references: Asia
Area: total: 447,400 sq km
country comparison to the world: 57
land: 425,400 sq km
water: 22, 000 sq km
Area—comparative:
California
Land boundaries: total: 6, 221 km
border countries: Afghanistan 137 km, Kazakh-
stan 2,203 km, Kyrgyzstan 1,099 km, Tajikistan 1,
161 km, Turkmenistan 1, 621 km
Coastline: O km (doubly landlocked); note—
Uzbekistan includes the southern portion of the
Aral Sea with a 420 km shoreline
Maritime claims: none (doubly landlocked)
Climate: mostly midlatitude desert, long, hot sum-
mers, mild winters; semiarid grassland in east
slightly larger than
Terrain: mostly flat-to-rolling sandy desert with
dunes; broad, flat intensely irrigated river valleys
along course of Amu Darya, Syr Darya (Sirdaryo),
and Zarafshon; Fergana Valley in east surrounded
by mountainous Tajikistan and Kyrgyzstan; shrink-
ing Aral Sea in west
Elevation extremes: lowest point: Sariqamish
Kuli-12 m
highest point: Adelunga Toghi 4,301 m
Natural resources: natural gas, petroleum, coal,
gold, uranium, silver, copper, lead’ and zinc, tung-
sten, molybdenum
Land use: arable land: 9.61%
permanent crops: 0.8%
other: 89.58% (2011)
Irrigated land: 41,980 sq km (2005)
Total renewable water resources: 48.87 cu km
(2011)
Freshwater withdrawal (domestic/industrial/
agricultural): total: 56 cu km/yr (7%/3%/90%)
per capita: 2,113 cu m/yr (2005)
Natural hazards: NA
Environment—current issues: shrinkage of the
Aral Sea has resulted in growing concentrations
of chemical pesticides and natural salts; these
substances are then blown from the increasingly
exposed lake bed and contribute to desertification
and respiratory health problems; water pollution
from industrial wastes and the heavy use of ferti-
lizers and pesticides is the cause of many human
health disorders; increasing soil salination; soil
contamination from buried nuclear processing and
agricultural chemicals, including DDT
779
Environment—international agreements:
party to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Endan-
gered Species, Environmental Modification, Haz-
- ardous Wastes, Ozone Layer Protection, Wetlands
signed, but not ratified: none of the selected
agreements
Geography—note: along with Liechtenstein, one
of the only two doubly landlocked countries in the
world','1f7a5a53a586bb3412760eb89e033adbed7b2e053339212a892a3a2118fc89a2','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f466e2f90e55a526aea71e5f1fd67285aa400c9226deccbe9dfc8ec4360906a6',2025,'AR','Argentina','geography',110,'industrializing economy such as deforestation,
soil degradation, desertification, air pollution, and
water pollution
note: Argentina is a world leader in setting volun-
tary greenhouse gas targets
Environment—international agreements:
party to: Antarctic-Environmenmal Protocol,
Anrarctic-Marine Living Resources, Antarctic
Seals, Antarctic Treaty, Biodiversity, Climate
Change, Climate Change-Kyoto Protocol, Deser-
tification, Endangered Species, Environmental
Modification, Hazardous Wastes, Law of the Sea,
Marine Dumping, Ozone Layer Protection, Ship
Pollution, Wetlands, Whaling
Geography—note: second-largest counny in
South America (after Brazil); strategic location
relative to sea lanes berween the South Atlantic
and the South Pacific Oceans (Strait of Magellan,
Beagle Channel, Drake Passage); diverse geophysi-
cal landscapes range from tropical climates in the
north to tundra in the far south; Cerro Aconca-
gua is the Western Hemisphere’s tallest mountain,
while Laguna del Carbon is the lowest point in the
Western Hemisphere
Nationality: noun: Argentine(s)
adjective: Argentine
Ethnic groups: white (mostly Spanish and Iral-
ian) 97%, mestizo (mixed white and Amerindian
ancestry), Amenndian, or other non-white groups
3%
Languages: Spanish (official), Italian, English,
German, French, indigenous (Mapudungun,
Quechua)
Religions: nominally Roman Catholic 92% (less
than 20% practicing), Protestant 2%, Jewish 2%,
other 4%
Demographic profile: Argentina’s population
continues to grow buf at a slow er rate because
of its steadily declining birth rate. Argentina’s
fertility decline began earlier than in the rest of
Latin America, occurring most rapidly berween
the early 20th century and the 1950s and then
becoming more gradual. Life expectancy has
been improving, most notably among the young
and the poor. While the population under age 15
is shrinking, the youth cohort—ages 15-24—is
the largest im Argentina''s history and will con-
tinue to bolster the working-age population.
If this large working-age population is well-
educated and gainfully employed, Argentina is
likely to experience an economic boost and pos-
sibly higher per capita savings and investment.
Although literacy and primary school enrollment
are nearly universal, grade repetition is prob-
lematic and secondary school completion is low.
Both of these issues, vary widely by region and
socioeconomic group. `.
Argentina has been primarily a country of immi-
gration for most of its history, welcoming Euro-
pean immigrants after its independence in the
19th century and attracting especially large num-
bers from Spain and italy. European immigration
diminished in the 1950s, when Argentina’s mili-
tary dictatorships tightened immigration rules and
European economies rebounded. Regional migra-
tion, how ever, continued to supply low-skilled
workers and today it accounts for three-quarters
of Argentina''s immigrant population. The first
waves of highly skilled Argentine emigrant work-
ers headed mainly to the United States and Spain
in the 1960s and 1970s. The ongoing European
economic crisis is driving the retum migration
of some Argentinean and other Latin American
” nationals, as well as the immigration of Europe-
ans to South America, where Argentina is a key
recipient.
Population: 42,610,981 (July 2013 est.)
country comparison to the world: 32
Age structure: 0-14 years 25.1% (male
5,468,773 /female 5,217,256)
15-24 years 15.8% (male 3,436,816/female
3,296,788)
25-54 years: 38.8% (male 8,238,184/female
8,290,649)
55-64 years 9.1% (male 1,871,644/female
1,990,790) $
65 years and over: 11.3% (male 1,987,344/female
2,812,737) (2013 est.)
Median age: total: 31 years
male: 29.9 years
female: 32.1 years (2013 est.)
Population growth rate: 0.98% (2013 est.)
country comparison to the world: 118
Birth rate: 17.12 births/1,000 population (2013
est.)
country comparison to the world: 113
Death rate: 7.35 deaths/1,000 population (2013
est.)
country comparison to the world: 119
Net migration rate: migrant(s)/1,000 population
(2013 est.)
country comparison to the world: 75.
Urbanization: urban population: 92% of total
population (2010)
rate of urbanization: 1.1% annual rate of change
(2010-15 est.)
Major cities—popuiation: BUENOS AIRES
(capital) 12.988 million; Cordoba 1.493 million;
Rosario 1.231 million; Mendoza 917,000; San
Miguel de Tucuman 831,000 (2009)
Sex ratio: at birth: 1.05 male(s)/female
0-14 years: 1.05 male(s)/female
15-24 years: 1.04 male(s)/female
25-54 years: 0.99male(s)/female
55-64 years: 0.94 male(s)/female
65 years and over: 0.7 male(s)/female
total population: 0.9/ male(s)/Temale (2013
est.)
Maternal mortality rate: 77 deaths/100,000 live
births (2010)
country comparison to the world: 84
Infant mortality rate: total: 10.24 deaths/1,000
live births
country comparison to the world: 143
male: 11.45 deaths/I ,000 live births
female: 8.96 deaths/1,000 live births (2013 est.)
Life expectancy at birth: cotal population:
77.32 years
country comparison to the world: 68
male: 74.09 years
female: 80.73 years (2013 est.)
- Total fertility rate: 2.27 children born/woman
(2013 est.)
country comparison to the world: 97
Health expenditures: 8.1% of GDP (2010)
country comparison to the world: 58
Physicians density: 3.16 physicians/1,000 popu-
lation (2004)
Hospital bed density: 4.5 beds/1,000 population
(2010)
Drinking water source:
Improved:
urban: 98% of population
rural; 80% of population
total: 97% of population
Unimproved:
urban: 2% of population
rural: 20% of population
total: 3% of population (2008 est.)
Sanitation facility access:
Improved:
urban: 92% of population
rural: 77% of population
total: 91% of population
Unimproved:
urban: 8% of population
rural: 23% of population
total: 9% of population (2000 est.)
HIV/AIDS—adult prevalence rate: 0.5% (2009
est.)
country comparison to the world: 66
HIV/AIDS—people living with HIV/AIDS:
110,000 (2009 est.)
country comparison to the world: 39
HIV/AIDS—deaths: 2,900 (2009 est.)
country comparison to the world: 46
Major infectious diseases: degree of risk:
intermediate
food or waterborne diseases: bacterial diarrhea,
hepatitis A
water contact disease: leptospirosis (2009)
Obesity—adult prevalence rate: 29.7% (2008)
country comparison to the world: 29
Children under the age of 5 years under-
weight: 2.3% (2005)
country comparison to the world: 113
Education expenditures: 5.8% of GDP (2010)
country comparison to the world: 44
Literacy: definition: age 10 and over can read
and write
total population: 98.1%
male: 98%
female: 98.1% (2010 census)
School life expectancy (primary to tertiary
education): total: 16 years
male: 15 years
female: 17 years (2007)
Unemployment, youth ages 15-24: coral: 18.7%
country comparison to the world: 66
male: 16.5%
female: 22.2% (2011)
Location: Southwestern Asia, between Turkey (to
the west) and Azerbaijan |
Geographic coordinates: 40 00 N, 45 00 E
Map references: Middle East
Area: total: 29,743 sq km
country comparison to the world: 143 land:
28,203 sq km
water: 1,540 sq km
Area—comparative:
Maryland
Land boundaries: total: 1,254 km
border countries: Azerbaijan-proper 566 km,
Azerbaijan-Naxcivan exclave 221 km, Georgia
164 km, Iran 35 km, Turkey 268 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
Climate: highland continental, hot summers, cold
winters
Terrain: Armenian Highland with mountains; lit-
tle forest land; fast flowing rivers; good soil in Aras
River valley
Elevation extremes: lowest point: Debed River
400 m
highest point: Aragats Lermagagat’ 4,090 m
Natural resources: small deposits of gold, copper,
molybdenum, zinc, bauxite
Land use: arable land: 14.47%
permanent crops: 1.8%
other: 83.74% (2011)
Irrigated land: 2,735 sq km (2006)
Total renewable water resources: 7.77 cu km
(2011)
Freshwater withdrawal (domestic/industrial/
agricultural); total: 2.86 cu km/yr (40%/6%/54%)
per capita: 929.7 cu m/yr (2010)
Natural hazards: occasionally severe earth-
quakes; droughts
Environment—current issues: soil pollution
from toxic chemicals such as DDT; the energy
crisis of the 1990s led to deforestation when
citizens scavenged for firew ood; pollution of
Hrazdan (Razdan) and Aras Rivers; the draining
of Sevana Lich (Lake Sevan), a result of its use
as a source for hydropow er, threatens drinking
water supplies; restart of Metsamor nuclear pow
er plant in spite of its location in a seismically
slightly smaller than
active zone
Environment—international agreements:
party to: Air Pollution, Biodiversity, Climate
Change, Climate Change-Kyoto Protocol, Deser-
tification, Environmental Modification, Hazard-
ous Wastes, Law of the Sea, Ozone Layer Protec-
tion, Wetlands
signed, but not ratified: Air Pollution-Persistent
Organic Pollutants
Geography—note: landlocked in the Lesser Cau-
casus Mountains; Sevana Lich (Lake Sevan) is the
largest lake in this mountain range
Location: Southern South America, bordering the
South Pacific Ocean, between Argentina and Peru
Geographic coordinates: 30 00 S, 71 00 W
Map references: South America
Area: total: 756,102 sq km
country comparison to the world: 38
land: 743,812 sq km
water: 12,290 sq km
note: includes Easter Island (Isla de Pascua) and
Isla Sala y Gomez
Area—comparative: slightly smaller than twice
the size of Montana
Land boundaries: total: 6,339 km
border countries: Argentina 5,308 km, Bolivia
860 km, Peru 171 km
Coastline: 6,435 km
Maritime claims: territorial sea: 12 nm
contiguous zone: 24 nm
exclusive economic zone: 200 nm
continental shelf: 200/350 nm
Climate: temperate; desert in north; Mediter-
ranean in central region; cool and damp in south
Terrain: low coastal mountains; fertile central val-
ley; rugged Andes in east
Elevation extremes: lowest point: Pacific Ocean
Om
highest point: Nevado Ojos del Salado 6,880 m
Natural resources: copper, timber, iron ore,
nitrates, precious metals, molybdenum, hydropower
Land use: arable land: 1.74%
permanent crops: 0.6%
other: 97.65% (2011)
Irrigated land: 11,990 sq km (2003)
Total renewable water resources; 922 cu km
(2011)
Freshwater withdrawal (domestic/indus-
triaW/agricultural): * total: 26.67 cu km/yr
(4%/10%/86%)
per capita: 1,603 cu m/yr (2007)
Notural hazards: severe earthquakes; active vol-
canism; tsunamis
volcanism: significant volcanic activity due to
more than three-dozen active volcanoes along the
Andes Mountains; Lascar (elev. 5,592 m), which
last erupted in 2007, is the most active volcano in
the northern Chilean Andes; Llaima (elev. 3,125
m) in central Chile, which last erupted in 2009,
is another of the country’s most active; Chaiten’s
2008 eruption forced major evacuations; other
notable historically active volcanoes include Cerro
Hudson, Copahue, Guallatiri, Llullaillaco, Neva-
dos de Chillan, Puyehue, San Pedro, and Villarrica
Environment—current issues: widespread defor-
estation and mining threaten natural resources; air
pollution from industrial and vehicle emissions;
water pollution from raw sew age
Environment—international agreements:
party to: Antarctic-Environmental Protocol, Ant-
arctic-Marine Living Resources, Antarctic Seals,
Antarctic Treaty, Biodiversity, Climate Change,
Climate Change-Kyoto Protocol, Desertification,
Endangered Species, Environmental Modifica-
tion, Hazardous Wastes, Law of the Sea, Marine
Dumping, Ozone Layer Protection, Ship Pollution,
Wetlands, Whaling
signed, but not ratified: none of the selected
agreements
Geography—note: the longest north-south trend-
ing country in the world, extending across 38
degrees of latitude; strategic location relative to
sea lanes between the Atlantic and Pacific Oceans
(Strait of Magellan, Beagle Channel, Drake Pas-
sage); Atacama Desert—the driest desert in the
world—spreads across the northern part of the coun-
try; the crater lake of Ojos del Salado is the world’s
highest lake (at 6,390 m)','b3011c46e6a18b133652a12d663f47b30957a6a8463abc248e1df02fd5bb76ba','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a960f56b244b562120b2ced1d6bd1fb8c6d660dea883ebb44c864ce76bd83950',2025,'AW','Aruba','geography',127,'Location: Caribbean, island in the Caribbean Sea,
north of Venezuela
Geographic coordinates: 12 30 N, 69 58 W
Map references: Central America and the
Caribbean
Area: total: 180 sq km
country comparison to the world: 218
land: 180 sq km
water: 0 sq km
Area—comparative: slightly larger than Wash-
ington, DC
Land boundaries: 0 km
Coastline: 68.5 km
Maritime claims: territorial sea: 12 nm
Climate: tropical marine; little seasonal tempera-
ture variation
Terrain: flat with a few hills; scant vegetation
Elevation extremes: lowest point: Caribbean
Sea O m
highest point: Ceru Jamanota 188 m
Natural resources: NEGL; white sandy beaches
Land use: arable land: 11.11%
permanent crops: 0%
other: 88.89% (2005)
Irrigated land: NA
Natural hazards: hurricanes; lies outside the Car-
ibbean hurricane belt and is rarely threatened
Environment—current issues: NA
Geography—note: a flat, riverless island renowned
for its white sand beaches: its tropical climate is
moderated by constant trade winds from the Atlan-
tic Ocean; the temperature is almost constant at
about 27 degrees Celsius (81 degrees Fahrenheit)
Location: body of water between Africa, Europe,
the Arctic Ocean, the Americas, and the South-
ern Ocean d
Geographic coordinates: 0 00 N, 25 00 W
Map references: Physical Map of the World
Area: total: 76.762 million sq km
note: includes Baltic Sea, Black Sea, Caribbean
Sea, Davis Strait, Denmark Strait, part of the
Drake Passage, Gulf of Mexico, Labrador Sea,
Mediterranean Sea, North Sea, Norwegian Sea,
‘almost all of the Scotia Sea, and other tributary
water bodies
Area—comparative: slightly less than 6.5 times
the size of the US
Coastline: 111,866 km
Climate: tropical cyclones (hurricanes) develop
off the coast of Africa near Cape Verde and move
westward into the Caribbean Sea; hurricanes can
occur from May to December but are most fre-
quent from August to November
Terrain: surface usually covered with sea ice in
Labrador Sea, Denmark Strait, and coastal por-
tions of the Baltic Sea from October to June;
clockwise warm-water gyre (broad, circular sys-
tem of currents) in the northern Atlantic, coun-
terclockwise warm-water gyre in the southern
Atlantic; the ocean floor is dominated by the Mid-
Atlantic Ridge, a rugged north-south centerline
for the entire Atlantic basin
Elevation extremes: lowest point: Milwaukee
Deep in the Puerto Rico Trench-8,605 m
highest point: sea level 0 m
Natural resources: oil and gas fields, fish, marine
mammals (seals and whales), sand and gravel
aggregates, placer deposits, polymetallic nodules,
precious stones
Natural hazards: icebergs common in Davis
Strait, Denmark Strait, and the northwestern
Atlantic Ocean from February to August and
have been spotted as far south as Bermuda and
the Madeira Islands; ships subject to superstruc-
ture icing in extreme northern Atlantic from
October to May; persistent fog can be a maritime
hazard from May to September; hurricanes (May
to December)
Environment—current . issues: endangered
marine species include the manatee, seals, sea
lions, turtles, and whales; drift net fishing is has-
tening the decline of fish stocks and contributing
to international disputes; municipal sludge pollu-
tion off eastern US, southern Brazil, and eastern
Argentina; oil pollution in Caribbean Sea, Gulf of
Mexico, Lake Maracaibo, Mediterranean Sea, and
North Sea; industrial waste and municipal sew age
pollution in Baltic Sea, North Sea, and Mediter-
ranean Sea
Geography—note: major chokepoints include
the Dardanelles, Strait of Gibraltar, access to the
Panama and Suez Canals; strategic straits include
the Strait of Dover, Straits of Florida, Mona Pas-
sage, The Sound (Oresund), and Windw ard Pas-
sage; the Equator divides the Atlantic Ocean into
the North Atlantic Ocean and South Atlantic
Ocean
Economy—overview: The Atlantic Ocean pro-
vides some of the world’s most heavily trafficked
sea routes, between and within the Eastern and
Western Hemispheres. Other economic activity
includes the exploitation of natural resources, e.g.,
fishing, dredging of aragonite. sands (The Baha-
mas), and production of crude oil and natural gas
(Caribbean Sea, Gulf of Mexico, and North Sea).','e65a23836590ea955dbeb296e58d33f30705d5ada99a58865277fc8fba5fc986','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('de191fd0fbbd461f18242ff16830fa5408b2faa11c49e3daa394fe4f1e8937cc',2025,'AU','Australia','geography',137,'Location: Oceania, continent between the Indian
Ocean and the South Pacific Ocean
Geographic coordinates: 27 00 S, 133 00 E
Map references: Oceania
Area: total: 7,741,220 sq km
country comparison to the world: 6
land: 7,682,300 sq km
water: 58,920 sq km
note: includes Lord Howe Island and Macquarie
Island
Area—comparative: slightly smaller than the US
contiguous 48 states
4
Land boundaries: 0 km
Coastline: 25,760 km
Maritime claims: territorial sea: 12 nm
contiguous zone: 24 nm exclusive economic zone:
200 nm
continental shelf: 200 nm or to the edge of the
continental margin
Climate: generally arid to semiarid; temperate in
south and east; tropical in north
Terrain: mostly low plateau with deserts; fertile
plain in southeast
Elevation extremes: lowest point: Lake Eyre-15
m
highest point: Mount Kosciuszko 2,229 m
Natural resources: bauxite, coal, iron ore, cop-
per, tin, gold, silver, uranium, nickel, tungsten,
rare earth elements, mineral sands, lead, zinc, dia-
monds, natural gas, petroleum
note: Australia is the world’s largest net exporter
of coal accounting for 29% of global coal exports
Land use: arable land: 6.16% (includes about 27
million hectares of cultivated grassland)
permanent crops: 0.05%
other: 93.79% (2011)
Irrigated land: 25,460 sq km (2006)
Total renewable water resources: 492 cu km
(2011)
Freshwater withdrawal (domestic/indus-
triaV/ogricultural): total: 22.58 cu km/yr
(27%/18%/55%)
per capita: 1,152 cu m/yr (2010)
Natural hazards: cyclones along the coast; severe
droughts; forest fires
volcanism: volcanic activity on Heard and
McDonald Islands
Environment—current issues: soil erosion from
overgrazing, industrial development,
zation, and poor farming practices; soil salin-
ity rising due to the use of poor quality water;
desertification; clearing for agricultural purposes
threatens the natural habitat of many unique ani-
mal and plant species; the Great Barrier Reef off
the northeast coast, the largest coral reef in the
world, is threatened by increased shipping and its
popularity as a tourist site; limited natural fresh-
urbani-
water resources
Environment—international agreements:
party to: Antarctic-Environmental Protocol, Ant-
arctic-Marine Living Resources, Antarctic Seals,
Antarctic Treaty, Biodiversity, Climate Change,
Climate Change-Kyoto Protocél, Desertification,
Endangered Species, Environmental Modifica-
tion, Hazardous Wastes, Law of the Sea, Marine
Dumping, Marine Life Conservation, Ozone Layer
Protection, Ship Pollution, Tropical Timber 83,
Tropical Timber 94, Wetlands, Whaling
signed, but not ratified: none of the selected
agreements
Geography—note: world’s smallest continent but
sixth-largest country; the only continent without
glaciers; population concentrated along the east-
ern and southeastern coasts; the invigorating sea
breeze known as the “Fremantle Doctor” affects
the city of Perth on the west coast and is one of
the most consistent winds in the world
Location: Oceania, islands in the Coral Sea,
northeast of Australia
Geographic coordinates: 18 00 S, 152 00 E
Map references: Oceania
Area: total: less than 3 sq km
country comparison to the world: 249
land: less than 3 sq km
water: 0 sq km
note: includes numerous small islands and
reefs scattered over a sea area of about
780,000 sq km with the Willis Islets the most
important
Area—comparative: NA
Land boundaries: 0 km
Coastline: 3,095 km
Maritime claims: territorial sea: 3 nm exclusive
fishing zone: 200 nm
Climate: tropical
Terrain: sand and coral reefs and islands (or cays)
Elevation extremes: lowest point: Pacific Ocean
Om
highest point: unnamed location on Cato Island
6m
Natural resources: NEGL
Land use: arable land:0%
permanent crops: 0%
other: 100% (mostly grass or scrub cover) (2011)
Irrigated land: 0 sq km (2011)
Natural hazards: occasional tropical cyclones
Environment—current issues: no permanent
freshw ater resources
Geography—note: important nesting area for
birds and turtles
Location: Oceania, islands in the North Pacific
Ocean, about three-quarters of the way from
Hawaii to the Philippines
Geographic coordinates: 15 12 N, 145 45 E
Map references: Oceania
Area: total: 464 sq km
country comparison to the world: 197
land: 464 sq km
water: 0 sq km
note: consists of 14 islands including Saipan, Rota,
and Tinian
Area—comporative: 2.5times the size of Wash-
ington, DC
Land boundaries: 0 km
Coastline: 1,482 km
Maritime claims: territorial sea: 12 nm exclusive
economic zone: 200 nm
Climate: tropical marine; moderated by northeast
trade winds, little seasonal temperature variation;
dry season December to June, rainy season July to
October
Terrain: southern islands are limestone with level
terraces and fringing coral reefs; northern islands
are volcanic
Elevation extremes: lowest point: Pacific Ocean 0 m
highest point: unnamed elevation on Agrihan
965 m
Natural resources: arable land, fish
Land use: arable land: 2.17%
permanent crops: 2.17%
other: 95.65% (2011)','2d97424b872d79e07bb43f3cda7005bd14d42ad5dfb7bc6da4868517f4ed4ff3','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('dbd7067579fb8a8b73b1be8e23797e51203dd1c065097c1da299c5e491e98f3d',2025,'AT','Austria','geography',147,'Location: Central Europe, north of Italy and
Location: Central Europe, between Germany,
Poland, Slovakia, and Austria
Geographic coordinates: 49 45 N, 15 30 E
Map references: Europe
Area: total: 78,867 sq km
country comparison to the world: 116
land: 77,247 sq km
water: 1,620 sq km
Area—comparative: slightly smaller than South
Carolina
Land boundaries: total: 1,989 km
border countries: Austria 362 km, Germany 815
km, Poland 615 km, Slovakia 197 km
Coastline: km (landlocked)
Maritime claims: none (landlocked)
Climate: temperate; cool summers; cold, cloudy,
humid winters
Terrain: Bohemia in the west consists of roll-
ing plains, hills, and plateaus surrounded by low
mountains; Moravia in the east consists of very
hilly country
Elevation extremes: lowest point: Labe (Elbe)
River 115 m
highest point: Snezka 1,602 m
Natural resources: hard coal, soft coal, kaolin,
clay, graphite, timber
Land use: arable land: 40.12%
permanent crops: 0.96%
other: 58.92% (2011)
Irrigated land: 385.3 sq km (2007)
Total renewable water resources: 13.15 cu km
(2011)
Freshwater withdrawal (domestic/industrial/
agricultural): total: 1.7 cu km/yr (41%/56%/2%)
per capita: 164.7 cu m/yr (2009)
Natural hazards: flooding
Environment—current issues: air and water pollu-
tion in areas of northwest Bohemia and in northem
Moravia around Ostrava present health risks; acid
rain damaging forests; efforts to bring industry up to
EU code should improve domestic pollution
Environment—international agreements:
party to: Air Pollution, Air Pollution-Nitrogen
Oxides, Air Pollution-Persistent Organic Pollut-
ants, Air Pollution-Sulfur 85, Air Pollution-Sulfur
94, Air Pollution-Volatile Organic Compounds,
Antarctic-Environmental Protocol, Antarctic
Treaty, Biodiversity, Climate Change, Climate
ChangeKyoto Protocol, Desertification, Endan-
gered Species, Environmental Modification, Haz-
ardous Wastés, Law of the Sea, Ozone Layer Pro-
tection, Ship Pollution, Wetlands, Whaling
signed, but not.ratified: none of the selected
agreements
Geography—note: landlocked; strategically
located astride some of oldest and most significant
land routes in Europe; Moravian Gate is a tradi-
tional military corridor between the North Euro-
pean Plain and the Danube in central Europe
Location: Northern Europe, bordering the Baltic
Sea and the North Sea, on a peninsula north of
Germany (Jutland); also includes several major
islands (Sjaelland, Fyn, and Bomholm)
Geographic coordinates: 56 00 N, 10 00 E
Map references: Europe
Area: total: 43,094 sq km country
comparison to the world: 134
land: 42,434 sq km
water: 660 sq km
note: includes the island of Bornholm in the Bal-
tic Sea and the rest of metropolitan Denmark (the
Jutland Peninsula, and the major islands of Sjael-
land and Fyn), bur excludes the Faroe Islands and','70ee7bff876248f37780bc4e2d0bda32a0fb76444015d30be10eda1aeb613543','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('446a2145f6d26154f0dcd38e19b4d4b6f3da7ba7e4d77d8f589b823bc1aff027',2025,'SI','Slovenia','geography',148,'Geographic coordinates: 47 20 N, 13 20 E
Map references: Europe
Area: total: 83,871 sq km
country comparison to the world: 114
land: 82,445 sq km
water: 1,426 sq km
Area—comparative: slightly smaller chan Maine
Land boundaries: total: 2,562 km
border countries: Czech Republic 362 km, Ger-
many 784 km, Hungary 366 km, Italy 430 km,
Liechtenstein 35 km, Slovakia 91 km, Slovenia
330 km, Switzerland 164 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
Climate: temperate; continental, cloudy; cold
winters with frequent rain and some snow in low-
lands and snow in. mountains; moderate summers
with occasional showers
Terrain: in the west and south mostly mountains
(Alps); along the eastern and northern margins
mostly flat or gently sloping
Elevation extremes: lowest point: Neusiedler
See 115 m a
highest point: Grossglockner 3,798 m
Natural resources: oil, coal, lignite, timber, iron
ore, copper, zinc, antimony, magnesite, tungsten,
graphite, salt, hydropow er
Land use: arable land: 16.25%
permanent crops: 0.77%
other: 82.98% (2011)
Irrigated land: 1,170 sq km (2007)
Totai renewable water resources: 77.7 cu km
(2011) a
Freshwater withdrawal (domestic/industrial/
agricultural): total: 3.66 cu km/yr (18%/79%/3%)
per capita: 452.4 cu m/yr (2008)
Natural hazards:
earthquakes
Environment—current issues: some forest deg-
radation caused by air and soil pollution; soil pollu-
tion results from the use of agricultural chemicals;
air pollution results from emissions by coal-and
oil-fired pow er stations and industrial plants and
from trucks transiting Austria between northern
and southern Europe ; i
Environment—international agreements: party
to: Air Pollution, Air Pollution-Nitrogen Oxides,
Air Pollution-Persisrent Organic Pollutants,
Air Pollution-Sulfur 85, Air Pollution-Sulphur
94, Air Pollution-Volatile Organic Compounds,
Antarctic Treaty, Biodiversity, Climate Change,
Climate Change-Kyoto Protocol, Desertification,
landslides; avalanches;
Endangered Species, Environmental Modification,
Hazardous Wastes, Law of the Sea, Ozone Layer
Protection, Ship Pollution, Tropical Timber 83,
Tropical Timber 94, Wetlands, Whaling
signed, but not ratified: none of the selected
agreements
Geography—nofe: landlocked; strategic location
at the crossroads of central Europe with many eas-
ily traversable Alpine passes and valleys; major
river is the Danube; population is concentrated
on eastern low lands because of steep slopes, poor
soils, and low temperatures elsewhere','8cca7b75e5c31a5bbf0c500a22b48cbdb420f9620c3326560f5e7808c8c2f068','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('93149961a70b6b76ee7acd98066c08ac05f3a6245b3d231c18854f934297b916',2025,'AZ','Azerbaijan','geography',165,'Location: chain of islands in the North Atlantic
Ocean, southeast of Florida, northeast of Cuba
Geographic coordinates:24 15 N, 76 00 W
Map references: Central America and the
Caribbean
Area: total: 13,880 sq km
country comparison to the world: 161
land: 10,010 sq km
water: 3,870 sq km
Area—comparative:
Connecticut
Land boundaries: 0 km
Coastline: 3,542 km
Maritime claims: territorial sea: 12 nm
exclusive economic zone: 200 nm
slightly smaller than
Climote: tropical marine; moderated by warm
waters of Gulf Stream
Terrain: long, flat coral formations with some low
rounded hills
Elevation extremes: lowest point: Atlantic
Ocean 0 m
highest point: Mount Alvernia on Cat Island 63 m
Natural resources: salt, aragonite, timber, arable
land j
Land use: arable land: 0.65%
permanent crops: 0.29%
other: 99.06% (2011)
Irrigated land: 10 sq km (2003)
Total renewable water resources: 0.02 cu km (2011)
Natural hazards: hurricanes and other tropical
storms cause extensive flood and wind damage
Environment—current issues: coral reef decay;
solid waste disposal
BAHAMAS, THE
Environment—international agreements:
party to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Endan-
gered Species, Hazardous Wastes, Law of tHe Sea,
Ozone Layer Protection, Ship Pollution, Wetlands
signed, but not ratified: none of the selected
agreements
Geography—note: strategic location adjacent to
US and Cuba; extensive island chain of which 30
are inhabited','3d1ca0cd8d6cfa2ffcbfd361a59e696a8f2dca6b23b7b3baf8d80a36b214fa8b','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f0afd05d710fe707deded04dfd15248e92d28bda39a2445d2827f8e41709c2ee',2025,'BH','Bahrain','geography',168,'Location: Middle East, archipelago in the Persian
Gulf, east of Saudi Arabia
Geographic coordinates: 26 00 N, 50 33 E
Map references: Middle East
Area: total: 760 sq km
country comparison to the world: 188
land: 760 sq km
water: 0 sq km
Area—comparative: 3.5 times the size of Wash-
ington, DC
Land boundaries: 0 km
Coastline: 161 km
Maritime claims: territorial sea: 12 nm
contiguous zone: 24 nm
continental shelf: extending to boundaries to be
determined
Climate: arid; mild, pleasant winters; very hot,
humid summers
Terrain: mostly low desert plain rising gently to
low central escarpment
Elevation extremes: lowest point: Persian Gulf 0 m
56
highest point: Jabal ad Dukhan 122 m
Natural resources: oil, associated and nonassoci-
ated natural gas, fish, pearls
Land use: arable land: 1.79%
permanent crops: 3.95%
other: 94.26% (2011)
Irrigated land: 40.15 sq km (2003)
Total renewable water resources: 0.12 cu km
(2011)
Freshwater withdrawal (domestic/industrial/
agricultural): total: 0.36 cu km/yr (50%/6%/45%)
per capita: 386 cu m/yr (2003)
Natural hazards: periodic droughts; dust storms
Environment—current issues: desertification
resulting from the degradation of limited arable land,
periods of drought, and dust storms; coastal degrada-
tion (damage to coastlines, coral reefs, and sea veg-
etation) resulting from oil spills and other discharges
from large tankers, oil refineries, and distribution
stations; lack of freshwater resources (groundwater
and seawater are the only sources for all water needs)
Environment—international agreements: party
to: Biodiversity, Climate Change, Climate Change-
Kyoto Protocol, Desertification, Hazardous Wastes,
Law of the Sea, Ozone Layer Protection, Wetlands
signed, but not ratified: none of the Ga soe
agreements
Geography—note: close to primary Middle East-
ern petroleum sources; strategic location in Persian
Gulf, through which much of the Western world’s
petroleum must transit to reach open ocean','52f595fa6d7e3895fd75319fdfcd2d9f0b6cc9a7d704719fcbd280109179af3d','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('899a279c34934650ee4cef2d5ff7ce60277f8327dee03b716a01bdf5d23e4689',2025,'BD','Bangladesh','geography',176,'Location: Souther Asia, bordering the Bay of
Bengal, between Burma and India
Geographic coordinates: 24 00 N, 90 00 E
Map references: Asia
Area: total: 143,998 sq km
country comparison to the world: 95
land: 130,168 sq km
water: 13,830 sq km
Area—compoarative: slightly smaller than low a
Land boundaries: total: 4,246 km
border countries; Burma 193 km, India 4,053 km
Coastline: 580 km
Maritime claims: territorial sea: 12 nm
contiguous zone: 18 nm
exclusive economic zone: 200 nm
continental shelf: up to the outer limits of the
continental margin
Climate: tropical; mild winter (October to
March); hot, humid summer (March to June);
humid, warm rainy monsoon (June to October)
Terrain: mostly flat alluvial plain; hilly in southeast
Elevation extremes:
Ocean 0 m
highest point: Keokradong 1,230 m
Natural resources: natural gas, arable land, tim-
ber, coal ‘
Land use: arable land: 52.97%
permanent crops: 6.25%
other: 40.78% (2011)
Irrigated land: 50,500 sq km (2008)
Total renewable water resources: 1,227 cu km
(2011)
Freshwater withdrawal (domestic/
industrioV/agricultural): total: 35.87 cu km/yr
(10%/2%/88%)
per capita: 238.3 cu m/yr (2008)
Natural hazards: droughts; cyclones; much of the
country routinely inundated during the summer
lowest point: Indian
monsoon season
Environment—current issues: many people
are landless and forced to live on and cultivate
flood-prone land; waterborne diseases prevalent
in surface water; water pollution, especially of
fishing areas, results from the use of commercial
pesticides; ground water contaminated by natu-
rally occurring arsenic; intermittent water short-
ages because of falling water tables in the northem
and central parts of the country; soil degradation
and erosion; deforestation; severe overpopulation
Environment—international agreements:
party to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Endan-
gered Species, Environmental Modification,
Hazardous Wastes, Law of the Sea, Ozone Layer
Protection, Ship Pollution, Wetlands
signed, but not ratified: none of the selected
agreements
Geography—note: most of the country is situated
on deltas of large rivers flowing from the Hima-
layas: the Ganges unites with the Jamuna (main
channel of the Brahmaputra) and later joins the
Meghna to eventually empty into the Bay of Bengal','21190254dbc21eb0546558753e330bce3622edff4640ff2a3eb4031409203585','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e8c8f3592969a26d2ee4fb476f58edee1e1f90982cff77bb9537b40de4d56c65',2025,'BB','Barbados','geography',186,'Location: Caribbean, island in the North Atlantic
Ocean, northeast of Venezuela
Geographic coordinates: 13 10 N, 59 32 W
Map references; Central America and the
Caribbean
Area: total: 430 sq km
country comparison to the world: 202
land: 430 sq km
water: 0 sq km
Area—comparative: 2.5 times the size of Wash-
ington, DC
Lond boundaries: 0 km
Coastline: 97 km
Maritime claims: territorial sea: 12 nm
exclusive economic zone: 200 nm
Climate: tropical; rainy season (June to October)
Terrain: relatively flat; rises gently to central high-
land region
Elevation extremes: lowest point: Atlantic
Ocean Ô m
highest point: Mount Hillaby 336 m
Natural resources: petroleum, fish, natural gas
Land use: arable land: 27.91%
permanent crops: 2.33%
other: 69.77% (2011)
Irrigated land: 54.35 sq km (2003)
Total renewable water resources: 0.08 cu km
(2011)
Freshwater withdrawal (domestic/industrial/
agricultural): total: 0.1 cu km/yr (20%/26%/54%)
per capita: 371.3 cu m/yr (2009)
Natural hazards: infrequent hurricanes; periodic
landslides
Environment—current Issues: pollution of
coastal waters from waste disposal by ships; soil
erosion; illegal solid waste disposal threatens con-
tamination of aquifers
Environment—international agreements:
party to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Endan-
gered Species, Hazardous Wastes, Law of the Sea,
Marine Dumping, Ozone Layer Protection, Ship
Pollution, Wetlands
‘signed, but not ratified: none of the selected
agreements
Geography—note: easternmost Caribbean island','79eefc22014b4f21de46b0db4de75131a87eee0a77007c38740fb3ca135a6352','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('708cc96282968f2e5c11f977586aaac8e5d8b347ec43746663e75a63e96916fb',2025,'BY','Belarus','geography',196,'Location: Eastern Europe, east of Poland
Geographic coordinates: 53 00 N, 28 00 E
Map references: Europe
Area: total: 207,600 sq km
country comparison to the world: 86
land: 202,900 sq km
water: 4,700 sq km
Area—comparative: slightly smaller than Kansas
Land boundaries: total: 3,306 km
border countries: Latvia 171 km, Lithuania 680 km,
Poland 605 km, Russia 959 km, Ukraine 891 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
Climate: cold winters, cool and moist summers;
transitional between continental and maritime
Terrain: generally oat and cuniams much marshland
Elevation extremes: lowest point: Nyoman
River 90 m i
highest point: Dzyarzhynskaya Hara 346 m
Natural resources: timber, peat deposits, small
quantities of oil and natural gas, granite, dolomitic
limestone, marl, chalk, sand, gravel, clay
Land use: arable land: 26.63%
permanent crops: 0.59%
other: 72.78% (2011)
Irrigated land: 1,150 sq km (2003)
Total renewable water resources: 58 cu km (2011)
66
Freshwater withdrawal (domestic/industrial/
agricultural): total: 4.34 cu km/yr (32%/65%/3%)
per capita: 435.4 cu m/yr (2009)
Natural hazards: NA
Environment—currenf issues: soil pollution
from pesticide use; southern part of the country
contaminated with fallout from 1986 nuclear reac-
tor accident at Chornobyl’ in northern Ukraine
Environment—international agreements: party
to: Air Pollution, Air Pollution-Nitrogen Oxides, Air
Pollution-Sulfur 85, Biodiversity, Climate Change,
Climate Change-Kyoto Protocol, Desertification,
Endangered Species, Environmental Modification,
Hazardous Wastes, Law of the Sea, Marine Dumping,
Ozone Layer Protection, Ship Pollution, Wetlands
signed, but not ratified: none of the selected
agreements
Geography—note: landlocked; glacial scouring
accounts for the flatness of Belarusian terrain and
for its 11,000 lakes','1a20e708c87e19a0c1ae21d0b431df8f0787d69c66c80fa6fdb9fb31930c1a3f','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e423f45b9610d164414dede25f9804a5a0b317230aa27417c68ad602d8a3827f',2025,'FR','France','geography',206,'Location: Western Europe, bordering the North
Sea, between France and the Netherlands
Geographic coordinates: 50 50 N, 4 00 E
Map references: Europe
Area: total: 30,528 sq km
country comparison to the world: 141
land: 30,278 sq km
water: 250 sq km
Area—comparative: about the size of Maryland
Land boundaries: total: 1,385 km
border countries: France 620 km, Germany 167
km, Luxembourg 148 km, Netherlands 450 km
Coastline: 66.5 km
Maritime claims: territorial sea: 12 nm
contiguous zone: 24 nm
exclusive economic zone: geographic coordinates
define outer limit continental shelf: median line
with neighbors
Climate: temperate; mild winters, cool summers;
rainy, humid, cloudy
Terrain: flat coastal plains in northwest, central
rolling hills, rugged mountains of Ardennes Forest
in southeast
Elevation extremes: lowest point: North Sea 0m
highest point: Botrange 694 m
Natural resources: construction materials, silica
sand, carbonates
Lond use: arable land: 27.06%
permanent crops: 0.72% other: 72.22%
note: includes Luxembourg (2011)
70
THE CIA WORLD FACTBOOK
Irrigated land: 233.5 sq km (2007)
Total renewable water resources: 18.3 cu km
(2011)
Freshwater withdrawal (domestic/industrial/
agricultural): total: 6.22 cu km/yr (12%/88%/1%)
per capita; 589.8 cu m/yr (2007)
Natural hazards: flooding is a threat along rivers
and in areas of reclaimed coastal land, protected
from the sea by concrete dikes
Environmeni—current issues: the environ-
ment is exposed to intense pressures from
human. activities: urbanization, dense transpor-
tation network, industry, extensive animal breed-
ing and crop cultivation; air and water pollution
also have repercussions for neighboring coun-
tries; uncertainties regarding federal and regional
responsibilities (now resolved) had slowed progress
in tackling environmental challenges
Environment—international agreements: party
to: Air Pollution, Air Pollution-Nitrogen Oxides,
Air Pollution-Persistent Organic Pollutants, Air
Pollution-Sulfur 85, Air Pollution-Sulfur 94, Air
Pollution-Volatile Organic Compounds, Antarctic-
Environmental Protocol, Antarctic-Marine Living
Resources, Antarctic Seals, Antarctic Treaty, Bio-
diversity, Climate Change, Climate Change-Kyoto
Protocol, Desertification, Endangered Species,
Environmental Modification, Hazardous Wastes,
Law of the Sea, Marine Dumping, Marine Life Con-
servation, Ozone Layer Protection, Ship Pollution,
Tropical Timber 83, Tropical Timber 94, Wetlands,
Whaling
signed, but not ratified: none of the selected
agreements
Geography—note: crossroads of Western Europe;
most West European capitals within 1,000 km of Brus-
sels, the seat of both the European Union and NATO
Location: Oceania, islands in the South Pacific
Ocean, southeast of Australia
Geographic coordinates: 41 00 S, 174 00 E
Map references: Oceania
Area: total: 267,710 sq km š
country comparison to the world: 76
land: 267,710 sq km
524
water: NA
note: includes Antipodes Islands, Auckland
Islands, Bounty Islands, Campbell Island,
Chatham Islands, and Kermadec Islands
Area—comparative: about the size of Colorado
Land boundaries: 0 km
Coastline: 15,134 km
Maritime claims: territorial sea: 12 nm
contiguous zone: 24 nm
exclusive economic zone: 200 nm
continental shelf: 200 nm or to the edge of the’
continental margin
Climate: temperate with sharp regional contrasts
Terrain: predominately mountainous with some
large coastal plains
Elevation extremes: lowest point: Pacific Ocean
Om
highest point: Aoraki-Mount Cook 3,754 m
Natural resources: natural gas, iron ore, sand,
coal, timber, hydropower, gold, limestone
Land use: arable land: 1.76%
permanent crops: 0.27%
other: 97.98% (2011)
irrigated land: 6,193 sq km (2007)
Total renewable water resources: 327 cu km
(2011)
Freshwater withdrawal (domestic/industrial/
agricultural): total: 4.75 cu km/yr (23%/5%/72%)
per capita: 1,200 cu m/yr (2010)
Natural hazards: earthquakes are common,
though usually not severe; volcanic activity
volcanism: significant volcanism on North Island;
Ruapehu (elev. 2,797 m), which last erupted in
2007, has a history of large eruptions in the past
century; Taranaki has the potential to produce
dangerous avalanches and lahars; other historically
active volcanoes include Okataina, Raoul Island,
Tongariro, and White Island
Environment—current issues: deforestation;
soil erosion; native flora and fauna hard-hit by
invasive species
Environment—international agreements:
party to: Antarctic-Environmental Protocol, Ant-
arctic-Marine Living Resources, Antarctic Treaty,
Biodiversity, Climate Change, Climate Change-
Kyoto Protocol, Desertification, Endangered
Species, Environmental Modification, Hazardous
Wastes, Law of the Sea, Marine Dumping, Ozone
Layer Protection, Ship Pollution, Tropical Timber
83, Tropical Timber 94, Wetlands, Whaling
SOUTH PACIFIC
ae es
THER RTS
SOMA
SGUTH
Toenail
signed, but not ratified: Antarctic Seals, Marine
Life Conservation
Geography—note: almost 90% of the population
lives in cities; Wellington is the southemmost
national capital in the w orld
Location: islands in the South Atlantic Ocean,
about midway between South America and Africa;
Ascension Island lies 700 nm northwest of Saint
Helena; Tristan da Cunha lies 2,300 nm southwest
of Saint Helena
Geographic coordinates: Saint Helena: 15 57 S,
542 W
Ascension Island: 7 57 S, 1422 W
Tristan da Cunha island group: 37 15 S, 12
30 W
Map references: Africa
Area: total: 308 sq km
country comparison to the world: 209
land: Saint Helena Island 122 sq km; Ascension
Island 88 sq km; Tristan da Cunha island group 98
sq km
water: 0 sq km
Area—comparative: slightly more than twice the
size of Washington, DC
Land boundaries: 0 km
Coastline: Saint Helena: 60 km Ascension Island:
NA Tristan da Cunha: 40 km
Maritime claims: territorial sea: 12 nm
exclusive fishing zone: 200 nm
Climate: Saint Helena: tropical marine; mild,
tempered by trade winds
Ascension Island: tropical marine; mild, semi-arid
Tristan da Cunha: temperate marine; mild, tem-
pered by trade winds (tends to be cooler than Saint
Helena)
Terrain: the islands of this group result from vol-
canic activity associated with the Atlantic Mid-
Ocean Ridge
Saint Helena: rugged, volcanic; small scattered
plateaus and plains
Ascension: surface covered by lava flows and cin-
der cones of 44 dormant volcanoes; ground rises
to the east
Tristan da Cunha: sheer cliffs line the coastline of
the nearly circular island; the flanks of the central
volcanic peak are deeply dissected; narrow coastal
plain lies between The Peak and the coastal cliffs
Elevation extremes: lowest point: Atlantic
Ocean 0 m
highest point: Queen Mary''s Peak on Tristan da
Cunha 2,060 m; Green Mountain on Ascension
Island 859 m; Mount Actaeon on Saint Helena
Island 818 m
Natural resources: fish, lobster
Land use: arable land: 10.26%
permanent crops: 0%
other: 89.74% (2011)
Irrigated land: NA
Natural hazards: active volcanism on Tristan da
Cunha
volcanism: the island volcanoes of Tristan da
Cunha (elev. 2,060 m) and Nightingale Island
(elev. 365 m) experience volcanic activity; Tristan
da Cunha erupted in 1962 and Nightingale in
2004
r
SAINT HELENA, ASCENSION, AND TRISTAN DA CUNHA
Environment—current issues: NA
Geography—note: Saint Helena harbors at
least 40 species of plants unknown elsewhere
in the world; Ascension is a breeding ground
for sea turtles and sooty terns; Queen Mary’s
Peak on Tristan da Cunha is the highest island
mountain in the South Atlantic and a promi-
nent landmark on the sea lanes around southern
Africa
Geographic coordinates: 40 00 N, 400 W
Map references: Europe
Area: total: 505,370 sq km
country comparison to the world: 52
land: 498,980 sq km
water: 6,390 sq km
note: there are two autonomous cities—Ceuta
and Melilla—and 17 autonomous communities
including Balearic Islands and Canary Islands, and
three small Spanish possessions off the coast of
Morocco—Islas Chafarinas, Penon de Alhucemas,
and Penon de Velez de la Gomera
Area—comparative: slightly more than twice the
size of Oregon
Land boundaries: total: 1,917.8 km
border countries: Andorra 63.7 km, France 623
km, Gibraltar 1.2 km, Portugal 1,214 km, Morocco
(Ceuta) 6.3 km, Morocco (Melilla) 9.6 km
Coastline: 4,964 km
Location: Middle East, west of Jordan, east of','d9d069bf77994e891d92ccf9d8906f056672d04531bfb0ee51bc8748c762bc47','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1e75cfad1fc078052a8e70b8655ae3e6b601de79dc2ff982d37e3cdfac7bc475',2025,'BE','Belgium','geography',216,'Location: Central America, bordering the Carib-
bean Sea, between Guatemala and Mexico
Geographic coordinates: 17 15 N, 88 45 W
Map references: Central America and the
Caribbean
Area: total: 22,966 sq km
country comparison to the world: 152
land: 22,806 sq km
water: 160 sq km
Area—comparative:
Massachusetts
Land boundaries: total: 516 km
border countries: Guatemala 266 km, Mexico
250 km
Coastline: 386 km
Maritime claims: territorial sea: 12 nm in the
north, 3 nm in the south; noce—from the mouth of
the Sarstoon River to Ranguana Cay, Belize’s ter-
ritorial sea is 3 nm; according to Belize’s Maritime
Areas Act, 1992, the purpose of this limitation is
to provide a framework for negotiating a definitive
agreement on territorial differences with Guate-
mala exclusive economic zone: 200 nm
slightly > smaller than
74
Climate: tropical; very hot and humid; rainy season
(May to November); dry season (February to May)
Terrain: flat, swampy coastal plain; low mountains
in south
Elevation extremes: lowest point: Caribbean
Sea 0 m
highest point: Doyle’s Delight 1,160 m
Natural resources: arable land potential, timber,
fish, hydropower
Land use: arable land: 3.27%
permanent crops: 1.39%
other: 95.34% (2011)
Irrigated tand: 30 sq km (2003)
Total renewable water resources: 18.55 cu km
(2011)
Freshwater withdrawal (domestic/industrial/
agricultural): total: 0.22 cu km/yr (4%/49%/46%)
per capita: 845.2 cu m/yr (2000)
Natura! hazards: frequent, devastating hurricanes
(June to November) and coastal flooding (espe-
cially in south)
Environment—current issues: deforestation;
water pollution from sewage, industrial effluents,
agricultural runoff; solid and sewage waste disposal
Environment—international agreements:
party to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Endan-
gered Species, Hazardous Wastes, Law of the Sea,
Ozone Layer Protection, Ship Pollution, Wet-
lands, Whaling
signed, but not ratified: none of the selected
agreements
Geography—note: only country in Central
America without a coastline on the North Pacific
Ocean
Location: Western Africa, bordering the Bight of
Benin, between Nigeria and Togo
Geographic coordinates: 9 30 N, 2 15 E
Map references: Africa
Area: total: 112,622 sq km
country comparison to the world: 102
land: 110,622 sq km
water: 2,000 sq km
Area—comparative:
Pennsylvania
Land boundaries: total: 1,989 km
border countries: Burkina Faso 306 km, Niger 266
km, Nigeria 773 km, Togo 644 km
Coastline: 121 km
Maritime claims: territorial sea: 200 nm
Climate: tropical; hot, humid iri south; semiarid
in north Terrain: mostly flat to undulating plain;
some hills and low mountains
slightly smaller than
Elevation extremes: lowest point: Atlantic
Ocean 0 m
highest point: Mont Sokbaro 658 m
Natural resources: small offshore oil deposits,
limestone, marble, timber
Land use: arable land: 22.48%
permanent crops: 2.61%
other: 74.9% (2011)
Irrigated land: 230.4 sq km (2008)
Total renewable water resources: 26.39 cu km
(2011) ‘ p
Freshwater withdrawal (domestic/industrial/
agricultural): cotal:0.13 cukm/yr (32%/23%/45%)
per capita: 18.74 cu m/yr (2001)
Natural hazards: hot, dry, dusty harmatran wind
may affect north from December to March
Environment—current issues: inadequate sup-
plies of potable water; poaching threatens wildlife
populations; deforestation; desertification
Environment—international agreements:
party to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Endan-
gered Species, Environmental Modification, Haz-
ardous Wastes, Law of the Sea, Ozone Layer Pro-
tection, Ship Pollution, Wetlands, Whaling
77
‘BURKINA
Faso
gil
À
y
F
i Malanvile”
,
Natitingou
¿Djougou
<Parakou &
E
4
=','916ccc2c3b3e80442a5a9d47c892b88b77b2ee606574dd5f1e71296561d3a0c4','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('af7117c89531f9f099bae061a741a82953955ee1b69ea4f774b1e42483382734',2025,'NG','Nigeria','geography',218,'I
4 S
Í Bonicon Cove i
ee
Abomey
2 $
¿ Lokossa PORTOŚ:
_ NOVO‘
S Ould x;
A n “Cotonou
signed, but not ratified: none of the selected
agreements
Geography—nofe: sandbanks create difficult
access to a coast with no natural harbors, river
mouths, or islands
Location: Central Africa, bordering the Bight of
Biafra, between Equatorial Guinea and Nigeria
Geographic coordinates: 6 00 N, 12 00 E
Map references: Africa
Area: total: 475,440 sq km
country comparison to the world: 54
land: 472,710 sq km
water: 2,730 sq km
Area—comparative:
California
Land boundaries: total: 4,591 km
border countries: Central African Republic 797
km, Chad 1,094 km, Republic of the Congo 523
slightly larger than
km, Equatorial Guinea 189 km, Gabon 298 km,
Nigeria 1,690 km
Coastline: 402 km
Maritime claims: territorial sea: 12 nm
contiguous zone: 24 nm
Climate: varies with terrain, from tropical along
coast to semiarid and hot in north
Terrain: diverse, with coastal plain in southwest,
dissected plateau in center, mountains in west,
plains in north
Elevation extremes: lowest point: Atlantic
Ocean 0 m
highest point: Fako 4,095 m (on Mt. Cameroon)
Natural resources: petroleum, bauxite, iron ore,
timber, hydropower
Land use: arable land: 13.04%
permanent crops: 2.94%
other: 84.01% (2011)
Irrigated land: 256.5 sq km (2003)
Total renewable water resources: 285.5 cu km
(2011)
Freshwater withdrawal (domestic/indus-
triaVagricultural): total: 0.97 cu km/yr
(23%/10%/68%)
per capita: 58.9 cu m/yr (2005)
Natural hazards: volcanic activity with periodic
releases of poisonous gases from Lake Nyos and
Lake Monoun volcanoes
volcanism: Mt. Cameroon (elev. 4,095 m), which
last erupted in 2000, is the most frequently active
volcano in West Africa; lakes in Oku volcanic
field have released fatal levels of gas on occasion,
killing some 1,700 people in 1986
Environment—current issues: waterborne dis-
eases are prevalent; deforestation; overgrazing;
desertification; poaching; overfishing
Environment—international agreements:
party to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Endan-
gered Species, Hazardous Wastes, Law of the Sea,
Ozone Layer Protection, Tropical Timber 83, Trop-
ical Timber 94, Wetlands, Whaling
signed, but not ratified: none of the selected
agreements
Geography—note: sometimes referred to as the
hinge of Africa; throughout the country there are
areas of thermal springs and indications of current
or prior volcanic activity; Mount Cameroon, the
highest mountain in Sub-Saharan west Africa, is
an active volcano
Location: Central Africa, bordering the Bight of
Biafra, between Cameroon and Gabon
Geographic coordinates: 2 00 N, 10 00 E
Map references: Africa
Area: total: 28,051 sq km
country comparison to the world: 146
land: 28,051 sq km
water: 0 sq km
Area—comparative:
Maryland
Land boundaries: total: 539 km
border countries: Cameroon 189 km, Gabon 350
km :
Coastline: 296 km
Maritime claims: territorial sea: 12 nm
exclusive economic zone: 200 nm
Climate: tropical; always hot, humid
Terrain: coastal plains rise to interior hills; islands
are volcanic
Elevation extremes: lowest point: Atlantic
Ocean 0 m
highest point: Pico Basile 3,008 m
Natural resources: petroleum, natural gas, tim-
ber, gold, bauxite, diamonds, tantalum, sand and
gravel, clay
Land use: arable land: 4.63%
permanent crops: 2.5%
other: 92.87% (2011)
Irrigated land: NA
Total renewable water resources: 26 cu km
(2011)
slightly smaller than
Freshwater withdrawal (domestic/industrial’ . -
agricultural): cotal:0.02 cu km/yr (80%/15%/5%)
per capita: 31.41 cu m/yr (2005)
Natural hazards: violent windstorms; flash floods
volcanism: Santa Isabel (elev. 3,007 m), which
last erupted in 1923, is the country’s only histori-
cally active volcano; Santa Isabel, along with two
dormant volcanoes, form Bioko Island in the Gulf
of Guinea
Environment—current issues: tap water is not
potable; deforestation
Environment—international agreements:
party to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Endan-
gered Species, Hazardous Wastes, Law of the Sea,
Marine Dumping, Ozone Layer Protection, Ship
Pollution, Wetlands
signed, but not ratified: none of the selected
agreements
Geography—note: insular and
regions widely separated
Location: Oceania, island in the South Pacific
Ocean, east of Tonga
Geographic coordinates: 19 02 S, 169 52 W
Map references: Oceania
Area: total: 260 sq km
country comparison to the world: 213
land; 260 sq km
water: 0 sq km
Area—comparative: 1.5 times the size of Wash-
ington, DC
Land boundaries: 0 km
Coastline: 64 km
Maritime claims: territorial sea: 12 nm
exclusive economic zone: 200 nm
Climate: tropical; modified by southeast trade
winds ó
Terrain: steep limestone cliffs along coast, central
plateau oa
Elevation extremes: lowest point: Pacific Ocean
Om
hignest point: unnamea elevation near iviutaiau
settlement 66 m
Natural resources: fish, arable land
Land use: arable land: 3.85%
permanent crops: 11.54%
other: 84.62% (2011)
irrigated land: NA
Natural hazards: typhoons
Environment—current issues: increasing atten-
tion to conservationist practices to counter loss
of soil fertility from traditional slash and burn
agriculture
Environment—international agreements:
party to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Law of
the Sea, Ozone Layer Protection
Geography—note: one of world’s largest coral
islands','b19090d31c528fd3c316ef0fdbb735b1291ed77209c4bb3bc1a2bc5de4d3f2f5','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f3e5e45fe9dd174a3e8b8971d1beb95ffed61597468d3f6cb0597fe227b8dd31',2025,'BM','Bermuda','geography',229,'Location: North America, group of islands in the
North Atlantic Ocean, east of South Carolina
(US)
Geographic coordinates: 32 20 N, 64 45 W
Map references: North America
Area: total: 54 sq km
country comparison to the world: 232
land: 54 sq km
water: 0 sq km
Area—comparative: about one-third the size of
Washington, DC
Land boundaries: 0 km
Coastline: 103 km
Maritime claims: territorial sea: 12 nm
exclusive fishing zone: 200 nm
Climate: subtropical; mild, humid; gales, strong winds
common in winter Terrain: low hills separated by
fertile depressions Elevation extremes: lowest point:
Atlantic Ocean 0 m highest point: Town Hill 76 m
Natural resources: limestone, pleasant climate
fostering tourism
Land use: arable land: 14.8%
permanent crops: 0%
other: 85.2% (55% developed, 45% rural/open
space) (2011)
Irrigated land: NA
Natural hazards: hurricanes (June to November)
Environment—current issues:
development
Geography—note: consists of about 138 coral
islands and islets with ample rainfall, but no rivers
t
sustainable
or freshwater lakes; some land was leased by the
US Government from 1941 to 1995','1ac92cf3b1ce4bc41837741e684dd1be0682a798707b0b1bd8a2c5b85b51b4d9','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('630198f0d25812fe0810471b2d710bb91610916c4f4884c52e6835942e53d566',2025,'BT','Bhutan','geography',239,'Location: Southern Asia, between China and
Location: Central South America, southwest of','57f5d8c03238c9fa9dfa8258a042932eddca473434d4bff2da68bea2aacb39ac','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('18d7660f0da7c6ad85707c1609f78ec96398886715d527c0a5589135f64aee6c',2025,'IN','India','geography',240,'Geographic coordinates: 27 30 N, 90 30 E
Map references: Asia
Area: total: 38,394 sq km
country comparison to the world: 137
land: 38,394 sq km
water: 0 sq km
Area—comparative: about one-half the size of
Indiana
Land boundaries: total: 1,075 km
border countries: China 470 km, India 605 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
Climate: varies; tropical in southern plains; cool
winters and hot summers in central valleys; severe
winters and cool summers in Himalayas
Terrain: mostly mountainous with some fertile val-
leys and savanna
Elevation extremes: lowest point: Drangeme
Chhu 97 m
highest point: Gangkar Puensum 7,570 m
83
Natural resources: timber, hydropower, gypsum,
calcium carbonate
Land use: arable land: 2.49%
permanent crops: 0.46%
other: 97.06% (2011)
Irrigated land: 319.1 sq km (2010)
Total renewable water resources: 78 cu km
(2011)
Freshwater withdrawal (domestic/industrial/
agricultural): total: 0.34 cu km/yr (5%/1%/94%)
per capita: 458 cu m/yr (2008)
Natural hazards: violent storms from the Hima- °
layas are the source of the country’s name, which
translates as Land of the Thunder Dragon; fre-
quent landslides during the rainy season
Environment—current issues: soil erosion; lim-
ited access to potable water
Environment—international agreements:
party to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Endan-
gered Species, Hazardous Wastes, Ozone Layer
Protection signed, but not ratified: Law of the Sea
Geography—note: landlocked; strategic location
between China and India; controls several key
Himalayan mountain passes
Location: Southeastern Asia, archipelago between
the Indian Ocean and the Pacific Ocean
Geographic coordinates: 5 00 S, 120 00 E
Map references: Southeast Asia
Area: total: 1,904,569 sq km
country comparison to the world: 15
land: 1,811,569 sq km
water: 93,000 sq km
Area—comparative: slightly less than three
times the size of Texas
Land boundaries: tocal:2,830 km
border countries: Timor-Leste 228 km, Malaysia
1,782 km, Papua New Guinea 820 km
Coostline: 54,716 km
Maritime claims: measured from claimed archi-
pelagic straight baselines
342
territorial sea: 12 nm
exclusive economic zone: 200 nm
Climate: tropical; hot, humid; more moderate in
highlands Terrain: mostly coastal low lands; larger
islands have interior mountains
Elevation extremes: lowest point: Indian Ocean
Om
highest point: Puncak Jaya 4,884 m
Natural resources: petroleum, tin, natural gas,
nickel, timber, bauxite, copper, fertile soils, coal,
gold, silver Land use: arable land: 12.34% perma-
nent crops: 10.5% other: 77.16% (2011)
Irrigated land: 67,220 sq km (2005)
Total renewable water resources: 2,019 cu km
(2011)
Freshwater withdrawal (domestic/indus-
triaV/agricultural): total: 113.3 cu km/yr
(11%/19%/71%) i `
per capita: 517.3 cu m/yr (2005)
Natural hazards: occasional floods; severe
droughts; earthquakes; volcanoes;
forest fires volcanism: Indonesia contains the
most volcanoes of any country in the world—
some 76 are historically active; significant vol-
canic activity occurs on Java, western Sumatra,
the Sunda Islands, Halmahera Island, Sulawesi
Island, Sangihe Island, and in the Banda Sea;
Merapi (elev. 2,968 m), Indonesia''s most active
volcano and in eruption since 2010, has been
deemed a “Decade Volcano” by the Interna-
tional Association of Volcanology and Chemis-
try of the Earth’s Interior, worthy of study due
to its explosive history and close proximity to
human populations; other notable historically
active volcanoes include Agung, Awu, Karang-
etang, Krakatau (Krakatoa), Makian, Raung,
and Tambora
Environment—current issues: deforestation;
water pollution from industrial wastes, sewage; air
pollution in urban areas; smoke and haze from for-
est fires
Environment—international agreements:
party to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Endan-
gered Species, Hazardous Wastes, Law of the Sea,
Ozone Layer Protection, Ship Pollution, Tropical
Timber 83, Tropical Timber 94, Wetlands
signed, but not ratified: Marine Life Conservation
Geography—note: archipelago of 17,508 islands
(6,000 inhabited); straddles equator; strategic
location astride or along major sea lanes from
Indian Ocean to Pacific Ocean','bb040d293317891f9bfe07df4d5b6f6d6f802212bba6518bba30062dc4768896','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4b892d8c264274345a11f92bd5ae187c5f18f121b298b4a4cc720347e4564824',2025,'BR','Brazil','geography',249,'Geographic coordinates: 17 00 S, 65 00 W
Map references: South America
Area: total: 1,098,581 sq km
country comparison to the world: 28
land: 1,083,301 sq km
water: 15,280 sq km
Area—comparative: slightly less than three
times the size of Montana
Land boundaries: total: 6,940 km
border countries: Argentina 832 km, Brazil 3,423
km, Chile 860 km, Paraguay 750 km, Peru 1,075 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
Climate: varies with altitude; humid and tropical
to cold and semiarid
Terrain: rugged Andes Mountains with a highland
plateau (Altiplano), hills, low land plains of the
Amazon Basin
Elevation extremes: lowest point: Rio Paraguay
90 m
highest point: Nevado Sajama 6,542 m
Natural resources: tin, natural gas, petroleum,
zinc, tungsten, antimony, silver, iron, lead, gold,
timber, hydropower
Land use: arable land: 3.49%
permanent crops: 0.2%
other: 96.31% (2011)
Irrigated land: 1,282 sq km (2003)
Total renewable water resources: 622.5 cu km
(2011)
Freshwater withdrawal (domestic/industrial/
agricultural): total: 2.64 cukm/yr (25%/14%/61%)
per capita: 305.8 cu m/yr (2005)
Natural hazards: flooding in the northeast
(March to April)
volcanism: volcanic activity in Andes Mountains
on the border with Chile; historically active vol-
canoes in this region are Irruputuncu (elev. 5,163
m), which last erupted in 1995, and Olca-Paruma
Environment—current issues: the clearing of
land for agricultural purposes and the interna-
tional demand for tropical timber are contributing
to deforestation; soil erosion from overgrazing and
poor cultivation methods (including slash-and-
burn agriculture); desertification; loss of biodiver-
sity; industrial pollution of water supplies used for
drinking and irrigation l
Environment—international agreements: party
to: Biodiversity, Climate Change, Climate Change-
Kyoto Protocol, Desertification, Endangered Spe-
cies, Hazardous Wastes, Law of the Sea, Marine
Dumping, Ozone Layer Protection, Ship Pollution,
Tropical Timber 83, Tropical Timber 94, Wetlands
signed, but not ratified: Environmental Modifica-
tion, Marine Life Conservation
Geography—fote: landlocked; shares control
of Lago Titicaca, world’s highest navigable lake
(elevation 3,805 m), with Peru
Location: Eastern South America, bordering the
Atlantic Ocean
Geographic coordinates: 10 00 S, 55 00 W
Map references: South America
Area: total: 8,514,877 sq km
country comparison to the world: 5
land: 8,459,417 sq km
water: 55,460 sq km
note: includes Arquipelago de Fernando de
Noronha, Atol das Rocas, Ilha da Trindade, Ilhas
Martin Vaz, and Penedos de Sao Pedro e Sao Paulo
Areo—comparative: slightly smaller than the US
Land boundaries: total: 16,885 km
border countries: Argentina 1,261 km, Bolivia
3,423 km, Colombia 1,644 km, French Guiana 730
km, Guyana 1,606 km, Paraguay 1,365 km, Peru
2,995 km, Suriname 593 km, Uruguay 1,068 km,
Venezuela 2,200 km
Coastline: 7,491 km
Maritime claims: territorial sea: 12 nm
contiguous zone: 24 nm
exclusive economic zone: 200 nm
continental shelf: 200 nm or to edge of the con-
tinental margin Climate: mostly tropical, but tem-
perate in south Terrain: mostly flat to rolling low
lands in north; some plains, hills, mountains, and
narrow coastal belt
Elevation extremes: lowest point: Atlantic
Ocean 0 m
highest point: Pico da Neblina 2,994 m
Natural resources: bauxite, gold, iron ore, manga-
nese, nickel, phosphates, platinum, tin, rare earth
elements, uranium, petroleum, hydropower, timber
Land use: arable land: 8.45%
permanent crops: 0.83%
other: 90.72% (2011)
Irrigated land: 54,000 sq km (2011)
Total renewable water resources: 8,233 cu km
(2011)
Freshwater withdrawal (domestic/industrial/
agricultural): total:58.07 cukm/yr (28%/17%/55%)
per capita: 306 cu m/yr (2006)
Natural hazards: recurring droughts in northeast;
floods and occasional frost in south
Environment—current issues: deforestation in
Amazon Basin destroys the habitat and endangers
a multitude of plant and animal species indigenous
to the area; there is a lucrative illegal wildlife
trade; air and water pollution in Rio de Janeiro,
Sao Paulo, and several other large cities; land deg-
radation and water pollution caused by improper
mining activities; wetland degradation; severe oil
spills
Environment—international agreements:
party to: Antarctic-Environmental Protocol, Ant-
arctic-Marine Living Resources, Antarctic Seals,
Antarctic Treaty, Biodiversity, Climate Change,
Climate Change-Kyoto Protocol, Desertification,
Endangered Species, Environmental Modifica-
tion, Hazardous Wastes, Law of the Sea, Marine
Dumping, Ozone Layer Protection, Ship Pollution,
Tropical Timber 83, Tropical Timber 94, Wetlands,
Whaling
signed, but not ratified: none of the selected
agreements
Geography—note: largest country in South
America: shares common boundaries with every
South American country except Chile and Ecuador
Terrain: mostly rolling highlands; low coastal
plain; savanna in south
312
Elevation extremes: lowest point: Atlantic
Ocean 0m
highest point: Mount Roraima 2,835 m
Natural resources: bauxite, gold, diamonds,
hardwood timber, shrimp, fish
Land use: arable land: 1.95%
permanent crops: 0.13%
other: 97.92% (2011)
Irrigated land: 1,501 sq km (2003)
Total renewable water resources: 241 cu km
(2011)
Freshwater withdrawal (domestic/industrial/
agricultural): total: 1.64 cu km/yr (4%/1%/94%)
per capita: 2,222 cu m/yr (2010)
Natural hazards: flash flood threat during rainy
seasons
Environment—current issues: water pollution
from sewage and agricultural and industrial chemi-
cals; deforestation
Environment—international agreements:
party to: Biodiversity, Climate Change, Climate ‘
Change-Kyoto Protocol, Desertification, Endan-
gered Species, Hazardous Wastes, Law of the Sea,
Ozone Layer Protection, Ship Pollution, Tropical
Timber 83, Tropical Timber 94
signed, but not ratified: none of the selected
agreements
Geography—note: the third-smallest country
in South America after Suriname and Uruguay;
substantial portions of its western and eastern ter-
ritories are claimed by Venezuela and Suriname
respectively','f778772052791542d3e15932e6b04b0415d10c3a8f89ba458d557dfcfa7478bb','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ecb0b9ef9c50fe0e153a010cf546704feaa85a2a7bca58d7daccdcf7627296c5',2025,'PY','Paraguay','geography',259,'Location: Southeastern Europe, bordering the
Adriatic Sea and Croatia
Geographic coordinates: 44 00 N, 18 00 E
Location: Central South America, northeast of
Argentina, southwest of Brazil
Geographic coordinates: 23 00 S, 58 00 W
Map references: South America
Area: total: 406,752 sq km
country comparison to the world: 60
land: 397,302 sq km
water: 9,450 sq km
Area—comparative:
California
Land boundaries: total: 3,995 km
border countries: Argentina 1,880 km, Bolivia
750 km, Brazil 1,365 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
Climate: subtropical to temperate; substantial
rainfall in the eastern portions, becoming semiarid
in the far west
slightly smaller than
Terrain: grassy plains and wooded hills east of Rio
+ Paraguay; Gran Chaco region west of Rio Paraguay
568
mostly low, marshy plain near the river, and dry
forest and thorny scrub elsewhere
Elevation extremes: lowest point: junction of
Rio Paraguay and Rio Parana 46 m
highest point: Cerro Pero 842 m
Natural resources: hydropower, timber, iron ore,
manganese, limestone
Land use: arable land: 9.59%
permanent crops: 0.22%
other: 90.19% (2011)
Irrigated land: 670 sq km (2003 )
Total renewable water resources: 336 cu km
(2011)
Freshwater withdrawal (domestic/industrial/
agricultural): total: 0.49 cu km/yr (20%/8%/71%)
per capita: 88.05 cu m/yr (2000)
Natural hazards: local flooding in southeast
(early September to June); poorly drained plains
may become boggy (early October to June)
Environment—current Issues: deforestation;
water pollution; inadequate means for waste dis-
posal pose health risks for many urban residents;
loss of wetlands
Environment—international agreements:
party to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Endan-
gered Species, Hazardous Wastes, Law of the Sea,
Ozone Layer Protection, Wetlands
signed, but not ratified: none of the selected
agreements
Geography—note: landlocked; lies between
Argentina, Bolivia, and Brazil; population con-
centrated in southern part of country
Location: Western South America, bordering the
South Pacific Ocean, between Chile and Ecuador _
Geographic coordinates: 10 00 S, 76 00 W
571
+ ear omen:
T i “a
| Mr
B c Tean
“Piura £ Yuginagyias J” É bao urgent,
Chiclayo? Y
Teme
ammore” 4 Node.
, a j
souTH ^ _ THuanucp
LIMA
n ra
Talara,
g valipa
k Y
*Huaecayo
ICE AN ‘gS:
Map references: South America
Area: total: 1,285,216 sq km
country comparison to the world: 20
* land: 1,279,996 sq km
water: 5,220 sq km
Area—comparative: slightly smaller than Alaska
Land boundaries: total; 7,461 km
border countries: Bolivia 1,075 km, Brazil 2,995
km, Chile 171 km, Colombia 1,800 km, Ecuador
1,420 km
Coastline: 2,414 km
Maritime claims: territorial sea: 200 nm
continental shelf: 200 nm
Climate: varies from tropical in east to dry desert
in west; temperate to frigid in Andes
Terrain: western coastal plain (costa), high and
rugged Andes in center (sierra), eastern low land
jungle of Amazon Basin (selva)
Elevation extremes: lowest point: Pacific Ocean
Om
highest point: Nevado Huascaran 6,768 m
Natural resources: copper, silver, gold, petro-
leum, timber, fish, iron ore, coal, phosphate, pot-
ash, hydropower, natural gas
Land use: arable land: 2.84%
permanent crops; 0.66%
other: 96.5% (2011)
Irrigated land: 11,960 sq km (2003)
Total renewable water resources: 1,913 cu km
(2011)
Freshwater ` withdrawal (domestic/indus-
trial/agricultural); total: 19.34 cu km/yr
(8%/10%/82%)
per capita: 727.6 cu m/yr (2005)
Natural hazards: earthquakes, tsunamis, flooding,
landslides, mild voleanic activity
volcanism: volcanic activity in the Andes Moun-
tains; Ubinas (elev. 5,672 m), which last erupted
in 2009, is the country’s most active volcano; other
historically active volcanoes include El Misti,
Huaynaputina, Sabancaya, and Yucamane
Environment—current issues: deforestation
(some the result of illegal logging); overgrazing of
the slopes of the costa and sierra leading to soil
erosion; desertification; air pollution in Lima; pol-
lution of rivers and coastal waters from municipal
and mining wastes
Environment—international agreements:
party to: Antarctic-Environmental Protocol,
Antarctic-Marine Living Resources, Antarctic
Treaty, Biodiversity, Climate Change, Climate
572
THE CIA WORLD FACTBOOK
Change-Kyoto Protocol, Desertification, Endan-
gered Species, Hazardous Wastes, Marine Dump-
ing, Ozone Layer Protection, Ship Pollution,
Tropical Timber 83, Tropical Timber 94, Wetlands,
Whaling
signed, but not ratified: none of the selected
agreements
Geography—note: shares control of Lago Titi-
caca, world’s highest navigable lake, with Bolivia;
a remote slope of Nevado Mismi, a 5,316 m peak, is
the ultimate source of the Amazon River','c1efe3fb9a806482fb4cb37c60ff244e30ef4ddc6e6ce6688c779dd23d6efb54','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8563cb10db6e2358126c2e625416de97578f75e9251197a42f46d7cfc5cfc9ec',2025,'BA','Bosnia and Herzegovina','geography',260,'Map references: Europe
Area: total: 51,197 sq km
country comparison to the world: 129
land: 51,187 sq km
water: 10 sq km
Areo—comparative: slightly smaller than West
Virginia
Land boundaries: total: 1,538 km
border countries: Croatia 932 km, Montenegro
249 km, Serbia 357 km
Coastline: 20 km
-Maritime claims: no data available
Climate: hot summers and cold winters; areas of
high elevation have short, cool summers and long,
severe winters; mild, rainy winters along coast
Terrain: mountains and valleys
Elevation extremes: lowest point: Adriatic Sea 0
m highest point: Maglic 2,386 m
Natural resources: coal, iron ore, bauxite, copper,
lead, zinc, chromite, cobalt, manganese, nickel,
clay, gypsum, salt, sand, timber, hydropower
Land use: arable land: 19.63%
permanent crops: 1.99%
other: 78.38% (2011)
Irrigated land: 30 sq km (2003)
Total renewable water resources: 37.5 cu km
(2011)
Natural hazards: destructive earthquakes -
Environment—current issues: air pollution from
metallurgical plants; sites for disposing of urban
waste are limited; water shortages and destruction
of infrastructure because of the 1992-95 civil strife;
deforestation
Environment—international agreements: party
to: Air Pollution, Biodiversity, Climate Change,
Climate Change-Kyoto Protocol, Desertification,
Hazardous Wastes, Law of the Sea, Marine Life
Conservation, Ozone Layer Protection, Wetlands
signed, but not ratified: none of the selected
agreements Geography—note: within Bosnia and
Herzegovina’s recognized borders, the country
is divided into a joint Bosniak/Croat Federation
(about 51% of the territory) and the Bosnian
Serb-led Republika Srpska or RS (about 49% of
the territory); the region called Herzegovina is
contiguous to Croatia and Montenegro, and tra-
ditionally has been settled by an ethnic Croat
majority in the west and an ethnic Serb majority
in the east
Nationality: noun: Bosnian(s), Herzegovinian(s)
adjective: Bosnian, Herzegovinian
Ethnic groups: Bosniak 48%, Serb 37.1%, Croat
14.3%, other 0.6% (2000)
note; Bosniak has replaced Muslim as an ethnic
term in part to. avoid confusion with the religious
term Muslim—an adherent of Islam
Languages: Bosnian (official), Croatian (offi-
cial), Serbian
Religions: Muslim 40%, Orthodox 31%, Roman
Catholic 15%, other 14%
Population: 3,875,723 (July 2013 est.)
country comparison to the world: 128
Age structure: 0-14 years: 14% (male 279,293/
female 262,552)
15-24 years: 13% (male 260,430/female 243,589)
25-54 years: 46.8% (male 910,266/female 905,184)
55-64 years: 13.2% (male 243,936/female 268,614)
65 years and over: 12.9% (male 194,743/female
307,116) (2013 est)
Medion age: total: 40.4 years
male; 39 years
female: 41.7 years (2013 est.)
Population growth rate: -0.1% (2013 est.)
country comparison to the world: 204
Birth rate: 8.92 births/1,000 population (2013
est.)
country comparison to the world: 210
Death rate: deaths/1,000 population (2013 est.)
country comparison to the world: 56
Net migration rate: -0.37 migrant(s)/1,000 popu-
lation (2013 est.)
country comparison to the world: 130
Urbanization: urban population: 49% of total
population (2010)
rate of urbanization: 1.1% annual rate of change
(2010-15 est.)
Major cities—population: SARAJEVO (capital)
392,000 (2009)
Sex ratio: at birth: 1.07 male(s)/female
0-14 years: 1.07 male(s)/female
15-24 years: 1.07 male(s)/female
25-54 years: 1 male(s)/female
55-64 years: 0.9 male(s)/female
65 years and over: 0.63 male(s)/female
total population: 0.95 male(s)/female (2013
est.)
Maternal mortality rate: 8 deaths/100,000 live
births (2010)
country comparison to the world: 156
Infant mortality rote: total: 5.97 deaths/1,000
live births y
country comparison to the world: 172
male: 6.02 deaths/1,000 live births
female: 5.92 deaths/1,000 live births (2013 est.)
Life expectancy at birth: total population: 76.12
years
country comparison to the world: 86
male: 73.13 years
female: 79.34 years (2013 est.)
Total fertility rate: 1.25 children born/woman
(2013 est.)
country comparison to the world: 218
Health expenditures: | 1.1%of GDP (2010)
country comparison to the world: 19
Physicians density: 1.42 physicians/1,000 popu-
lation (2005)
Hospital bed density: 3.4 beds/1,000 population
(2009)
Drinking water source:
Improved:
urban: 100% of population
rural: 98% of population
total: 99% of population
Unimproved:
urban: 0% of population
91
rural: 2% of population
total: 1% of population (2010 est.)
Sanitation facility access:
Improved:
urban: 99% of population
rural: 92% of population
total: 95% of population
Unimproved:
urban: 1% of population
rural: 8% of population
total: 5% of population (2010 est.)
HIV/AIDS—adult prevalence rate: less than
0.1% (2007 est.)
country comparison to the world: 113
HIV/AIDS—people living with HIV/AIDS: 900
(2007 est.)
country comparison to the world: 146
HIV/AIDS—deaths: 100 (2001 est.)
country comparison to the world: 145
Obesity—adult prevalence rate: 26.5% (2008)
country comparison to the world: 47
Children under the age of 5 years under-
weight: 1.6% (2006)
country comparison to the world: 124
Education expenditures: NA
Literacy: definition: age 15 and over can read
and write
total population: 97.9%
male: 99.4%
female: 96.5% (2010 est.)
School life expectancy (primary to tertiary
education): total: 14 years
male: 13 years
female: 14 years (2009)
Unemployment, youth ages 15-24: total: 57.5%
country comparison to the world: 3
male: 56.8%
female: 60% (2011)','5b51c7b1e21f2c770b7c01497f45542ef842791bc96b33c78de105490250f0b0','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('03a1b3b50256ea7fc19b3f1e103cdbb112fe04df7664a482a501d15bed3df3f2',2025,'BW','Botswana','geography',269,'Location: Southern Africa, north of South Africa
Geographic coordinates: 22 00 S, 24 00 E
Map references: Africa
Area: total: 581,730 sq km
country comparison to the world: 48
land: 566,730 sq km
water: 15,000 sq km
Area—comporative: slightly smaller than Texas
Land boundaries: total: 4,013 km
border countries: Namibia 1,360 km, South
Africa 1,840 km, Zimbabwe 813 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
Climate: semiarid; warm winters and hot summers
Terrain: predominantly flat to gently rolling table-
land; Kalahari Desert in southwest
Elevation extremes: lowest point: junction of
the Limpopo and Shashe Rivers 513 m
highest point: Tsodilo Hills 1,489 m
Natural resources: diamonds, copper, nickel, salt,
soda ash, potash, coal, iron ore, silver
Land use: arable land: 0.45%
permanent crops: 0%
other: 99.55% (2011)
Irrigated land: 14.39 sq km (2003)
Total renewable water resources: 12.24 cu km
(2011)
Freshwater withdrawal (domestic/indus-
trial/agricultura!): total: 0.19 cu km/yr
(42%/19%/39%)
per capita: 107.3 cu m/yr (2005)
Natura! hazards: periodic droughts; seasonal
August winds blow from the west, carrying sand
and dust across the country, which can obscure
visibility
Environment—current issues: overgrazing;
desertification; limited freshwater resources
Environment—international agreements:
party to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Endan-
gered Species, Hazardous Wastes, Law of the Sea,
Ozone Layer Protection, Wetlands
signed, but not ratified: none of the selected
agreements
Geography—note: landlocked; population con-
centrated in eastern part of the country','0b4dfca1dec8e6c3b090fb8173b1dd2c8f5f6434b378fe4793973be69f9f3823','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e9a138da3f16bcd7533901a0d91a5f2a58b4a54ec612da98f2541826414d1287',2025,'BV','Bouvet Island','geography',278,'Location: island in the South Atlantic Ocean,
southwest of the Cape of Good Hope (South Africa)
Geographic coordinates: 54 26 S, 3 24 E
Map references: Antarctic Region
Area: total: 49 sq km
country comparison to the world: 233
land: 49 sq km
water: 0 sq km
Area—comparative: about 0.3 times the size of
Washington, DC
Land boundaries: 0 km
Coastline: 29.6 km
Maritime claims: territorial sea: 4 nm
Climate: antarctic
Terrain: volcanic; coast is mostly inaccessible
Elevation extremes: lowest point: South Atlan-
tic Ocean 0 m
highest point: Olav Peak 935 m
Natural resources: none
Land use: arable land: 0%
permanent crops: 0%
other: 100% (93% ice) (2011)
Natural hazards: NA
Environment—current issues: NA
Geography—note: covered by
declared a nature reserve by Norway','d501760c77a376ae9e7aaba32a7e52aa4885ea7a906bf16c2e8c32c60b7e81a9','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fc3e4d928c195ead6fab16ebcbf0f7b1ffee7fc3b29d010e314c332d5cc4d0b5',2025,'IO','British Indian Ocean Territory','geography',286,'Location: archipelago in the Indian Ocean,
south of India, about halfway between Africa and','b082c2f426dcc5064bc3a05d5272ac2ebe6e92d4d3a300f6789122f9e201d600','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8a15c0f5a2e86a3e93b459e2ac38b5c3ac5887976c6558ac6677835a665da3a3',2025,'ID','Indonesia','geography',287,'Geographic coordinates: 6 00 S, 71 30 E; note—
Diego Garcia 7 20 S, 72 25 E
Map references: Political Map of the World
Area: total: 54,400 sq km
country comparison to the world: 128
land: 60 sq km; Diego Garcia 44 sq km
water: 54,340 sq km
note: includes the entire Chagos Archipelago of
55 islands
Area—comparotive: land area is about 0.3 times
the size of Washington, DC
Land boundaries: 0 km
Coastline: 698 km
Maritime claims: territorial sea: 3 nm
exclusive fishing zone: 200 nm
Climate: tropical marine; hot, humid, moderated
by trade winds Terrain: flat and low (most areas do
not exceed two meters in elevation)
Elevation extremes: lowest point: Indian Ocean
Om
highest point: unnamed location on Diego Garcia
15m
Natural resources: coconuts, fish, sugarcane
Land use: arable land: 0%
permanent crops: 0%
other: 100% (2011)
Natura! hazards: NA
Environment—current issues: NA
Geography—note: archipelago of 55 islands;
Diego Garcia, largest and southernmost island,
occupies strategic location in central Indian
Ocean: island is site of joint US-UK military
facility
Population: no indigenous inhabitants
note: approximately 1,200 former agricultural
workers resident in the Chagos Archipelago, often
referred to as Chagossians or Ilois, were relocated
to Mauritius and the Seychelles in the 1960s
and 1970s; in November 2004, approximately
4,000 UK and US military personnel and civilian
contractors were living on the island of Diego
Garcia
Location: Caribbean, between the Caribbean Sea
and the North Atlantic Ocean, east of Puerto Rico
Geographic coordinates: 18 30 N, 64 30 W
Map references: Central America and the
Caribbean
Area: total: 151 sqkm
country comparison to the world: 220
land: 151 sq km
water: 0 sq km
note: comprised of 16 inhabited and more than 20
uninhabited islands; includes the islands of Tor-
tola, Anegada, Virgin Gorda, Jost van Dyke
104
Area—comparative: about 0.9 times the size of
Washington, DC
Land boundaries: 0 km
Coastline: 80 km
Maritime claims: territorial sea: 3 nm
exclusive fishing zone: 200 nm
Climate: subtropical; humid; temperatures moder-
ated by trade winds Terrain: coral islands relatively
flat; volcanic islands steep, hilly
Elevation extremes: lowest point: Caribbean
Sea 0 m
highest point: Mount Sage 521 m
Natural resources: NEGL
Land use: arable land: 6.67%
permanent crops: 6.67%
other: 86.67% (2011)
Irrigated land: NA
Notural hazards: hurricanes and tropical storms
(July to October)
Environment—current issues: limited natural
freshwater resources except for a few seasonal
streams and springs on Tortola; most of the islands’
water supply comes from wells and rainwater
catchments
Geography—note: strong ties to nearby US Vir-
gin Islands and Puerto Rico
Location: Southeastern Asia, bordering the South
China Sea and Malaysia
Geographic coordinates: 4 30 N, 114 40 E
Map references: Southeast Asia
Area: total: 5,765 sq km
country comparison to the world: 173
land: 5,265 sq km
water: 500 sq km
Area—comparative: slightly smaller than Delaware
Land boundaries: total: 381 km
border countries: Malaysia 381 km
Coastline: 161 km
Maritime claims: territorial sea: 12 nm
exclusive economic zone: 200 nm or to median
line
Climate: tropical; hot, humid, rainy
Terrain: flat coastal plain rises to mountains in
east; hilly low land in west
Elevation extremes: lowest point: South China
Sea 0 m
highest point: Bukit Pagon 1,850 m
Natural resources: petroleum, natural gas, timber
Land use: arable land: 0.52%
permanent crops: 0.87%
other: 98.61% (2011)
Irrigated land: 10 sq km (2003)
Total renewable water resources: 8.5 cu km (2011)
Freshwater withdrawal (domestic/industrial/
agricultural): total: 0.09 cu km/yr (97%/0%/3%)
per capita: 301.6 cu m/yr (2009)
Natural hazards: typhoons, earthquakes, and
severe flooding are rare
Environment—current issues: seasonal smoke/
haze resulting from forest fires in Indonesia
Environment—international agreements: party
to: Biodiversity, Climate Change, Desertification,
Endangered Species, Hazardous Wastes, Law of the
Sea, Ozone Layer Protection, Ship Pollution signed,
but not ratified: none of the selected agreements
Geography—note: close to vital sea lanes
through South China Sea linking Indian and
Pacific Oceans; two parts physically separated by
Malaysia; almost an enclave within Malaysia
Location: Middle East, bordering the Gulf of
Oman, the Persian Gulf, and the Caspian Sea,
between Iraq and Pakistan
Geographic coordinates: 32 00 N, 53 00 E
Map references: Middle East
Area: total: 1,648,195 sq km
country comparison to the world: 18
land: 1,531,595 sq km
water: 116,600 sq km
Area—comparative: slightly smaller than Alaska
Land boundaries: total: 5,440 km
border countries: Afghanistan 936 km, Armenia
35 km, Azerbaijan-proper 432 km, Azerbaijan—
Naxcivan exclave 179 km, Iraq 1,458 km, Pakistan
909 km, Turkey 499 km, Turkmenistan 992 km
Coastline: 2,440 km; note—Iran also borders the
Caspian Sea (740 km)
Maritime claims: territorial sea: 12 nm
contiguous zone: 24 nm
exclusive economic zone: bilateral agreements or
median lines in the Persian Gulf continental shelf:
natural prolongation
Refugees and internally displaced persons:
IDPs: 180,000 (government offensives against
rebels in Aceh; most IDPs in Aceh, Central Kali-
mantan, Central Sulawesi Provinces, and Maluku)
(2011)
illicit drugs: illicit producer of cannabis largely
for domestic use; producer of methamphetamine
and ecstasy
Climate: mostly arid or semiarid, subtropical
along Caspian coast Terrain: rugged, mountainous
rim; high, central basin with deserts, mountains;
small, discontinuous plains along both coasts
Elevation extremes: lowest point: Caspian Sea-
28m
highest point: Kuh-e Damavand 5,671 m
Natural resources: petroleum, natural gas, coal,
chromium, copper, iron ore, lead, manganese, zinc,
sulfur
Land use: arable land: 10.05%
permanent crops: 1.08%
other: 88.86% (2011)
Irrigated land: 87,000 sq km (2009)
Total renewable water resources: 137 cu km
(2011) j
Freshwater withdrawal (domestic/industrial/
agricultural): total: 93.3 cu km/yr (7%/1%/92%)
per capita: 1,306 cu m/yr (2004)
Natural hazards: periodic droughts, floods; dust
storms, sandstorms; earthquakes
Environment—current issues: air pollution,
especially in urban areas, from vehicle emissions,
refinery operations, and industrial effluents; defor-
estation; overgrazing; desertification; oil pollution
in the Persian Gulf; wetland losses from drought;
soil degradation (salination); inadequate supplies
of potable water; water pollution from raw sewage
and industrial waste; urbanization
Environment—international agreements:
party to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Endan-
gered Species, Hazardous Wastes, Marine Dump-
ing, Ozone Layer Protection, Ship Pollution,
Wetlands
signed, but not ratified: Environmental Modifica-
tion, Law of the Sea, Marine Life Conservation
Geography—note: strategic location on the Per-
sian Gulf and Strait of Hormuz, which are vital
maritime pathways for crude oi! transport
Environment—international agreements:
party to: Biodiversity, Climate Change, Cli-
mate Change-Kyoto Protocol, Desertification,
Endangered Species, Hazardous Wastes, Law of
the Sea, Ozone Layer Protection, Ship Pollution
signed, but not ratified: none of the selected
agreements
Geography—note: focal point for Southeast
Asian sea routes
Location: Southeastern Asia, northwest of Aus-
tralia in the Lesser Sunda Islands at the eastern
end of the Indonesian archipelago; note—Timor-
Leste includes the eastern half of the island of
Timor, the Oecussi (Ambeno) region on the
northwest portion of the island of Timor, and the
islands of Pulau Atauro and Pulau Jaco
Geographic coordinates: 8 50 S, 125 55 E
Map references: Southeast Asia
Area: total: 14,874 sq km
country comparison to the world: 160
land: 14,874 sq km
water: 0 sq km
Area—comparative:
Connecticut
slightly larger than
Land boundaries: total: 228 km
border countries: Indonesia 228 km
Coastline: 706 km
Maritime claims: territorial sea: 12 nm
contiguous zone: 24 nm
exclusive fishing zone: 200 nm
Climate: tropical; hot, humid; distinct rainy and
dry seasons
Terrain: mountainous
Elevation extremes: lowest point: Timor Sea,
Savu Sea, and Banda Sea 0 m
highest point: Foho Tatamailau 2,963 m
Natural resources: gold, petroleum, natural gas,
manganese, marble
Land use: arable land: 10.09%
permanent crops: 4.03%
other: 85.88% (2011)
Irrigated land: 346.5 sq km (2003)
Natural hazards: floods and landslides are com-
mon; earthquakes; tsunamis; tropical cyclones
Environment—current issues: widespread use of
slash and burn agriculture has led to deforestation
and soil erosion
Environment—international agreements:
party to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification
signed, but not ratified: none of the selected
agreements
Geography—note: Timor comes from the Malay
word for “East”; the island of Timor is part of the
Malay Archipelago and is the largest and eastern-
most of the Lesser Sunda Islands','732fc888c238ec65585d03520039e280d51850aa9eef49117fa39ca56c526cd4','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4766945a15663648f0232e46c3fea839ac0619b9b1ce875de610f3152e98eda4',2025,'BG','Bulgaria','geography',300,'Location: Southeastern Europe, bordering the
Black Sea, between Romania and Turkey
Geographic coordinates: 43 00 N, 25 00 E
Map references: Europe
Area: total: 110,879 sq km
country comparison to the world: 105
land: 108,489 sq km
water: 2,390 sq km
Area—comparative:
Tennessee
Land boundaries: total: 1,808 km
border countries: Greece 494 km, Macedonia 148
km, Romania 608 km, Serbia 318 krn, Turkey 240 km
Coastline: 354 km
Maritime claims: territorial sea: 12 nm
contiguous zone: 24 nm
exclusive economic zone: 200 nm
Climate: temperate; cold, damp winters; hot, dry
summers Terrain: mostly mountains with lowlands
slightly larger than
in north and southeast
Elevation extremes: lowest point: Black Sea 0 m
highest point: Musala 2,925 m
Natural resources: bauxite, copper, lead, zinc,
coal, timber, arable land
Land use: arable land: 29.28%
permanent crops: 1.44%
other: 69.28% (2011)
irrigated land: 1,046 sq km (2007)
Total renewable water resources: 21.3 cu km
(2011)
Freshwater withdrawal (domestic/industrial/
agricultural): oral: 6.12 cu km/yr (16%/68%/16%)
per capita: 821.8 cu m/yr (2009)
Natural hazards: earthquakes; landslides
Environment—current issues: air pollution from
industrial emissions; rivers polluted from raw sew-
age, heavy metals, detergents; deforestation; forest
damage from air pollution and resulting acid rain;
soil contamination from heavy metals from metal-
lurgical plants and industrial wastes
Environment—international agreements: party
to: Air Pollution, Air Pollution-Nitrogen Oxides,
Air Pollution-Persistent Organic Pollutants, Air
Pollution-Sulfur 85, Air Pollution-Sulfur 94, Air
Pollution-Volatile Organic Compounds, Antarc-
tic-Environmental Protocol, Antarctic-Marine
Living Resources, Antarctic Treaty, Biodiversity,
Climate Change, Climate Change-Kyoto Proto-
col, Desertification, Endangered Species, Envi-
ronmental Modification, Hazardous Wastes, Law
109
of the Sea, Marine Dumping, Ozone Layer Protec-
tion, Ship Pollution, Wetlands
signed, but not ratified: none of the selected
agreements
Geography—note: strategic location near Turk-
ish Straits; controls key land routes from Europe to
Middle East and Asia','f30b3403e344f5319b485e3ca3e864fd24cfb46b56219fbe14888f6223313b0b','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('245a31932def87fa735d9c0a3003166efa9fa586626e03acc72836595cc09019',2025,'BF','Burkina Faso','geography',309,'Location: Western Africa, north of Ghana
Geographic coordinates: 13 00 N, 2 00 W
Map references: Africa
Area: total: 274,200 sq km
country comparison to the world: 75
land: 273,800 sq km
water: 400 sq km
Area—comparative: slightly larger than Colorado
Land boundaries: total: 3,193 km
border countries: Benin 306 km, Cote d''Ivoire
584 km, Ghana 549 km, Mali 1,000 km, Niger 628
km, Togo 126 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
Climate: tropical; warm, dry winters; hot, wet
summers Terrain: mostly flat to dissected, undulat-
ing plains; hills in west and southeast
Elevation extremes: lowest point: Mouhoun
(Black Volta) River 200 m
highest point: Tena Kourou 749 m
Natural resources: manganese, limestone, mar-
ble; small deposits of gold, phosphates, pumice, salt
Land use: arable land: 20.79%
permanent crops: 0.24%
other: 78.98% (2011)
Irrigated land: 250 sq km (2003)
Total renewable water resources: 12.5 cu km
(2011)
Freshwater withdrawal (domestic/industrial/
agricultural): toral:0.72 cu km/yr (46%/3%/51%)
per capita: 54.99 cu m/yr (2005)
Natural hazards: recurring droughts
Environment—current issues: recent droughts
and desertification severely affecting agricultural
activities, population distribution, and the econ-
omy; overgrazing; soil degradation; deforestation
Environment—international agreements:
party to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Endan-
gered Species, Hazardous Wastes, Law of the Sea,
Marine Life Conservation, Ozone Layer Protec-
tion, Wetlands
signed, but not ratified: none of the selected
agreements
Geography—note: landlocked savanna cut by
the three principal rivers of the Black, Red, and
White Voltas
Location: Southeastern Asia, bordering Thailand
Geographic coordinates: 22 00 N, 98 00 E
Map references: Southeast Asia
Area: total: 676,578 sq km
country comparison to the world: 40
land: 653,508 sq km
water: 23,070 sq km
Area—comparative: slightly smaller than Texas
Land boundaries: total: 5,876 km
border countries: Bangladesh 193 km, China
2,185 km, India 1,463 km, Laos 235 km, Thailand
1,800km
>
T
In Monywa, À
Mandalay
Chauk,
Jaunqyy
Nay Pyt Taw
ve a im
Swe
ANDAMAN
ISLANDS
Coastline: 1,930 km’
Maritime claims: territorial sea: 12 nm
contiguous zone: 24 nm
exclusive economic zone: 200 nm
continental shelf: 200 nm or to the edge of the
continental margin Climate: tropical monsoon;
cloudy, rainy, hot, humid summers (southwest
monsoon, June to September); less cloudy, scant
rainfall, mild temperatures, lower humidity during
winter (northeast monsoon, December to April)
Terrain: central low lands ringed by steep, rugged
highlands
Elevation extremes: lowest point: Andaman
Sea 0 m
highest point: Hkakabo Razi 5,881 m
Natural resources: petroleum, timber, tin, anti-
mony, zinc, copper, tungsten, lead, coal, marble,
limestone, precious stones, natural gas, hydropower
Land use: arable land: 15.94%
permanent crops: 2.16%
other: 81.89% (2011)
irrigated land: 21,100 sq km (2004)
Total renewable water resources: 1,168 cu km
(2011)
Freshwater withdrawal (domestic/indus-
triaVagricultural): total: 33.23 cu km/yr
(10%/1%/89%)
per capita: 728.6 cu m/yr (2005)
Natural hazards: destructive earthquakes and
cyclones; flooding and landslides common during
rainy season (June to September); periodic droughts
Environment—current issues: deforestation;
industrial pollution of air, soil, and water; inad-
equate sanitation and water treatment contribute
to disease
Environment—international agreements:
party to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Endan-
gered Species, Law of the Sea, Ozone Layer Protec-
tion, Ship Pollution, Tropical Timber 83, Tropical
Timber 94
signed, but not ratified: none, of the selected
agreements
Geography—note: strategic location near major
Indian Ocean shipping lanes
Nationality: noun: Burmese (singular and plural)
adjective: Burmese
Ethnic groups: Burman 68%, Shan 9%, Karen
7%, Rakhine 4%, Chinese 3%, Indian 2%, Mon
2%, other 5% :
Languages: Burmese (official)
note: minority ethnic groups have their own lan-
guages Religions: Buddhist 89%, Christian 4%
(Baptist 3%, Roman Catholic 1%), Muslim 4%,
animist 1%, other 2%
Population: 55,167,330 (July 2013 est.)
country comparison to the world: 24
note: estimates for this country take into account
the effects of excess mortality due to AIDS; this
can result in lower life expectancy, higher infant
mortality, higher death rates, lower population
growth rates, and changes in the distribution of
population by age and sex than would otherwise
be expected
Age structure: 0-14 years:
7,514,233/female 7,227,893)
15-24 years: 18.6% (male 5,183,653/female
5,060,385)
26.7% (male
BURMA
25-54 years: 42.8% (male 11,724,297/female
11,879,420)
55-64 years: 6.7%
1,963,051)
65 years and over: 5.2% (male 1,244,758/female
1,615,243) (2013 est.)
Median age: total: 27.6 years
male: 27 years
female: 28.2 years (2013 est.)
Population growth rate: 1.05% (2013 est.)
country comparison to the world: 109
Birth rate: 18.89 births/1 000 population (2013 est.)
country comparison to the world: 96
Death rate: 8.05 deaths/1,000 population (2013 est.)
country comparison to the world: 95
Net migration rate: -0.3 migrant(s)/1,000 popula-
tion (2013 est.)
country comparison to the world: 123
Urbanization: urban population: 34% of total
population (2010)
rate of urbanization: 2.9% annual rate of change
(2010-15 est.)
Major cities—population: RANGOON (capi-
tal) 4.259 million; Mandalay 1.009 million; Nay
Pyi Taw 992,000 (2009)
Sex ratio: at birth: 1.06 male(s)/female
0-14 years: 1.04 male(s)/female
15-24 years: 1.02 male(s)/female
25-54 years: 0.99 male(s)/female
55-64 years: 0.9 male(s)/female
65 years and over: 0.77 male(s)/female
total population: 0.99 male(s)/female (2013 est.)
Maternal mortality rate: 200 deaths/100,000 live
births (2010)
country comparison to the world: 52
Infant mortality rate: total: 46.31 deaths/1,000
live births
country comparison to the world: 46
male: 52.91 deaths/1,000 live births ”
female: 39.31 deaths/1,000 live births (2013 est.)
Life expectancy at birth: total population: 65.6
years
country comparison to the world: 170
male: 63.24 years
female: 68.09 years (2013 est.)
Total fertility rate: 2.21 children born/woman
(2013 est.)
country comparison to the world: 102
Health expenditures: 2% of GDP (2010)
country comparison to the world: 190
Physicians density: 0.46 physicians/1,000 popu-
lation (2008)
Hospital bed density: 0.6 beds/1,000 population
(2006)
Drinking water source:
Improved:
urban: 93% of population
rural: 78% of population
total: 83% of population
Unimproved:
urban: 7% of population
rural: 22% of population
total: 17% of population (2010 est.)
Sanitation facility access:
Improved:
urban: 83% of population
rural: 73% of population
total: 76% of population
{male
1,754,397/female
Unimproved:
urban: 17% of population
rural: 27% of population
total: 24% of population (2010 est.)
HIV/AIDS—adult prevalence rate: 0.6% (2009
est.)
country comparison to the world: 62
HIV/AIDS—people living with HIV/AIDS: (2009
est.)
country comparison to the world: 24
HIV/AIDS—deaths: (2009 est.)
country comparison to the world; 17
Major infectious diseases: degree of risk: very
high ;
food or waterborne diseases: bacterial and proto-
zoal diarrhea, hepatitis A, and typhoid fever vec-
torborne diseases: dengue fever and malaria water
contact disease: leptospirosis anim al contact dis-
ease: rabies :
note: highly pathogenic H5N1 avian influenza has
been identified in this country; it poses a negligible
tisk with extremely rare cases possible among US
citizens who have close contact with birds (2009)
Obesity—adult prevalence rate: 4% (2008)
country comparison to the world: 172
Children under the age of 5 years under-
weight: 22.6% (2010)
country comparison to the world: 26
Education expenditures: 0.8% of GDP (2011)
country comparison to the world: 172
Literacy: definition: age 15 and over can read and
write
total population: 89.9%
male: 93.9%
female: 86.4% (2006 est.)
Schoo! life expectancy (primary to tertiary
education): total: 9 years (2007)','e5d3f41c9fb7ec4ad2c0882c370c36b114175589a092fd24e527d500ca6fd188','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('375635ad235c838e22db702451eb4f2d13f72692bb61ba03a640d51f0f4f8527',2025,'BI','Burundi','geography',323,'Location: Central Africa, east of Democratic
Republic of the Congo
Geographic coordinates: 3 30 S, 30 00 E
Map references: Africa
Area: total: 27,830 sq km
country comparison to the world: 147
land: 25,680 sq km
water: 2,150 sq km
Area—comparative:
Maryland
Land boundaries: total: 974 km
border countries: Democratic Republic of the
Congo 233 km, Rwanda 290 km, Tanzania 451 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
Climate: equatorial; high plateau with consider-
able altitude variation (772 m to 2,670 m above
sea level); average annual temperature varies with
altitude from 23 to 17 degrees centigrade but is
generally moderate as the average altitude is about
1,700 m; average annual rainfall is about 150 cm;
two wet seasons (February to May and September
to November) and two dry seasons (June to August
and December to January)
Terrain: hilly and mountainous, dropping to a pla-
teau in east, some plains
Elevation extremes: lowest point: Lake Tang-
anyika 772 m ‘
slightly smaller than
highest point: Heha 2,670 m
Natural resources: nickel, uranium, rare earth
oxides, peat, cobalt, copper, platinum, vanadium,
arable land, hydropower, niobium, tantalum, gold,
tin, tungsten, kaolin, limestone
Land use: arable land: 33.06%
permanent crops: 14.37%
other: 52.57% (2011)
Irrigated land: 214.3 sq km (2003)
Total renewable water resources: 12:54 cu km
(2011)
Freshwater withdrawal (domestic/industrial/
agricultural): total: 0.29 cu km/yr (15%/5%/79%)
per capita: 43.27 cu m/yr (2005)
Natural hazards: flooding; landslides; drought
Environment—current issues: soil erosion as
a result of overgrazing and the expansion of agri-
culture into marginal lands; deforestation (little
forested land remains because of uncontrolled cut-
ting of trees for fuel); habitat loss threatens wildlife
populations
Environment—international agreements:
party to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Endan-
gered Species, Hazardous Wastes, Ozone Layer
Protection, Wetlands
signed, but not ratified: Law of the Sea
Geography—note: landlocked; straddles crest
of the Nile-Congo watershed; the Kagera, which
drains into Lake Victoria, is the most remote head-
stream of the White Nile
Location: Southeastern Asia, bordering the Gulf
of Thailand, between Thailand, Vietnam, and
Laos
Geographic coordinates: 13 00 N, 105 00 E','a04578ff49ffbffcc98526b3ef827131b89f4c3f36b1bf13820535f8aec7b50b','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e54d94bcab324fe686e38f0ce46765f90711ccd5ea193e8ed728e46e9786206e',2025,'KH','Cambodia','geography',331,'Map references: Southeast Asia
Area: total: 181,035 sq km
country comparison to the world: 90 `
land: 176,515 sq km
water: 4,520 sq km
Area—comparative:
Oklahoma
Land boundaries: total: 2,572 km
border countries: Laos 541 km, Thailand 803 km,
Vietnam 1,228 km
Coastline: 443 km
Maritime claims: territorial sea: 12 nm
contiguous zone: 24 nm
exclusive economic zone: 200 nm
continental shelf: 200 nme
slightly smaller than
Climate: tropical; rainy, monsoon season (May to
November); dry season (December to April); little
seasonal temperature variation
Terrain: mostly low, flat plains; mountains in
southwest and north ''
Elevation extremes: lowest point: Gulf of Thai-
land 0 m
highest point: Phnum Aoral 1,810 m
Natural resources: oil and gas, timber, gem-
stones, iron ore, manganese, phosphates, hydro-
power potential R
Land use: arable land: 22.09%
permanent crops: 0.86%
other: 77.05% (2011)
Irrigated land: 3,536 sq km (2006)
Total renewable water resources: 476.1 cu km
(2011)
Freshwater withdrawal (domestic/industrial/
agricultural): total: 2.18 cu km/yr (4%/2%/94%)
per capita: 159.8 cu m/yr (2006)
Natural hazards: monsoonal rains (June to:
November); flooding; occasional droughts
Environment—current issues: illegal logging
activities throughout the country and strip mining
for gems in the western region along the border
with Thailand have resulted in habitat loss and
declining biodiversity (in particular, destruction of
mangrove swamps threatens natural fisheries); soil
erosion; in rural areas, most of the population does
not have access to potable water; declining fish
stocks because of illegal fishing and overfishing
Environment—international agreements:
party to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Endan-
gered Species, Hazardous Wastes, Marine Life
Conservation, Ozone Layer Protection, Ship Pol-
lution, Tropical Timber 94, Wetlands, Whaling
signed, but not ratified: Law of the Sea
Geography—note: a land of paddies and forests
dominated by the Mekong River and Tonle Sap
(Southeast Asia’s largest freshwater lake)','2aee2c800c4f7df1729973c7c9857728bb0b0ed1b12b635e6eb31afcadf78cfa','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('46b6a8c497cc5a00d7ad1ccdb436d757c3fdec4bc33661174088d9c2d1b7c834',2025,'CA','Canada','geography',357,'Location: Western Africa, group of islands in the
North Atlantic Ocean, west of Senegal
Geographic coordinates: 16 00 N, 24 00 W
Map references: Africa
Area: total: 4,033 sq km
country comparison to the world: 176
land: 4,033 sq km
water: 0 sq km
Area—comporative: slightly larger than Rhode
Island
Land boundaries: 0 km
Coastline: 965 km
Maritime claims: measured from claimed archi-
pelagic baselines territorial sea: 12 nm
contiguous zone: 24 nm
exclusive economic zone: 200 nm
Climate: temperate; warm, dry summer; precipita-
tion meager and erratic
Terrain: steep, rugged, rocky, volcanic
Elevation extremes: lowest point: Atlantic
Ocean 0 m
highest point: Mt. Fogo 2,829 m (a volcano on
Fogo Island)
Natural resources: salt, basalt rock, limestone,
kaolin, fish, clay, gypsum
Land use: arable land: 11.66%
136
permanent crops: 0.74%
other: 87.59% (2011)
Irrigated land: 34.76 sq km (2004)
Total renewabie water resources: 0.3 cu km
(2011)
Freshwater withdrawal (domestic/industriai/
agricultural): total: 0.02 cu km/yr (6%/1%/93%)
per capita: 48.57 cu m/yr (2004)
Natural hazards: prolonged droughts; seasonal
harmattan wind produces obscuring dust; volcani-
cally and seismically active
volcanism: Fogo (elev. 2,829 m), which last erupted
in 1995, is Cape Verde’s only active volcano
Environment—current issues:
deforestation due to demand for wood used as
fuel; water shortages; desertification; environ-
mental damage has threatened several species of
birds and reptiles; illegal beach sand extraction;
overfishing
Environment—international agreements: party
to: Biodiversity, Climate Change, Climate Change-
Kyoto Protocol, Desertification, Endangered Spe-
cies, Environmental Modification, Hazardous
Wastes, Law of the Sea, Marine Dumping, Ozone
Layer Protection, Ship Pollution, Wetlands
signed, but not ratified: none of the selected
agreements
Geography—note: strategic location 500 km
from west coast of Africa near major north-south
sea routes; important communications station;
soil erosion;
important sea and air refueling site','70349192364580e5ed798c005eeb3408e06c3575e5fb65b7c3d4afdd6cc3e3f6','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b26820eb5e49175c1606476ac9130fe8242b700ace2d3640bbf3ac43122b5052',2025,'KY','Cayman Islands','geography',360,'Location: Caribbean, three-island group (Grand
Cayman, Cayman Brac, Little Cayman) in Car-
ibbean Sea, 240 km south of Cuba and 268 km
northwest of Jamaica
Geographic coordinates: 19 30 N, 80 30 W
Map references: Central America and the
Caribbean
Area: total: 264 sq km
country comparison to the world: 211
land: 264 sq km
water: 0 sq km
Area—comparative: 1.5 times the size ‘of Wash-
ington, DC
Land boundaries: 0 km
Coastline: 160 km
Maritime claims: territorial sea: 12 nm
exclusive fishing zone: 200 nm
Climate: cropical marine; warm, rainy summers
(May to October) and cool, relatively dry winters
(November to April)
Terrain: low-lying limestone base surrounded by
coral reefs
Elevation extremes: lowest point: Caribbean
Sea 0m
highest point: The Bluff on Cayman Brac 43 m
Natural resources: fish, climate and beaches that
foster tourism
Land use: arable land: 0.83%
permanent crops: 2.08%
other: 97.08% (2011)
Irrigated land: NA
Natural hazards: hurricanes (July to November)
Environment—current issues: no natural fresh-
water resources; drinking water supplies must be
met by rainwater catchments
Geography—nofe: important location between
Cuba and Central America','34b0d8a0ce713b274bd62782d396a9f3b15e9cf78eed0a36f84b7b505e2214b2','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('263a8a2f55b597f6e334fd110acbddda0964db145ead16b26001f8c9f0f07583',2025,'CF','Central African Republic','geography',370,'Location: Central Africa, north of Democratic
Republic of the Congo
Geographic coordinates: 7 00 N, 21 00 E
Map references: Africa
Area: total: 622,984 sq km
country comparison to the world: 45
land: 622,984 sq km
water: 0 sq km
Area—comporative: slightly smaller than Texas
Land boundaries: total: 5,203 km
border countries: Cameroon 797 km, Chad 1,197
km, Democratic Republic of the Congo 1,577 km,
Republic of the Congo 467 km, South Sudan 990
km, Sudan 175 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
Climate: tropical; hot, dry winters; mild to hot,
wet summers
Terrain: vast, flat to rolling, monotonous plateau;
scattered hills in northeast and southwest
Elevation extremes: lowest point: Oubangui
River 335 m
highest point: Mont Ngaoui 1,420 m
Natural resources: diamonds, uranium, timber,
gold, oil, hydropower
Land use: arable land: 2.89%
permanent crops: 0.13%
other: 96.98% (2011)
Irrigated land: 1.35 sq km (2003)
Total renewable water resources: 144.4 cu km
(2011)
Freshwater withdrawal (domestic/industrial/
agricultural): total: 0.07 cu km/yr (83%/17%/1%)
per
capita: 17.42 cu m/yr (2005)
Notural hazards: hot, dry, dusty harmattan winds
affect northern areas; floods are common
Environment—current issues; tap water is not
potable; poaching has diminished the country’s
reputation as one of the last great wildlife refuges;
desertification; deforestation
Environment—international agreements:
party to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Endan-
gered Species, Hazardous Wastes, Ozone Layer
Protection, Tropical Timber 94, Wetlands
signed, but not ratified: Law of the Sea
Geography—note: landlocked; almost the precise
center of Africa
Location: Central Africa, south of Libya
Geographic coordinates: 15 00 N, 19 00 E
Map references: Africa
Area: total: 1.284 million sq km
country comparison to the world: 21
land: 1,259,200 sq km
water: 24,800 sq km
Area—comparative: slightly more than three
times the size of California
Land boundaries: total: 5,968 km
5 S A
ma} 4N DJAMENA
Ha
>
CENTRAL AFRICAN
_ REPUBLIC
væ
mien i.
border countries: Cameroon 1,094 km, Central
African Republic 1,197 km, Libya 1,055 km, Niger
1,175 km, Nigeria 87 km, Sudan 1,360 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
Climate: tropical in south, desert in north
Terrain: broad, arid plains in center, desert in
north, mountains in northwest, low lands in
south
Elevation extremes: lowest point: Djourab 160 m
highest point: Emi Koussi 3,415 m
Natural resources: petroleum, uranium, natron,
kaolin, fish (Lake Chad), gold, limestone, sand
and gravel, salt
Land use: arable land: 3.82%
permanent crops: 0.02%
other: 96.16% (2011)
Irrigated land: 302.7 sq km (2003)
Total renewable water resources: 43 cu km
(2011)
Freshwater withdrawal (domestic/industriaV/agri-
cultural): total: 0.88 cu km/yr (12%/12%/76%)
per capita: 84.81 cu m/yr (2005)
Natural hazards: hot, dry, dusty harmattan winds
occur in north; periodic droughts; locust plagues
Environment—current issues: inadequate sup-
pliés of potable water; improper waste disposal in
rural areas contributes to soil and water pollution;
desertification
Environment—international agreements:
party to: Biodiversity, Climate Change, Deserti-
fication, Endangered Species, Hazardous Wastes,
Ozone Layer Protection, Wetlands
signed, but not ratified: Law of the Sea, Marine
Dumping ’ a','3f9fae689cd9f52b1623f11ebe12ac454e7749aa9dd901c399de9c5979dcaf5f','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('32eec1171755082cf62a8b195c2acdc1b33271fdee9174b368dc6234b56c36c6',2025,'TD','Chad','geography',378,'Geography—note: landlocked; Lake Chad is the
Most significant water body in the Sahel','806d424d04786e25c41fa5151068d8f092ced1c81f879a056eaff294651ef1b9','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ff01526ddcad40ac13fcfd22dc6eaf835de10765693817731e894313cf9fab1c',2025,'CN','China','geography',392,'Location: Eastern Asia, bordering the East China
Sea, Korea Bay, Yellow Sea, and South China Sea,
between North Korea and Vietnam
Geographic coordinates: 35 00 N, 105 00 E
Map references: Asia
Area: total: 9,596,961 sq km
country comparison to the world; 4
land: 9,569,901 sq km
water: 27,060 sq km
Area—compoarative: slightly smaller than the US
Land boundaries: total: 22,117 km
border countries: Afghanistan 76 km, Bhutan 470
km, Burma 2,185 km, India 3,380 km, Kazakhstan
1,533 km, North Korea 1,416 km, Kyrgyzstan 858
152
km, Laos 423 km, Mongolia 4,677 km, Nepal
1,236 km, Pakistan 523 km, Russia (northeast)
3,605 km, Russia (northwest) 40 km, Tajikistan
414 km, Vietnam 1,281 km re gional borders:
Hong Kong 30 km, Macau 0.34 km
Coastline: 14,500 km
Maritime claims: territorialsea: 12 nm
contiguous zone: 24 nm exclusive economic zone:
200 nm
continental shelf: 200 nm or to the edge of the
continental margin
Climate: extremely diverse; tropical in south to
subarctic in north
Terrain: mostly mountains, high plateaus, deserts
in west; plains, deltas, and hills in east
Elevation extremes: lowest þoint: Turpan Pendi-
154 m
highest point: Mount Everest 8,850 m (highest
poiht in Asia)
Natural resources: coal, iron ore, petroleum,
natural gas, mercury, tin, tungsten, antimony,
manganese, molybdenum, vanadium, magnetite,
aluminum, lead, zinc, rare earth elements, ura-
nium, hydropower potential (world’s largest)
Land use: arable land: 11.62%
permanent crops: 1.53%
other: 86.84% (2011)
Irrigated land: 629,380 sq km (2006)
Total renewable water resources: 2,840 cu km
(2011)
Freshwater withdrawal (domestic/indus-
triaV/agricultural): total: 554.1 cu km/yr
(12%/23%/65%)
per capita: 409.9 cu m/yr (2005)
Natural hazards: frequent typhoons (about five
per year along southern and eastern coasts); dam-
aging floods; tsunamis; earthquakes; droughts; land
subsidence °
volcanism: China contains some historically
active volcanoes including Changbaishan (also
known as Baitoushan, Baegdu, or P’aektu-san),
Hainan Dao, and Kunlun although most have
been relatively inactive in recent centuries
Environment—current Issues: air pollution
(greenhouse gases, sulfur dioxide particulates)
from reliance on coal produces acid rain; water
shortages, particularly in the north; water pollu-
tion from untreated wastes; deforestation; esti-
mated loss of one-fifth of agricultural land since
1949 to soil erosion and economic development;
desertification; trade in endangered species
Environment—international agreements: party
to: Antarctic-Environmental Protocol, Antarctic
Treaty, Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Endan-
gered Species, Environmental Modification, Haz-
ardous Wastes, Law of the Sea, Marine Dumping,
Ozone Layer Protection, Ship Pollution, Tropical
Timber 83, Tropical Timber 94, Wetlands, Whaling
signed, but not ratified: none of the selected
agreements
Geography—note: world’s fourth largest country
(after Russia, Canada, and US); Mount Everest on
the border with Nepal is the world’s tallest peak
Location: Central Europe, northwest of Romania
Geographic coordinates: 47 00 N, 20 00 E
Mop references: Europe
Area: total:93,028 sq km
country comparison to the world: 110
land: 89,608 sq km
` water: 3,420 sq km
Area—comparative: slightly smaller than
Indiana
Land boundaries: total: 2,185 km
border countries: Austria 366 km, Croatia 329
km, Romania 443 km, Serbia 166 km, Slovakia
676 km, Slovenia 102 km, Ukraine 103 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
Climate: temperate; cold, cloudy, humid winters;
warm summers mostly flat to rolling plains; hills
and low mountains on the Slovakian border
Elevation extremes: lowest point: Tisza River
78 m
highest point: Kekes 1,014 m
Natural resources: bauxite, coal, natural gas, fer-
tile soils, arable land
Land use: arable land: 47.24%
permanent crops: 1.97%
other: 50.79% (2011)
Irrigated land: 1,409 sq km (2007)
Total renewable water resources: 104 cu km
(2011)
Freshwater withdrawal (domestic/industrial/
agricultural): total:5.58 cu km/yr (12%/83%/5%)
per capita: 555.9 cu m/yr (2007)
Environment—current issues: the upgrading of
Hungary''s standards in waste management, energy
efficiency, and air, soil, and water pollution to meet
‘BU requirements will require large investments
Environment—international agreements:
party to: Air Pollution, Air Pollution-Nicrogen
Oxides, Air Pollution-Persistent Organic Pollut-
ants, Air Pollution-Sulfur 85, Air Pollution-Sulfur
94, Air Pollution-Volatile Organic Compounds,
Antarctic Treaty, Biodiversity, Climate Change,
Climate Change-Kyoto Protocol, Desertification,
Endangered Species, Environmental Modifica-
tion, Hazardous Wastes, Law of the Sea, Marine
Dumping, Ozone Layer Protection, Ship Pollution,
Wetlands, Whaling
signed, but not ratified: none of the selected
agreements
Geography—note: landlocked; strategic location
astride main land routes between Western Europe
and Balkan Peninsula as well as between Ukraine
and Mediterranean basin; the north-south flowing
Duna (Danube) and Tisza Rivers divide the coun-
try into three large regions
Location: Southeastern Europe, north of Greece
Geographic coordinates: 41 50 N, 22 00 E
Map references: Europe
Area: total: 25,713 sq km
country comparison to the world: 150
land: 25,433 sq km
water: 280 sq km
Area—comparative: slightly larger chan Vermont
Lond boundaries: total: 766 km
border countries: Albania 151 km, Bulgaria 148
km, Greece 246 km, Kosovo 159 km, Serbia 62 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
Climate: warm, dry summers and autumns; rela-
tively cold winters with heavy snowfall
444
Terrain: mountainous territory covered with deep
basins and valleys; three large lakes, each divided
by a frontier line; country bisected by the Vardar
River
Elevation extremes: lowest point: Vardar River 50 m
highest point: Golem Korab (Maja e Korabit)
2,764 m
Natural resources: low-grade iron ore, copper,
lead, zinc, chromite, manganese, nickel, tungsten,
gold, silver, asbestos, gypsum, timber, arable land
tand use: arable land: 16.1%
permanent crops: 1.36% |
other: 82.54% (2011)
Irrigated land: 1,278 sq km (2004)
Total renewable water resources: 6.4 cu km
(2011)
Freshwater withdrawal (domestic/indus-
triaVagricuitural): total: 1.03 cu km/yr
(21%/67%/12%)
per capita: 502 cu m/yr (2007)
Natural hazards: high seismic risks
Environmerit—current issues: air pollution from
metallurgical plants
Environment—international agreements:
party to: Air Pollution, Biodiversity, Climate
Change, Climate Change-Kyoto Protocol, Deser-
tification, Endangered Species, Hazardous Wastes,
Law of the Sea, Ozone Layer Protection, Wetlands
signed, but not ratified: none of the selected
agreements
Geography—note: landlocked; major transporta-
tion corridor from Western and Central Europe
to Aegean Sea and Southern Europe to Western
Europe','0c95e9e3235600428fabd080d1a38435a96bc88d371373cf4e578ebc4b38cbea','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d0a9fecfa9e663f3c9c85ca8aa31d301d41aec4ecfcb8c64c4c8a4bb05844bd2',2025,'CX','Christmas Island','geography',401,'Location: Southeastern Asia, island in the Indian
Ocean, south of Indonesia
Geographic coordinates: 10 30 S, 105 40 E
Map references: Oceania
Area: total: 135 sq km
country comparison to the world: 222
land: 135 sq km
water: 0 sq km
Areao—comparative: about three-quarters the size
of Washington, DC
Land boundaries: 0 km
Coastline: 138.9 km
Maritime claims: territorial sea: 12 nm
contiguous zone: 12 nm
exclusive fishing zone: 200 nm
Climate: tropical with a wet season (December to
April) and dry season; heat and humidity moder-
ated by trade winds
Terrain: steep cliffs along coast rise abruptly to
central plateau
Elevation extremes: lowest point: Indian Ocean
Om
highest point: Murray Hill 361 m
Natural resources: phosphate, beaches
Land use: arable land: 0%
permanent crops: 0%
other: 100% (mainly tropical rainforest; 63% of
the island is a national park) (2011)
Irrigated land: NA
Natural hazards: the narrow fringing reef sur-
rounding the island can be a maritime hazard
Environment—current Issues: loss of rainforest;
impact of phosphate mining
Geography—note: located along major sea lanes
of Indian Ocean','c864c960013dd6af6d35210d22a1ed8f4276035da90431f0edbc063feb41d5e8','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bd361a3b3cccf9acffe7a72fc1a1f701edd25a8da7923557e5f0eca2f4699e22',2025,'CC','Cocos (Keeling) Islands','geography',408,'Location: Southeastern Asia, group of islands in
the Indian Ocean, southwest of Indonesia, about
halfw ay between Australia and Sri Lanka
Geographic coordinates: 12 30 S, 96 50 E
Map references: Oceania
Area: total: 14 sq km
country comparison to the world: 241
land: 14 sq km water: 0 sq km
note: includes the two main islands of West Island
and Home Island
Area—comparative: about 24 times the size of
The Mall in Washington, DC
Land boundaries: 0 km
Coastline: 26 km
Maritime claims: territorial sea: 12 nm
exclusive fishing zone: 200 nm
Climate: tropical with high humidity, moder-
ated by the southeast trade winds for about nine
months of the year
Terrain: flat, low-lying coral atolls
Elevation extremes: lowest point: Indian Ocean
Om
highest point: unnamed location 5 m
Natural resources: fish
Land use: arable land: 0%
permanent crops: 0%
other: 100% (2011)
Irrigated land: NA
Natura! hazards: cyclone season is October to
April
Environment—current issues:
resources are limited to rainwater accumulations
in natural underground reservoirs
Geography—tote: islands are thickly covered
with coconut palms and other vegetation; site of
a World War | naval battle in November 1914
between the Australian light cruiser HMAS Syd-
ney and the German raider SMS Emden; after
being heavily damaged in the engagement, the
Emden was beached by her captain on North
Keeling Island
Nationality: noun: Cocos Islander(s)
adjective: Cocos Islander
Ethnic groups: Europeans, Cocos Malays
Languages: Malay (Cocos dialect), English
Religions: Sunni Muslim 80%, other 20% (2002
est.)
Population: 596 (July 2010 est.)
country comparison to the world: 238
Population growth rate: 0% (2013 est.)
freshwater
country comparison to the world: 195
Birth rate: -9 births/1,000 population
country comparison to the world: 224
Death rate: -9 deaths/1,000 population
country comparison to the world: 225
Net migration rate: -999 migrant(s)/1,000 popu-
lation''NA (2013 est.)
country comparison to the world: 222
Infant mortality rate: total: NA
male: NA
female: NA
Life expectancy at birth: total population: NA
male: NA
female:NA
Total fertitity rate: NA
HiV/AIDS—adult prevalence rate: NA
HIV/AIDS—people living with HIV/AIDS: NA
HIV/AIDS—deaths: NA
Literacy: NA','2879fa67b320e7e0aa0c8de90da3fb08838630604e191b422669f180061402c4','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f07522fdbf72c7b00749183af0b6d41ca40444f42ebbfc24e37d595d9d09be4b',2025,'CO','Colombia','geography',414,'Location: Northern South America, bordering the
Caribbean Sea, between Panama and Venezuela,
and bordering the North Pacific Ocean, between
Ecuador and Panama
160
Geographic coordinates: 4 00 N, 72 00 W
Map references: South America
Area: total: 1,138,910 sq km
country comparison to the world: 26
land: 1,038,700 sq km
water: 100,210 sq km
note: includes Isla de Malpelo, Roncador Cay, and
Serrana Bank
Area—comparative: slightly less than twice the
size of Texas
Land boundaries: total: 6,309 km
border countries: Brazil 1,644 km, Ecuador 590
km, Panama 225 km, Peru 1,800 km, Venezuela
2,050 km
Coastline:
3,208 km (Caribbean Sea 1,760 km, North
Pacific Ocean 1,448 km)
Maritime claims: territorial sea: 12 nm
exclusive economic zone: 200 nm
continental shelf: 200 m depth or to the depth of
exploitation
Climate: tropical along coast and eastern plains;
cooler in highlands
Terrain: flat coastal lowlands, central highlands,
high Andes Mountains, eastern lowland plains
Elevation extremes: lowest point: Pacific Ocean
Om
highest point: Pico Cristobal Colon 5,775 m
note: nearby Pico Simon Bolivar also has the same
elevation
Natural resources: petroleum, natural gas,
coal, iron ore, nickel, gold, copper, emeralds,
hydropower
Land use: arable land: 1.84%
permanent crops: 1.66%
other: 96.5% (2011)
Irrigated land: 10,870 sq km (2011)
Total renewable water resources: 2,132 cu km
(2011)
Freshwater withdrawal (domestic/indus-
trialfagricultural): total: 12.65 cu km/yr
(55%/4%/41%)
per capita: 308 cu m/yr (2010)
Natural hazards: highlands subject to volcanic
eruptions; occasional earthquakes; periodic
droughts volcanism: Galeras (elev. 4,276 m) is
one of Colombia''s most active volcanoes, having
erupted in 2009 and 2010 causing major evacua-
tions; it has been deemed a “Decade Volcano” by
the International Association of Volcanology and
Chemistry of the Earth’s Interior, worthy of study
due to its explosive history and close proximity to
human populations; Nevado del Ruiz (elev. 5,321
m), 129 km (80 mi) west of Bogota, erupted in
1985 producing lahars that killed 23,000 people;
the volcano last erupted in 1991; additionally,
after 500 years of dormancy, Nevado del Huila
reaw akened in 2007 and has experienced frequent
eruptions since then; other historically active vol-
canoes include Cumbal, Dona Juana, Nevado del
Tolima, and Purace
Environment—current issues: deforestation;
soil and water quality damage from overuse of
pesticides; air pollution, especially in Bogota, from
vehicle emissions
Environment—international agreements;
party to: Antarctic Treaty, Biodiversity, Climate
Change, Climate Change-Kyoto Protocol, Deser-
tification, Endangered Species, Hazardous Wastes,
Marine Life Conservation, Ozone Layer Protec-
tion, Ship Pollution, Tropical Timber 83, Tropical
Timber 94, Wetlands
signed, but not ratified: Law of the Sea
Geography—note: only South American country
with coastlines on both the North Pacific Ocean
and Caribbean Sea
Location: Northern South America, bordering
the Caribbean Sea and the North Atlantic Ocean,
between Colombia and Guyana
Geographic coordinates: 8 00 N, 66 00 W
Map references: South America
Area: total: 912,050 sq km
country comparison to the world: 33
land: 882,050 sq km
* water: 30,000 sq km
Area—comparative: slightly more than twice the
size of California
Land boundaries: total: 4,993 km
border countries: Brazil 2,200 km, Colombia
2,050 km, Guyana 743 km
Coastline: 2,800 km
Maritime claims: territorial sea; 12 nm
contiguous zone: 15 nm
exclusive economic zone: 200 nm
continental shelf: 200 m depth of to the depth of
exploitation
Climate: tropical; hot, humid; more moderate in
highlands
Terrain: Andes Mountains and Maracaibo Low-
lands in northwest; central plains (Ilanos); Guiana
Highlands in southeast . _.:*
VENEZUELA
Elevation extremes: lowest point: Caribbean
Sea Om
highest point: Pico Bolivar 5,007 m
Natural resources: petroleum, natural gas, iron
ore, gold, bauxite, other minerals, hydropower,
diamonds
Land use: arable land: 2.85%
permanent crops: 0.71%
other: 96.44% (2011)
Irrigated tand: 10,550 sq km (2008)
Total renewable water resources: 1,233 cu km
(2011)
Freshwater withdrawal (domestic/industrial/
agricultural): total: 9.06 cu km/yr (23%/4%/74%)
per capita: 358.6 cu m/yr (2008)
Natural hazards: subject to floods, rockslides,
mudslides; periodic droughts
Environment—current issues: sewage pollution
of Lago de Valencia; oil and urban pollution of
Lago de Maracaibo; deforestation; soil degrada-’
tion; urban and industrial pollution, especially
along the Caribbean coast; threat to the rainforest
ecosystem from irresponsible mining operations
Environment—international agreements: party
to: Antarctic Treaty, Biodiversity, Climate Change,
Climate Change-Kyoto Protocol, Desertification,
Endangered Species, Hazardous Wastes, Marine
Life Conservation, Ozone Layer Protection, Ship
Pollution, Tropical Timber 83, Tropical Timber
94, Wetlands signed but not ratified:: none of the
selected agreements
Geography—note: on major sea and air routes
linking North and South America; Angel Falls
in the Guiana Highlands is the world’s highest
waterfall
Location: Southeastern Asia, bordering the Gulf
of Thailand, Gulf of Tonkin, and South China
Sea, as well as China, Laos, and Cambodia
Geographic coordinates; 16 10 N, 107 50 E
Map references: Southeast Asia
Area: total: 331,210 sq km
country comparison to the world: 66
„land: 310,070 sq km
water: 21,140 sq km
Areo—comparative: slightly larger than New','58489c569267a4e20406983f7ac8996944749214b43dc6d87d9803be59da0051','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b9e40be9797a333ccfb34356b9b15cd21da76f7bbd32cf147661ca7e764d0b96',2025,'KM','Comoros','geography',424,'Location: Southern Africa, group of islands at
the northern mouth of the Mozambique Chan-
nel, about two-thirds of the way between northern
Madagascar and northern Mozambique
Geographic coordinates: 12 10S, 44 15E
Map references: Africa
Area: total: 2,235 sq km
country comparison to the world: 180
land: 2,235 sq km water: 0 sq km
Area—compoarative: slightly more than 12 times
the size of Washington, DC
Land boundaries: 0 km
Coastline: 340 km
Maritime claims: territorial sea: 12 nm
exclusive economic zone: 200 nm
Climate: tropical marine; rainy season (November
to May)
Terrain: volcanic islands, interiors vary from steep
mountains to low hills
Elevation extremes: lowest point: Indian Ocean
Om
highest point: Karthala 2,360 m
Natural resources: NEGL
Land use: arable land: 44.06%
permanent crops: 31.17%
other: 24.77% (2011)
Irrigated land: 1.3 sq km NA (2003)
Total renewable water resources: 1.2 cu km
(2011)
Freshwater withdrawal (domestic/industrial/
agricultural): total: 0.01 cu km/yr (48%/5%/47%)
per capita: 16.86 cu m/yr (1999)
Natural hazards: cyclones possible during rainy
season (December to April); volcanic activity on
Grand Comore volcanism: Karthala (elev. 2,361
m) on Grand Comore Island last erupted in 2007;
a 2005 eruption forced thousands of people to be
evacuated and produced a large ash cloud
Environment—current issues: soil degradation
and erosion results from crop cultivation on slopes
without proper terracing; deforestation
Environment—international agreements: party
to: Biodiversity, Climate Change, Climate Change-
Kyoto Protocol, Desertification, Endangered Spe-
cies, Hazardous Wastes, Law of the Sea, Ozone
Layer Protection, Ship Pollution, Wetlands
signed, but not ratified: none of the selected
agreements
Geography—note: important location at north-
ern end of Mozambique Channel
Location: Central Africa, northeast of Angola
Geographic coordinates: 0 00 N, 25 00 E
Map references: Africa
Area: total: 2,344,858 sq km
country comparison to the world: 11 R
land: 2,267,048 sq km |
water: 77,810 sq km
Area—comparative: slightly less than one-fourth
the size of the US
Land boundaries: total: 10,730 km
border countries: Angola 2,511 km (of which 225
km is the boundary of Angola''s discontiguous Cab-
inda Province), Burundi 233 km, Central African
Republic 1,577 km, Republic of the Congo 2,410
km, Rwanda 217 km, South Sudan 628 km, Tan-
zania 459 km, Uganda 765 km, Zambia 1,930 km ,
Coastline: 37 km
Maritime claims: territorial sea:12 nm
exclusive economic zone: boundaries
neighbors
with
Climate: tropical; hot and humid in equatorial
river basin; cooler and drier in southern highlands;
cooler and wetter in eastern highlands; north of
Equator—wet season (April to October), dry sea-
son (December to February); south of Equator—
wet season (November to March), dry season
(April to October)
Terrain: vast central basin is a low-lying plateau;
mountains in east
Elevation extremes: lowest point: Atlantic
Ocean 0m
highest point: Pic Marguerite on Mont Ngaliema
(Mount Stanley) 5,110 m
167
Natural resources: cobalt, copper, niobium, tan-
talum, petroleum, industrial and gem diamonds,
gold, silver, zinc, manganese, tin, uranium, coal,
hydropower, timber
Land use: arable land: 2.9%
permanent crops: 0.32%
other: 96.78% (2011)
Irrigated land: 105 sq km (2003)
Total renewable water resources: 283 cu km
(2011)
Freshwater withdrawal (domestic/indus-
trial/agricultural): total: 0.68` cu km/yr
(68%/21%/11%)
per capita; 11.25 cu m/yr (2005)
Natural hazards: periodic droughts in south;
Congo River floods (seasonal); active volcanoes in
the east along the Great Rift Valley
volcanism: Nyiragongo (elev. 3,470 m), which
erupted in 2002 and is experiencing ongoing
activity, poses a major threat to the city of Goma,
home to a quarter million people; the volcano pro-
duces unusually fast-moving lava, known to travel
up to 100 km /hr; Nyiragongo has been deemed
a “Decade Volcano” by the International Associa-
tion of Volcanology and Chemistry of the Earth’s
Interior, worthy of study due to its explosive his-
tory and close proximity to human populations;
its neighbor, Nyamuragira, which erupted in 2010,
is Africa’s most active volcano; Visoke is the only
other historically active volcano
Environment—current issues: ` poaching
threatens wildlife populations; water pollution;
deforestation; refugees responsible for significant
deforestation, soil erosion, and wildlife poaching;
mining of minerals (coltan—a mineral used in
creating capacitors, diamonds, and gold) causing
environmental damage
Environment—international agreements:
party to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Endan-
gered Speties, Hazardous Wastes, Law of the Sea,
Marine Dumping, Ozone Layer Protection, Tropi-
cal Timber 83, Tropical Timber 94, Wetlands
signed, but not ratified: Environmental
Modification
Geography—note: straddles equator; has narrow
strip of land that controls the lower Congo River
and is only outlet to South Atlantic Ocean; dense
tropical rain forest in central river basin and east-
ern highlands; second largest country in Africa
(after Algeria)
ir
i < aa:
anod By CU Sass
PRAMEN
OCEAN
Natural hazards: periodic cyclones; drought; and
locust infestation
volcanism: Madagascar’s volcanoes have not
erupted in historical times
Environment—current Issues: soil erosion
results from deforestation and overgrazing; deserti-
fication; surface water contaminated with raw sew-
age and other organic wastes; several endangered
species of flora and fauna unique to.the island
Environment—internationat agreements:
party to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Endan-
gered Species, Hazardous Wastes, Law of the Sea,
Marine Life Conservation, Ozone Layer Protec-
tion, Ship Pollution, Wetlands
signed, but not ratified: none of the selected
agreements
Geography—note: world’s fourth-largest island;
strategic location along Mozambique Channel','b97c38bb9aca3951cdf6128d8cab46a54bfccc2d6a4abee2854feaaad12503fd','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('570badf379d8d4c125b4ed1ebf48bf70c950ad67cd505dbdfb9b2976a1ac635e',2025,'CK','Cook Islands','geography',440,'Location: Oceania, group of islands in the South
Pacific Ocean, about half way betw een Haw aii
and New Zealand a
Geographic coordinates: 21 14 S, 159 46 W
Map references: Oceania *
Area: total: 236 sq km
country comparison to the world: 215
land: 236 sq km
water: 0 sq km
Area—comparative: 1.3 times the size of Wash-
ington, DC
Land boundaries: 0 km
Coastline: 120 km
Maritime claims: territorial sea: 12 nm
exclusive economic zone: 200 nm
continental shelf: 200 nm or to the edge of the
continental margin
Climate: tropical oceanic; moderated by trade
winds; a dry season from April to November and a
more humid season from December to March
Terrain: low coral atolls in north; volcanic, hilly
islands in south
Elevation extremes: lowest point: Pacific Ocean
Om
highest point: Te Manga 652 m
Natural resources: NEGL
Land use: arable land: 8.33%
permanent crops: 4.17%
other: 87.5% (2011)
irrigated land: NA
Natural hazards: typhoons (November to March)
Environment—current issues: NA
Environment—international agreements:
party to: Biodiversity, Climate Change, Cli-
mate Change-Kyoto Protocol, Desertification,
Hazardous Wastes, Law of the Sea, Ozone Layer
Protection
Geography—note: the northern Cook Islands are
seven low-lying, sparsely populated, coral atolls;
the southern Cook Islands, where most of the
population lives, consist of eight elevated, fertile,
volcanic isles, including the largest, Rarotonga, at
67 sq km','b24a70b150c75e10d3b2f13f669665769dd3ba247c179747eb2cb07ede0e37c2','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('88d9954cad813eaae8ca4d7e2ee1f9c031d20ee2fd7eb8260d61857c023009ca',2025,'CR','Costa Rica','geography',449,'Location: Central America, bordering both -the
Caribbean Sea and the North Pacific Ocean,
between Nicaragua and Panama
Geographic coordinates: 10 00 N, 84 00 W
Map references: Central America and the
Caribbean
Area: total: 51,100 sq km
country comparison to the world: 130
land: 51,060 sq km
water: 40 sq km
note: includes Isla del Coco
Area—comporative: slightly smaller than, West
Virginia
Land boundaries: total:639 km
border countries: Nicaragua 309 km, Panama 330
km
Coastline: 1,290 km
Maritime claims: territorial sea: 12 nm
exclusive economic zone: 200 nm
continental shelf: 200 nm
Climate: tropical and subtropical; dry season
(December to April); rainy season (May to
November); cooler in highlands
Terrain: coastal plains separated by rugged moun-
tains including over 100 volcanic cones, of which
several are major volcanoes
Elevation extremes: lowest point: Pacific Ocean
Om
highest point: Cerro Chirripo 3,810 m
Natural resources: hydropower
Land use: arable land: 4.89%
permanent crops: 6.46%
other: 88.65% (2011)
Irrigated land: sq km (2003)
Total renewable water resources: cu km (2011)
Freshwater withdrawal (domestic/industrial/
agricultural): tocal: 5.77 cu km/yr (15%/9%/77%)
per capita: 1,582 cu m/yr (2006)
Natural hazards: occasional earthquakes, hur-
ricanes along Atlantic coast; frequent flooding of
low lands at onset of rainy season and landslides;
active volcanoes
volcanism: Arenal (elev. 1,670 m), which erupted
in 2010, is the most active volcano in Costa Rica;
a 1968 eruption destroyed the town of Tabacon; -
Irazu (elev. 3,432 m), situated just east of San Jose,
has the potential to spewash over the capital city
as it did between 1963 and 1965; other historically
active volcanoes include Miravalles, Poas, Rincon
de la Vieja, and Turrialba
Environment—current issues: deforestation and
land use change, largely a result of the clearing of
land for cattle ranching and agriculture; soil ero-
sion; coastal marine pollution; fisheries protection;
solid waste-management; air pollution
Environment—international agreements:
party to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Endan-
gered Species, Environmental Modification, Haz-
ardous Wastes, Law of the Sea, Marine Dumping,
Ozone Layer Protection, Wetlands, Whaling
signed, but not ratified: Marine Life Conservation
Geography—note: four volcanoes, two of them
active,. rise near the capital of San Jose in the
center of the country; one of the volcanoes, Irazu,
erupted destructively in 1963-65
Location: Western Africa, bordering the North
Atlantic Ocean, between Ghana and Liberia
Geographic coordinates: 8 00 N, 5 00 W
Map references: Africa
Area: total: 322,463 sq km
country comparison to the world: 69
land: 318,003 sq km
water: 4,460 sq km `
Area—comparative: slightly larger than New','85c6686ba21cd2cf5963fb9daa75d320a7f6fc98f064a4de5c69fafc5c8b2099','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('200ec9b799edab280737cf502ce6bc3e85d86ad9f8e9bc8a9392cb749a85fb88',2025,'MX','Mexico','geography',455,'Land boundaries: total: 3,110 km
border countries: Burkina Faso 584 km, Ghana
668 km, Guinea 610 km, Liberia 716 km, Mali
532km ` >
Coastline: 515 km
Maritime claims: territorial sea: 12 nm
exclusive economic zone: 200 nm
continental shelf: 200 nm
Climate: tropical along coast, semiarid in far
north; three seasons—warm and dry (November
to March), hot and dry (March to May), hot and
wet (June to October)
Terrain: mostly flat to undulating plains; moun-
tains in northwest
Elevation extremes: lowest point: Gulf of
Guinea 0 m
highest point: Monts Nimba 1,752 m
Natural resources: petroleum, natural gas, dia-
monds, manganese, iron ore, cobalt, bauxite, cop-
per, gold, nickel, tantalum, silica sand, clay, cocoa
beans, coffee, palm oil, hydropower
Land use: arable land: 8.99%
permanent crops: 13.65%
other: 77.36% (2011)
trrigated land: 727.5 sq km (2003)
Total renewable water resources: 81.14 cu km
(2011)
Freshwater withdrawal (domestic/indus-
triaVagricultural): total: 1.55 cu km/yr
(41%/21%/38%)
per capita: 83.07 cu m/yr (2008)
Notural hazards: coast has heavy surf and no
natural harbors; during the rainy season torrential
flooding is possible
Environment—current issues: deforestation
(most of the country’s forests—once the largest
in West Africa—have been heavily logged); water
pollution from sew age and industrial and agricul-
tural effluents y i
Environment—international agreements:
party to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Endan-
gered Species, Hazardous Wastes, Law of the Sea,
Marine Dumping, Ozone Layer Protection, Ship
Pollution, Tropical Timber 83, Tropical Timber 94,
Wetlands, Whaling
signed, but not ratified: none of the selected
agreements
Geography—note: most of the inhabitants live
along the sandy coastal region; apart from the capi-
tal area, the forested interior is sparsely populated
Geography—note: strategic location on south-
ern border of US; corn (maize), one of the world’s
Major grain crops, is thought to have originated in
Location: Oceania, island group in the North
Pacific Ocean, about three-quarters of the way
from Hawaii to Indonesia
Geographic coordinates: 6 55 N, 158 15 E
Map references: Oceania
Area: total: 702 sq km
country comparison to the world: 191
land: 702 sq km
water: 0 sq km (fresh water only)
note: includes Pohnpei (Ponape), Chuuk (Truk)
Islands, Yap Islands, and Kosrae (Kosaie)
Area—comparaftive: four times the size of Wash-
ington, DC (land area only)
Land boundaries: 0 km
Coastline: 6,112 km
Maritime claims: territorial sea: 12 nm
exclusive economic zone: 200 nm
Climate: tropical; heavy year-round rainfall, espe-
cially in the eastern islands; located on southern
edge of the typhoon belt with occasionally severe
damage
Terrain: islands vary geologically from high moun-
tainous islands to low, coral atolls; volcanic out-
croppings on Pohnpei Kosrae and Chuuk
Elevation extremes: lowest point: Pacific Ocean
Om
highest point: Dolohmwar (Totolom) 791 m
Natural resources: timber, marine products,
deep-seabed minerals, phosphate
Land use: arable land: 2.86%
permanent crops: 24.29%
other: 72.86% (2011)
Irrigated land: NA
Natural hazards: typhoons (June to December)
Environment—current issues: Over fishing, cli-
mate change, pollution
Environment—international agreements:
party to: Biodiversity, Climate Change, Cli-
mate Change-Kyoto Protocol, Desertification,
Hazardous Wastes, Law of the: Sea, Ozone Layer
Protection >
Federated States of Micronesia
FEDERATED STATES OF MICRONESIA
signed, but not ratified: none of the selected
agreements
Geography—note: four major island groups total-
ing 607 islands
Land boundaries: total:2,542 km
border countries: Finland 727 km, Sweden 1,619
km, Russia 196 km Coastline: 25,148 km (includes
mainland 2,650 krn, as well as long fjords, numer-
ous small islands, and minor indentations 22,498
km; length of island coastlines 58,133 km)
Maritime claims: territorial sea: 12 nm contigu-
ous zone: 10 nm exclusive economic zone: 200 nm
continental shelf: 200 nm
Climate: temperate along coast, modified by
North Atlantic Current; colder interior with
increased precipitation and colder summers; rainy
year-round on west coast
Terrain: glaciated; mostly high plateaus and rug-
ged mountains broken by fertile valleys; small,
scattered plains; coastline deeply indented by
fjords; arctic tundra in north
Elevation extremes: lowest point: Norwegian
Sea 0 m highest point: Galdhopiggen 2,469 m
Natura! resources: petroleum, natural gas, iron
ore, copper, lead, zinc, titanium, pyrites, nickel,
fish, timber, hydropower
Lond use: arable land:2.52%
permanent crops: 0.01%
other: 97.46% (2011)
Irrigated land: 1,149 sq km (2007)
Total renewable water resources: 382 cu km
(2011)
Freshwater withdrawal (domestic/indus-
triaV/agricultural): total: 2.94 cu km/yr
(28%/43%/29%)
per capita: 622.4 cu m/yr (2006)
Natural hazards: rockslides, avalanches
volcanism: Beerenberg (elev. 2,227 m) on Jan
Mayen Island in the Norwegian Sea is the coun-
try''s only active volcano
Environment—current issues: water pollution;
acid rain damaging forests and adversely affecting
lakes, threatening fish stocks; air pollution from
vehicle emissions
Environment—international agreements:
party to: Air Pollution, Air Pollution-Nitrogen
Oxides, Air Pollution-Persistent Organic Pollut-
ants, Air Pollution-Sulfur 85, Air Pollution-Sulfur
94, Air Pollution-Volatile Organic Compounds,
Antarctic-Environmental
Marine Living Resources, Antarctic Seals, Ant-
Climate Change,
Climate Change-Kyoto Protocol, Desertification,
Protocol, Antarctic-
arctic ‘Treaty, Biodiversity,
Endangered Species, Environmental Modifica-
tion, Hazardous Wastes, Law of the Sea, Marine
Dumping, Ozone Layer Protection, Ship Pollution,
Tropical Timber 83, Tropical Timber 94, Wetlands,
Whaling
signed, but not ratified: none of the selected
agreements
Geography—note: about two-thirds mountains;
some 50,000 islands off its much-indented coast-
line; strategic location adjacent to sea lanes and air
routes in North Atlantic; one of the most rugged
and longest coastlines in the world
Land boundaries: total: 3,047 km
border countries: Belarus 605 km, Czech Republic
615 km, Germany 456 km, Lithuania 91 km, Rus-
sia (Kaliningrad Oblast) 432 km, Slovakia 420 km,
Ukraine 428 km
Coastline: 440 km
Maritime claims: territorial sea: 12 nm
exclusive economic zone; defined by interna-
tional treaties
Climate: temperate with cold, cloudy, mod-
erately severe winters with frequent precipita-
tion; mild summers with frequent showers and
thundershowers
Terrain: mostly flat plain; mountains along south-
ern border
Elevation extremes: lowest point: near Raczki
Elblaskie -2 m
highest point: Rysy 2,499 m
Natural resources: coal, sulfur, copper, natural
gas, silver, lead, salt, amber, arable land
Land use: arable land: 35.49%
permanent crops; 1.25%
other: 63.26% (2011)
Irrigated land: 1,157 sq km (2007)
Total renewable water resources: 61.6 cu km
(2011)
Freshwater withdrawal (domestic/indus-
trial/agricuitural): total: 11.96 cu km/yr
(31%/60%/10%)
per capita: 312.3 cu m/yr (2009)
Natural hazards: flooding
n
Environment—current issues: situation has
improved since 1989 due to decline in heavy indus-
try and increased environmental concern Dy post-
Communist govemments; air pollution nonetheless
- remains serious because of sulfur dioxide emissions
from coal-fired power plants, and the resulting acid
rain has caused forest damage; water pollution from
industrial and municipal sources is also a problem,
as is disposal of hazardous wastes; pollution levels
should continue to decrease as industrial establish-
ments bring their facilities up to EU code, but at
substantial cost to business and the government
Environment—international agreements:
party to: Air Pollution, Antarctic-Environmental
Protocol, Antarctic-Marine Living Resources,
Antarctic Seals, Antarctic Treaty, Biodiversity,
Climate Change, Climate Change-Kyoto Proto-
‘col, Desertification, Endangered Species, Envi-
ronmental Modification, Hazardous Wastes, Law ‘
of the Sea, Marine Dumping, Ozone Layer Protec-
tion, Ship Pollution, Wetlands
signed, but not ratified; Air Pollution-Nitrogen
Oxides, Air Pollution-Persistent Organic Pollut-
ants, Air Pollution-Sulfur 94
Geography—note: historically, an area of conflict
because of flat terrain and the lack of natural barri-
ers on the North European Plain
Land boundaries: total: 4,639 km
border countries; Cambodia 1,228 km, China
1,281 km, Laos 2,130 km
Coastline: 3,444 km (excludes islands)
Maritime claims: territorial sea: 12 nm
contiguous zone: 24 nm
exclusive economic zone: 200 nm
continental shelf: 200 nm or to the edge of the
continental margin
Climate: tropical in south; monsoonal in north
with hot, rainy season (May to September) and
warm, dry season (October to March)
Terrain: low, flat delta in south and north; cen-
tral highlands; hilly, mountainous in far north and
northwest
Elevation extremes: lowest point: South China
Sea 0 m
highest point; Fan Si Pan 3,144 m
Natural resources: phosphates, coal, manganese,
rare earth elements, bauxite, chromate, offshore
‘oil and gas deposits, timber, hydropower
Land use: arable land: 19.64%
permanent crops: 11.18%
other: 69.18% (2011) ; t
Irrigated land: 45,850 sq km (2005)
Total renewable water resources: 884.1 cu km
(2011)
Freshwater withdrawal (domestic/industrial/
agricultural): otal: 82.03 cu km/yr (1%/4%/95%)
per capita: 965 cu m/yr (2005)
Natural hazards: occasional typhoons (May to
January) with extensive flooding, especially in the
Mekong River delta
Environment—current issues: logging and
slash-and-burn agricultural practices contribute to
deforestation and soil degradation; water pollution
and overfishing threaten marine life populations;
groundwater contamination limits potable water
supply; growing urban industrialization and popula-
tion migration are rapidly degrading environment in
Hanoi and Ho Chi Minh City
Environmeni—international agreements:
party to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Endan-
gered Species, Environmental Modification,
Hazardous Wastes, Law of the Sea, Ozone Layer
Protection, Ship Pollution, Wetlands
signed, but not ratified: none of the selected
agreements
791
Geography—note: extending 1,650 km north to
south, the country is only 50 km across at its nar-
rowest point','ee8d5cf495a459460b2d907efdc6ff3a88e0a6993ac8da475629091e30098f1a','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4f5c80598bc1b600e5c67dca2a2cd4ea569ef59cfa38b8324a9973737e945deb',2025,'HR','Croatia','geography',466,'Location: Southeastern Europe, bordering the
Adriatic Sea, betw een Bosnia and Herzegovina
and Slovenia
182
Geographic coordinates: 45 10 N, 15 30 E
Map references: Europe
Area: total: 56,594 sq km
country comparison to the world: 127
land: 55,974 sq km
water: 620 sq km
Area—comparative: slightly smaller than West
Virginia
Land boundaries: total: 1,982 km
border countries: Bosnia and Herzegovina 932
km, Hungary 329 km, Serbia 241 km, Montenegro
25 km, Slovenia 455 km
Coastline: 5,835 km (mainland 1,777 km, islands
4,058 km)
Maritime claims: territorial sea: 12 nm
continental shelf: 200 m depth or to the depth of
exploitation
Climate: Mediterranean and continental; con-
tinental climate predominant with hot summers
and cold winters; mild winters, dry summers along
coast
Terrain: geographically diverse; flat plains along
Hungarian border, low mountains and highlands
near Adriatic coastline and islands
Elevation extremes: lowest point: Adriatic Sea
Om
highest point: Dinara 1,831 m
Natural resources: oil, some coal, bauxite, low-
grade iron ore, calcium, gypsum, natural asphalt,
silica, mica, clays, salt, hydropower
Land use: arable land: 15.85%
permanent crops: 1.47%
other: 82.69% (2011)
Irrigated land: 36.27 sq km (2010)
Total renewable water resources: 105.5 cu km
(2011)
Natura! hazards: destructive earthquakes
Environment—current - issues: air pollution
(from metallurgical plants) and resulting acid rain
is damaging the forests; coastal pollution from
industrial and domestic waste; landmine removal
and reconstruction of infrastructure consequent to
1992-95 civil strife
Environment—international agreements:
party to: Air Pollution, Air Pollution-Nitrogen
Oxides, Air Pollution-Persistent Organic Pollut-
ants, Air Pollution-Sulfur 94, Air Pollution-Vol-
atile Organic Compounds, Biodiversity, Climate
Change, Climate Change-Kyoto Protocol, Deser-
tification, Endangered Species, Hazardous Wastes,
Law of the Sea, Marine Dumping, Ozone Layer
Protection, Ship Pollution, Wetlands, Whaling
signed, but not ratified: none of the selected
agreements
Geography—note: controls most land routes
from Westem Europe to Aegean Sea and Turkish
Straits; most Adriatic Sea islands lie off the coast
of Croatia—some 1,200 islands, islets, ridges, and
rocks','b10a89579da67977a14d047aae8f700b04fedd603dfe70eeacb612c7f8b3a0d9','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8efd321257e1569722fe138a349172d9e54191017b7234fc7acbda5b407207ff',2025,'CU','Cuba','geography',475,'Location: Caribbean, island between the Carib-
bean Sea and the North Atlantic Ocean, 150 km
south of Key West, Florida
Geographic coordinates: 21 30 N, 80 00 W
186
Map references: Central America and the
Caribbean
Area: total: 110,860 sq km
country comparison to the world: 106
land: 109,820 sq km water: 1,040 sq km
Area—comparative: slightly smaller
Pennsylvania
Land boundaries: total: 29 km
border countries: US Naval Base at Guantanamo
Bay 29 km
note: Guantanamo Naval Base is leased by the US
and remains part of Cuba
Coastline: 3,735 km
Maritime claims: territorial sea: 12 nm
contiguous zone: 24 nm
exclusive economic zone: 200 nm
Climate: tropical; moderated by trade winds; dry
season (November to April); rainy season (May to
October)
Terrain: mostly flat to rolling plains, with rugged
hills and mountains in the southeast
Elevation extremes: lowest point: Caribbean
Sea O m
highest point: Pico Turquino 2,005 m
Natural resources: cobalt, nicket, iron ore, chro-
mium, copper, salt, timber, silica, petroleum, arable
land
Land use: arable land: 32.31%
permanent crops: 3.55%
other: 64.15% (2011)
Irrigated land: 8,703 sq km (2003)
Total renewable water resources: 38.12 cu km
than
(2011)
Freshwater withdrawal (domestic/indus-
trial/agricultural): total: 4.42 cu km/yr
(22%/14%/65%)
per capita: 392.6 cu m/yr (2010)
Natural hazards: the east coast is subject to hur-
ricanes from August to November (in general, the
country averages about one hurricane every other
year); droughts are common
Environment—current issues: air and water pol-
lution; biodiversity loss; deforestation
Environment—international agreements:
party to: Antarctic Treaty, Biodiversity, Climate
Change, Climate Change-Kyoto Protocol, Deser-
tification, Endangered Species, Environmental
Modification, Hazardous Wastes, Law of the Sea,
Marine Dumping, Ozone Layer Protection, Ship
Pollution, Wetlands
signed, but not ratified: Marine Life Conservation
Geography—note: largest country in Caribbean
and westernmost island of the Greater Antilles
Location: Middle East, island in the Mediterra-
nean Sea, south of Turkey
Geographic coordinates: 35 00 N, 33 00 E
Mapreferences: Europe
Area: total: 9,251 sq km (of which 3,355 sq km are
in north Cyprus)
country comparison to the world: 171
land: 9,241 sq km wate r: 10 sq km
Area—comparative: about 0.6 times the size of
Connecticut
Land boundaries: total: 150.4 km (approximately)
border sovereign base areas: Akrotiri 47.4 km,
Dhekelia 103 km (approximately)
Coastline: 648 km
Maritime claims: territorial sea: 12 nm
contiguous zone: 24 nm
190
THE CIA WORLD FACTBOOK
continental shelf: 200 m depth or to the depth of
exploitation
Climate: temperate; Mediterranean with hot, dry
summers and cool winters
Terrain: central plain with mountains to north
and south; scattered but significant plains along
southern coast
Elevation extremes: lowest point: Mediterra-
nean Sea 0.m
highest point: Mount Olympus 1,951 m
Natural resources: copper, pyrites, asbestos, gyp-
sum, timber, salt, marble, clay earth pigment
Land use: arable land: 9.06%
permanent crops: 3.54%
other: 87.41% (2011)
Irrigated land: 457.9 sq km (2007)
Total renewable water resources: 0.78 cu km
(2011)
Freshwater withdrawal (domestic/industrial/
agricultural): total: 0.18 cu km/yr (10%/3%/86%)
per capita: 164.7 cu m/yr (2009)
Notural hazards: moderate earthquake activity;
droughts
Environment—current issues: water resource
problems (no natural reservoir catchments, sea- .
sonal disparity in rainfall, sea water intrusion to
island’s largest aquifer, increased salination in the
north); water pollution from sew age and industrial
wastes; coastal degradation; loss of wildlife habitats
from urbanization
Environmenf—international agreements:
party to: Air Pollution, Air Pollution-Nitrogen
Oxides, Air Pollution-Persistent Organic Pollut-
ants, Air Pollution-Sulfur 94, Biodiversity, Cli-
mate Change, Climate Change-Kyoto Protocol,
Desertification, Endangered Species, Environmen-
tal Modification, Hazardous Wastes, Law of the
Sea, Marine Dumping, Ozone Layer Protection,
Ship Pollution, Wetlands
signed, but not ratified: none of the selected
agreements
Geography—note: the third largest island in the
Mediterranean Sea (after Sicily and Sardinia)','0dc2ef75c52983522987ef2d511edb6b26d24acff28dda2d53ebb5a45122f6c1','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('11b73d7166aa2fdb5fd1af4c2c1cc57f565554bb9d559665a7ff3d031ee08af7',2025,'GL','Greenland','geography',490,'Areo—comparative: slightly less than twice the
size of Massachusetts
Land boundaries: total: 68 km
border countries: Germany 68 km
Coastline: 7,314 km
Maritime claims: territorial sea: 12 nm
contiguous zone: 24 nm
exclusive economic zone: 200 nm
continental shelf: 200 m depth or to the depth of
exploitation
Climate: temperate; humid and overcast; mild,
windy winters and cool summers
Terrain: low and flat to gently rolling plains
Elevation extremes: lowest point: Lammefjord
-7m
highest point: Mollehoj/Ejer Bavnehoj 171 m
Natural resources: petroleum, natural gas, fish,
salt, limestone, chalk, stone, gravel and sand
Land use: arable land: 57.99%
permanent crops: 0.09%
other: 41.91% (2011) f','f92752a874e72dc3f7ac85521faece37105e80a2852a1cc234a045b1a31d4e79','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('da9bc0032be307a8e1ec5e8ae22a9632a1787e1e962f45884eb6bce12675ef98',2025,'DK','Denmark','geography',491,'irrigated tand: 4,354 sq km (2007)
Totali renewable water resources: 6 cu km
(2011)
Freshwater withdrawal (domestic/industrial/
agricultural): total: 0.66 cu km/yr (58%/5%/36%)
per capita; 118.4 cu m/yr (2009) -
Natural hazards: flooding is a threat in some
areas of the country (e.g., parts of Jutland, along
the southern coast of the island of Lolland) that
are protected from the sea by a system of dikes
Environment—current Issues: air pollution,
principally from vehicle and power plant emis-
sions; nitrogen and phosphorus pollution of the
North Sea; drinking and surface water becoming
polluted from animal wastes and pesticides
Environment—international agreements:
party to: Air Pollution, Air Pollution-Nitrogen
Oxides, Air Pollution-Persistent Organic Pollut-
ants, Air Pollution-Sulfur 85, Air Pollution-Sulfur
94, Air Pollution-Volatile Organic Compounds,
Antarctic Treaty, Biodiversity, Climate Change,
Climate Change-Kyoto Protocol, Desertification,
Endangered Species, Environmental Modifica-
tion, Hazardous Wastes, Law of the Sea, Marine
Dumping, Marine Life Conservation, Ozone Layer
Protection, Ship Pollution, Tropical Timber 83,
Tropical Timber 94, Wetlands, Whaling
signed, but not ratified: none of the selected
agreements
Geography—note: controls _— Straits
(Skagerrak and Kattegat) linking Baltic and North
Seas; about one-quarter of the population lives in
greater Copenhagen
Location: Eastern Mediterranean, on the south-
east coast of Cyprus near Famagusta
Geographic coordinates: 34 59 N, 33 45 E
Map references: Europe
Area: total: 130.8 sq km
country comparison to the world: 223
note: area surrounds three Cypriot enclaves
202
Areo—comparative: about three-quarters the size
of Washington, DC
Land boundaries: total: 103 km (approximately)
border countries: Cyprus 103 km (approximately)
Coastline: 27.5 km
Climate: temperate; Mediterranean with hot, dry
summers and cool winters
Environment—current issues: netting and trap-
ping of small migrant songbirds in the spring and
autumn
Geography—note: British extraterritorial rights
also extended to several small off-post sites scat-
tered across Cyprus; of the Sovereign Base Area
land 60% is privately owned and farmed, 20% is
ow ned by the Ministry of Defense, and 20% is
SBA Crown land
Location: Caribbean, island between the Carib-
bean Sea and Atlantic Ocean, north of Trinidad
and Tobago
Geographic coordinates: 12 07 N, 61 40 W
Map references: Central America and the
Caribbean
Area: total: 344 sq km
country comparison to the world: 207
land: 344 sq km
water: 0 sq km
Area—comparative: twice the size of Washing-
ton, DC
Land boundaries: 0 km
Coastline: 121 km .
Maritime claims: territorial sea: 12 nm
exclusive economic zone: 200 nm
Climate: tropical; teripered by northeast trade
winds
Terrain: volcanic in origin with central mountains
Elevation extremes: lowest point: Caribbean
Sea O m
highest point: Mount Saint Catherine 840 m
Natural resources: timber, tropical fruit, deepwa-
ter harbors
Land use: arable land:8.82%
permanent crops: 20.59%
other: 70.59% (2011)
Irrigated land: 2.19 sq km (2003)
Total renewable water resources: NA
Natural hazards: lies on edge of hurricane belt;
hurricane season lasts from June to November
Environment—current issues: NA
Environment—international agreements:
party to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Endan-
gered Species, Law of the Sea, Ozone Layer Pro-
tection, Whaling
signed, but not ratified: none of the selected
agreements
Geography—note: the administration of the
islands of the Grenadines group is divided between
Saint Vincent and the Grenadines and Grenada','57b0d9964b05d84561d3d04e33e9c6bd74edeba409a29cc4ded9f3c8c9100409','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a8663114e22c4b9e6459fb9d8b04763990875fd93069f0756ebc440db0d606b9',2025,'DJ','Djibouti','geography',505,'Location: Eastern Africa, bordering the Gulf
of Aden and the Red Sea, betw een Eritrea and','222a89b7b9537974b71151075423cf1a8ec6adec3fbab84817c8431a23222203','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b38d16d7c3363571d0f687ca406491613fc90c3392c1d8903ff1672b65f3dd87',2025,'SO','Somalia','geography',506,'Geographic coordinates: 11 30 N, 43 00 E
Map references: Africa
Area: total: 23,200 sq km
country comparison to the world: 151
land: 23,180 sq km
water: 20 sq km
Area—comparative:
Massachusetts
Land boundaries: total: 516 km
border countries: Eritrea 109 km, Ethiopia 349
km, Somalia 58 km
Coastline: 314 km
Maritime cicims: territorial sea: 12 nm
contiguous zone: 24 nm
exclusive economic zone: 200 nm
Climate: desert; torrid, dry
Yerraln: coastal plain and plateau separated by
central mountains
Elevation extremes: lowest point: Lac Assal-155
m
highest point: Moussa Ali 2,028 m
Natural resources: potential geothermal power,
gold, clay, granite, limestone, marble, salt, diato-
mite, gypsum, pumice, petroleum
Land use: arable land: 0.09%
permanent crops: 0%
other: 99.91% (2011)
Irrigated land: 10.12 sq km (2003)
Total renewable water resources: 0.3 cu km
(2011)
Freshwater withdrawal (domestic/industrial/
agricultural): total: 0.02 cu km/yr (84%/0%/16%)
per capita: 24.84 cu m/yr (2000)
Natural hazards: earthquakes; droughts; occasional
cyclonic disturbances from the Indian Ocean bring
heavy rains and flash floods
slightly smaller than
volcanism: experiences limited volcanic activity;
Ardoukoba (elev. 298 m) last erupted in 1978;
Manda-Inakir, located along the Ethiopian border,
is also historically active
Environment—current issues; inadequate sup-
plies of potable water; limited arable land; deser-
tification; endangered species
Environment—international agreements:
party to: Biodiversity, Climate Change, Cli-
mate Change-Kyoto Protocol, Desertification,
Endangered Species, Hazardous Wastes, Law of
the Sea, Ozone Layer Protection, Ship Pollution,
Wetlands
signed, but not ratified: none of the selected
agreements
Geography—note: strategic location near world’s
busiest shipping lanes and close to Arabian oil-
fields; terminus of rail traffic into Ethiopia; mostly
wasteland; Lac Assal (Lake Assal) is the lowest
point in Africa and the saltiest lake in the world
Location: Southern Africa, at the southern tip of
* the continent of Africa
Geographic coordinates: 29 00 S, 24 00 E
Map references: Africa
Area: total: 1,219,090 sq km
country comparison to the world: 25
land: 1,214,470 sq km
water: 4,620 sq km
note: includes. Prince Edward Islands (Marion
Island and Prince Edward Island)
Area—comparative: slightly less than twice the
size of Texas
Land boundaries: total: 4,862 km
border countries: Botswana 1,840 km, Lesotho
909 km, Mozambique 491 km, Namibia 967 kin,
Swaziland 430 km, Zimbabwe 225 km
Coastline: 2,798 km
Maritime claims: territorial sea: 12 nm
contiguous zone: 24 nm
exclusive economic zone: 200 nm
continental shelf: 200 nm or to edge of the conti-
nental margin Climate: mostly semiarid; subtropi-
cal along east coast; sunny days, cool nights Ter-
rain: vast interior plateau rimmed by rugged hills
and narrow coastal plain
Elevation extremes: lowest point: Atlantic
Ocean 0 m
highest point: Njesuthi 3,408 m
Natural resources: gold, chromium, antimony,
coal, iron ore, manganese, nickel, phosphates,
tin, rare earth elements, uranium, gem diamonds,
platinum, copper, vanadium, salt, natural gas
Land use: arable land: 9.87%
permanent crops: 0.34%
other: 89.79% (2011)
Irrigated land: 16,700 sq km (2012)
Total renewable water resources: 51.4 cu km
(2011)
Freshwater withdrawal (domestic/industrial/
agricultural): cotal: 12.5 cu km/yr (36%/7%/57%)
per capita: 271.7 cu m/yr (2005) ’
Natural hazards: prolonged droughts
volcanism: the volcano forming Marion Island in
the Prince Edward Islands, which last erupted in
2004, is South Africa’s only active volcano
Environment—current issues: lack of impor-
tant arterial rivers or lakes requires extensive
water conservation and control measures; growth
in water usage outpacing supply; pollution of riv-
ers from agricultural runoff and urban discharge;
air pollution resulting in acid rain; soil erosion;
desertification
Environment—international agreements:
party to: Antarctic-Environmental Protocol, Ant-
atctic-Marine Living Resources, Antarctic Seals,
Antarctic Treaty, Biodiversity, Climate Change,
Climate Change-Kyoto Protocol, Desertification,
Endangered Species, Hazardous Wastes, Law of
+','69c1ed2c8ddd21b2dbadb592631fcadff94799b0957a6d7a7db61fabe8f462e4','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('403ca9b4cb8b513c07173a68bb9e0501b217c5ad706bca436027c3842f60704b',2025,'DM','Dominica','geography',517,'Location: Caribbean, island between the Carib-
bean Sea and the North Atlantic Ocean, about half
way between Puerto Rico and Trinidad and Tobago
Geographic coordinates: 15 25 N, 61 20 W
Map references: Central America and the
Caribbean
Area: total:751 sq km
country comparison to the world: 189
land: 751 sq km
water: 0 sq km
Area—comparative: slightly more than four
times the size of Washington, DC
Land boundaries: 0 km
Coastline: 148 km
Maritime claims: territorial sea: 12 nm
contiguous zone: 24 nm
exclusive economic zone: 200 nm
Climate: tropical; moderated by northeast trade
winds; heavy rainfall
Terrain: rugged mountains of volcanic origin
Elevation extremes: lowest point: Caribbean
SeaOm ,
highest point: Morne Diablotins 1,447 m
Natural resources: timber, hydropower, arable land
Land use: arable land:8%
permanent crops: 24%
other: 68% (2011)
Irrigated land: NA
Total renewable water resources: NA
Freshwater withdrawal (domestic/industrial/
agricultural): total: 0.02 cu km/yr (NA)
per capita: 244.1 cu m/yr (2004)
Natural hazards: flash floods are a constant
threat; destructive hurricanes can be expected dur-
ing the late summer months
Environment—current issues: NA
Environment—international agreements:
party to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Endan-
gered Species, Environmental Modification,
Hazardous Wastes, Law of the Sea, Ozone Layer
Protection, Ship Pollution, Whaling
signed, but not ratified: none of the selected
agreements
Geography—note: known as “The Nature Island
of the Caribbean” due to its spectacular, lush,
and varied flora and fauna, which are protected
by an extensive natural park system; the most
mountainous of the Lesser Antilles, its volcanic
peaks are cones of lava craters and include Boiling
Lake, the second-largest, thermally active lake in
the world','82203b488bf0ab85155db1cc1e2bf6533971d5e5e4cb20b6ed718c5f06cacc55','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4a3624baffb3c58fb351d5f7ac15a0761fe74793a843ec4e95fc251c0514d35f',2025,'DO','Dominican Republic','geography',527,'Location: Caribbean, eastern two-thirds of the
island of Hispaniola, between the Caribbean Sea
and the North Atlantic Ocean, east of Haiti
Geographic coordinates: 19 00 N, 70 40 W
Map references: Central America and the
Caribbean
Area: total: 48,670 sq km
country comparison to the world: 132
land: 48,320 sq km
water: 350 sq km
Areo—comparative: slightly more than twice the
size of New Hampshire
Land boundaries: total: 360 km
border countries: Haiti 360 km
Coastline: 1,288 km
Maritime claims: measured from claimed archi-
pelagic straight baselines’
territorial sea; 6 nm
contiguous zone: 24 nm
exclusive economic zone: 200 nm
continental shelf: 200 nm or to the edge of the
continental margin
Climate: tropical maritime; little seasonal tem-
perature variation; seasonal variation in rainfall
Terrain: rugged highlands and mountains with fer-
tile valleys interspersed
Elevation extremes: lowest point: Lago Enri-
quillo-46 m
highest point: Pico Duarte 3,175 m
Natural resources: nickel, bauxite, gold, silver
Land use: arable land: 16.44%
permanent crops: 9.25%
other: 74.32% (2011)
Irrigated land: 3,065 sq km (2009)
Total renewable water resources: 21 cu km
(2011)
Freshwater withdrawal (domestic/industrial/
agricultural): total:5.47 cu km/yr (26%/1%/72%)
per capita: 574.2 cu m/yr (2005)
Natural hazards: lies in the middle of the hur-
ricane belt and subject to severe storms from June
to October; occasional flooding; periodic droughts
Environment—current issues: water short-
ages; soil eroding into the sea damages coral reefs;
deforestation
Environment—international agreements:
party to: Biodiversity, Climate Change, Climate
209
Change-Kyoto Protocol, Desertification, Endan-
gered Species, Hazardous Wastes, Marine Dump-
ing, Marine Life Conservation, Ozone Layer Pro-
tection, Ship Pollution, Wetlands
signed, but not ratified: Law of the Sea
Geography—note: shares island of Hispaniola
with Haiti
Geographic coordinates: 19 00 N, 72 25 W
Map references: Central America and the
Caribbean
Area: total: 27,750 sq km
country comparison to the world: 148
316
land: 27,560 sq km
water: 190 sq km
Area—comparative:
Maryland
Land boundaries: total: 360 km
border countries: Dominican Republic 360 km
Coastline: 1,771 km
Maritime claims: territorial sea: 12 nm
contiguous zone: 24 nm
exclusive economic zone: 200 nm
continental shelf: to depth of exploitation
slightly smaller than
Climate: tropical; semiarid where mountains fn
” east cut off trade winds
Terrain: mostly rough and mountainous
Elevation extremes: lowest point: Caribbean
Sea 0 m
highest point: Chaine de la Selle 2,680 m
Natural resources: bauxite, copper, calciĝm car-
bonate, gold, marble, hydropower
Land use: arable land: 36.04%
permanent crops: 10.09%
other: 53.87% (2011)
Irrigated land: 970 sq km (2009)
Total renewable water resources: 14.03 cu km
(2011)
Freshwater withdrawal (domestic/industrial/
agricultural): total: 1.2 cu km/yr (17%/3%/80%)
per capita: 134.3 cu m/yr (2009)
Natural hazards: lies in the middle of the hur-
ricane belt and subject to severe storms from June
to October; occasional flooding and earthquakes;
periodic droughts .
Environment—current issues: extensive defor-
estation (much of the remaining forested land is
being cleared for agriculture and used as fuel); soil
erosion; inadequate supplies of potable water
Environment—international agreements:
party to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Law of
the Sea, Marine Dumping, Marine Life Conserva-
tion, Ozone Layer Protection
signed, but not ratified: Hazardous Wastes
Geography—note: shares island of Hispaniola
with Dominican Republic (westem one-third
is Haiti, eastem two-thirds is the Dominican
Republic)','11d27d28f3e1b73e5e107b4778b7827d76db984992b1e797c1e48e7119114193','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('239a19731ddcd2e9aa7c8f5a325c97e740d3f693c47f13615b2a22f5515c3bd4',2025,'EC','Ecuador','geography',541,'Location: Northern Africa, bordering the Medi-
terranean Sea, between Libya and the Gaza Strip,
and the Red Sea north of Sudan, and includes the
Asian Sinai Peninsula ,','bd7356ca6b1dadf02960d096b42da7c2bfb88f58d9630ae3ac03523ce7058601','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('67d25c0b53ed0a7986aed660a6d9a7e8eeab578b6987e243977e2fe908309d93',2025,'EG','Egypt','geography',542,'Geographic coordinates: 27 00 N, 30 00E
Map references: Africa
Area: total: 1,001,450 sq km
country comparison to the world: 30
land: 995,450 sq km
water: 6,000 sq km
Areo—comparative: slightly more than three
times the size of New Mexico
Land boundaries: total: 2,665 km
border countries: Gaza Strip 11 km, Israel 266
_ km, Libya 1,115 km, Sudan 1,273 km
Coastline: 2,450 km
Maritime claims: territorial sea: 12 nm
contiguous zone: 24 nm
exclusive economic zone: 200 nm
continental shelf: 200 m depth or to the depth of
exploitation
Climate: desert; hot, dry summers with moderate
winters
Terrain: vast desert plateau interrupted by Nile
valley and delta
Elevation extremes: lowest point: Qattara
Depression-133m
highest point: Mount Catherine 2,629m
Natural resources: petroleum, natural gas, iron
ore, phosphates, manganese, limestone, gypsum,
talc, asbestos, lead, rare earth elements, zinc
Land use: arable land: 2.87%
permanent crops: 0.79%
other: 96.34% (2011)
Irrigated land: 34,220 sq km(2003)
Total renewable water resources: 57.3 cu
km(2011)
Freshwater withdrawal (domestic/industrial/
agricultural): total: 68.3 cu km/yr (8%/6%/86%)
per capita: 973.3 cu m/yr (2000)
Natural hazards: periodic droughts; frequent
earthquakes; flash floods; landslides; hot, driving
windstorms called khamsin occur in spring; dust
storms; sandstorms
Environment—current issues: agricultural land
being lost to urbanization and windblown sands;
increasing soil salination below Aswan High
Dam; desertification; oil pollution threatening
coral reefs, beaches, and marine habitats; other
water pollution from agricultural pesticides, raw
sewage, and industrial effluents; limited natural
freshwater resources away from the Nile, which
is the only perennial water source; rapid growth
in population overstraining the Nile and natural
resources
Environment—international agreements:
party to: Biodiversity, Climate Change, Cli-
mate Change-Kyoto Protocol, Desertification,
Endangered Species, Environmental Modifica-
tion, Hazardous Wastes, Law of the Sea, Marine
Dumping, Ozone Layer Protection, Ship Pollu-
tion, Tropical Timber 83, Tropical Timber 94,
Wetlands
signed, but not ratified: none of the selected
agreements
Geography—note: controls Sinai Peninsula, only
land bridge between Africa and remainder of East-
em Hemisphere; controls Suez Canal, a sea link
between Indian Ocean and Mediterranean Sea;
size, and juxtaposition to Israel, establish its major
role in Middle Eastern geopolitics; dependence
on upstream neighbors; dominance of Nile basin
issues; prone to influxes of refugees from Sudan
and the Palestinian territories','d5712e65916290b898c01b22ad2038a5a33887ffd174de26cede59b1d4cf9a5f','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8690421762631eec5a85f8a92faafdbe0be1481af3b3e42cb2de4f84fb2d12ad',2025,'GT','Guatemala','geography',554,'Location: Central America, bordering the North
Pacific Ocean, between Guatemala and Honduras
Geographic coordinates: 13 50 N, 88 55 W
Map references: Central America and the
Caribbean
Area: total: 21,041 sq km
country comparison to the world: 153
land: 20,721 sq km
water: 320 éq km
Area—comparative:
Massachutetts
Land boundaries: total: 545 km
border countries: Guatemala 203 km, Honduras
342 km
Coastline: 307 km
Maritime claims: territorial sea: 12 nm
contiguous zone: 24 nm
exclusive economic zone: 200 nm
Climate: tropical; rainy season (May to October);
dry season (November to April); tropical on coast;
temperate in uplands
slightly smaller than
Terrain: mostly mountains with narrow coastal
belt and central plateau
Elevation extremes: lowest point: Pacific Ocean
Om i
highest point: Cerro El Pital 2,730 m
Natural resources: hydropower,
power, petroleum, arable land
Land use: arable land: 31.61%
permanent crops: 10.93%
other: 57.46% (2011)
Irrigated tand: 449.9 sq km (2003)
Total renewable water resources: 25.23 cu km
(2011)
geothermal
Freshwater withdrawal (domestic/indus-
trial/agricultural): total: 1.84 cu km/yr
(22%/14%/64%)
per capita: 301.9 cu m/yr (2007)
Natural hazards: known as the Land of Volca-
noes; frequent and sometimes destructive earth-
quakes and volcanic activity; extremely suscepti-
ble to hurricanes
volcanism: significant volcanic activity; San
Salvador (elev. 1,893 m), which last erupted in
1917, has the potential to cause major harm to
* the country’s capital, which lies just below the vol-
cano’s slopes; San Miguel (elev. 2,130 m), which
last erupted in 2002, is one of the most active
volcanoes in the country; other historically active
volcanoes include Conchaguita, Ilopango, Izalco,
and Santa Ana
Environment—current issues: deforestation;
soil erosion; water pollution; contamination of
soils from disposal of toxic wastes
Environment—international agreements:
party to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Endan-
gered Species, Hazardous Wastes, Ozone Layer
Protection, Wetlands s z
signed, but not ratified: Law of the Sea
Geography—note: smallest Central American
country and only one without a coastline on Car-
ibbean Sea
Location: Central America, bordering the North
Pacific Ocean, between El Salvador and Mexico,
and bordering the Gulf of Honduras (Caribbean
Sea) between Honduras and Belize
Geographic coordinates: 15 30 N, 90 15 W
Map references: Central America and the
Caribbean
Area: total: 108,889 sq km
country comparison to the world: 107
land: 107,159 sq km
water: 1,730 sq km
Area—comparative:
Tennessee
Land boundaries: total: 1,687 km
border countries: Belize 266 km, El Salvador
203 km, Honduras 256 km, Mexico 962 km
Coastline: 400 km
Maritime claims: territorial sea: 12 nm
slightly smaller than
_ exclusive economic zone: 200 nm
continental shelf: 200 m depth or to the depth of
exploitation
Climate: tropical; hot, humid in low lands; cooler
in highlands
Terrain: mostly mountains with narrow coastal
plains and rolling limestone plateau
Elevation extremes: lowest point: Pacific Ocean
Om
highest point: Volcan Tajumulco 4,211 m
note: highest point in Central America
Natural resources: petroleum, nickel, rare woods,
fish, chicle, hydropower
Land use: arable land: 13.78%
permanent crops: 8.68%
other: 77.55% (2011)
Irrigated land: 3,121 sq km (2003)
Total renewable water resources: 111.3 cukm
(2011)
Freshwater withdrawal (domestic/indus-
triaV/agricultural): total: 3.46 cu km/yr
(15%/31%/54%)
per capita: 259.1 cu m/yr (2006)
Natural hazards: numerous volcanoes in moun-
tains, with occasional violent earthquakes; Carib-
bean coast extremely susceptible to hurricanes and
other tropical storms
299
volcanism: significant volcanic activity in the
Sierra Madre range; Santa Maria (elev. 3,772
m) has been deemed a “Detade Volcano” by the
International Association of Volcanology and
Chemistry of the Earth’s Interior, worthy of study
due to its explosive history and close proximity to
human populations; Pacaya (elev. 2,552 m), which
erupted in May 2010 causing an ashfall on Gua-
temala City and prompting evacuations, is one of
the country’s most active volcanoes with frequent
eruptions since 1965; other historically active vol-
canoes include Acatenango, Almolonga, Atitlan,
Fuego, and Tacana
Environment—current issues: deforestation in
the Peten rainforest; soil erosion; water pollution
Environment—international agreements:
party to: Antarctic Treaty, Biodiversity, Climate
Change, ‘Climate Change-Kyoto Protocol, Deser-
tification, Endangered Species, Environmental
Modification, Hazardous Wastes, Law of the Sea,
Marine Dumping, Ozone Layer Protection, Ship
Pollution, Wetlands, Whaling
signed, but not ratified: none of the selected
agreements
Geography—note: no natural harbors on west
coast','7de90dd30ec69942fabe328af4a420feb29d4b19233689d6631b8bbe3c06afc0','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cdbd70ae5e5ce51b3ec1c2f79e7d4529adadb04c00d5494b39774db2bcd30c52',2025,'GQ','Equatorial Guinea','geography',570,'Location: Eastern Africa, bordering the Red Sea,
between Djibouti and Sudan
Geographic coordinates: 15 00 N, 39 00 E
Map references: Africa
226
Area: total: 117,600 sq km
country comparison to the world: 101
land: 101,000 sq km
water: 16,600 sq km
Area—comparative:
Pennsylvania
Land boundaries: total: 1,626 km
border countries: Djibouti 109 km, Ethiopia 912
km, Sudari 605 km
Coastline: 2,234 km (mainland on Red Sea 1,151
km, islands in Red Sea 1,083 km)
Maritime claims: territorial sea: 12 nm
Climate: hot, dry desert strip along Red Sea coast;
cooler and wetter in the central highlands (up to
61 cm of rainfall annually, heaviest June to Sep-
tember); semiarid in western hills and low lands
slightly larger chan
Terrain: dominated by extension of Ethiopian
north-south trending highlands, descending on
the east to a coastal desert plain, on the northwest
to hilly terrain and on the southwest to flat-to-
rolling plains
Elevation extremes: lowest point: near Kulul
within the Danakil Depression-75 m
highest point: Soira 3,018 m
Natural resources: gold, potash, zinc, copper,
salt, possibly oil and natural gas, fish
Land use: arable land: 5.87%
permanent crops: 0.02%
other: 94.12% (2011)
irrigated land: 215.9 sq km (2003)
Total renewable water resources: 6.3 cu km
(2011)
Freshwater withdrawal (domestic/industrial/
agricultural): total:0.58 cu km/yr (5%/0%/95%)
per capita: 121.3 cu m/yr (2004)
Natural hazards: frequent droughts, rare earth-
quakes and volcanoes; locust swarms
volcanism: Dubbi (elev. 1,625 m), which last
erupted in 1861, was the country’s only historically
active volcano until Nabro (2,218 m) came to life
on 12 June 2011
Environment—current issues: deforestation;
desertification; soil erosion; overgrazing; ‘loss of
infrastructure from civil warfare
Environment—international agreements: party
to: Biodiversity, Climate Change, Climate Change-
Kyoto Protocol, Desertification, Endangered Spe-
cies, Hazardous Wastes, Ozone Layer Protection
signed, but not ratified: none of the selected
agreements
Geography—note: strategic geopolitical posi-
tion along world’s busiest shipping lanes; Eritrea
retained the entire coastline of Ethiopia along the
Red Sea upon de jure independence from Ethiopia
on 24 May 1993','3b2dd2b8ea3614f5307be0e508427325d800153ef6d79230a9a0227bad5af6c2','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('82c4ae761ce838d0fb63008c2017d7b15d115c83ded7c5f7bef440ad2f90bed1',2025,'ER','Eritrea','geography',578,'Location: Eastern Europe, bordering the Baltic Sea
and Gulf of Finland, between Latvia and Russia
Geographic coordinates: 59 00 N, 26 00 E
Map references: Europe
« Area: total: 45,228 sq km
country comparison to the world: 133
land: 42,388 sq km
water: 2,840 sq km
note: includes 1,520 islands in the Baltic Sea
Area—comparotive: slightly smaller than New
Hampshire and Vermont combined
Land boundaries: toral: 633 km
border countries: Latvia 343 km, Russia 290 km
Coastline: 3,794 km
Maritime claims: territorial sea; 12 nm
exclusive economic zone: limits fixed in coordi-
nation with neighboring states
Climate: maritime; wet, moderate winters, cool
summers
Terrain: marshy, lowlands; flat in the north, hilly
in the south
Elevation extremes: lowest point: Baltic Sea O m
highest point: Suur Munamagi 318 m
Natural resources: oil shale, peat, rare earth ele-
ments, phosphorite, clay, limestone, sand, dolo-
mite, arable land, sea mud
Land use: arable land: 13.97%
permanent crops: 0.13%
other: 85.89% (2011)
Irrigated land: 4.58 sq km (2010)
Total renewable water resources: 12.81 cu km
(2011)
Freshwater withdrawal (domestic/industrial/
agricultural): total: 1.8 cu km/yr (3%/97%/0%)
per capita: 1,337 cu m/yr (2009)
Natural hazards: sometimes flooding occurs in
the spring
Environment—current issues: air polluted with
sulfur dioxide from oil-shale burning power plants
in northeast; however, the amount of pollutants
emitted to the air have fallen steadily, the emis-
sions of 2000 were 80% less than in 1980; the
amount of unpurified wastewater discharged to
water bodies in 2000 was 1/20 the level of 1980;
in connection with the start-up of new water puri-
fication plants, the pollution load of wastewater
decreased; Estonia has more than 1,400 natural
and manmade lakes, the smaller of which in agri-
cultural areas need to be monitored; coastal seawa-
ter is polluted in certain locations
Environment—international agreements:
party to: Air Pollution, Air Pollution-Nitrogen
Oxides, Air Pollution-Persistent Organic Pollut-
ants, Air Pollution-Sulfur 85, Air Pollution-Vola-
tile Organic Compounds, Antarctic Treaty, Biodi-
versity, Climate Change, Climate Change-Kyoto
Protocol, Endangered Species, Hazardous Wastes,
Law of the Sea, Ozone Layer Protection, Ship Pol-
lution, Wetlands
231
signed, but not ratified: none of the selected
agreements
Geography—nofe: the mainland terrain is flat,
boggy, and partly wooded; offshore lie more than
1,500 islands','4284a4fe65e07e66d952d76df44412c3e4f09ad1dffab4399d1ba6c162061c71','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('beb7208d3713d2843bccbcf064f5389ed5bf8b0796c6633e8442876ded54afe8',2025,'EE','Estonia','geography',588,'Location: Eastern Africa, west of Somalia
Geographic coordinates: 8 00 N, 38 00 E
Map references: Africa
Area: total: 1,104,300 sq km
country comparison to the world: 27
land: 1 million sq km
water: 104,300 sq km
Area—comparative: slightly less than twice the
size of Texas
Land boundaries: total: 5,328 km
border countries: Djibouti 349 km, Eritrea
912 km, Kenya 861 km, Somalia 1,600 km, South
Sudan 837 km, Sudan 769 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
Climate: tropical monsoon with wide topo-
graphic-induced variation
Terrain: high plateau with central mountain range
divided by Great Rift Valley','01895fd65b4b7540d73db9eda8e1a1f1066482e3bd92b6d43cb4438a20123a51','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6c9a5477325f90c907774a2e52669dbf90f843623034cd90503ba382be595386',2025,'ET','Ethiopia','geography',589,'Elevation extremes: lowest point: Danakil
Depression-125 m
highest point: Ras Dejen 4,533 m
Natural resources: small reserves of gold, plati-
num, copper, potash, natural gas, hydropower
Land use: arable land: 13.19%
permanent crops: 1.01%
other: 85.8% (2011)
Irrigated land: 2,896 sq km (2003)
Total renewable water resources: 122 cu km (2011)
Freshwater withdrawal (domestic/industrial/
agricultural): total: 5.56 cu km/yr (13%/1%/86%)
per capita: 80.5 cu m/yr (2005)
Natural hazards: geologically active Great Rift
Valley susceptible to earthquakes, volcanic erup-
tions; frequent droughts
volcanism: volcanic activity in the Great Rift
Valley; Erta Ale (elev. 613 m), which has caused
frequent lava flows in recent years, is the coun-
try’s most active volcano; Dabbahu became active
in 2005, causing évacuations; other historically
active volcanoes include Alayta, Dalaffilla, Dallol,
Dama Ali, Fentale, Kone, Manda Hararo, and
Manda-Inakir
Environmeni—current issues: deforestation;
overgrazing; soil erosion; desertification; water
shortages in some areas from water-intensive farm-
ing and poor management
Environment—international agreements:
party to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Endan-
gered Species, Hazardous Wastes, Ozone Layer
Protection
signed, but not ratified: Environmental Modifica-
tion, Law of the Sea
Geography—note: landlocked—entire coast-
line along the Red Sea was lost with the de jure
independence of Eritrea on 24 May 1993; the Blue
Nile, the chief headstream of the Nile by water
volume, rises in T’ana Hayk (Lake Tana) in north-
west Ethiopia; three major crops are believed to
have originated in Ethiopia: coffee, grain sorghum,
and castor bean
Location: Europe between the North Atlan-
tic Ocean in the west and Russia, Belarus, and
Ukraine to the east
Map references: Europe
Area: total: 4,324,782 sq km
Area—compaorative: less than one-half the size
of the US
Land boundaries: total: 12,440.8 km
border countries: Albania 282 km, Andorra 120.3
km, Belarus 1,050 km, Croatia 999 km, Holy See
3.2 km, Liechtenstein 34.9 km, Macedonia 394
km, Moldova 450 km, Monaco 4.4 km, Norway
2,348 km, Russia 2,257 km, San Marino 39 km,
Serbia 945 km, Switzerland 1,811 km, Turkey 446
km, Ukraine 1,257 km
note: data for European Continent only
Coastline: 65,992.9 km
Maritime claims: NA
Climate: cold temperate; potentially subarctic in
the north to temperate; mild wet winters; hot dry
summers in the south
Terrain: fairly flat along the Baltic and Atlantic
coast; mountainous in the central and southern
areas
Elevation extremes: lowest point: Lammefjord,
Denmark-7 m; Zuidplaspolder, Netherlands-7 m
highest point: Mont Blanc 4,807 m; note—situ-
ated on the border between France and Italy
Natural resources: iron ore, natural gas, petro-
leum, coal, copper, lead, zinc, bauxite, uranium,
potash, salt, hydropower, arable land, timber, fish
Land use: arable land: 24.91
permanent crops: 2.75
other: 72.34 (2011)
irrigated land: 154,539.82 sq km (2011 st.)
Total renewable water resources: 2,057.76 cu
km (2011)
Natural hazards: flooding along coasts; ava-
lanches in mountainous area; earthquakes in
the south; volcanic eruptions in Italy; periodic
droughts in Spain; ice floes in the Baltic
Environment—current issues: NA
Environment—international agreements: party
to: Air Pollution, Air Pollution-Nitrogen Oxides,
Air Pollution-Persistent Organic Pollutants, Air
Pollution-Sulphur 94, Antarctic-Marine Living
Resources, Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Hazard-
ous Wastes, Law of the Sea, Ozone Layer Protec-
tion, Tropical Timber 83, Tropical Timber 94
signed but not ratified: Air Pollution-Volatile
Organic Compounds
Location: Southern South America, islands in the
South Atlantic Ocean, east of southern Argentina
Geographic coordinates: 51 45 S, 59 00 W
Map references: South America
Area: total: 12,173 sq km
country comparison to the world: 165
land: 12,173 sq km
water: 0 sq km
note: includes the two main islands of East and
West Falkland and about 200 small islands
Area—comparative:
Connecticut
Land boundaries: 0 km
Coastline: 1,288 km
Maritime claims: territorial sea: 12 nm
continental shelf: 200 nm
exclusive fishing zone: 200 nm
slightly smaller than
Climate: cold marine;: strong westerly winds,
cloudy, humid; rain occurs on more than half of
days in year; average annual rainfall is 24 inches in
Stanley; occasional snow all year, except in Janu-
ary and February, but typically does not accumulate
Terrain: rocky, hilly, mountainous with some
boggy, undulating plains
Elevation extremes: lowest point: Atlantic
Ocean 0 m
244
highest point: Mount Usborne 705 m
Natural resources: fish, squid, wildlife, calcified
seaweed, sphagnum moss
Land use: arable land:0%
permanent crops: 0%
other: 100% (99% permanent pastures, 1% other)
(2011)
Irrigated land: NA
Natural hazards: strong winds persist throughout
the year
Environment—current issues: overfishing by
unlicensed vessels is a problem; reindeer were
introduced to the islands in 2001 for commercial
reasons; this is the only commercial reindeer herd
In the world unaffected by the 1986 Chornobyl
disaster
Geography—note: deeply indented coast provides
good natural harbors; short growing season
Location: Eastern Africa, bordering the Gulf of
Aden and the Indian Ocean, east of Ethiopia
Geographic coordinates: 10 00 N, 49 00 E
Map references: Africa
Area: total: 637,657 sq km
country comparison to the world: 44
land: 627,337 sq km
water: 10,320 sq km
Areo—comparative: slightly smaller than Texas
Land boundaries: total: 2,340 km
border countries: Djibouti 58 km, Ethiopia 1,600
km, Kenya 682 km
Coastline: 3,025 km
Maritime claims: territorial sea: 200 nm
Climate: principally desert; northeast monsoon
(December to February), moderate temperatures
in north and hot in south; southwest monsoon
(May to October), torrid in the north and hot in
the south, irregular rainfall, hot and humid periods
(tangambili) between monsoons
Terrain: mostly flat to undulating plateau rising to
hills in north
Elevation extremes: lowest point: Indian Ocean
Om ° r
highest point: Shimbiris 2,416 m
Natural resources: uranium and largely unex-
ploited reserves of iron ore, tin, gypsum, bauxite,
copper, salt, riatural gas, likely oil reserves +
Land use: arable land: 1.73%
permanent crops: 0.05%
other: 98.23% (2011)
Irrigated land: 2,000 sq km (2003)
Total renewable water resources: 14.7 cu km
(2011)
Freshwater withdrawal (domestic/industrial/
agricultural): total: 3.3 cu km/yr (0%/0%/99%)
per capita: 377.6 cu m/yr (2003)
Natural hazards: recurring droughts; frequent
dust storms over eastern plains in summer; floods
during rainy season
Environment—ourrent issues: famine; use of
contaminated water contributes to human health
problems; deforestation; overgrazing; soil erosion;
desertification
Environment—international agreements:
party to: Biodiversity, Desertification, Endangered
Species, Law of the Sea, Ozone Layer Protection
signed, but not ratified: none of the selected
agreements
Geography—note: strategic location on Hom
of Africa along southern approaches to Bab el
Mandeb and route through Red Sea and Suez
Canal','e4defef62a7b6471223d01b2bd39e073b53ea043ada70bf1356dd0a882ff756e','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('70d6bbc91d13e9ba007a6c9b554c1e4f2455c3a571266d59f933b77dc318b095',2025,'FJ','Fiji','geography',611,'Location: Northern Europe, bordering the Baltic
Sea, Gulf of Bothnia, and Gulf of Finland, between
Sweden and Russia
Geographic coordinates: 64 00 N, 26 00 E
Map references: Europe
Area: total: 338,145 sq km :
country comparison to the world: 65
land: 303,815 sq km
water: 34,330 sq km
Arec—comparative:
Montana
slightly smaller than
Land boundaries: total: 2,654 km
border countries: Norway 727 km, Sweden 614
km, Russia 1,313 km
Coastline: 1,250 km
Maritime claims: territorial sea: 12 nm (in the
Gulf of Finland—3 nm)
contiguous zone: 24 nm
exclusive fishing zone: 12 nm; extends to conti-
nental shelf boundary with Sweden
continental shelf: 200 m depth or to the depth of
exploitation
Climate: cold temperate; potentially sub arctic
but comparatively mild because of moderating
influence of the North Atlantic Current, Baltic
Sea, and more than 60,000 lakes
Terrain: mostly low, flat to rolling plains inter-
spersed with lakes and low hills
251
am
ba i AS
4
N
GWP 5
g
a
“Rovaniemi \\
„2 Kokkola r
:
Kuopiot *
iy
Jyvaskyla, vanai i
k! Pon ampere
sRauira
Wustkaupunki oe
Turk vovise,™
WO cn, a Brie
os “HELSINKI
BETONIA ds
Elevation extremes: lowest point: Baltic Sea 0 m
highest point: Halti (alternatively Haltia, Halti-
tunturi, Haltiarunturi) 1,328 m
Natural resources: timber, iron-ore, copper, lead,
zinc, chromite, nickel, gold, silver, limestone
Land use: arable land: 6.65%
permanent crops: 0.01%
other: 93.34% (2011)
Irrigated land: 685.8 sq km (2010)
Total renewable water resources: 110 cu km
(2011)
Freshwater withdrawal (domestic/industrial/
agricultural): total: 1.63 cu km/yr (25%/72%/3%)
per capita: 308.9 cu m/yr (2005)
Natural hazards: NA
Environment—current issues: air pollution from
manufacturing and power plants contributing to
acid rain; water pollution from industrial wastes,
agricultural chemicals; habitat loss threatens wild-
life populations
Environment—international agreements:
party to: Air Pollution, Air Pollution-Nitrogen
Oxides, Air Pollution-Persistent Organic Pollutants,
Air Pollution-Sulfur 85, Air Pollution-Sulfur 94, Air
Pollution- Volatile Organic Compounds, Antarctic-
Environmental Protocol, Antarctic-Marine Living
Resources, Antarctic Treaty, Biodiversity, Climate
Change, Climate Change-Kyoto Protocol, Deserti-
fication, Endangered Species, Environmental Modi-
fication, Hazardous Wastes, Law of the Sea, Marine
Dumping, Marine Life Conservation, Ozone Layer
Protection, Ship Pollution, Tropical Timber 83,
Tropical Timber 94, Wetlands, Whaling
signed, but not ratified: none of the selected
agreements
252
THE CIA WORLD FACTBOOK
Geography—note: long boundary with Russia;
Helsinki is northernmost national capital on Euro-
pean continent; population concentrated on small
southwestern coastal plain','85869b59f67e286fdc468a9be6626d2d8a1e06864248caa0bb2df9d125e670e4','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d27e74dcebb39403e7d0ee04f6ab5a98e38c60c5b70cc1f4014ff70caf92919d',2025,'FI','Finland','geography',618,'Location: metropolitan France: Western Europe,
bordering the Bay of Biscay and English Channel,
between Belgium and Spain, southeast of the UK;
bordering the Mediterranean Sea, between Italy
and Spain
French Guiana: Northern South America, bor-
dering the North Atlantic Ocean, between Brazil
and Suriname
Guadeloupe: Caribbean, islands between the Car-
ibbean Sea and the North Atlantic Ocean, south-
east of Puerto Rico
Martinique: Caribbean, island between the Car-
ibbean Sea and North Atlantic Ocean, north of','608d6690d9360c0ae05cd70483bcd91b45bf0d7cf09c48899a1de2c25eb39761','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f1e28bacdcab065ccb97e327eda0d4a6fa66ec0af154981f92075e7e00da6fb2',2025,'TT','Trinidad and Tobago','geography',619,'Mayotte: Southern Indian Ocean, island in the
Mozambique Channel, about half way between
northern Madagascar and northern Mozambique
Reunion: Southern Africa, island in the Indian
Ocean, east of Madagascar
Geographic coordinates: metropolitan France:
4600N,200E
French Guiana: 4 00 N, 53 00 W
Guadeloupe: 16 15 N, 61 35 W
Martinique: 1 4 40 N, 61 00 W
‘Mayotte: 12 50 S, 45 10 E
Reunion: 21 06 S, 55 36 E
Map references: metropolitan France: Europe
French Guiana: South America
Guadeloupe: Central America and the Caribbean
Martinique: Central America and the Caribbean
Mayotte: Africa
Reunion: World
Area: total: 643,801 sq km; 551,500 sq km (met-
ropolitan France)
country comparison to the world: 43
land: 640,427 sq km; 549,970 sq km (metropolitan
France)
water: 3,374 sq km; 1,530 sq km (metropolitan
France)
note: the first numbers include the overseas
regions of French Guiana, Guadeloupe, Marti-
nique, Mayotte, and Reunion
Area—comparative: slightly less than the size of
Texas
Lond boundaries: metropolitan France—total:
2,889 km
border countries: Andorra 56.6 km, Belgium 620
km, Germany 451 km, Italy 488 km, Luxembourg
73 km, Monaco 4.4 km, Spain 623 km, Switzer-
land 573 km
French Guiana—total: 1,183 km
border countries: Brazil 673 km, Suriname 510
km
Coastline: total: 4,853 km
metropolitan France: 3,427 km
Maritime claims: territorial sea: 12 nm contigu-
ous zone: 24 nm
exclusive economic zone: 200 nm (does not apply
to the Mediterranean)
continental shelf: 200 m depth or to the depth of
exploitation
Climate: metropolitan France: generally cool
winters and mild summers, but mild winters and
hot summers along the Mediterranean; occasional
255
strong, cold, dry, north-to-northwesterly wind
known as mistral
French Gulana: tropical; hot, humid; little sea-
sonal temperature variation
Guadeloupe and Martinique: subtropical tem-
pered by trade winds; moderately high humidity;
rainy season (June to October); vulnerable to dev-
astating cyclones (hurricanes) every eight years on
average
Mayotte: tropical; marine; hot, humid, rainy sea-
son during northeastern monsoon (November to
May); dry season is cooler (May to November)
Reunion: tropical, but temperature moderates
with elevation; cool and dry (May to November),
hot and rainy (November to April)
Terrain: metropolitan France: mostly flat plains
or gently rolling hills in north and west; remain-
der is mountainous, especially Pyrenees in south,
Alps in east 7
French Guiana: low-lying coastal plains rising to
hills and small mountains
Guadeloupe: Basse-Terre is volcanic in origin
with interior mountains; Grande-Terre is low lime-
stone formation; most of the seven other islands
are volcanic in origin
Martinique: mountainous with indented coast-
line; dormant volcano a
Mayotte: generally undulating, with deep ravines
and ancient volcanic peaks
Reunion: mostly rugged and mountainous; fertile
low lands along coast
Elevation extremes: lowest point: Rhone River
delta-2 m
highest point: Mont Blanc 4,807 m
note: in order to assess the possible effects of oli-
mate change on the ice and snow cap of Mont
Blanc, its surface and peak have been extensively
measured in recent years; these new peak meas-
urements have exceeded the traditional height
of 4,807 m and have varied between 4,808 m and
4,811 m; the actual rock summit is 4,792 m and is
40 m away from the ice-covered summit
Natural resources: metropolitan France: coal,
iron ore, bauxite, zinc, uranium, antimony, arse-
hic, potash, feldspar, fluorspar, gypsum, timber, fish
French Guiana: gold deposits, petroleum, kaolin,
niobium, tantalum, clay
Land use: arable land: 33.45%
permanent crops: 1.86% other: 64.69%
note: French Guiana—arable land 0.13%, perma-
nent crops 0.04%, other 99.83% (90% forest, 10%
other); Guadeloupe—arable land 11.70%, perma-
nent crops 2.92%, other 85.38%; Martinique—
arable land 9.09%, permanent crops 10.0%, other
80.91%; Reunion—arable land 13.94%, perma-
nent crops 1.59%, other 84.47% (2011)
Irrigated land: total: 26,420 sq km 26,950 sq km
metropolitan France: 27,230 sq km (2007)
Total renewable water resources: 211 cu km (2011)
Freshwater withdrawal (domestic/indus-
trlal/agricultural): total: 31.62 cu km/yr
(19%/71%/10%)
per capita: 512.1 cu m/yr (2009)
Natural hazards: metropolitan France: flooding;
avalanches; midwinter windstorms; drought; forest
fires in south near the Mediterranean
overseas departments: hurricanes (cyclones);
flooding; volcanic activity (Guadeloupe, Marti-
nique, Reunion)
256
THE CIA WORLD FACTBOOK
Environment—current issues: some forest dam-
age from acid rain; air pollution from industrial
and vehicle emissions; water pollution from urban
wastes, agricultural runoff
Environment—international agreements:
party to: Air Pollution, Air Pollution-Nitrogen
Oxides, Air Pollution-Persistent Organic Pollut-
ants, Air Pollution-Sulfur 85, Air Pollution-Sulfur
94, Air Pollution-Volatile Organic Compounds,
Antarctic-Environmental Protocol, Antarctic-
Marine Living Resources, Antarctic Seals, Ant-
arctic Treaty, Biodiversity, Climate Change,
Climate Change-Kyoto Protocol, Desertification,
Endangered Species, Hazardous Wastes, Law of the
Sea, Marine Dumping, Marine Life Conservation,
Ozone Layer Protection, Ship Pollution, Tropical
Timber 83, Tropical Timber 94, Wetlands, Whal-
ing signed, but not ratified: none of the selected
agreements
Geography—note: largest West European nation
People and Society: FRANCE Nationality: noun:
Frenchman(men), Frenchwoman(women)
adjective: French
Ethnic groups: Celtic and Latin with Teutonic,
Slavic, North African, Indochinese, Basque
minorities overseas departments: black, white,
mulatto, East Indian, Chinese, Amerindian
Languages: French (official) 100%, rapidly
declining regional dialects and languages (Proven-
cal, Breton, Alsatian, Corsican, Catalan, Basque,
Flemish)
overseas departments: French, Creole patois,
Mahorian (a Swahili dialect)
Religions: Roman Catholic 83%-88%, Protestant
2%, Jewish 1%, Muslim 5%-10%, unaffiliated 4%
overseas departments: Roman Catholic, Protes-
tant, Hindu, Muslim, Buddhist, pagan
Population: 65,951,611 (July 2013 est.)
country comparison to the world: 21
note: the above figure is for metropolitan France
and five overseas regions; the metropolitan France
population is 62,814,233 :
Age structure: 0-14 years: 18.7% (male 6,314,779/
female 6,029,258)
15-24 years; 11.9% (male 4,017,893/female
3,840,268)
25-54 years: 38.9% (male 12,877,039/female
12,764,229)
55-64 years: 12.6% (male 4,020,974/female
4,287,381)
65 years and over: 17.9% (male 5,029,801/female
6,769,989) (2013 est.)
Median age: total: 40.6 years
male: 39.1 years
female: 42.1 years (2013 est.)
Population growth rate: 0.47% (2013 est.)
country comparison to the world: 152
Birth rate: 12.6 births/1,000 population (2013 est.)
country comparison to the world: 157
Death rate: 8.96 deaths/1,000 population (2013
est.)
country comparison to the world: 68
Net migration rate: migrant(s)/1,000 population
(2013 est.)
country comparison to the world: 54
Urbanization: urban population: 85% of total
population (2010)
rate of urbanization: 1% annual rate of change
(2010-15 est.)
Major urban areas—population: PARIS (capi-
tal) 10.41 million; Marseille-Aix-en-Provence
1.457 million; Lyon 1.456 million; Lille 028 mil-
lion; Nice-Cannes 977,000 (2009)
Sex ratio: ar birth: 1.05 male(s)/female
0-14 years: 1.05 male(s)/female
15-24 years: 1.05 male(s)/female
25-54 years: 1.01 male(s)/female
55-64 years: 0.94 male(s)/female
65 years and over: 0.74 male(s)/female
total population: 0.96 male(s)/female (2013 est.)
Maternal mortality rate: 8 deaths/100,000 live
births (2010)
country comparison to the world: 157
Infant mortality rate: total: 3.34 deaths/1,000
live births
country comparison to the world: 215 male: 3.67
deaths/1,000 live births female: 2.99 deaths/1,000
live births (2013 est.)
Life expectancy at birth: total population: 81.56
years
country comparison to the world: 15
male: 78.45 years
female: 84.82 years (2013 est.)
Total fertility rate: children born/woman (2013
est.)
country comparison to the world: 117
Health expenditures: 11.9% of GDP (2010)
country comparison to the world: 8
Physicians density: 3.5 physicians/1,000 popula-
tion (2008)
Hospital bed density: beds/1,000 population
(2009)
Drinking water source:
Improved:
urban: 100% of population
rural: 100% of population
total: 100% of population (2010 est.)
Sanitation facility access:
Improved:
urban: 100% of population
rural: 100% of population
total: 100% of population (2010 est.)
HIV/AIDS—adult prevalence rate: 0.4% (2009
est.)
country comparison to the world: 74
HIV/AIDS—peopie living with HIV/AIDS:
150,000(2009 est.)
country comparison to the world: 33
HIV/AIDS—deaths: 1,700 (2009 est.)
country comparison to the world: 56
Obesity—adult prevalence rate: 18.2% (2008)
country comparison to the world: 108
Education expenditures: 5.9% of GDP (2009)
country comparison to the world: 40
Literacy: definition: age 15 and over can read and
write total population: 99%
male: 99%
female: 99% (2003 est.)
School life expectancy (primary to tertiary
education): total: 16 years
male: 16 years. : 7
female: 16 years (2008)
Unemployment, youth ages 15-24: total:22.1%
country comparison to the world: 50
male: 21.2%
female: 23.2% (2011)
3, passenger 2, passenger/cargo 7, petroleum tanker
27, refrigerated cargo 4, roll on/roll off 4, special-
ized tanker 1
foreign-owned: 73 (Belgium 1, China 1, Egypt
1, Greece 2, India 2, Japan 2, Malaysia 1, Norway
3, Pakistan 1, Russia 13, Singapore 10, Turkey 18,
UAE 8, UK 1, Ukraine 8, US 1) (2010)
Ports and terminals: Basseterre, Charlestown
Geographic coordinates: 13 15 N, 61 12 W
Map references: Central America and the
Caribbean
Area: total: 389 sq km (Saint Vincent 344 sq km)
country comparison to the world: 204
land: 389 sq km
water: 0 sq km
Area—comparative: twice the size of Washing-
ton, DC
Land boundaries: 0 km
Coastline: 84 km
Maritime claims: territorial sea: 12 nm
contiguous zone: 24 nm
exclusive economic zone: 200 nm
continental shelf: 200 nm -
622
Climate: tropical; little seasonal temperature vari-
ation; rainy season (May to November)
Terrain: volcanic, mountainous
Elevation extremes: lowest point: Caribbean
Sea 0 m
highest point: La Soufriere 1,234 m
Natura! resources: hydropower, cropland
Land use: arable land: 12.82%
permanent crops: 7.69%
other: 79.49% (2011)
Irrigated land: 10 sq km (2003)
Freshwater withdrawal (domestic/industrial/
agricultural): total:0,01 cu’km/yr (NA)
per capita: 92.59 cu m/yr (1995)
Natural hazards: hurricanes; Soufriere volcano
on the island of Saint Vincent is a constant threat
Environment—current issues: pollution of
coastal waters and shorelines from discharges by
pleasure yachts and other effluents; in some areas,
pollution is severe enough to make swimming
prohibitive
Environment—international agreements:
party to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Endan-
gered Species, Environmental Modification, Haz-
ardous Wastes, Law of the Sea, Marine Dumping,
Ozone Layer Protection, Ship Pollution, Whal-
ing signed, but not ratified: none of the selected
agreements
Geography—note: the administration of the
islands of the Grenadines group is divided between
Saint Vincent and the Grenadines and Grenada;
Saint Vincent and the Grenadines is comprised of
32 islands and cays
PEOPLE ANDO SOCIETY
Nationality: noun: Saint
Vincentian(s)
adjective: Saint Vincentian or Vincentian
Ethnic groups: black 66%, mixed 19%, East
Indian 6%, European 4%, Carib Amerindian 2%,
other 3%
Languages: English, French patois
Religions: Protestant 75% (Anglican 47%, Methodist
28%), Roman Catholic 13%, other (includes Hindu,
Seventh-Day Adventist, other Protestant) 12%
Population: 103,220 (july 2013 est.)
country comparison to the world: 195
Vincentian(s) or
Age structure: 0-14 years 23.4% (male 12,179/
female 11.979) ` T
15-24 years: 17% (male 8,848/female 8,680)
25-54 years: 42.5% (male 22,777/female 21,067)
55-64 years 8.8% (male 4,627/female 4,412)
65 years and over: 8.4% (male 3,982/female
4,669) (2013 est.)
Median age: total: 31.3 years
male: 31.4 years
female: 31.2 years (2013 est.)
Population growth rate: -0.3% (2013 est.)
country comparison to the world: 217
Birth rate: 14.12 births/1,000 population (2013
est.)
country comparison to the world: 142
Death rate: 7.06 deaths/1,000 population (2013
est.)
country comparison to the world: 130
Net migration rate: -10.04 mierant(s)/1,000
population (2013 est.)
country comparison to the world: 210
Urbanization: urban population: 49% of total
population (2010)
rate of urbanization: 1% annual rate of change
(2010-15 est.)
Major urban areas—population: KINGS-
TOWN (capital) 28,000 (2009)
Sex ratio: at birth: 1.03 male(s)/female
0-14 years: 1.02 male(s)/female
15-24 years: 1.02 male(s)/female
25-54 years: 1.08 male(s)/female
55-64 years: 1.05 male(s)/female
65 years and over: 0.84 male(s)/female
total population: 1.03 male(s)/female (2013
est.)
Maternal mortality rate: 48 deaths/100,000 live
births (2010)
country comparison to the world: 109
Infant mortality rate: total: 13.46 deaths/1,000
live births
country comparison to the world: 124
male: 14.66 deaths/1,000 live births
female: 12.22 deaths/1,000 live births (2013
est.)
Life expectancy at birth: cotal population: 74.62
years
country comparison to the world: 108
male: 72.69 years
female: 76.62 years (2013 est.)
Total fertility ra te: 1.87 children born/woman
(2013 est.)
country comparison to the world: 144
Health expenditures: 4.5% of GDP (2010)
country comparison to the world: 154
‘Physicians density: 0.75 physicians/1,000 popu-
lation (2000) R ’
Hospital bed density: 2.6 beds/1,000 population
(2010) ‘ : as
Sanitation facility access:
Improved:
rural: 96%-of population
Unimproved:
rural: 4% of population (2010 est.)
HIV/AIDS—adult prevalence rate: NA
HIV/AIDS—people living with HIV/AIDS: NA
HIV/AIDS—deaths: NA
Obesity—adult prevalence rate: 23.4% (2008)
country comparison to the world: 75
Education expenditures: 5.1% of GDP (2010)
country comparison to the world: 69
Literacy: definition: age 15 and over has ever
attended school
total population: 96%
male: 96%
female: 96% (1970 est.)
School life expectancy (primary to tertiary
education): total: 13 years
male: 13 years
female: 13 years (2005)
Location: Caribbean, islands between the Carib-
bean Sea and the North Atlantic Ocean, north-
east of Venezuela
Geographic coordinates: 11 00 N, 61 00 W
Map references: Central America and the
Caribbean
Area: total: 5,128 sq km
country comparison to the world: 174
land: 5,128 sq km
water: 0 sq km
Area—comparative:
Delaware
Land boundaries: 0 km
Coastline: 362 km
Maritime claims; measured from claimed archi-
pelagic baselines
territorial sea: 12 nm
contiguous zone: 24 nm
exclusive economic zone: 200 nm
continental shelf: 200 nm or to the outer edge of
the continental margin
Climate:
December)
Terrain: mostly plains with some hills and low
mountains
Elevation extremes: lowest point: Caribbean
Sea 0 m
highest point: El Cerro del Aripo 940 m
Natural resources: petroleum, natural gas, asphalt
Land use: arable land: 4.87%
permanent crops: 4.29%
slightly smaller than
topical; rainy season (June to
other: 90.84% (2011)
Irrigated land: 36 sq km (2003)
Total renewable water resources: 3.84 cu km
(2011)
Freshwater withdrawal (domestic/industrial/
agricultural): coral: 0.23 cu km/yr (67%/25%/8%)
per capita: 177.9 eu m/yr (2005)
Natural hazards: outside usual path of hurricanes
and other tropical storms
Environment—current issues: water pollution
from agricultural chemicals, industrial wastes, and
raw sewage; oil pollution of beaches; deforestation;
soil erosion
Environment—international agreements:
party to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Endan-
gered Species, Hazardous Wastes, Law of the Sea,
Marine Dumping, Marine Life Conservation,
Ozone Layer Protection, Ship Pollution, Tropical
Timber 83, Tropical Timber 94, Wetlands
signed, but not ratified: none of the selected
agreements
Geography—note: Pitch Lake, on Trinidad’s
southwestern coast, is the world’s largest natural
reservoir of asphalt','52bff592588dd45966531044dcc462258bf4071492bbc8ee7bf4f315d615891e','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('11d51918defd0b35b85a700654e6894f5c0961303918987c5ef97338572b345e',2025,'MU','Mauritius','geography',636,'Location: Central Africa, bordering the Atlantic
Ocean at the Equator, between Republic of the
Congo and Equatorial Guinea
Geographic coordinates: 1 00 S, 11 45 E
Map references: Africa
Area: total: 267,667 sq km
country comparison to the world: 77
land: 257,667 sq km
water: 10,000 sq km
Area—comparative: slightly smaller than Colorado
Land boundaries: total: 2,551 km
border countries: Cameroon 298 km, Republic of
the Congo 1,903 km, Equatorial Guinea 350 km
Coastline: 885 km
Maritime claims: territorial sea: 12 nm
contiguous zone: 24 nm
exclusive economic zone: 200 nm
Climate: tropical; always hot, humid
Terrain: narrow coastal plain; hilly interior;
savanna in east and south
Elevation extremes: lowest point: Atlantic
Ocean 0 m :
highest point: Mont Iboundji 1,5/5 m
Natural resources: petroleum, natural gas, dia-
mond, niobium, manganese, uranium, gold, tim-
ber, iron ore, hydropower
Location: North America, bordering the Carib-
bean Sea and the Gulf of Mexico, between Belize
and the United States and bordering the North
Pacific Ocean, between Guatemala and the
United States A
Geographic coordinates: 23 00 N, 102 00 W
Mop references: North America
Area: total: 1,964,375 sq km
country comparison to the world: 14
land: 1,943,945 sq km
water: 20,430 sq km
=
Area—comparative: slightly less than three
times the size of Texas
Land boundaries: total: 4,353 km
border countries: Belize 250 km, Guatemala 962
km, US 3,141 km
Coastline: 9,330 km
Maritime claims: territorial sea:12 nm
contiguous zone: 24 nm exclisive economic zone:
200 nm
continental shelf: 200 nm or to the edge of the
continental margin
Climate: varies from tropical to desert
Terrain: high, rugged mountains; low coastal
plains; high plateaus; desert
Elevation extremes: lowest point: Laguna Salada
-10m
highest point: Volcan Pico de Orizaba 5,700 m
Natural resources: petroleum, silver, copper,
gold, lead,.zinc, natural gas, timber
Land use: arable land: 12.98%
permanent crops: 1.36%
other: 85.66% (2011)
Irrigated land: 64,600 sq km(2009)
Total renewable water resources: 457.2 cu km
(2011)
. Freshwater withdrawal (domestic/industrial/
agricultural): toral: 80.4 cu km/yr (14%/9%/77%)
per capita: 700.4 cu m/yr (2009)
Natural hazards: tsunamis along the Pacific
coast, volcanoes and destructive earthquakes
in the center and south, and hurricanes on the
Pacific, Gulf of Mexico, and Caribbean coasts
volcanism: volcanic activity in the central-southern
part of the country; the volcanoes in Baja California
are mostly dormant; Colima (elev. 3,850 m), which
erupted in 2010, is Mexico’s most active volcano
and is responsible for causing periodic evacuations of
nearby villagers; it has been deemed a “Decade Vol-
cano” by the International Association of Volcanol-
ogy and Chemistry of the Earth’s Interior, worthy of
study due to its explosive history and close proximity
to human populations; Popocatepetl (elev. 5,426
m) poses a threat to Mexico City; other historically
active volcanoes include Barcena, Ceboruco, El
Chichon, Michoacan-Guanajuato, Pico de Orizaba,
San Martin, Socorro, and Tacana
Environment—current issues: scarcity of haz-
ardous waste disposal facilities; rural to urban
migration; natural freshwater resources scarce and
polluted in north, inaccessible and poor quality
in center and extreme southeast; raw sewage and
industrial effluents polluting rivers in urban areas;
deforestation; widespread erosion; desertification;
deteriorating agricultural lands; serious air and
water pollution in the national capital and urban
centers along US-Mexico border; land subsid-
ence in Valley of Mexico caused by groundwater
depletion
note: the government considers the lack of clean
water and deforestation national security issues
Environment—international agreements:
party to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Endan-
gered Species, Hazardous Wastes, Law of the Sea,
Marine Dumping, Marine Life Conservation,
Ozone Layer Protection, Ship Pollution, Wet-
lands, Whaling
signed, but not ratified: none of the selected
agreements . *','0a27c72774bdedcc11c3ba640db551f9ba8d214ecc1b265c0756dd914f6abf69','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('773d933167e24fc8a48aa0bbc85798ad973ea920c61467601bd12a6389a10b1b',2025,'GA','Gabon','geography',637,'Land use: arable land: 1.21%
permanent crops: 0.64%
other: 98.15% (2011)
Irrigated land: 44.5 sq km (2003)
Total renewable water resources: 164 cu kin
(2011)
Freshwater withdrawal = (domestic/indus-
triaVagricultural): total: 0.14 cu km/yr
(61%/10%/29%)
per capita: 97.68 cu m/yr (2005)
Natural hazards: NA
Environment—current
poaching _
Environment—international agreements:
party to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Endan-
gered Species, Hazardous Wastes, Law of the Sea,
Marine Dumping, Ozone Layer Protection, Ship
Pollution, Tropical Timber 83, Tropical Timber 94,
Wetlands, Whaling
signed, but not ratified: none of the selected
agreements
Geography—note: a small population and oil and
mineral reserves have helped Gabon become one
of Africa’s wealthier countries; in general, these
circumstances have allowed the country to main-
tain and conserve its pristine rain forest and rich
biodiversity','a0d92b2e5e5ec8a2f8b6716cddd8365f17a4f80442b9da6a61607d55d254d27e','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f6b97ef4c4fce2c830e6442afdce5bac0d4b755d2420d4455ecf72f3babc6e52',2025,'SN','Senegal','geography',647,''' Location: Western Africa, bordering the North
Atlantic Ocean and Senegal
Geographic coordinates: 1328 N, 1634 W
Map references: Africa
Area: total: 11,295 sq km
country comparison to the world: 167
land: 10,000 sq km
water: 1,295 sq km
Area—comparative: slightly less than twice the
size of Delaware
Land boundaries: total: 740 km
border countries: Senegal 740 km
268
Coastline: 80 km
Maritime claims: territorial sea:12 nm ,
contiguous zone: 18 nm
exclusive fishing zone: 200 nm
continental shelf: extent not specified
Climate: tropical; hot, rainy season’ (June to
November); cooler, dry season (November to
May)
Terrain: flood plain of the Gambia River flanked
by some low hills
Elevation extremes: lowest point: Atlantic
Ocean 0 m
highest point: unnamed elevation 53 m
Natural resources: fish, clay, silica sand, titanium
(rutile and ilmenite), tin, zircon
Land use: arable land: 39.82%
permanent crops: 0.44%
other: 59.73% (2011)
Irrigated land: 50 sq km (2011)
Total renewable woter resources: 8 cu km
(2011)
Freshwater withdrawal (domestic/indus-
trial/agricultural): total: 0.09 cu km/yr
(41%/21%/39%)
per capita: 65.77 cu m/yr (2005)
Natural hazards: drought (rainfall has dropped by
30% in the last 30 years) f
Environment—current issues: deforestation;
desertification; water-borne diseases prevalent
Environment—international agreements:
party to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Endan-
gered Species, Hazardous Wastes, Law of the Sea,
Ozone Layer Protection, Ship Pollution, Wet-
lands, Whaling ae
signed, but not ratified: none of the selected
agreements
Geography—note: almost an enclave of Senegal;
smallest country on the continent of Africa
Location: Middle East, bordering the Mediterra-
nean Sea, between Egypt and Israel
Geographic coordinates: 31 25 N, 34 20 E
Map references: Middle East
Area: total: 360 sq km
country comparison to the world: 206
land: 360 sq km
water: 0 sq km
Area—comparative: slightly more than twice the
size of Washington, DC
Land boundaries: total: 62 km
border countries: Egypt 11 km, Israel 51 km
Coastline: 40 km
Maritime claims: see entry for Israel
note: effective 3 January 2009 the Gaza maritime
area is closed to all maritime traffic and is under
blockade imposed by Israeli Navy until further
notice
Climate: temperate, mild winters, dry and warm
to hot summers
Terrain: flat to rolling, sand-and-dune-covered
coastal plain
Elevation extremes: lowest point: Mediterra-
nean Sea 0 m
highest point: Abu ‘Awdah (Joz Abu ‘Awdah)
105 m
Natural resources: arable land, natural gas
Land use: arable land: 7.39%
permanent crops: 10.96%
other: 81.64% (2011)
Irrigated land: 240 sq km; note—includes West
Bank (2003)
Notural hazards: droughts
Environment—current issues: desertification;
salination of fresh water; sew age treatment; water-
borne disease; soil degradation; depletion and con-
tamination of underground water resources
271
Geography—note: strategic strip of land along
Mideast-North African trade routes has experi-
enced an incredibly turbulent history; the town
of Gaza itself has been besieged countless times in
its history
Location: Southwestern Asia, bordering the Black
Sea, between Turkey and Russia, with a sliver of
land north of the Caucasus extending into Europe;
note—Georgia views itself as part of Europe
Geographic coordinates: 42 00 N, 43 30 E
Map references: Middle East
Area: total: 69,700 sq km
country comparison to the world: 121
land: 69,700 sq km
water: 0 sq km
Area—comparative: slightly smaller than South
Carolina
Land boundaries: total: 1,461 km
border countries: Armenia 164 km, Azerbaijan
322 km, Russia 723 km, Turkey 252 km
Coastline: 310 km
Maritime claims: territorial sea: 12 nm
exclusive economic zone: 200 nm
Climate: warm and pleasant; Mediterranean-like
on Black Sea coast
Terrain: largely mountainous with Great Cau-
casus Mountains in the north and Lesser Cauca-
sus Mountains in the south; Kolkhet’is Dablobi
(Kolkhida Lowland) opens to the Black Sea in the
west; Mrkvari River Basin in the east; good soils','3a081479f801232bfe9f036eae57738693dfe4c413f373923a53b493ade93afb','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('688bda0a6a8105dc475c7a950cad406c4441432ff937f3d38bd9f2ea350bb3ac',2025,'GE','Georgia','geography',661,'Location: Central Europe, bordering the Baltic
Sea and the North Sea, between the Netherlands
and Poland, south of Denmark
Geographic coordinates: 51 00 N, 9 00 E
Military expenditures: 1.9% of GDP (2010
est.)
country comparison to the world: 75','a6c33eafb04c0aacca6a244a48a5309ab32c4cdb085d450442ad30fab2e8d34f','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c10bcc365b9322dfdeb72ce2c996eeb4ee9ac1d790afaed9e5ad639c8d9039ef',2025,'DE','Germany','geography',671,'Location: Western Africa, bordering the Gulf of
Guinea, between Cote d''lvoire and Togo
Geographic coordinates: 8 00 N, 2 00 W
Map references: Africa
Area: total: 238,533 sq km
country comparison to the world: 82
land: 227,533 sq km
water: 11,000 sq km
Area—comparative:
Oregon
Land boundaries: total: 2,094 km
border countries: Burkina Faso 549 km, Cote
d''Ivoire 668 km, Togo 877 km
Coastline: 539 km
Maritime claims: territorial sea: 12 nm
contiguous zone: 24 nm
exclusive economic zone: 200 nm
continental shelf: 200 nm
slightly smaller
Climate: tropical; warm and comparatively dry
along southeast coast; hot and humid in southwest;
hot and dry in north
Terrain: mostly low plains with dissected plateau
in south-central area
Elevation extremes: lowest point: Atlantic
Ocean 0 m
highest point: Mount Afadjato 885 m
Natural resources: gold, timber, industrial dia-
monds, bauxite, manganese, fish, rubber, hydro-
power, petroleum, silver, salt, limestone
Land use: arable land: 20.12%
permanent crops: 11.74%
other: 68.14% (2011)
Irrigated land: 309 sq km (2003)
Total renewable water resources: 53.2 cu km
(2011)
Freshwater withdrawal (domestic/indus-
triaVagricultural): rotal: 0.98 cu km/yr
(24%/10%/66%)
per capita: 48.82 cu mfyr (2000)
Natural hazards: dry, dusty, northeastern harmat-
tan winds from January to March; droughts
Environment—current issues: recurrent drought
in north severely affects agricultural activities;
deforestation; overgrazing; soil erosion; poaching
and habitat destruction threatens wildlife popu-
lations; water pollution; inadequate supplies of
potable water
Environment—intemational agreements:
party to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Endan-
gered Species, Environmental Modification,
Hazardous Wastes. Law of the Sea, Ozone Layer
Protection, Ship Pollution, Tropical Timber 83,
Tropical Timber 94, Wetlands
signed, but not ratified: Marine Life Conservation
Geography—note: Lake Volta is the world’s larg-
est artificial lake by surface area (8,482 sq km;
3,275 sq mi)
Geographic coordinates: 49 45 N, 6 10 E
Map references: Europe
Area: total: 2,586 sq km
country comparison to the world: 179
land: 2,586 sq km
water: 0 sq km
Area—compoarative: slightly smaller than Rhode
Island
Land boundaries: total: 359 km
border countries: Belgium 148 km, France 73 km,
Germany 138 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
Climate: modified continental with mild winters,
cool summers m','31e5f569431ef88ec307297ed7396205a4d78f4f892a4f7856d5fccd4ca67b8b','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('03a2c98aa9f04c244e9671f2b944ce1513ebd61b0d7277c63042497e889f9cf4',2025,'GR','Greece','geography',692,'Location: Southern Europe, bordering the Aegean
Sea, Ionian Sea, and the Mediterranean Sea,
between Albania and Turkey
Geographic coordinates: 39 00 N, 22 00 E
Map references: Europe
Area: total: 131,957 sq km
country comparison to the world: 97
land: 130,647 sq km
water: 1,310 sq km
Area—comparative:
Alabama
Land boundaries: total: 1,228 km
border countries: Albania 282 km, Bulgaria 494
km, Turkey 206 km, Macedonia 246 km
Coastline: 13,676 km
Maritime claims: territorial sea: 12 nm
continental shelf: 200 m depth or to the depth of
exploitation
Climate: temperate; mild, wet winters; hot, dry
summers
slightly smaller than
Terrain: mostly mountains with ranges extending
into the sea as peninsulas or chains of islands
Elevation extremes: lowest point: Mediterra-
nean Sea 0 m
highest point: Mount Olympus 2,917 m
Natural resources: lignite, petroleum, iron ore,
bauxite, lead, zinc, nickel, magnesite, marble, salt,
hydropower potential
Land use: arable land: 18.95%
permanent crops: 8.73%
other: 72.32% (2011)
Irrigated land: 15,550 sq km (2007)
Total renewable water resources: 74.25 cu km
(2011)
Freshwater withdrawal (domestic/industrial/
agricultural): total:9.47 cu km/yr (9%/2%/89%)
per capita: 841.4 cu m/yr (2007)
Natural hazards: severe earthquakes
volcanism: Santorini (elev. 367 m) has been
deemed a “Decade Volcano” by the International
Association of Volcanology and Chemistry of the
Earth''s Interior, worthy of study due to its explo-
sive history and close proximity to human popula-
tions; although there have been very few eruptions
in recent centuries, Methana and Nisyros in the
Aegean are classified as historically active
Environmeni—current issues: air pollution;
water pollution
Environment—international agreements:
party to: Air Pollution, Air Pollution-Nitrogen
Oxides, Air Pollution-Sulfur 94, Antarctic-Envi-
ronmental Protocol, Antarctic-Marine Living
Resources, Antarctic Treaty, Biodiversity, Climate
Change, Climate Change-Kyoto Protocol, Deser-
tification, Endangered Species, Environmental
Modification, Hazardous Wastes, Law of the Sea,
Marine Dumping, Ozone Layer Protection, Ship
287
Pollution, Tropical Timber 83, Tropical Timber
94, Wetlands
signed, but not ratified: Air Pollution-Persis-
tent Organic Pollutants, Air Pollution-Volatile
Organic Compounds
Geography—note: strategic location dominating
the Aegean Sea and southern approach to Turkish
Straits; a peninsular country, possessing an archi-
pelago of about 2,000 islands
Location: Northern North America, island
between the Arctic Ocean and the North Atlantic
Ocean, northeast of Canada
Geographic coordinates: 72 00 N, 40 00 W
Map references: North America
Area: total: 2,166,086 sq km
country comparison to the world: 12 land:
2,166,086 sq km (410,449 sq km ice-free,
1,755,637 sq km ice-covered)
Manpower available for military service:
males age 16-49: 2,485,389
females age 16-49: 2,469,854 (2010 est.)
Manpower fit for military service: males age
16-49; 2,032,378
females age 16-49: 2,016,552 (2010 est.)
Manpower reaching militarily significant age
annually: male: 52,754
female: 49,485 (2010 est.)
Military expenditures; 4.3% of GDP (2005 est.)
country comparison to the world: 21','cd1e835031318eb79ad66956dcdc9865293209868d18c574f4022c3317cf532c','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a56de5844333de058ea00469e0026a8a1b815de0e34780a0da2c6c1382b33e9a',2025,'GD','Grenada','geography',712,'Location: Oceania, island in the North Pacific
Ocean, about three-quarters of the way from
Hawaii to the Philippines
Geographic coordinates: 13 28 N, 144 47 E
Map references: Oceania
Area: rotal:544 sq km
country comparison to the world: 195
land: 544 sq km
water: 0 sq km
Area—comporative: three times the size of
Washington, DC
Land boundaries: 0 km
Coastline: 125.5 km
Maritime claims: territorial sea: 12 nm
exclusive economic zone: 200 nm
Climate: tropical marine; generally warm and
humid, moderated by northeast trade winds; dry
season (Januaty to June), rainy season (July to
December); little seasonal temperature variation
Terrain: volcanic origin, surrounded by coral reefs;
relatively flat coralline limestone plateau (source
of most fresh water), with steep coastal cliffs and
narrow coastal plains in north, low hills in center,
mountains in south
Elevation extremes: lowest point: Pacific Ocean
Om
highest point: Mount Lamlam 406 m
Natural resources: aquatic wildlife (supporting
tourism), fishing (largely undeveloped)
Land use: arable land: 1.85%
permanent crops: 16.67%
other: 81.48% (2011)
Irrigated land: 2 sq km (2011)
Natural hazards: frequent squalls during rainy
season; relatively rare but potentially destructive
typhoons (June to December)
Environment—current issues: extirpation of
native bird population by the rapid proliferation
of the brown tree snake, an exotic, invasive species
Geography—note: largest and southernmost
island in the Mariana Islands archipelago; strategic
location in western North Pacific Ocean','128b4d2d41a662728b704967f7afb1d4a0e1bdfb3089b7d8af8a99135d76e2f9','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8a0ce3f8b5c2e6d84f0faf0e5d43280a35fc394840c9a2dff41152891d8d56bb',2025,'GG','Guernsey','geography',720,'Location: Western Europe, islands in the English
Channel, northwest of France
Geographic coordinates: 49 28 N, 2 35 W
Map references: Europe
Area: total: 78 sq km
country comparison to the world: 228
land: 78 sq km
water: 0 sq km
note: includes Alderney, Guernsey, Herm, Sark,
and some other smaller islands
Arec—comparative: about one-half the size of
Washington, DC
Land boundaries: 0 km
Coastline: 49 km
Maritime claims: territorial sea: 3 nm
exclusive fishing zone: 12 nm
Climate: temperate with mild winters and cool
summers; about 50% of days are overcast
Terrain: mostly level with low hills in southwest
Elevation extremes: lowest point: Atlantic
Ocean 0m
highest point: unnamed elevation on Sark 114 m
Natural resources: cropland
Land use: arable land: NA
permanent crops: NA
other: NA
Irrigated land: NA
Natural hazards: NA
Environment—current issues: NA
Geography—note: large, deepwater harbor at
Saint Peter Port
Location: Western Africa, bordering the North
Atlantic Ocean, between Guinea-Bissau and','fbfdd2c4afbf556247e6b47be0a53dac02e6ca8332f418830a3d92efba483739','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b6c3379f69abb38d585309454da2b6ecaea4e0087178bd7dcf5dde90394a0249',2025,'SL','Sierra Leone','geography',726,'Geographic coordinates: 11 00 N, 1000 W
Map references: Africa
Area: total: 245,857 sq km
country comparison to the world: 79
land: 245,717 sq km
water: 140 sq km
Area—comparotive: slightly smaller than Oregon
Land boundaries: total: 3,399 km
border countries: Cote d''lvoire 610 km, Guinea-
Bissau 386 km, Liberia 563 km, Mali 858 km, Sen-
egal 330 km, Sierra Leone 652 km
Coastline: 320 km
Maritime claims: territorial sea: 12 nm
exclusive economic zone: 200 nm
Climate: generally hot and humid; monsoonal-
type rainy season (June to November) with south-
westerly winds; dry season (December to May)
with northeasterly harmattan winds
Terrain: generally flat coastal plain, hilly to moun-
tainous interior
Elevation extremes: lowest point: Atlantic
Ocean 0 m
highest point: Mont Nimba 1,752-m
Airports—with paved runways: toral:2
914 to 1,523 m: 1
under 914 m: 1 (2012)
Ports and terminals: Braye Bay, Saint Peter
Port
Location: Western Africa, bordering the North
Atlantic Ocean, between Guinea and Liberia
Geographic coordinates: 8 30 N, 11 30 W
Map references: Africa
Area: total: 71,740 sq km
country comparison to the world: 119
648
land: 71,620 sq km
water: 120 sq km
Area—comparative: slightly smaller than South
Carolina
Land boundaries: total:958 km
border countries: Guinea 652 km, Liberia 306 km
Coastline: 402 km
Maritime claims: territorial sea: 12 nm
contiguous zone: 24 nm exclusive
economic zone: 200 nm
continental shelf: 200 nm
Climate: tropical; hot, humid; summer rainy
season (May to December); winter dry season
(December to April)
Terrain: coastal belt of mangrove swamps, wooded
hill country, upland plateau, mountains in east
Elevation extremes: lowest point: Atlantic
Ocean 0 m
highest point: Loma Mansa (Bintimani) 1,948 m
Natural resources; diamonds, titanium ore, baux-
ite, iron ore, gold, chromite
Land use: arable land: 15.33%
permanent crops: 1.88%
other: 82.79% (2011)
Irrigated land: 293.6 sq km (2003)
Total renewable water resources: 160 cu km
(2011)
Freshwater withdrawal (domestic/indus-
trial/agricultural): total: 0.21 cu km/yr
(52%/26%/22%)
per capita: 38.74 cu m/yr (2005)
Natural hazards: dry, sand-laden harmattan
winds blow from the Sahara (December to Febru-
ary); sandstorms, dust storms
Environment—current issues: rapid population
growth pressuring the environment; overharvest-
ing of timber, expansion of cattle grazing, and
slash-and-burn agriculture have resulted in defor-
estation and soil exhaustion; civil war depleted
natural resources; overfishing
Environment—international agreements:
party to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Endan-
gered Species, Law of the Sea, Marine Life Con-
servation, Ozone Layer Protection, Ship Pollution,
Wetlands
signed, but not
Modification
Geography—note: rainfall along the coast can
reach 495 cm (195 inches) a year, making it one
ratified:
Environmental
of the wettest places along coastal, western Africa','4bc27c95fed5a8051b5f05eae08047da74f7c51188777228964ce3d3cac5ccce','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e17ec49552521fe3fcaa64e8ec5c41a4c4c192eb810c0d60a3f788c3fdf27924',2025,'GW','Guinea-Bissau','geography',739,'Location: Western Africa, bordering the North
Atlantic Ocean, between Guinea and Senegal
Geographic coordinates: 12 00 N, 15 00.W
Map references: Africa
Area: total: 36,125 sq km
country comparison to the world: 138
land: 28,120 sq km
_ water: 8,005 sq km
Area—comparotive: slightly less than three
times the size of Connecticut
Land boundaries: total: 724 km
border countries: Guinea 386 km, Senegal 338 km
Coastline: 350 km
Maritime claims: territorial sea: 12 nm
exclusive economic zone: 200 nm
Climate: tropical; generally hot and humid; mon-
soonal-type rainy season (June to November) with
southwesterly winds; dry season (December to
May) with northeasterly harmattan winds
Terrain: mostly low coastal plain rising to savanna
in east
Elevation extremes: lowest point: Atlantic
Ocean 0 m
highest point: unnamed elevation in the eastern
part of the country 300 m
Natural resources: fish, timber, phosphates,
bauxite, clay, granite, limestone, unexploited
deposits of petroleum
Land use: arable land:8.3%
permanent crops: 6.92%
other: 84.78% (2011)
Irrigated land: 225.6 sq km (2003)
Total renewable water resources: 3) cu km
(2011)
Freshwater withdrawal (domestic/industrial/
agricultural): cotal: 0.18 cu km/yr (18%/6%/76%)
per capita: 135.7 cu m/yr (2005)
Natural hazords: hot, dry, dusty harmattan haze
may reduce visibility during dry season; brush fires
Environment—current issues;
soil erosion; overgrazing; overfishing
Environment—international agreements:
party to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Endan-
gered Species, Hazardous Wastes, Law of the Sea,
Ozone Layer Protection, Wetlands
signed, but not ratified: none of the selected
agreements
Geography—note: this small country is swampy
along its western coast and low-lying inland','043356549e6dabe50fe33c440f8d769d6944c5899f01adfaef6dfc7b1278f98e','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('42831cc3ab6e5f1c69f91a4fa74c95d01d545dc047ef35d9cd5fac23441e502d',2025,'GY','Guyana','geography',748,'Location: Northern South America, bordering
the North Atlantic Ocean, between Suriname and
Venezuela
Geographic coordinates: 5 00 N, 59 00 W
Map references: South America
Area: total: 214,969 sq km
country comparison to the world: 85
land: 196,849 sq km
water: 18,120 sq km i
Area—comparative: slightly smaller than Idaho
Land boundaries: total: 2,949 km
border countries: Brazil 1,606 km, Suriname 600
km, Venezuela 743 km
Coastline: 459 km
Maritime claims: territorial sea: 12 nm
exclusive economic zone: 200 nm
continental shelf: 200 nm or to the outer edge of
the continental margin
Climate: tropical; hot, humid, moderated by
northeast trade winds; two rainy seasons (May to
August, November to January)
Location: Caribbean, western one-third of the
island of Hispaniola, between the Caribbean
Sea and the North Atlantic Ocean, west of the','cba4088902c2440b91638d911f5788cfcd8a38d4bfbc39ad1e789ba4a84d60bb','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('707f8c1b37d24dc81a90531457d0f14470decbbd31498b1ae735039e265762e5',2025,'HM','Heard Island and McDonald Islands','geography',764,'Location: islands in the Indian Ocean, about two-
thirds of the way from Madagascar to Antarctica
Geographic coordinates: 53 06S, 72 31 E
Map references: Antarctic Region
Area: total: 412 sq km
country comparison to the world: 203
land: 412 sqkm
water: 0 sq km
Area—comparative: slightly more than two
times the size of Washington, DC
Land boundaries: 0 km
Coastline: 101.9 km
Maritime claims: territorial sea: 12 nm
exclusive fishing zone: 200 nm
Climate: antarctic
Terrain: Heard Island—80% ice-covered, bleak
and mountainous, dominated by a large massif
(Big Ben) and an active volcano (Mawson Peak);
McDonald Islands—small and rocky
Elevation extremes: lowest point: Indian Ocean 0 m
319
highest poitit: Mawson Peak on Big Ben volcano
2,745 m
Natural resources: fish
Land use: arable land:0%
permanent crops: 0%
other: 100% (2011)
Irrigated land: 0 sq km (2011)
Natural hazards: Mawson Peak, an active vol-
cano, is on Heard Island
Environment—current issues: NA
Geography—note: Mawson Peak on Heard Island
is the highest Australian mountain (at 2,745
meters, it is taller than Mt. Kosciuszko in Australia
proper), and one of only two active volcanoes
located in Australian territory, the other being
McDonald Island; in 1992, McDonald Island broke
its dormancy and began erupting; it has erupted
several times since, most recently in 2005
Location: Southern Europe, an enclave of Rome
(Italy)
Geographic coordinates: 41 54 N, 12 27 E
Map references: Europe
Area: total: 0.44 sq km
country comparison to the world: 252
land: 0.44 sq km
water: 0 sq km
Area—comparative: about 0.7 times the size of
The National Mall in Washington, DC
Land boundaries: total: 3.2 km
border countries: Italy 3.2 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
Climate: temperate; mild, rainy winters (Sep-
tember to May) with hot, dry summers (May to
September)
Terrain: urban; low hill
Elevation extremes: lowest point: unnamed
location 19 m
highest point: unnamed elevation 75 m
Natural resources: none
Land use: arable land:
permanent crops: 0%
other: 100% (urban area) (2011)
Irrigated land: 0 sq km (2011)
Notural hazards: NA
Environment—current issues: NA
Environment—international
party to: Ozone Layer Protection
signed, but not ratified: Air Pollution, Environ-
mental Modification
Geography—note: landlocked; enclave in Rome,
Italy; world’s smallest state; beyond the territorial
boundary of Vatican City, the Lateran Treaty of
1929 grants the Holy See extraterritorial authority
agreements:
Government allows limited fishing in the sur-
rounding waters. Visits to Heard Island typically
focus on terrestrial and marine research and infre-
quent private expeditions.
Internet country code:.hm
Internet hosts: 102 (2012)
country comparison to the world: 209','d02a410a37b5f440327468a3884300226ea65060202e50b0a5d9f7046b98ef96','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fa592664d4945d277bad721ff79176c090e617a3322bf4b44d37d6da836f5f8b',2025,'VA','Holy See (Vatican City State)','geography',774,'Location: Central America, bordering the Car-
ibbean Sea, between Guatemala and Nicaragua
and bordering the Gulf of Fonseca (North Pacific
Ocean), between El Salvador and Nicaragua
Geographic coordinates: 15 00 N, 86 30 W
Map references: Central America and the
Caribbean
Area: total: 112,090 sq km
country comparison to the world: 103
land: 111,890 sq km
water: 200 sq km
Areo—comparative: slightly larger than Tennessee
Land boundaries; total: 1,520 km
border countries: Guatemala 256 km, El Salvador
342 km, Nicaragua 922 km Coastline: Caribbean
Sea 669 km; Gulf of Fonseca 163 km
Maritime claims: territorial sea: 12 nm
contiguous zone: 24 nm
exclusive economic zone: 200 nm
continental shelf: natural extension of territory
or to 200 nm
Climate: subtropical in low lands, temperate in
mountains
Terrain: mostly mountains in interior, narrow
coastal plains
Elevation extremes: lowest point: Caribbean
Sea 0m
highest point: Cerro Las Minas 2,870 m
Natural resources: timber, gold, silver, cop»
per, lead, zinc, iron ore, antimony, coal, fish,
hydropower
Land use: arable land:9.07%
permanent crops: 3.91%
other: 87.02% (2011)
Irrigated land: 878.5 sq km (2007)
Total renewable water resources: 95.93 cu km
(2011)
Freshwater withdrawal (domestic/indus-
triaW/agricultural): total: 2.12 cu km/yr
(16%/23%/61%)
per capita: 295.6 cu m/yr (2006)
Natural hazards: frequent, but generally mild,
earthquakes; extremely susceptible to damaging
hurricanes and floods along the Caribbean coast
Environment—current issues: urban population
expanding; deforestation results from logging and
the clearing of land for agricultural purposes; fur-
ther land degradation and soil erosion hastened by
322
THE CIA WORLD FACTBOOK
uncontrolled development and improper land use
practices such as farming of marginal lands; min-
ing activities polluting Lago de Yojoa (the coun-
try’s largest source of fresh water), as well as several
rivers and streams, with heavy metals
Environment—international agreements:
party to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Endan-
gered Species, Hazardous Wastes, Law of the Sea,
_ Marine Dumping, Ozone Layer Protection, Ship
Pollution, Tropical Timber 83, Tropical Timber
94, Wetlands
signed, but not ratified: none of the selected
agreements
Geography—note: has only a short Pacific coast
but a long Caribbean shoreline, including the vir-
tually uninhabited eastern Mosquito Coast','9e325ee2f4fcde697ed233f647b53690360a837fd927fbd0437d282e8d436de7','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e366ca4a8531eb884f9c2d9b2316d545529bd4497b4d39d708c6225423084b49',2025,'HN','Honduras','geography',784,'Location: Eastern Asia, bordering the South
China Sea and China Geographic coordinates: 22
15 N, 114 10 E
Map references: Southeast Asia
Area: total: 1,104 sq km
country comparison to the world: 184
land: 1,054 sq km
water: 50 sq km
Area—comporative: six times the size of Wash-
ington, DC
Land boundaries: total: 30 km
regional border: China 30 km
Coastline: 733 km
Maritime claims: territorial sea: 3 nm
Climate: subtropical monsoon; cool and humid in
winter, hot and rainy from spring through summer,
warm and sunny in fall
Terrain: hilly to mountainous wini steep slopes,
low lands in noi in
Elevation extremes: lowest point: South China
Sea 0 m
highest point: Tai Mo Shan 958 m
Natural resources: outstanding deepwater har-
bor, feldspar
Land use: arable land:5.05%
permanent crops: 1.01%
other: 93.94% (2011)
irrigated land: NA; note—included in the total
for China
Natural hazards: occasional typhoons
Environment—current issues: air and water pol-
lution from rapid urbanization
Environment—international agreements:
party t6: Marine Dumping (associate member),
Ship Pollution (associate member)
Geography—note: composed of more than 200
islands','35dbf3a35e4ac369748cdcf125ff373c191f9d1e088588e9e849292a38f7ab4f','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8da94ee6eca8b045bd93b929671cd363fb066a4d181f30f2a5761b3447ea5757',2025,'HU','Hungary','geography',801,'Location: Northern Europe, island between the
Greenland Sea and the North Atlantic Ocean,
northwest of the United Kingdom
Geographic coordinates: 65 00 N, 18 00 W
Map references: Europe
Area: total: 103,000 sq km
country comparison to the world: 108
land: 100,250 sq km
water: 27750 sq km
Area—comparative:
Kentucky
Land boundaries: 0 km
Coastline: 4,970 km
Maritime claims: territorial sea: 12 nm
exclusive economic zone: 200 nm
continental shelf: 200 nm or to the edge of the
continental margin Climate: temperate; moder-
ated by North Atlantic Current; mild, windy win-
ters; damp, cool summers Terrain: mostly plateau
interspersed with mountain peaks, icefields; coast
deeply indented by bays and fiords
Elevation extremes: lowest point: Atlantic
Ocean 0m
highest point: Hvannadalshnukur 2,110 m (at
Vatnajokull glacier)
slightly smaller than
Natural resources: fish, hydropower, geothermal
power, diatomite
Land use: arable land: 1.19%
permanent crops: 0%
other: 98.81% (2011)
Irrigated land: NA
Total renewable water resources: 170 cu km (2011)
Freshwater withdrawal (domestic/industrial/
agricultural): total:0.17 cu km/yr (49%/8%/42%)
per capita: 539.2 cu m/yr (2005)
Natural hazards: earthquakes and volcanic
activity
volcanism: Iceland, situated on top of a hotspot,
experiences severe volcanic activity; Eyjafjalla-
jokull (elev. 1,666 m) erupted in 2010, sending ash
high into the atmosphere and seriously disrupting
European air traffic; scientists continue to moni-
tor nearby Katla (elev. 1,512 m), which has a high
probability of eruption in the very near future,
potentially disrupting air traffic; Grimsvoetn
and Hekla are Iceland’s most active volcanoes;
other historically active volcanoes include Askja,
Bardarbunga, Brennisteinsfjoll, Esjufjoll, Hengill,
Krafla, Krisuvik, Kverkfjoll, Oraefajokull, Rey-
kjanes, Torfajokull, and Vestmannaeyjar
Environment—current issues: water pollu-
tion from fertilizer runoff; inadequate wastewater
treatment
Environment—international agreements: party
to: Air Pollution, Air Pollution-Persistent Organic
Pollutants, Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Endan-
gered Species, Hazardous Wastes, Kyoto Protocol,
Law of the Sea, Marine Dumping, Ozone Layer
Protection, Ship Pollution, Transboundary Air Pol-
lution, Wetlands, Whaling
signed, but not ratified: Environmental Modifica-
tion, Marine Life Conservation
Geography—note: strategic location between
Greenland and Europe; westernmost European
country; Reykjavik is the northernmost national
capital in the world; more land covered by glaciers
than in all of continental Europe','cbba85a4a41d068dbfc3b37bcf9833f686d723803408012775a59125803d6ae2','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('367d543f63918d779d0784ba1b45a2b6057f5bd074d68b40b6726d806a374e70',2025,'IS','Iceland','geography',808,'Location: Southern Asia, bordering the Arabian
Sea and the Bay of Bengal, between Burma and','2c133c1ce642e044f757765d4d5b3a59a4a4aeb5ad3f0ea72bd3f7cb41059bb8','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('705c6fe4d92bbe76d28200a15dd2197ac15f1eb9a468c2c0711728bf4958b2db',2025,'PK','Pakistan','geography',809,'Geographic coordinates: 20 00 N, 77 00 E
Map references: Asia
Area: total: 3,287,263 sq km
country comparison to the world: 7
land: 2,973,193 sq km
water: 314,070 sq km
Ared—comparative: slightly more than one-
third the size of the US
Land boundaries: coral: 14,103 km
border countries: Bangladesh 4,053 km, Bhutan
605 km, Burma 1,463 km, China 3,380 km, Nepal
1,690 km, Pakistan 2,912 km
Coastline: km
Maritime claims: territorial sea: 12 nm
contiguous zone: 24 nm
exclusive economic zone: 200 nm
continental shelf: 200 nm or to the edge of the
continental margin Climate: varies from tropical
monsoon in south to temperate in north Terrain:
upland plain (Deccan Plateau) in south, flat to
tolling plain along the Ganges, deserts in west,
Himalayas in north
Elevation extremes: lowest point: Indian Ocean
Om
highest point: Kanchenjunga 8,598 m
Natural resources: coal (fourth-largest: reserves
in the world), iron ore, manganese, mica, bauxite,
rare earth elements, titanium ore, chromite, natu-
ral gas, diamonds, petroleum, limestone, ‘arable
land
Land use: arable land: 47.87%
permanent crops: 3.74%
other: 48.39% (2011)
Irrigated land: 663,340 sq km (2008)
Total renewable water resources: 1,911 cu km
(2011)
Freshwater withdrawal (domestic/industrial/
agricultural): total: 761 cu km/yr (7%/2%/90%)
per capita; 613 cu m/yr (2010)
Natural hazards: droughts; flash floods, as well
as widespread and destructive flooding from mon-
soonal rains; severe thunderstorms; earthquakes
volcanism: Barren Island (elev. 354 m) in the
Andaman Sea has been active in recent years
Environment—current issues: deforestation;
soil erosion; overgrazing; desertification; air pol-
lution from industrial effluents and vehicle emis-
sions; water pollution from raw sewage and runoff
of agricultural pesticides; tap water is not potable
throughout the country; huge and growing popula-
tion is.overstraining natural resources
Environment—internationai agreements:
party to: Antarctic-Environmental Protocol, Ant-
arctic-Marine Living Resources, Antarctic Treaty,
Biodiversity, Climate Change, Climate Change-
Kyoto Protocol, Desertification, Endangered
Species, Environmental Modification, Hazardous
Wastes, Law of the Sea, Ozone Layer Protection,
Ship Pollution, Tropical Timber 83, Tropical Tim-
ber 94, Wetlands, Whaling
signed, but not ratified: none of the selected
agreements
Geography—note: dominates South Asian sub-
continent; near important Indian Ocean trade
routes; Kanchenjunga, third tallest mountain in
the world, lies on the border with Nepal','fa19312021aeb1218f467db4b8bbbfc176174d7de37387ae6612a732c16c1055','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6377b36d43ad0acbfda666b4a9e5890a4002c44db03a8a26bc1fdcbabea89169',2025,'IQ','Iraq','geography',820,'Location: Middle East, bordering the Persian Gulf,
between Iran and Kuwait
a
Geographic coordinates: 33 00 N, 44 00 E
Map references: Middle East
Area: total: 438,317 sq km
country comparison to the world: 59
land: 437,367 sq km
water: 950 sq km
Area—comparative: slightly more than twice the
size of Idaho
Land boundaries: total: 3,650 km
border countries: Iran 1,458 km, Jordan 181 km,
‘Kuwait 240 km, Saudi Arabia 814 km, Syria 605
km, Turkey 352 km
Coastline: 58 km
Maritime claims: territorial sea: 12 nm
continental shelf: not specified
Climate: mostly desert; mild to cool winters with
dry, hot, cloudless summers; northern mountain-
ous regions along Iranian and Turkish borders —
experience cold winters with occasionally heavy
snows that melt in early spring, sometimes causing
extensive flooding in central and southern Iraq
Terrain: mostly broad plains; reedy marshes along
Iranian border in south with large flooded areas;
mountains along borders with Iran and Turkey
Elevation extremes: lowest point: Persian Gulf
Om
highest point: unnamed peak; 3,611 m;
note: this peak is neither Gundah Zhur 3,607 m
nor Kuh-e Hajji-Ebrahim 3,595 m
Natural resources: petroleum, natural gas, phos-
phates, sulfur : l
Land use: arable land: 9.19%
permanent crops: 0.48%
other: 90.33% (2011)
Irrigated land: 35,250 sq km (2003)
Total renewable water resources: 89.86 cu km
(2011)
Freshwater withdrawal (domestic/industrial/
agricultural): total: 66 cu km/yr (7%/15%/79%)
per capita: 2,616 cu m/yr (2000)
Natural hazards: dust storms; sandstorms; floods
Environment—current issues:
water control projects have drained most of the
inhabited marsh areas east of An Nasiriyah by dry-
ing up or diverting the feeder streams and rivers;
a once sizable population of Marsh Arabs, who
inhabited these areas for thousands of years, has
been displaced; furthermore, the destruction of the
natural habitat poses serious threats to the area’s
wildlife populations; inadequate supplies of pota-
ble water; development of the Tigris and Euphra-
tes rivers system contingent upon agreements
with upstream riparian Turkey; air and water pol-
lution; soil degradation (salination) and erosion;
desertification
Environment—international agreements:
party to: Biodiversity, Law of the Sea, Ozone Layer
Protection
signed, but not
Modification
Geography—note: strategic location on Shatt al
Arab waterway and at the head of the Persian Gulf
Location: Western Europe, occupying five-sixths
of the island of Ireland in the North Atlantic
Ocean, west of Great Britain
Geographic coordinates: 53 00 N, 8 00 W
Map references: Europe
Area: total: 70,273 sq km
country comparison to the world: 120
land: 68,883 sq km
majority taking refuge in Syria and Jordan, and
lesser numbers to Egypt, Lebanon, Iran, and Tur-
key; Iraq’s lack of a maritime boundary with Iran
prompts jurisdiction disputes beyond the mouth of
the Shatt al Arab iri the Persian Gulf; Turkey has
expressed concern over the autonomous status of
Kurds in Iraq
Refugees and internally displaced persons:
refugees (country of origin): 15,606 (Turkey);
water: 1,390 sq km
Area—comparative: slightly larger than West
Virginia
Land boundaries: total: 360 km
border countries: UK 360 km
Coastline: 1,448 km
Maritime claims: territorial sea: 12 nm
exclusive fishing zone: 200 nm
Climate: temperate maritime; modified by North
Atlantic Current; mild winters, cool summers;
consistently humid; overcast about half the time
Terrain: mostly level to rolling interior plain sur-
rounded by rugged hills and low mountains; sea
cliffs on west coast
Elevation extremes: lowest point: Atlantic
Ocean 0 m
highest point: Carrauntoohil 1,041 m
Natural resources: natural gas, peat, copper, lead,
zinc, silver, barite, gypsum, limestone, dolomite
Land use: arable land: 15.11%
permanent crops; 0.01%
other: 84.87% (2011)
Irrigated land: 11 sq km (2003)
Total renewobdie water resources: 52 cu km
(2011)
Freshwater withdrawal (domestic/industrial/
agricultural); total: 0.79 cu km/yr (94%/6%/0%)
per capita: 226.9 cu m/yr (2007)
Natural hazards: NA
Environment—current issues: water pollution,
especially of lakes, from agricultural runoff
Environment—international agreements:
party to: Air Pollution, Air Pollution-Nitrogen
Oxides, Air Pollution-Sulfur 94, Biodiversity, Cli-
mate Change, Climate Change-Kyoto Protocol,
Desertification, Endangered Species, Environmen-
tal Modification, Hazardous Wastes, Law of the
Sea, Marine Dumping, Ozone Layer Protection,
Ship Pollution, Tropical Timber 83, Tropical Tim-
ber 94, Wetlands, Whaling
signed, but not ratified: Air Pollution-Persistent
Organic Pollutants, Marine Life Conservation
Geography—note: strategic location on major air
and sea routes between North America and north-
ern Europe; over 40% of the population resides
within 100 km of Dublin','31df12299c6cdef9541ae44f383b79cc0a51c37949cf51cb554380d500b5bc28','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f1ff2d0d4c144869a12a13207aa32ab559cb0f8b2f73708d7f4b998f9c4bf82e',2025,'IM','Isle of Man','geography',835,'Location: Western Europe, island in the Irish Sea,
between Great Britain and Ireland
Geographic coordinates: 54 15 N, 430 W
Map references: Europe
Area: total: 572 sq km
country comparison ta the world: 194
land: 572 sq km
water: 0 sq km
Area—comparative: slightly more than three
times the size of Washington, DC
Land boundaries: 0 km
Coastline: 160 km
Maritime claims: territorial sea: 12 nm
exclusive fishing zone: 12 nm
Climate: temperate; cool summers and mild win-
ters; overcast about a third of the time Terrain:
_ hills in north and south bisected by central val-
ley Elevation extremes: lowest point: Irish Sea 0 m
highest point: Snaefell 621 m
Natural resources: none
Land use: arable land: 43.86%
permanent crops: 0%
other: 56.14% (permanent pastures, forests, moun-
tain, and heathland) (2011)
Irrigated land: 0 sq km (2011)
Natural hazards: NA
Environment—current issues: waste disposal
(both household and industrial); transboundary
air pollution
Geography—note: one small islet, the Calf of
Man, lies to the southwest and is a bird sanctuary','73a82ab559534af1fd0df412cdfaa176382d3bbd5ed8e843fe0fd4ed13ee2ea1','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7a8534004d5d3840429dca0d38fe5fcb937a5f4114e3be72331345cf511a7b75',2025,'IL','Israel','geography',843,'Location: Middle East, bordering the Mediterra-
nean Sea, between Egypt and Lebanon
Geographic coordinates: 31 30 N, 34 45 E
Map references: Middle East
Area: total: 20,770 sq km
country comparison to the world: 154
land: 20,330 sq km
water: 440 sq km
Area—comparative: slightly larger than New
Jersey i
Land boundaries: total: 1,017 km
border countries: Egypt 266 km, Gaza Strip 51
km, Jordan 238 km, Lebanon 79 km, Syria 76 km:
West Bank 307 km
Coastline: 273 km
Maritime claims: territorial sea:12 nm
continental shelf: to depth of exploitation
Climate: temperate; hot and dry in southern and
eastern desert areas Terrain: Negev desert in the
south; low coastal plain; central mountains; Jordan
Rift Valley
Elevation extremes: lowest point: Dead Sea-408
m
highest point: Har Meron 1,208 m
Natural resources: timber, potash, copper ore,
natural gas, phosphate rock, magnesium bromide,
clays, sand
Land use: arable land: 13.68%
permanent crops: 3.69%
other; 82.62% (2011)
Irrigated land: 2,250 sq km (2004)
Total renewable water resources: 1.78 cu km
(2011)
Freshwater withdrawal (domestic/industrial/
agricultural): total: 1.95 cu km/yr (39%/6%/55%)
per capita: 282.4 cu m/yr (2009)
Natural hazards: sandstorms may occur during
spring and summer; droughts; periodic earthquakes
Environment—current issues: limited arable
land and natural freshwater resources pose seri-
ous constraints; desertification; air pollution from
industrial and vehicle emissions; groundwater pol-
lution from industrial and domestic waste, chemi-
cal fertilizers, and pesticides
Environment—international agreements:
party to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Endan-
gered Species, Hazardous Wastes, Ozone Layer
Protection, Ship Pollution, Wetlands, Whaling
signed, but not ratified: Marine Life Conservation
Geography—note: Lake Tiberias (Sea of Galilee)
is an important freshwater source; the Dead Sea
is the second saltiest body of water in the world
(after Lake Assal in Djibouti); there are about
355 Israeli civilian sites including about 145 small
outpost communities in the West Bank, 41 sites
in the Golan Heights, and 32 in East Jerusalem
(2010 est.)
Location: Southern Europe, a peninsula extending
into the central Mediterranean Sea, northeast of
Geographic coordinates: 32 00 N, 35 15 E
Map references: Middle East
Area: total: 5,860 sq km
country comparison to the world: 172
land: 5,640 sq km
water: 220 sq km
note: includes West Bank, Latrun Salient, and the
northwest quarter of the Dead Sea, but excludes
Mt. Scopus; East Jerusalem and Jerusalem No
Man''s Land are also included only as a means of
depicting the entire area occupied by Israel in 1967
Area—comparative:
Delaware
Land boundaries: total: 404 km
border countries: Israel 307 km, Jordan 97 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
Climate: temperate; temperature and precipita-
tion vary with altitude, warm to hot summers, cool
to mild winters
slightly smaller than
Terrain: mostly rugged dissected upland, some veg-
etation in west, but barren in east
Elevation extremes: lowest point: Dead Sea -408
m highest point: Tall Asur 1,022 m
Natural resources: arable land
Land use: arable
land: 7.39%
permanent crops: 10.96%
other: 81.64% (2011)
Irrigated land: 240 sq km; note—includes Gaza
Strip (2003)
Natural hazards: droughts
Environment—current issues:
freshwater supply; sewage treatment
Geography—note: landlocked; highlands are
main recharge area for Israel’s coastal aquifers;
there are about 355 Israeli civilian sites including
about 145 small outpost communities in the West
Bank and 32 sites in East Jerusalem (2010 est.)','fead05fa14aed0e43490a7b177b02b0d6e1dc72ddf29096884449b3405b5031d','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b7102a5aea78736468a5529930fb58402c85bddc279b7e27d3f4295e30a1605e',2025,'TN','Tunisia','geography',851,'Geographic coordinates: 42 50 N, 12 50 E
Map references: Europe
Area: total: 301,340 sq km
countrycomparison to the world: 72
, land: 294,140 sq km
water: 7,200 sq km
note: includes Sardinia and Sicily
Area—comparative: slightly larger than Arizona
Land boundaries: total: 1,899.2 km
border countries: Austria 430 km, France 488
km, Holy See (Vatican City) 3.2 km, San Marino
39 km, Slovenia 199 km, Switzerland 740 km
Coastline: 7,600 km
Maritime claims: territorial sea:12 nm
continental shelf: 200 m depth or to the depth of
exploitation
Climate: predominantly Mediterranean; Alpine
in far north; hot, dry in south Terrain: mostly
rugged and mountainous; some plains, coastal
lowlands È
Location: Northern Africa, bordering the Medi-
‘terranean Sea, between Algeria and Libya
Geographic coordinates: 34 00 N, 9 00 E
Map references: Africa
Area: total: 163,610 sq km
country comparison to the world: 93
land: 155,360 sq km
water: 8,250 sq km
Area—comporative: slightly larger than Georgia
Land boundaries: total: 1,424 km
border countries: Algeria 965 km, Libya 459 km
Coastline: 1,148 km
Maritime claims: territorial sea: 12 nm
contiguous zone: 24 nm
exclusive economic zone: 12 nm
Climate: temperate in north with mild, rainy win-
ters and hot, dry summers; desert in south Terrain:
mountains in north; hot, dry central plain; semi-
arid south merges into the Sahara
Elevation extremes: lowest point: Shattal Ghar-
sah-17 m
highest point: Jebel ech Chambi 1,544 m
Notural resources: petroleum, phosphates, iron
ore, lead, zinc, salt
Land use: arable land: 17.35%
permanent crops: 14.63%
other: 68.02% (2011) ó
Irrigated land: 3,970 sq km (2003)
Total renewable water resources: 4.6 cu km
(2011)
Freshwater withdrawal (domestic/industrial/
agricultural): cotal: 2.85 cu km/yr (14%/4%/82%)
per capita: 295.8 cu m/yr (2001)
Natural hazards: NA
Environment—current issues: toxic and hazard-
ous waste disposal is ineffective and poses health
tisks; water pollution from raw sewage; limited
natural freshwater resources; deforestation; over-
grazing; soil erosion; desertification
Environment—international agreements:
party to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Endan-
gered Species, Environmental Modification, Haz-
ardous Wastes, Law of the Sea, Marine Dumping,
Ozone Layer Protection, Ship Pollution, Wetlands
signed, but not ratified: Marine Life Conservation
Geography—note: strategic location in central
Mediterranean; Malta and Tunisia are discussing
the commercial exploitation of the continental
shelf between their countries, particularly for oil
exploration
Location: Southeastern Europe and Southwestern
Asia (that portion of Turkey west of the Bosporus
is geographically part of Europe), bordering the
Black Sea, between Bulgaria and Georgia, and
bordering the Aegean Sea and the Mediterranean
Sea, between Greece and Syria
Geographic coordinates: 39 00 N, 35 00 E
Map references: Middle East
Area: total: 783,562 sq km
country comparison to the world: 37
land: 769,632 sq km
water: 13, 930 sq km
Area—comporative: slightly larger than Texas
Land boundaries: total: 2, 648 km
border countries: Armenia 268 km, Azerbaijan 9
km, Bulgaria 240 km, Georgia 252 km, Greece 206
km, Iran 499 km, Iraq 352 km, Syria 822 km
Coastline: 7,200 km
Maritime claims: territorial sea: 6 nm in the
Aegean Sea; 12 nm in Black Sea and in Mediter-
ranean Sea Ž . aA
exclusive economic zone: in Black Sea only: to
the maritime boundary agreed upon with the for-
mer USSR
Climate: temperate; hot, dry summers with mild,
wet winters; harsher in interior
Terrain: high central plateau (Anatolia); narrow
coastal plain; several mountain ranges
Elevation extremes: lowest point: Mediterranean
Sea 0 m highest point: Mount Ararat 5,166 m
Natural resources: coal, iron ore, copper, chro-
mium, antimony, mercury, gold, barite, borate,
celestite (strontium), emery, feldspar, limestone,
magnesite, marble, perlite, pumice, pyrites (sulfur),
clay, arable land, hydropower
Land use: arable land: 26.21%
permanent crops: 3.94%
other: 69.84% (2011)
Irrigated land: 53,400 sq km (2012)
Total renewable water resources: 211.6 cu km
>
(2011)
Freshwater withdrawal (domestic/indus-
triaW/agricultural): total: 40.1 cu km/yr
(14%/10%/76%)
per capita: 572.9 cu m/yr (2008)
Natural hazards: severe earthquakes, especially in
northem Turkey, along an arc extending from the
Sea of Marmara to Lake Van
volcanism: limited volcanic activity; its three his-
torically active volcanoes; Ararat, Nemrut Dagi,
and Tendurek Dagi have not erupted since the
19th century or earlier
Environment—current issues: water pollution
from dumping of chemicals and detergents; air pol-
lution, particularly in urban areas; deforestation;
concern for oil spills from increasing Bosporus ship
traffic
Environment—international agreements:
party to: Air Pollution, Antarctic Treaty, Biodi-
versity, Climate Change, Desertification, Endan-
gered Species, Hazardous Wastes, Ozone Layer
Protection, Ship Pollution, Wetlands
_signed, but not ratified: Environmental
Modification
- Geography—fote: strategic location controlling
the Turkish Straits (Bosporus, Sea of Marmara, Dar-
danelles) that link Black and Aegean Seas; Mount
Ararat, the legendary landing place of Noah''s ark,
is in the far eastern portion of the country
Nationality: noun: Turk(s)
adjective: Turkish
Ethnic groups: Turkish 70-75%, Kurdish 18%,
other minorities 7-12% (2008 est.)
Languages: Turkish (official), Kurdish, other
minority languages Religions: Muslim 99.8% (mostly
Sunni), other 0.2% (mostly Christians and Jews)
TURKEY
Population: 80,694,485 (July 2013 est.)
country comparison to the world: 17
Age structure: 0-14 years: 25.9% (male
10,682,900/female 10,201,965)
15-24 years: 17% ° (male
6,703,689)
25-54 years: 42.7% (male 17,375,544/female
17,097,927)
55-64 years: 7.9%
3,169,450)
65 years and over: 6.6% (male 2,422,983/female
2,870,341) (2013 est.)
Median age: total: 29.2 years
male: 28.8 years
female: 29.6 years (2013 est.)
Population growth rate: 1.16% (2013 est.)
country comparison to the world: 100
Birth rate: 17.22 births/1,000 population (2013
est.)
country comparison to the world: 109
Death rate: 6.11 deaths/1,000 population (2013
est.)
country comparison to the world: 160
Net migration rate: 0.48 migrant(s)/1,000 popu-
lation (2013 est.)
6,979,955/female
{male 3,189,731/female
- country comparison to the world: 67
Urbanization: urban population: 70% of total
population (2010)
rate of urbanization: 1.7% annual rate of change
(2010-15 est.)
Major urban areas—population: Istanbul
10.378 million; ANKARA (capital) 3.846 mil-
lion; Izmir 2.679 million; Bursa 1.559 million;
Adana 1.339 million (2009)
Sex ratio: at birth: 1.05 male(s)/female 0-14
years: 1.05 male(s)/female
15-24 years: 1.04 male(s)/female
25-54 years: 1.02 male(s)/female
55-64 years: 1.01 male(s)/female
65 years and over: 0.84 male(s)/female
total population: 1.02 male(s)/female (2013 est.)
Maternal mortality rate: 20 deaths/100,000 live
births (2010) $
country comparison to the world: 140
infant mortality rate: total: 22.23 deaths/1,000
live births
country comparison to the world: 84
male: 23.29 deaths/1,000 live births
female: 21.12 deaths/1,000 live births (2013 est.)
Life expectancy ot birth: total population: 73.03
years
country comparison to the world: 126
male: 71.09 years
female: 75.07 years (2013 est.)
Total fertility rate: 2.1 children born/woman
(2013 est.)
country comparison to the world: 110
Health expenditures: 6.7% of GDP (2010)
country comparison to the world: 93
Physicians density: 1.45 physicians/1,000 popu-
lation (2008)
Hospital bed density: 2.5 beds/1,000 population
(2009)
Drinking water source:
Improved:
urban: 100% of population
rural: 99% of population
total: 100% of population
Unimproved:
urban: 0% of population
rural: 1% of population
total: 0% of population (2010 est.)
Sanitation facility access:
Improved:
urban: 97% of population
rural: 75% of population
total: 90% of population
Unimproved:
urban:3% of population
rural: 25% of population
total: 10% of population (2010 est.)
HIV/AIDS—adult prevalence rate: less than
0.1%; note—no country specific models provided
(2009 est.)
country comparison to the world: 111
HIV/AIDS—people living with HIV/AIDS: 4,600
(2009 est.)
country comparison to the world: 120
HIV/AIDS—deaths: fewer than 200 (2009 est.)
country comparison to the world: 110
Obesity—adu!t prevalence rate: 27.8% (2008)
country comparison to the world: 36
Children under the age of 5 years under-
weight: 3.5% (2004)
country comparison to the world: 101
Education expenditures: 2.9% of GDP (2006)
country comparison to the world: 145
Literacy: definition: age 15 and over can read and
write
total population: 87.4%
male: 95.3%
female: 79.6% (2004 est.)
School life expectancy (primary to tertiary
education): total: 12 years
male: 12 years
female: 11 years (2008)
Unemployment, youth ages 15-24: total: 18.4%
country comparison to the world: 68
male: 17.1%
female: 20.7% (2011)','d47476678955f633744cf9a0e5e70a76ae2e4c6d4af3284d4a090f22776d9744','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3e859978580a5acbbd301e9a6ec823c3bcfbd14e97e9aa36da539cb49a2e57e4',2025,'IT','Italy','geography',852,'Elevation extremes: lowest point: Mediterra-
nean Sea 0 m
highest point: Mont Blanc (Monte Bianco) de
Courmayeur 4,748 m (a secondary peak of Mont
Blanc)
Natural resources: coal, mercury, zinc, potash,
marble, barite, asbestos, pumice, fluorspar, feldspar,
pyrite (sulfur), natural gas and crude oil reserves,
fish, arable land
Land use: arable land: 22.57%
permanent crops: 8.37%
other: 69.07% (2011)
Irrigated land: 39,510 sq km (2007)
Total renewable water resources: 191.3 cu km
(2011)
Freshwater withdrawal (domestic/indus-
triaVagricultural): total: 45.41 cu km/yr
(24%/43%/34%)
per capita: 789.8 cu m/yr (2008)
Natural hazards: regional risks include landslides,
mudflows, avalanches, earthquakes, volcanic erup-
tions, flooding; land subsidence in Venice
volcanism: significant volcanic activity; Etna
(elev. 3,330 m), which is in eruption as of 2010, is
Europe''s most active volcano; flank eruptions pose
a threat to nearby Sicilian villages; Ema, along
with the famous Vesuvius, which remains a threat
to the millions of nearby residents in the Bay of
Naples area, have both been deemed “Decade
Volcanoes” by the International Association of
Volcanology and Chemistry of.the Earth’s Interior,
worthy of study due to their explosive history and
close proximity to human populations; Stromboli,
on its namesake island, has also been continuously
active with moderate volcanic activity; other his-
torically active volcanoes include Campi Flegrei,
Ischia, Larderello, Vulcano, and
Vulsini
Environment—current issues: air pollution from
industrial emissions such as sulfur dioxide; coastal
and inland rivers polluted from industrial and
agricultural effluents; acid rain damaging lakes;
inadequate industrial waste treatment and disposal
facilities
Environment—international agreements:
party to: Air Pollution, Air Pollution-Nitrogen
Oxides, Air Pollution-Persistent Organic Pollut-
ants, Air Pollution-Sulfur 85, Air Pollution-Sulfur
94, Air Pollution-Volatile Organic Compounds,
Antarctic-Environmental Protocol, Antarctic-
Marine Living Resources, Antarctic Seals, Antarc-
tic Treaty, Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Endan-
gered Species, Environmental Modification, Haz-
ardous Wastes, Law of the Sea, Marine Dumping,
Ozone Layer Protection, Ship Pollution, Tropical
Timber 83, Tropical Timber 94, Wetlands, Whaling
signed, but not ratified: none of the selected
agreements
Geography—note: strategic location dominating
central Mediterranean as well as southern sea and
air approaches to Western Europe
Location: Caribbean, island in the Caribbeari Sea,
south of Cuba
Geographic coordinates: 18 15 N, 77 30 W
Map references: Central America and the
Caribbean
Area: total: 10,991 sq km
country comparison to the world: 168
land: 10,831 sq km
water: 160 sq km
Area—comparative:
Connecticut
Land boundaries: 0 km
Coastline: 1,022 km
Maritime claims: measured from claimed archi-
pelagic straight baselines
territorial sea: 12 nm
contiguous zone: 24 nm
exclusive economic zone: 200 nm
continental shelf: 200 nm or to edge of the con-
tinental margin
Climate: tropical; hot, humid; temperate interior
Terrain: mostly mountains, with narrow, discon-
tinuous coastal plain
Elevation extremes: lowest point: Caribbean
Sea 0 m
highest point: Blue Mountain Peak 2,256 m
Natural resources: bauxite, gypsum, limestone
Land use: arable land: 10.92%
permanent crops: 9.1%
other: 79.98% (2011) -. *
slightly smaller than
Irrigated land: 252.2 sq km (2003)
Total renewable water resources: 9.4 cu km
(2011)
Freshwater withdrawal = (domestic/indus-
triaV/ogricultural): total: 0.93 cu km/yr
(32%/16%/52%)
per capita: 369.9 cu m/yr (2009)
Natural hazards: hurricanes (especially July to
November)
Environment—current issues: heavy rates of
deforestation; coastal waters polluted by industrial
waste, sewage, and oil spills; damage to coral reefs;
air pollution in Kingston from vehicle emissions
Environment—international agreements:
party to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Endan-
gered Species, Hazardous Wastes, Law of the Sea,
Marine Dumping, Marine Life Conservation,
Ozone Layer Protection, Ship Pollution, Wetlands
signed, but not ratified: none of the selected
agreements
Geography—note: strategic location between
Cayman Trench and Jamaica Channel, the main
sea lanes for the Panama Canal
Location: Southem Europe, an enclave in central
Geographic coordinates: 43 46 N, 12 25 E
Map references: Europe
Area: total: 61 sq km
country comparison to the world: 229
land: 61 sq km
water: 0 sq km
Area—comparative: about one third times the
size of Washington, DC
Land boundaries: total: 39 km
border countries: Italy 39 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
Climate: Mediterranean; mild to cool winters;
warm, sunny summers
Terrain: rugged mountains l
Elevation extremes: lowest point: Torrente Ausa
55 m
highest point: Monte Titano 755 m
Natural resources: building stone
Land use: arable land: 16.67%
permanent crops: 0%
ther: 83.33% (2011)
Irrigated land: NA
Natural hazards: NA
Environment—current Issues: air pollution:
urbanization decreasing rural farmlands
Environment—international agreements: party
to: Biodiversity, Climate Change, Desertification,
Whaling signed, but not ratified: Air Pollution
628
g
Geography—note: landlocked; smallest inde-
pendent state in Europe after the Holy See and
Monaco; dominated by the Apennines','1bb0ee91c322a2e124abac167a0eef5e1b8c8c817c415fbc69ba5bd01c761b8d','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('27ababa3e869ebff142c644aaeebb4827ff48377ad414261a7d34c6f7799bb03',2025,'JM','Jamaica','geography',869,'Location: Northern Europe, island between the
Greenland Sea and the Norwegian Sea, northeast
of Iceland
Geographic coordinates: 71 00 N, 8 00 W
Map references: Europe
Area: total: 377 sq km
country comparison to the world: 205
land: 377 sq km
water: 0 sq km
Area—compoarative: slightly more than twice the
size of Washington, DC
Land boundaries: 0 km
Coastline: 124.1 km
Maritime claims: territorial sea: 4 nm
contiguous zone: 10 nm
exclusive economic zone: 200 nm
continental shelf: 200 m depth or to the depth of
exploitation
Climate: arctic maritime with frequent storms and
persistent fog
Terrain: volcanic island, partly covered by glaciers
Elevation extremes: lowest point: Norwegian
Sea 0 m
highest point: Haakon VII Toppen on Beerenberg
2,277 m
note: Beerenberg volcano has numerous peaks; the
highest point on the volcano rim is named Haakon
VII Toppen, after Norway''s first king following the
reestablishment of Norwegian independence in
1905
Natural resources: none
Land use: arable land:0%
permanent crops: 0%
other: 100% (2011)
irrigated land: 0 sq km (2011)
Natural hazards: dominated by the volcano
Beerenberg
volcanism: Beerenberg (elev. 2,227 m) is Norway’s
only active volcano; volcanic activity resumed in
1970; the most recent eruption occurred in 1985
Environment—current issues: NA
Geography—note: barren volcanic island with
some moss and grass','9414dd9fc3516bfc830cd57b87dd6d98813e7e70ad4027c6621534c6f7c5223a','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d22400cb4396b50e124bcc88fbbab664e6e1b3a679d1be1d37a736b99811c603',2025,'NO','Norway','geography',873,'Location: Eastern Asia, island chain between the
North Pacific Ocean and the Sea of Japan, east of
the Korean Peninsula
Geographic coordinates: 36 00 N, 138 00 E
Map references: Asia
Area: total: 377,915 sq km
country comparison to the world: 62
land: 364,485 sq km
water: 13,430 sq km
note: includes Bonin Islands (Ogasawara-gunto),
Daito-shoto, Minami-jima, Okino-tori-shima,
Ryukyu Islands (Nansei-shoto), and Volcano
Islands (Kazan-retto)
Area—comparative:
California
Land boundaries: 0 km
Coastline: 29,751 km
Maritime claims: territorial sea: 12 nm; between
3 nm and 12 nm in the international straits—La
Perouse or Soya, Tsugaru, Osumi, and Eastern and
Western Channels of the Korea or Tsushima Strait
contiguous zone: 24 nm
exclusive economic zone: 200 nm
Climate: varies from tropical in south to cool tem-
perate in north
slightly smaller than
Terrain: mostly rugged and mountainous
Elevation extremes: lowest point: Hachiro-
gata-4 m Z
highest point: Fujiyama 3,776 m
Natural resources: negligible mineral resources,
fish
note: with virtually no energy natutal resources,
Japan is the world’s largest importer of coal and
liquefied natural gas, as well as the second largest
importer of oil
Land use: arable land: 11.26%
permanent crops: 0.81%
other: 87.93% (2011) a
Location: Northern Europe, bordeting the North
Sea and the North Atlantic Ocean, west of
Location: Middle East, bordering the Arabian Sea,
Gulf of Oman, and Persian Gulf, between Yemen
and UAE
Geographic coordinates: 21 00 N, 57 00 E
Map references: Middle East
Area: total: 309,500 sq km
country comparison to the world: 71
land: 309,500 sq km water: 0 sq km
Area—comparative: slightly smaller than Kansas
Land boundaries: total: 1,374 km
border countries: Saudi Arabia 676 km, UAE
410 km, Yemen 288 km
Coastline: 2,092 km
Maritime claims: territorial sea: 12 nm
contiguous zone: 24 nm
exclusive economic zone: 200 nm
Climate: dry desert; hot, humid along coast; hot,
dry interior; strong southwest summer monsoon
(May to September) in far south
Terrain: central desert plain, rugged mountains in
north and south
Elevation extremes: lowest point: Arabian Sea
Om
highest point: Jabal Shams 2,980 m
Natural feSOUFCES: petroleum, copper, asbestos,
some marble, limestone, chromium, gypsum, natu-
ral gas : j
Land use: arable land: 0.1% permanent
crops: 0.12%
other: 99.77% (2011)
Irrigated land: 588.5 sq km (2004)
Total renewable water resources: 1.4 cu km
(2011)
Freshwater withdrawal (domestic/industrial/
agricultural): total: 1532 cukm/yr (10%/1%/88%)
per capita: 515.8 cu m/yr (2003)
Natural hazards: summer winds often raise large
sandstorms and dust storms in interior; periodic
droughts
Environment—current issues: rising soil salin-
ity; beach pollution from oil spills; limited natural
freshwater resources
Environment—international agreements:
party to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Hazard-
ous Wastes, Law of the Sea, Marine Dumping,
Ozone Layer Protection, Ship Pollution, Whaling
signed, but not ratified: none of the selected
agreements
Geography—note: strategic location on Musandam
Peninsula adjacent to Strait of Hormuz, a vital transit
point for world crude oil','fb0071e9764413b8f0ba0467d78d4dbc37848d2c7f90dd5ae61740597bdb2f19','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e92d18747b7d5820c1b84a94e1a29eb80c06fdaf99be7c8c2f521b6cf2203b16',2025,'JP','Japan','geography',874,'Irrigated land: 25,000 sq km (2010)
Total renewable water resources: 430 cu km
(2011)
Freshwater withdrawal (domestic/industrial/
agricultural): t
total: 90.04 cu km/yr (20%/18%/62%)
per capita: 714.3 cu m/yr (2007)
Natural hazards: many dormant and some
active volcanoes; about 1,500 seismic occurrences
(mostly tremors but occasional severe earth-
quakes) every year; tsunamis; typhoons
volcanism: both Unzen (elev. 1,500 m) and
Sakura-jima (elev. 1,117 m), which lies near the
densely populated city of Kagoshima, have been
deemed “Decade Volcanoes” by the International
Association of Volcanology and Chemistry of
the Earth’s Interior, worthy of study due to their
explosive history and close proximity to human
populations; other notable historically active
volcanoes include Asama, Honshu Island’s most
active volcano, Aso, Bandai, Fuji, Iwo-Jima, Kikai,
Kirishima, Komaga-take, Oshima, Suwanosejima,
Tokachi, Yake-dake, and Usu
Environment—current issues: air pollution from
power plant emissions results in acid rain; acidi-
fication of lakes and reservoirs degrading water
quality and threatening aquatic life; Japan is one
of the largest consumers of fish and tropical timber,
contributing to the depletion of these resources in
Asia and elsewhere
Environment—international agreements:
party to: Antarctic-Environmental Protocol, Ant-
arctic-Marine Living Resources, Antarctic Seals,
Antarctic Treaty, Biodiversity, Climate Change,
Climate Change-Kyoto Protocol, Desertification,
Endangered Species, Environmental Modifica-
tion, Hazardous Wastes, Law of the Sea, Marine
Dumping, Ozone Layer Protection, Ship Pollution,
Tropical Timber 83, Tropical Timber 94, Wetlands,
Whaling
signed, but not ratified: none of the selected -
agreements
Geography—note: strategic location in northeast
Asia','03c212a1a43b49cc74343feaa8ed91492a80c0d1a9f02756b5c8811dc2e33ae1','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bd6a8c206d8f9bcb91762617d9a1187d596a9ae464d9e9c090801e4a9acdd11a',2025,'JE','Jersey','geography',884,'Location: Western Europe, island in the English
Channel, northwest of France
Geographic coordinates: 49 15 N, 2 10 W
Map references: Europe
Area: total: 116 sq km
country comparison to the world: 225
land: 116 sq km
water: 0 sq km
Area—comparative: about two-thirds the size of
Washington, DC
Land boundaries: 0 km
Coastline: 70 km
Maritime claims: territorial sea:3 nm
exclusive fishing zone: 12 nm
Climate:
summers
temperate; mild winters and cool
Terrain: gently rolling plain with low, rugged hills
along north coast _
Elevation extremes: lowest point: Atlantic
Ocean 0 m
highest point: unnamed elevation 143 m
Natural resources: arable land
Land use: arable land: NA
permanent crops: NA
other: NA (2005)
Irrigated land: NA
Natural hazards: NA
Environment—current issues: NA
Geography—note: largest and southernmost of
Channel Islands; about 30% of population con-
centrated in Saint Helier
403
Land boundaries: total: 462 km
border countries: Iraq 240 km, Saudi Arabia 222
km Coastline: 499 km
Maritime claims: territorial sea: 12 nm
Climate: dry desert; intensely hot summers; short,
cool winters
Terrain: flat to slightly undulating desert plain
Elevation extremes: lowest point: Persian Gulf
Om
highest point: unnamed elevation 306 m
Natural resources: petroleum, fish, shrimp, natu-
ral gas
Land use: arable land:0.62%
permanent crops: 0.28%
other: 99.1% (2011)
Irrigated land: 86 sq km (2007)
Total renewable water resources: 0.02 cu km
(2011)
Freshwater withdrawal (domestic/industrial/
agricultural): total:0.91 cu km/yr (47%/2%/51%)
per capita: 441.2 cu m/yr (2005)
Natural hazards: sudden cloudbursts are common’
from October to April and bring heavy rain, which
can damage roads and houses; sandstorms and dust
storms occur throughout the year but are most
common between March and August
Environment—current issues: limited natural
freshwater resources; some of world’s largest and
most sophisticated desalination facilities pro-
vide much of the water; air and water pollution;
desertification .
Environment—international agreements:
party to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Endan-
gered Species, Environmental Modification,
Hazardous Wastes, Law of the Sea, Ozone Layer
Protection
signed, but not ratified: Marine Dumping
Geography—note: strategic location at head of
Persian Gulf
Land boundaries; 0 km
Coastline: 2,254 km
Maritime claims: territorial sea: 12 nm
exclusive economic zone: 200 nm
Climate: tropical; modified by southeast trade
winds; hot, humid
Terrain: coastal plains with interior mountains
Elevation extremes: lowest point: Pacific Ocean
Om
highest point: Mont Panie 1,628 m
522
Natural resources: nickel, chrome, iron, cobalt,
manganese, silver, gold, lead, copper
Land use: arable land:0.38%
permanent crops: 0.27%
other: 99.34% (2011)
Irrigated land: 100 sq km (2003)
Natural hazards: cyclones, most frequent from
November to March
volcanism: Matthew and Hunter Islands are his-
torically active
Environment—current issues: erosion caused by
mining exploitation and forest fires
Geography—note: consists of the main island of
New Caledonia (one of the largest in the Pacific
Ocean), the archipelago of Iles Loyaute, and
numerous sinall, sparsely populated islands and
atolls
Land boundaries: total:535 km
border countries: Mozambique 105 km, South
Africa 430 km
692
THE CIA WORLD FACTBOOK
Airports—with paved runways: total: 1
2,438 to 3,047 m: 1 (2012)
Airports—with unpaved runways: total: 3
under 914 m: 3 (2012)
Heliports: 0 (2012)
Ports and terminals: Barentsburg, Longyearbyen,
Ny-Alesund, Pyramiden
Military branches: no regular military forces
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
Climate: varies from tropical-to near temperate
Terrain: mostly mountains and hills; some moder-
ately sloping plains i
Elevation extremes: lowest point: Great Usutu
River 21 m
highest point: Emlembe 1,862 m
Natural resources: asbestos, coal, clay, cassiter-
ite, hydropower, forests, small gold and diamond
deposits, quarry stone, and talc
Land use: arable land: 10.08%
permanent crops; 0.86%
other: 89.06% (2011)
Irrigated land: 498.5 sq km (2003)
Total renewable water resources: 4.51 cu km
(2011)
Freshwater withdrawal (domestic/industrial/
agricultural): total: 1.04 cu km/yr (4%/2%/94%)
per capita: 962.1 cu m/yr (2005)
Natural hazards: drought
Environment—current issues:
plies of potable water; wildlife populations being
depleted because of excessive hunting; overgraz-
ing; soil degradation; soil erosion
Environmeni—international
limited sup-
agreements:
party to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Endan-
gered Species, Hazardous Wastes, Ozone Layer
Protection
signed, but not ratified: Law of the Sea
Geography—note: landlocked;
pletely surrounded by South Africa
Location: Northern Europe, bordering the Baltic
Sea, Gulf of Bothnia, Kattegat, and Skagerrak,
between Finland and Norway
Geographic coordinates: 62 00 N, 15 00 E
Map references: Europe
Area: total: 450,295 sq km
country comparison to the world: 56
land: 410,335 sq km
water: 39,960 sq km
Area—comparative:
California
Land boundaries: total: 2,233 km
border countries: Finland 614 km, Norway 1,619
km
Coastline: 3,218 km
Maritime claims: territorial sea: 12 nm (adjust-
ments made to return a portion of straits to high
slightly larger than
seas)
exclusive economic zone: agreed boundaries or
midlines
continental shelf: 200 m depth or to the depth of
exploitation
Climate: temperate in south with cold, cloudy win-
ters and cool, partly cloudy summers; subarctic in
north Terrain: mostly flat or gently rolling lowlands;
mountains in west
Elevation extremes: lowest point: reclaimed bay
of Lake Hammarsjon, near Kristianstad -2.4 m
highest point: Kebnekaise 2,111 m
Natural resources: iron ore, copper, lead, zinc,
gold, silver, tungsten, uranium, arsenic, feldspar,
timber, hydropower
Land use: arable land: 5.8%
permanent crops: 0.02%
other: 94.18% (2011)
Irrigated land: 1,597 sq km (2007)
Total renewable water resources: 174 cu km
(2011)
Freshwater withdrawal (domestic/industrial/
agricultural): total:2.62 cu km/yr (37%/59%/4%)
per capita: 285.6 cu m/yr (2007)
Manpower fit for military service: males age
16-49: 201,853
females age 16-49: 175,477 (2010 est.)
Manpower reaching militarily significant age
annually: male: 16,168
female: 15,763 (2010 est.)
Military expenditures: 2.6% of GDP (2011)
country comparison to the world: 50','49d4f5cb8ecd4ae493358256422fdecfc630b48e479a84c3307e5428e5345a6a','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('678575a34260a886b2417ed1fd8169b322873eced349573c81d5b42b27a914b2',2025,'JO','Jordan','geography',893,'Location: Middle East, northwest of Saudi Arabia,
between Israel (to the west) and Iraq
Geographic coordinates: 31 00 N, 36 GOE
Map references: Middle East
Area: total: 89,342 sq km
country comparison to the world: 112 land:
88,802 sq km water: 540 sq km
Area—comparative:
Indiana
Land boundaries: total: 1,635 km
border countries: Iraq 181 km, Israel 238 km,
Saudi Arabia 744 km, Syria 375 km, West Bank
97 km
Coastline: 26 km
Maritime claims: territorial sea; 3 nm
Climate: mostly arid desert; rainy season in west
(November to April)
Terrain: mostly desert plateau in east, highland
area in west; Great Rift Valley separates East and
West Banks of the Jordan River
Elevation extremes: lowest point: Dead Sea-408 m
highest point: Jabal Umm ad Dami 1,854 m
Natural resources: phosphates, potash, shale oil
Land use: arable land: 1.97%
permanent crops: 0.95%
other: 97.08% (2011)
Irrigated land: 788.6 sq km (2004)
Total renewable water resources: 0.94 cu km
(2011) á
slightly smaller than
Freshwater withdrawal (domestic/industrial/
agricultural): total:0.94 cu km/yr (31%/4%/65%)
per capita: 166 cu m/yr (2005)
Natural hazards: droughts; periodic earthquakes
Environmeni—current issues: limited natural
freshwater resources; deforestation; overgrazing;
soil erosion; desertification
Environment—international agreements:
party to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Endan-
gered Species, Hazardous Wastes, Law of the
Sea, Marine Dumping, Ozone Layer Protection,
Wetlands
signed, but not ratified: none of the selected
apreements i
Geography—note: strategic location at the head
of the Gulf of Aqaba and as the Arab country that
shares the longest border with Israel and the occu-
pied West Bank i :
Location: Central Asia, northwest of China; a
small portion west of the Ural (Zhayyq) River in
eastern-most Europe
Geographic coordinates: 48 00 N, 68 00 E
Map references: Asia
— Area: total:2,724,900 sq km
country comparison to the world: 9
land: 2,699,700 sq km
water: 25,200 sq km
Area—comparative: slightly less than four times
the size of Texas
Land boundaries: total: 12,185 km
border countries: China 1,533 km, Kyrgyzstan
1,224 km, Russia 6,846 km, Turkmenistan 379 km,
Uzbekistan 2,203 km
Coastline: 0 km (landlocked); note—Kazakhstan
borders the Aral Sea, now split into two bodies of
water (1,070 km), and the Caspian Sea (1,894 km)
Maritime claims: none (landlocked)
Climate: continental, cold winters and hot sum-
mers, arid and semiarid
a
Terrain: vast flat steppe extending from the Volga
in the west to the Altai Mountains in the east and
from the plains of western Siberia in the north to
oases and deserts of Central Asia in the south
Elevation extremes: lowest point: Vpadina
Kaundy-132 m
highest point: Khan Tangiri, Shyngy (Pik Khan-
Tengri) 6,995 m
Natural resources: major deposits of petroleum,
natural gas, coal, iron ore, manganese, chrome ore,
nickel, cobalt, ‘copper, molybdenum, lead, zinc,
bauxite, gold, uranium
Land use: arable land: 8.82%
permanent crops: 0.03%
other: 91.15% (2011)
Irrigated land: 20,660 sq km (2010)
Total renewable water resources: 107.5 cu km
(2011)
Freshwater withdrawal (domestic/indus-
'' triaVagricultural): total: 21.14 cu km/yr
(4%/30%/66%)
per capita: 1,304 cu m/yr (2010)
Natural hazards: earthquakes in the south; mud-
slides around Almaty
Environment—current issues: radioactive or
toxic chemical sites associated with former defense
industries and test ranges scattered throughout
the country pose health risks for humans and ani-
mals; industrial pollution is severe in some cities;
because the two main rivers that flowed into the
Aral Sea have been diverted for irrigation, it is
drying up and leaving behind a harmful layer of
chemical pesticides and natural salts; these sub-
stances are then picked up by the wind and blown
into noxious dust storms; pollution in the Caspian
Sea; soil pollution from overuse of agricultural
chemicals and salination from poor infrastructure
and wasteful irrigation practices
Environment—international © agreements:
party to: Air Pollution, Biodiversity, Climate
Change, Desertification, Endangered Species,
Environmental Modification, Hazardous Wastes,
Ozone Layer Protection, Ship Pollution, Wetlands
signed, but not ratified: Climate Change-Kyoto
Protocol
Geography—note: landlocked; Russia leases
approximately 6,000 sq km of: territory enclos-
ing the Baykonur Cosmodrome; in January 2004,
Kazakhstan and Russia extended the lease to 2050','a947335dca7ae3c34b1eab948d6d34e7c795f06d4a4a9d282296f4ec2388aec8','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6c2d869a743d27a1c073fa90d6b07d0b2144bc9a7bbbce3d441e67d67d6a7cb9',2025,'KE','Kenya','geography',908,'Location: Eastern Africa, bordering the Indian
Ocean, between Somalia and Tanzania
Geographic coordinates: 1 00 N, 38 00 E
Map references: Africa
Area: total: 580,367 sq km
country comparison to the world: 49
land: 569,140 sq km
water: 11,227 sq km
Area—comparative: slightly more than twice the
size of Nevada
Land boundaries: total:3,477 km
border countries: Ethiopia 861 km, Somalia 682
km, South Sudan 232 km, Tanzania 769 km,
Uganda 933 km
; Coastline: 536 km
Maritime claims: territorial sea: 12 nm
exclusive economic zone: 200 nm
continental shelf: 200 m depth or to the depth of
exploitation
Climate: varies from tropical along coast to arid
in interior
Terrain: low plains rise to central highlands
bisected by Great Rift Valley; fertile plateau in
west
Elevation extremes: lowest point: Indian Ocean
Om
highest point: Mount Kenya.5,199 m
Natural resources: limestone, soda ash, salt, gem-
stones, fluorspar, zinc, diatomite, gypsum, wildlife,
hydropower
Land use: arable land:9.48%
permanent crops: 1.12%
other: 89.4% (2011)
irrigated land: 1,032 sq km (2003)
Total renewable water resources: 30.7 cu km
(2011)
Freshwater withdrawal (domestic/industrial/
agricultural); total: 2.74 cu km/yr (17%/4%/79%)
per capita: 72.96 cu m/yr (2003)
Natural hazards: recurring drought; flooding dur-
ing rainy seasons
volcanism: limited volcanic activity; the Barrier
(elev. 1,032 m) last erupted in 1921; South Island
is the only other historically active volcano
Environment—current issues: water pollution
from urban and industrial wastes; degradation of
water quality from increased use of pesticides and
fertilizers; water hyacinth infestation in Lake Vic-
toria; deforestation; soil erosion; desertification;
poaching
Environment—international agreements:
party to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Endan-
gered Species, Hazardous Wastes, Law of the Sea,
Marine Dumping, Marine Life Conservation,
Ozone Layer Protection, Ship Pollution, Wet-
lands, Whaling signed,
but not ratified: none of the selected agreements
Geography—note: the Kenyan Highlands
comprise one of the most successful agricultural
production regions in Africa; glaciers are found
on Mount Kenya, Africa’s second highest peak;
unique physiography supports abundant and varied
wildlife of scientific and economic value','cc79b05b0bea13c72a816dbd0ea7bfda6296a9ea9365e072adff98a655b43bb8','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('aa19455cb649d6641fdca0e15df5ca02fca7136cfd145483cdf703877ac3ce1f',2025,'KI','Kiribati','geography',916,'Location: Oceania, group of 33 coral atolls in the
Pacific Ocean, straddling the Equator, as well as
the International Date Line; the capital Tarawa is
about half way berween Hawaii and Australia
Geographic coordinates: 1 25 N, 173 00 E
Mop references: Oceania
Area: total: 811 sq km
country comparison to the world: 187
land: 811 sq km water: 0 sq km
note: includes three island groups—Gilbert
Islands, Line Islands, Phoenix Islands
Area—comparative: four times the size of Wash-
ington, DC
Land boundaries: 0 km
Coastline: 1,143 km
Maritime claims: territorial sea: 12 nm
exclusive economic zone: 200 nm
Climate: tropical; marine, hot and humid, moder-
ated by trade winds
Terrain: mostly low-lying coral atolls surrounded
by extensive reefs
Elevation extremes: lowest point: Pacific Ocean
Om
_ highest point: unnamed elevation on Banaba 81 m
Natural resources: phosphate (production dis-
continued in 1979)
Land use: arable land: 2.47%
permanent crops: 39.51%
other: 58.02% (2011)
Irrigated land: NA
Natural hazards: typhoons can occur any time,
but usually November to March; occasional torna-
does; low level of some of the islands make them
sensitive to changes in sea level
Environment—current issues: heavy pollu-
tion in lagoon of south Tarawa atoll due to heavy
migration mixed with traditional practices such
as lagoon latrines and open-pit dumping; ground
water at risk
a
Environment—international agreements:
party to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Hazard-
ous Wastes, Law of the Sea, Marine Dumping,
Ozone Layer Protection, Whaling
signed, but not ratified: none of the selected
agreements ;
Geography—note: 21 of the 33 islands are inhab-
ited; Banaba (Ocean Island) in Kiribati is one
of the three great phosphate rock islands in the
Pacific Ocean—the others are Makatea in French
Polynesia, and Nauru; Kiribati is the only coun-
try in the world to fall into all four hemispheres
(northern, southern, eastern, and western)
Location: Eastern Asia, northern half of the
Korean Peninsula bordering the Korea Bay and
the Sea of Japan, between China and South Korea
Geographic coordinates: 40 00 N, 127 00 E
Map references: Asia
Area: total: 120,538 sq km
country comparison to the world: 99
land: 120,408 sq km
water: 130 sq km
Area—comparative:
Mississippi
Land boundaries: total: 1,671.5 km
border countries: China 1,416 km, South Korea
238 km, Russia 17.5 km
Coastline: 2,495 km
Maritime claims: territorial sea: 12 nm
exclusive economic zone: 200 nm
note: military boundary line 50 nm in the Sea of
Japan and the exclusive economic zone limit in
the Yellow Sea where all foreign vessels and air-
craft without permission are banned
slightly smaller than
Climate: temperate with rainfall concentrated in
summer
Terrain: mostly hills and mountains separated by
deep, narrow valleys; coastal plains wide in west,
discontinuous in east
Elevation extremes: lowest point: Sea of Japan
Om
highest point: Paektu-san 2,744 m
Natural resources: coal, lead, tungsten, zinc,
graphite, magnesite, iron ore, copper, gold, pyrites,
salt, fluorspar, hydropower
Land use: arable land: 19.08%
permanent crops: 1.7%
other: 79.22% (2011)
Irrigated land: 14,600 sq km (2003)
Total renewable water resources: 77.15 cu km
(2011) f z :
withdrawal (domestic/indus-
Freshwater
triaV/agricuitural); total: 866 cu’ km/yr
(10%/13%/76%)
per capita: 360.6 cu m/yr (2005)
Natural hazards: late spring droughts often fol-
lowed by severe flooding; occasional typhoons dur-
ing the early fall
volcanism: Changbaishan (elev. 2,744 m) (also
known as Baitoushan, Baegdu or P’aektu-san),
on the Chinese border, is considered historically
active à
Environment—current issues: water pollution;
inadequate supplies of potable water; waterborne
disease; deforestation; soil erosion and degradation
Environment—international agreements:
party to: Antarctic Treaty, Biodiversity, Cli-
mate Change, Climate Change-Kyoto Protocol,
Desertification, Environmental Modification,
Hazardous Wastes, Ozone Layer Protection, Ship
Pollution
signed, but not ratified: Law of the Sea
Geography—note: strategic location bordering
China, South Korea, and Russia; mountainous
interior is isolated and sparsely populated
394
[5
THE CIA WORLD FACTBOOK
Location: Easten Asia, southern half of the
Korean Peninsula bordering the Sea of Japan and
the Yellow Sea
Geographic coordinates: 37 00 N, 127 30E
Map references: Asia
Area: total:99,720 sq km
country comparison to the world: 109
land: 96,920 sq km
water: 2,800 sq km
Area—comparative: slightly larger than Indiana
Land boundaries: total: 238 km
border countries: North Korea 238 km
Coastline: 2,413 km
Maritime claims: territorial sea: 12 nm; between
3 nm and 12 nm in the Korea Strait
contiguous zone: 24 nm
exclusive economic zone: 200 nm
continental shelf: not specified
Climate: temperate, with rainfall heavier in sum-
mer than winter
Terrain: mostly hills and mountains; wide coastal
plains in west and south
Elevation extremes: lowest point: Sea of Japan
Om
highest point: Halla-san 1,950 m
Natural resources: coal, tungsten, graphite,
molybdenum, lead, hydropower potential
Land use: arable land: 14.93%
permanent crops: 2.06%
other: 83% (2011)
Irrigated land: 8,804 sq km (2003)
Total renewable water resources: 69.7 cu km
(2011)
Freshwater withdrawal (domestic/indus-
triaW/agricultural): total: 25.47 cu km/yr
(26%/12%/62%)
per capita: 548.7 cu m/yr (2003)
Natural hazards: occasional typhoons bring high
winds and floods; low-level seismic activity com-
mon in southwest
volcanism: Halla (elev. 1,950 m) is considered
historically active although it has ‘not erupted in
many centuries
Environment—current issues: air pollution in
large cities; acid rain; water pollution from the
discharge of sewage and industrial effluents; drift
net fishing
Environment—international agreements:
party to: Antarctic-Environmental Protocol, Ant-
arctic-Marine Living Resources, Antarctic Treaty,
Biodiversity, Climate Change, Climate Change-
Kyoto Protocol, Desertification, Endangered
Species, Environmental Modification, Hazardous
Wastes, Law of the Sea, Marine Dumping, Ozone
Layer Protection, Ship Pollution, Tropical Timber
83, Tropical Timber 94, Wetlands, Whaling
signed, but not ratified: none of the selected
agreements
Geography—note: strategic location on Korea
Strait','fa010f0db85f6801275ded7132dfdb674603157b5cef4d5e3bc28c73c1ce3c56','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cc75e9facb0908d04d14fd825c4b9d5f4672b4bdab5652ab26bf4f9a814bb153',2025,'RS','Serbia','geography',933,'Location: Middle East, bordering the Persian Gulf,
between Iraq and Saudi Arabia
Geographic coordinates: 29 30 N, 45 45 E
Map references: Middle East
Area: total: 17,818 sq km
country comparison to the world: 158
land: 17,818 sq km
water: 0 sq km
Area—comparative: slightly smaller than New
Location: Southeastern Europe, between Macedo-
nia and Hungary :
Geographic coordinates: 44 00 N, 21 00 E
Map references: Europe
Area: total: 77,474 sq km
country comparison to the world: 117
land: 77,474 sq km
water: 0 sq km
Area—comparative: slightly smaller than South
Carolina $ J
Land boundaries: coral: 2,026 km
border countries: Bosnia and Herzegovina 302
km, Bulgaria 318 km, Croatia 241 km, Hungary
151 km, Kosovo 352 km, Macedonia 62 km, Mon-
renegro 124 km, Romania 476 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
Climate: in the north, continental climate (cold
winters and hot, humid summers with well-dis-
tributed rainfall); in other parts, continental and
Mediterranean climate (relatively cold winters
with heavy snow fall and hot, dry summers and
autumns)
Terrain: extremely varied; to the north, rich fertile
plains; to the east, limestone ranges and basins; to
the southeast, ancient mountains and hills
Elevation extremes: lowest point: Danube and
Timok Rivers 35 m
highest point: Midzor 2,169 m
Natural resources: oil, gas, coal, iron ore, copper,
zinc, antimony, chromite, gold, silver, magnesium,
pyrite, limestone, marble, salt, arable land
Land use: arable land: 37.28%
permanent crops: 3.41% ;
other: 59.31% (2011)
Irrigated land: 919.6 sq km (2011)
Total renewable water resources: 162.2 cu km
(note—includes Kosovo) (2011)
Natural hazards: destructive earthquakes
Environment—current issues: air pollution
around Belgrade and other industrial citiés; water
pollution from industrial wastes dumped into the
Sava which flows into the Danube
Environment—international agreements:
party to: Air Pollution, Biodiversity,” Climate
Change, Climate Change-Kyoto Protocol, Deser-
tification, Endangered Species, Hazardous Wastes,
Law of the Sea, Marine Dumping, Marine Life
Conservation, Ozone Layer Protection, Ship Pol-
lution, Wetlands signed, but not ratified: none of
the selected agreements
Geography—note: controls one of the major land
routes from Western Europe to Turkey and the
Near East
Location: archipelago in the Indian Ocean, north-
east of Madagascar
Geographic coordinates: 4 35 S, 55 40 E
Map references: Africa
Area: total: 455 sq km
country comparison to the world: 199
land: 455 sq km
water: 0 sq km
Areo—comparative: 2.5 times the size of Wash-
ington, DC
Land boundaries: 0 km
Coastline: 491 km
Maritime claims: territorial sea: 12 nm
contiguous zone: 24 nm
exclusive economic zone: 200 nm
continental shelf: 200 nm or to the edge of the
continental margin Climate: tropical marine;
humid; cooler seasbn during southeast monsoon
(late May to September);
northwest monsoon (March to May)
warmer season during
Terrain: Mane Group is granitic, narrow coastal
strip, rocky, hilly; others are coral, flat, elevated
reefs
Elevation extremes: lowest point: Indian Ocean
Om
highest point: Morne Seychellois 905 m
Natural resources: fish, copra, cinnamon trees
Land use: arable land:2.17%
permanent crops: 4.35%
other: 93.48% (2011)
Irrigated land: 2.6 sq km (2003)
Natural hazards: lies outside the cyclone belt, so
severe storms are rare; occasional short droughts
Environment—current issues: water supply
depends on catchments to collect rainwater
Environment—international agreements:
party to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Endan-
gered Species, Hazardous Wastes, Law of the Sea,
Marine Dumping, Ozone Layer Protection, Ship
Pollution, Wetlands
signed, but not ratified: none of the selected
agreements
Geography—note: 41 granitic and about 75 cor-
alline islands','6493fb546fc6e2a185be15412ad9c78b90cdbaed316781727f088871f17c5a7b','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('58a67dbeeec740136bd06de458db879cd93c17748159f79a9c830425fde72fe1',2025,'KZ','Kazakhstan','geography',941,'Geographic coordinates: 41 00 N, 75 00 E
Map references: Asia
Area: total: 199,951 sq km
country comparison to the world: 87
land: 191,801 sq km
water: 8,150 sq km
‘Area—comporative: slightly smaller chan South
Dakota
Land boundaries: total: 3,051 km
border countries: China 858 km, Kazakhstan
1,224 km, Tajikistan 870 km, Uzbekistan 1,099 km
Coastline; 0 km (landlocked)
Maritime claims: none (landlocked)
Climate: dry continental to polar in high Tien
Shan Mountains; subtropical in southwest (Fer-
gana Valley); temperate in northern foothill zone
Terrain: peaks of Tien Shan and associated val-
leys and basins encompass entire nation
Elevation extremes: lowest point: Kara-Daryya
(Karadar’ya) 132 m
highest point: nii S (Pik Pobedy)
7,439 m','eebd39bfeb5230eae30aca09de737a5b21c92236dcbb94e1b53944022c81c32a','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('60e80bb85128f45ef9ffc5ad0a6062f88377a1ae280771d115a59f0cee277ebf',2025,'KG','Kyrgyzstan','geography',942,'Natural resources: abundant hydropower; sig-
nificant deposits of gold and rare earth metals;
locally exploitable coal, oil, and natural gas; other
deposits of nepheline, mercury, bismuth, lead, and
zinc
Land use: arable land: 6.38%
permanent crops: 0.37%
other: 93.24%
note: Kyrgyzstan has the world’s largest natural-
growth walnut forest (2011)
Irrigated land: 10,210 sq km (2005)
Total renewable water resources: 23.62 cu km
(2011)
Freshwater withdrawal (domestic/industrial/
agricultural): total: 8.01 cu km/yr (3%/4%/93%)
per capita: 1,558 cu m/yr (2006)
Natural hazards: NA
Environment—current issues: water pollution;
many people get their water directly from contami-
nated streams and wells; as a result, water-bome dis-
eases are prevalent; increasing soil salinity from faulty
irrigation practices
Environment—international agreements:
party to: Air Pollution, Biodiversity, Climate
Change, Climate Change-Kyoto Protocol, Deser-
tification, Hazardous Wastes, Ozone Layer Protec-
tion, Wetlands
signed, but not ratified: none of the selected
agreements
Geography—note: landlocked; entirely moun-
tainous, dominated by the Tien Shan range; 94%
of the country is 1,000 m above sea level with an
average elevation of 2,750 m; many tall peaks, gla-
ciers, and high-altitude lakes
Location: Southeastern Asia, northeast of Thai-
land, west of Vietnam
Geographic coordinates: 18 00 N, 105 00 E
Map references: Southeast Asia
Area: total: 236,800 sq km
country comparison to the world: 84
land: 230,800 sq km
water: 6,000 sq km
Area—comparative: slightly larger than Utah
Land boundaries: toral: 5,083 km
border countries: Burma 235 km, Cambodia 541
km, China 423 km, Thailand 1,754 km, Vietnam
2,130 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
Climate: tropical monsoon; rainy season (May to
November); dry season (December to April)
Terrain: mostly rugged mountains; some plains
and plateaus
Elevation extremes: lowest point: Mekong River
70m
highest point: Phu Bia 2,817 m
Natural resources: timber, hydropower, gypsum,
tin, gold, gemstones
Land use: arable land; 5.91%
permanent crops; 0.42%
other: 93.67% (2011) . *
Irrigated land: 3,100 sq km (2005)
Total renewable water resources: 333.5 cu km
(2011)
Freshwater withdrawal (domestic/industrial/
agricultural): total: 3.49 cu km/yr (4%/5%/91%)
per capita: 588.9 cu m/yr (2005)
Natural hazards: floods, droughts
Environment—current issues: unexploded
ordnance; deforestation; soil erosion;.most of the
population does not have access to potable water
Environment—international agreements:
party to: Biodiversity, Climate Change, Climate .
Change-Kyoto Protocol, Desertification, Endan-
“gered Species, Environmental Modification, Law
of the Sea, Ozone Layer Protection
signed, but not ratified: none of the selected
agreements
Geography—note: landlocked; most of the
country is mountainous and thickly forested; the
Mekong River forms a large part of the western
boundary with Thailand
Geographic coordinates: 39 00 N, 71 00 E
Map references: Asia
Area: total: 143,100 sq km
country comparison to the world: 96
land: 141,510 sq km
water: 2,590 sq km
Area—comparative:
Wisconsin
Land boundaries: total: 3,651 km
border countries: Afghanistan 1,206 km, China
414 km, Kyrgyzstan 870 km, Uzbekistan 1,161 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
slightly smaller than
Climate: midlaticude continental, hot sum-
mers, mild winters; semiarid to polar in Pamir
Mountains
Terrain: Pamir and Alay Mountains dominate
landscape; western Fergana Valley in north,
Kofarnihon and Vakhsh Valleys in southwest
Elevation extremes: lowest point: Syr Darya
(Sirdaryo) 300 m
highest point: Qullai Somoniyon 7,495 m
Natural resources: hydropower, some petroleum,
uranium, mercury, brown coal, lead, zinc, anti-
mony, tungsten, silver, gold
Land use: arable land: 5.96%
permanent crops: 0.91%
other: 93.13% (2011)
Irrigated land: 7,421 sq km (2009)
Total renewable water resources: 21.91 cu km
(2011)
Freshwater withdrawal (domestic/industrial/
agricultural): total: 11.49 cu km/yr (6%/4%/91%)
per capita: 1,740 cu m/yr (2006)
Natural hazards: earthquakes; floods
Environment—current issues: inadequate sani-
tation facilities; increasing levels of soil salinity;
industrial pollution; excessive pesticides
Environment—internationai agreements:
party to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Envi-
ronmental Modification, Ozone Layer Protection,
Wetlands
signed, but not ratified: none of the selected
agreements
Geography—note: landlocked; mountainous
region dominated by the Trans-Alay Range in
the north and the Pamirs in the southeast; high-
est point, Quilai Ismoili Somoni (formerly Com-
munism Peak), was the tallest mountain in the
former USSR
PEOPLE AND
Nationality: noun: Tajikistani(s)
adjective: Tajikistani
Ethnic groups: Tajik 79.9%, Uzbek 15.3%, Rus-
sian 1.1%, Kyrgyz 1.1%, other 2.6% (2000 census)
Languages: Tajik (official), Russian widely used
in government and business
Religions; Sunni Muslim 85%, Shia Muslim 5%,
other 10% (2003 est.)
Population: 7,910,041 (July 2013 est.)
country comparison to the world: 96
Age structure: 0-14 years: 33.4%
1,343,251/female 1,296,192)
15-24 years: 20.4% (male 818,089/female 795,303)
25-54 years: 38.5% (male 1,501,713/female
1,541,413)
55-64 years: 4.6% (male 165,220/female 195,363)
65 years and over: 3.2% (male 106,605/female
146,892) (2013 est.)
Median age: total: 23.2 years
male: 22.7 years
female: 23.7 years (2013 est.)
Population growth rate: 1.79% (2013 est.)
country comparison to the world: 67
Birth rate: 25.49 births/1 000 population (2013 est.)
country comparison to the world: 55
Death rate: 6.38 deaths/1,000 population (2013 est.)
- country comparison to the world: 153
Net migration rate: -1.19 migrant(s)/1,000 popu-
` lation (2013 est.)
country comparison to the world: 149
Urbanization: urban population: 26% of total
population (2010)
rate of urbanization: 2.2% annual rate of change
(2010-15 est:)
Major urban areas—population; DUSHANBE
(capital) 704,000 (2009)
Sex ratio: at birth: 1.05 male(s)/female
0-14 years: 1.04 male(s)/female
15-24 years: 1.03 male(s)/female
25-54 years: 0.97 male(s)/female
55-64 years: 0.85 male(s)/female
65 years and over: 0.73 male(s)/female
(male','a1d20241a3f1d6e9d635fa692363d8d86721e422e97bc18289c510b5a3ad3770','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('768f3a75b6ca1bc31bbe1fa47e150f8a3989c4f8b616f846b3b4046f73f995f5',2025,'LT','Lithuania','geography',955,'Location: Pastern Europe, bordering the Baltic
Sea, between Estonia and Lithuania
Geographic coordinates: 57 00 N, 25 00 E
Map references: Europe
Area: total: 64,589 sq km
country comparison to the world: 124
land: 62,249 sq km
water: 2,340 sq km
Area—comparative: slightly larger than West
Virginia .
Land boundaries: total: 1,382 km
414
border countries: Belarus 171 km, Estonia 343
km, Lithuania 576 km, Russia 292 km
Coastline: 498 km
Maritime claims: territorial sea: 12 nm
exclusive economic zone: 200 nm
continental shelf: 200 m depth or to the depth of
exploitation
Climate: maritime; wet, moderate winters
Terrain: low plain
Elevation extremes: lowest point: Baltic Sea O m
highest point: Gaizina Kalns 312 m
Natural resources: peat, limestone, dolomite,
amber, hydropower, timber, arable land
Land use: arable land: 17.96%
permanent crops: 0.11%
other: 81.93% (2011)
Irrigated land: 8.3 sq km
note: land in Latvia is often too wet and in need
of drainage not irrigation; approximately 16,000 sq
km or 85% of agricultural land has been improved
by drainage (2007)
Total renewable water resources: 35.45 cu km
(2011)
Freshwater withdrawal (domestic/indus-
trial/agricultural): total: 0.42 cu km/yr
(42%/45%/13%)
per capita: 177.9 cu m/yr (2007)
Natural hazards; NA
Environment—current issues: Latvia’s environ-
ment has benefited from a shift to service indus-
tries after the country regained independence; the
main environmental priorities are improvement of
drinking water quality and sew age system, house-
hold, and hazardous waste management, as well as
reduction of air pollution; in 2001, Latvia closed
the EU accession negotiation chapter on environ-
ment committing to full enforcement of EU envi-
ronmental directives by 2010
Environment—international agreements:
party to: Air Pollution, Air Pollution-Persistent
Organic Pollutants, Biodiversity, Climate Change,
Climate Change-Kyoto Protocol, Desertification,
Endangered Species, Hazardous Wastes, Law of
the Sea, Ozone Layer Protection, Ship Pollution,
Wetlands
signed, but not ratified: none of the selected
agreements
Geography—note: most of the country is com-
posed of fertile low—lying plains with some hills
in the east
Location: Eastern Europe, bordering the Baltic
Sea, between Latvia and Russia
Geographic coordinates: 56 00 N, 24 00 E
Map references: Europe
Area: total: 65,300 sq km
country comparison to the world: 123
land: 62,680 sq km
water: 2,620 sq km
Area—comparotive: slightly larger than West
Virginia
Land boundaries: total: 1,574 km
border countries: Belarus 680 km, Latvia 576 km,
Poland 91 km, Russia (Kaliningrad) 227 km
Coastline: 90 km
Maritime claims: territorial sea: 12 nm
Climate: transitional, between maritime and con-
tinental; wet, moderate winters and summers
Terrain: lowland, many scattered small lakes, fer-
tile soil
433
Elevation extremes: lowest point: Baltic Sea 0 m
highest point: Aukstojas 294 m
Natural resources: peat, arable land, amber
Land use: arable land: 33.48%
permanent crops: 0.47%
other: 66.05% (2011)
Irrigated land: 13.4 sq km (2007)
Total renewable water resources: 24.9 cu km
(2011)
Freshwater withdrawal (domestic/industrial/
agricultural): total: 2.38 cu km/yr (7%/90%/3%)
per capita: 703.8 cu m/yr (2009)
Natural hazards: NA
Environment—current issues: contamination of
soil and groundwater with petroleum products and
chemicals at military bases
Environment—international agreements:
party to: Air Pollution, Air Pollution-Nitrogen
Oxides, Air Pollution-Persistent Organic Pollut-
ants, Air Pollution-Sulphur 85, Air Pollution-
Sulphur 94, Air Pollution-Volatile Organic Com-
pounds, Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Endan-
gered Species, Environmental Modification,
Hazardous Wastes, Law of the Sea, Ozone Layer
Protection, Ship Pollution, Wetlands
signed, but not ratified: none of the selected
agreements l :
Geography—note: fertile central plains are
separated by hilly uplands that are ancient glacial
deposits
i PEOPLE AND SOCIETY
Nationality: noun: Lithuanian(s)
adjective: Lithuanian
Ethnic groups: Lithuanian 84%, Polish 6.1%,
Russian 4.9%, Belarusian 1.1%, other or unspeci-
fied 3.9% (2009)
Languages: Lithuanian (official) 82%, Russian
8%, Polish 5.6%, other and unspecified 4.4%
(2001 census) A .
Religions: Roman Catholic 79%, Russian Ortho-
dox’ 4.1%, Protestant (including Lutheran and
Evangelical Christian Baptist) 1.9%, other or
unspecified 5.5%, none 9.5% (2001 census)
Population: 3,515,858 (July 2013 est.)
country comparison to the world: 132
Age structure: 0-14 years: 13.6% (male 245,028/
female 232,356)
15-24 years: 13% (male 233,939/female 223,495)
25-54 years: 44.8% (male 784,389/female 790,066)
55-64 years: 11.9% (male 187,057/female 229,943)
65 years and over: 16.8% (male 204,314/female
385,271) (2013 est.)
Median age: total: 40.8 years
male: 38.2 years
female: 43.3 years (2013 est.)
Population growth rate: -0.28% (2013 est.)
country comparison to the world: 216
Birth rate: 9.36 births/1,000 population (2013
est.)
country comparison to the world: 204
Death rate: 11.48 deaths/1,000 population (2013
est.)
country comparison to the world: 32
Net migration rate: -0.73 migrant(s)/1,000 popu-
lation (2013 est.)
country comparison to the world: 142
434
THE CIA WORLD FACTBOOK
Urbanization: urban population: 67% of total
population (2010)
rate of urbanization: -0.5% annual rate of
change (2010-15 est.)
Major urban areas—population: VILNIUS
(capital) 546,000 (2009)
Sex ratio: at birth: 1.06 male(s)/female
0-14 years: 1.06 male(s)/female
15-24 years: 1.04 male(s)/female
25-54 years: 0.99 male(s)/female
55-64 years; 0.81 male(s)/female
65 years and over: 0.53 male(s)/female
total population: 0.89 male(s)/female (2013 est.)
Maternal mortality rate: 8 deaths/100,000 live
births (2010)
country comparison to the world: 161
Infant mortality rate: total: 6.09 deaths/1,000
live births
country comparison to the world: 171
male: 7.26 deaths/1,000 live births
female: 4.85 deaths/1,000 live births (2013 est.)
Life expectancy at birth: total population: 75.77
years
country comparison to the world: 89
male: 70.96 years
female: 80.84 years (2013 est.)
Total fertility rate: 1.28 children born/woman
(2013 est.)
country comparison to the world: 217
Health expenditures: 7% of GDP (2010)
country comparison to the world: 80
Physicians density: 3.66 physicians/1,000 popu-
lation (2008) x
Hospital bed density: 6.8 beds/1,000 population
(2009)
Drinking water source:
Improved:
urban: 93% of population
rural: 81% of population
total: 92% of population
Unimproved:
urban: 7% of population
rural: 19% of population
total: 8% of population (2000 est.)
Sanitation facility access:
Improved:
urban: 95% of population
rural: 69% of population
total: 86% of population
Unimproved:
urban: 5% of population
rural: 31% of population
total: 14% of population (2000 est.)
HIV/AIDS—adult prevalence rate: 0.1% (2009 est.)
country comparison to the world: 142
HIV/AlIDS—people living with HIV/AIDS: 1,200
(2009 est.)
country comparison to the world: 137
HIV/AIDS—deaths: fewer than 100 (2009 est.)
country comparison to the world: 138
Major infectious diseases: degree of risk:
intermediate
food or waterborne diseases: bacterial diarrhea
vectorborne diseases: tickborne encephalitis
(2009)
Obesity—adult prevalence rate: 27.6% (2008)
country comparison to the world: 38
Education expenditures: 5.7% of GDP (2009)
country comparison to the world: 48
Literacy: definition: age 15 and over can read
and write
total population: 99.7%
male: 99.7%
female: 99.7% (2010 est.)
School life expectancy (primary to tertiary
education): total: 16 years
male: 15 years
female: 17 years (2008)
Unemployment, youth ages 15-24: total: 32.9%
country comparison to the world: 20
male: 34.6%
female: 30.5% (2011)
Location: Western Europe, between France and
in accordance with the land ''and maritime treaty
ratified by Russia in May 2003 and by Lithuania
in 1999; Lithuania operates a simplified transit
regime for Russian nationals traveling from the
Kaliningrad coastal: exclave into Russia, while
still conforming, as a EU member state having an
external border with a non-EU member, to strict
Schengen border rules; boundary demarcated with
Latvia and Lithuania; as of January 2007, ground
demarcation of the boundary with Belarus was
Terrain: mostly gently rolling uplands with broad,
shallow valleys; uplands to slightly mountainous in
the north; steep slope down to moselle flood plain
in the southeast
Elevation extremes: lowest point: Moselle River
133m i s `
highest point: Buurgplaatz 559 m
Natural resources: iron ore (no longer exploited),
arable land
Land use: arable land: 23.9%
permanent crops: 0.58%
other: 75.52% (includes Belgium) (2011)
irrigated land: NA
Total renewable water resources: 3.1 cu km (2011)
Freshwater withdrawal (domestic/industrial/
agricultural): total: 0.06 cu km/yr (65%/33%/1%)
per capita: 135.9 cu m/yr (2010)
Natural hazards: NA
Environment—current issues: air and water pol-
lution in urban areas, soil pollution of farmland
Environment—international agreements:
party to: Air Pollution, Air Pollution-Nitrogen
Oxides, Air Pollution-Persistent Organic Pollut-
ants, Air Pollution-Sulfur 85, Air Pollution-Sulfur
94, Air Pollution-Volatile Organic Compounds,
Biodiversity, Climate Change, Climate Change-
Kyoto Protocol, Desertification, Endangered Spe-
cies, Hazardous Wastes, Law of the Sea, Marine
Dumping, Ozone Layer Protection, Ship Pollution,
Tropical Timber 83, Tropical Timber 94, Wetlands
signed, but not ratified: Environmental
Modification
Geography—note: landlocked; the only Grand
Duchy in the world','0c9064b3238c33e59dd74c2059fd6eb3d36bfe8823a602898611dd14400ed432','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ab937b00f8a6acfc859045eb1a08e08b2cce28e39bbd01723a06fd3ce1cc90a6',2025,'LB','Lebanon','geography',965,'Location: Middle East, bordering the Mediterra-
nean Sea, between Israel and Syria
Geographic coordinates: 33 50 N, 35 50 E
Map references: Middle East
Area: total: 10,400 sq km
country comparison to the world: 170
land: 10,230 sq km
water: 170 sq km
Area—comparative: about 0.7 times the size of
Connecticut
Land boundaries: total: 454 km
border countries: Israel 79 km, Syria 375 km
Coastline: 225 km
Maritime claims: territorial sea: 12 nm
Climate: Mediterranean; mild to cool, wet winters
with: hot, dry summers; Lebanon mountains expe-
rience heavy winter snows
Terrain: narrow coastal plain; El Beqaa (Bekaa
Valley) separates Lebanon and Anti-Lebanon
Mountains
Elevation extremes: lowest point: Mediterra-
nean Sea 0 m
highest point: Qornet es Saoyda 3,088 m
Natural resources: limestone, iron ore, salt, water-
surplus state in a water-deficit region, arable land
Land use: arable land: 10.72%
permanent crops: 12.06%
other: 77.22% (2011)
Irrigated land: 1,040 sq km (2003)
Total renewable water resources: 4.5 cu km (2011)
Freshwater withdrawal (domestic/industrial/
agricultural): coral: 1.31 cu km/yr (29%/11%/60%)
per capita: 316.8 cu m/yr (2005)
Natural hazards: dust storms, sandstorms
Environment—current issues: deforestation;
soil erosion; desertification; air pollution in Beirut
from vehicular traffic and the burning of industrial
wastes; pollution of coastal waters from raw sewage
and oil spills
Environment—international agreements:
party to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Hazard-
ous Wastes, Law of the Sea, Ozone Layer Protec-
tion, Ship Pollution, Wetlands
signed, but not ratified: Environmental Modifica-
tion, Marine Life Conservation
Geography—note: Nahr el Litani is the
only major river in Near East not crossing an
418
THE CIA WORLD FACTBOOK
international boundary; rugged terrain historically
helped isolate, protect, and develop numerous fac-
tional groups based on religion, clan, and ethnicity
Location: Southern AGica, an enclave of South
Africa
Geographic coordinates: 29 30 S, 28 30E
Map references: Africa
Area: total: 30,355 sq km
country comparison to the world: 142
land: 30,355 sq km
water: 0 sq km
Areo—comparative: slightly smaller than Maryland
Land boundaries: total: 909 km
border countries: South Africa 909 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
Climate: temperate; cool to cold, dry winters; hot,
wet summers Terrain: mostly highland with pla-
teaus, hills, and mountains
Elevation extremes: lowest point: junction of
the Orange and Makhaleng Rivers 1,400 m
highest point: Thabana Ntlenyana 3,482 m
Natural resources: water, agricultural and grazing
land, diamonds, sand, clay, building stone
Land use: arable land: 10.14%
permanent crops: 0.13%
other: 89.72% (2011)
Irrigated land: 26.37 sq km (2003)
Total renewable water resources: 3.2 cu km (2011)
Freshwater withdrawal (domestic/industrial/
agricultural): total: 0.04 cu km/yr (46%/46%/9%)
per capita: 21.79 cu m/yr (2000)
Natural hazards: periodic droughts
Environment—current issues: population pres-
sure forcing settlement in marginal areas results in
portions of the Lebanon-Syria boundary are
unclear with several sections in dispute; since
2000, Lebanon has claimed Shab’a Farms area in
the Israeli-occupied Golan Heights; the roughly
2,000-strong UN Interim Force in Lebanon has
been in place since 1978
Refugees and internally displaced persons:
refugees (country of origin); 436,154 (Palestinian
refugees (UNRWA); 8,751 (Iraq) (2011); 495,776
(Syria) (2013)
IDPs: at least 47,000 (1975-90 civil war, 2007
Lebanese security forces’ destruction of Palestinian
refugee camp) (2011)
Wicit drugs: cannabis cultivation dramatically
teduced to 2,500 hectares in 2002 despite con-
tinued significant cannabis consumption; opium
poppy cultivation minimal; small amounts of
Latin American cocaine and Southwest Asian
heroin transit country on way to European
markets and for Middle Eastern consumption;
money laundering of drug proceeds fuels con-
cern that extremists are benefiting from drug
trafficking
overgrazing, severe soil erosion, and soil exhaus-
tion; desertification; Highlands Water Project con-
trols, stores, and redirects water to South Africa
Environment—international agreements:
party to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Endan-
gered Species, Hazardous Wastes, Law of the Sea,
Marine Life Conservation, Ozone Layer Protec-
tion, Wetlands
signed, but not ratified: none of the selected
agreements
Geography—note: landlocked, completely sur-
rounded by South Africa; mountainous, more than
80% of the country is 1,800 m above sea level','01434f1f9d2ba585906df8007a62c440934c2fbe725c49aef2926f10abaf7dc1','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ac732090f26b8ed2397b6c670ce1d146775e6a6666886474c4293f3dfa3790af',2025,'LR','Liberia','geography',984,'Location: Westem Africa, bordering the North
Atlantic Ocean, between Cote d''Ivoire and Sierra
Leone
Geographic coordinates: 6 30 N, 9 30 W
Map references: Africa
Area: total: 111,369 sq km
country comparison to the world: 104
land: 96,320 sq km
water: 15,049 sq km
Area—comporative: slightly larger than Tennessee
Land boundaries: total: 1,585 km
border countries: Guinea 563 km, Cote d''Ivoire
716 km, Sierra Leone 306 km
Coastline: 579 km
Maritime claims: territorial sea: 200 nm
Climate: tropical; hot, humid; dry winters with
hot days and cool to cold nights; wet, cloudy sum-
mers with frequent heavy showers
Terrain: mostly flat to rolling coastal plains rising
to rolling plateau and low mountains in northeast
Elevation extremes: lowest point: Atlantic
Ocean 0 m
highest point: Mount Wuteve 1,380 m
Natural resources: iron ore, timber, diamonds,
gold, hydropower
Land use: arable land: 4.04%
permanent crops: 1.62%
other: 94.34% (2011)
Irrigated land: 21 sq km (2003)
Total renewable water resources: 232 cu km
(2011)
Freshwater withdrawal (domestic/industrial/
agricultural): tocal:0.13 cu km/yr (55%/37%/8%)
per capita: 43.66 cu m/yr (2005) °
Natural hazards: dust-laden harmattan winds
blow from the Sahara (December to March)
Environment—current issues: tropical rain for-
est deforestation; soil erosion; loss of biodiversity;
pollution of coastal waters from oil residue and raw
sewage _ :
Environment—international agreements:
party to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Endan-
gered Species, Hazardous Wastes, Law of the Sea,
Ozone Layer Protection, Ship Pollution, Tropical
Timber 83, Tropical Timber 94, Wetlands
signed, but not ratified: Environmental Modifica-
tion, Marine Life Conservation
Geography—note: facing the Atlantic Ocean,
the coastline is characterized by lagoons, man-
grove swamps, and river-deposited sandbars; the
inland grassy plateau supports limited agriculture','e9e4e55f81eb2078b7391b312654bf04ea8200bf4614a003eba34f6d644cd2bf','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('575ffd313c6cd9e8be06fef4252e6031bf6fa83de342ba602d0045f31b5cbdf0',2025,'CH','Switzerland','geography',1001,'Geographic coordinates: 47 16 N, 9 32 E
Map references: Europe
Area: total: 160 sq km
country comparison to the world: 219
land: 160 sq km
water: 0 sq km
Area—comparative: about 0.9 trimes the size of
Washington, DC
Land boundaries: total: 76 km
border countries: Austria 34.9 km, Switzerland
41.1 km
Coastline: 0 km (doubly landlocked)
Maritime claims: none (landlocked)
Climate: continental; cold, cloudy winters with
frequent snow or rain; cool to moderately warm,
cloudy, humid summers
Terrain: mostly mountainous (Alps) with Rhine
Valley in western third
Elevation extremes: lowest point: Ruggeller Riet
430m
highest point: Vorder-Grauspitz 2,599 m
Natural resources: hydroelectric potential, ara-
ble land
Land use: arable land: 21.88%
permanent crops: 0%
other: 78.12% (2011)
Irrigated land: NA
Natural hazards: NA
Environment—current issues: NA
Environment—international agreements:
party to: Air Pollution, Air Pollution-Nitrogen
Oxides, Air Pollution-Persistent Organic Pollut-
ants, Air Pollution-Sulfur 85, Air Pollution-Sulfur
94, Air Pollution-Volatile Organic Compounds,
Biodiversity, Climate Change, Climate Change-
Kyoto Protocol, Desertification, Endangered Spe-
cies, Hazardous Wastes, Ozone Layer Protection,
Wetlands
signed, but not ratified: Law of the Sea
Geography—note: along with Uzbekistan, one
of only two doubly landlocked countries in the
world; variety of microclimatic variations based
on elevation
Location: Middle East, bordering the Mediterra-
nean Sea, between Lebanon and Turkey
Geographic coordinates: 35 00 N, 38 00 E
Mop references: Middle East
Area: total: 185,180 sq km
country comparison to the world: 89
land: 183,630 sq km
water: 1,550 sq km k
noté: includes 1,295 sq km of Israeli-occupied
territory
Area—comporative: slightly larger than North
Dakota i
Land boundaries: total: 2,253 km
border countries: Iraq 605 km, Israel 76 km, Jor-
dan 375 km, Lebanon 375 km, Turkey 822 km
Coastline: 193 km
Maritime claims: territorial sea: 12 nm
contiguous zone: 24 nm
Climate: mostly desert; hot, dry, sunny summers
(June to August) and mild, rainy winters (Decem-
ber to February) along coast; cold weather with
snow or sleet periodically in Damascus
Terrain: primarily semiarid and desert plateau;
narrow coastal plain; mountains in west
Elevation extremes: lowest point: unnamed
location near Lake Tiberias -200 m
highest point: Mount Hermon 2,814 m
Natural resources: petroleum,
chrome and manganese ores, asphalt, iron ore,
rock salt, marble, gypsum, hydropower
Land use: arable land: 24.9%
permanent crops; 5.69%
other: 69.41% (2011)
Irrigated land: 13,410 sq km (2010)
Total renewable water resources: 16.3 cu km
(2011)
Freshwater withdrawal (domestic/industrial/
agricultural): total: 16.76 cu km/yr (9%/4%/88%)
per capita: 867.4 cu m/yr (2005)
Natural hazards: dust storms, sandstorms
volcanism: Syria''s two historically active volca-
noes, Es Safa and an unnamed volcano near the
Turkish border have not erupted in centuries
Environment—current Issues: deforestation;
overgrazing; soil erosion; desertification; water
phosphates,
pollution from raw sewage and petroleum refining
wastes; inadequate potable water
Environment—international agreements:
party to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Endan-
gered Species, Hazardous Wastes, Ozone Layer
Protection, Ship Pollution, Wetlands signed, but
not ratified: Environmental Modification
Geography—fote: the capital of Damascus—
located at an oasis fed by the Barada River—is
thought to be one of the world’s oldest continu-
ously inhabited cities; there are 41 Israeli settle-
ments and civilian land use sites in the Israeli-
occupied Golan Heights (2010 est.)
Location: Eastem Asia, islands bordering the East
China Sea, Philippine Sea, South China Sea, and
Taiwan Strait, north of the Philippines, off the
southeastern coast of China :
Geographic coordinates: 23 30 N, 121 00 E
Map references: Southeast Asia
Area: total: 35,980 sq km
country comparison to the world; 139
land: 32,260 sq km
water: 3,720 sq km
note: includes the
Quemoy islands
Area—comporative: slightly smaller than Mary-
land and Delaware combined
Land boundaries: 0 km
Coastline: 1,566.3 km
Maritime claims: territorial sea: 12 nm exclusive
economic zone: 200 nm
Pescadores, Matsu, and
Climate: tropical; marine; rainy season during
southwest monsoon (June to August); cloudness is
persistent and extensive all year
Terrain: eastern two-thirds mostly rugged moun-
tains; flat to gently rolling plains in west
Elevation extremes: lowest point: South China
Sea 0 m
highest point: Yu Shan 3,952 m
Natural resources: small deposits of coal, natural
gas, limestone, marble, and asbestos
Land use: arable land: 24%
permanent crops: 1%
other: 75% (2011)
Irrigated land: NA
Total renewable water resources: 67 cu km
(2011)
Natural hazards: eaithquakes; typhoons
voicanism: Kueishantao Island (elev. 401 m), east
of Taiwan, is its only historically active volcano,
although it has not erupted in centuries
Environment—current issues: air pollution;
water pollution from industrial emissions, raw
sewage; contamination of drinking water supplies;
trade in endangered species; low-level radioactive
waste disposal
Environment—international agreements:
party to: none of the selected agreements because
of Taiwan''s international status
Geography—note: strategic location adjacent to
both the Taiwarf?Strait and the Luzon Strait','88be0efda3938aedb06e3fc0bfaeb269a8502ec1d0e4c9acd4a080e1aa4ff56f','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('91a921f46edfbfb472a6f6fced5163f2f7d1ff9c8734c48e8d1bd732d7974314',2025,'LU','Luxembourg','geography',1022,'Location: Eastern Asia, bordering the South
China Sea and China
Geographic coordinates: 22 10 N, 113 33 E
Map references: Southeast Asia
Area: total: 28.2 sq km
country comparison to the world: 237
land: 28.2 sq km
water: 0 sq km
Area—comparative: less than one-sixth the size
of Washington, DC
Land boundaries: total: 0.34 km
regional border: China 0.34 km
Coastline: 41 km
Maritime claims: not specified
Climate: subtropical; marine with cool winters,
warm summers
Terrain: generally flat
Elevation extremes: lowest point: South China
Sea 0 m
highest point: Coloane Alto 172 m
Natural resources: NEGL
Land use: arable land: 0%
permanent crops: 0%
other: 100% (2011)
Irrigated land: NA; note—included-in the total
for China
Natural hazards: typhoons
Environment—current issues; NA
Environment—international agreements:
party to: Marine Dumping (associate member),
Ship Pollution (associate, member)
Geography—note: essentially urban; an area of
land reclaimed from the`sea measuring 5.2 sq km
and known as Cotai now connects the islands of
Coloane and Taipa; the island area is connected to
the mainland peninsula by three bridges','874f6e7dfc46ef62c34f79012d5522a6c017a6c7c1e62b3f83881e87213f0a63','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f7e8f6b33b3ef1df9d1e10115f7e7faacf2e6547dfa5b8813f4c21a07cfc117b',2025,'MG','Madagascar','geography',1027,'Location: Southern Africa, island in the Indian
Ocean, east of Mozambique
Geographic coordinates: 20 00 S, 47 00 E
Map references: Africa
Area: total: 587,041 sq km
country comparison to the world: 47
land: 581,540 sq km
water: 5,501 sq km
Areo—comparative: slightly less than twice the
size of Arizona
Land boundaries: 0 km
Coastline: 4,828 km
Maritime claims: territorial sea: 12 nm
contiguous zone: 24.nm
exclusive economic zone: 200 nm
continental shelf: 200 nm or 100 nm from the
2,500-m isobath
Climate: tropical along coast, temperate inland,
arid in south
Terrain: narrow coastal plain, high plateau and
mountains in center
Elevation extremes: lowest point: Indian Ocean
Om
highest point: Maromokotro 2,876 m
Natural resources: graphite, chromite, coal,
bauxite, rare earth elements, salt, quartz, tar sands,
semiprecious stones, mica, fish, hydropower
Land use: arable land: 5.96%
permanent crops: 1.02%
other: 93.02% (2011)
Irrigated land: 10,860 sq km (2003)
Totat renewable water resources: 337 cu km
(2011)
Freshwater withdrawal (domestic/industrial/
agricultural): total: 16.5 cu km/yr (2%/1%/97%)
per capita: 1,010 cu m/yr (2005)
447','14846233382631b90eb05417ed41448c98fd2a0264cb6066afce83023db27ac4','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7195eb3bc9ddd63f73edf8fe2dfa46f316fa42549a3f85f66f3e48073b86ca44',2025,'ZM','Zambia','geography',1036,'Location: Southern Africa, east of Zambia, west
and north of Mozambique
Geographic coordinates: 13 30 S, 34 00 E
Map references: Africa
Area: total: 118,484 sq km*
highest point: unnamed elevation in Mafinga Hills
2,301 m
Natural resources: copper, cobalt, zinc, lead,
coal, emeralds, gold, silver, uranium, hydropower
Land use: arable land:4.52%
permanent crops: 0.05%
other: 95.44% (2011)
Irrigated land: 1,559 sq km (2003)
Total renewable water resources: 105.2 cu km
(2011)
Freshwater withdrawal (domestic/industrial/
agricultural): total: 1.57 cu km/yr (18%/8%/73%)
per capita: 147 cu m/yr (2002)
Natural hazards: periodic drought; tropical
storms (November to April)
Environment—current issues: air pollution
and resulting acid rain in the mineral extraction
and refining region; chemical runoff into water-
sheds; poaching seriously threatens rhinoceros,
elephant, antelope, and large cat populations;
deforestation; soil erosion; desertification; lack of
adequate water treatment presents human health
risks
Environment—international agreements:
party to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Endan-
gered Species, Hazardous Wastes, Law of the Sea,
Ozone Layer Protection, Wetlands signed, but not
ratified: none of the selected agreements
Geography—note: landlocked; the Zambezi
forms a natural riverine boundary with Zimbabwe;
Lake Kariba on the Zambia-Zimbabwe border
forms the world’s largest reservoir by volume (180
cu km; 43 cu mi)','c9920a5e882fd625e7021b3a189eee4bb468aa64a834dd23877fdf21bb4ecb56','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0e54aa95889c88effbbdb348ef63e48f9791af0b19b935955b741b0868ad0d31',2025,'MW','Malawi','geography',1037,'country comparison to the world: 100
land: 94,080 sq km
water: 24,404 sq km
Area-comparative:
Pennsylvania
Land boundaries: total: 2,881 km
border countries: Mozambique 1,569 km, Tanza-
nia 475 km, Zambia 837 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
Climate: sub-tropical; rainy season (November to
May); dry season (May to November)
slightly smaller than
Terrain: narrow elongated plateau with rolling
plains, rounded hills, some mountains
Elevation extremes: lowest point: junction of
the Shire River and international boundary with
Mozambique 37 m
highest point: Sapitwa (Mount Mlanje) 3,002 m
Natural resources: limestone, arable land, hydro-
power, unexploited deposits of uranium, coal, and
bauxite
Land use: arable land: 30.38%
permanent crops: 1.1%
other: 68.52% (2011)
Irrigated tand: 735 sq km (2006)
Total renewable water resources: 17.28 cu km
(2011)
Freshwater withdrawal (domestic/industrial/
agricultural): total: 1.36 cu km/yr (11%/4%/86%)
per capita: 99.86 cu m/yr (2005)
Natural hazards: NA
Environment—current issues: deforestation;
land degradation; water pollution from 2gncul-
tural runoff, sewage, industrial wastes; siltation of
spawning grounds endangers fish populations
Environmoni—international agreements:
party to: Biodiversity, Climate Change, Cli-
mate Change-Kyoto Protocol, Desertification,
Endangered Species, Environmental Modifica-
tion, Hazardous Wastes, Marine Life Conser-
vation, Ozone Layer Protection, Ship Pollu-
tion, Wetlands
signed, but not ratified: Law of the Sea
Geography—note: landlocked; Lake Nyasa, some
580 km long, is the country’s most prominent
physical feature; it contains more fish species than
any other lake on earth','d7a408a6849661493b0f966265deb80c9ea4ad4125cfcb8d0420d865b5270d78','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2e92fb53dee8213761ab3e9151b36b831ecf67b2dc28e7941f15104095d13bf8',2025,'MY','Malaysia','geography',1048,'Location: Southeastern Asia, peninsula border-
ing Thailand and northern one-third of the island
454
of Borneo, bordering Indonesia, Brunei, and the
South China Sea, south of Vietnam
Geographic coordinates: 30 N, 112 30 E
Map references: Southeast Asia
Area: total: 329,847 sq km
country comparison to the world: 67
land: 328,657 sq km
water: 1,190 sq km
Area—comparative: slightly larger than New Mexico
Land boundaries: total: 2,669 km
border countries: Brunei 381 km, Indonesia 1,782
km, Thailand 506 km
Coastline: 4,675 km (Peninsular Malaysia 2,068
km, East Malaysia 2,607 km)
Maritime claims: territorial sea: 12 nm
exclusive economic zone: 200 nm
continental shelf: 200 m depth or to the depth
of exploitation; specified boundary in the South
China Sea
Climate: tropical; annual southwest (April to
October) and northeast (October to February)
monsoons
Terrain: coastal plains rising to hills and
mountains
Elevation extremes: lowest point: Indian Ocean
Om
highest point: Gunung Kinabalu 4,100 m
Natural resources: tin, petroleum, timber, cop-
per, iron ore, natural gas, bauxite
Land use: arable land: 5.44%
permanent crops: 17.49%
other: 77.07% (2011)
Irrigated land: 3,800 sq km (2009)
Total renewable water resources: 580 cu km
(2011)
Freshwater withdrawal (domestic/indus-
trial/agricultural): total: 11.2 cu km/yr
(35%/43%/22%)
per capita: 414 cu m/yr (2005)
Natural hazards: flooding; landslides; forest fires
Environment—current issues: air pollution from
industrial and vehicular emissions; water pollution
from raw sewage; deforestation; smoke/haze from
Indonesian forest fires .
Environment—international agreements:
party to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Endan-
gered Species, Hazardous Wastes, Law of the Sea,
Marine Life Conservation, Ozone Layer Protec-
tion, Ship Pollution, Tropical Timber 83, Tropical
Timber 94, Wetlands
signed, but not ratified: none of the selected
agreements
Geography—note: strategic location along Strait
of Malacca and southern South China Sea
Location: Southem Asia, group of atolls in the
Indian Ocean, south-southwest of India
+
Geographic coordinates: 3 15 N, 73 00 E
Location: Southeastern Asia, islands between
Malaysia and Indonesia
Geographic coordinates: 1 22 N, 103 48E
Map references: Southeast Asia
Area: total: 697 sq km
country comparison to the world: 192
land: 687 sq km
water: 10 sq km
Area—comparative: slightly more chan 3.5 times
the size of Washington, DC
Land boundaries: 0 km
Coastline: 193 km
Maritime claims: territorial sea: 3 nm
exclusive fishing zone: within and beyond territo-
rial sea, as defined in treaties and practice
Climate: tropical; hor, humid, rainy; two dis-
tinct monsoon seasons—Northeastern monsoon
(December to March) and Southwestern monsoon
(June to September); inter-monsoon—frequent
afternoon and early evening thunderstorms
Terrain: low land; gently undulating central pla-
teau contains water catchment area and nature
preserve
Elevation extremes: lowest point: Singapore
Strait 0 m
highest point: Bukit Timah 166 m
Naturai resources: fish, deepwater ports
Land use: arable land: 0.89%
permanent crops: 0.14%
other: 98.97% (2011)
Irrigated land: NA
Total renewable water resources: 0.6 cu km
(2011)
Freshwater withdrawal (domestic/industrial/
agricultural): total:0.19 cu km/yr (47%/53%/0%)
per capita: 81.97 cu m/yr (2005)
Natural hazards: NA
Environment—current issues: industrial pollu-
tion; limited natural freshwater resources; limited
land availability presents waste disposal problems;
seasonal smoke/haze resulting from forest fires in','ba37f2d3fc98b3a471ba937150530a2acb505af4652f9f2bf946b007414a4a5d','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3067a2f184119c7c82fa059aa5a2f6cde91aa02232ef4a182e74bcfc080e3bfd',2025,'MV','Maldives','geography',1056,'Map references: Asia
Area: total:298 sq km
country comparison to the world: 210
land: 298 sq km
water: 0 sq km
Areo—comparative: about 1.7 times the size of
Washington, DC
Land boundaries: 0 km
Coastline: 644 km
Maritime claims: measured from claimed archi-
pelagic straight baselines territorial sea: 12 nm
contiguous zone: 24 nm exclusive economic zone:
200 nm
Climate: tropical; hot, humid; dry, northeast mon-
soon (November to March); rainy, southwest mon-
soon (June to August)
Terrain: flat, with white sandy beaches
Elevation extremes: lowest point: Indian Ocean
Om
highest point: unnamed location on Viligili in the
Addu Atholhu 2.4 m
Natural resources: fish
Land use: arable land: 10%
permanent crops: 10%
other: 80% (2011)
irrigated land: 0 sq km NA (2003)
Total renewable water resources: 0.03 cu km
(2011)
Freshwater withdrawal (domestic/industrial/
agricultural): total: 0.01 cu km/yr (95%/5%/0%)
per capita: 18.44 cu m/yr (2008)
Natural hazards: tsunamis; low elevation of
islands makes them sensitive to sea level rise
Environment—current issues: depletion of
freshwater aquifers threatens water supplies; global
warming and sea level rise; coral reef bleaching
Environment—international agreements:
party to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Hazard-
ous Wastes, Law of the Sea, Ozone Layer Protec-
tion, Ship Pollution
signed, but not ratified: none of the selected
agreements
Geography—note: 1,190 coral islands grouped
into 26 atolls“ (200 inhabited islands, plus 80
islands with tourist resorts); archipelago with stra-
tegic location astride and along major sea lanes in
Indian Ocean','0477c052f70c5f2ae666eae66ef6434abb4751339d56dde50350c7398ed364db','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('babdc0017e2e3b751d6e77d3e0850ffe3c9ca54ffb7cc4cd2db77049b4c98f35',2025,'ML','Mali','geography',1076,'Location: Southern Europe, islands in the Medi-
terranean Sea, south of Sicily (Italy)
Geographic coordinates: 35 50 N, 14 35 E
Map references: Europe
Area: total: 316 sq km
country comparison to the world: 208
land: 316 sq km
water: 0 sq km
Area—comparative: slightly less than twice the
'' size of Washington, DC
Land boundaries: Okm |
Coastline; 196.8 km (excludes 56 km for the
island of Gozo)
Maritime claims: territorial sea: 12 nm contigu-
ous zone: 24 nm
continental shelf: 200 m depth or to the depth of
exploitation exclusive fishing zone: 25 nm
Climate: Mediterranean; mild, rainy winters; hor,
dry summers
Terrain: mostly low, rocky, flat tọ dissected plains;
many coastal cliffs
Elevation extremes: lowest point: Mediterra-
nean Sea 0 m
highest point: Ta’Dmejrek 253 m (near Dingli)
Natural resources: limestone, salt, arable land
Land use: arable land: 28.12%
permanent crops: 4.06%
other: 67.81% (2011)
Irrigated land: 32 sq km (2007)
Total renewable water resources: 0.05 cu km
(2011)
466
Freshwater withdrawal (domestic/industrial/
agricultural): total:0.05 cu km/yr (64%/1%/35%)
per capita: 134.1 cu m/yr (2009)
Natural hazards: NA
Environment—current issues: limited natu-
ral freshwater resources; increasing reliance on
desalination
Environment—international agreements:
party to: Air Pollution, Biodiversity, Climate
Change, Climate Change-Kyoto Protocol, Deser-
tification, Endangered Species, Hazardous Wastes,
Law of the Sea, Marine Dumping, Ozone Layer
Protection, Ship Pollution, Wetlands
signed, but not ratified: none of the selected
agreements *
Geography—note: the country comprises an
archipelago, with only the three largest islands
(Malta, Ghawdex or Gozo, and Kemmuna or
Comino) being inhabited; numerous bays provide
good harbors; Malta and Tunisia are discussing
the commercial exploitation of the continental
shelf between their countries, particularly for oil
exploration','85fd050a4601ebd4c2db9397340a492bbdb316e960fa5bcf83ffb6022c48d974','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4fdc10e47cb91f6fb697b674e647eac0a1df9176a626202be709d49fb8a7b181',2025,'MH','Marshall Islands','geography',1086,'Location: Oceania, two archipelagic island chains
of 29 atolls, each made up of many small islets,
and five single islands in the North Pacific Ocean,
about half way between Hawaii and Australia
Geographic coordinates: 9 00 N, 168 00 E
Map references: Oceania
a
Area: total: 181 sq km
country comparison to the world:217 .
land: 181 sq km
water: 0 sq km
note: the archipelago includes 11,673 sq km
of lagoon waters and encompasses the atolls of
Bikini, Enewetak, Kwajalein, Majuro, Rongelap,
and Utirik
Area—comparative: about the size of Washing-
ton, DC
Land boundaries: km
Coastline: 370.4 km
Maritime claims: territorial sea: 12 nm contigu-
ous zone: 24 nm exclusive economic zone: 200 nm
Climate: tropical; hot and humid; wet season May
to November; islands border typhoon belt
Terrain: low coral limestone ana sana islanas
Elevation extremes: lowest point: Pacific Ocean
Om
highest point: unnamed location on Likiep 10 m
Natural resources: coconut products, marine
products, deep seabed minerals
Land use: arable land: 11.11%
permanent crops: 44.44%
other: 44.44% (2011)
irrigated land: 0 sq km (2011)
Natural hazards: infrequent typhoons
Environment—current issues: inadequate sup-
plies of potable’ water; pollution of Majuro lagoon
from household waste and discharges from fishing
vessels
Environment— international agreements:
party to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Hazard-
ous Wastes, Law of the Sea, Ozone Layer Protec-
tion, Ship Pollution, Wetlands, Whaling
signed, but not ratified: none of the selected
agreements
Geography—note: the islands of Bikini and
Enewetak are former US nuclear test sites;
Kwajalein atoll, famous as a World War II bat-
tleground, surrounds the world’s largest lagoon
and is used as a US missile test range; the island
city of Ebeye is the second largest settlement in
the Marshall Islands, after the capital of Majuro,
and one of the most densely populated locations
in the Pacific
Location: Western Africa, bordering the North
Atlantic Ocean, between Senegal and Western
Sahara
Geographic coordinates: 20 00 N, 12 00 W
Map references: Africa
Area: total: 1,030,700 sq km
country comparison to the world: 29
land: 1,030,700 sq km
water: 0 sq km
Area—comparative: slightly larger than three
times the size of NewMexica
Land boundaries: total: 5,074 km
border countries: Algeria 463 km, Mali 2,237 km,
Senegal 813 km, Western Sahara 1,561 km
Coastline: 754 km
Maritime claims: territorial sea: 12 nm
472
O I0) 200km
oe H
10 200 mu
contiguous zone: 24 nm
exclusive economic zone: 200 nm
continental shelf: 200 nmor to the edge of the
continental margin
Climate: desert; constantly hot, dry, dusty
Terrain: mostly barren, flat plains of the Sahara;
some central hills
Elevation extremes: lowest point: Sebkhet Te-n-
Dghamcha -5 m
highest point: Kediet ljill 915 m
Natural resources: iron ore, gypsum, copper,
phosphate, diamonds, gold, oil, fish
Land use: arable land:0.44%
permanent crops: 0.01%
other: 99.55% (2011)
Irrigated land: sq km(2004)
Total renewable water resources; cu km(2011)
Freshwater withdrawal (domestic/industrial/
agricultural): total: 1.35 cu km/yr (7%/2%/91%)
per capita: 420.2 cu m/yr (2005)
Natural hazards: hot, dry, dust/sand-laden sirocco
wind blows primarily in March and April; periodic
droughts
Environment—current issues: overgrazing,
deforestation, and soil erosion aggravated by
drought are contributing to desertification; lim-
ited natural freshwater resources away fromthe
Senegal, which is the only perennial river; locust
infestation
Environment—international agreements:
party to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Endan-
gered Species, Hazardous Wastes, Law of the Sea,
Ozone Layer Protection, Ship Pollution, Wet-
lands, Whaling
signed, but not ratified: none of the selected
agreements
Geography—note: most of the population is
concentrated in the cities of Nouakchott and
Nouadhibou and along the Senegal River in the
southern part of the country','ab43fb7e15abeacd2de014b28f379d3897cf741a67b855f582a95f12c6052db6','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c0400d461f8701e881e946a05fc18b6bc15767e596d8ac8f62686605c7ac0f94',2025,'MR','Mauritania','geography',1096,'Location: Southern Africa, island in the Indian
Ocedn, east of Madagascar
Geographic coordinates: 20 17 S, 57 33 E
Map references: Africa
Area: total: 2,040 sq km
country comparison to the world: 181
land: 2,030 sq km
water: 10 sq km
note: includes Agalega Islands, Cargados Carajos
Shoals (Saint Brandon), and Rodrigues
Area—comparative: almost 11 times the size of
Washington, DC
Land boundaries: km
Coastline: 177 km
Maritime claims: measured from claimed archi-
pelagic straight baselines
territorial sea: 12 nm
exclusive economic zone: 200 nm
continental shelf: 200 nm or to the edge of the
continental margin
Climate: tropical, modified by southeast trade
winds; warm, dry winter (May to November); hot,
wet, humid summer (November to May)
Terrain: small coastal plain rising to discontinuous
mountains encircling central plateau
Trafficking in persons: current situation: Mauri-
tania is a source and destination country for men,
women, and children subjected to conditions of
forced labor and sex trafficking; women, men, and
children fromtraditional slave castes are subjected to
slavery-related practices rooted in ancestral master-
slave relationships; Mauritanian boys called talibe
are trafficked within the country by religious teach-
ers for forced begging; Mauritanian girls, as well as
girls fromMali, Senegal, The Gambia, and other
West African countries, are forced into domestic
servitude; Mauritanian women and girls are forced
into prostitution in the country or transported to
countries in the Middle East for the same purpose
tier rating: Tier 3—the Government of Mauritania
does not fully comply with the minimumstandards
for the elimination of tiafficking and is not making
significant efforts to do so; the government acknowl-
edges that some forms of trafficking are a problemin
the country, and during the year, it created a multi-
stakeholder body to lead its efforts related to child
trafficking, child smuggling, and child labor; heredi-
tary slavery was officially outlawed in 2007, but
many officials do not recognize that the practice
continues despite its prohibition; the government
did not take proactive measures to identify traffick-
ing victims or provide themwith protective services,
and it continued to jail individuals in prostitution
and detain illegal migrants without screening either
population for trafficking victims (2009)
Elevation extremes: lowest point: Indian Ocean
Om
highest point: Mont Piton 828 m
Natural resources: arable land, fish
Land use: arable land: 38.24%
permanent crops: 1.96%
other: 59.8% (2011)
Irrigated land: 212.2 sq km (2003)
Total renewable water resources: 2.75 cu km
(2011)
Freshwater withdrawal (domestic/industrial/
agricultural): total:0.73 cu km/yr (30%/3%/68%)
per capita: 568.2 cu m/yr (2003)
Natural hazards: cyclones (November to April);
almost completely surrounded by reefs thac may
pose maritime hazards
Environment—current issues: water pollution,
degradation of coral reefs
Environment—international agreements:
party to: Antarctic-Marine Living Resources,
Biodiversity, Climate Change, Climate Change-
Kyoto Protocol, Desertification, Endangered
Species, Environmental Modification, Hazardous
Wastes, Law of the Sea, Marine Life Conserva-
tion, Ozone Layer Protection, Ship Pollution,
Wetlands
signed, but not ratified: none of the selected
agreements
Geography—note: the main island, from which
the country derives its name, is of volcanic origin
and is almost entirely surrounded by coral reefs;
former home of the dodo, a large flightless bird
related to pigeons, driven to extinction by the
475
end of the 17th century through a combination of
hunting and the introduction of predatory species','00c814f2aacc349a6760bac53de459f2d5a4bb5b4b79a5f07bd356db59c17a61','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('12804dbf91aa73d360c7295b14404afa5bd5e34739876327c3c931aa377c7d56',2025,'RO','Romania','geography',1108,'Location: Eastern Europe, northeast of Romania
Geographic coordinates: 47 00 N, 29 00 E
Map references: Europe
Area: total: 33,851 sq km
country comparison to the world: 140
land: 32,891 sq km
water: 960 sq km
Area—comparative:
Maryland
Land boundaries: total: 1,390 km
border countries: Romania 450 km, Ukraine 940
km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
Climate: moderate winters, warm summers
slightly larger than
Terrain: rolling steppe, gradual slope south ro
Black Sea
Elevation extremes: lowest point: Dniester (Nis-
tru) 2m
highest point: Dealul Balanesti 430 m
Natural resources: lignite, phosphorites, gypsum,
arable land, limestone
Land use: arable land: 53.47%
permanent crops: 8.77%
other: 37.75% (2011)
Irrigated land: 2,283 sq km (2011)
Total renewable water resources: 11.65 cu km
(2011)
Freshwater withdrawal (domestic/industrial/
agricultural); total: 1.07 cu km/yr (14%/83%/4%)
per capita: 290 cu m/yr (2010)
Natural hazards: landslides
Environment—current issues: heavy use of
agricultural chemicals, including banned pe
cides such as DDT. has contaminated soil and
groundwater; extensive soil erosion from poor
farming methods
Environment—iniernational agreements:
party to: Air Pollution, Air Pollution-Persis-
tent Organic Pollutants
Change
Desertification, Endangered Spec
Biodiversity limate
Climate Change-Kyo
Wastes, Ozone Layer Protection, Ship
Wetlands
signed, but not ratified: none of the selected
agreements
Geography—note: landlocked; well endowed
with various sedimentary rocks and mine
including sand, gravel, gypsum, and limestone
Location: Western Europe, bordering the Mediter-
ranean Sea on the southern coast of France, near
the border with Italy
Geographic coordinates: 43 44 N, 7 24 E
Map references: Europe
Area: total: 2 sq km
country comparison to the world: 250
land: 2 sq km
water: 0 sq km
Area—comparative: about three times the size of
The Mall in Washington, DC
Land boundaries: total: 4.4 km
border countries: France 4.4 km
Coastline: 4. 1 km
Maritime claims: territorial sea:12 nm exclusive
economic zone: 12 nm
Climate: Mediterranean with mild, wet winters
and hot, dry summers
Terrain: hilly, rugged, rocky
Elevation extremes: lowest point: Mediterra-
nean Sea 0 m
highest point: Mont Agel 140 m
Natural resources: none
Land use: arable land: 0%
permanent crops: 1%
other: 99% (urban area) (2011)
Irrigated land: NA
Natural hazards: NA
Environment—current issues: NA
a
Climate: temperate; cold, cloudy winters with fre-
quent snow and fog; sunny summers with frequent
showers and thunderstorms
Terrain: central Transylvanian Basin is separated
from the Moldavian Plateau on the east by the
Eastern Carpathian Mountains and separated from
the Walachian Plain on the south by the Transyl-
vanian Alps
Elevation extremes: lowest point: Black Sea 0 m
highest point: Moldoveanu 2,544 m
Natural resources: petroleum (reserves declin-
ing), timber, natural gas, coal, iron ore, salt, arable
land, hydropower
Land use: arable land: 37.73%
permanent crops: 1.86%
other: 60.41% (2011)
Irrigated land: 6,153 sq km (2007)
Total renewable water resources; 211.9 cu km
(2011)
Freshwater withdrawal (domestic/indus-
trial/agricultural): total: 6.88 cu km/yr
(22%/61%/17%)
per capita: 320.8 cu m/yr (2009)
Natural hazards: earthquakes, most severe in
south and southwest; geologic structure and cli-
mate promote landslides
Environment—current issues: soil erosion and
degradation; water pollution; .air pollution in
south from industrial effluents; contamination of
Danube delta wetlands
Environment—international agreements:
party to: Air Pollution, Air Pollution-Persistent
Organic Pollutants,
Protocol, Antarctic Treaty, Biodiversity, Climate
Change, Climate Change-Kyoto Protocol, Deser-
tification, Endangered Species, Environmental
Modification, Hazardous Wastes, Law of the Sea,
Ozone Layer Protection, Ship Pollution, Wet-
lands signed, but not ratified: none of the selected
agreements
Geography—note: controls most easily travers-
able land route between the Balkans, Moldova,
and Ukraine
Location: North Asia bordering the Arctic Ocean,
extending from Europe (the portion west of the
Urals) to the North Pacific Ocean
Geographic coordinates: 60 00 N, 100 00 E
Map references: Asia
Area: total: 17,098,242 sq km
country comparison to the world: 1
land: 16,377,742 sq km
water: 720,500 sq km
Area—comparative: approximately 1.8 times the
size of the US
Lond boundaries: total: 20,241.5 km
border countries: Azerbaijan 284 km, Belarus 959
km, China (southeast) 3,605 km, China (south)
40 km, Estonia 290 km, Finland 1,313 km, Geor-
gia 723 km, Kazakhstan 6,846 km, North Korea
17.5 km, Latvia 292 km, Lithuania (Kaliningrad
Oblast) 227 km, Mongolia 3,441 km, Norway 196
km, Poland (Kaliningrad Oblast) 432 km, Ukraine
1,576 km
Coastline: 37,653 km
Maritime claims: territorial sea: 12 nm
contiguous zone: 24 nm
exclusive economic zone: 200 nm
continental shelf: 200 m depth or to the depth of
exploitation
Climate: ranges from steppes in the south through
humid continental in much of European Russia;
subarctic in Siberia to tundra climate in the polar
north; winters vary from cool along Black Sea
coast to frigid in Siberia; summers vary from warm
in the steppes to cool along Arctic coast
Terrain: broad plain with low hills west of Urals;
vast coniferous forest and tundra in Siberia; uplands
and mountains along southern border regions
Elevation extremes; lowest point: Caspian Sea
-28 m
highest point: Gora El’brus 5,633 m{highest point
in Europe) à
Natura) resources; wide natural resource base
including major deposits of oil, natural gas, coal,
and many strategic minerals, reserves of rare earth
elements, timber
note: formidable obstacles of climate, terrain, and
distance hinder exploitation of natural resources
Land use: arable land: 7.11%
permanent crops: 0.1%
other: 92.79% (2011)
Irrigated land: 43,460 sq km (2008)
Total renewable water resources: 4,508 cu km
(2011)
Freshwater withdrawal (domestic/indus-
frial/agricultural): total: 66.2 cu km/yr
(20%/60%/20%)
per capita: 454.9 cu m/yr (2001)
Natural hazards: permafrost over much of Siberia
is a major impediment to development; volcanic
activity in the Kuril Islands; volcanoes and earth-
quakes on the Kamchatka Peninsula; spring floods
and summer/autumn forest fires throughout Sibe-
ria and parts of European Russia
volcanism: significant volcanic activity on the
Kamchatka Peninsula and Kuril Islands; the pen-
insula alone is home to some 29 historically active
volcanoes, with dozens more in the Kuril Islands;
600
THE CIA WORLD FACTBOOK
Kliuchevskoi (elev. 4,835 m), which erupted
in 2007 and 2010, is Kamchatka’s most active
volcano; Avachinsky and Koryaksky volcanoes,
which pose a threat to the city of Petropavlovsk-
Kamchatskiy, have been deemed “Decade Volca-
noes” by the International Association of Volcan-
ology and Chemistry of the Earth’s Interior, worthy
of study due to their explosive history and close ''
proximity to human populations; other notable
historically active volcanoes include Bezymianny,
Chikurachki, Ebeko, Gorely, Grozny, Karymsky,
Ketoi, Kronotsky, Ksudach, Medvezhia, Mut-
novsky, Sarychev Peak, Shiveluch, Tiatia, Tolba-
chik, and Zheltovsky
Environment—current issues: air pollution
from heavy industry, emissions of coal-fired elec-
tric plants, and transportation in major cities;
industrial, municipal, and agricultural pollution of
inland waterways and seacoasts; deforestation; soil
erosion; soil contamination from improper appli-
cation of agricultural chemicals; scattered areas
of sometimes intense radioactive contamination;
groundwater contamination from toxic waste;
urban solid waste management; abandoned stocks
of obsolete pesticides
Environment—international agreements: party
to: Air Pollution, Air Pollution-Nitrogen Oxides,
Air Pollution-Sulfur 85, Antarctic-Environmental
Protocol, Antarctic-Marine Living Resources,
Antarctic Seals, Antarctic Treaty, Biodiversity,
Climate Change, Climate Change-Kyoto Protocol,
Desertification, Endangered Species, Environmen-
tal Modification, Hazardous Wastes, Law of the
Sea, Marine Dumping, Ozone Layer Protection,
Ship Pollution, Tropical Timber 83, Wetlands,
Whaling
signed, but not ratified: Air Pollution-Sulfur 94
Geography—note: largest country in the world
in terms of area but unfavorably located in rela-
tion to major sea lanes of the world; despite its size,
much of the country lacks proper soils and climates
(either too cold or too dry) for agriculture; Mount
El’brus is Europe’s tallest peak; Lake Baikal, the
deepest lake in the world, is estimated to hold one
fifth of the world’s fresh water','5f5be4d7ce39d9f3ed669f22113201c8f24bec1ca497c3eaa945949c5c256f56','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d27f8940ba112ded99a33890365647fe0ae3fe418e08c2259086aa140edd14a9',2025,'MC','Monaco','geography',1115,'Environment—international agreements:
party to: Air Pollution, Air Pollution-Sulfur
94, Air Pollution-Volatile Organic Compounds,
Biodiversity, Climate Change, Climate Change-
Kyoto Protocol, Desertification, Endangered Spe-
cies, Hazardous Wastes, Law of the Sea, Marine
Dumping, Ozone Layer Protection, Ship Pollution,
Wetlands, Whaling
signed, but not ratified: none of the selected
agreements
Geography—note: second-smallest independent
state in the world (after Holy See); almost entirely
urban','cbe484ea431e7c5a6f2be4615b9c72916bbf4e2539087247de0895b063832b54','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('208eb34687dd45fce4ba7ee0695c96eab677774d430951e1daeb1fbf483bdb46',2025,'MN','Mongolia','geography',1128,'Location: Southeastern Europe, between the
Adriatic Sea and Serbia
Geographic coordinates: 42 30 N, 19 18 E
Map references: Europe
Area: total: 13,812 sq km
country comparison to the world: 162
land: 13,452 sq km
water: 360 sq km
Area—comparative:
Connecticut
Land boundaries: total: 625 km
border countries: Albania 172 km, Bosnia and
Herzegovina 225 km, Croatia 25 km, Kosovo 79
km, Serbia 124 km
slightly smaller than','297af0be3c37599a993d17446bb5e52f58722d7132d7c5ecd9fd949f4fdbfbb0','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4299ba1c123c658fad0d369df02ef5436ab8848bd03a7c8ed60398010b865e43',2025,'ME','Montenegro','geography',1129,'Coastline: 293.5 km
Maritime claims:
territorial sea: 12 nm
continental shelf: defined by treaty
Climate: Mediterranean climate, hot dry sum-
mers and autumns and relatively cold winters
with heavy snow falls inland
Terrain: highly indented coastline with narrow
coastal plain backed by rugged high limestone
mountains and plateaus
Elevation extremes: lowest point: Adriatic Sea
Pm
highest point: Bobotov Kuk 2,522 m
Natural resources: bauxite, hydroelectricity
Land use: arable land: 12.45%
permanent crops: 1.16%
other: 86.39% (2011)
Irrigated land: 24.12 sq km (2010)
Natural hazards: destructive earthquakes
Environment—current issues: pollution of
coastal waters from sewage outlets, especially in
tourist-related areas such as Kotor -
Environment—international agreements:
party to: Air Pollution, Biodiversity, Climate
Change, Climate Change-Kyoto Protocol, Deser-
tification, Hazardous Wastes, Law of the Sea,
Marine Dumping, Marine Life Conservation,
Ozone Layer Protection, Ship Pollution
signed, but not ratified: none of the selected
agreements
Geography—note: strategic location along the
Adriatic coast','a685010be027541d64ac942fde0df5602c21d8c48084d0da26264b1273094e21','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9166614493735f46dd246686f4c4306db20e9ea7c6d483d573553178aacd2a53',2025,'MS','Montserrat','geography',1139,'Location: Caribbean, island in the Caribbean Sea,
southeast of Puerto Rico
Geographic coordinates: 16 45 N, 62 12 W
Map references: Central America and the
Caribbean
Area: total; 102 sq km
country comparison to the world; 226
land: 102 sq km
water: 0 sq km
Area—comparative: about 0.6 times the size of
Washington, DC
Land boundaries: 0 km
Coastline: 40 km
Maritime claims: territorial sea: 3 nm
exclusive fishing zone: 200 nm
Climate: tropical; little daily or seasonal tempera-
ture variation
Terrain: volcanic island, mostly mountainous,
with small coastal low land
Elevation extremes: lowest point: Caribbean
Sea 0 m
highest point: lava dome in English''s Crater (in
the Soufriere Hills volcanic complex) estimated at
over 930 m (2006)
Natural resources: NEGL
Land use: arable land: 20%
permanent crops: 0%
other: 80% (2011)
Irrigated land: NA
498
Natural hazards: volcanic eruptions; severe hur-
ricanes (June to November)
volcanism: Soufriere Hills voleano (elev. 915 m),
has erupted continuously since 1995; a massive
eruption in 1997 destroyed most of the capital,
Plymouth, and resulted in approximately half of
the island becoming uninhabitable
Environment—current issues:
sion occurs on slopes that have been cleared for
cultivation
Geography—note: the island is entirely volcanic
in origin and comprised of three major volcanic
centers of differing ages','d7e91f451da9d8d0d990c3de5d48adce7f2bbbdfbe674f75723d7073f4f387f9','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('66f47fb589b1e694753f5500811ae21d12aee065fbdc5f6dc1f8fdf00b8aeb25',2025,'MA','Morocco','geography',1148,'Location: Northern Africa, bordering the North
Atlantic Ocean and the Mediterranean Sea,
between Algeria and Western Sahara
Geographic coordinates: 32 00 N, 5 00 W
Map references: Africa
Area: total: 446,550 sq km
country comparison to the world: 58
land: 446,300 sq km
water: 250 sq km
Area—comparative:
California
sngntiy larger man
Land boundaries: total:2,017.9 km
border countries: Algeria 1,559 km, Western
Sahara 443 km, Spain (Ceuta) 6.3 km, Spain
(Melilla) 9.6 km
Coastline: 1,835 km
Maritime claims: territorial sea: 12 nm contigu-
ous zone: 24 nm exclusive economic zone: 200 nm
continental shelf: 200 m depth or to the depth oT
exploitation Climate: Mediterranean, becoming more
extreme in the interior
Terrain: northern coast and interior are mountain-
ous with large areas oT bordering plateaus, inter-
montane valleys, and rich coastal plains
Elevation extremes: lowest point: Sebkha Tah
-55 m
highest point: Jebel Toubkal 4,165 m
Natural resources: phosphates, iron ore, manga-
nese, lead, zinc, fish, salt
Land use: arable land: 17.79%
permanent crops: 2.6%
other: 79.61% (2011)
Irrigated land: 14,850 sq km (2004)
Total renewable water resources: 29 cu km
(2011)
Freshwater withdrawal (domestic/indus-
trial/agricultural): total: 12.651 cu km/yr
(12%/4%/84%)
per capita: 428.1 cu m/yr (2005)
Natural hazards: riorthern mountains geologi-
cally unstable and subject to earthquakes; periodic
droughts
Environment—current issues: land degradation/
desertiTication (soil erosion resulting Teom Tarm-
ing oT marginal areas, overgrazing, destruction oT
vegetation); water supplies contaminated by raw
sewage; siltation oT reservoirs; oil pollution oT
coastal waters
Environment—interational agreements:
party to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Endangered
Species, Hazardous Wastes, Law of the Sea, Marine
Dumping, Ozone Layer Protection, Ship Pollution,
Wetlands, Whaling
signed, but not
Modification
Geography—note: strategic location along Strait
of Gibraltar
ratified: Environmental
PEOPLE AND SOCIET)
Nationality: noun: Moroccan(s)
adjective: Moroccan
Ethnic groups: Arab-Berber 99%, other 1%
Languages: Arabic’ (official), Berber languages
(Tamazight (official), Tachelhit, Tarifit), French
(often the language of business, government, and
diplomacy)
Religions: Muslim 99% (official), Christian 1%,
Jewish about 6,000 Population: 32,649,130 (July
2013 est.)
country comparison to the world: 38
Age structure: 0-14 years: 27.1% (male
4,489,297/female 4,353,921) :
15-24 years: 18% (male
2,951,131)
25-54 years: 41.7% (male 6,590,575/female
7,033,013)
55-64 years 7%
1,135,747)
_ 65 years and over: 6.3% (male 919,236/female
1,121,524) (2013 est.)
Median age: total: 27.7 years
male: 27.1 years
female: 28.2 years (2013 est.)
Population growth rate: 1.04% (2013 est.)
country comparison to the world: 111
Birth rate: 18.73 births/1,000 population (2013
est.)
country comparison to the world: 100
Death rate: 4.78 deaths/1,000 population (2013
est.)
country comparison to the world: 194
Net migration rate: -3.56 migrant(s)/1,000 popu-
lation (2013 est.)
* country comparison to the world: 184
Urbanization: urban population: 58% of total
population (2010)
rate of urbanization: 2.1% annual rate of change
(2010-15 est.) ;
Major urban areas—population: Casablanca
3.245 million; RABAT (capital) 1.77 million;
Fes 1.044 million; Marrakech 909,000; Tangier
768,000 (2009)
` Sex ratio: at birth: 1.05 male(s)/female
0-14 years: 1.03 male(s)/female
15-24 years: 0.99 male(s)/female
25-54 years: 0.94 male(s)/female
55-64 years: 1 male(s)/female
65 years and over: 0.82 male(s)/female
total population: 0.97 male(s)/female (2013 est.)
Maternal mortality rate: 100 deaths/100,000 live
births (2010)
country comparison to the world: 70 _
infant mortality rate: total: 25.49 deaths/!,000
live births
country comparison to the world: 75
male: 30.04 deaths/1,000 live births
female: 20.71 deaths/1,000 live births (2013 est.)
Lite expectancy at birth: total population: 76.31
years
2,918,765/female
(male 1,135,921/female
country comparison to the world: 79
male: 73.25 years
female: 79.53 years (2013 est.)
Tota! fertility rate: 2.17 children born/woman
(2013 est.)
country comparison to the world: 106
Health expenditures: 5.2% of GDP (2010)
country comparison to the world: 129
Physicians density: 0.62 physicians/1,000 popu-
lation (2009)
Hospital bed density: 1.1 beds/1,000 population
(2009)
Drinking water source:
Improved
urban: 98% of population
rural: 61% of population
total: 83% of population
Unimproved
urban: 2% of population
rural: 39% of population
total: 17% of population (2010 est.)
Sanitation facility access:
Improved
urban: 83% of population
rural: 52% of population
total: 70% of population
Unimproved
urban: 17% of population
rural: 48% of population
total: 30% of population (2010 est.)
HIV/AiDS—adult prevalence rate: 0.1% (2009
est.)
country comparison to the world: 146
HIV/AIDS—people living with HIV/AIDS: 26,0
(2009 est.) ee
country comparison to the world: 71
HIV/AIDS—deaths: 1,200 (2009 est.)
country comparison to the world: 63
Obesity—aduit prevalence rate: 16.4% (2008)
country comparison to the world: 114
Children under the age of 5 years under-
weight: 3.1% (2011)
country comparison to the world: 111
Education expenditures: 5.4% of GDP (2009)
country comparison to the world: 56
Literacy: definition: age 15 and over can read and
write
total population: 56.1%
male: 68.9%
female: 43.9% (2009 est.)
School life expectancy (primary to tertiary
education): total: 10 years
male: 11 years
female: 10 years (2007)
Unemployment, youth ages 15-24: coral: 17.9%
country comparison to the world: 69
male: 18.1%
female: 17.4% (2011)','e618c3625f191ed4155cacbbc684dfde223440b58d965139659a360ff2e8e07f','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fe16625fead0717d2b1d87dbd6a27e658637758175402c0b543b581c63b96557',2025,'MZ','Mozambique','geography',1157,'Location: Southeastern Africa, bordering the
Mozambique Channel, between South Africa and
Tanzania
Geographic coordinates: 18 15 S, 35 00 E
Map references; Africa
Area: total: 799,380 sq km
country comparison to the world: 35
land: 786,380 sq km
water: 13,000 sq km
Area—comparative: slightly less than twice the
size of California
Land boundaries: total: 4,571 km
border countries: Malawi 1,569 km, South Africa
491 km, Swaziland 105 km, Tanzania 756 km,
Zambia 419 km, Zimbabwe 1,231 km
Coastline: 2,470 km
Maritime claims: territorial sea: 12 nm exclusive
economic zone: 200 nm
foreign investment.
Climate: tropical to subtropical
Terrain: mostly coastal low lands, uplands in
center, high plateaus in northwest, mountains in
west
Elevation extremes: lowest point: Indian Ocean
Om
highest point: Monte Binga 2,436 m
Natural resources: coal, titanium, natural gas,
hydropower, tantalum, graphite
Land use: arable land: 6.51%
permanent crops; 0.25%
other: 93.24% (2011)
Irrigated land: 1,181 sq km (2003)
Total renewable water resources: 217.1 cukm
(2011)
Freshwater withdrawal (domestic/industrial/
agricultural): total:0.88 cu km/yr (26%/4%/70%)
per capita: 46.05 cu m/yr (2005)
Natural hazards: severe droughts; devastat-
ing cyclones and floods in central and southem
provinces
Environment—current issues: a long civil war
and recurrent drought in the hinterlands have
resulted in increased migration of the population
to urban and coastal areas with adverse environ-
mental consequences; desertification; pollution of
surface and coastal waters; elephant poaching for
ivory is a problem
Environment—international agreements:
party to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Endan-
gered Species, Hazardous Wastes, Law of the
Sea, Ozone Layer Protection, Ship Pollution,
Wetlands
signed, but not ratified: none of the selected
agreements
Geography—note: the Zambezi flows through the
north-central and most fertile part of the country','731599f0a4c8a87c50e6c1e703e70772476734e3956de01b78ea1eb96ead3406','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5a7dbb5d0a720ebe353cd1df2521b0c0c30ea592bb5bdc62dd5cd90750b99042',2025,'NA','Namibia','geography',1165,'note: suspected deposits of oil, coal, and iron ore
Land use: arable land:0.97%
permanent crops: 0.01%
other: 99.02% (2011)
irrigated land: 75.73 sq km (2003)
Total renewable water resources: 17.72 cu km
(2011)
Freshwater withdrawal (domestic/industrial/
agricultural): total:0.29 cu km/yr (25%/5%/70%)
per capita: 146 cu m/yr (2002)
Natural hazards: prolonged periods of drought
Environment—current issues:
ral freshwater resources; desertification; wildlife
poaching; land degradation has led to few conser-
vation areas
Environment—international agreements:
party to: Antarctic-Marine Living Resources,
Biodiversity, Climate Change, Climate Change-
Kyoto Protocol, Desertification, Endangered Spe-
cies, Hazardous Wastes, Law of the Sea, Ozone
Layer Protection, Wetlands
signed, but not ratified: none of the selected
agreements
Geography—note: first country in the world to
incorporate the protection of the environment
into its constitution; some 14% of the land is pro-
tected, including virtually the entire Namib Desert
coastal strip
Location: Oceania, island in the South Pacific
Ocean, south of the Marshall Islands
Geographic coordinates: 0 32 S, 166 55 E
914 to 1,523 m: 52
under 914 m: 16 (2012)
Railways: total: 2,626 km
country comparison to the world: 63
narrow gauge: 2,626 km 1.067-m gauge (2008)
Roadways: total: 64,189 km
country comparison to the world: 70
paved: 5,477 km
unpaved: 58,712 km (2010)
Merchant marine: coral: |
country comparison to the world: 151
by type: cargo 1 (2010)
` Ports and terminals: Luderitz, Walvis Bay','1785eb20aaa5491d49507db805d0bfbddee71ce00f30a6e8fbbfdbe5e96fed4c','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('96d0ad684a9f757462f8c94fb3734a4c35c05b23f8cb30b2e0907e6bf3e7c32f',2025,'NR','Nauru','geography',1181,'Location: Caribbean, island in the Caribbean Sea,
35 miles west of Tiburon Peninsula of Haiti
Geographic coordinates: 18 25 N, 75 02 W
Map references: Central America and the
Caribbean
KALIMANDU
tine
Location: Southern Asia, between China and
India ‘
Geographic coordinates: 28 00 N, 84 00 E
Map references: Asia
Area: total: 147,181 sq km
country comparison to the world: 94
land: 143,351 sq km
water: 3,830 sq km
Area—comparative:
Arkansas
Land boundaries: total: 2,926 km
slightly larger than
border countries: China 1,236 km, India 1,690
km
Coostline: 0 km (landlocked)
Maritime claims: none (landlocked)
Climate: varies from cool summers and severe
winters in north to subtropical summers and mild
winters in south
Terrain: Tarain or flat river’plain of the Ganges
in south, central hill region, rugged Himalayas in
north
Elevation extremes: lowest point: Kanchan
Kalan 70 m
highest point: Mount Everest 8,850 m (highest
point in Asia)
Natural resources: quartz, water, timber, hydro-
power, scenic beauty, small deposits of lignite, cop-
per, cobalt, iron ore
Land use: arable land: 16%
permanent crops: 0.8%
other: 83.2% (2011)
irrigated land: 11,680 sq km (2003)
Total renewable water resources: 210.2 cu km
(2011)
Freshwater withdrawal (domestic/industric/
agricultural): total: 9.5 cu km/yr (2%/0%/98%)
per capita: 334.7 cu-m/yr (2006)
Natural hazards: severe thunderstorms; flood-
ing; landslides; drought and famine depending on
the timing, intensity, and duration of the summer
monsoons
Environment—current issues: deforestation
(overuse of wood for fuel and lack of alternatives);
contaminated water (with human and animal
wastes, apricultural runoff, and industrial efflu-
ents); wildlife conservation; vehicular emissions
Environment—international agreements:
party to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Endan-
gered Species, Hazardous Wastes, Law of the Sea,
Ozone Layer Protection, Tropical Timber 83, Trop-
ical Timber 94, Wetlands
signed, but not ratified: Marine Life Conservation
Geography—note: landlocked; strategic loca-
tion between China and India; contains eight of
world’s 10 highest peaks, including Mount Everest
and Kanchenjunga—the world’s tallest and third
tallest—on the borders with China and India
respectively','3b32645bc4ba37a019bc4bc813d7a20e1e287fbfc865ee1be0e41cb5527a9cf2','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fb766135a873879df047017292eaa7bc15e630c03e5e4aa83d0d3069902336cf',2025,'NL','Netherlands','geography',1193,'Location: Western Europe, bordering the North
Sea, between Belgium and Germany
518
Geographic coordinates: 52 30 N, 5 45 E
Map references: Europe `
Area: total: 41,543 sq km
country comparison to the world: 135
land: 33,893 sq km
water: 7,650 sq km
Area—comparative: slightly less than twice the
size of New Jersey
Land boundaries: total: 1,027 km
border countries: Belgium 450 km, Germany 577
km
Coastline: 451 km
Maritime claims: territorial sea: 12 nm
contiguous zone: 24 nm
exclusive fishing zone: 200 nm
Climate: temperate; marine; cool summers and
mild winters
Terrain: mostly coastal lowland and reclaimed
land (polders); some hills in southeast
Elevation extremes: lowest point:Zuidplaspolder
-1m
highest point: Mount Scenery 862 m (on the
island of Saba in the Caribbean, now considered
an integral part of the Netherlands following the
dissolution of the Netherlands Antilles)
note: the highest point on continental Neéther-
lands is Vaalserberg at 322 m
Natural resources: natural gas, petroleum, peat,
limestone, salt, sand and gravel, arable land
Land use: arable land: 25.08%
permanent crops: 0.88%
other: 74.04% (2011)
Irrigated land: 4,572 sq km (2007)
Total renewable water resources: 91 cu km
(2011)
Freshwater withdrawal (domestic/indus-
trialV/agricultural): total: 10.61 cu km/yr
(12%/88%/1%)
per capita: 636.7 cu m/yr (2008)
Natural hazards: flooding
Environment—current issues: water pollution
in the form of heavy metals, organic compounds,
and nutrients such as nitrates and phosphates; air
pollution from vehicles and refining activities;
acid rain
Environment—international agreements:
party to: Air Pollution, Air Pollution-Nitrogen
Oxides, Air Pollution-Persistent Organic Pollutants,
Air Pollution-Sulfur 85, Air Pollution-Sulfur 94, Air
Pollution- Volatile Organic Compounds, Antarctic-
Environmental Protocol, Antarctic-Marine Living
Resources, Antarctic Treaty, Biodiversity, Climate
Change, Climate Change-Kyoto Protocol, Deserti-
fication, Endangered Species, Environmental Modi-
fication, Hazardous Wastes, Law of the Sea, Marine
Dumping, Marine Life Conservation, Ozone Layer
Protection, Ship Pollution, Tropical Timber 83,
Tropical Timber 94, Wetlands, Whaling
signed, but not ratified: none of the selected
agreements
Geography—note: located ar mouths of three
major European rivers (Rhine, Maas or Meuse,
and Schelde)
PEOPLE AND SODIETY
Nationality: noun:
Dutchwoman(women)
adjective: Dutch
Ethnic groups: Dutch 80.7%, EU 5%, Indonesian
2.4%, Turkish 2.2%, Surinamese 2%, Moroccan
2%, Caribbean 0.8%, other 4.8% (2008 est.)
Languages: Dutch (official), Frisian (official)
Religions: Roman Catholic 30%, Protestant 20%
(Dutch Reformed 11%, Calvinist 6%, other Prot-
estant 3%), Muslim 5.8%, other 2.2%, none 42%
(2006)
Population: 16,805,037 (July 2013 est.)
country comparison to the world: 64
Age structure: 0-14 years: 17.1% (male 1,468,364/
female 1,401,651)
15-24 years: 12.2% (male 1,041,181/female
1,002,125)
25-54 years: 40.8% (male 3,436,713/female
3,411,374)
55-64 years: 12.9% (male 1,083,095/female
1,085,929)
65 years and over: 17.1% (male 1,284,788/female
1,589,817) (2013 est.) i
Median age: total: 41.8 years
male: 41 years
female: 42.6 years (2013 est.)
Dutchman(men),
Population growth rate: 0.44% (2013 est.)
country comparison to the world: 155
Birth rate: 10.85 births/1,000 population (2013 est.)
country comparison to the world: 176
Death rate: 8.48 deaths/1,000 population (2013
est.) `
country comparison to the world: 82
Net migration rate: 1.99 migrant(s)/1,000 popu-
lation (2013 est.)
country comparison to the world: 40
Urbanization: urban population: 83% of total
population (2010)
rate of urbanization: 0.8% annual rate of change
(2010-15 est.)
Major urban areas—population: AMSTER-
DAM (capital) 1.044 million; Rotterdam 1.008
million; The Hague (seat of government) 629,000
(2009)
Sex ratio: at birth: 1.05 male(s)/female
0-14 years: 1.05 male(s)/female
15-24 years: 1.04 male(s)/female
25-54 years: 1.01 male(s)/female
55-64 years: 1 male(s)/female
65 years and over: 0.8 male(s)/female
total population: 0.98 male(s)/female (2013 est.)
Maternal mortality rate: 6 deaths/100,000 live
births (2010)
country comparison to the world: 170
infant mortality rate: total: 3.69 deaths/1,000
live births
country comparison to the world: 205 male:3.99
deaths/1,000 live births
female: 3.38 deaths/1,000 live births (2013 est.)
Life expectancy at birth: total population:81.01
years
country comparison to the world: 21
male: 78.93 years
female: 83.21 years (2013 est.)
Total fertility rate: 1.78 children born/woman
(2013 est.)
country comparison to the world: 154
Health expenditures: 11.9% of GDP (2010)
country comparison to the world: 7
Physicians density: 3.92 physicians/1,000 popu-
lation (2007) .
Hospital bed density: 4.7 beds/1,000 population
(2009)
Drinking water source: im proved: urban: 100%
of population
rural: 100% of population
total: 100% of population (2010 est.)
Sanitation facility access: im proved: urban:
100% of population
rural: 100% of population
total: 100% of population (2010 est.)
HIV/AIDS—adult prevalence rate: 0.2% (2009
est.)
country comparison to the world: 104
HIV/AIDS—people living with HIV/AIDS: 22,0
(2009 est.)
country comparison to the world: 74
HIV/AIDS—deaths: fewer than 100 (2009 est.)
country comparison to the world: 146
Obesity—adult prevalence rate: 18.8% (2008)
country comparison to the world: 103
Education expenditures: 5.9% of GDP (2009)
country comparison to the world; 42
a
Literacy: definition: age 15 and over can read and
write
total population: 99%
male:99% °
female:99% (2003 est.)
School life expectancy (primary to tertiary
education): total: 17 years
male: 17 years
female: 17 years (2008)
Unemployment, youth ages 15-24: total: 7.7%
country comparison to the world: 122 male:
7.5%
female: 7.8% (2011)
Location: Oceania, islands in the South Pacific
Ocean, east of Australia Geographic coordinates:
21 30S, 165 30E
Map references: Oceania
Area: total: 18,575 sq km
country comparison to the world: 156
land: 18,275 sq km
water: 300 sq km
Area—comparative: slightly smaller than New','f33753fd59836a6bf11828fbffadaf15cc81fdf56a0e51169f7a756dd589c0a6','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4f52d7ade8822120d04181a9bccdb2057fc15c83c8ac4b15fb7864189fd5674a',2025,'NI','Nicaragua','geography',1215,'Location: Central America, bordering both the
Caribbean Sea and the North Pacific Ocean,
between Costa Rica and Honduras
Geographic coordinates: 13 00 N, 85 00 W
Map references: Central America and the
Caribbean
528
Area: total: 130,370 sq km
country comparison to the world; 98
land: 119,990 sq km
water: 10,380 sq km
Area—comparative: slightly smaller than New
York state
Land boundaries: total: 1,231 km
border countries: Costa Rica 309 km, Honduras
922 km
Coastline: 910 km
Maritime claims: territorial sea: 12 nm
contiguous zone: 24 nm
continental shelf: natural prolongation
Climate: tropical in lowlands, cooler in highlands
Terrain: extensive Atlantic coastal plains rising to
central interior mountains; narrow Pacific coastal
plain interrupted by volcanoes
Elevation extremes: lowest point: Pacific Ocean
Om
highest point: Mogoton 2,438 m
Natural resources: gold, silver, copper, tungsten,
lead, zinc, timber, fish
Land use: arable land: 14.57%
permanent crops; 1.76%
other: 83.66% (2011)
Irrigated land: 942.4 sq km (2003)
Total renewable water resources: 196.6 cu km
(2011)
Freshwater withdrawal (domestic/industrial/
agricultural): total: 1.39 cu km/yr (23%/4%/73%)
per capita: 265.9 cu m/yr (2008)
Natural hazards: earthquakes;
volcanoes; landslides; extremely susceptible to
hurricanes
volcanism: significant volcanic activity; Cerro
Negro (elev. 728 m), which last erupted in 1999,
is one-of Nicaragua''s most active volcanoes; its
lava flows and ash have been known to cause sig-
nificant damage to farmland and buildings; other
historically active volcanoes include Concepcion,
Cosiguina, Las Pilas, Masaya, Momotombo, San
Cristobal, and Telica
destructive
Environment—current {ssues: deforestation;
soil erosion; water pollution
Environment—international agreements:
party to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Endan-
gered Species, Environmental Modification, Haz-
ardous Wastes, Law of the Sea, Ozone Layer Pro-
tection, Ship Pollution, Wetlands, Whaling
signed, but not ratified: none of the selected
agreements
Geography—note: largest country in Central
America; contains the largest freshwater body in
Central America, Lago de Nicaragua
Location: Western Africa, southeast of Algeria
Geographic coordinates: 16 00 N, 8 00 E
Map references: Africa
Area: total: 1.267 million sq km
country comparison to the world: 22
land: 1,266,700 sq km
water: 300 sq km
Area—comparative: slightly less than twice the
size of Texas
Tahoua
.
ECHAN
AER
532
_ km, Mali 821 km, Nigeria 1,497 km
THE CIA WORLD FACTBOOK
Land boundaries: total: 5,697 km
border countries: Algeria 956 km, Benin 266 km,
Burkina Faso 628 km, Chad 1,175 km, Libya 354
Coastline: km (landlocked) .
Maritime claims: none (landlocked)
Climate: desert; mostly hot, dry, dusty; tropical in
extreme south
Terrain: predominately desert plains and sand
dunes; flat to rolling plains in south; hills in north
Elevation extremes: lowest point: Niger River
200 m
highest point: Idoukal-n-Taghes 2,022 m
Notural resources: uranium, coal, iron ore, tin,
phosphates, gold, molybdenum, gypsum, salt,
petroleum
Land use: arable land: 11.79%
permanent crops: 0.05%
other: 88.16% (2011)
Irrigated land: 736.6 sq km (2005)
Total renewable water resources: 33.65 cu km
(2011)
Freshwater withdrawal (domestic/industrial/
agricultural): toral:0.98 cu km/yr (30%/3%/67%)
per capita: 70.53 cu m/yr (2005)
Natural hazards: recurring droughts
Environment—current issues: overgrazing; soil
erosion; deforestation; desertification; wildlife
populations (such as elephant, hippopotamus,
giraffe, and lion) threatened beaause of poaching
and habitat destruction l
Environment—international agreements:
party to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Endan-
gered Species, Environmental Modification, Haz-
ardous Wastes, Ozone Layer Protection, Wetlands
signed, but not ratified: Law of the Sea
Geography—note: landlocked; one of the hot-
test countries in the world; northern four-fifths is
desert, southern one-fifth’ is savanna, suitable for
livestock and limited agriculture','216ca19136402741ef9d200d6b632f5d4197b22e1aaa523e34e74f86d5378efc','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('923c69cd6478f1cb7aa588f654a51b9281fcdd97c65ad60d41dc94b159a8f298',2025,'NE','Niger','geography',1231,'Location: Western Africa, bordering the Gulf of
Guinea, between Benin and Cameroon
Geographic coordinates: 10 00 N, 8 00 E
Map references: Africa
Area: total: 923,768 sq km
country comparison to the world: 32
land: 910,768 sq km
water: 13,000 sq km
Area—comporative: slightly more than twice the
size of California
Land boundaries: total: 4,047 km
border countries: Benin 773 km, Cameroon
1,690 km, Chad 87 km, Niger 1,497 km
Coastline: 853 km
Maritime claims: territorial sea: 12 nm
exclusive economic zone: 200 nm
continental shelf: 200 m depth or to the depth of
exploitation
Climate: varies; equatorial in south, tropical in
center, arid in north
Terrain: southern lowlands merge into central
hills and plateaus; mountains in southeast, plains
in north
Elevation extremes: lowest point: Atlantic
Ocean 0m
highest point: Chappal Waddi 2,419 m
Natural resources: natural gas, petroleum, tin,
iron ore, coal, limestone, niobium, lead, zinc,
arable land
Land use: arable land: 38.97%
permanent crops: 3.46%
535
other: 57.57% (2011)
Irrigated land: 2,932 sq km (2004)
Total renewable water resources: 286.2 cu km
(2011)
Freshwater withdrawal _(domestic/indus-
trial/agricultural): ‘coral: 13.11 cu km/yr
(31%/15%/54%)
per capita: 89.21 cu m/yr (2005)
Natural hazards: periodic droughts; flooding
Environment—current issues: soil degradation;
rapid deforestation; urban air and water pollution;
desertification; oil pollution—water, air, and soil;
has suffered serious damage from oil spills; loss of
arable land; rapid urbanization
Environment—international agreements:
party to: Biodiversity, Climate Change, Cli-
mate Change-Kyoto Protocol, Desertification,
Endangered Species, Hazardous Wastes, Law of
the Sea, Marine Dumping, Marine Life Conser-
vation, Ozone Layer Protection, Ship Pollution,
Wetlands
signed, but not ratified: none of the selected
agreements
Geography—note: the Niger enters the country
in the northwest and flows southward through
tropical rain forests and swamps to its delta in the
Gulf of Guinea','3b5e8b03de42dd7307f6cb270a322f1e0a3f350f8111f532c4b78def954b3bc8','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6e1fbb187643d788cfe436c9b32a3b56fc33cbd91038900dc9be2fca4216eaa3',2025,'NF','Norfolk Island','geography',1241,'Location: Oceania, island in the South Pacific
Ocean, east of Australia
Geographic coordinates: 29 02 S, 167 57 E
Map references: Oceania
Area: total: 36 sq km
country comparison to the world: 235
land: 36 sq km
water: 0 sq km
Area—comparative: about 0.2 times the size of
Washington, DC
Land boundaries: 0 km
Coastline: 32 km
Maritime claims: territorial sea: 12 nm
exclusive fishing zone: 200 nm
Climate: subtropical; mild, little seasonal tem-
perature variation
Terrain: volcanic formation with mostly rolling
plains
Elevation extremes: lowest point: Pacific Ocean
Om =.
highest point: Mount Bates 319 m
Natural resources: fish
Land use: arable land:0%
permanent crops: 0%
other: 100% (2011)
Irrigated land: NA
Notural hazards: typhoons (especially May to
July)
Environment—current issues: NA
Geography—note: most of the 32 km coastline
consists of almost inaccessible cliffs, but the land
slopes down to the sea in one small southern area
on Sydney Bay, where the capital of Kingston is
situated','fc44f2c3a38eed39acda799c99049d7ed191ba19088876ac8bdfdc257df8897a','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5ca79f4435f3c21ec9da852b1a0f9096b66ea6c1bdf36f7acde7e176ef2952ab',2025,'MP','Northern Mariana Islands','geography',1244,'Irrigated fand: 1 sq km (2011)
Natura! hazards: active volcanoes on Pagan
and Agrihan; typhoons (especially August to
November)
Environment—current issues: contamination of
groundwater on Saipan may contribute to disease;
clean-up of landfill; protection of endangered spe-
cies conflicts with development
Geography—note: strategic location in the
North Pacific Ocean','5cc45c148583516e4c7bf516d89e84a1544302c1049b8fda82a704f3403356b4','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c77a828f4e17f74550576cf330cd8285f3a0cce4fbc72ba18b011b05f9d25dd6',2025,'SE','Sweden','geography',1250,'Geographic coordinates: 62 00 N, 10 00 E
Map references: Europe
Area: total: 323,802 sq km
country comparison to the world: 68
land: 304,282 sq km
water: 19,520 sq km
Area—comparotive: slightly larger chan New','27377bba9f462face6821a443bb17822d12e1b3ea45e5462f559877a65a0914a','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('525e1bd2b2a307327ede8d9160356a4fcdcaabfa07a130961733535ff40b426a',2025,'OM','Oman','geography',1265,'Location: body of water between the South-
em Ocean, Asia, Australia, and the Western
Hemisphere
Geographic coordinates: 0 00 N, 16000 W
Map references: Physical -Map of the World
Area: total: 155.557 million sq km
note: includes Bali Sea, Bering Sea, Bering Strait,
Coral Sea, East China Sea, Gulf of Alaska, Gulf
of Tonkin, Philippine Sea, Sea of Japan, Sea of
Okhotsk, South China Sea, Tasman Sea, and
other tributary water bodies
Area—comparative: about 15 times the size of
the US; covers about 28% of the global surface;
almost equal to the total land area of the world
Coastline: 135,663 km
Climate: planetary air pressure systems and result-
ant wind patterns exhibit remarkable uniformity
in the south and east; trade winds and westerly
winds are well-developed patterns, modified by
seasonal fluctuations; tropical cyclones (hur-
ticanes) may form south of Mexico from June to
October and affect Mexico and Central America;
continental influences cause climatic uniformity
to be much less pronounced in the eastern and
western regions at the same latitude in the North
Pacific Ocean; the western Pacific is monsoonal—
a rainy season occurs during the summer months,
when moisture-laden winds blow from the ocean
over the land, and a dry season during the win-
ter months, when dry winds blow from the Asian
landmass back to the ocean; tropical cyclones
(typhoons) may strike southeast and east Asia
from May to December
Terrain: surface currents in the northern Pacific
are dominated by a clockwise, warm-water gyre
(broad circular system of currents) and in the
southern Pacific by a counterclockwise, cool-
water gyre; in the northern Pacific, sea ice forms
in the Bering Sea and Sea of Okhotsk in winter;
in the southern Pacific, séa ice from Antarctica
reaches its northernmost extent in October; the
ocean floor in the eastern Pacific is dominated by
the East Pacific Rise, while the western Pacific is
dissected by deep trenches, including the Mariana
Trench, which is the world’s deepest
Elevation extremes: lowest point: Challenger
Deep in the Mariana Trench-10,924 m
highest point: sea level 0 m
Natural resources: oil and gas fields, polymetallic
nodules, sand and gravel aggregates, placer depos-
its, fish
Natural hazards: surrounded by a zone of vio-
lent volcanic and earthquake activity sometimes
referred to as the “Pacific Ring of Fire”; subject to
tropical cyclones (typhoons) in southeast and east
Asia from May to December (most frequent from
July to October); tropical cyclones (hurricanes)
may form south of Mexico and strike Central
America and Mexico from June to October (most
common in August and September); cyclical El
Nino/La Nina phenomenon occurs in the equa-
torial Pacific, influencing weather in the West-
ern Hemisphere and: the westetn Pacific; ships
subject to superstructure icing in extreme north
from October to May; persistent fog in the north-
ern Pacific can be a maritime hazard from June to
December
Environment—current issues:
marine species include the dugong, sea lion, sea
t
endangered
otter, seals, turtles, and whales; oil pollution in
Philippine Sea and South China Sea
Geography—note: the major chokepoints are
the Bering Strait, Panama Canal, Luzon Strait,
and the Singapore Strait; the Equator divides the
Pacific Ocean into fhe North Pacific Ocean and
the South Pacific Ocean; dotted with low coral
islands and rugged volcanic islands in the south-
western Pacific Ocean
Location: Southern Asia, bordering the Arabian
Sea, between India on the east and Iran and
Afghanistan on the west and China in the north
Geographic coordinates: 30 00 N, 70 00 E
Map references: Asia
Area: total: 796,095 sq km country
comparison to the world: 36
land: 770,875 sq km
water: 25,220 sq km
Area—comparative: slightly less than twice the
size of California
Land boundaries: total: 6,774 km
border countries: Afghanistan 2,430 km, China
523 km, India 2,912 km, Iran 909 km
Coastline: 1,046 km
Maritime claims: territorial sea: 12 nm
contiguous zone: 24 nm
exclusive economic zone: 200 nm
continental shelf: 200 nm or to the edge of the
continental margin
Climate: mostly hot, dry desert; temperate in
northwest; arctic in north
Terrain: flat Indus plain in east; mountains in
north and northwest; Balochistan plateau in west
Elevation extremes: lowest point: Indian Ocean
Om
highest point: K2 (Mt. Godwin-Austen) 8,611 m
Natural resources: land, extensive natural gas
reserves, limited petroleum, poor quality coal, iron
ore, copper, salt, limestone
Land use: arable land: 26.02%
permanent crops: 1.05% ©
other: 72.93% (2011)
irrigated land: 199,900 sq km (2008)
Total renewable water resources: 246.8 cu km
(2011)
Freshwater withdrawal (domestic/industrial/
agricultural): total: 183.5 cu km/yr (5%/1%/94%)
per capita: 1,038 cu m/yr (2008)
Natura! hazards: frequent earthquakes, occasion-
ally severe especially in north and west; flooding
along the Indus after heavy rains (July and August)
Environment—current issues: water pollution
from raw sewage, industrial wastes, and agricul-
tural runoff; limited natural freshwater resources;
most of the population does not have access
554
‘Major
THE CIA WORLD FACTBOOK
to potable water; deforestation; soil erosion;
desertification
Environment—international agreements:
party to: Biodiversity, Climate Change, Cli-
mate Change-Kyoto Protocol, Desertification,
Endangered Species, Environmental Modifica-
tion, Hazardous Wastes, Law of the Sea, Marine
Dumping, Ozone Layer Protection, Ship Pollu-
tion, Wetlands
signed, but not ratified: Marine Life Conservation
Geography—note: conirols Khyber Pass and
Bolan Pass, traditional invasion routes between
Central Asia and the Indian Subcontinent','87b6c68f06a8d41d27c2d96d6634b185c27419ec1b892f4a1cd02103d70994a4','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('be6de7ea15cae97951e077fd459a8fe4679bcd5eeab922d2dbd17b4faf9d3aea',2025,'PA','Panama','geography',1283,'Location: Central America, bordering both the
Caribbean Sea and the North Pacific Ocean,
between Colombia and Costa Rica
Geographic coordinates: 9 00 N, 80 00 W
Map references: Central America and the
Caribbean
Area: total: 75,420 sq km
country comparison to the world: 118
land: 74,340 sq km
water: 1,080 sq km
Area—comparative: slightly smaller than South
Carolina
Land boundaries: total: 555 km
560
border countries: Colombia 225 km, Costa Rica
330 km
Coastline: 2,490 km
Maritime claims: territorial sea: 12 nm
contiguous zone: 24 nm
exclusive economic zone: 200 nm or edge of con-
tinental margin
Climate: tropical maritime; hot, humid, cloudy;
prolonged rainy season (May to January), short dry
season (January to May)
Terrain: interior mostly steep, rugged mountains
and dissected, upland plains; coastal areas largely
plains and rolling hills à
Elevation extremes: lowest point: Pacific Ocean
Om :
highest point: Volcan Baru 3,475 m
Natural resources: ‘copper, mahogany forests,
shrimp, hydropower
Land use: arable land: 7.16%
permanent crops: 2.51%
other: 90.33% (2011)
Irrigated land: 346.2 sq km (2003)
Total renewable water resources: 148 cu km
(2011)
Freshwater withdrawal (domestic/industrial/
agricultural): total: 0.91 cu km/yr (27%/2%/71%)
per capita: 296.1 cu m/yr (2005)
Natural hazards: occasional severe storms and
forest fires in the Darien area
Environment—current Issues: water pollution
from agricultural runoff threatens fishery resources;
deforestation of tropical rain forest; land degrada-
tion and soil erosion threatens siltation of Panama
Canal; air pollution in urban areas; mining threat-
ens natural resources
Environment—international agreements:
party to: Biodiversity, Climate Change, Cli-
mate Change-Kyoto Protocol, Desertification,
Endangered Species, Environmental Modifica-
tion, Hazardous Wastes, Law of the Sea, Marine
Dumping, Ozone Layer Protection, Ship Pollution,
Tropical Timber 83, Tropical Timber 94, Wetlands,
Whaling
signed, but not ratified: Marine Life Conservation
Geography—note: strategic location on east-
em end of isthmus forming land bridge connect-
ing North and South America; controls Panama
Canal that links North Atlantic Ocean via Carib-
bean Sea with North Pacific Ocean','aa7caca9f6fbcfc79651ac64e3d6dc41e887687e7a3e657207dfc8e56073f86d','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('707a7822d713a5973b6a393dfea4d15a45b54ab5218d565720944d74308cdaa9',2025,'PG','Papua New Guinea','geography',1293,'Location: Oceania, group of islands including the
eastern half of the island of New Guinea between
the Coral Sea and the South Pacific Ocean, east
of Indonesia
Geographic coordinates: 6 00 S, 147 00 E
Map references; Oceania
Area: total: 462,840 sq km
country comparison to the world: 55
land: 452,860 sq km
water: 9,980 sq km
Area—comparative:
California
Land boundaries: total: 820 km
border countries: Indonesia 820 km
Coastline: 5,152 km
Maritime claims: measured from claimed archi-
pelagic baselines
territorial sea: 12 nm
continental shelf: 200 m depth or to the depth of
exploitation
exclusive fishing zone: 200 nm
slightly larger than
Climate: tropical; northwest monsoon (December
to March), southeast monsoon (May to Octo-
ber); slight seasonal temperature variation mostly
mountains with coastal lowlands and rolling
foothills
Elevation extremes: lowest point: Pacific Ocean
Om
highest point: Mount Wilhelm 4,509 m
Natural resources: gold, copper, silver, natural
gas, timber, oil, fisheries
Land use: arable land: 0.65%
permanent crops: 1.51%
564
other: 97.84% (2011)
Irrigated land: 0 sq km (2003)
Total renewable water resources: 801 cu km
(2011)
Freshwater withdrawal (domestic/industrial/
agricultural): total: 0.39 cu km/yr (57%/43%/0%)
per capita: 61.3 cu m/yr (2005)
Natural hazards: active volcanism; situated along
the Pacific “Ring of Fire”; the country is subject to
frequent and sometimes severe earthquakes; mud
slides; tsunamis
volcanism: severe volcanic activity; Ulawun
(elev. 2,334 m), one of Papua New Guinea’s poten-
tially most dangerous volcanoes, has been deemed
a “Decade Volcano” by the International Associa-
tion of Volcanology and Chemistry of the Earth’s
Interior, worthy of study due to its explosive his-
tory and close proximity to human populations;
Rabaul (elev. 688 m) destroyed the city of Rabaul
in 1937 and 1994; Lamington erupted in 1951 kill-
ing 3,000 people; Manam’s 2004 eruption forced
the island’s abandonment; other historically active
volcanoes include Bam, Bagana, Garbuna, Karkar,
Langila, Lolobau, Long Island, Pago, St. Andrew
Strait, Victory, and Waiowa
Environment—current issues: rain forest subject
to deforestation as a result of growing commercial
demand for tropical timber; pollution from mining
projects; severe drought
Environment—international agreements: party
to: Antarctic Treaty, Biodiversity, Climate Change,
Climate Change-Kyoto Protocol, Desertification,
Endangered Species, Environmental Modifica-
tion, Hazardous Wastes, Law of the Sea, Marine
Dumping, Ozone Layer Protection, Ship Pollution,
Tropical Timber 83, Tropical Timber 94, Wetlands
signed, but not ratified: none of the selected
agreements
Geography—note: shares island of New Guinea.
with Indonesia; one of world’s largest swamps
along southwest coast
Location: Southeastem Asia, group of small
islands and reefs in the South China Sea, about
one-third of the way from central Vietnam to the
northern Philippines
Geographic coordinates: 16 30 N, 112 00 E
Mop references: Southeast Asia
Area: total: ca, 7.75 sq km
land: ca. 7.75 sq km
water: 0 sq km
Area—comparative: NA
Land boundaries: 0 km
Coastline: 518 km
Maritime claims: NA
Climate: tropical
Terrain: mostly low and flat
Elevation extremes: lowest point: South China
Sea 0m
highest point: unnamed location on Rocky Island
14m
Natural resources: none
Land use: arable land: 0%
permanent crops: 0%
other: 100% (2011) j
Irrigated land: 0 sq km (2011)
Natura! hazards: typhoons
Environment—current issues: NA
Geography—note: composed of 130 small coral
islands and reefs divided into the northeast Amphi-
trite Group and the western Crescent Group','256398f59d4078f23961567bb711ced3e568fccf13fc118d661331bc53995413','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9210d3cdd915d91d3609c6bb155b3016f6219bb03dde0e75cd068c7b7b4e7bd2',2025,'PE','Peru','geography',1315,'Location: Southeastern Asia, archipelago between
the Philippine Sea and the South China Sea, east
of Vietnam
Geographic Coordinates: 13 00 N, 122 00 E
Map references: Southeast Asia
Area: total: 300,000 sq km
country comparison to the world: 73
land: 298,170 sq km
water: 1,830 sq km
Area—comparotive: slightly larger than Arizona
Land boundaries: 0 km
Coastline: 36,289 km
Maritime claims: territorial sea: irregular poly-
gon extending up to 100 nm from coastline as
defined by 1898 treaty; since late 1970s has also
claimed polygonal-shaped area in South China
Sea up to 285 nm in breadth
exclusive economic zone: 200 nm
continental shelf: to depth of exploitation
Climate: tropical marine; northeast monsoon
(November to April); southwest monsoon (May
to October)
Terrain: mostly mountains with narrow to exten-
sive coastal low lands
Elevation extremes: lowest point: Philippine
Sea 0 m
highest point: Mount Apo 2,954 m
Natural resources: timber, petroleum, nickel,
cobalt, silver, gold, salt, copper
Land use: arable land: 18%
permanent crops: 17.33%
other: 64.67% (2011)
Irrigated land: 18,790 sq km (2006)
Total renewable water resources: 479 cu km
(2011)
Freshwater withdrawal (domestic/indus-
trial/agricultural): total: 81.56 cu km/yr
(8%/10%/82%)
per capita: 859.9 cu m/yr (2009)
Natural hazards: astride typhoon belt, usually
affected by 15 and struck by five to six cyclonic
storms each year; landslides; active volcanoes;
destructive earthquakes; tsunamis
volcanism: significant volcanic activity; Taal
(elev. 311 m), which has shown recent unrest and
may erupt in the near future, has been deemed a
“Decade Volcano” by the International Associa-
tion of Volcanology and Chemistry of the Earth’s
Interior, worthy of study due to its explosive history
and close proximity to human populations; Mayon
(elev. 2,462 m), the country’s most active volcano,
erupted in 2009 forcing over 33,000 to be evacu-
ated; other historically active volcanoes include
Biliran, Babuyan Claro, Bulusan, Camiguin, Cami-
guin de Babuyanes, Didicas, Iraya, Jolo, Kanlaon,
Makaturing, Musuan, Parker, Pinatubo and Ragang
Environment—current issues:
deforestation especially in watershed areas; soil
erosion; air and water pollution in major urban
centers; coral reef degradation; increasing pollu-
tion of coastal mangrove swamps that are impor-
tant fish breeding grounds
Environment—international agreements:
party to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Endan-
gered Species, Hazardous Wastes, Law of the Sea,
Marine Dumping, Ozone Layer Protection, Ship
Pollution, Tropical Timber 83, Tropical Timber 94,
Wetlands, Whaling
signed, but not ratified: Air Pollution-Persistent
Organic Pollutants
Geography—note: the Philippine archipelago
is made up of 7,107 islands; favorably located in
relation to many of Southeast Asia’s main water
bodies: the South China Sea, Philippine Sea, Sulu
Sea, Celebes Sea, and Luzon Strait','eda746142c570c7053ce57476198daf882c95dfffedc0fe25d95554bef764fc8','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2aa4e40ecdd7183f7cbdb0c3fa761741ca9dafd477f6ef4e1123a978e8a40cea',2025,'PW','Palau','geography',1326,'Location: Oceania, islands in the South Pacific
Ocean, about midway between Peru and New
Zealand
Geographic coordinates: 25 04 S, 13006 W
Map references: Oceania
Area: total: 47 sq km
country comparison to the world: 234
land: 47 sq km
580
water: 0 sq km
Area—comparative: about three tenths the size
of Washington, DC
Land boundaries: 0 km
Coastline: 51 km
Maritime claims: territorial sea: 3 nm
exclusive economic zone: 200 nm
Climate: tropical; hot and humid; modified by
southeast trade winds; rainy season (November to
March)
Terrain: rugged volcanic formation; rocky coast-
line with cliffs
Elevation extremes: lowest point: Pacific Ocean
Om
highest point: Big Ridge 347 m
Natural resources: mirotrees (used for handi-
crafts), fish
note; manganese, iron, copper, gold, silver, and
zinc have been discovered offshore
Land use: arable land: 0%
permanent crops: 0%
other: 100% (2011)
Irrigated land: NA
Natural hazards: typhoons (especially November
to March)
Environment—current issues: deforestation
(only a small portion of the original forest remains
because of burning and cléaring for settlement)
Geography—note: Britain’s most isolated depend-
ency; only the larger island of Pitcairn is inhabited
but it has no port or natural harbor; supplies must
be transported by rowed longboat from larger ships
stationed offshore','c49797a05ac402fdf0501b2f310a622c5a1649f6e21375dc00e619b9c8622ec4','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ed290514d2108b0b9d2d82b34eeee40f1714b03ee50c608da8d295a0119e44c5',2025,'PL','Poland','geography',1330,'Location: Central Europe, east of Germany
Geographic coordinates: 52 00 N, 20 00 E
Map references: Europe
Area: total: 312,685 sq km
country comparison to the world: 70
581
land: 304,255 sq km
water: 8,430 sq km
Area—comparative: slightly smaller than New
Location: Southwestern Europe, bordering the
North Atlantic Ocean, west of Spain
Geographic coordinates: 39 30 N, 8 00 W
Map references: Europe
Area: total: 92,090 sq km
country comparison to the world: 111
land: 91,470 sq km
water: 620 sq km
note: includes Azores and Madeira Islands
Area—comparative:
Indiana
Land boundaries: total: 1,214 km
border countries: Spain 1,2#4 km
slightly smaller than
Coastline: 1,793 km
Maritime claims: territorial sea: 12 nm
contiguous zone: 24 nm
exclusive economic zone: 200 nm
continental shelf: 200 m depth or to the depth of
exploitation
Climate: maritime temperate; cool and rainy in
north, warmer and drier in south
Terrain: mountainous north of the Tagus River,
rolling plains in south
Elevation extremes: lowest point: Atlantic
Ocean 0 m
highest point: Ponta do Pico (Pico or Pico Alto)
on Ilha do Pico in the Azores 2,351 m
Natural resources: fish, forests (cork), iron ore,
copper, zinc, tin, tungsten, silver, gold, uranium,
marble, clay, gypsum, salt, arable land, hydropower
Land use: arable land: 11.88%
permanent crops: 7.71%
other: 80.41% (2011)
Irrigated land: 5,837 sq km (2007)
Total renewable water resources: 68.7 cu km
(2011)
Freshwater withdrawal (domestic/indus-
triaVagricultural): total: 8.46 cu km/yr
(12%/18%/69%)
per capita: 812 cu m/yr (2005)
Natural hazards: Azores subject to severe
earthquakes
volcanism: limited volcanic activity in the Azores
Islands; Fayal or Faial (elev. 1,043 m) last erupted
in 1958; most volcanoes have not erupted in cen-
turies; historically active volcanoes include Agua
de Pau, Furnas, Pico, Picos Volcanic System, San
Jorge, Sete Cidades, and Terceira
Environment—current issues: soil erosion; air
pollution caused by. industrial and vehicle emis-
sions; water pollution, especially in coastal areas
Environment—International agreements:
party to: Air Pollution, Biodiversity, Climate
Change, Climate Change-Kyoto Protocol, Deser-
tification, Endangered Species, Hazardous Wastes,
Law of the Sea, Marine Dumping, Marine Life
Conservation, Ozone Layer Protection, Ship Pol-
lution, Tropical Timber 83, Tropical Timber 94,
Wetlands, Whaling
signed, but not ratified: Air Pollution-Persistent
Organic Pollutants, Air Pollution-Volatile Organic
Compounds, Environmental Modification
Geography—note: Azores and Madeira Islands
occupy strategic locations along western sea
approaches to Strait of Gibraltar','760590e0680153e269860fef37c98cf8e053a83fe0888a8c1527f4c2b965bcb9','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0810c1fe579f1c2b41ff299be75f7adda33f7c4c381963d4649a04738d92c521',2025,'QA','Qatar','geography',1351,'Area: total: 11,586 sq km
country comparison to the world: 166 land:
11,586 sq km
water: 0 sq km
Area—comparative:
Connecticut
Land boundaries: total: 60 km
border countries: Saudi Arabia 60 km
Coastline: 563 km
Maritime claims: territorial sea; 12 nm
contiguous zone: 24 nm
exclusive economic zone: as determined by bilat-
eral agreements or the median line
slightly smaller than
Climate: arid; mild, pleasant winters; very hot,
humid summers Terrain: mostly flat and barren
desert covered with loose sand and gravel
Elevation extremes: lowest point: Persian Gulf 0 m
highest point: Tuwayyir al Hamir 103 m
Natural resources: petroleum, natural gas, fish
Land use: arable land: 1.21%
permanent crops: 0.17%
other: 98.62% (2011)
Irrigated land:129.4 sq km (2003)
Total renewable water resources: 0.06 cu km
(2011)
Freshwater withdrawal (domestic/industrial/
agricultural): total: 0.44 cu km/yr (39%/2%/59%)
per capita: 376.9 cu m/yr (2005)
Natural hazards: haze, dust storms, sandstorms
common
Environment—current issues: limited natural
freshwater resources are increasing dependence on
large-scale desalination facilities
Environment—international agreements:
party to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Endan-
gered Species, Hazardous Wastes, Law of the Sea,
Ozone Layer Protection, Ship Pollution
signed, but not ratified: none of the selected
agreements
Geography—note: strategic location in central
Persian Gulf near major petroleum deposits
Location: Southeastern Europe, bordering the
Black Sea, between Bulgaria and Ukraine
Geographic coordinates: 46 00 N, 25 00 E
Map references: Europe
Area: total: 238,391 sq km
country comparison to the world: 83
land; 229,891 sq km
water: 8,500 sq km
Area—comparative:
Oregon
Land boundaries: total: 2,508 km
border countries: Bulgaria 608 km, Hungary 443
km, Moldova 450 km, Serbia 476 km, Ukraine
(north) 362 km, Ukraine (east) 169 km
Coastline: 225 km
Maritime claims: territorial sea: 12 nm
contiguous zone: 24 nm
exclusive e Annnm ic z Ane: 200 nm
exclusive economic zone. 200 11111
continental shelf: 200 m depth or to the depth of
exploitation
slightly smaller than
596','7c4bb12e9a60ccca30c5bcd6706b31e5535b2cacf4ffde71162b0fc09c47bacc','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9f18cd697ae1131ad2b23e3d082972fb8f114ee67d323a2981caf1054aec7b33',2025,'RW','Rwanda','geography',1365,'Location: Central Africa, east of Democratic
Republic of the Congo
Geographic coordinates: 2 00 S, 30 00 E
Map references: Africa
Area: total: 26,338 sq km
country camparison to the world: 149
land: 24,668 sq km
water: 1,670 sq km
Area—comparative: slightly smaller than
Maryland
Land boundaries: total: 893 km
border countries: Burundi 290 km, Democratic
Republic of the Congo 217 km, Tanzania 217 km,
Uganda 169 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
Climate: temperate; two rainy seasons (February
to April, November to January); mild in moun-
tains with frost and snow possible
Terrain: mostly grassy uplands and hills; relief is
mountainous with altitude declining from west to
at
Elevation extremes:
lowest point: Rusizi River 950 m
highest point: Volcan Karisimbi 4,519 m
Natural resources: gold, cassiterite (tin ore),
wolframite (tungsten ore), methane, hydropower,
arable land
Land use: arable land: 46.32%
permanent crops: 9.49%
other: 44.19% (2011)
Irrigated land: 96.25 sq km (2007)
Total renewable water resources: 9.5 cu km
(2011)
Freshwater withdrawal (domestic/indus-
triai/agricultural): total: 0.15 cu km/yr
(33%/11%/55%)
per capita: 17.25 cu m/yr (2005)
Natural hazards: periodic droughts; the volcanic
Virunga mountains are in the northwest along the
border with Democratic Republic of the Congo
volcanism: Visoke (elev. 3,71 1 m), located on
the border with the Democratic Republic of the
Congo, is the country’s only historically active
volcano
Environment—current issues:
results from uncontrolled cutting of trees for fuel;
overgrazing; soil exhaustion; soil erosion; wide-
deforestation
spread poaching
Environment—international agreements:
party to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Endan-
gered Species, Hazardous Wastes, Ozone Layer
Protection, Wetlands signed, but not ratified: Law
of the Sea
Geography—note: landlocked; most of the coun-
try is savanna grassland with the population pre-
dominantly rural','44f035bfa03a9728d5e45810fd3ab7d81b5ea744ced27c7b7ca85802f9ba5efd','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('90ae5ea20bb303ba0b63804bdc5dbd65870de1d2d74f86dbf6a995916c780569',2025,'KN','Saint Kitts and Nevis','geography',1375,'Location: Caribbean, islands in the Caribbean
Sea, about one-third of the way from Puetto Rico
to Trinidad and Tobago
Geographic coordinates: 17 20 N, 62 45 W
Map references: Central America and the
Caribbean
Area: total: 261 sq km (Saint Kitts 168 sq km;
Nevis 93 sq km)
country comparison to the world: 212
land: 261 sq km
water: 0 sq km
Area—comporative: one and a half times the size
of Washington, DC
Land boundaries: 0 km
Coastline: 135 km
Maritime claims: territorial sea: 12 nm
contiguous zone: 24 nm
exclusive economic zone: 200 nm
continental shelf: 200 nm or to the edge of the
continental margin
Climate: tropical, tempered by constant sea
breezes; little seasonal temperature variation; rainy
season (May to November)
Terrain: volcanic with mountainous interiors
Elevation extremes: lowest point: Caribbean
Sea 0m
highest point: Mount Liamuiga 1,156 m
Natural resources: arable land
Land use: arable land: 19.23%
permanent crops: 0.38%
other: 80.38% (2011)
Irrigated land: 0.18 sq km (2003)
Total renewable water resources: 0.02 cu km
(2011)
Natural hazards: hurricanes (July to October)
Environment—current issues: NA
Environment—international agreements:
party to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Endan-
gered Species, Hazardous Wastes, Law of the Sea,
Marine Dumping, Ozone Layer Protection, Ship
Pollution, Whaling
signed, but not ratified: none of the selected
agreements i
Geogrophy—note: with coastlines in the shape of
a baseball bat and ball, the two volcanic islands
are separated by a 3-km-wide channel called The
Narrows; on the southern tip of long, baseball bat-
shaped Saint Kitts lies the Great Salt Pond; Nevis
Peak sits in the center of its almost circular name-
sake island and its ball shape complements that of
- its sister island
Location: Caribbean, island between the Carib-
bean Sea and North Atlantic Ocean, north of','28648845f3d9517e11762e0e8c687af96ab547a5c263a8d78cc3652da191d0ad','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('318d2617b1d03f60dff1ba177081e9e64784db02ea086d73883312827a092f95',2025,'LC','Saint Lucia','geography',1390,'Location: Caribbean, located in the Leeward
Islands (northern) group; French part of the island
-
2,438 to 3,047 m: 1
1,524 to 2,437 m: 1 (2012)
Roadways: total: 1,210 km (2002)
country comparison to the world: 180
Ports and terminals: Castries, Cul-de-Sac,
Vieux-Fort','c1d5778314f445a29e63023194fa34871a3925b7c2c8a98d0a599f35f08b8021','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fa5f86680cee4e00090575a2dcd69a84627e62871b108e219db937199dff5d47',2025,'PM','Saint Pierre and Miquelon','geography',1397,'Location: Northern North America, islands in the
North Atlantic Ocean, south of Newfoundland
(Canada) 1
Geographic coordinates: 46 50 N, 56 20 W
Map references: North America
Area: total: 242 sq km
country comparison to the world: 214
land: 242 sq km
water: 0 sq km `
note: includes eight small islands in the Saint
Pierre and the Miquelon groups
Area—comparative: one and half times the size
of Washington, DC
Land boundaries: 0 km
Coastline: 120 km
Maritime claims: territorial sea: 12 nm
exclusive economic zone: 200 nm
Climate: cold and wet, with considerable mist and
fog; spring and autumn are often windy
Terrain: mostly barren rock
Elevation extremes: lowest point: Atlantic
Ocean 0 m
highest point: Morne de la Grande Montagne 240
m
Natural resources: fish, deepwater ports
Land use: arable land: 8.7%
permanent crops: 0%
other: 91.3% (2011)
Irrigated land: NA
Natural hazards: persistent fog throughout the
year can be a maritime hazard
Environment—current Issues: recent test drill-
ing for oil in waters around Saint Pierre and
Miquelon may bring future development that
would impact the environment
Geography—note: vegetation scanty
620','065427ae386254207fd3d132215094f8e594d2e862c380b66b196ff9596ab88d','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('60128aac1892207a9a4841ea4287d30cd84d6fd0c85600a5957c5de524d5c52f',2025,'VC','Saint Vincent and the Grenadines','geography',1406,'Location: Caribbean, islands between the Car-
ibbean Sea and North Atlantic Ocean, north of
Location: Oceania, group of islands in the South
Pacific Ocean, about half way between Hawaii and','cb1e6cf28c45346711e16a57a22547b43db487ef4d0d3dd26392b5d715b89935','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2ec3d2f3f453693fabe4aa3839a905d871e0803cd488400e818025cc1a57ff43',2025,'WS','Samoa','geography',1413,'volcanism: Savai’l Island (elev. 1,858 m), which
last erupted in 1911, is historically active
Environment—current issues: soil erosion,
deforestation, invasive species, overfishing
Environment—international agreements:
party to: Biodiversity, Climate Change, Cli-
mate Change-Kyoto Protocol, Desertification,
Hazardous Wastes, Law of the Sea, Ozone
Layer Protection, Ship Pollution, Wetlands
signed, but not ratified: none of the selected
agreements
Geography—note: occupies an almost central
position within Polynesia','07c2c878c5ffa48e077e62691a53d108801b56a175f25734b79c33d561b33846','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('71f3856ebad91b04ba303fc319e90f3ef5300436222f41a76afcb31d5dd142a5',2025,'SA','Saudi Arabia','geography',1430,'Location: Middle East, bordering the Persian Gulf
and the Red Sea, north of Yemen
Geographic coordinates: 25 00 N, 45 00 E
Map references: Middle East
Area: total: 2,149,690 sq km
country comparison to the world: 13
land: 2,149,690 sq km
water: 0 sq km
Area—comparative: slightly more than one-fifth
the size of the US
Land boundaries: total: 4,431 km
border countries: Iraq 814 km, Jordan 744 km,
Kuwait 222 km, Oman 676 km, Qatar 60 km, UAE
457 km, Yemen 1,458 km
Coastline: 2.640 km
Maritime claims: territorial sea: 12 nm
contiguous zone: 18 nm
continental shelf: not specified
Climate: harsh, dry desert with great temperature
extremes spoon
Terrain: mostly uninhabited, sandy desert
Elevation extremes: lowest point: Persian Gulf
Om
highest point: Jabal Sawda’ 3,133 m
633
Natural resources: petroleum, natural gas, iron
ore, gold, copper
Land use: arable land: 1.45%
permanent crops: 0.11%
other: 98.44% (2011)
Irrigated.land: 16,200 sq km (2004)
Total renewable water resources: 2.4 cu km
(2011)
Freshwater withdrawal (domestic/indus-
triaV/agricultural): total: 23.67 cu km/yr
(9%/3%/88%)
per capita; 928.1 cu m/yr (2006)
Natural hazards: frequent sand and dust storms
volcanism: despite many volcanic formations,
there has been little activity in the past few centu-
ries; volcanoes include Harrat Rahat, Harrat Khay-
bar, Harrat Lunayyir, and Jabal Yar
Environment—current issues: desertification;
depletion of underground water resources; the lack
of perennial rivers or permanent water bodies has
prompted the development of extensive seawater
desalination facilities; coastal pollution from oil
spills '' `
Environment—international agreements:
party to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Endan-
gered Species, Hazardous Wastes, Law of the Sea,
Marine Dumping, Ozone Layer Protection, Ship
Pollution
signed, but not ratified: none of the selected
agreements
Geography—note: Saudi Arabia is the largest
country in the world without a river; extensive
coastlines on the Persian Gulf and Red Sea
provide great leverage on shipping (especially
crude oil) through the Persian Gulf and Suez
Canal
Location: Western Africa, bordering the North
Atlantic Ocean, between Guinea-Bissau and
Mauritania : E
countries, were believed to have been forced into
prostitution in Saudi Arabia; others were report-
edly kidnapped and forced into prostitution after
running away from abusive employers; Yemeni,
Nigerian, Pakistani, Afghan, Chadian, and Suda-
nese children were subjected to forced labor as beg-
gars and street vendors in Saudi Arabia, facilitated
by criminal gangs; some Saudi nationals travel to
destinations including Morocco, Egypt, Yemen,
Afghanistan, Pakistan, India, and Bangladesh to
solicit prostitution
tier rating: Tier. 3—Saudi Arabia does not fully
comply with the minimum standards for the elimi-
nation of trafficking and is not making significant
Geographic coordinates: 14 00 N, 14 00 W
Map references: Africa
Area: total: 196,722 sq km
country comparison to the world: 88
land: 192,530 sq km
water: 4,192 sq km
Area—comparative: slightly smaller than South
Dakota
Land boundaries: total:2,640 km
border countries: The Gambia 740 km, Guinea
330 km, Guinea-Bissau 338 km, Mali 419 km,
Mauritania 813 km
Coastline: 531 km
Maritime claims: territorial sea: 12 nm contigu-
ous zone: 24 nm
exclusive economic zone: 200 nm
continental shelf: 200 nm or to the edge of the
continental margin Climate: tropical; hot, humid;
rainy season (May to November) has strong south-
east winds; dry season (December to April) domi-
nated by hot, dry, harmattan wind
Terrain: generally low, rolling, plains rising to
foothills in southeast
Elevation extremes:
Ocean 0 m
highest point: unnamed elevation southwest of
Kedougou 581 m
Natural resources: fish, phosphates, iron ore
Land use: arable land: 19.57%
permanent crops: 0.28%
other: 80.15% (2011)
Irrigated land: 1,197 sq km (2003)
Total renewable water resources: 38.8 cu km
(2011)
Freshwater withdrawal (domestic/Industrial/
agricultural): total: 2.22 cu km/yr (4%/3%/93%)
per capita: 221.6 cu m/yr (2002)
Natural hazards: low lands seasonally flooded;
periodic droughts
Environment—current issues: wildlife popu-
lations threatened by poaching; deforesta-
tion; overgrazing; soil erosion; desertification;
overfishing
Environment—international agreements:
party to: Biodiversity, Climate Change, Cli-
mate Change-Kyoto Protocol, Desertification,
lowest point: Atlantic
efforts to do so; however, the government under-
took some efforts to improve its response to the
vast human trafficking problem in Saudi Arabia,
including training government officials on its
2009 anti-trafficking law and conducting surprise
visits to places where victims may be found; it also
achieved its first conviction under its human traf-
ficking law; nonetheless, the government did not
prosecute and punish a significant number of traf-
ficking offenders or significantly improve victim
protection services (2008)
Illicit drugs: death penalty for traffickers;
improving anti-money-laundering legislation and
enforcement
Endangered Species, Hazardous Wastes, Law of
the Sea, Marine Life Conservation, Ozone Layer
Protection, Ship Pollution, Wetlands, Whaling
signed, but not ratified: none of the selected
agreements
Geography—note: westernmost, country on the
African continent; The Gambia is almost an
enclave within Senegal
Geographic coordinates: 24 00 N, 54 00 E
Map references: Middle East
Area: total: 83,600 sq km
country comparison to the world: 115
land: 83,600 sq km
water: 0 sq km
Area—comparative: slightly smaller than Maine
Land boundaries: total: 867 km
border countries: Oman 410 km, Saudi Arabia
457 km
Coastline: 1,318 km
Maritime claims: territorial sea: 12 nm
contiguous zone: 24 nm
exclusive economic zone: 200 nm
continental shelf: 200 nm or to the edge of the
continental margin
Climate: desert; cooler in eastern mountains
Terrain: flat, barren coastal plain merging into
rolling sand dunes of vast desert wasteland; moun-
tains in east
Elevation extremes: lowest point: Persian Gulf
Om
a
Geographic coordinates: 15 00 N, 48 00 E
Map references: Middle East
Area: total:527,968 sq km
country comparison to the world: 50
land: 527,968 sq km
water: 0 sq km
‘note: includes Perim, Socotra, the former Yemen
Arab Republic (YAR or North Yemen), and the
former People’s Democratic Republic of Yemen
(PDRY or South Yemen)
Area—comparative: slightly larger than twice
the size of Wyoming
Land boundaries: total: 1,746 km
border countries: Oman 288 km, Saudi Arabia
1,458 km
Coastline: 1,906 km
Maritime claims: territorial sea: 12 nm
contiguous zone: 24 nm
exclusive economic zone: 200 nm
continental shelf: 200 nm or to the edge of the
continental margin
Climate: mostly desert; hot and humid along west
coast; temperate in western mountains affected by
seasonal monsoon; extraordinarily hot, dry, harsh
desert in east
Terrain: narrow coastal plain backed by flat-
topped hills and rugged mountains; dissected
upland desert plains in center slope into the desert
interior of the Arabian Peninsula a
Elevation extremes: lowest point: Arabian Sea
Om
highest point: Jabal ari Nabi Shu’ayb 3,760 m
Natural resources: petroleum, fish, rock salt,
marble; small deposits of coal, gold, lead, nickel,
and copper; fertile soil in west
Land use: arable land:2.2%
permanent crops: 0.55%
other: 97.25% (2011)
Irrigated land: 6,801 sq km (2004)
Total renewable water resources: 2.1 cu km
(2011)
Freshwater withdrawal (domestic/industrial/
agricultural): total: 3.57 cu km/yr (7%/2%/91%)
per capita: 162.4 cu m/yr (2005)
Natural hazards: sandstorms and dust storms in
summer
volcanism: limited volcanic activity; Jebel at Tair
(Jabal al-Tair, Jebel Teir, Jabal al-Tayr, Jazirat at-
Tair) (elev. 244 m), which forms an island in the
Red Sea, erupted in 2007 after awakening from
dormancy; other historically active volcanoes
include Harra of Arhab, Harras of Dhamar, Harra
es-Sawad, and Jebel Zubair, although many of
these have not erupted in over a century
Environment—current issues: limited natural
freshwater resources; inadequate supplies of pota-
ble water; overgrazing; soil erosion; desertification
Environment—international agreements:
party to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Endan-
gered- Species, Environmental Modification,
Hazardous Wastes, Law of the Sea, Ozone Layer
Protection
signed, but not ratified: none of the selected
agreements
Geography—nofe: strategic location on Babel
Mandeb, the strait linking the Red Sea and the
Gulf of Aden, one of world’s most active shipping
lanes','cebc53a679f336d0a968de85e3ac539687fdb32dd51fdf79a4234e5b20b12083','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e4b16ae121c7a9cc765262810513c7054c5be3665eb56e0416134819ed92a892',2025,'SK','Slovakia','geography',1458,'Location: Central Europe, south of Poland
Geographic coordinates: 48 40 N, 19 30 E
Map references: Europe
Area: total: 49,035 sq km
country comparison to the world: 131
land: 48, 105 sq km
water: 930 sq km
Area—comparative: about twice the size of New
Hampshire
Land boundaries: total: 1,474 km
border countries: Austria 91 km, Czech Repub-
lic 197 km, Hungary 676 km, Poland 420 km,
Ukraine 90 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
Climate: temperate; cool summers; cold, cloudy,
humid winters Terrain: rugged mountains in the _
central and northern part and lowlands in the
south
Elevation extremes: lowest point: Bodrok River
94m
highest point: Gerlachovsky Stit 2,655 m
Natural resources: brown coal and lignite; small
amounts of iron ore, copper and manganese ore;
salt; arable land
Land use: arable land: 28.36%
permanent crops: 0.41%
other: 71.22% (2011)
Irrigated land: 1,720 sq km (2007)
Total renewable water resources: 50.1 cu km
(2011)
Freshwater withdrawal (domestic/industrial/
agricultural): total:0.69 cu km/yr (47%/51%/3%)
per capita: 126.7 cu m/yr (2010)
Natural hazards: NA
Environment—current issues: air pollution from
metallurgical plants presents human health risks;
acid rain damaging forests
Environment—international agreements:
party to: Air Pollution, Air Pollution-Nitrogen
Oxides, Air Pollution-Persistent Organic Pollut-
ants, Air Pollution-Sulfur 85, Air Pollution-Sulfur
94, Air Pollution-Volatile Organic Compounds,
Antarctic Treaty, Biodiversity, Climate Change,
Climate Change-Kyoto Protocol, Desertification,
Endangered Species, Environmental Modifica-
tion, Hazardous Wastes, Law of the Sea, Ozone
‘Layer Protection, Ship Pollution, Wetlands,
+
Whaling signed, but not ratified: none of the
selected agreements
Geography—note: landlocked; most of the coun-
try is rugged and mountainous; the Tatra Moun-
tains in the north are interspersed with many sce-
nic lakes and valleys','a20db3a5863fc26fdd9766dbc479a0d01e3e0eff0e9ca29b6459a797392cee75','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('90ffd2d855791491ea1644c7671b6e8ef6127908ecd80d3905584f7692e86b0b',2025,'SB','Solomon Islands','geography',1473,'Location: Oceania, group of islands in the South
Pacific Ocean, éast of Papua New Guinea
Geographic coordinates: 8 00 S, 159 00 E
Map references: Oceania
Area: total: 28,896 sq km
country comparison to the world: 144
land: 27,986 sq km
water: 910 sq km
Area—comparative:
Maryland
Land boundaries: 0 km
slightly smaller than
662
Coastline: 5,313 km
Maritime claims: measured from claimed archi-
pelagic baselines
territorial sea: 12 nm
exclusive economic zone: 200 nm
continental shelf: 200 nm
Climate: tropical monsoon; few extremes of tem-
perature and weather
Terrain: mostly rugged mountains with some low
coral atolls
Elevation extremes: lowest point: Pacific Ocean
Om
highest point: Mount Popomanaseu 2,310 m
Natural resources: fish, forests, gold, bauxite,
phosphates, lead, zinc, nickel
Land use: arable land:0.62%
permanent crops: 2.25%
other: 97.13% (2011)
Irrigated land: NA
Total renewable water resources: 44.7 cu km
(2011)
Natural hazards: typhoons, but rarely destruc-
tive; geologically active region with frequent
earthquakes, tremors, and volcanic activity;
tsunamis
volcanism: Tinakula (elev. 851 m) has frequent
eruption activity, while an eruption of Savo (elev.
485 m) could affect the capital Honiara on nearby
Guadalcanal
Environment—current issues: deforestation;
soil erosion; many of the surrounding coral reefs
are dead or dying
Environment—international
party to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Envi-
ronmental Modification, Law of the Sea, Marine
Dumping, Marine Life Conservation, Ozone Layer
Protection, Whaling
signed, but not ratified: none of the selected
agreements
agreements:
Geography—note: strategic location on sea
routes between the South Pacific Ocean, the Solo-
mon Sea, and the Coral Sea; on 2 April 2007 an
undersea earthquake measuring 8.1 on the Richter
scale occurred 345 km WNW of the capital Honi-
ara; the resulting tsunami devastated coastal areas
of Western and Choiseul provinces with dozens of
deaths and thousands dislocated; the provincial
capital of Gizo was especially hard hit','30274834af55028f25181ffad44942fc8408b9ce3604c577601642ea0f087017','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('96bbe04b2db0537d67702903ef345a7b76b1ab655ac119afa1830e5ddc1821fc',2025,'ZA','South Africa','geography',1484,'the Sea, Marine Dumping, Marine Life Conser-
vation, Ozone Layer Protection, Ship Pollution,
Wetlands, Whaling signed, but not ratified: none
of the selected agreements
Geography—note: South Africa completely sur-
rounds Lesotho and almost completely surrounds
Swaziland
Location: Southern South America, islands in the
South Atlantic Ocean, east of the tip of South
America
Geographic coordinates: 54 30 S, 37 00 W
Map references: South America
Area: total: 3,903 sq km
country comparison to the world: 177
land: 3,903 sq km
SOUTH GEORGIA AND SOUTH SANDWICH
water: 0 sq km
note: includes Shag Rocks, Black Rock, Clerke
Rocks, South Georgia Island, Bird Island, and
the South Sandwich Islands, which consist of 11
islands
Area—comparative: slightly larger than Rhode
Island
Land boundaries: 0 km
Coastline: NA
Maritime claims: territorial sea:12 nm
exclusive fishing zone: 200 nm
Climate: variable, with mostly westerly winds
throughout the year interspersed with periods of
calm; nearly all precipitation falls as snow Terrain:
most of the islands, rising steeply from the sea, are
rugged and mountainous; South Georgia is largely
barren and has steep, glacier-covered mountains;
the South Sandwich Islands are of volcanic origin
with some active volcanoes i
Elevation extremes: lowest point: Atlantic
Ocean 0 m
highest point: Mount Paget (South Georgia) 2,934
m
Natural resources: fish
Land use: arable land:0%
permanent crops: 0%
other: 100% (largely covered by permanent ice
and snow with some sparse vegetation consisting
of grass, moss, and lichen) (2011)
Irrigated land: 0 sq km (2011)
Natural hazards: the South Sandwich Islands
have prevailing weather conditions that generally
make them difficult to approach by ship; they are
also subject to active volcanism
Environment—current issues: NA
Geography—note: the north coast of South Geor-
gia has several large bays, which provide good
anchorage; reindeer, introduced early in the 20th
century, live on South Georgia
Location: body of water between 60 degrees south
latitude and Antarctica
Geographic coordinates: 60 00 S, 90 00 E (nomi-
nally), but the Southern Ocean has the unique dis-
tinction of being a large circumpolar body of water
totally encircling the continent of Antarctica; this
ring of water lies between 60 degrees south latitude
and the coast of Antarctica and encompasses 360
degrees of longitude
Map references: Antarctic Region
673
Area: total:20.327 million sq km
note: includes Amundsen Sea, Bellingshausen
Sea, part of the Drake Passage, Ross Sea, a small
part of the Scotia Sea, Weddell Sea, and other
tributary water bodies
Area—comparative: slightly more than twice the
size of the US
Coastline: 17,968 km
Climate: sea temperatures vary from about 10
degrees Celsius to-2 degrees Celsius; cyclonic
storms travel eastward around the continent and
frequently are intense because of the tempera-
ture contrast between ice and open ocean; the
ocean area from about latitude 40 south to the
Antarctic Circle has the strongest average winds
found anywhere on Earth in winter the ocean
freezes outward to 65 degrees south latitude in
the Pacific sector and 55 degrees south latitude
in the Atlantic sector, lowering surface tempera-
tures well below 0 degrees Celsius; at some coastal
points intense persistent drainage winds from the
interior keep the shoreline ice-free throughout
the winter
Terrain: the Southern Ocegn is deep, 4,000 to
5,000 m over most of its extent with only limited
areas of shallow water; the Antarctic continental
shelf is generally narrow and unusually deep, its
edge lying at depths of 400 to 800 m (the global
mean is 133 m); the Antarctic icepack grows
from an average minimum of 2.6 million sq km in
March to about 18.8 million sq km in September,
better than a sixfold increase in area; the Antarc-
tic Circumpolar Current (21,000 km in length)
moves perpetually eastward; it is the world’s larg-
est ocean current, transporting 130 million cubic
meters of water per second—100 times the flow of
all the world’s rivers
Elevation extremes: lowest point: -7,235 m at
the southern end of the South Sandwich Trench
highest point: sea level 0 m
Natural resources: probable large and possible
giant oil and gas fields on the continental mar-
gin; manganese nodules, possible placer depos-
its, sand and gravel, fresh water as icebergs;
squid, whales, and seals—none exploited; krill,
fish
Natural hazards: huge icebergs with drafts up to
several hundred meters; smaller bergs and iceberg
fragments; sea ice (generally 0.5 to 1 m thick) with
sometimes dynamic short-term variations and with
large annual and interannual variations; deep con-
tinental shelf floored by glacial deposits varying
widely over short distances; high winds and large
674
THE CIA WORLD FACTBOOK
+
waves much of the year; ship icing, especially May-
October; most of region is remote from sources of
search and rescue
Environment—current issues: increased solar
ultraviolet radiation resulting from the Antarctic
ozone hole in recent years, reducing marine pri-
mary productivity (phytoplankton) by as much as
15% and damaging the DNA of some fish; illegal,
unreported, and unregulated fishing in recent
years, especially the landing of an estimated five
to six times more Patagonian toothfish than the
regulated fishery, which is likely to affect the sus-
tainability of the stock; large amount of incidental
mortality of seabirds resulting from long-line fish-
ing for toothfish
note: the now-protected fur seal population is
making a strong comeback after severe overexploi-
tation in the 18th and 19th centuries
Environment—international agreements: the
Southem Ocean ‘is subject to all international
agreements regarding the world’s oceans; in addi-
tion, it is subject to these agreements specific to
the Antarctic region: International Whaling
Commission (prohibits commercial whaling south
of 40 degrees south [south of 60 degrees south
between 50 degrees and 130 degrees west]); Con-
vention on the Conservation of Antarctic Seals
(limits sealing); Convention on the Conservation
of Antarctic Marine Living Resources (regulates
fishing)
note: many nations (including the US) prohibit
mineral resource exploration and exploitation
south of the fluctuating Polar Front (Antarc-
tic Convergence), which is in the middle of the
Antarctic Circumpolar Current and serves as the
dividing line between the cold polar surface waters
to the south and the warmer waters to the north
Geography—note: the major chokepoint is the
Drake Passage between South America and Ant-
arctica; the Polar Frant (Antarctic Convergence)
is the best natural definition of the northern extent
of the Southern Ocean; it is a distinct region at the
middle of the Antarctic Circumpolar Current that
separates the cold polar surface waters to the south
from the warmer waters to the north; the Front
and the Current extend entirely around Antarc-
tica, reaching south of 60 degrees south near New
Zealand and near 48 degrees south in the far South
Atlantic coinciding with the path of the maximum
westerly winds
Location: Southwestern Europe, bordering the
Mediterranean Sea, North Atlantic Ocean, Bay
of Biscay, and Pyrenees Mountains; southwest of','66e8d611b2283d1c458d430a1be4a542272e81338f03d1b58b49682c09c9fa9a','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('61943163b5c01710b3c53da31f478636590fb5eb9aeffcfa469a91a4ba9b7c9f',2025,'ES','Spain','geography',1491,'Maritime claims: territorial sea: 12 nm
contiguous zone: 24 nm
exclusive economic zone: 200 nm (applies only to
the Atlantic Ocean)
Climate: temperate; clear, hot summers in inte-
rior, more moderate and cloudy along coast;
cloudy, cold winters in interior, partly cloudy and
cool along coast
Terrain: large, flat to dissected plateau surrounded
by rugged hills; Pyrenees Mountains in north
Elevation extremes: lowest point: Atlantic
Ocean 0 m
highest point: Pico de Teide (Tenerife) on Canary
Islands 3,718 m
Natural resources: coal, lignite, iron ore, copper,
lead, zinc, uranium, tungsten, mercury, pyrites,
magnesite, fluorspar, gypsum, sepiolite, kaolin,
potash, hydropower, arable land
Land use: arable land: 24.75%
permanent crops: 9.29%
other: 65.96% (2011)
Irrigated land: 34,700 sq km (2011)
Total renewable water resources: 111.5 cu km
(2011)
Freshwater withdrawal (domestic/indus-
triaV/agricultural): total: 32.46 cu km/yr
(18%/22%/61%)
per capita: 698.7 cu m/yr (2008)
Natural hazards: periodic droughts, occasional
flooding
volcanism: volcanic activity in the Canary
Islands, located off Africa’s northwest coast; Teide
(elev. 3,715 m) has been deemed a “Decade Vol-
cano” by the International Association of Volcan-
ology and Chemistry of the Earth’s Interior, worthy
of study due to its explosive history and close prox-
imity to human populations; La Palma (elev. 2,426
m), which last erupted in 1971, is the most active
of the Canary Islands volcanoes; Lanzarote is the
only other historically active volcano
Environment—current Issues: pollution of che
Mediterranean Sea from raw sewage and effluents
from the offshore production of oil and gas; water
quality and quantity nationwide; air pollution;
deforestation; desertification s
Environment—international agreements:
party to: Air Pollution, Air Pollution-Nitrogen
Oxides, Air Pollution-Sulfur 94, Air Pollution-
Volatile Organic Compounds, Antarctic-Envi-
ronmental Protocol, Antarctic-Marine Living
Resources, Antarctic Treaty, Biodiversity, Climate
Change, Climate Change-Kyoto Protocol, Deser-
tification, Endangered Species, Environmental
Modification, Hazardous Wastes, Law of the Sea,
Marine Dumping, Marine Life Conservation,
Ozone Layer Protection, Ship Pollution, Tropi-
cal Timber 83, Tropical Timber 94, Wetlands,
Whaling
signed, but not ratified: Air Pollution-Persistent
Organic Pollutants
Geography—note: strategic location
approaches to Strait of Gibraltar; Spain controls a
number of territories in northern Morocco includ-
ing the enclaves of Ceuta and Melilla, and the
along
islands of Penon de Velez de la Gomera, Penon de
Albucemas, and Islas Chafarinas
Location: Southeastern Asia, group of reefs and
islands in the South China Sea, about two-thirds
of the way from southem Vietnam to the southern','d166697ec19b34a550a5f7daddd94fc335c6486f78bd721adc5df8fb376bfd37','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('05522be2635e56b25916d8bd23df40e511ab7657c5020693f6dfb2ab64842b2f',2025,'PH','Philippines','geography',1497,'Geographic coordinates: 8 38 N, 111 55 E
Map references: Southeast Asia
Area: total: less than 5 sq km
country comparison to the world: 248
land: less than 5 sq km
water: 0 sq km
note: includes 100 or so islets, coral reefs, and sea
mounts scattered over an area of nearly 410,000 sq
km of the central South China Sea
Area—comparative: NA
Land boundaries: 0 km
Coastline: 926 km
Maritime claims: NA
Climate: tropical
Terrain: Flat
Elevation extremes: lowest point: South China
Sea O m
highest point: unnamed location on Southwest
Cav 4m
Natural resources: fish, guano, undetermined oil
and natural gas potential
Land use: arable land: 0%
permanent crops: 0%
other: 100% (2011)
irrigated land: 5,700 sq km (2006)
Natural hazards: typhoons; numerous reefs and
shoals pose a serious maritime hazard
Environmeni—current issues: NA
Geography—note: strategically located near sev-
eral primary shipping lanes in the central South
China Sea; includes numerous small islands, atolls,
shoals, and coral reefs','8618b476190d39c88bc234706b4bf6cca26bd514621f06ae6f46d4639a791d52','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8a3b4a4e9bd9816018fe4a78e1c778c12584b75faf28e6e6e92e35f7edea4c04',2025,'LK','Sri Lanka','geography',1507,'Location: north-eastern Africa, bordering the Red
Sea, between Egypt and Eritrea
Geographic coordinates: 15 00 N, 30 00 E
Map references: Africa
Area: total: 1,861,484 sq km
country comparison to the world: 16
land: NA
water: NA
Area—comparative: slightly less than one-fifth
the size of the US
Land boundaries: total:6,751 km
border countries: Central African Republic 175
km, Chad 1,360 km, Egypt 1,275 km, Eritrea 605
km, Ethiopia 769 km, Libya 383 km, South Sudan
2,184 km
note: Sudan-South Sudan boundary represents 1
January 1956 alignment final alignment pending
683
negotiations and demarcation; final sovereignty
status of Abyei region pending negotiations
between Sudan and South Sudan
Coastline: 853 km
Maritime claims: territorial sea: 12 nm
contiguous zone: 18 nm
continental shelf: 200 m depth or to the depth
of exploitation Climate: hot and dry; arid
desert; rainy season varies by region (April to
November)
Terrain: generally flac, featureless plain; desert
dominates the north
Elevation extremes: lowest point: Red Sea 0 m
highest point: Jabal Marrah 3,071 m
Natural resources: petroleum; small reserves of
iron ore, copper, chromium ore, zinc, tungsten,
mica, silver, gold; hydropower
Land use: arable land: 6.76%
permanent crops: 0.07%
other: 93.17% (2011)
Irrigated land: 18,900 sq km (2010)
Total renewable water resources: 64.5 cu km
(2011) f
Freshwater withdrawal (domestic/indus-
trial/agricultural): total: 27.59 cu km/yr
(4%/1%/95%)
per capita: 683.4 cu m/yr (2005)
Natural hazards: dust storms and periodic persis-
tent droughts
Environment—current issues: inadequate sup-
plies of potable water; wildlife populations threat-
ened by excessive hunting; soil erosion; desertifica-
tion; periodic drought
Environment—international agreements:
party to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Endan-
gered Species, Hazardous Wastes, Law of the Sea,
Ozone Layer Protection, Wetlands signed, but not
ratified: none of the selected agreements
Geography—note: dominated by the Nile and its
tributaries','c90bc3bc3deaa3a24fac77ecdbccf3b05d3c0607065b764354f9d45340883b29','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('18b2c604ca1817d501d428b56cca94e337b6e5983dd4d844b1556b6a82d2fade',2025,'SR','Suriname','geography',1523,'Location: Northern Europe, islands between the
Arctic Ocean, Barents Sea, Greenland Sea, and
Norwegian Sea, north of Norway
Geographic coordinates: 78 00 N, 20 00 E
Map references: Europe
Area: total: 62,045 sq km
country comparison to the world: 125
land: 62,045 sq km
water: 0 sq km
note: includes Spitsbergen and Bjornoya (Bear
Island)
Area—comparative: slightly smaller than West
Virginia
Land boundaries: 0 km
Coastline: 3,587 km
Maritime claims: territorial sea:4 nm
exclusive fishing zone: 200 nm unilaterally
claimed by Norway bue not recognized by Russia
Climate: arctic, tempered by warm North Atlantic
Current; cool summers, cold winters; North Atlan-
fic Current flows along west and north coasts of
Spitsbergen, keeping water open and navigable
most of the year
Terrain: wild, rugged mountains; much of high
land ice covered; west coast clear of ice about one-
half of the year; fjords along west and north coasts
Elevation extremes: lowest point: Arctic Ocean
Om
highest point: New tontoppen 1,717 m
Natural resources: coal, iron ore, copper, zinc,
phosphate, wildlife, fish
Land use: arable land:0%
permanent crops: 0%
other: 100% (no trees; the only bushes are crow-
berry and cloudberry) (2011)
Irrigated land: NA
s
Natural hazards: ice floes often block the entrance
to Bellsund (a transit point for coal export) on
the west coast and occasionally make parts of the
* northeastern coast inaccessible to maritime traffic
Environment—current issues: NA
Geography—note: northernmost part of the
Kingdom of Norway; consists of nine main islands;
glaciers and snowfields cover 60% of the total
area; Spitsbergen Island is the site of the Svalbard
Global Seed Vault, a seed repository established by
the Global Crop Diversity Trust and the Norwe-
gian Government
Location: Southern Africa, between Mozambique
and South Africa
Geographic coordinates: 26 30 S, 31 30 E
Map references: Africa
Area: total: 17,364 sq km
country comparison to the world: 159
land: 17,204 sq km
water: 160 sq km
Area—comparative: slightly smaller than New','ba0cc64d905736cd7547cd4f1fa4b2342f9dcec4d764a6d79591c149d646a7e1','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1a5cc583681fb438cec70aefa9c9ce87c315195a92da42f95ef2e78d5c7d4604',2025,'TJ','Tajikistan','geography',1538,'Location: Central Asia, west of China, south of
total population: 0.99 male(s)/female (2013 est.)
Maternal mortality rate: 65 deaths/100,000 live
births (2010) i
country comparison to the world: 93
Infant mortality rate: total: 36.16 deaths/1,000
live births
country comparison to the world: 64
male: 40.65 deaths/1,000 live births
female: 31.45 deaths/1,000 live births (2013 est.)
Life expectancy at birth: total population: 66.72
years
country comparison to the world: 166
male: 63.63 years
female: 69.97 years (2013 est.)
Total fertility rate: 2.8 children born/woman
(2013 est.)
country comparison to the world: 70
Health expenditures: 6% of GDP (2010)
country comparison to the world: 109
Physicians density: 2.1 physicians/1,000 popula-
tion (2006)
Hospital bed density: 5.2 beds/1,000 population
(2009)
Drinking water source:
Improved:
urban: 92% of population
rural: 54% of population
total: 64% of population
Unimproved:
urban: 8% of population
rural: 46% of population
total: 36% of population (2010 est.)
Sanitation facility access:
Improved:
urban: 95% of population
rural: 94% of population
total: 94% of population
Unimproved:
urban: 5% of population
rural: 6% of population
total: 6% of population (2010 est.)
HiV/AIDS—adult prevalence rate: 0.2% (2009
est.)
country comparison to the world: 106
HIV/AIDS—people living with HIV/AIDS: 9,100
(2009 est.)
country comparison to the world: 101
HIV/AIDS—deaths: fewer than 500 (2009 est.)
country comparison to the world: 81
Major Infectious diseases: degree of risk: high
food or waterborne diseases: bacterial diarrhea,
hepatitis A, and typhoid fever
vectorborne disease: malaria (2009)
Obesity—adult prevalence rate: 8.6% (2008)
country comparison to the world: 136
Children under the age of 5 years under-
weight: 15% (2005)
country comparison to the world: 51
Education expenditures: 3.9% of GDP (2011)
country comparison to the world: 115
Literacy: definition: age 15 and over can read
and write
total population: 99.7%
male: 99.8%
female: 99.6% (2010 est.)
Schoo! life expectancy (primary to tertiary
education): total: 11 years
male: 12 years
female: 10 years (2008)
Location: Eastern Africa, bordering the Indian
Ocean, between Kenya and Mozambique
Geographic coordinates: 6 00 S, 35 00 E
Map references: Africa
Area: total: 947,300 sq km
country comparison to the world: 31
land: 885,800 sq km
water: 61,500 sq km
note: includes the islands of Mafia, Pemba, and
Zanzibar
Area—comparative: slightly larger than twice
the size of California
Land boundaries: total: 3,861 km
border countries: Burundi 451 km, Democratic
Republic of the Congo 459 km, Kenya 769 km,
Malawi 475 km, Mozambique 756 km, Rwanda
217 km, Uganda 396 km, Zambia 338 km
Coastline: 1,424 km
Maritime claims: territorial sea: 12 nm
exclusive economic zone: 200 nm
Climate: varies from tropical along coast to tem-
perate in highlands
714
Terrain: plains along coast; central plateau; high-
lands in north, south
Elevation extremes: lowest point: Indian Ocean
Om
highest point: Kilimanjaro 5,895 m (highest point
in Africa)
Notural resources: hydropower, tin, phosphates,
iron ore, coal, diamonds, gemstones, gold, natural
gas, nickel
Land use: arable land: 12.25%
permanent crops: 1.79%
other: 85.96% (2011) :
Irrigated land: 1,843 sq km (2003)
Tota! renewable water resources: 96.27 cu km
(2011)
Freshwater withdrawal (domestic/industrial/
agricultural): total: 5.18 cu km/yr (10%/0%/89%)
per capita: 144.7 cu m/yr (2002)
Natural hazards: flooding on the central plateau
during the rainy season; drought
volcanism: limited volcanic activity; Ol Doinyo
Lengai (elev. 2,962 m) has emitted lava in recent
years; other historically active volcanoes include
Kieyo and Meru
Environment—eurrent issues: soil degrada-
tion; deforestation; desertification; destruction
of coral reefs threatens marine habitats; recent
droughts affected marginal agriculture; wildlife
threatened by illegal hunting and trade, espe-
cially for ivory
Environment—intemational agreements:
party to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Endan-
gered Species, Hazardous Wastes, Law of the Sea,
Ozone Layer Protection, Wetlands
signed, but not ratified: none of the selected
agreements
Geography—note: Kilimanjaro is the highest
point in Africa and one of only two mountains
on the continent that has glaciers (the other is
Mount Kenya); bordered by three of the largest
lakes on the continent: Lake Victoria (the world’s
second-largest freshwater lake) in the north,
Lake Tanganyika (the world’s second deepest) in
the west, and Lake Nyasa (Lake Malawi) in the
southwest
Location: Southeastern Asia, bordering the Anda-
man Sea and the Gulf of Thailand, southeast of
Burma
Geographic coordinates: 15 00 N, 100 00 E
Map references: Southeast Asia
Area: total: 513,120 sq km
country comparison to the world: 51
land: 510,890 sq km
water: 2,230 sq km
Area—comparative: slightly more than twice the
size of Wyoming
Land boundaries: total: 4,863 km
border countries: Burma 1,800 km, Cambodia
803 km, Laos 1,754 km, Malaysia 506 km
Coastline: 3,219 km
Maritime claims: territorial sea: 12 nm
exclusive economic zone: 200 nm
continental shelf: 200 m depth or to the depth of
exploitation
Climate: tropical; rainy, warm, cloudy southwest
monsoon (mid-May to September); dry, cool
northeast monsoon (November to mid-March);
southern isthmus always hot and humid
Terrain: central plain; Khorat Plateau in the east;
mountains elsewhere
Elevation extremes: lowest point: Gulf of Thai-
land 0 m
highest point: Doi Inthanon 2,576 m
Natural resources: tin, rubber, natural gas, tung-
sten, tantalum, timber, lead, fish, gypsum, lignite,
fluorite, arable land
Land use: arable land: 30.71%
permanent crops: 8.77%
other: 60.52% (2011)
Irrigated land: 64,150 sq km (2007)
Total renewable water resources: 438.6 cu km
(2011)
Freshwater withdrawal (domestic/industrial/
agricultural): total: 57.31 cu km/yr (5%/5%/90%)
per capita: 845.3 cu m/yr (2007)
Natural hazards: land subsidence in Bangkok
area resulting from the depletion of the water
table; droughts
Environment—current issues: air pollution
from vehicle emissions; water pollution from
organic and factory wastes; deforestation; soil ero-
sion; wildlife populations threatened by illegal
hunting
Environment—international agreements:
party to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Endan-
gered Species, Hazardous Wastes, Marine Life
Conservation, Ozone Layer Protection, Tropical
Timber 83, Tropical Timber 94, Wetlands
signed, but not ratified: Law of the Sea
Geography—note: controls only land route from
Asia to Malaysia and Singapore','181d5f77a1e882e0de0ad6b2245709bdd09db2a0383d741763387ea67704abc3','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('74f44c546b3c72ad4f75adfaf3720a168fa841d9369b8977215324d4e968d516',2025,'TL','Timor-Leste','geography',1564,'Location: Western Africa, bordering the Bight of
Benin, between Benin and Ghana
Geographic coordinates: 8 00 N, 1 10 E
Map references: Africa
Area: total: 56,785 sq km
country comparison to the world: 126
land: 54,385 sq km
water: 2,400 sq km
Area—comparative: slightly smaller than West
Virginia
Lond boundaries: total: 1,647 km
border countries: Benin 644 km, Burkina Faso
126 km, Ghana 877 km
Coastline: 56 km
Maritime claims: territorial sea: 30 nm
exclusive economic zone: 200 nm
Climate: tropical; not, humid in south; semiarld
in north
Terrain: gently rolling savanna in north; central
hills; southern plateau; low coastal plain with
extensive lagoons and marshes
Elevation extremes:
Ocean 0 m highest point: Mont Agou 986 m
Natural resources: phosphates; limestone, mar-
ble, arable land
Land use: arable land: 44.2%
permanent crops: 3.7%
other: 52.1% (2011)
Irrigated land: 73 sq km (2003)
Total renewobie water resources: 14.7 cu km
(2011)
Freshwater withdrawal (domestic/industrial/
agricultural): total:0.17 cukm/yr (63%/3%/34%)
per capita: 33.46 cu m/yr (2005)
Natural hazards: hor, dry harmattan wind can
reduce visibility in north during winter; periodic
lowest point: Atlantic
droughts
Environment—current issues:
attributable to slash-and-burn agriculture and
deforestation
the use of wood for fuel; water pollution presents
health hazards and hinders the fishing industry; air
pollution increasing in urban are
Environment—international agreements:
party to: Biodiversity, Climate Change, Cli-
mate Change-Ky Desertification,
Endangered Species, Law of the Sea, Oz
Layer Protection, Ship Pollution, Tropical Tim-
ber 83, Tropical Timber 94, Wetlands, Whaling
Pr BA |
9 Frotocoi,
725
signed, but not ratified: none of the selected
agreements
Geography—note: the country’s length allows it
to stretch through six distinct geographic regions;
climate varies from tropical to savanna','ea779521c4cacb47e347b76a676bf0b854b62a45c99b5be7dd113bc0d3540f1c','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c53663a4e16d59bb2cb6b3bed68118a4edaeaac4bba91d5e2c84cc9cd70ef5c9',2025,'TK','Tokelau','geography',1571,'Location: Oceania, group of three atolls in the
South Pacific Ocean, about one-half of the way
from Hawaii to New Zealand
Geographic coordinates: 9 00 S, 172 00 W
Map references: Oceania
Area: total: 12 sq km
country comparison to the world: 242
land: 12 sq km
water: 0 sq km
Area—comparative: about 17 times the size of
The Mall in Washington, DC
Land boundaries: 0 km
Coastline: 101 km
Maritime claims: territorial sea: 12 nm
exclusive economic zone: 200 nm
Climate: tropical; moderated by trade winds
(April to November)
Terrain: low-lying coral atolls enclosing large
lagoons
Elevation extremes: lowest point: Pacific Ocean
Om
highest point: unnamed location 5 m
Naturai resources: NEGL
Land use: arable land: 0% (soil is thin and
infertile)
permanent crops: 60%
other: 40% (2011)
Irrigated land: NA
Natural hazards: lies in Pacific typhoon belt
Environment—current issues: limited natural
resources and’ overcrowding are contributing to
emigration to New Zealand
Geography—note: consists of three
(Atafu, Fakaofo, Nukunond), each with a lagoon
atolls
surrounded by a number of reef-bound islets of
varying length and rising to over 3 m above sea
level
Location: Oceania, archipelago in the South
Pacific Ocean, about two-thirds of the way from
Hawaii to New Zealand
Geographic coordinates: 20 00 S, 175 00 W
Map references: Oceania
Area: total: 747 sq km
country comparison to the world: 190
land: 717 sq km
water: 30 sq km
Area—comparative: four times the size of Wash-
ington, DC
Land boundaries: 0 km
Coastline: 419 km
Maritime claims: territorial sea; 12 nm
exclusive economic zone: 200 nm
1.39 (2010)
1.6 (2009)
1.42 (2008)
Fiscal year: 1 April—31 March','f007733efb11507d87e3d8b249451701ba7d56ce304a4902376a0d176d20dcba','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8755a1ad6beddba9984add6f2048edd9d7b13944e394dadfc4d1a4a2c9fd985e',2025,'TC','Turks and Caicos Islands','geography',1602,'ISLANDS Location: two island groups in the
North Atlantic Ocean, southeast of The Bahamas,
north of Haiti
Geographic coordinates: 21 45 N, 71 35 W
Map references: Central America and the
Caribbean
Area: total: 948 sq km
country comparison to the world: 186
land: 948 sq km
water: 0 sq km
Area—compaorative: 2.5 times the size of Wash-
ington, DC
Land boundaries: 0 km
Coastline: 389 km
Maritime claims: territorial sea: 12 nm
exclusive fishing zone: 200 nm
Climate: tropical; marine; moderated by trade
winds; sunny and relatively dry Terrain: low,
748
flat limestone; extensive marshes and mangrove
swamps Elevation extremes:
lowest point: Caribbean Sea 0 m highest point:
Flamingo Hill 48 m
Natural resources: spiny lobster, conch
Land use: arable land: 1.05%
permanent crops: 0%
other: 98.95% (2011)
Irrigated land: NA
Natural hazards: frequent hurricanes
Environment—current issues: limited natu-
tal freshwater resources, private cisterns collect
rainwater
Geography—note:
inhabited)
Location: Oceania, island group consisting of nine
çoral atolls in the South Pacific Ocean, about one-
half of the way from Hawaii to Australia
Geographic coordinates: 8 00 S, 178 00 E
Map references: Oceania
Area: total: 26 sq km
country comparison to the world: 238
land: 26 sq km
water: 0 sq km
Area—comparative: 0.1 times the size of Wash-
ington, DC
Land boundaries: 0 km
Coastline: 24 km
Maritime claims: territorial sea: 12 nm
contiguous zone: 24 nm
exclusive economic zone: 200 nm
Climate: tropical; moderated by easterly trade
winds (March to November); westerly gales and
heavy rain (November to March)
Terrain: low-lying and narrow coral atolls
Elevation extremes: lowest point: Pacific Ocean
Om
highest point: unnamed location 5 m
Natural resources: fish
Land use: arable land: 0%
permanent crops: 60% ae
other: 40% (2011)
Irrigated land: NA
Natural hazards: severe tropical storms are usu-
ally rare, but in 1997 there were three cyclones;
low levels of islands make them sensitive to
changes in sea level
Environment—current issues: since there
are no streams or rivers and groundwater is not
potable, most water needs must be met by catch-
ment systems with storage facilities (the Japanese
r
Government has built one desalination plant
and plans to build one other); beachhead erosion
because of the use of sand for building materi-
als; excessive clearance of forest undergrowth
for use as fuel; damage to coral reefs from the
spread of the Crown of Thorns starfish; Tuvalu is
concerned about global increases in greenhouse
gas emissions and their effect on rising sea lev-
els, which threaten the country’s underground
water table; in 2000, the government appealed
to Australia and New Zealand to take in Tuvalu-
ans if rising sea levels should make evacuation
necessary
Environment—international agreements:
party to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Law of
the Sea, Ozone Layer Protection, Ship Pollution,
Whaling
signed, but not ratified: none of the selected
agreements
Geography—note: one of the smallest and most
remote countries on Earth; six of the nine coral
atollk——Nanumea, Nui, Vaitupu, Nukufetau,
Funafuti, and Nukulaelae—have lagoons open
to the ocean; Nanumaya and Niutao have land-
lockéd lagoons; Niulakita does not have a lagoon','2dcee41cf1dfd4b0f0b2850f00d6f91784cd1ecf827f5c73518bca4925aa1c6b','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('04b532dcb3aae857e3e6de4ef7bbf1b7e148e86aa38eca7903044022a0a68428',2025,'TV','Tuvalu','geography',1619,'Location: East-Central Africa, west of Kenya, east
of the Democratic Republic of the Congo
Geographic coordinates: 100 N, 3200 E
_ Map references: Africa
Area: total: 241,038 sq km
country comparison to the world: 81
land: 197,100 sq km
water: 43,938 sq km
Arec—comparative:
Oregon
Land boundaries: total: 2,698 km
border countries: Democratic Republic of the
Congo 765 km, Kenya 933 km, Rwanda 169 km,
South Sudan 435 km, Tanzania 396 km 7
~ Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
Climate: tropical; generally rainy with two dry
seasons (December to February, June to August);
semiarid in northeast
Terrain: mostly plateau with rim of mountains
Elevation extremes: lowest point: Lake Albert
621m
highest point: Margherita Peak on Mount Stanley
5,110 m
Natural resources: copper, cobalt, hydropower,
limestone, salt, arable land, gold
Lond use: arable land: 27.94%
permanent crops: 9.11%
other: 62.95% (2011)
Irrigated land: 144.2 sq km (2010)
slightly smaller than
Total renewable water resources: 66 cu km
(2011)
Freshwoter withdrawal (domestic/indus-
trial/agricultural): total: 0.32 cu km/yr
(41%/16%/43%)
per capita: 12.31 cu m/yr (2005)
Natural hazards: NA
Environment—current issues: draining of wet-
lands for agricultural use; deforestation; overgraz-
ing; soil erosion; water hyacinth infestation in
Lake Victoria; widespread poaching
Environment—international agreements:
party to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Endan-
gered Species, Hazardous Wastes, Law of the Sea,
Marine Life Conservation, Ozone Layer Protec-
tion, Wetlands
signed, but not ratified: Environmental
Modification
Geography—note: landlocked; fertile, well-
watered country with many lakes and rivers','1be8abaa1b6799b555f917f42c5e8a44b2d4ed2ab4cc42cdc43658b418815551','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b924e7ee90a4016212ad3759229050ee6351a5d954c3e8793b51a1e1f1acd91f',2025,'UG','Uganda','geography',1627,'Location: Eastern Europe, bordering the Black
Sea, between Poland, Romania, and Moldova in
the west and Russia in the east
Geographic coordinates: 49 00 N, 32 00 E
Map references: Europe
Area: total: 603,550 sq km
country comparison to the world: 46
land: 579,330 sq km
water: 24,220 sq km
Areo—comparative: slightly smaller than Texas
Land boundaries: total: 4,566 km
border countries: Belarus 891 km, Hungary 103
km, Moldova 940 km, Poland 428 km, Romania
(south) 176 km, Romania (southwest) 362 km,
Russia 1,576 km, Slovakia 90 km
Coastline: 2,782 km
Maritime claims: territorial sea: 12 nm
exclusive economic zone: 200 nm
continental shelf: 200 m or to the depth of
exploitation
Climate: temperate continental; Mediterranean
only on the southern ‘Crimean coast; precipita-
tion disproportionately distributed, highest in west
and north, lesser in east and southeast; winters
vary from cool along the Black Sea to cold farther
inland; summers are warm across the greater part of
the country, Kot in the south
Terrain: most of Ukraine consists of fertile plains
(steppes) and plateaus, mountains being found
only in the west (the Carpathians), and in the
Crimean Peninsula in the extreme south
Elevation extremes: lowest point: Black Sea O m
highest point: Hora Hoverla 2,061 m
Natural resources: iron ore, coal, manganese,
natural gas, oil, salt, sulfur, graphite, titanium,
magnesium, kaolin, nickel, mercury, timber, arable
land
Land use: arable land: 53.85%
permanent crops: 1.48%
other: 44.67% (2011) .
Irrigated land: 21,750 sq km (2010)
Total renewable water resources: 139.6 cu km
(2011)
Freshwater withdrawal (domestic/indus-
triaVagricultural): total: 19.24 cu km/yr
(24%/69%/7%)
per capita: 415.7 cu m/yr (2010)
Natural hazards: NA
Environment—current Issues: inadequate
supplies of potable water; air and water pollu-
tion; deforestation; radiation contamination in
the northeast from 1986 accident at Chornobyl’
Nuclear Power Plant
Environment—international agreements:
party to: Air Pollution, Air Pollution-Nitrogen
Oxides, Air Pollution-Sulfur 85, Antarctic-Envi-
ronmental Protocol, Antarctic-Marine Living
Resources, Antarctic Treaty, Biodiversity, Climate
Change, Climate Change-Kyoto Protocol, Deser-
tification, Endangered Species, Environmental
Modification, Hazardous Wastes, Law of the Sea,
Marine Dumping, Ozone Layer Protection, Ship
Pollution, Wetlands
signed, but not ratified: Air Pollution-Persistent
Organic Pollutants, Air Pollution-Sulfur 94, Air
Pollution- Volatile Organic Compounds
Geography—note: strategic position at the cross-
roads between Europe and Asia; second-largest
_country in Europe','01cd637d57ea67734ea86b8930e7a4c6a4ee4269160dbcd5fbaf62fabdf89f40','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6fc9f6a9562c0731da4d2917d9f05a58d90aabcb18f9c39dc60ad052b437926b',2025,'AE','United Arab Emirates','geography',1637,'Location: Middle East, bordering the Gulf of
Oman and the Persian Gulf, between Oman and
highest point: Jabal Yibir 1,527 m
Natural resources: petroleum, natural gas
Land use: arable land: 0.61%
permanent crops: 0.5%
other: 98.9% (2011)
Irrigated land: 920 sq km (2010)
Total renewable water resources: 0.15 cu km
(2011)
Freshwater withdrawal (domestic/industrial/
agricultural): total: 3.99 cu km/yr (15%/2%/83%)
ber capita: 739.5 cu m/yr (2005)
Natural hazards: frequent sand and dust storms
Environment—current issues: lack of natural
freshwater resources compensated by desalination
plants; desertification; beach pollution from oil spills
Environment—international agreements:
party to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Endan-
gered Species, Hazardous Wastes, Marine Dump-
ing, Ozone Layer Protection signed, but not rati-
fied: Law of the Sea
Geography—note: strategic location along south-
em approaches to Strait of Hormuz, a vital transit
point for world crude oil','d9e3fdd1230d51e424b1d4375847e721f63b564b9d70092ab683f4fd87be1cd6','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7188b3d8419e74396049db924582aab3e64a23c3ca8e24e8c8dc2e515397f826',2025,'GB','United Kingdom','geography',1646,'Location: Western Europe, islands—including
the northern one-sixth of the island of Ireland—
between the North Atlantic Ocean and the North
Sea; northwest of France
Geographic coordinates: 54 00 N, 2 00 W
Map references: Europe
Area: total: 243,610 sq km
country comparison to the world: 80
land: 241,930 sq km
water: 1,680 sq km
764
note: includes Rockall and Shetland Islands
Area—comparative:
Oregon
Land boundaries: total: 360 km
border countries: Ireland 360 km
Coastline: 12,429 km
Maritime claims: territorial sea: 12 nm
exclusive fishing zone: 200 nm
continental shelf: as defined in continental
shelf orders or in accordance with agreed upon
boundaries
slightly smaller than
Climate: temperate; moderated by prevailing
southwest winds over the North Atlantic Current;
more than one-half of the days are overcast
Terrain: mostly rugged hills and low mountains;
level to rolling plains in east and southeast
Elevation extremes: lowest point: The Fens -4 m
highest point: Ben Nevis 1,343 m
Natural resources: coal, petroleum, natural gas,
» iron ore, lead, zinc, gold, tin, limestone, salt, clay,
chalk, gypsum, potash, silica sand, slate, arable
land
Land use: arable land: 24.88%
permanent crops: 0.18%
other: 74.93% (2011)
irrigated land: 2,280 sq km (2005)
Total renewable water resources: 147 cu km
(2011)
Freshwater withdrawal (domestic/indus-
trial/agricultural): total: 13.03 cu km/yr
(58%/33%/9%)
per capita: 213.2 cu m/yr (2008)
Natural hazards: winter windstorms; floods
Environment—current issues: continues to reduce
greenhouse gas emissions (has met Kyoto Protocol
target of a 12.5% reduction from 1990 levels and
intends to meet the legally binding target and move
toward a domestic goal of a 20% cut in emissions by
2010); by 2005 the government reduced the amount
of industrial and commercial waste disposed of in
landfill sites to 85% of 1998 levels and recycled or
composted at least 25% of household waste, increas-
ing to 33% by 2015
Environment—international agreements:
party to: Air Pollution, Air Pollution-Nitrogen
Oxides, Air Pollution-Persistent Organic Pol-
lutanes, Air Pollution-Sulfur 94, Air Pollution-
Volatile Organic Compounds, Antarctic-Envi-
ronmental Protocol, Antarctic-Marine Living
Resources, Antarctic“ Seals, Antarctic Treaty,
Biodiversity, Climate Change, Climate Change-
Kyoto Protocol, Desertification, Endangered
Species, Environmental Modification, Hazardous
Wastes, Law of the Sea, Marine Dumping, Marine
Life Conservation, Ozone Layer Protection, Ship
Pollution, Tropical Timber 83, Tropical Timber 94,
Wetlands, Whaling
signed, but not ratified: none of the selected
agreements
Geography—note: lies near vital North Atlan-
tic sea lanes; only 35 km from France and linked
by tunnel under the English Channel; because of
heavily indented coastline, no location is more
than 125 km from tidal waters','4827756d7f854eafc6e994666b3bd689d93c6af412457c9cf9adfb6802c00efc','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ebdbdda1c25d29eb0205761af95b6bf3a4876c80737b6b9457365377a1ea21b7',2025,'US','United States','geography',1654,'Location: North America, ‘bordering both the
North Atlantic Ocean and the North Pacific
Ocean, between Canada and Mexico
Geographic coordinates: 38 00 N, 97 00 W
Map references: North America
Area: total: 9,826,675 sq km
country comparison to the world: 3
land: 9,161,966 sq km
water: 664,709 sq km A
note: includes only the 50 states and District of
Columbia
Area—comparajive: about half the size of Rus-
sia; about three-tenths the size of Africa; about
half the size of South America (or slightly larger
than Brazil); slightly larger than China; more than
twice the size of the European Union
Land boundaries: total: 12, 034 km
border countries: Canada 8,893 km (including
2,477 km with.Alaska), Mexico 3, 141 km
note: US Naval Base at Guantanamo Bay, Cuba
is leased by the US and is part of Cuba; the base
boundary is 28 km n
Coastline: 19,924 km
Moritime claims: territorial sea: 12 nm contigu-
ous zone: 24 nm
exclusive economic zone: 200 nin
continental shelf: not specified
Climate: mostly temperate, but tropical in Hawaii
and Florida, arctic in Alaska, semiarid in the great
plains west of the Mississippi River, and arid in the
Great Basin of the southwest; low winter tempera-
tures in the northwest are ameliorated occasionally
in January and February by warm chinook winds
from the eastern slopes of the Rocky Mountains
Terrain: vast central plain, mountains in west,
hills and low mountains in east; rugged mountains
and broad river valleys in Alaska; rugged, volcanic
topography in Hawaii
Elevation extremes: lowest point: Death Valley
-86 m
highest point: Mount McKinley (Denali) 6,194 m
(highest point in North America)
note: the peak of Mauna Kea (4,207 m above sea
level) on the island of Hawaii rises about 10,200
m above the Pacific Ocean floor; by this measure-
ment, it is the world’s tallest mountain—higher
than Mount Everest (8,850 m), which is recog-
nized as the tallest mountain above sea level
Natural resources: coal, copper, lead, molybdenum,
phosphates, rare earth elements, uranium, bauxite,
gold, iron, mercury, nickel, potash, silver, tungsten,
zinc, petroleum, natural gas, timber
note: the US has the world’s largest coal reserves
with 491 billion short tons accounting for 27% of
the world’s total
Land use: arable land: 16.29%
permanent crops: 0.26%
other: 83.44% (2011)
Irrigated land: 266,440 sq km (2007)
Total renewable water resources: 3,069 cu km
(2011)
Freshwater withdrawal (domestic/indus-
triaVagricultural): total: 478.4 cu km/yr
(14%/46%/40%)
per capita: 1,583 cu m/yr (2005)
Natural hazards: tsunamis; volcanoes; earth-
quake activity around Pacific Basin; hurricanes
along the Atlantic and Gulf of Mexico coasts; tor-
nadoes in the Midwest and Southeast; mud slides
in California; forest fires in the west; flooding;
permafrost in northern Alaska, a major impedi-
ment to development volcanism: volcanic activ-
ity in the Hawaiian Islands, Western Alaska, the
Pacific Northwest, and in the Northern Mariana
Islands; both Mauna Loa (elev. 4,170 m) in Hawaii
and Mount Rainier (elev. 4,392 m) in Washing-
ton have been deemed “Decade Volcanoes” by
the International Association of Volcanology and
Chemistry of the Earth’s Interior, worthy of study
due to their explosive history and close proximity
to human populations; Pavlof (elev. 2,519 m) is
the most active volcano in Alaska’s Aleutian Arc
and poses a significant threat to air travel since
the area constitutes a major flight path between
North America and East Asia; St. Helens (elev.
2,549 m, famous for the devastating 1980 eruption,
remains active today; numerous other historically
active volcanoes exist, mostly concentrated in the
Aleutian arc and Hawaii; they include: in Alaska:
Aniakchak, Augustine, Chiginagak, Fourpeaked,
Iliamna, Katmai, Kupreanof, Martin, Novarupta,
Redoubt, Spurr, Wrangell; in Hawaii: Trident,
Ugashik-Peulik, Ukinrek Maars, Veniaminof; in
the Northern Mariana Islands: Anatahan; and in
the Pacific Northwest: Mount Baker, Mount Hood
Environment—current issues: air pollution
resulting in acid rain in both the US and Canada;
the US is the largest single emitter of carbon diox-
ide from the burning of fossil fuels; water pollution
from runoff of pesticides and fertilizers; limited
natural freshwater resources in much of the west-
ern part of the country require careful manage-
ment; desertification
Environment—international agreements:
party to: Air Pollution, Air Pollution-Nitrogen
Oxides, Antarctic-Environmental
Antarctic-Marine Living Resources, Antarctic
Seals, Antarctic Treaty, Climate Change, Deser-
tification, Endangered Species, Environmental
Modification, Marine Dumping, Marine Life Con-
servation, Ozone Layer Protection, Ship Pollution,
Tropical Timber 83, Tropical Timber 94, Wetlands,
Whaling signed, but not ratified: Air Pollution-
Persistent Organic Pollutants, Air Pollution-Vol-
atile Organic Compounds, Biodiversity, Climate
Change-Kyoto Protocol, Hazardous Wastes
Geography—note: world’s third-largest country
by size (after Russia and Canada) and by popula-
tion (after China and India); Mt. McKinley is
highest point in North America and Death Valley
the lowest point on the continent
Location: Oceania
Baker Island: atoll in the North Pacific Ocean
1,830 nm (3,389 km) southwest of Honolulu,
about halfway between Hawaii and Australia
Howland Island: island in the North Pacific
Ocean 1,815 nm (3,361 km) southwest of Hono-
lulu, about halfway between Hawaii and Australia
Jarvis Island: island in the South Pacific Ocean
1,305 nm (2,417 km) south of Honolulu, about
half way between Hawaii and Cook Islands
Johnston Atoll: atoll in the North Pacific Ocean
717 nm (1,328 km) southwest of Honolulu, about
one-third of the way from Hawaii to the Marshall
Islands
Kingman Reef: reef in the North Pacific Ocean
930 nm (1,722 km) south of Honolulu, about half
way between Hawaii and American Samoa
Midway Islands: atoll in the North Pacific Ocean
1,260 nm (2,334 km) northwest of Honolulu near
the end of the Hawaiian Archipelago, about one-
third of the way from Honolulu to Tokyo
Palmyra Atoll: atoll in the North Pacific Ocean
960 nm (1,778 km) south of Honolulu, about half
way between Hawaii and American Samoa
Geographic coordinates: Baker Island: 0 13 N,
176 28 W
Howland Island: 0 48 N, 176 38 W
Jarvis Island: 0 23 S, 160 01 W
Johnston Atoll: 16 45 N, 169 31 W
Kingman Reef: 6 23 N, 162 25 W
Midway Islands: 28 12 N, 177 22 W
Palmyra Atoll: 5 53 N, 162 05 W
Mop references: Oceania
Area: total—6,959.41 sq km; emergent land—
22.41 sq km; submerged—6,937 sq km
country comparison to the world: 239
Baker Island: total—129. 1 sq km; emergent
land—2.1 sq km; submerged—127 sq km
Howland Island: total—138.6 sq km; emergent
land—2.6 sq km; submerged—136 sq km
Jarvis Island: total—152 sq km; emergent land—5
sq km; submerged—147 sq km
Johnston Atoll: total—276.6 sq km; emergent .
land—2. 6 sq km; submerged—274 sq km
Kingman Reef: total—1,958.01 sq km; emergent
land—0.01 sq km; submerged—1,958 sq km
Midway Islands: toral—2,355.2 sq km; emergent
land—6.2 sq km; submerged—2,349 sq km
Palmyra Atoll: total—1,949.9 sq km; emergent
land—3.9 sq km; submerged—1,946 sq km
Area—comparative: Baker Island: about two
and a half times the size of The Mall in Washing-
ton, DC
Howland Island: about three times the size of The
Mall in Washington, DC
Jarvis Island: about eight times the size of The
Mall in Washington, DC
Johnston Atoll: about four and a half times the
size of The Mall in Washington, DC
Kingman Reef: a little more than one and a half
times the size of The Mall in Washington, DC
Midway Islands: about nine times the size of The
Mall in Washington, DC
Palmyra Atoll: about 20 times the size of The
Mall in Washington, DC
Land boundaries: none
Coastline: Baker Island: 4.8 km
Howland Island: 6.4 km
Jarvis Island: 8 km
Johnston Atoll: 34 km
Kingman Reef: 3 km
Midway Islands: 15 km
Palmyra Atoll: 14.5 km
Maritime claims: territorial sea: 12 nm
exclusive economic zone: 200 nm
Climate: Baker, Howland, and Jarvis Islands:
equatorial; scant rainfall, constant wind, burning sun
UNITED STATES PACIFIC ISLAND WILDLIFE REFUGES
Johnston Atoll and Kingman Reef: tropical, but
generally dry; consistent northeast trade winds
with little seasonal temperature variation
Midway Islands: subtropical with cool, moist
winters (December to February) and warm, dry
summers (May to October); moderated by pre-
vailing easterly winds; most of the 1,067 mm
(42 in} of annual rainfall occurs during the
winter
Palmyra Atoll: equatorial, hot; located within the
low pressure area of the Intertropical Convergence
Zone (ITCZ) where the northeast and southeast
trade winds meet, it is extremely wet with between
4,000-5,000 mm (160-200 in) of rainfall each year
Terrain: low and nearly level sandy coral islands
with narrow fringing reefs that have developed
at the top of submerged volcanic mountains,
which in most cases rise steeply from the ocean
floor
Elevation eftremes: lowest point: Pacific Ocean
Om
highest point: Baker Island, unnamed loca-
tion—8 m; Howland Island, unnamed loca-
tion—3 m; Jarvis Island, unnamed location—7
m; Jahaston Atoll, Sand Isiand—10 m; Kingman
Reef, unnamed location—less than 2 m; Midway
Islands, unnamed location—1!3 m; Palmyra Atoll,
unnamed location—3 m
Natural resources: terrestrial and aquatic wildlife
Land use: arable land: 0%
permanent crops: 0%
other: 100% (2011)
Natural hazards: Baker, Howland, and Jarvis
Islands: the narrow fringing reef surrounding the
island poses a maritime hazard
Kingman Reef: wet or awash most of the time,
maximum. elevation of less than 2 m makes King-
man Reef a maritime hazard
Midway Islands, Johnston, and Palmyra Atolls:
NA
Environment—current issues: Baker, How-
land, and Jarvis Islands, and Johnston Atoll: no
natural freshwater resources
Kingman Reef: none
Midway Islands and Palmyra Atoll: NA
Geography—note: Baker, Howland, and Jarvis
Islands: scattered vegetation consisting of grasses,
prostrate vines, and low growing shrubs; primarily
a nesting, roosting, and foraging habitat for sea-
birds, shorebirds, and marine wildlife; closed to
the public
Johnston Atoll: Johnston Island and Sand Island
are natural islands, which have been expanded
by coral dredging; North Island (Akau) and East
Island (Hikina) are manmade islands formed from
coral dredging; the egg-shaped reef is 34 km in cir-
cumference; closed to the public
Kingman Reef: barren coral atoll with deep inte-
tior lagoon; closed to the public
Midway Islands: a coral atoll managed as a
NWR and open to the public for wildlife-related
recreation in the form of wildlife observation and
photography
Palmyra Atoll: the high rainfall and resulting
lus vegetation make the environment of this
atoll unique among the US Pacific Island territo-
ries; supports a large undisturbed stand of Pisonia
beach forest
Location: Southern South America, bordering
the South Atlantic Ocean, between Argentina
and Brazil
Geographic coordinates: 33 00 S, 56 00 W
Map references: South America
Ares: total: 176.215 sq km
country comparison to the world: 91
land: 175,015 sq km
water: 1,200 sq km
Area—comporative: slightly smaller than the
tate of Washington
Land boundaries: coral: 1,648 km
border countries: Argentina 580 km, Brazil 1,068
km
Coastline: 660 km
Maritime claims: territorial sea: 12 nm
775
x
č
"sano
Jacuarembo i
Pasand.
san Flonda
Jose Minaa,
Las
Piedras
MONTEVIDEO SOV
ATLANTE
Doaa
contiguous zone: 24 nm
exclusive economic zone: 200 nm
continental shelf: 2uu nm or edge of continental
margin
Climate: warm temperate; freezing temperatures
almost unknown
Terrain: mostly rolling plains and low hills; fertile
coastal lowland
Elevation extremes: lowest point: Atlantic
Ocean U m
highest point: Cerro Catedral 514 m
Natural resources: arable land, hydropower,
minor minerals, fish
Land use: arable land: 10.25%
permanent crops: 0.22%
other: 89.52% (2011)
Irrigated land: 1,810 sq km (2003)
Total renewable water resources: 139 cu km
- (2011)
Freshwater withdrawal (domestic/industrial/
agricultural): total: 3.66 cu km/yr (11%/2%/87%)
per capita: 1,101 cu m/yr (2000)
Natura) hazards: seasonally high winds (the
pampero is a chilly and occasional violent wind
that blows north from the Argentine pampas),
droughts, floods; because of the absence of moun-
tains, which act as weather barriers, all locations
are particularly vulnerable to rapid changes from
weather fronts
Environment—current issues: water pollution
from meat packing/tannery industry; inadequate
solid/hazardous waste disposal
Environment—international agreements:
party to: Antarctic-Environmental Protocol, Ant-
arctic-Marine Living Resources, Antarctic Treaty,
Biodiversity, Climate Change, Climate Change-
Kyoto Protocol, Endangered
Species, Environmental Modification, Hazardous
Wastes, Law of the Sea, Ozone Layer Protection,
Ship Pollution, Wetlands
signed, but not ratified: Marine Dumping, Marine
Life Conservation
Geography—note: second-smallest South Ameri-
can country (after Suriname); most of the low-
lying landscape (three-quarters of the country) is
grassland, ideal Tor cattle and sheep raising','241b3627047f0f8f7200583a92ebfb30b34f94b8f407f29b00f0df79f5ee51c5','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9ca96a9b1d8cb693318e01e60c2907070792e7504dd12652a851adde0cdf6892',2025,'UZ','Uzbekistan','geography',1680,'Location: Oceania, group of islands in the South
Pacific Ocean, about three-quarters of the way
from Hawaii to Australia
Geographic coordinates: 16 00 S, 167 00 E
Map references: Oceania
Area: total: 12,189 sq km
country comparison to the world: 164
land: 12,189 sq km
water: 0 sq km
note: includes more than 80 islands, about 65 of
which are inhabited
Area—comparative:
Connecticut
Land boundaries: 0 km
Coastline: 2,528 km
Maritime claims: measured from claimed archi-
pelagic baselines
784
slightly larger than
territorial sea: 12 nm
contiguous zone: 24 nm
exclusive economic zone: 200 nm
continental shelf: 200 nm or to the edge of the
continental margin
Climate: tropical; moderated by southeast trade
winds from May to October; moderate rainfall
from November to April; may be affected by
cyclones from December to April
Terrain: mostly mountainous islands of volcanic
origin; narrow coastal plains
Elevation extremes: lowest point: Pacific Ocean
Om
highest point: Tabwemasana 1,877 m
Natural resources; manganese, hardwood forests,
fish
Land use: arable land: 1.64%
permanent crops: 10.25%
other: 88.11% (2011)
Irrigated land: NA
Natural hazards: tropical cyclones or typhoons
(January to April); volcanic eruption on Aoba
(Ambae) island began on 27 November 2005,
volcanism also causes minor earthquakes; tsunamis
volcanism: significant volcanic activity with mul-
tiple eruptions in recent years; Yasur (elev. 361 m),
one of the world’s most active volcanoes, has expe-
rienced continuous activity in recent centuries;
other historically active volcanoes include, Aoba,
Ambrym, Epi, Gaua, Kuwae, Lopevi, Suretamatai,
and Traitor’s Head
Environment—current issues: most of the popu-
lation does not have access to a reliable supply of
potable water; deforestation
Environment—international agreements:
party to: Antarctic-Marine Living Resources, Bio-
diversity, Climate Change, Climate Change-Kyoto
Protocol, Desertification, Endangered Species,
Law of the Sea, Marine Dumping, Ozone Layer
Protection, Ship Pollution, Tropical Timber 94
signed, but not ratified: none of the selected
agreements
Geography—note: a Y-shaped chain of four main
islands and 80 smaller islands; several of the islands
have active volcanoes and there are several under-
water volcanoes as well','1eb0f0a95bfc8d3cda82a1dac95a7323ab1d84d1a545d0f2f5338947cd9082eb','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('83aa0b1e4479b9c2a4c1a64d7c1e11351321b25b09275a08518a518a968e2165',2025,'VN','Viet Nam','geography',1697,'Location: Caribbean, islands between the Carib-
bean Sea and the North Atlantic Ocean, east of','3d7a4606bd8d210f3038b4e004d34127361cdee9a27d494df74849b2edc07b01','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5b7761746441331bf7d1dbc5bdff4f01da105bde649089fd52dc1f4fa6dd7c3c',2025,'WF','Wallis and Futuna','geography',1705,'Location: Oceania, islands in the South Pacific
Ocean, about two-thirds of the way from Hawaii
to New Zealand
798
Geographic coordinates: 13 18 S, 176 12 W
Map references: Oceania
Area: total: 142 sq km
country comparison to the world: 221
land: 142 sq km
water: 0 sq km
note: includes lle Uvea (Wallis Island), Ile Futuna
{Futuna Island), tle Alofi, and 20 islets
Area—comparative: 1.5 times the size of Wash-
ington, DC
Land boundaries: 0 km
Coastline: 129 km
Maritime claims: territorial sea: 12 nm
exclusive economic zone: 200 nm
Climate: tropical; hot, rainy season (November to
April); cool, dry season (May to October); rains
2,5003,000 mm per year (80% humidity); average
temperature 26.6 degrees C
Terrain: volcanic origin; low hills
Elevation extremes: lowest point: Pacific Ocean
Om
highest point: Mont Singavi (on Futuna) 765 m
Natural resources: NEGL
Land use: arable land: 7.14%
permanent crops: 35.71%
other: 57.15% (2011)
Irrigated land: NA
Natural hazards: NA
Environment—current issues:. deforestation
(only small portions of the original forests remain)
largely as a result of the continued use of wood
as the main fuel source; as a consequence of cut-
ting down the forests, the mountainous terrain of
Futuna is particularly prone to erosion; there are
no permanent settlements on Alofi because of the
lack of natural freshwater resources
Ne Futuna
¿Sigave (Laava)
“he Alofi
Geography—note: both island groups have fring-
ing reefs <“ Å','109faa892cd3bae3ded41c59dce1d35aa96d858ac1efba169d94f5b1db10285b','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6be49ea31606150728e4b51efcb880422d07917800a6395f304c914c553570a5',2025,'EH','Western Sahara','geography',1711,'Location: Northern Africa, bordering the North
Atlantic Ocean, between Mauritania and Morocco
Geographic coordinates: 24 30 N, 13 00 W
Map references: Africa
Area: total: 266,000 sq km
country comparison to the world: 78
land: 266,000 sq km
water: 0 sq km
Area—comparative: about the size of Colorado
Land boundaries: total: 2,046 km
border countries: Algeria 42 km, Mauritania
1,561 km, Morocco 443 km
Coastline: 1,110 km
Maritime claims: contingent upon resolution of
sovereignty issue
Climate: hot, dry desert; rain is rare; cold offshore
air currents produce fog and heavy dew
Terrain: mostly low, flat desert with large areas of
rocky or sandy surfaces rising to small mountains
in south and northeast : _, *
Elevation extremes: lowest point: Sebjet Tah-
55m
highest point: unnamed elevation 805 m
Natural resources: phosphates, iron ore
Land use: arable land: 0.02%
permanent crops: 0%
other: 99.98% (2011)
Irrigated land: NA
Natural hazards: hot, dry, dust/sand-laden sirocco
wind can occur during winter and spring; wide-
spread harmattan haze exists 60% of time, often
severely restricting visibility
Environment—current issues: sparse water and
lack of arable land
Environment—international agreements:
party to: none of the selected agreements
Geography—note: the waters off the coast are par-
ticularly rich fishing areas
Geographic overview: The surface of the earth is
approximately 70.9% water and 29.1% land. The
former portion is divided into large water bodies
termed oceans. The World Factbook recognizes
and describes five oceans, which are in decreasing
order of size: the Pacific Ocean, Atlantic Ocean,
Indian Ocean, Southern Ocean, and Arctic Ocean.
The land portion is generally divided into sev-
eral, large, discrete landmasses termed continents.
Depending on the convention used, the number of
continents can vary from five to seven. The most
common classification recognizes seven, which
are (from largest to smallest): Asia, Africa, North
America, South America, Antarctica, Europe, and
Australia. Asia and Europe are sometimes lumped
together into a Eurasian continent resulting in
six continents. Alternatively, North and South
America are sometimes grouped as simply the
Americas, resulting in a continent total of six (or
five, if the Eurasia designation is used).
North America is commonly understood to include
the island of Greenland, the isles of the Caribbean,
and to extend south all the way to the Isthmus of
Panama. The easternmost extent of Europe is gen-
erally defined as being the Ural Mountains and the
_Ural River; on the southeast the Caspian Sea; and
on the south the Caucasus Mountains, the Black
Sea, and the Mediterranean. Portions of Azerbai-
jan, Georgia, Kazakhstan, Russia, and Turkey fall
within both Europe and Asia, but in every instance
_ the larger section is in Asia. These countries are
- considered part of both continents. Armenia and
Cyprus, which lie completely in Western Asia, are
geopolitically European countries.
Asia usually incorporates all the islands of the Phil-
ippines, Malaysia, and Indonesia. The islands of the
Pacific are often lumped with Australia into a “land
mass” termed Oceania or Australasia. Africa’s north-
east extremity is frequently delimited at the Isthmus
of Suez, but for geopolitical purposes, the Egyptian
Sinai Peninsula is often included as part of Africa.
a
Although the above groupings are the most com-
mon, different continental dispositions are rec-
ognized or taught in certain parts of the world,
with some arrangenients more heavily based on
cultural spheres rather than physical geographic
* considerations.
Map references: Political Map of the World,
Physical Map of the World, Standard Time Zones
of the World, World Oceans
Area: total: 510.072 million sq km
land: 148.94 million sq km
water: 361.132 million sq km
note: 70.9% of the world’s surface is water, 29.1%
is land
Area—comparative: land area about 16 times the
size of the US
top fifteen World Factbook entities ranked by
size: Pacific Ocean 155.557 million sq km; Atlan-
tic Ocean 76.762 million sq km; Indian Ocean
68.556 million sq km; Southern Ocean 20.327
million sq km; Russia 17,098,242 sq km; Arctic
Ocean 14.056 million sq km; Antarctica 14 mil-
lion sq km; Canada 9,984,670 sq km; United
States 9,826,675 sq km; China 9,596,961 sq km;
Brazil 8,514,877 sq km; Australia 7,741,220 sq km;
. European Union 4,324,782 sq km; India 3,287,263
sq km; Argentina 2,780,400 sq km
top ten largest water bodies: Pacific Ocean
155.557 million sq km; Atlantic Ocean 76.762
million sq km; Indian Ocean 68.556 million
sq km; Southern Ocean 20.327 million sq km;
Arctic Ocean 14.056 million sq km; Coral Sea
4,184,100 sq km; South China Sea 3,595,900 sq
km; Caribbean Sea 2.834 million sq km; Bering
Sea 2.52 million sq km; Mediterranean Sea 2.469
million sq km
top ten largest landmasses: Asia 44,568,500 sq
km; Africa 30.065 million sq km; North America
24.473 million sq km; South America 17.819 mil-
lion sq km; Antarctica 14 million sq km; Europe
9.948 million sq km; Australia 7,741,220 sq km;
Greenland 2,166,086 sq km; New Guinea 785,753
sq km; Borneo 751,929 sq km
top ten largest islands: Greenland 2,166,086 sq
km; New Guinea (Indonesia, Papua New Guinea)
785,753 sq km; Borneo (Brunei, Indonesia, Malay-
sia) 751,929 sq km; Madagascar 587,713 sq km;
Baffin Island (Canada) 507,451 sq km; Suma-
tra (Indonesia) 472,784 sq km; Honshu (Japan)
227,963 sq km; Victoria Island (Canada) 217,291
sq km; Great Britain (United Kingdom) 209,331
sq km; Ellesmere Island (Canada) 196,236 sq km
Land boundaries: the land boundaries in the
world total 251,060 km (not counting ‘shared
boundaries twice); two nations, China and Russia,
each border 14 other countries
note: 46 nations and other areas are landlocked,
these. include: Afghanistan, Andorra, Armenia,
Austria, Azerbaijan, Belarus, Bhutan, Bolivia,
Botswana, Burkina Faso, Burundi, Central Afri-
can Republic, Chad, Czech Republic, Ethiopia,
Holy See (Vatican City), Hungary, Kazakhstan,
Kosovo, Kyrgyzstan, Laos, Lesotho, Liechtenstein,
Luxembourg, Macedonia, Malawi, Mali, Moldova,
Mongolia, Nepal, Niger, Paraguay, Rwanda, San
Marino, Serbia, Slovakia, South Sudan, Swa-
ziland, Switzerland, Tajikistan, Turkmenistan,
Uganda, Uzbekistan, West Bank, Zambia, Zimba-
bwe; two of these, Liechtenstein and Uzbekistan,
are doubly landlocked
Coastline: 356,000 km
note: 95 nations and other entities are islands that
border no other countries, they include: American
Samoa, Anguilla, Antigua and Barbuda, Aruba,
Ashmore and Cartier Islands, The Bahamas,
Bahrain, Baker Island, Barbados, Bermuda, Bou-
vet Island, British Indian Ocean Territory, Brit-
ish Virgin Islands, Cape Verde, Cayman Islands,
Christmas Istand, Clipperton Island, Cocos (Keel-
ing) Islands, Comoros, Cook Islands, Coral Sea
Islands, Cuba, Curacao, Cyprus, Dominica, Falk-
land Islands (Islas Malvinas), Faroe Islands, Fiji,
French Polynesia, French Southern and Antarctic
Lands, Greenland, Grenada, Guam, Guernsey,
Heard Island and McDonald Islands, Howland `
Island, Iceland, Isle of Man, Jamaica, Jan Mayen,
805
Japan, Jarvis Island, Jersey, Johnston Atoll, King-
man Reef, Kiribati, Madagascar, Maldives, Malta,
Marshall Islands, Mauritius, Mayotte, Federated
States of Micronesia, Midway Islands, Montser-
rat, Nauru, Navassa Island, New Caledonia, New
Zealand, Niue, Norfolk Island, Northern Mariana
Islands, Palau, Palmyra Atoll, Paracel Islands,
Philippines, Pitcairn Islands, Puerto Rico, Saint
Barthelemy, Saint Helena, Saint Kitts and Nevis,
Saint Lucia, Saint Pierre and Miquelon, Saint Vin-
cent and the Grenadines, Samoa, Sao Tome and
Principe, Seychelles, Singapore, Sint Maarten,
Solomon Islands, South Georgia and the South
Sandwich Islands, Spratly Islands, Sri Lanka,
Svalbard, Tokelau, Tonga, Trinidad and Tobago,
Turks and Caicos Islands, Tuvalu, Vanuatu, Virgin
Islands, Wake Island, Wallis and Futuna, Taiwan
Maritime claims: a variety of situations exist,
but in general, most countries make the following
claims measured from the mean low-tide baseline
as described in the 1982 UN Convention on the
Law of the Sea: territorial sea—12 nm, contiguous
zone—24 nm, and exclusive economic zone—200
nm; additional zones provide for exploitation of
continental shelf resources and an exclusive fish-
ing zone; boundary situations with neighboring
states prevent many countries from extending
their fishing or economic zones to a full 200 nm
Climate: a wide equatorial band of hot and humid
tropical climates—bordered north and south by
subtropical temperate zones—that separate two
large areas of cold and dry polar climates
Terrain: the greatest ocean depth is the Mariana
Trench at 10,924 m in the Pacific Ocean
Elevation extremes: lowest point: Bentley Sub-
glacial Trench (Antarctica) -2,555 m
note: in the oceanic realm, Challenger Deep in the
Mariana Trench is the lowest point, lying -10,924
m below the surface of the Pacific Ocean
highest point: Mount Everest 8,850 m
top ten highest mountains (measured from sea
level): Mount Everest (China-Nepal) 8,850 m;
K2 (Pakistan) 8,611 m; Kanchenjunga (India-
Nepaf) 8,598 m; Lhotse (Nepal) 8,516 m; Makalu
(China-Nepal) 8,463 m; Cho Oyu (China-Nepal)
8,201 m; Dhaulagiri (Nepal) 8,167 m; Manaslu
(Nepal) 8,163 m; Nanga Parbat (Pakistan) 8,125
m; Anapurna (Nepal) 8,091 m
Natural resources: the rapid depletion of nonre-
newable mineral resources, the depletion of forest
areas and wetlands, the extinction of animal and
plant species, and the deterioration in air and
watet quality (especially in some countries of East-
ern Europe, the former USSR, and China) pose
serious long-term problems that governments and
peoples are only beginning to address
Lond use: arable land: 10.43%
permanent crops: 1.15%
other: 88.42% (2011)
Irrigated tand: 3,096,621.45 sq km (2011 est.)
Total renewable water resources: 53,789.29 cu
km (2011)
Natural hazards: large areas subject to severe
weather (tropical cyclones); natural disasters (earth-
quakes, landslides, tsunamis, volcanic eruptions)
volcanism: volcanism is a fundamental driver and
consequence of plate tectonics, the physical pro-
cess reshaping the Earth’s lithosphere; the world is
home to more than 1,500 potentially active volca-
noes, with over 500 of these having erupted in his-
torical times; an estimated 500 million people live
806
THE CIA WORLD FACTBOOK
near these volcanoes; associated dangers include
lava flows, lahars (mudflows), pyroclastic flows,
ash clouds, ash fall, ballistic projectiles, gas emis-
sions, landslides, earthquakes, and tsunamis; in the
1990s, the International Association of Volcanol-
ogy and Chemistry of the Earth’s Interior, created a
list of 16 volcanoes worthy of special study because
of their great potential for destruction: Avachin-
sky-Koryaksky (Russia), Colima (Mexico), Ema
(Italy), Galeras (Colombia), Mauna Loa (United
States), Merapi (Indonesia), Nyiragongo (Demo-
cratic Republic of the Congo), Rainier (United
States), Sakurajima (Japan), Santa Maria (Gua-
temala), Santorini (Greece), Taal (Philippines),
Teide (Spain), Ulawun (Papua New Guinea),
Unzen (Japan), Vesuvius (Italy)
Environment—current issues: large areas sub-
ject to overpopulation, industrial disasters, pollu-
tion (air, water, acid rain, toxic substances), loss of
vegetation (overgrazing, deforestation, desertifica-
tion), loss of wildlife, soil degradation, soil deple-
tion, erosion; global warming becoming a greater
concern
Geography—note: the world is now thought to ''
be about 4.55 billion years old, just about one-
third of the 13.8-billion-year age estimated for the
universe
Location: Middle East, bordering the Arabian Sea,
Gulf of Aden, and Red Sea, between Oman and','ad78783fc92334abf684aa45d7a63e251e8b9742c7d4ff9c5321688ffd56412b','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e2a2da5ce468b3805d648ee2a37fb3e8b5f012667ff519e98c794aa01eeeb064',2025,'YE','Yemen','geography',1725,'Location: Southérn Africa, east of Angola, south
of the Democratic Republic of the Congo
Geographic coordinates: 15 00 S, 30 00 E
Map references: Africa
Area: total: 752,618 sq km
country comparison to the world: 39
land: 743,398 sq km
water: 9,220 sq km
Area—comparative: slightly larger than Texas
Land boundaries: total: 5,664 km
border countries: Angola 1,110 km, Democratic
Republic of the Congo 1,930 km, Malawi 837 km,
Mozambique 419 km, Namibia 233 km, Tanzania
338 km, Zimbabwe 797 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
Climate: Tropical, modified by altitude, rainy sea-
son (October to April)
Terrain: mostly high plateau with some hills and
mountains
Elevation extremes: lowest point: Zambezi river
329 m
814','71390933ca2be15fc8469ef4cda69b77e89781434a822c252434f1db6ea7cc18','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('97dd85aa25ba1778145c044922d50385c2fd845d80a5b1a2c1b1e6d47f86f35e',2025,'ZW','Zimbabwe','geography',1729,'Location: Southern Africa, between South Africa
and Zambia
Geographic coordinates: 2000 S, 3000 E
Map references: Africa
Area: total: 390,757 sq km
country comparison to the world: 61
land: 386,847 sq km
water: 3,910 sq km
Area—comparative:
Montana
Land boundaries; total: 3,066 km
border countries: Botswana 813 km, Mozam-
bique 1,231 km, South Africa 225 km, Zambia
797 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
Climate: tropical; moderated by altitude; rainy
season (November to March)
slightly larger than
Terrain: mostly high plateau with higher central
plateau (high veld); mountains in east
Elevation extremes: lowest point: junction of
the Runde and Save Rivers 162 m
highest point: Inyangani 2,592 m
Natural resources: coal, chromium ore, asbestos,
gold, nickel, copper, iron ore, vanadium, lithium,
tin, platinum group metals
Land use: arable land: 10.49%
permanent crops: 0.31%
other: 89.2% (2011)
Irrigated land: 1,735 sq km (2003)
Total renewable water resources: 20 cu km
(2011)
Freshwater withdrawal (domestic/industrial/
agricultural): total:4.21 cu km/yr (14%/7%/79%)
per capita: 333.5 cu m/yr (2002)
817
Natural hazards: recurring droughts; floods and
severe storms are rare
Environment—current issues: deforestation; soil
erosion; land degradation; air and water pollution;
the black rhinoceros herd—once the largest con-
centration of the species in the world—has been
significantly reduced by poaching; poor mining
practices have led to toxic waste and heavy metal
pollution
Environment—international agreements:
party to: Biodiversity, Climate Change, Deser-
tification, Endangered Species, Law of the Sea,
Ozone Layer Protection
signed, but not ratified: none of the selected
agreements
Geography—note: landlocked; the Zambezi
forms a natural riverine boundary with Zambia;
in full flood (February-April) the massive Victoria
Falls on the river forms the world’s largest curtain
of falling water; Lake Kariba on the Zambia-Zim-
babwe border forms the world’s largest reservoir by
volume (180 cu km; 43 cu mi)','4c7ec738e500e49676a011f4fd4b10da4c5bc9dceeb69ebcdd56367534759d11','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);

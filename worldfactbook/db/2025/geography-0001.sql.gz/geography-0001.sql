SET NAMES utf8mb4;
CREATE TABLE IF NOT EXISTS worldfactbook_chunks (
  chunk_id CHAR(64) NOT NULL,
  edition_year SMALLINT UNSIGNED NOT NULL,
  entity_code VARCHAR(24) NOT NULL DEFAULT '',
  entity_name VARCHAR(160) NOT NULL DEFAULT '',
  category VARCHAR(96) NOT NULL,
  ordinal INT UNSIGNED NOT NULL,
  content MEDIUMTEXT NOT NULL,
  content_sha256 CHAR(64) NOT NULL,
  source_provider VARCHAR(64) NOT NULL,
  source_identifier VARCHAR(255) NOT NULL,
  source_format VARCHAR(32) NOT NULL,
  source_sha256 CHAR(64) NOT NULL,
  source_url TEXT NOT NULL,
  extractor VARCHAR(64) NOT NULL,
  PRIMARY KEY (chunk_id),
  KEY idx_wfb_year_category (edition_year, category),
  KEY idx_wfb_entity_year (entity_code, edition_year),
  KEY idx_wfb_source_sha (source_sha256)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b5e0bcbcfb2187b4d49659065e4ae4d912d32b9016027a3785a49d9d5fdb61ce',2025,'AF','Afghanistan','geography',2,'Location:
Southern Asia, north and west of Pakistan, east of Iran
Geographic coordinates:
33 00 N, 65 00 E
Map references:
Asia
Area:
total:
652,230 sq km
land:
652,230 sq km
water:
0 sq km
comparison ranking:
total 43
Area - comparative:
almost six times the size of Virginia; slightly smaller than Texas
Land boundaries:
total:
5,987 km
border countries (6):
China 91 km; Iran 921 km; Pakistan 2,670 km; Tajikistan 1,357 km; Turkmenistan 804 km; Uzbekistan 144 km
Coastline:
0 km (landlocked)
Maritime claims:
none (landlocked)
Climate:
arid to semiarid; cold winters and hot summers
Terrain:
mostly rugged mountains; plains in north and southwest
Elevation:
highest point:
Noshak 7,492 m
lowest point:
Amu Darya 258 m
mean elevation:
1,884 m
Natural resources:
natural gas, petroleum, coal, copper, chromite, talc, barites, sulfur, lead, zinc, iron ore, salt, precious and semiprecious stones, arable land
Land use:
agricultural land:
58.1% (2018 est.)
arable land:
11.8% (2018)
permanent crops:
0.3% (2018)
permanent pasture:
46% (2018)
forest:
1.8% (2018 est.)
other:
40.1% (2018)
Irrigated land:
24,930 sq km (2020)
Major lakes (area sq km):
salt water lake(s):
Ab-e Istadah-ye Muqur (endorheic basin) - 520 sq km
Major rivers (by length in km):
Amu Darya (shared with Tajikistan [s], Turkmenistan, and Uzbekistan [m]) - 2,620 km; Helmand river source (shared with Iran) - 1,130 km
note
– [s] after country name indicates river source; [m] after country name indicates river mouth
Major watersheds (area sq km):
Indian Ocean drainage:
Indus (1,081,718 sq km)
Internal
(endorheic basin)
drainage:
Amu Darya (534,739 sq km); Tarim Basin (1,152,448 sq km)
Population distribution:
populations tend to cluster in the foothills and periphery of the rugged Hindu Kush range; smaller groups are found in many of the country’s interior valleys; in general, the east is more densely settled, while the south is sparsely populated
Natural hazards:
damaging earthquakes occur in Hindu Kush mountains; flooding; droughts
Geography - note:
landlocked; the Hindu Kush mountains that run northeast to southwest divide the northern provinces from the rest of the country; the highest peaks are in the northern Vakhan (Wakhan Corridor)','d7c02018ceec5cf83f1aa6d4d332afb84d0c00a9260949e82b9f5d350eb28112','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c0d9e8290df7aae659b436d3e94c9f7531c4251384a33808d76e407a811d21cc',2025,'AF','Afghanistan','geography',14,'Location:
Eastern Mediterranean, peninsula on the southwest coast of Cyprus
Geographic coordinates:
34 37 N, 32 58 E
Map references:
Middle East
Area:
total:
123 sq km
note:
includes a salt lake and wetlands
comparison ranking:
total 223
Area - comparative:
about 0.7 times the size of Washington, DC
Land boundaries:
total:
48 km
border countries (1):
Cyprus 48 km
Coastline:
56.3 km
Climate:
temperate; Mediterranean with hot, dry summers and cool winters
Geography - note:
British extraterritorial rights also extended to several small off-post sites scattered across Cyprus; of the Sovereign Base Area (SBA) land, 60% is privately owned and farmed, 20% is owned by the Ministry of Defense, and 20% is SBA Crown land','cf617882508953385dbcf2c29105115df3c1113ec9fad500dc40fecc39da76f8','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c22a600716d86ef983d7548286872e287f27a15e5b8088602cc80dc2596eab4b',2025,'AL','Albania','geography',23,'Location:
Southeastern Europe, bordering the Adriatic Sea and Ionian Sea, between Greece to the south and Montenegro and Kosovo to the north
Geographic coordinates:
41 00 N, 20 00 E
Map references:
Europe
Area:
total:
28,748 sq km
land:
27,398 sq km
water:
1,350 sq km
comparison ranking:
total 144
Area - comparative:
slightly smaller than Maryland
Land boundaries:
total:
691 km
border countries (4):
Greece 212 km; Kosovo 112 km; Macedonia 181 km; Montenegro 186 km
Coastline:
362 km
Maritime claims:
territorial sea:
12 nm
continental shelf:
200-m depth or to the depth of exploitation
Climate:
mild temperate; cool, cloudy, wet winters; hot, clear, dry summers; interior is cooler and wetter
Terrain:
mostly mountains and hills; small plains along coast
Elevation:
highest point:
Maja e Korabit (Golem Korab) 2,764 m
lowest point:
Adriatic Sea 0 m
mean elevation:
708 m
Natural resources:
petroleum, natural gas, coal, bauxite, chromite, copper, iron ore, nickel, salt, timber, hydropower, arable land
Land use:
agricultural land:
42.8% (2018 est.)
arable land:
22.3% (2018 est.)
permanent crops:
3% (2018 est.)
permanent pasture:
17.4% (2018 est.)
forest:
28.8% (2018 est.)
other:
28.2% (2018 est.)
Irrigated land:
1,820 sq km (2020)
Major lakes (area sq km):
fresh water lake(s):
Lake Scutari (shared with Montenegro) - 400 sq km note - largest lake in the Balkans
Major watersheds (area sq km):
Atlantic Ocean drainage:
(Black Sea)
Danube (795,656 sq km)
Population distribution:
a fairly even distribution, with somewhat higher concentrations of people in the western and central parts of the country
Natural hazards:
destructive earthquakes; tsunamis occur along southwestern coast; floods; drought
Geography - note:
strategic location along Strait of Otranto (links Adriatic Sea to Ionian Sea and Mediterranean Sea)','6c7213aa65554d1b71c8cc123b120fec3b2a68fe55e16d3bbcff37e39a3afbb0','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('46621f6a361a9b2619ab67579cc256a41fa4b077fb57f96d3856ff5ac8d05560',2025,'DZ','Algeria','geography',35,'Location:
Northern Africa, bordering the Mediterranean Sea, between Morocco and Tunisia
Geographic coordinates:
28 00 N, 3 00 E
Map references:
Africa
Area:
total:
2,381,740 sq km
land:
2,381,740 sq km
water:
0 sq km
comparison ranking:
total 11
Area - comparative:
slightly less than 3.5 times the size of Texas
Land boundaries:
total:
6,734 km
border countries (6):
Libya 989 km; Mali 1,359 km; Mauritania 460 km; Morocco 1,941 km; Niger 951 km; Tunisia 1,034 km
Coastline:
998 km
Maritime claims:
territorial sea:
12 nm
contiguous zone:
24 nm
exclusive fishing zone:
32-52 nm
Climate:
arid to semiarid; mild, wet winters with hot, dry summers along coast; drier with cold winters and hot summers on high plateau; sirocco is a hot, dust/sand-laden wind especially common in summer
Terrain:
mostly high plateau and desert; Atlas Mountains in the far north and Hoggar Mountains in the south; narrow, discontinuous coastal plain
Elevation:
highest point:
Tahat 2,908 m
lowest point:
Chott Melrhir -40 m
mean elevation:
800 m
Natural resources:
petroleum, natural gas, iron ore, phosphates, uranium, lead, zinc
Land use:
agricultural land:
17.4% (2018 est.)
arable land:
3.2% (2018 est.)
permanent crops:
0.4% (2018 est.)
permanent pasture:
13.8% (2018 est.)
forest:
0.8% (2018 est.)
other:
81.8% (2018 est.)
Irrigated land:
12,605 sq km (2016)
Major watersheds (area sq km):
Atlantic Ocean drainage:
Niger (2,261,741 sq km)
Internal
(endorheic basin)
drainage:
Lake Chad (2,497,738 sq km)
Major aquifers:
Lullemeden-Irhazer Aquifer System, Murzuk-Djado Basin, North Western Sahara Aquifer, Taoudeni-Tanezrouft Basin
Population distribution:
the vast majority of the populace is found in the extreme northern part of the country along the Mediterranean Coast as shown in this population distribution map
Natural hazards:
mountainous areas subject to severe earthquakes; mudslides and floods in rainy season; droughts
Geography - note:
largest country in Africa but 80% desert; canyons and caves in the southern Hoggar Mountains and in the barren Tassili n’Ajjer area in the southeast of the country contain numerous examples of prehistoric art - rock paintings and carvings depicting human activities and wild and domestic animals (elephants, giraffes, cattle) - that date to the African Humid Period, roughly 11,000 to 5,000 years ago, when the region was completely vegetated','f1c6b96d71d3ff873f501c69482f7cd59c75d8924fa66704aed5047d7a19e925','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b8e555326606ccd29e7dacdd6d4bd29cf6356bc7d33738006b86e2a9a3dbde75',2025,'AS','American Samoa','geography',48,'Location:
Oceania, group of islands in the South Pacific Ocean, about halfway between Hawaii and New Zealand
Geographic coordinates:
14 20 S, 170 00 W
Map references:
Oceania
Area:
total:
224 sq km
land:
224 sq km
water:
0 sq km
note:
includes Rose Atoll and Swains Island
comparison ranking:
total 215
Area - comparative:
slightly larger than Washington, DC
Land boundaries:
total:
0 km
Coastline:
116 km
Maritime claims:
territorial sea:
12 nm
exclusive economic zone:
200 nm
Climate:
tropical marine, moderated by southeast trade winds; annual rainfall averages about 3 m; rainy season (November to April), dry season (May to October); little seasonal temperature variation
Terrain:
five volcanic islands with rugged peaks and limited coastal plains, two coral atolls (Rose Atoll, Swains Island)
Elevation:
highest point:
Lata Mountain 964 m
lowest point:
Pacific Ocean 0 m
Natural resources:
pumice, pumicite
Land use:
agricultural land:
24.5% (2018 est.)
arable land:
15% (2018 est.)
permanent crops:
9.5% (2018 est.)
permanent pasture:
0% (2018 est.)
forest:
75.5% (2018 est.)
other:
0% (2018 est.)
Irrigated land:
0 sq km (2022)
Natural hazards:
cyclones common from December to March
volcanism:
limited volcanic activity on the Ofu and Olosega Islands; neither has erupted since the 19th century
Geography - note:
Pago Pago has one of the best natural deepwater harbors in the South Pacific Ocean, sheltered by shape from rough seas and protected by peripheral mountains from high winds; strategic location in the South Pacific Ocean','7e0ae35a2f45f99b688d534018a6f9a83ab21d1345fb6ee2f28b2d47375f18c3','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('54124c6f599f3608a2caf00ec274b5974ef905e22554fa5b2fbec9f673b21915',2025,'AD','Andorra','geography',59,'Location:
Southwestern Europe, Pyrenees mountains, on the border between France and Spain
Geographic coordinates:
42 30 N, 1 30 E
Map references:
Europe
Area:
total:
468 sq km
land:
468 sq km
water:
0 sq km
comparison ranking:
total 195
Area - comparative:
2.5 times the size of Washington, DC
Land boundaries:
total:
118 km
border countries (2):
France 55 km; Spain 63 km
Coastline:
0 km (landlocked)
Maritime claims:
none (landlocked)
Climate:
temperate; snowy, cold winters and warm, dry summers
Terrain:
rugged mountains dissected by narrow valleys
Elevation:
highest point:
Pic de Coma Pedrosa 2,946 m
lowest point:
Riu Runer 840 m
mean elevation:
1,996 m
Natural resources:
hydropower, mineral water, timber, iron ore, lead
Land use:
agricultural land:
40% (2018 est.)
arable land:
1.7% (2018 est.)
permanent crops:
0% (2018 est.)
permanent pasture:
38.3% (2018 est.)
forest:
34% (2018 est.)
other:
26% (2018 est.)
Irrigated land:
0 sq km (2022)
Population distribution:
population is unevenly distributed and is concentrated in the seven urbanized valleys that make up the country’s parishes (political administrative divisions)
Natural hazards:
avalanches
Geography - note:
landlocked; straddles a number of important crossroads in the Pyrenees','3bfc6ffa1335d9dacb33b3123cf93504aee2bd7cde54d3bb58163f49867e524e','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('743115f410f01abb63269c6bae46113c794fb87360d95d35cb553ee9317fb210',2025,'AO','Angola','geography',2,'Location:
Southern Africa, bordering the South Atlantic Ocean, between Namibia and Democratic Republic of the Congo
Geographic coordinates:
12 30 S, 18 30 E
Map references:
Africa
Area:
total:
1,246,700 sq km
land:
1,246,700 sq km
water:
0 sq km
comparison ranking:
total 24
Area - comparative:
about eight times the size of Georgia; slightly less than twice the size of Texas
Land boundaries:
total:
5,369 km
border countries (4):
Democratic Republic of the Congo 2,646 km (of which 225 km is the boundary of discontiguous Cabinda Province); Republic of the Congo 231 km; Namibia 1,427 km; Zambia 1,065 km
Coastline:
1,600 km
Maritime claims:
territorial sea:
12 nm
contiguous zone:
24 nm
exclusive economic zone:
200 nm
Climate:
semiarid in south and along coast to Luanda; north has cool, dry season (May to October) and hot, rainy season (November to April)
Terrain:
narrow coastal plain rises abruptly to vast interior plateau
Elevation:
highest point:
Moca 2,620 m
lowest point:
Atlantic Ocean 0 m
mean elevation:
1,112 m
Natural resources:
petroleum, diamonds, iron ore, phosphates, copper, feldspar, gold, bauxite, uranium
Land use:
agricultural land:
45.7% (2018 est.)
arable land:
3.9% (2018 est.)
permanent crops:
0.3% (2018 est.)
permanent pasture:
41.5% (2018 est.)
forest:
54.3% (2018 est.)
Irrigated land:
860 sq km (2014)
Major rivers (by length in km):
Rio Zambeze (Zambezi) (shared with Zambia [s], Namibia, Botswana, Zimbabwe, and Mozambique [m]) - 2,740 km; Rio Cubango (Okavango) river source (shared with Namibia and Botswana [m]) - 1,600 km
note
– [s] after country name indicates river source; [m] after country name indicates river mouth
Major watersheds (area sq km):
Atlantic Ocean drainage:
Congo (3,730,881 sq km)
Indian Ocean drainage:
Zambezi (1,332,412 sq km)
Internal (endorheic basin) drainage:
Okavango Basin (863,866 sq km)
Major aquifers:
Congo Basin, Upper Kalahari-Cuvelai-Upper Zambezi Basin
Population distribution:
most people live in the western half of the country; urban areas account for the highest concentrations of people, particularly the capital of Luanda as shown in this population distribution map
Natural hazards:
locally heavy rainfall causes periodic flooding on the plateau
Geography - note:
the province of Cabinda is an exclave, separated from the rest of the country by the Democratic Republic of the Congo','a0f001ab83d4941c30c4766db969127b760cdaf1a44c7f4594d9574fcd8a1cab','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2525fffa081abe385cdfd86575fbf07f922264d5e7655871cf205e70078c38ec',2025,'AI','Anguilla','geography',14,'Location:
Caribbean, islands between the Caribbean Sea and North Atlantic Ocean, east of Puerto Rico
Geographic coordinates:
18 15 N, 63 10 W
Map references:
Central America and the Caribbean
Area:
total:
91 sq km
land:
91 sq km
water:
0 sq km
comparison ranking:
total 226
Area - comparative:
about one-half the size of Washington, DC
Land boundaries:
total:
0 km
Coastline:
61 km
Maritime claims:
territorial sea:
12 nm
exclusive economic zone:
200 nm
exclusive fishing zone:
200 nm
Climate:
tropical; moderated by northeast trade winds
Terrain:
flat and low-lying island of coral and limestone
Elevation:
highest point:
Crocus Hill 73 m
lowest point:
Caribbean Sea 0 m
Natural resources:
salt, fish, lobster
Land use:
agricultural land:
0% (2018 est.)
arable land:
0% (2018 est.)
permanent crops:
0% (2018 est.)
permanent pasture:
0% (2018 est.)
forest:
61.1% (2018 est.)
other:
38.9% (2018 est.)
Irrigated land:
0 sq km (2020)
Population distribution:
most of the population is concentrated in The Valley in the center of the island; settlmement is fairly uniform in the southwest, but rather sparce in the northeast
Natural hazards:
frequent hurricanes and other tropical storms (July to October)
Geography - note:
the most northerly of the Leeward Islands in the Lesser Antilles','63d564767f550644eb4c996f2b61462e84a32b6e95b12498a227560fc4fdf6eb','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3d885f2cc42161a59ebc033c1f33c9c2fde9969efab6297b294afadecf191c8a',2025,'AQ','Antarctica','geography',25,'Location:
continent mostly south of the Antarctic Circle
Geographic coordinates:
90 00 S, 0 00 E
Map references:
Antarctic Region
Area:
total:
14.2 million sq km
land:
14.2 million sq km (285,000 sq km ice-free, 13.915 million sq km ice-covered) (est.)
note:
fifth-largest continent, following Asia, Africa, North America, and South America, but larger than Australia and the subcontinent of Europe
comparison ranking:
total 2
Area - comparative:
slightly less than 1.5 times the size of the US
Land boundaries:
0 note:
see entry on Disputes - international
Coastline:
17,968 km
Maritime claims:
Australia, Chile, and Argentina claim Exclusive Economic Zone (EEZ) rights or similar over 200 nm extensions seaward from their continental claims, but like the claims themselves, these zones are not accepted by other countries; 22 of 29 Antarctic Treaty consultative parties have made no claims to Antarctic territory, although Russia and the United States have reserved the right to do so, and no country can make a new claim; also see the Disputes - international entry
Climate:
the coldest, windiest, and driest continent on Earth; severe low temperatures vary with latitude, elevation, and distance from the ocean; East Antarctica is colder than West Antarctica because of its higher elevation; Antarctic Peninsula has the most moderate climate; higher temperatures occur in January along the coast and average slightly below freezing; summers characterized by continuous daylight, while winters bring continuous darkness; persistent high pressure over the interior brings dry, subsiding air that results in very little cloud cover
Terrain:
about 99% thick continental ice sheet and 1% barren rock, with average elevations between 2,000 and 4,000 m; mountain ranges up to nearly 5,000 m; ice-free coastal areas include parts of southern Victoria Land, Wilkes Land, the Antarctic Peninsula area, and parts of Ross Island on McMurdo Sound; glaciers form ice shelves along about half of the coastline, and floating ice shelves constitute 11% of the area of the continent
Elevation:
highest point:
Vinson Massif 4,892 m
lowest point:
Denman Glacier more than -3,500 m (-11,500 ft) below sea level
mean elevation:
2,300 m
note:
the lowest known land point in Antarctica is hidden in the Denman Glacier; at its surface is the deepest ice yet discovered and the world’s lowest elevation not under seawater
Natural resources:
iron ore, chromium, copper, gold, nickel, platinum and other minerals, and coal and hydrocarbons have been found in small noncommercial quantities; mineral exploitation except for scientific research is banned by the Environmental Protocol to the Antarctic Treaty; krill, icefish, toothfish, and crab have been taken by commercial fisheries, which are managed through the Commission for the Conservation of Antarctic Living Marine Resources (CCAMLR)
Land use:
agricultural land:
0% (2018 est.)
Natural hazards:
katabatic (gravity-driven) winds blow coastward from the high interior; frequent blizzards form near the foot of the plateau; cyclonic storms form over the ocean and move clockwise along the coast; large icebergs may calve from ice shelf
volcanism:
volcanic activity on Deception Island and isolated areas of West Antarctica; other seismic activity rare and weak
Geography - note:
the coldest, windiest, highest (on average), and driest continent; during summer, more solar radiation reaches the surface at the South Pole than is received at the Equator in an equivalent period
mostly uninhabitable, 99% of the land area is covered by the Antarctic ice sheet, the largest single mass of ice on earth covering an area of 14 million sq km (5.4 million sq mi) and containing 26.5 million cu km (6.4 million cu mi) of ice (this is almost 62% of all of the world’s fresh water); if all this ice were converted to liquid water, one estimate is that it would be sufficient to raise the height of the world’s oceans by 58 m (190 ft)','7f5f3b23678fc230ad270eabb01fd7c842caa330f530c9f89ffd628178c035a5','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b373913038381e63b8bfd3ba37f904d0fa55c60727ecd2f8c01f5d7fb4280c2b',2025,'AG','Antigua and Barbuda','geography',35,'Location:
Caribbean, islands between the Caribbean Sea and the North Atlantic Ocean, east-southeast of Puerto Rico
Geographic coordinates:
17 03 N, 61 48 W
Map references:
Central America and the Caribbean
Area:
total:
443 sq km (Antigua 280 sq km; Barbuda 161 sq km)
land:
443 sq km
water:
0 sq km
note:
includes Redonda, 1.6 sq km
comparison ranking:
total 200
Area - comparative:
2.5 times the size of Washington, DC
Land boundaries:
total:
0 km
Coastline:
153 km
Maritime claims:
territorial sea:
12 nm
contiguous zone:
24 nm
exclusive economic zone:
200 nm
continental shelf:
200 nm or to the edge of the continental margin
Climate:
tropical maritime; little seasonal temperature variation
Terrain:
mostly low-lying limestone and coral islands, with some higher volcanic areas
Elevation:
highest point:
Mount Obama 402 m
lowest point:
Caribbean Sea 0 m
Natural resources:
NEGL; pleasant climate fosters tourism
Land use:
agricultural land:
20.5% (2018 est.)
arable land:
9% (2018 est.)
permanent crops:
2.3% (2018 est.)
permanent pasture:
9% (2018 est.)
forest:
18.8% (2018 est.)
other:
60.8% (2018 est.)
Irrigated land:
1.3 sq km (2012)
Population distribution:
the island of Antigua is home to approximately 97% of the population; nearly the entire population of Barbuda lives in Codrington
Natural hazards:
hurricanes and tropical storms (July to October); periodic droughts
Geography - note:
Antigua has a deeply indented shoreline with many natural harbors and beaches; Barbuda has a large western harbor','795240f75b04c3669b7cec6a687303c18f0dd29fbac74ea82c59c8cdd9dac20b','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('eedbfc03f4a2b139411403d30c8bfb78475695d1d1f9dddc82de7e77225c6b34',2025,'AG','Antigua and Barbuda','geography',46,'Location:
body of water between Europe, Asia, and North America, mostly north of the Arctic Circle
Geographic coordinates:
90 00 N, 0 00 E
Map references:
Arctic Region
Area:
total:
15.558 million sq km
note:
includes Barents Sea, Beaufort Sea, Chukchi Sea, East Siberian Sea, Greenland Sea, Kara Sea, Laptev Sea, Northwest Passage, Norwegian Sea, and other tributary water bodies
Area - comparative:
slightly less than 1.5 times the size of the US
Coastline:
45,389 km
Climate:
polar climate characterized by persistent cold and relatively narrow annual temperature range; winters characterized by continuous darkness, cold and stable weather conditions, and clear skies; summers characterized by continuous daylight, damp and foggy weather, and weak cyclones with rain or snow
Ocean volume:
ocean volume:
18.75 million cu km
percent of World Ocean total volume:
1.4%
Major ocean currents:
two major, slow-moving, wind-driven currents (drift streams) dominate: a clockwise drift pattern in the Beaufort Gyre in the western part of the Arctic Ocean and a nearly straight line Transpolar Drift Stream that moves eastward across the ocean from the New Siberian Islands (Russia) to the Fram Strait (between Greenland and Svalbard); sea ice that lies close to the center of the gyre can complete a 360 degree circle in about 2 years, while ice on the gyre periphery will complete the same circle in about 7-8 years; sea ice in the Transpolar Drift crosses the ocean in about 3 years
Elevation:
highest point:
sea level
lowest point:
Molloy Deep -5,577 m
mean depth:
-1,205 m
ocean zones:
Composed of water and in a fluid state, the oceans are delimited differently than the solid continents. Oceans are divided into three zones based on depth and light level. Although some sea creatures depend on light to live, others can do without it. Sunlight entering the water may travel about 1,000 m into the oceans under the right conditions, but there is rarely any significant light beyond 200 m.
The upper 200 m (656 ft) of oceans is called the euphotic, or “sunlight,” zone. This zone contains the vast majority of commercial fisheries and is home to many protected marine mammals and sea turtles. Only a small amount of light penetrates beyond this depth.
The zone between 200 m (656 ft) and 1,000 m (3,280 ft) is usually referred to as the “twilight” zone, but is officially the dysphotic zone. In this zone, the intensity of light rapidly dissipates as depth increases. Such a minuscule amount of light penetrates beyond a depth of 200 m that photosynthesis is no longer possible.
The aphotic, or “midnight,” zone exists in depths below 1,000 m (3,280 ft). Sunlight does not penetrate to these depths and the zone is bathed in darkness.
Distance Sunlight Travels in the Ocean:
Natural resources:
sand and gravel aggregates, placer deposits, polymetallic nodules, oil and gas fields, fish, marine mammals (seals and whales)
Natural hazards:
ice islands occasionally break away from northern Ellesmere Island; icebergs calved from glaciers in western Greenland and extreme northeastern Canada; permafrost in islands; virtually ice locked from October to June; ships subject to superstructure icing from October to May
Geography - note:
major chokepoint is the southern Chukchi Sea (northern access to the Pacific Ocean via the Bering Strait); strategic location between North America and Russia; shortest marine link between the extremes of eastern and western Russia; floating research stations operated by the US and Russia; maximum snow cover in March or April about 20 to 50 centimeters over the frozen ocean; snow cover lasts about 10 months','9b7864f35029da5b0e5189b6ddc02c36a736bb353bcfdce1a6c9dc6c2b7b2d73','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('98bf387212c86c07dbb63299d81ad302b5c10fa62f4778fd69fa0a83b43f552b',2025,'AR','Argentina','geography',52,'Location:
Southern South America, bordering the South Atlantic Ocean, between Chile and Uruguay
Geographic coordinates:
34 00 S, 64 00 W
Map references:
South America
Area:
total:
2,780,400 sq km
land:
2,736,690 sq km
water:
43,710 sq km
comparison ranking:
total 9
Area - comparative:
slightly less than three-tenths the size of the US
Land boundaries:
total:
11,968 km
border countries (5):
Bolivia 942 km; Brazil 1,263 km; Chile 6,691 km; Paraguay 2,531 km; Uruguay 541 km
Coastline:
4,989 km
Maritime claims:
territorial sea:
12 nm
contiguous zone:
24 nm
exclusive economic zone:
200 nm
continental shelf:
200 nm or to the edge of the continental margin
Climate:
mostly temperate; arid in southeast; subantarctic in southwest
Terrain:
rich plains of the Pampas in northern half, flat to rolling plateau of Patagonia in south, rugged Andes along western border
Elevation:
highest point:
Cerro Aconcagua (located in the northwestern corner of the province of Mendoza; highest point in South America) 6,962 m
lowest point:
Laguna del Carbón (located between Puerto San Julián and Comandante Luis Piedra Buena in the province of Santa Cruz) -105 m
mean elevation:
595 m
Natural resources:
fertile plains of the pampas, lead, zinc, tin, copper, iron ore, manganese, petroleum, uranium, arable land
Land use:
agricultural land:
53.9% (2018 est.)
arable land:
13.9% (2018 est.)
permanent crops:
0.4% (2018 est.)
permanent pasture:
39.6% (2018 est.)
forest:
10.7% (2018 est.)
other:
35.4% (2018 est.)
Irrigated land:
23,600 sq km (2012)
Major lakes (area sq km):
fresh water lake(s):
Lago Buenos Aires (shared with Chile) - 2,240 sq km; Lago Argentino - 1,410 sq km; Lago Viedma - 1,090 sq km; Lago San Martín (shared with Chile) - 1,010 sq km; Lago Colhué Huapi - 800 sq km; Lago Fagnano (shared with Chile) - 590 sq km; Lago Nahuel Huapi - 550 sq km
salt water lake(s):
Laguna Mar Chiquita - 1,850 sq km;
Major rivers (by length in km):
Río de la Plata/Paraná river mouth (shared with Brazil [s], Paraguay, and Uruguay) - 4,880 km; Paraguay (shared with Brazil [s], and Paraguay [m]) - 2,549 km; Uruguay (shared with Brazil [s] and Uruguay [m]) - 1,610 km
note – [s] after country name indicates river source; [m] after country name indicates river mouth
Major watersheds (area sq km): Atlantic Ocean drainage:
Paraná (2,582,704 sq km)
Major aquifers:
Guaraní Aquifer System
Population distribution:
one-third of the population lives in Buenos Aires; pockets of agglomeration occur throughout the northern and central parts of the country; Patagonia to the south remains sparsely populated
Natural hazards:
San Miguel de Tucumán and Mendoza areas in the Andes subject to earthquakes; pamperos are violent windstorms that can strike the pampas and northeast; heavy flooding in some areas
volcanism:
volcanic activity in the Andes Mountains along the Chilean border; Copahue (2,997 m) last erupted in 2000; other historically active volcanoes include Llullaillaco, Maipo, Planchón-Peteroa, San José, Tromen, Tupungatito, and Viedma
Geography - note:
note 1:
second-largest country in South America (after Brazil); strategic location relative to sea lanes between the South Atlantic and the South Pacific Oceans (Strait of Magellan, Beagle Channel, Drake Passage); diverse geophysical landscapes range from tropical climates in the north to tundra in the far south; Cerro Aconcagua is the Western Hemisphere’s tallest mountain, while Laguna del Carbón is the lowest point in the Western Hemisphere; shares Iguazú Falls, the world’s largest waterfalls system, with Brazil
note 2:
southeast Bolivia and northwest Argentina seem to be the original development site for peanuts','0d1219afac2db26513514b95444988117d683d45127869ee1300a9eb1ab7abdf','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7b47c5ddb5119199d3798f9167db840f27aacca8ed964db5cf8fe3dc3e5d9a32',2025,'AM','Armenia','geography',65,'Location:
Southwestern Asia, between Turkey (to the west) and Azerbaijan; note - Armenia views itself as part of Europe; geopolitically, it can be classified as falling within Europe, the Middle East, or both
Geographic coordinates:
40 00 N, 45 00 E
Map references:
Asia
Area:
total:
29,743 sq km
land:
28,203 sq km
water:
1,540 sq km
comparison ranking:
total 142
Area - comparative:
slightly smaller than Maryland
Land boundaries:
total:
1,570 km
border countries (4):
Azerbaijan 996 km; Georgia 219 km; Iran 44 km; Turkey 311 km
Coastline:
0 km (landlocked)
Maritime claims:
none (landlocked)
Climate:
highland continental, hot summers, cold winters
Terrain:
Armenian Highland with mountains; little forest land; fast flowing rivers; good soil in Aras River valley
Elevation:
highest point:
Aragats Lerrnagagat’ 4,090 m
lowest point:
Debed River 400 m
mean elevation:
1,792 m
Natural resources:
small deposits of gold, copper, molybdenum, zinc, bauxite
Land use:
agricultural land:
59.7% (2018 est.)
arable land:
15.8% (2018 est.)
permanent crops:
1.9% (2018 est.)
permanent pasture:
42% (2018 est.)
forest:
9.1% (2018 est.)
other:
31.2% (2018 est.)
Irrigated land:
1,554 sq km (2020)
Major lakes (area sq km):
fresh water lake(s):
Lake Sevan - 1,360 sq km
Population distribution:
most of the population is located in the northern half of the country; the capital of Yerevan is home to more than five times as many people as Gyumri, the second largest city in the country
Natural hazards:
occasionally severe earthquakes; droughts
Geography - note:
landlocked in the Lesser Caucasus Mountains; Sevana Lich (Lake Sevan) is the largest lake in this mountain range','f3cc3ea1ad8866495a93a8ddedaec49a8c98a1b52044557f1fbbfa3946618339','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('565e235ddb9efd34a9622679aa419df65d3073a18ec1c3e8cdf75cb9b4fe9f42',2025,'AW','Aruba','geography',2,'Location:
Caribbean, island in the Caribbean Sea, north of Venezuela
Geographic coordinates:
12 30 N, 69 58 W
Map references:
Central America and the Caribbean
Area:
total:
180 sq km
land:
180 sq km
water:
0 sq km
comparison ranking:
total 217
Area - comparative:
slightly larger than Washington, DC
Land boundaries:
total:
0 km
Coastline:
68.5 km
Maritime claims:
territorial sea:
12 nm
exclusive economic zone:
200 nm
Climate:
tropical marine; little seasonal temperature variation
Terrain:
flat with a few hills; scant vegetation
Elevation:
highest point:
Ceru Jamanota 188 m
lowest point:
Caribbean Sea 0 m
Natural resources:
NEGL; white sandy beaches foster tourism
Land use:
agricultural land:
11.1% (2018 est.)
arable land:
11.1% (2018 est.)
permanent crops:
0% (2018 est.)
permanent pasture:
0% (2018 est.)
forest:
2.3% (2018 est.)
other:
86.6% (2018 est.)
Irrigated land:
NA
Population distribution:
most residents live in or around Oranjestad and San Nicolaas; most settlments tend to be located on the less mountainous western side of the island
Natural hazards:
hurricanes; lies outside the Caribbean hurricane belt and is rarely threatened
Geography - note:
a flat, riverless island renowned for its white sand beaches; its tropical climate is moderated by constant trade winds from the Atlantic Ocean; the temperature is almost constant at about 27 degrees Celsius (81 degrees Fahrenheit)','14d4f01425e0ba3fabc433064b6b9f6a694d307195b6c2bd732c95432ff42616','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('dbb7bf2c2f0e8f4ae33d9d0bca40a68689b9feb20efa43aad8522feb3ae9ea26',2025,'AW','Aruba','geography',13,'Location:
Southeastern Asia, islands in the Indian Ocean, midway between northwestern Australia and Timor island; Ashmore Reef is 840 km west of Darwin and 610 km north of Broome; Cartier Islet is 70 km east of Ashmore Reef
Geographic coordinates:
12 25 S, 123 20 E
note -
Ashmore Reef - 12 14 S, 123 05 E; Cartier Islet - 12 32 S, 123 32 E
Map references:
Southeast Asia
Area:
total:
5 sq km
land:
5 sq km
water:
0 sq km
note:
includes Ashmore Reef (West, Middle, and East Islets) and Cartier Island
comparison ranking:
total 248
Area - comparative:
about eight times the size of the National Mall in Washington, DC
Land boundaries:
total:
0 km
Coastline:
74.1 km
Maritime claims:
territorial sea:
12 nm
contiguous zone:
24 nm
continental shelf:
200-m depth or to the depth of exploitation
exclusive fishing zone:
200 nm
Climate:
tropical
Terrain:
low with sand and coral
Elevation:
highest point:
Cartier Island 5 m
lowest point:
Indian Ocean 0 m
Natural resources:
fish
Land use:
agricultural land:
0% (2018 est.)
Natural hazards:
surrounded by shoals and reefs that can pose maritime hazards
Geography - note:
Ashmore Reef National Nature Reserve established in August 1983; Cartier Island Marine Reserve established in 2000','58a67b9566ab6b77a39846e68eef5e339532b63f632619a2916b1b820a29a93a','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('522a14bb5a51e92b43f9395e075fb0a8f771bd4a2b15a271a310f26d23a87f8a',2025,'AW','Aruba','geography',21,'Location:
body of water between Africa, Europe, the Arctic Ocean, the Americas, and the Southern Ocean
Geographic coordinates:
0 00 N, 25 00 W
Map references:
Political Map of the World
Area:
total:
85.133 million sq km
note:
includes Baffin Bay, Baltic Sea, Black Sea, Caribbean Sea, Davis Strait, Denmark Strait, part of the Drake Passage, Hudson Bay, Hudson Strait, Gulf of Mexico, Labrador Sea, Mediterranean Sea, North Sea, almost all of the Scotia Sea, and other tributary water bodies
Area - comparative:
about 7.5 times the size of the US
Coastline:
111,866 km
Climate:
tropical cyclones (hurricanes) develop off the coast of Africa near Cabo Verde and move westward into the Caribbean Sea; hurricanes can occur from May to December but are most frequent from August to November
Ocean volume:
ocean volume:
310,410,900 cu km
percent of World Ocean total volume:
23.3%
Major ocean currents:
clockwise North Atlantic Gyre consists of the northward flowing, warm Gulf Stream in the west, the eastward flowing North Atlantic Current in the north, the southward flowing cold Canary Current in the east, and the westward flowing North Equatorial Current in the south; the counterclockwise South Atlantic Gyre composed of the southward flowing warm Brazil Current in the west, the eastward flowing South Atlantic Current in the south, the northward flowing cold Benguela Current in the east, and the westward flowing South Equatorial Current in the north
Elevation:
highest point:
sea level
lowest point:
Puerto Rico Trench -8,605 m
mean depth:
-3,646 m
ocean zones:
Composed of water and in a fluid state, the oceans are delimited differently than the solid continents. Oceans are divided into three zones based on depth and light level. Although some sea creatures depend on light to live, others can do without it. Sunlight entering the water may travel about 1,000 m into the oceans under the right conditions, but there is rarely any significant light beyond 200 m.
The upper 200 m (656 ft) of oceans is called the euphotic, or “sunlight,” zone. This zone contains the vast majority of commercial fisheries and is home to many protected marine mammals and sea turtles. Only a small amount of light penetrates beyond this depth.
The zone between 200 m (656 ft) and 1,000 m (3,280 ft) is usually referred to as the “twilight” zone, but is officially the dysphotic zone. In this zone, the intensity of light rapidly dissipates as depth increases. Such a minuscule amount of light penetrates beyond a depth of 200 m that photosynthesis is no longer possible.
The aphotic, or “midnight,” zone exists in depths below 1,000 m (3,280 ft). Sunlight does not penetrate to these depths and the zone is bathed in darkness.
Distance Sunlight Travels in the Ocean:
Natural resources:
oil and gas fields, fish, marine mammals (seals and whales), sand and gravel aggregates, placer deposits, polymetallic nodules, precious stones
Natural hazards:
icebergs common in Davis Strait, Denmark Strait, and the northwestern Atlantic Ocean from February to August and have been spotted as far south as Bermuda and the Madeira Islands; ships subject to superstructure icing in extreme northern Atlantic from October to May; persistent fog can be a maritime hazard from May to September; hurricanes (May to December)
Geography - note:
major chokepoints include the Dardanelles, Strait of Gibraltar, access to the Panama and Suez Canals; strategic straits include the Strait of Dover, Straits of Florida, Mona Passage, The Sound (Oresund), and Windward Passage; the Equator divides the Atlantic Ocean into the North Atlantic Ocean and South Atlantic Ocean','cfb6a60cc824821274a6869f620aa4a56f25603e503d899d43c1be052474b404','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d2aa563c4d0e8e11b8fd1386113ffa8c44a9ff87ee50d628fc0b67fba4f10bd9',2025,'AU','Australia','geography',28,'Location:
Oceania, continent between the Indian Ocean and the South Pacific Ocean
Geographic coordinates:
27 00 S, 133 00 E
Map references:
Oceania
Area:
total:
7,741,220 sq km
land:
7,682,300 sq km
water:
58,920 sq km
note:
includes Lord Howe Island and Macquarie Island
comparison ranking:
total 7
Area - comparative:
slightly smaller than the US contiguous 48 states
Land boundaries:
total:
0 km
Coastline:
25,760 km
Maritime claims:
territorial sea:
12 nm
contiguous zone:
24 nm
exclusive economic zone:
200 nm
continental shelf:
200 nm or to the edge of the continental margin
Climate:
generally arid to semiarid; temperate in south and east; tropical in north
Terrain:
mostly low plateau with deserts; fertile plain in southeast
Elevation:
highest point:
Mount Kosciuszko 2,228 m
lowest point:
Lake Eyre -15 m
mean elevation:
330 m
Natural resources:
alumina, coal, iron ore, copper, lithium, tin, gold, silver, uranium, nickel, tungsten, rare earth elements, mineral sands, lead, zinc, diamonds, opals, natural gas, petroleum
note 1:
Australia is the world’s largest net exporter of coal accounting for 26.5% of global coal exports in 2021; coal is the country’s most abundant energy resource, and coal ranks as the second-largest export commodity from Australia in terms of revenue; in 2020, Australia held the third-largest recoverable coal reserves in the world behind the United States and Russia
note 2:
Australia is by far the world’s largest supplier of opals
note 3:
Australia holds the largest uranium reserves in the world, and was the second-largest global uranium producer behind Kazakhstan in 2020.
note 4:
Australia was the largest exporter of LNG in the world in 2020.
Land use:
agricultural land:
46.65% (2018 est.)
arable land:
4.03% (2018 est.)
permanent crops:
0.04% (2018 est.)
permanent pasture:
42.58% (2018 est.)
forest:
17.42% (2018 est.)
other:
33.42% (2018 est.)
Irrigated land:
15,210 sq km (2020)
Major lakes (area sq km):
fresh water lake(s):
Lake Alexandrina - 570 sq km
salt water lake(s):
Lake Eyre - 9,690 sq km; Lake Torrens (ephemeral) - 5,780 sq km; Lake Gairdner - 4,470 sq km; Lake Mackay (ephemeral) - 3,494 sq km; Lake Frome - 2,410 sq km; Lake Amadeus (ephemeral) - 1,032 sq km
Major rivers (by length in km):
River Murray - 2,508 km; Darling River - 1,545 km; Murrumbidgee River - 1,485 km; Lachlan River - 1,339 km; Cooper Creek - 1,113 km; Flinders River - 1,004 km
Major watersheds (area sq km):
Indian Ocean drainage:
(Great Australian Bight)
Murray-Darling (1,050,116 sq km)
Internal (endorheic basin) drainage:
Lake Eyre (1,212,198 sq km)
Major aquifers:
Great Artesian Basin, Canning Basin
Population distribution:
population is primarily located on the periphery, with the highest concentration of people residing in the east and southeast; a secondary population center is located in and around Perth in the west; of the States and Territories, New South Wales has, by far, the largest population; the interior, or “outback”, has a very sparse population
Natural hazards:
cyclones along the coast; severe droughts; forest fires
volcanism:
volcanic activity on Heard and McDonald Islands
Geography - note:
note 1:
world’s smallest continent but sixth-largest country; the largest country in Oceania, the largest country entirely in the Southern Hemisphere, and the largest country without land borders
note 2:
the Great Dividing Range that runs along eastern Australia is that continent’s longest mountain range and the third-longest land-based range in the world; the term “Great Dividing Range” refers to the fact that the mountains form a watershed crest from which all of the rivers of eastern Australia flow – east, west, north, and south
note 3:
Australia is the only continent without glaciers; it is the driest inhabited continent on earth, making it particularly vulnerable to the challenges of climate change; the invigorating sea breeze known as the “Fremantle Doctor” affects the city of Perth on the west coast and is one of the most consistent winds in the world; Australia is home to 10% of the world’s biodiversity, and a great number of its flora and fauna exist nowhere else in the world','1a0871737419e25dfc6874a45ccad3f7d2f0b455433fa4e5a86228462b2c230b','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8e77ee30f634d3baccd58c0070d0e0252b7217b327868be2b0d1b15a13e56dbf',2025,'AT','Austria','geography',41,'Location:
Central Europe, north of Italy and Slovenia
Geographic coordinates:
47 20 N, 13 20 E
Map references:
Europe
Area:
total:
83,871 sq km
land:
82,445 sq km
water:
1,426 sq km
comparison ranking:
total 114
Area - comparative:
about the size of South Carolina; slightly more than two-thirds the size of Pennsylvania
Land boundaries:
total:
2,524 km
border countries (8):
Czech Republic 402 km; Germany 801 km; Hungary 321 km; Italy 404 km; Liechtenstein 34 km; Slovakia 105 km; Slovenia 299 km; Switzerland 158 km
Coastline:
0 km (landlocked)
Maritime claims:
none (landlocked)
Climate:
temperate; continental, cloudy; cold winters with frequent rain and some snow in lowlands and snow in mountains; moderate summers with occasional showers
Terrain:
mostly mountains (Alps) in the west and south; mostly flat or gently sloping along the eastern and northern margins
Elevation:
highest point:
Grossglockner 3,798 m
lowest point:
Neusiedler See 115 m
mean elevation:
910 m
Natural resources:
oil, coal, lignite, timber, iron ore, copper, zinc, antimony, magnesite, tungsten, graphite, salt, hydropower
Land use:
agricultural land:
38.4% (2018 est.)
arable land:
16.5% (2018 est.)
permanent crops:
0.8% (2018 est.)
permanent pasture:
21.1% (2018 est.)
forest:
47.2% (2018 est.)
other:
14.4% (2018 est.)
Irrigated land:
382 sq km (2016)
Major lakes (area sq km):
fresh water lake(s):
Lake Constance (shared with Switzerland and Germany) - 540 sq km
Major rivers (by length in km):
Donau (Danube) (shared with Germany [s], Slovakia, Czechia, Hungary, Croatia, Serbia, Bulgaria, Ukraine, Moldova, and Romania [m]) - 2,888 km
note
– [s] after country name indicates river source; [m] after country name indicates river mouth
Major watersheds (area sq km): Atlantic Ocean drainage:
Rhine-Maas (198,735 sq km),
(Black Sea)
Danube (795,656 sq km)
Population distribution:
the northern and eastern portions of the country are more densely populated; nearly two-thirds of the populace lives in urban areas
Natural hazards:
landslides; avalanches; earthquakes
Geography - note:
note 1:
landlocked; strategic location at the crossroads of central Europe with many easily traversable Alpine passes and valleys; major river is the Danube; population is concentrated on eastern lowlands because of steep slopes, poor soils, and low temperatures elsewhere
note 2:
the world’s largest and longest ice cave system at 42 km (26 mi) is the Eisriesenwelt (Ice Giants World) inside the Hochkogel mountain near Werfen, about 40 km south of Salzburg; ice caves are bedrock caves that contain year-round ice formations; they differ from glacial caves, which are transient and are formed by melting ice and flowing water within and under glaciers','8e748a868dd94a4e1f4dba0a03288980db7fbae5e04140a39afde1bd5162d6b9','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c33b3703443471cb17024dd5f651b98ac25add8e04af70a7f35980fc8eb5409f',2025,'AZ','Azerbaijan','geography',54,'Location:
Southwestern Asia, bordering the Caspian Sea, between Iran and Russia, with a small European portion north of the Caucasus range
Geographic coordinates:
40 30 N, 47 30 E
Map references:
Asia
Area:
total:
86,600 sq km
land:
82,629 sq km
water:
3,971 sq km
note:
includes the exclave of Naxcivan Autonomous Republic and the Nagorno-Karabakh region; the final status of the region has yet to be determined
comparison ranking:
total 113
Area - comparative:
about three-quarters the size of Pennsylvania; slightly smaller than Maine
Land boundaries:
total:
2,468 km
border countries (5):
Armenia 996 km; Georgia 428 km; Iran 689 km; Russia 338 km; Turkey 17 km
Coastline:
0 km (landlocked); note - Azerbaijan borders the Caspian Sea (713 km)
Maritime claims:
none (landlocked)
Climate:
dry, semiarid steppe
Terrain:
large, flat Kur-Araz Ovaligi (Kura-Araks Lowland, much of it below sea level) with Great Caucasus Mountains to the north, Qarabag Yaylasi (Karabakh Upland) to the west; Baku lies on Abseron Yasaqligi (Apsheron Peninsula) that juts into Caspian Sea
Elevation:
highest point:
Bazarduzu Dagi 4,466 m
lowest point:
Caspian Sea -28 m
mean elevation:
384 m
Natural resources:
petroleum, natural gas, iron ore, nonferrous metals, bauxite
Land use:
agricultural land:
57.6% (2018 est.)
arable land:
22.8% (2018 est.)
permanent crops:
2.7% (2018 est.)
permanent pasture:
32.1% (2018 est.)
forest:
11.3% (2018 est.)
other:
31.1% (2018 est.)
Irrigated land:
14,649 sq km (2020)
Major lakes (area sq km):
salt water lake(s):
Caspian Sea (shared with Iran, Russia, Turkmenistan, and Kazakhstan) - 374,000 sq km
Population distribution:
highest population density is found in the far eastern area of the country, in and around Baku; apart from smaller urbanized areas, the rest of the country has a fairly light and evenly distributed population
Natural hazards:
droughts
Geography - note:
both the main area of the country and the Naxcivan exclave are landlocked','676e13a75605fc8b7b448bf8e91dbff44bc1ccd67031da44c14dadce8aaa55d1','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cce8e4510e7f5fbc694cbaf7a5ae4855b5cc5a29bc06f7fea030af017b2f83ba',2025,'BH','Bahrain','geography',4,'Location:
Middle East, archipelago in the Persian Gulf, east of Saudi Arabia
Geographic coordinates:
26 00 N, 50 33 E
Map references:
Middle East
Area:
total:
760 sq km
land:
760 sq km
water:
0 sq km
comparison ranking:
total 187
Area - comparative:
3.5 times the size of Washington, DC
Land boundaries:
total:
0 km
Coastline:
161 km
Maritime claims:
territorial sea:
12 nm
contiguous zone:
24 nm
continental shelf:
extending to boundaries to be determined
Climate:
arid; mild, pleasant winters; very hot, humid summers
Terrain:
mostly low desert plain rising gently to low central escarpment
Elevation:
highest point:
Jabal ad Dukhan 135 m
lowest point:
Persian Gulf 0 m
Natural resources:
oil, associated and nonassociated natural gas, fish, pearls
Land use:
agricultural land:
11.3% (2018 est.)
arable land:
2.1% (2018 est.)
permanent crops:
3.9% (2018 est.)
permanent pasture:
5.3% (2018 est.)
forest:
0.7% (2018 est.)
other:
88% (2018 est.)
Irrigated land:
40 sq km (2012)
Major aquifers:
Arabian Aquifer System
Population distribution:
smallest population of the Gulf States, but urbanization rate exceeds 90%; largest settlement concentration is found on the far northern end of the island in and around Manamah and Al Muharraq
Natural hazards:
periodic droughts; dust storms
Geography - note:
close to primary Middle Eastern petroleum sources; strategic location in Persian Gulf, through which much of the Western world’s petroleum must transit to reach open ocean','f900c5d7b5f8e0f20c0db4012483f0e4c7ea0ef277a9cb2d4e183b7d9122e21f','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('01b19f66e3333f907602c141f15a36072e391cdece57b70ec4041f48b041b3df',2025,'BD','Bangladesh','geography',17,'Location:
Southern Asia, bordering the Bay of Bengal, between Burma and India
Geographic coordinates:
24 00 N, 90 00 E
Map references:
Asia
Area:
total:
148,460 sq km
land:
130,170 sq km
water:
18,290 sq km
comparison ranking:
total 94
Area - comparative:
slightly larger than Pennsylvania and New Jersey combined; slightly smaller than Iowa
Land boundaries:
total:
4,413 km
border countries (2):
Burma 271 km; India 4,142 km
Coastline:
580 km
Maritime claims:
territorial sea:
12 nm
contiguous zone:
18 nm
exclusive economic zone:
200 nm
continental shelf:
to the outer limits of the continental margin
Climate:
tropical; mild winter (October to March); hot, humid summer (March to June); humid, warm rainy monsoon (June to October)
Terrain:
mostly flat alluvial plain; hilly in southeast
Elevation:
highest point:
Mowdok Taung 1,060 m
lowest point:
Indian Ocean 0 m
mean elevation:
85 m
Natural resources:
natural gas, arable land, timber, coal
Land use:
agricultural land:
70.1% (2018 est.)
arable land:
59% (2018 est.)
permanent crops:
6.5% (2018 est.)
permanent pasture:
4.6% (2018 est.)
forest:
11.1% (2018 est.)
other:
18.8% (2018 est.)
Irrigated land:
81,270 sq km (2020)
Major rivers (by length in km):
Brahmaputra river mouth (shared with China [s] and India) - 3,969 km; Ganges river mouth (shared with India [s]) - 2,704 km
note
– [s] after country name indicates river source; [m] after country name indicates river mouth
Major watersheds (area sq km): Indian Ocean drainage:
Brahmaputra (651,335 sq km), Ganges (1,016,124 sq km)
Major aquifers:
Indus-Ganges-Brahmaputra Basin
Natural hazards:
droughts; cyclones; much of the country routinely inundated during the summer monsoon season
Geography - note:
most of the country is situated on deltas of large rivers flowing from the Himalayas: the Ganges unites with the Jamuna (main channel of the Brahmaputra) and later joins the Meghna to eventually empty into the Bay of Bengal','cca386d1255272514c82c204c62dd1e91b0219885cc0d6956e4bf14fbac732cb','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e883087b8785c3cd3922770f6be20b53c70dbb291d07ba4d5b8a5386a6bc4e5c',2025,'BB','Barbados','geography',30,'Location:
Caribbean, island in the North Atlantic Ocean, northeast of Venezuela
Geographic coordinates:
13 10 N, 59 32 W
Map references:
Central America and the Caribbean
Area:
total:
430 sq km
land:
430 sq km
water:
0 sq km
comparison ranking:
total 201
Area - comparative:
2.5 times the size of Washington, DC
Land boundaries:
total:
0 km
Coastline:
97 km
Maritime claims:
territorial sea:
12 nm
exclusive economic zone:
200 nm
Climate:
tropical; rainy season (June to October)
Terrain:
relatively flat; rises gently to central highland region
Elevation:
highest point:
Mount Hillaby 336 m
lowest point:
Atlantic Ocean 0 m
Natural resources:
petroleum, fish, natural gas
Land use:
agricultural land:
32.6% (2018 est.)
arable land:
25.6% (2018 est.)
permanent crops:
2.3% (2018 est.)
permanent pasture:
4.7% (2018 est.)
forest:
19.4% (2018 est.)
other:
48% (2018 est.)
Irrigated land:
50 sq km (2012)
Population distribution:
most densely populated country in the eastern Caribbean; approximately one-third live in urban areas
Natural hazards:
infrequent hurricanes; periodic landslides
Geography - note:
easternmost Caribbean island','16b6c28a82ae2ba953ea56d63032ad71b8d3b2e0900641ab53a92be3d87c6e11','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4e4c26b759e3d2337a0ecc5a966b4a314a135120ebe133593b6d3daa4cc95522',2025,'BY','Belarus','geography',41,'Location:
Eastern Europe, east of Poland
Geographic coordinates:
53 00 N, 28 00 E
Map references:
Europe
Area:
total:
207,600 sq km
land:
202,900 sq km
water:
4,700 sq km
comparison ranking:
total 86
Area - comparative:
slightly less than twice the size of Kentucky; slightly smaller than Kansas
Land boundaries:
total:
3,599 km
border countries (5):
Latvia 161 km; Lithuania 640 km; Poland 375 km; Russia 1,312 km; Ukraine 1,111 km
Coastline:
0 km (landlocked)
Maritime claims:
none (landlocked)
Climate:
cold winters, cool and moist summers; transitional between continental and maritime
Terrain:
generally flat with much marshland
Elevation:
highest point:
Dzyarzhynskaya Hara 346 m
lowest point:
Nyoman River 90 m
mean elevation:
160 m
Natural resources:
timber, peat deposits, small quantities of oil and natural gas, granite, dolomitic limestone, marl, chalk, sand, gravel, clay
Land use:
agricultural land:
43.7% (2018 est.)
arable land:
27.2% (2018 est.)
permanent crops:
0.6% (2018 est.)
permanent pasture:
15.9% (2018 est.)
forest:
42.7% (2018 est.)
other:
13.6% (2018 est.)
Irrigated land:
303 sq km (2020)
Major rivers (by length in km):
Dnyapro (Dnieper) (shared with Russia [s] and Ukraine [m]) - 2,287 km
note
– [s] after country name indicates river source; [m] after country name indicates river mouth
Major watersheds (area sq km): Atlantic Ocean drainage:
(Black Sea) Dnieper (533,966 sq km)
Population distribution:
a fairly even distribution throughout most of the country, with urban areas attracting larger and denser populations
Natural hazards:
large tracts of marshy land
Geography - note:
landlocked; glacial scouring accounts for the flatness of Belarusian terrain and for its 11,000 lakes','7f8089175610b73705d45598a9f5a36c5352dc48aa21b4b39a31ef9612483407','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fd194c85deb27b73a6dbc04eb99de47afe840d5d312c507bf3456bcc25c5c25b',2025,'BE','Belgium','geography',53,'Location:
Western Europe, bordering the North Sea, between France and the Netherlands
Geographic coordinates:
50 50 N, 4 00 E
Map references:
Europe
Area:
total:
30,528 sq km
land:
30,278 sq km
water:
250 sq km
comparison ranking:
total 140
Area - comparative:
about the size of Maryland
Land boundaries:
total:
1,297 km
border countries (4):
France 556 km; Germany 133 km; Luxembourg 130 km; Netherlands 478 km
Coastline:
66.5 km
Maritime claims:
territorial sea:
12 nm
contiguous zone:
24 nm
exclusive economic zone:
geographic coordinates define outer limit
continental shelf:
median line with neighbors
Climate:
temperate; mild winters, cool summers; rainy, humid, cloudy
Terrain:
flat coastal plains in northwest, central rolling hills, rugged mountains of Ardennes Forest in southeast
Elevation:
highest point:
Botrange 694 m
lowest point:
North Sea 0 m
mean elevation:
181 m
Natural resources:
construction materials, silica sand, carbonates, arable land
Land use:
agricultural land:
44.1% (2018 est.)
arable land:
27.2% (2018 est.)
permanent crops:
0.8% (2018 est.)
permanent pasture:
16.1% (2018 est.)
forest:
22.4% (2018 est.)
other:
33.5% (2018 est.)
Irrigated land:
57 sq km (2013)
Major watersheds (area sq km): Atlantic Ocean drainage:
Seine (78,919 sq km), Rhine-Maas (198,735 sq km)
Population distribution:
most of the population concentrated in the northern two-thirds of the country; the southeast is more thinly populated; considered to have one of the highest population densities in the world; approximately 97% live in urban areas
Natural hazards:
flooding is a threat along rivers and in areas of reclaimed coastal land, protected from the sea by concrete dikes
Geography - note:
crossroads of Western Europe; most West European capitals are within 1,000 km of Brussels, the seat of both the EU and NATO','d7eca6a62d92df192a85c6725d4c2c726a287f9909b3b599030892d6ef88ea23','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('99e83c627dd0e49761fbb8f3d481fe739cc4d6143115ec5ed20c23d831de7c1c',2025,'BZ','Belize','geography',2,'Location:
Central America, bordering the Caribbean Sea, between Guatemala and Mexico
Geographic coordinates:
17 15 N, 88 45 W
Map references:
Central America and the Caribbean
Area:
total:
22,966 sq km
land:
22,806 sq km
water:
160 sq km
comparison ranking:
total 151
Area - comparative:
slightly smaller than Massachusetts
Land boundaries:
total:
542 km
border countries (2):
Guatemala 266 km; Mexico 276 km
Coastline:
386 km
Maritime claims:
territorial sea:
12 nm in the north, 3 nm in the south; note - from the mouth of the Sarstoon River to Ranguana Cay, Belize’s territorial sea is 3 nm; according to Belize’s Maritime Areas Act, 1992, the purpose of this limitation is to provide a framework for negotiating a definitive agreement on territorial differences with Guatemala
exclusive economic zone:
200 nm
Climate:
tropical; very hot and humid; rainy season (May to November); dry season (February to May)
Terrain:
flat, swampy coastal plain; low mountains in south
Elevation:
highest point:
Doyle’s Delight 1,124 m
lowest point:
Caribbean Sea 0 m
mean elevation:
173 m
Natural resources:
arable land potential, timber, fish, hydropower
Land use:
agricultural land:
6.9% (2018 est.)
arable land:
3.3% (2018 est.)
permanent crops:
1.4% (2018 est.)
permanent pasture:
2.2% (2018 est.)
forest:
60.6% (2018 est.)
other:
32.5% (2018 est.)
Irrigated land:
35 sq km (2012)
Population distribution:
approximately 25% to 30% of the population lives in the former capital, Belize City; over half of the overall population is rural; population density is slightly higher in the north and east
Natural hazards:
frequent, devastating hurricanes (June to November) and coastal flooding (especially in south)
Geography - note:
only country in Central America without a coastline on the North Pacific Ocean','92c5468f0d9831eb3c06073207b226a1021d6a12e257e414be2f2529db5967a8','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4d9ab2ad63d734d6a52373153802b039af10a6de835452fa409ef1af66fb0aff',2025,'BJ','Benin','geography',13,'Location:
Western Africa, bordering the Bight of Benin, between Nigeria and Togo
Geographic coordinates:
9 30 N, 2 15 E
Map references:
Africa
Area:
total:
112,622 sq km
land:
110,622 sq km
water:
2,000 sq km
comparison ranking:
total 102
Area - comparative:
slightly smaller than Pennsylvania
Land boundaries:
total:
2,123 km
border countries (4):
Burkina Faso 386 km; Niger 277 km; Nigeria 809 km; Togo 651 km
Coastline 121 km
Maritime claims:
territorial sea:
200 nm; note: the US does not recognize this claim
continental shelf:
200 nm
exclusive fishing zone:
200 nm
Climate:
tropical; hot, humid in south; semiarid in north
Terrain:
mostly flat to undulating plain; some hills and low mountains
Elevation:
highest point:
unnamed elevation 675 m; located 2.5 km southeast of the town of Kotopounga
lowest point:
Atlantic Ocean 0 m
mean elevation:
273 m
Natural resources:
small offshore oil deposits, limestone, marble, timber
Land use:
agricultural land:
31.3% (2018 est.)
arable land:
22.9% (2018 est.)
permanent crops:
3.5% (2018 est.)
permanent pasture:
4.9% (2018 est.)
forest:
40% (2018 est.)
other:
28.7% (2018 est.)
Irrigated land:
172 sq km (2017)
Major watersheds (area sq km): Atlantic Ocean drainage:
Niger (2,261,741 sq km), Volta (410,991 sq km)
Population distribution:
the population is primarily located in the south, with the highest concentration of people residing in and around the cities on the Atlantic coast; most of the north remains sparsely populated with higher concentrations of residents in the west as shown in this population distribution map
Natural hazards:
hot, dry, dusty harmattan wind may affect north from December to March
Geography - note:
sandbanks create difficult access to a coast with no natural harbors, river mouths, or islands','1c07ba0ba1802ea9bc22257b117b55735fca0bb6e4d564b0dd1029ef6dbcb858','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('aa0ad2250ba2d05115da7c64b6b99ca6931662c31ba209977510818ca82b8f04',2025,'BM','Bermuda','geography',25,'Location:
North America, group of islands in the North Atlantic Ocean, east of South Carolina (US)
Geographic coordinates:
32 20 N, 64 45 W
Map references:
North America
Area:
total:
54 sq km
land:
54 sq km
water:
0 sq km
comparison ranking:
total 230
Area - comparative:
about one-third the size of Washington, DC
Land boundaries:
total:
0 km
Coastline:
103 km
Maritime claims:
territorial sea:
12 nm
exclusive economic zone:
200 nm
exclusive fishing zone:
200 nm
Climate:
subtropical; mild, humid; gales, strong winds common in winter
Terrain:
low hills separated by fertile depressions
Elevation:
highest point:
Town Hill 79 m
lowest point:
Atlantic Ocean 0 m
Natural resources:
limestone, pleasant climate fostering tourism
Land use:
agricultural land:
14.8% (2018 est.)
arable land:
14.8% (2018 est.)
permanent crops:
0% (2018 est.)
permanent pasture:
0% (2018 est.)
forest:
20% (2018 est.)
other:
65.2% (2018 est.)
Irrigated land:
NA
Population distribution:
relatively even population distribution throughout
Natural hazards:
hurricanes (June to November)
Geography - note:
consists of about 138 coral islands and islets with ample rainfall, but no rivers or freshwater lakes; some land was leased by the US Government from 1941 to 1995','e3339dcab427380950115e99cedf21d2c2d4b5cc6ca671344962ba39fc4b3cc0','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2fdcccd020af979c0e216565c8ca192e15d0c857404c9d7d975ffaf6d91da86b',2025,'BT','Bhutan','geography',36,'Location:
Southern Asia, between China and India
Geographic coordinates:
27 30 N, 90 30 E
Map references:
Asia
Area:
total:
38,394 sq km
land:
38,394 sq km
water:
0 sq km
comparison ranking:
total 136
Area - comparative:
slightly larger than Maryland; about one-half the size of Indiana
Land boundaries:
total:
1,136 km
border countries (2):
China 477 km; India 659 km
Coastline:
0 km (landlocked)
Maritime claims:
none (landlocked)
Climate:
varies; tropical in southern plains; cool winters and hot summers in central valleys; severe winters and cool summers in Himalayas
Terrain:
mostly mountainous with some fertile valleys and savanna
Elevation:
highest point:
Gangkar Puensum 7,570 m
lowest point:
Drangeme Chhu 97 m
mean elevation:
2,220 m
Natural resources:
timber, hydropower, gypsum, calcium carbonate
Land use:
agricultural land:
13.6% (2018 est.)
arable land:
2.6% (2018 est.)
permanent crops:
0.3% (2018 est.)
permanent pasture:
10.7% (2018 est.)
forest:
85.5% (2018 est.)
other:
0.9% (2018 est.)
Irrigated land:
320 sq km (2012)
Natural hazards:
violent storms from the Himalayas are the source of the country’s Bhutanese name, which translates as Land of the Thunder Dragon; frequent landslides during the rainy season
Geography - note:
landlocked; strategic location between China and India; controls several key Himalayan mountain passes','0fc7dd9a9b11d210808fc856afa088e3a805b4d9afe738776c048f6bfb61164a','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('999f3b1778716877e442da2c58ca9a679ab7ac462276825e0c575df90a779896',2025,'BT','Bhutan','geography',48,'Location:
Central South America, southwest of Brazil
Geographic coordinates:
17 00 S, 65 00 W
Map references:
South America
Area:
total:
1,098,581 sq km
land:
1,083,301 sq km
water:
15,280 sq km
comparison ranking:
total 29
Area - comparative:
slightly less than three times the size of Montana
Land boundaries:
total:
7,252 km
border countries (5):
Argentina 942 km; Brazil 3,403 km; Chile 942 km; Paraguay 753 km; Peru 1,212 km
Coastline:
0 km (landlocked)
Maritime claims:
none (landlocked)
Climate:
varies with altitude; humid and tropical to cold and semiarid
Terrain:
rugged Andes Mountains with a highland plateau (Altiplano), hills, lowland plains of the Amazon Basin
Elevation:
highest point:
Nevado Sajama 6,542 m
lowest point:
Rio Paraguay 90 m
mean elevation:
1,192 m
Natural resources:
lithium, tin, natural gas, petroleum, zinc, tungsten, antimony, silver, iron, lead, gold, timber, hydropower
Land use:
agricultural land:
34.3% (2018 est.)
arable land:
3.6% (2018 est.)
permanent crops:
0.2% (2018 est.)
permanent pasture:
30.5% (2018 est.)
forest:
52.5% (2018 est.)
other:
13.2% (2018 est.)
Irrigated land:
2,972 sq km (2017)
Major lakes (area sq km):
fresh water lake(s):
Lago Titicaca (shared with Peru) - 8,030 sq km
salt water lake(s):
Lago Poopo - 1,340 sq km
Major watersheds (area sq km): Atlantic Ocean drainage:
Amazon (6,145,186 sq km), Paraná (2,582,704 sq km)
Major aquifers:
Amazon Basin
Population distribution:
a high altitude plain in the west between two cordillera of the Andes, known as the Altiplano, is the focal area for most of the population; a dense settlement pattern is also found in and around the city of Santa Cruz, located on the eastern side of the Andes
Natural hazards:
flooding in the northeast (March to April)
volcanism:
volcanic activity in Andes Mountains on the border with Chile; historically active volcanoes in this region are Irruputuncu (5,163 m), which last erupted in 1995, and the Olca-Paruma volcanic complex (5,762 m to 5,167 m)
Geography - note:
note 1:
landlocked; shares control of Lago Titicaca, world’s highest navigable lake (elevation 3,805 m), with Peru
note 2:
the southern regions of Peru and the extreme northwestern part of Bolivia are considered to be the place of origin for the common potato, while southeast Bolivia and northwest Argentina seem to be the original development site for peanuts','01e90d9d781299ba5dfa24281c35e9e3ca7afedffe6fdc1e278b051cc4f0fb4c','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('08edcda00c92248a27e145b57d84e1c4ba7f68667ecbfb9bc524a5be6accb730',2025,'BA','Bosnia and Herzegovina','geography',60,'Location:
Southeastern Europe, bordering the Adriatic Sea and Croatia
Geographic coordinates:
44 00 N, 18 00 E
Map references:
Europe
Area:
total:
51,197 sq km
land:
51,187 sq km
water:
10 sq km
comparison ranking:
total 128
Area - comparative:
slightly smaller than West Virginia
Land boundaries:
total:
1,543 km
border countries (3):
Croatia 956 km; Montenegro 242 km; Serbia 345 km
Coastline:
20 km
Climate:
hot summers and cold winters; areas of high elevation have short, cool summers and long, severe winters; mild, rainy winters along coast
Terrain:
mountains and valleys
Elevation:
highest point:
Maglic 2,386 m
lowest point:
Adriatic Sea 0 m
mean elevation:
500 m
Natural resources:
coal, iron ore, antimony, bauxite, copper, lead, zinc, chromite, cobalt, manganese, nickel, clay, gypsum, salt, sand, timber, hydropower
Land use:
agricultural land:
42.2% (2018 est.)
arable land:
19.7% (2018 est.)
permanent crops:
2% (2018 est.)
permanent pasture:
20.5% (2018 est.)
forest:
42.8% (2018 est.)
other:
15% (2018 est.)
Irrigated land:
30 sq km (2012)
Major watersheds (area sq km): Atlantic Ocean drainage:
(Black Sea) Danube (795,656 sq km)
Population distribution:
the northern and central areas of the country are the most densely populated
Natural hazards:
destructive earthquakes
Geography - note:
within Bosnia and Herzegovina’s recognized borders, the country is divided into a joint Bosniak/Croat Federation (about 51% of the territory) and the Bosnian Serb-led Republika Srpska or RS (about 49% of the territory); the region called Herzegovina is contiguous to Croatia and Montenegro, and traditionally has been settled by an ethnic Croat majority in the west and an ethnic Serb majority in the east','115900dce14f9f5a8151c3a1506907e9dd8f75a272301810ea2becceeda8fa55','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8bfc2e65f05a76e8acf490786e167317dd224f32f5012f46902646368adb531e',2025,'BW','Botswana','geography',2,'Location:
Southern Africa, north of South Africa
Geographic coordinates:
22 00 S, 24 00 E
Map references:
Africa
Area:
total:
581,730 sq km
land:
566,730 sq km
water:
15,000 sq km
comparison ranking:
total 50
Area - comparative:
slightly smaller than Texas; almost four times the size of Illinois
Land boundaries:
total:
4,347.15 km
border countries (4):
Namibia 1,544 km; South Africa 1,969 km; Zambia 0.15 km; Zimbabwe 834 km
Coastline:
0 km (landlocked)
Maritime claims:
none (landlocked)
Climate:
semiarid; warm winters and hot summers
Terrain:
predominantly flat to gently rolling tableland; Kalahari Desert in southwest
Elevation:
highest point:
Manyelanong Hill 1,495 m
lowest point:
junction of the Limpopo and Shashe Rivers 513 m
mean elevation:
1,013 m
Natural resources:
diamonds, copper, nickel, salt, soda ash, potash, coal, iron ore, silver
Land use:
agricultural land:
45.8% (2018 est.)
arable land:
0.6% (2018 est.)
permanent crops:
0% (2018 est.)
permanent pasture:
45.2% (2018 est.)
forest:
19.8% (2018 est.)
other:
34.4% (2018 est.)
Irrigated land:
25 sq km (2014)
Major rivers (by length in km):
Zambezi (shared with Zambia [s]), Angola, Namibia, Zimbabwe, and Mozambique [m]) - 2,740 km; Limpopo (shared with South Africa [s], Zimbabwe, and Mozambique [m]) - 1,800 km; Okavango river mouth (shared with Angola [s], and Namibia) - 1,600 km
note
– [s] after country name indicates river source; [m] after country name indicates river mouth
Major watersheds (area sq km): Atlantic Ocean drainage:
Orange (941,351 sq km)
Indian Ocean drainage:
Zambezi (1,332,412 sq km)
Internal
(endorheic basin)
drainage:
Okavango Basin (863,866 sq km)
Major aquifers:
Lower Kalahari-Stampriet Basin, Upper Kalahari-Cuvelai-Upper Zambezi Basin
Population distribution:
the population is primarily concentrated in the east with a focus in and around the captial of Gaborone, and the far central-eastern city of Francistown; population density remains low in other areas in the country, especially in the Kalahari to the west as shown in this population distribution map
Natural hazards:
periodic droughts; seasonal August winds blow from the west, carrying sand and dust across the country, which can obscure visibility
Geography - note:
landlocked; sparsely populated with most settlement concentrated in the southern and eastern parts of the country; geography dominated by the Kalahari Desert, which covers about 70% of the country, although the Okavango Delta brings considerable biodiversity as one of the largest inland deltas in the World','889f0be82102ed00dfb4d91eb324f4b9f147635c942886ebcaba9f98a15c6c11','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3393e304359a39559c6a781a61ce82d591e7cd9fee1d7e82d77976c4b927559d',2025,'BV','Bouvet Island','geography',14,'Location:
island in the South Atlantic Ocean, southwest of the Cape of Good Hope (South Africa)
Geographic coordinates:
54 26 S, 3 24 E
Map references:
Antarctic Region
Area:
total:
49 sq km
land:
49 sq km
water:
0 sq km
comparison ranking:
total 232
Area - comparative:
about 0.3 times the size of Washington, DC
Land boundaries:
total:
0 km
Coastline:
29.6 km
Maritime claims:
territorial sea:
4 nm
Climate:
antarctic
Terrain:
volcanic; coast is mostly inaccessible
Elevation:
highest point:
Olavtoppen (Olav Peak) 780 m
lowest point:
South Atlantic Ocean 0 m
Natural resources:
none
Land use:
agricultural land:
0% (2018 est.)
arable land:
0% (2018 est.)
permanent crops:
0% (2018 est.)
permanent pasture:
0% (2018 est.)
forest:
0% (2018 est.)
other:
100% (2018 est.)
Natural hazards:
occasional volcanism, rock slides; harsh climate, surrounded by pack ice in winter
Geography - note:
almost entirely covered by glacial ice (93%); declared a nature reserve by Norway; the distance from Bouvet Island to Norway is 12,776 km, which is almost one-third the circumference of the earth','ac747da4a163d0f17da8b65f9855d358edf35a5b5ac6fae4ed4ace4b56c79746','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('112b55ba25b276376ffb0c5076433879b6b135aa53d26defbcc916a041f020f8',2025,'BR','Brazil','geography',23,'Location:
Eastern South America, bordering the Atlantic Ocean
Geographic coordinates:
10 00 S, 55 00 W
Map references:
South America
Area:
total:
8,515,770 sq km
land:
8,358,140 sq km
water:
157,630 sq km
note:
includes Arquipelago de Fernando de Noronha, Atol das Rocas, Ilha da Trindade, Ilhas Martin Vaz, and Penedos de Sao Pedro e Sao Paulo
comparison ranking:
total 6
Area - comparative:
slightly smaller than the US
Land boundaries:
total:
16,145 km
border countries (10):
Argentina 1,263 km; Bolivia 3,403 km; Colombia 1,790 km; French Guiana 649 km; Guyana 1,308 km; Paraguay 1,371 km; Peru 2,659 km; Suriname 515 km; Uruguay 1,050 km; Venezuela 2,137 km
Coastline:
7,491 km
Maritime claims:
territorial sea:
12 nm
contiguous zone:
24 nm
exclusive economic zone:
200 nm
continental shelf:
200 nm or to edge of the continental margin
Climate:
mostly tropical, but temperate in south
Terrain:
mostly flat to rolling lowlands in north; some plains, hills, mountains, and narrow coastal belt
Elevation:
highest point:
Pico da Neblina 2,994 m
lowest point:
Atlantic Ocean 0 m
mean elevation:
320 m
Natural resources:
alumina, bauxite, beryllium, gold, iron ore, manganese, nickel, niobium, phosphates, platinum, tantalum, tin, rare earth elements, uranium, petroleum, hydropower, timber
Land use:
agricultural land:
32.9% (2018 est.)
arable land:
8.6% (2018 est.)
permanent crops:
0.8% (2018 est.)
permanent pasture:
23.5% (2018 est.)
forest:
61.9% (2018 est.)
other:
5.2% (2018 est.)
Irrigated land:
69,029 sq km (2017)
Major lakes (area sq km):
fresh water lake(s):
Lagoa dos Patos - 10,140 sq km
salt water lake(s):
Lagoa Mirim (shared with Uruguay) - 2,970 sq km
Major rivers (by length in km):
Amazon river mouth (shared with Peru [s]) - 6,400 km; Río de la Plata/Paraná river source (shared with Paraguay, Argentina, and Uruguay [m]) - 4,880 km; Tocantins - 3,650 km; São Francisco - 3,180 km; Paraguay river source (shared with Argentina and Paraguay [m]) - 2,549 km; Rio Negro river mouth (shared with Colombia [s] and Venezuela) - 2,250 km; Uruguay river source (shared with Argentina and Uruguay [m]) - 1,610 km
note
– [s] after country name indicates river source; [m] after country name indicates river mouth
Major watersheds (area sq km): Atlantic Ocean drainage:
Amazon (6,145,186 sq km), Orinoco (953,675 sq km), Paraná (2,582,704 sq km), São Francisco (617,814 sq km), Tocantins (764,213 sq km)
Major aquifers:
Amazon Basin, Guarani Aquifer System, Maranhao Basin
Population distribution:
the vast majority of people live along, or relatively near, the Atlantic coast in the east; the population core is in the southeast, anchored by the cities of São Paolo, Brasília, and Rio de Janeiro
Natural hazards:
recurring droughts in northeast; floods and occasional frost in south
Geography - note:
note 1:
largest country in South America and in the Southern Hemisphere; shares common boundaries with every South American country except Chile and Ecuador; most of the Pantanal, the world’s largest tropical wetland, extends through the west central part of the country; shares Iguaçu Falls (Iguazú Falls), the world’s largest waterfalls system, with Argentina
note 2:
cassava (manioc) the sixth most important food crop in the world - after maize, rice, wheat, potatoes, and soybeans - seems to have originated in the west-central part of Brazil; pineapples are probably indigenous to the southern Brazil-Paraguay region
note 3:
Rocas Atoll, located off the northeast coast of Brazil, is the only atoll in the South Atlantic
Rocas Atoll:','a41b9257e113474d8ad0ae9937c0658ba2a6c247aae1b2c76878d3f22878b92c','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1a0440bd729585ca92090d89c5a26bb2b2936d59068636bcf736628f09cd131d',2025,'IO','British Indian Ocean Territory','geography',36,'Location:
archipelago in the Indian Ocean, south of India, about halfway between Africa and Indonesia
Geographic coordinates:
6 00 S, 71 30 E; note - Diego Garcia 7 20 S, 72 25 E
Map references:
Political Map of the World
Area:
total:
60 sq km
land:
60 sq km (44 Diego Garcia)
water:
54,340 sq km
note:
includes the entire Chagos Archipelago of 55 islands
comparison ranking:
total 229
Area - comparative:
land area is about one-third the size of Washington, DC
Land boundaries:
total:
0 km
Coastline:
698 km
Maritime claims:
territorial sea:
12 nm
Environment (Protection and Preservation) Zone:
200 nm
Climate:
tropical marine; hot, humid, moderated by trade winds
Terrain:
flat and low coral atolls (most areas do not exceed two m in elevation); sits atop the submarine volcanic Chagos-Laccadive Ridge
Elevation:
highest point:
ocean-side dunes on Diego Garcia 9 m
lowest point:
Indian Ocean 0 m
Natural resources:
coconuts, fish, sugarcane
Land use:
agricultural land:
0% (2018 est.)
forest:
0% (2018 est.)
other:
100% (2018 est.)
Natural hazards:
none; located outside routes of Indian Ocean cyclones
Geography - note:
note 1:
archipelago of 55 islands; Diego Garcia, the largest and southernmost island, occupies a strategic location in the central Indian Ocean; the island is the site of a joint US-UK military facility
note 2:
Diego Garcia is the only inhabited island of the BIOT and one of only two British territories where traffic drives on the right, the other being Gibraltar','7af4135507bacee67a712e5a4fde26777f32e4e3e4a076fa4421cf6eef65bf8a','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2194ba7bfbdeeeb30b11defc01049f838239f2074cabad4d488316ddd821e596',2025,'IO','British Indian Ocean Territory','geography',46,'Location:
Caribbean, between the Caribbean Sea and the North Atlantic Ocean, east of Puerto Rico
Geographic coordinates:
18 30 N, 64 30 W
Map references:
Central America and the Caribbean
Area:
total:
151 sq km
land:
151 sq km
water:
0 sq km
note:
comprised of 16 inhabited and more than 20 uninhabited islands; includes the islands of Tortola, Anegada, Virgin Gorda, Jost van Dyke
comparison ranking:
total 219
Area - comparative:
about 0.9 times the size of Washington, DC
Land boundaries:
total:
0 km
Coastline:
80 km
Maritime claims:
territorial sea:
12 nm
exclusive fishing zone:
200 nm
Climate:
subtropical; humid; temperatures moderated by trade winds
Terrain:
coral islands relatively flat; volcanic islands steep, hilly
Elevation:
highest point:
Mount Sage 521 m
lowest point:
Caribbean Sea 0 m
Natural resources:
NEGL; pleasant climate, beaches foster tourism
Land use:
agricultural land:
46.7% (2018 est.)
arable land:
6.7% (2018 est.)
permanent crops:
6.7% (2018 est.)
permanent pasture:
33.3% (2018 est.)
forest:
24.3% (2018 est.)
other:
29% (2018 est.)
Irrigated land:
NA
Population distribution:
a fairly even distribution throughout the inhabited islands, with the largest islands of Tortola, Anegada, Virgin Gorda, and Jost Van Dyke having the largest populations
Natural hazards:
hurricanes and tropical storms (July to October)
Geography - note:
strong ties to nearby US Virgin Islands and Puerto Rico','68294c9056160682f34e3cc88690f3ba33485dd665abf384a5b5522c3f0f908a','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('081a1b0aade5c813c8378e2672297aa648db84c722b8b59111ba27943c257303',2025,'IO','British Indian Ocean Territory','geography',57,'Location:
Southeastern Asia, along the northern coast of the island of Borneo, bordering the South China Sea and Malaysia
Geographic coordinates:
4 30 N, 114 40 E
Map references:
Southeast Asia
Area:
total:
5,765 sq km
land:
5,265 sq km
water:
500 sq km
comparison ranking:
total 172
Area - comparative:
slightly smaller than Delaware
Land boundaries:
total:
266 km
border countries (1):
Malaysia 266 km
Coastline:
161 km
Maritime claims:
territorial sea:
12 nm
exclusive economic zone:
200 nm or to median line
Climate:
tropical; hot, humid, rainy
Terrain:
flat coastal plain rises to mountains in east; hilly lowland in west
Elevation:
highest point:
Bukit Pagon 1,850 m
lowest point:
South China Sea 0 m
mean elevation:
478 m
Natural resources:
petroleum, natural gas, timber
Land use:
agricultural land:
2.5% (2018 est.)
arable land:
0.8% (2018 est.)
permanent crops:
1.1% (2018 est.)
permanent pasture:
0.6% (2018 est.)
forest:
71.8% (2018 est.)
other:
25.7% (2018 est.)
Irrigated land:
10 sq km (2012)
Population distribution:
the vast majority of the population is found along the coast in the western part of Brunei, which is separated from the eastern portion by Malaysia; the largest population concentration is in the far north on the western side of the Brunei Bay, in and around the capital of Bandar Seri Begawan
Natural hazards:
typhoons, earthquakes, and severe flooding are rare
Geography - note:
close to vital sea lanes through South China Sea linking Indian and Pacific Oceans; two parts physically separated by Malaysia; the eastern part, the Temburong district, is an exclave and is almost an enclave within Malaysia','c27f2d1aba1b8e76620a1359d5b3ff3eee2938775a9afb3ce5984949be540bff','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a1bbad0ab426e0b1f5e438aaa72f4bcabae5756df2759d000a23f639a565ecd7',2025,'BG','Bulgaria','geography',2,'Location:
Southeastern Europe, bordering the Black Sea, between Romania and Turkey
Geographic coordinates:
43 00 N, 25 00 E
Map references:
Europe
Area:
total:
110,879 sq km
land:
108,489 sq km
water:
2,390 sq km
comparison ranking:
total 105
Area - comparative:
almost identical in size to Virginia; slightly larger than Tennessee
Land boundaries:
total:
1,806 km
border countries (5):
Greece 472 km; Macedonia 162 km; Romania 605 km; Serbia 344 km; Turkey 223 km
Coastline:
354 km
Maritime claims:
territorial sea:
12 nm
contiguous zone:
24 nm
exclusive economic zone:
200 nm
Climate:
temperate; cold, damp winters; hot, dry summers
Terrain:
mostly mountains with lowlands in north and southeast
Elevation:
highest point:
Musala 2,925 m
lowest point:
Black Sea 0 m
mean elevation:
472 m
Natural resources:
bauxite, copper, lead, zinc, coal, timber, arable land
Land use:
agricultural land:
46.9% (2018 est.)
arable land:
29.9% (2018 est.)
permanent crops:
1.5% (2018 est.)
permanent pasture:
15.5% (2018 est.)
forest:
36.7% (2018 est.)
other:
16.4% (2018 est.)
Irrigated land:
987 sq km (2013)
Major rivers (by length in km):
Dunav (Danube) (shared with Germany [s], Austria, Slovakia, Czechia, Hungary, Croatia, Serbia, Ukraine, Moldova, and Romania [m]) - 2,888 km
note
– [s] after country name indicates river source; [m] after country name indicates river mouth
Major watersheds (area sq km): Atlantic Ocean drainage:
(Black Sea)
Danube (795,656 sq km)
Population distribution:
a fairly even distribution throughout most of the country, with urban areas attracting larger populations
Natural hazards:
earthquakes; landslides
Geography - note:
strategic location near Turkish Straits; controls key land routes from Europe to Middle East and Asia','f64d8bd0f0f6c1fee7654c120c1cb54e20ee335224fa8102015d3e70738c28d8','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d67fa2b39dc23496cfad10728d266d3c9c500ba57e898411e444e830f13d958d',2025,'BF','Burkina Faso','geography',15,'Location:
Western Africa, north of Ghana
Geographic coordinates:
13 00 N, 2 00 W
Map references:
Africa
Area:
total:
274,200 sq km
land:
273,800 sq km
water:
400 sq km
comparison ranking:
total 76
Area - comparative:
slightly larger than Colorado
Land boundaries:
total:
3,611 km
border countries (6):
Benin 386 km; Cote d’Ivoire 545 km; Ghana 602 km; Mali 1325 km; Niger 622 km; Togo 131 km
Coastline:
0 km (landlocked)
Maritime claims:
none (landlocked)
Climate:
three climate zones including a hot tropical savanna with a short rainy season in the southern half, a tropical hot semi-arid steppe climate typical of the Sahel region in the northern half, and small area of hot desert in the very north of the country bordering the Sahara Desert
Terrain:
mostly flat to dissected, undulating plains; hills in the west and southeast; occupies an extensive plateau with savanna that is grassy in the north and gradually gives way to sparse forests in the south
Elevation:
highest point:
Tena Kourou 749 m
lowest point:
Mouhoun (Black Volta) River 200 m
mean elevation:
297 m
Natural resources:
gold, manganese, zinc, limestone, marble, phosphates, pumice, salt
Land use:
agricultural land:
44.2% (2018 est.)
arable land:
22% (2018 est.)
permanent crops:
37% (2018 est.)
permanent pasture:
21.93% (2018 est.)
forest:
19.3% (2018 est.)
other:
36.5% (2018 est.)
Irrigated land:
550 sq km (2016)
Major rivers (by length in km):
Volta river source (shared with Ghana [m]) - 1,600 km
note
– [s] after country name indicates river source; [m] after country name indicates river mouth
Major watersheds (area sq km): Atlantic Ocean drainage:
Niger (2,261,741 sq km), Volta (410,991 sq km)
Population distribution:
Most of the population is located in the center and south. Nearly one-third of the population lives in cities. The capital and largest city is Ouagadougou (Ouaga), with a population of 1.8 million as shown in this population distribution map
(2019)
Natural hazards:
recurring droughts
Geography - note:
landlocked savanna cut by the three principal rivers of the Black, Red, and White Voltas','c405bcffc3745122f15bb66117bfa478a64679aab582acd266fd4b59a2e62df1','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('48c91f8c2382986376f9d6310c09158d720d090eaf2b36453b39f334b9a4482a',2025,'BF','Burkina Faso','geography',27,'Location:
Southeastern Asia, bordering the Andaman Sea and the Bay of Bengal, between Bangladesh and Thailand
Geographic coordinates:
22 00 N, 98 00 E
Map references:
Southeast Asia
Area:
total:
676,578 sq km
land:
653,508 sq km
water:
23,070 sq km
comparison ranking:
total 42
Area - comparative:
slightly smaller than Texas
Land boundaries:
total:
6,522 km
border countries (5):
Bangladesh 271 km; China 2,129 km; India 1,468 km; Laos 238 km; Thailand 2,416 km
Coastline:
1,930 km
Maritime claims:
territorial sea:
12 nm
contiguous zone:
24 nm
exclusive economic zone:
200 nm
continental shelf:
200 nm or to the edge of the continental margin
Climate:
tropical monsoon; cloudy, rainy, hot, humid summers (southwest monsoon, June to September); less cloudy, scant rainfall, mild temperatures, lower humidity during winter (northeast monsoon, December to April)
Terrain:
central lowlands ringed by steep, rugged highlands
Elevation:
highest point:
Gamlang Razi 5,870 m
lowest point:
Andaman Sea/Bay of Bengal 0 m
mean elevation:
702 m
Natural resources:
petroleum, timber, tin, antimony, zinc, copper, tungsten, lead, coal, marble, limestone, precious stones, natural gas, hydropower, arable land
Land use:
agricultural land:
19.2% (2018 est.)
arable land:
16.5% (2018 est.)
permanent crops:
2.2% (2018 est.)
permanent pasture:
0.5% (2018 est.)
forest:
48.2% (2018 est.)
other:
32.6% (2018 est.)
Irrigated land:
17,140 sq km (2020)
Major rivers (by length in km):
Mekong (shared with China [s], Laos, Thailand, Cambodia, and Vietnam [m]) - 4,350 km; Salween river mouth (shared with China [s] and Thailand) - 3,060 km; Irrawaddy river mouth (shared with China [s]) - 2,809 km; Chindwin - 1,158 km
note
– [s] after country name indicates river source; [m] after country name indicates river mouth
Major watersheds (area sq km): Indian Ocean drainage:
Brahmaputra (651,335 sq km), Ganges (1,016,124 sq km), Irrawaddy (413,710 sq km), Salween (271,914 sq km)
Pacific Ocean drainage:
Mekong (805,604 sq km)
Population distribution:
population concentrated along coastal areas and in general proximity to the shores of the Irrawaddy River; the extreme north is relatively underpopulated
Natural hazards:
destructive earthquakes and cyclones; flooding and landslides common during rainy season (June to September); periodic droughts
Geography - note:
strategic location near major Indian Ocean shipping lanes; the north-south flowing Irrawaddy River is the country’s largest and most important commercial waterway','16c72421e3548d7687a08e9ecdf6443b20de7311e567ae5e223eb7f21e987b9d','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1ac3aa7d6700832c367caaa62940292ed6e25c88c3dd93dc69c605b4b323403a',2025,'BI','Burundi','geography',38,'Location:
Central Africa, east of the Democratic Republic of the Congo, west of Tanzania
Geographic coordinates:
3 30 S, 30 00 E
Map references:
Africa
Area:
total:
27,830 sq km
land:
25,680 sq km
water:
2,150 sq km
comparison ranking:
total 146
Area - comparative:
slightly smaller than Maryland
Land boundaries:
total:
1,140 km
border countries (3):
Democratic Republic of the Congo 236 km; Rwanda 315 km; Tanzania 589 km
Coastline:
0 km (landlocked)
Maritime claims:
none (landlocked)
Climate:
equatorial; high plateau with considerable altitude variation (772 m to 2,670 m above sea level); average annual temperature varies with altitude from 23 to 17 degrees Celsius but is generally moderate as the average altitude is about 1,700 m; average annual rainfall is about 150 cm; two wet seasons (February to May and September to November), and two dry seasons (June to August and December to January)
Terrain:
hilly and mountainous, dropping to a plateau in east, some plains
Elevation:
highest point:
unnamed elevation on Mukike Range 2,685 m
lowest point:
Lake Tanganyika 772 m
mean elevation:
1,504 m
Natural resources:
nickel, uranium, rare earth oxides, peat, cobalt, copper, platinum, vanadium, arable land, hydropower, niobium, tantalum, gold, tin, tungsten, kaolin, limestone
Land use:
agricultural land:
73.3% (2018 est.)
arable land:
38.9% (2018 est.)
permanent crops:
15.6% (2018 est.)
permanent pasture:
18.8% (2018 est.)
forest:
6.6% (2018 est.)
other:
20.1% (2018 est.)
Irrigated land:
230 sq km (2012)
Major lakes (area sq km):
fresh water lake(s):
Lake Tanganyika (shared with Democratic Republic of Congo, Tanzania, and Zambia) - 32,000 sq km
Major watersheds (area sq km): Atlantic Ocean drainage:
Congo (3,730,881 sq km), (Mediterranean Sea) Nile (3,254,853 sq km)
Population distribution:
one of Africa’s most densely populated countries; concentrations tend to be in the north and along the northern shore of Lake Tanganyika in the west; most people live on farms near areas of fertile volcanic soil as shown in this population distribution map
Natural hazards:
flooding; landslides; drought
Geography - note:
landlocked; straddles crest of the Nile-Congo watershed; the Kagera, which drains into Lake Victoria, is the most remote headstream of the White Nile','25c16e9407c43f7d00f8a5e29be4e2ed79a29b8379cfa163ff8c5f085024e1e7','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f08dc81564967e6a53f7db777c1a436b00cd2a2a6de0e7d9f594b06705f3ffba',2025,'CV','Cabo Verde','geography',2,'Location:
Western Africa, group of islands in the North Atlantic Ocean, west of Senegal
Geographic coordinates:
16 00 N, 24 00 W
Map references:
Africa
Area:
total:
4,033 sq km
land:
4,033 sq km
water:
0 sq km
comparison ranking:
total 175
Area - comparative:
slightly larger than Rhode Island
Land boundaries:
total:
0 km
Coastline:
965 km
Maritime claims:
territorial sea:
12 nm
contiguous zone:
24 nm
exclusive economic zone:
200 nm
measured from claimed archipelagic baselines
Climate:
temperate; warm, dry summer; precipitation meager and erratic
Terrain:
steep, rugged, rocky, volcanic
Elevation:
highest point:
Mt. Fogo (a volcano on Fogo Island) 2,829 m
lowest point:
Atlantic Ocean 0 m
Natural resources:
salt, basalt rock, limestone, kaolin, fish, clay, gypsum
Land use:
agricultural land:
18.6% (2018 est.)
arable land:
11.7% (2018 est.)
permanent crops:
0.7% (2018 est.)
permanent pasture:
6.2% (2018 est.)
forest:
21% (2018 est.)
other:
60.4% (2018 est.)
Irrigated land:
35 sq km (2012)
Population distribution:
among the nine inhabited islands, population distribution is variable; islands in the east are very dry and are only sparsely settled to exploit their extensive salt deposits; the more southerly islands receive more precipitation and support larger populations, but agriculture and livestock grazing have damaged the soil fertility and vegetation; approximately half of the population lives on Sao Tiago Island, which is the location of the capital of Praia; Mindelo, on the northern island of Sao Vicente, also has a large urban population as shown in this population distribution map
Natural hazards:
prolonged droughts; seasonal harmattan wind produces obscuring dust; volcanically and seismically active
volcanism:
Fogo (2,829 m), which last erupted in 1995, is Cabo Verde’s only active volcano
Geography - note:
strategic location 500 km from west coast of Africa near major north-south sea routes; important communications station; important sea and air refueling site; one of four North Atlantic archipelagos that make up Macaronesia; the others are Azores (Portugal), Canary Islands (Spain), and Madeira (Portugal)','20084e15e456c09c3af2964624b5ff37125a4d367a2e3f4d6a1f58c938f3daf1','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3955140b524dbc23b57a61b11a3c1d71c280c7ad6805fe7684bbf0e3933629d1',2025,'KH','Cambodia','geography',13,'Location:
Southeastern Asia, bordering the Gulf of Thailand, between Thailand, Vietnam, and Laos
Geographic coordinates:
13 00 N, 105 00 E
Map references:
Southeast Asia
Area:
total:
181,035 sq km
land:
176,515 sq km
water:
4,520 sq km
comparison ranking:
total 90
Area - comparative:
one and a half times the size of Pennsylvania; slightly smaller than Oklahoma
Land boundaries:
total:
2,530 km
border countries (3):
Laos 555 km; Thailand 817 km; Vietnam 1158 km
Coastline:
443 km
Maritime claims:
territorial sea:
12 nm
contiguous zone:
24 nm
exclusive economic zone:
200 nm
continental shelf:
200 nm
Climate:
tropical; rainy, monsoon season (May to November); dry season (December to April); little seasonal temperature variation
Terrain:
mostly low, flat plains; mountains in southwest and north
Elevation:
highest point:
Phnum Aoral 1,810 m
lowest point:
Gulf of Thailand 0 m
mean elevation:
126 m
Natural resources:
oil and gas, timber, gemstones, iron ore, manganese, phosphates, hydropower potential, arable land
Land use:
agricultural land:
32.1% (2018 est.)
arable land:
22.7% (2018 est.)
permanent crops:
0.9% (2018 est.)
permanent pasture:
8.5% (2018 est.)
forest:
56.5% (2018 est.)
other:
11.4% (2018 est.)
Irrigated land:
3,540 sq km (2012)
Major lakes (area sq km):
fresh water lake(s):
Tonle Sap - 2,700-16,000 sq km
Major rivers (by length in km):
Mekong (shared with China [s], Burma, Thailand, Laos, and Vietnam [m]) - 4,350 km
note – [s] after country name indicates river source; [m] after country name indicates river mouth
Major watersheds (area sq km): Pacific Ocean drainage:
Mekong (805,604 sq km)
Population distribution:
population concentrated in the southeast, particularly in and around the capital of Phnom Penh; further distribution is linked closely to the Tonle Sap and Mekong Rivers
Natural hazards:
monsoonal rains (June to November); flooding; occasional droughts
Geography - note:
a land of paddies and forests dominated by the Mekong River and Tonle Sap (Southeast Asia’s largest freshwater lake)','8e4f8633fc72d1f900b14ea492b19fe052cac5f1a0572e0b578ffe8ad2e368c3','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f5a7e94b01f44b4796e0cea95b63c7186bc19034bbacdb9b9b38e158035e78c3',2025,'CM','Cameroon','geography',24,'Location:
Central Africa, bordering the Bight of Biafra, between Equatorial Guinea and Nigeria
Geographic coordinates:
6 00 N, 12 00 E
Map references:
Africa
Area:
total:
475,440 sq km
land:
472,710 sq km
water:
2,730 sq km
comparison ranking:
total 56
Area - comparative:
slightly larger than California; about four times the size of Pennsylvania
Land boundaries:
total:
5,018 km
border countries (6):
Central African Republic 901 km; Chad 1,116 km; Republic of the Congo 494 km; Equatorial Guinea 183 km; Gabon 349 km; Nigeria 1975 km
Coastline:
402 km
Maritime claims:
territorial sea:
12 nm
contiguous zone:
24 nm
Climate:
varies with terrain, from tropical along coast to semiarid and hot in north
Terrain:
diverse, with coastal plain in southwest, dissected plateau in center, mountains in west, plains in north
Elevation:
highest point:
Fako on Mont Cameroun 4,045 m
lowest point:
Atlantic Ocean 0 m
mean elevation:
667 m
Natural resources:
petroleum, bauxite, iron ore, timber, hydropower
Land use:
agricultural land:
20.6% (2018 est.)
arable land:
13.1% (2018 est.)
permanent crops:
3.3% (2018 est.)
permanent pasture:
4.2% (2018 est.)
forest:
41.7% (2018 est.)
other:
37.7% (2018 est.)
Irrigated land:
290 sq km (2012)
Major lakes (area sq km):
fresh water lake(s):
Lake Chad (endorheic lake shared with Niger, Nigeria, and Chad) - 10,360-25,900 sq km note - area varies by season and year to year
Major watersheds (area sq km): Atlantic Ocean drainage:
Congo (3,730,881 sq km), Niger (2,261,741 sq km)
Internal
(endorheic basin)
drainage:
Lake Chad (2,497,738 sq km)
Major aquifers:
Lake Chad Basin
Population distribution:
population concentrated in the west and north, with the interior of the country sparsely populated as shown in this population distribution map
Natural hazards:
volcanic activity with periodic releases of poisonous gases from Lake Nyos and Lake Monoun volcanoes
volcanism:
Mt. Cameroon (4,095 m), which last erupted in 2000, is the most frequently active volcano in West Africa; lakes in Oku volcanic field have released fatal levels of gas on occasion, killing some 1,700 people in 1986
Geography - note:
sometimes referred to as the hinge of Africa because of its central location on the continent and its position at the west-south juncture of the Gulf of Guinea; throughout the country there are areas of thermal springs and indications of current or prior volcanic activity; Mount Cameroon, the highest mountain in Sub-Saharan west Africa, is an active volcano','239fff178a02beac80511f0fde09dcd9b2366ec3e6d488a4da17239b96ca429f','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('11d79b448821c352361354d32de918fb1ef664bea7410be5ac5064d00ffe8e40',2025,'CA','Canada','geography',36,'Location:
Northern North America, bordering the North Atlantic Ocean on the east, North Pacific Ocean on the west, and the Arctic Ocean on the north, north of the conterminous US
Geographic coordinates:
60 00 N, 95 00 W
Map references:
North America
Area:
total:
9,984,670 sq km
land:
9,093,507 sq km
water:
891,163 sq km
comparison ranking:
total 3
Area - comparative:
slightly larger than the US
Land boundaries:
total:
8,892 km
border countries:
US 8,891 km (includes 2,475 km with Alaska); Denmark (Greenland) 1.3 km
Coastline:
202,080 km
note:
the Canadian Arctic Archipelago - consisting of 36,563 islands, several of them some of the world’s largest - contributes to Canada easily having the longest coastline in the world
Maritime claims:
territorial sea:
12 nm
contiguous zone:
24 nm
exclusive economic zone:
200 nm
continental shelf:
200 nm or to the edge of the continental margin
Climate:
varies from temperate in south to subarctic and arctic in north
Terrain:
mostly plains with mountains in west, lowlands in southeast
Elevation:
highest point:
Mount Logan 5,959 m
lowest point:
Atlantic/Pacific/Arctic Oceans 0 m
mean elevation:
487 m
Natural resources:
bauxite, iron ore, nickel, zinc, copper, gold, lead, uranium, rare earth elements, molybdenum, potash, diamonds, silver, fish, timber, wildlife, coal, petroleum, natural gas, hydropower
Land use:
agricultural land:
6.8% (2018 est.)
arable land:
4.7% (2018 est.)
permanent crops:
0.5% (2018 est.)
permanent pasture:
1.6% (2018 est.)
forest:
34.1% (2018 est.)
other:
59.1% (2018 est.)
Irrigated land:
9,045 sq km (2015)
Major lakes (area sq km):
fresh water lake(s):
Huron* - 35,972 sq km; Great Bear Lake - 31,328 sq km; Superior* - 28,754 sq km; Great Slave Lake - 28,568 sq km; Lake Winnipeg - 24,387 sq km; Erie* - 12,776 sq km; Ontario* - 9,790 sq km; Lake Athabasca - 7,935 sq km; Reindeer Lake - 6,650 sq km; Nettilling Lake - 5,542 sq km
note - Great Lakes* area shown as Canadian waters
Major rivers (by length in km):
Mackenzie - 4, 241 km; Yukon river source (shared with the US [m]) - 3,185 km; Saint Lawrence river mouth (shared with US) - 3,058 km; Nelson - 2,570 km; Columbia river source (shared with the US [m]) - 1,953 km; Churchill - 1,600 km; Fraser - 1,368 km; Ottawa - 1,271 km; Athabasca - 1,231 km; North Saskatchewan - 1,220 km; Liard - 1,115 km
note – [s] after country name indicates river source; [m] after country name indicates river mouth
Major watersheds (area sq km): Atlantic Ocean drainage:
Mississippi*
(Gulf of Mexico)
(3,202,185 sq km, Canada only 32,000 sq km), Nelson
(Hudson Bay)
(1,093,141 sq km), Saint Lawrence* (1,049,636 sq km, Canada only 839,200 sq km)
Arctic Ocean drainage: Mackenzie (1,706,388 sq km)
Pacific Ocean drainage: Yukon* (847,620 sq km, Canada only 823,800 sq km), Columbia* (657,501 sq km, Canada only 103,000 sq km)
note - watersheds shared with the US shown with *
Major aquifers:
Northern Great Plains Aquifer
Population distribution:
vast majority of Canadians are positioned in a discontinuous band within approximately 300 km of the southern border with the United States; the most populated province is Ontario, followed by Quebec and British Columbia
Natural hazards:
continuous permafrost in north is a serious obstacle to development; cyclonic storms form east of the Rocky Mountains, a result of the mixing of air masses from the Arctic, Pacific, and North American interior, and produce most of the country’s rain and snow east of the mountains
volcanism:
the vast majority of volcanoes in Western Canada’s Coast Mountains remain dormant
Geography - note:
note 1:
second-largest country in world (after Russia) and largest in the Americas; strategic location between Russia and US via north polar route; approximately 90% of the population is concentrated within 160 km (100 mi) of the US border
note 2:
Canada has more fresh water than any other country and almost 9% of Canadian territory is water; Canada has at least 2 million and possibly over 3 million lakes - that is more than all other countries combined','9676f769785a798e2b35a33d9992b6d3921e0add70b808624afc7f8ca5b6d03b','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6c5a76dfc722749d804637124c0039dc372835afb65d55479d232509ecc52892',2025,'KY','Cayman Islands','geography',49,'Location:
Caribbean, three-island group (Grand Cayman, Cayman Brac, Little Cayman) in Caribbean Sea, 240 km south of Cuba and 268 km northwest of Jamaica
Geographic coordinates:
19 30 N, 80 30 W
Map references:
Central America and the Caribbean
Area:
total:
264 sq km
land:
264 sq km
water:
0 sq km
comparison ranking:
total 210
Area - comparative:
1.5 times the size of Washington, DC
Land boundaries:
total:
0 km
Coastline:
160 km
Maritime claims:
territorial sea:
12 nm
exclusive economic zone:
200 nm
exclusive fishing zone:
200 nm
Climate:
tropical marine; warm, rainy summers (May to October) and cool, relatively dry winters (November to April)
Terrain:
low-lying limestone base surrounded by coral reefs
Elevation:
highest point:
1 km SW of The Bluff on Cayman Brac 50 m
lowest point:
Caribbean Sea 0 m
Natural resources:
fish, climate and beaches that foster tourism
Land use:
agricultural land:
11.2% (2018 est.)
arable land:
0.8% (2018 est.)
permanent crops:
2.1% (2018 est.)
permanent pasture:
8.3% (2018 est.)
forest:
52.9% (2018 est.)
other:
35.9% (2018 est.)
Population distribution:
majority of the population resides on Grand Cayman
Natural hazards:
hurricanes (July to November)
Geography - note:
important location between Cuba and Central America','8482bcd1d22fce9a1c12d72a91d1b0236d02610d7d4e27dab4fc605ba90264ce','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('64ab0b39385b8624cefe94345092814215ff6a427bab45b927bd5deffcbb0338',2025,'CF','Central African Republic','geography',60,'Location:
Central Africa, north of Democratic Republic of the Congo
Geographic coordinates:
7 00 N, 21 00 E
Map references:
Africa
Area:
total:
622,984 sq km
land:
622,984 sq km
water:
0 sq km
comparison ranking:
total 47
Area - comparative:
slightly smaller than Texas; about four times the size of Georgia
Land boundaries:
total:
5,920 km
border countries (5):
Cameroon 901 km; Chad 1556 km; Democratic Republic of the Congo 1,747 km, Republic of the Congo 487 km; South Sudan 1055 km; Sudan 174 km
Coastline:
0 km (landlocked)
Maritime claims:
none (landlocked)
Climate:
tropical; hot, dry winters; mild to hot, wet summers
Terrain:
vast, flat to rolling plateau; scattered hills in northeast and southwest
Elevation:
highest point:
Mont Ngaoui 1,410 m
lowest point:
Oubangui River 335 m
mean elevation:
635 m
Natural resources:
diamonds, uranium, timber, gold, oil, hydropower
Land use:
agricultural land:
8.1% (2018 est.)
arable land:
2.9% (2018 est.)
permanent crops:
0.1% (2018 est.)
permanent pasture:
5.1% (2018 est.)
forest:
36.2% (2018 est.)
other:
55.7% (2018 est.)
Irrigated land:
10 sq km (2012)
Major rivers (by length in km):
Oubangui (Ubangi) river [s] (shared with Democratic Republic of Congo and Republic of Congo [m]) - 2,270 km
note – [s] after country name indicates river source; [m] after country name indicates river mouth
Major watersheds (area sq km):
Atlantic Ocean drainage: Congo (3,730,881 sq km), (Mediterranean Sea) Nile (3,254,853 sq km) Internal (endorheic basin) drainage: Lake Chad (2,497,738 sq km)
Major aquifers:
Congo Basin, Lake Chad Basin
Population distribution:
majority of residents live in the western and central areas of the country, especially in and around the capital of Bangui as shown in this population distribution map
Natural hazards:
hot, dry, dusty harmattan winds affect northern areas; floods are common
Geography - note:
landlocked; almost the precise center of Africa','446cb2d0894b274bbeb64f11b4e1ea8ccc0ee0beee0c683634d4bdfdb8845016','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6dd019d5b10c431c762aa98b812983e5964501acc436d97bb4c8d3b58d7f8f09',2025,'TD','Chad','geography',2,'Location:
Central Africa, south of Libya
Geographic coordinates:
15 00 N, 19 00 E
Map references:
Africa
Area:
total:
1.284 million sq km
land:
1,259,200 sq km
water:
24,800 sq km
comparison ranking:
total 22
Area - comparative:
almost nine times the size of New York state; slightly more than three times the size of California
Land boundaries:
total:
6,406 km
border countries (6):
Cameroon 1,116 km; Central African Republic 1,556 km; Libya 1,050 km; Niger 1,196 km; Nigeria 85 km; Sudan 1,403 km
Coastline:
0 km (landlocked)
Maritime claims:
none (landlocked)
Climate:
tropical in south, desert in north
Terrain:
broad, arid plains in center, desert in north, mountains in northwest, lowlands in south
Elevation:
highest point:
Emi Koussi 3,445 m
lowest point:
Djourab 160 m
mean elevation:
543 m
Natural resources:
petroleum, uranium, natron, kaolin, fish (Lake Chad), gold, limestone, sand and gravel, salt
Land use:
agricultural land:
39.6% (2018 est.)
arable land:
3.9% (2018 est.)
permanent crops:
0% (2018 est.)
permanent pasture:
35.7% (2018 est.)
forest:
9.1% (2018 est.)
other:
51.3% (2018 est.)
Irrigated land:
300 sq km (2012)
Major lakes (area sq km):
fresh water lake(s):
Lake Chad (endorheic lake shared with Niger, Nigeria, and Cameroon) - 10,360-25,900 sq km
note - area varies by season and year to year
Major watersheds (area sq km): Atlantic Ocean drainage:
Niger (2,261,741 sq km)
Internal
(endorheic basin)
drainage:
Lake Chad (2,497,738 sq km)
Major aquifers:
Lake Chad Basin, Nubian Aquifer System
Population distribution:
the population is unevenly distributed due to contrasts in climate and physical geography; the highest density is found in the southwest, particularly around Lake Chad and points south; the dry Saharan zone to the north is the least densely populated as shown in this population distribution map
Natural hazards:
hot, dry, dusty harmattan winds occur in north; periodic droughts; locust plagues
Geography - note:
note 1:
Chad is the largest of Africa’s 16 landlocked countries
note 2:
not long ago - geologically speaking - what is today the Sahara was green savannah teeming with wildlife; during the African Humid Period, roughly 11,000 to 5,000 years ago, a vibrant animal community, including elephants, giraffes, hippos, and antelope lived there; the last remnant of the “Green Sahara” exists in the Lakes of Ounianga (oo-nee-ahn-ga) in northern Chad, a series of 18 interconnected freshwater, saline, and hypersaline lakes now protected as a World Heritage site
note 3:
Lake Chad, the most significant water body in the Sahel, is a remnant of a former inland sea, paleolake Mega-Chad; at its greatest extent, sometime before 5000 B.C., Lake Mega-Chad was the largest of four Saharan paleolakes that existed during the African Humid Period; it covered an area of about 400,000 sq km (150,000 sq mi), roughly the size of today’s Caspian Sea','5f0f47d993867420a05bf792986474d58eeace90a1e86a167aa228d34173d43f','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('58eb2a5cbf65e2aabeaa8d5fd4c8fc21b3f5216df590a5ec32cc2de3e9e21941',2025,'CL','Chile','geography',14,'Location:
Southern South America, bordering the South Pacific Ocean, between Argentina and Peru
Geographic coordinates:
30 00 S, 71 00 W
Map references:
South America
Area:
total:
756,102 sq km
land:
743,812 sq km
water:
12,290 sq km
note:
includes Easter Island (Isla de Pascua) and Isla Sala y Gomez
comparison ranking:
total 39
Area - comparative:
slightly smaller than twice the size of Montana
Land boundaries:
total:
7,801 km
border countries (3):
Argentina 6,691 km; Bolivia 942 km; Peru 168 km
Coastline:
6,435 km
Maritime claims:
territorial sea:
12 nm
contiguous zone:
24 nm
exclusive economic zone:
200 nm
continental shelf:
200/350 nm
Climate:
temperate; desert in north; Mediterranean in central region; cool and damp in south
Terrain:
low coastal mountains, fertile central valley, rugged Andes in east
Elevation:
highest point:
Nevado Ojos del Salado 6,893 m (highest volcano in the world)
lowest point:
Pacific Ocean 0 m
mean elevation:
1,871 m
Natural resources:
copper, timber, iron ore, nitrates, precious metals, molybdenum, hydropower
Land use:
agricultural land:
21.1% (2018 est.)
arable land:
1.7% (2018 est.)
permanent crops:
0.6% (2018 est.)
permanent pasture:
18.8% (2018 est.)
forest:
21.9% (2018 est.)
other:
57% (2018 est.)
Irrigated land:
11,100 sq km (2012)
Major lakes (area sq km):
fresh water lake(s):
Lago General Carrera (shared with Argentina) - 2,240 sq km; Lago O’Higgins (shared with Argentina) - 1,010 sq km; Lago Llanquihue - 800 sq km; Lago Fagnano (shared with Argentina) - 590 sq km
Population distribution:
90% of the population is located in the middle third of the country around the capital of Santiago; the far north (anchored by the Atacama Desert) and the extreme south are relatively underpopulated
Natural hazards:
severe earthquakes; active volcanism; tsunamis
volcanism:
significant volcanic activity due to more than three-dozen active volcanoes along the Andes Mountains; Lascar (5,592 m), which last erupted in 2007, is the most active volcano in the northern Chilean Andes; Llaima (3,125 m) in central Chile, which last erupted in 2009, is another of the country’s most active; Chaiten’s 2008 eruption forced major evacuations; other notable historically active volcanoes include Cerro Hudson, Calbuco, Copahue, Guallatiri, Llullaillaco, Nevados de Chillan, Puyehue, San Pedro, and Villarrica; see note 2 under “Geography - note”
Geography - note:
note 1:
the longest north-south trending country in the world, extending across 39 degrees of latitude; strategic location relative to sea lanes between the Atlantic and Pacific Oceans (Strait of Magellan, Beagle Channel, Drake Passage)
note 2:
Chile is one of the countries along the Ring of Fire, a belt of active volcanoes and earthquake epicenters bordering the Pacific Ocean; up to 90% of the world’s earthquakes and some 75% of the world’s volcanoes occur within the Ring of Fire
note 3:
the Atacama Desert - the driest desert in the world - spreads across the northern part of the country; Ojos del Salado (6,893 m) in the Atacama Desert is the highest active volcano in the world, Chile’s tallest mountain, and the second highest in the Western Hemisphere and the Southern Hemisphere - its small crater lake (at 6,390 m) is the world’s highest lake','c35d3318e16c8b5be4f2305745522c3b614e33acffc412586d5553219aa98569','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9d28b9cb8e6f3b7122f750858fb608ddce29bea021209984faf076101cdccdf1',2025,'CN','China','geography',26,'Location:
Eastern Asia, bordering the East China Sea, Korea Bay, Yellow Sea, and South China Sea, between North Korea and Vietnam
Geographic coordinates:
35 00 N, 105 00 E
Map references:
Asia
Area:
total:
9,596,960 sq km
land:
9,326,410 sq km
water:
270,550 sq km
comparison ranking:
total 5
Area - comparative:
slightly smaller than the US
Land boundaries:
total:
22,457 km
border countries (14):
Afghanistan 91 km; Bhutan 477 km; Burma 2,129 km; India 2,659 km; Kazakhstan 1,765 km; North Korea 1,352 km; Kyrgyzstan 1,063 km; Laos 475 km; Mongolia 4,630 km; Nepal 1,389 km; Pakistan 438 km; Russia (northeast) 4,133 km and Russia (northwest) 46 km; Tajikistan 477 km; Vietnam 1,297 km
Coastline:
14,500 km
Maritime claims:
territorial sea:
12 nm
contiguous zone:
24 nm
exclusive economic zone:
200 nm
continental shelf:
200 nm or to the edge of the continental margin
Climate:
extremely diverse; tropical in south to subarctic in north
Terrain:
mostly mountains, high plateaus, deserts in west; plains, deltas, and hills in east
Elevation:
highest point:
Mount Everest (highest peak in Asia and highest point on earth above sea level) 8,849 m
lowest point:
Turpan Pendi (Turfan Depression) -154 m
mean elevation:
1,840 m
Natural resources:
coal, iron ore, helium, petroleum, natural gas, arsenic, bismuth, cobalt, cadmium, ferrosilicon, gallium, germanium, hafnium, indium, lithium, mercury, tantalum, tellurium, tin, titanium, tungsten, antimony, manganese, magnesium, molybdenum, selenium, strontium, vanadium, magnetite, aluminum, lead, zinc, rare earth elements, uranium, hydropower potential (world’s largest), arable land
Land use:
agricultural land:
54.7% (2018 est.)
arable land:
11.3% (2018 est.)
permanent crops:
1.6% (2018 est.)
permanent pasture:
41.8% (2018 est.)
forest:
22.3% (2018 est.)
other:
23% (2018 est.)
Irrigated land:
690,070 sq km (2012)
Major lakes (area sq km):
fresh water lake(s):
Dongting Hu - 3,100 sq km; Poyang Hu - 3,350 sq km; Hongze Hu - 2,700 sq km; Tai Hu - 2,210 sq km; Hulun Nur - 1,590
salt water lake(s):
Quinghai Hu - 4,460 sq km; Nam Co - 2,500 sq km; Siling Co - 1,860 sq km; Tangra Yumco - 1,400 sq km; Bosten Hu 1,380 sq km
Major rivers (by length in km):
Yangtze - 6,300 km; Huang He - 5,464 km; Amur river source (shared with Mongolia and Russia [m]) - 4,444 km; Lancang Jiang (Mekong) river source (shared with Burma, Laos, Thailand, Cambodia, and Vietnam [m]) - 4,350 km; Yarlung Zangbo Jiang (Brahmaputra) river source (shared with India and Bangladesh [m]) - 3,969 km; Yin-tu Ho (Indus) river source (shared with India and Pakistan [m]) - 3,610 km; Nu Jiang (Salween) river source (shared with Thailand and Burma [m]) - 3,060 km; Irrawaddy river source (shared with Burma [m]) - 2,809 km; Zhu Jiang (Pearl) (shared with Vietnam [s]) - 2,200 km; Yuan Jiang (Red river) source (shared with Vietnam [m]) - 1,149 km
note – [s] after country name indicates river source; [m] after country name indicates river mouth
Major watersheds (area sq km): Pacific Ocean drainage:
Amur (1,929,955 sq km), Huang He (944,970 sq km), Mekong (805,604 sq km), Yangtze (1,722,193 sq km)
Indian Ocean drainage:
Brahmaputra (651,335 sq km), Ganges (1,016,124 sq km), Indus (1,081,718 sq km), Irrawaddy (413,710 sq km), Salween (271,914 sq km)
Arctic Ocean drainage:
Ob (2,972,493 sq km)
Internal
(endorheic basin)
drainage:
Tarim Basin (1,152,448 sq km), Amu Darya (534,739 sq km), Syr Darya (782,617 sq km), Lake Balkash (510,015 sq km)
Major aquifers:
North China Aquifer System (Huang Huai Hai Plain), Song-Liao Plain, Tarim Basin
Population distribution:
overwhelming majority of the population is found in the eastern half of the country; the west, with its vast mountainous and desert areas, remains sparsely populated; though ranked first in the world in total population, overall density is less than that of many other countries in Asia and Europe; high population density is found along the Yangtze and Yellow River valleys, the Xi Jiang River delta, the Sichuan Basin (around Chengdu), in and around Beijing, and the industrial area around Shenyang
Natural hazards:
frequent typhoons (about five per year along southern and eastern coasts); damaging floods; tsunamis; earthquakes; droughts; land subsidence
volcanism:
China contains some historically active volcanoes including Changbaishan (also known as Baitoushan, Baegdu, or P’aektu-san), Hainan Dao, and Kunlun although most have been relatively inactive in recent centuries
Geography - note:
note 1:
world’s fourth largest country (after Russia, Canada, and US) and largest country situated entirely in Asia; Mount Everest on the border with Nepal is the world’s tallest peak above sea level
note 2:
the largest cave chamber in the world is the Miao Room, in the Gebihe cave system at China’s Ziyun Getu He Chuandong National Park, which encloses some 10.78 million cu m (380.7 million cu ft) of volume; the world’s largest sinkhole is the Xiaoxhai Tiankeng sinkhole in Chongqing Municipality, which is 660 m deep, with a volume of 130 million cu m
note 3:
China appears to have been the center of domestication for two of the world’s leading cereal crops: millet in the north along the Yellow River and rice in the south along the lower or middle Yangtze River','d35abc2375b44e07e608a606b2bce1633348f704e57da12af5764384165e25b8','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('65f3b4de7407d5c3ca9daa97df01f80f6c394b0cb0510d4c2df715acbe69ef2e',2025,'CX','Christmas Island','geography',38,'Location:
Southeastern Asia, island in the Indian Ocean, south of Indonesia
Geographic coordinates:
10 30 S, 105 40 E
Map references:
Southeast Asia
Area:
total:
135 sq km
land:
135 sq km
water:
0 sq km
comparison ranking:
total 221
Area - comparative:
about three-quarters the size of Washington, DC
Land boundaries:
total:
0 km
Coastline:
138.9 km
Maritime claims:
territorial sea:
12 nm
contiguous zone:
12 nm
exclusive fishing zone:
200 nm
Climate:
tropical with a wet season (December to April) and dry season; heat and humidity moderated by trade winds
Terrain:
steep cliffs along coast rise abruptly to central plateau
Elevation:
highest point:
Murray Hill 361 m
lowest point:
Indian Ocean 0 m
Natural resources:
phosphate, beaches
Land use:
agricultural land:
0% (2018 est.)
other:
100% (2018 est.)
Population distribution:
majority of the population lives on the northern tip of the island
Natural hazards:
the narrow fringing reef surrounding the island can be a maritime hazard
Geography - note:
located along major sea lanes of the Indian Ocean','ba86a181de881e28e8559dbc4aa9e9bcb5e67625249243e323ee6da363b49448','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('66dcfb6badb9f79087b5aa73af185de0f3d2a39453c6f361430503e68d28478d',2025,'CX','Christmas Island','geography',48,'Location:
Middle America, atoll in the North Pacific Ocean, 1,120 km southwest of Mexico
Geographic coordinates:
10 17 N, 109 13 W
Map references:
Political Map of the World
Area:
total:
6 sq km
land:
6 sq km
water:
0 sq km
comparison ranking:
total 246
Area - comparative:
about 12 times the size of The Mall in Washington, DC
Land boundaries:
total:
0 km
Coastline:
11.1 km
Maritime claims:
territorial sea:
12 nm
exclusive economic zone:
200 nm
Climate:
tropical; humid, average temperature 20-32 degrees Celsius, wet season (May to October)
Terrain:
coral atoll
Elevation:
highest point:
Rocher Clipperton 29 m
lowest point:
Pacific Ocean 0 m
Natural resources:
fish
Land use:
agricultural land:
0% (2018 est.)
forest:
0% (2018 est.)
other:
100% (2018 est.)
Natural hazards:
subject to tropical storms and hurricanes from May to October
Geography - note:
the atoll reef is approximately 12 km (7.5 mi) in circumference; an attempt to colonize the atoll in the early 20th century ended in disaster and was abandoned in 1917','b890af172d369fe1e08d7077d6721a533edb99073965abd62ed37f7bef929ca9','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('75944862bee840a2f769f033d203b01cd434056355b60572bec00177104313e7',2025,'CC','Cocos (Keeling) Islands','geography',56,'Location:
Southeastern Asia, group of islands in the Indian Ocean, southwest of Indonesia, about halfway between Australia and Sri Lanka
Geographic coordinates:
12 30 S, 96 50 E
Map references:
Southeast Asia
Area:
total:
14 sq km
land:
14 sq km
water:
0 sq km
note:
includes the two main islands of West Island and Home Island
comparison ranking:
total 240
Area - comparative:
about 24 times the size of The Mall in Washington, DC
Land boundaries:
total:
0 km
Coastline:
26 km
Maritime claims:
territorial sea:
12 nm
exclusive fishing zone:
200 nm
Climate:
tropical with high humidity, moderated by the southeast trade winds for about nine months of the year
Terrain:
flat, low-lying coral atolls
Elevation:
highest point:
South Point on South Island 9 m
lowest point:
Indian Ocean 0 m
Natural resources:
fish
Land use:
agricultural land:
0% (2018 est.)
forest:
0% (2018 est.)
other:
100% (2018 est.)
Irrigated land:
NA
Population distribution:
only Home Island and West Island are populated
Natural hazards:
cyclone season is October to April
Geography - note:
note 1:
there are 27 coral islands in the group; apart from North Keeling Island, which lies 30 km north of the main group, the islands form a horseshoe-shaped atoll surrounding a lagoon; North Keeling Island was declared a national park in 1995 and is administered by Parks Australia; the population on the two inhabited islands generally is split between the ethnic Europeans on West Island and the ethnic Malays on Home Island; the islands are thickly covered with coconut palms and other vegetation
note 2:
site of a World War I naval battle in November 1914 between the Australian light cruiser HMAS Sydney and the German raider SMS Emden; after being heavily damaged in the engagement, the Emden was beached by her captain on North Keeling Island','17519a6f5acaa74f8cb30f0eb912cd345958f404a8456a52b0a2e2522e45cd95','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('03d8fd2ac1a517f97764fb7e46751cc83ca6cf97c14131f1a194af4371658756',2025,'CO','Colombia','geography',66,'Location:
Northern South America, bordering the Caribbean Sea, between Panama and Venezuela, and bordering the North Pacific Ocean, between Ecuador and Panama
Geographic coordinates:
4 00 N, 72 00 W
Map references:
South America
Area:
total:
1,138,910 sq km
land:
1,038,700 sq km
water:
100,210 sq km
note:
includes Isla de Malpelo, Roncador Cay, and Serrana Bank
comparison ranking:
total 27
Area - comparative:
slightly less than twice the size of Texas
Land boundaries:
total:
6,672 km
border countries (5):
Brazil 1,790 km; Ecuador 708 km; Panama 339 km; Peru 1,494 km; Venezuela 2,341 km
Coastline:
3,208 km (Caribbean Sea 1,760 km, North Pacific Ocean 1,448 km)
Maritime claims:
territorial sea:
12 nm
exclusive economic zone:
200 nm
continental shelf:
200-m depth or to the depth of exploitation
Climate:
tropical along coast and eastern plains; cooler in highlands
Terrain:
flat coastal lowlands, central highlands, high Andes Mountains, eastern lowland plains (Llanos)
Elevation:
highest point:
Pico Cristobal Colon 5,730 m
lowest point:
Pacific Ocean 0 m
mean elevation:
593 m
Natural resources:
petroleum, natural gas, coal, iron ore, nickel, gold, copper, emeralds, hydropower
Land use:
agricultural land:
37.5% (2018 est.)
arable land:
1.4% (2018 est.)
permanent crops:
1.6% (2018 est.)
permanent pasture:
34.5% (2018 est.)
forest:
54.4% (2018 est.)
other:
8.1% (2018 est.)
Irrigated land:
10,900 sq km (2012)
Major rivers (by length in km):
Rio Negro river source (shared with Venezuela and Brazil [m]) - 2,250 km; Orinoco (shared with Venezuela [s]) - 2,101 km
note – [s] after country name indicates river source; [m] after country name indicates river mouth
Major watersheds (area sq km): Atlantic Ocean drainage:
Amazon (6,145,186 sq km), Orinoco (953,675 sq km)
Major aquifers:
Amazon Basin
Population distribution:
the majority of people live in the north and west where agricultural opportunities and natural resources are found; the vast grasslands of the llanos to the south and east, which make up approximately 60% of the country, are sparsely populated
Natural hazards:
highlands subject to volcanic eruptions; occasional earthquakes; periodic droughts
volcanism:
Galeras (4,276 m) is one of Colombia’s most active volcanoes, having erupted in 2009 and 2010 causing major evacuations; it has been deemed a Decade Volcano by the International Association of Volcanology and Chemistry of the Earth’s Interior, worthy of study due to its explosive history and close proximity to human populations; Nevado del Ruiz (5,321 m), 129 km (80 mi) west of Bogota, erupted in 1985 producing lahars (mudflows) that killed 23,000 people; the volcano last erupted in 1991; additionally, after 500 years of dormancy, Nevado del Huila reawakened in 2007 and has experienced frequent eruptions since then; other historically active volcanoes include Cumbal, Dona Juana, Nevado del Tolima, and Purace
Geography - note:
only South American country with coastlines on both the North Pacific Ocean and Caribbean Sea','464331bafcdce9a58b1c9226c346ed80420bf15ea20d2e8d2909d7c7582482f2','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6ef4200423750a9279aab95a8663f2f3277bc72660a070efdafeeed8009c86ee',2025,'KM','Comoros','geography',2,'Location:
Southern Africa, group of islands at the northern mouth of the Mozambique Channel, about two-thirds of the way between northern Madagascar and northern Mozambique
Geographic coordinates:
12 10 S, 44 15 E
Map references:
Africa
Area:
total:
2,235 sq km
land:
2,235 sq km
water:
0 sq km
comparison ranking:
total 179
Area - comparative:
slightly more than 12 times the size of Washington, DC
Land boundaries:
total:
0 km
Coastline:
340 km
Maritime claims:
territorial sea:
12 nm
exclusive economic zone:
200 nm
Climate:
tropical marine; rainy season (November to May)
Terrain:
volcanic islands, interiors vary from steep mountains to low hills
Elevation:
highest point:
Karthala 2,360 m
lowest point:
Indian Ocean 0 m
Natural resources:
fish
Land use:
agricultural land:
84.4% (2018 est.)
arable land:
46.7% (2018 est.)
permanent crops:
29.6% (2018 est.)
permanent pasture:
8.1% (2018 est.)
forest:
1.4% (2018 est.)
other:
14.2% (2018 est.)
Irrigated land:
1.3 sq km (2012)
Population distribution:
the capital city of Maroni, located on the western side of the island of Grande Comore, is the country’s largest city; however, of the three islands that comprise Comoros, it is Anjouan that is the most densely populated as shown in this population distribution map
Natural hazards:
cyclones possible during rainy season (December to April); volcanic activity on Grand Comore
volcanism:
Karthala (2,361 m) on Grand Comore Island last erupted in 2007; a 2005 eruption forced thousands of people to be evacuated and produced a large ash cloud
Geography - note:
important location at northern end of Mozambique Channel; the only Arab League country that lies entirely in the Southern Hemisphere','6877e2bfa97eae5f30d841d7e10d18774d6b299f3114de8ac5d108bbe28bf39b','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('244d903bf3a221ce7d0c7e8e18a0c7a9b3955ec09458b4c6f83b7a8a8603aa30',2025,'KM','Comoros','geography',13,'Location:
Central Africa, northeast of Angola
Geographic coordinates:
0 00 N, 25 00 E
Map references:
Africa
Area:
total:
2,344,858 sq km
land:
2,267,048 sq km
water:
77,810 sq km
comparison ranking:
total 12
Area - comparative:
slightly less than one-fourth the size of the US
Land boundaries:
total:
11,027 km
border countries (9):
Angola 2,646 km (of which 225 km is the boundary of Angola’s discontiguous Cabinda Province); Burundi 236 km; Central African Republic 1,747 km; Republic of the Congo 1,775 km; Rwanda 221 km; South Sudan 714 km; Tanzania 479 km; Uganda 877 km; Zambia 2,332 km
Coastline:
37 km
Maritime claims:
territorial sea:
12 nm
exclusive economic zone:
since 2011, the DRC has had a Common Interest Zone agreement with Angola for the mutual development of off-shore resources
Climate:
tropical; hot and humid in equatorial river basin; cooler and drier in southern highlands; cooler and wetter in eastern highlands; north of Equator - wet season (April to October), dry season (December to February); south of Equator - wet season (November to March), dry season (April to October)
Terrain:
vast central basin is a low-lying plateau; mountains in east
Elevation:
highest point:
Pic Marguerite on Mont Ngaliema (Mount Stanley) 5,110 m
lowest point:
Atlantic Ocean 0 m
mean elevation:
726 m
Natural resources:
cobalt, copper, niobium, tantalum, petroleum, industrial and gem diamonds, gold, silver, zinc, manganese, tin, uranium, coal, hydropower, timber
note 1:
coltan, the industrial name for a columbite–tantalite mineral from which niobium and tantalum are extracted, is being linked to warfare in the Democratic Republic of the Congo; mining of coltan is mainly artisanal and small-scale and vulnerable to extortion and human trafficking; fighting over cassiterite deposits, a tin ore, is also a major cause of conflict in eastern parts of the Democratic Republic of the Congo; tantalum, tin, tungsten, and gold extracted from central Africa are considered “conflict minerals” and as such are subject to international monitoring
note 2:
the DROC is the World’s leading producer of cobalt, accounting for as much as 70% of the World’s supply; between 20-30% of this cobalt is produced in artisanal and small-scale mining operations which are vulnerable to extortion, human trafficking, and exploitative working conditions including child labor
Columbite-Tantalite:: Cobaltite:
Cassiterite:
: Land use
agricultural land:
11.4% (2018 est.)
arable land:
3.1% (2018 est.)
permanent crops:
0.3% (2018 est.)
permanent pasture:
8% (2018 est.)
forest:
67.9% (2018 est.)
other:
20.7% (2018 est.)
Irrigated land:
110 sq km (2012)
Major lakes (area sq km):
fresh water lake(s):
Lake Tanganyika (shared with Burundi, Tanzania, and Zambia) - 32,000 sq km; Lake Albert (shared with Uganda) - 5,590 sq km; Lake Mweru (shared with Zambia) - 4,350 sq km; Lac Mai-Ndombe - 2,300 sq km; Lake Kivu (shared with Rwanda) - 2,220 sq km; Lake Edward (shared with Uganda) - 2,150 sq km; Lac Tumba - 500 sq km; Lac Upemba - 530 sq km
Major rivers (by length in km):
Zaïre (Congo) river mouth (shared with Zambia [s], Angola, and Republic of Congo) - 4,700 km; Ubangi river mouth (shared with Central African Republic [s] and Republic of Congo) - 2,270 km note – [s] after country name indicates river source; [m] after country name indicates river mouth
Major watersheds (area sq km): Atlantic Ocean drainage:
Congo (3,730,881 sq km),
(Mediterranean Sea)
Nile (3,254,853 sq km)
Indian Ocean drainage:
Zambezi (1,332,412 sq km)
Major aquifers:
Congo Basin
Population distribution:
urban clusters are spread throughout the country, particularly in the northeast along the border with Uganda, Rwanda, and Burundi; the largest city is the capital, Kinshasha, located in the west along the Congo River; the south is least densely populated as shown in this population distribution map
Natural hazards:
periodic droughts in south; Congo River floods (seasonal); active volcanoes in the east along the Great Rift Valley
volcanism:
Nyiragongo (3,470 m), which erupted in 2002 and is experiencing ongoing activity, poses a major threat to the city of Goma, home to a quarter million people; the volcano produces unusually fast-moving lava, known to travel up to 100 km /hr; Nyiragongo has been deemed a Decade Volcano by the International Association of Volcanology and Chemistry of the Earth’s Interior, worthy of study due to its explosive history and close proximity to human populations; its neighbor, Nyamuragira, which erupted in 2010, is Africa’s most active volcano; Visoke is the only other historically active volcano
Geography - note:
note 1:
second largest country in Africa (after Algeria) and largest country in Sub-Saharan Africa; straddles the equator; dense tropical rain forest in central river basin and eastern highlands; the narrow strip of land that controls the lower Congo River is the DRC’s only outlet to the South Atlantic Ocean
note 2:
because of its speed, cataracts, rapids, and turbulence the Congo River, most of which flows through the DRC, has never been accurately measured along much of its length; nonetheless, it is conceded to be the deepest river in the world; estimates of its greatest depth vary between 220 and 250 meters','ee187a3f1213d0af5cb394025a509e8a2f5fb3cb4bcc3bbf5104d5ac65f9ad9b','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('14b7b32feec2c8f6674f7d81ed3bc4e7ae0b4ec11f55181c112bdfc8c3d09756',2025,'KM','Comoros','geography',25,'Location:
Central Africa, bordering the South Atlantic Ocean, between Angola and Gabon
Geographic coordinates:
1 00 S, 15 00 E
Map references:
Africa
Area:
total:
342,000 sq km
land:
341,500 sq km
water:
500 sq km
comparison ranking:
total 65
Area - comparative:
slightly smaller than Montana; about twice the size of Florida
Land boundaries:
total:
5,554 km
border countries (5):
Angola 231 km; Cameroon 494 km; Central African Republic 487 km; Democratic Republic of the Congo 1,775 km; Gabon 2,567 km
Coastline:
169 km
Maritime claims:
territorial sea:
12 nm
contiguous zone:
24 nm
exclusive economic zone:
200 nm
Climate:
tropical; rainy season (March to June); dry season (June to October); persistent high temperatures and humidity; particularly enervating climate astride the Equator
Terrain:
coastal plain, southern basin, central plateau, northern basin
Elevation:
highest point:
Mont Nabeba 1,020 m
lowest point:
Atlantic Ocean 0 m
mean elevation:
430 m
Natural resources:
petroleum, timber, potash, lead, zinc, uranium, copper, phosphates, gold, magnesium, natural gas, hydropower
Land use:
agricultural land:
31.1% (2018 est.)
arable land:
1.6% (2018 est.)
permanent crops:
0.2% (2018 est.)
permanent pasture:
29.3% (2018 est.)
forest:
65.6% (2018 est.)
other:
3.3% (2018 est.)
Irrigated land:
20 sq km (2012)
Major rivers (by length in km):
Oubangui (Ubangi) (shared with Central African Republic [s] and Democratic Republic of Congo [m]) - 2,270 km
note – [s] after country name indicates river source; [m] after country name indicates river mouth
Major watersheds (area sq km): Atlantic Ocean drainage:
Congo (3,730,881 sq km)
Major aquifers:
Congo Basin
Population distribution:
the population is primarily located in the south, in and around the capital of Brazzaville as shown in this population distribution map
Natural hazards:
seasonal flooding
Geography - note:
about 70% of the population lives in Brazzaville, Pointe-Noire, or along the railroad between them','2630345fbf5f9fd023dd5b0718a55342b925e2b3ec343a94842f659aa21eef34','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('03446ed78a92197a99d498cb2af53430d62dd8a31166c1ad8997654bdfed5f4b',2025,'CK','Cook Islands','geography',36,'Location:
Oceania, group of islands in the South Pacific Ocean, about halfway between Hawaii and New Zealand
Geographic coordinates:
21 14 S, 159 46 W
Map references:
Oceania
Area:
total:
236 sq km
land:
236 sq km
water:
0 sq km
comparison ranking:
total 214
Area - comparative:
1.3 times the size of Washington, DC
Land boundaries:
total:
0 km
Coastline:
120 km
Maritime claims:
territorial sea:
12 nm
exclusive economic zone:
200 nm
continental shelf:
200 nm or to the edge of the continental margin
Climate:
tropical oceanic; moderated by trade winds; a dry season from April to November and a more humid season from December to March
Terrain:
low coral atolls in north; volcanic, hilly islands in south
Elevation:
highest point:
Te Manga 652 m
lowest point:
Pacific Ocean 0 m
Natural resources:
coconuts (copra)
Land use:
agricultural land:
8.4% (2018 est.)
arable land:
4.2% (2018 est.)
permanent crops:
4.2% (2018 est.)
permanent pasture:
0% (2018 est.)
forest:
64.6% (2018 est.)
other:
27% (2018 est.)
Population distribution:
most of the population is found on the island of Rarotonga
Natural hazards:
tropical cyclones (November to March)
Geography - note:
the northern Cook Islands are seven low-lying, sparsely populated, coral atolls; the southern Cook Islands, where most of the population lives, consist of eight elevated, fertile, volcanic isles, including the largest, Rarotonga, at 67 sq km','5da987f3a10c74953cf064e96c93ff2a936a1a47f83a82409c8c472f5629f1f0','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3f57f4e07a896c4957391462f6f9811ccebdf3415f83b0cd67ddec287053b755',2025,'CK','Cook Islands','geography',47,'Location:
Oceania, islands in the Coral Sea, northeast of Australia
Geographic coordinates:
18 00 S, 152 00 E
Map references:
Oceania
Area:
total:
3 sq km less than
land:
3 sq km less than
water:
0 sq km
note:
includes numerous small islands and reefs scattered over a sea area of about 780,000 sq km (300,000 sq mi) with the Willis Islets the most important
comparison ranking:
total 253
Area - comparative:
about four times the size of the National Mall in Washington, DC
Land boundaries:
total:
0 km
Coastline:
3,095 km
Maritime claims:
territorial sea:
3 nm
exclusive fishing zone:
200 nm
Climate:
tropical
Terrain:
sand and coral reefs and islands (cays)
Elevation:
highest point:
unnamed location on Cato Island 9 m
lowest point:
Pacific Ocean 0 m
Natural resources:
fish
Land use:
agricultural land:
0% (2018 est.)
other:
100% (2018 est.)
Natural hazards:
occasional tropical cyclones
Geography - note:
important nesting area for birds and turtles','bc49eda2618604b6fe60257dcf5393b9fad69a82c2c2c90a1105008941d06e27','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1b430199438663e5a17cf5204e2d25c2a1279b7cc515dd65f41a63d40dfd07fe',2025,'CR','Costa Rica','geography',56,'Location:
Central America, bordering both the Caribbean Sea and the North Pacific Ocean, between Nicaragua and Panama
Geographic coordinates:
10 00 N, 84 00 W
Map references:
Central America and the Caribbean
Area:
total:
51,100 sq km
land:
51,060 sq km
water:
40 sq km
note:
includes Isla del Coco
comparison ranking:
total 129
Area - comparative:
slightly smaller than West Virginia
Land boundaries:
total:
661 km
border countries (2):
Nicaragua 313 km; Panama 348 km
Coastline:
1,290 km
Maritime claims:
territorial sea:
12 nm
exclusive economic zone:
200 nm
continental shelf:
200 nm
Climate:
tropical and subtropical; dry season (December to April); rainy season (May to November); cooler in highlands
Terrain:
coastal plains separated by rugged mountains including over 100 volcanic cones, of which several are major active volcanoes
Elevation:
highest point:
Cerro Chirripo 3,819 m
lowest point:
Pacific Ocean 0 m
mean elevation:
746 m
Natural resources:
hydropower
Land use:
agricultural land:
37.1% (2018 est.)
arable land:
4.9% (2018 est.)
permanent crops:
6.7% (2018 est.)
permanent pasture:
25.5% (2018 est.)
forest:
51.5% (2018 est.)
other:
11.4% (2018 est.)
Irrigated land:
1,015 sq km (2012)
Population distribution:
roughly half of the nation’s population resides in urban areas; the capital of San Jose is the largest city and home to approximately one-fifth of the population
Natural hazards:
occasional earthquakes, hurricanes along Atlantic coast; frequent flooding of lowlands at onset of rainy season and landslides; active volcanoes
volcanism:
Arenal (1,670 m), which erupted in 2010, is the most active volcano in Costa Rica; a 1968 eruption destroyed the town of Tabacon; Irazu (3,432 m), situated just east of San Jose, has the potential to spew ash over the capital city as it did between 1963 and 1965; other historically active volcanoes include Miravalles, Poas, Rincon de la Vieja, and Turrialba
Geography - note:
four volcanoes, two of them active, rise near the capital of San Jose in the center of the country; one of the volcanoes, Irazu, erupted destructively in 1963-65','ebd02860ccac01364fad001977ecd07779c0dc95f81ac1eb4631e9a25b101532','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cdd8b8df865da39a995660d14fe8b5224801fe238b69b0d053afb7fa6cf8d120',2025,'CR','Costa Rica','geography',68,'Location:
Western Africa, bordering the North Atlantic Ocean, between Ghana and Liberia
Geographic coordinates:
8 00 N, 5 00 W
Map references:
Africa
Area:
total:
322,463 sq km
land:
318,003 sq km
water:
4,460 sq km
comparison ranking:
total 70
Area - comparative:
slightly larger than New Mexico
Land boundaries:
total:
3,458 km
border countries (5):
Burkina Faso 545 km; Ghana 720 km; Guinea 816 km; Liberia 778 km; Mali 599 km
Coastline:
515 km
Maritime claims:
territorial sea:
12 nm
exclusive economic zone:
200 nm
continental shelf:
200 nm
Climate:
tropical along coast, semiarid in far north; three seasons - warm and dry (November to March), hot and dry (March to May), hot and wet (June to October)
Terrain:
mostly flat to undulating plains; mountains in northwest
Elevation:
highest point:
Monts Nimba 1,752 m
lowest point:
Gulf of Guinea 0 m
mean elevation:
250 m
Natural resources:
petroleum, natural gas, diamonds, manganese, iron ore, cobalt, bauxite, copper, gold, nickel, tantalum, silica sand, clay, cocoa beans, coffee, palm oil, hydropower
Land use:
agricultural land:
64.8% (2018 est.)
arable land:
9.1% (2018 est.)
permanent crops:
14.2% (2018 est.)
permanent pasture:
41.5% (2018 est.)
forest:
32.7% (2018 est.)
other:
2.5% (2018 est.)
Irrigated land:
730 sq km (2012)
Major lakes (area sq km):
salt water lake(s):
Lagune Aby - 780 sq km
Major watersheds (area sq km): Atlantic Ocean drainage:
Niger (2,261,741 sq km), Volta (410,991 sq km)
Population distribution:
the population is primarily located in the forested south, with the highest concentration of people residing in and around the cities on the Atlantic coast; most of the northern savanna remains sparsely populated with higher concentrations located along transportation corridors as shown in this population distribution map
Natural hazards:
coast has heavy surf and no natural harbors; during the rainy season torrential flooding is possible
Geography - note:
most of the inhabitants live along the sandy coastal region; apart from the capital area, the forested interior is sparsely populated','fcd56fb4040559d7f1dd196de10e2d26e852f978618ca1745bb519402dd2d676','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e44d0ff818e4d404bf6475690f68041f10f61f45c6ebdbd6df1dabcf7446e6a9',2025,'HR','Croatia','geography',2,'Location:
Southeastern Europe, bordering the Adriatic Sea, between Bosnia and Herzegovina and Slovenia
Geographic coordinates:
45 10 N, 15 30 E
Map references:
Europe
Area:
total:
56,594 sq km
land:
55,974 sq km
water:
620 sq km
comparison ranking:
total 127
Area - comparative:
slightly smaller than West Virginia
Land boundaries:
total:
2,237 km
border countries (5):
Bosnia and Herzegovina 956 km; Hungary 348 km; Montenegro 19 km; Serbia 314 km; Slovenia 600 km
Coastline:
5,835 km (mainland 1,777 km, islands 4,058 km)
Maritime claims:
territorial sea:
12 nm
continental shelf:
200-m depth or to the depth of exploitation
Climate:
Mediterranean and continental; continental climate predominant with hot summers and cold winters; mild winters, dry summers along coast
Terrain:
geographically diverse; flat plains along Hungarian border, low mountains and highlands near Adriatic coastline and islands
Elevation:
highest point:
Dinara 1,831 m
lowest point:
Adriatic Sea 0 m
mean elevation:
331 m
Natural resources:
oil, some coal, bauxite, low-grade iron ore, calcium, gypsum, natural asphalt, silica, mica, clays, salt, hydropower
Land use:
agricultural land:
23.7% (2018 est.)
arable land:
16% (2018 est.)
permanent crops:
1.5% (2018 est.)
permanent pasture:
6.2% (2018 est.)
forest:
34.4% (2018 est.)
other:
41.9% (2018 est.)
Irrigated land:
171 sq km (2020)
Major rivers (by length in km):
Dunav (Danube) (shared with Germany [s], Austria, Slovakia, Czechia, Hungary, Serbia, Bulgaria, Ukraine, Moldova, and Romania [m]) - 2,888 km
note – [s] after country name indicates river source; [m] after country name indicates river mouth
Major watersheds (area sq km): Atlantic Ocean drainage:
(Black Sea)
Danube (795,656 sq km)
Population distribution:
more of the population lives in the northern half of the country, with approximately a quarter of the populace residing in and around the capital of Zagreb; many of the islands are sparsely populated
Natural hazards:
destructive earthquakes
Geography - note:
controls most land routes from Western Europe to Aegean Sea and Turkish Straits; most Adriatic Sea islands lie off the coast of Croatia - some 1,200 islands, islets, ridges, and rocks','ef57f28aca536e0d737bd82a0e8f2544ce6ebdf027dbfd3ac275862952e28553','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6f6414811112501eaddad0164e659e607a13194f54ea93255d1afae2a292554b',2025,'CU','Cuba','geography',13,'Location:
Caribbean, island between the Caribbean Sea and the North Atlantic Ocean, 150 km south of Key West, Florida
Geographic coordinates:
21 30 N, 80 00 W
Map references:
Central America and the Caribbean
Area:
total:
110,860 sq km
land:
109,820 sq km
water:
1,040 sq km
comparison ranking:
total 106
Area - comparative:
slightly smaller than Pennsylvania
Land boundaries:
total:
28.5 km
border countries (1):
US Naval Base at Guantanamo Bay 28.5 km
note:
Guantanamo Naval Base is leased by the US and remains part of Cuba
Coastline:
3,735 km
Maritime claims:
territorial sea:
12 nm
contiguous zone:
24 nm
exclusive economic zone:
200 nm
Climate:
tropical; moderated by trade winds; dry season (November to April); rainy season (May to October)
Terrain:
mostly flat to rolling plains, with rugged hills and mountains in the southeast
Elevation:
highest point:
Pico Turquino 1,974 m
lowest point:
Caribbean Sea 0 m
mean elevation:
108 m
Natural resources:
cobalt, nickel, iron ore, chromium, copper, salt, timber, silica, petroleum, arable land
Land use:
agricultural land:
60.3% (2018 est.)
arable land:
33.8% (2018 est.)
permanent crops:
3.6% (2018 est.)
permanent pasture:
22.9% (2018 est.)
forest:
27.3% (2018 est.)
other:
12.4% (2018 est.)
Irrigated land:
8,700 sq km (2012)
Population distribution:
large population clusters found throughout the country, the more significant ones being in the larger towns and cities, particularly the capital of Havana
Natural hazards:
the east coast is subject to hurricanes from August to November (in general, the country averages about one hurricane every other year); droughts are common
Geography - note:
largest country in Caribbean and westernmost island of the Greater Antilles','9397331cc9f9435f1da4ff129a14511cbac80812d471c099de1b73727f38ee84','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fd429942ed888b36be8052283e7acb10ee4d9d6f0133edd0827cf7e10596b0c3',2025,'CU','Cuba','geography',24,'Location:
Caribbean, an island in the Caribbean Sea, 55 km off the coast of Venezuela
Geographic coordinates:
12 10 N, 69 00 W
Map references:
Central America and the Caribbean
Area:
total:
444 sq km
land:
444 sq km
water:
0 sq km
comparison ranking:
total 199
Area - comparative:
more than twice the size of Washington, DC
Land boundaries:
0
Coastline:
364 km
Maritime claims:
territorial sea:
12 nm
exclusive economic zone:
200 nm
Climate:
tropical marine climate, ameliorated by northeast trade winds, results in mild temperatures; semiarid with average rainfall of 60 cm/year
Terrain:
generally low, hilly terrain
Elevation:
highest point:
Mt. Christoffel 372 m
lowest point:
Caribbean Sea 0 m
Natural resources:
calcium phosphates, protected harbors, hot springs
Land use:
agricultural land:
10% (2018 est.)
arable land:
10% (2018)
other:
90% (2018 est.)
Population distribution:
largest concentration on the island is Willemstad; smaller settlements near the coast can be found throughout the island, particularly in the northwest
Natural hazards:
Curacao is south of the Caribbean hurricane belt and is rarely threatened
Geography - note:
Curacao is a part of the Windward Islands (southern) group in the Lesser Antilles','a164fc26135bf6e6646fa4a4942c867f5a0e490464804702dfcf954c693ebc32','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('786f712e72abc75d85c6c627af4bf30eeda4186f6233291d2aa139e651899ad7',2025,'CY','Cyprus','geography',35,'Location:
Middle East, island in the Mediterranean Sea, south of Turkey; note - Cyprus views itself as part of Europe; geopolitically, it can be classified as falling within Europe, the Middle East, or both
Geographic coordinates:
35 00 N, 33 00 E
Map references:
Middle East
Area:
total:
9,251 sq km (of which 3,355 sq km are in north Cyprus)
land:
9,241 sq km
water:
10 sq km
comparison ranking:
total 169
Area - comparative:
about 0.6 times the size of Connecticut
Land boundaries:
total:
156 km
border sovereign base areas:
Akrotiri 48 km; Dhekelia 108 km
Coastline:
648 km
Maritime claims:
territorial sea:
12 nm
contiguous zone:
24 nm
continental shelf:
200-m depth or to the depth of exploitation
Climate:
temperate; Mediterranean with hot, dry summers and cool winters
Terrain:
central plain with mountains to north and south; scattered but significant plains along southern coast
Elevation:
highest point:
Mount Olympus 1,951 m
lowest point:
Mediterranean Sea 0 m
mean elevation:
91 m
Natural resources:
copper, pyrites, asbestos, gypsum, timber, salt, marble, clay earth pigment
Land use:
agricultural land:
13.4% (2018 est.)
arable land:
9.8% (2018 est.)
permanent crops:
3.2% (2018 est.)
permanent pasture:
0.4% (2018 est.)
forest:
18.8% (2018 est.)
other:
67.8% (2018 est.)
Irrigated land:
268 sq km (2020)
Population distribution:
population concentrated in central Nicosia and in the major cities of the south: Paphos, Limassol, and Larnaca
Natural hazards:
moderate earthquake activity; droughts
Geography - note:
the third largest island in the Mediterranean Sea (after Sicily and Sardinia); several small Cypriot enclaves exist within the Dhekelia Sovereign Base Area','54cbe000fec608c7943990ac7b56ae5091e3eb63365d653e3f93ab2a87af68de','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f2535f150eed8f39afe17eeb207412f94eebce65737a05589214e7063b8ee7d8',2025,'CZ','Czechia','geography',47,'Location:
Central Europe, between Germany, Poland, Slovakia, and Austria
Geographic coordinates:
49 45 N, 15 30 E
Map references:
Europe
Area:
total:
78,867 sq km
land:
77,247 sq km
water:
1,620 sq km
comparison ranking:
total 116
Area - comparative:
about two-thirds the size of Pennsylvania; slightly smaller than South Carolina
Land boundaries:
total:
2,046 km
border countries (4):
Austria 402 km; Germany 704 km; Poland 699 km; Slovakia 241 km
Coastline:
0 km (landlocked)
Maritime claims:
none (landlocked)
Climate:
temperate; cool summers; cold, cloudy, humid winters
Terrain:
Bohemia in the west consists of rolling plains, hills, and plateaus surrounded by low mountains; Moravia in the east consists of very hilly country
Elevation:
highest point:
Snezka 1,602 m
lowest point:
Labe (Elbe) River 115 m
mean elevation:
433 m
Natural resources:
hard coal, soft coal, kaolin, clay, graphite, timber, arable land
Land use:
agricultural land:
54.8% (2018 est.)
arable land:
41% (2018 est.)
permanent crops:
1% (2018 est.)
permanent pasture:
12.8% (2018 est.)
forest:
34.4% (2018 est.)
other:
10.8% (2018 est.)
Irrigated land:
220 sq km (2020)
Major rivers (by length in km):
Dunaj (Danube) (shared with Germany [s], Austria, Slovakia, Hungary, Croatia, Serbia, Bulgaria, Ukraine, Moldova, and Romania [m]) - 2,888 km; Labe (Elbe) river source (shared with Germany [m]) - 1,252 km
note – [s] after country name indicates river source; [m] after country name indicates river mouth
Major watersheds (area sq km): Atlantic Ocean drainage:
(Black Sea)
Danube (795,656 sq km)
Population distribution:
a fairly even distribution throughout most of the country, but the northern and eastern regions tend to have larger urban concentrations
Natural hazards:
flooding
Geography - note:
note 1:
landlocked; strategically located astride some of oldest and most significant land routes in Europe; Moravian Gate is a traditional military corridor between the North European Plain and the Danube in central Europe
note 2:
the Hranice Abyss in Czechia is the world’s deepest surveyed underwater cave at 404 m (1,325 ft); its survey is not complete and it could end up being some 800-1,200 m deep','00b7099d0068b6f8dc8eb3c4894201f12f1b149a4c4708031582b077e3177b01','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('948acd8d5a9d342e0f5cd79cc49793e9296268b10f1daa47b50ee4c7983c8c0e',2025,'DK','Denmark','geography',2,'Location:
Northern Europe, bordering the Baltic Sea and the North Sea, on a peninsula north of Germany (Jutland); also includes several major islands (Sjaelland, Fyn, and Bornholm)
Geographic coordinates:
56 00 N, 10 00 E
Map references:
Europe
Area:
total:
43,094 sq km
land:
42,434 sq km
water:
660 sq km
note:
includes the island of Bornholm in the Baltic Sea and the rest of metropolitan Denmark (the Jutland Peninsula, and the major islands of Sjaelland and Fyn) but excludes the Faroe Islands and Greenland
comparison ranking:
total 133
Area - comparative:
slightly less than twice the size of Massachusetts; about two-thirds the size of West Virginia
Land boundaries:
total:
141 km
border countries:
Germany 140 km; Canada 1.3 km
Coastline:
7,314 km
Maritime claims:
territorial sea:
12 nm
contiguous zone:
24 nm
exclusive economic zone:
200 nm
continental shelf:
200-m depth or to the depth of exploitation
Climate:
temperate; humid and overcast; mild, windy winters and cool summers
Terrain:
low and flat to gently rolling plains
Elevation:
highest point:
Store Mollehoj 171 m
lowest point:
Lammefjord -7 m
mean elevation:
34 m
Natural resources:
petroleum, natural gas, fish, arable land, salt, limestone, chalk, stone, gravel and sand
Land use:
agricultural land:
63.4% (2018 est.)
arable land:
58.9% (2018 est.)
permanent crops:
0.1% (2018 est.)
permanent pasture:
4.4% (2018 est.)
forest:
12.9% (2018 est.)
other:
23.7% (2018 est.)
Irrigated land:
2,360 sq km (2020)
Population distribution:
with excellent access to the North Sea, Skagerrak, Kattegat, and the Baltic Sea, population centers tend to be along coastal areas, particularly in Copenhagen and the eastern side of the country’s mainland
Natural hazards:
flooding is a threat in some areas of the country (e.g., parts of Jutland, along the southern coast of the island of Lolland) that are protected from the sea by a system of dikes
Geography - note:
composed of the Jutland Peninsula and a group of more than 400 islands (Danish Archipelago); controls Danish Straits (Skagerrak and Kattegat) linking Baltic and North Seas; about one-quarter of the population lives in greater Copenhagen','8e1acc6c0b4e641c5e366ac05949e734d17933d4a21265b25f7db4f194357879','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f377662eb2ee5fa3e7c4c845f4f82cfc9139bd488de8ac46793c558a85580c34',2025,'DK','Denmark','geography',15,'Location:
Eastern Mediterranean, on the southeast coast of Cyprus near Famagusta
Geographic coordinates:
34 59 N, 33 45 E
Map references:
Middle East
Area:
total:
131 sq km
note:
area surrounds three Cypriot enclaves
comparison ranking:
total 222
Area - comparative:
about three-quarters the size of Washington, DC
Land boundaries:
total:
108 km
border countries (1):
Cyprus 108 km
Coastline:
27.5 km
Climate:
temperate; Mediterranean with hot, dry summers and cool winters
Geography - note:
British extraterritorial rights also extended to several small off-post sites scattered across Cyprus; several small Cypriot enclaves exist within the Sovereign Base Area (SBA); of the SBA land, 60% is privately owned and farmed, 20% is owned by the Ministry of Defense, and 20% is SBA Crown land','daf3d0d6d899856872d08c4c04771f983579c2bb546f672603e0aafb48112489','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('438d447afe34ca47b67421c8a483dd0619991c69aaabcb3a8427a43ff4346a85',2025,'DJ','Djibouti','geography',23,'Location:
Eastern Africa, bordering the Gulf of Aden and the Red Sea, between Eritrea and Somalia
Geographic coordinates:
11 30 N, 43 00 E
Map references:
Africa
Area:
total:
23,200 sq km
land:
23,180 sq km
water:
20 sq km
comparison ranking:
total 150
Area - comparative:
slightly smaller than New Jersey
Land boundaries:
total:
528 km
border countries (3):
Eritrea 125 km; Ethiopia 342 km; Somalia 61 km
Coastline:
314 km
Maritime claims:
territorial sea:
12 nm
contiguous zone:
24 nm
exclusive economic zone:
200 nm
Climate:
desert; torrid, dry
Terrain:
coastal plain and plateau separated by central mountains
Elevation:
highest point:
Moussa Ali 2,021 m
lowest point:
Lac Assal -155 m
mean elevation:
430 m
Natural resources:
potential geothermal power, gold, clay, granite, limestone, marble, salt, diatomite, gypsum, pumice, petroleum
Land use:
agricultural land:
73.4% (2018 est.)
arable land:
0.1% (2018 est.)
permanent crops:
0% (2018 est.)
permanent pasture:
73.3% (2018 est.)
forest:
0.2% (2018 est.)
other:
26.4% (2018 est.)
Irrigated land:
10 sq km (2012)
Major lakes (area sq km):
salt water lake(s):
Abhe Bad/Abhe Bid Hayk (shared with Ethiopia) - 780 sq km
Population distribution:
most densely populated areas are in the east; the largest city is Djibouti, with a population over 600,000; no other city in the country has a total population over 50,000 as shown in this population distribution map
Natural hazards:
earthquakes; droughts; occasional cyclonic disturbances from the Indian Ocean bring heavy rains and flash floods
volcanism:
experiences limited volcanic activity; Ardoukoba (298 m) last erupted in 1978; Manda-Inakir, located along the Ethiopian border, is also historically active
Geography - note:
strategic location near world’s busiest shipping lanes and close to Arabian oilfields; terminus of rail traffic into Ethiopia; mostly wasteland; Lac Assal (Lake Assal) is the lowest point in Africa and the saltiest lake in the world','3a27e656c052b0db4aa219df63d183f49d3068f4166e70f2836d3be8d9669fcf','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9cbcd808ac9ef2a0ac6be65e4534d6177775f03682fcd1b4cb68b22a6d38ca29',2025,'DM','Dominica','geography',35,'Location:
Caribbean, island between the Caribbean Sea and the North Atlantic Ocean, about halfway between Puerto Rico and Trinidad and Tobago
Geographic coordinates:
15 25 N, 61 20 W
Map references:
Central America and the Caribbean
Area:
total:
751 sq km
land:
751 sq km
water:
NEGL
comparison ranking:
total 188
Area - comparative:
slightly more than four times the size of Washington, DC
Land boundaries:
total:
0 km
Coastline:
148 km
Maritime claims:
territorial sea:
12 nm
contiguous zone:
24 nm
exclusive economic zone:
200 nm
Climate:
tropical; moderated by northeast trade winds; heavy rainfall
Terrain:
rugged mountains of volcanic origin
Elevation:
highest point:
Morne Diablotins 1,447 m
lowest point:
Caribbean Sea 0 m
Natural resources:
timber, hydropower, arable land
Land use:
agricultural land:
34.7% (2018 est.)
arable land:
8% (2018 est.)
permanent crops:
24% (2018 est.)
permanent pasture:
2.7% (2018 est.)
forest:
59.2% (2018 est.)
other:
6.1% (2018 est.)
Population distribution:
population is mosly clustered along the coast, with roughly a third living in the parish of St. George, in or around the capital of Roseau; the volcanic interior is sparsely populated
Natural hazards:
flash floods are a constant threat; destructive hurricanes can be expected during the late summer months
volcanism:
Dominica was the last island to be formed in the Caribbean some 26 million years ago, it lies in the middle of the volcanic island arc of the Lesser Antilles that extends from the island of Saba in the north to Grenada in the south; of the 16 volcanoes that make up this arc, five are located on Dominica, more than any other island in the Caribbean: Morne aux Diables (861 m), Morne Diablotins (1,430 m), Morne Trois Pitons (1,387 m), Watt Mountain (1,224 m), which last erupted in 1997, and Morne Plat Pays (940 m); the two best known volcanic features on Dominica, the Valley of Desolation and the Boiling Lake thermal areas, lie on the flanks of Watt Mountain and both are popular tourist destinations
Geography - note:
known as “The Nature Island of the Caribbean” due to its spectacular, lush, and varied flora and fauna, which are protected by an extensive natural park system; the most mountainous of the Lesser Antilles, its volcanic peaks are cones of lava craters and include Boiling Lake, the second-largest, thermally active lake in the world','aac3e34de868ab4f90769a7568e17a864f734592d5ac387579f157b7d7f87fb9','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ec218874a2d213a603bd186aa0e63d4f4941bab5e0d912942b2bdb9c3df0b14f',2025,'DO','Dominican Republic','geography',46,'Location:
Caribbean, eastern two-thirds of the island of Hispaniola, between the Caribbean Sea and the North Atlantic Ocean, east of Haiti
Geographic coordinates:
19 00 N, 70 40 W
Map references:
Central America and the Caribbean
Area:
total:
48,670 sq km
land:
48,320 sq km
water:
350 sq km
comparison ranking:
total 131
Area - comparative:
slightly more than twice the size of New Jersey
Land boundaries:
total:
376 km
border countries (1):
Haiti 376 km
Coastline:
1,288 km
Maritime claims:
territorial sea:
12 nm
contiguous zone:
24 nm
exclusive economic zone:
200 nm
continental shelf:
200 nm or to the edge of the continental margin measured from claimed archipelagic straight baselines
Climate:
tropical maritime; little seasonal temperature variation; seasonal variation in rainfall
Terrain:
rugged highlands and mountains interspersed with fertile valleys
Elevation:
highest point:
Pico Duarte 3,098 m
lowest point:
Lago Enriquillo -46 m
mean elevation:
424 m
Natural resources:
nickel, bauxite, gold, silver, arable land
Land use:
agricultural land:
51.5% (2018 est.)
arable land:
16.6% (2018 est.)
permanent crops:
10.1% (2018 est.)
permanent pasture:
24.8% (2018 est.)
forest:
40.8% (2018 est.)
other:
7.7% (2018 est.)
Irrigated land:
2,980 sq km (2018)
Major lakes (area sq km):
salt water lake(s):
Lago de Enriquillo - 500 sq km
Population distribution:
coastal development is significant, especially in the southern coastal plains and the Cibao Valley, where population density is highest; smaller population clusters exist in the interior mountains (Cordillera Central)
Natural hazards:
lies in the middle of the hurricane belt and subject to severe storms from June to October; occasional flooding; periodic droughts
Geography - note:
shares island of Hispaniola with Haiti (eastern two-thirds makes up the Dominican Republic, western one-third is Haiti); the second largest country in the Antilles (after Cuba); geographically diverse with the Caribbean’s tallest mountain, Pico Duarte, and lowest elevation and largest lake, Lago Enriquillo','b6fe7809d6276912096455d1bede03b680214e4a149a142d2de3a746fa05240b','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3fd169002296ba7913d76c618f002eb735965629bb4390a45ee3afe79063dbd7',2025,'EC','Ecuador','geography',2,'Location:
Western South America, bordering the Pacific Ocean at the Equator, between Colombia and Peru
Geographic coordinates:
2 00 S, 77 30 W
Map references:
South America
Area:
total:
283,561 sq km
land:
276,841 sq km
water:
6,720 sq km
note:
includes Galapagos Islands
comparison ranking:
total 75
Area - comparative:
slightly smaller than Nevada
Land boundaries:
total:
2,237 km
border countries (2):
Colombia 708 km; Peru 1529 km
Coastline:
2,237 km
Maritime claims:
territorial sea:
12 nm
exclusive economic zone:
200 nm
continental shelf:
200 nm
note:
Ecuador has declared its right to extend its continental shelf to 350 nm measured from the baselines of the Galapagos Archipelago
Climate:
tropical along coast, becoming cooler inland at higher elevations; tropical in Amazonian jungle lowlands
Terrain:
coastal plain (costa), inter-Andean central highlands (sierra), and flat to rolling eastern jungle (oriente)
Elevation:
highest point:
Chimborazo 6,267
lowest point:
Pacific Ocean 0 m
mean elevation:
1,117 m
note:
because the earth is not a perfect sphere and has an equatorial bulge, the highest point on the planet farthest from its center is Mount Chimborazo not Mount Everest, which is merely the highest peak above sea level
Natural resources:
petroleum, fish, timber, hydropower
Land use:
agricultural land:
29.7% (2018 est.)
arable land:
4.7% (2018 est.)
permanent crops:
5.6% (2018 est.)
permanent pasture:
19.4% (2018 est.)
forest:
38.9% (2018 est.)
other:
31.4% (2018 est.)
Irrigated land:
10,000 sq km (2020)
Major watersheds (area sq km): Atlantic Ocean drainage:
Amazon (6,145,186 sq km)
Population distribution:
nearly half of the population is concentrated in the interior in the Andean intermontane basins and valleys, with large concentrations also found along the western coastal strip; the rainforests of the east remain sparsely populated
Natural hazards:
frequent earthquakes; landslides; volcanic activity; floods; periodic droughts
volcanism:
volcanic activity concentrated along the Andes Mountains; Sangay (5,230 m), which erupted in 2010, is mainland Ecuador’s most active volcano; other historically active volcanoes in the Andes include Antisana, Cayambe, Chacana, Cotopaxi, Guagua Pichincha, Reventador, Sumaco, and Tungurahua; Fernandina (1,476 m), a shield volcano that last erupted in 2009, is the most active of the many Galapagos volcanoes; other historically active Galapagos volcanoes include Wolf, Sierra Negra, Cerro Azul, Pinta, Marchena, and Santiago
Geography - note:
note 1:
Cotopaxi in Andes is highest active volcano in world
note 2:
genetic research indicates that the cherry-sized tomato originated in Ecuador without any human domestication; later domestication in Mexico transformed the plant into the large modern tomato; archeological research indicates that the cacao tree, whose seeds are used to make chocolate and which was long thought to have originated in Mesoamerica, was first domesticated in the upper Amazon region of northwest South America - present-day Ecuador - about 3,300 B.C.','88fbe32ef31c0f596736ddde8436867c0d61d1eee7627bb571d839ba6e8dc66d','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fd89048a3f425073434920089ca374a0a90f061523fa4cad0885a3cd636b84d0',2025,'EG','Egypt','geography',14,'Location:
Northern Africa, bordering the Mediterranean Sea, between Libya and the Gaza Strip, and the Red Sea north of Sudan, and includes the Asian Sinai Peninsula
Geographic coordinates:
27 00 N, 30 00 E
Map references:
Africa
Area:
total:
1,001,450 sq km
land:
995,450 sq km
water:
6,000 sq km
comparison ranking:
total 31
Area - comparative:
more than eight times the size of Ohio; slightly more than three times the size of New Mexico
Land boundaries:
total:
2,612 km
border countries (4):
Gaza Strip 13 km; Israel 208 km; Libya 1,115 km; Sudan 1,276 km
Coastline:
2,450 km
Maritime claims:
territorial sea:
12 nm
contiguous zone:
24 nm
exclusive economic zone:
200 nm or the equidistant median line with Cyprus
continental shelf:
200 nm
Climate:
desert; hot, dry summers with moderate winters
Terrain:
vast desert plateau interrupted by Nile valley and delta
Elevation:
highest point:
Mount Catherine 2,629 m
lowest point:
Qattara Depression -133 m
mean elevation:
321 m
Natural resources:
petroleum, natural gas, iron ore, phosphates, manganese, limestone, gypsum, talc, asbestos, lead, rare earth elements, zinc
Land use:
agricultural land:
3.6% (2018 est.)
arable land:
2.8% (2018 est.)
permanent crops:
0.8% (2018 est.)
permanent pasture:
0% (2018 est.)
forest:
0.1% (2018 est.)
other:
96.3% (2018 est.)
Irrigated land:
36,500 sq km (2012)
Major lakes (area sq km):
salt water lake(s):
Lake Manzala - 1,360 sq km
note - largest of Nile Delta lakes
Major rivers (by length in km):
An Nīl (Nile) river mouth (shared with Rwanda [s], Tanzania, Uganda, South Sudan, and Sudan) - 6,650 km
note
– [s] after country name indicates river source; [m] after country name indicates river mouth
Major watersheds (area sq km): Atlantic Ocean drainage:
(Mediterranean Sea)
Nile (3,254,853 sq km)
Major aquifers:
Nubian Aquifer System
Population distribution:
approximately 95% of the population lives within 20 km of the Nile River and its delta; vast areas of the country remain sparsely populated or uninhabited as shown in this population distribution map
Natural hazards:
periodic droughts; frequent earthquakes; flash floods; landslides; hot, driving windstorms called khamsin occur in spring; dust storms; sandstorms
Geography - note:
note:
controls Sinai Peninsula, the only land bridge between Africa and remainder of Eastern Hemisphere; controls Suez Canal, a sea link between Indian Ocean and Mediterranean Sea; size, and juxtaposition to Israel, establish its major role in Middle Eastern geopolitics; dependence on upstream neighbors; dominance of Nile basin issues; prone to influxes of refugees from Sudan and the Palestinian territories','8fd5626028c6e586ab229bcd71b9921b8d3ebffba0e16e60c0e5a31b2c1adc16','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ac1d7ae508eb6a87ec5d69f97e78a8e3132e93f85d423aae26106e9a51c87215',2025,'SV','El Salvador','geography',27,'Location:
Central America, bordering the North Pacific Ocean, between Guatemala and Honduras
Geographic coordinates:
13 50 N, 88 55 W
Map references:
Central America and the Caribbean
Area:
total:
21,041 sq km
land:
20,721 sq km
water:
320 sq km
comparison ranking:
total 153
Area - comparative:
about the same size as New Jersey
Land boundaries:
total:
590 km
border countries (2):
Guatemala 199 km; Honduras 391 km
Coastline:
307 km
Maritime claims:
territorial sea:
12 nm
contiguous zone:
24 nm
exclusive economic zone:
200 nm
Climate:
tropical; rainy season (May to October); dry season (November to April); tropical on coast; temperate in uplands
Terrain:
mostly mountains with narrow coastal belt and central plateau
Elevation:
highest point:
Cerro El Pital 2,730 m
lowest point:
Pacific Ocean 0 m
mean elevation:
442 m
Natural resources:
hydropower, geothermal power, petroleum, arable land
Land use:
agricultural land:
74.7% (2018 est.)
arable land:
33.1% (2018 est.)
permanent crops:
10.9% (2018 est.)
permanent pasture:
30.7% (2018 est.)
forest:
13.6% (2018 est.)
other:
11.7% (2018 est.)
Irrigated land:
274 sq km (2020)
Population distribution:
although it is the smallest country in land area in Central America, El Salvador has a population that is 18 times larger than Belize; at least 20% of the population lives abroad; high population density country-wide, with particular concentration around the capital of San Salvador
Natural hazards:
known as the Land of Volcanoes; frequent and sometimes destructive earthquakes and volcanic activity; extremely susceptible to hurricanes
volcanism:
significant volcanic activity; San Salvador (1,893 m), which last erupted in 1917, has the potential to cause major harm to the country’s capital, which lies just below the volcano’s slopes; San Miguel (2,130 m), which last erupted in 2002, is one of the most active volcanoes in the country; other historically active volcanoes include Conchaguita, Ilopango, Izalco, and Santa Ana
Geography - note:
smallest Central American country and only one without a coastline on the Caribbean Sea','05c747b2af5b08e5ad89687a35a48cbd679bacdf5d3bd91c56ff842ed7d35743','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('535cabe475159cb3084fef2d164a7b4f1a9e33fab67ba16ab12bfb232f9d3359',2025,'GQ','Equatorial Guinea','geography',39,'Location:
Central Africa, bordering the Bight of Biafra, between Cameroon and Gabon
Geographic coordinates:
2 00 N, 10 00 E
Map references:
Africa
Area:
total:
28,051 sq km
land:
28,051 sq km
water:
0 sq km
comparison ranking:
total 145
Area - comparative:
slightly smaller than Maryland
Land boundaries:
total:
528 km
border countries (2):
Cameroon 183 km; Gabon 345 km
Coastline:
296 km
Maritime claims:
territorial sea:
12 nm
exclusive economic zone:
200 nm
Climate:
tropical; always hot, humid
Terrain:
coastal plains rise to interior hills; islands are volcanic
Elevation:
highest point:
Pico Basile 3,008 m
lowest point:
Atlantic Ocean 0 m
mean elevation:
577 m
Natural resources:
petroleum, natural gas, timber, gold, bauxite, diamonds, tantalum, sand and gravel, clay
Land use:
agricultural land:
10.1% (2018 est.)
arable land:
4.3% (2018 est.)
permanent crops:
2.1% (2018 est.)
permanent pasture:
3.7% (2018 est.)
forest:
57.5% (2018 est.)
other:
32.4% (2018 est.)
Population distribution:
only two large cities over 30,000 people (Bata on the mainland, and the capital Malabo on the island of Bioko); small communities are scattered throughout the mainland and the five inhabited islands as shown in this population distribution map
Natural hazards:
violent windstorms; flash floods
volcanism:
Santa Isabel (3,007 m), which last erupted in 1923, is the country’s only historically active volcano; Santa Isabel, along with two dormant volcanoes, form Bioko Island in the Gulf of Guinea
Geography - note:
insular and continental regions widely separated; despite its name, no part of the Equator passes through Equatorial Guinea; the mainland part of the country is located just north of the Equator','1b47d5c15be912610f7d9a5d6e7e1aa080d3dceed01e7731f80a96532e872d10','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('824e32897bad2e1f3088d10bb376ea1d528f98ae572a95b6225c35adad61bd3b',2025,'ER','Eritrea','geography',50,'Location:
Eastern Africa, bordering the Red Sea, between Djibouti and Sudan
Geographic coordinates:
15 00 N, 39 00 E
Map references:
Africa
Area:
total:
117,600 sq km
land:
101,000 sq km
water:
16,600 sq km
comparison ranking:
total 101
Area - comparative:
slightly smaller than Pennsylvania
Land boundaries:
total:
1,840 km
border countries (3):
Djibouti 125 km; Ethiopia 1,033 km; Sudan 682 km
Coastline:
2,234 km (mainland on Red Sea 1,151 km, islands in Red Sea 1,083 km)
Maritime claims:
territorial sea:
12 nm
Climate:
hot, dry desert strip along Red Sea coast; cooler and wetter in the central highlands (up to 61 cm of rainfall annually, heaviest June to September); semiarid in western hills and lowlands
Terrain:
dominated by extension of Ethiopian north-south trending highlands, descending on the east to a coastal desert plain, on the northwest to hilly terrain and on the southwest to flat-to-rolling plains
Elevation:
highest point:
Soira 3,018 m
lowest point:
near Kulul within the Danakil Depression -75 m
mean elevation:
853 m
Natural resources:
gold, potash, zinc, copper, salt, possibly oil and natural gas, fish
Land use:
agricultural land:
75.1% (2018 est.)
arable land:
6.8% (2018 est.)
permanent crops:
0% (2018 est.)
permanent pasture:
68.3% (2018 est.)
forest:
15.1% (2018 est.)
other:
9.8% (2018 est.)
Irrigated land:
210 sq km (2012)
Population distribution:
density is highest in the center of the country in and around the cities of Asmara (capital) and Keren; smaller settlements exist in the north and south as shown in this population distribution map
Natural hazards:
frequent droughts, rare earthquakes and volcanoes; locust swarms
volcanism:
Dubbi (1,625 m), which last erupted in 1861, was the country’s only historically active volcano until Nabro (2,218 m) came to life on 12 June 2011
Geography - note:
strategic geopolitical position along world’s busiest shipping lanes; Eritrea retained the entire coastline of Ethiopia along the Red Sea upon de jure independence from Ethiopia on 24 May 1993','56055796b11943389984208bec08b61b611228d2a4ef98714040e601c4d60cc3','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3735c33451cf43479620d077454668b22148084bcd1b399a413337f664142ed7',2025,'EE','Estonia','geography',2,'Location:
Eastern Europe, bordering the Baltic Sea and Gulf of Finland, between Latvia and Russia
Geographic coordinates:
59 00 N, 26 00 E
Map references:
Europe
Area:
total:
45,228 sq km
land:
42,388 sq km
water:
2,840 sq km
note:
includes 1,520 islands in the Baltic Sea
comparison ranking:
total 132
Area - comparative:
about twice the size of New Jersey
Land boundaries:
total:
657 km
border countries (2):
Latvia 333 km; Russia 324 km
Coastline:
3,794 km
Maritime claims:
territorial sea:
12 nm
exclusive economic zone:
limits as agreed to by Estonia, Finland, Latvia, Sweden, and Russia
Climate:
maritime; wet, moderate winters, cool summers
Terrain:
marshy, lowlands; flat in the north, hilly in the south
Elevation:
highest point:
Suur Munamagi 318 m
lowest point:
Baltic Sea 0 m
mean elevation:
61 m
Natural resources:
oil shale, peat, rare earth elements, phosphorite, clay, limestone, sand, dolomite, arable land, sea mud
Land use:
agricultural land:
22.2% (2018 est.)
arable land:
14.9% (2018 est.)
permanent crops:
0.1% (2018 est.)
permanent pasture:
7.2% (2018 est.)
forest:
52.1% (2018 est.)
other:
25.7% (2018 est.)
Irrigated land:
20 sq km (2016)
Major lakes (area sq km):
fresh water lake(s):
Lake Peipus - 4,300 sq km (shared with Russia); Lake Võrtsjärv - 270 sq km
Population distribution:
a fairly even distribution throughout most of the country, with urban areas attracting larger and denser populations
Natural hazards:
sometimes flooding occurs in the spring
Geography - note:
the mainland terrain is flat, boggy, and partly wooded; offshore lie more than 1,500 islands','23fdabd397743e81ad333df8692909d2705a32b31c58d08566a2d5428e104e0d','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('863f537fbaacf8e6b171f161c2cbcf70db2fd287089bbd7dbe236b595ba2c597',2025,'SZ','Eswatini','geography',13,'Location:
Southern Africa, between Mozambique and South Africa
Geographic coordinates:
26 30 S, 31 30 E
Map references:
Africa
Area:
total:
17,364 sq km
land:
17,204 sq km
water:
160 sq km
comparison ranking:
total 158
Area - comparative:
slightly smaller than New Jersey
Land boundaries:
total:
546 km
border countries (2):
Mozambique 108 km; South Africa 438 km
Coastline:
0 km (landlocked)
Maritime claims:
none (landlocked)
Climate:
varies from tropical to near temperate
Terrain:
mostly mountains and hills; some moderately sloping plains
Elevation:
highest point:
Emlembe 1,862 m
lowest point:
Great Usutu River 21 m
mean elevation:
305 m
Natural resources:
asbestos, coal, clay, cassiterite, hydropower, forests, small gold and diamond deposits, quarry stone, and talc
Land use:
agricultural land:
68.3% (2018 est.)
arable land:
9.8% (2018 est.)
permanent crops:
0.8% (2018 est.)
permanent pasture:
57.7% (2018 est.)
forest:
31.7% (2018 est.)
other:
0% (2018 est.)
Irrigated land:
500 sq km (2012)
Population distribution:
because of its mountainous terrain, the population distribution is uneven throughout the country, concentrating primarily in valleys and plains as shown in this population distribution map
Natural hazards:
drought
Geography - note:
landlocked; almost completely surrounded by South Africa','61aaac5a04d0fb3651c1807693253334a5c9cf344e4a7d3100b7e470fe670a1c','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c4d09c316b0e11539efa8229547344d3da29ca82ddc36ec9e17d89338a606c73',2025,'ET','Ethiopia','geography',24,'Location:
Eastern Africa, west of Somalia
Geographic coordinates:
8 00 N, 38 00 E
Map references:
Africa
Area:
total:
1,104,300 sq km
land:
1,096,570 sq km
water:
7,730 sq km
note:
area numbers are approximate since a large portion of the Ethiopia-Somalia border is undefined comparison ranking: total 28
Area - comparative:
slightly less than twice the size of Texas
Land boundaries:
total:
5,925 km
border countries (6):
Djibouti 342 km; Eritrea 1,033 km; Kenya 867 km; Somalia 1,640 km; South Sudan 1,299 km; Sudan 744 km
Coastline:
0 km (landlocked)
Maritime claims:
none (landlocked)
Climate:
tropical monsoon with wide topographic-induced variation
Terrain:
high plateau with central mountain range divided by Great Rift Valley
Elevation:
highest point:
Ras Dejen 4,550 m
lowest point:
Danakil Depression -125 m
mean elevation:
1,330 m
Natural resources:
small reserves of gold, platinum, copper, potash, natural gas, hydropower
Land use:
agricultural land:
36.3% (2018 est.)
arable land:
15.2% (2018 est.)
permanent crops:
1.1% (2018 est.)
permanent pasture:
20% (2018 est.)
forest:
12.2% (2018 est.)
other:
51.5% (2018 est.)
Irrigated land:
1,813 sq km (2020)
Major lakes (area sq km):
fresh water lake(s):
Lake Tana - 3,600 sq km; Abaya Hayk - 1,160 sq km; Ch’amo Hayk - 550 sq km
salt water lake(s):
Lake Turkana (shared with Kenya) - 6,400 sq km; Abhe Bid Hayk/Abhe Bad (shared with Djibouti) - 780 sq km;
Major rivers (by length in km):
Blue Nile river source (shared with Sudan [m]) - 1,600 km
note
– [s] after country name indicates river source; [m] after country name indicates river mouth
Major watersheds (area sq km): Atlantic Ocean drainage:
(Mediterranean Sea)
Nile (3,254,853 sq km)
Major aquifers:
Ogaden-Juba Basin, Sudd Basin (Umm Ruwaba Aquifer)
Population distribution:
highest density is found in the highlands of the north and middle areas of the country, particularly around the centrally located capital city of Addis Ababa; the far east and southeast are sparsely populated as shown in this population distribution map
Natural hazards:
geologically active Great Rift Valley susceptible to earthquakes, volcanic eruptions; frequent droughts
volcanism:
volcanic activity in the Great Rift Valley; Erta Ale (613 m), which has caused frequent lava flows in recent years, is the country’s most active volcano; Dabbahu became active in 2005, forcing evacuations; other historically active volcanoes include Alayta, Dalaffilla, Dallol, Dama Ali, Fentale, Kone, Manda Hararo, and Manda-Inakir
Geography - note:
note 1:
landlocked - entire coastline along the Red Sea was lost with the de jure independence of Eritrea on 24 May 1993; Ethiopia is, therefore, the most populous landlocked country in the world; the Blue Nile, the chief headstream of the Nile by water volume, rises in T’ana Hayk (Lake Tana) in northwest Ethiopia
note 2:
three major crops may have originated in Ethiopia: coffee (almost certainly), grain sorghum, and castor bean','887f9bf7bb47235ed886541f63fb463f54c3db4794b26d538b190768983a9854','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c67c32c4dbecc52b80b54a95d4c1844fd140de132e1a6a364f14d785085b7819',2025,'ET','Ethiopia','geography',37,'Location:
Europe between the North Atlantic Ocean in the west and Russia, Belarus, and Ukraine to the east
Map references:
Europe
Area:
total:
4,236,351 sq km
rank by area (sq km):
1. France (includes five overseas regions) 643,801
2. Spain 505,370
3. Sweden 450,295
4. Germany 357,022
5. Finland 338,145
6. Poland 312,685
7. Italy 301,340
8. Romania 238,391
9. Greece 131,957
10. Bulgaria 110,879
11. Hungary 93,028
12. Portugal 92,090
13. Austria 83,871
14. Czechia 78,867
15. Ireland 70,273
16. Lithuania 65,300
17. Latvia 64,589
18. Croatia 56,594
19. Slovakia 49,035
20. Estonia 45,228
21. Denmark 43,094
22. Netherlands 41,543
23. Belgium 30,528
24. Slovenia 20,273
25. Cyprus 9,251
26. Luxembourg 2,586
27. Malta 316
Area - comparative:
less than one half the size of the United States
Land boundaries:
total:
13,770 km
border countries (20):
Albania 212 km; Andorra 118 km; Belarus 1,176 km; Bosnia and Herzegovina 956 km; Holy See 3 km; Liechtenstein 34 km; North Macedonia 396 km; Moldova 683 km; Monaco 6 km; Montenegro 19 km; Norway 2,375 km; Russia 2,435 km; San Marino 37 km; Serbia 1,353 km; Switzerland 1,729 km; Turkey 415 km; United Kingdom 499 km; Ukraine 1,324 km; note - the Brexit Withdrawal Agreement (2020) commits the United Kingdom (UK) to maintain an open border in Ireland, so the border between Northern Ireland (UK) and the Republic of Ireland is only
de jure
and is not a hard border; the
de facto
border is the Irish Sea between the islands of Ireland and Great Britain
note:
data for European continent only
Coastline:
53,563.9 km
Climate:
cold temperate; potentially subarctic in the north to temperate; mild wet winters; hot dry summers in the south
Terrain:
fairly flat along Baltic and Atlantic coasts; mountainous in the central and southern areas
Elevation:
highest point:
Mont Blanc, France 4,810 m
lowest point:
Zuidplaspolder, Netherlands -7 m
Natural resources:
iron ore, natural gas, petroleum, coal, copper, lead, zinc, bauxite, uranium, potash, salt, hydropower, arable land, timber, fish
Irrigated land:
154,539.82 sq km (2011 est.)
Population distribution:
population distribution varies considerably from country to country but tends to follow a pattern of coastal and river settlement, with urban agglomerations forming large hubs facilitating large scale housing, industry, and commerce; the area in and around the Netherlands, Belgium, and Luxembourg (known collectively as Benelux), is the most densely populated area in the EU
Natural hazards:
flooding along coasts; avalanches in mountainous area; earthquakes in the south; volcanic eruptions in Italy; periodic droughts in Spain; ice floes in the Baltic Sea region','ef533c80e1532af1371f87dbe35b337c72e1ab1bf05b24598431270949db5483','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ba4fd22205286b3c6c96655d60eb7a04c2a8557b1a00469329c7f146b04790bd',2025,'FO','Faroe Islands','geography',3,'Location:
Northern Europe, island group between the Norwegian Sea and the North Atlantic Ocean, about halfway between Iceland and Norway
Geographic coordinates:
62 00 N, 7 00 W
Map references:
Europe
Area:
total:
1,393 sq km
land:
1,393 sq km
water:
0 sq km (some lakes and streams)
comparison ranking:
total 182
Area - comparative:
eight times the size of Washington, DC
Land boundaries:
total:
0 km
Coastline:
1,117 km
Maritime claims:
territorial sea:
12 nm
continental shelf:
200 nm or agreed boundaries or median line
exclusive fishing zone:
200 nm or agreed boundaries or median line
Climate:
mild winters, cool summers; usually overcast; foggy, windy
Terrain:
rugged, rocky, some low peaks; cliffs along most of coast
Elevation:
highest point:
Slaettaratindur 882 m
lowest point:
Atlantic Ocean 0 m
Natural resources:
fish, whales, hydropower, possible oil and gas
Land use:
agricultural land:
2.1% (2018 est.)
arable land:
2.1% (2018 est.)
permanent crops:
0% (2018 est.)
permanent pasture:
0% (2018 est.)
forest:
0.1% (2018 est.)
other:
97.8% (2018 est.)
Population distribution:
the island of Streymoy is by far the most populous with over 40% of the population; it has approximately twice as many inhabitants as Eysturoy, the second most populous island; seven of the inhabited islands have fewer than 100 people
Natural hazards:
strong winds and heavy rains can occur throughout the year
Geography - note:
archipelago of 17 inhabited islands and one uninhabited island, and a few uninhabited islets; strategically located along important sea lanes in northeastern Atlantic; precipitous terrain limits habitation to small coastal lowlands','5fc7ec6fcf99ead03c54c120faf3f4deccd84c162927a9b06bf8d3a8d27de83a','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fb5f67732c2f5834b8afeb3a48d57199dd6ce70a6f68c9554bce798a3ed8234f',2025,'FJ','Fiji','geography',14,'Location:
Oceania, island group in the South Pacific Ocean, about two-thirds of the way from Hawaii to New Zealand
Geographic coordinates:
18 00 S, 175 00 E
Map references:
Oceania
Area:
total:
18,274 sq km
land:
18,274 sq km
water:
0 sq km
comparison ranking:
total 156
Area - comparative:
slightly smaller than New Jersey
Land boundaries:
total:
0 km
Coastline:
1,129 km
Maritime claims:
territorial sea:
12 nm
contiguous zone:
24 nm
exclusive economic zone:
200 nm
continental shelf:
200-m depth or to the depth of exploitation measured from claimed archipelagic straight baselines
Climate:
tropical marine; only slight seasonal temperature variation
Terrain:
mostly mountains of volcanic origin
Elevation:
highest point:
Tomanivi 1,324 m
lowest point:
Pacific Ocean 0 m
Natural resources:
timber, fish, gold, copper, offshore oil potential, hydropower
Land use:
agricultural land:
23.3% (2018 est.)
arable land:
9% (2018 est.)
permanent crops:
4.7% (2018 est.)
permanent pasture:
9.6% (2018 est.)
forest:
55.7% (2018 est.)
other:
21% (2018 est.)
Irrigated land:
40 sq km (2012)
Population distribution:
approximately 70% of the population lives on the island of Viti Levu; roughly half of the population lives in urban areas
Natural hazards:
cyclonic storms can occur from November to January
Geography - note:
consists of 332 islands, approximately 110 of which are inhabited, and more than 500 islets','ae17187971f0cf407cfa5d59911a58b003401520c944475e8da504d8928f7227','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fddcf8b28ff3dd455c20fe6ae63a8d72f476203336cca5d6d3f338dc9feb9d2a',2025,'FI','Finland','geography',25,'Location:
Northern Europe, bordering the Baltic Sea, Gulf of Bothnia, and Gulf of Finland, between Sweden and Russia
Geographic coordinates:
64 00 N, 26 00 E
Map references:
Europe
Area:
total:
338,145 sq km
land:
303,815 sq km
water:
34,330 sq km
comparison ranking:
total 66
Area - comparative:
slightly more than two times the size of Georgia; slightly smaller than Montana
Land boundaries:
total:
2,563 km
border countries (3):
Norway 709 km; Sweden 545 km; Russia 1,309 km
Coastline:
1,250 km
Maritime claims:
territorial sea:
12 nm (in the Gulf of Finland - 3 nm)
contiguous zone:
24 nm
continental shelf:
200 m depth or to the depth of exploitation
exclusive fishing zone:
12 nm; extends to continental shelf boundary with Sweden, Estonia, and Russia
Climate:
cold temperate; potentially subarctic but comparatively mild because of moderating influence of the North Atlantic Current, Baltic Sea, and more than 60,000 lakes
Terrain:
mostly low, flat to rolling plains interspersed with lakes and low hills
Elevation:
highest point:
Halti (alternatively Haltia, Haltitunturi, Haltiatunturi) 1,328 m
lowest point:
Baltic Sea 0 m
mean elevation:
164 m
Natural resources:
timber, iron ore, copper, lead, zinc, chromite, nickel, gold, silver, limestone
Land use:
agricultural land:
7.5% (2018 est.)
arable land:
7.4% (2018 est.)
permanent crops:
0% (2018 est.)
permanent pasture:
0.1% (2018 est.)
forest:
72.9% (2018 est.)
other:
19.6% (2018 est.)
Irrigated land:
80 sq km (2015)
Major lakes (area sq km):
fresh water lake(s):
Saimaa - 1,760 sq km; Paijanne - 1,090 sq km; Inarijarvi - 1,000 sq km; Oulujarvi - 900 sq km; Pielinen - 850 sq km
Population distribution:
the vast majority of people are found in the south; the northern interior areas remain sparsely populated
Natural hazards:
severe winters in the north
Geography - note:
long boundary with Russia; Helsinki is northernmost national capital on European continent; population concentrated on small southwestern coastal plain','b3fa5cacad57225bd6184e7f9d04c9b5c53afd98b7027d1cbd24b001beeaeda6','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('168c24099e621e8995d326e1ad462a6361c419ca68e55ff0cc6195a961be4e66',2025,'FR','France','geography',36,'Location:
metropolitan France:
Western Europe, bordering the Bay of Biscay and English Channel, between Belgium and Spain, southeast of the UK; bordering the Mediterranean Sea, between Italy and Spain;
French Guiana:
Northern South America, bordering the North Atlantic Ocean, between Brazil and Suriname;
Guadeloupe:
Caribbean, islands between the Caribbean Sea and the North Atlantic Ocean, southeast of Puerto Rico;
Martinique:
Caribbean, island between the Caribbean Sea and North Atlantic Ocean, north of Trinidad and Tobago;
Mayotte:
Southern Indian Ocean, island in the Mozambique Channel, about halfway between northern Madagascar and northern Mozambique;
Reunion:
Southern Africa, island in the Indian Ocean, east of Madagascar
Geographic coordinates:
metropolitan France:
46 00 N, 2 00 E;
French Guiana:
4 00 N, 53 00 W;
Guadeloupe:
16 15 N, 61 35 W;
Martinique:
14 40 N, 61 00 W;
Mayotte:
12 50 S, 45 10 E;
Reunion:
21 06 S, 55 36 E
Map references:
metropolitan France:
Europe;
French Guiana:
South America;
Guadeloupe:
Central America and the Caribbean;
Martinique:
Central America and the Caribbean;
Mayotte:
Africa;
Reunion:
World
Area:
total:
643,801 sq km ; 551,500 sq km (metropolitan France)
land:
640,427 sq km ; 549,970 sq km (metropolitan France)
water:
3,374 sq km ; 1,530 sq km (metropolitan France)
note:
the first numbers include the overseas regions of French Guiana, Guadeloupe, Martinique, Mayotte, and Reunion
comparison ranking:
total 45
Area - comparative:
slightly more than four times the size of Georgia; slightly less than the size of Texas
Land boundaries:
total:
3,956 km
border countries (8):
Andorra 55 km; Belgium 556 km; Germany 418 km; Italy 476 km; Luxembourg 69 km; Monaco 6 km; Spain 646 km; Switzerland 525 km
metropolitan France - total:
2751 km
French Guiana - total:
1205 km
Coastline:
4,853 km
metropolitan France:
3,427 km
Maritime claims:
territorial sea:
12 nm
contiguous zone:
24 nm
exclusive economic zone:
200 nm (does not apply to the Mediterranean Sea)
continental shelf:
200m depth or to the depth of exploitation
Climate:
metropolitan France:
generally cool winters and mild summers, but mild winters and hot summers along the Mediterranean; occasional strong, cold, dry, north-to-northwesterly wind known as the mistral
French Guiana:
tropical; hot, humid; little seasonal temperature variation
Guadeloupe and Martinique:
subtropical tempered by trade winds; moderately high humidity; rainy season (June to October); vulnerable to devastating cyclones (hurricanes) every eight years on average
Mayotte:
tropical; marine; hot, humid, rainy season during northeastern monsoon (November to May); dry season is cooler (May to November)
Reunion:
tropical, but temperature moderates with elevation; cool and dry (May to November), hot and rainy (November to April)
Terrain:
metropolitan France:
mostly flat plains or gently rolling hills in north and west; remainder is mountainous, especially Pyrenees in south, Alps in east;
French Guiana:
low-lying coastal plains rising to hills and small mountains;
Guadeloupe:
Basse-Terre is volcanic in origin with interior mountains; Grande-Terre is low limestone formation; most of the seven other islands are volcanic in origin;
Martinique:
mountainous with indented coastline; dormant volcano;
Mayotte:
generally undulating, with deep ravines and ancient volcanic peaks;
Reunion:
mostly rugged and mountainous; fertile lowlands along coast
Elevation:
highest point:
Mont Blanc 4,810
lowest point:
Rhone River delta -2 m
mean elevation:
375 m
note:
to assess the possible effects of climate change on the ice and snow cap of Mont Blanc, its surface and peak have been extensively measured in recent years; these new peak measurements have exceeded the traditional height of 4,807 m and have varied between 4,808 m and 4,811 m; the actual rock summit is 4,792 m and is 40 m away from the ice-covered summit
Natural resources:
metropolitan France: coal, iron ore, bauxite, zinc, uranium, antimony, arsenic, potash, feldspar, fluorspar, gypsum, timber, arable land, fish; French Guiana: gold deposits, petroleum, kaolin, niobium, tantalum, clay
Land use:
agricultural land:
52.7% (2018 est.)
arable land:
33.4% (2018 est.)
permanent crops:
1.8% (2018 est.)
permanent pasture:
17.5% (2018 est.)
forest:
29.2% (2018 est.)
other:
18.1% (2018 est.)
Irrigated land:
14,236 sq km (2013)
Major lakes (area sq km):
fresh water lake(s):
Lake Geneva (shared with Switzerland) - 580 sq km
Major rivers (by length in km):
Rhin (Rhine) (shared with Switzerland [s], Germany, and Netherlands [m]) - 1,233 km; Loire - 1,012 km
note – [s] after country name indicates river source; [m] after country name indicates river mouth
Major watersheds (area sq km): Atlantic Ocean drainage:
Loire (115,282 sq km), Seine (78,919 sq km), Rhine-Maas (198,735 sq km),
(Adriatic Sea)
Po (76,997 sq km),
(Mediterranean Sea)
Rhone (100,543 sq km)
Major aquifers:
Paris Basin
Population distribution:
much of the population is concentrated in the north and southeast; although there are many urban agglomerations throughout the country, Paris is by far the largest city, with Lyon ranked a distant second
Natural hazards:
metropolitan France: flooding; avalanches; midwinter windstorms; drought; forest fires in south near the Mediterranean;
overseas departments:
hurricanes (cyclones); flooding;
volcanism:
Montagne Pelee (1,394 m) on the island of Martinique in the Caribbean is the most active volcano of the Lesser Antilles arc, it last erupted in 1932; a catastrophic eruption in May 1902 destroyed the city of St. Pierre, killing an estimated 30,000 people; La Soufriere (1,467 m) on the island of Guadeloupe in the Caribbean last erupted from July 1976 to March 1977; these volcanoes are part of the volcanic island arc of the Lesser Antilles that extends from Saba in the north to Grenada in the south
Geography - note:
largest West European nation; most major French rivers - the Meuse, Seine, Loire, Charente, Dordogne, and Garonne - flow northward or westward into the Atlantic Ocean, only the Rhone flows southward into the Mediterranean Sea','724657ed74abd23f9294d6b998ab70f2d9d04263bd6776ec1ea951f38a2d8f75','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4b85e102367dbc1689c6d02fd7bb6e830b827ea5ab2a03dc052e6d8059c6d52b',2025,'PF','French Polynesia','geography',49,'Location:
Oceania, five archipelagoes (Archipel des Tuamotu, Iles Gambier, Iles Marquises, Iles Tubuai, Society Islands) in the South Pacific Ocean about halfway between South America and Australia
Geographic coordinates:
15 00 S, 140 00 W
Map references:
Oceania
Area:
total:
4,167 sq km (118 islands and atolls; 67 are inhabited)
land:
3,827 sq km
water:
340 sq km
comparison ranking:
total 174
Area - comparative:
slightly less than one-third the size of Connecticut
Land boundaries:
total:
0 km
Coastline:
2,525 km
Maritime claims:
territorial sea:
12 nm
exclusive economic zone:
200 nm
Climate:
tropical, but moderate
Terrain:
mixture of rugged high islands and low islands with reefs
Elevation:
highest point:
Mont Orohena 2,241 m
lowest point:
Pacific Ocean 0 m
Natural resources:
timber, fish, cobalt, hydropower
Land use:
agricultural land:
12.5% (2018 est.)
arable land:
0.7% (2018 est.)
permanent crops:
6.3% (2018 est.)
permanent pasture:
5.5% (2018 est.)
forest:
43.7% (2018 est.)
other:
43.8% (2018 est.)
Irrigated land:
10 sq km (2012)
Population distribution:
the majority of the population lives in the Society Islands, one of five archipelagos that includes the most populous island - Tahiti - with approximately 70% of the nation’s population
Natural hazards:
occasional cyclonic storms in January
Geography - note:
includes five archipelagoes:
four volcanic (Iles Gambier, Iles Marquises, Iles Tubuai, Society Islands) and one coral (Archipel des Tuamotu); the Tuamotu Archipelago forms the largest group of atolls in the world - 78 in total, 48 inhabited; Makatea in the Tuamotu Archipelago is one of the three great phosphate rock islands in the Pacific Ocean - the others are Banaba (Ocean Island) in Kiribati and Nauru','a194931f482ac4b3c884f992b0a8829e16878177d2daf2556acd3cde89618ecf','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5038f0ca3e7d601fe258edb6f158cd6a897f88ae1ad1a00c00f6de0d2ff3eaf3',2025,'PF','French Polynesia','geography',60,'Location:
southeast and east of Africa, islands in the southern Indian Ocean, some near Madagascar and others about equidistant between Africa, Antarctica, and Australia; note - French Southern and Antarctic Lands include Ile Amsterdam, Ile Saint-Paul, Iles Crozet, Iles Kerguelen, Bassas da India, Europa Island, Glorioso Islands, Juan de Nova Island, and Tromelin Island in the southern Indian Ocean, along with the French-claimed sector of Antarctica, “Adelie Land”; the US does not recognize the French claim to “Adelie Land”
Geographic coordinates: Ile Amsterdam (Ile Amsterdam et Ile Saint-Paul):
37 50 S, 77 32 E;
Ile Saint-Paul (Ile Amsterdam et Ile Saint-Paul):
38 72 S, 77 53 E;
Iles Crozet:
46 25 S, 51 00 E;
Iles Kerguelen:
49 15 S, 69 35 E;
Bassas da India (Iles Eparses):
21 30 S, 39 50 E;
Europa Island (Iles Eparses):
22 20 S, 40 22 E;
Glorioso Islands (Iles Eparses):
11 30 S, 47 20 E;
Juan de Nova Island (Iles Eparses):
17 03 S, 42 45 E;
Tromelin Island (Iles Eparses):
15 52 S, 54 25 E
Map references:
Antarctic RegionAfrica
Area: Ile Amsterdam (Ile Amsterdam et Ile Saint-Paul):
total - 55 sq km; land - 55 sq km; water - 0 sq km
Ile Saint-Paul (Ile Amsterdam et Ile Saint-Paul):
total - 7 sq km; land - 7 sq km; water - 0 sq km
Iles Crozet:
total - 352 sq km; land - 352 sq km; water - 0 sq km
Iles Kerguelen:
total - 7,215 sq km; land - 7,215 sq km; water - 0 sq km
Bassas da India (Iles Eparses):
total - 80 sq km; land - 0.2 sq km; water - 79.8 sq km (lagoon)
Europa Island (Iles Eparses):
total - 28 sq km; land - 28 sq km; water - 0 sq km
Glorioso Islands (Iles Eparses):
total - 5 sq km; land - 5 sq km; water - 0 sq km
Juan de Nova Island (Iles Eparses):
total - 4.4 sq km; land - 4.4 sq km; water - 0 sq km
Tromelin Island (Iles Eparses):
total - 1 sq km; land - 1 sq km; water - 0 sq km
note:
excludes “Adelie Land” claim of about 500,000 sq km in Antarctica that is not recognized by the US
Area - comparative: Ile Amsterdam (Ile Amsterdam et Ile Saint-Paul):
less than one-half the size of Washington, DC;
Ile Saint-Paul (Ile Amsterdam et Ile Saint-Paul):
more than 10 times the size of the National Mall in Washington, DC;
Iles Crozet:
about twice the size of Washington, DC;
Iles Kerguelen:
slightly larger than Delaware;
Bassas da India (Iles Eparses):
land area about one-third the size of the National Mall in Washington, DC;
Europa Island (Iles Eparses):
about one-sixth the size of Washington, DC;
Glorioso Islands (Iles Eparses):
about eight times the size of the National Mall in Washington, DC;
Juan de Nova Island (Iles Eparses):
about seven times the size of the National Mall in Washington, DC;
Tromelin Island (Iles Eparses):
about 1.7 times the size of the National Mall in Washington, DC
Land boundaries:
total:
0 km
Coastline: Ile Amsterdam (Ile Amsterdam et Ile Saint-Paul):
28 km
Ile Saint-Paul (Ile Amsterdam et Ile Saint-Paul): Iles Kerguelen:
2,800 km
Bassas da India (Iles Eparses):
35.2 km
Europa Island (Iles Eparses):
22.2 km
Glorioso Islands (Iles Eparses):
35.2 km
Juan de Nova Island (Iles Eparses):
24.1 km
Tromelin Island (Iles Eparses):
3.7 km
Maritime claims:
territorial sea:
12 nm
exclusive economic zone:
200 nm from Iles Kerguelen and Iles Eparses (does not include the rest of French Southern and Antarctic Lands); Juan de Nova Island and Tromelin Island claim a continental shelf of 200-m depth or to the depth of exploitation
Climate: Ile Amsterdam et Ile Saint-Paul:
oceanic with persistent westerly winds and high humidity;
Iles Crozet:
windy, cold, wet, and cloudy;
Iles Kerguelen:
oceanic, cold, overcast, windy;
Iles Eparses:
tropical
Terrain: Ile Amsterdam (Ile Amsterdam et Ile Saint-Paul):
a volcanic island with steep coastal cliffs; the center floor of the volcano is a large plateau;
Ile Saint-Paul (Ile Amsterdam et Ile Saint-Paul):
triangular in shape, the island is the top of a volcano, rocky with steep cliffs on the eastern side; has active thermal springs;
Iles Crozet:
a large archipelago formed from the Crozet Plateau is divided into two groups of islands;
Iles Kerguelen:
the interior of the large island of Ile Kerguelen is composed of high mountains, hills, valleys, and plains with peninsulas stretching off its coasts;
Bassas da India (Iles Eparses):
atoll, awash at high tide; shallow (15 m) lagoon;
Europa Island, Glorioso Islands, Juan de Nova Island:
low, flat, and sandy;
Tromelin Island (Iles Eparses):
low, flat, sandy; likely volcanic seamount
Elevation:
highest point:
Mont de la Dives on Ile Amsterdam (Ile Amsterdam et Ile Saint- Paul) 867 m
lowest point:
Indian Ocean 0 m
highest points throughout the French Southern and Antarctic Lands:
unnamed location on Ile Saint-Paul (Ile Amsterdam et Ile Saint-Paul) 272 m; Pic Marion-Dufresne in Iles Crozet 1090 m; Mont Ross in Iles Kerguelen 1850 m; unnamed location on Bassas de India (Iles Eparses) 2.4 m;24 unnamed location on Europa Island (Iles Eparses) 24 m; unnamed location on Glorioso Islands (Iles Eparses) 12 m; unnamed location on Juan de Nova Island (Iles Eparses) 10 m; unnamed location on Tromelin Island (Iles Eparses) 7 m
Natural resources:
fish, crayfish, note, Glorioso Islands and Tromelin Island (Iles Eparses) have guano, phosphates, and coconuts
note:
in the 1950’s and 1960’s, several species of trout were introduced to Iles Kerguelen of which two, Brown trout and Brook trout, survived to establish wild populations; reindeer were also introduced to Iles Kerguelen in 1956 as a source of fresh meat for whaling crews, the herd today, one of two in the Southern Hemisphere, is estimated to number around 4,000
Natural hazards:
Ile Amsterdam and Ile Saint-Paul are inactive volcanoes; Iles Eparses subject to periodic cyclones; Bassas da India is a maritime hazard since it is under water for a period of three hours prior to and following the high tide and surrounded by reefs
volcanism:
Reunion Island - Piton de la Fournaise (2,632 m), which has erupted many times in recent years including 2010, 2015, and 2017, is one of the world’s most active volcanoes; although rare, eruptions outside the volcano’s caldera could threaten nearby cities
Geography - note:
islands’ component is widely scattered across remote locations in the southern Indian Ocean
Bassas da India (Iles Eparses):
atoll is a circular reef atop a long-extinct, submerged volcano;
Europa Island and Juan de Nova Island (Iles Eparses):
wildlife sanctuary for seabirds and sea turtles;
Glorioso Island (Iles Eparses):
islands and rocks are surrounded by an extensive reef system;
Tromelin Island (Iles Eparses):
climatologically important location for forecasting cyclones in the western Indian Ocean; wildlife sanctuary (seabirds, tortoises)','70f7e54fdab355311c03f0459ab347f63c9f17fb3720702327094e9bb75d2d4d','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('999647669d7a890583ce20e205549bbaa5449ab5546c25e5dd9a02e0fea4cc68',2025,'GA','Gabon','geography',2,'Location:
Central Africa, bordering the Atlantic Ocean at the Equator, between Republic of the Congo and Equatorial Guinea
Geographic coordinates:
1 00 S, 11 45 E
Map references:
Africa
Area:
total:
267,667 sq km
land:
257,667 sq km
water:
10,000 sq km
comparison ranking:
total 78
Area - comparative:
slightly smaller than Colorado
Land boundaries:
total:
3,261 km
border countries (3):
Cameroon 349 km; Republic of the Congo 2,567 km; Equatorial Guinea 345 km
Coastline:
885 km
Maritime claims:
territorial sea:
12 nm
contiguous zone:
24 nm
exclusive economic zone:
200 nm
Climate:
tropical; always hot, humid
Terrain:
narrow coastal plain; hilly interior; savanna in east and south
Elevation:
highest point:
Mont Bengoue 1,050 m
lowest point:
Atlantic Ocean 0 m
mean elevation:
377 m
Natural resources:
petroleum, natural gas, diamond, niobium, manganese, uranium, gold, timber, iron ore, hydropower
Land use:
agricultural land:
19% (2018 est.)
arable land:
1.2% (2018 est.)
permanent crops:
0.6% (2018 est.)
permanent pasture:
17.2% (2018 est.)
forest:
81% (2018 est.)
other:
0% (2018 est.)
Irrigated land:
40 sq km (2012)
Major watersheds (area sq km): Atlantic Ocean drainage:
Congo (3,730,881 sq km)
Major aquifers:
Congo Basin
Population distribution:
the relatively small population is spread in pockets throughout the country; the largest urban center is the capital of Libreville, located along the Atlantic coast in the northwest as shown in this population distribution map
Natural hazards:
none
Geography - note:
a small population and oil and mineral reserves have helped Gabon become one of Africa’s wealthier countries; in general, these circumstances have allowed the country to maintain and conserve its pristine rain forest and rich biodiversity','f2e753d8b9529918894a546fdab2eac8a0e1e8cd340640b833b2ad86efb14a25','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2e1ed259e5ff7f1faa7fb144a70942e5cc316c18b0c8d714eca28a4bf13adb5d',2025,'GA','Gabon','geography',14,'Location:
Western Africa, bordering the North Atlantic Ocean and Senegal
Geographic coordinates:
13 28 N, 16 34 W
Map references:
Africa
Area:
total:
11,300 sq km
land:
10,120 sq km
water:
1,180 sq km
comparison ranking:
total 165
Area - comparative:
slightly less than twice the size of Delaware
Land boundaries:
total:
749 km
border countries (1):
Senegal 749 km
Coastline:
80 km
Maritime claims:
territorial sea:
12 nm
contiguous zone:
18 nm
continental shelf:
extent not specified
exclusive fishing zone:
200 nm
Climate:
tropical; hot, rainy season (June to November); cooler, dry season (November to May)
Terrain:
flood plain of the Gambia River flanked by some low hills
Elevation:
highest point:
unnamed elevation 63 m; 3 km southeast of the town of Sabi
lowest point:
Atlantic Ocean 0 m
mean elevation:
34 m
Natural resources:
fish, clay, silica sand, titanium (rutile and ilmenite), tin, zircon
Land use:
agricultural land:
56.1% (2018 est.)
arable land:
41% (2018 est.)
permanent crops:
0.5% (2018 est.)
permanent pasture:
14.6% (2018 est.)
forest:
43.9% (2018 est.)
other:
0% (2018 est.)
Irrigated land:
50 sq km (2012)
Major rivers (by length in km):
Gambia river mouth (shared with Senegal and Guinea [s]) - 1,094 km
note – [s] after country name indicates river source; [m] after country name indicates river mouth
Major aquifers:
Senegalo-Mauritanian Basin
Population distribution:
settlements are found scattered along the Gambia River; the largest communities, including the capital of Banjul, and the country’s largest city, Serekunda, are found at the mouth of the Gambia River along the Atlantic coast as shown in this population distribution map
Natural hazards:
droughts
Geography - note:
almost an enclave of Senegal; smallest country on the African mainland','e848ba32e99b684eaff1650b0a17b83e8e9ba52a10c44d3555838437bdd0d16d','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3a9451513ac16dd715763ce8b5aba745479005f9b511dd082736eb07babd2b55',2025,'GA','Gabon','geography',25,'Location:
Middle East, bordering the Mediterranean Sea, between Egypt and Israel
Geographic coordinates:
31 25 N, 34 20 E
Map references:
Middle East
Area:
total:
360 sq km
land:
360 sq km
water:
0 sq km
comparison ranking:
total 206
Area - comparative:
slightly more than twice the size of Washington, DC
Land boundaries:
total:
72 km
border countries (2):
Egypt 13 km; Israel 59 km
Coastline:
40 km
Maritime claims:
see entry for Israel note:
effective 3 January 2009, the Gaza maritime area is closed to all maritime traffic and is under blockade imposed by Israeli Navy until further notice
Climate:
temperate, mild winters, dry and warm to hot summers
Terrain:
flat to rolling, sand- and dune-covered coastal plain
Elevation:
highest point:
Abu ’Awdah (Joz Abu ’Awdah) 105 m
lowest point:
Mediterranean Sea 0 m
Natural resources:
arable land, natural gas
Irrigated land:
(2013) 151 sq km; note - includes the West Bank
Population distribution:
population concentrated in major cities, particularly Gaza City in the north
Natural hazards:
droughts
Geography - note:
once a strategic strip of land along Mideast-North African trade routes that has experienced an incredibly turbulent history; the town of Gaza itself has been besieged countless times in its history; Israel evacuated its civilian settlements and soldiers from the Gaza Strip in 2005','49b541fab998ddd725adf77243261c414a31759bfd71232d9fc5cf74571bcfef','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8dabf6d8d6121059410714d22bc474d205466e826c501a140059a1bbef66ab8f',2025,'GE','Georgia','geography',37,'Location:
Southwestern Asia, bordering the Black Sea, between Turkey and Russia, with a sliver of land north of the Caucasus extending into Europe; note - Georgia views itself as part of Europe; geopolitically, it can be classified as falling within Europe, the Middle East, or both
Geographic coordinates:
42 00 N, 43 30 E
Map references:
Asia
Area:
total:
69,700 sq km
land:
69,700 sq km
water:
0 sq km
note:
approximately 12,560 sq km, or about 18% of Georgia’s area, is Russian occupied; the seized area includes all of Abkhazia and the breakaway region of South Ossetia, which consists of the northern part of Shida Kartli, eastern slivers of the Imereti region and Racha-Lechkhumi and Kvemo Svaneti, and part of western Mtskheta-Mtianeti
comparison ranking:
total 121
Area - comparative:
slightly smaller than South Carolina; slightly larger than West Virginia
Land boundaries:
total:
1,814 km
border countries (4):
Armenia 219 km; Azerbaijan 428 km; Russia 894 km; Turkey 273 km
Coastline:
310 km
Maritime claims:
territorial sea:
12 nm
exclusive economic zone:
200 nm
Climate:
warm and pleasant; Mediterranean-like on Black Sea coast
Terrain:
largely mountainous with Great Caucasus Mountains in the north and Lesser Caucasus Mountains in the south; Kolkhet’is Dablobi (Kolkhida Lowland) opens to the Black Sea in the west; Mtkvari River Basin in the east; fertile soils in river valley flood plains and foothills of Kolkhida Lowland
Elevation:
highest point:
Mt’a Shkhara 5,193 m
lowest point:
Black Sea 0 m
mean elevation:
1,432 m
Natural resources:
timber, hydropower, manganese deposits, iron ore, copper, minor coal and oil deposits; coastal climate and soils allow for important tea and citrus growth
Land use:
agricultural land:
35.5% (2018 est.)
arable land:
5.8% (2018 est.)
permanent crops:
1.8% (2018 est.)
permanent pasture:
27.9% (2018 est.)
forest:
39.4% (2018 est.)
other:
25.1% (2018 est.)
Irrigated land:
4,330 sq km (2012)
Population distribution:
settlement concentrated in the central valley, particularly in the capital city of Tbilisi in the east; smaller urban agglomerations dot the Black Sea coast, with Bat’umi being the largest
Natural hazards:
earthquakes
Geography - note:
note 1:
strategically located east of the Black Sea; Georgia controls much of the Caucasus Mountains and the routes through them
note 2:
the world’s four deepest caves are all in Georgia, including two that are the only known caves on earth deeper than 2,000 m: Krubera Cave at -2,197 m (-7,208 ft; reached in 2012) and Veryovkina Cave at -2,212 (-7,257 ft; reached in 2018)','65d4a1ae0a104e36890ab45a800d20c7471729612b014406b989523fa84f1aef','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e89e3f97d993aca5884350579ad35f4c1a63bd64a4b9d02237d3e350888ac2e1',2025,'DE','Germany','geography',48,'Location:
Central Europe, bordering the Baltic Sea and the North Sea, between the Netherlands and Poland, south of Denmark
Geographic coordinates:
51 00 N, 9 00 E
Map references:
Europe
Area:
total:
357,022 sq km
land:
348,672 sq km
water:
8,350 sq km
comparison ranking:
total 64
Area - comparative:
three times the size of Pennsylvania; slightly smaller than Montana
Land boundaries:
total:
3,694 km
border countries (9):
Austria 801 km; Belgium 133 km; Czechia 704 km; Denmark 140 km; France 418 km; Luxembourg 128 km; Netherlands 575 km; Poland 447 km; Switzerland 348 km
Coastline:
2,389 km
Maritime claims:
territorial sea:
12 nm
exclusive economic zone:
200 nm
continental shelf:
200-m depth or to the depth of exploitation
Climate:
temperate and marine; cool, cloudy, wet winters and summers; occasional warm mountain (foehn) wind
Terrain:
lowlands in north, uplands in center, Bavarian Alps in south
Elevation:
highest point:
Zugspitze 2,963 m
lowest point:
Neuendorf bei Wilster -3.5 m
mean elevation:
263 m
Natural resources:
coal, lignite, natural gas, iron ore, copper, nickel, uranium, potash, salt, construction materials, timber, arable land
Land use:
agricultural land:
48% (2018 est.)
arable land:
34.1% (2018 est.)
permanent crops:
0.6% (2018 est.)
permanent pasture:
13.3% (2018 est.)
forest:
31.8% (2018 est.)
other:
20.2% (2018 est.)
Irrigated land:
5,056 sq km (2020)
Major lakes (area sq km):
fresh water lake(s):
Lake Constance (shared with Switzerland and Austria) - 540 sq km
salt water lake(s):
Stettiner Haff/Zalew Szczecinski (shared with Poland) - 900 sq km
Major rivers (by length in km):
Donau (Danube) river source (shared with Austria, Slovakia, Czechia, Hungary, Croatia, Serbia, Bulgaria, Ukraine, Moldova, and Romania [m]) - 2,888 km; Elbe river mouth (shared with Czechia [s]) - 1,252 km; Rhein (Rhine) (shared with Switzerland [s], France, and Netherlands [m]) - 1,233 km
note – [s] after country name indicates river source; [m] after country name indicates river mouth
Major watersheds (area sq km): Atlantic Ocean drainage:
Rhine-Maas (198,735 sq km), (Black Sea) Danube (795,656 sq km)
Population distribution:
second most populous country in Europe; a fairly even distribution throughout most of the country, with urban areas attracting larger and denser populations, particularly in the far western part of the industrial state of North Rhine-Westphalia
Natural hazards:
flooding
Geography - note:
strategic location on North European Plain and along the entrance to the Baltic Sea; most major rivers in Germany - the Rhine, Weser, Oder, Elbe - flow northward; the Danube, which originates in the Black Forest, flows eastward','c814aaca9d10b86f5914af357f0393df6e5094b402c3e9789d5db55fa0fab022','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('97669ecc05bfff50272ac1160126e15781bdc5fd77dd37ae3df4810b2fb9060d',2025,'GH','Ghana','geography',61,'Location:
Western Africa, bordering the Gulf of Guinea, between Cote d’Ivoire and Togo
Geographic coordinates:
8 00 N, 2 00 W
Map references:
Africa
Area:
total:
238,533 sq km
land:
227,533 sq km
water:
11,000 sq km
comparison ranking:
total 82
Area - comparative:
slightly smaller than Oregon
Land boundaries:
total:
2,420 km
border countries (3):
Burkina Faso 602 km; Cote d’Ivoire 720 km; Togo 1098 km
Coastline:
539 km
Maritime claims:
territorial sea:
12 nm
contiguous zone:
24 nm
exclusive economic zone:
200 nm
continental shelf:
200 nm
Climate:
tropical; warm and comparatively dry along southeast coast; hot and humid in southwest; hot and dry in north
Terrain:
mostly low plains with dissected plateau in south-central area
Elevation:
highest point:
Mount Afadjato 885 m
lowest point:
Atlantic Ocean 0 m
mean elevation:
190 m
Natural resources:
gold, timber, industrial diamonds, bauxite, manganese, fish, rubber, hydropower, petroleum, silver, salt, limestone
Land use:
agricultural land:
69.1% (2018 est.)
arable land:
20.7% (2018 est.)
permanent crops:
11.9% (2018 est.)
permanent pasture:
36.5% (2018 est.)
forest:
21.2% (2018 est.)
other:
9.7% (2018 est.)
Irrigated land:
360 sq km (2013)
Major rivers (by length in km):
Volta river mouth (shared with Burkina Faso [s]) - 1,600 km
note – [s] after country name indicates river source; [m] after country name indicates river mouth
Major watersheds (area sq km): Atlantic Ocean drainage:
Volta (410,991 sq km)
Population distribution:
population is concentrated in the southern half of the country, with the highest concentrations being on or near the Atlantic coast as shown in this population distribution map
Natural hazards:
dry, dusty, northeastern harmattan winds from January to March; droughts
Geography - note:
Lake Volta is the world’s largest artificial lake (manmade reservoir) by surface area (8,482 sq km; 3,275 sq mi); the lake was created following the completion of the Akosombo Dam in 1965, which holds back the White Volta and Black Volta Rivers','f9fe96e470b0f86805add56b51b3f55ac78e66d99f7829db3a62d2ff5562d5f0','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5c9635fc83b57664f28354cdd0abad6b811dc83efa584268dbfe2703ef64c28c',2025,'GI','Gibraltar','geography',2,'Location:
Southwestern Europe, bordering the Strait of Gibraltar, which links the Mediterranean Sea and the North Atlantic Ocean, on the southern coast of Spain
Geographic coordinates:
36 08 N, 5 21 W
Map references:
Europe
Area:
total:
7 sq km
land:
6.5 sq km
water:
0 sq km
comparison ranking:
total 245
Area - comparative:
more than 10 times the size of The National Mall in Washington, D.C.
Land boundaries:
total:
1.2 km
border countries (1):
Spain 1.2 km
Coastline:
12 km
Maritime claims:
territorial sea:
3 nm
Climate:
Mediterranean with mild winters and warm summers
Terrain:
a narrow coastal lowland borders the Rock of Gibraltar
Elevation:
highest point:
Rock of Gibraltar 426 m
lowest point:
Mediterranean Sea 0 m
Natural resources:
none
Land use:
agricultural land:
0% (2011 est.)
other:
100% (2018 est.)
Natural hazards:
occasional droughts; no streams or large bodies of water on the peninsula (all potable water comes from desalination)
Geography - note:
note 1:
strategic location on Strait of Gibraltar that links the North Atlantic Ocean and Mediterranean Sea
note 2:
one of only two British territories where traffic drives on the right, the other being the island of Diego Garcia in the British Indian Ocean Territory','e3070aa0873e6b7cb2a5117b9d8209b1fb7402d60dbbd4824f75b4f1bd7491b4','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4d3b150d082d68294f74d510b4211bb6f0274007b4e6363335860bcc8bb877c1',2025,'GR','Greece','geography',13,'Location:
Southern Europe, bordering the Aegean Sea, Ionian Sea, and the Mediterranean Sea, between Albania and Turkey
Geographic coordinates:
39 00 N, 22 00 E
Map references:
Europe
Area:
total:
131,957 sq km
land:
130,647 sq km
water:
1,310 sq km
comparison ranking:
total 97
Area - comparative:
slightly smaller than Alabama
Land boundaries:
total:
1,110 km
border countries (4):
Albania 212 km; Bulgaria 472 km; North Macedonia 234 km; Turkey 192 km
Coastline:
13,676 km
Maritime claims:
territorial sea:
6 nm
continental shelf:
200-m depth or to the depth of exploitation
Climate:
temperate; mild, wet winters; hot, dry summers
Terrain:
mountainous with ranges extending into the sea as peninsulas or chains of islands
Elevation:
highest point:
Mount Olympus 2,917
lowest point:
Mediterranean Sea 0 m
mean elevation:
498 m
note:
Mount Olympus actually has 52 peaks but its highest point, Mytikas (meaning “nose”), rises to 2,917 meters; in Greek mythology, Olympus’ Mytikas peak was the home of the Greek gods
Natural resources:
lignite, petroleum, iron ore, bauxite, lead, zinc, nickel, magnesite, marble, salt, hydropower potential
Land use:
agricultural land:
63.4% (2018 est.)
arable land:
19.7% (2018 est.)
permanent crops:
8.9% (2018 est.)
permanent pasture:
34.8% (2018 est.)
forest:
30.5% (2018 est.)
other:
6.1% (2018 est.)
Irrigated land:
11,853 sq km (2019)
Population distribution:
one-third of the population lives in and around metropolitan Athens; the remainder of the country has moderate population density mixed with sizeable urban clusters
Natural hazards:
severe earthquakes
volcanism:
Santorini (367 m) has been deemed a Decade Volcano by the International Association of Volcanology and Chemistry of the Earth’s Interior, worthy of study due to its explosive history and close proximity to human populations; although there have been very few eruptions in recent centuries, Methana and Nisyros in the Aegean are classified as historically active
Geography - note:
strategic location dominating the Aegean Sea and southern approach to Turkish Straits; a peninsular country, possessing an archipelago of about 2,000 islands','e233747b0841c7acec23c2c65df3c177053906b9c1fd8ac066ad9222f76f49a1','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('300da5d45200da784cc050d96039294feb6dfc182dea5080c59e8da00a68d224',2025,'GL','Greenland','geography',26,'Location:
Northern North America, island between the Arctic Ocean and the North Atlantic Ocean, northeast of Canada
Geographic coordinates:
72 00 N, 40 00 W
Map references:
Arctic Region
Area:
total:
2,166,086 sq km
land:
2,166,086 sq km (approximately 1,710,000 sq km ice-covered)
comparison ranking:
total 13
Area - comparative:
slightly more than three times the size of Texas
Land boundaries:
total:
0 km
Coastline:
44,087 km
Maritime claims:
territorial sea:
3 nm
continental shelf:
200 nm or agreed boundaries or median line
exclusive fishing zone:
200 nm or agreed boundaries or median line
Climate:
arctic to subarctic; cool summers, cold winters
Terrain:
flat to gradually sloping icecap covers all but a narrow, mountainous, barren, rocky coast
Elevation:
highest point:
Gunnbjorn Fjeld 3,694 m
lowest point:
Atlantic Ocean 0 m
mean elevation:
1,792 m
Natural resources:
coal, iron ore, lead, zinc, molybdenum, diamonds, gold, platinum, niobium, tantalite, uranium, fish, seals, whales, hydropower, possible oil and gas
Land use:
agricultural land:
0.6% (2018 est.)
arable land:
0% (2018 est.)
permanent crops:
0% (2018 est.)
permanent pasture:
0.6% (2018 est.)
forest:
0% (2018 est.)
other:
99.4% (2018 est.)
Population distribution:
settlement concentrated on the southwest shoreline, with limited settlements scattered along the remaining coast; interior is uninhabited
Natural hazards:
continuous permafrost over northern two-thirds of the island
Geography - note:
dominates North Atlantic Ocean between North America and Europe; sparse population confined to small settlements along coast; close to one-quarter of the population lives in the capital, Nuuk; world’s second largest ice sheet after that of Antarctica covering an area of 1.71 million sq km (660,000 sq mi) or about 79% of the island, and containing 2.85 million cu km (684 thousand cu mi) of ice (this is almost 7% of all of the world’s fresh water); if all this ice were converted to liquid water, one estimate is that it would be sufficient to raise the height of the world’s oceans by 7.2 m (24 ft)','3d28c32c34d37a128623874158d7f644bb1718cc8a26b543512dadd5b80e6f30','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7ad73316c51c1cbb730e69a76a5e4609e4be1004165c357f92f7c8ec48a2fd60',2025,'GD','Grenada','geography',37,'Location:
Caribbean, island between the Caribbean Sea and Atlantic Ocean, north of Trinidad and Tobago
Geographic coordinates:
12 07 N, 61 40 W
Map references:
Central America and the Caribbean
Area:
total:
344 sq km
land:
344 sq km
water:
0 sq km
comparison ranking:
total 207
Area - comparative:
twice the size of Washington, DC
Land boundaries:
total:
0 km
Coastline:
121 km
Maritime claims:
territorial sea:
12 nm
exclusive economic zone:
200 nm
Climate:
tropical; tempered by northeast trade winds
Terrain:
volcanic in origin with central mountains
Elevation:
highest point:
Mount Saint Catherine 840 m
lowest point:
Caribbean Sea 0 m
Natural resources:
timber, tropical fruit
Land use:
agricultural land:
32.3% (2018 est.)
arable land:
8.8% (2018 est.)
permanent crops:
20.6% (2018 est.)
permanent pasture:
2.9% (2018 est.)
forest:
50% (2018 est.)
other:
17.7% (2018 est.)
Irrigated land:
20 sq km (2012)
Population distribution:
approximately one-third of the population is found in the capital of St. George’s; the island’s population is concentrated along the coast
Natural hazards:
lies on edge of hurricane belt; hurricane season lasts from June to November
volcanism:
Mount Saint Catherine (840 m) lies on the island of Grenada; Kick ’em Jenny, an active submarine volcano (seamount) on the Caribbean Sea floor, lies about 8 km north of the island of Grenada; these two volcanoes are at the southern end of the volcanic island arc of the Lesser Antilles that extends up to the Netherlands dependency of Saba in the north
Geography - note:
the administration of the islands of the Grenadines group is divided between Saint Vincent and the Grenadines and Grenada','697c3f108d17f6dccb4e8cc6b20969c2732f59a4206aefe2f3ea187d9a3cd275','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('97efb0e354faac4824e0c176e7bfad2fdbf392b18dca59bcfb2c3217d51fe83e',2025,'GU','Guam','geography',48,'Location:
Oceania, island in the North Pacific Ocean, about three-quarters of the way from Hawaii to the Philippines
Geographic coordinates:
13 28 N, 144 47 E
Map references:
Oceania
Area:
total:
544 sq km
land:
544 sq km
water:
0 sq km
comparison ranking:
total 194
Area - comparative:
three times the size of Washington, DC
Land boundaries:
total:
0 km
Coastline:
125.5 km
Maritime claims:
territorial sea:
12 nm
exclusive economic zone:
200 nm
Climate:
tropical marine; generally warm and humid, moderated by northeast trade winds; dry season (January to June), rainy season (July to December); little seasonal temperature variation
Terrain:
volcanic origin, surrounded by coral reefs; relatively flat coralline limestone plateau (source of most fresh water), with steep coastal cliffs and narrow coastal plains in north, low hills in center, mountains in south
Elevation:
highest point:
Mount Lamlam 406 m
lowest point:
Pacific Ocean 0 m
Natural resources:
aquatic wildlife (supporting tourism), fishing (largely undeveloped)
Land use:
agricultural land:
33.4% (2018 est.)
arable land:
1.9% (2018 est.)
permanent crops:
16.7% (2018 est.)
permanent pasture:
14.8% (2018 est.)
forest:
47.9% (2018 est.)
other:
18.7% (2018 est.)
Irrigated land:
2 sq km (2012)
Population distribution:
no large cities exist on the island, though large villages (municipalities) attract much of the population; the largest of these is Dededo
Natural hazards:
frequent squalls during rainy season; relatively rare but potentially destructive typhoons (June to December)
Geography - note:
largest and southernmost island in the Mariana Islands archipelago and the largest island in Micronesia; strategic location in western North Pacific Ocean','c0dccf04bbfa58186aa7e75e141dd4bb697ba958df2752696762c1c4ca3ceed4','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('556508e9187f0eccd3d7a0544a1c618e2c69f224a18f01e1796652d89161d1d7',2025,'GT','Guatemala','geography',59,'Location:
Central America, bordering the North Pacific Ocean, between El Salvador and Mexico, and bordering the Gulf of Honduras (Caribbean Sea) between Honduras and Belize
Geographic coordinates:
15 30 N, 90 15 W
Map references:
Central America and the Caribbean
Area:
total:
108,889 sq km
land:
107,159 sq km
water:
1,730 sq km
comparison ranking:
total 107
Area - comparative:
slightly smaller than Pennsylvania
Land boundaries:
total:
1,667 km
border countries (4):
Belize 266 km; El Salvador 199 km; Honduras 244 km; Mexico 958 km
Coastline:
400 km
Maritime claims:
territorial sea:
12 nm
exclusive economic zone:
200 nm
continental shelf:
200-m depth or to the depth of exploitation
Climate:
tropical; hot, humid in lowlands; cooler in highlands
Terrain:
two east-west trending mountain chains divide the country into three regions:
the mountainous highlands, the Pacific coast south of mountains, and the vast northern Peten lowlands
Elevation:
highest point:
Volcan Tajumulco (highest point in Central America) 4,220 m
lowest point:
Pacific Ocean 0 m
mean elevation:
759 m
Natural resources:
petroleum, nickel, rare woods, fish, chicle, hydropower
Land use:
agricultural land:
41.2% (2018 est.)
arable land:
14.2% (2018 est.)
permanent crops:
8.8% (2018 est.)
permanent pasture:
18.2% (2018 est.)
forest:
33.6% (2018 est.)
other:
25.2% (2018 est.)
Irrigated land:
3,375 sq km (2012)
Major lakes (area sq km):
fresh water lake(s):
Lago de Izabal - 590 sq km
Population distribution:
the vast majority of the populace resides in the southern half of the country, particularly in the mountainous regions; more than half of the population lives in rural areas
Natural hazards:
numerous volcanoes in mountains, with occasional violent earthquakes; Caribbean coast extremely susceptible to hurricanes and other tropical storms
volcanism:
significant volcanic activity in the Sierra Madre range; Santa Maria (3,772 m) has been deemed a Decade Volcano by the International Association of Volcanology and Chemistry of the Earth’s Interior, worthy of study due to its explosive history and close proximity to human populations; Pacaya (2,552 m), which erupted in May 2010 causing an ashfall on Guatemala City and prompting evacuations, is one of the country’s most active volcanoes with frequent eruptions since 1965; other historically active volcanoes include Acatenango, Almolonga, Atitlan, Fuego, and Tacana; see note 2 under “Geography - note”
Geography - note:
note 1:
despite having both eastern and western coastlines (Caribbean Sea and Pacific Ocean respectively), there are no natural harbors on the west coast
note 2:
Guatemala is one of the countries along the Ring of Fire, a belt of active volcanoes and earthquake epicenters bordering the Pacific Ocean; up to 90% of the world’s earthquakes and some 75% of the world’s volcanoes occur within the Ring of Fire','87af47f3f89a0d2e321523bfddf736105a3a2013d229b9688a0f60582d80be58','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('37c93a61d36699b9258c1aeb180457e51257e084f8f5f7084b82e8514fe7d0f6',2025,'GG','Guernsey','geography',2,'Location:
Western Europe, islands in the English Channel, northwest of France
Geographic coordinates:
49 28 N, 2 35 W
Map references:
Europe
Area:
total:
78 sq km
land:
78 sq km
water:
0 sq km
note:
includes Alderney, Guernsey, Herm, Sark, and some other smaller islands
comparison ranking:
total 227
Area - comparative:
about one-half the size of Washington, DC
Land boundaries:
total:
0 km
Coastline:
50 km
Maritime claims:
territorial sea:
12 nm
exclusive fishing zone:
12 nm
Climate:
temperate with mild winters and cool summers; about 50% of days are overcast
Terrain:
mostly flat with low hills in southwest
Elevation:
highest point:
Le Moulin on Sark 114 m
lowest point:
English Channel 0 m
Natural resources:
Cropland
Natural hazards:
very large tidal variation and fast currents can make local waters dangerous
Geography - note:
large, deepwater harbor at Saint Peter Port','73e0f7a78de08b92300728b7d89b9c4173fba61df5b8ee8f71175095b7df7f95','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('945c99f160b06e29b24fd816589a836dd85c5b1214e1e556d7811a4e73a934fe',2025,'GN','Guinea','geography',13,'Location:
Western Africa, bordering the North Atlantic Ocean, between Guinea-Bissau and Sierra Leone
Geographic coordinates:
11 00 N, 10 00 W
Map references:
Africa
Area:
total:
245,857 sq km
land:
245,717 sq km
water:
140 sq km
comparison ranking:
total 79
Area - comparative:
slightly smaller than Oregon; slightly larger than twice the size of Pennsylvania
Land boundaries:
total:
4,046 km
border countries (6):
Cote d’Ivoire 816 km; Guinea-Bissau 421 km; Liberia 590 km; Mali 1062 km; Senegal 363 km; Sierra Leone 794 km
Coastline:
320 km
Maritime claims:
territorial sea:
12 nm
exclusive economic zone:
200 nm
Climate:
generally hot and humid; monsoonal-type rainy season (June to November) with southwesterly winds; dry season (December to May) with northeasterly harmattan winds
Terrain:
generally flat coastal plain, hilly to mountainous interior
Elevation:
highest point:
Mont Nimba 1,752 m
lowest point:
Atlantic Ocean 0 m
mean elevation:
472 m
Natural resources:
bauxite, iron ore, diamonds, gold, uranium, hydropower, fish, salt
Land use:
agricultural land:
58.1% (2018 est.)
arable land:
11.8% (2018 est.)
permanent crops:
2.8% (2018 est.)
permanent pasture:
43.5% (2018 est.)
forest:
26.5% (2018 est.)
other:
15.4% (2018 est.)
Irrigated land:
950 sq km (2012)
Major rivers (by length in km):
Niger river source (shared with Mali, and Nigeria [m]) - 4,200 km; Gambie (Gambia) river source (shared with Senegal and The Gambia [m]) - 1,094 km
note – [s] after country name indicates river source; [m] after country name indicates river mouth
Major watersheds (area sq km): Atlantic Ocean drainage:
Niger (2,261,741 sq km), Senegal (456,397 sq km)
Population distribution:
areas of highest density are in the west and south; interior is sparsely populated as shown in this population distribution map
Natural hazards:
hot, dry, dusty harmattan haze may reduce visibility during dry season
Geography - note:
the Niger and its important tributary the Milo River have their sources in the Guinean highlands','6943be4c95832afff674dec04928676997a98de538bb15db98a63971e9bac951','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('65cc024955c40285d8095101dc5b51616cb4d5fc91f4da962145f51315dec4dc',2025,'GW','Guinea-Bissau','geography',24,'Location:
Western Africa, bordering the North Atlantic Ocean, between Guinea and Senegal
Geographic coordinates:
12 00 N, 15 00 W
Map references:
Africa
Area:
total:
36,125 sq km
land:
28,120 sq km
water:
8,005 sq km
comparison ranking:
total 137
Area - comparative:
slightly less than three times the size of Connecticut
Land boundaries:
total:
762 km
border countries (2):
Guinea 421 km; Senegal 341 km
Coastline:
350 km
Maritime claims:
territorial sea:
12 nm
exclusive economic zone:
200 nm
Climate:
tropical; generally hot and humid; monsoonal-type rainy season (June to November) with southwesterly winds; dry season (December to May) with northeasterly harmattan winds
Terrain:
mostly low-lying coastal plain with a deeply indented estuarine coastline rising to savanna in east; numerous off-shore islands including the Arquipelago Dos Bijagos consisting of 18 main islands and many small islets
Elevation:
highest point:
Dongol Ronde 277 m
lowest point:
Atlantic Ocean 0 m
mean elevation:
70 m
Natural resources:
fish, timber, phosphates, bauxite, clay, granite, limestone, unexploited deposits of petroleum
Land use:
agricultural land:
44.8% (2018 est.)
arable land:
8.2% (2018 est.)
permanent crops:
6.9% (2018 est.)
permanent pasture:
29.7% (2018 est.)
forest:
55.2% (2018 est.)
other:
0% (2018 est.)
Irrigated land:
250 sq km (2012)
Major aquifers:
Senegalo-Mauritanian Basin
Population distribution:
approximately one-fifth of the population lives in the capital city of Bissau along the Atlantic coast; the remainder is distributed among the eight other, mainly rural, regions as shown in this population distribution map
Natural hazards:
hot, dry, dusty harmattan haze may reduce visibility during dry season; brush fires
Geography - note:
this small country is swampy along its western coast and low-lying inland','ee73ae417671712878244378032442e9966c9870658f21feee93ff94b7f9b7b9','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('648c4d96965bfe354b6aa1d20b9ac062902fd64ba3bb281b246173d8c757f4fb',2025,'GY','Guyana','geography',35,'Location:
Northern South America, bordering the North Atlantic Ocean, between Suriname and Venezuela
Geographic coordinates:
5 00 N, 59 00 W
Map references:
South America
Area:
total:
214,969 sq km
land:
196,849 sq km
water:
18,120 sq km
comparison ranking:
total 85
Area - comparative:
slightly smaller than Idaho; almost twice the size of Tennessee
Land boundaries:
total:
2,933 km
border countries (3):
Brazil 1,308 km; Suriname 836 km; Venezuela 789 km
Coastline:
459 km
Maritime claims:
territorial sea:
12 nm
exclusive economic zone:
200 nm
continental shelf:
200 nm or to the outer edge of the continental margin
Climate:
tropical; hot, humid, moderated by northeast trade winds; two rainy seasons (May to August, November to January)
Terrain:
mostly rolling highlands; low coastal plain; savanna in south
Elevation:
highest point:
Laberintos del Norte on Mount Roraima 2,775 m
lowest point:
Atlantic Ocean 0 m
mean elevation:
207 m
Natural resources:
bauxite, gold, diamonds, hardwood timber, shrimp, fish
Land use:
agricultural land:
8.4% (2018 est.)
arable land:
2.1% (2018 est.)
permanent crops:
0.1% (2018 est.)
permanent pasture:
6.2% (2018 est.)
forest:
77.4% (2018 est.)
other:
14.2% (2018 est.)
Irrigated land:
1,430 sq km (2012)
Major watersheds (area sq km): Atlantic Ocean drainage:
Amazon (6,145,186 sq km), Orinoco (953,675 sq km)
Population distribution:
population is heavily concentrated in the northeast in and around Georgetown, with noteable concentrations along the Berbice River to the east; the remainder of the country is sparsely populated
Natural hazards:
flash flood threat during rainy seasons
Geography - note:
the third-smallest country in South America after Suriname and Uruguay; substantial portions of its western and eastern territories are claimed by Venezuela and Suriname respectively; contains some of the largest unspoiled rainforests on the continent','07a202dc1f8b72436d2341f8c85f06b8393cd7085c08cc59a779ef875888f28b','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bbe982da2022a804e70cc66ec3990944c9569199645e84d4766c48b6c2e6c893',2025,'HT','Haiti','geography',2,'Location:
Caribbean, western one-third of the island of Hispaniola, between the Caribbean Sea and the North Atlantic Ocean, west of the Dominican Republic
Geographic coordinates:
19 00 N, 72 25 W
Map references:
Central America and the Caribbean
Area:
total:
27,750 sq km
land:
27,560 sq km
water:
190 sq km
comparison ranking:
total 147
Area - comparative:
slightly smaller than Maryland
Land boundaries:
total:
376 km
border countries (1):
Dominican Republic 376 km
Coastline:
1,771 km
Maritime claims:
territorial sea:
12 nm
contiguous zone:
24 nm
exclusive economic zone:
200 nm
continental shelf:
to depth of exploitation
Climate:
tropical; semiarid where mountains in east cut off trade winds
Terrain:
mostly rough and mountainous
Elevation:
highest point:
Pic la Selle 2,674 m
lowest point:
Caribbean Sea 0 m
mean elevation:
470 m
Natural resources:
bauxite, copper, calcium carbonate, gold, marble, hydropower, arable land
Land use:
agricultural land:
66.4% (2018 est.)
arable land:
38.5% (2018 est.)
permanent crops:
10.2% (2018 est.)
permanent pasture:
17.7% (2018 est.)
forest:
3.6% (2018 est.)
other:
30% (2018 est.)
Irrigated land:
800 sq km (2013)
Population distribution:
fairly even distribution; largest concentrations located near coastal areas
Natural hazards:
lies in the middle of the hurricane belt and subject to severe storms from June to October; occasional flooding and earthquakes; periodic droughts
Geography - note:
shares island of Hispaniola with Dominican Republic (western one-third is Haiti, eastern two-thirds is the Dominican Republic); it is the most mountainous nation in the Caribbean','54dd1b147a515f7569e02f86d40868fcdc7cd906a2de640a25cfe6b4962d8101','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('327c650af171b398c6c3ef953c31008f1be86994c5af303cd0dbbf16a7e6355c',2025,'HM','Heard Island and McDonald Islands','geography',13,'Location:
islands in the Indian Ocean, about two-thirds of the way from Madagascar to Antarctica
Geographic coordinates:
53 06 S, 72 31 E
Map references:
Antarctic Region
Area:
total:
412 sq km
land:
412 sq km
water:
0 sq km
comparison ranking:
total 202
Area - comparative:
slightly more than two times the size of Washington, DC
Land boundaries:
total:
0 km
Coastline:
101.9 km
Maritime claims:
territorial sea:
12 nm
exclusive fishing zone:
200 nm
Climate:
antarctic
Terrain:
Heard Island - 80% ice-covered, bleak and mountainous, dominated by a large massif (Big Ben) and an active volcano (Mawson Peak); McDonald Islands - small and rocky
Elevation:
highest point:
Mawson Peak on Big Ben volcano 2,745 m
lowest point:
Indian Ocean 0 m
Natural resources:
fish
Land use:
agricultural land:
0% (2011 est.)
other:
100% (2018 est.)
Natural hazards:
Mawson Peak, an active volcano, is on Heard Island
Geography - note:
Mawson Peak on Heard Island is the highest Australian mountain (at 2,745 meters, it is taller than Mt. Kosciuszko in Australia proper), and one of only two active volcanoes located in Australian territory, the other being McDonald Island; in 1992, McDonald Island broke its dormancy and began erupting; it has erupted several times since, most recently in 2005','b6e107c2a8595caf8a7f7c7d29e08c196519cc412f3ccbe50057e049a7d3256e','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a1093de99a33bf1a8629fd4b7458a7ca0cfa817f9109a7eec67dff0377d489d1',2025,'HM','Heard Island and McDonald Islands','geography',22,'Location:
Southern Europe, an enclave of Rome (Italy)
Geographic coordinates:
41 54 N, 12 27 E
Map references:
Europe
Area:
total:
0 sq km
land:
0.44 sq km
water:
0 sq km
comparison ranking:
total 257
Area - comparative:
about 0.7 times the size of the National Mall in Washington, DC
Land boundaries:
total:
3.4 km
border countries (1):
Italy 3.4 km
Coastline:
0 km (landlocked)
Maritime claims:
none (landlocked)
Climate:
temperate; mild, rainy winters (September to May) with hot, dry summers (May to September)
Terrain:
urban; low hill
Elevation:
highest point:
Vatican Gardens (Vatican Hill) 78 m
lowest point:
Saint Peter’s Square 19 m
Natural resources:
None
Land use:
agricultural land:
0% (2018 est.)
other:
100% (2018 est.)
Natural hazards:
occasional earthquakes
Geography - note:
landlocked; an enclave in Rome, Italy; world’s smallest state; beyond the territorial boundary of Vatican City, the Lateran Treaty of 1929 grants the Holy See extraterritorial authority over 23 sites in Rome and five outside of Rome, including the Pontifical Palace at Castel Gandolfo (the Pope’s summer residence)','6f1ae2463643a926c2c95deb3aa6a05c931530c9f91175a688abaff627bdf37a','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4f94a2cfbc160fcc8483aa8a392af43b42306ba890ad3d51556f30d501e0b1df',2025,'HN','Honduras','geography',32,'Location:
Central America, bordering the Caribbean Sea, between Guatemala and Nicaragua and bordering the Gulf of Fonseca (North Pacific Ocean), between El Salvador and Nicaragua
Geographic coordinates:
15 00 N, 86 30 W
Map references:
Central America and the Caribbean
Area:
total:
112,090 sq km
land:
111,890 sq km
water:
200 sq km
comparison ranking:
total 103
Area - comparative:
slightly larger than Tennessee
Land boundaries:
total:
1,575 km
border countries (3):
Guatemala 244 km; El Salvador 391 km; Nicaragua 940 km
Coastline:
823 km (Caribbean Sea 669 km, Gulf of Fonseca 163 km)
Maritime claims:
territorial sea:
12 nm
contiguous zone:
24 nm
exclusive economic zone:
200 nm
continental shelf:
natural extension of territory or to 200 nm
Climate:
subtropical in lowlands, temperate in mountains
Terrain:
mostly mountains in interior, narrow coastal plains
Elevation:
highest point:
Cerro Las Minas 2,870 m
lowest point:
Caribbean Sea 0 m
mean elevation:
684 m
Natural resources:
timber, gold, silver, copper, lead, zinc, iron ore, antimony, coal, fish, hydropower
Land use:
agricultural land:
28.8% (2018 est.)
arable land:
9.1% (2018 est.)
permanent crops:
4% (2018 est.)
permanent pasture:
15.7% (2018 est.)
forest:
45.3% (2018 est.)
other:
25.9% (2018 est.)
Irrigated land:
900 sq km (2012)
Major lakes (area sq km):
salt water lake(s):
Laguna de Caratasca - 1,110 sq km
Population distribution:
most residents live in the mountainous western half of the country; unlike other Central American nations, Honduras is the only one with an urban population that is distributed between two large centers - the capital of Tegucigalpa and the city of San Pedro Sula; the Rio Ulua valley in the north is the only densely populated lowland area
Natural hazards:
frequent, but generally mild, earthquakes; extremely susceptible to damaging hurricanes and floods along the Caribbean coast
Geography - note:
has only a short Pacific coast but a long Caribbean shoreline, including the virtually uninhabited eastern Mosquito Coast','cdb9619cdcc2b2113ee67223ad00ac08b42964ce95fe2abb0145172987aead5d','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ade912a00281fe0fd4ba87699a2b4aef550624c23c2b5e5a06535e3ced7e9847',2025,'HK','Hong Kong','geography',43,'Location:
Eastern Asia, bordering the South China Sea and China
Geographic coordinates:
22 15 N, 114 10 E
Map references:
Southeast Asia
Area:
total:
1,108 sq km
land:
1,073 sq km
water:
35 sq km
comparison ranking:
total 183
Area - comparative:
six times the size of Washington, DC
Land boundaries:
total:
33 km
regional borders (1):
China 33 km
Coastline:
733 km
Maritime claims:
territorial sea:
12 nm
Climate:
subtropical monsoon; cool and humid in winter, hot and rainy from spring through summer, warm and sunny in fall
Terrain:
hilly to mountainous with steep slopes; lowlands in north
Elevation:
highest point:
Tai Mo Shan 958 m
lowest point:
South China Sea 0 m
Natural resources:
outstanding deepwater harbor, feldspar
Land use:
agricultural land:
5% (2018 est.)
arable land:
3.2% (2018 est.)
permanent crops:
0.9% (2018 est.)
permanent pasture:
0.9% (2018 est.)
forest:
0% (2018 est.)
other:
95% (2018 est.)
Irrigated land:
10 sq km (2012)
Population distribution:
population fairly evenly distributed
Natural hazards:
occasional typhoons
Geography - note:
consists of a mainland area (the New Territories) and more than 200 islands','c6ca638b7819a451a8373d5fcc27bf69a94fcb3df1c9b01fee783b26fcdd6cd6','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0f9f6b96c70ba8c77a2f45468ee0fe1d995517ce220194d9c11ec2f1cecc91c9',2025,'HU','Hungary','geography',55,'Location:
Central Europe, northwest of Romania
Geographic coordinates:
47 00 N, 20 00 E
Map references:
Europe
Area:
total:
93,028 sq km
land:
89,608 sq km
water:
3,420 sq km
comparison ranking:
total 110
Area - comparative:
slightly smaller than Virginia; about the same size as Indiana
Land boundaries:
total:
2,106 km
border countries (7):
Austria 321 km; Croatia 348 km; Romania 424 km; Serbia 164 km; Slovakia 627 km; Slovenia 94 km; Ukraine 128 km
Coastline:
0 km (landlocked)
Maritime claims:
none (landlocked)
Climate:
temperate; cold, cloudy, humid winters; warm summers
Terrain:
mostly flat to rolling plains; hills and low mountains on the Slovakian border
Elevation:
highest point:
Kekes 1,014 m
lowest point:
Tisza River 78 m
mean elevation:
143 m
Natural resources:
bauxite, coal, natural gas, fertile soils, arable land
Land use:
agricultural land:
58.9% (2018 est.)
arable land:
48.5% (2018 est.)
permanent crops:
2% (2018 est.)
permanent pasture:
8.4% (2018 est.)
forest:
22.5% (2018 est.)
other:
18.6% (2018 est.)
Irrigated land:
1,010 sq km (2019)
Major lakes (area sq km):
fresh water lake(s):
Lake Balaton - 590 sq km
Major rivers (by length in km):
Duna (Danube) (shared with Germany [s], Austria, Slovakia, Croatia, Serbia, Bulgaria, Ukraine, Moldova, and Romania [m]) - 2,888 km
note –
[s] after country name indicates river source; [m] after country name indicates river mouth
Major watersheds (area sq km): Atlantic Ocean drainage:
(Black Sea) Danube (795,656 sq km)
Population distribution:
a fairly even distribution throughout most of the country, with urban areas attracting larger and denser populations
Geography - note:
landlocked; strategic location astride main land routes between Western Europe and Balkan Peninsula as well as between Ukraine and Mediterranean basin; the north-south flowing Duna (Danube) and Tisza Rivers divide the country into three large regions','2b82e6fc7eeea1fc5888b147c42cb557a77fc1d90e6a0c5e23e4579e4563adad','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b70082e4bc81d675a2c060e87312809792c7c1be6415b991b1b68981b31ec3f6',2025,'IS','Iceland','geography',2,'Location:
Northern Europe, island between the Greenland Sea and the North Atlantic Ocean, northwest of the United Kingdom
Geographic coordinates:
65 00 N, 18 00 W
Map references:
Arctic Region
Area:
total:
103,000 sq km
land:
100,250 sq km:
water:
2,750 sq km
comparison ranking:
total 108
Area - comparative:
slightly smaller than Pennsylvania; about the same size as Kentucky
Land boundaries:
total:
0 km
Coastline:
4,970 km
Maritime claims:
territorial sea:
12 nm
exclusive economic zone:
200 nm
continental shelf:
200 nm or to the edge of the continental margin
Climate:
temperate; moderated by North Atlantic Current; mild, windy winters; damp, cool summers
Terrain:
mostly plateau interspersed with mountain peaks, icefields; coast deeply indented by bays and fiords
Elevation:
highest point:
Hvannadalshnukur (at Vatnajokull Glacier) 2,110 m
lowest point:
Atlantic Ocean 0 m
mean elevation:
557 m
Natural resources:
fish, hydropower, geothermal power, diatomite
Land use:
agricultural land:
18.7% (2018 est.)
arable land:
1.2% (2018 est.)
permanent crops:
0% (2018 est.)
permanent pasture:
17.5% (2018 est.)
forest:
0.3% (2018 est.)
other:
81% (2018 est.)
Irrigated land:
0.5 sq km (2020)
Population distribution:
Iceland is almost entirely urban with half of the population located in and around the capital of Reykjavik; smaller clusters are primarily found along the coast in the north and west
Natural hazards:
earthquakes and volcanic activity
volcanism:
Iceland, situated on top of a hotspot, experiences severe volcanic activity; Eyjafjallajokull (1,666 m) erupted in 2010, sending ash high into the atmosphere and seriously disrupting European air traffic; scientists continue to monitor nearby Katla (1,512 m), which has a high probability of eruption in the very near future, potentially disrupting air traffic; Grimsvoetn and Hekla are Iceland’s most active volcanoes; other historically active volcanoes include Askja, Bardarbunga, Brennisteinsfjoll, Esjufjoll, Hengill, Krafla, Krisuvik, Kverkfjoll, Oraefajokull, Reykjanes, Torfajokull, and Vestmannaeyjar
Geography - note:
strategic location between Greenland and Europe; westernmost European country; Reykjavik is the northernmost national capital in the world; more land covered by glaciers than in all of continental Europe','4c899b7f77df17f40c6b03003e32afddaf9fee7cf86993aab1f2ffcbed3810f9','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f14b762e4c9a53994114c3bb00b7c55186a76ebc7d7b27a53402b4c1f84d0b29',2025,'IN','India','geography',13,'Location:
Southern Asia, bordering the Arabian Sea and the Bay of Bengal, between Burma and Pakistan
Geographic coordinates:
20 00 N, 77 00 E
Map references:
Asia
Area:
total:
3,287,263 sq km
land:
2,973,193 sq km
water:
314,070 sq km
comparison ranking:
total 8
Area - comparative:
slightly more than one-third the size of the US
Land boundaries:
total:
13,888 km
border countries (6):
Bangladesh 4,142 km; Bhutan 659 km; Burma 1,468 km; China 2,659 km; Nepal 1,770 km; Pakistan 3,190 km
Coastline:
7,000 km
Maritime claims:
territorial sea:
12 nm
contiguous zone:
24 nm
exclusive economic zone:
200 nm
continental shelf:
200 nm or to the edge of the continental margin
Climate:
varies from tropical monsoon in south to temperate in north
Terrain:
upland plain (Deccan Plateau) in south, flat to rolling plain along the Ganges, deserts in west, Himalayas in north
Elevation:
highest point:
Kanchenjunga 8,586 m
lowest point:
Indian Ocean 0 m
mean elevation:
160 m
Natural resources:
coal (fourth-largest reserves in the world), antimony, iron ore, lead, manganese, mica, bauxite, rare earth elements, titanium ore, chromite, natural gas, diamonds, petroleum, limestone, arable land
Land use:
agricultural land:
60.5% (2018 est.)
arable land:
52.8% (2018 est.)
permanent crops:
4.2% (2018 est.)
permanent pasture:
3.5% (2018 est.)
forest:
23.1% (2018 est.)
other:
16.4% (2018 est.)
Irrigated land:
715,539 sq km (2020)
Major lakes (area sq km):
salt water lake(s):
Chilika Lake - 1,170 sq km
Major rivers (by length in km):
Brahmaputra (shared with China [s] and Bangladesh [m]) - 3,969 km; Indus (shared with China [s] and Pakistan [m]) - 3,610 km; Ganges river source (shared with Bangladesh [m]) - 2,704 km; Godavari - 1,465 km; Sutlej (shared with China [s] and Pakistan [m]) - 1,372 km; Yamuna - 1,370 km; Narmada - 1,289 km; Chenab river source (shared with Pakistan [m]) - 1,086 km; Ghaghara river mouth (shared with China [s] and Nepal) - 1,080 km
note
– [s] after country name indicates river source; [m] after country name indicates river mouth
Major watersheds (area sq km): Indian Ocean drainage:
Brahmaputra (651,335 sq km), Ganges (1,016,124 sq km), Indus (1,081,718 sq km), Irrawaddy (413,710 sq km)
Major aquifers:
Indus-Ganges-Brahmaputra Basin
Population distribution:
with the notable exception of the deserts in the northwest, including the Thar Desert, and the mountain fringe in the north, a very high population density exists throughout most of the country; the core of the population is in the north along the banks of the Ganges, with other river valleys and southern coastal areas also having large population concentrations
Natural hazards:
droughts; flash floods, as well as widespread and destructive flooding from monsoonal rains; severe thunderstorms; earthquakes
volcanism:
Barren Island (354 m) in the Andaman Sea has been active in recent years
Geography - note:
dominates South Asian subcontinent; near important Indian Ocean trade routes; Kanchenjunga, third tallest mountain in the world, lies on the border with Nepal','314f31105a0dbbd7afb076576c01ebd6e14568acabe2b29dc342825fffd98ef8','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('77928db1f1bddc9c92314aa02b02255fba237aa4f64599cd35380590e6fb5317',2025,'IN','India','geography',26,'Location:
body of water between Africa, the Southern Ocean, Asia, and Australia
Geographic coordinates:
20 00 S, 80 00 E
Map references:
Political Map of the World
Area:
total:
70.56 million sq km
note:
includes Andaman Sea, Arabian Sea, Bay of Bengal, Great Australian Bight, Gulf of Aden, Gulf of Oman, Mozambique Channel, Persian Gulf, Red Sea, Savu Sea, Strait of Malacca, Timor Sea, and other tributary water bodies
Area - comparative:
almost 7 times the size of the US
Coastline:
66,526 km
Climate:
northeast monsoon (December to April), southwest monsoon (June to October); tropical cyclones occur during May/June and October/November in the northern Indian Ocean and January/February in the southern Indian Ocean
Ocean volume:
ocean volume:
264 million cu km
percent of World Ocean total volume:
19.8%
Major ocean currents:
the counterclockwise Indian Ocean Gyre comprised of the southward flowing warm Agulhas and East Madagascar Currents in the west, the eastward flowing South Indian Current in the south, the northward flowing cold West Australian Current in the east, and the westward flowing South Equatorial Current in the north; a distinctive annual reversal of surface currents occurs in the northern Indian Ocean; low atmospheric pressure over southwest Asia from hot, rising, summer air results in the southwest monsoon and southwest-to-northeast winds and clockwise currents, while high pressure over northern Asia from cold, falling, winter air results in the northeast monsoon and northeast-to-southwest winds and counterclockwise currents
Elevation:
highest point:
sea level
lowest point:
Java Trench -7,192 m unnamed deep
mean depth:
-3,741 m
ocean zones:
Composed of water and in a fluid state, the oceans are delimited differently than the solid continents. Oceans are divided into three zones based on depth and light level. Although some sea creatures depend on light to live, others can do without it. Sunlight entering the water may travel about 1,000 m into the oceans under the right conditions, but there is rarely any significant light beyond 200 m.
The upper 200 m (656 ft) of oceans is called the euphotic, or “sunlight,” zone. This zone contains the vast majority of commercial fisheries and is home to many protected marine mammals and sea turtles. Only a small amount of light penetrates beyond this depth.
The zone between 200 m (656 ft) and 1,000 m (3,280 ft) is usually referred to as the “twilight” zone, but is officially the dysphotic zone. In this zone, the intensity of light rapidly dissipates as depth increases. Such a minuscule amount of light penetrates beyond a depth of 200 m that photosynthesis is no longer possible.
The aphotic, or “midnight,” zone exists in depths below 1,000 m (3,280 ft). Sunlight does not penetrate to these depths and the zone is bathed in darkness.
Distance Sunlight Travels in the Ocean:
Natural resources oil and gas fields, fish, shrimp, sand and gravel aggregates, placer deposits, polymetallic nodules
Natural hazards:
occasional icebergs pose navigational hazard in southern reaches
Geography - note:
major chokepoints include Bab el Mandeb, Strait of Hormuz, Strait of Malacca, southern access to the Suez Canal, and the Lombok Strait','d4f664a64687dafa3644ba06e60c1e06922a918c330388f49939b657a88cb25d','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('61f1a7c6d2bcd3a437cb4834f72bb56a84d44a3dae94b48ddf7fefb57da75491',2025,'ID','Indonesia','geography',33,'Location:
Southeastern Asia, archipelago between the Indian Ocean and the Pacific Ocean
Geographic coordinates:
5 00 S, 120 00 E
Map references:
Southeast Asia
Area:
total:
1,904,569 sq km
land:
1,811,569 sq km
water:
93,000 sq km
comparison ranking:
total 16
Area - comparative:
slightly less than three times the size of Texas
Land boundaries:
total:
2,958 km
border countries (3):
Malaysia 1,881 km; Papua New Guinea 824 km; Timor-Leste 253 km
Coastline:
54,716 km
Maritime claims:
territorial sea:
12 nm
exclusive economic zone:
200 nm
measured from claimed archipelagic straight baselines
Climate:
tropical; hot, humid; more moderate in highlands
Terrain:
mostly coastal lowlands; larger islands have interior mountains
Elevation:
highest point:
Puncak Jaya 4,884 m
lowest point:
Indian Ocean 0 m
mean elevation:
367 m
Natural resources:
petroleum, tin, natural gas, nickel, timber, bauxite, copper, fertile soils, coal, gold, silver
note:
Indonesia is the World’s leading producer of nickel with an output of 1.6 million mt in 2022
Land use:
agricultural land:
31.2% (2018 est.)
arable land:
13% (2018 est.)
permanent crops:
12.1% (2018 est.)
permanent pasture:
6.1% (2018 est.)
forest:
51.7% (2018 est.)
other:
17.1% (2018 est.)
Irrigated land:
67,220 sq km (2012)
Major lakes (area sq km):
fresh water lake(s):
Danau Toba - 1,150 sq km
note
– located in the caldera of a super volcano that erupted more than 70,000 years ago; it is the largest volcanic lake in the World
Major rivers (by length in km):
Sepik (shared with Papua New Guinea [s]) - 1,126 km; Fly (shared with Papua New Guinea [s]) - 1,050 km
note
– [s] after country name indicates river source; [m] after country name indicates river mouth
Population distribution:
major concentration on the island of Java, which is considered one of the most densely populated places on earth; of the outer islands (those surrounding Java and Bali), Sumatra contains some of the most significant clusters, particularly in the south near the Selat Sunda, and along the northeastern coast near Medan; the cities of Makasar (Sulawesi), Banjarmasin (Kalimantan) are also heavily populated
Natural hazards:
occasional floods; severe droughts; tsunamis; earthquakes; volcanoes; forest fires
volcanism:
Indonesia contains the most volcanoes of any country in the world - some 76 are historically active; significant volcanic activity occurs on Java, Sumatra, the Sunda Islands, Halmahera Island, Sulawesi Island, Sangihe Island, and in the Banda Sea; Merapi (2,968 m), Indonesia’s most active volcano and in eruption since 2010, has been deemed a Decade Volcano by the International Association of Volcanology and Chemistry of the Earth’s Interior, worthy of study due to its explosive history and close proximity to human populations; on 22 December 2018, a large explosion and flank collapse destroyed most of the 338 m high island of Anak Krakatau (Child of Krakatau) and generated a deadly tsunami inundating portions of western Java and southern Sumatra leaving more than 400 dead; other notable historically active volcanoes include Agung, Awu, Karangetang, Krakatau (Krakatoa), Makian, Raung, Sinabung, and Tambora; see note 2 under “Geography - note”
Geography - note:
note 1:
according to Indonesia’s National Coordinating Agency for Survey and Mapping, the total number of islands in the archipelago is 13,466, of which 922 are permanently inhabited (Indonesia is the world’s largest country comprised solely of islands); the country straddles the equator and occupies a strategic location astride or along major sea lanes from the Indian Ocean to the Pacific Ocean
note 2:
Indonesia is one of the countries along the Ring of Fire, a belt of active volcanoes and earthquake epicenters bordering the Pacific Ocean; up to 90% of the world’s earthquakes and some 75% of the world’s volcanoes occur within the Ring of Fire; 80% of tsunamis, caused by volcanic or seismic events, occur within the “Pacific Ring of Fire”
note 3:
despite having the fourth largest population in the world, Indonesia is the most heavily forested region on earth after the Amazon
note 4:
two major food crops apparently developed on the island of New Guinea: bananas and sugarcane','e4a4ae0978af9658f6bd84777736b0a228011d358c3abbab5a457318373854e4','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2264d971fb42369263d710323f8085016f8ba883bfbca0c704b86bd12976ae30',2025,'ID','Indonesia','geography',46,'Location:
Middle East, bordering the Gulf of Oman, the Persian Gulf, and the Caspian Sea, between Iraq and Pakistan
Geographic coordinates:
32 00 N, 53 00 E
Map references:
Middle East
Area:
total:
1,648,195 sq km
land:
1,531,595 sq km
water:
116,600 sq km
comparison ranking:
total 19
Area - comparative:
almost 2.5 times the size of Texas; slightly smaller than Alaska
Land boundaries:
total:
5,894 km
border countries (7):
Afghanistan 921 km; Armenia 44 km; Azerbaijan 689 km; Iraq 1,599 km; Pakistan 959 km; Turkey 534 km; Turkmenistan 1,148 km
Coastline:
2,440 km - note: Iran also borders the Caspian Sea (740 km)
Maritime claims:
territorial sea:
12 nm
contiguous zone:
24 nm
exclusive economic zone:
bilateral agreements or median lines in the Persian Gulf
continental shelf:
natural prolongation
Climate:
mostly arid or semiarid, subtropical along Caspian coast
Terrain:
rugged, mountainous rim; high, central basin with deserts, mountains; small, discontinuous plains along both coasts
Elevation:
highest point:
Kuh-e Damavand 5,625 m
lowest point:
Caspian Sea -28 m
mean elevation:
1,305 m
Natural resources:
petroleum, natural gas, coal, chromium, copper, iron ore, lead, manganese, zinc, sulfur
Land use:
agricultural land:
30.1% (2018 est.)
arable land:
10.8% (2018 est.)
permanent crops:
1.2% (2018 est.)
permanent pasture:
18.1% (2018 est.)
forest:
6.8% (2018 est.)
other:
63.1% (2018 est.)
Irrigated land:
79,721 sq km (2020)
Major lakes (area sq km):
salt water lake(s):
Caspian Sea (shared with Russia, Azerbaijan, Turkmenistan, and Kazakhstan) - 374,000 sq km; Lake Urmia - 5,200 sq km; Lake Namak - 750 sq km
Major rivers (by length in km): Euphrates (shared with Turkey [s], Syria, and Iraq [m]) - 3,596 km; Tigris (shared with Turkey, Syria, and Iraq [m]) - 1,950 km; Helmand (shared with Afghanistan [s]) - 1,130 km note - [s] after country name indicates river source; [m] after country name indicates river mouth
Major watersheds (area sq km): Indian Ocean drainage:
(Persian Gulf) Tigris and Euphrates (918,044 sq km)
Population distribution:
population is concentrated in the north, northwest, and west, reflecting the position of the Zagros and Elburz Mountains; the vast dry areas in the center and eastern parts of the country, around the deserts of the Dasht-e Kavir and Dasht-e Lut, have a much lower population density
Natural hazards:
periodic droughts, floods; dust storms, sandstorms; earthquakes
Geography - note:
strategic location on the Persian Gulf and Strait of Hormuz, which are vital maritime pathways for crude oil transport','5321d9c2950780447b04e44d47e3c7916d0542ed12c91220a467f169560bc1ca','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('78b46007e2cee211d3bb2ef420b8e4090a6cac3f3c38e6b39c40ad2f6cc927c9',2025,'IQ','Iraq','geography',2,'Location:
Middle East, bordering the Persian Gulf, between Iran and Kuwait
Geographic coordinates:
33 00 N, 44 00 E
Map references:
Middle East
Area:
total:
438,317 sq km
land:
437,367 sq km
water:
950 sq km
comparison ranking:
total 60
Area - comparative:
slightly more than three times the size of New York state
Land boundaries:
total:
3,809 km
border countries (6):
Iran 1,599 km; Jordan 179 km; Kuwait 254 km; Saudi Arabia 811 km; Syria 599 km; Turkey 367 km
Coastline:
58 km
Maritime claims:
territorial sea:
12 nm
continental shelf:
not specified
Climate:
mostly desert; mild to cool winters with dry, hot, cloudless summers; northern mountainous regions along Iranian and Turkish borders experience cold winters with occasionally heavy snows that melt in early spring, sometimes causing extensive flooding in central and southern Iraq
Terrain:
mostly broad plains; reedy marshes along Iranian border in south with large flooded areas; mountains along borders with Iran and Turkey
Elevation:
highest point:
Cheekha Dar (Kurdish for “Black Tent”) 3,611 m
lowest point:
Persian Gulf 0 m
mean elevation:
312 m
Natural resources:
petroleum, natural gas, phosphates, sulfur
Land use:
agricultural land:
18.1% (2018 est.)
arable land:
8.4% (2018 est.)
permanent crops:
0.5% (2018 est.)
permanent pasture:
9.2% (2018 est.)
forest:
1.9% (2018 est.)
other:
80% (2018 est.)
Irrigated land:
35,250 sq km (2012)
Major lakes (area sq km):
fresh water lake(s):
Lake Hammar - 1,940 sq km
Major rivers (by length in km):
Euphrates river mouth (shared with Turkey[s], Syria, and Iran) - 3,596 km; Tigris river mouth (shared with Turkey[s], Syria, and Iran) - 1,950 km; the Tigris and Euphrates join to form the Shatt al Arab
note
– [s] after country name indicates river source; [m] after country name indicates river mouth
Major watersheds (area sq km): Indian Ocean drainage:
(Persian Gulf) Tigris and Euphrates (918,044 sq km)
Major aquifers:
Arabian Aquifer System
Population distribution:
population is concentrated in the north, center, and eastern parts of the country, with many of the larger urban agglomerations found along extensive parts of the Tigris and Euphrates Rivers; much of the western and southern areas are either lightly populated or uninhabited
Natural hazards:
dust storms; sandstorms; floods
Geography - note:
strategic location on Shatt al Arab waterway and at the head of the Persian Gulf','657a537a48a17ecdd6bf1851a7674d79e292fc89c41623f1abe151307265ab8d','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cf007c9f7a038bf08aa97c2ce5f37f553fb70b561e1573863e266396ce55b16d',2025,'IE','Ireland','geography',15,'Location:
Western Europe, occupying five-sixths of the island of Ireland in the North Atlantic Ocean, west of Great Britain
Geographic coordinates:
53 00 N, 8 00 W
Map references:
Europe
Area:
total:
70,273 sq km
land:
68,883 sq km
water:
1,390 sq km
comparison ranking:
total 120
Area - comparative:
slightly larger than West Virginia
Land boundaries:
total:
490 km
border countries (1):
UK 490 km
Coastline:
1,448 km
Maritime claims:
territorial sea:
12 nm
exclusive fishing zone:
200 nm
Climate:
temperate maritime; modified by North Atlantic Current; mild winters, cool summers; consistently humid; overcast about half the time
Terrain:
mostly flat to rolling interior plain surrounded by rugged hills and low mountains; sea cliffs on west coast
Elevation:
highest point:
Carrauntoohil 1,041 m
lowest point:
Atlantic Ocean 0 m
mean elevation:
118 m
Natural resources:
natural gas, peat, copper, lead, zinc, silver, barite, gypsum, limestone, dolomite
Land use:
agricultural land:
66.1% (2018 est.)
arable land:
15.4% (2018 est.)
permanent crops:
0% (2018 est.)
permanent pasture:
50.7% (2018 est.)
forest:
10.9% (2018 est.)
other:
23% (2018 est.)
Irrigated land:
0 sq km (2022)
Population distribution:
population distribution is weighted to the eastern side of the island, with the largest concentration being in and around Dublin; populations in the west are small due to mountainous land, poorer soil, lack of good transport routes, and fewer job opportunities
Natural hazards:
rare extreme weather events
Geography - note:
strategic location on major air and sea routes between North America and northern Europe; over 40% of the population resides within 100 km of Dublin','52b65d3c3b3d7e3cda1e98539f5def6aacde1d20c03082db0ca8ade4d3627374','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('664efb61df62d8bd2b712490a435dd59e0242714d2e4dc2f51672cbf465869c8',2025,'IM','Isle of Man','geography',27,'Location:
Western Europe, island in the Irish Sea, between Great Britain and Ireland
Geographic coordinates:
54 15 N, 4 30 W
Map references:
Europe
Area:
total:
572 sq km
land:
572 sq km
water:
0 sq km
comparison ranking:
total 193
Area - comparative:
slightly more than three times the size of Washington, DC
Land boundaries:
total:
0 km
Coastline:
160 km
Maritime claims:
territorial sea: 12 nm
exclusive fishing zone:
12 nm
Climate:
temperate; cool summers and mild winters; overcast about a third of the time
Terrain:
hills in north and south bisected by central valley
Elevation:
highest point:
Snaefell 621 m
lowest point:
Irish Sea 0 m
Natural resources:
none
Land use:
agricultural land:
74.7% (2018 est.)
arable land:
43.8% (2018 est.)
permanent crops:
0% (2018 est.)
permanent pasture:
30.9% (2018 est.)
forest:
6.1% (2018 est.)
other:
19.2% (2018 est.)
Population distribution:
most people concentrated in cities and large towns of which Douglas, in the southeast, is the largest
Natural hazards:
occasional high winds and rough seas
Geography - note:
one small islet, the Calf of Man, lies to the southwest and is a bird sanctuary','1d9c970299474b807da3ceb052626ec0dad13b0baf4a66b201c828b8e2a12882','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4b1eca944b01379e0a6b81e72cf418d20843a34d4b7d35bf9531419522170946',2025,'IL','Israel','geography',38,'Location:
Middle East, bordering the Mediterranean Sea, between Egypt and Lebanon
Geographic coordinates:
31 30 N, 34 45 E
Map references:
Middle East
Area:
total:
21,937 sq km
land:
21,497 sq km
water:
440 sq km
comparison ranking:
total 152
Area - comparative:
slightly larger than New Jersey
Land boundaries:
total:
1,068 km
border countries (6):
Egypt 208 km; Gaza Strip 59 km; Jordan 327 km (20 km are within the Dead Sea); Lebanon 81 km; Syria 83 km; West Bank 330 km
Coastline:
273 km
Maritime claims:
territorial sea:
12 nm
continental shelf:
to depth of exploitation
Climate:
temperate; hot and dry in southern and eastern desert areas
Terrain:
Negev desert in the south; low coastal plain; central mountains; Jordan Rift Valley
Elevation:
highest point:
Mitspe Shlagim 2,224 m; note - this is the highest named point, the actual highest point is an unnamed dome slightly to the west of Mitspe Shlagim at 2,236 m; both points are on the northeastern border of Israel, along the southern end of the Anti-Lebanon mountain range
lowest point:
Dead Sea -431 m
mean elevation:
508 m
Natural resources:
timber, potash, copper ore, natural gas, phosphate rock, magnesium bromide, clays, sand
Land use:
agricultural land:
23.8% (2018 est.)
arable land:
13.7% (2018 est.)
permanent crops:
3.8% (2018 est.)
permanent pasture:
6.3% (2018 est.)
forest:
7.1% (2018 est.)
other:
69.1% (2018 est.)
Irrigated land:
2,159 sq km (2020)
Major lakes (area sq km):
salt water lake(s):
Dead Sea (shared with Jordan and West Bank) - 1,020 sq km
note
– endorheic hypersaline lake; 9.6 times saltier than the ocean; lake shore is 431 meters below sea level
Population distribution:
population concentrated in and around Tel-Aviv, as well as around the Sea of Galilee; the south remains sparsely populated with the exception of the shore of the Gulf of Aqaba
Natural hazards:
sandstorms may occur during spring and summer; droughts; periodic earthquakes
Geography - note:
note 1:
Lake Tiberias (Sea of Galilee) is an important freshwater source; the Dead Sea is the second saltiest body of water in the world (after Lake Assal in Djibouti)
note 2:
the Malham Cave in Mount Sodom is the world’s longest salt cave at 10 km (6 mi); its survey is not complete and its length will undoubtedly increase; Mount Sodom is actually a hill some 220 m (722 ft) high that is 80% salt (multiple salt layers covered by a veneer of rock)
note 3:
in March 2019, there were 380 Israeli settlements, to include 213 settlements and 132 outposts in the West Bank, and 35 settlements in East Jerusalem; there are no Israeli settlements in the Gaza Strip, as all were evacuated in 2005 (2019)','1670ef7980e4b34809ea162303cfe2e790e893205c7c0f309be43276329d17c6','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a4fe9d7cd326e65bcb0310e764ef0a1efb4810f80dc3af5f77931bc11e53ac08',2025,'IT','Italy','geography',51,'Location:
Southern Europe, a peninsula extending into the central Mediterranean Sea, northeast of Tunisia
Geographic coordinates:
42 50 N, 12 50 E
Map references:
Europe
Area:
total:
301,340 sq km
land:
294,140 sq km
water:
7,200 sq km
note:
includes Sardinia and Sicily
comparison ranking:
total 73
Area - comparative:
almost twice the size of Georgia; slightly larger than Arizona
Land boundaries:
total:
1,836.4 km
border countries (6):
Austria 404 km; France 476 km; Holy See (Vatican City) 3.4 km; San Marino 37 km; Slovenia 218 km; Switzerland 698 km
Coastline:
7,600 km
Maritime claims:
territorial sea:
12 nm
continental shelf:
200-m depth or to the depth of exploitation
Climate:
predominantly Mediterranean; alpine in far north; hot, dry in south
Terrain:
mostly rugged and mountainous; some plains, coastal lowlands
Elevation:
highest point: Mont Blanc (Monte Bianco) de Courmayeur (a secondary peak of Mont Blanc) 4,748 m
lowest point:
Mediterranean Sea 0 m
mean elevation:
538 m
Natural resources:
coal, antimony, mercury, zinc, potash, marble, barite, asbestos, pumice, fluorspar, feldspar, pyrite (sulfur), natural gas and crude oil reserves, fish, arable land
Land use:
agricultural land: 47.1% (2018 est.)
arable land:
22.8% (2018 est.)
permanent crops:
8.6% (2018 est.)
permanent pasture:
15.7% (2018 est.)
forest:
31.4% (2018 est.)
other:
21.5% (2018 est.)
Irrigated land:
26,010 sq km (2013)
Major watersheds (area sq km): Atlantic Ocean drainage:
Rhine-Maas (198,735 sq km),
(Black Sea)
Danube (795,656 sq km),
(Adriatic Sea)
Po (76,997 sq km),
(Mediterranean Sea)
Rhone (100,543 sq km)
Population distribution:
despite a distinctive pattern with an industrial north and an agrarian south, a fairly even population distribution exists throughout most of the country, with coastal areas, the Po River Valley, and urban centers (particularly Milan, Rome, and Naples), attracting larger and denser populations
Natural hazards:
regional risks include landslides, mudflows, avalanches, earthquakes, volcanic eruptions, flooding; land subsidence in Venice
volcanism:
significant volcanic activity; Etna (3,330 m), which is in eruption as of 2010, is Europe’s most active volcano; flank eruptions pose a threat to nearby Sicilian villages; Etna, along with the famous Vesuvius, which remains a threat to the millions of nearby residents in the Bay of Naples area, have both been deemed Decade Volcanoes by the International Association of Volcanology and Chemistry of the Earth’s Interior, worthy of study due to their explosive history and close proximity to human populations; Stromboli, on its namesake island, has also been continuously active with moderate volcanic activity; other historically active volcanoes include Campi Flegrei, Ischia, Larderello, Pantelleria, Vulcano, and Vulsini
Geography - note:
strategic location dominating central Mediterranean as well as southern sea and air approaches to Western Europe','dce498899ef37192ce5cd041f02097d9baba1b8b2112ebf60275508ceb71f09f','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5cded3ccba7e1bf5e8ce774aab8d4b3469bef63d226b61279cedda960a4adb98',2025,'JM','Jamaica','geography',2,'Location:
Caribbean, island in the Caribbean Sea, south of Cuba
Geographic coordinates:
18 15 N, 77 30 W
Map references:
Central America and the Caribbean
Area:
total:
10,991 sq km
land:
10,831 sq km
water:
160 sq km
comparison ranking:
total 166
Area - comparative:
about half the size of New Jersey; slightly smaller than Connecticut
Land boundaries:
total:
0 km
Coastline:
1,022 km
Maritime claims:
territorial sea:
12 nm
contiguous zone:
24 nm
exclusive economic zone:
200 nm
continental shelf:
200 nm or to edge of the continental margin measured from claimed archipelagic straight baselines
Climate:
tropical; hot, humid; temperate interior
Terrain:
mostly mountains, with narrow, discontinuous coastal plain
Elevation:
highest point:
Blue Mountain Peak 2,256 m
lowest point:
Caribbean Sea 0 m
mean elevation:
18 m
Natural resources:
bauxite, alumina, gypsum, limestone
Land use:
agricultural land:
41.4% (2018 est.)
arable land:
11.1% (2018 est.)
permanent crops:
9.2% (2018 est.)
permanent pasture:
21.1% (2018 est.)
forest:
31.1% (2018 est.)
other:
27.5% (2018 est.)
Irrigated land:
250 sq km (2012)
Population distribution:
population density is high throughout, but increases in and around Kingston, Montego Bay, and Port Esquivel
Natural hazards:
hurricanes (especially July to November)
Geography - note:
third largest island in the Caribbean (after Cuba and Hispaniola); strategic location between Cayman Trench and Jamaica Channel, the main sea lanes for the Panama Canal','6f763e884079e1ffb6a216b9a2e5eff12e543871a36adebfe7fd4dc1b8dc730d','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('362c4afab4b21211e2614a452acbabd2d74b42a5c10fbe567a47c61097364295',2025,'JM','Jamaica','geography',13,'Location:
Northern Europe, island between the Greenland Sea and the Norwegian Sea, northeast of Iceland
Geographic coordinates:
71 00 N, 8 00 W
Map references:
Arctic Region
Area:
total:
377 sq km
land:
377 sq km
water:
0 sq km
comparison ranking:
total 205
Area - comparative:
slightly more than twice the size of Washington, DC
Land boundaries:
total:
0 km
Coastline:
124.1 km
Maritime claims:
territorial sea:
12 nm
contiguous zone:
24 nm
exclusive economic zone:
200 nm
continental shelf:
200-m depth or to the depth of exploitation
Climate:
arctic maritime with frequent storms and persistent fog
Terrain:
volcanic island, partly covered by glaciers
Elevation:
highest point:
Haakon VII Toppen on Beerenberg 2,277
lowest point:
Norwegian Sea 0 m
note:
Beerenberg volcano has numerous peaks; the highest point on the volcano rim is named Haakon VII Toppen, after Norway’s first king following the reestablishment of Norwegian independence in 1905
Natural resources:
none
Land use:
agricultural land:
0% (2011 est.)
other:
100% (2018 est.)
Irrigated land:
0 sq km (2022)
Natural hazards:
dominated by the volcano Beerenberg
volcanism:
Beerenberg (2,227 m) is Norway’s only active volcano; volcanic activity resumed in 1970; the most recent eruption occurred in 1985
Geography - note:
barren volcanic spoon-shaped island with some moss and grass flora; island consists of two parts: a larger northeast Nord-Jan (the spoon “bowl”) and the smaller Sor-Jan (the “handle”), linked by a 2.5 km-wide isthmus (the “stem”) with two large lakes, Sorlaguna (South Lagoon) and Nordlaguna (North Lagoon)','49caf31a69bcc3cdd831a9a472b7370dc207c126b44925489c9f673398b1755c','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('18903eb72fe49180d1271d30921fca1a7ce6ed4b64f233ad3dc5a3664ea1af04',2025,'JP','Japan','geography',22,'Location:
Eastern Asia, island chain between the North Pacific Ocean and the Sea of Japan, east of the Korean Peninsula
Geographic coordinates:
36 00 N, 138 00 E
Map references:
Asia
Area:
total:
377,915 sq km
land:
364,485 sq km
water:
13,430 sq km
note:
includes Bonin Islands (Ogasawara-gunto), Daito-shoto, Minami-jima, Okino-tori-shima, Ryukyu Islands (Nansei-shoto), and Volcano Islands (Kazan-retto)
comparison ranking:
total 63
Area - comparative:
slightly smaller than California
Land boundaries:
total:
0 km
Coastline:
29,751 km
Maritime claims:
territorial sea: 12 nm; between 3 nm and 12 nm in the international straits - La Perouse or Soya, Tsugaru, Osumi, and the Korea and Tsushima Straits
contiguous zone:
24 nm
exclusive economic zone:
200 nm
Climate:
varies from tropical in south to cool temperate in north
Terrain:
mostly rugged and mountainous
Elevation:
highest point:
Mount Fuji 3,776 m
lowest point:
Hachiro-gata -4 m
mean elevation:
438 m
Natural resources:
negligible mineral resources, fish; note - with virtually no natural energy resources, Japan is almost totally dependent on foreign, imported sources of energy
Land use:
agricultural land:
12.5% (2018 est.)
arable land:
11.7% (2018 est.)
permanent crops:
0.8% (2018 est.)
permanent pasture:
0% (2018 est.)
forest:
68.5% (2018 est.)
other:
19% (2018 est.)
Irrigated land:
15,730 sq km (2014)
Major lakes (area sq km):
fresh water lake(s):
Biwa-ko 688 sq km
Population distribution:
all primary and secondary regions of high population density lie on the coast; one-third of the population resides in and around Tokyo on the central plain (Kanto Plain)
Natural hazards:
many dormant and some active volcanoes; about 1,500 seismic occurrences (mostly tremors but occasional severe earthquakes) every year; tsunamis; typhoons
volcanism:
both Unzen (1,500 m) and Sakura-jima (1,117 m), which lies near the densely populated city of Kagoshima, have been deemed Decade Volcanoes by the International Association of Volcanology and Chemistry of the Earth’s Interior, worthy of study due to their explosive history and close proximity to human populations; other notable historically active volcanoes include Asama, Honshu Island’s most active volcano, Aso, Bandai, Fuji, Iwo-Jima, Kikai, Kirishima, Komaga-take, Oshima, Suwanosejima, Tokachi, Yake-dake, and Usu; see note 2 under “Geography - note”
Geography - note:
note 1: strategic location in northeast Asia; composed of four main islands (the “Home Islands”) - from north: Hokkaido, Honshu (the largest, most populous, and site of Tokyo, the capital), Shikoku, and Kyushu
note 2:
a 2023 Geospatial Information Authority of Japan survey technically detected 100,000 islands and islets, but only the 14,125 islands with a circumference of at least 100 m (330 ft) were officially counted; only about 260 of the islands are inhabited
note 3:
Japan annually records the most earthquakes in the world; it is one of the countries along the Ring of Fire, a belt of active volcanoes and earthquake epicenters bordering the Pacific Ocean; up to 90% of the world’s earthquakes and some 75% of the world’s volcanoes occur within the Ring of Fire','bd57e78dcabec7da83a5b6941c6b961050df31a41bf35c6c8928d399e6598949','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a508a3bc9bb7a734a986348130db527ed03c39d545db4a905a553a896b5ea725',2025,'JE','Jersey','geography',34,'Location:
Western Europe, island in the English Channel, northwest of France
Geographic coordinates:
49 15 N, 2 10 W
Map references:
Europe
Area:
total:
116 sq km
land:
116 sq km
water:
0 sq km
comparison ranking:
total 224
Area - comparative:
about two-thirds the size of Washington, DC
Land boundaries:
total:
0 km
Coastline:
70 km
Maritime claims:
territorial sea:
12 nm
exclusive fishing zone:
12 nm
Climate:
temperate; mild winters and cool summers
Terrain:
gently rolling plain with low, rugged hills along north coast
Elevation:
highest point:
Les Platons 136 m
lowest point:
English Channel 0 m
Natural resources:
arable land
Land use:
agricultural land:
66% (2018 est.)
arable land:
66% (2018 est.)
other:
34% (2018 est.)
Irrigated land:
NA
Population distribution:
fairly even distribution; no notable trends
Natural hazards:
very large tidal variation can be hazardous to navigation
Geography - note:
largest and southernmost of Channel Islands; about 30% of population concentrated in Saint Helier','e20341bbc2dc77facdd196d9ef0c76d1e47e836a4d4cd44e6dd35dbf0e18dd29','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('56bc621c43b53cb12a4518ef74d2dd730009dd9e392fee5a83bf271f52227ab7',2025,'JO','Jordan','geography',45,'Location:
Middle East, northwest of Saudi Arabia, between Israel (to the west) and Iraq
Geographic coordinates:
31 00 N, 36 00 E
Map references:
Middle East
Area:
total:
89,342 sq km
land:
88,802 sq km
water:
540 sq km
comparison ranking:
total 112
Area - comparative:
about three-quarters the size of Pennsylvania; slightly smaller than Indiana
Land boundaries:
total:
1,744 km
border countries (5):
Iraq 179 km; Israel 307 km; Saudi Arabia 731 km; Syria 379 km; West Bank 148 km
Coastline:
26 km
Maritime claims:
territorial sea:
3 nm
Climate:
mostly arid desert; rainy season in west (November to April)
Terrain:
mostly arid desert plateau; a great north-south geological rift along the west of the country is the dominant topographical feature and includes the Jordan River Valley, the Dead Sea, and the Jordanian Highlands
Elevation:
highest point:
Jabal Umm ad Dami 1,854 m
lowest point:
Dead Sea -431 m
mean elevation:
812 m
Natural resources:
phosphates, potash, shale oil
Land use:
agricultural land:
11.4% (2018 est.)
arable land:
2% (2018 est.)
permanent crops:
1% (2018 est.)
permanent pasture:
8.4% (2018 est.)
forest:
1.1% (2018 est.)
other:
87.5% (2018 est.)
Irrigated land:
833 sq km (2020)
Major lakes (area sq km):
salt water lake(s):
Dead Sea (shared with Israel and West Bank) - 1,020 sq km
note
– endorheic hypersaline lake; 9.6 times saltier than the ocean; lake shore is 431 meters below sea level
Major watersheds (area sq km): Indian Ocean drainage:
(Persian Gulf)
Tigris and Euphrates (918,044 sq km)
Major aquifers:
Arabian Aquifer System
Population distribution:
population heavily concentrated in the west, and particularly the northwest, in and around the capital of Amman; a sizeable, but smaller population is located in the southwest along the shore of the Gulf of Aqaba
Natural hazards:
droughts; periodic earthquakes; flash floods
Geography - note:
strategic location at the head of the Gulf of Aqaba and as the Arab country that shares the longest border with Israel and the occupied West Bank; the Dead Sea, the lowest point in Asia and the second saltiest body of water in the world (after Lac Assal in Djibouti), lies on Jordan’s western border with Israel and the West Bank; Jordan is almost landlocked but does have a 26 km southwestern coastline with a single port, Al ’Aqabah (Aqaba)','3a7d66e6472b468851806a4de9625c7d9911ea0077b7fb249a001accb1bf94fd','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c4361b51398cbe3f7bcfef1bd4dacdb9d9a451b86668dbc037a208c80359a91c',2025,'KZ','Kazakhstan','geography',2,'Location:
Central Asia, northwest of China; a small portion west of the Ural (Oral) River in easternmost Europe
Geographic coordinates:
48 00 N, 68 00 E
Map references:
Asia
Area:
total: 2,724,900
sq km
land:
2,699,700 sq km
water:
25,200 sq km
comparison ranking:
total 10
Area - comparative:
slightly less than four times the size of Texas
Land boundaries:
total: 13,364
km
border countries (5):
China 1,765 km; Kyrgyzstan 1,212 km; Russia 7,644 km; Turkmenistan 413 km; Uzbekistan 2,330 km
Coastline:
0 km (landlocked); note - Kazakhstan borders the Aral Sea, now split into two bodies of water (1,070 km), and the Caspian Sea (1,894 km)
Maritime claims:
none (landlocked)
Climate:
continental, cold winters and hot summers, arid and semiarid
Terrain:
vast flat steppe extending from the Volga in the west to the Altai Mountains in the east and from the plains of western Siberia in the north to oases and deserts of Central Asia in the south
Elevation:
highest point: Pik
Khan-Tengri 7,010 m
note - the northern most 7,000 meter peak in the World
lowest point:
Qauyndy Oyysy -132 m
mean elevation:
387 m
Natural resources:
major deposits of petroleum, natural gas, coal, iron ore, manganese, chrome ore, nickel, cobalt, copper, molybdenum, lead, zinc, bauxite, gold, uranium
Land use:
agricultural land: 77.4%
(2018 est.)
arable land:
8.9% (2018 est.)
permanent crops:
0% (2018 est.)
permanent pasture:
68.5% (2018 est.)
forest:
1.2% (2018 est.)
other:
21.4% (2018 est.)
Irrigated land:
18,099 sq km (2020)
Major lakes (area sq km):
fresh water lake(s): Ozero
Balkhash - 22,000 sq km; Ozero Zaysan - 1,800 sq km
salt water lake(s):
Caspian Sea (shared with Iran, Azerbaijan, Turkmenistan, and Russia) - 374,000 sq km; Aral Sea (north) - 3,300 sq km; Ozero Alakol - 2,650 sq km; Ozero Teniz 1,590 sq km; Ozero Seletytenzi - 780 sq km; Ozero Sasykkol - 740 sq km
Major rivers (by length in km):
Syr Darya river mouth (shared with Kyrgyzstan [s], Uzbekistan, and Tajikistan) - 3,078 km
note – [s] after country name indicates river source; [m] after country name indicates river mouth
Major watersheds (area sq km): Internal (endorheic basin) drainage:
Tarim Basin (1,152,448 sq km), Amu Darya (534,739 sq km), Syr Darya (782,617 sq km), Lake Balkash (510,015 sq km)
Population distribution:
most of the country displays a low population density, particularly the interior; population clusters appear in urban agglomerations in the far northern and southern portions of the country
Natural hazards:
earthquakes in the south; mudslides around Almaty
Geography - note:
World’s largest landlocked country and one of only two landlocked countries in the world that extends into two continents (the other is Azerbaijan); Russia leases approximately 6,000 sq km of territory enclosing the Baikonur Cosmodrome; in January 2004, Kazakhstan and Russia extended the lease to 2050','2284f58c43b119fcdebd8fe1b90e0dd4bb23c3f821fea5e4db47e50762bf9b3f','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3c684da097a4773717b9a200a958e85d007fc2d6514ab97cdce468eda49edebb',2025,'KE','Kenya','geography',14,'Location:
Eastern Africa, bordering the Indian Ocean, between Somalia and Tanzania
Geographic coordinates:
1 00 N, 38 00 E
Map references:
Africa
Area:
total: 580,367
sq km
land:
569,140 sq km
water:
11,227 sq km
comparison ranking:
total 51
Area - comparative:
five times the size of Ohio; slightly more than twice the size of Nevada
Land boundaries:
total: 3,457
km
border countries (5):
Ethiopia 867 km; Somalia 684 km; South Sudan 317 km; Tanzania 775 km; Uganda 814 km
Coastline:
536 km
Maritime claims:
territorial sea: 12
nm
exclusive economic zone:
200 nm
continental shelf:
200-m depth or to the depth of exploitation
Climate:
varies from tropical along coast to arid in interior
Terrain:
low plains rise to central highlands bisected by Great Rift Valley; fertile plateau in west
Elevation:
highest point: Mount
Kenya 5,199 m
lowest point:
Indian Ocean 0 m
mean elevation:
762 m
Natural resources:
limestone, soda ash, salt, gemstones, fluorspar, zinc, diatomite, gypsum, wildlife, hydropower
Land use:
agricultural land: 48.1%
(2018 est.)
arable land:
9.8% (2018 est.)
permanent crops:
0.9% (2018 est.)
permanent pasture:
37.4% (2018 est.)
forest:
6.1% (2018 est.)
other:
45.8% (2018 est.)
Irrigated land:
1,030 sq km (2012)
Major lakes (area sq km):
fresh water lake(s): Lake
Victoria (shared with Tanzania and Uganda) - 62,940 sq km
salt water lake(s):
Lake Turkana (shared with Ethiopia) - 6,400 sq km
Major watersheds (area sq km): Atlantic Ocean drainage:
(Mediterranean Sea)
Nile (3,254,853 sq km)
Major aquifers:
Ogaden-Juba Basin
Population distribution:
population heavily concentrated in the west along the shore of Lake Victoria; other areas of high density include the capital of Nairobi, and in the southeast along the Indian Ocean coast as shown in this population distribution map
Natural hazards:
recurring drought; flooding during rainy seasons
volcanism:
limited volcanic activity; the Barrier (1,032 m) last erupted in 1921; South Island is the only other historically active volcano
Geography - note:
the Kenyan Highlands comprise one of the most successful agricultural production regions in Africa; glaciers are found on Mount Kenya, Africa’s second highest peak; unique physiography supports abundant and varied wildlife of scientific and economic value; Lake Victoria, the world’s largest tropical lake and the second largest fresh water lake, is shared among three countries: Kenya, Tanzania, and Uganda','9c5b23af05402703801b11e76e23b3a92322e1bb6828f744919b7e053c8573e7','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a89563bb344542f41850c978df2d395a054fbb1bd4f02d97f0a7224a8b7824d7',2025,'KI','Kiribati','geography',27,'Location:
Oceania, group of 32 coral atolls and one raised coral island in the Pacific Ocean, straddling the Equator; the capital Tarawa is about halfway between Hawaii and Australia
Geographic coordinates:
1 25 N, 173 00 E
Map references:
Oceania
Area:
total: 811
sq km
land:
811 sq km
water:
0 sq km
note:
includes three island groups - Gilbert Islands, Line Islands, and Phoenix Islands - dispersed over about 3.5 million sq km (1.35 million sq mi)
comparison ranking:
total 186
Area - comparative:
four times the size of Washington, DC
Land boundaries:
total: 0
km
Coastline:
1,143 km
Maritime claims:
territorial sea: 12
nm
exclusive economic zone:
200 nm
Climate:
tropical; marine, hot and humid, moderated by trade winds
Terrain:
mostly low-lying coral atolls surrounded by extensive reefs
Elevation:
highest point: unnamed
elevation on Banaba 81 m
lowest point:
Pacific Ocean 0 m
mean elevation:
2 m
Natural resources:
phosphate (production discontinued in 1979), coconuts (copra), fish
Land use:
agricultural land: 42%
(2018 est.)
arable land:
2.5% (2018 est.)
permanent crops:
39.5% (2018 est.)
permanent pasture:
0% (2018 est.)
forest:
15% (2018 est.)
other:
43% (2018 est.)
Irrigated land:
0 sq km (2022)
Population distribution:
consists of three achipelagos spread out over an area roughly the size of India; the eastern Line Islands and central Phoenix Islands are sparsely populated, but the western Gilbert Islands are some of the most densely settled places on earth, with the main island of South Tarawa boasting a population density similar to Tokyo or Hong Kong
Natural hazards:
typhoons can occur any time, but usually November to March; occasional tornadoes; low level of some of the islands make them sensitive to changes in sea level
Geography - note:
21 of the 33 islands are inhabited; Banaba (Ocean Island) in Kiribati is one of the three great phosphate rock islands in the Pacific Ocean - the others are Makatea in French Polynesia, and Nauru; Kiribati is the only country in the world to fall into all four hemispheres (northern, southern, eastern, and western)','b70568045d1ed7f5b2c528b5162532a8a7bb5b56a6814cdf32854861976fab68','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('58a2f87bc62e7b9eea5da7ddfdf5cf20ecbb310b6a4be5bf8a96b9614ecde012',2025,'KI','Kiribati','geography',38,'Location:
Eastern Asia, northern half of the Korean Peninsula bordering the Korea Bay and the Sea of Japan, between China and South Korea
Geographic coordinates:
40 00 N, 127 00 E
Map references:
Asia
Area:
total: 120,538
sq km
land:
120,408 sq km
water:
130 sq km
comparison ranking:
total 99
Area - comparative:
slightly larger than Virginia; slightly smaller than Mississippi
Land boundaries:
total: 1,607
km
border countries (3):
China 1,352 km; South Korea 237 km; Russia 18 km
Coastline:
2,495 km
Maritime claims:
territorial sea: 12
nm
exclusive economic zone:
200 nm
note:
military boundary line 50 nm in the Sea of Japan and the exclusive economic zone limit in the Yellow Sea where all foreign vessels and aircraft without permission are banned
Climate:
temperate, with rainfall concentrated in summer; long, bitter winters
Terrain:
mostly hills and mountains separated by deep, narrow valleys; wide coastal plains in west, discontinuous in east
Elevation:
highest point: Paektu-san
2,744 m
lowest point:
Sea of Japan 0 m
mean elevation:
600 m
Natural resources:
coal, iron ore, limestone, magnesite, graphite, copper, zinc, lead, precious metals, hydropower
Land use:
agricultural land: 21.8%
(2018 est.)
arable land:
19.5% (2018 est.)
permanent crops:
1.9% (2018 est.)
permanent pasture:
0.4% (2018 est.)
forest:
46% (2018 est.)
other:
32.2% (2018 est.)
Irrigated land:
14,600 sq km (2012)
Population distribution:
population concentrated in the plains and lowlands; least populated regions are the mountainous provinces adjacent to the Chinese border; largest concentrations are in the western provinces, particularly the municipal district of Pyongyang, and around Hungnam and Wonsan in the east
Natural hazards:
late spring droughts often followed by severe flooding; occasional typhoons during the early fall
volcanism:
P’aektu-san (2,744 m) (also known as Baitoushan, Baegdu, or Changbaishan), on the Chinese border, is considered historically active
Geography - note:
strategic location bordering China, South Korea, and Russia; mountainous interior is isolated and sparsely populated','d898413e5beca1b4fccf02705bd1a70ad1393bbbd8a8909fcd2e47f970cc0f42','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8c4db8a21681ad0da66e1d2cb2698f3f1fe92bf7931c9761a71547dfa0cdb662',2025,'KW','Kuwait','geography',6,'Location:
Middle East, bordering the Persian Gulf, between Iraq and Saudi Arabia
Geographic coordinates:
29 30 N, 45 45 E
Map references:
Middle East
Area:
total: 17,818
sq km
land:
17,818 sq km
water:
0 sq km
comparison ranking:
total 157
Area - comparative:
slightly smaller than New Jersey
Land boundaries:
total: 475
km
border countries (2):
Iraq 254 km; Saudi Arabia 221 km
Coastline:
499 km
Maritime claims:
territorial sea: 12
nm
Climate:
dry desert; intensely hot summers; short, cool winters
Terrain:
flat to slightly undulating desert plain
Elevation:
highest point: 3.6
km W. of Al-Salmi Border Post 300 m
lowest point:
Persian Gulf 0 m
mean elevation:
108 m
Natural resources:
petroleum, fish, shrimp, natural gas
Land use:
agricultural land: 8.5%
(2018 est.)
arable land:
0.6% (2018 est.)
permanent crops:
0.3% (2018 est.)
permanent pasture:
7.6% (2018 est.)
forest:
0.4% (2018 est.)
other:
91.1% (2018 est.)
Irrigated land:
100 sq km (2015)
Major watersheds (area sq km): Indian Ocean drainage:
(Persian Gulf)
Tigris and Euphrates (918,044 sq km)
Major aquifers:
Arabian Aquifer System
Population distribution:
densest settlement is along the Persian Gulf, particularly in Kuwait City and on Bubiyan Island; significant population threads extend south and west along highways that radiate from the capital, particularly in the southern half of the country
Natural hazards:
sudden cloudbursts are common from October to April and bring heavy rain, which can damage roads and houses; sandstorms and dust storms occur throughout the year but are most common between March and August
Geography - note:
strategic location at head of Persian Gulf','f78b5aef4b4011477d2efdaf8d385d88606b97985ccc19a4cee60beb06c8aecb','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4b702993f665163c191b152b9ca1b9d8d2eb5184757e52bc7eb3519fe0e24877',2025,'KG','Kyrgyzstan','geography',17,'Location:
Central Asia, west of China, south of Kazakhstan
Geographic coordinates:
41 00 N, 75 00 E
Map references:
Asia
Area:
total: 199,951
sq km
land:
191,801 sq km
water:
8,150 sq km
comparison ranking:
total 87
Area - comparative:
slightly smaller than South Dakota
Land boundaries:
total: 4,573
km
border countries (4):
China 1,063 km; Kazakhstan 1,212 km; Tajikistan 984 km; Uzbekistan 1,314 km
Coastline:
0 km (landlocked)
Maritime claims:
none (landlocked)
Climate:
dry continental to polar in high Tien Shan Mountains; subtropical in southwest (Fergana Valley); temperate in northern foothill zone
Terrain:
peaks of the Tien Shan mountain range and associated valleys and basins encompass the entire country
Elevation:
highest point: Jengish
Chokusu (Pik Pobedy) 7,439 m
lowest point:
Kara-Daryya (Karadar’ya) 132 m
mean elevation:
2,988 m
Natural resources:
abundant hydropower; gold, rare earth metals; locally exploitable coal, oil, and natural gas; other deposits of nepheline, mercury, bismuth, lead, and zinc
Land use:
agricultural land: 55.4%
(2018 est.)
arable land:
6.7% (2018 est.)
permanent crops:
0.4% (2018 est.)
permanent pasture:
48.3% (2018 est.)
forest:
5.1% (2018 est.)
other:
39.5% (2018 est.)
Irrigated land:
10,043 sq km (2020)
Major lakes (area sq km):
salt water lake(s): Ozero
Issyk-Kul 6,240 sq km
note - second largest saline lake after the Caspian Sea; second highest mountain lake after Lake Titicaca; it is an endorheic mountain basin; although surrounded by snow capped mountains it never freezes
Major rivers (by length in km):
Syr Darya river source (shared with Tajikistan, Uzbekistan, and Kazakhstan [m]) - 3,078 km note – [s] after country name indicates river source; [m] after country name indicates river mouth
Major watersheds (area sq km): Internal (endorheic basin) drainage:
Tarim Basin (1,152,448 sq km),
(Aral Sea basin)
Amu Darya (534,739 sq km), Syr Darya (782,617 sq km)
Population distribution:
the vast majority of Kyrgyzstanis live in rural areas; densest population settlement is to the north in and around the capital, Bishkek, followed by Osh in the west; the least densely populated area is the east, southeast in the Tien Shan mountains
Natural hazards:
major flooding during snow melt; prone to earthquakes
Geography - note:
landlocked; entirely mountainous, dominated by the Tien Shan range; 94% of the country is 1,000 m above sea level with an average elevation of 2,750 m; many tall peaks, glaciers, and high-altitude lakes','4a928290c6ce7db511d32402197ba43d0f8d2ddeb3e50537a50db58ab102bdda','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c9b88c661b6027d74fc799ea58dc2b95bd9399439fc50cebfad7041ba6d91075',2025,'LV','Latvia','geography',4,'Location:
Eastern Europe, bordering the Baltic Sea, between Estonia and Lithuania
Geographic coordinates:
57 00 N, 25 00 E
Map references:
Europe
Area:
total:
64,589 sq km
land:
62,249 sq km
water:
2,340 sq km
comparison ranking:
total 124
Area - comparative:
slightly larger than West Virginia
Land boundaries:
total:
1,370 km
border countries (4):
Belarus 161 km; Estonia 333 km; Lithuania 544 km; Russia 332 km
Coastline:
498 km
Maritime claims:
territorial sea:
12 nm
exclusive economic zone:
limits as agreed to by Estonia, Finland, Latvia, Sweden, and Russia
continental shelf:
200 m depth or to the depth of exploitation
Climate:
maritime; wet, moderate winters
Terrain:
low plain
Elevation:
highest point:
Gaizina Kalns 312 m
lowest point:
Baltic Sea 0 m
mean elevation:
87 m
Natural resources:
peat, limestone, dolomite, amber, hydropower, timber, arable land
Land use:
agricultural land:
29.2% (2018 est.)
arable land:
18.6% (2018 est.)
permanent crops:
0.1% (2018 est.)
permanent pasture:
10.5% (2018 est.)
forest:
54.1% (2018 est.)
other:
16.7% (2018 est.)
Irrigated land:
6 sq km (2016)
note:
land in Latvia is often too wet and in need of drainage not irrigation; approximately 16,000 sq km or 85% of agricultural land has been improved by drainage
Population distribution:
largest concentration of people is found in and around the port and capital city of Riga; small agglomerations are scattered throughout the country
Natural hazards:
large percentage of agricultural fields can become waterlogged and require drainage
Geography - note:
most of the country is composed of fertile low-lying plains with some hills in the east','622ab4a75119ea9b27292de705c1bbeab28c12e2f1bfe6c9f944e7ecb4beed55','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('99c31e940f3884351dbc8a416403460780626473349388e9971014c96bbd63e0',2025,'LB','Lebanon','geography',15,'Location:
Middle East, bordering the Mediterranean Sea, between Israel and Syria
Geographic coordinates:
33 50 N, 35 50 E
Map references:
Middle East
Area:
total:
10,400 sq km
land:
10,230 sq km
water:
170 sq km
comparison ranking:
total 168
Area - comparative:
about one-third the size of Maryland
Land boundaries:
total:
484 km
border countries (2):
Israel 81 km; Syria 403 km
Coastline:
225 km
Maritime claims:
territorial sea:
12 nm
Climate:
Mediterranean; mild to cool, wet winters with hot, dry summers; the Lebanon Mountains experience heavy winter snows
Terrain:
narrow coastal plain; El Beqaa (Bekaa Valley) separates Lebanon and Anti-Lebanon Mountains
Elevation:
highest point:
Qornet es Saouda 3,088 m
lowest point:
Mediterranean Sea 0 m
mean elevation:
1,250 m
Natural resources:
limestone, iron ore, salt, water-surplus state in a water-deficit region, arable land
Land use:
agricultural land:
63.3% (2018 est.)
arable land:
11.9% (2018 est.)
permanent crops:
12.3% (2018 est.)
permanent pasture:
39.1% (2018 est.)
forest:
13.4% (2018 est.)
other:
23.3% (2018 est.)
Irrigated land:
1,040 sq km (2012)
Population distribution:
the majority of the people live on or near the Mediterranean coast, and of these most live in and around the capital, Beirut; favorable growing conditions in the Bekaa Valley, on the southeastern side of the Lebanon Mountains, have attracted farmers and thus the area exhibits a smaller population density
Natural hazards:
earthquakes; dust storms, sandstorms
Geography - note:
smallest country in continental Asia; Nahr el Litani is the only major river in Near East not crossing an international boundary; rugged terrain historically helped isolate, protect, and develop numerous factional groups based on religion, clan, and ethnicity','0575ae43b72bd18cb9c130a26bd5efa0b0986097ff6d4adee458c7779910a3dc','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('214a857ca9e3e309270dc1bd108699d7eac6b4399acdc4b21885fbe11bda6a5f',2025,'LS','Lesotho','geography',27,'Location:
Southern Africa, an enclave of South Africa
Geographic coordinates:
29 30 S, 28 30 E
Map references:
Africa
Area:
total:
30,355 sq km
land:
30,355 sq km
water:
0 sq km
comparison ranking:
total 141
Area - comparative:
slightly smaller than Maryland
Land boundaries:
total:
1,106 km
border countries (1):
South Africa 1,106 km
Coastline:
0 km (landlocked)
Maritime claims:
none (landlocked)
Climate:
temperate; cool to cold, dry winters; hot, wet summers
Terrain:
mostly highland with plateaus, hills, and mountains
Elevation:
highest point:
Thabana Ntlenyana 3,482 m
lowest point:
junction of the Orange and Makhaleng Rivers 1,400 m
mean elevation:
2,161 m
Natural resources:
water, agricultural and grazing land, diamonds, sand, clay, building stone
Land use:
agricultural land:
76.1% (2018 est.)
arable land:
10.1% (2018 est.)
permanent crops:
0.1% (2018 est.)
permanent pasture:
65.9% (2018 est.)
forest:
1.5% (2018 est.)
other:
22.4% (2018 est.)
Irrigated land:
12 sq km (2013)
Major rivers (by length in km):
Orange river source (shared with South Africa and Namibia [m]) - 2,092 km
note
– [s] after country name indicates river source; [m] after country name indicates river mouth
Major watersheds (area sq km): Atlantic Ocean drainage:
Orange (941,351 sq km)
Population distribution:
relatively higher population density in the western half of the nation, with the capital of Maseru, and the smaller cities of Mafeteng, Teyateyaneng, and Leribe attracting the most people as shown in this population distribution map
Natural hazards:
periodic droughts
Geography - note:
landlocked, an enclave of (completely surrounded by) South Africa; mountainous, more than 80% of the country is 1,800 m above sea level','7bcb735ab8eebe98322a71b24ffbf622ee2dbb4af2adb65b37e34ada40d45de0','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a227dd883ffa04e48cbb4fb288c01558f4cce1f000a947b265b3e0c85dc29444',2025,'LR','Liberia','geography',38,'Location:
Western Africa, bordering the North Atlantic Ocean, between Cote d’Ivoire and Sierra Leone
Geographic coordinates:
6 30 N, 9 30 W
Map references:
Africa
Area:
total:
111,369 sq km
land:
96,320 sq km
water:
15,049 sq km
comparison ranking:
total 104
Area - comparative:
slightly larger than Virginia
Land boundaries:
total:
1,667 km
border countries (3):
Guinea 590 km; Cote d’Ivoire 778 km; Sierra Leone 299 km
Coastline:
579 km
Maritime claims:
territorial sea:
12 nm
contiguous zone:
24 nm
exclusive economic zone:
200 nm
continental shelf:
200 nm
Climate:
tropical; hot, humid; dry winters with hot days and cool to cold nights; wet, cloudy summers with frequent heavy showers
Terrain:
mostly flat to rolling coastal plains rising to rolling plateau and low mountains in northeast
Elevation:
highest point:
Mount Wuteve 1,447 m
lowest point:
Atlantic Ocean 0 m
mean elevation:
243 m
Natural resources:
iron ore, timber, diamonds, gold, hydropower
Land use:
agricultural land:
28.1% (2018 est.)
arable land:
5.2% (2018 est.)
permanent crops:
2.1% (2018 est.)
permanent pasture:
20.8% (2018 est.)
forest:
44.6% (2018 est.)
other:
27.3% (2018 est.)
Irrigated land:
30 sq km (2012)
Population distribution:
more than half of the population lives in urban areas, with approximately one-third living within an 80-km radius of Monrovia as shown in this population distribution map
Natural hazards:
dust-laden harmattan winds blow from the Sahara (December to March)
Geography - note:
facing the Atlantic Ocean, the coastline is characterized by lagoons, mangrove swamps, and river-deposited sandbars; the inland grassy plateau supports limited agriculture','15ca1806fbac2fdf6b23eead162d4e21975452f6c126ad9464dd5beaf06c9212','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3580789aae70706c61ff8955dba37d5a1979b92bcf6b8a969a9c2004d465a545',2025,'LY','Libya','geography',2,'Location:
Northern Africa, bordering the Mediterranean Sea, between Egypt, Tunisia, and Algeria
Geographic coordinates:
25 00 N, 17 00 E
Map references:
Africa
Area:
total:
1,759,540 sq km
land:
1,759,540 sq km
water:
0 sq km
comparison ranking:
total 18
Area - comparative:
about 2.5 times the size of Texas; slightly larger than Alaska
Land boundaries:
total:
4,339 km
border countries (6):
Algeria 989 km; Chad 1,050 km; Egypt 1,115 km; Niger 342 km; Sudan 382 km; Tunisia 461 km
Coastline:
1,770 km
Maritime claims:
territorial sea:
12 nm
exclusive fishing zone:
62 nm
note:
Gulf of Sidra closing line - 32 degrees, 30 minutes north
Climate:
Mediterranean along coast; dry, extreme desert interior
Terrain:
mostly barren, flat to undulating plains, plateaus, depressions
Elevation:
highest point:
Bikku Bitti 2,267 m
lowest point:
Sabkhat Ghuzayyil -47 m
mean elevation:
423 m
Natural resources:
petroleum, natural gas, gypsum
Land use:
agricultural land:
8.8% (2018 est.)
arable land:
1% (2018 est.)
permanent crops:
0.2% (2018 est.)
permanent pasture:
7.6% (2018 est.)
forest:
0.1% (2018 est.)
other:
91.1% (2018 est.)
Irrigated land:
4,700 sq km (2012)
Major watersheds (area sq km): Internal (endorheic basin) drainage:
Lake Chad (2,497,738 sq km)
Major aquifers:
Nubian Aquifer System, North Western Sahara Aquifer System, Murzuk-Djado Basin
Population distribution:
well over 90% of the population lives along the Mediterranean coast in and between Tripoli to the west and Al Bayda to the east; the interior remains vastly underpopulated due to the Sahara and lack of surface water as shown in this population distribution map
Natural hazards:
hot, dry, dust-laden ghibli is a southern wind lasting one to four days in spring and fall; dust storms, sandstorms
Geography - note:
note 1:
more than 90% of the country is desert or semidesert
note 2:
the volcano Waw an Namus lies in south central Libya in the middle of the Sahara; the caldera is an oasis - the name means “oasis of mosquitoes” - containing several small lakes surrounded by vegetation and hosting various insects and a large diversity of birds','5d338d0f9d79766e13364bf1dff7b981d82ebf560fc54eccad77fab14ecf0c66','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c6106b3b005310bc623a85be0a7c6fa48b157631635e5eb65bb8484bf3c3ad57',2025,'LI','Liechtenstein','geography',14,'Location:
Central Europe, between Austria and Switzerland
Geographic coordinates:
47 16 N, 9 32 E
Map references:
Europe
Area:
total:
160 sq km
land:
160 sq km
water:
0 sq km
comparison ranking:
total 218
Area - comparative:
about 0.9 times the size of Washington, DC
Land boundaries:
total:
75 km
border countries (2):
Austria 34 km; Switzerland 41 km
Coastline:
0 km (doubly landlocked)
Maritime claims:
none (landlocked)
Climate:
continental; cold, cloudy winters with frequent snow or rain; cool to moderately warm, cloudy, humid summers
Terrain:
mostly mountainous (Alps) with Rhine Valley in western third
Elevation:
highest point:
Vorder-Grauspitz 2,599 m
lowest point:
Ruggeller Riet 430 m
Natural resources:
hydroelectric potential, arable land
Land use:
agricultural land:
37.6% (2018 est.)
arable land:
18.8% (2018 est.)
permanent crops:
0% (2018 est.)
permanent pasture:
18.8% (2018 est.)
forest:
43.1% (2018 est.)
other:
19.3% (2018 est.)
Irrigated land:
0 sq km (2012)
Major watersheds (area sq km): Atlantic Ocean drainage:
Rhine-Maas (198,735 sq km)
Population distribution:
most of the population is found in the western half of the country along the Rhine River
Natural hazards:
avalanches, landslides
Geography - note:
along with Uzbekistan, one of only two doubly landlocked countries in the world; variety of microclimatic variations based on elevation','7a3c88206377041d3ac3a60fa40cae84eb4b78bfe8cfab06a34f1a73515afd13','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cb5766b9fc814dcc2d553738499e6469bb129bc5102101185604961c79d045e8',2025,'LT','Lithuania','geography',25,'Location:
Eastern Europe, bordering the Baltic Sea, between Latvia and Russia, west of Belarus
Geographic coordinates:
56 00 N, 24 00 E
Map references:
Europe
Area:
total:
65,300 sq km
land:
62,680 sq km
water:
2,620 sq km
comparison ranking:
total 123
Area - comparative:
slightly larger than West Virginia
Land boundaries:
total:
1,545 km
border countries (4):
Belarus 640 km; Latvia 544 km; Poland 100 km; Russia (Kaliningrad) 261 km
Coastline:
90 km
Maritime claims:
territorial sea:
12 nm
Climate:
transitional, between maritime and continental; wet, moderate winters and summers
Terrain:
lowland, many scattered small lakes, fertile soil
Elevation:
highest point:
Aukstojas 294 m
lowest point:
Baltic Sea 0 m
mean elevation:
110 m
Natural resources:
peat, arable land, amber
Land use:
agricultural land:
44.8% (2018 est.)
arable land:
34.9% (2018 est.)
permanent crops:
0.5% (2018 est.)
permanent pasture:
9.4% (2018 est.)
forest:
34.6% (2018 est.)
other:
20.6% (2018 est.)
Irrigated land:
16 sq km (2013)
Major lakes (area sq km):
salt water lake(s):
Curonian Lagoon (shared with Russia) - 1,620 sq km
Population distribution:
fairly even population distribution throughout the country, but somewhat greater concentrations in the southern cities of Vilnius and Kaunas, and the western port of Klaipeda
Natural hazards:
occasional floods, droughts
Geography - note:
fertile central plains are separated by hilly uplands that are ancient glacial deposits','bf6fab8ffbb57073a9c847f31ae753846d03e5aa04d2e8c5059e0f66c006e316','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('340d66261e420281505f6f0b58737a6850b6f1950108f77ac52709ebc029165c',2025,'LU','Luxembourg','geography',37,'Location:
Western Europe, between France and Germany
Geographic coordinates:
49 45 N, 6 10 E
Map references:
Europe
Area:
total:
2,586 sq km
land:
2,586 sq km
water:
0 sq km
comparison ranking:
total 178
Area - comparative:
slightly smaller than Rhode Island; about half the size of Delaware
Land boundaries:
total:
327 km
border countries (3):
Belgium 130 km; France 69 km; Germany 128 km
Coastline:
0 km (landlocked)
Maritime claims:
none (landlocked)
Climate:
modified continental with mild winters, cool summers
Terrain:
mostly gently rolling uplands with broad, shallow valleys; uplands to slightly mountainous in the north; steep slope down to Moselle flood plain in the southeast
Elevation:
highest point:
Buurgplaatz 559 m
lowest point:
Moselle River 133 m
mean elevation:
325 m
Natural resources:
iron ore (no longer exploited), arable land
Land use:
agricultural land:
50.7% (2018 est.)
arable land:
24% (2018 est.)
permanent crops:
0.6% (2018 est.)
permanent pasture:
26.1% (2018 est.)
forest:
33.5% (2018 est.)
other:
15.8% (2018 est.)
Irrigated land:
0 sq km (2012)
Major watersheds (area sq km): Atlantic Ocean drainage:
Rhine-Maas (198,735 sq km)
Population distribution:
most people live in the south, on or near the border with France
Natural hazards:
occasional flooding
Geography - note:
landlocked; the only grand duchy in the world','b1df775b1cacdedfaa4ee7d2157da2750fd1a5b520f8a75b700a982719cca5db','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('66cb2a9bd64a919b89ea297c8599c9d82bcd5690312882d61ebaedd6eb037bbf',2025,'MG','Madagascar','geography',4,'Location:
Southern Africa, island in the Indian Ocean, east of Mozambique
Geographic coordinates:
20 00 S, 47 00 E
Map references:
Africa
Area:
total:
587,041 sq km
land:
581,540 sq km
water:
5,501 sq km
comparison ranking:
total 49
Area - comparative:
almost four times the size of Georgia; slightly less than twice the size of Arizona
Land boundaries:
total:
0 km
Coastline:
4,828 km
Maritime claims:
territorial sea:
12 nm
contiguous zone:
24 nm
exclusive economic zone:
200 nm
continental shelf:
200 nm or 100 nm from the 2,500-m isobath
Climate:
tropical along coast, temperate inland, arid in south
Terrain:
narrow coastal plain, high plateau and mountains in center
Elevation:
highest point:
Maromokotro 2,876 m
lowest point:
Indian Ocean 0 m
mean elevation:
615 m
Natural resources:
graphite, chromite, coal, bauxite, rare earth elements, salt, quartz, tar sands, semiprecious stones, mica, fish, hydropower
Land use:
agricultural land:
71.1% (2018 est.)
arable land:
6% (2018 est.)
permanent crops:
1% (2018 est.)
permanent pasture:
64.1% (2018 est.)
forest:
21.5% (2018 est.)
other:
7.4% (2018 est.)
Irrigated land:
10,860 sq km (2012)
Population distribution:
most of population lives on the eastern half of the island; significant clustering is found in the central highlands and eastern coastline as shown in this population distribution map
Natural hazards:
periodic cyclones; drought; and locust infestation
volcanism:
Madagascar’s volcanoes have not erupted in historical times
Geography - note:
world’s fourth-largest island; strategic location along Mozambique Channel; despite Madagascar’s close proximity to the African continent, ocean currents isolate the island resulting in high rates of endemic plant and animal species; approximately 90% of the flora and fauna on the island are found nowhere else','8410f3ee734e8ab41911ca0756ce3ef42c46992cdeff846c70853645c98c3333','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ea19b5c8d3dc1899a65098b110818fb36427966afe36197b003876d2fb289b1c',2025,'MW','Malawi','geography',15,'Location:
Southern Africa, east of Zambia, west and north of Mozambique
Geographic coordinates:
13 30 S, 34 00 E
Map references:
Africa
Area:
total:
118,484 sq km
land:
94,080 sq km
water:
24,404 sq km
comparison ranking:
total 100
Area - comparative:
slightly smaller than Pennsylvania
Land boundaries:
total:
2,857 km
border countries (3):
Mozambique 1,498 km; Tanzania 512 km; Zambia 847 km
Coastline:
0 km (landlocked)
Maritime claims:
none (landlocked)
Climate:
sub-tropical; rainy season (November to May); dry season (May to November)
Terrain:
narrow elongated plateau with rolling plains, rounded hills, some mountains
Elevation:
highest point:
Sapitwa (Mount Mlanje) 3,002 m
lowest point:
junction of the Shire River and international boundary with Mozambique 37 m
mean elevation:
779 m
Natural resources:
limestone, arable land, hydropower, unexploited deposits of uranium, coal, and bauxite
Land use:
agricultural land:
59.2% (2018 est.)
arable land:
38.2% (2018 est.)
permanent crops:
1.4% (2018 est.)
permanent pasture:
19.6% (2018 est.)
forest:
34% (2018 est.)
other:
6.8% (2018 est.)
Irrigated land:
740 sq km (2012)
Major lakes (area sq km):
fresh water lake(s):
Lake Malawi (shared with Mozambique and Tanzania) - 22,490
salt water lake(s):
Lake Chilwa - 1,040 sq km
Major rivers (by length in km):
Zambezi (shared with Zambia [s], Angola, Zimbabwe, Namibia, Tanzania, and Mozambique [m]) - 2,740 km note – [s] after country name indicates river source; [m] after country name indicates river mouth
Major watersheds (area sq km): Atlantic Ocean drainage:
Congo (3,730,881 sq km)
Indian Ocean drainage:
Zambezi (1,332,412 sq km)
Population distribution:
population density is highest south of Lake Nyasa as shown in this population distribution map
Natural hazards:
flooding; droughts; earthquakes
Geography - note:
landlocked; Lake Nyasa, some 580 km long, is the country’s most prominent physical feature; it contains more fish species than any other lake on earth','bf22316995a6f6d4d8b3bfd0c553deb0724b05f7cde683d67d25aa5ffbc17e9a','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('adf6b4ad4f61f6aacb006b29cddd25d5f511a1e8ccff2f8f70e6d4a2de0e8e13',2025,'MY','Malaysia','geography',26,'Location:
Southeastern Asia, peninsula bordering Thailand and northern one-third of the island of Borneo, bordering Indonesia, Brunei, and the South China Sea, south of Vietnam
Geographic coordinates:
2 30 N, 112 30 E
Map references:
Southeast Asia
Area:
total:
329,847 sq km
land:
328,657 sq km
water:
1,190 sq km
comparison ranking:
total 68
Area - comparative:
slightly larger than New Mexico
Land boundaries:
total:
2,742 km
border countries (3):
Brunei 266 km; Indonesia 1,881 km; Thailand 595 km
Coastline:
4,675 km (Peninsular Malaysia 2,068 km, East Malaysia 2,607 km)
Maritime claims:
territorial sea:
12 nm
exclusive economic zone:
200 nm
continental shelf:
200-m depth or to the depth of exploitation; specified boundary in the South China Sea
Climate:
tropical; annual southwest (April to October) and northeast (October to February) monsoons
Terrain:
coastal plains rising to hills and mountains
Elevation:
highest point:
Gunung Kinabalu 4,095 m
lowest point:
Indian Ocean 0 m
mean elevation:
419 m
Natural resources:
tin, petroleum, timber, copper, iron ore, natural gas, bauxite
Land use:
agricultural land:
23.2% (2018 est.)
arable land:
2.9% (2018 est.)
permanent crops:
19.4% (2018 est.)
permanent pasture:
0.9% (2018 est.)
forest:
62% (2018 est.)
other:
14.8% (2018 est.)
Irrigated land:
4,420 sq km (2020)
Population distribution:
a highly uneven distribution with over 80% of the population residing on the Malay Peninsula
Natural hazards:
flooding; landslides; forest fires
Geography - note:
strategic location along Strait of Malacca and southern South China Sea','54f34ae222d23c2e53a26ced6027595db109049943c963dc6df1706ee4c7787d','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3079a525feadb2996ff5c4ebaf6e53a400d117832bf8adc1a6f64c58484f0c1e',2025,'MV','Maldives','geography',39,'Location:
Southern Asia, group of atolls in the Indian Ocean, south-southwest of India
Geographic coordinates:
3 15 N, 73 00 E
Map references:
Asia
Area:
total:
298 sq km
land:
298 sq km
water:
0 sq km
comparison ranking:
total 209
Area - comparative:
about 1.7 times the size of Washington, DC
Land boundaries:
total:
0 km
Coastline:
644 km
Maritime claims:
territorial sea:
12 nm
contiguous zone:
24 nm
exclusive economic zone:
200 nm measured from claimed archipelagic straight baselines
Climate:
tropical; hot, humid; dry, northeast monsoon (November to March); rainy, southwest monsoon (June to August)
Terrain:
flat coral atolls, with white sandy beaches; sits atop the submarine volcanic Chagos-Laccadive Ridge
Elevation:
highest point:
8th tee, golf course, Villingi Island 5 m
lowest point:
Indian Ocean 0 m
mean elevation:
2 m
Natural resources:
fish
Land use:
agricultural land:
23.3% (2018 est.)
arable land:
10% (2018 est.)
permanent crops:
10% (2018 est.)
permanent pasture:
3.3% (2018 est.)
forest:
3% (2018 est.)
other:
73.7% (2018 est.)
Irrigated land:
0 sq km (2012)
Population distribution:
about a third of the population lives in the centrally located capital city of Male and almost a tenth in southern Addu City; the remainder of the populace is spread over the 200 or so populated islands of the archipelago
Natural hazards:
tsunamis; low elevation of islands makes them sensitive to sea level rise
Geography - note:
smallest Asian country; archipelago of 1,190 coral islands grouped into 26 atolls (200 inhabited islands, plus 80 islands with tourist resorts); strategic location astride and along major sea lanes in Indian Ocean','e280c9ae9338df5fb0ca899958b9070806a5d4ac74b090f293b9dfa16f83c8f0','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f248356009ca500b9ed6295e03f5222cdd6f26dfb507ea07b97e2e7558ea5cb9',2025,'ML','Mali','geography',2,'Location:
interior Western Africa, southwest of Algeria, north of Guinea, Cote d’Ivoire, and Burkina Faso, west of Niger
Geographic coordinates:
17 00 N, 4 00 W
Map references:
Africa
Area:
total:
1,240,192 sq km
land:
1,220,190 sq km
water:
20,002 sq km
comparison ranking:
total 25
Area - comparative:
slightly less than twice the size of Texas
Land boundaries:
total:
7,908 km
border countries (6):
Algeria 1,359 km; Burkina Faso 1,325 km; Cote d’Ivoire 599 km; Guinea 1,062 km; Mauritania 2,236 km; Niger 838 km, Senegal 489 km
Coastline:
0 km (landlocked)
Maritime claims:
none (landlocked)
Climate:
subtropical to arid; hot and dry (February to June); rainy, humid, and mild (June to November); cool and dry (November to February)
Terrain:
mostly flat to rolling northern plains covered by sand; savanna in south, rugged hills in northeast
Elevation:
highest point:
Hombori Tondo 1,155 m
lowest point:
Senegal River 23 m
mean elevation:
343 m
Natural resources:
gold, phosphates, kaolin, salt, limestone, uranium, gypsum, granite, hydropower, note, bauxite, iron ore, manganese, tin, and copper deposits are known but not exploited
Land use:
agricultural land:
34.1% (2018 est.)
arable land:
5.6% (2018 est.)
permanent crops:
0.1% (2018 est.)
permanent pasture:
28.4% (2018 est.)
forest:
10.2% (2018 est.)
other:
55.7% (2018 est.)
Irrigated land:
3,780 sq km (2012)
Major lakes (area sq km):
fresh water lake(s):
Lac Faguibine - 590 sq km
note - the Niger River is the only source of water for the lake; in recent years the lake is dry
Major rivers (by length in km):
Niger (shared with Guinea [s], Niger, and Nigeria [m]) - 4,200 km; Senegal (shared with Guinea [s], Senegal, and Mauritania [m]) - 1,641 km
note – [s] after country name indicates river source; [m] after country name indicates river mouth
Major watersheds (area sq km): Atlantic Ocean drainage:
Niger (2,261,741 sq km), Senegal (456,397 sq km), Volta (410,991 sq km)
Major aquifers:
Lullemeden-Irhazer Basin, Taodeni-Tanezrouft Basin
Population distribution:
the overwhelming majority of the population lives in the southern half of the country, with greater density along the border with Burkina Faso as shown in this population distribution map
Natural hazards:
hot, dust-laden harmattan haze common during dry seasons; recurring droughts; occasional Niger River flooding
Geography - note:
landlocked; divided into three natural zones:
the southern, cultivated Sudanese; the central, semiarid Sahelian; and the northern, arid Saharan','32b7fac3b29d84e6155ed86116e00f284c6754c81af913472442a3e08bcbef7e','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8ec029607f82b0e5ced50a1424532776d4c095af80e84352ca86c6753ee06f82',2025,'MT','Malta','geography',14,'Location:
Southern Europe, islands in the Mediterranean Sea, south of Sicily (Italy)
Geographic coordinates:
35 50 N, 14 35 E
Map references:
Europe
Area:
total:
316 sq km
land:
316 sq km
water:
0 sq km
comparison ranking:
total 208
Area - comparative:
slightly less than twice the size of Washington, DC
Land boundaries:
total:
0 km
Coastline:
196.8 km (excludes 56 km for the island of Gozo)
Maritime claims:
territorial sea:
12 nm
contiguous zone:
24 nm
continental shelf:
200-m depth or to the depth of exploitation
exclusive fishing zone:
25 nm
Climate:
Mediterranean; mild, rainy winters; hot, dry summers
Terrain:
mostly low, rocky, flat to dissected plains; many coastal cliffs
Elevation:
highest point:
Ta’Dmejrek on Dingli Cliffs 253 m
lowest point:
Mediterranean Sea 0 m
Natural resources:
limestone, salt, arable land
Land use:
agricultural land:
32.3% (2018 est.)
arable land:
28.4% (2018 est.)
permanent crops:
3.9% (2018 est.)
permanent pasture:
0% (2018 est.)
forest:
0.9% (2018 est.)
other:
66.8% (2018 est.)
Irrigated land:
35 sq km (2020)
Population distribution:
most of the population lives on the eastern half of Malta, the largest of the three inhabited islands
Natural hazards:
occasional droughts
Geography - note:
the country comprises an archipelago, with only the three largest islands (Malta, Ghawdex or Gozo, and Kemmuna or Comino) inhabited; numerous bays provide good harbors; Malta and Tunisia are discussing oil exploration on the continental shelf between their countries, although no commercially viable reserves have been found as of 2017','e9016fd7d7722566070b31badffe0c5679c91fb43f39c207955673e1e921e18a','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6cb09de0a23c9a9fd89b4f6d7b486b1392c616316bf7c6d59d1678e21ca4631c',2025,'MH','Marshall Islands','geography',26,'Location:
Oceania, consists of 29 atolls and five isolated islands in the North Pacific Ocean, about halfway between Hawaii and Australia; the atolls and islands are situated in two, almost-parallel island chains - the Ratak (Sunrise) group and the Ralik (Sunset) group; the total number of islands and islets is about 1,225; 22 of the atolls and four of the islands are uninhabited
Geographic coordinates:
9 00 N, 168 00 E
Map references:
Oceania
Area:
total:
181 sq km
land:
181 sq km
water:
0 sq km
note:
the archipelago includes 11,673 sq km of lagoon waters and encompasses the atolls of Bikini, Enewetak, Kwajalein, Majuro, Rongelap, and Utirik
comparison ranking:
total 216
Area - comparative:
about the size of Washington, DC
Land boundaries:
total:
0 km
Coastline:
370.4 km
Maritime claims:
territorial sea:
12 nm
contiguous zone:
24 nm
exclusive economic zone:
200 nm
Climate:
tropical; hot and humid; wet season May to November; islands border typhoon belt
Terrain:
low coral limestone and sand islands
Elevation:
highest point:
East-central Airik Island, Maloelap Atoll 14 m
lowest point:
Pacific Ocean 0 m
mean elevation:
2 m
Natural resources:
coconut products, marine products, deep seabed minerals
Land use:
agricultural land:
50.7% (2018 est.)
arable land:
7.8% (2018 est.)
permanent crops:
31.2% (2018 est.)
permanent pasture:
11.7% (2018 est.)
forest:
49.3% (2018 est.)
other:
0% (2018 est.)
Irrigated land:
0 sq km (2022)
Population distribution:
most people live in urban clusters found on many of the country’s islands; more than two-thirds of the population lives on the atolls of Majuro and Ebeye
Natural hazards:
infrequent typhoons
Geography - note:
the islands of Bikini and Enewetak are former US nuclear test sites; Kwajalein atoll, famous as a World War II battleground, surrounds the world’s largest lagoon and is used as a US missile test range; the island city of Ebeye is the second largest settlement in the Marshall Islands, after the capital of Majuro, and one of the most densely populated locations in the Pacific','5f97fe6605446437a995291fbf32e2d521b737a63887c5db2627d1a2d25f839e','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('eb36490045899097222f5923f6dbaa8e43191980d615440472421aebe2d6cdc9',2025,'MR','Mauritania','geography',37,'Location:
Western Africa, bordering the North Atlantic Ocean, between Senegal and Western Sahara
Geographic coordinates:
20 00 N, 12 00 W
Map references:
Africa
Area:
total:
1,030,700 sq km
land:
1,030,700 sq km
water:
0 sq km
comparison ranking:
total 30
Area - comparative:
slightly larger than three times the size of New Mexico; about six times the size of Florida
Land boundaries:
total:
5,002 km
border countries (4):
Algeria 460 km; Mali 2,236 km; Morocco 1,564 km; Senegal 742 km
Coastline:
754 km
Maritime claims:
territorial sea:
12 nm
contiguous zone:
24 nm
exclusive economic zone:
200 nm
continental shelf:
200 nm or to the edge of the continental margin
Climate:
desert; constantly hot, dry, dusty
Terrain:
mostly barren, flat plains of the Sahara; some central hills
Elevation:
highest point:
Kediet Ijill 915 m
lowest point:
Sebkhet Te-n-Dghamcha -5 m
mean elevation:
276 m
Natural resources:
iron ore, gypsum, copper, phosphate, diamonds, gold, oil, fish
Land use:
agricultural land:
38.5% (2018 est.)
arable land:
0.4% (2018 est.)
permanent crops:
0% (2018 est.)
permanent pasture:
38.1% (2018 est.)
forest:
0.2% (2018 est.)
other:
61.3% (2018 est.)
Irrigated land:
450 sq km (2012)
Major rivers (by length in km):
Senegal river mouth (shared with Guinea [s], Senegal and Mali) - 1,641 km
note – [s] after country name indicates river source; [m] after country name indicates river mouth
Major watersheds (area sq km): Atlantic Ocean drainage:
Niger (2,261,741 sq km), Senegal (456,397 sq km)
Major aquifers:
Senegalo-Mauritanian Basin, Taodeni-Tanzerouft Basin
Population distribution:
with most of the country being a desert, vast areas of the country, particularly in the central, northern, and eastern areas, are without sizeable population clusters; half the population lives in or around the coastal capital of Nouakchott; smaller clusters are found near the southern border with Mali and Senegal as shown in this population distribution map
Natural hazards:
hot, dry, dust/sand-laden sirocco wind primarily in March and April; periodic droughts
Geography - note:
Mauritania is considered both a part of North Africa’s Maghreb region and West Africa’s Sahel region; most of the population is concentrated in the cities of Nouakchott and Nouadhibou and along the Senegal River in the southern part of the country','4b43ecc43c0845746aeed6fadc1ee330728b63491846200d941e3ccdad766aa0','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('155579e2ce0e1a113447e4726a20b8dda2392e9640b68ad88c52c1faea4c0929',2025,'MU','Mauritius','geography',49,'Location:
Southern Africa, island in the Indian Ocean, about 800 km (500 mi) east of Madagascar
Geographic coordinates:
20 17 S, 57 33 E
Map references:
Africa
Area:
total:
2,040 sq km
land:
2,030 sq km
water:
10 sq km
note:
includes Agalega Islands, Cargados Carajos Shoals (Saint Brandon), and Rodrigues comparison ranking: total 180
Area - comparative:
almost 11 times the size of Washington, DC
Land boundaries:
total:
0 km
Coastline:
177 km
Maritime claims:
territorial sea:
12 nm
exclusive economic zone:
200 nm
continental shelf:
200 nm or to the edge of the continental margin measured from claimed archipelagic straight baselines
Climate:
tropical, modified by southeast trade winds; warm, dry winter (May to November); hot, wet, humid summer (November to May)
Terrain:
small coastal plain rising to discontinuous mountains encircling central plateau
Elevation:
highest point:
Mont Piton 828 m
lowest point:
Indian Ocean 0 m
Natural resources:
arable land, fish
Land use:
agricultural land:
43.8% (2018 est.)
arable land:
38.4% (2018 est.)
permanent crops:
2% (2018 est.)
permanent pasture:
3.4% (2018 est.)
forest:
17.3% (2018 est.)
other:
38.9% (2018 est.)
Irrigated land:
158 sq km (2020)
Population distribution:
population density is one of the highest in the world; urban clusters are found throughout the main island, with a greater density in and around Port Luis; population on Rodrigues Island is spread across the island with a slightly denser cluster on the north coast as shown in this population distribution map
Natural hazards:
cyclones (November to April); almost completely surrounded by reefs that may pose maritime hazards
Geography - note:
the main island, from which the country derives its name, is of volcanic origin and is almost entirely surrounded by coral reefs; former home of the dodo, a large flightless bird related to pigeons, driven to extinction by the end of the 17th century through a combination of hunting and the introduction of predatory species','cc2b2b08b9d19ecb9f1a9bfcdc1405041e93f7c60705761df2a888f9656989f5','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3ee865736d99117752dd4eb7fff54da06f73b08392160056e485dfa2b575bdc2',2025,'MX','Mexico','geography',2,'Location:
North America, bordering the Caribbean Sea and the Gulf of Mexico, between Belize and the United States and bordering the North Pacific Ocean, between Guatemala and the United States
Geographic coordinates:
23 00 N, 102 00 W
Map references:
North America
Area:
total:
1,964,375 sq km
land:
1,943,945 sq km
water:
20,430 sq km
comparison ranking:
total 15
Area - comparative:
slightly less than three times the size of Texas
Land boundaries:
total:
4,389 km
border countries (3):
Belize 276 km; Guatemala 958 km; US 3,155 km
Coastline:
9,330 km
Maritime claims:
territorial sea:
12 nm
contiguous zone:
24 nm
exclusive economic zone:
200 nm
continental shelf:
200 nm or to the edge of the continental margin
Climate:
varies from tropical to desert
Terrain:
high, rugged mountains; low coastal plains; high plateaus; desert
Elevation:
highest point:
Volcan Pico de Orizaba 5,636 m
lowest point:
Laguna Salada -10 m
mean elevation:
1,111 m
Natural resources:
petroleum, silver, antimony, copper, gold, lead, zinc, natural gas, timber
Land use:
agricultural land:
54.9% (2018 est.)
arable land:
11.8% (2018 est.)
permanent crops:
1.4% (2018 est.)
permanent pasture:
41.7% (2018 est.)
forest:
33.3% (2018 est.)
other:
11.8% (2018 est.)
Irrigated land:
60,620 sq km (2020)
Major lakes (area sq km):
fresh water lake(s):
Laguna de Chapala - 1,140 sq km
salt water lake(s):
Laguna de Terminos - 1,550 sq km
Major rivers (by length in km):
Rio Grande river mouth (shared with US [s]) - 3,057 km; Colorado river mouth (shared with US [s]) - 2,333 km
note – [s] after country name indicates river source; [m] after country name indicates river mouth
Major watersheds (area sq km): Atlantic Ocean drainage:
(Gulf of Mexico)
Rio Grande/Bravo (607,965 sq km)
Pacific Ocean drainage:
(Gulf of California)
Colorado (703,148 sq km)
Major aquifers:
Atlantic and Gulf Coastal Plains Aquifer
Population distribution:
most of the population is found in the middle of the country between the states of Jalisco and Veracruz; approximately a quarter of the population lives in and around Mexico City
Natural hazards:
tsunamis along the Pacific coast, volcanoes and destructive earthquakes in the center and south, and hurricanes on the Pacific, Gulf of Mexico, and Caribbean coasts
volcanism:
volcanic activity in the central-southern part of the country; the volcanoes in Baja California are mostly dormant; Colima (3,850 m), which erupted in 2010, is Mexico’s most active volcano and is responsible for causing periodic evacuations of nearby villagers; it has been deemed a Decade Volcano by the International Association of Volcanology and Chemistry of the Earth’s Interior, worthy of study due to its explosive history and close proximity to human populations; Popocatepetl (5,426 m) poses a threat to Mexico City; other historically active volcanoes include Barcena, Ceboruco, El Chichon, Michoacan-Guanajuato, Pico de Orizaba, San Martin, Socorro, and Tacana; see note 2 under “Geography - note”
Geography - note:
note 1:
strategic location on southern border of the US; Mexico is one of the countries along the Ring of Fire, a belt of active volcanoes and earthquake epicenters bordering the Pacific Ocean; up to 90% of the world’s earthquakes and some 75% of the world’s volcanoes occur within the Ring of Fire
note 2:
some of the world’s most important food crops were first domesticated in Mexico; the “Three Sisters” companion plants - winter squash, maize (corn), and climbing beans - served as the main agricultural crops for various North American Indian groups; all three apparently originated in Mexico but then were widely disseminated through much of North America; avocado, amaranth, and chili peppers also emanate from Mexico, as does vanilla, the world’s most popular aroma and flavor spice; although cherry tomatoes originated in Ecuador, their domestication in Mexico transformed them into the larger modern tomato
note 3:
the Sac Actun cave system at 348 km (216 mi) is the longest underwater cave in the world and the second longest cave worldwide, after Mammoth Cave in the United States (see “Geography - note” under United States)
note 4:
the prominent Yucatán Peninsula that divides the Gulf of Mexico from the Caribbean Sea is shared by Mexico, Guatemala, and Belize; just on the northern coast of Yucatan, near the town of Chicxulub (pronounce cheek-sha-loob), lie the remnants of a massive crater (some 150 km in diameter and extending well out into the Gulf of Mexico); formed by an asteroid or comet when it struck the earth 66 million years ago, the impact is now widely accepted as initiating a worldwide climate disruption that caused a mass extinction of 75% of all the earth’s plant and animal species - including the non-avian dinosaurs','9c41d6b71217f7cac50daa82bfdabacc8d553798395454760a22610ef5cd22f6','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b06357bd289326adccb73a06d602a8a7c250e2f0315a8291271a08be1c168dc2',2025,'FM','Micronesia, Federated States of','geography',14,'Location:
Oceania, island group in the North Pacific Ocean, about three-quarters of the way from Hawaii to Indonesia
Geographic coordinates:
6 55 N, 158 15 E
Map references:
Oceania
Area:
total:
702 sq km
land:
702 sq km
water:
0 sq km (fresh water only)
note:
includes Pohnpei (Ponape), Chuuk (Truk) Islands, Yap Islands, and Kosrae (Kosaie)
comparison ranking:
total 191
Area - comparative:
four times the size of Washington, DC (land area only)
Land boundaries:
total:
0 km
Coastline:
6,112 km
Maritime claims:
territorial sea:
12 nm
exclusive economic zone:
200 nm
Climate:
tropical; heavy year-round rainfall, especially in the eastern islands; located on southern edge of the typhoon belt with occasionally severe damage
Terrain:
islands vary geologically from high mountainous islands to low, coral atolls; volcanic outcroppings on Pohnpei, Kosrae, and Chuuk
Elevation:
highest point:
Nanlaud on Pohnpei 782 m
lowest point:
Pacific Ocean 0 m
Natural resources:
timber, marine products, deep-seabed minerals, phosphate
Land use:
agricultural land:
25.5% (2018 est.)
arable land:
2.3% (2018 est.)
permanent crops:
19.7% (2018 est.)
permanent pasture:
3.5% (2018 est.)
forest:
74.5% (2018 est.)
other:
0% (2018 est.)
Irrigated land:
0 sq km (2022)
Population distribution:
the majority of the populaton lives in the coastal areas of the high islands; the mountainous interior is largely uninhabited; less than half of the population lives in urban areas
Natural hazards:
typhoons (June to December)
Geography - note:
composed of four major island groups totaling 607 islands','a640aebdab8604224f95a511e4249e2705b620d67fd320c4a629da4c0bd728d4','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('205de16a192f5722cbc951c9f2014cbe773d6d56a9cb70557a53a6fd4d9ab6e7',2025,'FM','Micronesia, Federated States of','geography',25,'Location:
Eastern Europe, northeast of Romania
Geographic coordinates:
47 00 N, 29 00 E
Map references:
Europe
Area:
total:
33,851 sq km
land:
32,891 sq km
water:
960 sq km
comparison ranking:
total 139
Area - comparative:
slightly larger than Maryland
Land boundaries:
total:
1,885 km
border countries (2):
Romania 683 km; Ukraine 1202 km
Coastline:
0 km (landlocked)
Maritime claims:
none (landlocked)
Climate:
moderate winters, warm summers
Terrain:
rolling steppe, gradual slope south to Black Sea
Elevation:
highest point:
Dealul Balanesti 430 m
lowest point:
Dniester (Nistru) 2 m
mean elevation:
139 m
Natural resources:
lignite, phosphorites, gypsum, limestone, arable land
Land use:
agricultural land:
74.9% (2018 est.)
arable land:
55.1% (2018 est.)
permanent crops:
9.1% (2018 est.)
permanent pasture:
10.7% (2018 est.)
forest:
11.9% (2018 est.)
other:
13.2% (2018 est.)
Irrigated land:
2,155 sq km (2020)
Major rivers (by length in km):
Dunărea (Danube) (shared with Germany [s], Austria, Slovakia, Czechia, Hungary, Croatia, Serbia, Bulgaria, Ukraine, and Romania [m]) - 2,888 km; Nistru (Dniester) (shared with Ukraine [s/m]) - 1,411 km note – [s] after country name indicates river source; [m] after country name indicates river mouth
Major watersheds (area sq km): Atlantic Ocean drainage:
(Black Sea)
Danube (795,656 sq km)
Population distribution:
pockets of agglomeration exist throughout the country, the largest being in the center of the country around the capital of Chisinau, followed by Tiraspol and Balti
Natural hazards:
landslides
Geography - note:
landlocked; well endowed with various sedimentary rocks and minerals including sand, gravel, gypsum, and limestone','dc1a5b155cb62e82082afed039ae1d3062950dbab346bcd41d3b1335a3620cb8','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3c7ca4f5ad7983632e20d93fac6f6c58e9348d37cb1049da08018df9d0bd4b77',2025,'MC','Monaco','geography',36,'Location:
Western Europe, bordering the Mediterranean Sea on the southern coast of France, near the border with Italy
Geographic coordinates:
43 44 N, 7 24 E
Map references:
Europe
Area:
total:
2 sq km
land:
2 sq km
water:
0 sq km
comparison ranking:
total 254
Area - comparative:
about three times the size of the National Mall in Washington, DC
Land boundaries:
total:
6 km
border countries (1):
France 6 km
Coastline:
4.1 km
Maritime claims:
territorial sea:
12 nm
exclusive economic zone:
12 nm
Climate:
Mediterranean with mild, wet winters and hot, dry summers
Terrain:
hilly, rugged, rocky
Elevation:
highest point:
Chemin des Revoires on Mont Agel 162 m
lowest point:
Mediterranean Sea 0 m
Natural resources:
none
Land use:
agricultural land:
1% (2018 est.)
arable land:
0% (2018 est.)
permanent crops:
1% (2018 est.)
permanent pasture:
0% (2018 est.)
forest:
0% (2018 est.)
other:
99% (2018 est.)
Irrigated land:
0 sq km (2022)
Population distribution:
the second most densely populated country in the world (after Macau); its entire population living on 2 square km
Natural hazards:
none
Geography - note:
second-smallest independent state in the world (after the Holy See); smallest country with a coastline; almost entirely urban','fb60df34dbd8d5c74f8d95649a7be4a0ea839a88e7621891969c331d118bc628','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cce432cb23aa4cf74803714fe2afa44d0c8d861c8b79b0a48a9c7f24381e1c64',2025,'MN','Mongolia','geography',47,'Location:
Northern Asia, between China and Russia
Geographic coordinates:
46 00 N, 105 00 E
Map references:
Asia
Area:
total:
1,564,116 sq km
land:
1,553,556 sq km
water:
10,560 sq km
comparison ranking:
total 20
Area - comparative:
slightly smaller than Alaska; more than twice the size of Texas
Land boundaries:
total:
8,082 km
border countries (2):
China 4,630 km; Russia 3,452 km
Coastline:
0 km (landlocked)
Maritime claims:
none (landlocked)
Climate:
desert; continental (large daily and seasonal temperature ranges)
Terrain:
vast semidesert and desert plains, grassy steppe, mountains in west and southwest; Gobi Desert in south-central
Elevation:
highest point:
Nayramadlin Orgil (Khuiten Peak) 4,374 m
lowest point:
Hoh Nuur 560 m
mean elevation:
1,528 m
Natural resources:
oil, coal, copper, molybdenum, tungsten, phosphates, tin, nickel, zinc, fluorspar, gold, silver, iron
Land use:
agricultural land:
73% (2018 est.)
arable land:
0.4% (2018 est.)
permanent crops:
0% (2018 est.)
permanent pasture:
72.6% (2018 est.)
forest:
7% (2018 est.)
other:
20% (2018 est.)
Irrigated land:
602 sq km (2020)
Major lakes (area sq km):
fresh water lake(s):
Hovsgol Nuur - 2,620 sq km; Har Us Nuur - 1,760 sq km;
salt water lake(s):
Uvs Nuur - 3,350 sq km; Hyargas Nuur - 1,360 sq km
Major rivers (by length in km):
Amur (shared with China [s] and Russia [m]) - 4,444 km
note – [s] after country name indicates river source; [m] after country name indicates river mouth
Population distribution:
sparsely distributed population throughout the country; the capital of Ulaanbaatar and the northern city of Darhan support the highest population densities
Natural hazards:
dust storms; grassland and forest fires; drought; “zud,” which is harsh winter conditions
Geography - note:
landlocked; strategic location between China and Russia','df6aa29dbeac4517dabaac17577bff71785f9b37afc7f4de7fb6e15cf41a8ebd','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5c9dcbcb0c8f6cda52115db2c95f67466451fa7e357251437f77f526b1bbf4e0',2025,'ME','Montenegro','geography',2,'Location:
Southeastern Europe, between the Adriatic Sea and Serbia
Geographic coordinates:
42 30 N, 19 18 E
Map references:
Europe
Area:
total:
13,812 sq km
land:
13,452 sq km
water:
360 sq km
comparison ranking:
total 161
Area - comparative:
slightly smaller than Connecticut; slightly larger than twice the size of Delaware
Land boundaries:
total:
680 km
border countries (5):
Albania 186 km; Bosnia and Herzegovina 242 km; Croatia 19 km; Kosovo 76 km; Serbia 157 km
Coastline:
293.5 km
Maritime claims:
territorial sea:
12 nm
continental shelf:
defined by treaty
Climate:
Mediterranean climate, hot dry summers and autumns and relatively cold winters with heavy snowfalls inland
Terrain:
highly indented coastline with narrow coastal plain backed by rugged high limestone mountains and plateaus
Elevation:
highest point:
Zia Kolata 2,534 m
lowest point:
Adriatic Sea 0 m
mean elevation:
1,086 m
Natural resources:
bauxite, hydroelectricity
Land use:
agricultural land:
38.2% (2018 est.)
arable land:
12.9% (2018 est.)
permanent crops:
1.2% (2018 est.)
permanent pasture:
24.1% (2018 est.)
forest:
40.4% (2018 est.)
other:
21.4% (2018 est.)
Irrigated land:
24 sq km (2012)
Major lakes (area sq km):
fresh water lake(s):
Lake Scutari (shared with Albania) - 400 sq km
note - largest lake in the Balkans
Major watersheds (area sq km): Atlantic Ocean drainage:
(Black Sea)
Danube (795,656 sq km)
Population distribution:
highest population density is concentrated in the south, southwest; the extreme eastern border is the least populated area
Natural hazards:
destructive earthquakes
Geography - note:
strategic location along the Adriatic coast','dbd402e6ce16c411a5b931ce49dbf6921565237bfa50b4f5db8d38019ea8432e','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('436e6baae4af9850a08ef1b657ceceef84afee1352e059896b1702e9b07b0865',2025,'MS','Montserrat','geography',13,'Location:
Caribbean, island in the Caribbean Sea, southeast of Puerto Rico
Geographic coordinates:
16 45 N, 62 12 W
Map references:
Central America and the Caribbean
Area:
total:
102 sq km
land:
102 sq km
water:
0 sq km
comparison ranking:
total 225
Area - comparative:
about 0.6 times the size of Washington, DC
Land boundaries:
total:
0 km
Coastline:
40 km
Maritime claims:
territorial sea:
12 nm
exclusive fishing zone:
200 nm
Climate:
tropical; little daily or seasonal temperature variation
Terrain:
volcanic island, mostly mountainous, with small coastal lowland
Elevation:
highest point:
Soufriere Hills volcano pre-eruption height was 915 m; current lava dome is subject to periodic build up and collapse; estimated dome height was 1,050 m in 2015
lowest point:
Caribbean Sea 0 m
Natural resources:
NEGL
Land use:
agricultural land:
30% (2018 est.)
arable land:
20% (2018 est.)
permanent crops:
0% (2018 est.)
permanent pasture:
10% (2018 est.)
forest:
25% (2018 est.)
other:
45% (2018 est.)
Irrigated land:
0 sq km (2022)
Population distribution:
only the northern half of the island is populated, the southern portion is uninhabitable due to volcanic activity
Natural hazards:
volcanic eruptions; severe hurricanes (June to November)
volcanism:
Soufriere Hills volcano (915 m), has erupted continuously since 1995; a massive eruption in 1997 destroyed most of the capital, Plymouth, and resulted in approximately half of the island becoming uninhabitable; the island of Montserrat is part of the volcanic island arc of the Lesser Antilles that extends from Saba in the north to Grenada in the south
Geography - note:
the island is entirely volcanic in origin and comprised of three major volcanic centers of differing ages','daf076a28c8421518a6bd1350b663a0d2d3a10a8643718fb8393d1f7a15e205c','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('727ed94a4dc750fae800b069bf99093b197713054d524896fde25be3f4056246',2025,'MA','Morocco','geography',24,'Location:
Northern Africa, bordering the North Atlantic Ocean and the Mediterranean Sea, between Algeria and Mauritania
Geographic coordinates:
28 30 N, 10 00 W
Map references:
Africa
Area:
total:
716,550 sq km
land:
716,300 sq km
water:
250 sq km
comparison ranking:
total 41
Area - comparative:
slightly larger than twice the size of California
Land boundaries:
total:
3,523.5 km
border countries (3):
Algeria 1,941 km; Mauritania 1,564 km; Spain (Ceuta) 8 km and Spain (Melilla) 10.5 km
note:
an additional 75-meter border segment exists between Morocco and the Spanish exclave of Penon de Velez de la Gomera
Coastline:
2,945 km
Maritime claims:
territorial sea:
12 nm
contiguous zone:
24 nm
exclusive economic zone:
200 nm
continental shelf:
200-m depth or to the depth of exploitation
Climate:
Mediterranean in the north, becoming more extreme in the interior; in the south, hot, dry desert; rain is rare; cold offshore air currents produce fog and heavy dew
note:
data does not include former Western Sahara
Terrain:
mountainous northern coast (Rif Mountains) and interior (Atlas Mountains) bordered by large plateaus with intermontane valleys, and fertile coastal plains; the south is mostly low, flat desert with large areas of rocky or sandy surfaces
Elevation:
highest point:
Jebel Toubkal 4,165 m
lowest point:
Sebkha Tah -59 m
mean elevation:
909 m
Natural resources:
phosphates, iron ore, manganese, lead, zinc, fish, salt
Land use:
agricultural land:
67.5% (2018 est.)
arable land:
17.5% (2018 est.)
permanent crops:
2.9% (2018 est.)
permanent pasture:
47.1% (2018 est.)
forest:
11.5% (2018 est.)
other:
21% (2018 est.)
note:
does not include the area of the former Western Sahara, which is almost exclusively desert
Irrigated land:
17,645 sq km (2019)
Major rivers (by length in km):
Draa - 1,100 km
Population distribution:
the highest population density is found along the Atlantic and Mediterranean coasts; a number of densely populated agglomerations are found scattered through the Atlas Mountains as shown in this population distribution map
Natural hazards:
in the north, the mountains are geologically unstable and subject to earthquakes; periodic droughts; windstorms; flash floods; landslides; in the south, a hot, dry, dust/sand-laden sirocco wind can occur during winter and spring; widespread harmattan haze exists 60% of time, often severely restricting visibility
Geography - note:
strategic location along Strait of Gibraltar; the only African nation to have both Atlantic and Mediterranean coastlines; the waters off the Atlantic coast are particularly rich fishing areas','2e4fe9376a8329e36d988cc11b3176b53d1b69d82d340a89afd9ebd7cd4d11fc','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('35eec75a3b4393b56fa7f552a70d602c3fe3838ed53b02e66416dbcc7f445dd4',2025,'MZ','Mozambique','geography',37,'Location:
Southeastern Africa, bordering the Mozambique Channel, between South Africa and Tanzania
Geographic coordinates:
18 15 S, 35 00 E
Map references:
Africa
Area:
total:
799,380 sq km
land:
786,380 sq km
water:
13,000 sq km
comparison ranking:
total 36
Area - comparative:
slightly more than five times the size of Georgia; slightly less than twice the size of California
Land boundaries:
total:
4,783 km
border countries (6):
Malawi 1498 km; South Africa 496 km; Eswatini 108 km; Tanzania 840 km; Zambia 439 km; Zimbabwe 1,402 km
Coastline:
2,470 km
Maritime claims:
territorial sea:
12 nm
exclusive economic zone:
200 nm
Climate:
tropical to subtropical
Terrain:
mostly coastal lowlands, uplands in center, high plateaus in northwest, mountains in west
Elevation:
highest point:
Monte Binga 2,436 m
lowest point:
Indian Ocean 0 m
mean elevation:
345 m
Natural resources:
coal, titanium, natural gas, hydropower, tantalum, graphite
Land use:
agricultural land:
56.3% (2018 est.)
arable land:
6.4% (2018 est.)
permanent crops:
0.3% (2018 est.)
permanent pasture:
49.6% (2018 est.)
forest:
43.7% (2018 est.)
other:
0% (2018 est.)
Irrigated land:
1,180 sq km (2012)
Major lakes (area sq km):
fresh water lake(s):
Lake Malawi (shared with Malawi and Tanzania) - 22,490
Major rivers (by length in km):
Rio Zambeze (Zambezi) river mouth (shared with Zambia [s]), Angola, Namibia, Botswana, and Zimbabwe) - 2,740 km; Rio Limpopo river mouth (shared with South Africa [s], Botswana, and Zimbabwe) - 1,800 km
note – [s] after country name indicates river source; [m] after country name indicates river mouth
Major watersheds (area sq km): Indian Ocean drainage:
Zambezi (1,332,412 sq km)
Population distribution:
three large populations clusters are found along the southern coast between Maputo and Inhambane, in the central area between Beira and Chimoio along the Zambezi River, and in and around the northern cities of Nampula, Cidade de Nacala, and Pemba; the northwest and southwest are the least populated areas as shown in this population distribution map
Natural hazards:
severe droughts; devastating cyclones and floods in central and southern provinces
Geography - note:
the Zambezi River flows through the north-central and most fertile part of the country','95bd44a6def4883ec404ff97a82b2a43d84215559a3e295d82688389595ecbb0','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('506d09eaffda20b87b1fddb6113517da5f2f14090949abbf9149fda88430934d',2025,'NA','Namibia','geography',2,'Location:
Southern Africa, bordering the South Atlantic Ocean, between Angola and South Africa
Geographic coordinates:
22 00 S, 17 00 E
Map references:
Africa
Area:
total:
824,292 sq km
land:
823,290 sq km
water:
1,002 sq km
comparison ranking:
total 35
Area - comparative:
almost seven times the size of Pennsylvania; slightly more than half the size of Alaska
Land boundaries:
total:
4,220 km
border countries (4):
Angola 1,427 km; Botswana 1,544 km; South Africa 1,005 km; Zambia 244 km
Coastline:
1,572 km
Maritime claims:
territorial sea:
12 nm
contiguous zone:
24 nm
exclusive economic zone:
200 nm
Climate:
desert; hot, dry; rainfall sparse and erratic
Terrain:
mostly high plateau; Namib Desert along coast; Kalahari Desert in east
Elevation:
highest point:
Konigstein on Brandberg 2,573 m
lowest point:
Atlantic Ocean 0 m
mean elevation:
1,141 m
Natural resources:
diamonds, copper, uranium, gold, silver, lead, tin, lithium, cadmium, tungsten, zinc, salt, hydropower, fish; note - suspected deposits of oil, coal, and iron ore
Land use:
agricultural land:
47.2% (2018 est.)
arable land:
1% (2018 est.)
permanent crops:
0% (2018 est.)
permanent pasture:
46.2% (2018 est.)
forest:
8.8% (2018 est.)
other:
44% (2018 est.)
Irrigated land:
80 sq km (2012)
Major rivers (by length in km):
Zambezi (shared with Zambia [s]), Angola, Botswana, Zimbabwe, and Mozambique [m]) - 2,740 km; Orange river mouth (shared with Lesotho [s], and South Africa) - 2,092 km; Okavango (shared with Angola [s], and Botswana [m]) - 1,600 km
note –
[s] after country name indicates river source; [m] after country name indicates river mouth
Major watersheds (area sq km): Atlantic Ocean drainage:
Orange (941,351 sq km)
Indian Ocean drainage:
Zambezi (1,332,412 sq km)
Internal
(endorheic basin)
drainage:
Okavango Basin (863,866 sq km)
Major aquifers:
Lower Kalahari-Stampriet Basin, Upper Kalahari-Cuvelai-Upper Zambezi Basin
Population distribution:
population density is very low, with the largest clustering found in the extreme north-central area along the border with Angola as shown in this population distribution map
Natural hazards:
prolonged periods of drought
Geography - note:
the Namib Desert, after which the country is named, is considered to be the oldest desert in the world; Namibia is the first country in the world to incorporate the protection of the environment into its constitution; some 14% of the land is protected, including virtually the entire Namib Desert coastal strip; Namib-Naukluft National Park (49,768 sq km), is the largest game park in Africa and one of the largest in the world','d89def351bc6efea74dd2eaaddac88a240a31e6a8dd3fd40db2b69e107a8c94e','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6eb42be3b11230b503832bb46bbad7165cceb453e570b97f770b6f4cf0ce7e85',2025,'NR','Nauru','geography',13,'Location:
Oceania, island in the South Pacific Ocean, south of the Marshall Islands
Geographic coordinates:
0 32 S, 166 55 E
Map references:
Oceania
Area:
total:
21 sq km
land:
21 sq km
water:
0 sq km
comparison ranking:
total 239
Area - comparative:
about 0.1 times the size of Washington, DC
Land boundaries:
total:
0 km
Coastline:
30 km
Maritime claims:
territorial sea:
12 nm
contiguous zone:
24 nm
exclusive economic zone:
200 nm
Climate:
tropical with a monsoonal pattern; rainy season (November to February)
Terrain:
sandy beach rises to fertile ring around raised coral reefs with phosphate plateau in center
Elevation:
highest point:
Command Ridge 70 m
lowest point:
Pacific Ocean 0 m
Natural resources:
phosphates, fish
Land use:
agricultural land:
20% (2018 est.)
arable land:
0% (2018 est.)
permanent crops:
20% (2018 est.)
permanent pasture:
0% (2018 est.)
forest:
0% (2018 est.)
other:
80% (2018 est.)
Irrigated land:
0 sq km (2022)
Population distribution:
extensive phosphate mining made approximately 90% of the island unsuitable for farming; most people live in the fertile coastal areas, especially along the southwest coast
Natural hazards:
periodic droughts
Geography - note:
Nauru is the third-smallest country in the world behind the Holy See (Vatican City) and Monaco; it is the smallest country in the Pacific Ocean, the smallest country outside Europe, the world’s smallest island country, and the the world’s smallest independent republic; situated just 53 km south of the Equator, Nauru is one of the three great phosphate rock islands in the Pacific Ocean - the others are Banaba (Ocean Island) in Kiribati and Makatea in French Polynesia','56946001acfe321de1368dc52faea239dfffd0c8658a28d42709c89124e818b5','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('447c7ab516bb9eea7d14b89e3e053f225a86ffb89ae6c49c81d900ce5f9a4edd',2025,'NR','Nauru','geography',24,'Location:
Caribbean, island in the Caribbean Sea, 30 nm west of Tiburon Peninsula of Haiti
Geographic coordinates:
18 25 N, 75 02 W
Map references:
Central America and the Caribbean
Area:
total:
5 sq km
land:
5.4 sq km
water:
0 sq km
comparison ranking:
total 249
Area - comparative:
about nine times the size of the National Mall in Washington, DC
Land boundaries:
total:
0 km
Coastline:
8 km
Maritime claims:
territorial sea:
12 nm
exclusive economic zone:
200 nm
Climate:
marine, tropical
Terrain:
raised flat to undulating coral and limestone plateau; ringed by vertical white cliffs (9 to 15 m high)
Elevation:
highest point:
200 m NNW of lighthouse 85 m
lowest point:
Caribbean Sea 0 m
Natural resources:
guano (mining discontinued in 1898)
Land use:
other:
100% (2018 est.)
Natural hazards:
hurricanes
Geography - note:
strategic location 160 km south of the US Naval Base at Guantanamo Bay, Cuba; mostly exposed rock with numerous solution holes (limestone sinkholes) but with enough grassland to support goat herds; dense stands of fig trees, scattered cactus','e678fbc39329e1b5d49915f4944e89c49e2a77dc60f736df1222c398a07473b2','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('17ee42674f5d9d24fb4f3f83436971eb2079b3b59e7542e6ccebd2159a9aa895',2025,'NP','Nepal','geography',32,'Location:
Southern Asia, between China and India
Geographic coordinates:
28 00 N, 84 00 E
Map references:
Asia
Area:
total:
147,181 sq km
land:
143,351 sq km
water:
3,830 sq km
comparison ranking:
total 95
Area - comparative:
slightly larger than New York state
Land boundaries:
total:
3,159 km
border countries (2):
China 1,389 km; India 1,770 km
Coastline:
0 km (landlocked)
Maritime claims:
none (landlocked)
Climate:
varies from cool summers and severe winters in north to subtropical summers and mild winters in south
Terrain:
Tarai or flat river plain of the Ganges in south; central hill region with rugged Himalayas in north
Elevation:
highest point:
Mount Everest (highest peak in Asia and highest point on earth above sea level) 8,849 m
lowest point:
Kanchan Kalan 70 m
mean elevation:
2,565 m
Natural resources:
quartz, water, timber, hydropower, scenic beauty, small deposits of lignite, copper, cobalt, iron ore
Land use:
agricultural land:
28.8% (2018 est.)
arable land:
15.1% (2018 est.)
permanent crops:
1.2% (2018 est.)
permanent pasture:
12.5% (2018 est.)
forest:
25.4% (2018 est.)
other:
45.8% (2018 est.)
Irrigated land:
13,320 sq km (2012)
Major watersheds (area sq km): Indian Ocean drainage:
Brahmaputra (651,335 sq km), Ganges (1,016,124 sq km), Indus (1,081,718 sq km)
Major aquifers:
Indus-Ganges-Brahmaputra Basin
Population distribution:
most of the population is divided nearly equally between a concentration in the southern-most plains of the Tarai region and the central hilly region; overall density is quite low
Natural hazards:
severe thunderstorms; flooding; landslides; drought and famine depending on the timing, intensity, and duration of the summer monsoons
Geography - note:
landlocked; strategic location between China and India; contains eight of world’s 10 highest peaks, including Mount Everest and Kanchenjunga - the world’s tallest and third tallest mountains - on the borders with China and India respectively','ae94c6b9b57017341a823c856919330482400c4d3cf29e89e50ade00a76a6cb8','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4f7dd17c32a3ab0fc510451950261f5c226cbb4e10f81b3e0a94dbb98d03a195',2025,'NL','Netherlands','geography',44,'Location:
Western Europe, bordering the North Sea, between Belgium and Germany
Geographic coordinates:
52 31 N, 5 46 E
Map references:
Europe
Area:
total:
41,543 sq km
land:
33,893 sq km
water:
7,650 sq km
comparison ranking:
total 134
Area - comparative:
slightly less than twice the size of New Jersey
Land boundaries:
total:
1,053 km
border countries (2):
Belgium 478 km; Germany 575 km
Coastline:
451 km
Maritime claims:
territorial sea:
12 nm
contiguous zone:
24 nm
exclusive fishing zone:
200 nm
Climate:
temperate; marine; cool summers and mild winters
Terrain:
mostly coastal lowland and reclaimed land (polders); some hills in southeast
Elevation:
highest point:
Mount Scenery (on the island of Saba in the Caribbean, now considered an integral part of the Netherlands following the dissolution of the Netherlands Antilles) 862 m
lowest point:
Zuidplaspolder -7 m
mean elevation:
30 m
note:
the highest point on continental Netherlands is Vaalserberg at 322 m
Natural resources:
natural gas, petroleum, peat, limestone, salt, sand and gravel, arable land
Land use:
agricultural land:
55.1% (2018 est.)
arable land:
29.8% (2018 est.)
permanent crops:
1.1% (2018 est.)
permanent pasture:
24.2% (2018 est.)
forest:
10.8% (2018 est.)
other:
34.1% (2018 est.)
Irrigated land:
2,969 sq km (2019)
Major rivers (by length in km):
Rijn (Rhine) river mouth (shared with Switzerland [s], Germany, and France) - 1,233 km
note –
[s] after country name indicates river source; [m] after country name indicates river mouth
Major watersheds (area sq km): Atlantic Ocean drainage:
Rhine-Maas (198,735 sq km)
Population distribution:
an area known as the Randstad, anchored by the cities of Amsterdam, Rotterdam, the Hague, and Utrecht, is the most densely populated region; the north tends to be less dense, though sizeable communities can be found throughout the entire country
Natural hazards:
flooding
volcanism:
Mount Scenery (887 m), located on the island of Saba in the Caribbean, last erupted in 1640; Round Hill (601 m), a dormant volcano also known as The Quill, is located on the island of St. Eustatius in the Caribbean; these islands are at the northern end of the volcanic island arc of the Lesser Antilles that extends south to Grenada
Geography - note:
located at mouths of three major European rivers (Rhine (Rijn), Meuse (Maas), and Scheldt (Schelde)); about a quarter of the country lies below sea level and only about half of the land exceeds one meter above sea level','f9b514b8240fe369d74f684885ff6d375dfc384e049bdd971399c34ad962c01e','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('15cda9eae5c7240fe3105beb740a7ac83c48798b51e7470c157e06b79fb424a7',2025,'NC','New Caledonia','geography',57,'Location:
Oceania, islands in the South Pacific Ocean, east of Australia
Geographic coordinates:
21 30 S, 165 30 E
Map references:
Oceania
Area:
total:
18,575 sq km
land:
18,275 sq km
water:
300 sq km
comparison ranking:
total 155
Area - comparative:
slightly smaller than New Jersey
Land boundaries:
total:
0 km
Coastline:
2,254 km
Maritime claims:
territorial sea:
12 nm
exclusive economic zone:
200 nm
Climate:
tropical; modified by southeast trade winds; hot, humid
Terrain:
coastal plains with interior mountains
Elevation:
highest point:
Mont Panie 1,628 m
lowest point:
Pacific Ocean 0 m
Natural resources:
nickel, chrome, iron, cobalt, manganese, silver, gold, lead, copper
Land use:
agricultural land:
10.4% (2018 est.)
arable land:
0.4% (2018 est.)
permanent crops:
0.2% (2018 est.)
permanent pasture:
9.8% (2018 est.)
forest:
45.9% (2018 est.)
other:
43.7% (2018 est.)
Irrigated land:
100 sq km (2012)
Population distribution:
most of the populace lives in the southern part of the main island, in and around the capital of Noumea
Natural hazards:
cyclones, most frequent from November to March
volcanism:
Matthew and Hunter Islands are historically active
Geography - note:
consists of the main island of New Caledonia (one of the largest in the Pacific Ocean), the archipelago of Iles Loyaute, and numerous small, sparsely populated islands and atolls','e88141487184a0d2cb595bb599f901c1565f6f8ab23e38e9ff9f4f7ebfed944f','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('abbd6b381b947d61419f56d6df9894932b604962c474eb2d55fc4f9bddc23657',2025,'NZ','New Zealand','geography',2,'Location:
Oceania, islands in the South Pacific Ocean, southeast of Australia
Geographic coordinates:
41 00 S, 174 00 E
Map references:
Oceania
Area:
total:
268,838 sq km
land:
264,537 sq km
water:
4,301 sq km
note:
includes Antipodes Islands, Auckland Islands, Bounty Islands, Campbell Island, Chatham Islands, and Kermadec Islands
comparison ranking:
total 77
Area - comparative:
almost twice the size of North Carolina; about the size of Colorado
Land boundaries:
total:
0 km
Coastline:
15,134 km
Maritime claims:
territorial sea:
12 nm
contiguous zone:
24 nm
exclusive economic zone:
200 nm
continental shelf:
200 nm or to the edge of the continental margin
Climate:
temperate with sharp regional contrasts
Terrain:
predominately mountainous with large coastal plains
Elevation:
highest point:
Aoraki/Mount Cook 3,724 m; note - the mountain’s height was 3,764 m until 14 December 1991 when it lost about 10 m in an avalanche of rock and ice; erosion of the ice cap since then has brought the height down another 30 m
lowest point:
Pacific Ocean 0 m
mean elevation:
388 m
Natural resources:
natural gas, iron ore, sand, coal, timber, hydropower, gold, limestone
Land use:
agricultural land:
43.2% (2018 est.)
arable land:
1.8% (2018 est.)
permanent crops:
0.3% (2018 est.)
permanent pasture:
41.1% (2018 est.)
forest:
31.4% (2018 est.)
other:
25.4% (2018 est.)
Irrigated land:
7,000 sq km (2014)
Major lakes (area sq km):
fresh water lake(s):
Lake Taupo - 610 sq km
Population distribution:
over three-quarters of New Zealanders, including the indigenous Maori, live on the North Island, primarily in urban areas
Natural hazards:
earthquakes are common, though usually not severe; volcanic activity
volcanism:
significant volcanism on North Island; Ruapehu (2,797 m), which last erupted in 2007, has a history of large eruptions in the past century; Taranaki has the potential to produce dangerous avalanches and lahars; other historically active volcanoes include Okataina, Raoul Island, Tongariro, and White Island; see note 2 under “Geography - note”
Geography - note:
note 1:
consists of two main islands and a number of smaller islands; South Island, the larger main island, is the 12th largest island in the world and is divided along its length by the Southern Alps; North Island is the 14th largest island in the world and is not as mountainous, but it is marked by volcanism
note 2:
New Zealand lies along the Ring of Fire, a belt of active volcanoes and earthquake epicenters bordering the Pacific Ocean; up to 90% of the world’s earthquakes and some 75% of the world’s volcanoes occur within the Ring of Fire
note 3:
almost 90% of the population lives in cities and over three-quarters on North Island; Wellington is the southernmost national capital in the world','d28933449ae24e17d2edd4fd224710576a06f57c432552da1ae7c3d42f8546bf','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c12e715cec627d97adeb82059349f10d480434fb4b7678a792b3eb424f205cd8',2025,'NI','Nicaragua','geography',15,'Location:
Central America, bordering both the Caribbean Sea and the North Pacific Ocean, between Costa Rica and Honduras
Geographic coordinates:
13 00 N, 85 00 W
Map references:
Central America and the Caribbean
Area:
total:
130,370 sq km
land:
119,990 sq km
water:
10,380 sq km
comparison ranking:
total 98
Area - comparative:
slightly larger than Pennsylvania; slightly smaller than New York state
Land boundaries:
total:
1,253 km
border countries (2):
Costa Rica 313 km; Honduras 940 km
Coastline:
910 km
Maritime claims:
territorial sea:
12 nm
contiguous zone:
24 nm
continental shelf:
natural prolongation
Climate:
tropical in lowlands, cooler in highlands
Terrain:
extensive Atlantic coastal plains rising to central interior mountains; narrow Pacific coastal plain interrupted by volcanoes
Elevation:
highest point:
Mogoton 2,085 m
lowest point:
Pacific Ocean 0 m
mean elevation:
298 m
Natural resources:
gold, silver, copper, tungsten, lead, zinc, timber, fish
Land use:
agricultural land:
42.2% (2018 est.)
arable land:
12.5% (2018 est.)
permanent crops:
2.5% (2018 est.)
permanent pasture:
27.2% (2018 est.)
forest:
25.3% (2018 est.)
other:
32.5% (2018 est.)
Irrigated land:
1,990 sq km (2012)
Major lakes (area sq km):
fresh water lake(s):
Lago de Nicaragua - 8,150 sq km; Lago de Managua - 1,040 sq km
Population distribution:
the overwhelming majority of the population resides in the western half of the country, with much of the urban growth centered in the capital city of Managua; coastal areas also show large population clusters
Natural hazards:
destructive earthquakes; volcanoes; landslides; extremely susceptible to hurricanes
volcanism:
significant volcanic activity; Cerro Negro (728 m), which last erupted in 1999, is one of Nicaragua’s most active volcanoes; its lava flows and ash have been known to cause significant damage to farmland and buildings; other historically active volcanoes include Concepcion, Cosiguina, Las Pilas, Masaya, Momotombo, San Cristobal, and Telica
Geography - note:
largest country in Central America; contains the largest freshwater body in Central America, Lago de Nicaragua','7db1bab490367e15efd89cfa8cec73a96e828f574a27cdb9e040201c95967ece','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cc8e8eb9a69cda7c716310293715e8246a539be93e4e5b324b7ca1fd5fccfcc9',2025,'NE','Niger','geography',27,'Location:
Western Africa, southeast of Algeria
Geographic coordinates:
16 00 N, 8 00 E
Map references:
Africa
Area:
total:
1.267 million sq km
land:
1,266,700 sq km
water:
300 sq km
comparison ranking:
total 23
Area - comparative:
slightly less than twice the size of Texas
Land boundaries:
total:
5,834 km
border countries (7):
Algeria 951 km; Benin 277 km; Burkina Faso 622 km; Chad 1,196 km; Libya 342 km; Mali 838 km;
Nigeria 1,608 km
Coastline:
0 km (landlocked)
Maritime claims:
none (landlocked)
Climate:
desert; mostly hot, dry, dusty; tropical in extreme south
Terrain:
predominately desert plains and sand dunes; flat to rolling plains in south; hills in north
Elevation:
highest point:
Idoukal-n-Taghes 2,022 m
lowest point:
Niger River 200 m
mean elevation:
474 m
Natural resources:
uranium, coal, iron ore, tin, phosphates, gold, molybdenum, gypsum, salt, petroleum
Land use:
agricultural land:
35.1% (2018 est.)
arable land:
12.3% (2018 est.)
permanent crops:
0.1% (2018 est.)
permanent pasture:
22.7% (2018 est.)
forest:
1% (2018 est.)
other:
63.9% (2018 est.)
Irrigated land:
2,666 sq km (2020)
Major lakes (area sq km):
fresh water lake(s):
Lake Chad (endorheic lake shared with Chad, Nigeria, and Cameroon) - 10,360-25,900 sq km
note - area varies by season and year to year
Major rivers (by length in km):
Niger (shared with Guinea [s], Mali, Benin, and Nigeria [m]) - 4,200 km
note –
[s] after country name indicates river source; [m] after country name indicates river mouth
Major watersheds (area sq km): Atlantic Ocean drainage:
Niger (2,261,741 sq km)
Internal
(endorheic basin)
drainage:
Lake Chad (2,497,738 sq km)
Major aquifers:
Lake Chad Basin, Lullemeden-Irhazer Basin, Murzuk-Djado Basin
Population distribution:
majority of the populace is located in the southernmost extreme of the country along the border with Nigeria and Benin as shown in this population distribution map
Natural hazards:
recurring droughts
Geography - note:
landlocked; one of the hottest countries in the world; northern four-fifths is desert, southern one-fifth is savanna, suitable for livestock and limited agriculture','80f4c637b58e5c212e85c2e2bee6506cf3caad6fe6045f1f97d0c8b8cfc35b68','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5aa441928bc5efea27187243136e5251642f86a68a58bb5781c971c963c0cf23',2025,'NG','Nigeria','geography',39,'Location:
Western Africa, bordering the Gulf of Guinea, between Benin and Cameroon
Geographic coordinates:
10 00 N, 8 00 E
Map references:
Africa
Area:
total:
923,768 sq km
land:
910,768 sq km
water:
13,000 sq km
comparison ranking:
total 33
Area - comparative:
about six times the size of Georgia; slightly more than twice the size of California
Land boundaries:
total:
4,477 km
border countries (4):
Benin 809 km; Cameroon 1,975 km; Chad 85 km; Niger 1,608 km
Coastline:
853 km
Maritime claims:
territorial sea:
12 nm
exclusive economic zone:
200 nm
continental shelf:
200-m depth or to the depth of exploitation
Climate:
varies; equatorial in south, tropical in center, arid in north
Terrain:
southern lowlands merge into central hills and plateaus; mountains in southeast, plains in north
Elevation:
highest point:
Chappal Waddi 2,419 m
lowest point:
Atlantic Ocean 0 m
mean elevation:
380 m
Natural resources:
natural gas, petroleum, tin, iron ore, coal, limestone, niobium, lead, zinc, arable land
Land use:
agricultural land:
78% (2018 est.)
arable land:
37.3% (2018 est.)
permanent crops:
7.4% (2018 est.)
permanent pasture:
33.3% (2018 est.)
forest:
9.5% (2018 est.)
other:
12.5% (2018 est.)
Irrigated land:
2,930 sq km (2012)
Major lakes (area sq km):
fresh water lake(s):
Lake Chad (endorheic lake shared with Niger, Chad, and Cameroon) - 10,360-25,900 sq km note - area varies by season and year to year
Major rivers (by length in km):
Niger river mouth (shared with Guinea [s], Mali, Benin, and Niger) - 4,200 km
note –
[s] after country name indicates river source; [m] after country name indicates river mouth
Major watersheds (area sq km): Atlantic Ocean drainage:
Niger (2,261,741 sq km)
Internal
(endorheic basin)
drainage:
Lake Chad (2,497,738 sq km)
Major aquifers:
Lake Chad Basin, Lullemeden-Irhazer Aquifer System
Population distribution:
largest population of any African nation; significant population clusters are scattered throughout the country, with the highest density areas being in the south and southwest as shown in this population distribution map
Natural hazards:
periodic droughts; flooding
Geography - note:
the Niger River enters the country in the northwest and flows southward through tropical rain forests and swamps to its delta in the Gulf of Guinea','76deed48372e9caf2b0855aa40be22a33c47daa831c8e433590a50c5a4f97916','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4e8ccf94c4a23faaae865386648fe33344bc529f5867500688f0538566030a1d',2025,'NU','Niue','geography',2,'Location:
Oceania, island in the South Pacific Ocean, east of Tonga
Geographic coordinates:
19 02 S, 169 52 W
Map references:
Oceania
Area:
total:
260 sq km
land:
260 sq km
water:
0 sq km
comparison ranking:
total 212
Area - comparative:
1.5 times the size of Washington, DC
Land boundaries:
total:
0 km
Coastline:
64 km
Maritime claims:
territorial sea:
12 nm
exclusive economic zone:
200 nm
Climate:
tropical; modified by southeast trade winds
Terrain:
steep limestone cliffs along coast, central plateau
Elevation:
highest point:
unnamed elevation 1.4 km east of Hikutavake 80 m
lowest point:
Pacific Ocean 0 m
Natural resources:
arable land, fish
Land use:
agricultural land:
19.1% (2018 est.)
arable land:
3.8% (2018 est.)
permanent crops:
11.5% (2018 est.)
permanent pasture:
3.8% (2018 est.)
forest:
71.2% (2018 est.)
other:
9.7% (2018 est.)
Irrigated land:
0 sq km (2022)
Population distribution:
population distributed around the peripheral coastal areas of the island
Natural hazards:
tropical cyclones
Geography - note:
one of world’s largest coral islands; the only major break in the surrounding coral reef occurs in the central western part of the coast','8cd87e7cdfd86e9939603fcdc395bfe7a0388deb7da3dad25ca4b87aa07b42b1','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('90c26455bad31b9aaa8fbdd3e74ac9803999d2efd5f1c0db5ed5da0122b6dab6',2025,'NF','Norfolk Island','geography',13,'Location:
Oceania, island in the South Pacific Ocean, east of Australia
Geographic coordinates:
29 02 S, 167 57 E
Map references:
Oceania
Area:
total:
36 sq km
land:
36 sq km
water:
0 sq km
comparison ranking:
total 234
Area - comparative:
about 0.2 times the size of Washington, DC
Land boundaries:
total:
0 km
Coastline:
32 km
Maritime claims:
territorial sea:
12 nm
contiguous zone:
24 nm
exclusive fishing zone:
200 nm
Climate:
subtropical; mild, little seasonal temperature variation
Terrain:
volcanic island with mostly rolling plains
Elevation:
highest point:
Mount Bates 319 m
lowest point:
Pacific Ocean 0 m
Natural resources:
fish
Land use:
agricultural land:
25% (2018 est.)
arable land:
0% (2018 est.)
permanent crops:
0% (2018 est.)
permanent pasture:
25% (2018 est.)
forest:
11.5% (2018 est.)
other:
63.5% (2018 est.)
Irrigated land:
0 sq km (2022)
Population distribution:
population concentrated around the capital of Kingston
Natural hazards:
tropical cyclones (especially May to July)
Geography - note:
most of the 32 km coastline consists of almost inaccessible cliffs, but the land slopes down to the sea in one small southern area on Sydney Bay, where the capital of Kingston is situated','6ab093ad0a8f8706c8439cb54805448517bce563b24b537bac3201ca622ed561','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('787920139ed315ff16cee3f57a7652dd328a551c80153e2f327de9dbd0b6c2bf',2025,'MK','North Macedonia','geography',23,'Location:
Southeastern Europe, north of Greece
Geographic coordinates:
41 50 N, 22 00 E
Map references:
Europe
Area:
total:
25,713 sq km
land:
25,433 sq km
water:
280 sq km
comparison ranking:
total 149
Area - comparative:
slightly larger than Vermont; almost four times the size of Delaware
Land boundaries:
total:
838 km
border countries (5):
Albania 181 km; Bulgaria 162 km; Greece 234 km; Kosovo 160 km; Serbia 101 km
Coastline:
0 km (landlocked)
Maritime claims:
none (landlocked)
Climate:
warm, dry summers and autumns; relatively cold winters with heavy snowfall
Terrain:
mountainous with deep basins and valleys; three large lakes, each divided by a frontier line; country bisected by the Vardar River
Elevation:
highest point:
Golem Korab (Maja e Korabit) 2,764 m
lowest point:
Vardar River 50 m
mean elevation:
741 m
Natural resources:
low-grade iron ore, copper, lead, zinc, chromite, manganese, nickel, tungsten, gold, silver, asbestos, gypsum, timber, arable land
Land use:
agricultural land:
44.3% (2018 est.)
arable land:
16.4% (2018 est.)
permanent crops:
1.4% (2018 est.)
permanent pasture:
26.5% (2018 est.)
forest:
39.8% (2018 est.)
other:
15.9% (2018 est.)
Irrigated land:
844 sq km (2016)
Major watersheds (area sq km): Atlantic Ocean drainage:
(Black Sea)
Danube (795,656 sq km)
Population distribution:
a fairly even distribution throughout most of the country, with urban areas attracting larger and denser populations
Natural hazards:
high seismic risks
Geography - note:
landlocked; major transportation corridor from Western and Central Europe to Aegean Sea and Southern Europe to Western Europe','7c43b954303f83fcdf6ee4fa5371cc6e2f5f678b7dd49ecd73a180c47b6ca870','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3f57e77be09dd52585a68a41bab88afb0f88ae0bbdb53d663d85b9e1b6af69ca',2025,'MP','Northern Mariana Islands','geography',35,'Location:
Oceania, islands in the North Pacific Ocean, about three-quarters of the way from Hawaii to the Philippines
Geographic coordinates:
15 12 N, 145 45 E
Map references:
Oceania
Area:
total:
464 sq km
land:
464 sq km
water:
0 sq km
note:
consists of 14 islands including Saipan, Rota, and Tinian
comparison ranking:
total 196
Area - comparative:
2.5 times the size of Washington, DC
Land boundaries:
total:
0 km
Coastline:
1,482 km
Maritime claims:
territorial sea:
12 nm
exclusive economic zone:
200 nm
Climate:
tropical marine; moderated by northeast trade winds, little seasonal temperature variation; dry season December to June, rainy season July to October
Terrain:
the southern islands in this north-south trending archipelago are limestone, with fringing coral reefs; the northern islands are volcanic, with active volcanoes on several islands
Elevation:
highest point:
Agrihan Volcano 965 m
lowest point:
Pacific Ocean 0 m
Natural resources:
arable land, fish
Land use:
agricultural land:
6.6% (2018 est.)
arable land:
2.2% (2018 est.)
permanent crops:
2.2% (2018 est.)
permanent pasture:
2.2% (2018 est.)
forest:
65.5% (2018 est.)
other:
27.9% (2018 est.)
Irrigated land:
1 sq km (2012)
Population distribution:
approximately 90% of the population lives on the island of Saipan
Natural hazards:
active volcanoes on Pagan and Agrihan; typhoons (especially August to November)
Geography - note:
strategic location in the North Pacific Ocean','c229b56e32dc5b93c03e3042d7a7613da5e5b443a6bab10c40c5638151aff4f7','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e0de6e5965c008204f15d8add8f6d77bc75693414d88ab6812945ffd2018a129',2025,'NO','Norway','geography',46,'Location:
Northern Europe, bordering the North Sea and the North Atlantic Ocean, west of Sweden
Geographic coordinates:
62 00 N, 10 00 E
Map references:
Europe
Area:
total:
323,802 sq km
land:
304,282 sq km
water:
19,520 sq km
comparison ranking:
total 69
Area - comparative:
slightly larger than twice the size of Georgia; slightly larger than New Mexico
Land boundaries:
total:
2,566 km
border countries (3):
Finland 709 km; Sweden 1,666 km; Russia 191 km
Coastline:
25,148 km (includes mainland 2,650 km, as well as long fjords, numerous small islands, and minor indentations 22,498 km; length of island coastlines 58,133 km)
Maritime claims:
territorial sea:
12 nm
contiguous zone:
10 nm
exclusive economic zone:
200 nm
continental shelf:
200 nm
Climate:
temperate along coast, modified by North Atlantic Current; colder interior with increased precipitation and colder summers; rainy year-round on west coast
Terrain:
glaciated; mostly high plateaus and rugged mountains broken by fertile valleys; small, scattered plains; coastline deeply indented by fjords; arctic tundra in north
Elevation:
highest point:
Galdhopiggen 2,469 m
lowest point:
Norwegian Sea 0 m
mean elevation:
460 m
Natural resources:
petroleum, natural gas, iron ore, copper, lead, zinc, titanium, pyrites, nickel, fish, timber, hydropower
Land use:
agricultural land:
2.7% (2018 est.)
arable land:
2.2% (2018 est.)
permanent crops:
0% (2018 est.)
permanent pasture:
0.5% (2018 est.)
forest:
27.8% (2018 est.)
other:
69.5% (2018 est.)
Irrigated land:
337 sq km (2016)
Population distribution:
most Norwegians live in the south where the climate is milder and there is better connectivity to mainland Europe; population clusters are found all along the North Sea coast in the southwest, and Skaggerak in the southeast; the interior areas of the north remain sparsely populated
Natural hazards:
rockslides, avalanches
volcanism:
Beerenberg (2,227 m) on Jan Mayen Island in the Norwegian Sea is the country’s only active volcano
Geography - note:
about two-thirds mountains; some 50,000 islands off its much-indented coastline; strategic location adjacent to sea lanes and air routes in North Atlantic; one of the most rugged and longest coastlines in the world','792db5d9afd9ae1d180c2218f1f10018dd9838a3a43d7c476ce389563f32fa9f','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('352c1245adef5fbce7fbb1f5091631cdba36b5986ecb24c1cd7b7e60d3802de6',2025,'OM','Oman','geography',2,'Location:
Middle East, bordering the Arabian Sea, Gulf of Oman, and Persian Gulf, between Yemen and the UAE
Geographic coordinates:
21 00 N, 57 00 E
Map references:
Middle East
Area:
total:
309,500 sq km
land:
309,500 sq km
water:
0 sq km
comparison ranking:
total 72
Area - comparative:
twice the size of Georgia
Land boundaries:
total:
1,561 km
border countries (3):
Saudi Arabia 658 km; UAE 609 km; Yemen 294 km
Coastline:
2,092 km
Maritime claims:
territorial sea:
12 nm
contiguous zone:
24 nm
exclusive economic zone:
200 nm
Climate:
dry desert; hot, humid along coast; hot, dry interior; strong southwest summer monsoon (May to September) in far south
Terrain:
central desert plain, rugged mountains in north and south
Elevation:
highest point:
Jabal Shams 3,004 m
lowest point:
Arabian Sea 0 m
mean elevation:
310 m
Natural resources:
petroleum, copper, asbestos, some marble, limestone, chromium, gypsum, natural gas
Land use:
agricultural land:
4.7% (2018 est.)
arable land:
0.1% (2018 est.)
permanent crops:
0.1% (2018 est.)
permanent pasture:
4.5% (2018 est.)
forest:
0% (2018 est.)
other:
95.3% (2018 est.)
Irrigated land:
1,079 sq km (2020)
Major aquifers:
Arabian Aquifer System
Population distribution:
the vast majority of the population is located in and around the Al Hagar Mountains in the north of the country; another smaller cluster is found around the city of Salalah in the far south; most of the country remains sparsely poplulated
Natural hazards:
summer winds often raise large sandstorms and dust storms in interior; periodic droughts
Geography - note:
consists of Oman proper and two northern exclaves, Musandam and Al Madhah; the former is a peninsula that occupies a strategic location adjacent to the Strait of Hormuz, a vital transit point for world crude oil','bd34fb5530b24fdfe281ed0f6396fa7128f4eb0be9adad06c463f44121d78a80','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0fb5cc2b3e280d757e25aa0542fc6bc369faa42b4c50e15bb6b03d7c57bc16fa',2025,'PK','Pakistan','geography',3,'Location:
Southern Asia, bordering the Arabian Sea, between India on the east and Iran and Afghanistan on the west and China in the north
Geographic coordinates:
30 00 N, 70 00 E
Map references:
Asia
Area:
total:
796,095 sq km
land:
770,875 sq km
water:
25,220 sq km
comparison ranking:
total 37
Area - comparative:
slightly more than five times the size of Georgia; slightly less than twice the size of California
Land boundaries:
total:
7,257 km
border countries (4):
Afghanistan 2,670 km; China 438 km; India 3,190 km; Iran 959 km
Coastline:
1,046 km
Maritime claims:
territorial sea:
12 nm
contiguous zone:
24 nm
exclusive economic zone:
200 nm
continental shelf:
200 nm or to the edge of the continental margin
Climate:
mostly hot, dry desert; temperate in northwest; arctic in north
Terrain:
divided into three major geographic areas:
the northern highlands, the Indus River plain in the center and east, and the Balochistan Plateau in the south and west
Elevation:
highest point:
K2 (Mt. Godwin-Austen) 8,611 m
lowest point:
Arabian Sea 0 m
mean elevation:
900 m
Natural resources:
arable land, extensive natural gas reserves, limited petroleum, poor quality coal, iron ore, copper, salt, limestone
Land use:
agricultural land:
35.2% (2018 est.)
arable land:
27.6% (2018 est.)
permanent crops:
1.1% (2018 est.)
permanent pasture:
6.5% (2018 est.)
forest:
2.1% (2018 est.)
other:
62.7% (2018 est.)
Irrigated land:
193,400 sq km (2020)
Major rivers (by length in km):
Indus river mouth (shared with China [s] and India) - 3,610 km; Sutlej river mouth (shared with China [s] and India) - 1,372 km; Chenab river mouth (shared with India [s]) - 1,086 km
note
– [s] after country name indicates river source; [m] after country name indicates river mouth
Major watersheds (area sq km): Indian Ocean drainage:
Indus (1,081,718 sq km)
Internal
(endorheic basin)
drainage:
Tarim Basin (1,152,448 sq km),
(Aral Sea basin)
Amu Darya (534,739 sq km)
Major aquifers:
Indus Basin
Population distribution:
the Indus River and its tributaries attract most of the settlement, with Punjab province the most densely populated
Natural hazards:
frequent earthquakes, occasionally severe especially in north and west; flooding along the Indus after heavy rains (July and August)
Geography - note:
controls Khyber Pass and Bolan Pass, traditional invasion routes between Central Asia and the Indian Subcontinent','a7636bebe10cb40daf159666e306a1b4415d4412b552bb125ee8a7db63a02033','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('49f287e4f133f89b106e14ae258722d77358465c5c85a55975150ca6d34cc13c',2025,'PW','Palau','geography',16,'Location:
Oceania, group of islands in the North Pacific Ocean, southeast of the Philippines
Geographic coordinates:
7 30 N, 134 30 E
Map references:
Oceania
Area:
total:
459 sq km
land:
459 sq km
water:
0 sq km
comparison ranking:
total 197
Area - comparative:
slightly more than 2.5 times the size of Washington, DC
Land boundaries:
total:
0 km
Coastline:
1,519 km
Maritime claims:
territorial sea:
12 nm
contiguous zone:
24 nm
exclusive economic zone:
200 nm
continental shelf:
200 nm
Climate:
tropical; hot and humid; wet season May to November
Terrain:
varying topography from the high, mountainous main island of Babelthuap to low, coral islands usually fringed by large barrier reefs
Elevation:
highest point:
Mount Ngerchelchuus 242 m
lowest point:
Pacific Ocean 0 m
Natural resources:
forests, minerals (especially gold), marine products, deep-seabed minerals
Land use:
agricultural land:
10.8% (2018 est.)
arable land:
2.2% (2018 est.)
permanent crops:
4.3% (2018 est.)
permanent pasture:
4.3% (2018 est.)
forest:
87.6% (2018 est.)
other:
1.6% (2018 est.)
Irrigated land:
0 sq km (2022)
Population distribution:
most of the population is located on the southern end of the main island of Babelthuap
Natural hazards:
typhoons (June to December)
Geography - note:
westernmost archipelago in the Caroline chain, consists of six island groups totaling more than 300 islands; includes World War II battleground of Beliliou (Peleliu) and world-famous Rock Islands','db81cf93d2d8a39d5164b8c28b201a1912f0a953964d3452f1c3edd2a1c02d6e','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ccfe6cc6de3f4785f2699f6252de7d52b165e9b8dd928ebb544d83266fd98d78',2025,'PA','Panama','geography',27,'Location:
Central America, bordering both the Caribbean Sea and the North Pacific Ocean, between Colombia and Costa Rica
Geographic coordinates:
9 00 N, 80 00 W
Map references:
Central America and the Caribbean
Area:
total:
75,420 sq km
land:
74,340 sq km
water:
1,080 sq km
comparison ranking:
total 118
Area - comparative:
slightly smaller than South Carolina
Land boundaries:
total:
687 km
border countries (2):
Colombia 339 km; Costa Rica 348 km
Coastline:
2,490 km
Maritime claims:
territorial sea:
12 nm
contiguous zone:
24 nm
exclusive economic zone:
200 nm or edge of continental margin
Climate:
tropical maritime; hot, humid, cloudy; prolonged rainy season (May to January), short dry season (January to May)
Terrain:
interior mostly steep, rugged mountains with dissected, upland plains; coastal plains with rolling hills
Elevation:
highest point:
Volcan Baru 3,475 m
lowest point:
Pacific Ocean 0 m
mean elevation:
360 m
Natural resources:
copper, mahogany forests, shrimp, hydropower
Land use:
agricultural land:
30.5% (2018 est.)
arable land:
7.3% (2018 est.)
permanent crops:
2.5% (2018 est.)
permanent pasture:
20.7% (2018 est.)
forest:
43.6% (2018 est.)
other:
25.9% (2018 est.)
Irrigated land:
407 sq km (2020)
Major lakes (area sq km):
salt water lake(s):
Laguna de Chiriqui - 900 sq km
Population distribution:
population is concentrated towards the center of the country, particularly around the Canal, but a sizeable segment of the populace also lives in the far west around David; the eastern third of the country is sparsely inhabited
Natural hazards:
occasional severe storms and forest fires in the Darien area
Geography - note:
strategic location on eastern end of isthmus forming land bridge connecting North and South America; controls Panama Canal that links North Atlantic Ocean via Caribbean Sea with North Pacific Ocean','db6bc2598f7bf2853f3c906a5260db9272d9f8f87f083433d48cee0ebfa2d57c','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bede5fa4a221c34cab84f4b20cf533c1f2e670b4242c6cb636a18f278a152216',2025,'PG','Papua New Guinea','geography',38,'Location:
Oceania, group of islands including the eastern half of the island of New Guinea between the Coral Sea and the South Pacific Ocean, east of Indonesia
Geographic coordinates:
6 00 S, 147 00 E
Map references:
Oceania
Area:
total:
462,840 sq km
land:
452,860 sq km
water:
9,980 sq km
comparison ranking:
total 57
Area - comparative:
slightly larger than California
Land boundaries:
total:
824 km
border countries (1):
Indonesia 824 km
Coastline:
5,152 km
Maritime claims:
territorial sea:
12 nm
continental shelf:
200-m depth or to the depth of exploitation
exclusive fishing zone:
200 nm measured from claimed archipelagic baselines
Climate:
tropical; northwest monsoon (December to March), southeast monsoon (May to October); slight seasonal temperature variation
Terrain:
mostly mountains with coastal lowlands and rolling foothills
Elevation:
highest point:
Mount Wilhelm 4,509 m
lowest point:
Pacific Ocean 0 m
mean elevation:
667 m
Natural resources:
gold, copper, silver, natural gas, timber, oil, fisheries
Land use:
agricultural land:
2.6% (2018 est.)
arable land:
0.7% (2018 est.)
permanent crops:
1.5% (2018 est.)
permanent pasture:
0.4% (2018 est.)
forest:
63.1% (2018 est.)
other:
34.3% (2018 est.)
Irrigated land:
0 sq km (2022)
Major rivers (by length in km):
Sepik river source and mouth (shared with Indonesia) - 1,126 km; Fly river source and mouth (shared with Indonesia) - 1,050 km
Population distribution:
population concentrated in the highlands and eastern coastal areas on the island of New Guinea; predominantly a rural distribution with only about one-fifth of the population residing in urban areas
Natural hazards:
active volcanism; the country is subject to frequent and sometimes severe earthquakes; mud slides; tsunamis
volcanism:
severe volcanic activity; Ulawun (2,334 m), one of Papua New Guinea’s potentially most dangerous volcanoes, has been deemed a Decade Volcano by the International Association of Volcanology and Chemistry of the Earth’s Interior, worthy of study due to its explosive history and close proximity to human populations; Rabaul (688 m) destroyed the city of Rabaul in 1937 and 1994; Lamington erupted in 1951 killing 3,000 people; Manam’s 2004 eruption forced the island’s abandonment; other historically active volcanoes include Bam, Bagana, Garbuna, Karkar, Langila, Lolobau, Long Island, Pago, St. Andrew Strait, Victory, and Waiowa; see note 2 under “Geography - note”
Geography - note:
note 1:
shares island of New Guinea with Indonesia; generally east-west trending highlands break up New Guinea into diverse ecoregions; one of world’s largest swamps along southwest coast
note 2:
two major food crops apparently developed on the island of New Guinea: bananas and sugarcane
note 3:
Papua New Guinea is one of the countries along the Ring of Fire, a belt of active volcanoes and earthquake epicenters bordering the Pacific Ocean; up to 90% of the world’s earthquakes and some 75% of the world’s volcanoes occur within the Ring of Fire','d85b0dcf4d05aa24f5aa6ac30a82e73d1f233156e08b0c90770dc92709d89d15','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a8826300c92d789c74071d5c5e5fafc908033c747e870c098bd9256c8d7a3513',2025,'PG','Papua New Guinea','geography',49,'Location:
Southeastern Asia, group of small islands and reefs in the South China Sea, about one-third of the way from central Vietnam to the northern Philippines
Geographic coordinates:
16 30 N, 112 00 E
Map references:
Southeast Asia
Area:
total:
8 sq km ca.
land:
7.75 sq km ca.
water:
0 sq km
comparison ranking:
total 243
Area - comparative:
land area is about 13 times the size of the National Mall in Washington, DC
Land boundaries:
total:
0 km
Coastline:
518 km
Maritime claims:
NA
Climate:
tropical
Terrain:
mostly low and flat
Elevation:
highest point:
unnamed location on Rocky Island 14 m
lowest point:
South China Sea 0 m
Natural resources:
none
Land use:
other:
100% (2018 est.)
Irrigated land:
0 sq km (2022)
Population distribution:
a population of over 1,000 Chinese resides on Woody Island, the largest of the Paracels; there are scattered Chinese garrisons on some other islands
Natural hazards:
typhoons
Geography - note:
composed of 130 small coral islands and reefs divided into the northeast Amphitrite Group and the western Crescent Group','960e90635111c01b1fb0dd504349d900e4900f1d4c5384b705dda789fdb43ec5','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('44e33deb60b926e6f8d924c903968e45f070b5999960cf8f6b627c4e5481db2a',2025,'PY','Paraguay','geography',57,'Location:
Central South America, northeast of Argentina, southwest of Brazil
Geographic coordinates:
23 00 S, 58 00 W
Map references:
South America
Area:
total:
406,752 sq km
land:
397,302 sq km
water:
9,450 sq km
comparison ranking:
total 61
Area - comparative:
about three times the size of New York state; slightly smaller than California
Land boundaries:
total:
4,655 km
border countries (3):
Argentina 2,531 km; Bolivia 753 km; Brazil 1,371 km
Coastline:
0 km (landlocked)
Maritime claims:
none (landlocked)
Climate:
subtropical to temperate; substantial rainfall in the eastern portions, becoming semiarid in the far west
Terrain:
grassy plains and wooded hills east of Rio Paraguay; Gran Chaco region west of Rio Paraguay mostly low, marshy plain near the river, and dry forest and thorny scrub elsewhere
Elevation:
highest point:
Cerro Pero 842 m
lowest point:
junction of Río Paraguay and Río Paraná 46 m
mean elevation:
178 m
Natural resources:
hydropower, timber, iron ore, manganese, limestone
Land use:
agricultural land:
53.8% (2018 est.)
arable land:
10.8% (2018 est.)
permanent crops:
0.2% (2018 est.)
permanent pasture:
42.8% (2018 est.)
forest:
43.8% (2018 est.)
other:
2.4% (2018 est.)
Irrigated land:
1,362 sq km (2012)
Major rivers (by length in km):
Río de la Plata/Paraná (shared with Brazil [s], Argentina, and Uruguay [m]) - 4,880 km; Paraguay river mouth (shared with Brazil [s] and Argentina) - 2,549 km
note
– [s] after country name indicates river source; [m] after country name indicates river mouth
Major watersheds (area sq km): Atlantic Ocean drainage:
Paraná (2,582,704 sq km)
Major aquifers:
Guarani Aquifer System
Population distribution:
most of the population resides in the eastern half of the country; to the west lies the Gran Chaco (a semi-arid lowland plain), which accounts for 60% of the land territory, but only 2% of the overall population
Natural hazards:
local flooding in southeast (early September to June); poorly drained plains may become boggy (early October to June)
Geography - note:
note 1:
landlocked; lies between Argentina, Bolivia, and Brazil; population concentrated in eastern and southern part of country
note 2:
pineapples are probably indigenous to the southern Brazil-Paraguay region','e15a3af0a205c1a3f3e47738d5ac17d438830f82308132196d6ab41aab48ce32','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5532a4dbd13a24bca56d3beeaf0442283d4b9a0aeacebc45457594cff26e195c',2025,'PE','Peru','geography',2,'Location:
Western South America, bordering the South Pacific Ocean, between Chile and Ecuador
Geographic coordinates:
10 00 S, 76 00 W
Map references:
South America
Area:
total:
1,285,216 sq km
land:
1,279,996 sq km
water:
5,220 sq km
comparison ranking:
total 21
Area - comparative:
almost twice the size of Texas; slightly smaller than Alaska
Land boundaries:
total:
7,062 km
border countries (5):
Bolivia 1,212 km; Brazil 2,659 km; Chile 168 km; Colombia 1,494 km; Ecuador 1,529 km
Coastline:
2,414 km
Maritime claims:
territorial sea:
200 nm; note: the US does not recognize this claim
exclusive economic zone:
200 nm
continental shelf:
200 nm
Climate:
varies from tropical in east to dry desert in west; temperate to frigid in Andes
Terrain:
western coastal plain (costa), high and rugged Andes in center (sierra), eastern lowland jungle of Amazon Basin (selva)
Elevation:
highest point:
Nevado Huascaran 6,746 m
lowest point:
Pacific Ocean 0 m
mean elevation:
1,555 m
Natural resources:
copper, silver, gold, petroleum, timber, fish, iron ore, coal, phosphate, potash, hydropower, natural gas
Land use:
agricultural land:
18.8% (2018 est.)
arable land:
3.1% (2018 est.)
permanent crops:
1.1% (2018 est.)
permanent pasture:
14.6% (2018 est.)
forest:
53% (2018 est.)
other:
28.2% (2018 est.)
Irrigated land:
25,800 sq km (2012)
Major lakes (area sq km):
fresh water lake(s):
Lago Titicaca (shared with Bolivia) - 8,030 sq km
Major rivers (by length in km):
Amazon river source (shared with Brazil [m]) - 6,400 km
note
– [s] after country name indicates river source; [m] after country name indicates river mouth
Major watersheds (area sq km): Atlantic Ocean drainage:
Amazon (6,145,186 sq km)
Major aquifers:
Amazon Basin
Population distribution:
approximately one-third of the population resides along the desert coastal belt in the west, with a strong focus on the capital city of Lima; the Andean highlands, or sierra, which is strongly identified with the country’s Amerindian population, contains roughly half of the overall population; the eastern slopes of the Andes, and adjoining rainforest, are sparsely populated
Natural hazards:
earthquakes, tsunamis, flooding, landslides, mild volcanic activity
volcanism:
volcanic activity in the Andes Mountains; Ubinas (5,672 m), which last erupted in 2009, is the country’s most active volcano; other historically active volcanoes include El Misti, Huaynaputina, Sabancaya, and Yucamane; see note 2 under “Geography - note”
Geography - note:
note 1:
shares control of Lago Titicaca, world’s highest navigable lake, with Bolivia; a remote slope of Nevado Mismi, a 5,316 m peak, is the ultimate source of the Amazon River
note 2:
Peru is one of the countries along the Ring of Fire, a belt of active volcanoes and earthquake epicenters bordering the Pacific Ocean; up to 90% of the world’s earthquakes and some 75% of the world’s volcanoes occur within the Ring of Fire
note 3:
on 19 February 1600, Mount Huaynaputina in the southern Peruvian Andes erupted in the largest volcanic explosion in South America in historical times; intermittent eruptions lasted until 5 March 1600 and pumped an estimated 16 to 32 million metric tons of particulates into the atmosphere reducing the amount of sunlight reaching the earth’s surface and affecting weather worldwide; over the next two and a half years, millions died around the globe in famines from bitterly cold winters, cool summers, and the loss of crops and animals
note 4:
the southern regions of Peru and the extreme northwestern part of Bolivia are considered to be the place of origin for the common potato','27e1b5029af97ada6e5768b503b1f351f002c011b2c799dc43509ffce470c78a','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2a534d75d6224fbe95df9d90a3e11d85dd151e0cf4d80d66ea06e54a23b33e0d',2025,'PH','Philippines','geography',15,'Location:
Southeastern Asia, archipelago between the Philippine Sea and the South China Sea, east of Vietnam
Geographic coordinates:
13 00 N, 122 00 E
Map references:
Southeast Asia
Area:
total:
300,000 sq km
land:
298,170 sq km
water:
1,830 sq km
comparison ranking:
total 74
Area - comparative:
slightly less than twice the size of Georgia; slightly larger than Arizona
Land boundaries:
total:
0 km
Coastline:
36,289 km
Maritime claims:
territorial sea:
irregular polygon extending up to 100 nm from coastline as defined by 1898 treaty; since late 1970s has also claimed polygonal-shaped area in South China Sea as wide as 285 nm
exclusive economic zone:
200 nm
continental shelf:
to the depth of exploitation
Climate:
tropical marine; northeast monsoon (November to April); southwest monsoon (May to October)
Terrain:
mostly mountains with narrow to extensive coastal lowlands
Elevation:
highest point:
Mount Apo 2,954 m
lowest point:
Philippine Sea 0 m
mean elevation:
442 m
Natural resources:
timber, petroleum, nickel, cobalt, silver, gold, salt, copper
Land use:
agricultural land:
41% (2018 est.)
arable land:
18.2% (2018 est.)
permanent crops:
17.8% (2018 est.)
permanent pasture:
5% (2018 est.)
forest:
25.9% (2018 est.)
other:
33.1% (2018 est.)
Irrigated land:
16,270 sq km (2012)
Major lakes (area sq km):
salt water lake(s):
Laguna de Bay - 890 sq km
Population distribution:
population concentrated where good farmlands lie; highest concentrations are northwest and south-central Luzon, the southeastern extension of Luzon, and the islands of the Visayan Sea, particularly Cebu and Negros; Manila is home to one-eighth of the entire national population
Natural hazards:
astride typhoon belt, usually affected by 15 and struck by five to six cyclonic storms each year; landslides; active volcanoes; destructive earthquakes; tsunamis
volcanism:
significant volcanic activity; Taal (311 m), which has shown recent unrest and may erupt in the near future, has been deemed a Decade Volcano by the International Association of Volcanology and Chemistry of the Earth’s Interior, worthy of study due to its explosive history and close proximity to human populations; Mayon (2,462 m), the country’s most active volcano, erupted in 2009 forcing over 33,000 to be evacuated; other historically active volcanoes include Biliran, Babuyan Claro, Bulusan, Camiguin, Camiguin de Babuyanes, Didicas, Iraya, Jolo, Kanlaon, Makaturing, Musuan, Parker, Pinatubo, and Ragang; see note 2 under “Geography - note”
Geography - note:
note 1:
for decades, the Philippine archipelago was reported as having 7,107 islands; in 2016, the national mapping authority reported that hundreds of new islands had been discovered and increased the number of islands to 7,641 - though not all of the new islands have been verified; the country is favorably located in relation to many of Southeast Asia’s main water bodies: the South China Sea, Philippine Sea, Sulu Sea, Celebes Sea, and Luzon Strait
note 2:
Philippines is one of the countries along the Ring of Fire, a belt of active volcanoes and earthquake epicenters bordering the Pacific Ocean; up to 90% of the world’s earthquakes and some 75% of the world’s volcanoes occur within the Ring of Fire
note 3:
the Philippines sits astride the Pacific typhoon belt and an average of 9 typhoons make landfall on the islands each year - with about 5 of these being destructive; the country is the most exposed in the world to tropical storms','4ab2e76c630a34ddebf97d441ce93e0c9fbe52d76beff5a15a6148d700f88961','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('50c2355add1ce41da06e1863da68a4fe03c8a8fb7c7739fa281efe8bc99d16ed',2025,'PH','Philippines','geography',28,'Location:
Oceania, islands in the South Pacific Ocean, about midway between Peru and New Zealand
Geographic coordinates:
25 04 S, 130 06 W
Map references:
Oceania
Area:
total:
47 sq km
land:
47 sq km
water:
0 sq km
comparison ranking:
total 233
Area - comparative:
about three-tenths the size of Washington, DC
Land boundaries:
total:
0 km
Coastline:
51 km
Maritime claims:
territorial sea:
12 nm
exclusive economic zone:
200 nm
Climate:
tropical; hot and humid; modified by southeast trade winds; rainy season (November to March)
Terrain:
rugged volcanic formation; rocky coastline with cliffs
Elevation:
highest point:
Palwala Valley Point on Big Ridge 347 m
lowest point:
Pacific Ocean 0 m
Natural resources:
miro trees (used for handicrafts), fish; note - manganese, iron, copper, gold, silver, and zinc have been discovered offshore
Land use:
agricultural land:
0% (2011 est.)
forest:
74.5% (2018 est.)
other:
25.5% (2018 est.)
Irrigated land:
0 sq km (2022)
Population distribution:
less than 50 inhabitants on Pitcairn Island, most reside near the village of Adamstown
Natural hazards:
occasional tropical cyclones (especially November to March), but generally only heavy tropical storms; landslides
Geography - note:
Britain’s most isolated dependency; only the larger island of Pitcairn is inhabited but it has no port or natural harbor; supplies must be transported by rowed longboat from larger ships stationed offshore','c83b03ffb432b21b8493ce03a2cafb972a56bf9e2123669364da1ea9d885a3f3','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1d59a0c7ae5ca2d302abeaf965115a7bdcc7d2abc23523ce38243b3c3c95fcb4',2025,'PL','Poland','geography',38,'Location:
Central Europe, east of Germany
Geographic coordinates:
52 00 N, 20 00 E
Map references:
Europe
Area:
total:
312,685 sq km
land:
304,255 sq km
water:
8,430 sq km
comparison ranking:
total 71
Area - comparative:
about twice the size of Georgia; slightly smaller than New Mexico
Land boundaries:
total:
2,865 km
border countries (6):
Belarus 375 km; Czechia 699 km; Germany 467 km; Lithuania 100 km, Russia (Kaliningrad Oblast) 209 km; Slovakia 517 km; Ukraine 498 km
Coastline:
440 km
Maritime claims:
territorial sea:
12 nm
exclusive economic zone:
defined by international treaties
Climate:
temperate with cold, cloudy, moderately severe winters with frequent precipitation; mild summers with frequent showers and thundershowers
Terrain:
mostly flat plain; mountains along southern border
Elevation:
highest point:
Rysy 2,499 m
lowest point:
near Raczki Elblaskie -2 m
mean elevation:
173 m
Natural resources:
coal, sulfur, copper, natural gas, silver, lead, salt, amber, arable land
Land use:
agricultural land:
48.2% (2018 est.)
arable land:
36.2% (2018 est.)
permanent crops:
1.3% (2018 est.)
permanent pasture:
10.7% (2018 est.)
forest:
30.6% (2018 est.)
other:
21.2% (2018 est.)
Irrigated land:
760 sq km (2013)
Major lakes (area sq km):
salt water lake(s):
Zalew Szczecinski/Stettiner Haff (shared with Germany) - 900 sq km
Major rivers (by length in km):
Wisla (Vistula) river source and mouth (shared with Belarus and Ukraine) - 1,213 km
note
– longest river in Poland
Major watersheds (area sq km): Atlantic Ocean drainage:
(Black Sea)
Danube (795,656 sq km)
Population distribution:
population concentrated in the southern area around Krakow and the central area around Warsaw and Lodz, with an extension to the northern coastal city of Gdansk
Natural hazards:
flooding
Geography - note:
historically, an area of conflict because of flat terrain and the lack of natural barriers on the North European Plain','9b1c6397b4de0a4b59191aebd84083980398749e273465230d9910672a426816','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('26e55e06f3d86110a76645c42e8f08068fe2ae4c5d7a29db5fe6b0d9051c213a',2025,'PT','Portugal','geography',51,'Location:
Southwestern Europe, bordering the North Atlantic Ocean, west of Spain
Geographic coordinates:
39 30 N, 8 00 W
Map references:
Europe
Area:
total:
92,090 sq km
land:
91,470 sq km
water:
620 sq km
note:
includes Azores and Madeira Islands
comparison ranking:
total 111
Area - comparative:
slightly smaller than Virginia
Land boundaries:
total:
1,224 km
border countries (1):
Spain 1,224 km
Coastline:
1,793 km
Maritime claims:
territorial sea:
12 nm
contiguous zone:
24 nm
exclusive economic zone:
200 nm
continental shelf:
200-m depth or to the depth of exploitation
Climate:
maritime temperate; cool and rainy in north, warmer and drier in south
Terrain:
the west-flowing Tagus River divides the country:
the north is mountainous toward the interior, while the south is characterized by rolling plains
Elevation:
highest point:
Ponta do Pico (Pico or Pico Alto) on Ilha do Pico in the Azores 2,351 m
lowest point:
Atlantic Ocean 0 m
mean elevation:
372 m
Natural resources:
fish, forests (cork), iron ore, copper, zinc, tin, tungsten, silver, gold, uranium, marble, clay, gypsum, salt, arable land, hydropower
Land use:
agricultural land:
39.7% (2018 est.)
arable land:
11.9% (2018 est.)
permanent crops:
7.8% (2018 est.)
permanent pasture:
20% (2018 est.)
forest:
37.8% (2018 est.)
other:
22.5% (2018 est.)
Irrigated land:
5,662 sq km (2019)
Population distribution:
concentrations are primarily along or near the Atlantic coast; both Lisbon and the second largest city, Porto, are coastal cities
Natural hazards:
Azores subject to severe earthquakes
volcanism:
limited volcanic activity in the Azores Islands; Fayal or Faial (1,043 m) last erupted in 1958; most volcanoes have not erupted in centuries; historically active volcanoes include Agua de Pau, Furnas, Pico, Picos Volcanic System, San Jorge, Sete Cidades, and Terceira
Geography - note:
Azores and Madeira Islands occupy strategic locations along western sea approaches to Strait of Gibraltar; they are two of the four North Atlantic archipelagos that make up Macaronesia; the others are the Canary Islands (Spain) and Cabo Verde','5714718a57eb6b30b18e7507accaea71c7a8ad23db4dd136bc5ea0d21d1b52e3','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d160e3fde4f90f7478e59c806719410179143f1d2d949da78226083d1acc0290',2025,'PR','Puerto Rico','geography',64,'Location:
Caribbean, island between the Caribbean Sea and the North Atlantic Ocean, east of the Dominican Republic
Geographic coordinates:
18 15 N, 66 30 W
Map references:
Central America and the Caribbean
Area:
total:
9,104 sq km
land:
8,959 sq km
water:
145 sq km
comparison ranking:
total 170
Area - comparative:
slightly less than three times the size of Rhode Island
Land boundaries:
total:
0 km
Coastline:
501 km
Maritime claims:
territorial sea:
12 nm
exclusive economic zone:
200 nm
Climate:
tropical marine, mild; little seasonal temperature variation
Terrain:
mostly mountains with coastal plain in north; precipitous mountains to the sea on west coast; sandy beaches along most coastal areas
Elevation:
highest point:
Cerro de Punta 1,338 m
lowest point:
Caribbean Sea 0 m
mean elevation:
261 m
Natural resources:
some copper and nickel; potential for onshore and offshore oil
Land use:
agricultural land:
22% (2018 est.)
arable land:
6.6% (2018 est.)
permanent crops:
5.6% (2018 est.)
permanent pasture:
9.8% (2018 est.)
forest:
63.2% (2018 est.)
other:
14.8% (2018 est.)
Irrigated land:
220 sq km (2012)
Population distribution:
population clusters tend to be found along the coast, the largest of these is found in and around San Juan; an exception to this is a sizeable population located in the interior of the island immediately south of the capital around Caguas; most of the interior, particularly in the western half of the island, is dominated by the Cordillera Central mountains, where population density is low
Natural hazards:
periodic droughts; hurricanes
Geography - note:
important location along the Mona Passage - a key shipping lane to the Panama Canal; San Juan is one of the biggest and best natural harbors in the Caribbean; many small rivers and high central mountains ensure land is well watered; south coast relatively dry; fertile coastal plain belt in north','d4d1e5f4c6aeab818aa0e801001542bbfad5d70e275b4f13f04084bf50eb02ba','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('78b2bbeed6a4cff540860b6cb1eff07c3828827d9bc74021bda9d8ae6033f92b',2025,'QA','Qatar','geography',2,'Location:
Middle East, peninsula bordering the Persian Gulf and Saudi Arabia
Geographic coordinates:
25 30 N, 51 15 E
Map references:
Middle East
Area:
total:
11,586 sq km
land:
11,586 sq km
water:
0 sq km
comparison ranking:
total 164
Area - comparative:
almost twice the size of Delaware; slightly smaller than Connecticut
Land boundaries:
total:
87 km
border countries (1):
Saudi Arabia 87 km
Coastline:
563 km
Maritime claims:
territorial sea:
12 nm
contiguous zone:
24 nm
exclusive economic zone:
as determined by bilateral agreements or the median line
Climate:
arid; mild, pleasant winters; very hot, humid summers
Terrain:
mostly flat and barren desert
Elevation:
highest point:
Tuwayyir al Hamir 103 m
lowest point:
Persian Gulf 0 m
mean elevation:
28 m
Natural resources:
petroleum, fish, natural gas
Land use:
agricultural land:
5.6% (2018 est.)
arable land:
1.1% (2018 est.)
permanent crops:
0.2% (2018 est.)
permanent pasture:
4.3% (2018 est.)
forest:
0% (2018 est.)
other:
94.4% (2018 est.)
Irrigated land:
130 sq km (2020)
Major aquifers:
Arabian Aquifer System
Population distribution:
most of the population is clustered in or around the capital of Doha on the eastern side of the peninsula
Natural hazards:
haze, dust storms, sandstorms common
Geography - note:
the peninsula occupies a strategic location in the central Persian Gulf near major petroleum deposits','2db2517c8a6b879a62c93ee0487c33228d8fb8e44a2c2b344f8973b0b2753fdf','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7d571dcc84e30e62ebe3ccfffb735a619e30de9b9885e7e2068d99ed74aacfaa',2025,'RO','Romania','geography',2,'Location:
Southeastern Europe, bordering the Black Sea, between Bulgaria and Ukraine
Geographic coordinates:
46 00 N, 25 00 E
Map references:
Europe
Area:
total:
238,391 sq km
land:
229,891 sq km
water:
8,500 sq km
comparison ranking:
total 83
Area - comparative:
twice the size of Pennsylvania; slightly smaller than Oregon
Land boundaries:
total:
2,844 km
border countries (5):
Bulgaria 605 km; Hungary 424 km; Moldova 683 km; Serbia 531 km; Ukraine 601 km
Coastline:
225 km
Maritime claims:
territorial sea:
12 nm
contiguous zone:
24 nm
exclusive economic zone:
200 nm
continental shelf:
200-m depth or to the depth of exploitation
Climate:
temperate; cold, cloudy winters with frequent snow and fog; sunny summers with frequent showers and thunderstorms
Terrain:
central Transylvanian Basin is separated from the Moldavian Plateau on the east by the Eastern Carpathian Mountains and separated from the Walachian Plain on the south by the Transylvanian Alps
Elevation:
highest point:
Moldoveanu 2,544 m
lowest point:
Black Sea 0 m
mean elevation:
414 m
Natural resources:
petroleum (reserves declining), timber, natural gas, coal, iron ore, salt, arable land, hydropower
Land use:
agricultural land:
60.7% (2018 est.)
arable land:
39.1% (2018 est.)
permanent crops:
1.9% (2018 est.)
permanent pasture:
19.7% (2018 est.)
forest:
28.7% (2018 est.)
other:
10.6% (2018 est.)
Irrigated land:
4,730 sq km (2020)
Major rivers (by length in km):
Dunărea (Danube) river mouth (shared with Germany [s], Austria, Slovakia, Czechia, Hungary, Croatia, Serbia, Bulgaria, Moldova, and Ukraine) - 2,888 km
note –
[s] after country name indicates river source; [m] after country name indicates river mouth
Major watersheds (area sq km): Atlantic Ocean drainage:
(Black Sea)
Danube (795,656 sq km)
Population distribution:
urbanization is not particularly high, and a fairly even population distribution can be found throughout most of the country, with urban areas attracting larger and denser populations; Hungarians, the country’s largest minority, have a particularly strong presence in eastern Transylvania
Natural hazards:
earthquakes, most severe in south and southwest; geologic structure and climate promote landslides
Geography - note:
controls the most easily traversable land route between the Balkans, Moldova, and Ukraine; the Carpathian Mountains dominate the center of the country, while the Danube River forms much of the southern boundary with Serbia and Bulgaria','64b50297b6e42e28e8f12cc0bd6c90358922fc65e123a1497f90130ede91ac8e','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4e5a8f0d84045d7952c86f0cc59b95e9c58c3bfcfbf26e5e9cd6a067b9c6c386',2025,'RO','Romania','geography',15,'Location:
North Asia bordering the Arctic Ocean, extending from Eastern Europe (the portion west of the Urals) to the North Pacific Ocean
Geographic coordinates:
60 00 N, 100 00 E
Map references:
Asia
Area:
total:
17,098,242 sq km
land:
16,377,742 sq km
water:
720,500 sq km
comparison ranking:
total 1
Area - comparative:
approximately 1.8 times the size of the US
Land boundaries:
total:
22,407 km
border countries (14):
Azerbaijan 338 km; Belarus 1,312 km; China (southeast) 4,133 km and China (south) 46 km; Estonia 324 km; Finland 1,309 km; Georgia 894 km; Kazakhstan 7,644 km; North Korea 18 km; Latvia 332 km; Lithuania (Kaliningrad Oblast) 261 km; Mongolia 3,452 km; Norway 191 km; Poland (Kaliningrad Oblast) 209 km; Ukraine 1,944 km
Coastline:
37,653 km
Maritime claims:
territorial sea:
12 nm
contiguous zone:
24 nm
exclusive economic zone:
200 nm
continental shelf:
200-m depth or to the depth of exploitation
Climate:
ranges from steppes in the south through humid continental in much of European Russia; subarctic in Siberia to tundra climate in the polar north; winters vary from cool along Black Sea coast to frigid in Siberia; summers vary from warm in the steppes to cool along Arctic coast
Terrain:
broad plain with low hills west of Urals; vast coniferous forest and tundra in Siberia; uplands and mountains along southern border regions
Elevation:
highest point:
Gora El’brus (highest point in Europe) 5,642 m
lowest point:
Caspian Sea -28 m
mean elevation:
600 m
Natural resources:
wide natural resource base including major deposits of oil, natural gas, coal, and many strategic minerals, bauxite, reserves of rare earth elements, timber, note, formidable obstacles of climate, terrain, and distance hinder exploitation of natural resources
Land use:
agricultural land:
13.1% (2018 est.)
arable land:
7.3% (2018 est.)
permanent crops:
0.1% (2018 est.)
permanent pasture:
5.7% (2018 est.)
forest:
49.4% (2018 est.)
other:
37.5% (2018 est.)
Irrigated land:
43,000 sq km (2012)
Major lakes (area sq km):
fresh water lake(s):
Lake Baikal - 31,500 sq km; Lake Ladoga - 18,130 sq km; Lake Onega - 9,720 sq km; Lake Khanka (shared with China) - 5,010 sq km; Lake Peipus - 4,300 sq km (shared with Estonia); Ozero Vygozero - 1,250 sq km; Ozero Beloye - 1,120 sq km
salt water lake(s):
Caspian Sea (shared with Iran, Azerbaijan, Turkmenistan, and Kazakhstan) - 374,000 sq km; Ozero Malyye Chany - 2,500 sq km; Curonian Lagoon (shared with Lithuania) - 1,620 sq km note - the Caspian Sea is the World’s largest lake
Major rivers (by length in km):
Yenisey-Angara - 5,539 km; Ob-Irtysh - 5,410 km; Amur river mouth (shared with China [s] and Mongolia) - 4,444 km; Lena - 4,400 km; Volga - 3,645 km; Kolyma - 2,513 km; Ural river source (shared with Kazakhstan [m]) - 2,428 km; Dnepr (Dnieper) river source (shared with Belarus and Ukraine [m]) - 2,287 km; Don - 1,870 km; Pechora - 1,809 km
note
– [s] after country name indicates river source; [m] after country name indicates river mouth
Major watersheds (area sq km): Arctic Ocean drainage:
Kolyma (679,934 sq km), Lena (2,306,743 sq km), Ob (2,972,493 sq km), Pechora (289,532 sq km), Yenisei (2,554,388 sq km)
Atlantic Ocean drainage:
(Black Sea)
Don (458,694 sq km), Dnieper (533,966 sq km)
Pacific Ocean drainage:
Amur (1,929,955 sq km)
Internal
(endorheic basin)
drainage:
(Caspian Sea basin)
Volga (1,410,951 sq km)
Major aquifers:
Angara-Lena Basin, Pechora Basin, North Caucasus Basin, East European Aquifer System, West Siberian Basin, Tunguss Basin, Yakut Basin
Population distribution:
population is heavily concentrated in the westernmost fifth of the country extending from the Baltic Sea, south to the Caspian Sea, and eastward parallel to the Kazakh border; elsewhere, sizeable pockets are isolated and generally found in the south
Natural hazards:
permafrost over much of Siberia is a major impediment to development; volcanic activity in the Kuril Islands; volcanoes and earthquakes on the Kamchatka Peninsula; spring floods and summer/autumn forest fires throughout Siberia and parts of European Russia
volcanism:
significant volcanic activity on the Kamchatka Peninsula and Kuril Islands; the peninsula alone is home to some 29 historically active volcanoes, with dozens more in the Kuril Islands; Kliuchevskoi (4,835 m), which erupted in 2007 and 2010, is Kamchatka’s most active volcano; Avachinsky and Koryaksky volcanoes, which pose a threat to the city of Petropavlovsk-Kamchatsky, have been deemed Decade Volcanoes by the International Association of Volcanology and Chemistry of the Earth’s Interior, worthy of study due to their explosive history and close proximity to human populations; other notable historically active volcanoes include Bezymianny, Chikurachki, Ebeko, Gorely, Grozny, Karymsky, Ketoi, Kronotsky, Ksudach, Medvezhia, Mutnovsky, Sarychev Peak, Shiveluch, Tiatia, Tolbachik, and Zheltovsky; see note 2 under “Geography - note”
Geography - note:
note 1:
largest country in the world in terms of area but unfavorably located in relation to major sea lanes of the world; despite its size, much of the country lacks proper soils and climates (either too cold or too dry) for agriculture
note 2:
Russia’s far east, particularly the Kamchatka Peninsula, lies along the Ring of Fire, a belt of active volcanoes and earthquake epicenters bordering the Pacific Ocean; up to 90% of the world’s earthquakes and some 75% of the world’s volcanoes occur within the Ring of Fire
note 3:
Mount El’brus is Europe’s tallest peak; Lake Baikal, the deepest lake in the world, is estimated to hold one fifth of the world’s fresh surface water
note 4:
Kaliningrad oblast is an exclave annexed from Germany following World War II (it was formerly part of East Prussia); its capital city of Kaliningrad - formerly Koenigsberg - is the only Baltic port in Russia that remains ice free in the winter','0141b21c66772b23425dfa631679827eb4ebcd6cc6464f9252267cb8b9f74703','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('98723362e375cc0a9a8b7c285a8da240d1ef0c4ae213cb6a358d4fafa7289792',2025,'RW','Rwanda','geography',28,'Location:
Central Africa, east of the Democratic Republic of the Congo, north of Burundi
Geographic coordinates:
2 00 S, 30 00 E
Map references:
Africa
Area:
total:
26,338 sq km
land:
24,668 sq km
water:
1,670 sq km
comparison ranking:
total 148
Area - comparative:
slightly smaller than Maryland
Land boundaries:
total:
930 km
border countries (4):
Burundi 315 km; Democratic Republic of the Congo 221 km; Tanzania 222 km; Uganda 172 km
Coastline:
0 km (landlocked)
Maritime claims:
none (landlocked)
Climate:
temperate; two rainy seasons (February to April, November to January); mild in mountains with frost and snow possible
Terrain:
mostly grassy uplands and hills; relief is mountainous with altitude declining from west to east
Elevation:
highest point:
Volcan Karisimbi 4,519 m
lowest point:
Rusizi River 950 m
mean elevation:
1,598 m
Natural resources:
gold, cassiterite (tin ore), wolframite (tungsten ore), methane, hydropower, arable land
Land use:
agricultural land:
74.5% (2018 est.)
arable land:
47% (2018 est.)
permanent crops:
10.1% (2018 est.)
permanent pasture:
17.4% (2018 est.)
forest:
18% (2018 est.)
other:
7.5% (2018 est.)
Irrigated land:
96 sq km (2012)
Major lakes (area sq km):
fresh water lake(s):
Lake Kivu (shared with Democratic Republic of Congo) - 2,220 sq km
Major rivers (by length in km):
Nile river source (shared with Tanzania, Uganda, South Sudan, Sudan, and Egypt [m]) - 6,650 km
note
– [s] after country name indicates river source; [m] after country name indicates river mouth
Major watersheds (area sq km): Atlantic Ocean drainage:
Congo (3,730,881 sq km),
(Mediterranean Sea)
Nile (3,254,853 sq km)
Population distribution:
one of Africa’s most densely populated countries; large concentrations tend to be in the central regions and along the shore of Lake Kivu in the west as shown in this population distribution map
Natural hazards:
periodic droughts; the volcanic Virunga Mountains are in the northwest along the border with Democratic Republic of the Congo
volcanism:
Visoke (3,711 m), located on the border with the Democratic Republic of the Congo, is the country’s only historically active volcano
Geography - note:
landlocked; most of the country is intensively cultivated and rugged with the population predominantly rural','f448311ff97277e0a0b30b587a7e6d9e1636449976bfc5822c3ee9f9d4f94be4','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4cf931a953957331a0ed584e97a71d94bb807975dcb54b3c8acf03db9e142a50',2025,'KN','Saint Kitts and Nevis','geography',4,'Location:
Caribbean, islands in the Caribbean Sea, about one-third of the way from Puerto Rico to Trinidad and Tobago
Geographic coordinates:
17 20 N, 62 45 W
Map references:
Central America and the Caribbean
Area:
total:
261 sq km (Saint Kitts 168 sq km; Nevis 93 sq km)
land:
261 sq km
water:
0 sq km
comparison ranking:
total 211
Area - comparative:
1.5 times the size of Washington, DC
Land boundaries:
total:
0 km
Coastline:
135 km
Maritime claims:
territorial sea:
12 nm
contiguous zone:
24 nm
exclusive economic zone:
200 nm
continental shelf:
200 nm or to the edge of the continental margin
Climate:
tropical, tempered by constant sea breezes; little seasonal temperature variation; rainy season (May to November)
Terrain:
volcanic with mountainous interiors
Elevation:
highest point:
Mount Liamuiga 1,156 m
lowest point:
Caribbean Sea 0 m
Natural resources:
arable land
Land use:
agricultural land:
23.1% (2018 est.)
arable land:
19.2% (2018 est.)
permanent crops:
0.4% (2018 est.)
permanent pasture:
3.5% (2018 est.)
forest:
42.3% (2018 est.)
other:
34.6% (2018 est.)
Irrigated land:
8 sq km (2012)
Population distribution:
population clusters are found in the small towns located on the periphery of both islands
Natural hazards:
hurricanes (July to October)
volcanism:
Mount Liamuiga (1,156 m) on Saint Kitts, and Nevis Peak (985 m) on Nevis, are both volcanoes that are part of the volcanic island arc of the Lesser Antilles, which extends from Saba in the north to Grenada in the south
Geography - note:
smallest country in the Western Hemisphere both in terms of area and population; with coastlines in the shape of a baseball bat and ball, the two volcanic islands are separated by a 3-km-wide channel called The Narrows; on the southern tip of long, baseball bat-shaped Saint Kitts lies the Great Salt Pond; Nevis Peak sits in the center of its almost circular namesake island and its ball shape complements that of its sister island','5c2f88bc664346ea56aada1f42a53fbd27a6b89d5a90cbe41d41883b9c913b47','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f250529917695251889e9f4f42c96d4ede73cb34650dbf6ec054d874b7c61f1e',2025,'LC','Saint Lucia','geography',15,'Location:
Caribbean, island between the Caribbean Sea and North Atlantic Ocean, north of Trinidad and Tobago
Geographic coordinates:
13 53 N, 60 58 W
Map references:
Central America and the Caribbean
Area:
total:
616 sq km
land:
606 sq km
water:
10 sq km
comparison ranking:
total 192
Area - comparative:
three and a half times the size of Washington, DC
Land boundaries:
total:
0 km
Coastline:
158 km
Maritime claims:
territorial sea:
12 nm
contiguous zone:
24 nm
exclusive economic zone:
200 nm
continental shelf:
200 nm or to the edge of the continental margin
Climate:
tropical, moderated by northeast trade winds; dry season January to April, rainy season May to August
Terrain:
volcanic and mountainous with broad, fertile valleys
Elevation:
highest point:
Mount Gimie 948 m
lowest point:
Caribbean Sea 0 m
Natural resources:
forests, sandy beaches, minerals (pumice), mineral springs, geothermal potential
Land use:
agricultural land:
17.4% (2018 est.)
arable land:
4.9% (2018 est.)
permanent crops:
11.5% (2018 est.)
permanent pasture:
1% (2018 est.)
forest:
77% (2018 est.)
other:
5.6% (2018 est.)
Irrigated land:
30 sq km (2012)
Population distribution:
most of the population is found on the periphery of the island, with a larger concentration in the north around the capital of Castries
Natural hazards:
hurricanes
volcanism:
Mount Gimie (948 m), also known as Qualibou, is a caldera on the west of the island; the iconic twin pyramidal peaks of Gros Piton (771 m) and Petit Piton (743 m) are lava dome remnants associated with the Soufriere volcano; there have been no historical magmatic eruptions, but a minor steam eruption in 1766 spread a thin layer of ash over a wide area; Saint Lucia is part of the volcanic island arc of the Lesser Antilles that extends from Saba in the north to Grenada in the south
Geography - note:
the twin Pitons (Gros Piton and Petit Piton), striking cone-shaped peaks south of Soufriere, are one of the scenic natural highlights of the Caribbean','37328599c601875a4c1516cc4ac0a77f65ceb7e278c832beeac14d8caa838119','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('57e23e710252ffe43e01312f86210d01a672f28a4682f4d82fbe4622076d884f',2025,'LC','Saint Lucia','geography',26,'Location:
Caribbean, located in the Leeward Islands (northern) group; French part of the island of Saint Martin in the Caribbean Sea; Saint Martin lies east of the US Virgin Islands
Geographic coordinates:
18 05 N, 63 57 W
Map references:
Central America and the Caribbean
Area:
total:
50 sq km
land:
50 sq km
water:
negligible
comparison ranking:
total 231
Area - comparative:
more than one-third the size of Washington, DC
Land boundaries:
total:
16 km
border countries (1):
Sint Maarten 16 km
Coastline:
58.9 km (for entire island)
Climate:
temperature averages 27-29 degrees Celsius all year long; low humidity, gentle trade winds, brief, intense rain showers; hurricane season stretches from July to November
Elevation:
highest point:
Pic du Paradis 424 m
lowest point:
Caribbean Ocean 0 m
Natural resources:
salt
Population distribution:
most of the population is found along the coast, with a largest concentrations around the capital Marigot, Orleans, and Grand-Case
Natural hazards:
subject to hurricanes from July to November
Geography - note:
note 1:
the southern border is shared with Sint Maarten, a country within the Kingdom of the Netherlands; together, these two entities make up the smallest landmass in the world shared by two self-governing states
note 2:
Simpson Bay Lagoon (aka as Simson Bay Lagoon or The Great Pond) is one of the largest inland lagoons in the West Indies; the border between the French and Dutch halves of the island of Saint Martin runs across the center of the lagoon, which is shared by both of the island’s entities','aacebb9219f0e78d241a8b4c20141e97bce2cafe6e9af15e94a06b9a98dfa83d','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b7d2400d22d6501d4735073c921455c7d32ed25c65482638343524731ddf4ce8',2025,'PM','Saint Pierre and Miquelon','geography',37,'Location:
Northern North America, islands in the North Atlantic Ocean, south of Newfoundland (Canada)
Geographic coordinates:
46 50 N, 56 20 W
Map references:
North America
Area:
total:
242 sq km
land:
242 sq km
water:
0 sq km
note:
includes eight small islands in the Saint Pierre and the Miquelon groups
comparison ranking:
total 213
Area - comparative:
one and half times the size of Washington, DC
Land boundaries:
total:
0 km
Coastline:
120 km
Maritime claims:
territorial sea:
12 nm
exclusive economic zone:
200 nm
Climate:
cold and wet, with considerable mist and fog; spring and autumn are often windy
Terrain:
mostly barren rock
Elevation:
highest point:
Morne de la Grande Montagne 240 m
lowest point:
Atlantic Ocean 0 m
Natural resources:
fish, deepwater ports
Land use:
agricultural land:
8.7% (2018 est.)
arable land:
8.7% (2018 est.)
permanent crops:
0% (2018 est.)
permanent pasture:
0% (2018 est.)
forest:
12.5% (2018 est.)
other:
78.8% (2018 est.)
Irrigated land:
0 sq km (2022)
Population distribution:
most of the population is found on Saint Pierre Island; a small settlement is located on the north end of Miquelon Island
Natural hazards:
persistent fog throughout the year can be a maritime hazard
Geography - note:
vegetation scanty; the islands are actually part of the northern Appalachians along with Newfoundland','09437422e576367196dd8a5c094d83b054f3703c13b9a39fc80d49c6fb733789','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('238779c4b66395b07b0921e9ed5978e95f3b4a4dbd6014ec254d08a9476bbb79',2025,'VC','Saint Vincent and the Grenadines','geography',48,'Location:
Caribbean, islands between the Caribbean Sea and North Atlantic Ocean, north of Trinidad and Tobago
Geographic coordinates:
13 15 N, 61 12 W
Map references:
Central America and the Caribbean
Area:
total:
389 sq km (Saint Vincent 344 sq km)
land:
389 sq km
water:
0 sq km
comparison ranking:
total 204
Area - comparative:
twice the size of Washington, DC
Land boundaries:
total:
0 km
Coastline:
84 km
Maritime claims:
territorial sea:
12 nm
contiguous zone:
24 nm
exclusive economic zone:
200 nm
continental shelf:
200 nm
Climate:
tropical; little seasonal temperature variation; rainy season (May to November)
Terrain:
volcanic, mountainous
Elevation:
highest point:
La Soufriere 1,234 m
lowest point:
Caribbean Sea 0 m
Natural resources:
hydropower, arable land
Land use:
agricultural land:
25.6% (2018 est.)
arable land:
12.8% (2018 est.)
permanent crops:
7.7% (2018 est.)
permanent pasture:
5.1% (2018 est.)
forest:
68.7% (2018 est.)
other:
5.7% (2018 est.)
Irrigated land:
10 sq km (2012)
Population distribution:
most of the population is concentrated in and around the capital of Kingstown
Natural hazards:
hurricanes; La Soufriere volcano on the island of Saint Vincent is a constant threat
volcanism:
La Soufriere (1,234 m) on the island of Saint Vincent last erupted in 1979; the island of Saint Vincent is part of the volcanic island arc of the Lesser Antilles that extends from Saba in the north to Grenada in the south
Geography - note:
the administration of the islands of the Grenadines group is divided between Saint Vincent and the Grenadines and Grenada; Saint Vincent and the Grenadines is comprised of 32 islands and cays','621f9f8deefff0d12fd60489219003784e82c2be3cd7cf0a8b8140756da088b0','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('189180597ccf6e775702c0d2d2d7af9af64c202c808281d9c55fcf846b77ba64',2025,'WS','Samoa','geography',59,'Location:
Oceania, group of islands in the South Pacific Ocean, about halfway between Hawaii and New Zealand
Geographic coordinates:
13 35 S, 172 20 W
Map references:
Oceania
Area:
total:
2,831 sq km
land:
2,821 sq km
water:
10 sq km
comparison ranking:
total 177
Area - comparative:
slightly smaller than Rhode Island
Land boundaries:
total:
0 km
Coastline:
403 km
Maritime claims:
territorial sea:
12 nm
contiguous zone:
24 nm
exclusive economic zone:
200 nm
Climate:
tropical; rainy season (November to April), dry season (May to October)
Terrain:
two main islands (Savaii, Upolu) and several smaller islands and uninhabited islets; narrow coastal plain with volcanic, rugged mountains in interior
Elevation:
highest point:
Mount Silisili 1,857 m
lowest point:
Pacific Ocean 0 m
Natural resources:
hardwood forests, fish, hydropower
Land use:
agricultural land:
12.4% (2018 est.)
arable land:
2.8% (2018 est.)
permanent crops:
7.8% (2018 est.)
permanent pasture:
1.8% (2018 est.)
forest:
60.4% (2018 est.)
other:
27.2% (2018 est.)
Irrigated land:
0 sq km (2022)
Population distribution:
about three-quarters of the population lives on the island of Upolu
Natural hazards:
occasional cyclones; active volcanism
volcanism:
Savai’I Island (1,858 m), which last erupted in 1911, is historically active
Geography - note:
occupies an almost central position within Polynesia','a62cfecc9142af3b649fd5f81c1f6a054a4fb7a9e78e6bebe3c429bb14d93058','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8f4aecea0c55df59cab8d3afb8292936773179f8c199ec0c92345404c52d8aa9',2025,'SM','San Marino','geography',2,'Location:
Southern Europe, an enclave in central Italy
Geographic coordinates:
43 46 N, 12 25 E
Map references:
Europe
Area:
total:
61 sq km
land:
61 sq km
water:
0 sq km
comparison ranking:
total 228
Area - comparative:
about one-third the size of Washington, DC
Land boundaries:
total:
37 km
border countries (1):
Italy 37 km
Coastline:
0 km (landlocked)
Maritime claims:
none (landlocked)
Climate:
Mediterranean; mild to cool winters; warm, sunny summers
Terrain:
rugged mountains
Elevation:
highest point:
Monte Titano 739 m
lowest point:
Torrente Ausa 55 m
Natural resources:
building stone
Land use:
agricultural land:
16.7% (2018 est.)
arable land:
16.7% (2018 est.)
permanent crops:
0% (2018 est.)
permanent pasture:
0% (2018 est.)
forest:
0% (2018 est.)
other:
83.3% (2018 est.)
Irrigated land:
0 sq km (2022)
Natural hazards:
occasional earthquakes
Geography - note:
landlocked; an enclave of (completely surrounded by) Italy; smallest independent state in Europe after the Holy See and Monaco; dominated by the Apennine Mountains','3fb0f0adc4b01477e8670682898199c9e470b6db976ea7cb779965635b0c87f2','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cce3572088a86744df00ab43b88d7e0fded6d499a5a9d23b893279704adc2d0f',2025,'ST','Sao Tome and Principe','geography',13,'Location:
Central Africa, islands in the Gulf of Guinea, just north of the Equator, west of Gabon
Geographic coordinates:
1 00 N, 7 00 E
Map references:
Africa
Area:
total:
964 sq km
land:
964 sq km
water:
0 sq km
comparison ranking:
total 184
Area - comparative:
more than five times the size of Washington, DC
Land boundaries:
total:
0 km
Coastline:
209 km
Maritime claims:
territorial sea:
12 nm
exclusive economic zone:
200 nm
measured from claimed archipelagic baselines
Climate:
tropical; hot, humid; one rainy season (October to May)
Terrain:
volcanic, mountainous
Elevation:
highest point:
Pico de Sao Tome 2,024 m
lowest point:
Atlantic Ocean 0 m
Natural resources:
fish, hydropower
Land use:
agricultural land:
50.7% (2018 est.)
arable land:
9.1% (2018 est.)
permanent crops:
40.6% (2018 est.)
permanent pasture:
1% (2018 est.)
forest:
28.1% (2018 est.)
other:
21.2% (2018 est.)
Irrigated land:
100 sq km (2012)
Population distribution:
Sao Tome, the capital city, has roughly a quarter of the nation’s population; Santo Antonio is the largest town on Principe; the northern areas of both islands have the highest population densities as shown in this population distribution map
Natural hazards:
flooding
Geography - note:
the second-smallest African country (after the Seychelles); the two main islands form part of a chain of extinct volcanoes and both are mountainous','43556b8e730469d9b1a7139bb80e4a5377d60bfd9ac7d5b59a9ce92ca30de7db','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f2ab809aa148d29b0357f9769357fc8ca736ff475d267eba57f1e6dff4cc2b05',2025,'SA','Saudi Arabia','geography',24,'Location:
Middle East, bordering the Persian Gulf and the Red Sea, north of Yemen
Geographic coordinates:
25 00 N, 45 00 E
Map references:
Middle East
Area:
total:
2,149,690 sq km
land:
2,149,690 sq km
water:
0 sq km
comparison ranking:
total 14
Area - comparative:
slightly more than one-fifth the size of the US
Land boundaries:
total:
4,272 km
border countries (7):
Iraq 811 km; Jordan 731 km; Kuwait 221 km; Oman 658 km; Qatar 87 km; UAE 457 km; Yemen 1,307 km
Coastline:
2,640 km
Maritime claims:
territorial sea:
12 nm
contiguous zone:
18 nm
continental shelf:
not specified
Climate:
harsh, dry desert with great temperature extremes
Terrain:
mostly sandy desert
Elevation:
highest point:
As Sarawat range, 3,000 m
lowest point:
Persian Gulf 0 m
mean elevation:
665 m
Natural resources:
petroleum, natural gas, iron ore, gold, copper
Land use:
agricultural land:
80.7% (2018 est.)
arable land:
1.5% (2018 est.)
permanent crops:
0.1% (2018 est.)
permanent pasture:
79.1% (2018 est.)
forest:
0.5% (2018 est.)
other:
18.8% (2018 est.)
Irrigated land:
11,910 sq km (2018)
Major watersheds (area sq km): Indian Ocean drainage:
(Persian Gulf) Tigris and Euphrates (918,044 sq km)
Major aquifers:
Arabian Aquifer System
Population distribution:
historically a population that was mostly nomadic or semi-nomadic, the Saudi population has become more settled since petroleum was discovered in the 1930s; most of the economic activities - and with it the country’s population - is concentrated in a wide area across the middle of the peninsula, from Ad Dammam in the east, through Riyadh in the interior, to Mecca-Medina in the west near the Red Sea
Natural hazards:
frequent sand and dust storms
volcanism:
despite many volcanic formations, there has been little activity in the past few centuries; volcanoes include Harrat Rahat, Harrat Khaybar, Harrat Lunayyir, and Jabal Yar
Geography - note:
Saudi Arabia is the largest country in the world without a river; extensive coastlines on the Persian Gulf and Red Sea allow for considerable shipping (especially of crude oil) through the Persian Gulf and Suez Canal','7078eed9a822a0ddf714cb0fe7c9d2f625627eabad5ffbbfd7e3c58ffc9e3fc2','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('33cc62406880ec9272f3997a234768399394e8c6f370030754a6ee81909dbe3b',2025,'SN','Senegal','geography',37,'Location:
Western Africa, bordering the North Atlantic Ocean, between Guinea-Bissau and Mauritania
Geographic coordinates:
14 00 N, 14 00 W
Map references:
Africa
Area:
total:
196,722 sq km
land:
192,530 sq km
water:
4,192 sq km
comparison ranking:
total 88
Area - comparative:
slightly smaller than South Dakota; slightly larger than twice the size of Indiana
Land boundaries:
total:
2,684 km
border countries (5):
The Gambia 749 km; Guinea 363 km; Guinea-Bissau 341 km; Mali 489 km; Mauritania 742 km
Coastline:
531 km
Maritime claims:
territorial sea:
12 nm
contiguous zone:
24 nm
exclusive economic zone:
200 nm
continental shelf:
200 nm or to the edge of the continental margin
Climate:
tropical; hot, humid; rainy season (May to November) has strong southeast winds; dry season (December to April) dominated by hot, dry, harmattan wind
Terrain:
generally low, rolling, plains rising to foothills in southeast
Elevation:
highest point:
unnamed elevation 2.8 km southeast of Nepen Diaka 648 m
lowest point:
Atlantic Ocean 0 m
mean elevation:
69 m
Natural resources:
fish, phosphates, iron ore
Land use:
agricultural land:
46.8% (2018 est.)
arable land:
17.4% (2018 est.)
permanent crops:
0.3% (2018 est.)
permanent pasture:
29.1% (2018 est.)
forest:
43.8% (2018 est.)
other:
9.4% (2018 est.)
Irrigated land:
1,200 sq km (2012)
Major rivers (by length in km):
Senegal (shared with Guinea [s], Mali, and Mauritania [m]) - 1,641 km; Gambie (Gambia) (shared with Guinea [s] and The Gambia [m]) - 1,094 km
note – [s] after country name indicates river source; [m] after country name indicates river mouth
Major watersheds (area sq km): Atlantic Ocean drainage:
Senegal (456,397 sq km)
Major aquifers:
Senegalo-Mauritanian Basin
Population distribution:
the population is concentrated in the west, with Dakar anchoring a well-defined core area; approximately 70% of the population is rural as shown in this population distribution map
Natural hazards:
lowlands seasonally flooded; periodic droughts
Geography - note:
westernmost country on the African continent; The Gambia is almost an enclave within Senegal','1856fbe6329e5273b528c1af92aa9068690b064422ce7751153a2e37ff5a9e90','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3f89f926c4d0fe1761bad230a2da832cb8e52fc986ac45ce10a6ee69e0edff65',2025,'RS','Serbia','geography',49,'Location:
Southeastern Europe, between Macedonia and Hungary
Geographic coordinates:
44 00 N, 21 00 E
Map references:
Europe
Area:
total:
77,474 sq km
land:
77,474 sq km
water:
0 sq km
comparison ranking:
total 117
Area - comparative:
slightly smaller than South Carolina
Land boundaries:
total:
2,322 km
border countries (8):
Bosnia and Herzegovina 345 km; Bulgaria 344 km; Croatia 314 km; Hungary 164 km; Kosovo 366 km; North Macedonia 101 km; Montenegro 157 km; Romania 531 km
Coastline:
0 km (landlocked)
Maritime claims:
none (landlocked)
Climate:
in the north, continental climate (cold winters and hot, humid summers with well-distributed rainfall); in other parts, continental and Mediterranean climate (relatively cold winters with heavy snowfall and hot, dry summers and autumns)
Terrain:
extremely varied; to the north, rich fertile plains; to the east, limestone ranges and basins; to the southeast, ancient mountains and hills
Elevation:
highest point:
Midzor 2,169 m
lowest point:
Danube and Timok Rivers 35 m
mean elevation:
442 m
Natural resources:
oil, gas, coal, iron ore, copper, zinc, antimony, chromite, gold, silver, magnesium, pyrite, limestone, marble, salt, arable land
Land use:
agricultural land:
57.9% (2018 est.)
arable land:
37.7% (2018 est.)
permanent crops:
3.4% (2018 est.)
permanent pasture:
16.8% (2018 est.)
forest:
31.6% (2018 est.)
other:
10.5% (2018 est.)
Irrigated land:
520 sq km (2020)
Major rivers (by length in km):
Dunav (Danube) (shared with Germany [s], Austria, Slovakia, Czechia, Hungary, Croatia, Bulgaria, Ukraine, Moldova, and Romania [m]) - 2,888 km
note – [s] after country name indicates river source; [m] after country name indicates river mouth
Major watersheds (area sq km): Atlantic Ocean drainage:
(Black Sea) Danube (795,656 sq km)
Population distribution:
a fairly even distribution throughout most of the country, with urban areas attracting larger and denser populations
Natural hazards:
destructive earthquakes
Geography - note:
landlocked; controls one of the major land routes from Western Europe to Turkey and the Near East','6dc213bc1a48823e7cf575c20acacfbf049b6c2277bd5dfe501b8b2ddfa24c70','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3bfa19a7d08a7535b3398ab5199b80339e0afa3e85404c16cb37e86cf4032309',2025,'SC','Seychelles','geography',2,'Location:
archipelago in the Indian Ocean, northeast of Madagascar
Geographic coordinates:
4 35 S, 55 40 E
Map references:
Africa
Area:
total:
455 sq km
land:
455 sq km
water:
0 sq km
comparison ranking:
total 198
Area - comparative:
2.5 times the size of Washington, DC
Land boundaries:
total:
0 km
Coastline:
491 km
Maritime claims:
territorial sea:
12 nm
contiguous zone:
24 nm
exclusive economic zone:
200 nm
continental shelf:
200 nm or to the edge of the continental margin
Climate:
tropical marine; humid; cooler season during southeast monsoon (late May to September); warmer season during northwest monsoon (March to May)
Terrain:
Mahe Group is volcanic with a narrow coastal strip and rocky, hilly interior; others are relatively flat coral atolls, or elevated reefs; sits atop the submarine Mascarene Plateau
Elevation:
highest point:
Morne Seychellois 905 m
lowest point:
Indian Ocean 0 m
Natural resources:
fish, coconuts (copra), cinnamon trees
Land use:
agricultural land:
6.5% (2018 est.)
arable land:
2.2% (2018 est.)
permanent crops:
4.3% (2018 est.)
permanent pasture:
0% (2018 est.)
forest:
88.5% (2018 est.)
other:
5% (2018 est.)
Irrigated land:
3 sq km (2012)
Population distribution:
more than three-quarters of the population lives on the main island of Mahe; Praslin contains less than 10%; a smaller percent on La Digue and the outer islands as shown in this population distribution map
Natural hazards:
lies outside the cyclone belt, so severe storms are rare; occasional short droughts
Geography - note:
the smallest African country in terms of both area and population; the constitution of the Republic of Seychelles lists 155 islands: 42 granitic and 113 coralline; by far the largest island is Mahe, which is home to about 90% of the population and the site of the capital city of Victoria','c7d23f9f5915851a67aa5108f50762b8d637a01f0faf75791beabef7d8cae876','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c4a9714a2a4b4f94c7941bbac89ae62911326218200bb10c8b77a0d315206840',2025,'SL','Sierra Leone','geography',13,'Location:
Western Africa, bordering the North Atlantic Ocean, between Guinea and Liberia
Geographic coordinates:
8 30 N, 11 30 W
Map references:
Africa
Area:
total:
71,740 sq km
land:
71,620 sq km
water:
120 sq km
comparison ranking:
total 119
Area - comparative:
slightly smaller than South Carolina
Land boundaries:
total:
1,093 km
border countries (2):
Guinea 794 km; Liberia 299 km
Coastline:
402 km
Maritime claims:
territorial sea:
12 nm
contiguous zone:
24 nm
exclusive economic zone:
200 nm
continental shelf:
200 nm
Climate:
tropical; hot, humid; summer rainy season (May to December); winter dry season (December to April)
Terrain:
coastal belt of mangrove swamps, wooded hill country, upland plateau, mountains in east
Elevation:
highest point:
Loma Mansa (Bintimani) 1,948 m
lowest point:
Atlantic Ocean 0 m
mean elevation:
279 m
Natural resources:
diamonds, titanium ore, bauxite, iron ore, gold, chromite
Land use:
agricultural land:
56.2% (2018 est.)
arable land:
23.4% (2018 est.)
permanent crops:
2.3% (2018 est.)
permanent pasture:
30.5% (2018 est.)
forest:
37.5% (2018 est.)
other:
6.3% (2018 est.)
Irrigated land:
300 sq km (2012)
Major watersheds (area sq km): Atlantic Ocean drainage:
Niger (2,261,741 sq km)
Population distribution:
population clusters are found in the lower elevations of the south and west; the northern third of the country is less populated as shown on this population distribution map
Natural hazards:
dry, sand-laden harmattan winds blow from the Sahara (December to February); sandstorms, dust storms
Geography - note:
rainfall along the coast can reach 495 cm (195 inches) a year, making it one of the wettest places along coastal, western Africa','9f440e0b9364679688856c12b1cecbd3f9fb5cbfd138b27c6724ed313da9b547','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bf0f4a7f912fe475177eb623afd3800d19bbc797d20bbfda41cda61077a54586',2025,'SG','Singapore','geography',24,'Location:
Southeastern Asia, islands between Malaysia and Indonesia
Geographic coordinates:
1 22 N, 103 48 E
Map references:
Southeast Asia
Area:
total:
719 sq km
land:
709.2 sq km
water:
10 sq km
comparison ranking:
total 190
Area - comparative:
slightly more than 3.5 times the size of Washington, DC
Land boundaries:
total:
0 km
Coastline:
193 km
Maritime claims:
territorial sea:
3 nm
exclusive fishing zone:
within and beyond territorial sea, as defined in treaties and practice
Climate:
tropical; hot, humid, rainy; two distinct monsoon seasons - northeastern monsoon (December to March) and southwestern monsoon (June to September); inter-monsoon - frequent afternoon and early evening thunderstorms
Terrain:
lowlying, gently undulating central plateau
Elevation:
highest point:
Bukit Timah 166 m
lowest point:
Singapore Strait 0 m
Natural resources:
fish, deepwater ports
Land use:
agricultural land:
1% (2018 est.)
arable land:
0.9% (2018 est.)
permanent crops:
0.1% (2018 est.)
permanent pasture:
0% (2018 est.)
forest:
3.3% (2018 est.)
other:
95.7% (2018 est.)
Irrigated land:
0 sq km (2022)
Population distribution:
most of the urbanization is along the southern coast, with relatively dense population clusters found in the central areas
Natural hazards:
flash floods
Geography - note:
focal point for Southeast Asian sea routes; consists of about 60 islands, by far the largest of which is Pulau Ujong; land reclamation has removed many former islands and created a number of new ones','91a32b87e7aa93cac393fb8a23e734230764cfb7932df1dbefab09ad695eed12','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('723dfeaab79172c90ab9720a07d37355d21da338d1b2692b32e9f6277ea81601',2025,'SG','Singapore','geography',37,'Location:
Caribbean, located in the Leeward Islands (northern) group; Dutch part of the island of Saint Martin in the Caribbean Sea; Sint Maarten lies east of the US Virgin Islands
Geographic coordinates:
18 4 N, 63 4 W
Map references:
Central America and the Caribbean
Area:
total:
34 sq km
land:
34 sq km
water:
0 sq km
note:
Dutch part of the island of Saint Martin
comparison ranking:
total 235
Area - comparative:
one-fifth the size of Washington, DC
Land boundaries:
total:
16 km
border countries (1):
Saint Martin (France) 16 km
Coastline:
58.9 km (for entire island)
Maritime claims:
territorial sea:
12 nm
exclusive economic zone:
200 nm
Climate:
tropical marine climate, ameliorated by northeast trade winds, results in moderate temperatures; average rainfall of 150 cm/year; hurricane season stretches from July to November
Terrain:
low, hilly terrain, volcanic origin
Elevation:
highest point:
Mount Flagstaff 383 m
lowest point:
Caribbean Sea 0 m
Natural resources:
fish, salt
Population distribution:
most populous areas are Lower Prince’s Quarter (north of Philipsburg), followed closely by Cul de Sac
Natural hazards:
subject to hurricanes from July to November
Geography - note:
note 1:
the northern border is shared with the French overseas collectivity of Saint Martin; together, these two entities make up the smallest landmass in the world shared by two self-governing states
note 2:
Simpson Bay Lagoon (aka as Simson Bay Lagoon or The Great Pond) is one of the largest inland lagoons in the West Indies; the border between the French and Dutch halves of the island of Saint Martin runs across the center of the lagoon, which is shared by both of the island’s entities','94358968db64a59459b9c7d346ccb9127e334e27d96a8ad26fd66cb9bac3cb2a','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fa267786beca2d53d050a68d4be47264d2b3d5a46a0d451fca12d98e806d3e02',2025,'SK','Slovakia','geography',48,'Location:
Central Europe, south of Poland
Geographic coordinates:
48 40 N, 19 30 E
Map references:
Europe
Area:
total:
49,035 sq km
land:
48,105 sq km
water:
930 sq km
comparison ranking:
total 130
Area - comparative:
about one and a half times the size of Maryland; about twice the size of New Hampshire
Land boundaries:
total:
1,587 km
border countries (5):
Austria 105 km; Czechia 241 km; Hungary 627 km; Poland 517 km; Ukraine 97 km
Coastline:
0 km (landlocked)
Maritime claims:
none (landlocked)
Climate:
temperate; cool summers; cold, cloudy, humid winters
Terrain:
rugged mountains in the central and northern part and lowlands in the south
Elevation:
highest point:
Gerlachovsky Stit 2,655 m
lowest point:
Bodrok River 94 m
mean elevation:
458 m
Natural resources:
lignite, small amounts of iron ore, copper and manganese ore; salt; arable land
Land use:
agricultural land:
40.1% (2018 est.)
arable land:
28.9% (2018 est.)
permanent crops:
0.4% (2018 est.)
permanent pasture:
10.8% (2018 est.)
forest:
40.2% (2018 est.)
other:
19.7% (2018 est.)
Irrigated land:
211 sq km (2015)
Major rivers (by length in km):
Dunaj (Danube) (shared with Germany [s], Austria, Hungary, Croatia, Serbia, Bulgaria, Ukraine, Moldova, and Romania [m]) - 2,888 km
note – [s] after country name indicates river source; [m] after country name indicates river mouth
Major watersheds (area sq km): Atlantic Ocean drainage:
(Black Sea) Danube (795,656 sq km)
Population distribution:
a fairly even distribution throughout most of the country; slightly larger concentration in the west in proximity to the Czech border
Natural hazards:
flooding
Geography - note:
landlocked; most of the country is rugged and mountainous; the Tatra Mountains in the north are interspersed with many scenic lakes and valleys','90a1f6c7e0b24c3033b0a47c3d493ac232a2b34e7362524efaed8a1dbd647ed8','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b564d93e727199b83dd67dd52611c8c95d5c9d7e4c4e986c75febae14fd6f3d8',2025,'SI','Slovenia','geography',2,'Location:
south Central Europe, Julian Alps between Austria and Croatia
Geographic coordinates:
46 07 N, 14 49 E
Map references:
Europe
Area:
total:
20,273 sq km
land:
20,151 sq km
water:
122 sq km
comparison ranking:
total 154
Area - comparative:
slightly smaller than New Jersey
Land boundaries:
total:
1,211 km
border countries (4):
Austria 299 km; Croatia 600 km; Hungary 94 km; Italy 218 km
Coastline:
46.6 km
Maritime claims:
territorial sea:
12 nm
Climate:
Mediterranean climate on the coast, continental climate with mild to hot summers and cold winters in the plateaus and valleys to the east
Terrain:
a short southwestern coastal strip of Karst topography on the Adriatic; an alpine mountain region lies adjacent to Italy and Austria in the north; mixed mountains and valleys with numerous rivers to the east
Elevation:
highest point:
Triglav 2,864 m
lowest point:
Adriatic Sea 0 m
mean elevation:
492 m
Natural resources:
lignite, lead, zinc, building stone, hydropower, forests
Land use:
agricultural land:
22.8% (2018 est.)
arable land:
8.4% (2018 est.)
permanent crops:
1.3% (2018 est.)
permanent pasture:
13.1% (2018 est.)
forest:
62.3% (2018 est.)
other:
14.9% (2018 est.)
Irrigated land:
39 sq km (2020)
Major watersheds (area sq km): Atlantic Ocean drainage:
(Black Sea) Danube (795,656 sq km)
Population distribution:
a fairly even distribution throughout most of the country, with urban areas attracting larger and denser populations; pockets in the mountainous northwest exhibit less density than elsewhere
Natural hazards:
flooding; earthquakes
Geography - note:
despite its small size, this eastern Alpine country controls some of Europe’s major transit routes','8abe674f93573ef874fab24ad13852667919bffe21dea21e9637d39a97ab92fe','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d2bd19911635c75dbf26e55743a379ab9aa0afd96466cf6cf2e95114f6ce0731',2025,'SB','Solomon Islands','geography',13,'Location:
Oceania, group of islands in the South Pacific Ocean, east of Papua New Guinea
Geographic coordinates:
8 00 S, 159 00 E
Map references:
Oceania
Area:
total:
28,896 sq km
land:
27,986 sq km
water:
910 sq km
comparison ranking:
total 143
Area - comparative:
slightly smaller than Maryland
Land boundaries:
total:
0 km
Coastline:
5,313 km
Maritime claims:
territorial sea:
12 nm
exclusive economic zone:
200 nm
continental shelf:
200 nm
measured from claimed archipelagic baselines
Climate:
tropical monsoon; few temperature and weather extremes
Terrain:
mostly rugged mountains with some low coral atolls
Elevation:
highest point:
Mount Popomanaseu 2,335 m
lowest point:
Pacific Ocean 0 m
Natural resources:
fish, forests, gold, bauxite, phosphates, lead, zinc, nickel
Land use:
agricultural land:
3.9% (2018 est.)
arable land:
0.7% (2018 est.)
permanent crops:
2.9% (2018 est.)
permanent pasture:
0.3% (2018 est.)
forest:
78.9% (2018 est.)
other:
17.2% (2018 est.)
Irrigated land:
0 sq km (2022)
Population distribution:
most of the population lives along the coastal regions; about one in five live in urban areas, and of these some two-thirds reside in Honiara, the largest town and chief port
Natural hazards:
tropical cyclones, but rarely destructive; geologically active region with frequent earthquakes, tremors, and volcanic activity; tsunamis
volcanism:
Tinakula (851 m) has frequent eruption activity, while an eruption of Savo (485 m) could affect the capital Honiara on nearby Guadalcanal
Geography - note:
strategic location on sea routes between the South Pacific Ocean, the Solomon Sea, and the Coral Sea; Rennell Island, the southernmost in the Solomon Islands chain, is one of the world’s largest raised coral atolls; the island’s Lake Tegano, formerly a lagoon on the atoll, is the largest lake in the insular Pacific (15,500 hectares)','c670d246e09b3f5b139adfdd1eb78435078a051c162241be5ae357fb45db484f','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b2127937e22cd1c93e6afcc986d1752d473110555ccc50149e071b0702fcd077',2025,'SO','Somalia','geography',24,'Location:
Eastern Africa, bordering the Gulf of Aden and the Indian Ocean, east of Ethiopia
Geographic coordinates:
10 00 N, 49 00 E
Map references:
Africa
Area:
total:
637,657 sq km
land:
627,337 sq km
water:
10,320 sq km
comparison ranking:
total 46
Area - comparative:
almost five times the size of Alabama; slightly smaller than Texas
Land boundaries:
total:
2,385 km
border countries (3):
Djibouti 61 km; Ethiopia 1,640 km; Kenya 684 km
Coastline:
3,025 km
Maritime claims:
territorial sea:
200 nm; note: the US does not recognize this claim
exclusive economic zone:
200 nm
Climate:
principally desert; northeast monsoon (December to February), moderate temperatures in north and hot in south; southwest monsoon (May to October), torrid in the north and hot in the south, irregular rainfall, hot and humid periods (tangambili) between monsoons
Terrain:
mostly flat to undulating plateau rising to hills in north
Elevation:
highest point:
Mount Shimbiris 2,460 m
lowest point:
Indian Ocean 0 m
mean elevation:
410 m
Natural resources:
uranium and largely unexploited reserves of iron ore, tin, gypsum, bauxite, copper, salt, natural gas, likely oil reserves
Land use:
agricultural land:
70.3% (2018 est.)
arable land:
1.8% (2018 est.)
permanent crops:
0% (2018 est.)
permanent pasture:
68.5% (2018 est.)
forest:
10.6% (2018 est.)
other:
19.1% (2018 est.)
Irrigated land:
2,000 sq km (2012)
Major aquifers:
Ogaden-Juba Basin
Population distribution:
distribution varies greatly throughout the country; least densely populated areas are in the northeast and central regions, as well as areas along the Kenyan border; most populated areas are in and around the cities of Mogadishu, Marka, Boorama, Hargeysa, and Baidoa as shown on this population distribution map
Natural hazards:
recurring droughts; frequent dust storms over eastern plains in summer; floods during rainy season
Geography - note:
strategic location on Horn of Africa along southern approaches to Bab el Mandeb and route through Red Sea and Suez Canal','7f49ac93dc8b074eb0e7268a7a299624f4703bc44fbc5109c2f0e467c23ec73e','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('18c8d942df6ae9f4c4149bef706b6961c87800b9f207f1e3d0a5851e3ccafd32',2025,'ZA','South Africa','geography',36,'Location:
Southern Africa, at the southern tip of the continent of Africa
Geographic coordinates:
29 00 S, 24 00 E
Map references:
Africa
Area:
total:
1,219,090 sq km
land:
1,214,470 sq km
water:
4,620 sq km
note:
includes Prince Edward Islands (Marion Island and Prince Edward Island)
comparison ranking:
total 26
Area - comparative:
slightly less than twice the size of Texas
Land boundaries:
total:
5,244 km
border countries (6):
Botswana 1,969 km; Lesotho 1,106 km; Mozambique 496 km; Namibia 1,005 km; Eswatini 438 km; Zimbabwe 230 km
Coastline:
2,798 km
Maritime claims:
territorial sea:
12 nm
contiguous zone:
24 nm
exclusive economic zone:
200 nm
continental shelf:
200 nm or to edge of the continental margin
Climate:
mostly semiarid; subtropical along east coast; sunny days, cool nights
Terrain:
vast interior plateau rimmed by rugged hills and narrow coastal plain
Elevation:
highest point:
Ntheledi (Mafadi) 3,450 m
lowest point:
Atlantic Ocean 0 m
mean elevation:
1,034 m
Natural resources:
gold, chromium, antimony, coal, iron ore, manganese, nickel, phosphates, tin, rare earth elements, uranium, gem diamonds, platinum, copper, vanadium, salt, natural gas
note:
South Africa was the World’s leading chromite ore producer in 2022 with an output of 18,000 mt
Land use:
agricultural land:
79.4% (2018 est.)
arable land:
9.9% (2018 est.)
permanent crops:
0.3% (2018 est.)
permanent pasture:
69.2% (2018 est.)
forest:
7.6% (2018 est.)
other:
13% (2018 est.)
Irrigated land:
16,700 sq km (2012)
Major rivers (by length in km):
Orange (shared with Lesotho [s], and Namibia [m]) - 2,092 km; Limpoporivier (Limpopo) river source (shared with Botswana, Zimbabwe, and Mozambique [m]) - 1,800 km; Vaal [s] - 1,210 km
note – [s] after country name indicates river source; [m] after country name indicates river mouth
Major watersheds (area sq km): Atlantic Ocean drainage:
Orange (941,351 sq km)
Major aquifers:
Karoo Basin, Lower Kalahari-Stampriet Basin
Population distribution:
the population concentrated along the southern and southeastern coast, and inland around Pretoria; the eastern half of the country is more densely populated than the west as shown in this population distribution map
Natural hazards:
prolonged droughts
volcanism:
the volcano forming Marion Island in the Prince Edward Islands, which last erupted in 2004, is South Africa’s only active volcano
Geography - note:
South Africa completely surrounds Lesotho and almost completely surrounds Eswatini','c90e0b2c67dcc0222de66a6e864f0238ab98ec945040b1b30b7e4a8658c7a39b','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1b6c942355d11df0334d4b84190fa5a72d0027087b09b50024b54d3560365b55',2025,'SS','South Sudan','geography',3,'Location:
East-Central Africa; south of Sudan, north of Uganda and Kenya, west of Ethiopia
Geographic coordinates:
8 00 N, 30 00 E
Map references:
Africa
Area:
total:
644,329 sq km
comparison ranking:
total 44
Area - comparative:
more than four times the size of Georgia; slightly smaller than Texas
Land boundaries:
total:
6,018 km
border countries (6):
Central African Republic 1,055 km; Democratic Republic of the Congo 714 km; Ethiopia 1,299 km; Kenya 317 km; Sudan 2,158 km; Uganda 475 km
note:
South Sudan-Sudan boundary represents 1 January 1956 alignment; final alignment pending negotiations and demarcation; final sovereignty status of Abyei Area pending negotiations between South Sudan and Sudan
Coastline:
0 km (landlocked)
Maritime claims:
none (landlocked)
Climate:
hot with seasonal rainfall influenced by the annual shift of the Inter-Tropical Convergence Zone; rainfall heaviest in upland areas of the south and diminishes to the north
Terrain:
plains in the north and center rise to southern highlands along the border with Uganda and Kenya; the White Nile, flowing north out of the uplands of Central Africa, is the major geographic feature of the country; The Sudd (a name derived from floating vegetation that hinders navigation) is a large swampy area of more than 100,000 sq km fed by the waters of the White Nile that dominates the center of the country
Elevation:
highest point:
Kinyeti 3,187 m
lowest point:
White Nile 381 m
Natural resources:
hydropower, fertile agricultural land, gold, diamonds, petroleum, hardwoods, limestone, iron ore, copper, chromium ore, zinc, tungsten, mica, silver
Land use:
agricultural land:
45% (2018)
arable land:
4.4% (2018)
permanent pasture:
40.7% (2018)
forest:
11.3% (2018)
other:
43.5% (2018)
Irrigated land:
1,000 sq km (2012)
Major rivers (by length in km):
Nile (shared with Rwanda [s], Tanzania, Uganda, Sudan, and Egypt [m]) - 6,650 km
note – [s] after country name indicates river source; [m] after country name indicates river mouth
Major watersheds (area sq km): Atlantic Ocean drainage:
Congo (3,730,881 sq km), (Mediterranean Sea) Nile (3,254,853 sq km)
Population distribution:
clusters found in urban areas, particularly in the western interior and around the White Nile as shown in this population distribution map
Geography - note:
landlocked; The Sudd is a vast swamp in the north central region of South Sudan, formed by the White Nile, its size is variable but can reach some 15% of the country’s total area during the rainy season; it is one of the world’s largest wetlands','6efa97e5af3748aceb97b4620eefd8cadfc9ed8ff262774c7a27ccf396c029ad','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2edf7fd8c55ed429190b1ad0fa590b88b35ca0b69544cde39886d2e63c8055d5',2025,'SS','South Sudan','geography',14,'Location:
body of water between 60 degrees south latitude and Antarctica
Geographic coordinates:
60 00 S, 90 00 E (nominally), but the Southern Ocean has the unique distinction of being a large circumpolar body of water totally encircling the continent of Antarctica; this ring of water lies between 60 degrees south latitude and the coast of Antarctica and encompasses 360 degrees of longitude
Map references:
Antarctic Region
Area:
total:
21.96 million sq km
note:
includes Amundsen Sea, Bellingshausen Sea, part of the Drake Passage, Ross Sea, a small part of the Scotia Sea, Weddell Sea, and other tributary water bodies
Area - comparative:
slightly more than twice the size of the US
Coastline:
17,968 km
Climate:
sea temperatures vary from about 10 degrees Celsius to -2 degrees Celsius; cyclonic storms travel eastward around the continent and frequently are intense because of the temperature contrast between ice and open ocean; the ocean area from about latitude 40 south to the Antarctic Circle has the strongest average winds found anywhere on Earth; in winter the ocean freezes outward to 65 degrees south latitude in the Pacific sector and 55 degrees south latitude in the Atlantic sector, lowering surface temperatures well below 0 degrees Celsius; at some coastal points intense persistent drainage winds from the interior keep the shoreline ice-free throughout the winter
Ocean volume:
ocean volume:
71.8 million cu km
percent of World Ocean total volume:
5.4%
Major ocean currents:
the cold, clockwise-flowing Antarctic Circumpolar Current (West Wind Drift; 21,000 km long) moves perpetually eastward around the continent and is the world’s largest and strongest ocean current, transporting 130 million cubic meters of water per second - 100 times the flow of all the world’s rivers; it is also the only current that flows all the way around the planet and connects the Atlantic, Pacific, and Indian Oceans; the cold Antarctic Coastal Current (East Wind Drift) is the southernmost current in the world, flowing westward and parallel to the Antarctic coastline
Elevation:
highest point:
sea level
lowest point:
southern end of the South Sandwich Trench -7,434 m unnamed deep
mean depth:
-3,270 m
ocean zones:
Composed of water and in a fluid state, the oceans are delimited differently than the solid continents. Oceans are divided into three zones based on depth and light level. Although some sea creatures depend on light to live, others can do without it. Sunlight entering the water may travel about 1,000 m into the oceans under the right conditions, but there is rarely any significant light beyond 200 m.
The upper 200 m (656 ft) of oceans is called the euphotic, or “sunlight,” zone. This zone contains the vast majority of commercial fisheries and is home to many protected marine mammals and sea turtles. Only a small amount of light penetrates beyond this depth.
The zone between 200 m (656 ft) and 1,000 m (3,280 ft) is usually referred to as the “twilight” zone, but is officially the dysphotic zone. In this zone, the intensity of light rapidly dissipates as depth increases. Such a minuscule amount of light penetrates beyond a depth of 200 m that photosynthesis is no longer possible.
The aphotic, or “midnight,” zone exists in depths below 1,000 m (3,280 ft). Sunlight does not penetrate to these depths and the zone is bathed in darkness.
Natural resources:
probable large oil and gas fields on the continental margin; manganese nodules, possible placer deposits, sand and gravel, fresh water as icebergs; squid, whales, and seals - none exploited; krill, fish
Natural hazards:
huge icebergs with drafts up to several hundred meters; smaller bergs and iceberg fragments; sea ice (generally 0.5 to 1 m thick) with sometimes dynamic short-term variations and with large annual and interannual variations; deep continental shelf floored by glacial deposits varying widely over short distances; high winds and large waves much of the year; ship icing, especially May-October; most of region is remote from sources of search and rescue
Geography - note:
the major chokepoint is the Drake Passage between South America and Antarctica; the Polar Front (Antarctic Convergence) is the best natural definition of the northern extent of the Southern Ocean; it is a distinct region at the middle of the Antarctic Circumpolar Current that separates the cold polar surface waters to the south from the warmer waters to the north; the Front and the Current extend entirely around Antarctica, reaching south of 60 degrees south near New Zealand and near 48 degrees south in the far South Atlantic coinciding with the path of the maximum westerly winds','60559dc957ef87a0ad4128581676ba5005da48ebd4ab7e69f758a984d59c8dbb','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d75db71a7d119ffea3ba117e27155f0bbf2e27f7ee0388e66d7ce29ade76883d',2025,'ES','Spain','geography',20,'Location:
Southwestern Europe, bordering the Mediterranean Sea, North Atlantic Ocean, Bay of Biscay, and Pyrenees Mountains; southwest of France
Geographic coordinates:
40 00 N, 4 00 W
Map references:
Europe
Area:
total:
505,370 sq km
land:
498,980 sq km
water:
6,390 sq km
note:
there are two autonomous cities - Ceuta and Melilla - and 17 autonomous communities including Balearic Islands and Canary Islands, and three small Spanish possessions off the coast of Morocco - Islas Chafarinas, Penon de Alhucemas, and Penon de Velez de la Gomera
comparison ranking:
total 54
Area - comparative:
almost five times the size of Kentucky; slightly more than twice the size of Oregon
Land boundaries:
total:
1,952.7 km
border countries (5):
Andorra 63 km; France 646 km; Gibraltar 1.2 km; Portugal 1,224 km; Morocco (Ceuta) 8 km and Morocco (Melilla) 10.5 km
note:
an additional 75-meter border segment exists between Morocco and the Spanish exclave of Penon de Velez de la Gomera
Coastline:
4,964 km
Maritime claims:
territorial sea:
12 nm
contiguous zone:
24 nm
exclusive economic zone:
200 nm (applies only to the Atlantic Ocean)
Climate:
temperate; clear, hot summers in interior, more moderate and cloudy along coast; cloudy, cold winters in interior, partly cloudy and cool along coast
Terrain:
large, flat to dissected plateau surrounded by rugged hills; Pyrenees Mountains in north
Elevation:
highest point:
Pico de Teide (Tenerife) on Canary Islands 3,718 m
lowest point:
Atlantic Ocean 0 m
mean elevation:
660 m
Natural resources:
coal, lignite, iron ore, copper, lead, zinc, uranium, tungsten, mercury, pyrites, magnesite, fluorspar, gypsum, sepiolite, kaolin, potash, hydropower, arable land
Land use:
agricultural land:
54.1% (2018 est.)
arable land:
24.9% (2018 est.)
permanent crops:
9.1% (2018 est.)
permanent pasture:
20.1% (2018 est.)
forest:
36.8% (2018 est.)
other:
9.1% (2018 est.)
Irrigated land:
37,593 sq km (2020)
Major rivers (by length in km):
Tagus river source (shared with Portugal [m]) - 1,006
note – [s] after country name indicates river source; [m] after country name indicates river mouth
Population distribution:
with the notable exception of Madrid, Sevilla, and Zaragoza, the largest urban agglomerations are found along the Mediterranean and Atlantic coasts; numerous smaller cities are spread throughout the interior reflecting Spain’s agrarian heritage; very dense settlement around the capital of Madrid, as well as the port city of Barcelona
Natural hazards:
periodic droughts, occasional flooding
volcanism:
volcanic activity in the Canary Islands, located off Africa’s northwest coast; Teide (3,715 m) has been deemed a Decade Volcano by the International Association of Volcanology and Chemistry of the Earth’s Interior, worthy of study due to its explosive history and close proximity to human populations; La Palma (2,426 m), which last erupted in 1971, is the most active of the Canary Islands volcanoes; Lanzarote is the only other historically active volcano
Geography - note:
strategic location along approaches to Strait of Gibraltar; Spain controls a number of territories in northern Morocco including the enclaves of Ceuta and Melilla, and the islands of Penon de Velez de la Gomera, Penon de Alhucemas, and Islas Chafarinas; Spain’s Canary Islands are one of four North Atlantic archipelagos that make up Macaronesia; the others are Azores (Portugal), Madeira (Portugal), and Cabo Verde','5a812e3ce9d35df4bd2f9217d796b1db1dd2fc924bef7563718302a34b857b77','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e0780c1adc926781eb323fb9d99f881144e714e35b7fa41d09b2e62b4741706a',2025,'ES','Spain','geography',33,'Location:
Southeastern Asia, group of reefs and islands in the South China Sea, about two-thirds of the way from southern Vietnam to the southern Philippines
Geographic coordinates:
8 38 N, 111 55 E
Map references:
Southeast Asia
Area:
total:
5 sq km less than
land:
5 sq km less than
water:
0 sq km
note:
includes 100 or so islets, coral reefs, and sea mounts scattered over an area of nearly 410,000 sq km (158,000 sq mi) of the central South China Sea
comparison ranking:
total 250
Area - comparative:
land area is about seven times the size of the National Mall in Washington, DC
Land boundaries:
total:
0 km
Coastline:
926 km
Maritime claims:
NA
Climate:
tropical
Terrain:
small, flat islands, islets, cays, and reefs
Elevation:
highest point:
unnamed location on Southwest Cay 6 m
lowest point:
South China Sea 0 m
Natural resources:
fish, guano, undetermined oil and natural gas potential
Land use:
other:
100% (2018 est.)
Natural hazards:
typhoons; numerous reefs and shoals pose a serious maritime hazard
Geography - note:
strategically located near several primary shipping lanes in the central South China Sea; includes numerous small islands, atolls, shoals, and coral reefs','3cc15418b2340009bd45fbc0319b6846f42e68a4daa99976680c379ce91802eb','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('84529b03acd275aa12c5ca44c3bcf9ef975e6fffb8268656f803d3e23f535ee6',2025,'LK','Sri Lanka','geography',41,'Location:
Southern Asia, island in the Indian Ocean, south of India
Geographic coordinates:
7 00 N, 81 00 E
Map references:
Asia
Area:
total:
65,610 sq km
land:
64,630 sq km
water:
980 sq km
comparison ranking:
total 122
Area - comparative:
slightly larger than West Virginia
Land boundaries:
total:
0 km
Coastline:
1,340 km
Maritime claims:
territorial sea:
12 nm
contiguous zone:
24 nm
exclusive economic zone:
200 nm
continental shelf:
200 nm or to the edge of the continental margin
Climate:
tropical monsoon; northeast monsoon (December to March); southwest monsoon (June to October)
Terrain:
mostly low, flat to rolling plain; mountains in south-central interior
Elevation:
highest point:
Pidurutalagala 2,524 m
lowest point:
Indian Ocean 0 m
mean elevation:
228 m
Natural resources:
limestone, graphite, mineral sands, gems, phosphates, clay, hydropower, arable land
Land use:
agricultural land:
43.5% (2018 est.)
arable land:
20.7% (2018 est.)
permanent crops:
15.8% (2018 est.)
permanent pasture:
7% (2018 est.)
forest:
29.4% (2018 est.)
other:
27.1% (2018 est.)
Irrigated land:
5,700 sq km (2012)
Population distribution:
the population is primarily concentrated within a broad wet zone in the southwest, urban centers along the eastern coast, and on the Jaffna Peninsula in the north
Natural hazards:
occasional cyclones and tornadoes
Geography - note:
strategic location near major Indian Ocean sea lanes; Adam’s Bridge is a chain of limestone shoals between the southeastern coast of India and the northwestern coast of Sri Lanka; geological evidence suggests that this 50-km long Bridge once connected India and Sri Lanka; ancient records seem to indicate that a foot passage was possible between the two land masses until the 15th century when the land bridge broke up in a cyclone','762bcde0422625b1c2b7bb30a6a03abe55a82d7ff8dac5c01916c324a5e7f77a','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5fbcf3961d54b495fcde8c684967b62afb3b8d736e68e0b4f6b889fcb4278c98',2025,'SD','Sudan','geography',54,'Location:
north-eastern Africa, bordering the Red Sea, between Egypt and Eritrea
Geographic coordinates:
15 00 N, 30 00 E
Map references:
Africa
Area:
total:
1,861,484 sq km
land:
1,731,671 sq km
water:
129,813 sq km
comparison ranking:
total 17
Area - comparative:
slightly less than one-fifth the size of the US
Land boundaries:
total:
6,819 km
border countries (7):
Central African Republic 174 km; Chad 1,403 km; Egypt 1,276 km; Eritrea 682 km; Ethiopia 744 km; Libya 382 km; South Sudan 2,158 km
note:
Sudan-South Sudan boundary represents 1 January 1956 alignment; final alignment pending negotiations and demarcation; final sovereignty status of Abyei region pending negotiations between Sudan and South Sudan
Coastline:
853 km
Maritime claims:
territorial sea:
12 nm
contiguous zone:
18 nm
continental shelf:
200-m depth or to the depth of exploitation
Climate:
hot and dry; arid desert; rainy season varies by region (April to November)
Terrain:
generally flat, featureless plain; desert dominates the north
Elevation:
highest point:
Jabal Marrah 3,042 m
lowest point:
Red Sea 0 m
mean elevation:
568 m
Natural resources:
petroleum; small reserves of iron ore, copper, chromium ore, zinc, tungsten, mica, silver, gold; hydropower
Land use:
agricultural land:
100% (2018 est.)
arable land:
15.7% (2018 est.)
permanent crops:
0.2% (2018 est.)
permanent pasture:
84.2% (2018 est.)
forest:
0% (2018 est.)
other:
0% (2018 est.)
Irrigated land:
15,666 sq km (2020)
Major rivers (by length in km):
An Nīl (Nile) (shared with Rwanda [s], Tanzania, Uganda, South Sudan, and Egypt [m]) - 6,650 km; Blue Nile river mouth (shared with Ethiopia [s]) - 1,600 km
note – [s] after country name indicates river source; [m] after country name indicates river mouth
Major watersheds (area sq km): Atlantic Ocean drainage:
(Mediterranean Sea) Nile (3,254,853 sq km)
Internal (endorheic basin) drainage:
Lake Chad (2,497,738 sq km)
Major aquifers:
Nubian Aquifer System, Sudd Basin (Umm Ruwaba Aquifer)
Population distribution:
with the exception of a ribbon of settlement that corresponds to the banks of the Nile, northern Sudan, which extends into the dry Sahara, is sparsely populated; more abundant vegetation and broader access to water increases population distribution in the south extending habitable range along nearly the entire border with South Sudan; sizeable areas of population are found around Khartoum, southeast between the Blue and White Nile Rivers, and throughout South Darfur as shown on this population distribution map
Natural hazards:
dust storms and periodic persistent droughts
Geography - note:
the Nile is Sudan’s primary water source; its major tributaries, the White Nile and the Blue Nile, meet at Khartoum to form the River Nile which flows northward through Egypt to the Mediterranean Sea','ca58d1e3f0c02a68a94670a4fc7d12d141f23cae1cb043396380c5007cff0324','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('60bcaa8505a0f2838fe1bc3dabd1b4f3bc6cae1996077d34ce1c1e2a39ce6f91',2025,'SR','Suriname','geography',2,'Location:
Northern South America, bordering the North Atlantic Ocean, between French Guiana and Guyana
Geographic coordinates:
4 00 N, 56 00 W
Map references:
South America
Area:
total:
163,820 sq km
land:
156,000 sq km
water:
7,820 sq km
comparison ranking:
total 92
Area - comparative:
slightly larger than Georgia
Land boundaries:
total:
1,907 km
border countries (3):
Brazil 515 km; French Guiana 556 km; Guyana 836 km
Coastline:
386 km
Maritime claims:
territorial sea:
12 nm
exclusive economic zone:
200 nm
Climate:
tropical; moderated by trade winds
Terrain:
mostly rolling hills; narrow coastal plain with swamps
Elevation:
highest point:
Juliana Top 1,230 m
lowest point:
unnamed location in the coastal plain -2 m
mean elevation:
246 m
Natural resources:
timber, hydropower, fish, kaolin, shrimp, bauxite, gold, and small amounts of nickel, copper, platinum, iron ore
Land use:
agricultural land:
0.5% (2018 est.)
arable land:
0.4% (2018 est.)
permanent crops:
0% (2018 est.)
permanent pasture:
0.1% (2018 est.)
forest:
94.6% (2018 est.)
other:
4.9% (2018 est.)
Irrigated land:
600 sq km (2020)
Major watersheds (area sq km): Atlantic Ocean drainage:
Amazon (6,145,186 sq km)
Population distribution:
population concentrated along the nothern coastal strip; the remainder of the country is sparsely populated
Natural hazards:
flooding
Geography - note:
smallest independent country on South American continent; mostly tropical rain forest; great diversity of flora and fauna that, for the most part, is increasingly threatened by new development; relatively small population, mostly along the coast','838ee32cce3545afe8e22099b3335ce48a42e724a975cccc285e175fc81bcb5b','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a753ce06f9838e9a6387c4d3cbb3770153cd82731da13fdb0e0011c13c0896ec',2025,'SR','Suriname','geography',13,'Location:
Northern Europe, islands between the Arctic Ocean, Barents Sea, Greenland Sea, and Norwegian Sea, north of Norway
Geographic coordinates:
78 00 N, 20 00 E
Map references:
Arctic Region
Area:
total:
62,045 sq km
land:
62,045 sq km
water:
0 sq km
note:
includes Spitsbergen and Bjornoya (Bear Island)
comparison ranking:
total 125
Area - comparative:
slightly smaller than West Virginia
Land boundaries:
total:
0 km
Coastline:
3,587 km
Maritime claims:
territorial sea:
12 nm
contiguous zone:
24 nm
continental shelf:
extends to depth of exploitation
exclusive fishing zone:
200 nm
Climate:
arctic, tempered by warm North Atlantic Current; cool summers, cold winters; North Atlantic Current flows along west and north coasts of Spitsbergen, keeping water open and navigable most of the year
Terrain:
rugged mountains; much of the upland areas are ice covered; west coast clear of ice about half the year; fjords along west and north coasts
Elevation:
highest point:
Newtontoppen 1,717 m
lowest point:
Arctic Ocean 0 m
Natural resources:
coal, iron ore, copper, zinc, phosphate, wildlife, fish
Land use:
agricultural land:
0% (2018 est.)
other:
100% (2018 est.)
Population distribution:
the small population is primarily concentrated on the island of Spitsbergen in a handful of settlements on the south side of the Isfjorden, with Longyearbyen being the largest
Natural hazards:
ice floes often block the entrance to Bellsund (a transit point for coal export) on the west coast and occasionally make parts of the northeastern coast inaccessible to maritime traffic
Geography - note:
northernmost part of the Kingdom of Norway; consists of nine main islands; glaciers and snowfields cover 60% of the total area; Spitsbergen Island is the site of the Svalbard Global Seed Vault, a seed repository established by the Global Crop Diversity Trust and the Norwegian Government','b965e88f1d5f6972b9a2a39574d19d7ad12d74a4dbf13035b474683e4221947e','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('47105d1afdff03974fd8ba8fb47bf63ac968e1e17f883474b31eead0bef2ef44',2025,'SE','Sweden','geography',24,'Location:
Northern Europe, bordering the Baltic Sea, Gulf of Bothnia, Kattegat, and Skagerrak, between Finland and Norway
Geographic coordinates:
62 00 N, 15 00 E
Map references:
Europe
Area:
total:
450,295 sq km
land:
410,335 sq km
water:
39,960 sq km
comparison ranking:
total 58
Area - comparative:
almost three times the size of Georgia; slightly larger than California
Land boundaries:
total:
2,211 km
border countries (2):
Finland 545 km; Norway 1,666 km
Coastline:
3,218 km
Maritime claims:
territorial sea:
12 nm (adjustments made to return a portion of straits to high seas)
exclusive economic zone:
agreed boundaries or midlines
continental shelf:
200-m depth or to the depth of exploitation
Climate:
temperate in south with cold, cloudy winters and cool, partly cloudy summers; subarctic in north
Terrain:
mostly flat or gently rolling lowlands; mountains in west
Elevation:
highest point:
Kebnekaise South 2,100 m
lowest point:
reclaimed bay of Lake Hammarsjon, near Kristianstad -2.4 m
mean elevation:
320 m
Natural resources:
iron ore, copper, lead, zinc, gold, silver, tungsten, uranium, arsenic, feldspar, timber, hydropower
Land use:
agricultural land:
7.5% (2018 est.)
arable land:
6.4% (2018 est.)
permanent crops:
0% (2018 est.)
permanent pasture:
1.1% (2018 est.)
forest:
68.7% (2018 est.)
other:
23.8% (2018 est.)
Irrigated land:
519 sq km (2013)
Major lakes (area sq km):
fresh water lake(s):
Vanern - 5,580 sq km; Vattern - 1,910 sq km; Malaren - 1,140 sq km
Population distribution:
most Swedes live in the south where the climate is milder and there is better connectivity to mainland Europe; population clusters are found all along the Baltic coast in the east; the interior areas of the north remain sparsely populated
Natural hazards:
ice floes in the surrounding waters, especially in the Gulf of Bothnia, can interfere with maritime traffic
Geography - note:
strategic location along Danish Straits linking Baltic and North Seas; Sweden has almost 100,000 lakes, the largest of which, Vanern, is the third largest in Europe','efb9145f820256d071e24bee852e0d77857ecc2e5b5eab6028737234e3c03c25','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2c1757c71cff617ede5e30489a1d8dca2d5ad8c177d7ffea86c33c7b8435aef0',2025,'CH','Switzerland','geography',37,'Location:
Central Europe, east of France, north of Italy
Geographic coordinates:
47 00 N, 8 00 E
Map references:
Europe
Area:
total:
41,277 sq km
land:
39,997 sq km
water:
1,280 sq km
comparison ranking:
total 135
Area - comparative:
slightly less than twice the size of New Jersey
Land boundaries:
total:
1,770 km
border countries (5):
Austria 158 km; France 525 km; Italy 698 km; Liechtenstein 41 km; Germany 348 km
Coastline:
0 km (landlocked)
Maritime claims:
none (landlocked)
Climate:
temperate, but varies with altitude; cold, cloudy, rainy/snowy winters; cool to warm, cloudy, humid summers with occasional showers
Terrain:
mostly mountains (Alps in south, Jura in northwest) with a central plateau of rolling hills, plains, and large lakes
Elevation:
highest point:
Dufourspitze 4,634 m
lowest point:
Lake Maggiore 195 m
mean elevation:
1,350 m
Natural resources:
hydropower potential, timber, salt
Land use:
agricultural land:
38.7% (2018 est.)
arable land:
10.2% (2018 est.)
permanent crops:
0.6% (2018 est.)
permanent pasture:
27.9% (2018 est.)
forest:
31.5% (2018 est.)
other:
29.8% (2018 est.)
Irrigated land:
327 sq km (2016)
Major lakes (area sq km):
fresh water lake(s):
Lake Constance (shared with Germany and Austria) - 540 sq km; Lake Geneva (shared with France) - 580 sq km
Major rivers (by length in km):
Rhein (Rhine) river source (shared with Germany, France, and Netherlands [m]) - 1,233 km
note – [s] after country name indicates river source; [m] after country name indicates river mouth
Major watersheds (area sq km): Atlantic Ocean drainage:
Rhine-Maas (198,735 sq km), (Black Sea) Danube (795,656 sq km), (Adriatic Sea) Po (76,997 sq km), (Mediterranean Sea) Rhone (100,543 sq km)
Population distribution:
population distribution corresponds to elevation with the northern and western areas far more heavily populated; the higher Alps of the south limit settlement
Natural hazards:
avalanches, landslides; flash floods
Geography - note:
landlocked; crossroads of northern and southern Europe; along with southeastern France, northern Italy, and southwestern Austria, has the highest elevations in the Alps','9630e558e897b83d3ab6671895711d3a75149b4cad6e0b8568b23bc2069fc7f8','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('eb8779b38ff0c8c73dce1dc2ccfe440cb036d0878cbdca5d8626f9adb0f7ec7a',2025,'CH','Switzerland','geography',50,'Location:
Middle East, bordering the Mediterranean Sea, between Lebanon and Turkey
Geographic coordinates:
35 00 N, 38 00 E
Map references:
Middle East
Area:
total:
187,437 sq km
land:
185,887 sq km
water:
1,550 sq km
note:
includes 1,295 sq km of Israeli-occupied territory
comparison ranking:
total 89
Area - comparative:
slightly more than 1.5 times the size of Pennsylvania
Land boundaries:
total:
2,363 km
border countries (5):
Iraq 599 km; Israel 83 km; Jordan 379 km; Lebanon 403 km; Turkey 899 km
Coastline:
193 km
Maritime claims:
territorial sea:
12 nm
contiguous zone:
24 nm
Climate:
mostly desert; hot, dry, sunny summers (June to August) and mild, rainy winters (December to February) along coast; cold weather with snow or sleet periodically in Damascus
Terrain:
primarily semiarid and desert plateau; narrow coastal plain; mountains in west
Elevation:
highest point:
Mount Hermon (Jabal a-Shayk) 2,814 m
lowest point:
Yarmuk River -66 m
mean elevation:
514 m
Natural resources:
petroleum, phosphates, chrome and manganese ores, asphalt, iron ore, rock salt, marble, gypsum, hydropower
Land use:
agricultural land:
75.8% (2018 est.)
arable land:
25.4% (2018 est.)
permanent crops:
5.8% (2018 est.)
permanent pasture:
44.6% (2018 est.)
forest:
2.7% (2018 est.)
other:
21.5% (2018 est.)
Irrigated land:
13,100 sq km (2013)
Major rivers (by length in km):
Euphrates (shared with Turkey [s], Iran, and Iraq [m]) - 3,596 km; Tigris (shared with Turkey, Iran, and Iraq [m]) - 1,950 km
note – [s] after country name indicates river source; [m] after country name indicates river mouth
Major watersheds (area sq km): Indian Ocean drainage:
(Persian Gulf) Tigris and Euphrates (918,044 sq km)
Population distribution:
significant population density along the Mediterranean coast; larger concentrations found in the major cities of Damascus, Aleppo (the country’s largest city), and Hims (Homs); more than half of the population lives in the coastal plain, the province of Halab, and the Euphrates River valley
note:
the ongoing civil war has altered the population distribution
Natural hazards:
dust storms, sandstorms
volcanism:
Syria’s two historically active volcanoes, Es Safa and an unnamed volcano near the Turkish border have not erupted in centuries
Geography - note:
the capital of Damascus - located at an oasis fed by the Barada River - is thought to be one of the world’s oldest continuously inhabited cities; there are 42 Israeli settlements and civilian land use sites in the Israeli-controlled Golan Heights (2017)','cb7ce105887cd56a7aa702b4305b5135548f61fd79b76fe8c50a4ea336d378ee','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e8f65120bdfea5903b485e7c342df88e59446f25cb42ff123937608cd22d34fa',2025,'TJ','Tajikistan','geography',4,'Location:
Central Asia, west of China, south of Kyrgyzstan
Geographic coordinates:
39 00 N, 71 00 E
Map references:
Asia
Area:
total:
144,100 sq km
land:
141,510 sq km
water:
2,590 sq km
comparison ranking:
total 96
Area - comparative:
slightly smaller than Wisconsin
Land boundaries:
total:
4,130 km
border countries (4):
Afghanistan 1,357 km; China 477 km; Kyrgyzstan 984 km; Uzbekistan 1,312 km
Coastline:
0 km (landlocked)
Maritime claims:
none (landlocked)
Climate:
mid-latitude continental, hot summers, mild winters; semiarid to polar in Pamir Mountains
Terrain:
mountainous region dominated by the Alay Mountains in the north and the Pamirs in the southeast; western Fergana Valley in north, Kofirnihon and Vakhsh Valleys in southwest
Elevation:
highest point:
Qullai Somoniyon 7,495 m
lowest point:
Syr Darya (Sirdaryo) 300 m
mean elevation:
3,186 m
Natural resources:
hydropower, some petroleum, uranium, mercury, brown coal, lead, zinc, antimony, tungsten, silver, gold
Land use:
agricultural land:
34.7% (2018 est.)
arable land:
6.1% (2018 est.)
permanent crops:
0.9% (2018 est.)
permanent pasture:
27.7% (2018 est.)
forest:
2.9% (2018 est.)
other:
62.4% (2018 est.)
Irrigated land:
5,690 sq km (2020)
Major rivers (by length in km):
Syr Darya (shared with Kyrgyzstan [s], Uzbekistan, and Kazakhstan [m]) - 3,078 km; Amu Darya river source (shared with Turkmenistan, Afghanistan, and Uzbekistan [m]) - 2,620 km
note
– [s] after country name indicates river source; [m] after country name indicates river mouth
Major watersheds (area sq km): Internal (endorheic basin) drainage:
Tarim Basin (1,152,448 sq km),
(Aral Sea Basin)
Amu Darya (534,739 sq km), Syr Darya (782,617 sq km)
Population distribution:
the country’s population is concentrated at lower elevations, with perhaps as much as 90% of the people living in valleys; overall density increases from east to west
Natural hazards:
earthquakes; floods
Geography - note:
landlocked; highest point, Qullai Ismoili Somoni (formerly Communism Peak), was the tallest mountain in the former USSR','90ba812b180935d5838022677c5ea547b6a977d4973a8da2d9f590734824ebc1','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('da5477c5df66c7466ddc0582634ef7132f21a198ec965320b828aa7874bffedf',2025,'TJ','Tajikistan','geography',16,'Location:
Eastern Africa, bordering the Indian Ocean, between Kenya and Mozambique
Geographic coordinates:
6 00 S, 35 00 E
Map references:
Africa
Area:
total:
947,300 sq km
land:
885,800 sq km
water:
61,500 sq km
note:
includes the islands of Mafia, Pemba, and Zanzibar
comparison ranking:
total 32
Area - comparative:
more than six times the size of Georgia; slightly larger than twice the size of California
Land boundaries:
total:
4,161 km
border countries (8):
Burundi 589 km; Democratic Republic of the Congo 479 km; Kenya 775 km; Malawi 512 km; Mozambique 840 km; Rwanda 222 km; Uganda 391 km; Zambia 353 km
Coastline:
1,424 km
Maritime claims:
territorial sea:
12 nm
exclusive economic zone:
200 nm
Climate:
varies from tropical along coast to temperate in highlands
Terrain:
plains along coast; central plateau; highlands in north, south
Elevation:
highest point:
Kilimanjaro (highest point in Africa) 5,895 m
lowest point:
Indian Ocean 0 m
mean elevation:
1,018 m
Natural resources:
hydropower, tin, phosphates, iron ore, coal, diamonds, gemstones (including tanzanite, found only in Tanzania), gold, natural gas, nickel
Land use:
agricultural land:
43.7% (2018 est.)
arable land:
14.3% (2018 est.)
permanent crops:
2.3% (2018 est.)
permanent pasture:
27.1% (2018 est.)
forest:
37.3% (2018 est.)
other:
19% (2018 est.)
Irrigated land:
1,840 sq km (2012)
Major lakes (area sq km):
fresh water lake(s):
Lake Victoria (shared with Uganda and Kenya) - 62,940 sq km; Lake Tanganyika (shared with Democratic Republic of Congo, Burundi, and Zambia) - 32,000 sq km; Lake Malawi (shared with Mozambique and Malawi) - 22,490
salt water lake(s):
Lake Rukwa - 5,760 sq km
Major rivers (by length in km):
Nile (shared with Rwanda [s], Uganda, South Sudan, Sudan, and Egypt [m]) - 6,650 km
note
– [s] after country name indicates river source; [m] after country name indicates river mouth
Major watersheds (area sq km): Atlantic Ocean drainage:
Congo (3,730,881 sq km),
(Mediterranean Sea)
Nile (3,254,853 sq km)
Indian Ocean drainage:
Zambezi (1,332,412 sq km)
Population distribution:
the largest and most populous East African country; population distribution is extremely uneven, but greater population clusters occur in the northern half of country and along the east coast as shown in this population distribution map
Natural hazards:
flooding on the central plateau during the rainy season; drought
volcanism:
limited volcanic activity; Ol Doinyo Lengai (2,962 m) has emitted lava in recent years; other historically active volcanoes include Kieyo and Meru
Geography - note:
Kilimanjaro is the highest point in Africa and one of only three mountain ranges on the continent that has glaciers (the others are Mount Kenya [in Kenya] and the Ruwenzori Mountains [on the Uganda-Democratic Republic of the Congo border]); Tanzania is bordered by three of the largest lakes on the continent: Lake Victoria (the world’s second-largest freshwater lake) in the north, Lake Tanganyika (the world’s second deepest) in the west, and Lake Nyasa (Lake Malawi) in the southwest','af7fcf0c5e46679ee1ac28b16dff6be61897e3edb82879a6e22532496fc0d90d','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('493a05db8e01c1935b5d94b46565f67fdb379d9ce6d7f6a793be6303b4ca27e0',2025,'TH','Thailand','geography',28,'Location:
Southeastern Asia, bordering the Andaman Sea and the Gulf of Thailand, southeast of Burma
Geographic coordinates:
15 00 N, 100 00 E
Map references:
Southeast Asia
Area:
total:
513,120 sq km
land:
510,890 sq km
water:
2,230 sq km
comparison ranking:
total 53
Area - comparative:
about three times the size of Florida; slightly more than twice the size of Wyoming
Land boundaries:
total:
5,673 km
border countries (4):
Burma 2,416 km; Cambodia 817 km; Laos 1,845 km; Malaysia 595 km
Coastline:
3,219 km
Maritime claims:
territorial sea:
12 nm
exclusive economic zone:
200 nm
continental shelf:
200-m depth or to the depth of exploitation
Climate:
tropical; rainy, warm, cloudy southwest monsoon (mid-May to September); dry, cool northeast monsoon (November to mid-March); southern isthmus always hot and humid
Terrain:
central plain; Khorat Plateau in the east; mountains elsewhere
Elevation:
highest point:
Doi Inthanon 2,565 m
lowest point:
Gulf of Thailand 0 m
mean elevation:
287 m
Natural resources:
tin, rubber, natural gas, tungsten, tantalum, timber, lead, fish, gypsum, lignite, fluorite, arable land
Land use:
agricultural land:
41.2% (2018 est.)
arable land:
30.8% (2018 est.)
permanent crops:
8.8% (2018 est.)
permanent pasture:
1.6% (2018 est.)
forest:
37.2% (2018 est.)
other:
21.6% (2018 est.)
Irrigated land:
64,150 sq km (2012)
Major lakes (area sq km):
salt water lake(s):
Thalesap Songkhla - 1,290 sq km
Major rivers (by length in km):
Mae Nam Khong (Mekong) (shared with China [s], Burma, Laos, Cambodia, and Vietnam [m]) - 4,350 km; Salween (shared with China [s] and Burma [m]) - 3,060 km; Mun - 1,162 km
note
– [s] after country name indicates river source; [m] after country name indicates river mouth
Major watersheds (area sq km):
Indian Ocean drainage: Salween (271,914 sq km)
Pacific Ocean drainage:
Mekong (805,604 sq km)
Population distribution:
highest population density is found in and around Bangkok; significant population clusters found througout large parts of the country, particularly north and northeast of Bangkok and in the extreme southern region of the country
Natural hazards:
land subsidence in Bangkok area resulting from the depletion of the water table; droughts
Geography - note:
controls only land route from Asia to Malaysia and Singapore; ideas for the construction of a canal across the Kra Isthmus that would create a bypass to the Strait of Malacca and shorten shipping times around Asia continue to be discussed','25889bba1d4ab5d3bfb1fc18c430cf24774d3ec064a63c9d194adfa70d77b251','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5883bd0b4413f7982f998f01dc3469aa877d746b0959d7e9ded8dee5cc4c77b4',2025,'TL','Timor-Leste','geography',2,'Location:
Southeastern Asia, northwest of Australia in the Lesser Sunda Islands at the eastern end of the Indonesian archipelago; note - Timor-Leste includes the eastern half of the island of Timor, the Oecussi (Ambeno) region on the northwest portion of the island of Timor, and the islands of Pulau Atauro and Pulau Jaco
Geographic coordinates:
8 50 S, 125 55 E
Map references:
Southeast Asia
Area:
total:
14,874 sq km
land:
14,874 sq km
water:
0 sq km
comparison ranking:
total 159
Area - comparative:
slightly larger than Connecticut; almost half the size of Maryland
Land boundaries:
total:
253 km
border countries (1):
Indonesia 253 km
Coastline:
706 km
Maritime claims:
territorial sea:
12 nm
contiguous zone:
24 nm
exclusive fishing zone:
200 nm
Climate:
tropical; hot, humid; distinct rainy and dry seasons
Terrain:
mountainous
Elevation:
highest point:
Foho Tatamailau 2,963 m
lowest point:
Timor Sea, Savu Sea, and Banda Sea 0 m
Natural resources:
gold, petroleum, natural gas, manganese, marble
Land use:
agricultural land:
25.1% (2018 est.)
arable land:
10.1% (2018 est.)
permanent crops:
4.9% (2018 est.)
permanent pasture:
10.1% (2018 est.)
forest:
49.1% (2018 est.)
other:
25.8% (2018 est.)
Irrigated land:
350 sq km (2012)
Population distribution:
most of the population concentrated in the western third of the country, particularly around Dili
Natural hazards:
floods and landslides are common; earthquakes; tsunamis; tropical cyclones
Geography - note:
Timor comes from the Malay word for “east”; the island of Timor is part of the Malay Archipelago and is the largest and easternmost of the Lesser Sunda Islands; the district of Oecussi is an exclave separated from Timor-Leste proper by Indonesia; Timor-Leste has the unique distinction of being the only Asian country located completely in the Southern Hemisphere','cd6ebbd767167dbf2d8aa029975686ca79bad85dcf28cc2e4b09fbad0c5f7e14','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f2176b53b548f346f96fff1a3fbe1c8cf5da779667dda2dd472482da17a7971c',2025,'TG','Togo','geography',13,'Location:
Western Africa, bordering the Bight of Benin, between Benin and Ghana
Geographic coordinates:
8 00 N, 1 10 E
Map references:
Africa
Area:
total:
56,785 sq km
land:
54,385 sq km
water:
2,400 sq km
comparison ranking:
total 126
Area - comparative:
slightly smaller than West Virginia
Land boundaries:
total:
1,880 km
border countries (3):
Benin 651 km; Burkina Faso 131 km; Ghana 1,098 km
Coastline:
56 km
Maritime claims:
territorial sea: 30 nm; note:
the US does not recognize this claim
exclusive economic zone:
200 nm
Climate:
tropical; hot, humid in south; semiarid in north
Terrain:
gently rolling savanna in north; central hills; southern plateau; low coastal plain with extensive lagoons and marshes
Elevation:
highest point:
Mont Agou 986 m
lowest point:
Atlantic Ocean 0 m
mean elevation:
236 m
Natural resources:
phosphates, limestone, marble, arable land
Land use:
agricultural land:
67.4% (2018 est.)
arable land:
45.2% (2018 est.)
permanent crops:
3.8% (2018 est.)
permanent pasture:
18.4% (2018 est.)
forest:
4.9% (2018 est.)
other:
27.7% (2018 est.)
Irrigated land:
70 sq km (2012)
Major watersheds (area sq km): Atlantic Ocean drainage:
Volta (410,991 sq km)
Population distribution:
one of the more densely populated African nations with most of the population residing in rural communities, density is highest in the south on or near the Atlantic coast as shown in this population distribution map
Natural hazards:
hot, dry harmattan wind can reduce visibility in north during winter; periodic droughts
Geography - note:
the country’s length allows it to stretch through six distinct geographic regions; climate varies from tropical to savanna','342355ddc41ffa3845f849d6a268f991831c71b20f1da983c5306728b018fca2','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('68656c07db9ff1892d1b5667e6e3a8983126869b348470c0bd95a0febb745155',2025,'TK','Tokelau','geography',25,'Location:
Oceania, group of three atolls in the South Pacific Ocean, about one-half of the way from Hawaii to New Zealand
Geographic coordinates:
9 00 S, 172 00 W
Map references:
Oceania
Area:
total:
12 sq km
land:
12 sq km
water:
0 sq km
comparison ranking:
total 241
Area - comparative:
about 17 times the size of the National Mall in Washington, DC
Land boundaries:
total:
0 km
Coastline:
101 km
Maritime claims:
territorial sea:
12 nm
exclusive economic zone:
200 nm
Climate:
tropical; moderated by trade winds (April to November)
Terrain:
low-lying coral atolls enclosing large lagoons
Elevation:
highest point:
unnamed location 5 m
lowest point:
Pacific Ocean 0 m
Natural resources:
Fisheries
Land use:
agricultural land:
60% (2018 est.)
arable land:
0% (2018 est.)
permanent crops:
60% (2018 est.)
permanent pasture:
0% (2018 est.)
forest:
0% (2018 est.)
other:
40% (2018 est.)
Irrigated land:
0 sq km (2022)
Population distribution:
the country’s small population is fairly evenly distributed amongst the three atolls
Natural hazards:
lies in Pacific cyclone belt
Geography - note:
consists of three atolls (Atafu, Fakaofo, Nukunonu), each with a lagoon surrounded by a number of reef-bound islets of varying length and rising to over 3 m above sea level','c1f5f80d543b29d8b01479395493671f0cb29eac0a8d90edb8655339cca26249','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3f03e14f7a8f2367833c583e1da15148b8fe185edab7919b61f88eff223ce41d',2025,'TO','Tonga','geography',35,'Location:
Oceania, archipelago in the South Pacific Ocean, about two-thirds of the way from Hawaii to New Zealand
Geographic coordinates:
20 00 S, 175 00 W
Map references:
Oceania
Area:
total:
747 sq km
land:
717 sq km
water:
30 sq km
comparison ranking:
total 189
Area - comparative:
four times the size of Washington, DC
Land boundaries:
total:
0 km
Coastline:
419 km
Maritime claims:
territorial sea:
12 nm
exclusive economic zone:
200 nm
continental shelf:
200-m depth or to the depth of exploitation
Climate:
tropical; modified by trade winds; warm season (December to May), cool season (May to December)
Terrain:
mostly flat islands with limestone bedrock formed from uplifted coral formation; others have limestone overlying volcanic rock
Elevation:
highest point:
Kao Volcano on Kao Island 1,046 m
lowest point:
Pacific Ocean 0 m
Natural resources:
arable land, fish
Land use:
agricultural land:
43.1% (2018 est.)
arable land:
22.2% (2018 est.)
permanent crops:
15.3% (2018 est.)
permanent pasture:
5.6% (2018 est.)
forest:
12.5% (2018 est.)
other:
44.4% (2018 est.)
Irrigated land:
0 sq km (2022)
Population distribution:
over two-thirds of the population lives on the island of Tongatapu; only 45 of the nation’s 171 islands are occupied
Natural hazards:
cyclones (October to April); earthquakes and volcanic activity on Fonuafo’ou
volcanism:
moderate volcanic activity; Fonualei (180 m) has shown frequent activity in recent years, while Niuafo’ou (260 m), which last erupted in 1985, has forced evacuations; other historically active volcanoes include Late and Tofua
Geography - note:
the western islands (making up the Tongan Volcanic Arch) are all of volcanic origin; the eastern islands are nonvolcanic and are composed of coral limestone and sand','b16594ecbd5dba9e2ed93a5e629ca9eda0542e656e60d952c1c3de836c0cb344','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ef0cb18c2689d846652462900b51e79220d74e73ee452f572eb40a13b120836c',2025,'TT','Trinidad and Tobago','geography',46,'Location:
Caribbean, islands between the Caribbean Sea and the North Atlantic Ocean, northeast of Venezuela
Geographic coordinates:
11 00 N, 61 00 W
Map references:
Central America and the Caribbean
Area:
total:
5,128 sq km
land:
5,128 sq km
water:
0 sq km
comparison ranking:
total 173
Area - comparative:
slightly smaller than Delaware
Land boundaries:
total:
0 km
Coastline:
362 km
Maritime claims:
territorial sea:
12 nm
contiguous zone:
24 nm
exclusive economic zone:
200 nm
continental shelf:
200 nm or to the outer edge of the continental margin measured from claimed archipelagic baselines
Climate:
tropical; rainy season (June to December)
Terrain:
mostly plains with some hills and low mountains
Elevation:
highest point:
El Cerro del Aripo 940 m
lowest point:
Caribbean Sea 0 m
mean elevation:
83 m
Natural resources:
petroleum, natural gas, asphalt
Land use:
agricultural land:
10.6% (2018 est.)
arable land:
4.9% (2018 est.)
permanent crops:
4.3% (2018 est.)
permanent pasture:
1.4% (2018 est.)
forest:
44% (2018 est.)
other:
45.4% (2018 est.)
Irrigated land:
70 sq km (2012)
Population distribution:
population on Trinidad is concentrated in the western half of the island, on Tobago in the southern half
Natural hazards:
outside usual path of hurricanes and other tropical storms
Geography - note:
Pitch Lake, on Trinidad’s southwestern coast, is the world’s largest natural reservoir of asphalt','977394cafd03ed8d802a6d04abcd5a1ab0650e6808eda59131f16db2bd23b220','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c6b3f66f85abbc943f67ba866419f04d1e1e65074f014f732e8bff0698497b6d',2025,'TN','Tunisia','geography',2,'Location:
Northern Africa, bordering the Mediterranean Sea, between Algeria and Libya
Geographic coordinates:
34 00 N, 9 00 E
Map references:
Africa
Area:
total:
163,610 sq km
land:
155,360 sq km
water:
8,250 sq km
comparison ranking:
total 93
Area - comparative:
slightly larger than Georgia
Land boundaries:
total:
1,495 km
border countries (2):
Algeria 1,034 km; Libya 461 km
Coastline:
1,148 km
Maritime claims:
territorial sea:
12 nm
contiguous zone:
24 nm
exclusive economic zone:
12 nm
Climate:
temperate in north with mild, rainy winters and hot, dry summers; desert in south
Terrain:
mountains in north; hot, dry central plain; semiarid south merges into the Sahara
Elevation:
highest point:
Jebel ech Chambi 1,544 m
lowest point:
Shatt al Gharsah -17 m
mean elevation:
246 m
Natural resources:
petroleum, phosphates, iron ore, lead, zinc, salt
Land use:
agricultural land:
64.8% (2018 est.)
arable land:
18.3% (2018 est.)
permanent crops:
15.4% (2018 est.)
permanent pasture:
31.1% (2018 est.)
forest:
6.6% (2018 est.)
other:
28.6% (2018 est.)
Irrigated land:
3,920 sq km (2013)
Major aquifers:
North Western Sahara Aquifer System
Population distribution:
the overwhelming majority of the population is located in the northern half of the country; the south remains largely underpopulated as shown in this population distribution map
Natural hazards:
flooding; earthquakes; droughts
Geography - note:
strategic location in central Mediterranean; Malta and Tunisia are discussing the commercial exploitation of the continental shelf between their countries, particularly for oil exploration','48069ece2d74a22577b8254f4da5a336f95b894250660c46878880de2bcf5b54','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cf79ab4a9f105a7efae0bf5282c6f2f4d78011a42296312205d57158acef5a34',2025,'TN','Tunisia','geography',15,'Location:
Southeastern Europe and Southwestern Asia (that portion of Turkey west of the Bosporus is geographically part of Europe), bordering the Black Sea, between Bulgaria and Georgia, and bordering the Aegean Sea and the Mediterranean Sea, between Greece and Syria
Geographic coordinates:
39 00 N, 35 00 E
Map references:
Middle East
Area:
total:
783,562 sq km
land:
769,632 sq km
water:
13,930 sq km
comparison ranking:
total 38
Area - comparative:
slightly larger than Texas
Land boundaries:
total:
2,816 km
border countries (8):
Armenia 311 km; Azerbaijan 17 km; Bulgaria 223 km; Georgia 273 km; Greece 192 km; Iran 534 km; Iraq 367 km; Syria 899 km
Coastline:
7,200 km
Maritime claims:
territorial sea:
6 nm in the Aegean Sea
exclusive economic zone: in Black Sea only:
to the maritime boundary agreed upon with the former USSR
12 nm in Black Sea and in Mediterranean Sea
Climate:
temperate; hot, dry summers with mild, wet winters; harsher in interior
Terrain:
high central plateau (Anatolia); narrow coastal plain; several mountain ranges
Elevation:
highest point:
Mount Ararat 5,137 m
lowest point:
Mediterranean Sea 0 m
mean elevation:
1,132 m
Natural resources:
coal, iron ore, copper, chromium, antimony, mercury, gold, barite, borate, celestite (strontium), emery, feldspar, limestone, magnesite, marble, perlite, pumice, pyrites (sulfur), clay, arable land, hydropower
Land use:
agricultural land:
49.7% (2018 est.)
arable land:
26.7% (2018 est.)
permanent crops:
4% (2018 est.)
permanent pasture:
19% (2018 est.)
forest:
14.9% (2018 est.)
other:
35.4% (2018 est.)
Irrigated land:
52,150 sq km (2020)
Major lakes (area sq km):
fresh water lake(s):
Lake Beysehir - 650 sq km; Lake Egridir - 520 sq km
salt water lake(s):
Lake Van - 3,740 sq km; Lake Tuz - 1,640 sq km;
Major rivers (by length in km):
Euphrates river source (shared with Syria, Iran, and Iraq [m]) - 3,596 km; Tigris river source (shared with Syria, Iran, and Iraq [m]) - 1,950 km
note
– [s] after country name indicates river source; [m] after country name indicates river mouth
Major watersheds (area sq km): Indian Ocean drainage:
(Persian Gulf)
Tigris and Euphrates (918,044 sq km)
Population distribution:
the most densely populated area is found around the Bosporus in the northwest where 20% of the population lives in Istanbul; with the exception of Ankara, urban centers remain small and scattered throughout the interior of Anatolia; an overall pattern of peripheral development exists, particularly along the Aegean Sea coast in the west, and the Tigris and Euphrates River systems in the southeast
Natural hazards:
severe earthquakes, especially in northern Turkey, along an arc extending from the Sea of Marmara to Lake Van; landslides; flooding
volcanism:
limited volcanic activity; its three historically active volcanoes; Ararat, Nemrut Dagi, and Tendurek Dagi have not erupted since the 19th century or earlier
Geography - note:
strategic location controlling the Turkish Straits (Bosporus, Sea of Marmara, Dardanelles) that link the Black and Aegean Seas; the 3% of Turkish territory north of the Straits lies in Europe and goes by the names of European Turkey, Eastern Thrace, or Turkish Thrace; the 97% of the country in Asia is referred to as Anatolia; Istanbul, which straddles the Bosporus, is the only metropolis in the world located on two continents; Mount Ararat, the legendary landing place of Noah’s ark, is in the far eastern portion of the country','4bbe5973eb599f6dbbfd6df4c73af69eaa13316bd9158d3f0281866bb8cc2247','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('af16bc9be03c0e762c71a8938e431c928ad671486e0418c56f45c64e83f09031',2025,'TM','Turkmenistan','geography',28,'Location:
Central Asia, bordering the Caspian Sea, between Iran and Kazakhstan
Geographic coordinates:
40 00 N, 60 00 E
Map references:
Asia
Area:
total:
488,100 sq km
land:
469,930 sq km
water:
18,170 sq km
comparison ranking:
total 55
Area - comparative:
slightly more than three times the size of Georgia; slightly larger than California
Land boundaries:
total:
4,158 km
border countries (4):
Afghanistan 804 km; Iran 1,148 km; Kazakhstan 413 km; Uzbekistan 1,793 km
Coastline:
0 km (landlocked); note - Turkmenistan borders the Caspian Sea (1,768 km)
Maritime claims:
none (landlocked)
Climate:
subtropical desert
Terrain:
flat-to-rolling sandy desert with dunes rising to mountains in the south; low mountains along border with Iran; borders Caspian Sea in west
Elevation:
highest point:
Gora Ayribaba 3,139 m
lowest point:
Vpadina Akchanaya (Sarygamysh Koli is a lake in northern Turkmenistan with a water level that fluctuates above and below the elevation of Vpadina Akchanaya, the lake has dropped as low as -110 m) -81 m
mean elevation:
230 m
Natural resources:
petroleum, natural gas, sulfur, salt
Land use:
agricultural land:
72% (2018 est.)
arable land:
4.1% (2018 est.)
permanent crops:
0.1% (2018 est.)
permanent pasture:
67.8% (2018 est.)
forest:
8.8% (2018 est.)
other:
19.2% (2018 est.)
Irrigated land:
19,950 sq km (2012)
Major lakes (area sq km):
salt water lake(s):
Caspian Sea (shared with Iran, Azerbaijan, Russia, and Kazakhstan) - 374,000 sq km
Major rivers (by length in km):
Amu Darya (shared with Tajikistan [s], Afghanistan, and Uzbekistan [m]) - 2,620 km
note
– [s] after country name indicates river source; [m] after country name indicates river mouth
Major watersheds (area sq km): Internal (endorheic basin) drainage:
(Aral Sea basin)
Amu Darya (534,739 sq km)
Population distribution:
the most densely populated areas are the southern, eastern, and northeastern oases; approximately 50% of the population lives in and around the capital of Ashgabat
Natural hazards:
earthquakes; mudslides; droughts; dust storms; floods
Geography - note:
landlocked; the western and central low-lying desolate portions of the country make up the great Garagum (Kara-Kum) desert, which occupies over 80% of the country; eastern part is plateau','d66f1de7fef7edbff84de587729863e0b5e3a960d823c1c21fb8012a69f1a019','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('19ae1df92ced3a93c773aa549f72a73f31310ef8f52dee257858aad247a7469b',2025,'TC','Turks and Caicos Islands','geography',40,'Location:
two island groups in the North Atlantic Ocean, southeast of The Bahamas, north of Haiti; note - although the Turks and Caicos Islands do not border the Caribbean Sea, geopolitically they are often designated as being Caribbean
Geographic coordinates:
21 45 N, 71 35 W
Map references:
Central America and the Caribbean
Area:
total:
948 sq km
land:
948 sq km
water:
0 sq km
comparison ranking:
total 185
Area - comparative:
2.5 times the size of Washington, DC
Land boundaries:
total:
0 km
Coastline:
389 km
Maritime claims:
territorial sea:
12 nm
exclusive fishing zone:
200 nm
Climate:
tropical; marine; moderated by trade winds; sunny and relatively dry
Terrain:
low, flat limestone; extensive marshes and mangrove swamps
Elevation:
highest point:
Blue Hill on Providenciales and Flamingo Hill on East Caicos 48 m
lowest point:
Caribbean Sea 0 m
Natural resources:
spiny lobster, conch
Land use:
agricultural land:
1.1% (2018 est.)
arable land:
1.1% (2018 est.)
permanent crops:
0% (2018 est.)
permanent pasture:
0% (2018 est.)
forest:
36.2% (2018 est.)
other:
62.7% (2018 est.)
Irrigated land:
0 sq km (2022)
Population distribution:
eight of the thirty islands are inhabited; the island of Providenciales is the most populated, but the most densely populated is Grand Turk
Natural hazards:
frequent hurricanes
Geography - note:
include eight large islands and numerous smaller cays, islets, and reefs; only two of the Caicos Islands and six of the Turks group are inhabited','b9920be8587651d4ede82624ab0391e7daad3da13c5ac9bd29ec27bce64c6a07','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4c89190f3d8d540fd678b58c5041dd607778e01a809e6305e9f361a8c2fe38ed',2025,'TV','Tuvalu','geography',51,'Location:
Oceania, island group consisting of nine coral atolls in the South Pacific Ocean, about half way from Hawaii to Australia
Geographic coordinates:
8 00 S, 178 00 E
Map references:
Oceania
Area:
total:
26 sq km
land:
26 sq km
water:
0 sq km
comparison ranking:
total 237
Area - comparative:
0.1 times the size of Washington, DC
Land boundaries:
total:
0 km
Coastline:
24 km
Maritime claims:
territorial sea:
12 nm
contiguous zone:
24 nm
exclusive economic zone:
200 nm
Climate:
tropical; moderated by easterly trade winds (March to November); westerly gales and heavy rain (November to March)
Terrain:
low-lying and narrow coral atolls
Elevation:
highest point:
unnamed location 5 m
lowest point:
Pacific Ocean 0 m
mean elevation:
2 m
Natural resources:
fish, coconut (copra)
Land use:
agricultural land:
60% (2018 est.)
arable land:
0% (2018 est.)
permanent crops:
60% (2018 est.)
permanent pasture:
0% (2018 est.)
forest:
33.3% (2018 est.)
other:
6.7% (2018 est.)
Irrigated land:
0 sq km (2022)
Population distribution:
over half of the population resides on the atoll of Funafuti
Natural hazards:
severe tropical storms are usually rare, but in 1997 there were three cyclones; low levels of islands make them sensitive to changes in sea level
Geography - note:
one of the smallest and most remote countries on Earth; six of the nine coral atolls - Nanumea, Nui, Vaitupu, Nukufetau, Funafuti, and Nukulaelae - have lagoons open to the ocean; Nanumaya and Niutao have landlocked lagoons; Niulakita does not have a lagoon','0e6973120723af07e1625a156da4cda048380d41268d63345896e3c361aee1c1','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a8eafa93658846e7c945efb39fd5577135a6559dcdde2a08bda932bfa6812ce7',2025,'UG','Uganda','geography',2,'Location:
East-Central Africa, west of Kenya, east of the Democratic Republic of the Congo
Geographic coordinates:
1 00 N, 32 00 E
Map references:
Africa
Area:
total:
241,038 sq km
land:
197,100 sq km
water:
43,938 sq km
comparison ranking:
total 81
Area - comparative:
slightly more than two times the size of Pennsylvania; slightly smaller than Oregon
Land boundaries:
total:
2,729 km
border countries (5):
Democratic Republic of the Congo 877 km; Kenya 814 km; Rwanda 172 km; South Sudan 475 km; Tanzania 391 km
Coastline:
0 km (landlocked)
Maritime claims:
none (landlocked)
Climate:
tropical; generally rainy with two dry seasons (December to February, June to August); semiarid in northeast
Terrain:
mostly plateau with rim of mountains
Elevation:
highest point:
Margherita Peak on Mount Stanley 5,110 m
lowest point:
Albert Nile 614 m
Natural resources:
copper, cobalt, hydropower, limestone, salt, arable land, gold
Land use:
agricultural land:
71.2% (2018 est.)
arable land:
34.3% (2018 est.)
permanent crops:
11.3% (2018 est.)
permanent pasture:
25.6% (2018 est.)
forest:
14.5% (2018 est.)
other:
14.3% (2018 est.)
Irrigated land:
105 sq km (2013)
Major lakes (area sq km):
fresh water lake(s):
Lake Victoria (shared with Tanzania and Kenya) - 62,940 sq km; Lake Albert (shared with Democratic Republic of Congo) - 5,590 sq km; Lake Kyoga - 4,430 sq km; Lake Edward (shared with Democratic Republic of Congo) - 2,150 sq km
Major rivers (by length in km):
Nile (shared with Rwanda [s], Tanzania, South Sudan, Sudan, and Egypt [m]) - 6,650 km
note
– [s] after country name indicates river source; [m] after country name indicates river mouth
Major watersheds (area sq km): Atlantic Ocean drainage:
Congo (3,730,881 sq km),
(Mediterranean Sea)
Nile (3,254,853 sq km)
Population distribution:
population density is relatively high in comparison to other African nations; most of the population is concentrated in the central and southern parts of the country, particularly along the shores of Lake Victoria and Lake Albert; the northeast is least populated as shown in this population distribution map
Natural hazards:
droughts; floods; earthquakes; landslides; hailstorms
Geography - note:
landlocked; fertile, well-watered country with many lakes and rivers; Lake Victoria, the world’s largest tropical lake and the second largest fresh water lake, is shared among three countries: Kenya, Tanzania, and Uganda','c61ad510910eb5d80c151c723fefa3d5630692a4a85c4f3ea7c581b6c55fee36','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('01b4409db6a8da5ed6c372339f88039a9fc123a3228fccd711e060c8d0c57a0f',2025,'UA','Ukraine','geography',15,'Location:
Eastern Europe, bordering the Black Sea, between Poland, Romania, and Moldova in the west and Russia in the east
Geographic coordinates:
49 00 N, 32 00 E
Map references:
AsiaEurope
Area:
total:
603,550 sq km
land:
579,330 sq km
water:
24,220 sq km
note:
approximately 43,133 sq km, or about 7.1% of Ukraine’s area, is Russian occupied; the seized area includes all of Crimea and about one-third of both Luhans’k and Donets’k oblasts
comparison ranking:
total 48
Area - comparative:
almost four times the size of Georgia; slightly smaller than Texas
Land boundaries:
total:
5,581 km
border countries (6):
Belarus 1,111 km; Hungary 128 km; Moldova 1,202 km; Poland 498 km; Romania 601 km; Russia 1,944 km, Slovakia 97 km
Coastline:
2,782 km
Maritime claims:
territorial sea:
12 nm
exclusive economic zone:
200 nm
continental shelf:
200 m or to the depth of exploitation
Climate:
temperate continental; Mediterranean only on the southern Crimean coast; precipitation disproportionately distributed, highest in west and north, lesser in east and southeast; winters vary from cool along the Black Sea to cold farther inland; warm summers across the greater part of the country, hot in the south
Terrain:
mostly fertile plains (steppes) and plateaus, with mountains found only in the west (the Carpathians) or in the extreme south of the Crimean Peninsula
Elevation:
highest point:
Hora Hoverla 2,061 m
lowest point:
Black Sea 0 m
mean elevation:
175 m
Natural resources:
iron ore, coal, manganese, natural gas, oil, salt, sulfur, graphite, titanium, magnesium, kaolin, nickel, mercury, timber, arable land
Land use:
agricultural land:
71.2% (2018 est.)
arable land:
56.1% (2018 est.)
permanent crops:
1.5% (2018 est.)
permanent pasture:
13.6% (2018 est.)
forest:
16.8% (2018 est.)
other:
12% (2018 est.)
Irrigated land:
4,350 sq km (2020)
Major rivers (by length in km):
Dunay (Danube) (shared with Germany [s], Austria, Slovakia, Czechia, Hungary, Croatia, Serbia, Bulgaria, Moldova, and Romania [m]) - 2,888 km; Dnipro (Dnieper) river mouth (shared with Russia [s] and Belarus) - 2,287 km; Dnister (Dniester) river source and mouth (shared with Moldova) - 1,411 km; Vistula (shared with Poland [s/m] and Belarus) - 1,213 km
note
– [s] after country name indicates river source; [m] after country name indicates river mouth
Major watersheds (area sq km): Atlantic Ocean drainage:
(Black Sea)
Danube (795,656 sq km), Don (458,694 sq km), Dnieper (533,966 sq km)
Population distribution:
densest settlement in the eastern (Donbas) and western regions; noteable concentrations in and around major urban areas of Kyiv, Kharkiv, Donets’k, Dnipropetrovs’k, and Odesa
Natural hazards:
occasional floods; occasional droughts
Geography - note:
strategic position at the crossroads between Europe and Asia; second-largest country in Europe after Russia','65fccd63ec4276332d779a0026d9229874589d8d6f8fa0eda0103d416eae4079','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('567880096ee8bd352ed8e616b71cc1b98b5c7bbb4dc047abce03960718d273c2',2025,'AE','United Arab Emirates','geography',27,'Location:
Middle East, bordering the Gulf of Oman and the Persian Gulf, between Oman and Saudi Arabia
Geographic coordinates:
24 00 N, 54 00 E
Map references:
Middle East
Area:
total:
83,600 sq km
land:
83,600 sq km
water:
0 sq km
comparison ranking:
total 115
Area - comparative:
slightly larger than South Carolina; slightly smaller than Maine
Land boundaries:
total:
1,066 km
border countries (2):
Oman 609 km; Saudi Arabia 457 km
Coastline:
1,318 km
Maritime claims:
territorial sea:
12 nm
contiguous zone:
24 nm
exclusive economic zone:
200 nm
continental shelf:
200 nm or to the edge of the continental margin
Climate:
desert; cooler in eastern mountains
Terrain:
flat, barren coastal plain merging into rolling sand dunes of vast desert; mountains in east
Elevation:
highest point:
Jabal Bil ‘Ays 1,905 m
lowest point:
Persian Gulf 0 m
mean elevation:
149 m
Natural resources:
petroleum, natural gas
Land use:
agricultural land:
4.6% (2018 est.)
arable land:
0.5% (2018 est.)
permanent crops:
0.5% (2018 est.)
permanent pasture:
3.6% (2018 est.)
forest:
3.8% (2018 est.)
other:
91.6% (2018 est.)
Irrigated land:
898 sq km (2020)
Population distribution:
population is heavily concentrated to the northeast on the Musandam Peninsula; the three largest emirates - Abu Dhabi, Dubai, and Sharjah - are home to nearly 85% of the population
Natural hazards:
frequent sand and dust storms
Geography - note:
strategic location along southern approaches to Strait of Hormuz, a vital transit point for world crude oil; Abu Zaby (Abu Dhabi) and Dubayy (Dubai) together account for over 90% of the area of the country and two-thirds of the population','2738ae25ce5abedc17dbff740ba29a3b36bb25449d87179df6ff2f6a9cf1d7f0','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('22ea6563a5a7177eb9893b3a31d231e84d1cdc197e541a7c1c2d39ba0ddc4e06',2025,'GB','United Kingdom','geography',39,'Location:
Western Europe, islands - including the northern one-sixth of the island of Ireland - between the North Atlantic Ocean and the North Sea; northwest of France
Geographic coordinates:
54 00 N, 2 00 W
Map references:
Europe
Area:
total:
243,610 sq km
land:
241,930 sq km
water:
1,680 sq km
note 1: the percentage area breakdown of the four UK countries is:
England 53%, Scotland 32%, Wales 9%, and Northern Ireland 6%
note 2:
includes Rockall and the Shetland Islands, which are part of Scotland
comparison ranking:
total 80
Area - comparative:
twice the size of Pennsylvania; slightly smaller than Oregon
Land boundaries:
total:
499 km
border countries (1):
Ireland 499 km
Coastline:
12,429 km
Maritime claims:
territorial sea:
12 nm
continental shelf:
as defined in continental shelf orders or in accordance with agreed upon boundaries
exclusive fishing zone:
200 nm
Climate:
temperate; moderated by prevailing southwest winds over the North Atlantic Current; more than one-half of the days are overcast
Terrain:
mostly rugged hills and low mountains; level to rolling plains in east and southeast
Elevation:
highest point:
Ben Nevis 1,345 m
lowest point:
The Fens -4 m
mean elevation:
162 m
Natural resources:
coal, petroleum, natural gas, iron ore, lead, zinc, gold, tin, limestone, salt, clay, chalk, gypsum, potash, silica sand, slate, arable land
Land use:
agricultural land:
71% (2018 est.)
arable land:
25.1% (2018 est.)
permanent crops:
0.2% (2018 est.)
permanent pasture:
45.7% (2018 est.)
forest:
11.9% (2018 est.)
other:
17.1% (2018 est.)
Irrigated land:
718 sq km (2018)
Population distribution:
the core of the population lies in and around London, with significant clusters found in central Britain around Manchester and Liverpool, in the Scottish lowlands between Edinburgh and Glasgow, southern Wales in and around Cardiff, and far eastern Northern Ireland centered on Belfast
Natural hazards:
winter windstorms; floods
Geography - note:
lies near vital North Atlantic sea lanes; only 35 km from France and linked by tunnel under the English Channel (the Channel Tunnel or Chunnel); because of heavily indented coastline, no location is more than 125 km from tidal waters','cf2ae8df2e76280499a15d82f58e786db2425826640fc2b1aea768e1051f34ff','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('412d99b64318c46c3370f1549211550e09d39cf08a236e9952ba43c4499c1f5b',2025,'US','United States','geography',2,'Location:
North America, bordering both the North Atlantic Ocean and the North Pacific Ocean, between Canada and Mexico
Geographic coordinates:
38 00 N, 97 00 W
Map references:
North America
Area:
total:
9,833,517 sq km
land:
9,147,593 sq km
water:
685,924 sq km
note:
includes only the 50 states and District of Columbia, no overseas territories
comparison ranking:
total 4
Area - comparative:
about half the size of Russia; about three-tenths the size of Africa; about half the size of South America (or slightly larger than Brazil); slightly larger than China; more than twice the size of the European Union
Land boundaries:
total:
12,002 km
border countries (2):
Canada 8,891 km (including 2,475 km with Alaska); Mexico 3,111 km
note:
US Naval Base at Guantanamo Bay, Cuba is leased by the US and is part of Cuba; the base boundary is 28.5 km
Coastline:
19,924 km
Maritime claims:
territorial sea:
12 nm
contiguous zone:
24 nm
exclusive economic zone:
200 nm
continental shelf:
not specified
Climate:
mostly temperate, but tropical in Hawaii and Florida, arctic in Alaska, semiarid in the great plains west of the Mississippi River, and arid in the Great Basin of the southwest; low winter temperatures in the northwest are ameliorated occasionally in January and February by warm chinook winds from the eastern slopes of the Rocky Mountains
note:
many consider Denali, the highest peak in the US, to be the world’s coldest mountain because of its combination of high elevation and its subarctic location at 63 degrees north latitude; permanent snow and ice cover over 75 percent of the mountain, and enormous glaciers, up to 45 miles long and 3,700 feet thick, spider out from its base in every direction; it is home to some of the world’s coldest and most violent weather, where winds of over 150 miles per hour and temperatures of -93˚F have been recorded.
Terrain:
vast central plain, mountains in west, hills and low mountains in east; rugged mountains and broad river valleys in Alaska; rugged, volcanic topography in Hawaii
Elevation:
highest point:
Denali 6,190 m (Mount McKinley) (highest point in North America)
lowest point:
Death Valley (lowest point in North America) -86 m
mean elevation:
760 m
note:
Denali is one of the most striking features on the entire planet; at 20,310 feet, it is the crowning peak of the Alaska Range and the highest mountain on North America; it towers three and one-half vertical miles above its base, making it a mile taller from base to summit than Mt. Everest; Denali’s base sits at about 2,000 feet above sea level and rises over three and one-half miles to its 20,310 foot summit; Everest begins on a 14,000-foot high plain, then summits at 29,028 feet.
note:
the peak of Mauna Kea (4,207 m above sea level) on the island of Hawaii rises about 10,200 m above the Pacific Ocean floor; by this measurement, it is the world’s tallest mountain - higher than Mount Everest (8,850 m), which is recognized as the tallest mountain above sea level
Natural resources:
coal, copper, lead, molybdenum, phosphates, rare earth elements, uranium, bauxite, gold, iron, mercury, nickel, potash, silver, tungsten, zinc, petroleum, natural gas, timber, arable land;
note 1:
the US has the world’s largest coal reserves with 491 billion short tons accounting for 27% of the world’s total
note 2:
the US is reliant on foreign imports for 100% of its needs for the following strategic resources: Arsenic, Cesium, Fluorspar, Gallium, Graphite, Indium, Manganese, Niobium, Rare Earths, Rubidium, Scandium, Tantalum, Yttrium; see Appendix H: Strategic Materials for further details
Land use:
agricultural land:
44.5% (2018 est.)
arable land:
16.8% (2018 est.)
permanent crops:
0.3% (2018 est.)
permanent pasture:
27.4% (2018 est.)
forest:
33.3% (2018 est.)
other:
22.2% (2018 est.)
Irrigated land:
234,782 sq km (2017)
Major lakes (area sq km):
fresh water lake(s):
Michigan – 57,750 sq km; Superior* – 53,348 sq km; Huron* – 23,597 sq km; Erie* – 12,890 sq km; Ontario* – 9,220 sq km; Lake of the Woods – 4,350 sq km; Iliamna – 2,590 sq km; Okeechobee – 1,810 sq km; Belcharof – 1,190 sq km; Red – 1,170 sq km; Saint Clair – 1,113 sq km; Champlain – 1,100 sq km note - Great Lakes* area shown as US waters
salt water lake(s):
Great Salt – 4,360 sq km; Pontchartrain – 1,620 sq km; Selawik – 1,400 sq km; Salton Sea – 950 sq km
Major rivers (by length in km):
Missouri - 3,768 km; Mississippi - 3,544 km; Yukon river mouth (shared with Canada [s]) - 3,190 km; Saint Lawrence (shared with Canada) - 3,058 km; Rio Grande river source (mouth shared with Mexico) - 3,057 km; Colorado river source (shared with Mexico [m]) - 2,333 km; Arkansas - 2,348 km; Columbia river mouth (shared with Canada [s]) - 2,250 km; Red - 2,188 km; Ohio - 2,102 km; Snake - 1,670 km
note
– [s] after country name indicates river source; [m] after country name indicates river mouth
Major watersheds (area sq km): Atlantic Ocean drainage:
(Gulf of Mexico)
Mississippi* (3,202,185 sq km); Rio Grande (607,965 sq km);
(Gulf of Saint Lawrence)
Saint Lawrence* (1,049,636 sq km total, US only 505,000 sq km)
Pacific Ocean drainage:
Yukon* (847,620 sq km, US only 23,820 sq km); Colorado (703,148 sq km); Columbia* (657,501 sq km, US only 554,501 sq km)
note
- watersheds shared with Canada shown with *
Major aquifers:
Northern Great Plains Aquifer, Cambrian-Ordovician Aquifer System, Californian Central Valley Aquifer System, Ogallala Aquifer (High Plains), Atlantic and Gulf Coastal Plains Aquifer
Population distribution:
large urban clusters are spread throughout the eastern half of the US (particularly the Great Lakes area, northeast, east, and southeast) and the western tier states; mountainous areas, principally the Rocky Mountains and Appalachian chain, deserts in the southwest, the dense boreal forests in the extreme north, and the central prarie states are less densely populated; Alaska’s population is concentrated along its southern coast - with particular emphasis on the city of Anchorage - and Hawaii’s is centered on the island of Oahu
Natural hazards:
tsunamis; volcanoes; earthquake activity around Pacific Basin; hurricanes along the Atlantic and Gulf of Mexico coasts; tornadoes in the Midwest and Southeast; mud slides in California; forest fires in the west; flooding; permafrost in northern Alaska, a major impediment to development
volcanism:
volcanic activity in the Hawaiian Islands, Western Alaska, the Pacific Northwest, and in the Northern Mariana Islands; both Mauna Loa (4,170 m) in Hawaii and Mount Rainier (4,392 m) in Washington have been deemed Decade Volcanoes by the International Association of Volcanology and Chemistry of the Earth’s Interior, worthy of study due to their explosive history and close proximity to human populations; Pavlof (2,519 m) is the most active volcano in Alaska’s Aleutian Arc and poses a significant threat to air travel since the area constitutes a major flight path between North America and East Asia; St. Helens (2,549 m), famous for the devastating 1980 eruption, remains active today; numerous other historically active volcanoes exist, mostly concentrated in the Aleutian arc and Hawaii; they include: in Alaska: Aniakchak, Augustine, Chiginagak, Fourpeaked, Iliamna, Katmai, Kupreanof, Martin, Novarupta, Redoubt, Spurr, Wrangell, Trident, Ugashik-Peulik, Ukinrek Maars, Veniaminof; in Hawaii: Haleakala, Kilauea, Loihi; in the Northern Mariana Islands: Anatahan; and in the Pacific Northwest: Mount Baker, Mount Hood; see note 2 under “Geography - note”
Geography - note:
note 1:
world’s third-largest country by size (after Russia and Canada) and by population (after China and India); Denali (Mt. McKinley) is the highest point (6,190 m) in North America and Death Valley the lowest point (-86 m) on the continent
note 2:
the western coast of the United States and southern coast of Alaska lie along the Ring of Fire, a belt of active volcanoes and earthquake epicenters bordering the Pacific Ocean; up to 90% of the world’s earthquakes and some 75% of the world’s volcanoes occur within the Ring of Fire
note 3:
the Aleutian Islands are a chain of volcanic islands that divide the Bering Sea (north) from the main Pacific Ocean (south); they extend about 1,800 km westward from the Alaskan Peninsula; the archipelago consists of 14 larger islands, 55 smaller islands, and hundreds of islets; there are 41 active volcanoes on the islands, which together form a large northern section of the Ring of Fire
note 4:
Mammoth Cave, in west-central Kentucky, is the world’s longest known cave system with more than 650 km (405 miles) of surveyed passageways, which is nearly twice as long as the second-longest cave system, the Sac Actun underwater cave in Mexico - the world’s longest underwater cave system (see “Geography - note” under Mexico);
note 5:
Kazumura Cave on the island of Hawaii is the world’s longest and deepest lava tube cave; it has been surveyed at 66 km (41 mi) long and 1,102 m (3,614 ft) deep
note 6:
Bracken Cave outside of San Antonio, Texas is the world’s largest bat cave; it is the summer home to the largest colony of bats in the world; an estimated 20 million Mexican free-tailed bats roost in the cave from March to October making it the world’s largest known concentration of mammals
note 7:
the US is reliant on foreign imports for 100% of its needs for the following strategic resources - Arsenic, Cesium, Fluorspar, Gallium, Graphite, Indium, Manganese, Niobium, Rare Earths, Rubidium, Scandium, Tantalum, Yttrium; see Appendix H: Strategic Materials for further details
note 8: three food crops are generally acknowledged to be native to areas of what is now the United States:
cranberries, pecans, and sunflowers','fe00dc6c26dea9bd22653fa4ca66e54c18d364acebca31a288a19677af4255ac','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7ae6145c5b5eaf8e441ad1cda9d49f7da9b5442db71997d1e7483c0328376364',2025,'US','United States','geography',15,'Location:
Oceania
Baker Island:
atoll in the North Pacific Ocean 3,390 km southwest of Honolulu, about halfway between Hawaii and Australia;
Howland Island:
island in the North Pacific Ocean 3,360 km southwest of Honolulu, about halfway between Hawaii and Australia;
Jarvis Island:
island in the South Pacific Ocean 2,415 km south of Honolulu, about halfway between Hawaii and Cook Islands;
Johnston Atoll:
atoll in the North Pacific Ocean 1,330 km southwest of Honolulu, about one-third of the way from Hawaii to the Marshall Islands;
Kingman Reef:
reef in the North Pacific Ocean 1,720 km south of Honolulu, about halfway between Hawaii and American Samoa;
Midway Islands:
atoll in the North Pacific Ocean 2,335 km northwest of Honolulu near the end of the Hawaiian Archipelago, about one-third of the way from Honolulu to Tokyo;
Palmyra Atoll:
atoll in the North Pacific Ocean 1,780 km south of Honolulu, about halfway between Hawaii and American Samoa
Geographic coordinates:
Baker Island:
0 13 N, 176 28 W;
Howland Island:
0 48 N, 176 38 W;
Jarvis Island:
0 23 S, 160 01 W;
Johnston Atoll:
16 45 N, 169 31 W;
Kingman Reef:
6 23 N, 162 25 W;
Midway Islands:
28 12 N, 177 22 W;
Palmyra Atoll:
5 53 N, 162 05 W
Map references:
Oceania
Area:
land:
6,959.41 sq km (emergent land - 22.41 sq km; submerged - 6,937 sq km)
Baker Island:
total - 129.1 sq km; emergent land - 2.1 sq km; submerged - 127 sq km
Howland Island:
total - 138.6 sq km; emergent land - 2.6 sq km; submerged - 136 sq km
Jarvis Island:
total - 152 sq km; emergent land - 5 sq km; submerged - 147 sq km
Johnston Atoll:
total - 276.6 sq km; emergent land - 2.6 sq km; submerged - 274 sq km
Kingman Reef:
total - 1,958.01 sq km; emergent land - 0.01 sq km; submerged - 1,958 sq km
Midway Islands:
total - 2,355.2 sq km; emergent land - 6.2 sq km; submerged - 2,349 sq km
Palmyra Atoll:
total - 1,949.9 sq km; emergent land - 3.9 sq km; submerged - 1,946 sq km
Area - comparative: Baker Island:
about 2.5 times the size of the National Mall in Washington, DC;
Howland Island:
about three times the size of the National Mall in Washington, DC;
Jarvis Island:
about eight times the size of the National Mall in Washington, DC;
Johnston Atoll:
about 4.5 times the size of the National Mall in Washington, DC;
Kingman Reef:
a little more than 1.5 times the size of the National Mall in Washington, DC;
Midway Islands:
about nine times the size of the National Mall in Washington, DC;
Palmyra Atoll:
about 20 times the size of the National Mall in Washington, DC
Land boundaries:
total:
0 km
Coastline: Baker Island:
4.8 km
Howland Island:
6.4 km
Jarvis Island:
8 km
Johnston Atoll:
34 km
Kingman Reef:
3 km
Midway Islands:
15 km
Palmyra Atoll:
14.5 km
Maritime claims:
territorial sea:
12 nm
exclusive economic zone:
200 nm
Climate:
Baker, Howland, and Jarvis Islands: equatorial; scant rainfall, constant wind, burning sun;
Johnston Atoll and Kingman Reef:
tropical, but generally dry; consistent northeast trade winds with little seasonal temperature variation;
Midway Islands:
subtropical with cool, moist winters (December to February) and warm, dry summers (May to October); moderated by prevailing easterly winds; most of the 107 cm of annual rainfall occurs during the winter;
Palmyra Atoll:
equatorial, hot; located within the low pressure area of the Intertropical Convergence Zone (ITCZ) where the northeast and southeast trade winds meet, it is extremely wet with between 400-500 cm of rainfall each year
Terrain:
low and nearly flat sandy coral islands with narrow fringing reefs that have developed at the top of submerged volcanic mountains, which in most cases rise steeply from the ocean floor
Elevation:
highest point:
Baker Island, unnamed location 8 m; Howland Island, unnamed location 3 m; Jarvis Island, unnamed location 7 m; Johnston Atoll, Sand Island 10 m; Kingman Reef, unnamed location 2 m; Midway Islands, unnamed location less than 13 m; Palmyra Atoll, unnamed location 3 m
lowest point:
Pacific Ocean 0 m
Natural resources:
terrestrial and aquatic wildlife
Land use:
other:
100% (2018 est.)
Natural hazards:
Baker, Howland, and Jarvis Islands: the narrow fringing reef surrounding the island poses a maritime hazard;
Kingman Reef:
wet or awash most of the time, maximum elevation of less than 2 m makes Kingman Reef a maritime hazard;
Midway Islands, Johnston, and Palmyra Atolls:
NA
Geography - note:
Baker, Howland, and Jarvis Islands:
scattered vegetation consisting of grasses, prostrate vines, and low growing shrubs; primarily a nesting, roosting, and foraging habitat for seabirds, shorebirds, and marine wildlife; closed to the public;
Johnston Atoll:
Johnston Island and Sand Island are natural islands, which have been expanded by coral dredging; North Island (Akau) and East Island (Hikina) are manmade islands formed from coral dredging; the egg-shaped reef is 34 km in circumference; closed to the public;
Kingman Reef:
barren coral atoll with deep interior lagoon; closed to the public;
Midway Islands:
a coral atoll managed as a National Wildlife Refuge and open to the public for wildlife-related recreation in the form of wildlife observation and photography;
Palmyra Atoll:
the high rainfall and resulting lush vegetation make the environment of this atoll unique among the US Pacific Island territories; supports a large undisturbed stand of Pisonia beach forest','c523203e7a862b9c94c5c95fae3a68b96b0d172e8280045215639e350c5331cf','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2d2de49f6c438228162ce6ac56e3b2aabecc869de1b7a98591eb9b499a1699e2',2025,'UY','Uruguay','geography',23,'Location:
Southern South America, bordering the South Atlantic Ocean, between Argentina and Brazil
Geographic coordinates:
33 00 S, 56 00 W
Map references:
South America
Area:
total:
176,215 sq km
land:
175,015 sq km
water:
1,200 sq km
comparison ranking:
total 91
Area - comparative:
about the size of Virginia and West Virginia combined; slightly smaller than the state of Washington
Land boundaries:
total:
1,591 km
border countries (2):
Argentina 541 km; Brazil 1,050 km
Coastline:
660 km
Maritime claims:
territorial sea:
12 nm
contiguous zone:
24 nm
exclusive economic zone:
200 nm
continental shelf:
200 nm or the edge of continental margin
Climate:
warm temperate; freezing temperatures almost unknown
Terrain:
mostly rolling plains and low hills; fertile coastal lowland
Elevation:
highest point:
Cerro Catedral 514 m
lowest point:
Atlantic Ocean 0 m
mean elevation:
109 m
Natural resources:
arable land, hydropower, minor minerals, fish
Land use:
agricultural land:
87.2% (2018 est.)
arable land:
10.1% (2018 est.)
permanent crops:
0.2% (2018 est.)
permanent pasture:
76.9% (2018 est.)
forest:
10.2% (2018 est.)
other:
2.6% (2018 est.)
Irrigated land:
2,380 sq km (2012)
Major lakes (area sq km):
salt water lake(s):
Lagoa Mirim (shared with Brazil) - 2,970 sq km
Major rivers (by length in km):
Rio de la Plata/Parana river mouth (shared with Brazil [s], Argentina, Paraguay) - 4,880 km; Uruguay river mouth (shared with Brazil [s] and Argentina) - 1,610 km
note
– [s] after country name indicates river source; [m] after country name indicates river mouth
Major aquifers:
Guarani Aquifer System
Population distribution:
most of the country’s population resides in the southern half of the country; approximately 80% of the populace is urban, living in towns or cities; nearly half of the population lives in and around the capital of Montevideo
Natural hazards:
seasonally high winds (the pampero is a chilly and occasional violent wind that blows north from the Argentine pampas), droughts, floods; because of the absence of mountains, which act as weather barriers, all locations are particularly vulnerable to rapid changes from weather fronts
Geography - note:
second-smallest South American country (after Suriname); most of the low-lying landscape (three-quarters of the country) is grassland, ideal for cattle and sheep raising','348bde52bbc4d4d24f6656456516a6dddada61823b26b77929ef9a2d6d724132','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('228b49ad2002c06b71cfb94d49377700020ae0d0634501755f5c44462fd3d96f',2025,'UZ','Uzbekistan','geography',35,'Location:
Central Asia, north of Turkmenistan, south of Kazakhstan
Geographic coordinates:
41 00 N, 64 00 E
Map references:
Asia
Area:
total:
447,400 sq km
land:
425,400 sq km
water:
22,000 sq km
comparison ranking:
total 59
Area - comparative:
about four times the size of Virginia; slightly larger than California
Land boundaries:
total:
6,893 km
border countries (5):
Afghanistan 144 km; Kazakhstan 2,330 km; Kyrgyzstan 1,314 km; Tajikistan 1,312 km; Turkmenistan 1,793 km
Coastline:
0 km (doubly landlocked); note - Uzbekistan includes the southern portion of the Aral Sea with a 420 km shoreline
Maritime claims:
none (doubly landlocked)
Climate:
mostly mid-latitude desert, long, hot summers, mild winters; semiarid grassland in east
Terrain:
mostly flat-to-rolling sandy desert with dunes; broad, flat intensely irrigated river valleys along course of Amu Darya, Syr Darya (Sirdaryo), and Zaravshan; Fergana Valley in east surrounded by mountainous Tajikistan and Kyrgyzstan; shrinking Aral Sea in west
Elevation:
highest point:
Xazrat Sulton Tog’ 4,643 m
lowest point:
Sariqamish Kuli -12 m
Natural resources:
natural gas, petroleum, coal, gold, uranium, silver, copper, lead and zinc, tungsten, molybdenum
Land use:
agricultural land:
62.6% (2018 est.)
arable land:
10.1% (2018 est.)
permanent crops:
0.8% (2018 est.)
permanent pasture:
51.7% (2018 est.)
forest:
7.7% (2018 est.)
other:
29.7% (2018 est.)
Irrigated land:
37,320 sq km (2020)
Major lakes (area sq km):
fresh water lake(s):
Aral Sea (shared with Kazakhstan) - largely dried up
Major rivers (by length in km):
Syr Darya (shared with Kyrgyzstan [s], Tajikistan, and Kazakhstan [m]) - 3,078 km; Amu Darya river mouth (shared with Tajikistan [s], Afghanistan, and Turkmenistan) - 2,620 km
note
– [s] after country name indicates river source; [m] after country name indicates river mouth
Major watersheds (area sq km): Internal (endorheic basin) drainage:
(Aral Sea basin)
Amu Darya (534,739 sq km), Syr Darya (782,617 sq km)
Population distribution:
most of the population is concentrated in the fertile Fergana Valley in the easternmost arm of the country; the south has significant clusters of people, while the central and western deserts are sparsely populated
Natural hazards:
earthquakes; floods; landslides or mudslides; avalanches; droughts
Geography - note:
along with Liechtenstein, one of the only two doubly landlocked countries in the world','d6e70a20bb3e0f740162f8ce0d77e63f86a0bc3cb166ba03a5d7e3721f472cbe','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9e2510c34fe3c036590a93974b19adebbec8819f1ef1eb3b9ae0194a3e872db7',2025,'VU','Vanuatu','geography',2,'Location:
Oceania, group of islands in the South Pacific Ocean, about three-quarters of the way from Hawaii to Australia
Geographic coordinates:
16 00 S, 167 00 E
Map references:
Oceania
Area:
total:
12,189 sq km
land:
12,189 sq km
water:
0 sq km
note:
includes more than 80 islands, about 65 of which are inhabited
comparison ranking:
total 162
Area - comparative:
slightly larger than Connecticut
Land boundaries:
total:
0 km
Coastline:
2,528 km
Maritime claims:
territorial sea:
12 nm
contiguous zone:
24 nm
exclusive economic zone:
200 nm
continental shelf:
200 nm or to the edge of the continental margin
measured from claimed archipelagic baselines
Climate:
tropical; moderated by southeast trade winds from May to October; moderate rainfall from November to April; may be affected by cyclones from December to April
Terrain:
mostly mountainous islands of volcanic origin; narrow coastal plains
Elevation:
highest point:
Tabwemasana 1,877 m
lowest point:
Pacific Ocean 0 m
Natural resources:
manganese, hardwood forests, fish
Land use:
agricultural land:
15.3% (2018 est.)
arable land:
1.6% (2018 est.)
permanent crops:
10.3% (2018 est.)
permanent pasture:
3.4% (2018 est.)
forest:
36.1% (2018 est.)
other:
48.6% (2018 est.)
Irrigated land:
0 sq km (2022)
Population distribution:
three-quarters of the population lives in rural areas; the urban populace lives primarily in two cities, Port-Vila and Lugenville; three largest islands - Espiritu Santo, Malakula, and Efate - accomodate over half of the populace
Natural hazards:
tropical cyclones (January to April); volcanic eruption on Aoba (Ambae) island began on 27 November 2005, volcanism also causes minor earthquakes; tsunamis
volcanism:
significant volcanic activity with multiple eruptions in recent years; Yasur (361 m), one of the world’s most active volcanoes, has experienced continuous activity in recent centuries; other historically active volcanoes include Aoba, Ambrym, Epi, Gaua, Kuwae, Lopevi, Suretamatai, and Traitor’s Head
Geography - note:
a Y-shaped chain of four main islands and 80 smaller islands; several of the islands have active volcanoes and there are several underwater volcanoes as well','cc248439c396ef6e7727a28fcaaaf2503b5b21ee23cc807048514b7f30028ad8','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cc8341a94c8fd05de6b28d53c6cf6a581a57c11502e651ed404fdea3f594730a',2025,'VU','Vanuatu','geography',13,'Location:
Northern South America, bordering the Caribbean Sea and the North Atlantic Ocean, between Colombia and Guyana
Geographic coordinates:
8 00 N, 66 00 W
Map references:
South America
Area:
total:
912,050 sq km
land:
882,050 sq km
water:
30,000 sq km
comparison ranking:
total 34
Area - comparative:
almost six times the size of Georgia; slightly more than twice the size of California
Land boundaries:
total:
5,267 km
border countries (3):
Brazil 2,137 km; Colombia 2,341 km; Guyana 789 km
Coastline:
2,800 km
Maritime claims:
territorial sea:
12 nm
contiguous zone:
15 nm
exclusive economic zone:
200 nm
continental shelf:
200-m depth or to the depth of exploitation
Climate:
tropical; hot, humid; more moderate in highlands
Terrain:
Andes Mountains and Maracaibo Lowlands in northwest; central plains (llanos); Guiana Highlands in southeast
Elevation:
highest point:
Pico Bolivar 4,978 m
lowest point:
Caribbean Sea 0 m
mean elevation:
450 m
Natural resources:
petroleum, natural gas, iron ore, gold, bauxite, other minerals, hydropower, diamonds
Land use:
agricultural land:
24.5% (2018 est.)
arable land:
3.1% (2018 est.)
permanent crops:
0.8% (2018 est.)
permanent pasture:
20.6% (2018 est.)
forest:
52.1% (2018 est.)
other:
23.4% (2018 est.)
Irrigated land:
10,550 sq km (2012)
Major lakes (area sq km):
salt water lake(s):
Lago de Maracaibo - 13,010 sq km
Major rivers (by length in km):
Rio Negro (shared with Colombia [s] and Brazil [m]) - 2,250 km; Orinoco river source and mouth (shared with Colombia) - 2,101 km
note
– [s] after country name indicates river source; [m] after country name indicates river mouth
Major watersheds (area sq km): Atlantic Ocean drainage:
Amazon (6,145,186 sq km), Orinoco (953,675 sq km)
Population distribution:
most of the population is concentrated in the northern and western highlands along an eastern spur at the northern end of the Andes, an area that includes the capital of Caracas
Natural hazards:
subject to floods, rockslides, mudslides; periodic droughts
Geography - note:
note 1:
the country lies on major sea and air routes linking North and South America
note 2:
Venezuela has some of the most unique geology in the world; tepuis are massive table-top mountains of the western Guiana Highlands that tend to be isolated and thus support unique endemic plant and animal species; their sheer cliffsides account for some of the most spectacular waterfalls in the world including Angel Falls, the world’s highest (979 m) that drops off Auyan Tepui','0ef96f56b4a01d3f45a8155e78be5a1fa6cc77de93988381f3e243b6f24fb785','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a5ccb1e0dfbe90e67ba713ceb755ba7045278ccc539e80e5a62b85fd1f4b3084',2025,'VU','Vanuatu','geography',26,'Location:
Southeastern Asia, bordering the Gulf of Thailand, Gulf of Tonkin, and South China Sea, as well as China, Laos, and Cambodia
Geographic coordinates:
16 10 N, 107 50 E
Map references:
Southeast Asia
Area:
total:
331,210 sq km
land:
310,070 sq km
water:
21,140 sq km
comparison ranking:
total 67
Area - comparative:
about three times the size of Tennessee; slightly larger than New Mexico
Land boundaries:
total:
4,616 km
border countries (3):
Cambodia 1,158 km; China 1,297 km; Laos 2,161 km
Coastline:
3,444 km (excludes islands)
Maritime claims:
territorial sea:
12 nm
contiguous zone:
24 nm
exclusive economic zone:
200 nm
continental shelf:
200 nm or to the edge of the continental margin
Climate:
tropical in south; monsoonal in north with hot, rainy season (May to September) and warm, dry season (October to March)
Terrain:
low, flat delta in south and north; central highlands; hilly, mountainous in far north and northwest
Elevation:
highest point:
Fan Si Pan 3,144 m
lowest point:
South China Sea 0 m
mean elevation:
398 m
Natural resources:
antimony, phosphates, coal, manganese, rare earth elements, bauxite, chromate, offshore oil and gas deposits, timber, hydropower, arable land
Land use:
agricultural land:
34.8% (2018 est.)
arable land:
20.6% (2018 est.)
permanent crops:
12.1% (2018 est.)
permanent pasture:
2.1% (2018 est.)
forest:
45% (2018 est.)
other:
20.2% (2018 est.)
Irrigated land:
46,000 sq km (2012)
Major rivers (by length in km):
Sông Tiên Giang (Mekong) river mouth (shared with China [s], Burma, Laos, Thailand, Cambodia) - 4,350 km; Pearl river source (shared with China [m]) - 2,200 km; Red river mouth (shared with China [s]) - 1,149 km
note
– [s] after country name indicates river source; [m] after country name indicates river mouth
Major watersheds (area sq km): Pacific Ocean drainage:
Mekong (805,604 sq km)
Population distribution:
though it has one of the highest population densities in the world, the population is not evenly dispersed; clustering is heaviest along the South China Sea and Gulf of Tonkin, with the Mekong Delta (in the south) and the Red River Valley (in the north) having the largest concentrations of people
Natural hazards:
occasional typhoons (May to January) with extensive flooding, especially in the Mekong River delta
Geography - note:
note 1:
extending 1,650 km north to south, the country is only 50 km across at its narrowest point
note 2:
Son Doong in Phong Nha-Ke Bang National Park is the world’s largest cave (greatest cross sectional area) and is the largest known cave passage in the world by volume; it currently measures a total of 38.5 million cu m (about 1.35 billion cu ft); it connects to Thung cave (but not yet officially); when recognized, it will add an additional 1.6 million cu m in volume; Son Doong is so massive that it contains its own jungle, underground river, and localized weather system; clouds form inside the cave and spew out from its exits and two dolines (openings (sinkhole skylights) created by collapsed ceilings that allow sunlight to stream in)','af9ccf50b54633f034fe3c03c16a8cab5f3d327daa5ae50d8509cc24c07fb4d7','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('38333e2acc233bf18a59ee76846dd13c6b43c43124956ce236b1c2076dfbafb8',2025,'VU','Vanuatu','geography',38,'Location:
Caribbean, islands between the Caribbean Sea and the North Atlantic Ocean, east of Puerto Rico
Geographic coordinates:
18 20 N, 64 50 W
Map references:
Central America and the Caribbean
Area:
total:
1,910 sq km
land:
346 sq km
water:
1,564 sq km
comparison ranking:
total 181
Area - comparative:
twice the size of Washington, DC
Land boundaries:
total:
0 km
Coastline:
188 km
Maritime claims:
territorial sea:
12 nm
exclusive economic zone:
200 nm
Climate:
subtropical, tempered by easterly trade winds, relatively low humidity, little seasonal temperature variation; rainy season September to November
Terrain:
mostly hilly to rugged and mountainous with little flat land
Elevation:
highest point:
Crown Mountain 474 m
lowest point:
Caribbean Sea 0 m
Natural resources:
pleasant climate, beaches foster tourism
Land use:
agricultural land:
11.5% (2018 est.)
arable land:
2.9% (2018 est.)
permanent crops:
2.9% (2018 est.)
permanent pasture:
5.7% (2018 est.)
forest:
57.4% (2018 est.)
other:
31.1% (2018 est.)
Irrigated land:
1 sq km (2012)
Population distribution:
while overall population density throughout the islands is relatively low, concentrations appear around Charlotte Amalie on St. Thomas and Christiansted on St. Croix
Natural hazards:
several hurricanes in recent years; frequent and severe droughts and floods; occasional earthquakes
Geography - note:
important location along the Anegada Passage - a key shipping lane for the Panama Canal; Saint Thomas has one of the best natural deepwater harbors in the Caribbean','b94f8e7c6607fc9318aabf21eed1702d7c5ae364ea9b00fba6e52ee8129a9070','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('908d0bd1ea16f277250f55d214233d5d3a4544207eefccf3caeba2f2de5de7f2',2025,'WF','Wallis and Futuna','geography',3,'Location:
Oceania, islands in the South Pacific Ocean, about two-thirds of the way from Hawaii to New Zealand
Geographic coordinates:
13 18 S, 176 12 W
Map references:
Oceania
Area:
total:
142 sq km
land:
142 sq km
water:
0 sq km
note:
includes Ile Uvea (Wallis Island), Ile Futuna (Futuna Island), Ile Alofi, and 20 islets
comparison ranking:
total 220
Area - comparative:
1.5 times the size of Washington, DC
Land boundaries:
total:
0 km
Coastline:
129 km
Maritime claims:
territorial sea:
12 nm
exclusive economic zone:
200 nm
Climate:
tropical; hot, rainy season (November to April); cool, dry season (May to October); rains 250-300 cm per year (80% humidity); average temperature 26.6 degrees Celsius
Terrain:
volcanic origin; low hills
Elevation:
highest point:
Mont Singavi (on Futuna) 522 m
lowest point:
Pacific Ocean 0 m
Natural resources:
NEGL
Land use:
agricultural land:
42.8% (2018 est.)
arable land:
7.1% (2018 est.)
permanent crops:
35.7% (2018 est.)
permanent pasture:
0% (2018 est.)
forest:
41.9% (2018 est.)
other:
15.3% (2018 est.)
Irrigated land:
0.6 sq km (2020)
Natural hazards:
cyclones; tsunamis
Geography - note:
both island groups have fringing reefs; Wallis contains several prominent crater lakes','066c37fb7d4467e45b94439ee6aba65beb254d05fdd833c9e1e69f73467da113','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a9156f1a554fa5d8ddea58e4ceeeadfc3512d03084067daa26ac7e3aeb34bccb',2025,'WF','Wallis and Futuna','geography',13,'Location:
Middle East, west of Jordan, east of Israel
Geographic coordinates:
32 00 N, 35 15 E
Map references:
Middle East
Area:
total:
5,860 sq km
land:
5,640 sq km
water:
220 sq km
note:
includes West Bank, Latrun Salient, and the northwest quarter of the Dead Sea, but excludes Mt. Scopus; East Jerusalem and Jerusalem No Man’s Land are also included only as a means of depicting the entire area occupied by Israel in 1967
comparison ranking:
total 171
Area - comparative:
slightly smaller than Delaware
Land boundaries:
total:
478 km
border countries (2):
Israel 330 km; Jordan 148 km
Coastline:
0 km (landlocked)
Maritime claims:
none (landlocked)
Climate:
temperate; temperature and precipitation vary with altitude, warm to hot summers, cool to mild winters
Terrain:
mostly rugged, dissected upland in west, flat plains descending to Jordan River Valley to the east
Elevation:
highest point:
Khallat al Batrakh 1,020 m
lowest point:
Dead Sea -431 m
Natural resources:
arable land
Land use:
agricultural land:
43.3% (2018 est.)
arable land:
7.4% (2018 est.)
permanent crops:
11% (2018 est.)
permanent pasture:
24.9% (2018 est.)
forest:
1.5% (2018 est.)
other:
55.2% (2018 est.)
note:
includes Gaza Strip
Irrigated land:
(2013) 151 sq km;
note
- includes Gaza Strip
Major lakes (area sq km):
salt water lake(s):
Dead Sea (shared with Jordan and Israel) - 1,020 sq km
note
- endorheic hypersaline lake; 9.6 times saltier than the ocean; lake shore is 431 meters below sea level
Population distribution:
the most populous Palestinian communities in the West Bank are located in the central ridge and western half of its territory; Jewish settlements are located throughout the West Bank, the most populous in the Seam Zone-between the 1949 Armistice Line and the separation barrier--and around Jerusalem
Natural hazards:
droughts
Geography - note:
landlocked; highlands are main recharge area for Israel’s coastal aquifers; there are about 380 Israeli civilian sites, including about 213 settlements and 132 small outpost communities in the West Bank and 35 sites in East Jerusalem (2017)','bfe230354d026225f534f22e97760cf015bf074a4378e3e40c18de7993079efa','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0f3d89f34275a8d758b2ef55a5f79a33766ebfc1c5b5ca7e07159e65c56ea1a7',2025,'WF','Wallis and Futuna','geography',25,'Geographic overview:
The surface of the Earth is approximately 70.9% water and 29.1% land. The former portion constitutes the World Ocean, the single largest feature of the planet and one that connects all places on the globe. The World Ocean is divided by the intervening continental landmasses into five major ocean basins, which are in decreasing order of size: the Pacific, Atlantic, Indian, Southern, and Arctic.
The World Factbook
describes each of these five as oceans. Given the significant differences in direction and temperature of major ocean currents, as well as the effects of the major air masses above them, the Pacific and Atlantic Oceans are generally divided at the equator into the North and South Pacific Oceans and the North and South Atlantic Oceans, thus creating seven major water bodies - the so-called “Seven Seas.”
Some 97.5% of the Earth’s water is saltwater. Of the 2.5% that is fresh, about two-thirds is frozen mostly locked up in the Antarctic ice sheets and mountain glaciers worldwide. If all the surface ice on earth fully melted, the sea level would rise about 70 m (230 ft).
In a 100-year period, a water molecule spends 98 years in the ocean, 20 months as ice, about two weeks in lakes and rivers, and less than a week in the atmosphere. Groundwater can take 50 years to just traverse 1 km (0.6 mi).
Earth’s land portion is generally divided into several, large, discrete landmasses termed continents. Depending on the convention used, the number of continents can vary from five to seven. The most common classification recognizes seven, which are (from largest to smallest): Asia, Africa, North America, South America, Antarctica, Europe, and Australia. Asia and Europe are sometimes lumped together into a Eurasian continent resulting in six continents. Alternatively, North and South America are sometimes grouped as simply the Americas, resulting in a continent total of six (or five, if the Eurasia designation is used).
North America is commonly understood to include the island of Greenland, the isles of the Caribbean, and to extend south all the way to the Isthmus of Panama. The easternmost extent of Europe is generally defined as being the Ural Mountains and the Ural River; on the southeast the Caspian Sea; and on the south the Caucasus Mountains, the Black Sea, and the Mediterranean. Portions of five countries - Azerbaijan, Georgia, Kazakhstan, Russia, and Turkey - fall within both Europe and Asia, but in every instance the larger section is in Asia. These countries are considered part of both continents. Armenia and Cyprus, which lie completely in Western Asia, are geopolitically European countries.
Asia usually incorporates all the islands of the Philippines, Malaysia, and Indonesia. The islands of the Pacific are often lumped with Australia into a “land mass” termed Oceania or Australasia. Africa’s northeast extremity is frequently delimited at the Isthmus of Suez, but for geopolitical purposes, the Egyptian Sinai Peninsula is often included as part of Africa.
Although the above groupings are the most common, different continental dispositions are recognized or taught in certain parts of the World, with some arrangements more heavily based on cultural spheres rather than physical geographic considerations.
Based on the seven-continent model, and grouping islands with adjacent continents, Africa has the most countries with 54. Europe contains 49 countries and Asia 48, but these two continents share five countries: Azerbaijan, Georgia, Kazakhstan, Russia, and Turkey. North America consists of 23 sovereign states, Oceania has 16, and South America 12. In total, there are 197 countries recognized by the United States.
countries by continent:
Africa (54): Algeria, Angola, Benin, Botswana, Burkina Faso, Burundi, Cabo Verde, Cameroon, Central African Republic, Chad, Comoros, Democratic Republic of the Congo, Republic of the Congo, Cote d’Ivoire, Djibouti, Egypt, Equatorial Guinea, Eritrea, Eswatini, Ethiopia, Gabon, The Gambia, Ghana, Guinea, Guinea-Bissau, Kenya, Lesotho, Liberia, Libya, Madagascar, Malawi, Mali, Mauritania, Mauritius, Morocco, Mozambique, Namibia, Niger, Nigeria, Rwanda, Sao Tome and Principe, Senegal, Seychelles, Sierra Leone, Somalia, South Africa, South Sudan, Sudan, Tanzania, Togo, Tunisia, Uganda, Zambia, Zimbabwe;
Europe (49):
Albania, Andorra, Austria, Azerbaijan*, Belarus, Belgium, Bosnia and Herzegovina, Bulgaria, Croatia, Czech Republic, Denmark, Estonia, Finland, France, Georgia*, Germany, Greece, Holy See (Vatican City), Hungary, Iceland, Ireland, Italy, Kazakhstan*, Kosovo, Latvia, Liechtenstein, Lithuania, Luxembourg, Malta, Moldova, Monaco, Montenegro, Netherlands, North Macedonia, Norway, Poland, Portugal, Romania, Russia*, San Marino, Serbia, Slovakia, Slovenia, Spain, Sweden, Switzerland, Turkey*, Ukraine, United Kingdom (* indicates part of the country is also in Asia);
Asia (48):
Afghanistan, Armenia, Azerbaijan*, Bahrain, Bangladesh, Bhutan, Brunei, Burma, Cambodia, China, Cyprus, Georgia*, India, Indonesia, Iran, Iraq, Israel, Japan, Jordan, Kazakhstan*, North Korea, South Korea, Kuwait, Kyrgyzstan, Laos, Lebanon, Malaysia, Maldives, Mongolia, Nepal, Oman, Pakistan, Philippines, Qatar, Russia*, Saudi Arabia, Singapore, Sri Lanka, Syria, Tajikistan, Thailand, Timor-Leste, Turkey*, Turkmenistan, United Arab Emirates, Uzbekistan, Vietnam, Yemen (* indicates part of the country is also in Europe);
North America (23):
Antigua and Barbuda, The Bahamas, Barbados, Belize, Canada, Costa Rica, Cuba, Dominica, Dominican Republic, El Salvador, Grenada, Guatemala, Haiti, Honduras, Jamaica, Mexico, Nicaragua, Panama, Saint Kitts and Nevis, Saint Lucia, Saint Vincent and the Grenadines, Trinidad and Tobago, United States;
Oceania (16):
Australia, Cook Islands, Fiji, Kiribati, Marshall Islands, Federated States of Micronesia, Nauru, New Zealand, Niue, Palau, Papua New Guinea, Samoa, Solomon Islands, Tonga, Tuvalu, Vanuatu;
South America (12):
Argentina, Bolivia, Brazil, Chile, Colombia, Ecuador, Guyana, Paraguay, Peru, Suriname, Uruguay, Venezuela.
Three of the states described above – France, Netherlands, and the United Kingdom – consist of smaller political entities that are referred to as countries. France considers French Polynesia an overseas country; the Kingdom of the Netherlands refers to all four of its constituent parts (Netherlands [proper], and the islands of Aruba, Curacao, and Sint Maarten) as countries; and the United Kingdom comprises the countries of England, Wales, Scotland, and Northern Ireland. While not recognized as sovereign states,
The World Factbook
does include descriptive entries for the French and Dutch island “countries.”
the World from space:
Earth is the only planet in the Solar System to have water in its three states of matter: liquid (oceans, lakes, and rivers), solid (ice), and gas (water vapor in clouds). From a distance, Earth would be the brightest of the eight planets in the Solar System; this luminous effect would be because of the sunlight reflected by the planet’s water.
Earth is also the only planet in the Solar System known to be active with earthquakes and volcanoes due to plate tectonics; these events form the landscape, replenish carbon dioxide into the atmosphere, and erase impact craters caused by meteors.
Earth has a slight equatorial bulge - a difference between its equatorial and polar diameters - because of the centrifugal force exerted by the rotation of the planet about its axis. The equatorial diameter is 12,756 km, but the polar diameter is 12,714 km; this results in the Earth’s circumference at the equator being 40,075 km, while the polar circumference is 40,008 km.
the physical World:
The Earth is composed of three layers: the outer lithosphere (with its crust and uppermost solid mantle), the mantle (the thickest layer, with distinct upper and lower layers), and the core (with an outer (liquid) and inner (solid) core). Researchers have discovered that a transition zone (at a depth of 410-660 km (255-410 mi)) between the upper and lower mantle may well be hydrous (water-bearing). But this hydrous rock would neither feel wet nor drip water. At that depth, high temperatures and pressures structurally transform a mineral called olivine into another mineral ringwoodite - and ringwoodite can incorporate water, but not water in a liquid, solid, or gas form. The high temperatures and pressures cause: 1) water molecules to split, creating hydroxide ions (hydrogen and oxygen atoms bound together), and 2) create structural changes in ringwoodite so that it is able to contain hydroxide ions. Ringwoodite can hold 1 to 3% of its weight in hydroxide ions. Considering that the 250 km-transition zone is about 7% of the Earth’s mass (the crust, by comparison, is only about 1%), it could include at least as much (if not several times more) water than all of the Earth’s oceans.
Map references:
Physical Map of the World
Area:
total:
510.072 million sq km
land:
148.94 million sq km
water:
361,899,999 sq km
note:
70.9% of the world’s surface is water, 29.1% is land
Area - comparative:
land area about 16 times the size of the US
Area - rankings:
top fifteen World Factbook entities ranked by size:
Pacific Ocean 155,557,000 sq km; Atlantic Ocean 76,762,000 sq km; Indian Ocean 68,556,000 sq km; Southern Ocean 20,327,000 sq km; Russia 17,098,242 sq km; Antarctica 14,200,000 sq km; Arctic Ocean 14,056,000 sq km; Canada 9,984,670 sq km; United States 9,826,675 sq km; China 9,596,960 sq km; Brazil 8,515,770 sq km; Australia 7,741,220 sq km; European Union 4,324,782 sq km; India 3,287,263 sq km; Argentina 2,780,400 sq km
top ten largest water bodies:
Pacific Ocean 155,557,000 sq km; Atlantic Ocean 76,762,000 sq km; Indian Ocean 68,556,000 sq km; Southern Ocean 20,327,000 sq km; Arctic Ocean 14,056,000 sq km; Coral Sea 4,184,100 sq km; South China Sea 3,595,900 sq km; Caribbean Sea 2,834,000 sq km; Bering Sea 2,520,000 sq km; Mediterranean Sea 2,469,000 sq km
top ten largest landmasses:
Asia 44,568,500 sq km; Africa 30,065,000 sq km; North America 24,473,000 sq km; South America 17,819,000 sq km; Antarctica 14,200,000 sq km; Europe 9,948,000 sq km; Australia 7,741,220 sq km; Greenland 2,166,086 sq km; New Guinea 785,753 sq km; Borneo 751,929 sq km
top ten largest islands:
Greenland 2,166,086 sq km; New Guinea (Indonesia, Papua New Guinea) 785,753 sq km; Borneo (Brunei, Indonesia, Malaysia) 751,929 sq km; Madagascar 587,713 sq km; Baffin Island (Canada) 507,451 sq km; Sumatra (Indonesia) 472,784 sq km; Honshu (Japan) 227,963 sq km; Victoria Island (Canada) 217,291 sq km; Great Britain (United Kingdom) 209,331 sq km; Ellesmere Island (Canada) 196,236 sq km
top ten longest mountain ranges (land-based):
Andes (Venezuela, Colombia, Ecuador, Peru, Bolivia, Chile, Argentina) 7,000 km; Rocky Mountains (Canada, US) 4,830 km; Great Dividing Range (Australia) 3,700 km; Transantarctic Mountains (Antarctica) 3,500 km; Kunlun Mountains (China) 3,000 km; Ural Mountains (Russia, Kazakhstan) 2,640 km; Atlas Mountains (Morocco, Algeria, Tunisia) 2,500 km; Appalachian Mountains (Canada, US) 2,400 km; Himalayas (Pakistan, Afghanistan, India, China, Nepal, Bhutan) 2,300 km; Altai Mountains (Kazakhstan, Russia, Mongolia) 2,000 km;
note
- lengths are approximate; if oceans are included, the Mid-Ocean Ridge is by far the longest mountain range at 40,389 km
top ten largest forested countries (sq km and percent of land):
Russia 8,149,310 (49.8%); Brazil 4,935,380 (58.9%); Canada 3,470,690 (38.2%); United States 3,103,700 (33.9%); China 2,098,640 (22.3%); Democratic Republic of the Congo 1,522,670 (67.2%); Australia 1,250,590 (16.3%); Indonesia 903,250 (49.9%); Peru 738,054 (57.7%); India 708,600 (23.8%) (2016 est.)
top ten most densely forested countries (percent of land):
Suriname (98.3%), Federated States of Micronesia (91.9%), Gabon (90%), Seychelles (88.4%), Palau (87.6%), Guyana (83.9%), Laos (82.1%), Solomon Islands (77.9%), Papua New Guinea (74.1%), Finland (73.1%) (2016 est.)
top ten largest (non-polar) deserts:
Sahara (Algeria, Chad, Egypt, Libya, Mali, Mauritania, Niger, Western Sahara, Sudan, Tunisia) 9,200,000 sq km; Arabian (Saudi Arabia, Iraq, Jordan, Kuwait, Oman, Qatar, United Arab Emirates, Yemen) 2,330,000 sq km; Gobi (China, Mongolia) 1,295,000 sq km; Kalahari (Botswana, Namibia, South Africa) 900,000 sq km; Patagonian (Argentina) 673,000 sq km; Syrian (Syria, Iraq, Jordan, Saudi Arabia) 500,000 sq km; Chihuahuan (Mexico) 362,000 sq km; Kara-Kum (Turkmenistan) 350,000 sq km; Great Victoria (Australia) 348,750 sq km; Great Basin (United States) 343,169 sq km;
note
- if the two polar deserts are included, they would rank first and second: Antarctic Desert 14,200,000 sq km and Arctic Desert 13,900,000 sq km
ten smallest independent countries:
Holy See (Vatican City) 0.44 sq km; Monaco 2 sq km; Nauru 21 sq km; Tuvalu 26 sq km; San Marino 61 sq km; Liechtenstein 160 sq km; Marshall Islands 181 sq km; Cook Islands 236 sq km; Niue 260 sq km; Saint Kitts and Nevis 261 sq km
Land boundaries:
the land boundaries in
The World Factbook
total 279,035.5 km (not counting shared boundaries twice); two nations, China and Russia, each border 14 other countries
note 1:
the total is actually misleading in terms of accuracy, since one cannot accurately measure every river meander along a boundary; a number rounded slightly higher - to 280,000 km - makes more sense and has been coordinated with and approved by the US State Department
note 2:
46 nations and other areas are landlocked, these include: Afghanistan, Andorra, Armenia, Austria, Azerbaijan, Belarus, Bhutan, Bolivia, Botswana, Burkina Faso, Burundi, Central African Republic, Chad, Czechia, Eswatini, Ethiopia, Holy See (Vatican City), Hungary, Kazakhstan, Kosovo, Kyrgyzstan, Laos, Lesotho, Liechtenstein, Luxembourg, Macedonia, Malawi, Mali, Moldova, Mongolia, Nepal, Niger, Paraguay, Rwanda, San Marino, Serbia, Slovakia, South Sudan, Switzerland, Tajikistan, Turkmenistan, Uganda, Uzbekistan, West Bank, Zambia, Zimbabwe; two of these, Liechtenstein and Uzbekistan, are doubly landlocked
note 3:
worldwide, some one-quarter of interior (non-coastal) borders are rivers; South America with 43% leads the continents, followed by North America with 32%, Africa with 30%, Europe with 23%, and Asia with 18%; Australia has no interior national river borders
Coastline:
356,000 km
note:
95 nations and other entities are islands that border no other countries, they include: American Samoa, Anguilla, Antigua and Barbuda, Aruba, Ashmore and Cartier Islands, The Bahamas, Bahrain, Baker Island, Barbados, Bermuda, Bouvet Island, British Indian Ocean Territory, British Virgin Islands, Cabo Verde, Cayman Islands, Christmas Island, Clipperton Island, Cocos (Keeling) Islands, Comoros, Cook Islands, Coral Sea Islands, Cuba, Curacao, Cyprus, Dominica, Falkland Islands (Islas Malvinas), Faroe Islands, Fiji, French Polynesia, French Southern and Antarctic Lands, Greenland, Grenada, Guam, Guernsey, Heard Island and McDonald Islands, Howland Island, Iceland, Isle of Man, Jamaica, Jan Mayen, Japan, Jarvis Island, Jersey, Johnston Atoll, Kingman Reef, Kiribati, Madagascar, Maldives, Malta, Marshall Islands, Mauritius, Mayotte, Federated States of Micronesia, Midway Islands, Montserrat, Nauru, Navassa Island, New Caledonia, New Zealand, Niue, Norfolk Island, Northern Mariana Islands, Palau, Palmyra Atoll, Paracel Islands, Philippines, Pitcairn Islands, Puerto Rico, Saint Barthelemy, Saint Helena, Saint Kitts and Nevis, Saint Lucia, Saint Pierre and Miquelon, Saint Vincent and the Grenadines, Samoa, Sao Tome and Principe, Seychelles, Singapore, Sint Maarten, Solomon Islands, South Georgia and the South Sandwich Islands, Spratly Islands, Sri Lanka, Svalbard, Taiwan, Tokelau, Tonga, Trinidad and Tobago, Turks and Caicos Islands, Tuvalu, Vanuatu, Virgin Islands, Wake Island, Wallis and Futuna
Maritime claims:
a variety of situations exist, but in general, most countries make the following claims measured from the mean low-tide baseline as described in the 1982 UN Convention on the Law of the Sea: territorial sea - 12 nm, contiguous zone - 24 nm, and exclusive economic zone - 200 nm; additional zones provide for exploitation of continental shelf resources and an exclusive fishing zone; boundary situations with neighboring states prevent many countries from extending their fishing or economic zones to a full 200 nm
Climate:
a wide equatorial band of hot and humid tropical climates, bordered north and south by subtropical temperate zones that separate two large areas of cold and dry polar climates
ten driest places on Earth (average annual precipitation):
McMurdo Dry Valleys, Antarctica 0 mm (0 in)
Arica, Chile 0.76 mm (0.03 in)
Al Kufrah, Libya 0.86 mm (0.03 in)
Aswan, Egypt 0.86 mm (0.03 in)
Luxor, Egypt 0.86 mm (0.03 in)
Ica, Peru 2.29 mm (0.09 in)
Wadi Halfa, Sudan 2.45 mm (0.1 in)
Iquique, Chile 5.08 mm (0.2 in)
Pelican Point, Namibia 8.13 mm (0.32 in)
El Arab (Aoulef), Algeria 12.19 mm (0.48 in)
ten wettest places on Earth (average annual precipitation):
Mawsynram, India 11,871 mm (467.4 in)
Cherrapunji, India 11,777 mm (463.7 in)
Tutunendo, Colombia 11,770 mm (463.4 in)
Cropp River, New Zealand 11,516 mm (453.4 in)
San Antonia de Ureca, Equatorial Guinea 10,450 mm (411.4 in)
Debundsha, Cameroon 10,299 mm (405.5 in)
Big Bog, US (Hawaii) 10,272 mm (404.4 in)
Mt Waialeale, US (Hawaii) 9,763 mm (384.4 in)
Kukui, US (Hawaii) 9,293 mm (365.9 in)
Emeishan, China 8,169 mm (321.6 in)
ten coldest places on Earth (lowest average monthly temperature):
Verkhoyansk, Russia (Siberia) -47°C (-53°F) January
Oymyakon, Russia (Siberia) -46°C (-52°F) January
Eureka, Canada -38.4°C (-37.1°F) February
Isachsen, Canada -36°C (-32.8°F) February
Alert, Canada -34°C (-28°F) February
Kap Morris Jesup, Greenland -34°C (-29°F) March
Cornwallis Island, Canada -33.5°C (-28.3°F) February
Cambridge Bay, Canada -33.5°C (28.3°F) February
Ilirnej, Russia -33°C (-28°F) January
Resolute, Canada -33°C (-27.4°F) February
ten hottest places on Earth (highest average monthly temperature):
Death Valley, US (California) 39°C (101°F) July
Iranshahr, Iran 38.3°C (100.9°F) June
Ouallene, Algeria 38°C (100.4°F) July
Kuwait City, Kuwait 37.7°C (100°F) July
Medina, Saudi Arabia 36°C (97°F) July
Buckeye, US (Arizona) 34°C (93°F) July
Jazan, Saudi Arabia 33°C (91°F) June
Al Kufrah, Libya 31°C (87°F) July
Alice Springs, Australia 29°C (84°F) January
Tamanrasset, Algeria 29°C (84°F) June
Terrain:
tremendous variation of terrain may be found on each of the continents; check the World “Elevation” entry for a compilation of terrain extremes; the world’s ocean floors also display extraordinary variation while the ocean surfaces form a dynamic, continuously changing environment; check the “Bathymetry” and “Major surface currents” entries under each of the five ocean entries (Arctic, Atlantic, Indian, Pacific, and Southern) for further information on oceanic environs
Ten Cave Superlatives:
compiled from “Geography - note(s)” under various country entries where more details may be found
largest cave:
Son Doong in Phong Nha-Ke Bang National Park, Vietnam is the World’s largest cave (greatest cross sectional area) and is the largest known cave passage in the world by volume; it currently measures a total of 38.5 million cu m (about 1.35 billion cu ft); it connects to Thung cave (but not yet officially); when recognized, it will add an additional 1.6 million cu m in volume
largest ice cave:
the Eisriesenwelt (Ice Giants World) inside the Hochkogel mountain near Werfen, Austria is the World’s largest and longest ice cave system at 42 km (26 mi)
longest cave:
Mammoth Cave, in west-central Kentucky, is the World’s longest known cave system with more than 650 km (405 mi) of surveyed passageways
longest salt cave:
the Malham Cave in Mount Sodom in Israel is the World’s longest salt cave at 10 km (6 mi); its survey is not complete and its length will undoubtedly increase
longest underwater cave:
the Sac Actun cave system in Mexico at 348 km (216 mi) is the longest underwater cave in the World and the second longest cave worldwide
longest lava tube cave:
Kazumura Cave on the island of Hawaii is the World’s longest and deepest lava tube cave; it has been surveyed at 66 km (41 mi) long and 1,102 m (3,614 ft) deep
deepest cave:
Veryovkina Cave in the Caucasus country of Georgia is the World’s deepest cave, plunging down 2,212 m (7,257 ft)
deepest underwater cave:
the Hranice Abyss in Czechia is the World’s deepest surveyed underwater cave at 404 m (1,325 ft); its survey is not complete and it could end up being some 800-1,200 m deep
largest cave chamber:
the Miao Room in the Gebihe cave system at China’s Ziyun Getu He Chuandong National Park encloses some 10.78 million cu m (380.7 million cu ft) of volume
largest bat cave:
Bracken Cave outside of San Antonio, Texas is the World’s largest bat cave; it is the summer home to the largest colony of bats in the World; an estimated 20 million Mexican free-tailed bats roost in the cave from March to October making it the World’s largest known concentration of mammals
bonus “cave” - the world’s largest sinkhole:
the Xiaoxhai Tiankeng sinkhole in Chongqing Municipality, China is 660 m deep, with a volume of 130 million cu m
Elevation:
highest point:
Mount Everest 8,849 m
lowest point:
Denman Glacier (Antarctica) more than -3,500 m (in the oceanic realm, Challenger Deep in the Mariana Trench is the lowest point, lying -10,924 m below the surface of the Pacific Ocean)
mean elevation:
840 m
top ten highest mountains (measured from sea level):
Mount Everest (China-Nepal) 8,849 m; K2 (Pakistan) 8,611 m; Kanchenjunga (India-Nepal) 8,598 m; Lhotse (Nepal) 8,516 m; Makalu (China-Nepal) 8,463 m; Cho Oyu (China-Nepal) 8,201 m; Dhaulagiri (Nepal) 8,167 m; Manaslu (Nepal) 8,163 m; Nanga Parbat (Pakistan) 8,125 m; Anapurna (Nepal) 8,091 m;
note -
Mauna Kea (United States) is the world’s tallest mountain as measured from base to summit; the peak of this volcanic colossus lies on the island of Hawaii, but its base begins more than 70 km offshore and at a depth of about 6,000 m; total height estimates range from 9,966 m to 10,203 m
top ten highest island peaks:
Puncak Jaya (New Guinea) 4,884 m (Indonesia)*; Mauna Kea (Hawaii) 4,207 m (United States); Gunung Kinabalu (Borneo) 4,095 m (Malaysia)*; Yu Shan (Taiwan) 3,952 (Taiwan)*; Mount Kerinci (Sumatra) 3,805 m (Indonesia); Mount Erebus (Ross Island) 3,794 (Antarctica); Mount Fuji (Honshu) 3,776 m (Japan)*; Mount Rinjani (Lombok) 3,726 m (Indonesia); Aoraki-Mount Cook (South Island) 3,724 m (New Zealand)*; Pico de Teide (Tenerife) 3,718 m (Spain)*;
note -
* indicates the highest peak for that Factbook entry
highest point on each continent:','8f522c677a8a31cb1a279b15a63618187d1e0185c378b39b042c3741c2d03dd1','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('48c16363873acee25b436907b9b3dfcd1448d35d1c4344eb9ee27e4227f275d9',2025,'WF','Wallis and Futuna','geography',26,'Asia - Mount Everest (China-Nepal) 8,849 m; South America - Cerro Aconcagua (Argentina) 6,960 m; North America - Denali (Mount McKinley) (United States) 6,190 m; Africa - Kilimanjaro (Tanzania) 5,895 m; Europe - El’brus (Russia) 5,633 m; Antarctica - Vinson Massif 4,897 m; Australia - Mount Kosciuszko 2,229 m
highest capital on each continent:
South America - La Paz (Bolivia) 3,640 m; Africa - Addis Ababa (Ethiopia) 2,355 m; Asia - Thimphu (Bhutan) 2,334 m; North America - Mexico City (Mexico) 2,240 m; Europe - Andorra la Vella (Andorra) 1,023 m; Australia - Canberra (Australia) 605 m
lowest point on each continent:
Antarctica - Denman Glacier more than -3,500 m; Asia - Dead Sea (Israel-Jordan) -431 m; Africa - Lac Assal (Djibouti) -155 m; South America - Laguna del Carbon (Argentina) -105 m; North America - Death Valley (United States) -86 m; Europe - Caspian Sea (Azerbaijan-Kazakhstan-Russia) -28 m; Australia - Lake Eyre -15
lowest capital on each continent:
Asia - Baku (Azerbaijan) -28 m; Europe - Amsterdam (Netherlands) -2 m; Africa - Banjul (Gambia); Bissau (Guinea-Bissau), Conakry (Guinea), Djibouti (Djibouti), Libreville (Gabon), Male (Maldives), Monrovia (Liberia), Tunis (Tunisia), Victoria (Seychelles) 0 m; North America - Basseterre (Saint Kitts and Nevis), Kingstown (Saint Vincent and the Grenadines), Panama City (Panama), Port of Spain (Trinidad and Tobago), Roseau (Dominica), Saint John’s (Antigua and Barbuda), Santo Domingo (Dominican Republic) 0 m; South America - Georgetown (Guyana) 0 m; Australia - Canberra (Australia) 605 m
Natural resources:
the rapid depletion of nonrenewable mineral resources, the depletion of forest areas and wetlands, the extinction of animal and plant species, and the deterioration in air and water quality pose serious long-term problems
Irrigated land:
3,242,917 sq km (2012 est.)
Major lakes (area sq km):
top ten largest natural lakes:
Caspian Sea (Azerbaijan, Iran, Kazakhstan, Russia, Turkmenistan) 374,000 sq km; Lake Superior (Canada, United States) 82,100 sq km; Lake Victoria (Kenya, Tanzania, Uganda) 62,940 sq km; Lake Huron (Canada, United States) 59,600 sq km; Lake Michigan (United States) 57,750 sq km; Lake Tanganyika (Burundi, Democratic Republic of the Congo, Tanzania, Zambia) 32,000 sq km; Great Bear Lake (Canada) 31,328 sq km; Lake Baikal (Russia) 31,500 sq km; Lake Malawi (Malawi, Mozambique, Tanzania) 22,490 sq km; Great Slave Lake (Canada) 28,568 sq km
note 1:
the areas of the lakes are subject to seasonal variation; only the Caspian Sea is saline, the rest are fresh water
note 2:
Lakes Huron and Michigan are technically a single lake because the flow of water between the Straits of Mackinac that connects the two lakes keeps their water levels at near-equilibrium; combined, Lake Huron-Michigan is the largest freshwater lake by surface area in the World
note 3:
if ranked by water volume, the Caspian Sea would still be first, but it would be followed Lakes Baikal, Tanganyika, Superior, and Malawi; Lake Superior contains more water than the other four North American Great Lakes (Erie, Huron, Michigan, Ontario) combined
Major rivers (by length in km):
top ten longest rivers:
Nile (Africa) 6,650 km; Amazon (South America) 6,436 km; Yangtze (Asia) 6,300 km; Mississippi-Missouri (North America) 6,275 km; Yenisey-Angara (Asia) 5,539 km; Huang He/Yellow (Asia) 5,464 km; Ob-Irtysh (Asia) 5,410 km; Congo (Africa) 4,700 km; Amur (Asia) 4,444 km; Lena (Asia) 4,400 km
note:
there are 21 countries without rivers: 3 in Africa (Comoros, Djibouti, Libya), 1 in the Americas (Bahamas), 8 in Asia (Bahrain, Kuwait, Maldives, Oman, Qatar, Saudi Arabia, United Arab Emirates, Yemen), 3 in Europe (Malta, Monaco, Holy See), 6 in Oceania (Kiribati, Marshall Islands, Nauru, Niue, Tonga, Tuvalu); these countries also do not have natural lakes
Major watersheds (area sq km):
summary statement:
a watershed is a drainage basin on an area of land where precipitation collects and drains off into a common outlet, such as into a river, bay, or other body of water; oceans ultimately take in the drainage from 83% of all land area; the remaining 17% of the land drains into internal (endorheic) basins, e.g., the Caspian Sea;
The World Factbook
lists 51 different watersheds across 102 countries; of these, 18 are in Asia, 9 in Europe, 9 in Africa, 8 in North and Central America, 5 in South America, and 2 in Australia; all watersheds with an area of at least 500,000 sq km have been included along with a number of smaller, regionally significant watersheds; together, these watersheds represent the surface hydrology water flows that are the World’s primary sources of fresh water for individual consumption, industry, and agriculture
Major aquifers:
summary statement:
aquifers are underground layers of water-bearing permeable rock formations; they include alluvial formations such as unconsolidated sand and gravel aquifers, sedimentary rock formations of sandstone and karst (carbonate rocks such as limestone) aquifers, as well as volcanic aquifers, and basement aquifers (igneous and metamorphic rocks that underlie sedimentary and volcanic rock sequences); groundwater from aquifers can be extracted using a water well;
The World Factbook
lists 37 major aquifers across 52 countries; of these, 13 are in Africa, 10 in Asia, 5 in North America, 3 in South America, 4 in Europe, and 2 in Australia; although aquifers can vary in size, the major aquifers listed in
The Factbook
contain the bulk of the stored volume of groundwater; the fresh water held in these aquifers represents more than 30% of the World’s fresh water; in the US, groundwater is primarily used for irrigation and globally, 70% of groundwater withdrawn is used for agriculture; groundwater also supplies almost half of all drinking water worldwide
Population distribution:
six of the world’s seven continents are widely and permanently inhabited; Asia is easily the most-populous continent with about 60% of the world’s population (China and India together account for over 35%); Africa comes in second with over 15% of the earth’s populace, Europe has about 10%, North America 8%, South America almost 6%, and Oceania less than 1%; the harsh conditions on Antarctica prevent any permanent habitation
Natural hazards:
large areas subject to severe weather (tropical cyclones); natural disasters (earthquakes, landslides, tsunamis, volcanic eruptions)
volcanism:
volcanism is a fundamental driver and consequence of plate tectonics, the physical process reshaping the Earth’s lithosphere; the World is home to more than 1,500 potentially active volcanoes, with over 500 of these having erupted in historical times; an estimated 500 million people live near these volcanoes; associated dangers include lava flows, lahars (mudflows), pyroclastic flows, ash clouds, ash fall, ballistic projectiles, gas emissions, landslides, earthquakes, and tsunamis; in the 1990s, the International Association of Volcanology and Chemistry of the Earth’s Interior, created a list of 16 Decade Volcanoes worthy of special study because of their great potential for destruction: Avachinsky-Koryaksky (Russia), Colima (Mexico), Etna (Italy), Galeras (Colombia), Mauna Loa (United States), Merapi (Indonesia), Nyiragongo (Democratic Republic of the Congo), Rainier (United States), Sakurajima (Japan), Santa Maria (Guatemala), Santorini (Greece), Taal (Philippines), Teide (Spain), Ulawun (Papua New Guinea), Unzen (Japan), Vesuvius (Italy); see second note under “Geography - note”
Volcano statistics and superlatives:
countries with the most volcanoes (Holocene Epoch, the past 12,000 years):
United States (162), Japan (122), Indonesia (120), Russia (117), Chile (91);
note
- roughly 1,350 volcanoes have erupted over this time period; about 40-50 eruptions are ongoing at any one time; the frequency of volcanoes has not increased
longest erupting volcano:
Santa Maria volcano in Guatemala has been constantly erupting since 22 June 1922;
note
- the Yasur volcano on Tanna Island in Vanuatu was observed to be erupting by Captain Cook in 1774 and has been in constant activity since then, but it is not cited since it has no clear start date; research (tephra stratigraphy and radiocarbon dating) shows that activity may have begun on Yasur ca. A.D. 1270 and so has persisted for over 750 years
highest volcano (above sea level):
Nevado Ojos del Salado (6,893 m; 22,615 ft) on the Chile-Argentina border is the World’s highest volcano above sea level and the highest peak in Chile
highest volcano (from base):
Mauna Kea (United States) is the World’s tallest mountain as measured from base to summit; the peak of this volcanic colossus lies on the island of Hawaii, but its base begins more than 70 km offshore and at a depth of about 6,000 m; total height estimates range from 9,966 m to 10,203 m
Wonders of the World: The Seven Wonders of the Ancient World:
The conquests of Alexander the Great (r. 336-323 B.C.) in the fourth century B.C. fostered the spread of Greek culture to the lands bordering the eastern Mediterranean and through much of the Middle East, ushering in what is today referred to as the Hellenistic Period (323-31 B.C.). Guidebooks compiled by Hellenistic sightseers focused on outstanding monuments in those parts of the world now brought into the Hellenistic sphere: Persia, Egypt, and Babylon. Generally, seven were emphasized since that number was considered magical, perfect, and complete. Not all Wonders lists from ancient times agreed completely, but generally six of the seven consistently appeared (the massive Walls of Babylon sometimes substituted for the Lighthouse of Alexandria). The seven described below represent the “classic” Seven Wonders most often cited.
1. The Great Pyramid of Egypt:
The oldest of the Seven Wonders, the Great Pyramid is the only one that remains largely intact. Commissioned by the Pharaoh Khufu (r. ca. 2589-2566 B.C.), it is the largest of the three pyramids at Giza. It served as the ruler’s tomb and was built over a period of some 20 years, concluding about 2560 B.C. Estimated to have been 146.5 m tall when completed, it was the tallest man-made structure in the world for over 3,800 years (until the 14
th
century A.D.). Most of the original limestone casing stones that formed the outer smooth surface of the pyramid are gone. Today, the pyramid’s height is about 139 m.
2. The Hanging Gardens of Babylon:
This is the only one of the ancient Seven Wonders for which a definitive location has never been established. There are no surviving Babylonian texts mentioning the Gardens, nor have any archeological remains ever been discovered in today’s Iraq. According to tradition, the Gardens were a remarkable feat of engineering with an ascending series of mud-brick-tiered gardens containing a variety of trees, shrubs, and vines that when viewed from below resembled a leafy green mountain. The Gardens are frequently attributed to the Neo-Babylonian King Nebuchadnezzar II (r. 605-562 B.C.), who had them built for his Median wife Queen Amytis, who missed the green hills and valleys of her homeland.
3. The Temple of Artemis (Artemision) at Ephesus:
This Greek temple at Ephesus (3 km southwest of Selcuk in present-day western Turkey), dedicated to the goddess Artemis, was completely rebuilt twice: once after a 7
th
century B.C. flood and then following a 356 B.C. act of arson. In its final form it was judged to be one of the Seven Wonders and it survived for 600 years. The magnificent building was composed entirely of marble. Its massive dimensions were reported as 130 m by 69 m, with 127 columns, each some 18 m tall. The Temple was damaged in a Gothic raid in A.D. 268 and finally closed by Christians in the early-to-mid 5
th
century. The structure was dismantled in succeeding centuries and today almost nothing of the Temple remains.
4. The Mausoleum of Halicarnassus:
Constructed in about 350 B.C., the Mausoleum of Halicarnassus was located on the site of the present-day city of Bodrum in southwestern Turkey. It was the tomb of Mausolus, a Persian ruler, and his wife. (It is from the ruler’s name that the term mausoleum is derived.) The structure stood about 45 m high and took some 20 years to complete. A series of earthquakes between the 12
th
and 15
th
centuries A.D. devastated the structure, the last of the original Seven Wonders to be destroyed.
5. The Colossus of Rhodes:
This statue of the Greek sun god Helios, constructed to celebrate Rhodes’ successful repulse of a siege, was made of iron tie bars to which brass or bronze plates were attached to form a skin. Contemporary descriptions list its height at about 70 cubits or some 33 m – approximately the same height as the Statue of Liberty from heel to top of head (34 m) – thus making it the tallest statue in the ancient world. Completed in about 280 B.C. at the entrance to Rhodes harbor, the monument only stood for approximately 54 years until it toppled in a 226 B.C. earthquake. The impressive remains lay on the ground for over 800 years before finally being sold for scrap.
6. The Lighthouse (Pharos) of Alexandria:
Completed around 275 B.C., the Alexandria Lighthouse stood on Pharos Island at the entrance to the Egyptian port city for some 1,600 years! It was severely damaged by three earthquakes between A.D. 956 and 1323, when it was deactivated. We have a fairly good idea of the shape of the structure since it appears on a number of ancient coins. A solid square base, which made up about half of the height, supported an octagonal middle section, and a cylindrical top. The height of the structure is thought to have been at least 100 m and perhaps as high as 140 m. (The tallest lighthouse in the world today is the Jeddah Light in Saudi Arabia, which stands at 133 m.) At its apex stood a mirror that reflected sunlight during the day; a fire burned at night. Since it could be seen at a very great distance, the Pharos light served as a reassuring beacon for mariners from all parts of the Mediterranean.
7. The Statue of Zeus at Olympia in Greece:
The giant seated statue of the king of the Greek gods in the sanctuary of Olympia was completed by the Greek sculptor Phidias in approximately 435 B.C. Roughly 13 m tall, it was constructed of ivory plates and gold panels on a wooden framework; the god’s throne was ornamented with ebony, ivory, gold, and precious stones. With the rise of Christianity, the sanctuary at Olympia fell into disuse; the details of the statue’s final destruction are unknown.
note:
The Lighthouse of Alexandria may have been the last of the Wonders to be completed (ca. 275 B.C.) and the Colossus of Rhodes was the first to be destroyed in about 226 B.C., so the Seven Wonders existed at the same time for only some 50 years in the middle of the third century B.C.
The New Seven Wonders of the World:
A private initiative to come up with a new list for seven of the world’s wonders sprang up early in the new Millennium. Worldwide balloting – via the Internet or by telephone – took place covering a list of 200 existing monuments. Reportedly over 100 million votes were cast over a period of several years and the final list was announced on 7-7-2007. Even though the polling was unscientific, the seven “winners” were a worthy compilation of extraordinary Wonders to be found around the world. All seven of the New Wonders are inscribed as UNESCO World Heritage Sites and are frequently cited in the literature.
1. Chichen Itza, Yucatan, Mexico:
This archeological site includes the impressive remains of a large pre-Columbian Maya city that flourished from ca. A.D. 600-1100. Among the outstanding structures at the site are the massive Temple of the Warriors complex, an Observatory (El Caracol), the Great Ball Court, and the Sacred Cenote (sinkhole) where offerings were made. The most famous building, however, is the step-pyramid known as the Temple of Kukulcan that dominates the center of the site and serves as the symbol of Chichen Itza. The pyramidal structure is 24 m high; the crowning temple adds another 6 m. Although located in the dense jungles of Yucatan, it remains one of the most visited tourist sites in Mexico.
2. The Colosseum, Rome, Italy:
Construction began with the Roman Emperor Vespasian in A.D. 72 and was completed by his son Titus in A.D. 80. Some further modifications were made by Domitian (A.D. 81-96). The three emperors make up the Flavian Dynasty, thus providing the alternate name for the structure as the Flavian Amphitheater. The massive structure is estimated to have seated, on average, about 65 thousand spectators and was most famously used for gladiatorial contests and public spectacles. Substantially ruined by earthquakes and thieves who looted much of the stone, the structure nonetheless remains an iconic symbol of Rome. The Colosseum is one of the most popular tourist attractions in the World.
3. Christ the Redeemer Statue, Rio de Janeiro, Brazil:
Built between 1922 and 1931, the 30-meter-tall sculpture is reputed to be the largest Art Deco statue in the World. Its pedestal provides another 8 m in height and the arms stretch out to 28 m. Constructed of reinforced concrete and soapstone, the statue has become the cultural icon not only of Rio but also of Brazil.
4. Great Wall, China:
The name refers to a remarkable series of fortification systems that stretched across the northern historical borders of China and served as protection against various nomadic peoples. The earliest of these walls date to the 7
th
century B.C.; certain stretches began to be linked in the 3
rd
century B.C. and successive dynasties added to or maintained various sections of the walls. The best known and best-preserved portions of the wall are those built by the Ming Dynasty (1368-1644). An archeological survey revealed that the Wall and all its associated branches measures 21,196 km. Winding through amazingly varied terrain, the Great Wall is acknowledged as one of the most impressive architectural feats in history.
5.Machu Picchu, Cuzco Region, Peru:
Perhaps the most spectacular archeological site in the Americas, the Inca citadel of Machu Picchu, situated on a 2,430 m Andean mountain ridge, is now thought to have been erected as an estate for the Inca Emperor Pachacuti (r. 1438-1471). Additionally, it may also have served as a religious sanctuary. Built between about 1450 and 1460, it was abandoned approximately a century later, at the time of the Spanish conquest. Construction was carried out in the classic Inca style of polished, dry-stone, fitted walls. Some 750 people lived at this royal estate, most of them support staff to the nobility. The site is roughly divided into an agricultural sector (with myriad terraces for raising crops) and an urban sector. The latter is composed of an upper town (with temples) and a lower town (with warehouses). Some of the religious monuments include: the Intiwatana (a carved, ritual stone that served as a type of sundial and that is referred to as “The Hitching Post of the Sun”); the Torreon or Temple of the Sun, a small tower that likely served as a type of observatory; and the Intimachay, a sacred cave with a masonry entrance.
6.Petra, Ma’an, Jordan:
Petra is believed to have been established in the 4
th
century B.C. as the capital of the Nabataean Kingdom, an entity that grew fabulously wealthy as the nexus of trade routes in the southern Levant. The kingdom retained its independence until annexed by the Roman Empire in A.D. 106. The city is justifiably famous for two things, its stunning rock-cut architecture and its water conduit system, which allowed the Nabataeans to control and store the water supply in this desert region and create an artificial oasis. At its peak in the 1
st
century A.D., the city may have had a population of 20 thousand.
7. Taj Mahal, Agra, Uttar Pradesh, India:
This gorgeous ivory-white mausoleum – described as “one of the universally admired masterpieces of the World’s heritage” – was commissioned in 1632 by Shah Jahan (r. 1628-1658) as the final resting place for his favorite wife, Mumtaz Mahal. The building also houses the tomb of Shah Jahan himself. The Taj Mahal is the centerpiece of an entire 17-hectare complex that also includes a guest house, a mosque, and formal gardens. The entire project was not completed until about 1653. The Taj Mahal remains one of the most visited tourist sites in the World.
note:
The Great Pyramid of Egypt, the only surviving Wonder of the ancient Seven, received an honorary status among the New Seven Wonders. Its inclusion enabled a Wonder to be listed for five of the six habitable continents (all but Australia).
The World Factbook’s Seven Natural Ultra-Wonders of the World:
While all of the above Wonders are indeed outstanding, their presence in any type of list is entirely
subjective
. There are many other fabulous sites around the world that are equally worthy of being designated as Wonders. (An example is the inclusion of Chichen Itza from Mexico. While it is spectacular, it became a ‘Wonder’ for its popularity as a tourist site. Equally worthy in the same country is Teotihuacan, a far larger site outside of Mexico City that has two immense pyramids that dwarf the one at Chichen Itza.)
Taking these considerations into account,
The World Factbook
has come up with a Seven Wonders list that is indisputable, i.e., a list derived in a completely
objective
manner. A decision was made to focus on natural wonders and not anything man-made. These Wonders are all the biggest in their respective categories (they cannot be topped) and so there can be no dispute with the choice, therefore the ‘ultra’ designation. This fact distinguishes the
Factbook
listing from other Seven Natural Wonders lists that have been compiled in the past.
1. Amazonia:
A trans-national Wonder that is: a. the World’s largest collection of land biodiversity, b. the World’s largest rainforest, and c. includes the World’s largest swamp in the Amazon River floodplain; mostly in Brazil, Peru, and Colombia, but also in Venezuela, Ecuador, Bolivia, Guyana, Suriname, and French Guiana.
2. Central Indo-Pacific Region:
A Wonder hotspot that is the World’s largest collection of marine biodiversity; best represented by the
Coral Triangle
in the tropical waters around the Philippines, Indonesia, Malaysia, Papua New Guinea, the Solomon Islands, and Timor-Leste; as well as by the
Great Barrier Reef
(the World’s largest reef) in Australia.
3. The Aurora (Aurora Borealis and Aurora Australis; aka the Polar Lights):
The World’s largest light display that never ceases to awe; seen in countries of the northern latitudes, as well as those of the southern latitudes and Antarctica.
4. Mount Everest and the Himalayas:
The World’s tallest mountain and mountain range above sea level that stretches across Nepal, China (Tibet), India, Pakistan, and Bhutan (see alternate below).
5. Victoria Falls:','af0ff8001c1dd9aba130b09d199fffe87500b5cbadfde0f6c197894f7950b040','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('964d14da4a9f5aaea767c41618bb3fdc6fe292c0523d001536904c1e92ff4bcc',2025,'WF','Wallis and Futuna','geography',27,'The World’s largest unbroken waterfall on the border between Zambia and Zimbabwe (see alternates below).
6. Sahara:
The World’s largest hot desert that spreads across Algeria, Chad, Egypt, Libya, Mali, Mauritania, Morocco, Niger, Sudan, and Tunisia (see alternate below).
7. Animal Migrations:
The Earth is full of astounding migrations – occurring daily, seasonally, or annually – that are truly awe-inspiring natural wonders. A few extraordinary examples are: a. the diel vertical migrations (DVM, the World’s largest animal migration in terms of biomass and number of animals participating), which occur twice daily in all the oceans when zooplankton (microscopic animals) and fish rise to near the surface at night to feed on phytoplankton (microscopic plants) and then with the return of day dive back into the depths to hide in dark waters; b. the Arctic tern’s annual round trip of 71,000 km (from the Northern Hemisphere to the Southern Hemisphere and back (the World’s longest avian migration); or c. the 22,000 km annual migration of the humpback whale (World’s longest mammal migration).
Alternates:
Mountain alternate (no. 4). If measured strictly from base to peak, then the World’s tallest and largest mountains would be on the
Island of Hawaii
, which includes both the World’s tallest mountain [Mauna Kea]
and
the World’s largest active volcano and most voluminous mountain [Mauna Loa]); United States (Hawaii).
Waterfall alternate (no. 5). What constitutes the ‘biggest’ waterfall(s) can be approached in a number of ways. Depending on one’s viewpoint,
Iguazu Falls
(World’s largest waterfall system (275 drops)) in Argentina and Brazil, or
Angel Falls
(World’s tallest waterfall) in Venezuela could substitute.
Desert alternate (no. 6). If a desert is defined as a barren area where little precipitation occurs, then
Antarctica
with the World’s largest polar desert would certainly qualify; it is about 1.5 times the size of the Sahara. The southern continent does not belong to any one country but is a condominium governed by parties to the Antarctic Treaty.
note:
A question might arise, how about the World’s largest canyon? The Grand Canyon (United States, Arizona) is sometimes mentioned as a Wonder of the World, but ‘largest’ canyons can be notoriously difficult to define and measure. Does one go by length, depth, or total area of canyon system? Then too, there are largely inaccessible canyons in the Himalayas that have never been properly surveyed and massive canyons are known to exist in some ice-covered parts of Greenland and Antarctica. Therefore, it is not possible to come up with a superlative canyon.
Geography - note:
note 1:
the World is now thought to be about 4.55 billion years old, just about one-third of the 13.8-billion-year age estimated for the universe; the earliest widely accepted date for life appearing on Earth is 3.48 billion years ago, but this date is conservative and may get pushed back further
note 2:
although earthquakes can strike anywhere at any time, the vast majority occur in three large zones of the Earth; the world’s greatest earthquake belt, the Circum-Pacific Belt (popularly referred to as the Ring of Fire), is the zone of active volcanoes and earthquake epicenters bordering the Pacific Ocean; about 90% of the World’s earthquakes (81% of the largest earthquakes) and some 75% of the World’s volcanoes occur within the Ring of Fire; the belt extends northward from Chile, along the South American coast, through Central America, Mexico, the western US, southern Alaska and the Aleutian Islands, to Japan, the Philippines, Papua New Guinea, island groups in the southwestern Pacific, and New Zealand
the second prominent belt, the Alpide, extends from Java to Sumatra, northward along the mountains of Burma, then eastward through the Himalayas, the Mediterranean, and out into the Atlantic Ocean; it accounts for about 17% of the world’s largest earthquakes; the third important belt follows the long Mid-Atlantic Ridge
note 3:
information on the origin sites for many of the World’s major food crops may be found in the “Geography - note” for the following countries: Argentina, Bolivia, Brazil, China, Ecuador, Ethiopia, Indonesia, Mexico, Papua New Guinea, Paraguay, Peru, and the United States','23b41610c86d22da8508a1c3bb58c0314f15265cf4a83fc42fb913d4be4af68d','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b4cc39bcbb7ab5c79f053f6d44b5abc60c450623ff9348737e0f4b2a361a6055',2025,'YE','Yemen','geography',2,'Location:
Middle East, bordering the Arabian Sea, Gulf of Aden, and Red Sea, between Oman and Saudi Arabia
Geographic coordinates:
15 00 N, 48 00 E
Map references:
Middle East
Area:
total:
527,968 sq km
land:
527,968 sq km
water:
0 sq km
note:
includes Perim, Socotra, the former Yemen Arab Republic (YAR or North Yemen), and the former People’s Democratic Republic of Yemen (PDRY or South Yemen)
comparison ranking:
total 52
Area - comparative:
almost four times the size of Alabama; slightly larger than twice the size of Wyoming
Land boundaries:
total:
1,601 km
border countries (2):
Oman 294 km; Saudi Arabia 1,307 km
Coastline:
1,906 km
Maritime claims:
territorial sea:
12 nm
contiguous zone:
24 nm
exclusive economic zone:
200 nm
continental shelf:
200 nm or to the edge of the continental margin
Climate:
mostly desert; hot and humid along west coast; temperate in western mountains affected by seasonal monsoon; extraordinarily hot, dry, harsh desert in east
Terrain:
narrow coastal plain backed by flat-topped hills and rugged mountains; dissected upland desert plains in center slope into the desert interior of the Arabian Peninsula
Elevation:
highest point:
Jabal an Nabi Shu’ayb 3,666 m
lowest point:
Arabian Sea 0 m
mean elevation:
999 m
Natural resources:
petroleum, fish, rock salt, marble; small deposits of coal, gold, lead, nickel, and copper; fertile soil in west
Land use:
agricultural land:
44.5% (2018 est.)
arable land:
2.2% (2018 est.)
permanent crops:
0.6% (2018 est.)
permanent pasture:
41.7% (2018 est.)
forest:
1% (2018 est.)
other:
54.5% (2018 est.)
Irrigated land:
6,800 sq km (2012)
Population distribution:
the vast majority of the population is found in the Asir Mountains (part of the larger Sarawat Mountain system), located in the far western region of the country
Natural hazards:
sandstorms and dust storms in summer
volcanism:
limited volcanic activity; Jebel at Tair (Jabal al-Tair, Jebel Teir, Jabal al-Tayr, Jazirat at-Tair) (244 m), which forms an island in the Red Sea, erupted in 2007 after awakening from dormancy; other historically active volcanoes include Harra of Arhab, Harras of Dhamar, Harra es-Sawad, and Jebel Zubair, although many of these have not erupted in over a century
Geography - note:
strategic location on Bab el Mandeb, the strait linking the Red Sea and the Gulf of Aden, one of world’s most active shipping lanes','8465eb4debcc45bdd14830dcee4e7bef206d9c3be68a5c63f43660979ed4fa8c','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('502691693dfac6cbe820621de329a6d70e5b3321d409ae3fabdc4fd5a6c90507',2025,'ZM','Zambia','geography',2,'Location:
Southern Africa, east of Angola, south of the Democratic Republic of the Congo
Geographic coordinates:
15 00 S, 30 00 E
Map references:
Africa
Area:
total:
752,618 sq km
land:
743,398 sq km
water:
9,220 sq km
comparison ranking:
total 40
Area - comparative:
almost five times the size of Georgia; slightly larger than Texas
Land boundaries:
total:
6,043.15 km
border countries (8):
Angola 1,065 km; Botswana 0.15 km; Democratic Republic of the Congo 2,332 km; Malawi 847 km; Mozambique 439 km; Namibia 244 km; Tanzania 353 km; Zimbabwe 763 km
Coastline:
0 km (landlocked)
Maritime claims:
none (landlocked)
Climate:
tropical; modified by altitude; rainy season (October to April)
Terrain:
mostly high plateau with some hills and mountains
Elevation:
highest point:
Mafinga Central 2,330 m
lowest point:
Zambezi river 329 m
mean elevation:
1,138 m
Natural resources:
copper, cobalt, zinc, lead, coal, emeralds, gold, silver, uranium, hydropower
Land use:
agricultural land:
31.7% (2018 est.)
arable land:
4.8% (2018 est.)
permanent crops:
0% (2018 est.)
permanent pasture:
26.9% (2018 est.)
forest:
66.3% (2018 est.)
other:
2% (2018 est.)
Irrigated land:
1,560 sq km (2012)
Major lakes (area sq km):
fresh water lake(s):
Lake Tanganyika (shared with Democratic Republic of Congo, Tanzania, and Burundi) - 32,000 sq km; Lake Mweru (shared with Democratic Republic of Congo) - 4,350 sq km; Lake Bangweulu - 4,000-15,000 sq km seasonal variation
Major rivers (by length in km):
Congo river source (shared with Angola, Republic of Congo, and Democratic Republic of Congo [m]) - 4,700 km;
Zambezi river source (shared with Angola, Namibia, Botswana, Zimbabwe, and Mozambique [m]) - 2,740 km
note
– [s] after country name indicates river source; [m] after country name indicates river mouth
Major watersheds (area sq km): Atlantic Ocean drainage:
Congo (3,730,881 sq km)
Indian Ocean drainage:
Zambezi (1,332,412 sq km)
Major aquifers:
Upper Kalahari-Cuvelai-Upper Zambezi Basin
Population distribution:
one of the highest levels of urbanization in Africa; high density in the central area, particularly around the cities of Lusaka, Ndola, Kitwe, and Mufulira as shown in this population distribution map
Natural hazards:
periodic drought; tropical storms (November to April)
Geography - note:
landlocked; the Zambezi forms a natural riverine boundary with Zimbabwe; Lake Kariba on the Zambia-Zimbabwe border forms the world’s largest reservoir by volume (180 cu km; 43 cu mi)','68bf0432383e09c2bec3a23a023e36d996301e4ea34cfa4faab759dcbf8b5191','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('524d6a3bcc4d3148cf3fc8f28b6432762e8c81e32bf4e6124b46d897060100c6',2025,'ZW','Zimbabwe','geography',13,'Location:
Southern Africa, between South Africa and Zambia
Geographic coordinates:
20 00 S, 30 00 E
Map references:
Africa
Area:
total:
390,757 sq km
land:
386,847 sq km
water:
3,910 sq km
comparison ranking:
total 62
Area - comparative:
about four times the size of Indiana; slightly larger than Montana
Land boundaries:
total:
3,229 km
border countries (4):
Botswana 834 km; Mozambique 1,402 km; South Africa 230 km; Zambia 763 km
Coastline:
0 km (landlocked)
Maritime claims:
none (landlocked)
Climate:
tropical; moderated by altitude; rainy season (November to March)
Terrain:
mostly high plateau with higher central plateau (high veld); mountains in east
Elevation:
highest point:
Inyangani 2,592 m
lowest point:
junction of the Runde and Save Rivers 162 m
mean elevation:
961 m
Natural resources:
coal, chromium ore, asbestos, gold, nickel, copper, iron ore, vanadium, lithium, tin, platinum group metals
Land use:
agricultural land:
42.5% (2018 est.)
arable land:
10.9% (2018 est.)
permanent crops:
0.3% (2018 est.)
permanent pasture:
31.3% (2018 est.)
forest:
39.5% (2018 est.)
other:
18% (2018 est.)
Irrigated land:
1,740 sq km (2012)
Major rivers (by length in km):
Zambezi (shared with Zambia [s]), Angola, Namibia, Botswana, and Mozambique [m]) - 2,740 km; Limpopo (shared with South Africa [s], Botswana, and Mozambique [m]) - 1,800 km
note
– [s] after country name indicates river source; [m] after country name indicates river mouth
Major watersheds (area sq km): Indian Ocean drainage:
Zambezi (1,332,412 sq km)
Internal
(endorheic basin)
drainage:
Okavango Basin (863,866 sq km)
Major aquifers:
Upper Kalahari-Cuvelai-Upper Zambezi Basin
Population distribution:
Aside from major urban agglomerations in Harare and Bulawayo, population distribution is fairly even, with slightly greater overall numbers in the eastern half as shown in this population distribution map
Natural hazards:
recurring droughts; floods and severe storms are rare
Geography - note:
landlocked; the Zambezi forms a natural riverine boundary with Zambia; in full flood (February-April) the massive Victoria Falls on the river forms the world’s largest curtain of falling water; Lake Kariba on the Zambia-Zimbabwe border forms the world’s largest reservoir by volume (180 cu km; 43 cu mi)','23470e2128f4897c4a8b52425254ec2108eebbdb151a22f5f1016158de6a4fb5','internet-archive','CIA-World-Factbook-collection','epub','e9f2809e524c1794ce13993653de6ae13a1bffb32c316e1229c0e16090387a8e','https://archive.org/download/CIA-World-Factbook-collection/The%202024-2025%20CIA%20World%20Factbook%20by%20Central%20Intelligence%20Agency.epub','epub-html') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);

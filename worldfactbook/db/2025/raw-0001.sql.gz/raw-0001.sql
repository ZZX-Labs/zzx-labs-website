SET NAMES utf8mb4;
CREATE TABLE IF NOT EXISTS worldfactbook_chunks (
  chunk_id CHAR(64) NOT NULL,
  edition_year SMALLINT UNSIGNED NOT NULL,
  entity_code VARCHAR(24) NOT NULL DEFAULT '',
  entity_name VARCHAR(160) NOT NULL DEFAULT '',
  category VARCHAR(96) NOT NULL,
  ordinal INT UNSIGNED NOT NULL,
  content MEDIUMTEXT NOT NULL,
  content_sha256 CHAR(64) NOT NULL,
  source_provider VARCHAR(64) NOT NULL,
  source_identifier VARCHAR(255) NOT NULL,
  source_format VARCHAR(32) NOT NULL,
  source_sha256 CHAR(64) NOT NULL,
  source_url TEXT NOT NULL,
  extractor VARCHAR(64) NOT NULL,
  PRIMARY KEY (chunk_id),
  KEY idx_wfb_year_category (edition_year, category),
  KEY idx_wfb_entity_year (entity_code, edition_year),
  KEY idx_wfb_source_sha (source_sha256)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2c98bba44d7cffcb0dd4c3d3150618303049a738d1b5b44b83b1ae4e2ca9f941',2025,'','','raw',1,'Approved for Release: 2025/12/08 C071 83805,
Venezuela ‘Or Wot Fok
Cont ili hi
blcatons a
World Facthook (lbraryipublicatjonsl
Approved for Release: 2025/12/08 C07183805
‘Approved for Release: 2025/12/08 CO7183805.
~ Background (- MocaMnotneariddetd himiv25): This entry usually highlights major historic eventa end current lesuee end
* Inglude & statement about one or two kay future trenda, a : : ed
a. nee "Qc a ~
es ons of three couririea that emerged from the colapee of Gran Coloribla In 1830 (the others ng''Eouedor and)
: » New Granadb which became Coloma), For moet ofthe fr helo he 20h cortury, Venaziele was fed by pevesaly :
: benavolent pale puangTen who promoted the cll Industry and lowed for some social reforms. Democretically elected L-
pd Its powers
; ing witlespread shortages of basis consumer goods, medicine, and medical suppliey.
+ Geography f: Venezuela : : i ‘ 4 ; ‘
Location (. regia endde himis276): This entry Kientifies the country’s regional location, neighboring countries, and
Norther Soith America, dering the Caribbean Sea end the North Avetic Ocean, between Colombia grid Guyana
sognap d ‘This entry Includes rounded latflude and longitude Eigures for the
centroid orjcanter point of a j expreased in degrees and minutes; & ia based on the focations the
Names Seive {GN8), matninined by the National Geospaiis}intatigence Agency on behalf of the US Board on Geographic
re : : . : s oa
7" (Mfieidal27?. . ts :
, SOON, s8gaw 7 : sts ; 7 7 Q
Map reference: (docainotesanddefa,htmi#276): This entry Includes the name of the Factbook reference map on which ''@ ,
iad, GOUurty be fours’. Note that boundary representations on these mapa are not necessasfly authoritative. The entryon -
77. ae phi coordinates msy be helpful in finding some emaier counties. . 4
‘South Ametica =~ :
“Area (_Jddeslnotesanddefs.htmit270}: Thie entry Includes three subflads, Total area le the aurn of ail lard and water areas
debmited & ‘international boundaries and/oc constines. Land area Is tha aggregate ofall surfaces delimited by
intemational ~
. 7, bound op andior cosstines, excluding inland water bodies (lakes, reservors, rivera), Water aréa Is the eum of the surfaces of
2-2; 2 ate bodies, such as lakes, feservoirs, or vers, es delintied by Imlarnetional boundaries andlor coastlines.
ei: z . : - ; é. eae :
''. ,, “htips://spww.cia.govlibreryfpublications/the-world-fubtbook/geos/vehtml °° ~=—=—=—«5/17/2019
etter nntaerremnerrrn FA ODTOVE for Release: 2025/12/08 CO7183805-———-______-
‘Approved for Release: 2025/12/08 CO7183805:
qm (. octane anak This try
: ations Convention Law of
hat hui more moderate in noha
“Terrain (./doea
6, Cee ‘
“A hains and Maracaibo | Lowands’ in narthweat — pains fiignos);’ Gulane Highlands In gor saat a
; “Zevaton t pie aca This entry neces the ‘mean nacelle and sievatlon sx a8, — pole ind,
“Iga polnd Cartobean Sea 0 m
Hanes Pico Bolivar 4,878 m
m Pp fs t- a , oy
,cia.govilibeésy/publivationsithe-world-féétbook/geas/ve.htm! “. S/LF#2019''. *
Approved for Release: 2025/12/08 C07183805
Approved for Release: 2025/12/08 CO7183805.
Venezuela ~@ue World Factbook = Central Intelligenc@Meency *) Page 4 of 28 °
3 ose ( MdocaMnotenandcte.himis287): T Ta enty ists « country’s miners, pairoloum; hylropower, and other
senqurces of mercial importance, such as rere earlit elements (REEs) fn goniea, procs eppede :
ee hss es
” rubber that a Se pane caehe te ease Srerefeieyen cpl
Balhuhi#VE)
‘aban ot eet 008 2 4
. ) it pra sar: 2.08 01 eet)
“Tota (seaman Ty eer sat ct daa ta
89. htmiVE) , oe a0
dish (.fdocamoteehnddefa himlsS4a): This erty providoe anna aise Hm pn apr
it eine pen ah, dost ve ery ge. csi
.
0 be coiatdits isi neni weetem
_— 4 an ic ng eto srt nora st
U4 {. tmilk2e2); Th ny Int pote neural ators, For curries whore volo
# volcantem subfield highlights history acve volcancea.
‘
IrimidA284):
J exvtronmental egreements into two levels « ee ee ee feted in *
ee ee ts .
& farciic Treaty, victim Climate Change, Climate Change-Xyoto Protoca, Desertifoation, Eni
Hazardous fap m Mariné Life Consecvation, Ozote Scions
; o jected agreements
nae ey ie nn pe tn.
a
try en ma rine os — a
.
sa hoe somo ofthe moei unique gectogy in he word: tapua are mesaive table-top mountains ofthe western,
ighlands that tend to be fecleted.and thus support unique endemic plant and animal species; thelr sheer cffsides
i gore of fre moet epeciaculerweterae in the word inung Angel Fa, te west highest 070 fat crops of.
1
cis. gov/library/publications/the-world-fidtbook/geos/ve.html snag S
i
Approved for Release: 2025/12/08 C07183805. ~
Approved for Release: 2025/12/08 CO7183805.
“South Amé ca : Venezuela he World Factbook - Central Inteligenf{\\gency Page Sof 28 =
Acapecred {Jecandasandt ini; Ti ry geen eto fom te Us Buea te Canin bone ot dior
popula) Censuses, vitel siatieticg registration aysterns, or sample surveys pertaining to the recent end] on
pi bout fulure trends, The tote! population presents one overall messure of the potential Impact of country on the
on to the world: 43 (Miekial336renk himieve} ©
Simla): a Say eres Pa amet ing Nene Se ewe -naun nd eect,
an(s) “ ; 4 :
gro (celtic ng ok ip tog wh eye
: p nageen pee of pocuny ‘
Bp fen, Poruguoes Arab, German, Affican, Indigenous paople -
k.Mocahotosandde sry rok bg engage ack nach any a wan,
* ny thet Oficial netionsl or regional languages: “When dete Is avaliable, the languages spoken in each courffry are broken
. down accord 9 ton paca ofthe taal popuationepecing sch enguge on at language For hose core wit:
ve fears ia cr bad ners age onan GN 7
{ Q dialects
_, Rafigionsa (4 docenotesanddets, himi#401); Tie nti an ordered Bing of regione ty adherens stating withthe largest :
i otimes includes the percert of total population. The core chanscterietica and and Walefe of the world''s major religions
ip bd below. Bahat- + Founded by Mirza HusayreAd (known 8s Babalu''ah) in iran in 1852, Baha''t faith
fv and peace mon (-AcceenSaS aR une HAY oan cn ea ie
oe and peace m... smora (..Adocainctesanddats.himi#4ot) :
a
Par
ot pmieVE) ae . ;
cprofile (idoceénotesenddats, himi#S40): This entry describes a country’s key key domographis festures and trends
pre ow bs vary among ragional, ay eee eae ne ecrne cts hes emma mo papas
clure, Tertitty, heath, mortality, poverty, Oo ee
| benVE) ae 5 ond : Php
ent in Venequela during the CHAVEZ reduced poverty from nearly’ 50% in 1900 to shout 27%
Gecressed infant and chid mortality, and improved ecosas to potable water and
social Investment. "Missions" fo education, ‘care, and sankation were funded through
5 While CHA sas pitino and upper-ciasa Venéduslana are esiimated to have
emigrated. pail =tereocaret fe lcnetry ormerh. paral aipartairevghaa rates onder aca
6 avaabiity of education and health cara, Venezuele lao has been a felty accommodating host to Colombian
ambering about 170,000 as of year-end 2016. However, since 2014, falling oll prices have driven a mejor economic
as pushed Venecuelans petefee today Pobelyey aroha nl fmpernoey hy rng
See aaa ene cee <x STA0I9 >
Approved for Release: 2025/12/08 C07183805. = as
hy
South Amefica !: Venezuela oe World Factbook - Central eg "Page 6 of 28 .
and to deport Megal Venezusien migrants - Ecuador and Peru in August 2016 Began requiring valid passports for
aaa Obtein fos Veneauelens, eae aaa re ag to avoid econ cope st
é
‘
iniBAVE)
0-14 year: "04% (ral 4800 906 Nemo 4,170,618)
6-24 years: 16.82% (mala 2,709,250 female 2,824,681)
25-54 years: 40.85% (male 6,393,114 female 8,487,570) }
65-64 years: 8 3.14% (male.1,239,524 Homnaie 1,836,083) .
Ta il 1004 ra 23 ve nt
ae
det ratloe(, docetoteeancdeta hamite zi: i Dia tniserey lin en rib ol a gs scenuniod a sogidetin:
“They relate tha number of individuals that are fly to be economically "dependent" on the support of others. Dependency ratios
contrast the Fa o of youths (ages 0-14) and the siderly (ages 85+) to the number of those In the working-age group lages 15-
64). Change inthe depenseney io roi an cation of pole soc upper rquemers reg fom changes
eee ne Lee.
cy ratlo: 62.8(2016 eat) . y
nati: 43 (2015 eat.) . : :
mney rate: 9.6 (2015 eat) — JN Ps '', : 4
pport raiio: 10.5 (2015 eat} ''
Zann nT ayn ge pp nai ''
tye people are younger than this ége and half ere older, It ts a single index thal surnmarizas the age distribution of a-
‘ he inedlan age renee fom a low of about 16 in Niger end Upanda to 40 or more in saveral Europea
“counties sid d Japan. Spe the’ entry for "Age structure" for the Importsince of. young versus an older age structure and, by
pee alsa nn
sala
E himlVE)
0 1a cahnlasenddetaonisG44y: Tho wrerage anual percent changain ite poplaton, retirg om a
ot) of ths over desthes and the balance of iigrania entering and leaving 2 county. ‘The rate may bé positive or
» growth rate fa factor in determining how great a burden woudd be impoted on a country by the changing neede
eopie for infrastructure (e.g., schools, hasplials, houdliig, reads), redources (e.g., 400d, Water, slectrictly), and Joba. Répld
ZS fh can be seen av... more (.docamotenanddete,imitS44)
p the work 0 nk desta *
Bikth rata (.JdocaMnotesanddets. himiiS48}; This entry gives the average annual number of birtha during a year per 1,000
* persons in § i gst a ston aoa eninan marlon
d growth, It depends on both the level of ferifty and the age siructure of the
{
}
1 iatigh atthe istier shdialng tla aieek sabi ee
“population e nie eo town cute ea The eat wen eg naar ony enn,
a golibrary ublicatonate-warld-dbook/ geowve ht f+ samanis
U
Approved for Release: 2025/12/08 C07183805. ae
Approved for Release: 2025/12/08 CO07183805,
South Am i Veneta Qe Worl Feetbook - Cental Intelligen@Pgency Page 70f 28
as si actek enc plan al ats & acetic masts
f ee Sone el cree nr 91 8 ta peal oth at, bp or ante icRow het
aad am ing.. ... more (, }docenotesanddefa himwS46)
ag
t : ined
Q iso to the work: 167 ( Jelde/s46renk himeVE)
‘ rate ( Aloca/notesanddsts.himits47): This erty belshon Ge fere Sor Go Gleaie ets ie outer at
ent g end leaving a.country during the Year per 1,000 parsons {based on midyear population). An excess of persone
: entating the bo try Is referred to as net immigration (6.9., 3.68 migranta’1,000 ,000 popuistion); an excess of persons leaving the
., county as np ley el nten mae (Aecataeshaasetinaay enero
- to the ove a ioe popaeton an - More (./docanotesahddefs. hiniv347}
la
“( we)
: 12 mgr), 000 pope 208 ea) ¢ .
: 0 to thé work: 147 (. feldel347renk hive) .
b oahu oT ype sary dsc of ppt depen
Whe may sgt pop deny oe et rove dant dansity figures.
r -
* §.ffiekiars neni)
moat of the pop bs coca th nara sn wea igang ut ptt ation ot
: ba thet includes the capital of Caracas
ee THdssuby jain lol banners a degree sberlin ofa ponies
ban poputation, describes the percentage of the total population living In urban arees, aa definad by the county. The
uty of urbanization, describes the projected average rate of change of the elze-of the irban population averthe given
esac i, Additionally, Maumee
= canada priaing th. . .more (/docamnotesanddefe.hini#348)
G r: 88.2% of total popadation (20 (2018) Wo :
b Or: 428% rate of change (2016-20-eal) - “
sary areas - population (. ity oi ia adn a po
defined ps urberi agglomeratiana with populations of at least 760,000 people, An urben epgiomeration Ie defined am
fie ity of town proper and aisa the’suburban fringe or thickly settled territory lying outiide of, but adlecent to, the
eae eae oan een ane tae OTA moe, oy pec ofc
A
354). hemiVE)
on CARACAS (capital), 217 nia Mca, 784 Bo Vi 1:0 ay, 1.168 million
ats) (ante) g
cainotess fa htmi¥351): This entry Includes the number of males for each female in fve age groups - atbirth,
46-64 years, 65 yenra and over, and for the total poptéstion. Bex ratio at birth hes recently emerped ma an“ an
Kinds of sax discrimination In some countries. For instance, high sex ratios at birth in-eome Asian counitten
th ee ee ee) es eee es aang paper Cr aes: TN ee Bt Dar ore
eri... more (. docuinotesanofs. tit) a! Ad 5 3
BC 0.99 mate(e)femate (2015 eat)
vortaly rate (. _/docafroteaanddefa.hirnt#S63): The maternal mortality rate (MMR) Is the annual number at ferhale
Heaths per 100,000 lve birth from any caus related to or aggravated by pregnancy or Rs management (exchiding accidental
Or Incident tac, eh aang a, A oe tern ot pa
respect Le ea eee ae od . :
eS htm) a ak
710,000 five births (2018 eat :
parison tothe world 73 (Melda/35Srenichiri#VE) od
be oct eesti eal ela cad ; SAL TR019-
—~~romauanaammenenen A ODHroved for Release: 2025/12/08 CO7183805— aa a aa
*Approved for Release: 2025/12/08 CO7183805:
* 5 i
; .? bp 1 : ~ #2
America :: Veriezuela he World Factbook - Cental InteltigencM™yency - Rage 8 of 28
ra
: 4 7 ; . . . .
alty rate (./docsinotesanddsfs.himl¥354): This entry gives the nimber of dedths of Infante under oie year old in a
pe 1,000 live birtha Insthe eame yeer. ‘This rate W often used as an indicator of the {evel of health In a country.
SB4ihvalVE} 3
pthel 1,000 live births :
deathal,0OORve births bepld 5
Heaths/,000 live biths (2018 est) - ~ :
‘country comparigon ta the word: 417 (. pik . . me on ee
\\, Ute éxpactancy et birth (./docs/notesanddefa.trtm! : Thie entry contains the averags number of years to be lived by a group |
.” of people bam in the same year, If mortality at ‘each remains constant in the future. Life expectancy at birth Ie leo a
PeReuNE of bye af quailty of fife In a country and summarizes the mortality et al ages. It can alsa be thought of as Indicating the
«potential nots On Investment In human capital and Is necessary forthe calculation of varlous actuaraj measures, as
; ;
populatibn: 76.2 yeaa =~ - 5
e : : : ard oo a
(2018 est} : ; ce Hy
ity rate (,/docaMnotesanddefs.himls358): This entry gives @ figure for the average number of chikdren that would be
if ei! women Bved to the end of thelr childbesring years and bore children according to a given fertility rate at
total fertiity rate (TFR) lee mone direct measure of the level of fertility then the crude birth rate, sinca It refers to
b . This indicator shows the potential for population change.in the country. A.raig of two children per woman Is
‘
f data. The i end
itl also unehi in understanding, pest, prewar, and future ferlly trends, especially in developing
By himitVE) ‘ ae a (4
ppendii (. /docainotesanddefs.ttmii368): This entry provides total expenditure on health ae-a percentage of
GOP. Health expenditures are Broadly defined ax activities performed elther institutions or individuals through the application
of medical, jpeaxemedicel, andlor nursing knowledge end technology, the primary purpose of which Is ta promate, restore, of
.” Mmalrtein hébpit . mg ae
& - : - .
{.Abieide/368.htmiVE) as
iP (2074) : é
onjparisen to the world: 132 (.{felde/5érank honlVE) ‘
bed density (./doce/notesanddets himi#360): This entry provides the number of hospital beds par 1,000 paople; It
Geheral measure of inpatient service svallability. Hospital beds include Inpatient beds avallable in publla, private, - tats
ned ed hospitals and rehabiiftation centem. in moet cases, beds for both acute and chronic care ere nokided. =~ a eats
. Because ® level of Inpatient eervices required for Individual countries depands on several factors - such ag demographic Pe
if ~
Se »
G0. hirnliVE) ; .
DOG population (2014) : : . .
iter eourcs ( Jdoce/notesanddats,himitS81): This entry provides information about access to improved or : Wie
ac drinking water sources avallabis io segments of the popuistion of @ county. Improved drinking water - use of any of aS estes
hig S0urce piped water Into dwelling, yard, or plot public tap or standpipe; tubewell or borehole; protected dug well; rr
ipting; OF relnweater’ collection. Unimproved drinking water - use of any of th following sources: unprotected dug wel; Be ae
Inprotected spring; cart with amall tank or... . moré {. /docamotesanddets.himi#361} ae - a :
“{B- : ''
BihtmWVE) : ee as : ae
cia.gbv/library/piblications/the-world-fictbook/geowve.bimal |= _ samo
~Approved for Release: 2025/12/08 CO07183805-
Approved for Release: 2025/1 2/08 CO7183805-——___.—__-____—_ - ,
Turek 22.1% population . j ‘
totek €.8% o poll pe ;
, Sanitation ccreos oefcleanet ni} Thi ery preva eoaton abot acne to rover .
" ninprove enter fctes eva sogrent of tho pope ofa ou. bmproved sanitation - Spr fae
"folowing fe : us of pours & pec sower yale, spl ten pt ite; vented improved pt {3P) latrine: pil
om, septic tank... more (Adocsotesanddefa himis3o8) ae | : %
388, himuFVE) zy .
__iprovedcurt 676 of popeton (2016 eat) ; ''
‘Turek @0.0% pf population (2016 est} 5 oe pee ‘
fotak 94.4% bf population (2016 est). Pp Te . .
unimproved: rber: 2.6% of populétion (2046 ost)” se j ‘
_ Murat 30.1% Df population (2048 est) : ts : { oy
" totat 6.6% ol popuiation (2016 eat :
: HIMAIDS - pecan OEE ey I Ora fry gives sn estinate of thé percentage of aduts
mt aged 16 §) hing with HIVIADDS. Tho echt prevelonce rei caltlvied by cing te the eatimated numberof adujie ving wit
vot a yearend by the tobal adult popuistion at yearend, Sok
ca 63
0.8% (2016 pat)
county compay ato the won 85 {.Aetdanrwchamdne)
HIVIAIDS - regi hn nn: iat tot pt eit
ae oan sn nr et yh oe a AIDS.
“et (ollokds964, hiniaVE) . a Bie op, a 2
. 120,000 (2046 ent) ‘ : : ''
», Stniry comparison to the world: 40 (.fhekderse4renk
. ° SAIDBA g''s ghen calendar yeer.
2,000 (2018 at) : i . .
comp to the world: 47 {.
‘Major Infect ( Thi etry Bota mejor Infectious daeacs Rely tobe encountered in:
countries tha risk of such dssases Is sesesaed to be very high-as compared.to the United ‘Stales. These infectious
diseases rep t risks to US goverment {reveling to the epeciied county for @ period of leas than three years, The
Gegres of fs assessed by considering the foreign nature of these Infectious disexesa, thelr severity, and the probability of .
a i ha cra aera ee eee - a : : .
(ff : :
see is i icboh 201)
‘ moase: acl aren ai hepa A 2046
vecbome dengue fever and materia (2018) -
note: og tanatalon of Zka via by Aedes apcie mosasioes has bean Kent inhi coun (an of August
ae: _ 2018) pa : a en important dak (a large number of casse possible) among US cttizens If bitien by an infective moaquito; other
ered ways to gel Za ee trough an, i ood keto, rds pregnancy, wich te pregnant woman pastes
virus to
Coeahy - ef prevalence rebs ./docainctesenidefs.htmi#967): Thia entry gives the percent of a country’s ® population .
ca dtp ba obaes. Obesity defined as an adult having a Body Mase Index (BM!) greeter to or equal to S00, Bhi le
cakcadaioa f ga aa el ah ara oY
Hs > a F % :
" 2ha% (2016
_ country comparise sn tho worl: 60 (eld hi AVE} . ak:
Chikdren ui dor the age of 6 years underweight ( {..ocafnotesendéets.htmitdeg}: This entzy gives the percent of chidren under
five considared fo be underweight. Underweight means weight-for-age Is approximately 2 kg below for atandard at age one, 3 kg
. below etanpard for ages twa and thres,. end 4 kg below stendsid for ages four and fve. This statietic Ia an indicalor of the .
“.. RidrRional (tates of a community, Cieiran to ite bom grat eerie 6 ail of poor dels sor ceca btectcws
+ fend to he ee eee eee
'' TORS es ee
Sr aaa ‘Approved for Release: 2025/12/08 C07183805-—~ a
b; oF a compoating foiet, Urimproved saat se of ay of th folowing felon hush or pos fush not ped _
himl#VE) "So pak art
HIVIAIDS - Heat | ocahsonace 0 They ghee nti of be ier of acuta chen wo ed
_ Abttpsiftw Se coebecasiuaiie neces caluahe rele 7) -smaoig. >
ee for Release: aoa 2/08 CO71 83803
sou America :: Meceonis -@: World Factbook - — nage ’ Page 10 0f 28 .
3 : :
+ eide/Se ty ne
2.8% (z009| * ee ;
county compariso tothe work 103 (fhtdaoesnicHavE)
expand a aca ic Piety ee one
4
eo
parle rte ort: 16 ( lator
coc .himi#370): This entry inces x detirition of Iterecy and Cansus Bureau percentages for the
gio niaoe, and foriaes. The are no rivers deidlona i ane of Rorncy: Ursees choice apecibeg, ol
ratea are bazed on the most common definition - the abiily to read and write at a specified ege. Detailing the standards that
Indhidual oq knoe omen sly ore wa bmp i Fc. aban cn Ba, %
rn ct measu . ci acer aaa i
‘Jote! population: 87.1% . be
_ female: G7.2% (2076 ast.)
"School fe daqpects Gna oy ey acne i aca Lb
eo Be of schooling (primady to tectlery) thal a chid cen expect to récelve, assuming that tha probabltty of his or her
being enrofed In schoo! al any particular future ‘aga 1s equal to tha current enrolment ratio at that age. Caution must be .
abiied utlzing this Indicator In international comparisons, For example, a or on country is.
: pone sseen i teres elie tenia a a: (eno oe
VN
7
i
{
}
i
ins
,
ployree ram 504 hn i Thy Gt ro ir
ployed during a specified year, :
, “e i SS ge —s 3
. = '' : : aa aaee
.
"a i at , Sous, ; . ie?
county comp ot te word 7 (. Melt 7Srankchimi@VE) ie 7 . aoa
pot Ro
Country 2c ieersink Liiae Guiedvencs 4 ofthe country’s name ape by he Ut Board
4 - on Geographic Nemes (italy is used an an example): conventional long {iteflan Republic), conventional short form (thaly), °
ow p (Repubblica Hallana), focal short form (Italia), former (Kingdom of Htaly), 8g well ss the ebbrevistion. Also see the
g egy noe. . ‘ é ae Sie | Z
i?
1 a ee “
foes buon Lak Maraclbo rorindes ener Alonso de OJEDA ai Aerio VESPUCC!
gs in Venice and so they named the region “Venezuola," which in Italian means "Lite Venice”
({docalnotesshddefe himi#200): This entry gives the basic ferm of goverment. Deiniions of the mejor
tal terms are #e follows. (Note that for some counties more then one definkion applies.) : Absolute monarchy ~ #.forrn-
Overune where the monarch rulss unhindered, Le, withdut erty laws, constitution, or legally organized opposition. Anarchy
=a condiid Fo Senet 2 pene aera Les Sak oy Ue NRCS Of Govern neren Sees autherlty. Authoritarian - a torn
lacenolesaitddefs, htmis2e8)
“of goverment in whic’. ... mare {fd
ie
" \\httpas//eyprw.cia. govAibrary/publications/the-world-Setbook/geds/ve.html | - + 7/2019
: pos 2 : , : é . ,
‘Approved for Release: 2025/12/08 C07183805-
~~~ Approved for Release: 2025/12/08 CO7183805 -
a: ae World Ractbock - Cextral oe Page 11 of 28 -
sinotesancdefe ht ot Td anya ta eof heat tavern. Bs tec core,
: ca relative to Coordinated Univeral Time (UYC) and the tne observed in Waahinghos De, and, If applicable,
lial ato ag onl aa ae Where appropri spect he boon add oN hes cnn at
hi a0) hinevey pS ; : : ~ _ \\ t .
name. . ty :
geographic boordinstes: 1029N,6862W .- - .
tims differerie /UTO-4 (tourer of Wstlngfen, OC, ui Clavier Tse)
hte tent hy ey ee umbers, designatory terme, and frit:
8 divisions a8 approved the US Board on Geographic Names (BGN}. Citanges thet have bean neported
d on by the BGN are noted. Drees ace coats rine te BON wine capo cf
iad of ct te pc cea ; ze
/
i hime)
"23 stains (eptado ago 1 cal det cpa, era Spee epee ie :
Atnazonas, fr Apure, Aragua, Berines, Bolver, Carebobo, Cojedes, Delta Amacuro, Dependencies Federaiss (Federsl
ns)", Disttho Capital (Captal Disc Felcon, Guarico, Lara, Merida, Miranda, Monagas, Nueva Experts,
Sucre, Techice, Trufle, Vargas, Yaracuy, Zila 5
“note: the''fe ie dependency conslats of 14 federally controled isend groupe with a total of 72 Individual Ilends
denc (.{MocaMnotessnddete. himi#S05): For most countries, this entry gives the date that sovereignty was achieved and ;
. nation, empire, or trustoeship. For tha other countries, the date glvan may not represent “indapendanca” i the wbict
- genes, bun nfl Sena art naltonhood event such as the rational founding date or the dete of unitcation federation,
onfecerats hppa yuparey ren hla oh uae aoa Pantene ¢ Saree,
Rablighment of statehood .... more ¢..jdoceMnotasanddefe himi#305) 4
of B.himiVE)
Bayt from Spain}
Sona hn i py ten usually
Raila piri 3 ’ . : . . % %
inge ce 2 Day, 6 July (1811) = : ;
onsditu {..Adoce/notesanddets. himi#307): Téa eniry provides infomation on # county’ coratiasion anil includes two’
sb i Nietory subfield Includes the dates of previ','8bb9819258ccf75a9df7dedf6481d66fab07f6d64ba3590bababd0df9cdde32a','internet-archive','south-america-venezuela-16559438','txt','cf6a10ea00c36eb3db411ead5f1899246ed82cec14abf11f90452ebef3d181eb','https://archive.org/download/south-america-venezuela-16559438/SOUTH%20AMERICA%20VENEZUELA-%20%5B16559438%5D_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('00a2a5b51515942428c3a3ede5b17885100686619fffbb9d6fe1c240a91e7bb3',2025,'','','raw',2,'ous constitutions and the main steps and dates In formulating and
p the latest constitution. For countries with 1-9 previous constitutions, the yeara are Rated; for those with 4-0 *
previous, entry la listed as “several previous,” end for those with 10 or more, the entry fs “miity previous.” The Spe enens
subfield izes = the process of am . . - More (.doca/inotesanddefs.himi#307)
4
af} 7 hive) * ft icf. . 7 Pg
Louse samirepmeticlirnersoge effective $0 December 1609
aenonrener ys proposed raugh sgreeme hy o leet 20% ffs Nadonel AamerioW membership, by the prosdent ofthe
eeeng with the cabinet of ministera, or by petition of at isast 18% of registered voters; votsra; passage requires eimpie .
‘ fe by the Assembly and slniple majority aoprovel hu ha referendum; amended 2008; note - in 2016, Presklent MADURO
fesued a der: 2 to hold en election to form a constituent eesembly fo fo change the consiution; the election In July 2017 approved -
atic Seyret ” A aegis ei area
end Groupe explains the differing mandates of the ICJ and
“https://wpw.cia. gov/libriry/publicationsithe-world:fttbook/geow/ve htm! = s/t7/2019
Approved for Release: 2025/12/08 CO07183805.
sree! Approved for Release: 2025/12/08 C07183805
"South Amari :: Venezuela (Qe World Faotbook- Central Intelligenc@ency Page 120828. *
oan 7 , * ‘ "7 act
‘) A a
( elds t 7
has not sub Ried iy 6) puicicto!acotuton; ecxapte ICCt furtsdiction
Chtzanship jSotactatandiet henley Tiber junion Wseiacs scded ns would ekaae-*
ft ncluces four subfields: clizenahip by bith describes the acquiation of cltzeriship based on place of bit, lriown :
28 Jus oa of the citizenship of parents, chtzenship by descent only describes the acquisition of cliizenship basad’on
: oof Jus sanguints, or by descent, where si legat one parent faa cftzen of the ainte end being born within the
tenritodel irrite ofthe @ . . + more {./decalnotesendcets.Hom#S10)
‘{Meldarsia.henwve) : 4 - .
exspil aapetdal Mae a i # ee as ;
Executive b ocala Tia ley ch iene: tn: ti Gh pscemonte oo
cabinet, Gio election results. Chief of state Includes the name, tite, and beginning data in office of the thular
leader of t Gia who prea then fic anderen incon nyo be ved wh be .
activities of the govemment. Head Na -
‘executive branch of the govemment, e .. more (.idocemnotesanddets.himihS 12) :
14 himifVE}
seein Sacer ae Sle vgn UNDO nn nara Poo Veo ‘ ;
Proakient Nitot [MADURO Moros sinos 19 Apt 2043; tacit Vien Present Deley RODRIGUEZ Gombe (hoe 14 June
2016); note the president ls both chief of state and heed of goverment
‘head af go Pr Nie MADURO Mo i 0 2018; xs Vie Pr Dey RODRIGUEZ
Gomez ( qe 14 aie 2018) ee
cabinet: Co ol of Miniatacs appointed by-the president :
Fi ety oy a mao pp you no ih cn
held on 208 ay 2018 (net acon aceced fo 2024)
v- ‘election re : Nicolas MADURO Moros reeleciad preside; percant of vate - Nicdias MADURO Moros {PEUV) 68%, Herat
‘FALCON pate, devier BERTUCCH 11%; note - the siection waa marked by serious shortcomings arid electoral fraud; voter
-tumout wae @ taly 48% due largely to eri Opposition boycott of the election '' :
Leglalative brand (.docaMnetseanddeta. imix 1): ‘This entry hes three subvfekda, The description sublild provides the. -
logialative structure (unicameral ~ single house; bicameral = an upper and a lower house); formal name(s); number of mamber
‘eents; type Of conatituencies or voting discs (single set, mUlt-seet, nationwide); eléctoral voting aysiem{s); and rember
>” tear of of chutkaknn GER ee
al in by party/coalition an . aa greek be a 8
© §Alekia/9 1 rent
description: {sniés
ito ant abd rst 13 mabe ety dein ee rt
bile by almple majority vot, 81 directly Glected in muii-seat constituencies by closad, party-tet proportional
Ne Bil Ce rr een acias cf Vaniaeily ahaaibene marys © yest iene) :
lectiona: held on € Dackmtser 2016 (head to bs held by 2020) ‘ . 4
lection resilite: percent of vote by pasty - = MUD (opposition coalition) 68.2%, PBUV (pro-government) 40.9%, char 2.0%; vet t,
by patty c 0 108, PeUV 66 Indigenous peoples 8; composition - men 148, women''24, percent of women 14.4%
{-Mocufnotheanddefs himl#314): This entry includes three subfields. The highost court(s) sublleld inches the *
saet el country’s highest level courts), the number end tea of the judges, and the types of cesses heard by the court,
oa minonty are based on. vi, criminal; sdminiatretive, and constiutionel law. A number of countries have seperate
Miutiona! courts, The judge eelection and term of office subfield Inchides fhe organizations and associated officials
aponalh for nomineting and eppolnting |. ct a rcsaeaaic 2 J
ld niniavE) ;
Noheet og ipa Ta kn one of 2h ed ter pant, ec,
pid ap a ease aa divisions) ~
a
+
cia. govlibrary/publications/the-world-fufibook/jeosivelim! =. ° ~~ SANQ019 |
Approved for Release: 2025/12/08 CO7183805—_____--.
Approved for Release: 2025/12/08 CO7183805:
ica: Vera @> Wei rtenk- Cont sap ecy "Page 13 of 28-
erects si te of fle: gen proposed th Con oul Poston (nlndopendert lof .
lsc wpe cnon a tn pu can pe caper Shee tc
able 12-year terms; note - ~ in July 2017; the National Assembly named 33 Judges to the court to replace & eesles of
alst-party-ded
the new judge ap ter ap ovornpstel ohana ol
ohare : Superior o¢ Appeeis Courts (Ttbunales, Supedords}; District Tribunals (Tifbunales de Distrito): Courts of First
od Prarie; Pata Coste uni de Pro Justices of the Peace (Junticie de Paz)
a es und leaders (.Jdoceinotesanddefs.himi#S 18): This enty inctudiea « Hetl of pada aloes
A laine lc tan of nh arya igi ey re rn ia ty
es loyal to Hugo CHAVEZ — ~ Gromi Pattiotic Pole or GPP | } MADURO}
partiea = The Democratic Unity Tebie qr MUD [Joss CARTAYA]~
eauela or VV [Maria MACHADO} ‘ .
j of Venequeta or PCV [Oscar FIGUERA]
Action of AD [Henry RAMOG ALLUP] : ee
or PJ (Judio BORGES) . wk AS “ 7
o¢'' VP [Leopoldo LOPEZ] ea ee ae A ‘
or AP [Hens FALCON] P ; . ‘
ee OF LL Cauna R [Andres VELAZQUEZ] _ BO te og
fet Party of Venezuela or PSUV [Nicolas MADURO] ait ae)
ae
ye
FEO]. - ‘
send outs nutkh be abjedcanty ke amacaworsetavene nana cnar ea abbreviation
canara ales eae inane an cal oles way. ’ }
2
<2 1 ( Alighialst nmi ’ :
pb , CD, CDB, CELAC, FAO, 6-18, 6-24, @-77, 1ADB, IAEA, IBRD, ICAO, 16 (ronal commitaca), (2 .
RM, IDA, IFAD, IFC, FRCS, IHO, 1.0, IMF, FMC, IMBO, interpol, OC, [OM, PU, a ITU, ITUG (NGOs), LAES, \\
does er), MIGA, NAM, OAS, OPANAL, OPCW, OPEC, PGA, Petrocaribe, UN, UNASU R, UNCTAD, UNEBCO, .
#00, Union Latina, UNWTO, UPU, WCO, WIFTU (NGOs), WHO, WIPO, WMO, WTO :
pi to nth US ocacaendet AO Th ety chat cht of mao, chancay
tole a, FAX, consulate general lopstions, and consulate locations. The use of the annotated tile Appointed
bassador refers to a new ambassador who has presented his/her credentials to the secretary of ataie but not the US .
preeldent. Such smbsusscors fill all dplomaio incon except meetng wth or appearing atfuncfona atondd bythe 2
: See a, meer ae ee eee ee at + more { (kdoca/actesancdeefa hile 1)
sion: Ambasaador (vacant); Cian na HERE? rs ey 2
p. 1080 30th Street NW, Weshington, DC
Upset a “
- coneuiatse yeneral: Boston, “Chicago, Houston, New Orleans, New York, San Francisco, San Juan (Puerto Rie)
on from the US (:/doca/notesanddefs.himi#319): This ently includes the chief of misalon,
36, telaphone number, FAX number, branch offices ocations, conaulate general locations, and
s rs ne i “-.
ion: Ambassador (vacant); Deputy Chief of Mission James “Jimmy“ STORY (since July 2018); nate -duetosirsined
etween the US and Venezuelan Govemments, netther country has shared ambassadors sinea 2010; on 22 May 2018,
Mee ee ee
Ordered the N expelled
aF con Calle Suagure, Ubarizacion Cana Vie Ar, Caracas 1080 : e of
ai P. ©, Bax €2201, Caracas 1060-A; APO AA 24087 *- wo 1.
+ Amlephane: {B8).(212) 876-6414, 807-8400 (after hours) ae : c ; .
FAX [58 (412) 007-8108 ong )
ia, govfiary bilatnatn-wosldiok gecefve hal "| SALPAOLS |
Approved for Release: 2025/12/08 CO07183805.
Approved for Release: 2025/12/08 CO07183805
f
outh Amarica Venom @e ‘Mod Fetpook- Conn! Tnetienelleny Pie 14 of 28
"Flag des on (.Jdocanpbasanddefs htmH#320}: jiicer ebibe splae bg escaped apie ae
: best infor atlo don avaliable atthe tine te entry was wean. "The hageofndeperdent late Gre used by tar dependences
‘ sa Ce ee ee
+ (flelds/20 himigVE) =
teseagal ordinte ade feo op a incon of aman hl a yh bandana
. eight white § d stars centered in the blue band; the flog retalns.the thres squal horizontal bands and three riialn colors of .
the banner o Gan Clonbl, Sout Aneta mb al sk 00 yl trend a cg :
of the land, b fr the courage ofa peopl, and fd forthe blood ahed In attaining Independence; the soven sia onthe
ggiginal Sag fepresentad tha seven provinces In Venezuala thal united In the wer of independance: in 2008, then President Huge
CHAVEZ orgered an eighth atar added to the eterarc- a deciaicn that sparked much controversy - ~ ta conform with the fag
‘prociaimed ky Simon Bolvar In 1827 and to reprasent the historic province of Guayana , 3
| National pak) (.Jdocwrictesanddefs.hirite321): Anetional aymbol ts a faunel, fore, or other abstract representation - or
some dintiieive oblect « Se eerie ie cores be Henely amet wits Soni or sity. Net comes nao
ot Counties have more than ons. :
- (-Meidafa2; NimVE) . gen cat . a ya 1 ;
trouplal (bird);
National anthe {..Kloca/natganddeta.htik322): ik pani pelo wend Coveiealioa stil i ie vie a''s ag
‘hymn of p that evokes and eulogizes the history, Gaditions, or-struggies of a nation or Its people, National antheria can ba
: offically hea a a a ca a sila a aap shi
a in lyrlen, soma do nat 2 “
. (ath Pa 2 hint} mon ls . .
nome: “Gk Meer sais wav kaautecis ; -
_ , Wyrlcetmusic! Vicente BALIAS/iian Joes LANDAETA
note: adopted 1881; rn tian ni mon yen oh ALAS nd LAAETA rt.”
seg Ver rule''s struggle for Independence
i
v7 Eeoneny (.fdocainotesancdefehimik207} This ry iy dni be ype teary, licludtig the degre of
+ Market orlertation, the level of ecanomic development, the most important natural.resourcas, and the unique areas of
" |), Spectadizagp lo tracts major Sones evra ply changes nthe moa acer 12 mart er maybe,
. Satemant ab tone or two key future macroaconomic trends. a
oa :
highly dependent on oll revenues, which secount tor almost al export earings and nest half ofthe.
. 8 reverie, despite & conitnued deciine in oll 2017. in the absence of official statistics, foreign axperts
‘ eatinats GDP contracted 12% in 2017, inflation exceeded , people fecad wiiespread shortages of consumer goods
* end = tend the central banks international reserves dwindled. in lats 2017, Venezuata also entered selective defautt on
ome of ie on and state o8 company, Petroleos de Venazuela, $.A., (PDYSA) bonds, Domestic production and Industry
* continues bd ster underprorn an tha Venezuen Goverment counsel on inprts meet bal fod and
Consumer gpods needs. .
Fat ot oa cicestttateagsies a ia cabiads weal adlindaceaieaaee price controls, andrighd
gis Galati Wil PCNA poer teat he tava uted ried Hits cerraes eke onde Lh ocee tapes ;
d POVSA''a poor cath flow have slowed Investment in the petroleum sstcor, ene eeene hee
Unelee P t Nicolas MADURO, the-Venequstan Government''s response to the economic craia has been to incroaee eta
.” control a ope eee ra
on distribution of basic goods to thd military and to focal soclaliet party member committees. ent hes
Sc mainteined trict currency controls since 2003. The goverimant has been unable to austaln its mechantgms for dlatibuting
~dollars tot Se eee ee re ee ee ere
Bt aoa Parmer
4
- htipew/wprw.cia.govlibrary/ublicationsithe-world-fietbook/geoyvehtml . =). “S/ITQOI9 ~
Approved for Release: 2025/12/08 CO07183805——-—------
pena for Release: cua 2/08 Cort e002
ty
Ametioa : Aeon World Fastbooc- - Cex nag ay _ Page 15 0f 28
| papen basal jl a eben oclug gs a leeks a
Jnaintain tire ree arte eo race tat Epenalonas mocha pollen ae coréncy coils heen
Sreated 0 oppor for exbltrogs end comuption and fueled rapid increcse fn black market det.
mchieing dower parity) _Socahciosncdel i208): The entry pve the gross donate produ (2 of vélue of
good & and services luced within a nation in a given yeer. Anation’s GDP at eo 00) 9
sachange retea js the sum vaiue of ell goods and services produced In the Gourtry valued a! prices pravaiing in tie United
.o* Btates int qj Yeet noted, Thia Is the mesaure most economists prefar when looking at péc-caplta welare and when comparing
> Bving conditip M OF usa.of resources across counties, The measur. + more (,/docaMnolasandefs himi#208}
on to the work: 47 (,/feida/20erank html?) ,
flict J exchenge rts) (-hdocahnotesanefs hrA200} ‘This entry gives the gross domestic product (DP) or value of al
services produced within # nation in a given year. A nation’s GDP at official exchange rates (OER) ls the home-
d annual GDP figure divided by the bUsterel average US exchange rete with thet country in thet year, The .
nS, T : D tcompeand ie prec ears fo vn of up. Many einai reer ie meaie wn
~ _oe céno ic power an economy maintains vis-.. , More (..docafnotessinckiets, himi#200) oe
iy? 7
: t
tabi ‘ Pa . ‘ x zd os : io ace : ¢
(2017est)
grow ahammar? go ono ba i
oc. @ percent. The growth rates are year-over-yeer, and trot compounded.
+ f f
hind) ee des io
ont the wor: 222 (.Meidar2 torankchimltVE} , ; o
d PP amon Tey te Pn rp
oe
v -
6 eat) ; 7 Sts: ee ee
. pea) ; "at
in 2017 dotiars es woe
ie0 to the work: 128 (Melde/2ttranichimitVE)
‘saving (./docahnotesenddefe hill 12): Grose national seving fs dedved by deducting nel conauription
goverment) from Gross national Ingome, and consists of personal saving, pis
Meldel2 3. himiiNvE)
; ae oe ms 8
ingly pubtaonste- werd Alico geote inl : Be SAFAOLS
Approved for Release: 2025/12/08 C07183805- = AERA Sag a ee
Approved for Release: 2025/12/08 CO7183805
i . :
‘
ore @Or7 ot) Wt BP a) fine he OH es
LL
a3
83
g
oa and sorvions 10.7% (2017 sat) * ; i
compasitie pct ag (mans biz chy howe ar cin nn cane ‘
-economiy, The distribution gives the percentage contribution of agricuture, Industry, and services to total GDP, and will total 100
9, energy production, and construction. Services caver government activities, communications, Ct
| ecthr pat economic chee ht onc ro. ae aaa asa a
(ahr Try enn a a ie
Jv .
t * '' : Boge | he
& himiaVE)
, garare, es, bananas, vei, ib; bet, pa, oe fish
Ao ney peer e ce at ra M
sopton rowel Monaholoemsioek F Teeny! the =a fn ncuetrtal
didoceinoeeanideate hint’ a increase
= des manufacturing, ming, end conan), ils eer
‘ Be a6
; a : weet 0 Z
0 Sib inewnad ni Cadena) Ma he :
eta iz Ti hy be ire
f 7 et) : OO tte Sr
tothe wat: 4 (ites) . }
u {.idocaMnotesanddets ht
oi OCCUR jr a energy
“Prodution, and! construction. Services cover gavamement activites, communications, transportation, franes,’and ail other
EO ee etna mn Ei 360 peat Minn Sess ri:
and may sm 89-101 ee ee eye eg ee rT oe Lg
ae x ty,
rnp rate ( (.doca¢notwsanddata.nimi#220). Thence parte er ce tit
betentie underemployment ight be ned ~
) ™:
erfanc to tha weit si nlc
opine sce reg sarcanetranqeir-cit Ao RCT a OO
” poverty ine are based on surveys of eub-groups, with the résuits weighted by.the number of people In each group. *
Me innadaa co eo ee eee nee
uth Ams joa: Veh - Qe World Factbook es ad Page 16 0f 28
‘product osc i nal, uy id lied inl cui on construction mails, mica.
" SAT—2019 -
Approved for Release: 2025/12/08 CO7183805 eras a
‘Approved for Release: ee 2/08 CO71 Bape
Ambsiva a Word Fetbook cam mse Page 17 of
we ’
“procedures Saat eed seeing re ccm Rio facet \\
a ge ee ree
i ” : aa - . 4
highest 10%) $2.7% (2008) *
Distribution jof family Income - “hl (Simi ia cs vas tse bgac ve
pf family inicomé in @ country. The Index le calculated from the Lorenz curve, in which cumulative family income ls
Plotied aged inate number of famliss srranged from the poorest to the richest. The indax lathe ratio of (a) the area between a
income datbuton, be coewia am Sealnameanasenaiee ee eR
intry‘e Income diatribution, the closer ite .. - «thors { .fdocainotesanddefe.himi#223) +
00229. tinteVE) ‘ : : eee em . “ae 3
.
0 fo the word 74 (. feld2z3cnk hiifVE) =
d a himi224): This enry included revernsoe, experkftures, end fecal eit. Th a
ie onan change bile, eared eA canal, ;
de/224,himiVE) ‘
: 84.6 billon (2017 dat)
: Ea07 tion O17 ext) :
p Poem (gti eles tao Lad wise ca fecelved by the
go tt during the time period indiceted, expressed as a percent of GDP, Taxes indude end corporats *
Incorne tax 5, valve aided taxis, excise taxes, and tariffs, Other revenues Include social contributions - auch es payments for
i hesduenati grants, and net revenues from public enterprisse. oe :
b Sere eee ae . Inpre {.docafnotessnddets.hitmie225)
ayaa aia : hes
on fo the wort: 26 (.1 himigfVE) é
(of a) cantante Mh ery ec he enc betwen nao govt
and expendiwes, aypreseed as & percent of GDP. A positive (+) number rxicates that revenues excendad
oepanvitt Fates H GDh, outs enh earecerenn mae cette Normedizing the dita, by.
ding t apace Beenee by SF: Gnables easy compartadne across countries and Indicates whether a national govamment
tb that sre Genominsted in @ country’s home currency. Carrocy, Plc dott shoud ne coded wh exional dot hich
rec ofr cen eis oboe tn an pu aren rte fered oof re exchange :
41.9% of GB (2016 ext) . Ae ot
note: date cre oven a vod tov ch comp POV te aa le my
abt hetd frente: the gta chi ome det asd by subatonal ‘entities, se well ee Inragovemmental debt:
Of treasury. borrowings from surpluses In the social furnis, auch ae for ratirentent, nee ,
erect tuna oa ar ae ek
‘ 3 . + . .
{cia govilibrary/yublications/ine-world-fidtbook/geos/ve html - SATROID
‘Approved for Release: 2025/12/08 CO7183805- —— asst ate te aa
Approved for Release: 2025/1 2/08 C071 S389;
%
"South Am ida: Veena he Word Fetook- cea iigeaesy - Page 18 0f28
-'' e tos
:
Inftation ta ite uae ri Ty tien ea ppm age am
prices compa shad car Jah acoder
AG leldal224 a aa t a A SF : 4 poe
- 4,087,685 (2017 eat} G ee wage’ %
. "254.4% 201 ebt) .
on to the world: 226 (. a eyed:
, a chon some i oo
a6 een ee ene ee eens ee
(iekdar23h.himiVE) 1
20.5% (2018) '' ae, .
county compa : dni fo the world: 1 ( ftekdar23Greri
JymRVE) ~
bank pn onda reo docahteeandea hi Ti x poide singe average of arian”
a ‘Hrentn a inn aa reas aeige sd
| -(lfiokdar2s 4, m speed a ns o
++ 24.4% (81 Discomber 2017 est) - ¥ * : a ‘
_ 20.78% (81 Devember 2016 est) «. : ” : :
"| country comparison to the word: 12 Mekdr2S tran hit) ae
-, Stock ofne money (,/docanotesanddafs. htmst234): This entry, ies ea a cae elon en:
; “currency tn bira 1 Secon Glan ‘an cae} pos deeded cepvea detiphaded ie be nadie tere tntdte eaten cence
Inethtions, fatets and governments, pubic enterprises, and the private esctor economy,
apecific po ti time. Netional currency unite have bsen converted to US dofars at the closing exchange rata for the dite of the
+ Q Ge een inona {. 34)
eldarash hp . a - ; :
"$148.8 bil Go Deseaiber007 eet} st oi? ‘ M
"$163.3 billion (91 December 2018 est) boys
* country compariso pede ele cheobec ara
: Stock of broad money (,./docanotesanddefs.htmi#235): This enty cavers all of "Narrow money," plus the total quantity oftine °
and spot ce won dept, batudonl money tharket funds, short-term repurchase agreenients between the
dour scalpel bar sna ls ssn byoxt sr, etd
- st4ngb Dacre aii Gis cae A
” $189.9 biton (31 December 2016 est)" tae, :
* _ suuniry comparison to the world: 29 (../fieida/235rank himi#VE) :
- , Stock of deme re caholancl ni) T any etolquay of ce, eno at
‘Tae CUTONGY, i d by financial insttutions to the central bank, state and focal governments, public non-financial corporations,;
“+ and the pi mycket core Use ee eb ecg eb
ve ; ofthe ari sai .
$68.97 bifdh (31 December 2017 est) are -
$1485 {8t December 2016 est) ‘ ‘ ‘ ;
country conjparise fo-the world: 60 (. Melda/236rank himi#Ve)
* Maricett oot pti sen artnet faa ny sy
* Yaded co ‘ata price determined in the national stock markets on the final day of the period Indicated. It Is simply the
latest p oer ahr ped ye el maar usardg wana, med own cgren itd ce pare oe
e " A ; : : ‘ St et
(ute hina : Lie ; ‘ ot
$25.3 ba on (83 December 2012 est) . fg eet
+ 95.148 biliy {91 December 2014 eat) + s . i
“i+ $8.001 blitgn (31 Depsmber 2011 eat) . '' _ # Be me: tea” ea
attpa:/fwyw.cia.gov/library/publicdtions/the-world-fittbook/gessvehtmt ~~ > sn7mo19
Approved for Release: 2025/12/08 CO07183805.
Approved for Release: 2025/12/08 CO718380:
4 Se .
etic = Veiezucla — ge World Factbook - Conia Incligenoygpgency <Page 19 of 28.
‘ imifVE}
rt telanpe (.Aocalnaouen dics SMRZSEE Tie ntyvecerds« ouuréy‘s net rai tn gost ant eordath lie
net eamings Fo renta, interest, profite, and dividends, end net transfer payment (such se penglon funds and worker
-TemiBanesa) to Gee ee ne
‘baals, Le., no in purchasing power partty (PPP) terms. -
Hfiekds/236rank hime},
ocenotesanddet tT#220): Ths entry provides the total UA doller amicunt of merchendiee eiports on an tas.
tee Tegal on an ears sb np po Paty PPP ‘
XK eo 8 a £5 he -
p to the workt 3. Melder236randchil#VE) ‘
arine telco) poet rank orig ted per ag wh hn.
onetime inch the peronto ttl doar aki.
. 7.2% Cl 1%, Netcen ren 82%, Spas 6.2% Cuba 42% TA - ’
ad ae
1
: d fachimt#242}: Thie Tito ecey svete ts it UF dehes Soomnt of Gootherniee aslitacelaclt ial”
Spaces Reo rower mera :
’
1
) . .
14.2%, Mexico 6.8% (2017] } ; ae
roti esc hecion ad oie toscsudasit ns orly Shds Ws cr iekio i a tk af a
ots that are available to the centre! monetary authority for usa in meeting a county''s balance of paymenta needs as *
sis of he beriod specified. This category incladee not only foreign cusrancy ie
een enn ne ee enn eee,
.fieides24Srank himiVE) |
i (Fenn iT ry ra be i sr nt oto ei
pest mcpaet een see cr eaioen: Teens ees re ate een ee ee
g power perty (PPP) tenn. em
bicueve
{31 December 2047 est, : : ae 7 a -
(31 December 2016 est.) : - = . ei : x.
yw cia, govilibrary/publicationsthe-world-fictbook/geos/vekbim!
Approved for Release: 2025/12/08 C07183805 ae been Bis
Approved for Release: 2025/12/08 C071 83808, 3
, : ee Se t- - ‘
ie ‘ ae . ? . Z + ‘ : ”
lea eas “eee World — - a Intelligend@@ gency Page 20 of 28
county oo oir at 4 (iki te ee ee
frect foreign investment - at home (. 7: This entry gives the cumata! US dolar valua of.”
renti i In the home country made directly tesidents «primarily companies « bt other couricen ofthe end of the
q indicated, Se eee ene nee eee of shares:
47 kntVE) ) wes : ,
qn (jt December 2017est) . a .?
31 December 2018 eat) - 4 7
ariso to he wo 70 ada AVE
i i kang couetig nome etachy wo osu = primarily. Ti ty ge com sieeaete
sirits companies thé home country, as of the and of
indicated. Direct investment excludes Investment Swough purchase of shares.
Z
? 4
AeshimiVE) :
a ipl Decnber 2047 ca}
: 834, {abba (31 Daceinber 2010 est)
tet tos (, protien hl qvenage enreitpisd ofa coumbyyé monetary orf for
the time pa ne ant rwanda (SO)? omen oo eee
8 Intemational Standardization
oa
eat) ;
Gest) y a :
eat) -
ect) oh i : ee .
dct (sicctiaeatittes hia Ti ry on ema nana cy. Blectrifation data |.”
pm industry reports, national surveys, and intemationsl souross — chnelets of four subfisida. Population without
provides an estimate of the number of-citizens that do not have access to electricity. Electrification ~ total population is ;
8 fila habe carmerntasyededc or lectrtfication —urben areas {a the peroant of a country’s :
pital Sach aera aeaeter
~
oot
ivy
Zetec: 100,000 (2013)
~ total population: 88.7% (2013)
atlo} - urban sreae: 98.8% (2013) .
of ~ rune areas: 88.6% (2013)
production (-Moceinotesend
dete. himt#252): Th nt ie srt sty goer epee Mo
cy between the-amount of elacticity generated andor kaporied and Sie aricunt consumed end
\\ potinceny deipuoeatninarnblpciaA craggy : ;
. ,
da/252 himivVE) ; : -
on kWh (2016 eat) : ina ca a8 :
ariao Be 42 :
Blecticlly ~c co ri ieee ct ich cy id sy gt
expresaed in Klowati-hours, The apse barrel i agua a apace
on if ccaue','8037172173875135d5b2af51d62f25f72db65f33701714bc9fa031675386c361','internet-archive','south-america-venezuela-16559438','txt','cf6a10ea00c36eb3db411ead5f1899246ed82cec14abf11f90452ebef3d181eb','https://archive.org/download/south-america-venezuela-16559438/SOUTH%20AMERICA%20VENEZUELA-%20%5B16559438%5D_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('16ddbee6c76ffa05fba156895f8e849c4dace48bf21946b4974a375827af6414',2025,'','','raw',3,'d andr expat i accourd to axis rarindon and aon
(8 . is ;
"7. bln TS xt) ae , i &
parison fo the world: 3e (“Jflelde/26Srank himi#VE). me SMA ae
Electicky or (Seance erat Tk ny bel erred decay i doe ; ¢ gay
i265 himBAVE) ~ a e & oy ~* 7
i Ls a ee - . 7 sy = " re mene
cia. gov/library/publications/the-world-finthook/geos/ve.htndl f+ snqpois” -
aaa Approved for Release: 2025/12/08 CO7183805--___—_—---
hime} ;
mort (-sdocaMncineandidets.hirés263}: Try ah anc fog bare,
SS B 1 7
eG ya. html) fs
4 O bbdoy (216 ent) A,
ied are tate aria
‘ Lovisbnan ec reserves are those quaniiies of petroleum which, by enalyals of
and engineering date, can
imw« oo oe
ey le eae ene
(Me
Ria for Release: 2025/12/08 cor 83805 |
‘South erica Vawnaie Qe World Faetook i toy “Page 21 of 28.
: ‘ . F r ®
. . !
Wh (2018 est), ne C
BD wor ie _fhektar255rark himihVE) . ; <
* Bieta Ingtalled generating ‘ (/docenotesanddals.himi#266):
This entry Is the total capacky of curently indtalfed °
exprosaad in Kllowatta to produce electricity. A 10-idowait Serene se eae 22 eaten
a nciricity We rane conlieuoanty for one het, . ”
ig nie a eny meomre he capacty f tht prerl ly
Seth ce pea ch cr ean Te
This enty massures the of thet
* rer eal
miVE) x
hyn eee
ipartaon to himiVE)
gob bread aed pd
(Jiocelelsbanddefs he): This enky measures the capacty of plants that generale
Sey enn aes ee nen ed erage
P ; ae aA
oe ca) ‘
;
eee, ,
production (, finite Th yt mcf ie pr pre perce
imi pe tee 7
biwdey @017 eat). L
on to the workh 11 (./lleida/261 pork * F
(.tdoa : This entry Ia the tots! aricunt of erude ol exported, in barrels per day
E} 7 te 3 . u
bday (2016 est) . :
eriaon to the world: 8 ¢.Mefda/2e2renk
. f ate ‘
; _
county comiparizon to the wortd: 212 ekdecerark me cies
* Crude of - proved reserves (../docanotssanddefa himkk264):
This enty fe the ston
Pra
known reservoirs
ES f : 7 n
‘cia. gov/library/publicationa/the-world-Athcok/geos/ve html -
~~Approved for Release: 2025/12/08 C07183805-
Approved for Release: 2025/12/08 CO7183805.
a ''
‘ a ts : -
Asrerice :: Venemiela —@e World Factbook - Central Intelligenczency Paaiiaot
. V 7 = .
em be
es
- $02.5 billonibbi (1 January 2018 est) ‘ at. te
disc fo the world: 1 { Melds/284renik himeVE} .
eiroieum products - Tica cle aitomeadie aibsie: tas way ee inde waGdd aes
oni ducts, in barrels per day. (biiiday). The clecrepancy between the amount of refined pebrloum products produced -
sndiorimpy Sa ee Nene a eee eee agen refinery geine, antl other
~ ‘
(2016 ext) Pea -
ia cx bape NE eee é
evoloum products - ~ opuapion{.Aiccalotavoandsuds.hasdati: This ery ef county''s nl ooneustgen of
stenta products, In barrels per day (gbitday). The discrapsnoy between the amount of refined patrolaiim products,
ey sala nese ahead Sindtor exported Is due to the omlasion of stock changes, refinery galne,
me,
2G est). ° tes * : : . Rh. os ''
o lie cae ee
8 m er 7 Ty tars el pat tad
peeum fod, n bai per day (Ste), . ‘ Rk tae
‘bby (2016 est) : : isi F3 .
hémHVE).
pe products - lps aetna nT ery art imports ofretined.
: outs, bara per day (ne ‘ se
(iG est) - s : : a oe ee
barton to the wesid: 117 (Jfetas2eeenkhinave)
: on (catnip na a
‘ iim waa exported is
. Se, ene mene
.
OS himHAVE) * . . a
pum (2017 eat) bugs tg : :
20n to the workd: 28 (.Melda/28Granic htm) ‘ cad fi
ai - conaumation (docainotesanddee il#270): Tia ery the tte natural ges Gonsumed incu metrs (cr
‘ Ls
= Hésion of stock changes and other complicating actors,
himievE)
cu mi (2017 eat.) +
arieon to the world: 89 {. fhekds/27 Ordink. htin¥#VE)
a ene ee Ti ay th ta nfl genera aoe m).-
/ an Mee cree
oat . be ore ‘ ns a)
fo the world: 200 (.eld27 ‘rendchtmiev) :
-Hdocamnotasenddefs: SATA wats Ou et etal os aeedhicdes eis at
. wool
:
4 oe
wwe
awis toe Wes: 200 (Near Torark gai
gps abl raderarcon rir retin OR a REE
engineering data, can
" Netural gaa
Dp ivyordinh ). Proved reserves are these quaritities of natural ges, which, by analysis af gclogical and
3
cum (1 January 201B eat) te Sy ; a
erigon to the work: 7.(Aekdei27SrenkhonwVE) - - 4:
s . . . oe? mS ai
t= : Pa 2 a
¥ .cia.gov/library/publications/the-world-4book/geos/ve htm! ;
Approved for Release: 2025/12/08 C07183805. PP eore ne as
eases . Approved for Release: 2025/12/08 C07183805
* South Ambricaz Venemiela— ge Word Fetbook- Cental nteligene@iency | Pag 23 of 28
i e
fe m OK i es oe : ‘
(Carbon iioaide emissions from coneumption of energy (./doca/notesanddefs himi#274): This entry Ie the total amount of carbon’
= est od in metric tons, released by buming fossil fueis in the procees of proctucing and consuming energy.
{. Mloids/274.himWVE) : ae ,
20.9 milion Rt(2017 est} 2’ oe F Site
‘country comparison to tha world: $6 {.Melda/2?4rank htmigVE)
munications 2; Yenaguela
“Tekephte 24 hoc Ties {.Adoceinotesancets.hiri#106): This entry gives the total number of xed telephone thes in use: es
wo anteats ve
ber of subscriptions per 100
becriptions: 6,828,714 (2017 est.) - : : ; : ‘
becriptions per 100 inhabltente: 19 (2017 eat) “3 : . f
Soountry comp on to the world: 27 (. Mekia/1@8rank himieVizy 6 Te Pir wae
plaphones ~ Mobile celular (, /doce/ndtasanddefe.himu/197): Thia eniiy gives the‘total number of mobile Cellular telephone
ubscribe 8 wall as the number of subscription’ per 100 inhabitants. Note thaf bacausa of the ublquily of mobile phone use
oped countries, tha number of subscriptions per 100 inhablents can maceed 100; mn
Seidel 197, ro, My 7
total subscriptions: 24,403,687 (2017 est.) . . Ss .
bacriptions per 100 inhabitants: 76 (2017 eet) , : .
Country comperieon to the world: 60 (_/eldal1@7rank him¥eVE) .
Telephone syate (.Joca/notesanddefs.htmi#168): Thia entry inoludes a brief general easeesment of the system with detells
on the dompet and International components. The following terms end abbreviations are used throughout the entry: Arabast \\
Anah Satelite Communications Orgenization (Riyadh; Saudi Arabia), Autodin - Automatic Digital Netwerk (US Department of
Defense). GB - citizen''s band moble radio communications, Cetiuler telephone system «the telephones in this aystem are radia 5
braviscs ‘with each Instrumentshaving he 0. . more (.Adocsnoteagnddets. him 08) : ‘ oa
: i Bg oh? oh eres a
(ffiekia1 8. niene#VE) coe foe ee : eo i
n aeqaarment. modem and expanding; by late 2018 has dus to in the with
Pela ee ern bis
‘country due bo Anandal concems of customers, decrepit sate of fixed-line network and to pay for equipment from foreign
iS yendons; p y of social networks has given growth to mobile data traffic; LTE population coverage 47%
domestic: two domestic’ systems with three darth stations; telephone service in''rural
g recent improvement in
areas; . of @ nstional inter-urban fiber-optic network capable of digital multimedia services; 3 melor providers operate in
Bilbo! Pi and compete with stabe-cwned company, fteecine 18iper 100 and moblle-celtar telephones eubscrbership
i country code - 68; submarine cable systems provide cofinectivity to Cuba and the Carthbaan, Central and South ‘
H US; satadite earth atetions 4 Intelsat (Adentic Oosan) and 1 PanAmSat; participating with Colombia, Ecuador,
melivia in tre construction of an Intemational fiber-optic network = - sfoe. .
{..Adoca/notessnddefa.himi#180): This entry provides Information on the approximate numiber of pubic and
well a8 basic Information on the availability of satelite and cable TV sendces. -
dtmb202); :
Pe een Ht enc used by the Internet Assigned Numbers Aulhorty Sth
i r C Pe 7 :
r] ms .
ae S&S (
: : A .
littnsul/wrg}wicis. gov ibrary/publications/the-woild-Retbook/geosive.himl
Approved for Release: 2025/12/08 CO07183805. —- Eaten else
ener for Release: 202011 2/08 CO71 83805,
A
ica: Vente Wott sa chase . Page''24 of 28
i
''
ue ne . =
Reeve)
otal 18,547)981 (July 2018 eat).
‘percent of pap (ation: 60% (July 2016 eet}
fxd subocripions(./dceanoleeanddefsMinl#208): This erty ged the total mumble of fied-bedbend :
Subscriptions, ae well ae the number of subscriptions per 100 inhabitants, Fixed f cal wired
oe (eg cme ie eal erp ter an aa cents we
ig 4 * *
,
i)
,
Serengeti arn
: =e aon wagewannie, +more (-ddocahnotmeanddeta himit877) . ;
od ek carters: 17 (2018
d alycraft operated ay alc carters: 122 eons -
‘ fr er traffic on registered alr ‘camera: 8,468,863 (2015) : a
annual fraig talc on registred ale carer: 6.204.086 mf-on 2076) é oe : : : t
“ohiales i pgistration country cove prefix (.Jdocamotssanddets.hirilkS76): Thia entry provides the one- ortwo-charecter °
registration number consists of two perts: a prefix consisting of two-character alphanumeric
d ance rain aif on mas (cent aS
Jeti bee yD ate
0 dd Hmif’370): Th ‘erty gives the itl numberof dy bina git kos bath
Ste eee
b d inataliations. Airports or eicflelis thet are no loger recognizable (overgrown, no facilities, eta) are not Re,
G Pn ee ne ene: 5 ay
7 ce
__ aunty himuiVE}
- Alsports - f paved rurwaya (/doca/noteeatdets hii#360) Tha etry gle the total nanber of sirport with paved rurways.
Ssephall surfaces) by length. For alrports with than one runway, only the longest runwely Is Included
. ollewing five groupe = (1) over 3,047 m (over 10,000 oan gts Meats: Gea he
: eooot B.000 fy, 1) B14 to 1.28 m (3.0001 6,000 and (5) under 814 m (under 3,000. “Only airport with
, tonweys & poner eee Notall,.. more (. fe cS
y
nea han Tin don bel mb iat wh were
ent art depron bg For airports with more than one runway, only the-longest runvay Is
included abcort 9 to tha following five aroun) ove S047 fv #01000, 2) 2488 S047 (8,000 000M)
37 rm (6,000 to 8,600 A); (4) po egret pel ore aces Only airports
i ele ba dea i Riera acc carta
daf3ht
4
}
~ a °
cia. govibrary /publigations/the-world-Aictbodkd geod/ve.hiral 7 “5/17/2019
Approved for Release: 2025/12/08 CO07183805. a —— =
AppIoved for Release: 2025/1 | 2/08 C071 83805-
B29 m: 127 (2013)
i
under 914 m: 190 (2013)
ocainctosenddets., #082) The enty ee the teal number ot heliport wth hard-surfece runways, helipads, or
that eupport routine sustained wichabvely andi have aunport facie bichaing ane ce rete
clea adh fuel, pagaenger operate aaa ergo fu oo upp nang
/ddeahnotasenddefe himl#S83): This’ the lengthe and types of for
percept so lengths types som rt pt
Ban cide, Gtk 7 en i, 78 ats pc 9
§ IPS06: Tid ny elt rae tstn langle eo nine) bbiva ad b eoncoiee
. ich aw measure fo data beter th gr eso th lo bouhgrala The ar yp ype ot
oterdard, narrow, and dual, Other gauges are feted ander note, Some 60% of the world''s ralhvaya use the
gi male hd On Le en
On Wee Teap.... more Moceinctesanddets.himit384)
gt 447 km 1.436 gauge (4.4 kr elected) (2014)
to the workd: 116 (.
Th ye elie of roa nat ene rh
ed portions. : _
Te . : a ie Ue Me ,
een 2014) Se bade te OH .
OM pai tothe wort 42 (.Melde/S86rinic mtv)
Warm iSoccoessea ae Ti ry hosel nigh of eve er, ppirabaalreac apes
so Fv {000 er a cn ein agate went dcr
co on to the workd: 20 (.elde/38Grenk htm¥AVE)
Marchant my (Adocainotesanddefs henliS87): Merchant marie may’be detned es ai ships engagedtn the cariage of
“+ goods; or al commercial vesselg (8 cpposed to all nonmltary ships), which excludes tugs, flehing vessels, offshore off riga,”
trechuches tf ruber af shipe (1,000 GRT or aver, total DWT for those ‘ships, and totel GRT Yor those ships. DWT or dead ©
Weight tooroge fe the total weight ofc... more (ocahotsesnddete himi#67) : : :
‘Bau, b eater inntnaa nag pooner sa oa Salen ok
a d passenger ships. The ling ie. . ee ey F
: exp {..sdocainotesehddete himlé330}: This ‘This entry gives wai cl lua tela 9 a ee wea
wastes Serco fren ene po (COP te GOP moa nan geen a bbe
: : c ” 8 A d eee ik :
a atiebacae el Old al al eck SA72019
a7 om . . 7 be ie i .
a ~—~~-Approved for Release: 2025/12/08 CO7183805——-—----------
South America :: Vso he Wat Ca ag Page 25 of 28 .
ttc. This erfy contains information in four subiekis - total, ahips by type, forelgn-owned, and registered in other countries. Total
‘Approved for Release: 2025/12/08 CO7183805- 7
. Rennes - 4 s
b power pasty (PPP), Forcounties wih no mary forces, ie fgure can incuce expenditures on pubs secarty and
)
pinpariaon to the world: 114 (.fffeida/330mink himlaVE)
branches (/doca/notesanddele, himi#@34): Tir se evo bce bora dts i ct
of play round, reve, aed mane free), : & oe
ms x . a 3
i Antes *
of Armed Fite (Fuerza Armada Nii Gand, FANB): Baran Ay (co (Gert Savana, 0, FB)
‘Bolveran - y (Amada Bolvariana, AB: Includes Naval Infantry, Cosst Guard, Naval-A\\ Aviaion}, Bolvatan .
‘(Aviecion Mildar Bolivaiana, AMB; Includes Air National Guard), Bobvara Neon Gerd (Guarda Neco! Bott, GN) ‘
. Bolvarian tia (Milica Botivartana, NB} (2018)
“Miltary sebvice to bon (Mecano cma
’ oe eee
4
383,himWVE}
fy ieee (00 ri a iy se eg ney eat
8 mininum service obligation js 12 months (2016)
: ts (, .Adocanotesanddels_himie3s4); ‘This entry describes the threat of pimcy, an defined in Article 101, UN
0 on the Law of the Sea (UNCLOS), or amped robbery against ships, 8s defined In Resdlution A. 1026 (28) adopted
cH {chr ar ts und, ve hae og ibe sn te coos se W208 ee ers
d and this increased to 12 stacks In 2017 making Venezuela the fourth faxth most dangerous area in the Word.
group ornare pon ean tpt
ies blac pclae red at aa headquartered. Detaie
ofgantneatc ap a acca amar aaa
parson | Moots This erty inudes a wide veiety of sues that range fo
ataral boundary disputes to unliateral claims of one sort or another. Information regarding diaputes over
al toroatrial and Martine boundaries hes been reviewed by the US Department of Stain. Referinoes to ther
a vat 9 borders or frontiers may siso be incktied, tuxh 83 resqurce disputes, reread ,
aE an rennet eee: oe
Secnile iis Gas wen dio ego pera pans any ain lw wos edn Guyana has" :
* expressed Fitenfon Join Barbados In asserting cleims before ihe UN Convention oo the Law of the Sea thet Trinidad and
: e boundary with Venezuela extends into thelr weters; dispute with Colombls over martiime boundary and
ule Sintra Loe Moros lance nar the Gui of Venezu; Colomian organized Hegel nacoesend peranfay
é ea eee nee U8; France, and the Netherlands recognize Venezuele''s granting fl
Y ia govlbrarypbications/te-word-fltbook/geoshe btm : i ; "5/07/2019
Approved for Release: 2025/12/08 C07183805.
b Gosia tanned telsa tence eran sencieavoioee ara The entry Indudes the number of +
ee . : : - ” ried ke po?
Atherics :: Venezuela “Ov Factbook - Central Ineligencg@gency Page 26 0f 28, ake
ees for Release: 2025/12/08 C071 a
erica :: Vege Wo Facttvook - - Cr neon “Page 27.028
owalcondnatiel silt eamadiea ever portion
i as ‘
sieve ;
cet 1287 Cale 2017} a 7 ae ss
persons ( _docainotesanddets.himi#328): Trafficktrig kn persons si ows A Wotina who are.
Ged, or coerced Into isbor or sexual axpioltation. The sprain nai i vo ‘
fh eddreeding labor standerds, 1
ti dre Yoneda sesso er stabi cry ree, won me chin eu acetng en
0 ff Venemuelan women and girs, sometimes luréd from poor Interior regions to urban arid tourlet areas, are trafficked
8 on within the country, &8 Well as in the Carfubéen; Venezuelan chikdren are exploited, frequently by their
conditions
~ Venezuela dose not fuly comply withthe minimum standards for the emmineton of traficking and is nat
ig Be gan: 2044, be goverment appeared to Increase eforts to hold trefichere ofialy
d bit a lack ot government data metie inw enforcement efforts dfffcutt to assess, publonlly avetiathe
dicated many cases pureued under licking lew involved
2): This enby givea iniomaticn on the fve categories of ict druge - riteotios,
_ sea Gs stn) ara oma These ctogries clude many crgelgaly produced and,
preectbed by doctors as well as those Megaily produced and sok! outside of medical channels. Cannabla (Cannabis sativa) ia .
conund hes a oe cae tin mmf Aa
pen € grass, refer), a nana .
nM
J
. rualbacsle i te ec lt ch Aa t cala cela ica Sudan Gears lenge Guanes of
cocaine, hete snd marfijuena transit the country from bound for US and Europe; significant narcotice-raiated money °
‘ti laundering ciivity, ampecialty along thé border with rb omar erga cael ai :
pes al eee a ee a eee Sone ty Connie Pees See
“4a
cia. govilibrary/publicationa/the-world-Letbook/geowvehimt =. * 5/17/2019
‘Approved for Release: 2025/12/08 CO07183805. oe','fdf8dba056d175ac9b6931caca34f5dd21367e9e89d3cab9f35b11af5d360ad2','internet-archive','south-america-venezuela-16559438','txt','cf6a10ea00c36eb3db411ead5f1899246ed82cec14abf11f90452ebef3d181eb','https://archive.org/download/south-america-venezuela-16559438/SOUTH%20AMERICA%20VENEZUELA-%20%5B16559438%5D_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('730b5c9d12df0209e0186939df525ed6ec24186e4395e4cbfe9d56fe0eb446f6',2025,'','','raw',1,'FACTBOOK
CENTRAL INTELLIGENCE AGENCY
THE
WORLD
FACTBOOK
2014
MGE
CIA
WORLD
FACIBOOK
2014
CENTRAL INTELLIGENCE AGENCY
Skyhorse Publishing
Additional material copyright © 2013 by Skyhorse Publishing, Inc.
No claim is made to material contained in this work that is derived from government documents. Nevertheless, Skyhorse
Publishing claims copyright in all additional content, including, but not limited to, compilation copyright and the copyright
in and to any additional material, elements, design, images, or layout of whatever kind included herein.
All inquiries should be addressed to Skyhorse Publishing, 307 West 36th Street, 11th Floor, New York, NY 10018.
Skyhorse Publishing books may be purchased in bulk at special discounts for sales promotion, corporate gifts, fund-raising,
or educational purposes. Special editions can also be created to specifications. For details, contact the Special Sales
Department, Skyhorse Publishing, 307 West 36th Street, 11th Floor, New York, NY 10018or info@skyhorsepublishing.com.
Skyhorse® and Skyhorse Publishing® are registered trademarks of Skyhorse Publishing, Inc.®, a Delaware corporation.
Visit our website at www.skyhorsepublishing.com.
10987654321
Library of Congress Cataloging-in-Publication Data is available on file.
ISBN: 978-1-62636-073-0
Printed in Canada
CONTENTS
Introduction viii
A brief history of basic intelligence
and The World Factbook viii
Definitions and notes xi
Guide to country profiles xxxi
Afghanistan 1
Akrotiri 4
Albania 5
Algeria 8
American Samoa 12
Andorra 15
Angola 17
Anguilla 21
Antarctica 23
Antigua and Barbuda 25
Arctic Ocean 28
Argentina 28
Armenia 33
Aruba 37
Ashmore and Cartier Islands 39
Atlantic Ocean 40
Australia 41
Austria 45
Azerbaijan 49
Bahamas, the 53
Bahrain 56
Bangladesh 59
Barbados 63
Belarus 66
Belgium 70
Belize 74
Benin 77
Bermuda 81
Bhutan 83
Bolivia 87
Bosnia and Herzegovina 91
Botswana 95
Bouvet Island 98
Brazil 99
British Indian Ocean Territory 103
British Virgin Islands 104
Brunei 106
Bulgaria 109
Burkina Faso 113
Burma 116
Burundi 121','0566dc84691cdddcc47359011e5dca2dee1741f183f5a7a0a48dce4a3333e11a','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('78a5075befe51a5f405b926664934ccfbd01db269d5ca85abf431d125ca024d4',2025,'PF','French Polynesia','raw',2,'125
128
132
136
139
141
144
148
152
157
158
158
160
164
167
171
174
174
178
182
186
190
194
199
202
203
206
209
213
217
221
224
228
231
235
239
244
246
248
251
255
260
French Southern and
Antarctic Lands','5c00fa61840b3f6d8e55ddde385326aefb5882ad0fcdbec4b15c191168071f3b','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3032fcee31a740b6627bcac3aaeda3ed6110df4601f4c7fbfe480f902c3ef7ff',2025,'JO','Jordan','raw',3,'262
265
268
271
273
277
281
285
287
291
294
297
299
303
305
308
312
316
319
320
321
325
328
333
336
341
342
346
351
355
359
361
365
372','157c3e56f550df40f2e19a912baffaf13ea079d79b022b7b844b26072082a469','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('87a70f27aa51486ef08c21afe850bff7db85d80a0178bcb3d636943b992f27a0',2025,'NI','Nicaragua','raw',4,'vi
383
387
391
393
397
400
403
407
411
414
417
421
424
428
43]
433
437
441
444
447
451
454
459
462
466
469
472
475
478
483
485
489
491
495
498
500
504
508
511
514
514
518
522
524
528
THE CIA WORLD FACTBOOK','d09cb73d9bdd4634c7e0f02dcaf0b962322ac8fee42c43a9b19b4a3f6d2d9b21','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4084b8c03ed29c50006c9557601170b029033a17665ee716cbad9daba4be0826',2025,'SK','Slovakia','raw',5,'532
535
539
541
543
545
549
553
553
558
560
564
567
568
571
576
580
581
585
589
592
596
599
605
609
610
612
615
618
620
622
625
628
630
633
637
641
645
648
651
654
Slovenia 658
Solomon Islands 662
Somalia 665
South Africa 668
South Georgia and South
Sandwich Islands 672
Southern Ocean 673
Spain 675
Spratly Islands 679
Sri Lanka 680
Sudan 683
Suriname 687
Svalbard 691
Swaziland 692
Sweden 695
Switzerland 699
Syria 703
Taiwan 707
Tajikistan 710
Tanzania 714
Thailand 718
Timor-Leste 722
Togo 725
Tokelau 729
Tonga 730
Trinidad and Tobago 733
Tunisia 737
Turkey 740
Turkmenistan 745
Turks and Caicos Islands '' 748
Tuvalu 750
Uganda 753
Ukraine 756
United Arab Emirates 761
United Kingdom 764
United States 769
United States Pacific Island Wildlife
Refuges 774
Uruguay 775
Uzbekistan 779
Vanuatu 784
Venezuela 787
Vietnam 791
Virgin Islands 795
WAKEISLAND 798','ab88e923bddbfa97683610d188de3f099717f602dfe52b992ce41fc1e97cc73b','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5dfc481b2bb977566bfd514f0a218d2f7bd16cf861764eb565a4c6354df5415b',2025,'ZM','Zambia','raw',6,'- Zimbabwe
APPENDICES
A: Abbreviations
B: International Organizations
and Groups
798
800
803
804
810
814
817
822
828
CONTENTS
C: Selected International
Environmental Agreements
D: Cross-Reference List of
Country Data Codes
E: Cross-Reference List of
Hydrographic Data Codes
F: Cross-Reference List of
Geographic Names
G: Weights and Measures
REFERENCE MAPS
Africa
Antarctic Region
Arctic Region
Asia
Central America and the
Caribbean
Europe
856
863
871
872
903
914
915
916
917
918
919
Middle East
North America
Oceania
Physical Map of the World’
Political Map of the World
South America
Southeast Asia
Standard Time Zone of the World','41894a91cb9b684bfc21bed47166df805e4dc0790e13ca527538f4c09352de56','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);

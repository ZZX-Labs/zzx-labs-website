SET NAMES utf8mb4;
CREATE TABLE IF NOT EXISTS worldfactbook_chunks (
  chunk_id CHAR(64) NOT NULL,
  edition_year SMALLINT UNSIGNED NOT NULL,
  entity_code VARCHAR(24) NOT NULL DEFAULT '',
  entity_name VARCHAR(160) NOT NULL DEFAULT '',
  category VARCHAR(96) NOT NULL,
  ordinal INT UNSIGNED NOT NULL,
  content MEDIUMTEXT NOT NULL,
  content_sha256 CHAR(64) NOT NULL,
  source_provider VARCHAR(64) NOT NULL,
  source_identifier VARCHAR(255) NOT NULL,
  source_format VARCHAR(32) NOT NULL,
  source_sha256 CHAR(64) NOT NULL,
  source_url TEXT NOT NULL,
  extractor VARCHAR(64) NOT NULL,
  PRIMARY KEY (chunk_id),
  KEY idx_wfb_year_category (edition_year, category),
  KEY idx_wfb_entity_year (entity_code, edition_year),
  KEY idx_wfb_source_sha (source_sha256)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('edc9198445af4fbe5394808cfc474e0190a5751fca9eb3693802f5cdd6dd636d',2025,'US','United States','introduction',7,'The World Factbook is prepared by the Central Intelligence
Agency for the use of US Government officials, and the style,
format, coverage, and content are designed to meet their specific
requirements. Information is provided by Antarctic Information
Program (National Science Foundation), Armed Forces Medical
Intelligence Center (Department of Defense), Bureau of the Census
(Department of Commerce), Bureau of Labor Statistics (Depart-
ment of Labor), Central Intelligence Agency, Council of Manag-
ers of National Antarctic Programs, Defense Intelligence Agency
(Department of Defense), Department of Energy, Department of
State, Fish and Wildlife Service (Department of the Interior), Mari-
time Administration (Department of Transportation), National
Geospatial-Intelligence Agency (Department of Defense), Naval
Facilities Engineering Command (Department of Defense), Office
of Insular Affairs (Department of the Interior), Office of Naval
Intelligence (Department of Defense), US Board on Geographic
Names (Department of the Interior), US Transportation Command
(Department of Defense), Oil & Gas Journal, and other public and
private sources.
The Factbook is in the public domain. Accordingly, it may be cop-
ied freely without permission of the Central Intelligence Agency
(CIA). The official seal of the CIA, however, may NOT be copied
without permission as required by the CIA Act of 1949 (50 U.S.C.
section 403m). Misuse of the official seal of the CIA could result in
civil and criminal penalties.
Comments and queries are welcome and may be addressed to:
Central Intelligence Agency
Attn.: Office of Public Affairs
Washington, DC 20505
Hours: Monday-Friday 8:00 AM-4:30 PM Eastern Standard Time
Telephone: [1] (703) 482-0623
FAX: [1](703) 482-17
A BRIEF HISTORY OF BASIC INTELLIGENCE AND THE WORLD FACTBOOK
The Intelligence Cycle is the process by which information is
acquired, converted into intelligence, and made. available to
policymakers. Information is raw data from any source, data
that may be fragmentary, contradictory, unreliable, ambiguous,
deceptive, or wrong. Intelligence is information that has been
collected, integrated, evaluated, analyzed, and interpreted. Fin-
ished intelligence is the final product of the Intelligence Cycle
ready to be delivered to the policymaker.
The three types of finished intelligence are: basic, current, and
estitnative. Basic intelligence provides the fundamental and fac-
tual reference material on a country or issue. Current intelligence
reports on new developments. Estimative intelligence judges prob-
_ able outcomes. The three are mutually supportive: basic intelligence
is the foundation on which the other two are constructed; current
intelligence continually updates the inventory of knowledge; and
estimative intelligence revises overall interpretations of country and
issue prospects for guidance of basic and current intelligence. The
World Factbook, The President’ Daily Brief, and the National
Intelligence Estimates are examples of the three types of finished
intelligence.
The United States has carried on foreign intelligence activities
since the days of George Washington but only since World War
II have they been coordinated on a government-wide basis. Three
programs have highlighted the development of coordinated basic
intelligence since that time: (1) the Joint Army Navy Intelligence
Studies (JANIS), (2) the National Intelligence Survey (NIS), and
(3) The World Factbook .
During World War II, intelligence consumers realized that the pro-
duction of basic intelligence by different components of the US
Government resulted in a great duplication of effort and conflicting
information. The Japanese attack on Pearl Harbor in 1941 brought
home to leaders in Congress and the executive branch the need for
integrating departmental reports to national policymakers. Detailed
and coordinated information was needed not only on such major
powers as Germany and Japan, but also on places of little previous
interest. In the Pacific Theater, for example, the Navy and Marines
viii
had to launch amphibious operations against many islands about
which information was unconfirmed or nonexistent. Intelligence
authorities resolved that the United States should never again be
caught unprepared.
In 1943, Gen. George B. Strong (G-2), Adm. H. C. Train (Office of
Naval Intelligence—ONI), and Gen. William J. Donovan (Director
of the Office of Strategic Services—OSS) decided that a joint effort
should be initiated. A steering committee was appointed on 27 April
1943 that recommended the formation of a Joint Intelligence
Study Publishing Board to assemble, edit, coordinate, and publish
the Joint Army Navy Intelligence Studies (JANIS). JANIS was
the first interdepartmental basic intelligence program to fulfill the
needs of the US Government for an authoritative and coordinated
appraisal of strategic basic intelligence. Between April 1943 and
July 1947, the board published 34 JANIS studies. JANIS performed
well in the war effort, and numerous letters of commendation were
received, including a statement from Adm. Forrest Sherman, Chief
of Staff, Pacific Ocean Areas, which said, “JANIS has become the
indispensable reference work for the shore-based planners.”
The need for more comprehensive basic intelligence in the post-
war world was well expressed in 1946 by George S. Pettee, a noted
author on national security. He wrote in The Future of American
Secret Intelligence (Infantry Journal Press, 1946, page 46) that
world leadership in peace requires even more elaborate intelligence
than in war. “The conduct of peace involves all countries, all human
activiti¢s—not just the enemy and his war production.”
The Central Intelligence Agency was established on 26 July 1947
and officially began operating on 18 September 1947. Effective
t October 1947, the Director of Central Intelligence assumed oper-
ational responsibility for JANIS. On 13 January 1948, the National
Security Council issued Intelligence Directive (NSC ID) No. 3,
which authorized the National Intelligence Survey (NIS) program
as a peacetime replacement for the wartime JANIS program. Before
adequate NIS country sections could be produced, government
agencies had to develop more comprehensive gazetteers and better
maps. The US Board on Geographic Names (BGN) compiled the
A BRIEF HISTORY OF BASIC
names; the Department of the Interior produced the gazetteers; and
CIA produced the maps.
The Hoover Commission’s Clark Committee, set up in 1954 to study
the structure and administration of the CIA, reported to Congress
in 1955 that: “The National Intelligence Survey is an invaluable
publication which provides the essential elements of basic intelli-
gence on all areas of the world. There will always be a continuing
requirement for keeping the Survey up-to-date.” The Factbook was
created as an annual summary and update to the encyclopedic NIS
studies. The first classified Factbook was published in August 1962,
and the first unclassified version was published in June 1971. The
NIS program was terminated in 1973 except for the Factbook, map,
and gazetteer components. The 1975 Factbook was the first to be
made available to the public with sales through the US Govern-
ment Printing Office (GPO). The Factbook was first made avail-
able on the Internet in June 1997. The year 2013 marks the 66th
anniversary of the establishment of the Central Intelligence Agency
and the 70th year of continuous basic intelligence support to the
US Government by The World Factbook and its two predecessor
programs.
The Evolution of The World Factbook
National Basic Intelligence Factbook produced semiannually
until 1980. Country entries include sections on Land, Water, Peo-
ple, Government, Economy, Communications, and Defense Forces.
1981—Publication becomes an annual product and is renamed The
World Factbook. A total of 165 nations are covered on 225 pages.
1983—Appendices (Conversion Factors, International Organiza-
tions) first introduced.
1984—Appendices expanded; now include: A. The United
Nations, B. Selected United Nations Organizations, C. Selected
International Organizations, D. Country Membership in Selected
Organizations, E. Conversion Factors.
1987—A new Geography section replaces the former separate Land
and Water sections. UN Organizations and Selected International
Organizations appendices merged into a new International Organi-
zations appendix. First multi-color-cover Factbook.
988—More than 40 new geographic entities added to provide
complete world coverage without overlap or omission. Among
the new entities are Antarctica, oceans (Arctic, Atlantic, Indian,
Pacific), and the World. The front-of-the-book explanatory intro-
duction expanded and retitled to Notes, Definitions, and Abbrevia-
tions. Two new Appendices added: Weights and Measures (in place
of Conversion Factors) and a Cross-Reference List of Geographic
Names. Factbook size reaches 300 pages.
1989—Economy section completely revised and now includes an
Overview briefly describing a country’s economy. New entries added
under People, Government, and Communications.
section revised and considerably
1990—The Government
expanded with new entries.
1991—A new International Organizations and Groups appendix
added. Factbook size reaches 405 pages.
1992—Twenty new successor state entries replace those of the
Soviet Union and Yugoslavia. New countries are respectively:
Armenia, Azerbaijan, Belarus, Estonia, Georgia, Kazakhstan, Kyr-
gyzstan, Latvia, Lithuania, Moldova, Russia, Tajikistan, Turkmeni-
stan, Ukraine, Uzbekistan; and Bosnia and Hercegovina, Croatia,
Macedonia, Serbia and Montenegro, Slovenia. Number of nations
in the Factbook rises to 188.
1993—Czechoslovakia’s split necessitates new Czech Republic and
Slovakia entries. New Eritrea entry added after it secedes from Ethi-
opia. Substantial enhancements made to Geography section.
INTELLIGENCE AND THE WORLD FACTBOOK
1994—Two new appendices address Selected International Envi-
ronmental Agreements. The gross domestic product (GDP) of most
developing countries changed to a purchasing power parity (PPP)
basis rather than an exchange rate basis. Factbook size up to 512
pages.
1995—The GDP of all countries now presented on a PPP basis.
New appendix lists estimates of GDP on an exchange rate basis.
Communications category split; Railroads, Highways, Inland water-
ways, Pipelines, Merchant marine, and Airports entries. now make
up a new Transportation category. The World Factbook is first pro-
duced on CD-ROM.
1996—Maps accompanying each entry now present more detail.
Flags also introduced for nearly all entities. Various new entries
appear under Geography and Communications. Factbook abbre-
viations consolidated into a new Appendix A. Two new appendices
present a Cross-Reference List of Country Data Codes and a Cross-
Reference List of Hydrogeographic Data Codes. Geographic coor-
dinates added to Appendix H, Cross-Reference List of Geographic
Names. Factbook size expands by 95 pages in one year to reach 652.
1997—The World Factbook introduced onto the Internet. A
special printed edition prepared for the CIA’s 50th anniversary. A
schema or Guide to Country Profiles introduced. New color maps
and flags now accompany each country profile. Category head-
ings, distinguished by shaded backgrounds. Number of categories
expanded to nine with the addition of an Introduction (for only a
few countries) and Transnational Issues (which includes Disputes-
international and Illicit drugs).
1998—The Introduction category with two entries, Current issues
and Historical perspective, expanded to m ore countries. Last year
for the production of CD-ROM versions of the Factbook .
1999—Historical perspective and Current issues entries in the
- Introduction category combined into a new Background statement.
Several new Economy entries introduced. A new physical map of
the world added to the back-of-the-book reference maps.
2000—A new “country profile” added on the Southern Ocean. The
Background statements dramatically expanded to over 200 coun-
tries and possessions. A number of new Communications entries
added.
2001—Background entries completed for all 267 entities in the
Factbook. Several new HIV/AIDS entries introduced under the
People category. Revision begun on individual country maps to
include elevation extremes and a partial geographic grid. Weights
and Measures appendix deleted .
2002—New entry on Distribution of Family income—Gini index
added. Revision of individual country maps continued (process still
ongoing).
2003—In the Economy category, petroleum entries added for oil
production, consumption, exports, imports, and proved reserves, as
well as natural gas proved reserves.
2004—Bi-weekly updates launched on The World Factbook web-
site. Additional petroleum entries included for natural gas produc-
tion, consumption, exports, and imports. In the Transportation cat-
egory, under Merchant marine, subfields added for foreign-owned
vessels and those registered in other countries. Descriptions of the
many forms of government mentioned in the Factbook incorporated
into the Definitions and Notes.
2005—In the People category, a Major infectious diseases field
added for countries deemed to pose a higher risk for travelers. In the
Economy category, entries included for Current account balance,
Investment, Public debt, and Reserves of foreign exchange and
gold. The Transnational issues category expanded to include Refu-
gees and internally displaced persons. Size of the printed Factbook
reaches 702 pages.
ix
HIE
2006—In the Economy category, national GDP figures now pre-
'' sented at Official Exchange Rates (OER) in addition to GDP at pur-
chasing power parity (PPP). Entries in the Transportation section
reordered; Highways changed to Roadways, and Ports and harbors
to Ports and terminals.
2007~In the Government category, the Capital entry significantly
expanded with up to four subfields, including new information hav-
ing to do with time. The subfields consist of the name of the capital
itself, its geographic coordinates, the time difference at the capital
from coordinated universal time (UTC), and, if applicable, informa-
tion on daylight saving time (DST) Where appropriate a special
note is added to highlight those countries with multiple time zones.
A Trafficking in persons entry added to the Transnational issues cat-
egory.-A new appendix, Weights and Measures, (re) introduced to
the online version of the Factbook.
2008—In the Geography category, two fields focus on the increas-
ingly vital resource of water: Total renewable water resources and
Freshwater withdrawal. In the Economy category, three fields added
for: Stock of direct foreign investment—at home, Stock of direct
foreign investment—abroad, and Market value of publicly traded
shares. Concise descriptions of all major religions included in the
Definitions and Notes. Responsibility for printing of The World
Factbook turned over to the Government Printing Office.
2009—The online Factbook site completely redesigned with many .
new features. In the People category, two new fields provide infor-
mation on education in terms of opportunity and resources: School
Life Expectancy and Education expenditures. Additionally, the
Urbanization entry expanded to include all countries. In the Econ-
omy category, five fields added: Central bank discount rate, Com-
mercial bank prime lending rate, Stock of narrow money, Stock of
broad money, and Stock of domestic credit.
CiA WORLD FACTBOOK
2010—Weekly updates inaugurated on the The World Factbook
website. The dissolution of the Netherlands Antilles results in two
new listings: Curacao and Sint Maarten. In the Communications
category, a Broadcast media field replaces the former Radio broad-
cast stations and TV broadcast stations entries. In the Geography
section, under Natural hazards, a Volcanism subfield added for
countries with historically active volcanoes. In the Government
category, a new National anthems field introduced. Concise descrip-
tions of all major Legal systems incorporated into the Definitions
and Notes. In order to facilitate comparisons over time, dozens of
the entries in the Economy category expanded to include two (and
in some cases three) years’ worth of data.
2011—The People section expanded to People and Society, incor-
porating ten new fields. The Economy category added Taxes and
other revenues and Budget surplus (+) or deficit (-), while the Gov-
ernment section introduced International law organization partici-
pation and National symbols. A new African nation, South Sudan,
brings the total number of countries in The World Factbook to
195.
2012—A new Energy category introduced with 23 energy-related
fields. Several distinctive features added to The World Factbook
website: 1) playable audio files in the Government section for the
National Anthems entry, 2) online graphics in the form of a Popu-
lation Pyramid feature in the People and Society category’s Age
Structure field, and 3) a Users Guide enabling visitors to navigate
the Factbook more easily and efficiently. A new and distinctive
Map of the World Oceans highlights an expanded array of regional
and country maps. Size of the printed Factbook’s 50th anniversary
edition reaches 847 pages.
DEFINITIONS AND NOTES
Abbreviations This information is included in Appendix A:
Abbreviations, which includes all abbreviations and acronyms
used in the Factbook, with their expansions.
Acronyms An acronym is an abbreviation coined from the
initial letter of each successive word in a term or phrase. In gen-
eral, an acronym made up solely from the first letter of the major
words in the expanded form is rendered in all capital letters (NATO
from North Atlantic Treaty Organization; an exception would be
ASEAN for Association of Southeast Asian Nations). In general,
an acronym made up of more than the first letter of the major words
in the expanded form is rendered with only an initial capital letter
(Comsat from Communications Satellite Corporation; an excep-
tion would be NAM from Nonaligned Movement). Hybrid forms
are sometimes used to distinguish between initially identical terms
(ICC for International Chamber of Commerce and ICCt for Inter-
national Criminal Court).
Administrative divisions This entry generally gives the
numbers, designatory terms, and first-order administrative divi-
sions as approved by the US Board on Geographic Names (BGN).
Changes that have been reported but not yet acted on by the BGN
are noted.
Age structure This entry provides the distribution of the pop-
ulation according to age. Information is included by sex and age
group as follows: 0-14 years (children), 15-24 years (early working
age), 25-54 years (prime working age), 55-64 years (mature work-
ing age), 65 years and over (elderly). The age structure of a popu-
lation affects a nation’s key socioeconomic issues. Countries with
young populations (high percentage under age 15) need to invest
more in schools, while countries with older populations (high per-
centage ages 65 and over) need to invest more in the health sector.
The age structure can also be used to help predict potential political
issues. For example, the rapid growth of a young adult population
unable to find employment can lead to unrest.
Agriculture—products This entry is an ordered listing of
major crops and products starting with the most important.
Airports This entry gives the total number of airports or airfields
recognizable from the air. The runway(s) may be paved (concrete or
asphalt surfaces) or unpaved (grass, earth, sand, or gravel surfaces)
and may include closed or abandoned installations. Airports or air-
fields that are no longer recognizable (overgrown, no facilities, etc.)
are not included. Note that not all airports have accommodations
for refueling, maintenance, or air traffic control.
Alrports—with paved runways This entry gives the total
number of airports with paved runways (concrete or asphalt sur-
faces) by length. For airports with more than one runway, only the
longest runway is included according to the following five groups—
(1) over 3,047 m (over 10,000 ft), (2) 2,438 to 3,047 m (8,000 to
10,000 ft), (3) 1,524 to 2,437 m (5,000 to 8,000 ft), (4) 914 to 1,523
m (3,000 to 5,000 ft), and (5) under 914 m (under 3,000 ft). Only
airports with usable runways are included in this listing. Not all air-
ports have facilities for refueling, maintenance, or air traffic con-
trol. The type aircraft capable of operating from a runway of a given
length is dependent upon a number of factors including elevation of
the runway, runway gradient, average maximum daily temperature
at the airport, engine types, flap settings, and take-off weight of the
aircraft.
Alrports—with unpaved runways This entry gives the
total number of airports with unpaved runways (grass, dirt, sand, or
gravel surfaces) by length. For airports with more than one runway,
"only the longest runway is included according to the following five
groups—(1) over 3,047 m (over 10,000 ft), (2) 2,438 to 3,047 m
(8,000 to 10,000 ft), (3) 1,524 to 2,437 m (5,000 to 8,000 ft), (4) 914
to 1,523 m (3,000 to,5,000 ft), and (5) under 914 m (under 3,000
fc). Only airports with usable runways are included in this listing.
Not all airports have facilities for refueling, maintenance, or air traf-
fic control, The type aircraft capable of operating from a runway
of a given length is dependent upon a number of factors including
elevation of the runway, runway gradient, average maximum daily
temperature at the airport, engine types, flap settings, and take-off
weight of the aircraft.
Appendixes This section includes Factbook-related material
by topic.
Area This entry includes three subfields. Total area is the sum of
all land and water areas delimited by international boundaries and/
‘or coastlines. Land area is the aggregate of all surfaces delimited by
international boundaries and/or coastlines, excluding inland water
bodies (lakes, reservoirs, rivers). Water area is the sum of the sur-
faces of all inland water bodies, such as lakes, reservoirs, or rivers, as
delimited by international boundaries and/or coastlines.
Area—comparative This entry provides an area comparison
based on total area equivalents. Most entities are compared with the
entire US or one of the 50 states based on area measurements (1990
revised) provided by the US Bureau of the Census. The smaller enti-
ties are compared with Washington, DC (178 sq km, 69 sq mi) or
The Mall in Washington, DC (0.59 sq km, 0.23 sq mi, 146 acres).
Background This entry usually highlights major historic events
and current issues and may include a statement about one or two
key future trends.
Birth rate This entry gives the average annual number of births
during a year per 1,000 persons in the population at midyear; also
known as crude birth rate. The birth rate is usually the dominant
factor in determining the rate of population growth. It depends on
_ both the level of fertility and the age structure of the population.
Broadcast media This entry provides information on the ap-
proximate number of public and private TV and radio stations in a
country, as well as basic information on the availability of satellite
and cable TV services.
Budget This entry includes revenues, expenditures, and capital
expenditures. These figures are calculated on an exchange rate basis,
ie., not in purchasing power parity (PPP) terms.
Budget surplus (+) or deficit (-) This entry records the
difference between national government revenues and expendi-
tures, expressed as a percent of GDP. A positive (+) number indi-
cates that revenues exceeded expenditures (a budget surplus), while
a negative (-) number indicates the reverse (a budget deficit). Nor-
malizing the data, by dividing the budget balance by GDP, enables
easy comparisons across countries''and indicates whether a national
government saves or borrows money. Countries with high budge','27f738c7bc77143ee7261907c6543114faf12df56203c193538c073dbc178413','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('375e143b3d71898b20983fe54c28b826deb72ff09ddb6d5c1b629d017422032b',2025,'US','United States','introduction',8,'t
deficits (relative to their GDPs) generally have more difficulty rais-
ing funds to finance expenditures, than those with lower deficits.
Capital This entry gives the name of the seat of government, its
geographic coordinates, the time difference relative to Coordi-
nated Universal Time (UTC) and the time observed in Wash-
ington, DC, and, if applicable, information on daylight saving time
(DST). Where appropriate, a special note has been added to high-
light those countries that have multiple time zones.
Carbon dioxide emissions from consumption of
energy This entry is the total amount of carbon dioxide, meas-
ured in metric tons, released by burning fossil fuels in the process of
producing and consuming energy.
Central bank discount rate This entry provides the an-
nualized interest rate a country’s central bank charges commercial,
depository banks for loans to meet temporary shortages of funds.
Children under the age of 5 years underweight This
entry gives the percent of children under five considered to be un-
derweight. Underweight means weight-for-age is approximately 2 kg
below for standard at age one, 3 kg below standard for ages two and
xi
THE CIA WORLD FACTBOOK
three, and 4 kg below standard for ages four and five. This statistic
is an indicator of the nutritional status of a community. Children
who suffer from growth retardation as a result of poor diets and/or
recurrent infections tend to have a greater risk of suffering illness
and death.
Climate This entry includes a brief description of typical weather
regimes throughout the year.
Coastline This entry gives the total length of the boundary
between the land area (including islands) and the sea.
Commercial bank prime lending rate This entry pro-
vides a simple average of annualized interest rates commercial banks
charge on new loans, denominated in the national currency, to their
most credit-worthy customers.
Communications This category deals with the means of
exchanging information and includes the telephone, radio, televi-
sion, and Internet host entries.
Communications—note This. entry includes miscellane-
ous communications information of significance not included else-
where.
Constitution This entry includes the dates of adoption, revi-
sions, and major amendments.
Coordinated Universal Time (UTC) UTC is the interna-
tional atomic time scale that serves as the basis of timekeeping for
most of the world. The hours, minutes, and seconds expressed by
UTC represent the time of day at the Prime Meridian (0° longi-
tude) located near Greenwich, England as reckoned from midnight.
UTC is calculated by the Bureau International des Poids et Meas-
ures (BIPM) in Sevres, France. The BIPM averages data collected
from more than 200 atomic time and frequency standards located at
about 50 laboratories worldwide. UTC is the basis for all civil time
with the Earth divided into time zones expressed as positive or nega-
tive differences from UTC. UTC is also referred to as “Zulu time.”
See the Standard Time Zones of the World map included with the
Reference Maps.
Country data codes See Data codes.
Country map Most versions of the Factbook provide a country
map in color. The maps were produced from the best information
available at the time of preparation. Names and/or boundaries may
have changed subsequently.
Country name This entry includes all forms of the country’s
name approved by the US Board on Geographic Names (Italy is
used as an example): conventional long form (Italian Republic),
conventional short form (Italy), local long form (Repubblica
Italiana), local short form (Italia), former (Kingdom of Italy), as
well as the abbreviation. Also see the Terminology note.
Crude oil—exports This entry is the total amount of crude oil
exported, in barrels per day (bbl/day).
Crude oil—imports This entry is the total amount of crude oil
imported, in barrels per day (bbl/day).
Crude oil—production This entry is the total amount of
crude oil produced, in barrels per day (bbl/day).
Crude oii—proved reserves This entry is the stock of
proved reserves of crude oil, in barrels (bbl). Proved reserves are
those quantities of petroleum which, by analysis of geological and
engineering data, can be estimated with a high degree of confidence
to be commercially recoverable from a given date forward, from
known reservoirs and under current economic conditions.
Current account balance This entry records a coun-
try’s net trade in goods and services, plus net earnings from rents,
interest, profits, and dividends, and net transfer payments (such as
pension funds and worker remittances) to and from the rest of the
world during the period specified. These figures are calculated on
an exchange rate basis, i.e., not in purchasing power parity (PPP)
terms.
Data codes This information is presented in Appendix D:
Cross-Reference List of Country Data Codes and Appen-
dix E: Cross-Reference List of Hydrographic Data Codes.
xii
Date of information In general, information available as of
January in a given year is used in the preparation of the printed
edition.
Daylight Saving Time (DST) This entry is included for
those entities that have adopted a policy of adjusting the official
local time forward, usually one hour, from Standard Time during
summer months. Such policies are most common in mid-latitude
regions.
Death rate This entry gives the average annual number of
deaths during a year per 1,000 population at midyear; also known
as crude death rate. The death rate, while only a rough indicator
of the mortality situation in a country, accurately indicates the
current mortality impact on population growth. This indicator is
significantly affected by age distribution, and most countries will
eventually show a rise in the overall death rate, in spite of continued
decline in mortality at all ages, as declining fertility results in an
aging population.
Debt—external This entry gives the total public and private
debt owed to nonresidents repayable in internationally accepted
currencies, goods, or services. These figures are calculated on an ex-
change rate basis, i.e., not in purchasing power parity (PPP) terms.
Demographic profile This entry describes a country’s key .
demographic features and trends and how they vary among regional,
ethnic, and socioeconomic sub-populations. Some of the topics ad-
dressed are population age structure, fertility, health, mortality, pov-
erty, education, and migration.
Dependency status This entry describes the formal relation-
ship between a particular nonindependent entity and an independ-
ent state.
Dependent areas This entry contains an alphabetical listing
of all nonindependent entities associated in some way with a par-
ticular independent state.
Diplomatic representation The US Government has dip-
lomatic relations with 190 independent states, including 188 of the
193 UN members (excluded UN members are Bhutan, Cuba, Iran,
North Korea, and the US itself). In addition, the US has diplomatic
telations with 2 independent states that are not in the UN, the Holy
See and Kosovo, as well as with the EU.
Diplomatic representation from the US This entry
includes the chief of mission, embassy address, mailing address,
telephone number, FAX number, branch office locations, con-
sulate gerieral locations, and consulate locations.
Diplomatic representation in the US This entry in-
cludes the chief of mission, chancery address, telephone, FAX,
consulate general locations, and consulate locations. The use of
the annotated title Appointed Ambassador refers to a new ambas-
sador who has presented his/her credentials to the secretary of state
but not the US president. Such ambassadors fulfill all diplomatic
functions except meeting with or appearing at functions attended
by the president until such time as they formally present their cre-
dentials at a White House ceremony.
Disputes—international This entry includes a wide variety
of situations that range from traditional bilateral boundary disputes
to unilateral claims of one sort or another. Information regarding
disputes over international terrestrial and maritime boundaries has
been reviewed by the US Department of State. References to other
situations involving borders or frontiers may also be included, such
as resource disputes, geopolitical questions, or irredentist issues;
however, inclusion does not necessarily constitute official accept-
ance or recognition by the US Government.
Distribution of family income—Gini index This index
measures the degree of inequality in the distribution of family in-
come in a country. The index is calculated from the Lorenz curve,
in which cumulative family income is plotted against the number
of families arranged from the poorest to the richest. The index
is the ratio of (a) the area between a country’s Lorenz curve and
the 45 degree helping line to (b) the entire triangular area under the
45 degree line. The more nearly equal a country’s income distribu-
tion, the closer its Lorenz curve to the 45 degree line and the lower
DEFINITIONS AND NOTES : z
its Gini index, e.g., a Scandinavian country with an index of 25.
The more unequal a country’s income distribution, the farther its
Lorenz curve from the 45 degree line and the higher its Gini index,
e.g., a Sub-Saharan country with an index of 50. If income were
distributed with perfect equality, the Lorenz curve would coincide
with the 45 degree line and the index would be zero; if income were
distributed with perfect inequality, the Lorenz curve would coincide
with the horizontal axis and the right vertical axis and the index
would be 100.
Drinking water source This entry provides information
about access to improved or unimproved drinking water sources
available to segments of the population of a country. improved
drinking water—use of any of the following sources: piped water
into dwelling, yard, or plot; public tap or standpipe; tubewell or
borehole; protected dug well; protected spring; or rainwater col-
lection. unimproved drinking water—use of any of the following
sources: unprotected dug well; unprotected spring; cart with small
tank or drum; tanker truck; surface water, which includes rivers,
dams, lakes, ponds, streams, canals or irrigation channels; or bot-
tled water.
Economy This category includes the entries dealing with the
size, development, and management of productive resources, i.e.,
land, labor, and capital.
Economy—overview This entry briefly describes the type
of economy, including the degree of market orientation, the level
of economic development, the most important natural resources,
and the unique areas of specialization. It also characterizes major
economic events and policy changes in the most recent 12 months
and may include a statement about one or two key future macro-
economic trends.
Education expenditures This entry provides the public
expenditure on education as a percent of GDP.
Electricity—consumption This entry consists of total elec-
tricity generated annually plus imports and minus exports, expressed
in kilowatt-hours. The discrepancy between the amount of electric-
ity generated and/or imported and the amount consumed and/or
exported is accounted for as loss in transmission and distribution.
Electricity—exports This enuy is the total exported electric-
ity in kilowatt-hours. ,
Electricity—from fossil fuels This entry measures the
capacity of plants that generate electricity by burning fossil fuels
(such as coal, petroleum products, and natural gas), expressed as a
share of the country’s total generating capacity.
Electricity—trom hydroelectric plants This entry meas-
ures the capacity of plants that generate electricity by water-driven
turbines, expressed as a share of the country’s total generating ca-
pacity.
Electricity—from nuclear fuels This entry measures the
capacity of plants that generate electricity through radioactive
decay of nuclear fuel, expressed as a share of the country’s total gen-
erating capacity.
Electricity—from other renewable sources This entry
measures the capacity of plants that generate electricity by using
renewable energy sources other than hydroelectric (including, for
example, wind, waves, solar, and geothermal), expressed as a share
of the country’s total generating capacity.
Electricity—imports This entry is the total imported electric-
ity in kilowatt-hours.
Electricity—installed generating capacity This entry
is the total capacity of currently installed generators, expressed in
kilowatts (kW), to produce electricity. A 10-kilowatt (kW) genera-
tor will produce 10 kilowatt hours (kWh) of electricity, if it runs
continuously for one hour.
Electricity—production This entry is the annual electricity
generated expressed in kilowatt-hours. The discrepancy between the
amount of electricity generated and/or imported and the amount
consumed and/or exported is accounted for as loss in transmission
and distribution.
Elevation extremes This entry includes both the highest
point and the lowest point.
Energy This category includes entries dealing with the produc-
tion, consumption, import, and export of various forms of energy
including electricity, crude oil, refined petroleum products, and
natural gas.
Entities Some of the independent states, dependencies, areas of
special sovereignty, and governments included in this publication
are not independent, and others are not officially recognized by the
US Government. “Independent state” refers to a people politically
organized into a sovereign state with a definite territory. “Depend-
encies” and “areas of special sovereignty” refer to a broad category of
political entities that are associated in some way with an independ-
ent state. “Country” names used in the table of contents or for page
headings are usually the short-form names as approved by the US
Board on Geographic Names and may include independent states,
dependencies, and areas of special sovereignty, or other geographic
entities. There are a total of 267 separate geographic entities in The
World Factbook that may be categorized as follows:
INDEPENDENT STATES
195 Afghanistan, Albania, Algeria, Andorra, Angola, Antigua
and Barbuda, Argentina, Armenia, Australia, Austria, Azerbaijan,
The Bahamas, Bahrain, Bangladesh, Barbados, Belarus, Belgium,
Belize, Benin, Bhutan, Bolivia, Bosnia and Herzegovina, Botswana,
Brazil, Brunei, Bulgaria, Burkina Faso, Burma, Burundi, Cambo-
dia, Cameroon, Canada, Cape Verde, Central African Republic,
Chad, Chile, China, Colombia, Comoros, Democratic Republic
of the Congo, Republic of the Congo, Costa Rica, Cote d''Ivoire,
Croatia, Cuba, Cyprus, Czech Republic, Denmark, Djibouti, Domi-
nica, Dominican Republic, Ecuador, Egypt, El Salvador, Equatorial
Guinea, Eritrea, Estonia, Ethiopia, Fiji, Finland, France, Gabon,
The Gambia, Georgia, Germany, Ghana, Greece, Grenada, Guate-
mala, Guinea, Guinea-Bissau, Guyana, Haiti, Holy See, Honduras,
Hungary, Iceland, India, Indonesia, Iran, Iraq, Ireland, Israel, Italy,
. Jamaica, Japan, Jordan, Kazakhstan, Kenya, Kiribati, North Korea,
South Korea, Kosovo, Kuwait, Kyrgyzstan, Laos, Latvia, Lebanon,
Lesotho, Liberia, Libya, Liechtenstein, Lithuania, Luxembourg,
Macedonia, Madagascar, Malawi, Malaysia, Maldives, Mali, Malta,
Marshall Islands, Mauritania, Mauritius, Mexico, Federated States of
Micronesia, Moldova, Monaco, Mongolia, Montenegro, Morocco,
Mozambique, Namibia, Nauru, Nepal, Netherlands, NZ, Nicaragua,
Niger, Nigeria, Norway, Oman, Pakistan, Palau, Panama, Papua
New Guinea, Paraguay, Peru, Philippines, Poland, Portugal, Qatar,
Romania, Russia, Rwanda, Saint Kitts and Nevis, Saint Lucia, Saint
Vincent and the Grenadines, Samoa, San Marino, Sao Tome and
Principe, Saudi Arabia, Senegal, Serbia, Seychelles, Sierra Leone,
Singapore, Slovakia, Slovenia, Solomon Islands, Somalia, South
Africa, South Sudan, Spain, Sri Lanka, Sudan, Suriname, Swazi-
land, Sweden, Switzerland, Syria, Tajikistan, Tanzania, Thailand,
Timor-Leste, Togo, Tonga, Trinidad and Tobago, Tunisia, Turkey,
Turkmenistan, Tuvalu, Uganda, Ukraine, UAE, UK, US, Uru-
guay, Uzbekistan, Vanuatu, Venezuela, Vietnam, Yemen, Zambia,
Background: Britain’s American colonies broke
with the mother country in 1776 and were recog-
nized as the new nation of the United States of
America following the Treaty of Paris in 1783.
During the 19th and 20th centuries, 37 new
states were added to the original 13 as the nation
expanded across the North American continent
and acquired a number of overseas possessions.
The two most traumatic experiences in the
nation’s history were the Civil War (1861-65), in
which a northern Union of states defeated a seces-
sionist Confederacy of 11 southern slave states,
and the Great Depression of the 1930s, an eco-
nomic downturn during which about a quarter of
the labor force lost its jobs. Buoyed by victories in
World Wars | and H and the end of the Cold War
in 1991, the US remains the world’s most powerful
nation state. Since the end of World War II, the
economy has achieved relatively steady growth,
low unemployment and inflation, and rapid
advances in technology.
Background: All of the following US Pacific
island territories except Midway Atoll constitute
the Pacific Remote Islands National Wildlife
Refuge (NWR) Complex and as such are man-
aged by the Fish and Wildlife Service of the
US Department of the Interior. Midway Atoll
NWR has been included in a Refuge Complex
with the Hawaiian Islands NWR and also des- -
ignated as part of Papahanaumokuakea Marine
National Monument. These remote. refuges are
the most widespread collection of marine-and
terrestrial-life protected areas on the planet
under a single country’s jurisdiction. They sus- .
tain many endemic species including corals, fish,
shellfish, marine mammals, seabirds, water birds,
land birds, insects, and vegetation not found
elsewhere.
Baker Island: The US took possession of the
island in 1857. Its guano deposits were mined by
US and British companies during the second half
of the 19th century. In 1935, a short-lived attempt
at colonization began on this island but was dis-
rupted by World War II and thereafter abandoned.
The island was established as a NWR in 1974.
Howland Island: Discovered by the US early in
the 19th century, the uninhabited atoll was offi-
cially claimed by the US in 1857. Both US and
British companies mined for guano deposits until
about 1890. In 1935, a short-lived attempt at
colonization began on this island, similar to the
effort on nearby Baker Island, but was disrupted
by World War Il and thereafter abandoned. The
famed American aviatrix Amelia EARHART
disappeared while seeking out Howland Island as
a refueling stop during her 1937 round-the-world
flight; Earhart Light, a day béacon‘near the middle
of the west coast, was named in her memory. The
island was established as a NWR in 1974.
Jarvis Island: First discovered by the British in
1821, the uninhabited island was annexed by
the US in 1858 but abandoned in 1879 after tons
of guano had been removed. The UK annexed
the island in 1889 but never carried out plans
774
for further ex ploitation. The US occupied and
reclaimed the island in 1935. It was abandoned in
1942 during World War H. The island was estab-
lished as a NWR in 1974.
Johnston Atoll: Both the US and the Kingdom of
Hawaii annexed Johnston Atoll in 1858, but it was
the US that mined the guano deposits until the late
1880s. Johnston and Sand Islands were designated
wildlife refuges in 1926. The US Navy took over
the atoll in 1934. Subsequently, the US Air Force
assumed control in 1948. The site was used for high-
altitude nuclear tests in the 1950s and 1960s, Until
late in 2000 the atoll was maintained as a storage
and disposal site for chemical weapons. Munitions
destruction, cleanup, and closure of the facility were
completed by May 2005. The Fish and Wildlife Ser-
vice and the US Air Force are currently discussing
future management options; in the interim, John-
ston Atoll and the three-mile Naval Defensive Sea
around it remain under the jurisdiction and admin-
istrative control of the US Air Force.
Kingman Reef: The US annexed the reef in 1922.
Its sheltered lagoon served as a way station for fly-
ing boats on Hawaii-to-American Samoa flights
during the late 1930s. There are no terrestrial
plants on the reef, which is frequently awash, but
it does support abundant and diverse marine fauna
and flora. In 2001, the waters surrounding the reef
out to 12 nm were designated a US NWR.
Midway Islands: The US took formal Possession
of the islands in 1867. The laying of the trans-
Pacific cable, which passed through the islands,
brought the first residents in 1903. Between 1935
and 1947, Midway was used as a refueling stop for
transpacific flights. The US naval victory over a
Japanese fleet off Midway in 1942 was one of the
turning points of World War II. The islands con-
tinued to serve as a naval station until closed in
1993. Today the islands are a NWR and are the
site of the world’s largest Lays an albatross colony.
Palmyra Atoll: The Kingdom of Hawaii claimed
the atoll in 1862, and the US included it among
the Hawaiian Islands when it annexed the archi-
pelago in 1898. The Hawaii Statehood Act of
1959 did not include Palmyra Atoll, which is now
partly privately owned by the Nature Conservancy
with the rest owned by the Federal government
and managed by the US Fish and Wildlife Ser-
vice. These organizations are managing the atoll
as a wildlife refuge. The lagoons and surrounding
waters within the 12 nm US territorial seas were
transferred to the US Fish and Wildlife Service
and designated as a NWR in January 2001.','1446b141177df6a0f2c409fcc76104a6c1b66ab126e88c24ec71c2bf2da5167e','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5e72ddeed1a11f7dd1a615c4ccb09e322b074f7ce555d9b20a51778042b60c31',2025,'ZW','Zimbabwe','introduction',9,'OTHER
2 Taiwan, European Union
DEPENDENCIES AND AREAS OF SPECIAL
SOVEREIGNTY
6 Australia—Ashmore and Cartier Islands, Christmas Island, Cocos
(Keeling) Islands, Coral Sea Islands, Heard Island and McDonald
Islands, Norfolk Island
2 China—Hong Kong, Macau
2 Denmark—Faroe Islands, Greenland
8 France—Clipperton Island, French Polynesia, French Southern
and Antarctic Lands, New Caledonia, Saint Barthelemy, Saint Mar-
tin, Saint Pierre and Miquelon, Wallis and Futuna
3 Netherlands—Aruba, Curacao, Sint Maarten
3 New Zealand—Cook Islands, Niue, Tokelau
3 Norway—Bouvet Island, Jan Mayen, Svalbard
17 UK—Akrotiri, Anguilla, Bermuda, British Indian Ocean Ter-
ritory, British Virgin Islands, Cayman Islands, Dhekelia, Falk-
land Islands, Gibraltar, Guernsey, Jersey, Isle of Man, Montserrat,
xiii
THE CIA WORLD FACTBOOK
Pitcairn Islands, Saint Helena, South Georgia and the South Sand-
wich Islands, Turks and Caicos Islands
14 US—American Samoa, Baker Island*, Guam, Howland Island*,
Jarvis Island*, Johnston Atoll*, Kingman Reef*, Midway Islands*,
Navassa Island, Northern Mariana Islands, Palmyra Atoll*, Puerto
Rico, Virgin Islands, Wake Island (* consolidated in United States
Pacific Island Wildlife Refuges entry)
MISCELLANEOUS
6 Antarctica, Gaza Strip, Paracel Islands, Spratly Islands, West
Bank, Western Sahara i =
OTHER ENTITIES
5 oceans—Arctic Ocean, Atlantic Ocean, Indian Ocean, Pacific
Ocean, Southern Ocean
1 World
267 total
Environment—current issues This entry lists the most
pressing and important environmental problems. The following
terms and abbreviations are used throughout the entry:
Acidification—the lowering of soil and water pH due to acid
precipitation and deposition usually through precipitation; this
process disrupts ecosystem nutrient flows and may kill freshwa-
ter fish and plants dependent on more neutral or.alkaline condi-
tions (see acid rain).
Acid rain—characterized as containing harmful levels of sulfur
dioxide or nitrogen oxide; acid rain is damaging and potentially
deadly to the earth’s fragile ecosystems; acidity is measured using -
the pH scale where 7 is neutral, values greater than 7''are con-
sidered alkaline, and values below 5.6 are considered acid pre-
cipitation; note—a pH of 2.4 (the acidity of vinegar) has been
measured in rainfall in New England.
Aerosol—a collection of airborne particles dispersed in a gas,
smoke, or fog. Afforestation—converting a bare or agricul-
tural space by planting trees and plants; reforestation involves
replanting trees on areas that have been cut or destroyed by
fire.
_ Asbestos—a naturally occurring soft fibrous mineral com-
monly used in fireproofing materials and considered to be highly
carcinogenic in particulate form.
Biodiversity—also biological diversity; the relative number of
species, diverse in form and function, at the genetic, organism,
community, and ecosystem level; loss of biodiversity reduces
an ecosystem’s ability to recover from natural or man-induced
disruption.
Bio-indicators—a ‘plant or animal species whose presence,
abundance, and health reveal the general condition of its
habitat.
Biomass—the total weight or volume of living matter in a
given area or volume.
Carbon cycle—the term used to describe the exchange of
carbon (in various forms, e.g., as carbon dioxide) between
the atmosphere, ocean, terrestrial biosphere, and geological
deposits.
Catchments—assemblages used to capture and retain rainwa-
ter and runoff; an important water management technique in
areas with limited freshwater resources, such as Gibraltar,
DDT (dichloro-diphenyl-trichloro-ethane)—a colorless,
odorless insecticide that has toxic effects on most animals; the
use of DDT was banned in the US in 1972.
Defoliants~—chemicals which cause plants to lose their leaves
artificially; often used in agricultural practices for weed control,
and may have detrimental impacts on human and ecosystem
health.
Deforestation—the destruction of vast areas of forest (e.g.
unsustainable forestry practices, agricultural and range land
clearing, and the over exploitation of wood products for use as
fuel) without planting new growth.
Desertification—the spread of desert-like conditions in arid
or semi-arid areas, due to overgrazing, loss of agriculturally pro-
ductive soils, or climate change. :
Dredging—the practice of deepening an existing waterway;
also, a technique used for collecting bottom-dwelling marine
xiv
organisms (e.g., shellfish) or harvesting coral, often causing sig-
nificant destruction of reef and ocean-floor ecosystems.
Drift-net fishing—done with a net, miles in extent, that
is generally anchored to a boat and left to float with the tide;
often results in an over harvesting and waste of large popula-
tions of non-commercial marine species (by-catch) by its effect
of “sweeping the ocean clean.”
Ecosystems—ecological units comprised of complex commu-
nities of organisms and their specific environments.
Effluents—waste materials, such as smoke, sewage, or indus-
trial waste which are released into the environment, subse-
quently polluting it.
Endangered species—a species that is threatened with
extinction either by direct hunting or habitat destruction.
Freshwater—water with very low soluble mineral content;
sources include lakes, streams, rivers, glaciers, and underground
aquifers.
Greenhouse gas—a gas that “traps” infrared radiation in the
lower atmosphere causing surface warming; water vapor, carbon
dioxide, nitrous oxide, methane, hydrofluorocarbons, and ozone
are the primary greenhouse gases in the Earth’s atmosphere.
Groundwater—water sources found below the surface of the
earth often in naturally occurring reservoirs in permeable rock
strata; the source for wells and natural springs.
Highlands Water Project—a series of dams constructed
jointly by Lesotho and South ‘Africa to redirect Lesotho’s abun-
dant water supply into a rapidly growing area in South Africa;
while it is the largest infrastructure project in southern Africa,
it is also the most costly and controversial; objections to the
project include claims that it forces people from their homes,
submerges farmlands, and squanders economic resources.
Inuit Circumpolar Conference (ICC)—tepresents the
roughly 150,000 Inuits of Alaska, Canada, Greenland, and Rus-
sia in international environmental issues; a General Assembly
convenes every three years to determine the focus of the ICC;
the most current concerns are long-range transport of pollut-
ants, sustainable development, and climate change.
Metallurgical plants—industries which specialize in the sci-
ence, technology, and processing of metals; these plants produce
highly concentrated and toxic wastes which can contribute to
pollution of ground water and air when not properly disposed.
Noxious substances—injurious, very harmful to living
beings.
Overgrazing—the grazing of animals on plant material faster
than it can naturally regrow leading to the permanent loss of
plant cover, a common effect of too many animals grazing lim-
ited range land.
Ozone shield—a layer of the atmosphere composed of ozone
gas (03) that resides approximately 25 miles above the Earth’s
surface and absorbs solar ultraviolet radiation that can be harm-
ful to living organisms.
Poaching—the illegal killing of animals or fish, a great con-
cern with respect''to endangered or threatened species.
Pollution—the contamination of a healthy environment by
man-made waste.
Potable water—water that is drinkable, safe to be consumed.
Salination—the process through which fresh (drinkable) water
becomes salt (undrinkable) water; hence, desalination is the
reverse process; also involves the accumulation of salts in top-
soil caused by evaporation of excessive irrigation water, a process
that can eventually render soil incapable of supporting crops.
Siltation—occurs when water channels and reservoirs become
clotted with silt and mud, a side effect of deforestation and soil
erosion.
Slash-and-burn agriculture—a rotating cultivation tech-
‘nique in which trees are cut down and burned in order to clear
land for temporary agriculture; the land is used until its produc-
tivity declines at which point a new plot is selected and the pro-
cess repeats; this practice is sustainable while population levels
are low and time is permitted for regrowth of natural vegetation;
conversely, where these conditions do not exist, the practice
can have disastrous consequences for the environment.
DEFINITIONS AND NOTES
Soil degradation—damage to the land’s productive capacity
because of poor agricultural practices such as the excessive use of
pesticides or fertilizers, soil compaction from heavy equipment,
or erosion of topsoil, eventually resulting in reduced ability to
produce agricultural products.
Soil erosion—the removal of soil by the action of water or
wind, compounded by poor agricultural practices, deforestation,
overgrazing, and desertification. Ultraviolet (UV) radiation—a
portion of the electromagnetic energy emitted by the sun and
naturally filtered in the upper atmosphere by the ozone layer;
UV radiation can be harmful to living organisms and has been
linked to increasing rates of skin cancer in humans.
Waterborne diseases—those in which bacteria survive in,
and are transmitted through, water; always a serious threat in `
areas with an untreated water supply.
Environment—international agreements This entry
separates country participation in international environmental
agreements into two levels—party to and signed, but not ratified.
Agreements are listed in alphabetical order by the abbreviated form
of the full name.
Environmental agreements This information is presented
in Appendix C: Selected International Environmental
Agreements, which includes the name, abbreviation, date opened
for signature, date entered into force, objective, and parties by cat-
egory.
Ethnic groups This entry provides an ordered listing of ethnic
groups starting with the largest and normally includes the percent
of total population. ae,
Exchange rates This entry provides the average annual price
of a country’s monetary unit for the time period specified, expressed
in units of local currency per US dollar, as determined by interna-
tional market forces or by official fiat. The International Organiza-
tion for Standardization (ISO) 4217 alphabetic currency code for
the national medium of exchange is presented in parenthesis. Clos-
ing daily exchange rates are not presented in The World Factbook,
but are used to convert stock values—e.g., the market value of pub-
licly traded shares—to US dollars as of the specified date.
Executive branch This entry includes several subfields. Chief
of state includes the name and title of the titular leader of the coun-
try who represents the state at official and ceremonial functions but
may not be involved with the day-to-day activities of the govern-
ment. Head of government includes the name and title of the top
administrative leader who is designated to manage the day-to-day
activities of the government. For example, in the UK, the monarch
is the chief of state, and the prime minister is the head of govern-
ment. In the US, the president is both the chief of state and the
head of government. Cabinet includes the official name for this
body of high-ranking advisers and the method for selection of mem-
bers. Elections includes the nature of election process or accession
to power, date of the last election, and date of the next election.
Election results includes the percent of vote for each candidate in
the last election.
Exports This entry provides the total US dollar amount of mer-
chandise exports on an f.o.b. (free on board) basis. These figures are
calculated on an exchange rate basis, i.e., not in purchasing power
parity (PPP) terms.
Exports—commodities This entry provides a listing of the
highest-valued exported products; it sometimes includes the percent
of total dollar value.
Exports—partners This entry provides a rank ordering of
trading partners starting with the most important; it sometimes in-
cludes the percent of total dollar value.
Fiscal year This entry identifies the beginning and ending
months for a country’s accounting period of 12 months, which often
is the calendar year but which may begin in any month. All yearly
references are for the calendar year (CY) unless indicated as a non-
calendar fiscal year (FY).
Flag description. This entry provides á written flag description
produced from actual flags or the best information available at the
time the entry was written. The flags of independent states are used
by their dependencies unless there is an officially recognized local
flag. Some disputed and other areas do not have flags.
Flag graphic Most versions of the Factbook include a color
flag at the beginning of the country profile. The flag graphics were
produced from actual flags or the best information available at the
time of preparation. The flags of independent states are used by their
dependencies unless there is an officially recognized local flag. Some
disputed and other areas do not have flags.
Freshwater withdrawal (domestic/industrial/
agricultural) This entry provides the annual quantity of water
in cubic kilometers removed from available sources for use in any
purpose. Water drawn-off is not necessarily entirely consumed and
some portion may be returned for further use downstream. Domestic
sector use refers to water supplied by public distribution systems.
Note that some of this total may be used for small industrial and/or
limited agricultural purposes. Industrial sector use is the quantity of
water used by self-supplied industries not connected to a public dis-
tribution system. Agricultural sector use includes water used for ir-
rigation and livestock watering, and does not account for agriculture
directly dependent on rainfall. Included are figures for total annual
water withdrawal and per capita water withdrawal.
GDP (official exchange rate) This entry gives the gross
domestic product (GDP) or value of all final goods and services pro-
duced within a nation in a given year. A nation’s GDP at official
exchange rates (OER) is the home-currency-denominated annual
GDP figure divided by the bilateral average US exchange rate with
that country in that year. The measure is simple to compute and
gives a precise measure of the value of output. Many economists
prefer this measure when gauging the economic power an economy
maintains vis-a-vis its neighbors, judging that an exchange rate cap-
tures the purchasing power a nation enjoys in the international mar-
ketplace. Official exchange rates, however, can be artificially fixed
and/or subject to manipulation—resulting in claims of the country
having an under-or over-valued currency—and are not necessarily
the equivalent of a market-determined exchange rate. Moreover,
even if the official exchange rate is market-determined, market
exchange rates are frequently established by a relatively small set
of goods and services (the ones the country trades) and may not
capture the value of the larger set of goods the country produces.
Furthermore, OER-converted GDP is not well suited to comparing
domestic GDP over time, since appreciation/depreciation from one
year to the next will make the OER GDP value rise/fall regardless of
whether home-currency-denominated GDP changed.
GDP (purchasing power parity) This entry gives the
gross domestic product (GDP) or value of all final goods and ser-
vices produced within a nation in a given year. A nation’s GDP
at purchasing power parity (PPP) exchange rates is the sum value
of all goods and services produced in the country valued at prices
prevailing in the United States in the year noted. This is the meas-
ure most economists prefer when looking at per-capita welfare and
when comparing living conditions or use of resources across coun-
tries. The measure is difficult to compute, as a US dollar value has
to be assigned to all goods and services in the country regardless
of whether these goods ‘and services have a direct equivalent in
the United States (for example, the value of an ox-cart or non-US
military equipment); as a result, PPP estimates for some countries
are based on a small and sometimes different set of goods and ser-
vices. In addition, many countries do not formally participate in
the World Bank’s PPP project that calculates these measures, so the
resulting GDP estimates for these countries may lack precision. For
many developing countries, PPP-based GDP measures are multiples
of the official exchange rate (OER) measure. The differences be-
tween the OER-and PPP-denominated GDP values for most of the
wealthy industrialized countries are generally much smaller.
GDP—composition by sector This entry gives the per-
centage contribution of agriculture, industry, and services to total
GDP. Agriculture includes farming, fishing, and forestry. Industry
includes mining, manufacturing, energy production, and construc-
tion. Services cover government activities, communications, trans-
portation, finance, and all other private economic activities that do
XV
THE CIA WORLD FACTBOOK
not produce material goods. The distribution will total less than 100
percent if the data are incomplete.
GDP—per capita (PPP) This entry shows GDP on a pur-
chasing power parity basis divided by population as of 1 July for the
same year.
GDP—real growth rate This entry gives GDP growth on an
annual basis adjusted for inflation and expressed as a percent. The
growth rates are year-over-year, and not compounded.
GDP methodology In the Economy category, GDP dollar
estimates for countries are reported both on an official exchange rate
(OER) and a purchasing power-parity (PPP) basis. Both measures
contain information that is useful to the reader. The PPP method
involves the use of standardized international dollar price weights,
which are applied to the quantities of final goods and services pro-
duced in a given economy. The data derived from the PPP method
probably provide the best available starting point for comparisons of
economic strength and well-being between countries. In contrast,
the currency exchange rate method involves a variety of interna-
tional and domestic financial forces that may not capture the value
of domestic output. Whereas PPP estimates for OECD countries are
quite reliable, PPP estimates for developing countries are often rough
approximations. In developing countries with weak currencies, the
exchange rate estimate of GDP in dollars is typically one-fourth to
one-half the PPP estimate. Most of the GDP estimates for develop-
ing countries are based on extrapolation of PPP numbers published
by the UN International Comparison Program (UNICP) and by
Professors Robert Summers and Alan Heston of the University of
Pennsylvania and their colleagues. GDP derived using the OER
method should be used for the purpose of calculating the share of
items such as exports, imports, military expenditures, external debt,
or the current account balance, because the dollar values presented
in the Factbook for these items have been converted at official ex-
change rates, not at PPP. One should use the OER GDP figure to cal-
culate the proportion of, say, Chinese defense expenditures in GDP,
because that share will be the same as one calculated in local curren-
cy units. Comparison of OER GDP with PPP GDP may also indicate
whether a currency is over-or under-valued. If OER GDP is smaller
than PPP GDP, the official exchange rate may be undervalued, and
vice versa. However, there is no strong historical evidence that mar-
ket exchange rates move in the direction implied by the PPP rate, at
least not in the short-or medium-term. Note: the numbers for GDP
and other economic data should not be chained together from suc-
cessive volumes of the Factbook because of changes in the US dollar
measuring rod, revisions of data by statistical agencies, use of new or
different sources of information, and changes in national statistical
methods and practices.
Geographic coordinates This entry includes rounded lati-
tude and longitude figures for the centroid or center point of a coun-
try expressed in degrees and minutes; it is based on the locations
provided in the Geographic Names Server (GNS), maintained by
the National Geospatial-Intelligence Agency on behalf of the US
Board on Geographic Names.
Geographic names This information is presented in
Appendix F: Cross Reference List of Geographic Names.
It includes a listing of various alternate names, former names, lo-
cal names, and regional names referenced to one or more related
Factbook entries. Spellings are normally, but not always, those ap-
proved by the US Board on Geographic Names (BGN). Alternate
names and additional information are included in parentheses,
Geography This category includes the entries dealing with the
natural environment and the effects of human activity.
Geography—note This entry includes miscellaneous geo-
graphic information of significance not included elsewhere.
Gini index See entry for Distribution of family income—
Gini index
GNP Gross national product (GNP) is the value of all final goods
and services produced within a nation in a given year, plus income
earned by its citizens abroad, minus income earned by foreign-
ers from domestic production. The Factbook, following current
xvi
practice, uses GDP rather than GNP to measure national produc-
tion. However, the user must realize that in certain countries net
remittances from citizens working abroad may be important to na-
tional well-being.
Government This category includes the entries dealing with
the system for the adoption and administration of public policy.
Government—note This entry includes miscellaneous gov-
ernment information of significance not included elsewhere.
Government type This entry gives the basic form of govern-
ment. Definitions of the major governmental terms are as follows.
(Note that for some countries more than one definition applies.):
Absolute monarchy—a form of government where the mon-
arch rules unhindered, i.e., without any laws, constitution, or
legally organized opposition. Anarchy—a condition of lawless-
ness or political disorder brought about by the absence of gov-
ernmental authority.
Authoritarian—a form of government in which state author-
ity is imposed onto many aspects of citizens’ lives. ;
Commonwealth—a nation, state, or other political entity
founded on law and united by a compact of the people for the
common good.
Communist—a system of government in which the state plans
and controls the economy and a single—often authoritarian—
party holds power; state controls are imposed with the elimina-
tion of private ownership of property or capital while claiming
to make progress toward a higher social order in which all goods
are equally shared by the people (i.e., a classless society).
Confederacy (Confederation)—a union by compact or
treaty between states, provinces, or territories, that creates a
central government with limited powers; the constituent enti-
ties retain supreme authority over all matters except those del-
egated to the central government.
Constitutional—a government by or operating under an
authoritative document (constitution) that sets forth the sys-
tem of fundamental laws and principles that determines the
nature, functions, and limits of that government. Constitutional
democracy—a form of government in which the sovereign
power of the people is spelled out in a governing constitution.
Constitutional monarchy—a system of government in
which a monarch is guided by a constitution whereby his/her
rights, duties, and responsibilities are spelled out in written law
or by custom.
Democracy—a form of government in which the supreme
power is retained by the people, but which is usually exercised
indirectly through a system of representation and delegated
authority periodically renewed.
Democratic republic—a state in which the supreme power
rests in the body of citizens entitled','6322989d1bc4cd5bf54f221e0c2323ad4a8be2fe38e74779841535af811f0063','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('891cfbf815844b483e6b7bbe4cd7d135a87a348bd2d2861ee5e4d8d7af0107c4',2025,'ZW','Zimbabwe','introduction',10,'to vote for officers and rep-
resentatives responsible to them. Dictatorship—a form of gov-
ernment in which a ruler or small clique wield absolute power
(not restricted by a constitution or laws),
Ecclesiastical—a government administrated by a church.
Emirate—similar to a monarchy or sultanate, but a govern-
ment in which the supreme power is in the hands of an emir
(the ruler of a Muslim state); the emir may be an absolute over-
lord or a sovereign with constitutionally limited authority.
Federal (Federation)—a form of government in which sover-
eign power is formally divided—usually by means of a constitu-
tion—between a central authority and a number of constitu-
ent regions (states, colonies, or provinces) so that each region
retains some management of its internal affairs; differs from a
confederacy in that the central government exerts influence
directly upon both individuals as well as upon the regional
units. l F ‘
Federal republic—a state in which the powers of the central
government are restricted and in which the component parts
(states, colonies, or provinces) retain a degree of self-govern-
ment; ultimate sovereign power rests with the voters who chose
their governmental representatives.
Islamic republic—a particular form of government adopted
by some Muslim states; although such a state is, in theory, a
DEFINITIONS AND NOTES
theocracy, it remains a republic, but its laws are required to be
compatible with the laws of Islam.
Maoism—the theory and practice of Marxism-Leninism devel-
oped in China by Mao Zedong (Mao Tse-tung), which states
that a continuous revolution is necessary if the leaders of a com-
munist state are to keep in touch with the people. :
Marxism—the political, economic, and social principles
espoused by 19th century economist Karl Marx; he viewed
the struggle of workers as a progression of historical forces that
would proceed from a class struggle of the proletariat (work-
ers) exploited by capitalists (business owners), to a socialist
“dictatorship of the proletariat,” to, finally, a classless soci-
ety—Communism. Marxism-Leninism—an expanded form of
communism developed by Lenin from doctrines of Karl Marx;
Lenin saw imperialism as the final stage of capitalism and
shifted the focus of workers’ struggle from developed to under-
developed countries.
Monarchy—a government in which the supreme power is
lodged in the hands of a monarch who reigns over a state or
territory, usually for life and by hereditary right; the mon-
arch may be either a sole absolute ruler or a sovereign—such
as a king, queen, or prince—with constitutionally limited
authority.
Oligarchy—a government in which control is exercised by a
small group of individuals whose authority generally is based on
wealth or power.
Parliamentary democracy—a political system in which the
legislature
(parliament) selects the government—a prime minister,
premier, or chancellor along with the cabinet ministers—
according to party strength as expressed in elections; by this
system, the government acquires a dual responsibility: to the
people as well as to the parliament.
Parliamentary government (Cabinet-Parliamentary
. government)—a government in which members of an execu-
tive branch (the cabinet and its leader—a prime minister,
premier, or chancellor) are nominated to their positions by a
legislature or parliament, and are directly responsible to it; this
type of government can be dissolved at will by the parliament
(legislature) by means of a no confidence vote or the leader
of the cabinet may dissolve the parliament if it can no longer
function.
Parliamentary monarchy—a state headed by a monarch
who is not actively involved in policy formation or imple-
mentation (i.e., the exercise of sovereign powers by a mon-
arch in a ceremonial capacity); true governmental leadership
is carried out by a cabinet and its head—a prime minister,
premier, or chancellor—who are drawn from a legislature
(parliament).
Presidential—a system of government where the executive
branch exists separately from a legislature (to which it is gener-
ally not accountable).
Republic—a representative democracy in which the people’s
elected deputies (representatives), not the people themselves,
vote on legislation.
Socialism—a government in which the means of planning,
producing, and distributing goods is controlled by a central .
government that theoretically seeks a more just and equitable
distribution of property and labor; in actuality, most socialist
governments have ended up being no more than dictatorships
over workers by a ruling elite.
Sultanate—similar to a monarchy, but a government in which
the supreme power is in the hands of a sultan (the head of a
Muslim state); the sultan may be an absolute ruler or a sovereign
with constitutionally limited authority.
Theocracy—a form of government in which a Deity is recog-
nized as the supreme civil ruler, but the Deity’s laws are inter-
preted by ecclesiastical authorities (bishops, mullals, etc.); a
government subject to religious authority.
Totalitarian—a government that seeks to subordinate the
individual to the state by controlling not only all political and
economic matters, but also the attitudes, values, and beliefs of
its population.
Greenwich Mean Time (GMT) The mean solar time at
the Greenwich Meridian, Greenwich, England, with the hours and
days, since 1925, reckoned from midnight. GMT is now a historical
term having been replaced by UTC on 1 January 1972. See Coor-
dinated Universal Time.
Gross domestic product See GDP
Gross national product See GNP
Gross world product See GWP
GWP This entry gives the gross world product (GWP) or aggre-
gate value of all final goods and services produced worldwide in a
given year.
Health expenditures This entry provides the total expend-
iture on health as a percentage of GDP. Health expenditures are
broadly defined as activities performed either by institutions or
individuals through the application of medical, paramedical, and/or
nursing knowledge and technology, the primary purpose of which is
to promote, restore, or maintain health.’ i
Heliports This entry gives the total number of heliports with
hard-surface runways, helipads, or landing areas that support routine
sustained helicopter operations exclusively and have support facili-
ties including one or more of the following facilities: lighting, fuel,
passenger handling, or maintenance. It include$ former airports used
exclusively for helicopter operations but excludes heliports limited
to day operations and natural clearings that could support helicopter
landings and takeoffs.
HIV/AIDS—adult prevalence rate This entry gives an
estimate of the percentage of adults (aged 15-49) living with HIV/
AIDS. The adult prevalence rate is calculated by dividing the esti-
mated number of adults living with HIV/AIDS at yearend by the
total adult population at yearend.
HIV/AIDS—deaths This entry gives an estimate of the num-
ber of adults and children who died of AIDS during a given calendar
year.
` HIV/AIDS—people living with HIV/AIDS This entry
gives an estimate of all people (adults and children) alive at yearend
with HIV infection, whether or not they have developed symptoms
of AIDS.
Hospital bed densify This entry provides the number of
hospital beds per 1,000 people; it serves as a general measure of
inpatient service availability. Hospital beds include inpatient beds
available in public, private, general, and specialized hospitals ana
renadintation centers, in most cases, Deas ror Dotn acute ana
cnronic care are included. Because the level of inpatient services
required for individual countries depends on several factors—such
as demographic issues and the burden of disease—there is no global
target for the number of hospital beds per country. So, while 2 beds
per 1,000 in one country may be sufficient, 2 beds per 1,000 in an-
other may be woefully inadequate because of the number of people
hospitalized by disease.
Household income or consumption by percent-
age share Data on household income or consumption come
from household surveys, the results adjusted for household size.
Nations use different standards and procedures in collecting and
adjusting the data. Surveys based on income will normally show a
more unequal distribution than surveys based on consumption. The
quality of surveys is improving with time, yet caution is still neces-
sary in making inter-country comparisons.
Hydrographic data codes See Data codes
Illicit drugs This entry gives information on the five catego-
ries of illicit drugs—narcotics, stimulants, depressants (sedatives),
hallucinogens, and cannabis. These categories include many drugs
legally produced and prescribed by doctors as well as those illegally
produced and sold outside of medical channels.
Cannabis (Cannabis sativa) is the common hemp plant,
which provides hallucinogens with some sedative properties,
and includes marijuana (pot, Acapulco gold, grass, reefer), tet-
rahydrocannabinol (THC, Marinol), hashish (hash), and hash-
ish oil (hash oil).
xvii
THE CIA WORLD FACTBOOK
Coca (mostly Erythroxylum coca) is a bush with leaves that
contain the stimulant used to make cocaine. Coca is not to be
confused with cocoa, which comes from cacao seeds and is used
in making chocolate, cocoa, and cocoa butter.
Cocaine is a stimulant derived from the leaves of the coca
bush.
Depressants (sedatives) are drugs that reduce tension and
anxiety and include chloral hydrate, barbiturates (Amytal,
Nembutal, Seconal, phenobarbital), benzodiazepines (Librium,
Valium), methaqualone (Quaalude), glutethimide (Doriden),
and others (Equanil, Placidyl, Valmid).
Drugs are any chemical substances that effect a physical, men-
tal, emotional, or behavioral change in an individual.
Drug abuse is the tise of any licit or illicit chemical substance
that results in physical, mental, emotional, or behavioral
impairment in an individual.
Hallucinogens are drugs that affect sensation, thinking, self-
awareness, and emotion. Hallucinogens include LSD (acid,
microdot), mescaline and peyote (mexc, buttons, cactus),
amphetamine variants (PMA, STP, DOB), phencyclidine (PCP,
angel dust, hog), phencyclidine analogues (PCE, PCPy, TCP),
and others (psilocybin, psilocyn).
Hashish is the resinous exudate of the cannabis or hemp plant
(Cannabis sativa).
Heroin is a semisynthetic derivative of morphine.
Mandrax is a trade name for methaqualone, a pharmaceutical
depressant.
Marijuana is the dried leaf of the cannabis or hemp plant
(Cannabis sativa).
Methaqualone is a pharmaceutical depressant, referred to as
mandrax in Southwest Asia and Africa.
Narcotics are drugs that relieve pain, often induce sleep, and
refer to opium, opium derivatives, and synthetic substitutes.
Natural narcotics include opium (paregoric, parepectolin), mor-
phine (MS-Contin, Roxanol), codeine (Tylenol with codeine,
Empirin with codeine, Robitussin AC), and thebaine. Semi-
synthetic narcotics include heroin (horse, smack), and hydro-
morphone (Dilaudid). Synthetic narcotics include’ meperidine
or Pethidine (Demerol, Mepergan), methadone (Dolophine,
Methadose), and others (Darvon, Lomotil).
Opium is the brown, gummy exudate of the incised, unripe
seedpod of the opium poppy.
Opium poppy (Papaver somniferum) is the source for the
natural and semisynthetic narcotics,
Poppy straw is the entire cut and dried opium poppy-plant
material, other than the seeds.. Opium is extracted from poppy
straw in commercial operations that produce the drug for medi-
cal use.
Qat (kat, khat) is a stimulant from the buds or leaves of Catha
edulis that is chewed or drunk as tea.
Quaaludes is the North American slang term for meth-
aqualone, a pharmaceutical depressant.
Stimulants are drugs that relieve mild depression, increase
energy and activity, and include cocaine (coke, snow, crack),
amphetamines (Desoxyn, Dexedrine), ephedrine, ecstasy
(clarity, essence, doctor, Adam), phenmetrazine (Preludin),
methylphenidate (Ritalin), and others (Cylert, Sanorex,
Tenuate),
Imports This entry provides the total US dollar amount of mer-
chandise imports on a c.i.f. (cost, insurance, and freight) or f.o:b.
(free on board) basis. These figures are calculated on an exchange
rate basis, i.e., not in purchasing power parity (PPP) terms.
Imports—commodities This entry provides a listing of the
highest-valued imported products; it sometimes includes the per-
cent of total dollar value.
Imports—partners This entry provides a rank ordering of
trading partners starting with the most important; it sometimes in-
cludes the percent of total dollar value.
xviii
Independence For most countries, this entry gives the date
that sovereignty was achieved and from which nation, empire, or
trusteeship. For the other countries, the date given may not repre-
sent “independence” in the strict sense, but rather some significant
nationhood event such as the traditional founding date or the date
of unification, federation, confederation, establishment, fundamen-
tal change in the form of government, or state succession. For a
number of countries, the establishment of statehood was a lengthy
evolutionary process occurring over decades or even centuries. In
such cases, several significant dates are cited. Besa areas in-
clude the notation “none” followed by the nature of their depend-
ency status. Also see the Terminology note.
Industrial production growth rate This entry gives the
annual percentage increase in industrial production (includes man-
ufacturing, mining, and construction).
Industries This entry provides a rank ordering of industries start-
ing with the largest by value of annual output.
Infant mortality rate This entry gives the number of deaths
of infants under one year old in a given year per 1,000 live births in
the same year; included is the total death rate, and deaths by sex,
male and female. This rate is often used as an indicator of the level
of health in a country.
Inflation rate (consumer prices) This entry furnishes the
annual percent change in consumer prices compared with the previ-
ous year’s consumer prices.
International disputes sec Disputes—international
International law organization participation This
entry includes information on a country’s acceptance of jurisdic-
tion of the International Court of Justice (ICJ) and of the Inter-
national Criminal Court (ICCt); 55 countries have accepted IC]
jurisdiction with reservations and 11 have accepted IC] jurisdiction
without reservations; 114 countries have accepted ICCt jurisdic-
tion. Appendix B: International Organizations and Groups
explains the differing mandates of the IC] and ICCt.
International organization participation This entry
lists in alphabetical order by abbreviation those international or-
ganizations in which the subject country is a member or participates
in some other way.
International organizations This information is presented
in Appendix B: International Organizations and Groups
which includes the name, abbreviation, date established, aim, and
members by category.
Internet country code This entry includes the two-letter
codes maintained by the International Organization for Standardi-
zation (ISO) in the ISO 3166 Alpha-2 list and used by the Internet
Assigned Numbers Authority (IANA) to establish country-coded
top-level domains (ccTLDs).
Internet hosts This entry lists the number of Internet hosts
available within a country. An Internet host is a computer connect-
ed directly to the Internet; normally an Internet Service Provider''s
(ISP) computer is a host. Internet users may use either a hard-wired
terminal, at an institution with a mainframe computer connected
directly to the Internet, or may connect remotely by way of a mo-
dem via telephone line, cable, or satellite to the Internet Service
Provider’s host computer. The number of hosts is one indicator of
the extent of Internet connectivity.
Internet users This entry gives the number of users within a
country that access the Internet. Statistics vary from country to
country and may include users who access the Internet at least sev-
eral times a week to those who access it only once within a period
of several months.
Introduction This category includes one entry, Background.
Investment (gross fixed) This entry records total business
spending on fixed assets, such as factories, machinery, equipment,
dwellings, and inventories of raw materials, which provide the basis
for future production. It is measured gross of the depreciation of the
assets, i.e., it includes investment that merely replaces worn-out or
scrapped capital.
DEFINITIONS AND NOTES
irrigated land This entry gives the number of square kilom-
eters of land area that is artificially supplied with water.
Judicial branch This entry contains the name(s) of the
highest court(s) and a brief description of the selection process for
members.
Labor force This entry contains the total labor force figure.
Labor force—by occupation This entry lists the percent-
age distribution of the labor force by sector of occupation. Agri-
culture includes farming, fishing, and forestry. Industry includes
mining, manufacturing, energy production, and construction. Ser-
vices cover government activities, communications, transporta-
tion, finance, and all other economic activities that do not produce
material goods. The distribution will total less than 100 percent if
the data are incomplete and may range from 99-101 percent due to
rounding. 2
Land boundaries This entry contains the total length of all
land boundaries and the individual lengths for each of the contigu-
ous border countries. When available, official lengths published by
national statistical agencies are used. Because surveying methods
may differ, country border lengths reported by contiguous countries
may differ.
Land use This entry contains the percentage shares of total land
area for three different types of land use: arable land—land culti-
vated for crops like wheat, maize, and rice that are replanted after
each harvest; permanent crops—land cultivated for crops like cit-
rus, coffee, and rubber that are not replanted after each harvest; in-
cludes land under flowering shrubs, fruit trees, nut trees, and vines,
but excludes land under trees grown for wood or timber; other—
any land not arable or under permanent crops; includes permanent
meadows and pastures, forests and woodlands, built-on areas, roads,
barren land, etc.
Languages This entry provides a rank ordering of languages
starting with the largest and sometimes includes the percent of total
population speaking that language. i
Legal system This entry provides the description of a country’s
legal system. A statement on judicial review of legislative acts is also
included for a number of countries. The legal systems of nearly all
countries are generally modeled upon elements of five main types:
civil law (including French law, the Napoleonic Code, Roman law,
Roman-Dutch law, and Spanish law); common law (including Unit-
ed State law); customary law; mixed or pluralistic law; and religious
law (including Islamic law). An additional type of legal system—
international law, which governs the conduct of independent na-
tions in their relationships with one another—is also addressed
below. The following list describes these legal systems, the countries
or world regions where these systems are enforced, and a brief state-
ment on the origins and major features of each.
Civil Law—The most widespread type of legal system in the
world, applied in various forms in approximately 150 countries.
Also referred to as European continental law, the civil law sys-
tem is derived mainly from the Roman Corpus Juris Civilus,
(Body of Civil Law), a collection of laws and legal interpreta-
tions compiled under the East Roman (Byzantine) Emperor Jus-
tinian I between A.D. 528 and 565. The major feature of civil
law systems is that the laws are organized into systematic written
codes. In civil law the sources recognized as authoritative are
principally legislation—especially codifications in constitutions
or statutes enacted by governments—and secondarily, custom.
The civil law systems in some countries are based on more than
one code.
Common Law—A type of legal system, often synonymous
with “English common law,” which is the system of England
and Wales in the UK, and is also in force in approximately 80
countries formerly part of or influenced by the former British
Empire. English common law reflects Biblical influences as
well as remnants of law systems imposed by early conquerors
including the Romans, Anglo-Saxons, and Normans. Some
legal scholars attribute the formation of the English common
law system to King Henry II (r. 1154-1189). Until the time of
his feign, laws customary among England’s various manorial and
ecclesiastical (church) jurisdictions were administered locally.
Henry II established the king’s court and designated that laws
were “common” to the entire English realm. The foundation of
English common law is “legal precedent”—referred to as stare
decisis, meaning “to stand by things decided.” In the English
common law system, court judges are bound in their decisions in
large part by the rules and other doctrines developed—and sup-
plemented over time—by the judges of earlier English courts.
Customary Law—A type of legal system that serves as the
basis of, or has influenced, the present-day laws in approxi-
mately 40 countries—mostly in Africa, but some in the Pacific
islands, Europe, and the Near East. Customary law is also
referred to as “primitive law,” “unwritten law,” “indigenous law,”
and “folk law.” There is no single history of customary law such
as that found in Roman civil law, English common law, Islamic
law, or the Napoleonic Civil Code. The earliest systems of law
in human society were customary, and usually developed in
small agrarian and hunter-gatherer communities. As the term
implies, customary law is based upon the customs of a com-
munity. Common attributes of customary legal systems are that
they are seldom written down, thev embody an oraanized set
of rules reaulatina social relations, and they are agreed upon by
members of the community. Although such law systems include
sanctions for law infractions, resolution tends to be reconcilia-
tory rather than punitive. A number of African states practiced
customary law many centuries prior to colonial influences. Fol-
lowing colonization, such laws were written down and incorpo-
rated to varying extents into the legal systems imposed by their
colonial powers.
European Union Law—A sub-discipline of international law `
known as “supranational law” in which the rights of sovereign
nations are limited in relation to one another. Also referred to
as the Law of the European Union or Community Law, it is the
unique and complex legal system that operates in tandem with
the laws of the 27 member states of the European Union (EU).
Similar to federal states, the EU legal system ensures compliance
from the member states because of the Union’s decentralized
political nature. The European Court of Justice (ECJ), estab-
lished in 1952 by the Treaty of Paris, has been largely respon-
` sible for the development of EU law. Fundamental principles
of European Union law include: subsidiarity—the notion that
issues be handled by the smallest, lowest, or least centralized
competent authority; proportionality—the EU may only act
to the extent needed to achieve its objectives; conferral—the
EU is a union of member states, and all its authorities are vol-
untarily granted by its members; legal certaint''y—requires that
legal rules be clear and precise; and precautionary principle—
amoral and political principle stating that if an action or policy
might cause severe or irreversible harm to the public or to the
environment, in the absence of a scientific consensus that harm
would not ensue, the burden of proof falls on those who would
advocate taking the action.
French Law—A type of civil law that is the legal sy','d663cf7eea2fa0ad434651f1d6b9757327b2c86cb930e76221a954a71c0bd891','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('879b8d813f414caa454e0b83c5258e9364900836b602ecad461092ef0a02c12e',2025,'ZW','Zimbabwe','introduction',11,'stem
of France. The French system also serves as the basis for, or
is mixed with, other legal systems in approximately 50 coun-
tries, notably in North Africa, the Near East, and the French
territories and dependencies. French law is primarily codified
or systematic written civil law. Prior to the French Revolution
(1789-1799), France had no single national legal system. Laws
in the northern areas of present-day France were mostly local
customs based on privileges and exemptions granted by kings
and feudal lords, while in the southern areas Roman law pre-
dominated. The introduction of the Napoleonic Civil Code
during the reign of Napoleon I in the first decade of the 19th
century brought major reforms to the French legal system, many
of which remain part of France’s current legal structure, though
all have been extensively amended or redrafted to address a
modern nation. French law distinguishes between “public law”
and “private law.” Public law relates to government, the French
Constitution, public administration, and criminal law. Private
law covers issues between private citizens or corporations. The
most recent changes to the French legal system—introduced in
the 1980s—were the decentralization laws, which transferred
xix
THE CIA WORLD FACTBOOK
authority from centrally appointed government representatives
to locally elected representatives of the people.
. International Law—The law of the international commu-
nity, or the body of customary rules and treaty rules accepted as
legally binding by states in their relations with each other. Inter-
national law differs from other legal systems in that it primarily
concerns sovereign political entities. There are three separate
disciplines of international law: public international law, which
governs the relationship between provinces and international
entities and includes treaty law, law of the sea, international
criminal law, and international humanitarian law; private inter-
national law, which addresses legal jurisdiction; and suprana-
tional law—a legal framework wherein countries are bound by
regional agreements in which the laws of the member coun-
tries are held inapplicable when in conflict with supranational
laws. At present the European Union is the only entity under
a supranational legal system. The term “international law” was
coined by Jeremy Bentham in 1780 in his Principles of Mor-
als and Legislation, though laws governing relations between
states have been recognized from very early times (many centu-
ries B.C.). Modern international law developed alongside the
emergence and growth of the European nationstates beginning
_ in the early 16th century. Other factors that influenced the
development of international. law included the revival of legal
studies, the growth of international trade, and the practice of
exchanging emissaries and establishing legations. The sources
of International law are set out in Article 38-1 of the Statute
of the International Court of Justice within the UN Charter.
Islamic Law—The most’ widespread type of religious law, it is
the legal system enforced in over 30 countries, particularly in
the Near East, but also in Central and South Asia, Africa, and
Indonesia. In many countries Islamic law operates in tandem
with a civil law system. Islamic law is embodied in the sharia, an
Arabic word meaning “the right path.” Sharia covers all aspects
of public and private life and organizes them into five categories:
obligatory, recommended, permitted, disliked, and forbidden.
The primary sources of sharia law are the Qur’an, believed by
Muslims to be the word of God revealed to the Prophet Muham-
mad by the angel Gabriel, and the Sunnah, the teachings of the
Prophet and his works. In addition to these two primary sources,
traditional Sunni Muslims recognize the consensus of Muham-
mad’s companions and Islamic jurists on certain issues, called
ijmas, and various forms of reasoning, including analogy by legal
scholars, referred to as qiyas. Shia Muslims reject ijmas and qiyas
as sources of sharia law.
Mixed Law—Also referred to as pluralistic law, mixed law
consists of elements of some or all of the other main types of
legal systems—civil, common, customary, and religious. The
mixed legal systems of a number of countries came about when
colonial powers overlaid their own legal systems upon colonized
regions but retained elements of the colonies’ existing legal
systems.
Napoleonic Civil Code—A type of civil law, referred to
as the Civil Code or Code Civil des Frangais, forms part of
the legal system of France, and underpins the legal systems of
Bolivia, Egypt, Lebanon, Poland, and the US state of Louisiana.
The Civil Code was established under Napoleon J, enacted in
1804, and officially designated the Code Napoleon in 1807.
This legal system combined the Teutonic civil law tradition of
the northern provinces of France with the Roman law tradition
of the southern and eastern regions of the country. The Civil
Code bears similarities in its arrangement to the Roman Body
of Civil Law (see Civil Law above). As enacted in 1804, the
Code addressed personal status, property, and the acquisition of
property. Codes added over the following six years included civil
procedures, commercial law, criminal law and procedures, and
a penal code.
Religious Law—A legal system which stems from the sacred
texts of religious traditions and in most cases professes to cover
all aspects of life as a seamless part of devotional obligations
to a transcendent, imminent, or deep philosophical reality.
Implied as the basis of religious law is the concept of unalterabil-
ity, because the word of God cannot be amended or legislated
against by judges or governments. However, a detailed legal
system generally requires human elaboration. The main types
of religious law are sharia in Islam, halakha in Judaism, and
canon law in some Christian groups. Sharia is the most wide-
spread religious legal system (see Islamic Law), and is the sole
system of law for countries including Iran, the Maldives, and
Saudi Arabia. No country is fully governed by halakha, but Jew-
ish people may decide to settle disputes through Jewish courts
and be bound by their rulings. Canon law is not a divine law as
such because it is not found in revelation. It is viewed instead
as human law inspired by the word of God and applying the
demands of that revelation to the actual situation of the church.
Canon law regulates the internal ordering of the Roman Catho-
lic Church, the Eastern Orthodox Church, and the Anglican
Communion. ` i
Roman Law—A type of civil law developed in ancient Rome
and practiced from the time of the city’s founding (traditionally
753 B.C.) until the fall of the Western Empire in the 5th cen-
tury A.D. Roman law remained the legal system of the Byzan-
tine (Eastern Empire) until the fall of Constantinople in 1453.
Preserved fragments of the first legal text, known as the Law of
the Twelve Tables, dating from the 5th century B.C., contained
specific provisions designed to change the prevailing customary
law. Early Roman law was drawn from custom and statutes; later,
during the time of the empire, emperors asserted their author-
ity as the ultimate source of law. The basis for Roman laws was
the idea that the exact form—not the intention—of words or
of actions produced legal consequences. It was only in the late
6th century A.D. that a comprehensive Roman code of laws was
published (see Civil Law above). Roman law served as the basis
of law systems developed in a number of continental European
countries.
Roman-Dutch Law—A type of civil law based on Roman
law as applied in the Netherlands. Roman-Dutch law serves as
the basis for legal systems in seven African countries, as well
as Guyana, Indonesia, and Sri Lanka. This law system, which
originated in the province of Holland and expanded through-
out the Netherlands (to be replaced by the French Civil Code
in 1809), was instituted in a number of sub-Saharan African
countries during the Dutch colonial period. The Dutch jurist/
philosopher Hugo Grotius was the first to attempt to reduce
Roman-Dutch civil law into a system in his Jurisprudence of
. Holland (written 1619-20, commentary published 1621). The
Dutch historian/lawyer Simon van Leeuwen coined the term
“Roman-Dutch law” in 1652.
Spanish Law—A type of civil law, often referred to as the
Spanish Civil Code, it is the present legal system of Spain and is
the basis of legal systems in 12 countries mostly in Central and
South America, but also in southwestern Europe, northern and
western Africa, and southeastern Asia. The Spanish Civil Code
reflects a complex mixture of customary, Roman, Napoleonic,
local, and modern codified law. The laws of the Visigoth invad-
ers of Spain in the 5th to 7th centuries had the earliest major
influence on Spanish legal system development. The Christian
Reconquest of Spain in the 11th through 15th centuries wit-
nessed the development of customary law, which combined
canon (religious) and Roman law. During several centuries of
Hapsburg and Bourbon, rule, systematic recompilations of the
existing national legal system were attempted, but these often
conflicted with local and regional customary civil laws. Legal
system development for most of the 19th century concentrated
on formulating a national civil law system, which was finally
enacted in 1889 as the Spanish Civil Code. Several sections of
the code have been revised, the most recent of which are the
penal code in 1989 and the judiciary code in 2001. The Spanish
Civil Code separates public and private law. Public law includes
constitutional law, administrative law, criminal law, process law,
financial and tax law, and international public law. Private law
includes civil law, commercial law, labor law, and international
private law.
United States Law—A type of common law, which is the
basis of the legal system of the United States and that of its
island possessions in the Caribbean and the Pacific. This legal
system has several layers, more possi-
bly than in most other countries, and
is due in part to the division between
federal and state law. The United States
was founded not as one nation but as
a union of 13 colonies, each claiming
independeénce from the British Crown.
The US Constitution, implemented in
1789, began shifting power away from
the states and toward the federal gov-
ernment, though the states today retain
substantial legal authority. US law draws
its authority from four sources: consti-
tutional law, statutory law, admin-
istrative regulations, and case law.
Constitutfonal law is based on the US
Constitution and serves as the supreme
federal law. Taken together with those
of the state constitutions, these docu-
ments outline the general structure of
the federal and state governments and
provide the rules and limits of power.
US statutory law is legislation enacted
by the US Congress and is codified in
the United States Code. The 50 state
legislatures have similar authority to
enact state statutes. Administrative law
is the authority delegated to federal and
state executive agencies. Case law, also
referred to as common law, covers areas
where constitutional or statutory law
is lacking. Case law is a collection of
judicial decisions, customs, and general
principles that began in England centu-
ries ago, that were adopted in America
at the time of the Revolution, and that
continue to develop today.
Legislative branch This entrv con-
tains information on the structure (uni-
cameral, bicameral, tricameral), formal
name, number of seats, and term of office.
Elections includes the nature of the elec-
tion process or accession to power, date of
the last election, and date of the next elec-
tion. Election results includes the percent
of vote and/or number of seats held by each
party in the last election.
Life expectancy at birth This entry
contains the average number of years to be
lived by a group of people born in the same
year, if mortality at each age remains con-
stant in the future. The entry includes total
population as well as the male and female
components. Life expectancy at birth is also
a measure of overall quality of life in a coun-
try and summarizes the mortality at all ages.
It can also be thought of as indicating the
potential return on investment in human
capital and is necessary for the calculation
of various actuarial measures.
Literacy This entry includes a defini-
tion of literacy and Census Bureau percent-
ages for the total population, males, and
females. There are no universal definitions
and standards of literacy. Unless otherwise
specified, all rates are based on the most
corffmon definition—the ability to read
and write at a specified age. Detailing the
standards that individual countries use to
assess the ability to read and write is beyond
the scope of the Factbook. Information
on literacy, while not a perfect measure of
DEFINITIONS AND NOTES
educational results, is probably the most
easily available and valid for international
comparisons. Low levels of literacy, and ed-
ucation in general, can impede the econom-
ic development of a country in the current
rapidly changing, technology-driven world.
Location This entry identifies the coun-
try’s regional location, neighboring coun-
tries, and adjacent bodies of water.
Major cities—population This en-
try provides the population of the capital
and up to four major cities defined as urban
agglomerations with populations of at least
750,000 people. An urban agglomeration
is defined as comprising the city or town
proper and also the suburban fringe or
thickly settled territory lying outside of, but
adjacent to, the boundaries of the city. For
smaller countries, lacking urban centers of
750,000 or more, only the population of the
capital is presented.
Major infectious diseases This
entry lists major infectious diseases likely
to be encountered in countries where the
tisk of such diseases is assessed to be very
high as compared to the United States.
These infectious diseases represent risks to
US government personnel traveling to the
specified country for a period of less than
three years. The degree of risk is assessed
by considering the foreign nature of these
infectious diseases, their severity, and the
probability of being affected by the diseases
present. The diseases listed do not necessar-
ily represent the total disease burden expe-
rienced by the local population. The risk to
an individual traveler varies considerably by
the specific location, visit duration, type of
activities, type of accommodations, time of
year, and other factors. Consultation with a
travel medicine physician is needed to eval-
uate individual risk and recommend appro-
priate preventive measures such as vaccines.
Diseases are organized into the following
six exposure categories shown in italics and
listed in typical descending order of risk.
Note: The sequence of exposure categories
listed in individual country entries may vary
according to local conditions.
food or waterborne diseases acquired
through eating or drinking on the local
Location
Geographic coordinates
Map references
water
Area—comparative
Land boundaries
total
border countries
Coastline Maritime claims
territorial sea
contiguous zone
exclusive economic zone
continental shelf
exclusive fishing zone
Climate
Terrain
Elevation extremes
lowest point
highest point
Natural resources
Land use
arable land
permanent crops
other
Irrigated land
Total renewable water resources
Freshwater withdrawal (domestic/
industrial/agricultural)
total
per capita
Natural hazards
volcanism
Environment—current issues
Environment—international agreements
party to
signed, but not ratified
Geography—note
Background: The UK annexed Southern Rhode-
sia from the [British] South Africa Company in
1923. A 1961 constitution was formulated that
favored whites in power. In 1965 the govern-
ment unilaterally déclared its independence, but
the UK did not recognize the act and demanded
more complete voting rights for the black African
majority in the country (then called Rhodesia).
UN sanctions and a guerrilla uprising finally led to
free elections in 1979 and independence (as Zim-
babwe) in 1980. Robert MUGABE, the nation’s
first prime minister, has been the country’s only
tuler (as president since 1987) and has dominated
the country’s political system since independence.
His chaotic Jand redistribution campaign, which
began in 2000, caused an exodus of white farmers,
crippled the economy, and ushered in widespread
shortages of basic commodities. Ignoring interna-
tional condemnation, MUGABE rigged the 2002
presidential election to ensure his reelection. In
April 2005, the capital city of Harare embarked
on Operation Restore Order, ostensibly an urban
rationalization program, which resulted in the
destruction of the homes or businesses of 700,000
mostly poor supporters of the opposition. President
MUGABE in June 2007 instituted price controls
on all basic commodities causing panic buy-
ing and leaving store shelves empty for months.
General elections held in March 2008 contained
irregularities but still amounted to a censure of the
ZANU-PF-led government with the opposition
winning a majority of seats in parliament. MDC
opposition leader Morgan TSVANGIRAI won
the most votes in the presidential polls, but not
enough to win outright. In the lead up to a run-off
election in late June 2008, considerable violence
enacted against opposition party members led to
the withdrawal of TSVANGIRAI from the ballot.
Extensive evidence of violence and intimidation
resulted in international condemnation of the pro-
cess. Difficult negotiations over a power-sharing
government, in which MUGABE remained presi-
dent and TSVANGIRAI became prime minister,
were finally settled in February 2009, although the
leaders failed to agree upon many key outstanding
governmental issues. MUGABE since 2010 has
called for early elections—his term does not expire
until June 2013—but no election has been held.','533a3245c20e91fe56b55c87b40a8365d02c51811ce187ca40aab0aed780f55b','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8eb690b74b34a285ab24f21436013e354232ca18331aae2e01e036e072d39885',2025,'AF','Afghanistan','introduction',23,'Background: Ahmad Shah DURRANI unified
the Pashtun tribes and founded Afghanistan in
1747. The county served as a buffer between the
British and Russian Empires until it won inde-
pendence from notional British control in 1919.
A brief experiment in democracy ended in a 1973
coup and a 1978 Communist counter-coup. The
Soviet Union invaded in 1979 to support the tot-
tering Afghan Communist regime, touching off a
long and destructive war. The USSR withdrew in
1989 under relentless pressure by internationally
supported anti-Communist mujahedin rebels. A
series of subsequent civil wars saw Kabul finally fall
in 1996 to the Taliban, a hardline Pakistani-spon-
sored movement that emerged in 1994 to end the
country’s civil war and anarchy. Following the 11
September 2001 terrorist attacks, a US, Allied, and
anti-Taliban Northern Alliance military action
toppled the Taliban for sheltering Osama BIN
LADIN. The UN-sponsored Bonn Conference in
2001 established a process for political reconstruc-
tion that included the adoption of a new constitu-
tion, a presidential élection in 2004, and National
Assembly elections in 2005. In December 2004,
Hamid KARZAI became the first democratically
elected president of Afghanistan and the National
Assembly was inaugurated the following Decem-
ber. KARZAI was re-elected in August 2009 for a
second term. Despite gains toward building a stable
central government, a resurgent Taliban and con-
tinuing provincial instability—particularly in the
south and the east—remain serious challenges for
the Afghan Government.','8bf1a1c2f7b1280d6a41118ee675f85e66e21fc66b428f22bd46c87e07e37754','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('02f346a976137a4a35a56e666d8eec291698eaa4640cb2abdc00e093e5e2024d',2025,'CY','Cyprus','introduction',32,'Background: By terms of the 1960 Treaty of Estab-
lishment that created the independent Republic of
Cyprus, the UK retained full sovereignty and juris-
diction over two areas of almost 254 square kilom-
eters—Akrotiri and Dhekelia. The southernmost
and smallest of these is the Akrotiri Sovereign
Base Area, which is also referred to as the Western
Sovereign Base Area.','53b46709c0f08e8126b89d766452b1e12ff1c37f0b5ec67a20b9f979942cb8af','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7cd73ebb9af95c850b814229eae4880761b76783281a018f441d14b9989cceb3',2025,'AL','Albania','introduction',39,'Background: Albania declared its independence
from the Ottoman Empire in 1912, but was con-
quered by Italy in 1939. Communist partisans took
over the country in 1944. Albania allied itself first
with the USSR (until 1960), and then with China
(to 1978). In the early 1990s, Albania ended 46
years of xenophobic Communist rule and estab-
lished a multiparty democracy. The transition has
proven challenging as successive governments have
tried to deal with high unemployment, widespread
corruption, dilapidated infrastructure, powerful
organized crime networks, and combative political
opponents. Albania has made progress in its demo-
cratic development since first holding multiparty
elections in 1991, but deficiencies remain. Interna-
tional observers judged elections to be largely free
and fair since the restoration of political stability
following the collapse of pyramid schemes in 1997;
how ever, each of Albania’s post-Communist elec-
tions have been marred by claims of electoral fraud.
The 2009 general elections resulted in a coalition
government, the first such in the country’s his-
tory. Albania joined NATO in April 2009 and is
a potential candidate for EU accession. Although
Albania’s economy continues to grow, the country
is still one of the poorest in Europe, hampered by a
large informal economy and an inadequate energy
and transportation infrastructure.
Background: After more than a century of rule
by France, Algerians fought through much of the
1950s to achieve independence in 1962. Algeria’s
primary political party, the National Liberation
Front (FLN), was established in 1954 as part of the
struggle for independence and has largely domi-
nated politics since. The Government of Algeria
in 1988 instituted a multi-party system in response
to public unrest, but the surprising first round suc-
cess of the Islamic Salvation Front (FIS) in the
December 1991 balloting led the Algerian army to
intervene and postpone the second round of elec-
tions to prevent what the secular elite feared would
be an extremist-led government ftom assuming
power. The army began a crackdown on the FIS
that spurred FIS supporters to begin attacking gov-
ernment targets. Fighting escalated into an insur-
gency, which saw intense violence from 1992-98,
resulting in over 100,000 deaths—many attributed
to indiscriminate massacres of villagers by extrem-
ists. The government gained the upper hand by the
late-1990s, and FIS’s armed wing, the Islamic Sal-
vation Amny, disbanded in January 2000. Abdelaziz
BOUTEEFLIKA, with the backing of the military,
won the presidency in 1999 in an election widely
viewed as fraudulent. He was reelected to a second
term in 2004 and overwhelmingly won a third term
in 2009, after the government amended the consti-
tution in 2008 to remove presidential term limits.
Longstanding problems continue to face BOUTE-
FLIKA, including large-scale unemployment, a
shortage of housing, unreliable electrical and water
supplies, government inefficiencies and corruption,
and the continuing activities of extremist militants.
The Salafist Group for Preaching and Combat
(GSPC) in 2006 merged with al-Qa’ida to form al-
Qa’ida in the Lands of the Islamic Maghreb, which
has launched an ongoing series of kidnappings and
bombings targeting the Algerian Government and
Westem interests. The government in 2011 intro-
duced some political reforms in response to the
Arab Spring, including lifting the 19-year-old state
of emergency restrictions and increasing women’s
quotas for elected assemblies. Parliamentary elec-
tions in May 2012°and municipal and provincial
elections in November 2012 saw continued domi-
nance by the FLN, with Islamist opposition parties
performing poorly. Political protest activity in the
country remained low in 2012, but small, some-
times violent socioeconomic demonstrations by
disparate groups continued to be a common occur-
rence. Parliament in 2013 is expected to revise the
constitution.','0b57f7e4441af6fef4ac9d8aa25b3bed31d2c56e7e1b0183401cb3078dabe060','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f2b7ebde56d91abbda44b7095da18a810306e8ae814c09c6c76e94fdbaf0a3b7',2025,'AS','American Samoa','introduction',56,'Background: Settled as early as 1000 B.C., Samoa
was not reached by European explorers until the
18th century. International rivalries in the latter
half of the 19th century were settled by an 1899
treaty in which Germany and the US divided the
Samoan archipelago. The US formally occupied
12
its portion—a smaller group of eastern islands with
the excellent harbor of Pago Pago—the following
year.','11448516b0ff7ce7efc98c6b48811c059c97415f83d9b26eb59a31da9ff28cc9','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f04380dc7259b8e377b6401192714a66e7c59ddbe6244ad3ec7761b4fcd5f9ce',2025,'AD','Andorra','introduction',68,'Background: The landlocked Principality of
Andorra is one of the smallest states in Europe,
nestled high in the Pyrenees Mountains between
the French and Spanish borders. For 715 years,
from 1278 to 1993, Andorrans lived under a
unique co-principality, ruled by French and
Spanish leaders (from 1607 onward, the French
chief of state and the Spanish bishop of Seu
d''Urgell). In 1993, this feudal system was modi-
fied, with the titular heads of state retained,
but the government transformed into a parlia-
mentary democracy. In the late 20th century,
Andorra became a popular tourist destination.
An estimated 10 million people visit each year
drawn by the winter sports, summer climate,
and duty free goods. Andorra has also become
a wealthy center
because of its banking facilities, low taxes, and
lack of customs duties. How ever, recent eco-
nomic hardships have required Andorra to start
taxing foreign investments and to implement
intemational commercial
stricter economic policies. Andorra is not a
member of the European Union, but enjoys a
special relationship with it and uses the Euro as
its national currency. i
Background: Angola is still rebuilding its country
since the end of a 27-year civil war in 2002. Fight-
ing berween the Popular Movement for the Lib-
eration of Angola (MPLA), led by Jose Eduardo
DOS SANTOS, and the National Union for the
Total Independence of Angola (UNITA), led by
Jonas SAVIMBI, followed independence from
Portugal in 1975. Peace seemed imminent in 1992
when Angola held national elections, but fight-
ing picked up again in 1993. Up to 1.5 million
lives may have been lost—and 4 million people
displaced—during the more than a quarter cen-
tury of fighting. SAVIMBI’s death in 2002 ended
'' UNITA’ insurgency and cemented the MPLA’s
0.68 (2008 est.)
Fiscal year: calendar year
Electricity—production: 91.24 million kWh
(2011)
country comparison to the world: 198
Electricity—consumption: 562.4 million kWh
(2012)
country comparison to the world: 167
Electricity—exports: 1 million kWh (2011)
country comparison to the world: 87
Electricity—imports: 587 million kWh (2011)
country comparison to the world: 74','230c1fe2122e17fbff2c55fa1a3890724bc2d38aef604a44e046e9bac4099783','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('54bb79651923ef4e3eb57a031dcb2e8f1e19a55026d77b00355d9a03978e971d',2025,'AO','Angola','introduction',81,'Background: Colonized by English settlers from
Saint Kitts in 1650, Anguilla was administered
by Great Britain until the early 19th century,
when the island—against the wishes of the
inhabitants—w as incorporated into a single Brit-
ish dependency along with Saint Kitts and Nevis.
Several attempts at separation failed. In 1971, two
years after a revolt, Anguilla was finally allowed
to secede; this arrangement was formally recog-
nized in 1980, with Anguilla becoming a separate
British dependency.
Background: South Africa occupied the German
colony of South-West Africa during World War I
and administered it as a mandate until after World
War II, when it annexed the territory. In 1966 the
Marxist South-West Africa People’s Organization
(SWAPO) guerrilla group launched a war of inde-
pendence for the area that became Namibia, but
it was not until 1988 that South Africa agreed to
end its administration in accordance with a UN
peace plan for the entire region. Namibia has
been governed by SWAPO since the country won
independence in 1990. Hifikepunye POHAMBA
was elected president in November 2004 in a
landslide victory replacing Sam NUJOMA who
led the country during its first 14 years of self rule.
POHAMBA was reelected in November 2009.','c53b9e46719f20db53d584a16f5d9e4d59ae387bc777326d123a747233c1bfee','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1ec2f8b1506b08b7af60a884cfaed8977bc5507f9432ef3981a6ca667828eb7a',2025,'AQ','Antarctica','introduction',92,'Background: Speculation over the existence of a
“southem land” was not confirmed until the early
1820s when British and American commercial
operators and British and Russian national expe-
ditions began exploring the Antarctic- Peninsula
region and other areas south of the Antarctic Cir-
cle. Nort until 1840 was it established that Antarc-
tica was indeed a continent and not just a group
of islands or an area of ocean. Several exploration
“firsts” were achieved in the early 20th century, but
generally the area saw little human activity. Follow-
ing World War II, however, the continent experi-
enced an upsurge in scientific research. A number
of countries have set up a range of year-round and
seasonal stations, camps, and refuges to support
scientific research in Antarctica. Seven have made
territorial claims, but not all countries recognize
these claims. In order to form a legal framew ork
for the activities of nations on the continent, an
Antarctic Treaty was negotiated that neither denies
nor gives recognition to existing territorial claims;
signed in 1959, it entered into force in 1961.','7dd9952354e1598e60ab02ee9374ed285d8fd3dcfd8259bf068a100bd862b0fe','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1b11c693c18963c436f3f48171c285d7c3163bb6ef527800b3f0c06a0bae2c33',2025,'AG','Antigua and Barbuda','introduction',100,'Background: The Siboney were the first people
to inhabit the islands of Antigua and Barbuda
in 2400 B.C., but Arawak Indians populated the
islands when COLUMBUS landed on his second
voyage in 1493. Early Spanish and French settle-
ments were succeeded by an English colony in
1667. Slavery, established to run the sugar plan-
tations on Antigua, was abolished in 1834. The
islands became an independent state within the
British Commonwealth of Nations in 1981.
Background: The Arctic Ocean is the small-
est of the world’s five oceans (after the Pacific
Ocean, Atlantic Ocean, Indian Ocean, and
the recently delimited Southern Ocean). The
Northwest Passage (US and Canada) and
Northern Sea Route (Norway and Russia) are
two important seasonal waterways. In recent
years the polar ice pack has thinned allowing
for increased navigation and raising the pos-
sibility of future sovereignty and shipping dis-
putes among countries bordering the Arctic
Ocean.
Background: In 1816, the United Provinces of
the Rio Plata declared their independence from
Spain. After Bolivia, Paraguay, and Uruguay
went their separate ways, the area that remained
became Argentina. The country’s population and
culture were heavily shaped by immigrants from
throughout Europe, with Italy and Spain provid-
ing the largest percentage of new comers from
1860 to 1930. Up until about the mid-20th cen-
tury, much of Argentina’s history was dominated
by periods of internal political conflict between
Federalists and Unitarians and between civilian
and military factions. After World War II, an era
of Peronist populism and direct and indirect mili-
tary interference in subsequent governments was
follow ed by a military junta that took pow er in
1976. Democracy returned in 1983 after a failed
28
bid to seize the Falkland Islands (Islas Malvinas)
by force, and has persisted despite numerous chal-
lenges, the most formidable of which was a severe
economic crisis in 2001-02 that led to violent
public protests and the successive resignations of
several presidents. In January 2013, Argentina
assumed a nonpermanent seat on the UN Security
Council for the 2013-14 term.','49e4a4d0ff72bf5bf631018cad088ba1112feea5bece34fe693c6a9d5ba2ffa6','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5d78f750f9311bd906c940359536420777d3254e2ff32cd2952ae8065b84c9e8',2025,'AR','Argentina','introduction',118,'Background: Armenia prides itself on being the
first nation to formally adopt Christianity (early
4th century). Despite periods of autonomy, over
the centuries Armenia came under the sway of
various empires including the Roman, Byzantine,
Arab, Persian, and Ottoman. During World War I
in the western portion of Armenia, Ottoman Tur-
key instituted a policy of forced resettlement cou-
pled with other harsh practices that resulted in at
least 1 million Armenian deaths. The eastern area
of Armenia was ceded by the Ottomans to Russia
in 1828; this portion declared its independence in
1918, but was conquered by the Soviet Red Army
in 1920. Armenian leaders remain preoccupied by
the long conflict with Azerbaijan over Nagorno-
Karabakh, a primarily Armenian-populated region,
assigned to Soviet Azerbaijan in the 1920s by Mos-
cow. Armenia and Azerbaijan began fighting over
the area in 1988; the struggle escalated after both
countries attained independence from the Soviet
Union in 1991. By May 1994, when a cease-fire
took hold, ethnic Armenian forces held not only
Nagorno-Karabakh but also a significant portion
of Azerbaijan proper. The economies of both sides
have been hurt by their inability to make substan-
tial progress tow ard a peaceful resolution. Tur-
key closed the common border with Armenia in
1993 in support of Azerbaijan in its conflict with
Armenia over control of Nagorno-Karabakh and
surrounding areas, further hampering Armenian
economic growth. In 2009, senior Armenian lead-
ers began pursuing rapprochement with Turkey,
aiming to secure an opening of the border, but Tur-
key has not yet ratified the Protocols normalizing
relations between the two countries.
Background: Prior to the arrival of the Span-
ish in the 16th century, the Inca ruled northern
Chile while the Mapuche inhabited central and
southern Chile. Although Chile declared its
independence in 1810, decisive victory over the
Spanish was not achieved until 1818. In the War
of the Pacific (187983), Chile defeated Peru and
Bolivia and won its present northern regions. It
was not until the 1880s that the Mapuche were
brought under central government control. After
a series of elected governments, the three-year-
old Marxist government of Salvador ALLENDE
was overthrown in 1973 by a military coup led
by Augusto PINOCHET, who ruled until a freely
elected president was inaugurated in 1990. Sound
148
economic policies, maintained consistently since
the 1980s, have contributed to steady growth,
reduced poverty rates by over half, and have
helped secure the country’s commitment to demo-
cratic and representative government. Chile has
increasingly assumed regional and international
leadership roles befitting its status as a stable,
democratic nation.','1d64b8c68edfc7dee8ed32606f2a67993e02c68e9010989d93025064de9d3cdc','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2a8ea3693b32a7ff823767d7041c90fd5f6e803f716b3350a170bb40f5301471',2025,'AW','Aruba','introduction',126,'Background: Discovered and claimed for Spain in
1499, Aruba was acquired by the Dutch in 1636.
The island’s economy has been dominated by three
main industries. A 19th century gold rush was fol-
lowed by prosperity brought on by the opening
in 1924 of an oil refinery. The last decades of the
20th century saw a boom in the tourism industry.
Aruba seceded from the Netherlands Antilles in
1986 and became a separate, autonomous member
of the Kingdom of the Netherlands. Movement
tow ard full independence was halted at Aruba’s
request in 1990.
Background: These uninhabited islands came
under Australian authority in 1931; formal admin-
istration began two years later. Ashmore Reef sup-
ports a rich and diverse avian and marine habitat;
in 1983, it became a National Nature Reserve.
Cartier Island, a former bombing range, became a
marine reserve in 2000,
Location: Southeastern Asia, islands in the Indian
Ocean, midway between northwestern Australia
and Timor island
Geographic coordinates: 12 14 S, 123 05 E
Map references: Oceania
Area: total: 5 sq km
country comparison to the world: 247
land: 5 sq km water: 0 sq km
note: includes Ashmore Reef (West, Middle, and
East Islets) and Cartier Island
Area—comporotive: about eight times the size of
The Mall in Washington, DC
Land boundaries: 0 km
Coastline: 74.1 km
Maritime claims: territorial sea: 12 nm
contiguous zone: 12 nm
exclusive fishing zone: 200 nm
continental shelf: 200 m depth or to the depth of
exploitation
Climate: tropical
Terrain: low with sand and coral
Elevation extremes: lowest point: Indian Ocean
Om
highest point: unnamed location 3 m
Natural resources: fish
Land use: arable land: 0%
permanent crops: 0%
other: 100% (all grass and sand) (2011)
Natural hazards: surrounded by shoals and reefs
that can pose maritime hazards
Environment—current issues: illegal killing
of protected ‘wildlife by traditional Indonesian
fisherman, as well as fishing by non-traditional
Indonesian vessels, are ongoing problems
Geography—note: Ashmore Reef National
Nature Reserve established in August 1983;
Cartier Island Marine Reserve established in 2000
Background: The Atlantic Ocean is the second
largest of the world’s five oceans (after the Pacific
Ocean, but larger than the Indian Ocean, South-
em Ocean, and Arctic Ocean). The Kiel Canal
(Germany), Oresund (Denmark-Sweden), Bospo-
rus (Turkey), Strait of Gibraltar (Morocco-Spain),
and the Saint Law rence Seaway (Canada-US) are
important strategic access waterways. The decision
by the International Hydrographic Organization
in the spring of 2000 to delimit a fifth world ocean,
the Southern Ocean, removed the portion of the
Atlantic Ocean south of 60 degrees south latitude.','d4f912f8621b069308fb73c407b58bbddb4fa3f83b8969bb63d3eb452414f95f','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9c1d377f81dd8afe3ba535ab1b76d5619d0fd49c98ccab920d1691b48bb53f98',2025,'AU','Australia','introduction',136,'Background: Prehistoric settlers arrived on ‘the
continent from Southeast Asia at least 40,000 years
before the first Europeans began exploration in the
17th century. No formal territorial claims were
made until 1770, when Capt. James COOK took
possession of the east coast in the name of Great
Britain (all of Australia was claimed as British ter-
ritory in 1829 with the creation of the colony of
Western Australia). Six colonies were created in
the late 18th and 19th centuries; they federated
and became the Commonwealth of Australia in
1901. The new country took advantage of its
natural resources to rapidly develop agricultural
and manufacturing industries and to make a major
contribution to the Allied effort in World Wars I
and II. In recent decades, Australia has become
an internationally competitive, advanced market
economy due in large part to economic reforms
adopted in the 1980s and its location in one of
the fastest growing regions of the world economy.
Long-term concerns include aging of the popula-
tion, pressure on infrastructure, and environmental
issues such as floods, droughts, and bushfires. Aus-
tralia is the driest inhabited continent on earth,
making it particularly vulnerable to the challenges
of climate change. Australia is home to 10 per cent
of the world’s biodiversity, and a great number of its
flora and fauna exist now here else in the world. In
January 2013, Australia assumed a nonpermanent
seat on the UN Security Council for the 2013-14
term.
Background: Scattered over more than three-
quarters of a million square kilometers of ocean;
the Coral Sea Islands were declared a territory of
Australia in 1969. They are uninhabited except
for a small meteorological staff on the Willis Islets.
Automated weather stations, beacons, and a light-
house occupy many other islands and reefs. The
Coral Sea Islands Act 1969 was amended in 1997
to extend the boundaries of the Coral Sea Islands
Territory around Elizabeth and Middleton Reefs.
Background: Under US administration as part of
the UN Trust Territory of the Pacific, the people
of the Northern Mariana Islands decided in the
1970s not to seek independence but instead to
forge closer links with the US. Negotiations for
territorial status began in 1972. A covenant to
establish a commonw ealth in politicab union with
the US was approved in 1975, and came into force
on 24 March 1976. A new government and consti-
tution went into effect in 1978.','d062b6e3630ebaeee819fe0a3ea1a2392bcdb3e8aa6a738a5cabfbdd8c57f3bd','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f986b1732408a8aaa23284c79e40d81cdc6cefaa9a411cd8d072ebc460b3ed29',2025,'AT','Austria','introduction',146,'Background: Once the center of pow er for the
large Austro-Hungarian Empire, Austria was
reduced to a small republic after its defeat in World
War I. Following annexation by Nazi Germany in
1938 and subsequent occupation by the victorious
Allies in 1945, Austria’s status remained unclear
for a decade. A State Treaty signed in 1955 ended
the occupation, recognized Austria''s independ-
ence, and forbade unification with Germany. A
constitutional law that same year declared the
country’s “perpetual neutrality” as a condition for
Soviet military withdraw al. The Soviet Union’s
collapse in 1991 and Austria’s entry into the Euro-
pean Union in 1995 have altered the meaning of
this neutrality. A prosperous, democratic country,
Austria entered the EU Economic and Monetary
Union in 1999.
Background: At the close of World War I, the
Czechs and Slovaks of the former Austro-Hun-
garian Empire merged to form Czechoslovakia.
During the interw ar years, having rejected a
federal system, the new country’s predominantly
Czech leaders were frequently preoccupied with
meeting the increasingly strident demands of
other ethnic minorities within the republic,
most notably the Slovaks, the Sudeten Germans,
and the Ruthenians (Ukrainians). On the eve
of World War II, Nazi Germany occupied the
Czech part of the country and Slovakia became
an independent state allied with Germany. After
the war, a reunited but truncated Czechoslovakia
194
(less Ruthenia) fell within the Soviet sphere of
influence. In 1968, an invasion by Warsaw Pact
troops ended the efforts of the country’s leaders
to liberalize Communist rule and create “social-
ism with a human face,” ushering in a period
of repression known as “normalization.” The
peaceful “Velvet Revolution” swept the Com-
munist Party from power at the end of 1989 and
inaugurated a return to democratic rule and a
market economy. On 1 January 1993, the coun-
try underw ent a nonviolent “velvet divorce”
into its two national components, the Czech
Republic and Slovakia. The Czech Republic
joined NATO in 1999 and the European Union
in 2004.
Background: . The Swiss Confederation was
founded in 1291 as a defensive alliance among
three cantons. In succeeding years, other locali-
ties joined the original three. The Swiss Confed-
eration secured its independence from the Holy
Roman Empire in 1499. A constitution of 1848,
subsequently modified in 1874, replaced the con-
federation with a centralized federal government.
Switzerland’s sovereignty and neutrality have long
been honored by the major European powers, and
the country was not involved in either of the two
world wars. The political and economic integra-
tion of Europe over the past half century, as well as
Switzerland’s role in many UN and international
organizations, has strengthened Switzerland’s ties
with its neighbors. However, the country did not
officially become a UN member until 2002. Swit-
zerland remains active in many UN and interna-
tional organizations but retains a strong commit-
ment to neutrality.
GFOGRAPHY
Location: Central Europe, east of France, north
of Italy
Geographic coordinates: 47 00 N, 8 00 E
Map references: Europe
Area: total: 41,277 sq km
country comparison to the world: 136
land: 39,997 sq km
water: 1,280 sq km
Area—comporative: slightly less than twice the
size of New Jersey
Land boundaries: total: 1,852 km
border countries: Austria 164 km, France 573
km, Italy 740 km, Liechtenstein 41 km, Germany
334 km
. Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
Climate: temperate, but varies with altitude; cold,
cloudy, rainy/snowy winters; cool to warm, cloudy,
humid summers with occasional showers
Terrain: mostly mountains (Alps in south, Jura in
northwest) with a central plateau of rolling hills,
plains, and large lakes `
Elevation extremes: lowest point: Lake Maggiore
195 m
highest point: Dufourspitze 4,634 m
Natural resources: hydropower potential, timber,
salt
Land use: arable land: 9.8%
permanent crops: 0.57%
other: 89.63% (2011)
Irrigated land: 550 sq kma2007)
Total renewable water resources: 53.5 cu km (2011)
Freshwater withdrawal (domestic/industrial/
agricultural): total:2.61 cu km/yr (39%/58%/3%)
per capita: 360.3 cu m/yr (2010)
Natural hazards: avalanches, landslides; flash
floods
Environment—current Issues: air pollution from
vehicle emissions and open-air buming; acid rain;
water pollution from increased use of agricultural
fertilizers; loss of biodiversity
-Environment—intemational agreements: party
to: Air Pollution, Air Pollution-Nitrogen Oxides,
Air Pollution-Persistent Organic Pollutants, Air Pol-
lution-Sulfur 85, Air Pollution-Sulfur 94, Air Pollu-
tion- Volatile Organic Compounds, Antarctic Treaty,
Biodiversity, Climate Change, Climate Change-
Kyoto Protocol, Desertification, Endangered Species,
Environmental Modification, Hazardous Wastes,
Marine Dumping, Marine Life Conservation, Ozone
Layer Protection, Ship Pollution, Tropical Timber
83, Tropical Timber 94, Wetlands, Whaling
signed, but not ratified: Law of the Sea
Geography—note: landlocked; crossroads of
northern and southern Europe; along with south-
eastern France, northern Italy, and southwestem
Austria, has the highest elevations in the Alps','8add4ec3c087602869db5aee106ecb5dd2056e83710cee53061d9c81653e01a3','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('07c156a03beea6a6af695a2163c5188f49cae2aa20a14eb42eee7dfc6ed54045',2025,'AZ','Azerbaijan','introduction',156,'Background: Azerbaijan—a nation with a
majority-Turkic and majority-Shia Muslim popu-
lation—was briefly independent (from 1918
to 1920) following the collapse of the Russian
Empire; it was subsequently incorporated into
the Soviet Union for seven decades. Azerbaijan
has yet to resolve its conflict with Armenia over
Nagomo-Karabakh, a primarily Armenian-popu-
lated region that Moscow recognized in 1923 as
an autonomous region within Soviet Azerbaijan
after Armenia and Azerbaijan disputed the status
of the territory. Armenia and Azerbaijan began
fighting over the area in 1988; the struggle esca-
lated after both countries attained independence
from the Soviet Union in 1991. By May 1994,
when a cease-fire took hold, ethnic Armenian
forces held not only Nagorno-Karabakh but also
seven surrounding provinces in the territory of
Azerbaijan. The OSCE Minsk Group, co-chaired
by the United States, France, and Russia, is the
framework established to mediate a peaceful reso-
lution of the conflict. Corruption in the coun-
try is widespread, and the government, which
eliminated presidential term limits in a 2009
referendum, has been accused of authoritarian-
ism. Although the poverty rate has been reduced
and infrastructure investment has increased sub-
stantially in recent years due to revenue from oil
and gas production, reforms have not adequately
addressed weaknesses in most government insti-
tutions, particularly in the education and health
sectors. In January 2012, Azerbaijan assumed a
nonpermanent seat on the UN Security Council
for the 2012-13 term.
Location: Southwestern Asia, bordering the Cas-
pian Sea, between Iran and Russia, with a small
European portion north of the Caucasus range
Geographic coordinates: 40 30 N, 47 30 E
Map references: Middle East
Area: total: 86,600 sq km
country comparison to the world: 113
land: 82,629 sq km
water; 3,971 sq km
note: includes the exclave of Naxcivan Autono-
mous Republic and the, Nagorno-Karabakh
region; the region’s autonomy was abolished by
Azerbaijani Supreme Soviet on 26 November
1991
Area—comparative: slightly smaller than Maine
Land boundaries: total: 2,013 km
border countries: Armenia (with Azerbaijan-
proper) 566 km, Armenia (with Azerbaijan-
Naxcivan exclave) 221 km, Georgia 322 km,
Iran (with Azerbaijan-proper) 432 km, Iran (with
Azerbaijan-Naxcivan exclave) 179 km, Russia 284
km, Turkey 9 km
Coastline: 0 km (landlocked); note—Azerbaijan
borders the Caspian Sea (713 km)
Maritime claims: none (landlocked)
Climate: dry, semiarid steppe
Terrain: large, flat Kur-Araz Ovaligi (Kura-Araks
Low land, much of it below sea level) with Great
Caucasus Mountains to the north, Qarabag Yaylasi
(Karabakh Upland) in west; Baku lies on Abseron
Yasaqligi (Apsheron Peninsula) that juts into Cas-
pian Sea
Elevation extremes: lowest point: Caspian Sea
-28m
highest point: Bazarduru Dagi 4,485 m
Natural resources: petroleum, natural gas, iron
ore, nonferrous metals, bauxite
Land use: arable land: 21.78%
permanent crops: 2.62%
other: 75.6% (2011)
Irrigated land: 14,250 sq km (2010)
Total renewable water resources: 34.68 cu km
(2011)
Freshwater withdrawal (domestic/indus-
triaVagricultural); total: 12.21 cu km/yr
(4%/18%/78%)
per capita: 1,384 cu m/yr (2010)
Natural hazards: droughts
Environment—current issues: local scientists
consider the Abseron Yasaqligi (Apsheron Pen-
insula) (including Baku and Sumgayit) and the
Caspian Sea to be the ecologically most devas-
tated area in the world because of severe air, soil,
and water pollution; soil pollution results from
oil spills, from the use of DDT pesticide, and
from toxic defoliants used in the production of
cotton
Environment—international agreements: party
to: Air Pollution, Biodiversity, Climate Change,
Climate Change-Kyoto Protocol, Desertification,
Endangered Species, Hazardous Wastes, Marine `
Dumping, Ozone Layer Protection, Ship Pollution,
Wetlands
signed, but not ratified: none of the selected
agreements
Geography—note: both the main area of the
country and the Naxcivan exclave are landlocked
Background; Lucayan Indians inhabited the
islands when Christopher COLUMBUS first set
foot in the New World on San Salvador in 1492.
British sertlement of the islands began in 1647; the
islands became a colony in 1783. Since attaining
independence from the UK in 1973, The Baha-
mas has prospered through tourism, international
banking, and investment management. Because
of its geography, the country is a major transship-
ment point for illegal drugs, particularly shipments
to the US and Europe, and its territory is used for
smuggling illegal migrants into the US.','6914ef6f1e282aab72b33ba1a8f68a2fbf67030a57f90fe3933ac2121eaeb60e','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9b5f34b36c53347c21df80cfc8a8c9fb2a0996d776727dc9ed304b648dd8efa3',2025,'BH','Bahrain','introduction',167,'Background: In 1783, the Sunni Al-Khalifa fam-
ily captured Bahrain from the Persians. In order
to secure these holdings, it entered into a series of
treaties with the UK during the 19th century thet
made Bahrain a British protectorate. The archi-
pelago attained its independence in 1971. Facing
declining oil reserves, Bahrain has tumed to petro-
leum processing and refining and has become an
international banking center. Bahrain’s small size
and central location among Persian Gulf countries
require it to play a delicate balancing act in foreign
affairs among its larger neighbors. The Sunni-led
government has struggled to manage relations with
its large Shia-majority population. In early 2011,
amid Arab uprisings elsewhere in the region, the
Bahraini Government confronted similar protests
at home with police and military action. The after-
math led to modest reforms, though continued dis-
satisfaction by Bahraini oppositionists with the
extent of the reforms, has led to a broader dialogue
between government officials, political societies,
and legislators.','7f4ecb878bb28c31e11de05b35c9df4a417fe68d75fbeb740ccf5d22f2e8e370','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4136b3807367e4214aa7990af37111772affeb2d3726c00e9d7b50b1ad380eca',2025,'BD','Bangladesh','introduction',175,'Background: Muslim conversions and settlement
in the region now referred to as Bangladesh began
in the 10th century, primarily from Arab and Per-
sian traders and preachers. Europeans began to set
up trading posts in the area in the 16th century.
Eventually the area known as Bengal, primarily
Hindu in the western section and mostly Muslim
in the eastern half, became part of British India.
Partition in 1947 resulted in an eastern wing of
Pakistan in the Muslim-majority area, which
became East Pakistan. Calls for greater autonomy
and animosity between the eastern and western
wings of Pakistan led to a Bengali independence
movement. That movement, led by the Awami
League (AL) and supported by India, won inde-
pendence for Bangladesh in 1971, although at
least 300,000 civilians died in the process. The
post-independence, AL government faced daunt-
ing challenges and in 1975 was overthrown by the
military, triggering a series of military coups that
resulted in a military-backed government and
subsequent creation of the Bangladesh National-
ist Party (BNP). That government also ended in
a coup in 1981, followed by military-backed rule
until democratic elections in 1991. The BNP and
AL have altemately held power since then, with
the exception of a military-backed, emergency
caretaker regime that suspended parliamentary
elections planned for January 2007 in an effort
to reform the political system and root out cor-
ruption. That government returned the coun-
try to fully democratic rule in December 2008
with the election of the AL and Prime Minister
Sheikh HASINA. With the help of international
development assistance, Bangladesh has made
great progress in food security since independence,
and the economy has grown at an average of about
6 percent over the last two decades.','e2b41030ba73a5a3e0e86370a600f00fd3f01cc9f3297a5917e7627000a4aaf1','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f43bb929ae5fad0a92d0b756f88b79b80499fe02f0a93ad55772f09c965632cb',2025,'BB','Barbados','introduction',185,'Background: The island was uninhabited when
first settled by the British in 1627. African slaves
worked the sugar plantations established on the
island until 1834 when slavery was abolished. The
economy remained heavily dependent on sugar,
rum, and molasses production through most of the
20th century. The gradual introduction of social
and political reforms in the 1940s and 1950s led
to complete independence from the UK in 1966,
In the 1990s, tourism and manufacturing surpassed
the sugar industry in economic importance.','193c9b2e68ec15c4ffa887fff8907001d2a780d49542cbea1c8d0081433418a8','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('76e52c12e8dfde2f2d6714f3a13d7c3d3d021c663e38867a504948dbe9c714e4',2025,'BY','Belarus','introduction',195,'Background: After seven decades as a constituent
republic of the USSR, Belarus attained its inde-
pendence in 1991. It has retained closer political
and economic ties to Russia than any of the other
former Soviet republics. Belarus and Russia signed
a treaty on a two-state union on 8 December 1999
envisioning greater political and economic inte-
gration. Although Belarus agreed to a framework
to carry out the accord, serious implementation
has yet to take place. Since his election in July
1994 as the country’s first president, Aleksandr
LUKASHENKO has steadily: consolidated his
power through authoritarian means, Government
restrictions on fréedom of speech and the press,
peaceful assembly, and religion remain in place. *','6150786f097885e09f155b9effae7e79a9628c668ff6c9682917a0f0256c9072','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c64e65dced3704f0b5adfe97f071a3c9457fdd430d6bf63d9bd5bbe65bb808dd',2025,'FR','France','introduction',205,'Background: Belgium became independent from
the Netherlands in 1830; it was occupied by Ger-
many during World Wars I and II. The country
prospered in the past half century as a modern,
technologically advanced European state and
member of NATO and the EU. Tensions between
the Dutch-speaking Flemings of the north and the
French-speaking Walloons of the south have led in
recent years to constitutional amendments grant-
ing these regions formal recognition and autonomy.
. Its capital, Brussels, is home to numerous intema-
tional organizations including the EU and NATO.
Background: Thete are 27 coral islands in the group.
Captain William KEELING discovered the islands in
1609, but they remained uninhabited until the 19th
century. From the 1820s to 1978, members of the
CLUNIE-ROSS family controlled the islands and
the copra produced from local coconuts. Annexed by
158
Background: Fiji became independent in 1970
after nearly a century as a British colony. Demo-
cratic rule was interrupted by two military coups
in 1987 caused by concern over a government
perceived as dominated by the Indian community
(descendants of contract laborers brought to the
islands by the British in the 19th century). The
coups and a 1990 constitution that cemented
native Melanesian control of Fiji led to heavy
Indian emigration; the population loss resulted
in economic difficulties, but ensured that Mela-
nesians became the majority. A new constitution
enacted in 1997 was more equitable. Free and
peaceful elections in 1999 resulted in a govern-
ment led by an Indo-Fijian, but a civilian-led
248
coup in May 2000 ushered in a prolonged period
of political turmoil. Parliamentary elections held
in August 2001 provided Fiji with a democrati-
cally elected government led by Prime Minister
Laisenia QARASE. Re-elected in May 2006,
QARASE was ousted in a December 2006 mili-
tary coup led by Commodore Voreqe BAINIMA-
RAMA, who initially appointed himself acting
president but in January 2007 became interim
prime minister. Since taking power BAINIMA-
RAMA has neutralized his opponents, crippled
Fiji’s democratic institutions, and initially refused
to hold elections. In 2012, he promised to hold
elections in 2014.
Location: Oceania,- island group in the South
Pacific Ocean, about two-thirds of the way from
Hawaii to New Zealand
Geographic coordinates: 18 00 S, 175 00 E
Map references: Oceania
Area: total: 18,274 sq km
country comparison to the world: 157
land: 18,274 sq km
water: 0 sq km
Area—comparative: slightly smaller than New
Background: In February 2007, the Iles Eparses
became an integral part of the French Southern and
Antarctic Lands (TAAF). The Southern Lands are
now divided into five administrative districts, two
of which are archipelagos, Iles Crozet and Iles Ker-
guelen; the third is a district composed of two vol-
canic islands, Ile Saint-Paul and Ile Amsterdam;
the fourth, Iles Eparses, consists of five scattered
tropical islands around Madagascar. They contain
no permanent inhabitants and are visited only by
researchers studying the native fauna, scientists at
the various scientific stations, fishermen, and mili-
tary personnel. The fifth district is the Antarctic
portion, which consists of “Adelie Land,” a thin
slice of the Antarctic continent discovered and
claimed by the French in 1840.
Ile Amsterdam: Discovered but not named in
1522 by the Spanish, the island subsequently
received the appellation of Nieuw Amsterdam
from a Dutchman; it was claimed by France in
1843. A short-lived attempt at cattle farming
began in 1871. A French meteorological station
established on the island in 1949 is still in use.
Ile Saint Paul: Claimed by France since 1893, the
island was a fishing industry center from 1843 to
1914. In 1928, a spiny lobster cannery was estab-
lished, but when the company went bankrupt in
1931, seven workers were ‘abandoned. Only two .
survived until 1934 when rescue finally arrived.
Iles Crozet: A large archipelago formed from the
Crozet Plateau, Iles Crozet is divided into two
main groups: L’Occidental (the West), which
includes Ile aux Cochons, Hots des Apotres, Ile
des Pingouins, and the reefs Brisants de THeroine;
and UOriental (the East), which includes Ile d”Est
and Ile de la Possession (the largest island of the
Crozets). Discovered and claimed by France in
1772, the istands were used for seal hunting and
as a base for whaling. Originally administered as
a dependency of Madagascar, they became part of
the TA AF in 1955.
Iles Kerguelen: This island group, discovered in
1772, is: made up of one large island (Ile Kergue-
len) and about 300 smaller islands. A permanent
group of 50 to 100 scientists resides at the main
base at Port-aux-Francais.
Adelie Land: The only non-insular district of the
TAAF is the Antarctic claim known as “Adelie
Land.” The US Government does not recognize it
as a French dependency.
Bassas da India: A French possession since 1897,
this atoll is a volcanic rock surrounded by reefs and
is awash at high tide.
Europa Island: This heavily wooded island has
been a French possession since 1897; it is the site
of a small military garrison that staffs a weather
station.
Glorioso Islands: A French possession since 1892,
the Glorioso Islands are composed of two lushly
vegetated coral islands (lle Glorieuse and Ile du
Lys) and three rock islets. A military garrison oper-
ates a weather and radio station on Ile Glorieuse.
Juan de Nowa Island: Named after a famous 15th
century Spanish navigator and explorer, the island
has been a French possession since 1897. It has
been exploited for its guano and phosphate. Pres-
ently a small military garrison oversees a meteoro-
logical station.
Tromelin Island: First explored by the French in
1776, the island came under the jurisdiction of
Reunion in 1814. At present, it serves as a sea tur-
tle sanctuary and is the site of an important mete-
orological station.
Location: southeast and east of Africa, islands in
the southern Indian Ocean, some near Madagas-
car and others about equidistant between Africa,
Antarctica, and Australia; note—French South-
ern and Antarctic Lands include Ile Amsterdam,
Ile Saint-Paul, Iles Crozet, Iles Kerguelen, Bassas
da India, Europa Island, Glorioso Islands, Juan de
Nova Island, and Tromelin Island in the southern
Indian Ocean, along with the French-claimed sec-
tor of Antarctica, “Adelie Land”; the US does not
recognize the French claim to “Adelie Land”
Geographic coordinates: Ile Amsterdam (Ile
Amsterdam et Ile Saint-Paul): 37 50 S, 77 32 E
Tle Saint-Paul (Mle Amsterdam et Ile Saint-
Paul): 38 72 S, 77 53 E
Iles Crozet: 46 25 S, 51 00 E
Iles Kerguelen: 49 15 S, 69 35 E
Bassas da India (Iles Eparses): 21 30 S, 39 50 E
Europa Island (Iles Eparses): 22 20 S, 40 22 E
Glorioso Islands (Iles Eparses): 11 30 S, 47 20 E
Juande Nova Island (Iles Eparses): 17 03 S, 42 45 E
Tromelin Island (Iles Eparses): 15 52 S, 54 25 E
Map references: Antarctic Region
Area: Ile Am sterdam (Ile Am sterdam et Ile
Saint-Paul): total—55 sq km; land—55 sq km;
water—0 sq km
country comparison to the world: 230 Ile Saint-
Paul (Ile Am sterdam et Ile Saint-Paul): total—?
sq km; land—7 sq km; water—0O sq km
Iles Crozet: total—352 sq km; land—352 sq km;
water—0O sq km Hes Kerguelen: total—7,215 sq
km; land—7,215 sq km; water—O sq km
4
Bassas da India (Iles Eparses): total—80 sq km;
land—0.2 sq km; water—79.8 sq km (lagoon)
Europa Island (Iles Eparses): total—28 sq km;
land—28 sq km; water—O sq km
Glorioso Islands (Iles Eparses): total—5 sq km;
land—5 sq km; water—O sq km
Juan de Nova Island (Iles Eparses): total—4.4 sq
km; land—4.4 sq km; water—O sq km
Trom elin Island (Iles Eparses): total—1 sq km;
land—1 sq km; water—O sq km
note: excludes “Adelie Land” claim of about
500,000 sq km in Antarctica that is not recognized
by the US
Area—comparative: Ile Amsterdam (Ile Amster-
dam et Ile Saint-Paul): less than one-half the size
of Washington, DC `
lle Saint-Paul (lle Amsterdam et Ile Saint-
Paul): more than 10 times the size of The Mall in
Washington, DC
Iles Crozet: about twice the size of Washington,
DC Iles Kerguelen: slightly larger than Delaw are
Bassas da India (Iles Eparses): land area about
one-third the size of The Mall in Washington, DC
Europa Island (Iles Eparses): about one-sixth
the size of Washington, DC Glorioso Islands (Iles
Eparses): about eight times the size of The Mall in
Washington, DC Juan de Nova Island (Iles Eparses):
about seven times the size of The Mall in Washing-
ton, DC Tromelin Island (Iles Eparses): about 1.7
times the size of The Mall in Washington, DC
Land boundaries: 0 km
Coastline: Ile Am sterdam (Ile Am sterdam
et Tle Saint-Paul): 28 km Ile Saint-Paul (Ile Am
sterdamet Ile Saint-Paul): Iles Kerguelen: 2,800
km Bassas da India (Iles Eparses): 35.2 km Europa
Island (Ilés Eparses): 22.2 km Glorioso Islands (Iles
Eparses): 35.2 km Juan de Nova Island (Iles Eparses):
24.1 km Tromelin Island (Iles Eparses): 3.7 km
Maritime claims: territorial sea: 12 nm
exclusive economic zone: 200 nm from Iles Ker-
guelen and Iles Eparses (does not include the rest
of French Southern and Antarctic Lands); Juan
de Nova Island and Tromelin Island claim a con-
tinental shelf of 200-m depth or to the depth of
exploitation
Climate: [le Am sterdam et Ile Saint-Paul: oce-
anic with persistent westerly winds and high
humidity
Iles Crozet: windy, cold, wet, and cloudy
lles Kerguelen: oceanic, cold, overcast, windy
Iles Eparses: tropical
Terrain: Ile Am sterdam (Ile Am sterdam et Ile
Saint-Paul): a volcanic island with steep coastal
cliffs; the center floor of the volcano is a large
plateau
Ile Saint-Paul (Ile ‘Amsterdam et He Saint-
Paul): triangular in shape, the island is the top of a
volcano, rocky with steep cliffs on the eastern side;
has active thermal springslles Crozet: a large archi-
pelago formed from the Crozet Plateau is divided
into two groups of islands
Iles Kerguelen: the interior of the large island of
lle Kerguelen is composed of rugged terrain of high
mountains, hills, valleys, and plains with a num-
ber of peninsulas stretching off its coasts Bassas da
India (Iles Eparses): atoll, awash at high tide; shal-
low (15 m) lagoon Europa Island, Glorioso Islands,
Juan de Nova Island: low, flat, and sandy Tromelin
Island (Iles Eparses): low, flat, sandy; likely vol-
canic seamount
FRENCH SOUTHERN AND ANTARCTIC LANDS
Elevation extremes: lowest point: Indian Ocean
Om
highest point: Mont de la Dives on lle Amsterdam
(Ile Amsterdamet lle Saint-Paul) 867 m; unnamed
location on Ile Saint-Paul (lle Amsterdamet Ile
Saint-Paul) 272 m; Pic Marion-Dufresne in Iles
Crozet 1,090 m; Mont Ross in Iles Kerguelen 1,850
m; unnamed location on Bassas de India (Iles
Eparses) 2.4 m; unnamed location on Europa Island
(Iles Eparses) 24 m; unnamed location on Glorioso
Islands (Iles Eparses) 12 m; unnamed location on
Juan de Nova Island (Iles Eparses) 10 m; unnamed
location on Tromelin Island (lles Eparses) 7 m
Natural resources: fish, crayfish
note: Glorioso Islands and Tromelin Island (Iles
Eparses) have guano, phosphates, and coconuts
Land use: Ile Amsterdam (Ile Amsterdam et
Ile Saint-Paul) —100% ` trees, grasses, ferns,
and moss; Ile Saint-Paul (Ile Amsterdam et Ile
Saint-Paul)—100% grass, ferns, and moss; Iles
Crozet-—100% tossock grass, heath, and fern; Iles
Kerguelen—100% tossock grass and Kerguelen
cabbage; Bassas da India (Iles Eparses)—100%
rock, coral reef, and sand; Europa Island (Iles
Eparses)—100% mangrove swamp and dry wood-
lands; Glorioso Islands (Iles Eparses)—100% lush
vegetation and coconut palms; Juan de Nova
Island (Iles Eparses)—90% forest, 10% other;
Tromelin Island (Iles Eparses)\\—100% grasses and
scattered brush (2011)
Irrigated land: 0 sq km (2011)
Natural hazards: Ile Amsterdam and Ile Saint-
Paul are inactive volcanoes; Iles Eparses subject
to periodic cyclones; Bassas da India is a maritime
hazard since it is under water for a period of three
hours prior to and following the high tide and sur-
rounded by reefs
volcanism: Reunion Island—Piton de la Four-
naise (elev. 2,632 m,), which has erupted many
times in recent years including 2010, is one of the
world’s most active volcanoes; although rare, erup-
tions outside the volcano’s caldera could threaten
nearby cities
Environment—current issues: introduction of
foreign species on Iles Crozet has caused severe
damage to the original ecosystem; overfishing of
Patagonian toothfish around Iles Crozet and Iles
Kerguelen
Geography—note: islands component is widely
scattered across remote locations in the southern
Indian Ocean
Bas sas da India (Iles Eparses): the atoll is a cir-
cular reef that sits atop a long-extinct, submerged
volcano
Europa Island and Juan de Nova Island (Iles
Eparses): wildlife sanctuary for seabirds and sea
turtles
Glorioso Island (Iles Eparses): the islands and
rocks are surrounded by an extensive reef system
Tromelin Island (Iles Eparses): climatologically
important location for forecasting cyclones in the
western Indian Ocean; wildlife sanctuary (sea-
birds, tortoises)
Background: Saint Helena is a British Overseas
Territory consisting of Saint Helena and Ascen-
sion Islands, and the island group of Tristan da
Cunha.
Saint Helena: Uninhabited when first discov-
ered by the Portuguese in 1502, Skint Helena
was garrisoned by the British during the 17th
century. It acquired fame as the place of Napo-
leon BONAPARTE’: exile from 1815 until his
death in 1821, but its importance as a port
of call declined after the opening of the Suez
Canal in 1869. During the Anglo-Boer War in
610
South Africa, several thousand Boer prisoners
were confined on the island between 1900 and
1903.
Ascension Island: This barren and uninhabited
island was discovered and named by the Portu-
guese in 1503. The British garrisoned the island
in 1815 to prevent a rescue of Napoleon from
Saint Helena. It served as a provisioning station
for the Royal Navy’s West Africa Squadron on
anti-slavery patrol. The island remained under
Admiralty control until 1922, when it became
a dependency of Saint Helena. During World
War II, the UK permitted the US to construct
an airfield on Ascension in support of trans-
atlantic flights to Africa and anti-submarine
operations in the South Atlantic. In the 1960s
the island became an important space tracking
station for the US. In 1982, Ascension was an
essential staging area for British forces during
the Falklands War. It remains a critical refueling
point in the air-bridge from the UK to the South
Atlantic.
Tristan da Cunha: The island group consists of
the islands of Tristan da Cunha, Nightingale,
Inaccessible, and Gough. Tristan da Cunha is
named after its Portuguese discoverer (1506);
it was garrisoned by the British in 1816 to pre-
vent any attempt to rescue Napoleon from Saint
Helena. Gough and Inaccessible Islands have
been designated World Heritage Sites. South
Africa leases a site for a meteorological station
on Gough Island.
Background: From the early 16th century through
1917, the area now known as the West Bank fell
under Ottoman rule. Following World War I, the
Allied powers (France, UK, Russia) allocated the
area to the British Mandate of Palestine. After
World War II, the UN passed a resolution to
establish two states within the Mandate, and des-
ignated a territory including what is now known
as the West Bank as part of the proposed Arab
state. Following the 1948 Arab-Israeli War the
area was captured by Transjordan (later renamed
Jordan). Jordan annexed the West Bank in 1950,
In June 1967, Israel captured the West Bank and
East Jerusalem during the 1967 Six-Day War.
With the exception of East Jerusalem and the
former Israeli-Jordanian border zone, the West
Bank has remained: under Israeli military control.
Under a series of agreements signed between 1994
and 1999, Israel transferred to the Palestinian
Authority (PA) security and civilian responsibility
for many Palestinian-populated areas of the West
Bank as well as the Gaza Strip. Negotiations to
determine the permanent status of the West Bank
and Gaza Strip stalled after the outbreak of an inti-
fada in mid-2000. In early 2003, the “Quartet” of
the US, EU, UN, and Russia, presented a roadmap
to a final peace settlement by 2005, calling for two
states—Israel and a democratic Palestine. Follow-
ing Palestinian leader Yasir ARAFAT”s death in
late 2004 and the subsequent election of Mahmud
800
ABBAS (head of the Fatah political party) as the
PA president, Israel and the PA agreed to move
the peace process forward. Israel in late 2005 uni-
laterally withdrew all of its settlers and: soldiers
and dismantled its military facilities in the Gaza
Strip and redeployed its military from several West
Bank settlements, but continues to control mari-
time, airspace, and other access. In early 2006, the
Islamic Resistance Movement, HAMAS, won the
Palestinian Legislative Council election and took
control of the PA government. Attempts to form
a unity government failed, and violent clashes
between Fatah and HAMAS supporters ensued,
culminating in HAMAS"s violent seizure of all
military and governmental institutions in the Gaza
Strip. Fatah and HAMAS in early 2011 agreed to
reunify the Gaza Strip and West Bank, but the
factions have struggled to implement details on
governance and security. The status quo remains
with HAMAS in control of the Gaza Strip and the
PA governing the West Bank. Since the collapse
of direct talks between the Israelis and Palestinians
in late 2010, President ABBAS has reaffirmed that
he will not resume negotiations until Israel halts
all settlement activity in the West Bank and East
Jerusalem.','9487d3957a49748c2f7724727095805b8e348402e567137b576526e0f8744191','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e33349f967308373741aa531d7b77c46403bafee060e1d421a784f79488fb324',2025,'BE','Belgium','introduction',215,'Background: Belize was the site of several Mayan
city states until their decline at the end of the
first millennium A.D. The British and Spanish
disputed the region in the 17th and 18th cen-
turies; it formally became the colony of British
Honduras in 1854. Territorial disputes between
the UK and Guatemala delayed the independ-
ence of Belize until 1981. Guatemala refused to
recognize the new nation until 1992 and the two
countries are involved in an ongoing border dis-
pute. Guatemala and Belize plan to hold a simul-
taneous referendum, set for''6 October 2013, to
determine if this dispute will go before the Inter-
national Court of Justice at The Hague. Tourism
has become the mainstay of the economy. Cur-
rent concerns include the country’s heavy for-
eign debt burden, high unemployment, growing
involvement in the Mexican and South Ameri-
can drug trade, high crime rates, and one of the
highest HIV/AIDS prevalence rates in Central
America.
Background: Present day Benin was the site of
Dahomey, a West African kingdom that rose to
prominence in about 1600 and over the next
two and half centuries became a regional power,
largely based on its slave trade. Coastal areas of
Dahomey began to be controlled by the French
in the second half of the 19th century; the
entire kingdom was conquered by 1894. French
Dahomey achieved independence in 1960; it
changed its name to the Republic of Benin in
1975. A succession of military governments
ended in 1972 with the rise to power of Mathieu
KEREKOU and the establishment of a govern-
ment based on Marxist-Leninist principles. A
move to representative government began in
1989. Two years later, free elections ushered in
former Prime Minister Nicephore SOGLO as
president, marking the first successful transfer of
power in Africa from a dictatorship to a democ-
racy. KEREKOU was returned to power by elec-
tions held in 1996 and 2001, though some irregu-
larities were alleged. KEREKOU stepped down
at the end of his second term in 2006 and was
succeeded by Thomas YAYI Boni, a political out-
sider and independent. YAYI, who won a second
five-year term in March 2011, has attempted to
stem corruption and has strongly promoted accel-
erating Benin’s economic growth.','e435705495e09fee5c27bc2abf68b3694f661b8f574f977d032c4e0c29f923ba','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('165751b6b63b7b40a6aa6fb75068967f63d05f66fe096349f3a147f5c8665475',2025,'BM','Bermuda','introduction',228,'Background: Bermuda was first settled in 1609
by shipwrecked English colonists headed for Vir-
ginia. Vacationing to the island to escape North
American winters first developed in Victorian
times. Tourism continues to be important to the
island’s economy, although international business
has overtaken it in recent years. Bermuda has also
developed into a highly successful offshore finan-
cial center. A referendum on independence from
the UK was soundly defeated in 1995.','a1281bde8861b659e8619bfc4273e19df24d9cbc35dca9ceec75bf9c51cb49a3','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a9c0d89518fae5c75518ec37303c6d41c6cd83bfa142af804b1798bc0871188b',2025,'BT','Bhutan','introduction',238,'Background: In 1865, Britain and Bhutan signed
the Treaty of Sinchulu, under which Bhutan
would receive an annual subsidy in exchange for
ceding some border land to British India. Under
British influence, a monarchy was set up in 1907;
three years later, a treaty was signed whereby
the British agreed not to interfere in Bhutanese
+
internal affairs, and Bhutan allowéd Britain to
direct its foreign affairs. This role was assumed by
independent India after 1947. Two years later, a
formal Indo-Bhutanese accord returned to Bhu-
tan the areas annexed by the British, formalized
the annual subsidies the country yeceived, and
defined India’s responsibilities in defense and for-
eign relations. In March 2005, King Jigme Singye
WANGCHUCK unveiled the government''s draft
constitution—which introduced major demo-
cratic reforms—and pledged to hold a national
referendum for its approval. In December 2006,
the King abdicated the throne in favor of his son,
Jigme Khesar Namgyel WANGCHUCK, in order
to give him experience as head of state before the
democratic transition. In early 2007, India and
Bhutan renegotiated their treaty to allow Bhutan
greater autonomy in conducting its foreign policy,
although Thimphu continues to coordinate policy
decisions in this area with New Delhi. Elections
for seating the country’s first parliament were com-
pleted in March 2008; the king ratified the coun-
try’ first constitution in July 2008. The disposi-
tion of some 43,000 Bhutanese refugees—housed
in two UN refugee camps in Nepal—remains
unresolved.
Background: Bolivia, named after independ-
ence fighter Simon BOLIVAR, broke away from
Spanish rule in 1825; much of its subsequent his-
tory has consisted of a series of nearly 200 coups
and countercoups. Democratic civilian rule was
established in 1982, but leaders have faced dif-
ficult problems of deep-seated poverty, social
unrest, and illegal drug production. In Decem-
ber 2005, Bolivians elected Movement Toward
Socialism leader Evo MORALES president—by
the widest margin of any leader since the restora-
tion of civilian rule in 1982—after he ran on a
promise to change the country’s traditional politi-
cal class and empower the nation''s poor, indig-
enous majority. However, since taking office, his
controversial strategies have exacerbated racial
and economic tensions between the Amerindian
populations of the Andean west and the non-
indigenous communities of the eastern low lands.
In December 2009, President MORALES easily
won reelection, and his party took control of the
legislative branch of the government, which will
allow him to continue his process of change. In
October 2011, the country held its first judicial
elections to appoint judges to the four highest
courts.','7c03f765bd9c6f6b300580f5e3a694776def9e18884dcd3b5d7f93fca288c054','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1a1c7d7a01d9facd117a42b96b19aa10fd9e58ee5ac081a70eeaa1b5f5ded805',2025,'PY','Paraguay','introduction',258,'Background: Bosnia and Herzegovina’s declara-
tion of sovereignty in October 1991 was followed
by-a declaration of independence from the former
Yugoslavia on 3 March 1992 after a referendum
boycotted by ethnic Serbs. The Bosnian Serbs—
supported by neighboring Serbia and Montenegro
responded with armed resistance aimed at parti-
tioning the republic along ethnic lines and join-
ing Serb-held areas to form a “Greater Serbia.”
In March 1994, Bosniaks and Croats reduced the
number of warring factions from three to two by
signing an agreement creating a joint Bosniak/
Croat Federation of Bosnia and Herzegovina.
On 21 November 1995, in Dayton, Ohio, the
warring parties initialed a peace agreement that
brought to a halt three years of interethnic civil
strife (the final agreement was signed in Paris on
14 December 1995). The Dayton Peace Accords
retained Bosnia and Herzegovina’s international
boundaries and created a multi-ethnic and demo-
cratic government charged with conducting for-
eign, diplomatic, and fiscal policy. Also recognized
was a second tier of government composed of two
entities roughly equal in size: the Bosniak/Bosnian
Croat Federation of Bosnia and Herzegovina and
the Bosnian Serb-led Republika Srpska (RS). The
Federation and RS governments are responsible for
overseeing most government functions. Addition-
ally, the Dayton Accords established the Office
of the High Representative (OHR) to oversee
the implementation of the civilian aspects of the
agreement. The Peace Implementation Council
(PIC) at its conference in Bonn in 1997 also gave
the High Representative the authority to impose
legislation and remove officials, the so-called
“Bonn Powers.” An original NATO-led interna-
tional. peacekeeping force (IFOR) of 60,000 troops
assembled in 1995 was succeeded over time by a
smaller, NATO-led Stabilization Force (SFOR).
In 2004, European Union peacekeeping troops
(EUFOR) replaced SFOR. Currently EUFOR
deploys around 600 troops in theater in a polic-
ing capacity.
Background: Paraguay achieved its independence
from Spain in 1811. In the disastrous War of the
Triple Alliance (1865-70)—between Paraguay
and Argentina, Brazil, and Uruguay—Paraguay
lost two-thirds of all its adult males and much of its
territory. The country stagnated economically for
the next half century. Following the Chaco War of
1932-35 with Bolivia, Paraguay gained a large part
of the Chaco low land region. The 35-year military
dictatorship of Alfredo STROESSNER ended in
1989, and, despite a marked increase in political
infighting in recent years, Paraguay has held rela-
tively free and regular presidential elections since
the country’s return to democracy.','f9c3d9b8531ca1d6599a456eb2f1fee249876bbef9cf18524da737d80befda42','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c55d768463dfaf4f55a04a6a537f7f49c5474b4025f8d9db137924ab2b1a8277',2025,'BW','Botswana','introduction',268,'Background: Formerly the British protector-
ate of Bechuanaland, Botswana adopted its new
nemeé upon independence in 1966. More than
four decades of uninterrupted civilian leadership,
progressive social policies, and significant capital
investment have created one of the most stable
economies in Africa. Mineral extraction, prin-
cipally diamond mining, dominates economic
activity, though tourism is a growing sector
due to the country’s conservation practices and
extensive nature preserves. Botswana has one of
the world’s highest known rates of HIV/AIDS
infection, but also one of Africa’s most progres-
sive and comprehensive programs for dealing
with the disease.','d90f2772314704161ad8c0df45f17f53e1ab0af0a20b6a48272a6e6355e4cec4','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ea38cb5835b0247386a6d10c80726df166eb589754ca0d8a5bbbedc51369b50b',2025,'BV','Bouvet Island','introduction',277,'Background: This uninhabited, volcanic, Ant-
arctic island is almost entirely covered by glaciers
making it difficult to approach; it is recognized as
the most remote island on Earth. Bouvet Island
was discovered in 1739 by a French naval officer
after whom it is named. No claim was made until
1825, when the British flag was raised. In 1928,
the UK waived its claim in favor of Norway,
which had occupied the island the previous year.
In 1971, Norway designated Bouvet Island and
the adjacent territorial waters a nature reserve.
Since 1977, Norway has run an automated mete-
orological station and studied foraging strategies
and distribution of fur seals and penguins on the
island.
98','64ba94f0c914f861201deaf88eb51cd19274053146f27ba041b73a0702fd9d03','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a4d1ad38f66c25f82cda41878264415d8768dd147909219cd6327a608f70c178',2025,'BR','Brazil','introduction',283,'Background: Following more than three centuries
under Portuguese rule, Brazil gained its independ-
ence in 1822, maintaining a monarchical system of
government until the abolition of slavery in 1888
and the subsequent proclamation of a republic by the
military in 1889. Brazilian coffee exporters politically
dominated the country until populist leader Getulio
VARGAS tose to power in 1930. By far the largest
and most populous country in South America, Brazil
underw ent more than a half century of populist and
military government until 1985, when the military
regime peacefully ceded power to civilian rulers.
Brazil continues to pursue industrial and agricultural
growth and development of its interior. Exploiting
vast natural resources and a large labor pool, it is
today South America’s leading economic power and
a regional leader, one of the first in the area to begin
an economic recovery. Highly unequal income dis-
tribution and crime remain pressing problems.','60edabb615af024c0c0a55b354f425fa18f97337fe19e1c167e6d5baa78f198c','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b6176a5238a78df239a4618e24bf6d5e37b08841047f8f00714602d8ef73639c',2025,'IO','British Indian Ocean Territory','introduction',285,'Background: Formerly administered as part of the
British Crown Colony of Mauritius, the British
Indian Ocean Territory (BIOT) was established as
an overseas territory of the UK in 1965. A number
of the islands of the territory were later transferred
to the Seychelles when it attained independence
in 1976. Subsequently, BIOT has consisted only of
the six main island groups comprising the Chagos
Archipelago. The largest and most southerly of
the islands, Diego Garcia, contains a joint UK-US
naval support facility. All of the remaining islands
are uninhabited. Between 1967 and 1973, for-
mer agricultural workers, earlier residents in the
islands, were relocated primarily to Mauritius, but
also to the Seychelles. Negotiations between 1971
and 1982 resulted in the establishment of a trust
fund by the British Government as compensation
for the displaced islanders, known as Chagossians.
Beginning in 1998, the islanders pursued a series of
law suits against the British Government seeking
further compensation and the right to return to the
territory. In 2006 and 2007, British court rulings
invalidated the immigration policies contained
in the 2004 BIOT Constitution Order that had
excluded the islanders from the archipelago, but
upheld the special military status of Diego Garcia.
In 2008, the House of Lords, as the final court of
appeal in the UK, ruled in favor of the British Gov-
ernment by overtuming the lower court rulings
and finding no right of return for the Chagossians.','aad7ed1231a087a0bb522251c5f956262eca2ee14964c4313b0acf7a18975081','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ca6cdeb10e969ad45345a570075131bfaeac1cfad833a9850fd0c0ed6c93819b',2025,'ID','Indonesia','introduction',294,'Background: First inhabited by Arawak and later
by Carib Indians, the Virgin Islands were settled
by the Dutch in 1648 and then annexed by the
English in 1672. The islands were part of the Brit-
ish colony of the Leeward Islands from 1872-1960;
they were granted autonomy in 1967. The econ-
omy is closely tied to the larger and more populous
US Virgin Islands to the west; the US dollar is the
legal currency.
Background: The Sultanate of Brunei’s influence
peaked between the 15th and 17th centuries when
106
its control extended over coastal areas of north-
west Borneo and the southern Philippines. Brunei
subsequently entered a period of decline brought
on by internal strife over royal succession, colo-
nial expansion of European powers, and piracy. In
1888, Brunei became a British protectorate; inde-
pendence was achieved in 1984. The same fam-
ily has ruled Brunei for over six centuries. Brunei
benefits from extensive petroleum and natural gas
fields, the source of one of the highest per capita
GDPs in Asia.
Background: Known as Persia until 1935, Iran
became an Islamic republic’ in 1979 after the
ruling monarchy was overthrown and Shah
Mohammad Reza PAHLAVI was forced into
exile. Conservative clerical forces led by Aya-
tollah Ruhollah KHOMEINI established a
theocratic system of government with ultimate
political authority vested in a learned religious
scholar referred to commonly as the Supreme
Leader who, according to the constitution, is
accountable only to the Assembly of Experts—
a popularly elected 86-member body of clerics.
US-Iranian relations became strained when a
group of Iranian students seized the US Embassy
in Tehran in November 1979 and held embassy
personnel hostages until mid-January 1981. The
US cut off diplomatic relations with Iran in April
1980. During the period 1980-88, Iran fought a
bloody, indecisive war with Iraq that eventu-
ally expanded into the Persian Gulf and led to
clashes between US Navy and Iranian military
forces. Iran has been designated a state sponsor
of terrorism for its activities in Lebanon and
elsewhere in the world and remains subject to
US, UN, and EU economic sanctions and export
controls because of its continued involvement in
terrorism and its nuclear weapons ambitions. Fol-
lowing the election of reformer Hojjat ol-Eslam
Mohammad KHATAMI as president in 1997
and a reformist Majles (legislature) in 2000, a
campaign to foster political reform in response
to popular dissatisfaction was initiated. The
movement floundered as conservative politi-
cians, through control of unelected institutions,
346
THE CiA WORLD FACTBOOK
Indonesia and Singapore continue to work on
finalizing their 1973 maritime boundary agree-
ment by defining unresolved areas north of Indo-
nesia’s Batam Island; Indonesian secessionists,
squatters, and illegal migrants create repatriation
problems for Papua New Guinea; maritime delimi-
tation talks continue with Palau; EEZ negotiations
with Vietnam are ongoing, and the two countries
in Fall 2011 agreed to work together to reduce ille-
gal fishing along their maritime boundary
prevented reform measures from being enacted
and increased repressive measures. Starting with
nationwide municipal elections in 2003 and
continuing through Majles elections in 2004,
conservatives reestablished control over Iran''s
elected government institutions, which cul-
minated with the August 2005 inauguration of
hardliner Mahmud AHMADI-NEJAD as presi-
dent. His controversial reelection in June 2009
sparked nationwide protests over allegations of
electoral fraud. The UN Security Council has
passed a number of resolutions calling for Jran to
suspend its uranium enrichment and reprocessing
activities and comply with its [AEA obligations
and responsibilities. In mid-February 2011, oppo-
sition activists conducted the largest antiregime
rallies since December 2009, spurred by the suc-
cess of uprisings in Tunisia and Egypt. Protester
turnout probably was at most tens of thousands
and security forces were deployed to disperse pro-
testers. Additional protests in March 2011 failed
to elicit significant participation largely because
of the robust security response, although discon-
tent still smolders. Deteriorating economic con-
ditions due primarily to government mismanage-
ment and international sanctions prompted at
least two major economically based protests in
July and October 2012.
Background: The Portuguese began to trade with
the island of Timor in the early 16th century and
colonized it in mid-century. Skirmishing with the
Dutch in the region eventually resulted in an 1859
treaty in which Portugal ceded the western portion
of the island. Imperial Japan occupied Portuguese
Timor from 1942 to 1945, but Portugal resumed
colonial authority after the Japanese defeat in
World War II. East Timor declared itself independ-
ent from Portugal on 28 November 1975 and was
invaded and occupied by Indonesian forces nine
days later. It was incorporated into Indonesia in
July 1976 as the province of Timor Timur (East
Timor). An -unsuccessful campaign of pacifica-
tion followed over the next two decades, during
which an estimated 100,000 to 250,000 individu-
als lost their lives. On 30 August 1999, in a UN-
supervised popular referendum, an overwhelming
majority of the people of Timor-Leste voted for
independence from Indonesia. However, in the
next three weeks, anti-independence Timorese
militias—organized and supported by the Indone-
sian military—commenced a large-scale, scorched-
earth campaign of retribution. The militias killed
approximately 1,400 Timorese and forcibly pushed
300,000 people into western Timor as refugees.
Most of the country’s infrastructure, including
722
homes, irrigation systems, water supply systems,
and schools, and nearly 100% of the country’s elec-
trical grid were destroyed. On 20 September 1999,
Australian-led peacekeeping troops deployed to
the country and brought the violence to an end.
On 20 May 2002, Timor-Leste was internation-
ally recognized as an independent state. In 2006,
internal tensions threatened the new nation’s
security when a military strike led to violence and
a breakdown of law and order. At Dili’s request, an
Australian-led International Stabilization Force
(ISF) deployed to Timor-Leste, and the UN Secu-
rity Council established the UN Integrated Mis-
sion in Timor-Leste (UNMIT), which included an
authorized police presence of over 1,600 person-
nel. The ISF and UNMIT restored stability, allow-
ing for presidential and parliamentary elections in
2007 in a largely peaceful atmosphere. In February
2008, a rebel group staged an unsuccessful attack
against the president and prime minister. The
ringleader was killed in the attack, and most of the
tebels surrendered in April 2008. Since the attack,
the government has enjoyed one of its longest
periods of post-independence stability, including
successful 2012 elections for both the parliament
and president. In late 2012, the UN Security
Council voted to end its peacekeeping mission
in Timor-Leste and both the ISF and UNMIT
departed the country by the end of the year.','fac668999b2a37985e9904247ab6ae46d6981dcdf7ab7d45b92669b5e89bfc59','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('15091b4dcbdbf469084c0cff0452ca39809eef6e457268aa7804d944c14fff61',2025,'BG','Bulgaria','introduction',299,'Background: The Bulgars, a Central Asian Tur-
kic tribe, merged with the local Slavic inhabitants
in the late 7th century to form the first Bulgarian
state. In succeeding centuries, Bulgaria struggled
with the Byzantine Empire to assert its place in
the Balkans, but by the end of the 14th century
the country was overrun by the Ottoman Turks.
Northern Bulgaria attained autonomy in 1878
and all of Bulgaria became independent from
the Ottoman Empire in 1908. Having fought on
the losing side in both World Wars, Bulgaria fell
within the Soviet sphere of influence and became
a People’s Republic in 1946. Communist domina-
tion ended in 1990, when Bulgaria held its first
multiparty election since World War H and began
the contentious process of moving toward politi-
cal democracy and a market economy while com-
bating inflation, unemployment, corruption, and
crime. The country joined NATO in 2004 and the
. EU in 2007.','9b434cd2270444497a15910edbe92f04ae3b4f80c2c810f45b523f6e5ba0b708','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('db52f46432586f2b89560935e099e9611b251af26cb1a17bb4e64746be983aff',2025,'BF','Burkina Faso','introduction',308,'Background: Burkina Faso (formerly Upper
Volta) achieved independence from France in
1960. Repeated military coups during the 1970s
and 1980s were followed by multiparty elections
in the early 1990s. Current President Blaise COM-
PAORE came to power in a 1987 military coup
and has won every election since then. Burkina
Faso’s high population density and limited natural
resources result in poor economic prospects for the
majority of its citizens.
Background: Various ethnic Burmese and eth-
nic minority city-states or kingdoms occupied
the present borders through the 19th century.
Over a period of 62 years (1824-1886), Britain
conquered Burma and incorporated the country
into its Indian Empire. Burma was administered
as a province of India until 1937 when it became
a separate, self-governing colony; in 1948, Burma
attained independence from the Commonw ealth.
Gen. NE WIN dominated the government from
1962 to 1988, first as military ruler, then as self-
appointed president, and later as political kingpin.
In response to widespread civil unrest, NE WIN
resigned in 1988, but within months the military
crushed student-led protests and took power. Mul-
tiparty legislative elections in 1990 resulted in the
main opposition party—the National League for
Democracy (NLD)—winning a landslide victory,
Instead of handing over power, the junta placed
NLD leader (and Nobel Peace Prize recipient)
AUNG SAN S00 KYI (ASSK) under house arrest
from 1989 to 1995, 2000 to 2002, and from May
2003 to November 2010. In late September 2007,
the ruling junta brutally suppressed protests over
increased fuel prices led by prodemocracy activ-
ists and Buddhist monks, killing at least 13 people
and arresting thousands for participating in the
demonstrations. In early May 2008, Burma was
struck by Cyclone Nargis, which left over 138,000
dead and tens of thousands injured and homeless.
Despite this tragedy, the junta proceeded with its
May constitutional referendum, the first vote in
Burma since 1990. Parliamentary elections held
in November 2010, considered flawed by many
in the international community, saw the ruling
Union Solidarity and Development Party garner
over 75% of the seats. Parliament convened in
116
January 2011 and selected former Prime Minister
THEIN SEIN as president. Although the vast
majority of national-level appointees named by
THEIN SEIN are former or current military offic-
ers, the government has initiated a series of politi-
cal and economic reforms leading to a substantial
opening of the long-isolated country. These
reforms have included allowing ASSK to con-
test parliamentary byelections on 1 April 2012,
releasing hundreds of political prisoners, reaching
preliminary peace agreements with 10 of the 11
major armed ethnic groups, enacting laws that
provide better protections for basic human rights,
and gradually reducing restrictions on freedom of
the press, association, and civil society. At least
due in part to these reforms, ASSK now serves as
an elected Member of Parliament and chair of the
Committee for Rule of Law and Tranquility. Most
political parties have begun building their institu-
tions in preparation for the next round of general
elections in 2015. The country is preparing to
chair the Association of Southeast Asian Nations
(ASEAN) in 2014.','528f54f5011f91cd2b0748456a8dc240d549a0b1914676d5d59ea54bf4261bcf','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('72f53a5f4ea6abd5e46422ac1cb57b249e63956b9cdd34f1caa6b9502b4926fc',2025,'BI','Burundi','introduction',322,'Background: Burundi’s first democratically
elected president was assassinated in October 1993
after only 100 days in office, triggering widespread
ethific violence between Hutu and Tutsi factions.
More than Burundians perished during the conflict
that spanned almost a dozen years. Hundreds of
- thousands of Burundians were internally displaced
or became refugees in neighboring countries.
An internationally brokered power-sharing
agreement between the Tutsi-dominated govem-
ment and the Hutu rebels in 2003 paved the way
for a transition process that led to an integrated
defense force, established a new constitution in
2005, and elected a majority Hutu government in
2005. The government of President Pierre NKU-
RUNZIZA, who was reelected in 2010, continues
to face many political and economic challenges.','d9ea2a6cbc424d5d23c88b2856d1b161a0a31cdc46b1e207b5cbf86e9e9b195f','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ee2be4b23617b5314f52b55420e3b29ad19ec723f6975e1b30f08bf372eb373d',2025,'NG','Nigeria','introduction',341,'Background: French Cameroon became inde-
pendent in 1960 as the Republic of Cameroon.
The following year the southern portion of neigh-
boring British Cameroon voted to merge with
the new country to form the Federal Republic of
Cameroon. In 1972, a new constitution replaced
the federation with a unitary state, the United
Republic of Cameroon. The country has gener-
ally enjoyed stability, which has permitted the
development of agriculture, roads, and railways,
as well as a petroleum industry. Despite slow
movement toward democratic reform, political
power remains firmly in the hands of President
Paul BIYA
Background: Equatorial Guinea gained independ-
ence in 1968 after 190 years of Spanish rule: This
tiny country, composed of a mainland portion
plus five inhabited islands, is one of the small-
est on the African continent. President Teodoro
OBIANG NGUEMA MBASOGO has ruled the
country since 1979 when he seized power in a coup.
Although nominally a constitutional democracy
since 1991, the 1996, 2002, and 2009 presidential
elections—as well as the 1999, 2004, and 2008 leg-
islative elections—were widely seen as flawed. The
president exerts almost total control over the politi-
cal system and has discouraged political opposition.
Eqùatorial Guinea has experienced rapid economic
growth due to the discovery of large offshore oil
reserves, and in the last decade has become Sub-
Saharan Africa’s third largest oil exporter. Despite
the country’s economic windfall from oil produc-
tion, resulting in a massive increase in government
revenue in recent years, improvements in the popu-
lation’s living standards have been slow to develop.
Background: Niue”s remoteness, as well as cul-
tural and linguistic differences between its Polyne-
sian inhabitants and those of the rest of the Cook
Islands, have caused it to be separately adminis-
tered. The population of the island continues to
drop (from a peak of 5,200 in 1966 to an estimated
1,311 in.2011) with substantial emigration to New
Zealand 2,400 km to the southwest.','4f7871f7da6694f25021bf712fffbb8781ce84c23182d737a6ffc41382c342a3','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4be5c153a7d20beb3181125343a6f4db188fdf9df2deedb6bbde79091fb90e69',2025,'CA','Canada','introduction',348,'Background: A land of vast distances and rich
natural resources, Canada became a self-govern-
ing dominion in 1867 while retaining ties to the
British crown. Economically and technologically,
the nation has developed in parallel with the US,
its neighbor to the south across the world’s long-
est unfortified border. Canada faces the political
challenges of meeting public demands for qual-
ity improvements in health care, education,
social services, and economic competitiveness,
as well as responding to the particular con-
cerns of predominantly francophone Quebec.
Canada also aims to develop its diverse energy
resources while maintaining its commitment to
the environment.
GEQGRAPHY
Location: Northern North America, bordering the
North Atlantic Ocean on the east, North Pacific
Ocean on the west, and the Arctic Ocean on the
north, north of the conterminous US
Geographic coordinates: 60 00 N, 95 00 W
Map references: North America
Area: total: 9,984,670 sq km
country comparison to the world: 2
land: 9,093,507 sq km
water: 891,163 sq km
Area—comparative: slightly larger than the US
Land boundaries: total: 8,893 km
border countries: US 8,893. km (includes 2,477
km with Alaska)
note: Canada is the World''s largest country that
borders only one country
Coastline:.202,080 km
Maritime claims: territorial sea: 12 nm
contiguous zone: 24 nm
exclusive economic zone: 200 nm
continental shelf: 200 nm or to the edge of the
continental margin
Climate: varies from temperate in south to subare-
tic and arctic in north
Terrain: mostly plains with mountains in west and
lowlands in southeast
132
Elevation extremes: lowest point: Atlantic
Ocean 0 m
highest point: Mount Logan 5,959 m
Natural resources: iron ore, nickel, zinc, copper,
gold, lead, rare earth elements, molybdenum, pot-
ash, diamonds, silver, fish, timber, wildlife, coal,
petroleum, natural gas, hydropower
Land use: arable land: 4.3%
permanent crops: 0.49%
other: 95.2% (2011)
Irrigated land: 8,699 sq km (2004)
Total renewable water resources: 2,902 cu km
(2011)
Freshwater withdrawal (domestic/indus-
trial/agricultural): total: 42.2 cu km/yr
(20%/70%/10%)
per capita: 1,589 cu m/yr (2010)
Natural hazards: continuous permafrost in north
is a serious obstacle to development; cyclonic
storms form east of the Rocky Mountains, a result
of the mixing of air masses from the Arctic, Pacific,
and North American interior, and produce most of
the country’s rain and snow east of the mountains
volcanism: the vast majority of volcanoes in West-
ern Canada’s Coast Mountains remain dormant
Environment—current issues: air pollution and
resulting acid rain severely affecting lakes and
damaging forests; metal smelting, coal-burning
utilities, and vehicle emissions impacting on
agricultural and forest productivity; ocean waters
becoming contaminated due to agricultural, indus-
trial, mining, and forestry activities
Environment—international agreements:
party to: Air Pollution, Air Pollution-Nitrogen
Oxides, Air Pollution-Persistent Organic Pollut-
ants, Air Pollution-Sulfur 85, Air Pollution-Sulfur
94, Antarctic-Environmental Protocol, Antarctic-
Marine Living Resources, Antarctic Seals, Antarc-
tic Treaty, Biodiversity, Climate Change, Deserti-
fication, Endangered Species, Environmental
Modification, Hazardous Wastes, Law of the Sea,
Marine Dumping, Ozone Layer Protection, Ship
Pollution, Tropical Timber 83, Tropical Timber
94, Wetlands
signed, but not ratified: Air Pollution-Volatile
Organic Compounds, Marine Life Conservation
Geography—note: second-largest country in
world (after Russia); strategic location between
Russia arid US via north polar route; approxi-
mately 90% of the population is concentrated
within 160 km of the US border; Canada has more
fresh water than any other country and almost 9%
of Canadian territory is water; Canada has at least
2 million and possibly over 3 million lakes—that is
more than all other countries combined
Background: The uninhabited islands were discov-
ered and colonized by the Portuguese in the 15th
century; Cape Verde subsequently became a trad-
ing center for African slaves and later an important
coaling and resupply stop for whaling and transatlan-
tic shipping. Following independence in 1975, anda
tentative interest in unification with Guinea-Bissau,
a one-party system was established and maintained
until multi-party elections were held in 1990. Cape
Verde continues to exhibit one of Affica’s most
" stable democratic governments. Repeated droughts
during the second half of the 20th century caused
significant hardship and prompted heavy emigra-
tion. As a result, Cape Verde’s expatriate population
is greater than its domestic one. Most Cape Verdeans
have both African and Portuguese antecedents.','899b61e02a299cc7810ae7f39d52cfe1544680b8cd0bf8dab2aeb610976f5f60','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e37192c8feefcb65e5bff7b4f7cbcf9e7d6f2f733c98ded51b03c6ec99140759',2025,'KY','Cayman Islands','introduction',359,'Background: The Cayman Islands were colonized
from Jamaica by the British during the 18th and
19th centuries and were administered by Jamaica
after 1863. In 1959, the islands became a territory
within the Federation of the West Indies. When
the Federation dissolved in 1962, the Cayman
Islands chose to remain a British dependency.','7c18870462dd5a300d1a144ededa5108e4cc7e4385300118e227d25fef2dd4f5','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('707fb5fd81d89d1d74c0ee412ac8d9f6b2b4d1c7962735436d27fc0b601cf3a1',2025,'CF','Central African Republic','introduction',369,'Background: The former French colony of
Ubangi-Shari became the Central African Repub-
lic upon independence in 1960. After three
tumultuous decades of misrule—mostly by mili-
tary governments—civilian rule was established
in 1993 and lasted for one decade. In March, 2003
President Ange-Felix PATASSE was deposed
in a military coup led by General Francois BOZ-
IZE, who established a transitional government.
Elections held in 2005 affirmed General BOZIZE
as president; he was reelected in 2011 in voting
widely view ed as flawed. The government still does
not fully control the countryside, where pockets of
law lessness persist. The militant group the Lord’s
Resistance Army continues to destabilize south-
eastern Central African Republic, and several rebel
groups joined together in early December 2012 to
launch a series of attacks that left them in control of
numerous towns in the northern and central parts
of the country. The rebels—who are unhappy with
BOZIZE''s government—participated in peace talks
in early January 2013 which resulted in a coalition
government including the rebellion’s leadership. In
March 2013, the coalition government dissolved,
rebels seized the capital, and President BOZIZE
fled the country. Rebel leader Michel DJOTO-
DIA assumed the presidency, reappointed Nicolas
TIANGAYE as Prime Minister, and established a
transitional government on 31 March. On 13 April
2013, the National Transitional Council affirmed
DJOTODIA as President.
Background: Chad, part of France’s African hold-
ings until 1960, endured three decades of civil war-
fare, as well as invasions by Libya, before a semblance
of peace was finally restored in 1990. The govern-
ment eventually drafted a democratic constitution
and heid flawed presidential elections in 1996 and
2001. In 1998, a rebellion broke out in northern
Chad, which has sporadically flared up despite sev-
eral peace agreements between the government and
the insurgents. In 2005, new rebel groups emerged in
western Sudan and made probing attacks into eastern
Chad despite signing peace agreements in December
144
2006 and October 2007. In June 2005, President
Idriss DEBY held a referendum successfully remoy-
ing constitutional term limits and won another con-
troversial election in 2006. Sporadic rebel campaigns
continued throughout 2006 and 2007. The capital
experienced a significant insurrection in early 2008,
but has had no significant rebel threats since then, in
part due to Chad’s 2010 rapprochement with Sudan,
which previously used Chadian rebels as proxies.
DEBY in 2011 was reelected to his fourth term in
an election that intémational observers described as
proceeding without incident. Power remains in the
hands of an ethnic minority.','b3edf4383dd3b4605cac3b0603c83eb9ae63ef11ebb3faa6a67357504f4c80c4','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2c1c34c204f0218878a962260a03d2a4fdca6b2024d43da9d555bc70e9df4d61',2025,'CN','China','introduction',391,'Background: For centuries China stood as a lead-
ing civilization, outpacing the rest of the world in
the arts and sciences, but in the 19th and early
20th centuries, the country was beset by civil
unrest, major famines, military defeats, and foreign
occupation. After World War II, the Communists
under MAO Zedong established an autocratic
socialist system that, while ensuring China’s sov-
ereignty, imposed strict controls over everyday
life and cost the lives of tens of millions of peo-
ple. After 1978, MAO’s successor DENG Xiaop-
ing and other leaders focused on market-oriented
economic development and by 2000 output had
quadrupled. For much of the population, living
standards have improved dramatically and the
room for personal choice has expanded, yet politi-
cal controls remain tight. Since the early 1990s,
China has increased its global outreach and par-
ticipation in international organizations.
Background: Macedonia gained ''its independ-
ence peacefully from Yugoslavia in 1991.
Greece”s objection to the new state’ use of
what it considered a Hellenic name and sym-
bols delayed international recognition, which
occurred under the provisional designation of
“the Former Yugoslav Republic of Macedonia.”
In 1995, Greece lifted a 20-month trade embargo
and the two countries agreed to normalize
relations, but the issue of the namie remained
unresolved and negotiations for a solution are
ongoing. Since 2004, the United States and 133
other nations have recognized Macedonia by its
constitutional name, Republic of Macedonia.
Some ethnic Albanians, angered by perceived
political and economic inequities, launched an
insurgency in 2001 that eventually won the sup-
port of the majority of Macedonia”s ethnic Alba-
nian population and led to the internationally
"brokered Ohrid Framework Agreement, which
ended the fighting and established guidelines
for the creation of new laws that enhanced the
tights of minorities. Fully implementing the
Framework Agreement, maintaining momentum
on democratic reforms, and stimulating eco-
nomic growth and development continue to be
challenges for Macedonia, although progress has
been made over the past several years.','4bcf2d06fdf33d30e6157d8850d7ca18f3ebac752e21ea4c36334348b2c74a09','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1ae39fceac85d208805800569fc9d1d0ba61b36f65674b8a843baa181504140d',2025,'CX','Christmas Island','introduction',400,'Background: Named in 1643 for the day of its
discovery, the island was annexed and settlement
began by the UK in 1888 with the discovery of the
island’s phosphate deposits. Following the Second
World War, Christmas Island came under the juris-
diction of the new British Colony of Singapore.
The island existed as a separate Crown colony from
1 January 1958 to 1 October 1958 when its transfer
to Australian jurisdiction was finalized. That date
is still celebrated on the first Monday in October as
Territory Day. Almost two-thirds of the island has
been declared a national park.
Background: This isolated atoll was named for
John CLIPPERTON, a pirate who was rumored to
have made it his hideout early in the 18th cen-
tury. Annexed by France in 1855 and claimed
by the United States, it was seized by Mexico in
1897. Arbitration eventually awarded the island
to France in 1931, which took possession in 1935.
Location: Middle America, atoll in the North
Pacific Ocean, 1,120 km southwest of Mexico
Geographic coordinates: 10 17 N, 109 13 W
Map references: Political Map of the World
Area: total: 6 sq km
country comparison to the world: 245
land: 6 sq km water: 0 sq km
Area—compoarative: about 12 times the size of
The Mall in Washington, DC
Land boundaries: 0 km
Coastline: 11.1 km
Maritime claims: territorial sea: 12 nm
exclusive economic zone: 200 nm
Climate: tropical; humid, average temperature
20-32 degrees C, wet season (May to October)
Terrain: coral atoll
Elevation extremes: lowest point: Pacific Ocean
Om
highest point: rcocner Clipperton 29 m
Natural resources: fish
Land use: arable land: 0%
permanent crops: 0%
other: 100% (all coral) (2011)
Natural hazards: NA
Environment—current issues: NA
Geography—note: the atoll reef is approximately
12 km (7.5 mi) in circumference; an effort to colo-
nize the atoll in the early 20th century ended in
disaster and was abandoned in 1917','6e3574c7600e9f5a191faaff41d6e69adcbe00b8209e71cc87590344288dd22d','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('55e754c29bcd4b543de9499557527bc84cc15f8da21cf7754fb14a86f5d9d819',2025,'CC','Cocos (Keeling) Islands','introduction',407,'the UK in 1857, the Cocos Islands were transferred
to the Australian Government in 1955. Apart from
North Keeling Island, which lies 30 kilometers north
of the main group, the islands form a horseshoe-shaped
atoll surrounding a lagoon. North Keeling Island was
declared a national park in 1995 and is administered by
Parks Australia. The population on the two inhabited
islands generally is split between the ethnic Europeans
on West Island and the ethnic Malays on Home Island.','01f5f81531a64fe419bb7062237229c648c52c3b70e7328f3f9c1e7f556d4769','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7a1d5b13ce6330420d2ce89b0ab71f4bf14026dd59365d3099ec0e540ab99ae1',2025,'CO','Colombia','introduction',413,'Background: Colombia was one of the three
countries that emerged from the collapse of Gran
Colombia in 1830 (the others are Ecuador and Ven-
ezuela), A nearly five-decade long conflict between
government forces and anti-government insurgent
groups, principally the Revolutionary Armed Forces
of Colombia (FARC) heavily funded by the drug
trade, escalated during the 1990s. More than 31,000
former paramilitaries had demobilized by the end of
2006 and the United Self Defense Forces of Colom-
bia as a formal organization had ceased to function.
In the wake of the paramilitary demobilization,
emerging criminal groups arose, whose members
include some former paramilitaries. The insurgents
lack the military or popular support necessary to
overthrow the government, but continue attacks
against civilians. Large areas of the countryside
are under guerrilla influence or are contested by
security forces. In October 2012, the Colombian
Government started formal peace negotiations
with the FARC aimed at reaching a definitive
bilateral ceasefire and incorporating demobilized
FARC members into mainstream society and poli-
tics. The Colombian Government has stepped up
efforts to reassert government control throughout
the country, and now has a presence in every one
of its administrative departments. Despite decades
of internal conflict and drug related security chal-
lenges, Colombia maintains relatively strong demo-
cratic institutions characterized by peaceful, trans-
parent elections and the protection of civil liberties.
Background: Venezuela was one of three countries
that entërged from the collapse of Gran Colombia in
1830 (the others being Ecuador and New Granada,
which became Colombia). For most of the first half
of the 20th century, Venezuela was ruled by gener-
ally benevolent military strongmen, who promoted
the oil industry and allowed for some social reforms.
Democratically elected governments have held
sway since 1959. Hugo CHAVEZ, president from
1999 to 2013, sought to implement his “21st Cen-
tury Socialism,” which purported to alleviate social
ills while at the same time attacking capitalist glo-
balization and existing democratic institutions. Cur-
rent concerns include: a weakening of democratic
institutions, political polarization, a politicized mili-
tary, rampant violent crime, overdependence on the
petroleum industry with its price fluctuations, and
irresponsible mining operations that are endanger-
ing the rain forest and indigenous peoples.
Background: The conquest of Vietnam by France
began in 1858 and was completed by 1884. It
became part of French Indochina in 1887. Viet-
nam declared independence after World War H,
but France continued to rule until its 1954 defeat
by communist forces under Ho Chi MINH. Under
the Geneva Accords of 1954, Vietnam was divided
into the communist North and anti-communist
South. US economic and. military aid to South
Vietnam grew through the 1960s in an attempt
to bolster the government, but US armed forces
were withdrawn following a cease-fire agreement
in 1973. Two years later, North Vietnamese forces
overran the South reuniting the country under
communist rule. Despite the return of peace, for
over a decade the country experienced little eco-
nomic growth because of conservative leadership
policies, the persecution and mass exodus of indi-
viduals—many of them successful South Vietnam-
ese merchants—and growing international isola-
tion. However, since the enactment of Vietnam''s
“doi moi” (renovation) policy in 1986, Vietnamese
authorities have committed to increased economic,
structural reforms
needed to modernize the economy and to produce
more competitive, export-driven industries. The
communist leaders, however, maintain control on
liberalization and enacted
political expression and have resisted outside calls
to improve human rights. The country continues
to experience small-scale protests from various
groups—the vast majority connected to land-use
issues, calls for increased political space, and the
lack of equitable mechanisms for resolving dis-
putes, Various ethnic minorities, such as the Mon-
tagnards of the Central Highlands and the Khmer
Krom in the southern delta region, have also held
protests.','165f4e3440bcffef5bacc6854a4fcc03e1782b18939e707f71242cb5d245a9ae','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f05f990dd1955360cbc195eac08f0184cbf887707976fae886a3527647a04f1b',2025,'KM','Comoros','introduction',423,'Background: Comoros has endured more than 20
coups or attempted coups since gaining independ-
ence from France in 1975. In 1997, the islands of
Anjouan and Moheli declared independence from
Comoros. In 1999, military chief Col. AZALI
seized power of the entire government in a blood-
less coup, and helped negotiate the 2000 Fomboni
Accords power-sharing agreement in which the
federal presidency rotates among the three islands,
and each island maintains its local government.
AZALI won the 2002 federal presidential election,
and each island in the archipelago elected its presi-
dent. AZALI stepped down in 2006 and President
SAMBI was elected to office. In 2007, Mohamed
BACAR effected Anjouan’s de-facto secession from
the Union of Comoros, refusing to step down when
Comoros’ other islands held legitimate elections in
July. The African Union (AU) initially attempted to
resolve the political crisis by applying sanctions and
a naval blockade to Anjouan, but in March 2008
the AU and Comoran soldiers seized the island.
The island’s inhabitants generally welcomed the
164
move. In May 2011, Ikililou DHOININE won the
presidency in peaceful elections widely deemed to be
free and fair.
Background: Established as a Belgian colony in
1908, the then-Republic of the Congo gained its
independence in 1960, but its early years were
marred by political and social instability. Col.
Joseph MOBUTU seized power and declared
himself president in a November 1965 coup. He
subsequently changed his name—to MOBUTU
Sese Seko—as well as that of the country—to
Zaire. MOBUTU retained his position for 32
years through several sham elections, as well as
through brutal force. Ethnic strife and civil war,
touched off by a massive inflow of refugees in
1994 from fighting in Rwanda and Burundi, led
in May 1997 to the toppling of the MOBUTU
regime by a rebellion backed by Rw anda and
Uganda and fronted by Laurent KABILA. He
renamed the country the Democratic Republic of
=
the Congo (DRC), but in August 1998 his regime
was itself challenged by a second insurrection
again backed by Rw anda and Uganda. Troops
from Angola, Chad, Namibia, Sudan, and Zimba-
bwe intervened to support KABILA’s regime. In
January 2001, KABILA was assassinated and his
son, Joseph KABILA, was named head of state. In
October 2002, the new ptesident was successful
in negotiating the withdraw al of Rw andan forces
occupying the eastern DRC; two months later,
the Pretoria Accord was signed by all remaining
warring parties to end the fighting and establish
a government of national unity, A transitional
government was set up in July 2003; it held a suc-
cessful constitutional referendum in December
2005 and elections for the presidency, National
Assembly, and provincial legislatures took place
in 2006. In 2009, following a resurgence of con-
flict in the eastern DRC, the government signed
a peace agreement with the National Congress
for the Defense of the People (CNDP), a primar-
ily Tutsi rebel group. An attempt to integrate
CNDP members into the Congolese military
failed, prompting their defection in 2012 and the
formation of the M23 armed group—named after
the 23 March 2009 peace agreements. Renewed
conflict has lead to the displacement of large
numbers of persons and significant human rights
abuses. As of February 2013, peace talks between
the Congolese government and the M23 were on-
going. In addition, the DRC continues to experi-
ence violence committed by other armed groups
including the Democratic Forces for the Libera-
tion of Rw anda and Mai Mai groups. In the most
recent national elections, held in November
2011, disputed results allow ed Joseph KABILA
to be reelected to the presidency.','85658fd3320b177f4e3f791856ba1169d2a4506d0163a179f6289d4cb0f5caf8','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('76ae4a3ab94cd2ea4c3d0aeecd01f62c4e54d12ea0e3982dbd660c2fc514554d',2025,'CR','Costa Rica','introduction',448,'Background: Although explored by the Span-
ish early in the 16th century, initial attempts
at colonizing Costa Rica proved unsuccess-
ful due to a combination of factors, including
diseasé from mosquito-infested swamps, brutal
heat, resistance by natives, and pirate raids.
it was not until 1563 that a permanent settle-
ment of Cartago was established in the cooler,
fertile central highlands. The area remained a
colony for some two and a half centuries. In
1821, Costa Rica became one of several Cen-
tral American provinces that jointly declared
their independence from Spain. Two years
later it joined the United Provinces of Cen-
tral America, but this federation disintegrated
in 1838, at which time Costa Rica proclaimed
its sovereignty and independence. Since the
late 19th century, only two brief periods of
violence have marred the country’s democratic
development. In 1949, Costa Rica dissolved its
armed forces. Although it still maintains a large
agricultural sector, Costa Rica has expanded
its economy to include strong technology and
tourism industries. The standard of living is
relatively high. Land ownership is widespread.
Background: Close ties to France following
independence in 1960, the development of
cocoa production for export, and foreign invest-
ment all made Cote d''Ivoire one of the most
prosperous of the West African states but did
not protect it from political turmoil. In Decem-
ber 1999, a military coup—the first ever in
178
Cote d”IvoireMs history—overthrew the gov-
ernment. Junta leader Robert GUEI blatantly
rigged elections held in late 2000 and declared
himself the winner. Popular protest forced him
to step aside and brought Laurent GBAGBO
into power. Ivorian dissidents and disaffected
members of the military launched a failed coup
attempt in September 2002 that developed into
a rebellion and then a civil war. The war ended
in 2003 with a cease fire that left the country
divided with the rebels holding the north, the
government the south, and peacekeeping forces
a buffer zone between the two. In March 2007,
President GBAGBO and former New Forces
rebel leader Guillaume SORO signed an agree-
ment in which SORO joined GBAGBO’s gov-
ernment as prime minister and the two agreed
to reunite the country by dismantling the buffer
zone, integrating rebel forces into the national
armed forces, and holding elections. Difficul-
ties in preparing electoral registers delayed bal-
loting until 2010. In November 2010, Alassane
Dramane OUATTARA won the presidential
election over GBAGBO, but GBAGBO refused
to hand over power; resulting in a five-month
stand-off. In April 2011, after widespread fight-
ing, GBAGBO was formally forced from office
by armed OUATTARA supporters with the
help of UN and French forces, Several thou-
sand UN peacekeepers and several hundred
French troops remain in Cote d''Ivoire to sup-
port the transition process. OUATTARA is
focused on rebuilding the country’s infrastruc-
ture and military after the five months of post-
electoral fighting and faces ongoing threats
from GBAGBO supporters, many of whom
have sought shelter in Ghana. GBAGBO is
in The Hague awaiting trial for crimes against
humanity.','c66a3cbbec701c505f6702eb9ef4d4c6742ca1330c831c0a473b99175209e406','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8aea97d0089f2aa67d4649712c4f5b9d19dad8d86f74e437d26f2a02ff210987',2025,'HR','Croatia','introduction',465,'Background: The lands that today comprise
Croatia were part of the Austro-Hungarian Empire
until the close of World War I. In 1918, the Cro-
ats, Serbs, and Slovenes formed a kingdom known
after 1929 as Yugoslavia. Following World War II,
Yugoslavia became a federal independent Commu-
nist state under the strong hand of Marshal TITO.
Although Croatia declared its independence from
Yugoslavia in 1991, it took four years of sporadic,
but often bitter, fighting before occupying Serb
armies were mostly cleared from Croatian lands,
along with a majority of Croatia’s ethnic Serb
population. Under UN supervision, the last Serb-
held enclave in eastern Slavonia was returned to
Croatia in 1998. In April 2009, Croatia joined
NATO; Croatia signed the EU Accession Treaty
in December 2011 and ratified the Treaty in Janu-
ary, 2012. Croatia will become a member after all
27 EU members ratify the treaty, with a target date
of July 2013.','8a57bbbe30eb225b7be7c5767a160be8b8db54148552dbacb270e00363dd6e14','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d8215c36d5c3158d44f9937cd054d846ed1c7e0cf40929002855e746c0d39c12',2025,'CU','Cuba','introduction',474,'Background: The native Amerindian popula-
tion of Cuba began to decline after the European
discovery of the island by Christopher COLUM-
BUS in 1492 and following its development as
a Spanish colony during the next several cen-
turies. Large numbers of African slaves were
imported to work the coffee and sugar planta-
tions, and Havana became the launching point
for the annual treasure fleets bound for Spain
from Mexico and Peru. Spanish rule eventually
provoked an independence movement and occa-
sional rebellions that were harshly suppressed.
US intervention during the Spanish-American
War in 1898 assisted the Cubans in overthrow-.
ing Spanish rule. The Treaty of Paris established
Cuban independence from the US in 1902 after
which the island experienced a string of govern-
ments mostly dominated by the military and
corrupt politicians. Fidel CASTRO led a-rebel
army to victory in 1959; his iron rule held the
subsequent regime together for nearly five dec-
ades. He stepped down as president in Febru-
ary 2008 in favor of his younger brother Raul
CASTRO. Cuba’s Communist revolution, with
Soviet support, was exported throughout Latin
America and Africa during the 1960s, 1970s,
and 1980s. The country faced a severe economic
downturn in 1990 follow ing the withdraw al of
former Soviet subsidies worth $4 billion to $6
billion annually, Cuba at times portrays the US
embargo, in place since 1961, as the source if its
difficulties. Illicit migration to the US—using
homemade rafts, alien smugglers, air flights, or
via the US''s southwest border—is a continuing
problem. The US Coast Guard interdicted 1,275
Cuban nationals attempting to cross the Straits
of Florida in 2012.
Background: A former British colony, Cyprus
became independent in 1960 following years of
resistance to British rule. Tensions between the
Greek Cypriot majority and Turkish Cypriot
minority came to a head in December 1963,
when violence broke out in the capital of Nico-
sia. Despite the deployment of UN peacekeep-
ers in 1964, sporadic intercommunal violence
continued forcing most Turkish Cypriots into
enclaves throughout the island. In 1974, a
Greek Government-sponsored attempt to seize
control of Cyprus was met by military inter-
vention from Turkey, which soon controlled
more than a third of the island. In 1983, the
Turkish Cypriot-occupied area declared itself
the “Turkish Republic of Northern Cyprus”
(“TRNC”), but it is recognized only by Tur-
key. The election of a new Cypriot president
in 2008 served as the impetus for the UN to
encourage both the Greek Cypriot and Turk-
ish Cypriot communities to reopen unification
negotiations. In September 2008, the leaders of
the two communities began discussions under
UN auspices aimed at reuniting the ‘divided
island. The talks are ongoing. The entire island
entered the EU on 1 May 2004, although the
EU acquis—the body of common rights and
obligations—applies only to the areas under
the internationally recognized government,
and is suspended in the areas administered by
Turkish Cypriots. However, individual Turkish
Cypriots able to document their eligibility for
Republic of Cyprus citizenship legally enjoy
the same rights accorded to other citizens of
European Union states.','f96cbc8ae0620ca64289a8c0ac650c2a4d0623bedd9099f816305531f092aec8','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('81518b39cb91b563f0585eefe9b589c5b6cd7ab916cd1a5e3e8ee1bd989bd1d0',2025,'DK','Denmark','introduction',502,'Background: By terms of the 1960 Treaty of Estab-
lishment that created the independent Republic of
Cyprus, the UK retained full sovereignty and juris-
diction over two areas of almost 254 square kilom-
eters—Akrotiri and Dhekglia. The larger of these
is the Dhekelia Sovereign Base Area, which is also
referred to as the Eastern Sovereign Base Area.
Background: Carib Indians inhabited Grenada
when Christopher COLUMBUS discovered
the island in 1498, but it remained uncolonized
for more than a century. The French settled
Grenada in the 17th century, established sugar
estates, and imported large numbers of African
slaves. Britain took the island in 1762 and vig-
orously expanded sugar production. In the 19th
century, cacao eventually surpassed sugar as the
main export crop; in the 20th century, nutmeg
became the leading export. In 1967, Britain
gave Grenada autonomy over its internal affairs.
Full independence was attained in 1974 making
Grenada one of the smallest independent coun-
tries in the Western Hemisphere. Grenada was
seized by a Marxist military council on 19 Octo-
ber 1983. Six days later the island was invaded
by US forces and those of six other Caribbean
nations, which quickly captured the ringleaders
and their hundreds of Cuban advisers. Free elec-
tions were reinstituted the following year and
have continued since that time. Hurricane Ivan
struck Grenada in September of 2004 causing
severe damage.
294','11acd7f59776cb837ef8f079d64f9e693bf51674e339c31420409ad09ca50326','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e89896b3381c1b2f225584ece6c2e94fa9c4b772b54d5d03c2b1353af9ba9045',2025,'DJ','Djibouti','introduction',504,'Background: The French Territory of the Afars
and the Issas became Djibouti in 1977. Hassan
Gouled APTIDON installed an authoritarian
one-party state and proceeded to serve as presi-
dent until 1999. Unrest among the Afar minor-
ity during the 1990s led to a civil war that ended
in 2001 with a peace accord between Afar rebels
and the Somali Issa-dominated government.
In 1999, Djibouti’s first multiparty presidential
elections resulted in the election of Ismail Omar
GUELLEH as president; he was reelected to a
second term in 2005 and extended his tenure in
office via a constitutional amendment, which
allowed him to begin a third term in 2011. Dji-
bouti occupies a strategic geographic location at
the intersection of the Red Sea and the Gulf of
Aden and serves as an important shipping portal
for goods entering and leaving the east African
highlands and transshipments between Europe,
the Middle East, and Asia. The government holds
longstanding ties to France, which maintains a
significant military presence in the country, and
has strong ties with the United States. Djibouti
hosts several thousand members of US armed ser-
vices at US-run Camp Leménnier.','eda8257ee7e1a533a7133b7eba8bca311e41de991e6bedc3c9ef811e76c40578','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a3eaf81217e960bf8d102e881ef9ea8a8e6964f1bbebc8ce6aa7c79dcb73db21',2025,'DM','Dominica','introduction',516,'Background: Dominica was the last of the Car-
ibbean islands to be colonized by Europeans due
chiefly to the fierce resistance of the native Car-
ibs. France ceded possession to Great Britain in
1763, which made the island a colony in 1805. In
1980, two years after independence, Dominica''s
fortunes improved when a corrupt and tyranni-
cal administration was replaced by that of Mary
Eugenia CHARLES, the first female prime min-
ister in the Caribbean, who remained in office
for 15 years. Some 3,000 Carib Indians still liv-
ing on Dominica are the only pre-Columbian
population remaining in the eastern Caribbean.
206','9870cc4148744e549cce75c3687b736a20fb9b47ae71924dfd045c7d7e23369d','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('61f5786e629bc5a9eb5342f8ecaaa7eaee70ccb7112dbda26ea8065dd8eb8d59',2025,'DO','Dominican Republic','introduction',526,'Background: The Taino—indigenous inhabitants
of Hispaniola prior to the arrival of the Europe-
ans—divided the island into five chiefdoms and
territories. Christopher COLUMBUS explored and
claimed the island on his first voyage in 1492; it
became a springboard for Spanish conquest of the
Caribbean and the American mainland. In 1697,
Spain recognized French dominion over the western
third of the island, which in 1804 became Haiti. The
remainder of the island, by then known as Santo
Domingo, sought to gain its own independence in
1821 but was conquered and ruled by the Haitians
for 22 years; it finally attained independence as the
Dominican Republic in 1844. In 1861, the Domini-
cans voluntarily returned to the Spanish Empire,
but two years later they launched a war that restored
independence in 1865. A legacy of unsettled, mostly
non-representative rule followed, capped by the dic-
tatorship of Rafael Leonidas TRUJILLO from 1930
to 1961. Juan BOSCH was elected president in
1962 but was deposed in a military coup in 1963. In
1965, the United States led an intervention in the
midst of a civil war sparked by an uprising to restore
BOSCH. In 1966, Joaquin BALAGUER defeated
BOSCH in an election to become president. BAL-
AGUER maintained a tight grip on power for most
of the next 30 years when international reaction
to flawed elections forced him to curtail his term
in 1996. Since then, regular competitive elections
have been held in which opposition candidates
have won the presidency. Former President Leonel
FERNANDEZ Reyna (first term 1996-2000) won
election to a new term in 2004 following a constitu-
tional amendment allowing presidents to serve more
than one term, and was since reelected to a second
consecutive term.
Background: What is now Ecuador formed part
of the northern Inca Empire until the Spanish
conquest in 1533. Quito became a seat of Span-
ish_celonial government in 1563 and part of
the Viceroyalty of New Granada in 1717. The
territories of the Viceroyalty—New Granada
(Colombia), Venezuela, and Quito—gained
. their independence between 1819 and 1822 and
formed a federation known as Gran Colombia.
When Quito withdrew in 1830, the traditional
name was changed in favor of the “Republic of
the Equator.” Between 1904 and 1942, Ecuador
lost territories in a series of conflicts with its
neighbors. A border war with Peru that flared in
1995 was resolved in 1999. Although Ecuador
marked 30 years of civilian governance in 2004,
the period was marred by political instability. Pro-
tests in Quito contributed to the mid-term ouster
of three of Ecuador''s last four democratically
elected Presidents. In late 2008, voters approved
a new constitution, Ecuador’s 20th since gaining
independence. General elections were held in
February 2013, and voters re-elected President
Rafael CORREA.
Location: Western South America, bordering the
Pacific Ocean at the Equator, between Colombia
and Peru Far:
Geographic coordinates: 2 00 S, 77 30 W
Map references: South America
Area: total: 283,561 sq km
country comparison to the world: 74
land: 276,841 sq km
water: 6,720 sq km
note: includes Galapagos Islands
Area—comparative: lightly smaller than
Nevada
Land boundaries: total: 2,010 km
border countries: Colombia 590 km, Peru
1,420 km
. Coastline: 2,237 km
Maritime claims: territorial sea: 200 nm
continental shelf: 100 nm from 2,500-m isobath
Climate: tropical along coast, becoming cooler
inland at higher elevations; tropical in Amazonian
jungle low lands
Terrain: coastal plain (costa), inter-Andean cen-
tral highlands (sierra), and flat to rolling eastern
jungle (oriente)
Elevation extremes: lowest point: Pacific Ocean
Om
highest point: Chimborazo 6,267 m
note: due to the fact that the earth is not a per-
fect sphere and has an equatorial bulge, the high-
est point on the planet furthest from its center is
Mount Chimborazo not Mount Everest, which is
merely the highest peak above sea-level
Natural resources: petroleum, fish,
hydropower
Land use: arable land: 4.51%
permanent crops: 5.38%
other: 90.11% (2011)
Irrigated land: 8,534 sq km (2003)
Total renewable water resources: 424.4 cu km
(2011) :
Freshwater withdrawal (domestic/industrial/
agricultural): total: 9.92 cu km/yr (13%/6%/81%)
per capita: 716.1 cu m/yr (2005)
Natural hazards: frequent earthquakes; land-
slides; volcanic activity; floods; periodic droughts
volcanism: volcanic activity concentrated along
the Andes Mountains; Sangay (elev. 5,230 m),
which erupted in 2010, is mainland Ecuador''s
most active volcano; other historically active vol-
canoes in the Andes include Antisana, Cayambe,
Chacana, Cotopaxi, Guagua Pichincha, Reventa-
dor, Sumaco, and Tungurahua; Fernandina (elev.
1,476 m), a shield volcano that last erupted in
2009, is the most active of-the many Galapagos
volcanoes; other historically active Galapagos
volcanoes include Wolf, Sierra Negra, Cerro Azul,
Pinta, Marchena, and Santiago
Environment—current issues: deforestation;
soil erosion; desertification; water pollution; pol-
lution from oil production wastes in ecologically
sensitive areas of the Amazon Basin and Galapagos
Islands
Environment—international agreements:
party to: Antarctic-Environmental Protocol,
Antarctic Treaty, Biodiversity, Climate Change,
Climate Change-Kyoto Protocol, Desertification,
Endangered Species, Hazardous Wastes, Ozone
Layer Protection, Ship Pollution, Tropical Timber
83, Tropical Timber 94, Wetlands
signed, but not ratified: none of the selected
agreements
Geography—note: Cotopaxi in Andes is highest
active volcano in world','f245e7c8c0bfa47ea9f4c251ad9c4c6cedf3a6429077a89ca42e25509bb403b1','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bb583df981621437b78874f400b877f421a3cec65ae958518ef63aab44bfaf5b',2025,'EC','Ecuador','introduction',540,'Background: The regularity and richness of the
apnual Nile River flood, coupled with semi-iso-
lation provided by deserts to the east and west,
allowed for the development of one of the world’s
great civilizations. A unified kingdom arose circa
3200 B.C., and a series of dynasties ruled in Egypt
for the next three millennia. The last native
dynasty fell to the Persians in 341 B.C., who in
turn were replaced by the Greeks, Romans, and
Byzantines. It was the Arabs who introduced
Islam and the Arabic language in the 7th cen-
tury and who ruled for the next six centuries. A
local military caste, the Mamluks took control
about 1250 and continued to govem after the
conquest of Egypt by the Ottoman Turks in 1517.
Completion of the Suez Canal in 1869 elevated
Egypt as an important world transportation hub.
Ostensibly to protect its investments, Britain
seized control of Egypt’s govemment in 1882, but
nominal allegiance to the Ortoman Empire con-
tinued until 1914. Partially independent from the
UK in 1922, Egypt acquired full sovereignty from
Britain in 1952. The completion of the Aswan
High Damin 1971 and the resultant Lake Nasser
have altered the time-honored place of the Nile
River in the agriculture and ecology of Egypt. A
rapidly growing population (the largest in the
Arab world), limited arable land, and dependence
on the Nile all continue to overtax resources and
stress society. The government has struggled to
meet the demands of Egypt’s population through
economic reform and massive investment in com-
munications and physical infrastructure. Inspired
by the 2010 Tunisian revolution, Egyptian opposi-
tion groups led demonstrations and labor strikes
countrywide, culminating in President Hosni
MUBARAK’s ouster. Egypt’s military assumed
national. leadership until a new parliament was in
place in early 2012. The same year Muslim Broth-
ethood candidate, Mohammed MURSI, won the
presidential election and a new constitution was
affirmed.','24086f34e4002bad2f0d8e188f0cc4efc7299d122447b7dbf024b7527d2d2701','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('74e0052bb7b25cc0995937ba1019483cf0c813d91faf9f59a1e5fbbe42415bf5',2025,'GT','Guatemala','introduction',553,'Background: El Salvador achieved independence
from Spain in 1821 and from the Central Ameri-
can Federation in 1839. A 12-year civil war, which
cost about 75,000 lives, was brought to a close
in 1992 when the government and leftist rebels
signed a treaty that provided for military and
political reforms.
Background: The Maya civilization flourished in
Guatemala and surrounding regions during the first
millennium A.D. After almost three centuries as a
Spanish colony, Guatemala won its independence
in 1821. During the second half of the 20th cen-
tury, it experienced a variety of military and civil-
ian governments, as well as a 36-year guerrilla war.
In 1996, the government signed a peace agreement
formally ending the conflict, which had left more
than 200,000 people dead and had created, by some
estimates, some | million refugees. In January 2012,
Guatemala assumed a nonpermanent seat on the
UN Security Council for the 2012-13 term.','3b028aba1ef7706bd31ad693d7a78e943ad06dce1e62c79737763468396e85ce','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a953cbb4abd5f6ec15af11a3a7a4cc3d06b47b46d861e4638f137d7aadf133bd',2025,'GQ','Equatorial Guinea','introduction',569,'Background: The UN established Eritrea as an
autonomous region within the Ethiopian federa-
tion in 1952. Ethiopia’s full annexation of Eritrea
as a province 10 years later sparked a violent
30-year struggle for independence that ended, in
1991 with Eritrean rebels defeating government
forces. Eritreans overwhelmingly approved inde-
pendence in a 1993 referendum. ISAIAS Afworki
has been Eritrea’s only president since independ-
ence; his rule, particularly since 2001, has been
highly autocratic and repressive. His government
has created a highly militarized society by pursu-
ing an unpopular program of mandatory conscrip-
tion into national service, sometimes of indefinite
length. A two-and-a-half-year border war with
Ethiopia that erupted in 1998 ended under UN
auspices in December 2000. The Eritrea-Ethiopia
Boundary Commission (EEBC) created in April
2003 was tasked “to delimit and demarcate the
colonial treaty border based on pertinent colonial
treaties (1900, 1902, and 1908) and applicable
international law.” Eritrea for several years hosted
a UN peacekeeping operation that monitored a ,
25 km-wide Temporary Security Zone. The EEBC
on 30 November 2007 remotely demarcated the
border, assigning the town of Badme to Eritrea,
despite Ethiopia''s. maintaining forces there from
the time of the 1998-2000 war. An increasingly
hostile Eritrea insisted that the UN terminate its
peacekeeping mission on 31 July 2008. Eritrea has
accepted the EEBC’s “virtual demarcation” deci-
sion and repeatedly called on Ethiopia to remové
its troops. Ethiopia has not accepted the demarca-
tion decision, and neither party has entered into
meaningful dialogue to resolve the impasse. Eritrea
is subject to several UN Security Council Resolu-
tions (from 2009, 2011, and 2012) imposing vari-
ous military and economic sanctions, in view of
evidence that it has supported armed opposition
groups in the region.','42fa052340931ed60ce0c22cdd07cf572309de5a579910bfd44d423cc3cab806','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('181a128650088184fdfe350c98ca9429b5e4d38cb3b317abca0244fdd30aa4dc',2025,'ER','Eritrea','introduction',577,'Background: After centuries of Danish, Swedish,
German, and Russian rule, Estonia attained inde-
pendence in 1918. Forcibly incorporated into the
USSR in 1940—an action never recognized by the
US—it regained its freedom in 1991 with the col-
lapse of the Soviet Union. Since the last Russian
troops left in 1994, Estonia has been free to pro-
mote economic and political ties with the West.
It joined both NATO and the EU in the spring
of 2004, formally joined the OECD in late 2010,
and adopted the euro as its official currency on 1
January 2011.','adc95113dcb13f7e80dd40cf647d507714ba9584cfef85a61ed3da166197192a','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('46b569ec877b0dd7b6eb420b4ef8aa43e0469dbae37a79bc09e3432fb627ba95',2025,'EE','Estonia','introduction',587,'Background: Unique among African countries,
the ancient Ethiopian monarchy maintained its
freedom from colonial rule with the exception of
a short-lived Italian occupation from 1936-41. In
1974, a military junta, the Derg, deposed Emperor
Haile SELASSIE (who had ruled since 1930)
and established a socialist state. Torn by bloody
coups, uprisings, wide-scale drought, and massive
refugee problems, the regime was finally toppled
in 1991 by a coalition of rebel forces, the Ethio-
pian People’s Revolutionary Democratic Front
(EPRDF). A constitution was adopted in 1994,
and Ethiopia’s first multiparty elections were
held in 1995. A border war with Eritrea late in
the 1990s ended with a peace treaty in December
2000. In November 2007, the Eritrea-Ethiopia
Border Commission(EEBC) issued specific coor-
dinates as virtually demarcating the border and
pronounced its work finished. Alleging that the
EEBC acted beyond its mandate in issuing the
coordinates, Ethiopia has not accepted them and
has not withdrawn troops from previously con-
tested areas pronounced by the EEBC as belong-
ing to Eritrea.','b42b6a32a8ce023f351eb0c7c6cead280727197f545788204c77c291bae0a287','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a4bf82b254919abb591553306ce9b81d7bcb5f5b8c5657afe3ae8e4ef7982d38',2025,'ET','Ethiopia','introduction',594,'Preliminary statement: The evolution of
what is today the European Union (EU) from a
regional economic agreement among six neigh-
boring states in 1951 to today’s hybrid inter-
governmental and supranational organization
of 27 countries across the European continent
stands as an unprecedented phenomenon in the
‘annals of history. Dynastic unions for territorial
consolidation were long the norm in Europe;
on a few occasions even country-level unions
were arranged—the Polish-Lithuanian Com-
monwealth and the Austro-Hungarian Empire
were examples. But for such a large number of
nation-states to cede some òf their sovereignty
to an overarching entity is unique. Although
the EU is not a federation in the strict sense,
it is far more than a free-trade association such
as ASEAN, NAFTA, or Mercosur, and it has
certain attributes associated with independent
nations: its own flag, currency (for some mem-
bers), and law-making abilities, as well as dip-
lomatic representation and a common foreign
and security policy in its dealings with external
partners. Thus, inclusion of basic intelligence
on the EU has been deemed appropriate as a
new, separate entity in The World Factbook.
However, because of the EU’s special status, this
description is placed after the regular country
entries.
Background: «Following the two devastating
World Wars in the first half of the 20th century,
a number of European leaders in the late 1940s
became convinced that the only way to establish
a lasting peace was to reconcile the two chief
belligerent nations—France and Germany—
both economically and politically. In 1950, the
French Foreign Minister Robert SCHUMAN
proposed an eventual union of all Europe, the
first step of which would be the integration of
the coal and steel industries of Western Europe.
The following year, the European Coal and Steel
Community (ECSC) was set up when six mem-
bers, Belgium, France, West Germany, Italy,
Luxembourg, and the Netherlands, signed the
Treaty of Paris.
The ECSC was so successful that within a few
years the decision, was made to integrate other
elements of the countries’ economies. In 1957,
envisioning an “ever closer union,” the Treaties
of Rome created the European Economic Com-
munity (EEC) and the European Atomic Energy
Community (Euratom), and the six member states
undertook to eliminate trade barriers among them-
selves by forming a common market. In 1967, the
institutions of all three communities were formally
merged into the European Community (EC),
creating a single Commission, a single Council
of Ministers, and the body known today as the
European Parliament. Members of the European
‘Parliament were initially selected by national
parliaments, but in 1979 the first direct elections
were undertaken and have been held every five
years since.
In 1973, the first enlargement of the EC took
place with the addition of Denmark, Ireland,
and the United Kingdom. The 1980s saw fur-
ther membership expansion with Greece join-
ing in 1981 and Spain and Portugal in 1986.
The 1992 Treaty of Maastricht laid the basis
for further forms of cooperation in foreign and
defense policy, in judicial and internal affairs,
and in the creation of an economic and mon-
etary union—including a common. currency.
This further integration created the European
Union (EU), at the time standing alongside
the European Community. In 1995, Austria,
Finland, and Sweden joined the EU/EC, raising
the membership total to 15.
A new currency, the euro, was launched in
world money markets on 1 January 1999; it
became the unit of exchange for all EU member
states except Denmark, Sweden, and the United
Kingdom. In 2002, citizens of those 12 coun-
tries began using euro banknotes and coins. Ten
new countries joined the EU in 2004—Cyprus,
the Czech Republic, Estonia, Hungary, Latvia,
Lithuania, Malta, Poland, Slovakia, and Slove-
nia—and in 2007 Bulgaria and Romania joined,
bringing the membership to 27, where it stands
today.
In an effort to ensure that the EU could func-
tion efficiently with an expanded membership,
the Treaty of Nice (signed in 2000) set forth
rules aimed at streamlining the size and proce-
dures of EU institutions. An effort to establish
a “Constitution for Europe,” growing out of a
Convention held in 2002-2003, foundered when
it was rejected in referenda in France and the
Netherlands in 2005. A subsequent effort in 2007
incorporated many of the features of the rejected
Constitution while also making a number of sub-
stantive and symbolic changes. The new treaty,
initially known as the Reform Treaty but subse-
quently referred to as the Treaty of Lisbon, sought
to amend existing treatiest rather than replace
them. The treaty was approved at the EU inter-
governmental conference of the 27 member states
held in Lisbon in December 2007, after which
the process of national ratifications began. In
October 2009, an Irish referendum approved the
Lisbon Treaty (overturning a previous rejection)
and cleared the way for an ultimate unanimous
endorsement. Poland and the Czech Republic
signed on soon after. The Lisbon Treaty, again
invoking the idea of an “ever closer union,” came
into force on 1 December 2009 and the European
Union officially replaced and succeeded the Euro-
pean Community.
Background: Although first sighted by an English
navigator in 1592, the first landing (English) did
not occur until almost a century later in 1690, and
the first settlement (French) was not established
until 1764. The colony was tumed over to Spain
two years later and the islands have since been the
subject of a territorial dispute, first between Britain
and Spain, then between Britain and Argentina.
The UK asserted its claim to the islands by estab-
lishing a naval garrison there in 1833. Argentina
invaded the islands on 2 April 1982. The Brit-
ish responded with an expeditionary force that
landed seven weeks later and after fierce fighting
forced an Argentine surrender on 14 June 1982.
With hostilities ended and Argentine forces with-
drawn, UK administration resumed. In response
to renewed calls from Argentina for Britain to
relinquish control of the islands, a referendum was
held in March 2013, which resulted in 99.8% of
the population voting to remain a part of the UK.
Background: Britain withdrew from British
Somaliland in 1960 to allow its protector-
ate to join with Italian Somaliland and form
the new nation of Somalia. In 1969, a coup
headed by Mohamed SIAD Barre ushered in
an authoritarian socialist rule characterized by
the persecution, jailing, and torture of politi-
cal opponents and dissidents. After the regime’s
collapse early in 1991, Somalia descended into
turmoil, factional fighting, and anarchy. In May
1991, northern clans declared an independent
Republic of Somaliland that now includes the
administrative regions of Awdal, Woqooyi Gal-
beed, Togdheer, Sanaag, “and Sool. Although
not recognized by any government, this entity
has maintained a stable existence and continues
efforts to establish a constitutional democracy,
including holding municipal, parliamentary,
and presidential elections. The regions of Bari,
Nugaal, and northern Mudug comprise a neigh-
boring semi-autonomous state of Puntland,
which has been self-governing since 1998 but
does not aim at independence; it has also made
strides toward reconstructing a legitimate, rep-
resentative government but has suffered some
civil strife. Puntland disputes its border with
Somalilard as it,also claims portions of eastern
Sool and Sanaag. Beginning in 1993, a two-year
UN humanitarian effort (primarily in the south)
was able to alleviate famine conditions, but
when the UN withdrew in 1995, having suffered
significant casualties, order still had not been
restored. In 2000, the Somalia National Peace
Conference (SNPC) held in Djibouti resulted
in the formation of an interim government,
known as the Transitional National Govern-
ment (TNG). When the TNG failed to establish
+
adequate security or governing institutions, the
Goyernment of Kenya, under the auspices of
the Intergovernmental Authority on Develop-
ment (IGAD), led a subsequent peace process
that concluded in October 2004 with the elec-
tion of Abdullahi YUSUF Ahmed as President
of a second interim government, known as
the Transitional Federal Government (TFG)
of the Somali Republic. The TFG included a
275-member parliamentary body, known as the
Transitional Federal Parliament (TFP). Presi-
dent YUSUF resigned late in 2008 while United
Nations-sponsored talks between the TFG and
the opposition Alliance for the Re-Liberation of
Somalia (ARS) were underway in Djibouti. In
January 2009, following the creation of a TFG-
ARS unity government, Ethiopian military
forces, which had entered Somalia in December
2006 to support the TFG in the face of advances
by the opposition Islamic Courts Union (ICU),
withdrew from the country. The TFP was dou-
bled in size to 550 seats with the addition of
200 ARS and 75 civil society members of parlia-
ment. The expanded parliament elected Sheikh
SHARIF Sheikh Ahmed, the former ICU and
ARS chairman as president in January 2009,
The creation of the TFG was based on the Tran-
sitional Federal Charter (TFC), which outlined
a five-year mandate leading to the establishment
of a new Somali constitution and a transition to
a representative government following national
elections. In 2009, the TFP amended the TFC to
extend TFG’s mandate until 2011 and in 2011
Somali principals agreed to institute political
transition by August 2012. The transition pro-
cess ended in September 2012 when clan elders
appointed 275 members to a new parliament
replacing the TFP and the subsequent election,
by parliament, of a new president.','0615decb407943be427892c10ab98076c4c4159af427479d986d67fea91e1e3e','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ba5cd7bd042397dca26b25dbf099cf0e3c6f3af04f9d336ce38029b3e6f19453',2025,'FO','Faroe Islands','introduction',597,'Background: The population of the Faroe Islands
is largely descended from Viking settlers who
arrived in the 9th century. The islands have been
connected politically to Denmark since the 14th
century. A high degree of self-government was
granted the Faroese in 1948, who have autonomy
over most intemal affairs while Denmark is respon-
sible for justice, defense, and foreign affairs. The
Faroe Islands are not part of the European Union.
GEOGRAPHY T
Location: Northern Europe, island group between
the Norwegian Sea and the North Atlantic Ocean,
about half way between Iceland and Norway
Geographic coordinates: 62 00 N, 700 W
Map references: Europe
Area: total: 1,393 sq km
country comparison to the world: 183
land: 1,393 sq km
water: 0 sq km (some lakes and streams)
Area—comparative: eight times the size of
Washington, DC t
Land boundaries: 0 km
Coastline: 1,117 km
Maritime claims: territorial sea: 3 nm
continental shelf: 200 nm or agreed boundaries or
median line
exclusive fishing zone: 200 nm or agreed bounda-
ries or median line
Climate: mild winters, cool summers; usually
overcast; foggy, windy
Terrain: rugged, rocky, some low peaks; cliffs along
most of coast
Elevation extremes: lowest point: Atlantic
Ocean 0m
highest point: Slaettaratindur 882 m
Natural resources: fish, whales, hydropower, pos-
sible oil and gas
Land use: arableland:2.15% _
permanent crops: 0%
other: 97.85% (2011)
Irrigated land: 0 sq km (2011)
Natural hazards: NA
Environment—current issues: NA
246
Environment—international agreements:
party to: Marine Dumping—associate member to
the London Convention and Ship Pollution
Geography—note: archipelago of 17 inhabited
islands and one uninhabited island, and a few unin-
habited islets; strategically located alorig important
sea lanes in northeastern Atlantic; precipitous ter-
rain limits habitation to small coastal low lands','fe9362ea9b8f568a77a4b9cf153f29759af266ad14b069b0542dbe30cab41fbf','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9c126755212a33d2e7330f10e09665a1e6fd40e24a03343ee206514e75c94413',2025,'JE','Jersey','introduction',602,'Land boundaries: 0 km
Coastline: 1,129 km
Maritime claims: méasured from claimed archi-
pelagic straight baselines
territorial sea: 12 nm
exclusive economic zone: 200 nm
continental shelf: 200 m depth or to the depth of
exploitation; rectilinear shelf claim added
Climate: tropical marine; only slight seasonal
temperature variation
Terrain: mostly mountains of volcanic origin
Elevation extremes: lowest point: Pacific Ocean
Om
highest point: Tomanivi 1,324 m
Natural resources: timber, fish, gold, copper, off-
shore oil potential, hydropower
Land use: arable land:9.17%
permanent crops: 4.65%
other: 86.17% (2011)
Irrigated land: 30 sq km (2003)
Total renewable water resources: 28.55 cu km
(2011)
Freshwater withdrawal (domestic/indus-
triaV/agricultural): total: 0.08 cu kmj/yr
(30%/11%/59%)
per capita: 100.1 cu m/yr (2005)
Natural hazards: cyclonic storms can occur from
November to January
Environment—current
soil erosion
Environment—international ` agreements:
party to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Endan-
gered Species, Law of the Sea, Marine Life Conser-
vation, Ozone Layer Protection, Tropical Timber
83, Tropical Timber 94, Wetlands
signed, but not ratified: none of the selected
agreements
issues: deforestation:
Geography—note: includes 332 islands; approxi-
mately 110 are inhabited
Background: Jersey and the other Channel Islands
represent the last remnants of the medieval Duke-
dom of Normandy that held sway in both France
and England. These islands were the only British
soil occupied by German troops in World War II.
Jersey is a British crown dependency but is not part
of the UK or of the European Union. However, the
UK Government is constitutionally responsible for
its defense and international representation.
Land boundaries: total: 1,086 km
border countries: Austria 330 km, Croatia 455
km, Hungary 102 km, Italy 199 km
Coastline: 46.6 km
Maritime claims: territorial sea: 12 nm
Climate: Mediterranean climate on the coast,
continental climate with mild to hot summers and
cold winters in the plateaus and valleys to the east
Terrain: a short coastal strip on the Adriatic, an
alpine mountain region adjacent to Italy and Aus-
tria, mixed mountains and valleys with numerous
rivers to the east
Elevation extremes: lowest point: Adriatic Sea
Om
highest point: Triglav 2,864 m
Natural resources: lignite coal, lead, zinc, build-
ing stone, hydropower, forests
Land use: arable land: 8.31%
permanent crops: 1.33%
other: 90.36% (2011)
Irrigated land: 76.04 sq km (2010)
Total renewable water resources: 31.87 cu km
(2011)
Freshwater withdrawal (domestic/industrial/
agricultural): total:0.94 cu km/yr (18%/82%/0%)
per capita: 462.9 cu m/yr (2009) :
Natural hazards: flooding; earthquakes
Environment—current issues: Sava River pol-
luted with domestic and industrial waste; pollu-
tion of coastal waters with heavy metals and toxic
chemicals; forest damage near Koper from air pol-
lution (originating at metallurgical and chemical
plants) and resulting acid rain
Environment—international agreements:
party to: Air Pollution, Air Pollution-Nitrogen
Oxides, Air Pollution-Persistent Organic Pollut-
ants, Air Pollution-Sulfur 94, Biodiversity, Cli-
mate Change, Climate Change-Kyoto Protocol,
Desertification, Endangered Species, Environmen-
tal Modification, Hazardous Wastes, Law of the
Sea, Marine Dumping, Ozone Layer Protection,
Ship Pollution, Wetlands, Whaling
signed, but not ratified: none of the selected
agreements
Geography—note: despite its small size, this
eastern Alpine country controls some of Europe’s
major transit routes
Background: A military power during the 17th
century, Sweden has not participated in any war
for almost two centuries. An armed neutrality
was preserved in both world wars. Sweden’s
long-successful economic formula of a capital-
ist system interlarded with substantial welfare
elements. was challenged in the 1990s by high
unemployment and in 2000-02 and 2009 by
the global economic downturns, but fiscal dis-
cipline over the past several years has allowed
the country to weather economic vagaries.
Sweden joined the EU in 1995, but the public
Kd
SWAZILAND
country comparison to the world: 160
paved: 1,078 km
unpaved; 2,516 km (2002)','c00509ab5e6115daee727710bc5931b42cf48b9e4fd1cb20aeb8059a0172d2c8','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cfbeb832af56107f2a90545947755050ff2d6ba6781d597fbfa424662523a64f',2025,'FJ','Fiji','introduction',610,'Background: Finland was a province and then a
grand duchy under Sweden from the 12th to the
19th centuries, and an autonomous grand duchy
of Russia after 1809. It won its complete independ-
ence in 1917. During World War II, it was able to
successfully defend its freedom and resist invasions
by the Soviet Union—albeit with some loss of ter-
ritory. In the subsequent half century, the Finns
made a remarkable transformation from a farm/
forest economy to a diversified modern industrial
economy; per capita income is now among the
highest in Western Europe. A member of the
European Union since 1995, Finland was the only
Nordic state to join the euro system at its initiation
in January 1999. In the 21st century, the key fea-
tures of Finland”s modern*welfare state are a high
standard of education, equality promotion, and
national social security system—currently chal-
lenged by an aging population and the fluctuations
of an export-driven economy.','3aa32302c9203f7060edaa98ca8d7e9e620635a0aa5d85b54c211924b4d5bb59','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('df18eed2868d631d126e64011f59ca8f925cda744375f9bcff939aed988ff425',2025,'PF','French Polynesia','introduction',626,'Background: The French annexed various Polyne-
sian island groups during the 19th century. In Sep-
tember 1995, France stirred up widespread protests
by resuming nuclear testing on the Mururoa atoll
after a three-year moratorium. The tests were halted
in January 1996. In recent years, French Polynesia”s
autonomy has been considerably expanded.
Geography: FRENCH POLYNESIA Location:
Oceania, five archipelagoes (Archipel Des Tua-
motu, Iles Gambier, Iles Marquises, Iles Tubuai,
Society Islands) in the South Pacific Ocean about
half way between South America and Australia
Geographic coordinates: 15 00 S, 14000 W
Map references: Oceania
Area: total: 4,167 sq km (118 islands and atolls)
country comparison to the world: 175
land: 3,827 sq km
water: 340 sq km
Area—comparative: slightly less than one-third
the size of Connecticut
Lond boundaries: 0 km
Coastline: 2,525 km
Maritime claims: territorial sea: 12 nm
exclusive economic zone: 200 nm
Climate: tropical, but moderate
Terrain: mixture of rugged high islands and low
islands with reefs Elevation extremes: lowest point:
260
Pacific Ocean 0 m highest point: Mont Orohena
2,241 m f
Natural resources: timber, fish, cobalt,
hydropower
Land use: arable land: 0.68% permanent crops:
6.28% other: 93.03% (2011)
Irrigated land: 10 sq km (2003)
Natural hazards: occasional cyclonic storms
in January
Environment—current issues: NA
Geography—note: includes five archipelagoes
(four volcanic, one coral); Makatea in French
Polynesia is one of the three great phosphate
rock islands in the Pacific Ocean—the others are
Banaba (Ocean Island) in Kiribati and Nauru','408616b33851a36c2c7edc24a6807cd7347d39b0ffbb52abe816361c79f95874','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('eba1f30716c30434152d3369e1e51192e4ca5acc3b90e1b6d14b0a718c5def04',2025,'MU','Mauritius','introduction',635,'Background: El Hadj Omar BONGO Ondimba—
one of the longest-serving heads of state in the
world—dominated the country’s political scene for
four decades ( 1967-2009) following independence
from France in 1960. President BONGO intro-
duced a nominal multiparty system and a new con-
stitution in the early 1990s. However, allegations
of electoral fraud during local elections in 2002-03
and the presidential elections in 2005 exposed the
weaknesses of formal political structures in Gabon.
Following President BONGO''s death in 2009, new
elections brought Ali BONGO Ondimba, son
of the former president, to power. Despite con-
strained political conditions, Gabon’s small popu-
lation, abundant natural resources, and consider-
able foreign support have helped make it one of
the more prosperous and stable African countries.
Background: The site of several advanced Amer-
indian civilizations—including the Olmec, Toltec,
Teotihuacan, Zapotec, Maya, and Aztec—Mexico
was conquered and colonized by Spain in the early
16th century. Administered as the Viceroyalty
of New Spain for three centuries, it achieved its
478
THE CIA WORLD FACTBOOK
country comparison to the world: 171
Carbon dioxide emissions from consumption
of energy: 4.545 million Mr (2010 est.)
country comparison to the world: 12','7bae0a100ae6b6a128bb2539fb4dfea4e08a19cb6d315334827ba305424312e2','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fd43856280ecc9bae22c3cb28d93cf3de0d3fc9dc9c7ac4e16803dd239f6112a',2025,'SN','Senegal','introduction',646,'Background: The Gambia gained its independ-
ence from the UK in 1965. Geographically sur-
rounded by Senegal, it formed a short-lived
federation of Senegambia between 1982 and
1989. In 1991 the two nations signed a friend-
ship and cooperation treaty, but tensions have
flared up intermittently since then. Yahya JAM-
MEH led a military coup in 1994 that overthrew
the president and banned political activity. A
new constitution and presidential elections in
1996, followed by parliamentary balloting in
1997, completed a nominal return to civilian
rule. JAMMEH has been elected president in all
subsequent elections including most recently in
late 2011.
Background: Inhabited since at least the 15th
century B.C., Gaza has been dominated by many
different peoples and empires throughout its his-
tory; it was incorporated into the Ottoman Empire
in the early 16th century. Gaza fell to British forces
during World War I, becoming a part of the British
Mandate of Palestine. Following the 1948 Arab-
Israeli War, Egypt administered the newly formed
Gaza Strip; it was captured by Israel in the Six-Day
War with Egypt in 1967, and later transferred to
the Palestinian National Authority. Under a series
of agreements signed between 1994 and 1999,
Israel transferred to the Palestinian Authority
(PA) security and civilian responsibility for many
Palestinian-populated areas of the Gaza Strip as
well as the West Bank. Negotiations to determine
the permanent status of the-West Bank and Gaza
Strip stalled after the outbreak of an intifada in
mid-2000. In early 2003, the “Quartet” of the
US, EU, UN, and Russia, presented a roadmap to
a final peace settlement by 2005, calling for two
states—Israel and a democratic Palestine. Fol-
lowing Palestinian leader Yasir ARAFAT''s death
in late 2004 and the subsequent election of Mah-
mud ABBAS (head of the Fatah political party)
as the PA president, Israel and the PA agreed to
move the peace process forward. Israel in late 2005
unilaterally withdrew all of its settlers and soldiers
and dismantled its military facilities in the Gaza
Strip, but continues to control maritime, airspace,
and other access. In early 2006, the Islamic Resist-
ance Movement, HAMAS, won the Palestinian
Legislative Council election and took control of
the PA government. Attempts to form a unity
government failed, and violent clashes between
Fatah and HAMAS supporters ensued, culminat-
ing in HAMAS''’s violent seizure of all military and
governmental institutions in the Gaza Strip. Fatah
and HAMAS in early 2011 agreed to reunify the
Gaza Strip and West Bank, but the factions have
struggled to implement details on governance
and security. Brief periods of increased violence
between Israel and Palestinian militants in the
Gaza Strip in 2007-08 and again in 2012, both
led to Egyptian-brokered truces. The status quo
remains with HAMAS in control of the Gaza Strip
and the PA governing the West Bank.
Background: The Kingdom of, Serbs, Croats,
and Slovenes was formed in 1918; its name was
changed to Yugoslavia in 1929. Various paramili-
tary bands resisted Nazi Germany''s occupation
and division of Yugoslavia from 1941 to 1945, but
fought each other and ethnic opponents as much
as the invaders. The military and political move-
ment headed by Josip “TITO” Broz (Partisans)
took full control of Yugoslavia when German
and Croatian separatist forces were defeated in
1945. Although Communist, TITO’s new govern-
ment and his successors (he died in 1980) man-
aged to steer their own path between the Warsaw
Pact nations and the West for the next four and
a half decades. In 1989, Slobodan MILOSEVIC
became president of the Republic of Serbia and
his ultranationalist calls for Serbian domination
led to the violent breakup of Yugoslavia along
ethnic lines. In 1991, Croatia, Slovenia, and
Macedonia declared independence, followed
by Bosnia in 1992. The remaining republics of
Serbia and Montenegro declared a new Federal
Republic of Yugoslavia (FRY) in April 1992 and
under MILOSEVIC''s leadership, Serbia led vari-
ous military campaigns to unite ethnic Serbs in
neighboring republics into a “Greater Serbia.”
These actions were ultimately unsuccessful and
led to the signing of the Dayton Peace Accords
in 1995. MILOSEVIC retained control over Ser-
bia and eventually became president of the FRY
in 1997. In 1998, an ethnic Albanian insurgency
in the formerly autonomous Serbian province of
Kosovo provoked a Serbian counterinsurgency
campaign that resulted in massacres and massive
expulsions of ethnic Albanians living in Kosovo.
The MILOSEVIC government''s rejection of a
proposed international settlement led to NATO''s
bombing of Serbia in the spring of 1999, to the
withdrawal of Serbian military and police forces
from Kosovo in June 1999, and to the station-
ing of a NATO-led force in Kosovo to provide
a safe and secure environment for the region’s
ethnic communities. FRY elections in late 2000
led to the ouster of MILOSEVIC and the instal-
lation of democratic government. In 2003, the
FRY became Serbia and Montenegro, a loose fed-
eration of the two republics. Widespread violence','07491623c86881f658d7d613f69fdc8c5778bbb7801a0a6befb38c362839762a','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('096e4d4cfa969e4c1b521969eb4a3ae647a185443d256022c5ef9ae7c6f61036',2025,'GE','Georgia','introduction',660,'Background: As Europe’s largest economy and
second most populous nation (after Russia),
Germany is a key member of the continent''s
economic, political, and defense organizations.
European power struggles immersed Germany in
two devastating World Wars in the first half of
the 20th century and left the country occupied
by the victorious Allied powers of the US, UK,
France, and the Soviet Union in 1945. With the
advent of the Cold War, two German states were
formed in 1949: the western Federal Republic of
Germany (FRG) and the eastern German Demo-
cratic Republic (GDR). The democratic FRG
embedded itself in key Western economic and
security organizations, the EC, which became
the EU, and NATO, while the Communist GDR
was on the front line of the Soviet-led Warsaw
Pact. The decline of the USSR and the end of
the Cold War allowed for German unification
in 1990. Since then, Germany has expended
considerable funds to bring Eastern productivity
and wages up to Western standards. In January
1999, Germany and 10 other EU countries intro-
duced a common European exchange currency,
the euro.','012c4a473c66a18a92288966e3a2add74052d3b34bb2a25621d2b8565cf40475','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('95e4943a5e9f161afb1f7239c4ff2bd5cb2db8b5096b7be493c2e4f46e4ae410',2025,'DE','Germany','introduction',670,'Background: Formed from the merger of the
British colony of the Gold Coast and the Togo-
land trust territory, Ghana in 1957 became the
- first sub-Saharan country in colonial Africa to
gain its independence. Ghana endured a long
series of coups before Le. Jerry RAWLINGS
took power in 1981 and banned political parties.
After approving a new constitution and restoring
multiparty politics in 1992, RAWLINGS won
presidential elections in 1992 and 1996 but was
constitutionally prevented from running for a
third term in 2000. John KUFUOR succeeded
him and was reelected in 2004. John Atta MILLS
took over as head of state in early 2009, but he
died in July 2012 and was succeeded by his vice
president John Dramani MAHAMA, who subse-
quently won a December 2012 special presiden-
tial election.','9abcf4474840776c123a63a11d81f998948f520ba878083b46ff4ca71277cc90','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1fef2f9bbcb4e93658019e3c52614ca60bb6cdb9f126a1b72ed27314bc901f25',2025,'GI','Gibraltar','introduction',680,'Background: Strategically important, Gibraltar
was reluctantly ceded to Great Britain by Spain
in the 1713 Treaty of Utrecht; the British garrison
was formally declared a colony in 1830. In a ref-
erendum held in 1967, Gibraltarians voted over-
whelmingly to remain a British dependency. The
subsequent granting of autonomy in 1969 by the
UK led to Spain closing the border and severing
all communication links. Between 1997 and 2002,
the UK and Spain held a series of talks on estab-
lishing temporary joint sovereignty over Gibraltar.
In-response to these talks, the Gibraltar Govern-
ment called a referendum in late 2002 in which
the majority of citizens voted overwhelmingly
against any sharing of sovereignty with Spain.
Since late 2004, Spain, the UK, and Gibraltar
have held tripartite talks with the aim of coop-
eratively resolving problems that affect the local
population, and work continues on cooperation
agreements in areas such as taxation and financial
services; communications and maritime security;
- policy, legal and customs services; environmen-
tal protection; and education and visa services.
Throughout 2009, a dispute over Gibraltar’s claim
to territorial waters extending out three miles gave
rise to periodic nonviolent maritime confronta-
tions between Spanish and UK naval patrols. A
new noncolonial constitution came into effect in
2007, and the European Court of First Instance
recognized Gibraltar’s right to regulate its own tax
regime in December 2008. The UK retains respon-
sibility for defense, foreign relations, internal secu-
rity, and financial stability.
Location: Southwestern Europe, bordering the
Strait of Gibraltar, which links the Mediterranean
Sea and the North Atlantic Ocean, on the south-
em coast of Spain x
Geographic coordinates: 36 08 N, 5 21 W
Map references: Europe
Area: total: 6.5 sq km
country comparison to the world: 243
land: 6.5 sq km
water: 0 sq km
Area—comparative: more than 10 times the size
of The National Mall in Washington, D.C.
Land boundaries: total: 1.2 km
border countries: Spain 1.2 km
Coastline: 12 km
Maritime claims: territorial sea; 3 nm
Climate: Mediterranean with mild winters and
warm summers
Terrain: a narrow coastal low land borders the
Rock of Gibraltar
Elevation extremes: lowest point: Mediterra-
nean Sea 0 m
highest point: Rock of Gibraltar 426 m
Natural resources: none
Land use: arable land:0%
permanent crops: 0%
other: 100% (2011)
Irrigated land: NA
Natura! hazards: NA
Environment—current issues: limited natural
freshwater resources: large concrete or natural rock
water catchments collect rainwater (no longer
used for drinking water) and adequate desalina-
tion plant
Geography—note: strategic location on Strait of
Gibraltar that links the North Atlantic Ocean and
Mediterranean Sea','b1a9edd725379732398e38af1e8f62098fc57520598c9a3de098e045df1f61b4','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1a34f67947701fbf59d4697edfd40d22fb6e72f8ef2842f0439b40068a4d25de',2025,'GR','Greece','introduction',691,'Background: Greece achieved independence
~ from the Ottoman Empire in 1830. During the
second half of the 19th century and the first
half of the 20th century, it gradually added
neighboring islands and territories, most with
Greek-speaking populations. In World War HI,
Greece was first invaded by Italy (1940) and
subsequently occupied by Germany (1941-
44); fighting endured in a protracted civil war
between supporters of the king and other anti-
Communist and Communist rebels. Following
the latter''s defeat in 1949, Greece joined NATO
in 1952. In 1967, a group of military officers
seized power, establishing a military dictator-
ship that suspended many political liberties and
forced the king to flee the country. In 1974,
democratic elections and a referendum created
a parliamentary republic and abolished the mon-
archy. In 1981, Greece joined the EC (now the
EU); it became the 12th member of the Euro-
pean Economic and Monetary Union in 2001. In
2010, the prospect of a Greek default on its euro-
denominated debt created severe strains within
the EMU and raised the question of whether a
member country might voluntarily leave the
common currency or be removed.
Background: Greenland, the world’s largest
island, is about 81% ice capped. Vikings reached
the island in the 10th century from Iceland; Dan-
ish colonization began in the 18th century, and
Greenland was made an integral part of Denmark
in 1953. It joined the European Community (now
the EU) with Denmark in 1973 but withdrew in
1985 over a dispute centered on stringent fishing
quotas. Greenland was granted self-government
in 1979 by the Danish parliament; the law went
into effect the following year. Greenland voted in
favor of increased self-rule in November 2008 and
acquired greater responsibility for internal affairs
when the Act on Greenland Self-Government
was signed into law in June 2009. Denmark,
however, continues to exercise control of Green-
land’s foreign affairs, security, and financial policy
in consultation with Greenland’s Home Rule','1f87311629c881b818dea91d65fc64f57b66571313f76129c3e3ef32e81649fb','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('37f58061b3b799192ca502c5162e31df8d548c702b3e118d781f6ad8ef9e8a34',2025,'GD','Grenada','introduction',711,'Background: Spain ceded Guam to the US in
1898. Captured by the Japanese in 1941, it was
retaken by the US three years later. The military
installation on the island is one of the most strate-
gically important US bases in the Pacific.','4310b8c842c82e04feaf97982c8f4e3fb87a6727b200c5ff2d2271f4b3d1ed8c','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('200722a5810249aa6dbf150c7e5b87e201f116cf05db16f2ceb4ebdaf052f90d',2025,'GG','Guernsey','introduction',719,'Background: Guernsey and the other Channel
Islands represent the last remnants of the medi-
eval Dukedom of Normandy, which held sway in
both France and England. The islands were the
ra) Py
~ $7. PETER:
PORT °
only British soil occupied by German troops in
World War II. Guernsey is a British crown depend-
ency but is not part of the UK or of the European
Union. However, rhe UK Govemment is consti-
tutionally responsible for its defense and interna-
tional representation.
Background: Guinea has had a history of authori-
tarian rule since gaining its independence from
France in 1958. Lansana CONTE came to power
in 1984 when the military seized the govern-
ment after the death of the first president, Sekou
TOURE. Guinea did not hold democratic elec-
tions until 1993 when Gen. CONTE (head of
the military government) was elected president
of the civilian government. He was reelected
in 1998 and again in 2003, though all the polls
were matred by irregularities. History repeated
itself in December 2008 when following President
CONTE ’s death, Capt. Moussa Dadis CAMARA
led a military coup, seizing power and suspend-
ing the constitution. His unwillingness to yield
to domestic and international pressure to step
down led to heightened political tensions that
culminated in September 2009 when presidential
guards opened fire on an opposition rally killing
more than 150 people, and in early December
2009 when CAMARA was wounded in an assas-
sination attempt and evacuated to Morocco and
combined fixed and mobilecellular teledensity
exceeds 100 per 100 persons
international: country code—44; 1 submarine
cable (2011)
Broadcast media: multiple UK terrestrial TV
broadcasts are received via a transmitter in Jersey
with relays in Jersey, Guernsey, and Alderney; sat-
ellite packages are available; BBC Radio Guernsey
and 1 other radio station operating (2009)
Internet country code: gg
Internet hosts: 239 (2012)
country comparison to the world: 197
Internet users: 48,300 (2009)
countfy comparison to the world: 175','2d9cfe2280662939249e1fce82a5ae4d33dbfd0f25bae471db6da62973ec6d6f','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d2e5ecb91725f09c87c963b9c3b4e330622fb1c82e3d9ef44b771d563795af49',2025,'GW','Guinea-Bissau','introduction',738,'Background: Since independence from Portugal
in 1974, Guinea-Bissau has experienced consid-
erable political and military upheaval. In 1980,
a military coup established authoritarian dicta-
tor Joao Bernardo “Nino” VIEIRA as president.
Despite setting a path to a market economy and
multiparty system, VIEIRA’s regime was charac-
terized by the suppression of political opposition
and the purging of political rivals. Several coup
attempts through the 1980s and early 1990s failed
to unseat him. In 1994 VIEIRA was elected presi-
dent in the country’s first free elections. A mili-
tary mutiny and resulting civil war in 1998 even-
tually led to VIEIRA’s ouster in May 1999, In
February 2000, a transitional government turned
over power to opposition leader Kumba YALA
after he was elected president in transparent poll-
ing. In September 2003, after only three years
in office, YALA was overthrown in a bloodless
military coup, and businessman Henrique ROSA
was sworn in as interim president. In 2005, for-
mer President VIEIRA was re-elected president
pledging to pursue economic development and
national reconciliation; he was assassinated in
March 2009. Malam Bacai SANHA was elected
in an emergency election held in June 2009, but
he passed away in January 2012 from an existing
illness. A military coup in April 2012 prevented
Guinea-Bissau’s second-round presidential elec-
tion—to determine SANHA''s successor—from
taking place.','6027cd0673bedb08f98a7cc4b2fbffb0d6d492b79a948a2dae4ce46c7aecd653','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('846cc3d51a54d76dffb4f78afab672a850b6dda89866d53fb5d41cf2d8013a47',2025,'GY','Guyana','introduction',747,'Background: Originally a Dutch colony in the
17th century, by 1815 Guyana had become a Brit-
ish possession. The abolition of slavery led to black
settlement of urban areas-and the importation of
indentured servants from India to work the sugar
plantations. The resulting ethnocultural divide has
persisted and has led to turbulent politics. Guyana
achieved independence from the UK in 1966, and
since then it has been ruled mostly by socialist-
oriented governments. In 1992, Cheddi JAGAN
was elected president in what is considered the
country’s first free and fair election since inde-
pendence. After his death five years later, his wife,
Janet JAGAN, became president but resigned in
1999 due to poor health, Her successor, Bharrat
JAGDEO, was reelected in 2001 and again in
2006. Donald RAMOTAR was elected president
in 2011.
Background: The native Taino—who inhabited
the island of Hispaniola when it was discovered
by Christopher COLUMBUS in 1492—were
virtually annihilated by Spanish settlers within
25 years. In the early 17th century, the French
established a presence on Hispaniola, In 1697,
Spain ceded to the French the western third of
the island, which later became Haiti. The French
colony, based on forestry ahd sugar-related indus-
tries, became one of the wealthiest in the Carib-
bean but only through the heavy importation of
African slaves and considerable environmental
degradation. In the late 18th century, Haiti''s
nearly half million slaves revolted under Tous-
saint LOUVERTURE. After a prolonged strug-
gle, Haiti became the first post-colonial black-led
nation in the world, declaring its independence
in 1804. Currently the poorest country in the
Western Hemisphere, Haiti has experienced
political instability for most of its history. After
an armed rebellion led to the forced resignation
and exile of President Jean-Bertrand ARISTIDE
in February 2004, an interim government took
office to organize new elections under the aus-
pices of the United Nations. Continued instabil-
ity and technical delays prompted repeated post-
ponements, but Haiti inaugurated a democrati-
cally elected president and parliament in May of
2006. This was followed by contested elections in
2010 that resulted in the election of Haiti’s cur-
rent President, Michel MARTELLY. A massive
magnitude 7.0 earthquake struck Haiti in Janu-
ary 2010 with an epicenter about 25 km (15 mi)
west of the capital, Port-au-Prince. Estimates are
that over 300,000 people were killed and some
1.5 million left homeless. The earthquake was
assessed as the worst in this region over the last
200 years.','55fc37578f7a908cd10bb690fe5e0c5d78331d770bfb82c06987b89dd473dca1','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4a7d8941174fffb13cfaf3ef1193d1cbb490f2c015b6cfe4fa467f8120cbf7dc',2025,'HM','Heard Island and McDonald Islands','introduction',763,'Background: The United Kingdom transferred
these uninhabited, barren, sub-Antarctic islands
to Australia in 1947. Populated by large numbers
of seal and bird species, the islands have been des-
ignated a nature preserve.
Background: Popes in their secular role ruled por-
tions of the Italian peninsula for more than a thou-
sand years until the mid 19th century, when many
of the Papal States were seized by the newly united
Kingdom of Italy. In 1870, the pope’s holdings
were further circumscribed when Rome itself was
annexed. Disputes between a series of “prisoner”
popes and Italy were resolved in 1929 by three Lat-
eran Treaties, which established the independent
state of Vatican City and granted Roman Catholi-
cism special status in Italy. In 1984, a concordat
between the Holy See and Italy modified certain
of the earlier treaty provisions, including the pri-
macy of Roman Catholicism as the Italian state
religion. Present concerns of the Holy See include
religious freedom, threats against minority Chris-
tian communities in Africa and the Middle East,
international development, interreligious dialogue
and reconciliation, and the application of church
doctrine in an era of rapid change and globaliza-
tion. About 1.2 billion people worldwide profess
the Catholic faith.
320
THE CIA WORLD FACTBOOK','dbd5fbed4d921b3c3f14caf1399b3abfb87fec0fea18125e85dbbc66872237bd','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0ee1be9606624af0e7fa600eb7fd66f5bf0f5db49a85f2f99eb05768a8e78d17',2025,'VA','Holy See (Vatican City State)','introduction',773,'Background: Once part of Spain”s vast empire in
the New World, Honduras became an independ-
ent nation in 1821. After twe and a half decades of
mostly military rule, a freely elected civilian gov-
ernment came to power in 1982. During the 1980s,
Honduras proved a haven for anti-Sandinista con-
tras fighting the Marxist Nicaraguan Government
and an ally to Salvadoran Government forces
fighting leftist guerrillas. The country was devas-
tated by Hurricane Mitch in 1998, which killed
about 5,600 people and caused approximately $2
billion in damage. Since then, the economy has
slowly rebounded.
321
PAN TIS A RAIA
si, SR
Santa Rosa a aro
dë Cuwan uta
°
Danii”
S ee
Bh crengol,
met Cyaan
od NICARAGUA','11bb9f8f19a3d9c0e908f13b115f2f5e3be2d74961ba866911e2d02f80d1942e','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('47a1fcf460eff656fdaeea707f0d254c536d2c72f442064ef7c8c70c1ccf1c95',2025,'HN','Honduras','introduction',783,'Background: Occupied by the UK in 1841, Hong
Kong was formally ceded by China the following
year; various adjacent lands were added later in the
19th century. Pursuant to an agreement signed by
China and the UK on 19 December 1984, Hong
Kong became the Hong Kong Special Adminis-
trative Region (SAR) of the People’s Republic of
China on 1 July 1997. In this agreement, China
promised that, under its “one country, two systems”
formula, China’s socialist economic system would
not be imposed on Hong Kong and that Hong
Kong would enjoy a high degree of autonomy in all
matters except foreign and defense affairs for the
next 50 years. rs','7772b037aed445c847aaf49b0dea63818297eb2d207e7c85c96f2a0f56725b2f','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d3629584edb37832049c72c3449760be3ff1132b7a09f1b0c17abcf12480049b',2025,'HK','Hong Kong','introduction',790,'Background: Hungary became a Christian king-
dom in A.D. 1000 and for many centuries served
as a bulwark against Ottoman Turkish expansion
in Europe. The kingdom eventually became part
of the polyglot Austro-Hungarian Empire, which
collapsed during World War I. The country fell
under Communist rule following World War II.
In 1956, a revolt and an announced withdrawal
country comparison to the world: 172
paved: 2,067 km (2010)
Merchant marine: total: 1,644
country comparison to the world: 5
by type: barge carrier 2, bulk carrier 785, cargo
198, carrier 10, chemical tanker 149, container
288, liquefied gas 31, passenger 4, passenger/cargo
9, petroleum tanker 156, roll -on/roll off 5, vehicle
carrier 7
foreign-owned: 976 (Bangladesh 1, Belgium 26,
Bermuda 20, Canada 77, China 500, Cyprus 3, Den-
mark 42, France 4, Germany 10, Greece 27, Indone-
sia 10, Iran 3, Japan 79, Libya 1, Norway 48, Russia
1, Singapore 13, South Korea 3, Switzerland 5, Tai-
wan 25, UAE 1, UK 33, US 44) registered in other
countries: 341 (Bahamas 3, Bermuda 4, Cambodia
10, China 18, Curacao Cyprus 2, Georgia 3, India 2,
Kiribati 2, Liberia 48, Malaysia 8, Malta 4, Marshall
Islands 3, NZ Panama 144, Saint Vincent and the
Grenadines 5, Seychelles 1, Sierra Leone 7, Singa-
pore 46, Thailand 1, UK 12, unknown 16) (2010)
Ports and terminals: Hong Kong','ebeae83131078da7910657e6729daf5de51281c33bc6a6c9bc8d9b6ed236f6e0','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('82cd416f71e871782d637f2f2710c0a1bb2e960d06d2a667b437e32b14c247dc',2025,'HU','Hungary','introduction',800,'Background: Settled by Norwegian and Celtic
(Scottish and Irish) immigrants during the late
9th and 10th centuries A.D., Iceland boasts the
world’s oldest functioning legislative assembly, the
Althing, established in 930. Independent for over
300 years, Iceland was subsequently ruled by Nor-
way and Denmark. Fallout from the Askja volcano
of 1875 devastated the Icelandic economy and
caused widespread famine. Over the next quarter
century, 20% of the island’s population emigrated,
mostly to Canada and the US. Denmark granted
limited home rule in 1874 and complete independ-
ence in 1944. The second half of the 20th century
saw substantial economic growth driven primarily
by the fishing industry. The economy diversified
greatly after the country joined the European Eco-
nomic Area in 1994, but Iceland was especially
hard hit by the global financial crisis in the years
following 2008.: Literacy, longevity, and social
cohesion are first rate by world standards.','de443ce9f07e928b76244f3f37810bb73861e6e1f1581ac0c634b75846a749ca','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2a443c6058b7876e64c7c1941ae00f94f215deecfd84e57c94512f0bd0840519',2025,'IS','Iceland','introduction',807,'Background: The Indus Valley civilization,
one of the world’s oldest, flourished during
the 3rd and 2nd millennia B.C. and extended
into northwestern India. Aryan tribes from the
northwest infiltrated the Indian subcontinent
about 1500 B.C.; their merger with the ear-
lier Dravidian inhabitants created the classi-
cal Indian culture. The Maurya Empire of the
4th and 3rd centuries B.C.—which reached its
zenith under ASHOKA—united much of South
Asia. The Golden Age ushered in by the Gupta
dynasty (4th to 6th centuries A.D.) saw a flow-
ering of Indian science, art, and culture. Islam
336
spread across the subcontinent over a period of
700 years. In the 10th and 11th centuries, Turks
and Afghans invaded India and established
the Delhi Sultanate. In the early 16th century,
the Emperor BABUR established the Mughal
Dynasty which ruled India for more than three
centuries. European explorers began establishing
footholds in India during the 16th century. By
the 19th century, Great Britain had become the
dominant political power on the subcontinent.
The British Indian Army played a vital role in
both World Wars. Years of nonviolent resist-
ance to British rule, led by Mohandas GANDHI
and Jawaharlal NEHRU, eventually resulted
in Indian independence, which was granted in
1947. Large-scale communal violence took place
before and after the subcontinent partition into
two separate states—India and Pakistan. The
neighboring nations have fought three wars
since independence, the last of which was in
1971 and resulted in East Pakistan becoming the
separate nation of Bangladesh. India’s nuclear
weapons tests in 1998 emboldened Pakistan to
conduct its own tests that same year, In Novem-
ber 2008, terrorists originating from Pakistan
conducted a series of coordinated attacks in
Mumbai, India’s financial capital. Despite press-
ing problems such as significant overpopulation,
environmental degradation, extensive poverty,
and widespread corruption, economic growth
following the launch of economic reforms in
1991 and a massive youthful population are driv-
ing India’s emergence as a regional and global
power.','c54c0af55411952063c02686aee43a08ccde532cec8301b164a5ab8c133b53f0','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1e88d8a3562750562c2cbecb3854bf1dec8cca0e564981031ba64dfb9e924fa1',2025,'IN','India','introduction',815,'Background: The Indian Ocean is the third largest
of the world’s five oceans (after the Pacific Ocean
and Atlantic Ocean, but larger than the Southern
Ocean and Arctic Ocean). Four critically impor-
tant access waterways are the Suez Canal (Egypt),
Bab el Mandeb (Djibouti-Yemen), Strait of Hor-
muz (Iran-Oman), and Strait of Malacca (Indone-
sia-Malaysia). The decision by the International
Hydrographic Organization in the spring of 2000
to delimit a fifth ocean, the Southern Ocean,
removed the portion of the Indian Ocean south of
60 degrees south latitude.
Geography: INDIAN OCEAN
Location: body of water between Africa, the
Southern Ocean, Asia, and Australia
Geographic coordinates: 20 00 S, 80 00 E
Map references: Physical Map of the World
Area: total: 68.556 million sq km
note: includes Andaman Sea, Arabian Sea, Bay of
Bengal, Flores Sea, Great Australian Bight, Gulf
of Aden, Gulf of Oman, Java Sea, Mozambique
Channel, Persian Gulf, Red Sea, Savu Sea, Strait
of Malacca, Timor Sea, and other tributary water
bodies
Area—comparative: about 5.5 times the size of
the US
Coastline: 66,526 km Climate northeast monsoon
(December to April), southwest monsoon (June to
October); tropical cyclones occur during May/June
and October/November in the northem Indian
Ocean and January/February in the southern Indian
Ocean Terrain surface dominated by counterclock-
wise gyre (broad, circular system of currents) in the
southern Indian Ocean; unique reversal of surface cur-
rents in the northem Indian Ocean; low atmospheric
pressure over southwest Asia from hot, rising, summer
air results in the southwest monsoon and southwest-
to-northeast winds and currents, while high pressure
over northem Asia from cold, falling, winter air
results in the northeast monsoon and northeast-to-
southwest winds and currents; ocean floor is domi-
nated by the Mid-Indian Ocean Ridge and subdivided
by the Southeast Indian Ocean Ridge, Southwest
Indian Ocean Ridge, and Ninetyeast Ridge
Elevation extremes:
Trench-7,258 m
highest point: sea level 0 m ''
Natural resources: oil and gas fields, fish, shrimp,
sand and gravel aggregates, placer deposits, poly-
metallic nodules
Natural hazards: occasional icebergs pose naviga-
tional hazard in southern reaches
Environmeni—current issues:
marine species include the dugong, seals, turtles,
and whales; oil pollution in the Arabian Sea, Per-
sian Gulf, and Red Sea
Geography—note: major chokepoints include
Bab el Mandeb, Strait of Hormuz, Strait of
Malacca, southern access to the Suez Canal, and
the Lombok Strait
Background: The Dutch began to colonize Indo-
nesia in the early 17th century; Japan occupied the
islands from 1942 to 1945. Indonesia declared its
independence shortly before Japan’s surrender, but
it required four years of sometimes brutal fight-
ing, intermittent negotiations, and UN media-
tion before the Netherlands agreed to transfer
sovereignty in 1949. A period of sometimes unruly
parliamentary democracy ended in 1957 when
President SOEKARNO declared martial law and
instituted “Guided Democracy.” After an abortive
coup in 1965 by alleged Communist sympathizers,
SOEKARNO was removed from power. From 1966
until 1988, President SUHARTO ruled Indonesia
with his “New Order” Government. After rioting
toppled Suharto in 1998, free and fair legislative
elections took place in 1999. Indonesia is now
the world’s third most populous democracy, the
world’s largest archipelagic state, and the world’s
largest Muslim-majority nation. Current issues
include: alleviating poverty, improving education,
preventing terrorism, consolidating democracy
after four decades of authoritarianism, implement-
ing economic and financial reforms, stemming
corruption, reforming the criminal justice sys-
tem, holding the military and police accountable
for human rights violations, addressing climate
change, and controlling infectious diseases, par-
ticularly those of global and regional importance.
In 2005, Indonesia reached a historic peace agree-
ment with armed separatists in Aceh, which led to
democratic elections in Aceh in December 2006.
Indonesia continues to face low intensity armed
resistance in Papua by the separatist Free Papua
Movement.','ee0697aa44bdbe68016ebef267e74f4cbeabdb7776310b2511b26da06c958b74','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1f5424ea71f621b7630681a29f5768f6b38e7671e469ac5e189e021a1c895253',2025,'IQ','Iraq','introduction',819,'Background: Formerly part of the Ottoman
Empire, Iraq was occupied by Britain during the
course of World War I; in 1920, it was declared
a League of Nations mandate under UK adminis-
tration. In stages over the next dozen years, Iraq
attained its independence as a kingdom in 1932.
A “republic” was proclaimed in 1958, but in actu-
ality a series of strongmen ruled the country until
2003. The last was SADDAM Husayn. Territo-
rial disputes with Iran led to an inconclusive and
costly eight-year war (1980-88). In August 1990,
Iraq seized Kuwait but was expelled by US-led,
UN coalition forces during the Gulf War of Jan-
uary-February 1991. Following Kuwait’s libera-
tion, the UN Security Council (UNSC) required
Iraq to scrap all weapons of mass destruction and
long-range missiles and to allow UN verification
inspections. Continued Iraqi noncompliance with
UNSC resolutions over a period of 12 years led to
the US-led invasion of Iraq in March 2003 and
the ouster of the SADDAM Husayn regime. US
forces remained in Iraq under a UNSC mandate
through 2009 and under a bilateral security agree-
ment thereafter, helping to provide security and to
train and mentor Iraqi security forces. In October
2005, Iraqis approved a constitution in a national
referendum and, pursuant to this document,
elected a 275-member Council of Representatives
(COR) in December 2005. The COR approved
most cabinet ministers in May 2006, marking the
transition to Iraq''s first constitutional government
in nearly a half century. In January 2009, Iraq held
elections for provincial councils in all governo-
rates except for the three governorates comprising
the Kurdistan Regional Government and Kirkuk
Governorate. Iraq held a national legislative elec-
tion in March 2010—choosing 325 legislators in
an expanded COR—and, after nine months of
deadlock the COR approved the new government
in December 2010. Nearly nine years after the
start of the Second Gulf War in Iraq, US military
operations there ended in mid-December 2011.
Background: Celtic tribes arrived on the island
between 600 and 150 B.C. Invasions by Norse-
men that began in the late 8th century were
finally ended when King Brian BORU defeated
the Danes in 1014. English invasions began in the
12th century and set off more than seven centuries
of Anglo-Irish struggle marked by fierce rebellions
and harsh repressions. A failed 1916 Easter Mon-
day Rebellion touched off several years of guerrilla -
warfare that in 1921 resulted in independence
from the UK for 26 southern counties; six north-
ern (Ulster) counties remained part of the UK.
In 1949, Ireland withdrew from the British Com-
monwealth; it joined the European Community in
1973. Irish governments have sought the peaceful
unification of Ireland and have cooperated with
Britain against terrorist groups. A peace settlement
for Northern Ireland is gradually being imple-
mented despite some difficulties. In 2006, the Irish
and British governments developed and began to
implement the St. Andrews Agreement, building
on the Good Friday Agreement approved in 1998.','f235d1e59cba35c241c4762081674844016a82cb94ef79530698cfc956d0342a','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2f3d0b14b5e0ca50a495246b31053189aea4d77764633a24f0b0664343c36ebc',2025,'IM','Isle of Man','introduction',834,'Background: Part of the Norwegian Kingdom of
the Hebrides until the 13th century when it was
ceded to Scotland, the isle came under the British
crown in 1765. Current concems include reviving
the almost extinct Manx Gaelic language. Isle of
Man is a British crown dependency but is not part
of the UK or of the European Union. However, the
UK Government remains constitutionally responsi-
ble for its defense and international representation.
Background: Following World War Il, the Brit-
ish withdrew from their mandate of Palestine, and
the UN partitioned the area into Arab and Jew-
ish states, an arrangement rejected by the Arabs. .
Subsequently, the Israelis defeated the Arabs in
a series of wars without ending the deep tensions
berweeni the two sides. (The territories Israel occu-
pied since the 1967 war are not included in the
Israel country profile, unless otherwise noted.)
On 25 April 1982, Israel withdrew from the Sinai
pursuant to the 1979 Israel-Egypt Peace Treaty.
In keeping with the framework established at the
Madrid Conference in October 1991, bilateral
negotiations were conducted between Israel and
Palestinian representatives and Syria to achieve a
permanent settlement. Israel and Palestinian offi-
cials signed on 13 September 1993 a Declaration
of Principles (also known as the “Oslo Accords”)
guiding an interim period of Palestinian self-rule.
Outstanding territorial and other disputes with
Jordan were resolved in the 26 October 1994
Israel-Jordan Treaty of Peace. Progress toward a
permanent status agreement was undermined by
Israeli-Palestinian violence between September
2003 and February 2005. Israel in 2005 unilater-
ally disengaged from the Gaza Strip, evacuating
settlers and its military while retaining control
over most points of entry into the Gaza Strip.
The election of HAMAS to head the Palestin-
ian Legislative Council in 2006 froze relations
between Israel and the Palestinian Authority','74d804f9a08294454766a30b9b601bbefb58735f2dbd1e9d1ed2f9cbb0015b3e','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7d7b45e870a8cffa6a4e52bac42ae392009fb017d06f8d8d1c6a1ffdc20ccde9',2025,'IL','Israel','introduction',842,'(PA). In 2006 Israel engaged in a 34-day conflict
with Hizballah in Lebanon in June-August 2006
and a 23-day conflict with HAMAS in the Gaza
Strip during December 2008 and January 2009.
Prime Minister Binyamin NETANYAHU formed
a coalition in March 2009 following a February
2009 general election. Direct talks with the PA
launched in September 2010 collapsed following
the expiration of Israels 10-month partial settle-
ment construction moratorium in the West Bank.
Background: Italy became a nation-state in 1861
when the regional states of the peninsula, along
with Sardinia and Sicily, were united under King
Victor EMMANUEL II. An era of parliamentary
government came to a close in the early 1920s
when Benito MUSSOLINI established a Fascist
dictatorship. His alliance with Nazi Germany
led to Italy''s defeat in World War II. A demo-
cratic republic replaced the monarchy in 1946
and economic revival followed. Italy is a charter
member of NATO and the European Economic
Community (EEC). It has been at the forefront
of European economic and political unification,
joining the Economic and Monetary Union in
1999. Persistent problems include sluggish eco-
nomic growth, high youth and female unemploy-
ment, organized crime, corruption, and economic
disparities between southern Italy and the more
prosperous north.','b8c1664a09c881f3f9038d0b8c5b33ea1bf5ddf530f2465282487c91c2333e23','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0c8824c026c43b8d59a5567f0872b62219aee8d291c1356ec808c22062e43f6f',2025,'IT','Italy','introduction',861,'Background: The island—discovered by Chris-
topher COLUMBUS in 1494—was settled by
the Spanish early in the 16th century. The native
Taino, who had inhabited Jamaica for centuries,
were gradually exterminated and replaced by Afri-
can slaves. England seized the island in 1655 and
established a plantation economy based on sugar,
cocoa, and coffee. The abolition of slavery in
1834 freed a quarter million slaves, many of whom
became small farmers. Jamaica gradually increased
its independence from Britain. In 1958 it joined
other British Caribbean colonies in forming the
Federation of the West Indies. Jamaica gained full
independence when it withdrew from the Federa-
tion in 1962. Deteriorating economic conditions
during the 1970s led to recurrent violence as rival
gangs affiliated with the major political parties
evolved into powerful organized crime networks
involved in international drug smuggling and
money laundering. Violent crime, drug traffick-
ing, and poverty pose significant challenges to the
government today. Nonetheless, many rural and
resort areas remain relatively safe and contribute
substantially to the economy.
Background: Geographically the third smallest
state in Europe (after the Holy See and Monaco),
San Marino also claims to be the world’s oldest
republic. According to tradition, it was founded by
a Christian stonemason named Marinus in A.D.
301. San Marino’s foreign policy is aligned with
that of the European Union, although it is not a
member; social and political trends in the republic
track closely with those of its larger neighbor, Italy.','275045b4c13bbfff7fc27bb82b730d09214c876127ebb83d9a97f4008b192035','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('64f34bb15e5a7dba45becc29a95bff9d72a254cf7e4fe5328f7622381085cf64',2025,'JM','Jamaica','introduction',868,'Background: This desolate, arctic, mountain-
ous island was named after a Dutch whaling
captain who indisputably discovered it in 1614
(earlier claims are inconclusive). Visited only
occasionally by seal hunters and trappers over
the following centuries, the island came under
Norwegian sovereignty in 1929. The long dor-
mant Beerenberg volcano, the northernmost
active volcano on earth, resumed activity in
1970 and the most recent eruption occurred in
1985.','db70eb941876fb278f55303982b16ed8413d20156f2c6d4c22db00500d017f20','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9094fba27f32d65e3a5eecf8af0372f886adb2ffb247a9a98901c994a6c06dbd',2025,'NO','Norway','introduction',872,'Background: In 1603, after decades of civil war-
fare, the Tokugawa shogunate (a military-led,
dynastic government) ushered in a long period
of relative political stability and isolation from
foreign influence. For more than two centuries
this policy enabled Japan to enjoy a flowering
372
of its indigenous culture. Japan opened its ports
after signing the Treaty of Kanagawa with the
US in 1854 and began to intensively modernize
and industrialize. During the late 19th and early
20th centuries, Japan became a regional power
that was able to defeat the forces of both China
and Russia. It occupied Korea, Formosa (Taiwan),
and southern Sakhalin Island. In 1931-32 Japan
occupied Manchuria, and in 1937 ir launched a
full-scale invasion of China. Japan attacked US
forces in 1941—triggering America’s entry into
World War Il—and soon occupied much of East
and Southeast Asia. After its defeat in World War
II, Japan recovered to become an economic power
and an ally of the US. While the emperor retains
his throne as a symbol of national unity, elected
politicians hold actual decision-making power.
Following three decades of unprecedented growth,
Japan’s economy experienced a major slowdown
starting in the 1990s, but the country remains a
major economic power. In March 2011, Japan’s
strongest-ever earthquake, and an accompanying
tsunami, devastated the northeast part.of Honshu
island, killing thousands and damaging several
nuclear power plants. The catastrophe hobbled
the country’s economy and its energy infrastruc-
ture, and tested its ability to deal with humanitar-
ian disasters.
Background: Two centuries of Viking raids
-into Europe tapered off following the adoption
of Christianity by King Olav TRYGGVASON
in 994. Conversion of the Norwegian kingdom
occurred over the next several decades. In 1397,
Norway was absorbed into a union with Den-
mark that lasted more than four centuries. In
1814, Norwegians resisted the cession of their
country to Sweden and adopted a new constitu-
tion. Sweden then invaded Norway but agreed
to let Norway keep its constitution in return for
accepting the union under a Swedish king. Rising
nationalism throughout the 19th century led to a
1905 referendum granting Norway independence.
Although’ Norway remained neutral in World
War I, it suffered heavy losses to its shipping.
Norway proclaimed its neutrality at the outset
of World War Il, but was nonetheless occupied
for’five years by Nazi Germany (1940-45). In
1949, neutrality was abandoned and Norway
became a member of NATO. Discovery of oil and
gas in adjacent waters in the late 1960s boosted
Norway’s economic fortunes. In referenda held
in 1972 and 1994, Norway rejected joining the
EU. Key domestic issues include immigration
and integration of ethnic minorities, maintain-
ing the country’s extensive social safety net with
an aging population, and preserving economic
competitiveness.
Background: The inhabitants of the area of Oman
have long prospered on Indian Ocean trade. In
the lase 18th century, a nely established sultanate
in Muscat signed the first in a series of friendship
treaties with Britain. Over time, Oman’s depend-
ence on British political and military advisors
increased, but it never became a British colony.
In 1970, QABOOS bin Said Al-Said overthrew
his father, and he has since ruled as sultan. His
extensive modernization program has opened the
country to the outside world while preserving
the longstanding close ties with the UK. Oman’s
moderate, independent foreign policy has sought
‘to maintain good relations with all Middle Eastern
countries. Inspired by the popular uprisings that
swept the Middle East and North Africa beginning
in January 2011, Omanis began staging marches
and demonstrations to demand economic benefits,
an end to corruption, and greater political rights.
In response to protester demands, QABOOS in
2011 pledged to implement economic and politi-
cal reforms, such as granting legislative and regula-
tory powers to the Majlis al-Shura and introduc-
ing unemployment benefits. In August 2012, the
Sultan announced a royal directive mandating the
speedy implementation of a national job creation
plan for thousands of public and private sector
jobs. As part of the government''s efforts to decen-
tralize authority and allow greater citizen par-
ticipation in local governance, Oman successfully
conducted its first municipal council elections
in December 2012. Announced by the Sultan in
2011, the municipal councils will have the power
to advise the Royal Court on the needs of local
districts across Oman’s 11 governorates.','9f88103ff967614687d869521b0b8a998cdd0d745e6389c9f4e1fbe834320a07','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('02e01d4ce6b5661e029e8025c667cf11bc2dca693a81da47eb95ca46e01059cd',2025,'JO','Jordan','introduction',892,'Background: Following World War I and the
dissolution of the Ottoman Empire, the League
of Nations awarded Britain the mandate to gov-
ern much of the Middle East. Britain demarcated
a semi-autonomous region of Transjordan from
Palestine in the ‘early 1920s. The area gained its
378
independence in 1946 and thereafter became
The Hashemite Kingdom of Jordan. The coun-
try’s long-time ruler, King HUSSEIN (1953-99),
successfully navigated competing pressures from
the major powers (US, USSR, and UK), various
Arab states, Israel, and a large internal Palestinian
population. Jordan lost the West Bank to Israel in
the 1967 Six-Day War. King HUSSEIN in 1988
permanently relinquished Jordanian claims to the
West Bank; in 1994 he signed a peace treaty with
Israel. King ABDALLAH Il, King HUSSEIN’s
eldest son, assumed the throne following his
father’s death in 1999, He implemented modest
political and economic reforms, but in the wake
of the “Arab Revolution” across the Middle East,
Jordanians continue to press for further political
liberalization, government reforms, and economic
improvements.
Background: Ethnic Kazakhs, a mix of Turkic and
Mongol nomadic tribes who migrated into the
region in the 13th century, were rarely united as
a single nation. The area was conquered by Rus-
sia in the 18th century, and Kazakhstan became
a Soviet Republic in 1936. During the 1950s
and 1960s agricultural “Virgin Lands” program,
Soviet citizens were encouraged to help cultivate
Kazakhstan''s northern pastures. This influx of
immigrants (mostly Russians, but also some other
deported natignalities) skewed the ethnic mixture
and enabled non-ethnic Kazakhs to outnumber
natives. Non-Muslim ethnic minorities departed
Kazakhstan in large numbers from the mid-1990s
through the mid-2000s and a national program has
repatriated about a million ethnic Kazakhs thus far
back to Kazakhstan. These trends have allowed
Kazakhs to become the titular majority again. This
dramatic demographic shift has also undermined
the previous religious diversity and made the
country more than 70 percent Muslim. Kazakh-
stan’s economy is larger than those of all the other
Central Asian states largely due to the country’s
vast natural resources. Current issues include:
developing a cohesive national identity; managing
Islamic revivalism; expanding the development of
the country’s vast energy resources and exporting
them to world markets; diversifying the economy
outside the oil, gas, and mining sectors; enhancing
Kazakhstan''s economic competitiveness; develop-
ing a multiparty parliament and advancing politi-
cal and social reform; and strengthening relations
with neighboring states and other foreign powers.','c3a3ecbf0eb8bcfc6f6dc1502b6162290757ebeb2c36129d21705e0ee40b034a','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e1aec433039c5806b709eba3ba3faa15afabb562f502f24ad9b6b6636b707b67',2025,'KE','Kenya','introduction',907,'Background: Founding president and liberation
struggle icon Jomo KENYATTA led Kenya from
independence in 1963 until his death in 1978,
when President Daniel MOI took power in a con-
stitutional succession. The country was a de facto
one-party state from 1969 until 1982 when the
ruling Kenya African National Union (KANU)
thade itself the sole legal party in Kenya. MOI
acceded to internal and extemal pressure for polit-
ical liberalization in late 1991. The ethnically frac-
tured opposition failed to dislodge KANU from
power in elections in 1992 and 1997, which were
marred by violence and fraud, but were viewed as
having generally reflected the will of the Kenyan
people. President MOI stepped down in December
2002 following fair and peaceful elections. Mwai
KIBAKI, running as the candidate of the multi-
ethnic, united opposition group, the National
Rainbow Coalition (NARC), defeated KANU
candidate Uhuru KENYATTA and assumed the
presidency following a campaign centered on an
anticorruption platform. KIBAKI’s NARC coa-
lition splintered in 2005 over a constitutional
review process. Government defectors joined with
KANU to form a new opposition coalition, the
Orange Democratic Movement (ODM), which
defeated the government''s draft constitution in a
popular referendum in November 2005. KIBAKI''s
reelection in December 2007 brought charges of
vote rigging from ODM candidate Raila ODINGA
and unleashed two months of violence in which as
many as 1,500 people died. African Union-spon-
sored mediation led by former UN Secretary Gen-
eral Kofi ANNAN in late February 2008 resulted
in a power-sharing accord bringing ODINGA into
the government in the restored position of prime
minister. The power sharing accord included a
broad reform agenda, the centerpiece of which was
constitutional reform. In August 2010, Kenyans
overwhelmingly adopted a new constitution in a
national referendum. The new constitution intro-
duced additional checks and balances to executive
power and significant devolution of power and
resources to 47 newly created counties. It also
eliminated the position of prime minister follow-
ing the first presidential election under the new
constitution, which occurred on March 4, 2013.
Uhuru KENYATTA, the son of founding president
Jomo KENYATTA, won the March elections in
the first round by a close margin and was sworn
into office on 9 April 2013.','7166884f300a39a885febfcdd325822759f8ce899cbef2cdea37ef4c5af0b4f9','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c88b0af1c331451319200b05bbc8c40ae5db3a8286b4eaad97dca243638f6d37',2025,'KI','Kiribati','introduction',915,'Background: The Gilbert Islands became a Brit-
ish protectorate in 1892 and a colony in 1915;
they were captured by the Japanese in the Pacific
War in 1941. The islands of Makin and Tarawa
were the sites of major US amphibious victories
over entrenched Japanese garrisons in 1943.
The Gilbert Islands were granted self-rule by
the UK in 1971 and complete independence in
1979 under the new name of Kiribati. The US
relinquished all claims to the sparsely inhabited
Phoenix and Line Island groups in a 1979 treaty
of friendship with Kiribati.
Background: An independent kingdom for much
of its long history, Korea was occupied by Japan
beginning in 1905 following the Russo-Japanese
War. Five years later, Japan formally annexed the
entire peninsula. Following Worl® War Il, Korea
was split with the northem half coming under
Soviet-sponsored Communist control. After fail-
ing in the Korean War (1950-53) conquer
the US-backed Republic of Korea (ROK) in the
southern portion by force, North Korea (DPRK),
under its founder President KIM II Sung, adopted a
policy of ostensible diplomatic and economic “self-
reliance” as a check against outside influence. The
DPRK demonized the US as the ultimate threat to
its social system through state-funded propaganda,
and molded political, economic, and military
policies around the core ideological objective of
eventual unification of Korea under Pyongyang’s
control. KIM II Sung’s son, KIM a Il, was < peed
cially designated as his father’s successor in 196i
assuming a growing political and managerial role
until the elder KIM’s death in 1994. KIM Jong Un
was publicly unveiled as his father’s successor in
September 2010. Following KIM Jong I''s death m
December 2011, the regime began to take ac
to transfer power to KIM Jong Un and KIM
now assumed many his father’s former otles and
duties. After decades of economic mismanagement
and resource misallocation, the DPRK since the
mid-1990s has relied heavily on international aid
to feed its population. The DPRK began to ease
restrictions to allow semi-private markets, si
ing in 2002, but then sought to roll back th
of economic reforms in 2005 and 2009. |
Korea''s history of regional military provocations,
proliferation of military-related items; long-
missile development; WMD programs including
tests of nuclear devices in 2006, 2009, and 2013;
and massive conventional armed forces are of
major concern to the international community.
Background: An independent kingdom for much
of its long history, Korea was occupied by Japan
beginning in 1905 following the Russo-Japanese
War. In 1910, Tokyo formally annexed the entire
Peninsula. Korea regained its independence fol-
lowing Japan’s surrender to the United States in
1945. After World War Il, a democratic-based
government (Republic of Korea, ROK) was set up
in the southern half of the Korean Peninsula while
a Communist-style government was installed in
the north (Democratic People’s Republic of Korea,
DPRK). During the Korean War (1950-53), U.S.
troops and UN forces fought alongside ROK sol-
diers to defend South Korea from a DPRK invasion
supported by China and the Soviet Union. A 1953
armistice split the peninsula along a demilitarized
zone at about the 38th parallel. PARK Chung-
hee took over leadership of the country in a 1961
coup, During his regime, from 1961 to 1979, South
Korea achieved rapid economic growth, with per
capita income rising to roughly 17 times the level
of North Korea. South Korea held its first free
presidential election under a revised democratic
constitution in 1987, with former ROK Army
_ general ROH Tae-woo winning a close race. In
1993, KIM Young-sam (1993-98) became South
Korea''s first civilian president. South Korea today
is a fully functioning modern democracy. LEE
Myung-bak (2008-2013) pursued a policy of global
engagement, highlighted by Seoul’s hosting of the
G-20 summit in November 2010 and the Nuclear
Security Summit in March 2012. South Korea also
secured a non-permanent seat (2013-14) on the
UN Security Council and will host the 2018 Win-
ter Olympic Games. President PARK Geun-hye
took office in February 2013 and is South Korea’s
first female leader. Serious tensions with North
Korea have punctuated inter-Korean relations in
recent years, including the North''s sinking of the
South Korean warship Cheonan in March 2010
and its artillery attack on South Korean soldiers
a
and citizens in November 2010. In January 2013,
assumed a nonpermanent seat on the UN Security
Council for the 2013-14 term.
Background: The central Balkans were part of
the Roman and Byzantine Empires before ethnic
Serbs migrated to the territories of modern Kosovo
in the 7th century. During the medieval period,
Kosovo became the center of a Serbian Empire and
saw the construction of many important Serb reli-
gious sites, including many architecturally signifi-
cant Serbian Orthodox monasteries. The defeat
of Serbian forces at the Battle of Kosovo in 1389
led to five centuries of Ottoman rule during which
large numbers of Turks and Albanians moved to
Kosovo. By the end of the 19th century, Albanians
replaced the Serbs as the dominant ethnic group
in Kosovo. Serbia reacquired control over Kosovo
from the Ottoman Empire during the First Balkan
400
War of 1912. After World War II, Kosovo became
an autonomous province of Serbia in the Social-
ist Federal Republic of Yugoslavia (S.ER.Y.) with
status almost equivalent to that of a republic under
the 1974 S.ER.Y. constitution. Despite legislative
concessions, Albanian nationalism increased in
the 1980s, which led to riots and calls for Kosovo''s
independence. At the same time, Serb nation-
alist leaders, such as Slobodan MILOSEVIC,
exploited Kosovo Serb claims of maltreatment
to secure votes from supporters, many of whom
viewed Kosovo as their cultural heartland. Under
MILOSEVICS leadership, Serbia instituted a new
constitution in 1989 that revoked Kosavo’s status
as an autonomous province of Serbia. Kosovo''s
Albanian leaders responded in 1991 by organizing
a referendum that declared Kosovo independent.
Under MILOSEVIC, Serbia carried out repressive
measures against the Kosovar Albanians in the
early 1990s as the unofficial Kosovo government,
led by Ibrahim RUGOVA, used passive resistance
in an attempt to try to gain international assistance
and recognition of an independent Kosovo. Alba-
nians dissatisfied with RUGOVA''s passive strategy
in the 1990s created the Kosovo Liberation Army
and launched an insurgency. Starting in 1998,
Serbian military, police, and paramilitary forces
under MILOSEVIC conducted a brutal counterin-
surgency campaign that resulted in massacres and
massive expulsions of ethnic Albanians. Approxi-
mately 800,000 Albanians were forced from their
homes in Kosovo during this time, International
attempts to mediate the conflict failed, and MILO-
SEVICS rejection of a proposed settlement led to','5cbf194922ddc14d59f1ec77e5df17ee6122dd667f57ad74dd02c0c9a1019ec9','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f4f749d8e7dd86e5c73a0362e22b09d9559ccbc6011e1229ef90dc651637631c',2025,'RS','Serbia','introduction',925,'“a
Ea
DE pristina"
È ie
a three-month NATO military operation against
Serbia beginning in March 1999 that forced Serbia
to agree to withdraw its military and police forces
from Kosovo. UN Security Council Resolution
1244 (1999) placed Kosovo under a transitional
administration, the UN Interim Administration
Mission in Kosovo (UNMIK), pending a determi-
nation_of Kosovo''s future status. A UN-led process
began in late 2005 to determine Kosovo''s final sta-
tus. The negotiations ran in stages between 2006
and 2007, but ended without agreement between
Belgrade and Pristina. On 17 February 2008, the
Kosovo Assembly declared Kosovo independent.
Since then, over 95 countries have recognized
Kosovo, and it has joined the International Mon-
etary Fund, World Bank, and European Bank for
Reconstruction and Development, and is in the
process of signing a framework agreement with
the European Investment Bank (EIB). In October
2008, Serbia sought an advisory opinion from the
International Court of Justice (ICJ) on the legal-
ity under international law of Kosovo''s declaration
of independence. The ICJ released the advisory
opinion in July 2010 affirming that Kosovo''s
declaration of independence did not violate gen-
eral principles of international law, UN Security
Council Resolution 1244, or the Constitutive
Framework. The opinion was closely tailored to
Kosovo''s unique history and circumstances. Ser-
bia continues to reject Kosovo''s independence,
but the two countries are currently engaged in an
EU-facilitated dialogue aimed at normalizing the
countries” relations.
y GEOGRAPHY
Location: Soùtheast Europe, between Serbia and
Macedonia
Geographic coordinates: 42 35 N, 21 00 E
Map references: Europe
Area: total: 10,887 sq km
country comparison to the world: 169
land: 10,887 sq km
water: 0 sq km
Area—comparative:
Delaware
Land boundaries: total: 702 km
border countries: Albania 112 km, Macedonia
159 km, Montenegro 79 km, Serbia 352 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
Climate: influenced by continental air masses
resulting in relatively cold wigters with heavy
slightly larger than
KOSOVO
snowfall and hot, dry summers and autumns; Med-
iterranean and alpine influences create regional
variation; maximum rainfall between October and
December i
Terrain: fiat fluvial basin with an elevation of
400-700 m above sea level surrounded by several
high mountain ranges with elevations of 2,000 to
2,500 m
Elevation extremes: lowest point: Drini i
Bardhe/Beli Drim 297 m (located on the border
with Albania)
highest point: Gjeravica/Deravica 2,656 m
Natural resources: nickel, lead, zinc, magnesium,
lignite, kaolin, chrome, bauxite
Background: Britain oversaw foreign relations
and defense for the ruling Kuwaiti AL-SABAH
dynasty from 1899 until independence in 1961.
Kuwait was attacked and overrun by Iraq on 2
a
KOSOVO
country comparison to the world: 119
Electricity—consumption: 5.674 billion kWh
(2011) i
country comparison to the world: 110
Crude oli—proved reserves: NA bbl (1 January
2012 est.)
Refined petroleum products—production: 0
bbl/day (2007)
country comparison to the world: 162
Refined petroleum products—consumption:
NA bbl/day (2011 est.)
Natural gas—production: 0 cu m(2007)
country comparison to the world: 150
Natural gas—consumption: 0 cu m (2007)
country comparison to the world: 161
Natural gas—proved reserves: NA cu m (2011
est.)
predominantly targeting ethnic Serbs in Kosovo
in March 2004 caused the international commu-
nity to open negotiations on the future status of
Kosovo in January 2006. In June 2006, Montene-
gro seceded from the federation and declared itself
an independent nation. Serbia subsequently gave
notice that it was the successor state to the union
of Serbia and Montenegro. In February 2008,
after nearly two years of inconclusive negotia-
tions, the UN-administered province of Kosovo
declared itself independent of Serbia—an action
Serbia refuses to recognize. At Serbia’s request,
the UN General Assembly (UNGA) in Octo-
ber 2008 sought an advisory opinion from the
International Court of Justice (ICJ) on whether
Kosovo''s unilateral declaration of independence
was in accordance with international law. In a
ruling considered unfavorable to Serbia, the IC]
issued an advisory opinion in July 2010 stating
that international law did not prohibit declara-
tions of independence. In late 2010, Serbia agreed
to an EU-drafted UNGA Resolution acknowledg-
ing the IC}’s decision and calling for a new round
of talks between Serbia and Kosovo, this time on
practical issues rather than Kosovo''s status. The
EU-moderated Belgrade-Pristina dialogue began
in March 2011 and was raised to the level of prime
ministers in October 2012.
Background: A lengthy struggle between France
and Great Britain for the islands ended in 1814,
when they were ceded to the latter. Independence
came in 1976. Socialist rule was brought to a close
with a new constitution and free elections in 1993.
President France-Albert RENE, who had served
since 1977, was re-elected in 2001, but stepped
down in 2004. Vice President James MICHEL
took over the presidency and in July 2006 was
elected to a new five-year term; he was reelected
in May 2011.','14a8549b545894a01607ce16b191c5f4a0919e882803be769f011ddc5f30bce7','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3142720449b0d5cac76c344270a401f969eba7c8386ea40d394c4191e9dde631',2025,'KW','Kuwait','introduction',940,'Background: A Central Asian country of incred-
ible natural beauty and proud nomadic traditions,
most of Kyrgyzstan was formally annexed to Russia
in 1876. The Kyrgyz staged a major revolt against
the Tsarist Empire in 1916 in which almost one-
sixth of the Kyrgyz population was killed. Kyr-
gyzstan became a Soviet republic in 1936 and
achieved independence in 1991 when the USSR
dissolved. Nationwide demonstrations in the
spring of 2005 resulted in the ouster of President
Askar AKAEV, who had run the country since
1990. Subsequent presidential elections in July
2005 were won overwhelmingly by former prime
minister Kurmanbek BAKIEV. Over the next few
years, the new president manipulated the parlia-
Ment to accrue new powers for himself. In July
2009, after months of harassment against his oppo-
nents and media critics, BAKIEV won re-election
in a presidential campaign that the international
community deemed flawed. In April 2010, violent
protests in Bishkek led to the collapse of the BA
KIEV regime and his eventual fleeing to Minsk,
Belarus. His successor, Roza OTUNBAEVA,
served as transitional president until Almazbek
ATAMBAEV was inaugurated in December
2011. Continuing concerns include: the trajec-
tory of democratization, endemic corruption, poor
interethnic relations, and terrorism.','2a0698c3eda8df792c44905fd744cc755dd60d9306c9d58f8498c2a05b05299f','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b26b0a91174c579acc671049254d8280d389c68f69dc8cd61bb1f7ce7663d12d',2025,'KG','Kyrgyzstan','introduction',951,'Background: Modem-day Laos has its roots in the
ancient Lao kingdom of Lan Xang, established in
the 14th century under King FA NGUM. For 300
` ‘Years Lan Xang had influence reaching into pre-
sent-day Cambodia and Thailand, as well as over
all of what is now Laos. After centuries of gradual
decline, Laos came under the domination of Siam
(Thailand) from the late 18th century until the late
49th century when it became part of French Indo-
china. The Ftanco-Siamese Treaty of 1907 defined
the current Lao border with Thailand. In 1975, the
Communist Pathet Lao took control of the gov-
emment ending a six-century-old monarchy and
instituting a strict socialist regime closely aligned
to Viemam. A gradual, limited return to private
enterprise and the liberalization of foreign invest-
ment laws began in 1988. Laos became a member
of ASEAN in 1997 and the WTO in 2013.','0fa4be861fd3c7671ac43709340cc11ba331f84a4ccdc0f4f259dea9f59fcd1a','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('90723e956578212f6c161f807d6a3cc1f1818d8e85819a2c0a9a3b93a5aa9d7f',2025,'LT','Lithuania','introduction',954,'Background: The name “Latvia” originates from
the ancient Latgalians, one of four eastern Baltic
tribes that formed the ethnic core of the Latvian
people (ca. 8th-12th centuries A.D.). The region
subsequently came under the control of Germans,
Poles, Swedes, and finally, Russians. A Latvian
republic emerged following World War I, but it was
annexed by the USSR in 1940—an action never
recognized by the US and many other countries.
Latvia reestablished its independence in 1991 fol-
lowing the breakup of the Soviet Union. Although
the last Russian troops left in 1994, the status of
the Russian minority (some 28% of the popula-
tion) remains of concern to Moscow. Latvia joined
both NATO and the EU in the spring of 2004.
Background: Founded in 963, Luxembourg
became a grand duchy in 1815 and an independ-
ent state under the Netherlands. It lost more than
half of its territory to Belgium in 1839 but gained
a larger measure of autonomy. Full independence
was attained in 1867. Overrun by Germany in
both world wars, it ended its neutrality in 1948
when it entered into the Benelux Customs Union
and when it joined NATO the following year. In
1957, Luxembourg became one of the six founding
countries of the European Economic Community
(later the European Union), and in 1999 it joined
the euro currency area. In January 2013, Luxem-
bourg assumed a nonpermanent seat on the UN
Security Council for the 2013-14 term.','bf3615a7f3cf8301caea150baff4c17bd16788d2d196000b33a7ef69025eb160','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d29ad90fda46f8e6ec1f573da12f18884c4eb2b7d88471a82b957e79fedfe7a4',2025,'LB','Lebanon','introduction',964,'Background: Following World War I, France
acquired a mandate over the northern portion of
the former Ottoman Empire province of Syria.
The French demarcated the region of Lebanon
in 1920 and granted this area independence in
1943. Since independence: the country has been
marked by periods of political turmoil interspersed
with prosperity built on its position as a regional
center for finance and trade. The country’s 1975-
90 civil war that resulted in an estimated 120,000
fatalities, was followed by years of social and politi-
cal instability. Sectarianism is a key element of
Lebanese political life. Neighboring Syria has long
influenced Lebanon''s foreign policy and internal
policies, and its military occupied Lebanon from
1976 until 2005. The Lebanon-based Hizballah
militia and Israel continued attacks and counterat-
tacks against each other after Syria’s withdrawal,
and fought a brief war in 2006. Lebanon’s borders
with Syria and Israel remain unresolved.
417
includes Lebanese Navy (Al Quwwat al Bahiriyya
al Lubnaniya), Lebanese Air Force (Al Quwwat al
Jawwiya al Lubnaniya)) (2013)
Military service age and obligation: 17-30
years of age for voluntary military service; 18-24
years of age for officer candidates; no conscription
(2013)
Manpower available for military service:
males age 16-49: 1,081,016
females age 16-49: 1,115,349 (2010 est.)
Manpower fit for military service: males age
16-49: 920,825
females age 16-49: 941,806 (2010 est.)
Manpower reaching militarily significant age
annually: male: 36,856
female: 35,121 (2010 est.)
Military expenditures: 2.5% of GDP (2012)
country comparison to the world; 55','9dcc6e0fbd07add85035050716c6364376861c7d4155387a1028855718e3dd24','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('712103a488b21324a104d901e9b28bd6ccaa6df7888c0c6fbed75a543e20b214',2025,'ZA','South Africa','introduction',973,'Background: Basutoland was renamed the King-
dom of Lesotho upon independence from the
UK in 1966. The Basuto National Party ruled
the country during its first two decades. King
MOSHOESHOE was exiled in 1990, but returned
to Lesotho in 1992 and was reinstated in 1995
arid subsequently succeeded by his son, King
LETSIE Ill, in 1996. Constitutional government
was restored in 1993 after seven years of mili-
tary rule. In 1998, violent protests and a military
mutiny following a contentious election prompted
a brief but bloody intervention by South African
and Batswana military forces under the aegis of
the Southern African Development Commu-
nity. Subsequent constitutional reforms restored
relative political stability. Peaceful parliamentary
elections were held in 2002, but the National
Assembly elections of February 2007 were hotly
contested and aggrieved parties disputed how the
electoral law was applied to award proportional
seats in the Assembly. In May 2012, competitive
elections involving 18 parties saw Prime Minister
Motsoahae Thomas THABANE form a coalition
Background: The islands, which have large bird
and seal populations, lie approximately 1,000 km
east of the Falkland Islands and have been under
British administration since 1908—except for a
brief period in 1982 when Argentina occupied
them. Grytviken, on South Georgia, was a 19th
and early 20th century whaling station. Famed
explorer Ernest SHACKLETON stopped there
in 1914 en route to his ill-fated attempt to cross
Antarctica on foot. He returned some 20 months
later with a few companions in a small boat and
arranged a successful rescue for the rest of his crew,
stranded off the Antarctic Peninsula. He died in
1922 on a subsequent expedition and is buried in
Grytviken. Today, the station houses scientists
\\
from the British Antarctic Survey. Recognizing
the importance of preserving the marine stocks
in adjacent waters, the UK, in 1993, extended
the exclusive fishing zone from 12 nm to 200 nm
around each island.
Background: A large body of recent oceano-
graphic research has shown, that the Antarctic
Circumpolar Current (ACC), an ocean current
that flows from west to east around Antarctica,
plays a crucial role in global ocean circulation,
The region where the cold waters of the ACC
meet and mingle with the warmer waters of the
north defines a distinct border—the Antarctic
Convergence—which fluctuates with the seasons,
but which encompasses a discrete body of water
and a unique ecologic region. The Convergence
concentrates nutrients, which promotes marine
plant life, and which, in turn, allows for a greater
abundance of animal life. In the spring of 2000, the
International Hydrographic Organization decided
to delimit the waters within the Convergence as
a fifth world ocean—the Southern Qcean—by
combining the southern portions of the Atlantic
Ocean, Indian Ocean, and Pacific Ocean. The
Southern Ocean extends from the coast of Ant-
arctica north to 60 degrees south latitude, which
coincides with the Antarctic Treaty Limit and
which approximates the extent of the Antarctic
Convergence. As such, the Southern Ocean is
now the fourth largest of the world''s five oceans
(after the Pacific Ocean, Atlantic Ocean, and
Indian Ocean, but larger than the Arctic Ocean).
It should be noted that inclusion of the Souther
Ocean does not imply recognition of this feature
as one of the world’s primary oceans by the US
Background: Spain’s powerful world empire of the
16th and 17th centuries ultimately yielded com-
mand of the seas to England. Subsequent failure to
embrace the mercantile and industrial revolutions
caused the country to fall behind Britain, France,
and Germany in economic and political power.
Spain remained neutral in World Wars I and II but
suffered through a devastating civil war (1936-39).
A peaceful transition to democracy following the
death of dictator Francisco FRANCO in 1975,
and rapid economic modernization (Spain joined
the EU in 1986) gave Spain a dynamic and rap-
idly growing economy and made it a global cham-
pion of freedom and human rights. More recently
the government has had to focus on measures to
reverse a severe economic recession that began
in mid-2008. Austerity measures implemented to
reduce a large budget deficit and reassure foreign
investors have led to one of the highest unemploy-
ment rates in Europe.','fcf396910dfc53b3bcd5c2a6f6051c2f42ef87233bdf25b6c02f4418ad271471','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8c1947ba9195390a5925afcb5f1be13cb764fd95dccb78f120a60765eb02cc45',2025,'LR','Liberia','introduction',983,'Background: Settlement of freed slaves from the
US in what is today Liberia began in 1822; by
1847, the Americo-Liberians were able to establish
a republic. William TUBMAN, president from
1944-71, did much to promote foreign investment
and to bridge the economic, social, and political
424
gaps between the descendants of the original set-
tlers and the inhabitants of the interior. In 1980,
a military coup led by Samuel DOE ushered in a
decade of authoritarian rule. In December 1989,
Charles TAYLOR launched a rebellion against
DOE''s regime that led to a prolonged civil war
in which DOE was killed. A period of relative
peace in 1997 allowed for elections that brought
TAYLOR to power, but major fighting resumed
in 2000. An August 2003 peace agreement ended
the war and prompted the resignation of former
president Charles TAYLOR, who faces war crimes
charges in The Hague related to his involvement
in Sierra Leone''s civil war. After two years of rule
by a transitional government, democratic elections
in late 2005 brought President Ellen JOHNSON
SIRLEAF to power. She subsequently won reelec-
tion in 2011 in a second round vote that was boy-
cotted by the opposition and remains challenged to
build Liberia’s economy and reconcile a nation still
recovering from 14 years of fighting. The United
Nations Security Council in September 2012
passed Resolution 2066 which calls for a reduction
of UN troops in Liberia by half by 2015, bringing
the troop total down to fewer than 4000, and chal-
lenging Liberia’s security sector to fill the gaps.','1bbadb3c6ea9e8952d837a1765833fb10bc49d2b14498dcf28b430b91400a474','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4e9dc0bb1f6d6e2a5c111247516685000ff0d5518c0f620ef410e9fa66f5f696',2025,'LY','Libya','introduction',992,'Background: The Italians supplanted the Ottoman
Turks in the area around Tripoli in 1911 and did not
relinquish their hold until 1943 when defeated in
World War Il. Libya then passed to UN administra-
tion and achieved independence in 1951. Following
a 1969 military coup, Col. Muammar al-QADHAFI
assumed leadership and began to espouse his political
system at home, which was a combination of social-
ism and Islam. During the 1970s, QADHAFI used
oil revenues to promote his ideology outside Libya,
supporting subversive, and terrorist activities that
included the downing of two airliners—one over
Scotland, another in Northern Africa—and a dis-
cotheque bombing in Berlin. UN sanctions in 1992
isolated QADHAFI politically and economically
following the attacks; sanctions were lifted in 2003
following Libyan acceptance of responsibility for the
bombings and agreement to claimant compensation.
QADHAFI also agreed to end Libya’s program to
develop weapons of mass destruction, and he made
significant strides in normalizing relations with
Western nations. Unrest that began in several Mid-
dle Eastern and North African countries in late 2010
erupted in Libyan cities in early 2011. QADHAFI’s
brutal crackdown on protesters spawned a civil war
that triggered UN authorization of air and naval
intervention by the international community. After
months of seesaw fighting between government
and opposition forces, the QADHAFI regime was
toppled in mid-2011 and replaced by a transitional
government. Libya in 2012 formed a new parliament
and elected a new prime minister.
alia GEOGRAPHY
Location: Northern Africa, bordering the Mediter-
ranean Sea, between Egypt, Tunisia, and Algeria
Geographic coordinates: 25 00 N, 17 00 E
Map references: Africa
Area: total: 1,759,540 sq km
country comparison. to the world: 17
land: 1,759,540 sq km
water: 0 sq km
Area—comporative: slightly larger than Alaska
Land boundaries: total: 4,348 km
border countries: Algeria 982 km, Chad 1,055
km, Egypt 1,115 km, Niger 354 km, Sudan 383
km, Tunisia 459 km
428
Coastline: 1,770 km
Maritime claims: territorial sea: 12 nm
note: Gulf of Sidra closing line—32 degrees, 30
minutes north
exclusive fishing zone: 62 nm
Climate: Mediterranean along coast; dry, extreme
desert interior
Terrain: mostly barren, flat to undulating plains,
plateaus, depressions
Elevation extremes: lowest point: Sabkhat Ghu-
zayyil -47 m
highest point: Bikku Bitti 2,267 m
Natural resources: petroleum, natural gas, gypsum
Land use: arable land: 0.99%
permanent crops: 0.19%
other: 98.82% (2011)
Irrigated land: 4,700 sq km (2003)
Total renewable water resources: 0.7 cu km
(2011) i
Freshwater withdrawal (domestic/industriat/
agricultural): total: 4.33 cu km/yr (14%/3%/83%)
per capita: 796.1 cu m/yr (2000)
Natural hazards: hot, dry, dust-laden ghibli is a
southern wind lasting one to four days in spring
and fall; dust storms, sandstorms
Environment—current issues: desertification;
limited natural freshwater resources; the Great
Manmade River Project, the largest water develop-
ment scheme in the world, brings water from large
aquifers under the Sahara to coastal cities
Environment—international agreements:
party to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Endan-
gered Species, Hazardous Wastes, Marine Dump-
ing, Ozone Layer Protection, Ship Pollution,
Wetlands
signed, but not ratified: Law of the Sea
Geography—note: more than 90% of the country
is desert or semidesert','13b379d3a652e0c98cf3d7c001484da5113dbea811e7118f5668323a06a94d3f','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3b432bb978d4b590fae46e16c0cbc628f1cc514cf7b3f394d00e51de8c477279',2025,'LI','Liechtenstein','introduction',1000,'Background: The Principality of Liechtenstein
was established within the Holy Roman Empire
in 1719. Occupied by both French and Russian
troops during the Napoleonic Wars, it became a
sovereign state in 1806 and joined the Germanic
Confederation in 1815. Liechtenstein became
fully independent in 1866 when the Confedera-
tion dissolved. Until the end of World War I, it
was closely tied to Austria, but the economic
devastation caused by that conflict forced Liech-
tenstein to enter into a customs and monetary
union with Switzerland. Since World War II (in
which Liechtenstein remained neutral), the coun-
try’s low taxes have spurred outstanding economic
growth. In 2000, shortcomings in banking regula-
tory oversight resulted in Zoncerns about the use
of financial institutions for money laundering.
However, Liechtenstein implemented anti-money
laundering legislation and a Mutual Legal Assis-
tance Treaty with the US that went into effect in
2003.','27ebf9b744d5ca6c4a99196fd8db55ec83c4efd7664e55e22df4b2b746b4189a','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('882ba60f92fa92ecb030af7940869c8bfbdb904f063726e7073be391fb533ac2',2025,'LU','Luxembourg','introduction',1021,'Background: Colonized by the Portuguese in the
16th century, Macau was the first European settle-
ment in the Far East. Pursuarit to an agreement
signed by China and Portugal on 13 April 1987,
Macau became the Macau Special Administra-
tive Region (SAR) of the People’s Republic of
China on 20 December 1999. In this agreement,
China promised that, under its “one country, two
systems” formula, China''s political and economic
system would not be imposed on Macau, and that
Macau would enjoy a high degree of autonomy in
all matters except foreign affairs and defense for
the next 50 years.','4d586ff733fea927a75157357abf9cf22093cd8bc25dea331b36d11b15d9678e','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9c77e871fcf8dc2bcac370544f82845e0d76fdb903b7d5ff6982af52aad317ca',2025,'MG','Madagascar','introduction',1026,'Background: Formerly an independent kingdom,
Madagascar became a French colony in 1896 but
regained independence in 1960. During 1992-93,
free presidential and National Assembly elections
were held ending 17 years of single-party rule.
In 1997, in the second presidential race, Didier
RATSIRAKA, the leader during the 1970s and
1980s, was returned to the presidency. The 2001
presidential election was contested between the
followers of Didier RATSIRAKA and Marc RAV-
ALOMANANA, nearly causing secession of half of
the country. Jn April 2002, the High Constitutional
Court announced RAVALOMANANA the win-
ner. RAVALOMANANA achieved a second term
following a landslide victory in the generally free
and fair presidential elections of 2006. In early 2009,
protests over increasing restrictions on opposition
press and activities resulted in RAVALOMANANA
handing over power to the military, which then con-
ferred the presidency on the mayor of Antanana-
rivo, Andry RAJOELINA, in what amounted to a
coup d''etat. Numerous attempts have been made by
regional and international organizations to resolve
the subsequent political gridlock by forming a power-
sharing government. Madagascar’s independent
electoral commission and the UN originally planned
to hold a presidential election in early May 2013, but
postponed the election until late July 2013, due to
logistical delays.','76067ed01aee4b30f98950ca9020ff985b9790c9bfe44a61d264dae2f724edbb','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9c28a720769e966e9289fd6f2a2a59cb820e91f27ad6d9c9f7a718a02b730833',2025,'ZM','Zambia','introduction',1035,'Background: Established in 1891, the British pro-
tectorate of Nyasaland became the independent
nation of Malawi in 1964. After three decades of
one-party rule under President Hastings Kamuzu
BANDA the country held multiparty elections in
1994, under a provisional constitution that came
into full effect the following year. President Bin-
guwa MUTHARIKA, elected in May 2004 after a
failed attempt by the previous president to amend
the constitution to permit another term, struggled
to assert his authority against his predecessor and
subsequently started his own party, the Democratic
Progressive Party (DPP) in 2005. MUTHARIKA
was reelected to a second term in May 2009. As
president, he oversaw some economic improve-
ment in his first term, but was accused of economic
mismanagement and poor governance in his sec-
ond term. He died abruptly in April 2012 and was
succeeded by his vice president, Joyce BANDA.
Population growth, increasing pressure on agri-
cultural lands, corruption, and the spread of HIV/
AIDS pose major problems for Malawi.','a5c65111ceaebee08ecccc05148a472782fc9ac735f935ce9b11ea3110df2d80','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2da6bfa560587aa4b08276879d0778bf6ece256d5f98e41c07dabad8212c63e6',2025,'MY','Malaysia','introduction',1047,'Background: During the late 18th and 19th centu-
ries, Great Britain established colonies and protec-
torates in the area of current Malaysia; these were
occupied by Japan from 1942 to 1945. In 1948, the
British-ruled territories on the Malay Peninsula
except Singapore formed the Federation of Malaya,
which became independent in 1957. Malaysia was
formed in 1963 when the former British colonies
of Singapore, as well as Sabah and Sarawak on the
northern coast of Borneo, joined the Federation.
The first several years of the country’s independence
were marred by a Communist insurgency, Indonesian
confrontation with Malaysia, Philippine claims to
Sabah, and Singapore''s withdrawal in 1965. During
the 22-year term of Prime Minister MAHATHIR bin
Mohamad (1981-2003), Malaysia was successful in
diversifying its economy from dependence on exports
of raw materials to the development of manufactur-
ing, services, and tourism. Prime Minister Mohamed
NAJIB bin Abdul Razak (in office since April 2009)
has continued these pro-business policies and has
introduced some civil reforms.
Background: A sultanate since the 12th cen-
tury, the Maldives became a British protector-
ate in 1887. It became a republic in 1968, three
years after independence. President Maumoon
Abdul GAYOOM dominated the islands’ political
scene for 30 years, elected to six successive terms
by single-party referendums. Following political
demonstrations in the capital Male in August
2003, the president and his government pledged
to embark upon democratic reforms including a
more representative political system and expanded
political freedoms. Progress was sluggish, however,
and many promised reforms were slow to be real-
ized. Nonetheless, political parties were legalized
in 2005. In June 2008, a constituent assembly—
termed the “Special Maijlis"—finalized a new
constitution, which was ratified by the president
in August. The first-ever presidential elections
under a multi-candidate, multi-party system were
held in October 2008. GAYOOM was defeated in
a runoff poll by Mohamed NASHEED, a political
activist who had been jailéd several years earlier
by the former regime. President NASHEED faced
a number of challenges including strengthen-
ing democracy and combating poverty and drug
abuse. In easly February 2012, after several weeks
of street protests following his sacking of a top
judge, NASHEED resigned the presidency and
handed over power to Vice President Moham-
med WAHEED Hassan Maniku. In mid-2012, the
Commission of National Inquiry was set by the
Government to probe events leading to the regime
change. Though no evidence of a coup was found,
the report recommended the need to strengthen
the countrys democratic institutions to avert
similar events in the future, and to further inves-
tigate alleged police misconduct during the crisis.
Maldives officials have played a prominent role in
international climate change discussions (due to
the islands’ low elevation and the threat from sea-
level rise) on the United Nations Human Rights
Council, and in encouraging regional cooperation,
especially between India and Pakistan.','d8700c65e8a9bb06c95ccc3ed91faa099aec45914bf21652fd2e9cf03cc24dcf','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('24f6252444640bf0ae9b887e43004d86a9dbc5f875571fed242cdd6b53f442d1',2025,'MR','Mauritania','introduction',1064,'Background: The Sudanese Republic and Senegal
became independent of France in 1960 as the Mali
Federation. When Senegal withdrew after only a
few months, what formerly made up the Sudanese
Republic was renamed Mali. Rule by dictatorship
was brought to a close, in 1991 by a military coup
that ushered in a period of democratic rule. Presi-
dent Alpha KONARE won Mali’s first two demo-
cratic presidential elections in 1992 and 1997. In
keeping with Malis two-term constitutional limit,
he stepped down in 2002 and was succeeded by
Amadou TOURE, who was elected to a second
term in 2007 elections that were widely judged
to be free and fair. Malian returnees from Libya in
2011 exacerbated tensions in northern Mali, and
Tuareg ethnic militias started a rebellion in Janu-
ary 2012. Low—and mid-level soldiers, frustrated
with the poor handling of the rebellion overthrew
TOURE on 22 March. Intensive mediation efforts
led by the Economic Community of West African
States (ECOWAS) returned power to a civilian
administration in April with the appointment of
interim President Dioncounda TRAORE. The
post-coup chaos led to rebels expelling the Malian
military from the three northern regions of the
country and allow ed Islamic militants to set up
strongholds, Hundreds of thousands of northern
Malians fled the violence to southern Mali and
neighboring countries, exacerbating regional food
462
THE CIA,.WORLD FACTBOOK
Background: Although known to Arab and Malay
sailors as early as the 10th century, Mauritius was
first explored by the Portuguese in the 16th century
and subsequently settled by the Dutch—who named
it in honor of Prince Maurits van NASSAU—in
the 17th century. The French assumed control
in 1715, developing the island into an important
naval base overseeing Indian Ocean trade, and
establishing a plantation economy of sugar cane.
The British captured the island in 1810, during
the Napoleonic Wars. Mauritius remained a strate-
gically important British naval base, and later an
air station, playing an important role during World
War II for anti-submarine and convoy operations,
as well as the collection #f signals intelligence.','63c1a83e7f1dcbe7879bf57b9c01874b2193b689bfa9c1d471aaebb6df4fc529','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cc7b027f8348b9a9d6613866da56e37f254116aefbf8d474e978a52728d48985',2025,'ML','Mali','introduction',1075,'Background: Great Britain formally acquired pos-
session of Malta in 1814. The island staunchly
supported the UK through both world wars and
remained in the Commonwealth when it became
independent in 1964. A decade later Malta became
a republic. Since about the mid-1980s, the island has
transformed itself into a freight transshipment point,
a financial center, and a tourist destination. Malta
became an EU member in May 2004 and began
using the euro as currency in 2008.','2e9b8d237abc0d22c4f0a644f2fe104ccfcf23c91095e64ce9600ecb01be4bd3','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4ba186e7296db4a2228b0660fcc1d8eb0ef830d4628653a4c2eff1af9f24a2ef',2025,'MH','Marshall Islands','introduction',1085,'Background: After almost four decades under
US administration as the easternmost part of
the UN Trust Territory of the Pacific Islands, the
Marshall Islands attained independence in 1986
-under a Compact of Free Association. Compen-
sation claims continue as a result of US nuclear
testing on some of the atolls between 1947 and
1962. The Marshall Islands hosts the US Army
Kwajalein Atoll (USAKA) Reagan Missile Test
Site, a key installation in the US missile defense
network.
Background: Independent fromFrance in 1960,
Mauritania annexed the southerm third of the
former Spanish Sahara (nowWestern Sahara) in
1976 but relinquished it after three years of raids
by the Polisario guerrilla front seeking independ-
ence for the territory. Maaouya Ould Sid Ahmed
TAYA seized power in a coup in 1984 and riled
Mauritania with a heavy hand for more than two
decades. A series of presidential elections that he
held were widely seen as flawed. A bloodless coup
in August 2005 deposed President TAYA and ush-
ered in a military council that oversaw a transition
to democratic rule. Independent candidate Sidi
Ould Cheikh ABDALLAHI was inaugurated in
April 2007 as Mauritania’s first freely and fairly
elected president. His termended prematurely in
August 2008 when a military junta led by Gen-
eral Mohamed Ould Abdel AZIZ deposed himand
installed a military council government. AZIZ was
subsequently elected president in July 2009 and
sworn in the following month. AZIZ sustained
injuries froman accidental shooting by his own
troops in October 2012, but has continued to
maintain his authority. The country continues to
experience ethnic tensions among its black popu-
lation (Afro-Mauritanians) and white and black
Moor (Arab-Berber) communities, and is having
to confront a growing terrorismthreat by al-Qaida
in the Islamic Maghreb (AQIM).','bf0992d5a43e1a7584cb8a91e50de2a793b53251f0f1992d3f8fde8c41d82240','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ed136d33628a476053ac966eafacddd3451ec0679fccba0f2a96f121764fc1d3',2025,'MX','Mexico','introduction',1103,'Background: In 1979 the Federated States of
Micronesia, a UN Trust Territory under US admin-
istration, adopted a constitution. In 1986, inde-
pendence was attained under a Compact of Free
Association with the US, which was amended and
renewed in 2004. Present concerns include large-
scale unemployment, overfishing, and overdepend-
ence on US aid.','f174994b8a006388bb23b2ffc807c9ff538beb3e437b55270ed4bf976958ab85','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0a95aa42a3dbea85059dcf82df87bbb74c984774e91ff59c499e6bd872f62251',2025,'RO','Romania','introduction',1107,'Background: Part of Romania during the inter-
war period, Moldova was incorporated into
the Soviet Union at the close of World War Il.
Although the country has been independent
from the USSR since 1991, Russian forces have
remained on Moldovan territory east of the Nistru
River supporting a Transnistrian separatist region
composed of a Slavic majority population (mostly
Ukrainians and Russians), but with a sizeable
ethnic Moldovan minority. One of the poorest
nations in Europe, Moldova became the first for-
mer Soviet state to elect a Communist, Vladimir
VORONIN, as its president in 2001. VORONIN
served as Moldova’ president until he resigned
in September 2009, following the opposition’s
gain of a narrow majority in July parliamentary
elections and the Communist Party’s (PCRM)
subsequent inability to attract the three-fifths of
parliamentary votes required to elect a president.
Four Moldovan opposition parties formed a new
coalition, the Alliance for European Integration
(AEI), which has acted as Moldova''s governing
coalition since. Moldova experienced significant
political uncertainty between 2009 and early
2012, holding three general elections and numer-
ous presidential ballots in parliament, all of which
failed to secure a president. Following November
2010 parliamentary elections, a reconstituted
AEl-coalition consisting of three of the four
original AEI parties formed a government, and in
March 2012 was finally able to elect an independ-
ent as president.
Background: The Genoese built a fortress on the
site of present day Monaco in 1215. The current
tuling Grimaldi family first seized temporary control
in 1297, and again in 1331, but were not able to
permanently secure their holding until 1419. Eco-
nomic development was spurred in the late 19th
century with a railroad linkup to France and the
opening of a casino. Since then, the principality’s
mild climate, splendid scenery, and gambling facili-
ties have made Monaco world famous as a tourist
and recreation center.
Background: Founded in the 12th century, the
Principality of Muscovy, was able to emerge from
over 200 years of Mongol domination (13th-15th
centuries) and to gradually conquer and absorb
surrounding principalities: In the early 17th
century, a new Romanov Dynasty continued this
policy of expansion across Siberia to the Pacific.
Under PETER | (ruled 1682-1725), hegemony
was extended to the Baltic Sea and the country
was renamed the Russian Empire. During the 19th
century, more territorial acquisitions were made
in Europe and Asia. Defeat in the Russo-Japanese
War of 1904-05 contributed to the Revolution of
1905, which resulted in the formation of a parlia-
ment and other reforms. Repeated devastating
defeats of the Russian army in World War | led
to widespread rioting in the major cities of the
Russian Empire and to the overthrow in 1917 of
the imperial household. The Communists under
Vladimir LENIN seized power soon after and
formed the USSR. The brutal rule of losif STALIN
(1 928-53) strengthened Communist rule and Rus-
sian dominance of the Soviet Union at a cost of
tens of millions of lives. The Soviet economy and
society stagnated in the following decades until
General Secretary Mikhail GORBACHEV (1985-
91) introduced glasnost (openness) and pere-
stroika (restructuring) in an attempt to modern-
ize Communism, but his initiatives inadvertently
released forces that by December 1991 splintered
the USSR into Russia and 14 other independent
republics, Since then, Russia has shifted its post-
Soviet democratic ambitions in favor of a central-
ized semi-authoritarian state in which the leader-
ship seeks to legitimize its rule through managed
national elections, populist appeals by President
PUTIN, and continued economic growth. Russia
599
has severely disabled a Chechen rebel movement,
although violence still occurs throughout the
North Caucasus.','be36595c20bca13c0c5886e6ef1a195cb9f82fc270560e23c9190e3d65d84bbc','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('85a90296886096795c7c07f9979a05d37ab706945fd88e4641dd4f06ccd9e74c',2025,'MN','Mongolia','introduction',1127,'Background: The use of the name Crna Gora
Qvfintenepro) began in the 13th century in refer-
ence to a highland region in the Serbian province
of Zeta. The later medieval state of Zeta main-
tained its existence until 1496 when Montenegro
finally fell under Ottoman rule. Over subsequent
genturies, Montenegro, while a part of the Otto-
man Empire, was able to maintain a level of auton-
omy. From the 16th to 19th centuries, Montenegro
was a theocracy ruled by a series of bishop princes;
in 1852, it was transformed into a secular princi-
pality. Montenegro was recognized as an independ-
ent sovereign principality at rhe Congress of Berlin
in 1878. After World War I, during which Monte-
negro fought on the side of the Allies, Montenegro
was absorbed by the Kingdom of Serbs, Croats, and
Slovenes, which became the Kingdom of Yugosla-
via in 1929; at the conclusion of World War II,
it became a constituent republic of the Socialist
Federal Republic of Yugoslavia. When the latter
dissolved in 1992, Montenegro federated with Ser-
bia, first as the Federal Repyblic of Yugoslavia and,
after 2003, in a looser State Union of Serbia and
Montenegro. In May 2006, Montenegro invoked
its right under the Constitutional Charter of Ser-
bia and Montenegro to hold a referendum on inde-
pendence from the state union. The vote for sev-
ering ties with Serbia barely exceeded 55%—the
threshold set by the EU—allowing Montenegro to
formally restore its independence on 3 June 2006.','a2bd6f0878c7fc9644fdb2411a047833b249f69c7051be595f00ee61eb44d585','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6c46eb247b9e29bb25d351b15a05019a91e837dd0d1e38ebdce61543dc003619',2025,'MS','Montserrat','introduction',1138,'Background: English and Irish colonists from St.
Kitts first settled on Montserrat in 1632; the first
African slaves arrived three decades later. The Brit-
ish and French fought for possession of the island
for most of the 18th century, but it finally was con-
firmed as a British possession in 1783. The island''s
sugar plantation economy was converted to small
farm landholdings in the mid 19th century. Much
of this island was devastated and two-thirds of the
population fled abroad because of the eruption of
the Soufriere Hills Volcano that began on 18 July
1995. Montserrat has endured volcanic activity
since, with the last eruption occurring in July 2003.','a1d2416c0485f0fb80b296254f621809401de634754eb0df20c0a922908bc79b','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a6a22f12724ec839543ba2eb0575a927e7c303d9cf3c0dcec03c6538fdccdd78',2025,'MA','Morocco','introduction',1147,'Background: In 788, about a century after the
Arab conquest of North Africa, a series of Moroc-
can Muslim dynasties began to rule in Morocco.
In the 16th century, the Sa’adi monarchy, par-
ticularly under Ahmad al-MANSUR (1578-
1603), repelled foreign invaders and inaugurated
a golden age. The Alaouite dynasty, to which
the current Moroccan royal family belongs, dates
from the 17th century. In 1860, Spain occupied
northern Morocco and ushered in a half century
of trade rivalry among European powers that saw
Morocco’s sovereignty steadily erodes in 1912, the
French imposed a protectorate over the country.
A protracted independence struggle with France
ended successfully in 1956. The internationalized
city of Tangier and most Spanish possessions were
turned over to the new country that same year.
Sultan MOHAMMED V, the current monarch’s
grandfather, organized the new state as a con-
stitutional monarchy and in 1957 assumed the
title of king. Although Morocco is not the UN-
recognized Administering Power for the West-
ern Sahara, it exercises de facto administrative
500
control there. The UN assists with direct negotia-
tions between Morocco and the Polisario Front,
but the status of the territory remains unresolved.
Gradual political reforms in the 1990s resulted
in the establishment of a bicameral legislature,
which first met in 1997. Morocco enjoys a mod-
erately free press, but the government has taken
action against journalists who they perceive to be
challenging the monarchy, Islam, or the status of
Western Sahara. Influenced by protests elsewhere
in the region, in February 2011 thousands of
Moroccans began weekly rallies in multiple cities
across the country to demand greater democracy
and end to government corruption, Overall the
response of Moroccan security forces was subdued
compared to the violence elsewhere in the region.
King MOHAMMED VI responded quickly with
a reform program that included a new constitu-
tion and early elections. The constitution was
passed by popular referendum in July 2011; some
new powers were extended to parliament and the
prime minister, but ultimate authority remains in
the hands of the monarch, In early elections in
November 2012, the Justice and Development
Party—a moderate Islamist party, won the largest
number of seats, becoming the first Islamist party
to lead the Moroccan Government. In January
2012, Morocco assumed a nonpermanent seat on
the UN Security Council for the 2012-13 term.','30dd66c5cc24372599bdbe384674b375558d92fa16e398568a1e6c9c53a30802','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('dd7ad5115a2c1a28a79ce6d1897ecc63d54789aeb03e99e7cac1aa33909a488e',2025,'MZ','Mozambique','introduction',1156,'Background: Almost five centuries as a Por-
tuguese colony came to a close with inde-
pendence in 1975. Large-scale emigration,
economic dependence on South Africa, a
severe drought, and a prolonged civil war
hindered the country’s development until the
mid 1990s. The ruling Front for the Libera-
tion of Mozambique (Frelimo) party formally
abandoned Marxism in 1989, and a new''con-
stitution the following year provided for mul-
tiparty elections and a free market economy. A
UN-negotiated peace agreement between Fre-
limo and rebel Mozambique National Resist-
ance (Renamo) forces ended the fighting
504
in 1992. In December 2004, Mozambique
underwent a delicate transition as Joaquim
CHISSANO stepped down after 18 years in
office. His elected successor, Armando Emilio
GUEBUZA, promised to continue the sound
economic policies that have encouraged
President GUEBUZA
was reelected to a second term in October
2009. However, the elections were flawed by
voter fraud, questionable disqualification of
candidates, and Frelimo use of government
resources during the campaign. As a result,
Freedom House removed Mozambique from its
list of electoral democracies.','1774d4e32130b993e3a118d028bbda5e61676d90bc075f0c1712acee91b64d4b','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e0928c0d3c89b1b1b30f63073daa383d7e20f91f27e790b03f1244cfb821edad',2025,'NA','Namibia','introduction',1171,'Background: The exact origins of the Nauruans
are unclear since their language does not resemble
-any other in the Pacific region. Germany annexed
the island in 1888. A German-British consortium
began mining the island’s phosphate depos-
its early in the 20th century. Australian forces
occupied Nauru in World War l; it subsequently
became a League of Nations mandate. After the
Second World War—and a brutal occupation by
Japan—Nauru became a UN trust territory. It
achieved independence in 1968 and joined the
UN in 1999 as the world’s smallest independent
republic.','162773a47a09c8386968efbf3164f1c5f236ef78a7711db72e861987ced0f38e','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ea564e4382b61a25fb912de9ee2ee4be70ad59ec8bed364a66121c802484536f',2025,'NR','Nauru','introduction',1180,'Background: This uninhabited island was claimed
by the US in 1857 for its guano. Mining took place
between 1865 and 1898. The lighthouse, built in
1917, was shut down in 1996 and administration
of Navassa Island transferred from the US Coast
Guard to the Department of the Interior. A 1998
scientific expedition to the island described it as a
unique preserve of Caribbean biodiversity; the fol-
lowing year it became a National Wildlife Refuge
and annual scientific expeditions have continued.
Background: In 1951, the Nepali monarch ended
the century-old system of rule by hereditary pre-
miers and instituted a cabinet system of govern-
ment. Reforms in 1990 established a multiparty
democracy within the framework of a constitu-
tional monarchy. An insurgency led by Maoist
extremists broke out in 1996. The ensuing 10-year
civil war between insurgents and government
forces witnessed the dissolution of the cabinet and
parliament and assumption of absolute power by
514
Area: total: 5.4 sq km
country comparison to the world: 246
land: 5.4 sq km
water: 0 sq km
Area—comparotive: about nine times the size of
The Mall in Washington, DC
Land boundaries: 0 km
Coastline: 8 km
Maritime claims: territorial sea: 12 nm
exclusive economic zone: 200 nm
Climate: marine, tropical
Terrain: raised coral and limestone plateau, flat to
undulating; ringed by vertical white cliffs (9 to 15
m high)
Elevation extremes: lowest point: Caribbean
Sea O m
highest point: unnamed elevation on southwest
side 77 m
Natural resources: guano
Land use: arable land: 0%
permanent crops: 0%
other: 100% (2011)
Natural hazards: hurricanes
Environment—current issues: NA
Geography—note: strategic location 160 km south of
the US Naval Base at Guantanamo Bay, Cuba; mostly
exposed rock with numerous solution holes (limestone
sinkholes) but with enough grassland to support goat
herds; dense stands of fig trees, scattered cactus','23ab973f323fc2b7ca4a25f5471ed49b5efe0f1e8f97ad7553e8be671fbe3b22','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0ee86c083bd23e2b3eb62d9ae338e9261fbbec2fed9e0e0a0e2c32304746e6ef',2025,'NL','Netherlands','introduction',1192,'Background: The Dutch United Provinces
declared their independence from Spain in 1579;
during the 17th century, they became a leading
seafaring and commercial power, with settlements
and colonies around the world. After a 20-year
French occupation, a Kingdom of the Netherlands
was formed in 1815. In 1830 Belgium seceded
and formed a separate kingdom. The Netherlands
remained neutral in World War I, but suffered
invasion and occupation by Germany in World
War Ii. A modern, industrialized nation, the
Netherlands is also a large exporter of agricultural
products. The country was a founding member of
NATO and the EEC (now the EU) and partici-
pated in the introduction of the euro in 1999. In
October 2010, the former Netherlands Antilles
was dissolved and the three smallest islands—
Bonaire, Sint Eustatius, and Saba—became special
municipalities in the Netherlands administrative
structure. The larger islands of Sint Maarten and
Curacao joined the Netherlands and Aruba as
constituent countries forming the Kingdom of the
Netherlands.
Background: Settled by both Britain and France
during the first half of the 19th century, the island
became a French possession in 1853. It served as
a penal colony for four decades after 1864. Agi-
tation for independence during the 1980s and
early 1990s ended in the 1998 Noumea Accord,
which over a period of 15 to 20 years will transfer
an increasing amount of governing responsibility
from France to New Caledonia. The agreement
also commits France to conduct a referendum
between 2014 and 2018 to decide whether New
Caledonia should assume full sovereignty and
independence.','e2b73412283a7e16b57238ec7b0b9994b66e9e3a925201b359c9e5948a80cd26','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0bf46afc7c321d5f32c2bb26dba9569bff85f03f4af8d05278f20cd74847b1f6',2025,'NI','Nicaragua','introduction',1214,'Background: The Pacific coast of Nicaragua was
settled as a Spanish colony from Panama in the
early 16th century. Independence from Spain
“was declared in 1821 and the country became
an independent republic in 1838, Britain occu-
pied the Caribbean Coast in the first half of the
19th century, but gradually ceded control of the
region in subsequent decades. Violent opposi-
tion to governmental manipulation and corrup-
tion spread to all classes by 1978 and resulted in
a short-lived civil war that brought the Marxist
Sandinista guerrillas to power in 1979. Nicara-
guan aid to leftist rebels in El Salvador caused
the US to sponsor anti-Sandinista contra guerril-
las through much of the 1980s. After losing free
and fair elections in 1990, 1996, and 2001, former
Sandinista President Daniel ORTEGA Saave-
dra was elected president in 2006 and reelected
in 2011. The 2008 municipal elections, 2010
tegional elections, November 2011 presidential
elections, and 2012 municipal elections were
marred by widespread irregularities. Nicaragua''s
infrastructure and economy—hard hit by the ear-
lier civil war and by Hurricane Mitch in 1998—
are slowly being rebuilt, but democratic institu-
tions have been weakened under the ORTEGA
administration.
Background: Niger became independent from
France in 1960 and experienced single-party and
military rule until 1991, when Gen. Ali SAIBOU
was forced by public pressure to allow multiparty
elections, which resulted in a democratic govern-
ment in 1993. Political infighting brought the
government to a standstill and in 1996 led to a
coup by Col. Ibrahim BARE. In 1999, BARE was
killed in a counter coup by military officers who
restored democratic rule and held elections that
brought Mamadou TANDJA to power in Decem-
ber of that year. TANDJA was reelected in 2004
and in 2009 spearheaded a constitutional amend-
ment that would allow him to extend his term
as president. In February 2010, a military coup
deposed TANDJA, immediately suspended the
constitution, and dissblved the Cabinet. ISSOU-
FOU Mahamadou emerged victorious from a
crowded field in the election following the coup
and was inaugurated in April 2011. Niger is one
of the poorest countries in the world with mini-
mal government services and insufficient funds to
develop its resource base. The largely agrarian and
subsistence-based economy is frequently disrupted
by extended droughts common to the Sahel region
of Africa. The Nigerien Movement for Justice, a
predominately Tuareg ethnic group, emerged in
February 2007, and attacked several military tar-
gets in Niger''s northern region throughout 2007
and 2008. Successful government offensives in
2009 limited the rebels’ operational capabilities.
Niger is facing increased security concerns on its
borders from various external threats including
insecurity in Libya and spillover from the rebel-
lion in Mali.','a60599bbc66f077e03b5de3df1bcbab77a5fe293adbe38c370035fcbd7226b38','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('06920f11015272261211f2a7833078cc3e6ab61a47f5ec3b6c862e0411658650',2025,'NE','Niger','introduction',1230,'Background: British influence and control over
what would become Nigeria and Africa’s most
populous country grew through the 19th cen-
tury. A series of constitutions after World War
II granted Nigeria greater autonomy; independ-
ence came in 1960. Follgwing nearly 16 years
of military rule, a new constitution was adopted
in 1999, and a peaceful transition to civilian
government was completed. The government
continues to face the daunting task of reform-
ing a petroleum-based economy, whose revenues
have been squandered through corruption and
mismanagement, and institutionalizing democ-
racy. In addition, Nigeria continues to experi-
ence longstanding ethnic and religious tensions.
Although both the 2003 and 2007 presidential
elections were marred by significant irregularities
and violence, Nigeria is currently experiencing
its longest period of civilian rule since independ-
ence. The general elections of April 2007 marked
the first civilian-to-civilian transfer of power in
the country’s history.','dccf79a02f83a3db4c21980ea3d3330c66d3fa6c3f940eb0bbc17baafaabc19e','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e6a1dc3d5b1039a26fb6590decccb267074b9ae894c400e4b6dd899d0efc56da',2025,'NF','Norfolk Island','introduction',1240,'Background: Two British attempts at establish-
ing the island as a penal colony (1788-1814 and
1825-55) were ultimately abandoned. In 1856,
the island was resettled by Pitcairn Islanders,
e
descendants of the Bounty mutineers and their
Tahitian companions.','dce91a091817eb2352aaa0e61f9066b6bb2ea3e677336d7692dec33ce6c4f016','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a3b14f847e854632b87d8c78c0203c5b50a70313929f658d7c45437d6dcf46d9',2025,'OM','Oman','introduction',1264,'Background: The Pacific Ocean is the largest of
the world’s five oceans (followed by the Atlantic
Ocean, Indian Ocean, Southern Ocean, and Arc-
tic Ocean). Strategically important access water-
ways include the La Perouse, Tsugaru, Tsushima,
Taiwan, Singapore, and Torres Straits. The deci-
sion by the International Hydrographic Organiza-
` tion in the spring of 2000 to delimit a fifth ocean,
the Southern Ocean, removed the portion of the
Pacific Ocean south of 60 degrees south.
Background: The Indus Valley civilization, one of
the oldest in the world and dating back at least
5,000 years, spread over much of what is presently
Pakistan. During the second millennium B.C.,
remnants of this culture fused with the migrating
Indo-Aryan peoples. The area underwent succes-
sive invasions in subsequent centuries from the
Persians, Greeks, Scythians, Arabs (who brought
Islam), Afghans, and Turks. The Mughal Empire
flourished in the 16th ane 17th centuries; the
British came to dominate the region in the 18th
century. The separation in 1947 of British India
into the Muslim state of Pakistan (with West and
East sections) and largely Hindu India was never
satisfactorily resolved, and India and Pakistan
fought two wars—in 1947-48 and 1965—over the
disputed Kashmir territory. A third war between
these countries in 1971—in which India capital-
ized on Islamabad’s marginalization of Bengalis
in Pakistani politics—resulted in East Pakistan
becoming the separate nation of Bangladesh.
In response to Indian nuclear weapons testing,
Pakistan conducted its own tests in 1998. India-
Pakistan relations have been rocky since the
November 2008 Mumbai attacks, but both coun-
tries are taking small steps to put relations back on
track. In February 2008, Pakistan held parliamen-
tary elections and in September 2008, after the
resignation of former President MUSHARRAF,
elected Asif Ali ZARDARI to the presidency.
Pakistani government and military leaders are
struggling to control domestic insurgents, many
of whom are located in the tribal areas adjacent
to the border with Afghanistan. In January 2012,
553
> Se Abpottaa
AZO svar x GLAMABAD
Rawalping: “%
y Siakol
$ Gujraswala e
i Faigata
a a Fagalàbad,
Sukkuy, A
—s sional
Pakistan assumed a nonpermanent seat on the UN
Security Council for the 2012-13 term.','43a5e8f80ba37dba5392c91a36300e87ca86b017376945f27c3dba03b2a2e4c5','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bf0a4b4f55d4ec171d1ed714e216921e06f2a3a456c62ce33ce80c81785e0fcb',2025,'PK','Pakistan','introduction',1275,'Background: After three decades as part of the
UN Trust Territory of the Pacific under US admin-
istration, this westernmost cluster of the Caroline
Islands opted for independence in 1978 rather
than join the Federated States of Micronesia. A
Compact of Free Association with the US was
approved in 1986 but not ratified until 1993. It
entered into force the following year when the
islands gained independence.
GEOGRAFHY
Location: Oceania, group of islands in the North
Pacific Ocean, southeast of the Philippines
Geographic coordinates: 7 30 N, 134 30 E
Map references: Oceania
Area: total: 459 sq km
country comparison to the world: 198
land: 459 sq km
water: 0 sq km
Area—comparative: slightly more than 2.5 times
the size of Washington, DC
Land boundaries: 0 km
Coastline: 1,519 km
Maritime claims: territorial sea: 3 nm
exclusive fishing zone: 200 nm
Climate: tropical; hor and humid; wet season May
to November
Terrain: varying geologically from the high, moun-
tainous main island of Babelthuap to low, coral
islands usually fringed by large barrier reefs
Elevation extremes: lowest point: Pacific Ocean
Om
highest point: Mount Ngerchelchuus 242 m
Natural resources: forests, minerals (especially
gold), marine products, deep-seabed minerals
Land use: arable land: 2.17%
permanent crops: 4.35%
other: 93.48% (2011)
Irrigated land: NA
Natural hazards: typhoons (June to December)
Environment—current issues: inadequate
facilities for disposal of solid waste; threats to the
marine ecosystem from sand and coral dredging,
illegal fishing practices, and overfishing
558
THE CtA WORLD FACTBOOK
Environment—international agreements:
party to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Law
of the Sea, Ozone Layer Protection, Wetlands,
Whaling : iad
signed, but not ratified: none of the selected
agreements :
Geography—note: westernmost archipelago in
the Caroline chain, consists of six island groups
totaling more than 300 islands; includes World
War Il battleground of Beliliou (Peleliu) and
world-famous rock islands','88816c196c28cd917a803b0574a94b009fe613ddf7d32581e49ea986b91288dd','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('04998564a7ffe5c8cb04246f31eb88f81ab15793608c96aac08a133acfd01a72',2025,'PA','Panama','introduction',1282,'Background: Explored and settled by the Span-
ish in the 16th century, Panama broke with
Spain in 1821 and joined a union of Colombia,
Ecuador, and Venezuela—named the Republic
of Gran Colombia. When the latter dissolved in
1830, Panama remained part of Colombia. With
US backing, Panama seceded from Colombia
in 1903 and promptly signed a treaty with the
US allowing for the construction of a canal and
US sovereignty over a strip of land on either
side of the structure (the Panama Canal Zone).
The Panama Canal was built by the US Army
Corps of Engineers between 1904 and 1914. In
1977, an agreement was signed for the complete
transfer of the Canal from the US to Panama
by the end of the century. Certain portions of
the Zone and increasing responsibility over the
Canal were turned over in the subsequent dec-
ades. With US help, dictator Manuel NORIEGA
was deposed in 1989. The entire Panama Canal,
the area supporting the Canal, and remaining
US military bases were transferred to Panama
by the end of 1999. In October 2006, Panama-
nians approved an ambitious plan (estimated
to cost $5.3 billion) to expand the Canal. The
project, which began in 2007 and could double
the Canal’s capacity, is expected to be completed
in 2015.','688e5a423d42b83461e31a8f6b708b49d643e1ea0cdfe68481e6d7b619d4fa2d','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2bcb04e22148d1f6b3282ed92a5fcd4911aecf6139b5c40c4da2a0adf48ffa70',2025,'PG','Papua New Guinea','introduction',1292,'Background: The eastern half of the island of
New Guinea—second largest in the world—was
divided between Germany (north) and the UK
(south) in 1885. The latter area was transferred
to Australia in 1902, which occupied the north-
ern portion during World War I and continued
to administer the combined areas until independ-
ence in 1975. A nine-year secessionist revolt on
the island of Bougainville ended in 1997 after
claiming some 20,000 lives.
Background: The Paracel Islands are surrounded
by productive fishing grounds and by potential
oil and gas reserves. In 1932, French Indochina
annexed the islands and set up a weather station
on Pattle Island; maintenance was continued by
its successor, Vietnam. China has occupied all
the Paracel Islands since 1974, when its troops
seized a South Vietnamese garrison occupying
the western islands. China built a military instal-
lation on Woody Island with an airfield and
artificial harbor. The islands also are claimed by
Taiwan and Vietnam.','97c7a287e820f93c97168727dbd48ba5c01f6fd02de3e54d73b667eba58f42e0','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ea03653d9847c640e78f3aa0c577d11b5f79424dca1934655a249fb8cda8c40c',2025,'PE','Peru','introduction',1314,'Background: The Philippine Islands became a
Spanish colony: during the 16th century; they
were ceded to the US in 1898 following the
Spanish-American War. In 1935 the Philippines
became a self-governing commonwealth. Manuel
QUEZON was elected president and was tasked
with preparing the country for independence
after a 10-year transition. In 1942 the islands fell
under Japanese occupation during World War II,
and US forces and Filipinos fought together dur-
ing 1944-45 to regain control. On 4 July 1946
the Republic of the Philippines attained its inde-
pendence. A 20-year rule by Ferdinand MAR-
COS ended in 1986, when a “people power”
movement in Manila (“EDSA 1”) forced him
into exile and installed Corazon AQUINO as
president. Her presidency was hampered by sev-
eral coup attempts that prevented a return to full
political stability and economic development.
Fidel RAMOS was elected president in 1992.
.His administration was marked by increased
stability and by progress on economic reforms.
In 1992, the US closed its last military bases
on the islands. Joseph ESTRADA was elected
president in 1998. He was succeeded by his vice-
president, Gloria MACAPAGAL-ARROYO, in
January 2001 after ESTRADA’s stormy impeach-
ment trial on corruption charges broke down
and another “people power” movement (“EDSA
2”) demanded his resignation. MACAPAGAL-
ARROYO was elected to a six-year term as
576
THE CIA WORLD FACTBOOK
president in May 2004. Her presidency was
marred by several corruption allegations but the
Philippine economy was one of the few to avoid
contraction following the 2008 global financial
crisis, expanding each year of her administration.
Benigno AQUINO III was elected to a six-year
term as president in May 2010. The Philippine
Government faces threats from several groups,
some of which are on the US Government''s
Foreign Terrorist Organization list. Manila has
waged a decades-long struggle against ethnic
Moro insurgencies in the southern Philippines,
which has led to a peace accord with the Moro
National Liberation Front and ongoing peace
talks with the Moro Islamic Liberation Front.
The decades-long Maoist-inspired New People’s
Army insurgency also operates through much
of the country. The Philippines faces increased
tension with China over disputed territorial and
maritime claims in the South China Sea.','0e6c2bab3219cdd312b466532afade9e23e1bf1522ccc5405a02ab25218ac77b','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c53e9c8f4037d877ea79e6d23f02b7d254f007ad3764978a4680b69bf854331d',2025,'PW','Palau','introduction',1325,'Background: Pitcairn Island’ was discovered in
1767 by the British and settled in 1790 by the
Bounty mutineers and their Tahitian companions.
Pitcaim was the first Pacific island to become a
British colony (in 1838) and today remains the last
vestige of that empire in the South Pacific, Out
migration, primarily to New Zealand, has thinned
the population from a peak of 233 in 1937 to less
than 50 today.','44ede42879caeeac52c03bae0a1b41a1dde12d9ceb8405fe9c26ffde02c78150','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('228cf2e833dd2c583544649c78451caddbc1c55748200b99481e20f722871ad6',2025,'PL','Poland','introduction',1329,'Background: Poland’s history as a state begins
near the middle of the 10th century. By the mid-
16th century, the Polish-Lithuanian Common-
wealth ruled a vast tract of land in central and
eastern Europe. During the 18th century, internal
disorders weakened the nation, and in a series of
agreements between 1772 and 1795, Russia, Prus-
sia, and Austria partitioned Poland among them-
selves. Poland regained its independence in 1918
only to be overrun by Germany and the Soviet
Union in World War II. It became a Soviet satel-
lite state following the war, but its government was
comparatively tolerant and progressive. Labor tur-
moil in 1980 led to the formation of the independ-
ent trade union “Solidarity” that over time became
a political force with over ten million members.
Free elections in 1989 and 1990 won Solidarity
control of the parliament and the presidency,
bringing the Communist era to a close. A “shock
therapy” program during the early 1990s enabled
the country to transform its economy into one of
the most robust in Central Europe. Poland joined
NATO in 1999 and the European Union in 2004.
With its transformation to a democratic, market-
oriented country largely completed, Poland is
an increasingly active member of Euro-Atlantic
organizations.
Background: Following its heyday as a global mar-
itime power during the 15th and 16th centuries,
Portugal lost much of its wealth and status with the
destruction of Lisbon in a 1755 earthquake, occu-
pation duririg the Napoleonic Wars, and the inde-
pendence of its wealthiest colony of Brazil in 1822.
A 1910 revolution deposed the monarchy; for most
of the next six decades, repressive governments
ran the country. In 1974, a left-wing military coup
installed broad democratic reforms. The following
year, Portugal granted independence to all of its
African colonies. Portugal is a founding member of
NATO and entered the EC (now the EU) in 1986.','d7f60dce264f5eda63c8f1a5c58ddb22c4246285a59478c1cc8a4df99613eb06','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1057560fe952190c8de2d633871b3af88dacb7a5eac4fc8df701f0b81b058c30',2025,'PR','Puerto Rico','introduction',1344,'Background: Populated for centuries by abo-
riginal peoples, the island was claimed by the
Spanish Crown in 1493 following Christopher
COLUMBUS’ second voyage to the Americas. In
1898, after 400 years of colonial rule that saw the
indigenous population nearly exterminated and
African slave labor introduced, Puerto Rico was
ceded to the US as a result of the Spanish-Amer-
ican War. Puerto Ricans were granted US citizen-
ship in 1917. Popularly-elected governors have
served since 1948. In 1952, a constitution was
enacted providing for internal self government.
- In plebiscites held in 1967, 1993, and 1998, vot-
ers chése not to alter the existing political status
with the US, but the results of a 2012 vote left
open the possibility of American statehood.
Location: Caribbean, island between the Carib-
bean Sea and the North Atlantic Ocean, east of
the Dominican Republic
Geographic coordinates: 18 15 N, 66 30 W
Map references: Central America and the
Caribbean
Area: total: 13,790 sq km
country comparison to the world: 163
land: 8,870 sq km
water: 4,921 sq km wat
Area—comparative: slightly less than three
times the size of Rhode Island
Land boundaries: 0 km
Coastline: 501 km
Maritime claims: territorial sea: 12 nm >
exclusive economic zone: 200 nm
Climate: tropical marine, mild; little seasonal
temperature variation
Terrain: mostly mountains with coastal plain belt
in north; mountains precipitous to sea on west
coast; sandy beaches along most coastal areas
Elevation extremes: lowest point: Caribbean
Sea O m
highest point: Cerro de Punta 1,338 m
Natural resources: some copper and nickel;
potential for onshore and offshore oil
Land use: arable land: 6.76%
permanent crops: 4.51%
other: 88.73% (2011)
Irrigated land: 220.4 sq km (2005)
Natural hazards: periodic droughts; hurricanes
Environment—current Issues: erosion; occa-
sional drought causing water shortages
Geography—note: important location along the
Mona Passage—a key shipping lane to the Panama
Canal; San Juan is one of the biggest and best
natural harbors in the Caribbean; many small riv-
ers and high central mountains ensure land is well
watered; south coast relatively dry; fertile coastal
plain belt in north
Background: Ruled by the Al Thani family since
the mid-1800s, Qatar transformed itself from a poor
British protectorate noted mainly for pearling into
an independent state with significant oil and natural
gas revenues. During the late 1980s and early 1990s,
the Qatari economy was crippled by a continuous
siphoning off of petroleum revenues by the Amir,
who had ruled the country since 1972. His son,
the current Amir HAMAD bin Khalifa Al Thani,
overthrew the father in a bloodless coup in 1995.
In 2001, Qatar resolved its longstanding border
disputes with both Bahrain and Saudi Arabia. As
of 2007, oil and natural gas revenues had enabled
Qatar to attain the highest per capita income in
the world, Qatar has not experienced the level of
unrest or violence seen in other Near Eastern and
North African countries in 2010-11, due in part
to its immense wealth.Qatar’s international image
is bolstered in part by the Doha-based Al Jazeera
news network, which has provided comprehensive
coverage of the Near East and North African Arab
revolutions. Additionally, Qatar played a signifi-
cant role in the Libyan revolution by pressing the
Gulf Cooperation Council and the Arab League to
assist the Libyan rebel movement.
Background: The US annexed Wake Island in
1899 for a cable station. An important air and
naval base was constructed in 1940-41. In Decem-
ber 1941, the island was captured by the Japanese
and held until the end of World War II. In subse-
quent years, Wake was developed as a stopover and
refueling site for military and commercial aircraft
transiting the Pacific. Since 1974, the islands air-
strip has been used by the US military, as well as for
emergency landings. Operations on the island were
suspended and all personnel evacuated in 2006 with
the approach of super typhoon IOKE (category 5),
but resultant damage was comparatively minor. A
US Air Force repair team restored full capability to
the airfield and facilities, and the island remains a
vital strategic link in the Pacific region.','0ee225352e00369ef8f30551923ceb2d7e69a6ef90f861ea318e78bb6609b54c','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3836dbe48e20aadb762db716abe0fb75936e62ed6824357682554f9462bbe9ad',2025,'QA','Qatar','introduction',1360,'Background: The principalities of Wallachia and
Moldavia—for centuries under the suzerainty
of the Turkish Ottoman Empire—secured their
autonomy in 1856; they were de facto linked in
1859 and formally united in 1862 under the new
name of Romania. The country gained recogni-
tion of its independence in 1878. It joined the
Allied Powers in World War | and acquired new
territories—most notably Transylvania—follow-
ing the conflict. In 1940, Romania allied with the
Axis powers and participated in the 1941 German
invasion of the USSR. Three years later, overrun
by the Soviets, Romania signed an armistice. The
post-war Soviet occupation led to the formation of
a Communist “people’s republic” in 1947 and the
abdication of the king. The decades-long rule of
dictator Nicolae CEAUSESCU, who took power
in 1965, and his Securitate police state became
increasingly oppressive. and draconian through
the 1980s. CEAUSESCU was overthrown and
executed inylate 1989. Former Communists domi-
nated the government until 1996 when they were
swept from power. Romania joined NATO in 2004
and the EU in 2007.','8ba9c58dd59f121940b444e13265c1343bab7be72fbda58c58bc50a309fcad7d','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a23fd490696353745b4f54ec6a1359d080d682b58bcbca64ffadecd654db71bd',2025,'RW','Rwanda','introduction',1364,'Background: In 1959, three years before independ-
enee from Belgium, the majority ethnic group, the
Hutus, overthrew the ruling Tutsi king. Over the
next several years, thousands of Tutsis were killed,
and some 150,000 driven into exile in neighboring
countries. The children of these exiles later formed
a rebel group, the Rwandan Patriotic Front (RPF),
and began a civil war in 1990. The war, along with
several political and economic upheavals, exacer-
bated ethnic tensions, culminating in April 1994
in a state-orchestrated genocide, in which Rwan-
dans killed up to a million of their fellow citizens,
including approximately three-quarters of the Tutsi
population. The genocide ended later that same
year when the predominantly Tutsi RPF, operating
out of Uganda and northern Rwanda, defeated the
national army and Hutu militias, and established
an RPF-led government of national unity. Approx-
imately 2 million Hutu refugees—many fearing
Tutsi retribution—fled to neighboring Burundi,
Tanzania, Uganda, and former Zaire. Since then,
most of the refugees have returned to Rwanda,
but several thousand remained in the neighbor-
ing Democratic Republic of the Congo (DRC, the
former Zaire) and formed an extremist insurgency
bent on retaking Rwanda, much as the RPF did in
1990, Rwanda held its first local elections in 1999
and its first post-genocide presidential and legisla-
tive elections in 2003. Rwanda in 2009 staged a
joint military operation with the Congolese Army
in DRC to rout out the Hutu extremist insurgency
there, and Kigali and Kinshasa restored diplomatic
relations. Rwanda also joined the Commonwealth
in late 2009. In January 2013, Rwanda assumed a
nonpermanent seat on the UN Security Council
for the 2013-14 term.
Background: Discovered in 1493 by Christo-
pher COLUMBUS who named it for his brother
Bartolomeo, Saint Barthelemy was first settled
by the French in 1648. In 1784, the French sold
the island to Sweden, who renamed the largest
town Gustavia, after the Swedish King GUS-
TAV III, and made it a free port; the island pros-
pered as a trade and supply center during the
colonial wars of the 18th century. France repur-
chased the island in 1877 and took control the
following year. It was placed under the admin-
istration of Guadeloupe. Saint Barthelemy
retained its free port status along with various
Swedish appellations such as Swedish street
and town names, and the three-crown symbol
on the coat of arms. In 2003, the populace of
the island voted to secede from Guadeloupe and
in 2007, the island became a French overseas
collectivity.
Location: Caribbean, island between the Car-
ibbean Sea and the North Atlantic Ocean;
located in the Leeward Islands (northern)
group; Saint Barthelemy lies east of the US
Virgin Islands
Geographic coordinates: 17 90 N, 62 85 W
Map references; Central America and the
Caribbean
Area: 21 sq km
Area—comparative: less than an eighth of the
size of Washington, DC
Land boundaries: 0 km
Climate: tropical, with practically no variation in
temperature; has two seasons (dry and humid)
Terrain: hilly, almost completely surrounded by
shallow-water reefs, with plentiful beaches
Elevation extremes: lowest point: Caribbean
Ocean 0 m
highest point: Morne du Vitet 286 m
Natural resources: has few natural resources, its
beaches being the most important
Environment—current issues: with no natu-
ral rivers or-streams, fresh water is in short
supply, especially in summer, and provided by
desalinization of sea water, collection of rain water,
or imported via water tanker','179ff695f318af7cdb1c1d69440dc832e0ef93f63002cbb774e98611505bb8e9','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0dd374ccc69c37ddcf70b6b7cf713c73502a1238c7fb667ccbfaa786a806143e',2025,'KN','Saint Kitts and Nevis','introduction',1374,'Background: Carib Indians occupied the islands
of the West Indies for hundreds of years before
the British began settlement in 1623. In 1967,
the island territory of Saint Christopher-Nevis-
Anguilla became an associated state of the
UK with full internal autonomy. The island of
Anguilla rebelled and was allowed to secede in
1971. The remaining islands achieved independ-
ence in 1983 as Saint Kitts and Nevis. In 1998,
a vote in Nevis on a referendum to separate from
612
Saint Kitts fell short of the two-thirds majority
needed. Nevis continues in its efforts to separate
from Saint Kitts.
Background: The island, with its fine natural
harbor at Castries, was contested between Eng-
land and France throughout the 17th and early
18th centuries (changing possession 14 times); it
was finally ceded to the UK in 1814. Even after
the abolition of slavery on its plantations in 1834,
Saint Lucia remained an agricultural island, dedi-
cated to producing tropical commodity crops. Self-
government was granted in 1967 and independ-
ence in 1979.','5ce38265a979154879a1c344dd015ed2723881b180018f6044fbd05a3e5f1cb1','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('66fc048cb240bb7af3bea3e6a8891d2d829845058db48aa3d9b198e6175cb5e1',2025,'LC','Saint Lucia','introduction',1387,'Background: Although sighted by Christopher
COLUMBUS in 1493 and claimed for Spain, it
was the Dutch who occupied the island in 1631
and set about exploiting its salt deposits. The
618
THE CIA WORLD FACTBOOK','5b8e760fa538762756012614a47bcdc0d97f98aa1a7f4ab315b54ba211d6a157','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('25eafced1045a17ae1fc600ad79cb67fd2cf22b7093be63751de562c0d00306b',2025,'PM','Saint Pierre and Miquelon','introduction',1396,'Background: First settled by the French in the
early 17th century, the islands represent the sole
remaining vestige of France’s once vast North
American possessions.','f224a86e3633b364c38304980255abf2702d960f13ea4e0064692265a8a4be4a','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6a684b3937173ff9785fd7a573c992f3bf31964602cf9deed66d7b4e09461e78',2025,'VC','Saint Vincent and the Grenadines','introduction',1405,'Background: Resistance by native Caribs pre-
vented colonization on Saint Vincent until 1719.
Disputed between France and the United King-
dom for most of the 18th century, the island was
ceded to the latter in 1783. Between 1960 and
1962, Saint Vincent and the Grenadines was a
separate administrative unit of the Federation of
the West Indies. Autonomy was granted in 1969
and independence in 1979.
Background: New Zealand occupied the German
protectorate of Western Samoa at the outbreak of
World War I in 1914. It continued to administer
the islands as a mandate and then as a trust terri-
tory until 1962, when the islands became the first
Polynesian nation to reestablish independence in
the 20th century. The country dropped the “West-
em” from its name in 1997.','c93c71c4538add189ddaae07091ee76e1cac06f66ee971d60df1be8bced542ba','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3ed7249fdb45c47930f13ef842c36db7b9f31c7c11d53351da750e6aab0bb81d',2025,'SA','Saudi Arabia','introduction',1429,'Background: Saudi Arabia is the birthplace of
-Islam and home to Islam’s two holiest shrines in
Mecca and Medina. The king’s official title is
the Custodian of the Two Holy Mosques. The
modem Saudi state was founded in 1932 by
ABD AL-AZIZ bin Abd al-Rahman Al SAUD
(Ibn Saud) after a 30-year campaign to unify
most of the Arabian Peninsula. One of his male
descendants rules the country today, as required
by the country’s 1992 Basic Law. King ABDAL-
LAH bin Abd al-Aziz ascended to the throne
in 2005. Following Iraq’s invasion of Kuwait in
1990, Saudi Arabia accepted the Kuwaiti royal
family and 400,000 refugees while allowing
Western and Arab troops to deploy on its soil
for the liberation of Kuwait the following year.
The continuing presence of foreign troops on
Saudi soil after the liberation of Kuwait became
a source of tension between the royal family and
the public until all operational US troops left
the country in 2003. Major terrorist attacks in
May and November 2003 spurred a strong on-
going campaign against domestic terrorism and
extremism. King ABDALLAH has continued
the cautious reform program begun when he was
crown prince. The king instituted an interfaith
dialogue initiative in 2008 to encourage reli-
gious tolerance on a global level; in 2009, he
reshuffled the cabinet, which led to more mod-
erates holding ministerial and judicial positions,
and appointed the first female to the cabinet.
The 2010-12 uprisings across Middle Eastern
and North African countries sparked modest
incidents in Saudi cities, predominantly by Shia
demonstrators calling for the release of detain-
ees and the withdrawal from Bahrain of the Gulf
Cooperation CounciTs Peninsula Shield Force.
Protests in general were met by a strong police
presence, with some arrests, but not the level
of bloodshed seen in protests elsewhere in the
region. In response to the unrest, King ABDAL-
LAH in February and March 2011 announced a
series of benefits to Saudi citizens including funds
to build affordable housing, salary increases for
government workers, and unemployment enti-
tlements. To promote increased political partici-
pation, the government held elections nation-
wide in September 2011 for half the members of
285 municipal councils. Also in September, the
king announced that women will be allowed to
run for and vote in future municipal elections—
first held in 2005—and serve as full members
of the advisory Consultative Council. During
2012, Shia protests increased in violence, while
peaceful Sunni protests expanded. The country
remains a leading producer of oil and natural gas
and holds about 17% of the world’s proven oil
reserves. The government continues to pursue
economic reform and diversification, particu-
larly since Saudi Arabia''s accession to the WTO
in December 2005, and promotes foreign invest-
ment in the kingdom. A burgeoning popula-
tion, aquifer depletion, and an economy largely
dependent on petroleum output and prices are
ongoing governmental concerns.
Background: The French colonies of Senegal
and the French Sudan were merged in 1959 and
granted their independence as the Mali Federa-
tion in 1960. The union broke up after only a few
months. Senegal joined with The Gambia to form
the nominal confederation of Senegambia in 1982.
The envisaged integration of the two countries was
never carried out, and the union was dissolved in
1989. The Movement of Democratic Forces in the
Casamance (MFDC) has led a low-level separatist
insurgency in southern Senegal since the 1980s,
and several peace deals have failed to resolve the
- conflict. Nevertheless, Senegal remains one of the
most stable democracies in Africa and has a long
history of participating in international peacekeep-
ing and regional mediation. Senegal was tuled by a
Socialist Party for 40 years until Abdoulaye WADE
was elected president in 2000. He was reelected
in 2007 and during his two terms amended Sen-
egal’s constitution over a dozen times to increase
executive power and to weaken the opposition. His
decision to run for a third presidential term sparked
a large public backlash that led to his defeat in a
March 2012 runoff election with Macky SALL.','b6eb4722693d7911aa19d17f1c7436db17b3dce03b1c1f917eae1b26380ed1b6','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('30697d7792be6f3c7c634cb72a529874dd921b876b22b5ddb8c917661f3e8a56',2025,'SL','Sierra Leone','introduction',1447,'Background: Democracy is slowly being reestab-
lished after the civil war from 1991 to 2002 that
resulted in tens of thousands of deaths and the dis-
placement of more than 2 million people (about
a third of the population). The military, which
took over full responsibility for security following
the departure of UN peacekeepers at the end of
2005, is increasingly developing as a guarantor of
the country’s stability. The armed forces remained
on the sideline during the 2007 and 2012 national
elections but still look to the UN Integrated Peace
building Office in Sierra Leone (UNIPSIL)—a
civilian UN mission—to support efforts to con-
solidate peace. The new government''s priorities
include furthering development, creating jobs, and
stamping out endemic corruption.','21b976fbdccf61ee73fca6d7e2839294dde0ca193731eb8862fea862e21a9a90','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ae6d9f119120d9fb8a1e1864d8ca2c8e8064e1a85bd5553745e5c299ea9907d9',2025,'SK','Slovakia','introduction',1457,'Background: Slovakia’s roots can be traced to the
9th century state of Great Moravia. Subsequently,
the Slovaks became part of the Hungarian King-
dom, where they remained for the next 1,000
years. Following the formation of the dual Aus-
tro-Hungarian monarchy in 1867, language and
education policies favoring the use of Hungarian
654
(Magyarization) resulted in a strengthening of Slo-
vak nationalism and a cultivation of cultural ties
with the closely related Czechs, who were under
Austrian rule. After the dissolution of the Austro-
Hungarian Empire at the close of World War I, the
Slovaks joined the Czechs to form Czechoslova-
kia. During the interwar period, Slovak nationalist
leaders pushed for autonomy within Czechoslova-
kia, and in 1939 Slovakia became an independent
state allied with Nazi Germany. Following World
War II, Czechoslovakia was reconstituted and
came under communist rule within Soviet-
dominated Eastern Europe. In 1968, an invasion
by Warsaw Pact troops ended the efforts of the
country’s leaders to liberalize communist rule and
create “socialism with a human face,” ushering in
a period of repression known as “normalization.”
The peaceful “Velvet Revolution” swept the
Communist Party from power at the end of 1989
and inaugurated a return to democratic rule and a
market economy. On 1 January 1993, the country
underwent a nonviolent “velvet divorce” into its
two national components, Slovakia and the Czech
Republic. Slovakia joined both NATO and the
EU in the spring of 2004 and the euro zone on 1
January 2009.','78a24426cb680e49199a4527b533f1bff7cb2227b9e20673d8adef477333f140','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c02739c76bcfa6e277e515615f8317e1bba63e37c948fe6dc376e20b37a60b59',2025,'SI','Slovenia','introduction',1466,'Background: The Slovene lands were part of
the Austro-Hungarian Empire until the latter''s
dissolution at the end of World War I. In 1918,
the Slovenes joined the Serbs and Croats in form-
ing a new multinational state, which was named
Yugoslavia in 1929. After World War II, Slovenia
became a republic of the renewed Yugoslavia,
which though communist, distanced itself from
Moscow’s rule. Dissatisfied with the exercise of
power by the majority Serbs, the Slovenes suc-
ceeded in establishing their independence in 1991
after a short 10-day war. Historical ties to Western
Europe, a strong economy, and a stable democracy
658
have assisted in Slovenia’s transformation to a
modern state. Slovenia acceded to both NATO
and the EU in the spring of 2004; it joined the
eurozone in 2007.
Location: south Central Europe, Julian Alps
between Austria and Croatia
Geographic coordinates: 46 07 N, 14 49 E
Map references: Europe
Area: total: 20,273 sq km
country comparison to the world: 155
land: 20,151 sq km
water: 122 sq km
Areo—comparative: slightly smaller than New','c92a23ef5f08f861e4bc567a185963082e18d5a3b91298175a1046fd92d0a6a6','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('48237695bebf72a1cfe929b996f51acece92bc853cfa8039d820c9a8465bf44f',2025,'SB','Solomon Islands','introduction',1472,'Background: The UK established a protectorate
over the Solomon Islands in the 1890s. Some of
the most bitter fighting of World War II occurred
on this archipelago. Self-government was achieved
in 1976 and independence two years later. Ethnic
violence, government malfeasance, and endemic
crime have undermined stability and civil soci-
ety. In June 2003, then Prime Minister Sir Allan
KEMAKEZA sought the assistance of Australia
in reestablishing law and order; the following
month, an Australian-led multinational force
arrived to restore peace and disarm ethnic militias.
The Regional Assistance Mission to the Solomon
Islands (RAMSI) has generally been effective in
restoring law and order and rebuilding government
institutions.','4ded7a3e838023cfd10386ac2502fa528b3baf1018b050e29d8238451bbae61a','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e3685e799bb769a7a08ca494dfdbcebacb7ea88840518d0d924db3bd578c1886',2025,'SO','Somalia','introduction',1483,'Background: Dutch traders landed at the southern
tip of modern day South Africa in 1652 and estab-
lished a stopover point on the spice route between
the Netherlands and the Far East, founding the city
of Cape Town. After the British seized the Cape of
Good Hope area in 1806, many of the Dutch set-
tlers (the Boers) trekked north to found their own
republics. The discovery of diamonds (1867) and
gold (1886) spurred wealth and immigration and
intensified the subjugation of the native inhabit-
ants. The Boers resisted British encroachments but
were defeated in the Boer War (1899-1902); how-
ever, the British and the Afrikaners, as the Boers
became known, ruled together beginning in 1910
under the Union of South Africa, which became
the vicinity of the Maldives, and northeastward ta,
the Strait of Hormuz','6058d6e070e056c6fa432ddc93c318924eb46918682f44aa9ce185244db9731a','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('14cfede73adfc7d7dadc09f44e96c3df971957848dd08bbd624f5180ede69972',2025,'ES','Spain','introduction',1496,'Background: The Spratly Islands consist of
more than 100 small islands or reefs. They are
surrounded ,by rich fishing grounds and poten-
tially by ‘gas and oil deposits. They are claimed
in their entirety by China, Taiwan, and Viet-
nam, while portions are claimed by Malaysia and
the Philippines. About 45 islands are occupied
by relatively small numbers of military forces
from China, Malaysia, the Philippines, Taiwan,
and Vietnam. Since 1985 Brunei has claimed a
continental shelf that overlaps a southern reef
but has not made any formal claim to the reef.
Brunei claims an exclusive economic zone over
this area.','158c9897f27aa88fe92070192bf43add2f858b3f25227dd4389925edb32054c6','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e3795c201e17cca12171df451f62ceffb0fd7d403e4c4efd0cd05d236c5c99d1',2025,'PH','Philippines','introduction',1498,'Background: The first Sinhalese arrived in Sri
Lanka late in the 6th century B.C., probably from
northern India. Buddhism was introduced in about
the mid-third century B.C., and a great civilization
developed at the cities of Anuradhapura (king-
dom from circa 200 B.C, to circa A.D. 1000) and
Polonnaruwa (from about 1070 to 1200). In the
14th century, a:south Indian dynasty established
a Tamil kingdom ‘in northern Sri Lanka. The
coastal areas of the island were controlled by the
Portuguese in the 16th century and by the Dutch
in the 17th century. The island was ceded to the
British in 1796, became a crown colony in 1802,
and was formally united under British rule by 1815.
As Ceylon, it became independent in 1948; its
name was changed to Sri Lanka in 1972. Tensions
between the Sinhalese majority and Tamil separa-
tists erupted into war in 1983. After two decades
of fighting, the government and Liberation Tigers
of Tamil Eelam (LTTE) formalized a cease-fire in
February 2002 with Norway brokering peace riego-
tiations. Violence between the LTTE and govern-
ment forces intensified in 2006, but the govern-
ment regained control of the Eastern Province in
2007. By May 2009, the government announced
that its military had defeated the remnants of the
LTTE. Since the end of the conflict, the govern-
ment has enacted an ambitious program of eco-
nomic development projects, many of which are
financed by loans from the Government of China.
In addition to efforts to reconstruct its economy,
the government has resettled more than 95% of
those civilians who were displaced during the final
phase of the conflict and released the vast major-
ity of former LTTE combatants captured by Gov-
ernment Security Forces. At the same time, there
has been little progress on more contentious and
politically difficult issues such as reaching a politi-
cal settlement with Tamil elected representatives
and holding accountable those alleged to have
been involved in human rights violations at the
end of the war.
dk GEOGRAPHY
Location: Southern Asia, island in the Indian
Ocean, south of India
Geographic coordinates: 7 00 N, 81 00 E
680
Map references: Asia
Area: total: 65,610 sq km
country comparison to the world: 122
land: 64,630 sq km
water: 980 sq km
Area—comparative: slightly larger than West
Virginia
Land boundaries: 0 km
Coastline: 1,340 km
Maritime claims: territorial sea: 12 nm
contiguous tone: 24 nm
exclusive economic zone; 200 nm
continental shelf: 200 nm or to the edge of the
continental margin Climate: tropical monsoon;
northeast monsoon (December to March); south-
west monsoon (June to October)
Terrain: mostly low, flat to rolling plain; moun-
tains in south-central interior
Elevation extremes: lowest point: Indian Ocean
Om
highest point: Pidurutalagala 2,524 m
Natural resources: limestone, graphite, mineral
sands, gems, phosphates, clay, hydropower
Land use: arable land: 18.29%
permanent crops: 14.94%
other: 66.77% (2011)
Irrigated land: 5,700 sq km (2003)
Total renewable water resources: 5,700 cu km
(2011) s
Freshwater withdrawal (domestic/industrial/
agricultural): total: 12.95 cu km/yr (6%/6%/87%)
per capita: 638.8 cu m/yr (2005)
Natural hazards: occasional cyclones and
tornadoes
Environment—current issues: deforestation;
soil erosion; wildlife populations threatened by
poaching and urbanization; coastal degradation
from mining activities and increased pollution;
freshwater resources being polluted by industrial
wastes and sewage runoff; waste disposal; air pol-
lution in Colombo
Environment—international agreements:
party to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Endan-
gered Species, Environmental Modification,
Hazardous Wastes, Law of the Sea, Ozone Layer
Protection, Ship Pollution, Wetlands signed, but
not ratified: Marine Life Conservation
Geography—note: strategic location near major
Indian Ocean sea lanes','1c5485a5edfe7709b81a3b6eecbb681676f57cbf01048f1f0a4f43fc1f95fe70','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1fd49f26577679a3d9b49d6f3d97651848ef20fd0b593377471a4fef56262292',2025,'LK','Sri Lanka','introduction',1506,'Background: Military regimes favoring Islamic-
oriented governments have dominated national
politics since independence from the UK in 1956.
Sudan was embroiled in two prolonged civil wars
during most of the remainder of the 20th century.
These conflicts were rooted in northern eco-
nomic, political, and social domination of largely
+
non-Muslim, non-Arab southern Sudanese. The
first civil war ended in 1972 but broke out again in
1983. The second war and famine-related effects
resulted in more than four million people displaced
and, according to rebel estimates, more than two
million deaths over a period of two decades. Peace
talks gained momentum in 2002-04 with the sign-
ing of several‘ accords. The final North/South
Comprehensive Peace Agreement (CPA), signed
in January 2005, granted the southern rebels
autonomy for six years followed by a referendum
on independence for Southern Sudan. The ref-
erendum was held in January 2011 and indicated
overwhelming support for independence. South
Sudan became independent on 9 July 2011. Since
southern independence Sudan has been combating
rebels from the Sudan People’s Liberation Move-
ment-North (SPLM-N) in Southern Kordofan and
Blue Nile states. A separate conflict, which broke
out in the western region of Darfur in 2003, has
displaced nearly two million people and caused
an estimated 200,000 to 400,000 deaths. The UN
took command of the Darfur peacekeeping opera-
tion from the African Union in December 2007.
Peacekeeping troops have struggled to stabilize the
situation, which has become increasingly regional
in scope and has brought instability to eastern
Chad. Sudan also has faced large refugee influxes
from neighboring countries primarily Ethiopia and
Chad. Armed conflict, poor transport infrastruc-
ture, and lack of government support have chroni-
cally obstructed the provision of humanitarian
assistance to affected populations.','fcb9a2b9bad20e0bb5e273d4fa0b3f31be416d6736096391ff967d60f9cc8976','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('898b8f5466c31b8a82d309e0b17724ed1147b6f9025682feb716750d7a553a13',2025,'SD','Sudan','introduction',1513,'Background: First explored by the Spaniards in
the 16th century and then settled by the Eng-
lish in the mid-17th century, Suriname became
a Dutch colony in 1667. With the abolition of
African slavery in 1863, workers were brought
in from India and Java. Independence from the
Netherlands was granted in 1975. Five years
later the civilian govetnment was replaced by
a military regime that soon declared a socialist
republic. It continued to exert control through
a succession of nominally civilian administra-
tions until 1987, when international pressure
finally forced a democratic election. In 1990, the
military overthrew the civilian leadership, but a
democratically elected government—a four-party
coalition—returned to power in 1991. The coali-
tion expanded to eight parties in 2005 and ruled
until August 2010, when voters returned former
military leader Desire BOUTERSE and his oppo-
sition coalition to power.
Location: Northern South America, bordering the
North Atlantic Ocean, between French Guiana
and Guyana
Geographic coordinates: 4 00 N, 56 00 W
Map references: South America
Area: total: 163,820 sq km
country comparison to the world: 92
land: 156,000 sq km
water: 7,820 sq km
Area—comparative: slightly larger than Georgia
Land boundaries: total: 1,703 km
border countries: Brazil 593 km, French Guiana
510 km, Guyana 600 km
Coastline: 386 km
Maritime claims: territorial sea: 12 nm
exclusive economic zone: 200 nm
Climate: tropical; moderated by trade winds
Terrain: mostly rolling hills; narrow coastal plain
with swamps ý
Elevation extremes: lowest point: unnamed
location in the coastal plain -2 m
highest point: Juliana Top 1,230 m
Natural resources: timber, hydropower, fish, kao-
lin, shrimp, bauxite, gold, and small amounts of
nickel, copper, platinum, iron ore
Land use: arable land: 0.36%
permanent crops: 0.04%
other: 99.6% (2011)
irrigated land: 511.8 sq km (2003)
Total renewable water resources: 122 cu km (2011)
Freshwater withdrawal (domestic/industrial/
agricultural): total:0.67 cu km/yr (6%/4%/90%)
per capita: 1,396 cu m/yr (2006)
Natural hazards: NA
Environment—current issues: deforestation as
timber is cut for export; pollution of inland water-
ways by small-scale mining activities
Environment—international agreements:
party to: Biodiversity, Climate Change, Climate
687
Change-Kyoto Protocol, Desertification, Endan-
gered Species, Law of the Sea, Marine Dumping,
Ozone Layer Protection, Ship Pollution, Tropical
Timber 94, Wetlands, Whaling
signed, but not ratified: none of the selected
agreements
Geography—note: smallest independent country
on South American continent; mostly tropical
rain forest; great diversity of flora and fauna that,
for the most part, is increasingly threatened by new
development; relatively small population, mostly
along the coast','bbb86f8c061d849200e76b2b656c454490ea9fe5d67c7a6b8a5a84e4168633db','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('53c6b0277e7c51d72a7dee6e0f3a7575c7d0e6f1bd94a69a6ecc5632229a29b6',2025,'SR','Suriname','introduction',1522,'Background: First discovered by the Norwegians
in the 12th century, the islands served as an inter-
national whaling base during the 17th and 18th
centuries. Norway''s sovereignty was recognized
in 1920; five years later it officially took over the
territory.
Background: Autonomy for the Swazis of south-
ern Africa was guaranteed by the British in the
late 19th century; independence was granted in
1968. Student and labor unrest during the 1990s
pressured King MSWATI III, Africa’s last abso-
lute monarch, to grudgingly allow political reform
and greater democracy, although he has backslid
ori these promises in recent years. A constitu-
tion came into effect in 2006, but the legal status
of political parties remains unclear. The African
United Democratic Party tried unsuccessfully to
register as an official political party in mid 2006.
Talks over the constitution broke down between
the government and progressive groups in 2007.
Swaziland recently surpassed Botswana as the
country with the world''s highest known HIV/
AIDS prevalence rate.','b7e9c73533b1110971f9fcc3d413d0e3f5e5e47f71bd887cd3c994120f11ce17','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8477f3b5ca52c8d532347b94a11f831f53e761a8b993a7a063f308612f7cccc5',2025,'CH','Switzerland','introduction',1536,'Background: Following World War I, France
acquired a mandate over the northern portion
of the former Ottoman Empire province of Syria.
The French administered the area as Syria until
granting it independence in 1946. The new coun-
try lacked political stability, however, and expe-
rienced a series of military coups during its first
decades. Syria united with Egypt in February 1958
to form the United Arab Republic. In September
1961, the two entities separated, and the Syrian
Arab Republic was reestablished. In November
1970, Hafiz al-ASAD, a member of the socialist
Ba’th Party and the minority Alawi sect, seized
power in a bloodless coup and brought political
stability to the country. In the 1967 Arab-Israeli
War, Syria lost the Golan Heights to Israel. Dur-
ing the 1990s, Syria and Israel held occasional
peace talks over its return. Following the death
of President al-ASAD, his son, Bashar al-ASAD,
was approved as president by popular referendum
in July 2000. Syrian troops—stationed in Leba-
non since 1976 in an ostensible peacekeeping
tole—were withdrawn in April 2005. During
the July-August 2006 conflict between Israel and
Hizballah, Syria placed its military forces on alert
but did not intervene directly on behalf of its ally
Hizballah. In May 2007 Bashar al-ASAD’s sec-
ond term as president was approved by popular
referendum. Influenced by major uprisings that
began elsewhere in the region, antigovernment
protests broke out in the southern province of
. Dara in March 2011 with protesters calling
for the repeal of the restrictive Emergency Law
allowing arrests without charge, the legalization
of political parties, and the removal of corrupt
local officials: Since then demonstrations and
unrest have spread to nearly every city in Syria,
but the size and intensity of protests have fluc-
tuated over time. The government responded to
unrest with a mix of concessions—including the
repeal of the Emergency Law and approving new
laws permitting new political parties and liberal-
izing local and national elections—and force.
However, the. government''s response has failed
fo meet opposition demands for ASAD to step
down, and the government''s ongoing security
operations to quell unrest apd widespread armed
opposition activity have led to extended violent
SYRIA
clashes between government forces and opposi-
tionists. International pressure on the ASAD
regime has intensified since late 2011, as the
Arab League, EU, Turkey, and the United States
have expanded economic sanctions against the
regime. Lakhdar BRAHIMI, current -Joint Spe-
cial Representative of the United Nations and
the League of Arab States on the Syrian crisis,
in October 2012 began meeting with regional
heads of state to assist in brokering a cease-fire.
In December 2012, the National Coalition of
Syrian Revolution and Opposition Forces was
recognized by more than 130 countries as the sole
legitimate representative of the Syrian people.
Unrest persists in 2013, and the death toll among
Syrian Government forces, opposition forces, and
civilians has topped 70,000.
Background: In 1895, military defeat forced
China”s Qing Dynasty to cede Taiwan to Japan.
Taiwan came under Chinese Nationalist control
after World War II. Following the Communist
victory on the mainland in 1949, 2 million
Nationalists fled to Taiwan and established a
government using the 1947 constitution drawn
up for all of China. Beginning in the 1950s,
the ruling authorities gradually democratized
and incorporated the local population within
the governing structure. This process expanded
rapidly in the 1980s. In 2000, Taiwan under-
went its first peaceful transfer of power from the
Nationalist to the Democratic Progressive Party.
Throughout this period, the island prospered and
became one of East Asia’s economic “Tigers.”
The dominant political issues continue to be the
relationship between Taiwan and China—spe-
cifically the question of Taiwan’s eventual sta-
tus—as well as domestic political and economic
reform.','cc0fce0617b651b9b3b8ca11f1671d7dc0ae23417dc7ffa05f9743f6f94a4a1a','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('83eee32944d76837e844d7de7263062398536669a16a35e8542631a8de983ca5',2025,'TJ','Tajikistan','introduction',1537,'Background: The Tajik people came under Russian
rule in the 1860s and 1870s, but Russia’s hold on
Central Asia weakened following the Revolution
of 1917. Bolshevik control of the area was fiercely
contested and not fully reestablished until 1925.
Much of present-day Sughd province was trans-
ferred from the Uzbek SSR to the newly formed
Tajik SSR in 1929, Ethnic Uzbeks form a sub-
stantial minority in Tajikistan, Tajikistan became
independent in 1991 following the breakup of the
Soviet Union, and experienced a civil war between
regional factions from 1992-97. Tajikistan endured
several domestic security incidents in 2010-12,
including a mass prison-break from a Dushanbe
710
detention facility, the country’s first suicide car
bombing in Khujand, and armed conflict between
government forces and local strongmen in the
Rasht Valley and government forces and criminal
groups in Gorno-Badakhshan Autonomous Oblast.
The country remains the poorest: in the former
Soviet sphere. Attention by the international
community since the beginning of the NATO
intervention in Afghanistan has brought increased
economic and security assistance, which could cre-
ate jobs and strengthen stability in the long term.
Tajikistan joined NATO''s Partnership for Peace in
2002, and became a member of the World Trade
Organization in March 2013.
Background: Shortly after achieving independ-
ence from Britain in the early 1960s, Tanganyika
and Zanzibar merged to form the nation of Tan-
zania in 1964. One-party rule ended in 1995 with
the first democratic elections held in the country
since the 1970s. Zanzibar’s semi-autonomous status
and popular opposition have led to two conten-
tious elections since 1995, which the ruling party
won despite international observers” claims of vot-
ing irregularities. The formation of a government
of national unity between Zanzibar’s two leading
parties succeeded in minimizing electoral tension
in 2010.
Background: A unified Thai kingdom was estab-
lished in the mid-14th century. Known as Siam
until 1939, Thailand is the only Southeast Asian
country never to have been taken over by a Euro-
pean power. A bloodless revolution in 1932 led to
a constitutional monarchy. In alliance with Japan
during World War II, Thailand became a US
treaty ally in 1954 after sending troops to Korea
and later fighting alongside the United States in
Vietnam. Thailand since 2005 has experienced
several rounds of political turmoil including a
military coup in 2006 that ousted then Prime
Minister THAKSIN Chinnawat, followed by
large-scale street protests by competing political
factions in 2008, 2009, and 2010. Demonstra-
tions in 2010 culminated with clashes between
security forces and pro-THAKSIN protesters,
elements of which were armed, and resulted in
at least 92 deaths and an estimated $1.5 billion
in arson-related property losses. THAKSIN’s
youngest sister, YINGLAK Chinnaw at, in 2011
led the Puea Thai Party to an electoral win and
assumed control of the government. YINGLAK''s
leadership was almost immediately challenged
by historic flooding in late 2011 that had large
swathes of the country underwater and threatened
to inundate Bangkok itself. Throughout 2012 the
Puea Thai-led government struggled with the
opposition Democrat Party to fulfill some of its
718
main election promises, including constitutional
reform and political reconciliation. Since January
2004, thousands have been killed and wounded
in violence associated with the ethno-nationalist
insurgency in Thailand''s southern Malay-Muslim
majority provinces.','e5d59dcce0f58d3cc451fbc7a24433bb39beb3360b6879d4e3b40fcc1d2de2ca','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('880f07fa816ef8d35b17265ec38f5620c03fbd756f35c4d710eb0bb25baa01b2',2025,'TL','Timor-Leste','introduction',1563,'Background: French Togoland became Togo in
1960. Geri. Gnassingbe EYADEMA, installed as
military ruler in 1967, ruled Togo with a heavy
hand for almost four decades. Despite the facade of
multi-party elections instituted in the early 1990s,
the government was largely dominated by Presi-
dent. EYADEMA, whose Rally of the Togolese
People (RPT) party has maintained power almost
continually since 1967 and maintains a majority
of seats in today’s legislature. Upon EYADEMA''s
death in February 2005, the military installed the
president’s son, Faure GNASSINGBE, and then
@ .
engineered his formal election two months later.
Democratic gains since then allowed Togo to hold
its first relatively free and fair legislative elections
in October 2007. After years of political unrest
and condemnation from international organiza-
tions for human rights abuses, Togo is finally being
re-welcomed into the international community.
In January 2012, Togo assumed a nonpermanent
seat on the UN Security Council for the 2012-13
term.','0cfef79f4682c06048b01dba849d25d0c330d4eb1f3f6c892f23037e6d72bc68','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7ac5f1b065145301ebafe99b27185c65adef73522115f05577d0b2ea1a222b22',2025,'TK','Tokelau','introduction',1570,'Background: Originally settled by Polynesian emi-
grants from surrounding island groups, the Tokelau
Islands were made a British protectorate in 1889.
They were transferred to New Zealand administration
in 1925. Referenda held in 2006 and 2007 to change
the status of the islands from that of a New Zealand
territory to one of free association with New Zealand
did not meet the needed threshold for approval.','00d4fb672cb0de3658415107292d61609109271c30d02c421879a260339faa00','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9f25f314e9712770741050aa144b4b89b902d9da95ccd1bfe5beace770e2000e',2025,'TT','Trinidad and Tobago','introduction',1582,'Background: First colonized by the Spanish,
the islands came under British control in the
early 19th century. The islands” sugar industry
was hurt by the emancipation of the slaves in
1834. Manpower was replaced with the impor-
tation of-contract laborers from India between
1845 and 1917, which boosted sugar production
as well as tħe cocoa industry. The discovery of
oil on Trinidad in 1910 added another impor-
tant export. Independence was attained in 1962.
The country is one of the most prosperous in
the Caribbean thanks largely to petroleum and
natural gas production and processing. Tourism,
mostly in Tobago, is targeted for expansion and
is growing. The government is coping with a rise
in violent crime.
a
Background: Rivalry between French and Italian
interests in Tunisia culminated in a French inva-
sion in 1881 and the creation of a protectorate.
Agitation for independence in the decades fol-
lowing World War I was finally successful in get-
ting the French to recognize Tunisia as an inde-
pendent state in 1956. The country’s first presi-
dent, Habib BOURGUIBA, established a strict
one-party state. He dominated the country for
31 years, repressing Islamic fundamentalism and
establishing rights for women unmatched by any
other Arab nation. In November 1987, BOUR-
GUIBA was removed from office and replaced
by Zine el Abidine BEN ALI in a bloodless coup.
Street protests that began in Tunis in December
2010 over high unemployment, corruption, wide-
spread poverty, and high food prices escalated
in January 2011, culminating in rioting that led
to hundreds of deaths. On 14 January 2011, the
same day BEN ALI dismissed the government,
he fled the country, and by late January 2011, a
“national unity government” was formed. Elec-
tions for the new Constituent Assembly were held
in late October 2011, and in December, it elected
human rights activist Moncef MARZOUKI as
interim president. The Assembly began drafting
a new constitution in February 2012, and released
a second working draft in December 2012. The
interim government has proposed presidential
and parliamentary elections be held in 2013.','79c60dc16e16138bbaab08714e6b5d795e47c8d0c785f47c237cf86601313235','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a568d7f101b678aee886507b4116cb9330aa94236e704635ca56cd41a67f7597',2025,'TN','Tunisia','introduction',1590,'Background: Modern Turkey was founded in 1923
from the Anatolian remnants of the defeated Otto-
man Empire by national hero Mustafa KEMAL, who
was later honored with the title Ataturk or “Father
of the Turks.” Under his authoritarian leadership,
the country adopted wide-ranging social, legal, and
political reforms. After a period of one-party rule,
an experiment with multi-party politics led to the
1950 election victory of the opposition Democratic
740
THE CIA WORLD FACTBOOK
teledensity has reached about 125 telephones per
100 persons
international: country code—216; a landing
point for the SEA-ME-WE-4 submarine cabie
system that provides links to Europe, Middle
East, and Asia; satellite earth stations—I Intelsat
(Atlantic Ocean) and 1 Arabsat; coaxial cable
and microwave radio relay to Algeria and Libya;
participant in Medarabtel; 2 international gateway
digital switches (2011)
Broadcast media: broadcast media is mainly
government-controlled; the state-run Tuni-
sian Radio and Television Establishment
(ERTT) operates 2 national TV networks, sev-
eral national radio networks, and a number of
regional radio stations; 1 TV and 3 radio sta-
tions are privately owned and report domestic
news stories directly from the official Tunisian
news agency; the state retains control of broad-
cast facilities and transmitters through L''Office
National de la Telediffusion; Tunisians also have
access to Egyptian, pan-Arab, and European sat-
ellite TV channels (2007)
Internet country code: .tn
Internet hosts: 576 (2012)
country comparison to the world: 180
Internet users: 3.5 million (2009)
country comparison to the world: 60','332c0fe6f9067b80eaf88b858c67db3d63c43b5067c18e0b86d2c66c931d8c58','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8bbc309acde68ee48b4d142d21051d4b6ce1f4b2f72c0477c54bb31c699c80f6',2025,'TM','Turkmenistan','introduction',1595,'Background: Present-day Turkmenistan covers
territory that has been at the crossroads of civiliza-
tions for centuries. The area was ruled in antiquity
by various Persian empires, and was conquered by
Alexander the Great, Muslim crusaders, the Mon-
gols, Turkic warriors, and eventually the Russians.
In medieval times Merv (today known as Mary)
was one of the great cities of the Islamic world
and an important stop on the Silk Road. Annexed
by Russia in the late 1800s, Turkmenistan later
figured prominently in the anti-Bolshevik move-
ment in Central Asia. In 1924, Turkmenistan
became a Soviet republic; it achieved independ-
ence upon the dissolution of the USSR in 1991.
Extensive hydrocarbon/natural gas
which have yet to be fully exploited, have begun
to transform the country. Turkmenistan is mov-
ing to expand its extraction and delivery projects.
The Government of Turkmenistan is actively
working to diversify its gas export routes beyond
the still important Russian pipeline network. In
2010, new gas export pipelines that carry Turkmen
gas to China and to northern Iran began operat-
ing, effectively ending the Russian monopoly on
Turkmen gas exports. President for Life Sapar-
murat NYYAZOW died in December 2006, and
Turkmenistan held its first multi-candidate presi-
dential election in February 2007.Gurbanguly
BERDIMUHAMEDOW, a deputy cabinet chair-
man under NYYAZOW, emerged as the country’s
- new president; he was chosen as president again in
February 2012, in an election that the OSCE said
lacked the freedoms necessary to create a competi-
tive environment.
Location: Centrál Asia, bordering the Caspian
Sea, between Iran and Kazakhstan
Geographic coordinates: 40 00 N, 60 00 E
Map references: Asia
Area: total: 488,100 sq km
country comparison to the world: 53
land: 469,930 sq km
water: 18,170 sq km
Area—comparative: slightly
California : a
reserves,
larger than
Land boundaries: total: 3,736 km
border countries: Afghanistan 744 km, Iran 992
km, Kazakhstan 379 km, Uzbekistan 1,621 km
Coastline: 0 km; note—Turkmenistan borders the
Caspian Sea (1,768 km)
Maritime claims: none (landlocked)
Climate: subtropical desert
Terrain: flat-to-rolling sandy desert with dunes
rising to mountains in the south; low mountains
along border with Iran; borders Caspian Sea in
west
Elevation extremes: lowest point: Vpadina
Akchanaya-81 m
note: Sarygamysh Koli is a lake in northern Turk-
menistan with a water level that fluctuates above
and below the elevation of Vpadina Akchanaya
(the lake has dropped as low as-110 m)
highest point: Gora Ayribaba 3,139 m
Natural resources: petroleum, natural gas, sulfur,
salt
Land use: arable land: 3.89%
permanent crops: 0.12%
other: 95.98% (2011)
Irrigated land: 19,910 sq km (2006)
Total renewable water resources: 24.77 cu km
(2011)
Freshwater withdrawal (domestic/industrial/
agricultural): total: 27.95 cu km/yr (3%/3%/94%)
per capita: 5,752 cu m/yr (2004)
Natural hazards: NA
Environment—current issues: contamination of
soil and groundwater with agricultural chemicals,
pesticides; salination, water logging of soil due to
poor irrigation methods; Caspian Sea pollution;
diversion of a large share of the flow of the Amu
Darya into irrigation contributes to that river''s
inability to replenish the Aral Sea; desertification
Environment—international agreements:
party to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Hazard-
ous Wastes, Ozone Layer Protection
signed, but not ratified: none of the selected
agreements
Geography—note: landlocked; the western and
central low-lying desolate portions of the country
make up the great Garagum (Kara-Kum) desert,
which occupies over 80% of the country; eastern
part is plateau
Nationality: noun: Turkmen(s)
adjective: Turkmen
Ethnic groups: Turkmen 85%, Uzbek 5%, Russian
4%, other 6% (2003)
Languages: Turkmen (official) 72%, Russian
12%, Uzbek 9%, other 7%
Religions: Muslim 89%, Eastern Orthodox 9%,
unknown 2%
Population: 5,113,040 (July 2013 est.)
country comparison to the world: 118
Age structure: 0-14 years: 26.7% (male 690,673/
female 673,271)
15-24 years: 20.8% (male 535,131/female 528,473)
25-54 years: 41.8% (male 1,058,811/female
1,079,697)
55-64 years: 6.5% (male 157,474/female 176,088)
65 years and over: 4.2% (male 92,891/female
120,531) (2013 est.)
Median age: total: 26.2 years
male: 25.8 years
female: 26.6 years (2013 est.)
Population growth rate: 1.15% (2013 est.)
country comparison to the world: 103
Birth rate: 19.53 births/1,000 population (2013
est.)
country comparison to the world: 90
Death rate: 6.18 deaths/1,000 population (2013
est.)
country comparison to the world: 158
Net migration rate: -1.88 migrant(s)/1,000 popu-
lation (2013 est.)
country comparison to the world: 160
Urbanization: urban population: 50% of total
population (2010)
rate of urbanization: 2.2% annual rate of change
(2010-15 est.)
Major urban areas—population;: ASHGABAT
(capital) 637,000 (2009)
Sex ratio: at birth: 1.05 male(s)/female
0-14 years: 1.03 male(s)/female
15-24 years: 1.01 male(s)/female
25-54 years: 0.98 male(s)/female
55-64 years: 0.9 male(s)/female
65 years and over: 0.77 male(s)/female
total population: 0.98 male(s)/female (2013 est.)
Maternal mortality rate: 67 deaths/100,000 live
births (2010)
country comparison to the world; 89
Infant mortality rate: total: 39.48 deaths/1,000
live births
country comparison to the world: 60
male: 47.17 deaths/1,000 live births
female: 31.41 deaths/1,000 live births (2013 est.)
Life expectancy at birth: total population: 69.16
years i
country comparison to the world: 156
male: 66.18 years
female: 72.29 years (2013 est.)
Total fertility rate: 2.12 children born/woman
(2013 est.)
country comparison to the world: 108 |
Health expenditures: 2.5% of GDP (2010)
country comparison to the world: 186
Physicians density: 2.44 physicians/1,000 popu-
lation (2007)
Hospital bed density: 4 beds/1,000 population
(2009)
Drinking water source:
Improved:
urban: 97% of population
rural: 72% of population
total: 83% of population
Unimproved:
urban: 3% of population
rural: 28% of population
total: 17% of population (2000 est.)
745
Sanitation facility access:
Improved:
urban: 99% of population
rural: 97% of population
total: 98% of population
Unimproved:
urban: 1% of population
rural: 3% of population
total: 2% of population (2010 est.)
HIV/AIDS—adult prevalence rate: less than
0.1% (2007 est.)
country comparison to the world: 110
HIV/AIDS—people living with HIV/AIDS: fewer
than 200 (2007 est.)
country comparison to the world: 156
HIV/AIDS—deaths: fewer than 100 (2004 est.)
country comparison to the world: 118
Obesity—adult prevalence rate: 13.2% (2008)
country comparison to the world: 125
Education expenditures; NA
Literacy: definition: age 15 and over can read and
write total population: 98.8%
male: 99.3%
female: 98.3% (1999 est.)','3af198fb5c6888ee99820f7bff25c9ac59597b12e83005c0f6051005797d7609','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2f9fcdc5da7c8f835027373cb0f18bd940fefc8f8b3130628000834419c1abfd',2025,'TC','Turks and Caicos Islands','introduction',1610,'Background: In 1974, ethnic differences within
the British colony of the Gilbert and Ellice Islands
caused the Polynesians of the Ellice Islands to
vote for separation from the Micronesians of the
750
Gilbert Islands. The following year, the Ellice
Islands became the separate British colony of
Tuvalu. Independence was granted in 1978. In
2000, Tuvalu negotiated a contract leasing its
Internet domain naine “.tv” for $50 million in roy-
alties over a 12-year period. i','758b3049829c52d1ac4b703e9eea9882b00fa0eeff860381bdd258a617c90c31','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('64766476e0d7a3c9e6075f044dcccb3a0b9d174e244cf6445bd01390e29662a3',2025,'TV','Tuvalu','introduction',1618,'Background: The colonial boundaries created by
Britain to delimit Uganda grouped together a wide
range of ethnic groups with different political sys-
tems and cultures. These differences prevented the
establishment of a working political community
after independence was achieved in 1962. The dic-
tatorial regime of Idi AMIN (1971-79) was respon-
sible for the deaths of some 300,000 opponents;
guerrilla war and human rights abuses under Mil-
ton OBOTE (1980-85) claimed at least another
100,000 lives. The rule of Yoweri MUSEVENI
since 1986 has brought relative stability and eco-
nomic growth to Uganda. During the 1990s, the
government promulgated non-party presidential
and legislative elections.','c1b0e7c8b026c036b55edcf280ddfccc531e9a0c19d9290370d6d49bbe46d75a','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('179a3b9eb9fea8376925c34ba7c73d375344d1ea058bb73da6fb6ce7ee8d0a7c',2025,'UG','Uganda','introduction',1624,'Background: Ukraine was the center of the first
eastern Slavic state, Kyivan Rus, which during the
10th and 11th centuries was the largest and most
powerful state in Europe. Weakened by interne-
cine quarrels and Mongol invasions, Kyivan Rus
was incorporated into the Grand Duchy of Lithu-
ania and eventually into the Polish-Lithuanian
Commonwealth. The cultural and religious legacy
of Kyivan Rus laid the foundation for Ukrainian
nationalism through subsequent centuries, A new
Ukrainian state, the Cossack Hetmanate, was
established during the mid-17th century after an
uprising against the Poles. Despite continuous
Muscovite pressure, the Hetmanate managed
to remain autonomous for well over 100 years.
During the latter part of the 18th century, most
Ukrainian ethnographic territory was absorbed
by the Russian Empire. Following the collapse
756
THE CIA WORLD FACTBOOK
1,524 to 2,437 m:7
914 to 1523 m: 26
under 914 m: 7 (2012)
Railways: total: 1,244 km
country comparison to the world: 83
narrow gauge: 1,244 km 1.000-m gauge (2008)
Roadwoys: total: 70,746 km
country comparison to the world: 66
paved: 16,272 km
unpaved: 54,474 km (2003)
Waterways: (there are no long navigable stretches
of river in Uganda; parts of the Albert Nile that
flow out of Lake Albert in the northwestern part of
the country are navigable; several lakes including
Lake Victoria and Lake Kyoga have substantial traf-
fic; Lake Albert is navigable along a 200-km stretch
from its northern tip to its southern shores) (2011)
Ports and terminals: Entebbe, Jinja, Port Bell','97ee75a7cb9642047beab1c2ea5e08a03bb828f938e80ac8c87850a3a7ce0396','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b3ad259c3596669d59ea1a3fd2576956b5e77e0d7cf75e86db6a99e9ac370021',2025,'AE','United Arab Emirates','introduction',1636,'Background: The Trucial States of the Per-
sian Gulf coast granted the UK control of their
defense and foreign affairs in 19th century trea-
ties. In 1971, six of these states—Abu Dhabi,
‘Ajman, Al Fujayrah, Ash Shariqah, Dubayy, and
Umm al Qaywayn—merged to form the United
Arab Emirates (UAE). They were joined in 1972
by Ra’s al Khaymah. The UAE''s per capita GDP
is on par with those of leading West European
nations. Its high oil revenues and its moderate
foreign policy stance have allowed the UAE to
play a vital role in the affairs of the region. For
more than three decades, oil and global finance
drove the UAE''s economy. However, in 2008-09,
the confluence of falling oil prices, collapsing
real estate prices, and the international banking
crisis hit the UAE especially hard. The UAE has
essentially avoided the “Arab Spring” unrest seen
elsewhere in the Middle East, though in March
2011, political activists and intellectuals signed
a petition calling for greater public participation
in governance that was widely circulated on the
Internet. In an effort to stem potential further
unrest, the government announced a multi-year,
$1.6-billion infrastructure investment plan for the
poorer northern Emirates.','0a6e831c8d14fc091ba722a134bf2c87d5ecba5b29632c815e70f4da56abda4f','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('054f5c988b7f97ee085c2399df9e030f528b354019d9c0259dad397dbb1b990d',2025,'GB','United Kingdom','introduction',1645,'Background: The United Kingdom has histori-
cally played a leading role in developing parlia-
mentary democracy and in advancing literature
and science. At its zenith in the 19th century, the
British Empire stretched over one-fourth of the
earth''s surface. The first half of the 20th century
saw the UK’s strength seriously depleted in two
world wars and the Irish Republic’s withdrawal
from the union. The second half witnessed the
dismantling of the Empire and the UK rebuild-
ing itself into a modern and prosperous European
nation. As one of five permanent members of the
UN Security Council and a founding member of
NATO and the Commonwealth, the UK pursues
a global approach to foreign policy. The UK is also
an active member of the EU, although it chose
to remain outside the Economic and Monetary
Union. The Scottish Parliament, the National
Assembly for Wales, and the Northern Ireland
Assembly were established in 1999. The latter was
suspended until May 2007 due to wrangling over
the peace process, but devolution was fully com-
pleted in March 2010.','04e69606188fc6015a59f677aad941a35280d74c36ceb5798f8001e347b14363','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6fa4f725b7a13205b224782e5970f29ce41b8a9c0862cdea495e4d4f45e294e1',2025,'UY','Uruguay','introduction',1670,'Background: Russia conquered the territory of
present-day Uzbekistan in the late 19th century.
Stiff resistance to the Red Army after the Bol-
shevik Revolution was eventually suppressed
and a socialist republic established in 1924.
During the Soviet era, intensive production of
“white gold” (cotton) and grain led to overuse
of agrochemicals and the depletion of water
supplies, which have left the land degraded and
the Aral Sea and certain rivers half dry. Inde-
pendent since 1991, the country seeks to gradu-
ally lessen its dependence on the cotton mono-
culture by diversifying agricultural production
while developing its mineral and petroleum
reserves and increasing its manufacturing base.
Current concerns include terrorism by Islamic
militants, economic stagnation, and the curtail-
ment of human rights and democratization.','48726248ed3d9fce3196166f72a50c904b01f4e85ba9e9abe75aeb2fdf046266','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9c32acf788a23e0a1eb697a60efc9286baaf3ec8360839b7ef5ba2782d960f20',2025,'UZ','Uzbekistan','introduction',1679,'Background: Multiple waves of colonizers, each
speaking a distinct language, migrated to the New
Hebrides in the millennia preceding European
exploration in the 18th century. This settlement
pattern accounts for the complex linguistic diver-
sity found on the archipelago to this day. The
British and French, who settled the New Hebrides
in the 19th century, agreed in 1906 to an Anglo-
French Condominium, which administered the
islands until independence in 1980, when the new
name of Vanuatu was adopted.','edcf6f17a53da66fcb76e2ae8a0eb57ea2924c93508c3325169ff8db149c1936','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('61a1643f7ce68dc319215111bee89213b403d36049ddcde0c1bda413e803ceeb',2025,'VN','Viet Nam','introduction',1696,'Background: During the 17th century, the archi-
“pelago was divided into two territorial units, one
English and the other Danish. Sugarcane, pro-
duced by African slave labor, drove the islands’
economy during the 18th and early 19th centuries.
In 1917, the US purchased the Danish portion,
which had.been in economic decline since the
abolition of slaverý in 1848.','c3771f200fc64e469d01ed77b29cb6e15362a0787ba976c657e47d905c2e9401','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('da36ff0411fe070679f9cb08e5ac40dafd5edd32531d0bbbec9fdce81a532405',2025,'WF','Wallis and Futuna','introduction',1704,'Background: The Futuna island group was discov-
ered by the Dutch in 1616 and Wallis by the Brit-
ish in 1767, but it was the French who declared
a protectorate over the islands in 1842, and took
official control of them berween 1886 and 1888.
Notably, Wallis and Futuna was the only French
colony to side with the Vichy regime during World
War II, a phase that ended in May of 1942 with
the arrival of 2,000 American troops. In 1959,
the inhabitants of the islands voted to become a
French overseas territory and officially assumed
this status in July 1961.','efc8662f20de09851b06b81b7b9b6123b247325c889c8523b9ab8781a224c14d','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('12d68d32631edd0825b72c3f25f94b75a0b3bfc5c6c220d952fd611af721dede',2025,'EH','Western Sahara','introduction',1710,'Background: Westem Sahara is a disputed terri-
tory-Of the northwest coast of Africa bordered by
Morocco, Mauritania, and Algeria. After Spain
withdrew from its former colony of Spanish Sahara
in 1976, Morocco annexed the northern two-
thirds of Western Sahara and claimed the rest of
the territory in 1979, following Mauritania”s with-
drawal.. A guerrilla war with the Polisario Front
contesting Morocco”s sovereignty ended in a 1991
cease-fire and the establishment of a UN peace-
keeping operation. As part of this effort, the UN
sought to offer a choice to the peoples of the West-
ern Sahara between independence (favored by
the Polisario Front) or integration into Morocco.
A proposed referendum never took place-due to
lack of agreement on voter eligibility. The 2,700
km-(1,700 mi-) long defensive sand berm, built
by the Moroccans from 1980 to 1987 and running
the length of the territory, continues to separate
the opposing forces with Morocco controlling
the roughly 80 percent of the territory west of the
berm. Ethnic tensions in Western Sahara occa-
sionally erupt into violence requiring a Moroccan
security forcé response.
Background: Globally, the 20th century was
marked by: (a) two devastating world wars; (b)
the Great Depression of the 1930s; (c) the end of
vast colonial empires; (d) rapid advances in sci-
ence and technology, from the first airplane flight
at Kitty Hawk, North Carolina (US) to the land-
ing on the moon; (e) the Cold War between the
804
Western alliance and the Warsaw Pact nations; (f)
a sharp rise in living standards in North America,
Europe, and Japan; (g) increased concerns about
environmental degradation including deforesta-
tion, energy and water shortages, declining bio-
logical diversity, and air pollution; (h) the onset
of the AIDS epidemic; and (i) the ultimate emer-
gence of the US as the only world superpower. The
planet''s population continues to explode: from 1
billion in 1820 to 2 billion in 1930, 3 billion in
1960, 4 billion in 1974, 5 billion in 1987, 6 billion
in 1999, and 7 billion in 2012. For the 21st cen-
tury, the continued exponential growth in science
and technology raises both hopes (e.g., advances
in medicine) and fears (e.g., development of even
more lethal weapons of war).
World
Background: North Yemen became independent
of the Ottoman Empire in 1918. The British, who
had set up a protectorate area around the south-
em port of Aden in the 19th century, withdrew in
1967 from what became South Yemen. Three years
later, the southern government adopted a Marxist
orientation. The massive exodus of hundreds of
thousands of Yemenis from the south to the north
contributed to two decades of hostility between the
states. The two countries were formally unified as
the Republic of Yemen in 1990. A southern seces-
sionist movement and brief civil war in 1994 was
quickly subdued. In 2000, Saudi Arabia and Yemen
agreed to a delimitation of their border. Fighting
in the northwest between the government and
Huthi rebels, a group seeking a retum to traditional
Zaydi Islam, began in 2004 and has since resulted
in six rounds of fighting—the last ended in early
2010 with a cease-fire that continues to hold. The
southern secessionist movement was revitalized
in 2008 when a popular socioeconomic protest
movement initiated the prior year took on political
goals including secession. Public rallies in Sana”a
against then President SALIH—inspired by similar
demonstrations in Tunisia and Egypt—slowly built
momentum starting in late January 2011 fueled by
complaints over high unemployment, poor eco-
nomic conditions, and corruption. By the following
month, some protests had resulted in violence, and
the demonstrations had spread to other major cities.
By March the opposition had hardened its demands
and was unifying behind calls for SALIH’s immedi-
ate ouster, The Gulf Cooperation Council (GCC)
in late April 2011, in an attempt to mediate the
crisis in Yemen, proposed an agreement in which
the president would step down in exchange for
immunity from prosecution. SALIH’s refusal to sign
an agreement led to heavy street fighting and his
injury in an explosion in June 2011, The UN Secu-
rity Council passed Resolution 2014 in October
2011 calling on both sides to end the violence and
complete a power transfer deal. In late November
2011, SALIH signed the GCC-brokered agreement
to step down and to transfer some of his powers to
Vice President Abd Rabuh Mansur HADI. Fol-
lowing elections in February 2012, won by HADI,
SALIH formally transferred his powers. In accord-
ance with the GCC initiative, Yemen launched a
810
National Dialogue to discuss key constitutional,
political, and social issues in mid-March 2013.','0b1c8a352823c6d8d8543e07c78f5404849dc94391f4eb68f011787ce38748ce','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('01aa8b3d6b7dfecd9f892af65dea931f9982325b63e48cae70e7666ae1dc3d54',2025,'YE','Yemen','introduction',1724,'Background: The territory of Northern Rhodesia
was administered by the [British] South Africa
Company from 1891 until it was taken over by
the UK in 1923. During the 1920s and 1930s,
advances in mining spurred development and
immigration. The name was changed to Zambia
upon independence in 1964. In the 1980s and
1990s, declining copper prices, economic mis-
management and a prólonged drought hurt, the
economy. Elections in 1991 brought an end to
one-party rule, but the subsequent vote in 1996
saw blatant harassment of opposition parties. The
election in 2001 was marked by administrative
problems with three parties filing a legal petition
challenging the election of ruling party candidate
Levy MWANAWASA. MWANAWASA was
reelected in 2006 in an election that was deemed
free and fair. Upon his abrupt death in August
2008, he was succeeded by his vice president,
Rupiah BANDA, who subsequently won a special
presidential by election in October 2008. Michael
SATA was elected president in September 2011.','01cba33b56ea47b9b41384759724ea61fc1c69ce2e23247097e707c38d7e29ad','internet-archive','CIA-World-Factbook-collection','txt','d614d55a5c92b6d13a273b54df1e6b62d7e420ded11bf4eac6ee5903ea0f1c79','https://archive.org/download/CIA-World-Factbook-collection/The%202014%20CIA%20World%20Factbook%20by%20United%20States%20Central%20Intelligence%20Agency_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);

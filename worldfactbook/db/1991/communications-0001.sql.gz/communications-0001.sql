SET NAMES utf8mb4;
CREATE TABLE IF NOT EXISTS worldfactbook_chunks (
  chunk_id CHAR(64) NOT NULL,
  edition_year SMALLINT UNSIGNED NOT NULL,
  entity_code VARCHAR(24) NOT NULL DEFAULT '',
  entity_name VARCHAR(160) NOT NULL DEFAULT '',
  category VARCHAR(96) NOT NULL,
  ordinal INT UNSIGNED NOT NULL,
  content MEDIUMTEXT NOT NULL,
  content_sha256 CHAR(64) NOT NULL,
  source_provider VARCHAR(64) NOT NULL,
  source_identifier VARCHAR(255) NOT NULL,
  source_format VARCHAR(32) NOT NULL,
  source_sha256 CHAR(64) NOT NULL,
  source_url TEXT NOT NULL,
  extractor VARCHAR(64) NOT NULL,
  PRIMARY KEY (chunk_id),
  KEY idx_wfb_year_category (edition_year, category),
  KEY idx_wfb_entity_year (entity_code, edition_year),
  KEY idx_wfb_source_sha (source_sha256)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('26912a9ca4a687f5b2994ee2d3221f8cc87aa709c261e15f8950a46786a46f5a',1991,'ZW','Zimbabwe','communications',20,'_#_Railroads: 9.6 km (single track) 1.524-meter gauge from Kushka
(USSR) to Towraghondi and 15.0 km from Termez (USSR) to
Kheyrabad transshipment point on south bank of Amu Darya
_#_Highways: 21,000 km total (1984); 2,800 km hard surface, 1,650 km
bituminous-treated gravel and improved earth, 16,550 km unimproved earth
and tracks
_#_Inland waterways: total navigability 1,200 km; chiefly Amu Darya,
which handles steamers up to about 500 metric tons
_#_Pipelines: petroleum, oil, and lubricants pipelines--USSR
to Bagram and USSR to Shindand; natural gas, 180 km
_#_Ports: Shir Khan and Kheyrabad (river ports)
_#_Civil air: 2 TU-154, 2 Boeing 727, 4 Yak-40, assorted smaller
transports
_#_Airports: 40 total, 36 usable; 9 with permanent-surface runways;
none with runways over 3,659 m; 10 with runways 2,440-3,659 m;
17 with runways 1,220-2,439 m
_#_Telecommunications: limited telephone, telegraph, and
radiobroadcast services; television introduced in 1980; 31,200
telephones; stations--5 AM, no FM, 1 TV; 1 satellite earth station
_*_Defense Forces
_#_Branches: Army, Air and Air Defense Forces, Special
Guard/National Guard, Border Guard Forces, National Police Force
(Sarandoi), Ministry of State Security (WAD), Tribal Militia
_#_Manpower availability: males 15-49, 4,049,092; 2,171,757 fit for
military service; 166,135 reach military age (22) annually
_#_Defense expenditures: $450 million, 15% of GDP (1990)
_%_
_@_Albania
_#_Railroads: 543 km total; 509 1.435-meter standard gauge, single
track and 34 km narrow gauge, single track (1990); line connecting
Titograd (Yugoslavia) and Shkoder (Albania) completed August 1986
_#_Highways: 16,700 km total; 6,700 km highway and roads, 10,000 km
forest and agricultural (1990)
_#_Inland waterways: 43 km plus Albanian sections of Lake Scutari,
Lake Ohrid, and Lake Prespa (1990)
_#_Pipelines: crude oil, 145 km; refined products, 55 km; natural gas,
64 km (1988)
_#_Ports: Durres, Sarande, Vlore
_#_Merchant marine: 11 cargo ships (1,000 GRT or over) totaling 52,886
GRT/75,993 DWT
_#_Airports: 12 total, 10 usable; more than 5 with permanent-surface
runways; more than 5 with runways 2,440-3,659 m; 5 with runways
1,220-2,439 m
_#_Telecommunications: stations--17 AM, 1 FM, 9 TV; 246,000 TVs
(1990); 210,000 radios
_*_Defense Forces
_#_Branches: Albanian People''s Army, Albanian Coastal Defense Command,
Air and Air Defense Force, Frontier Troops, Interior Troops
_#_Manpower availability: males 15-49, 900,723; 743,594 fit for
military service; 33,497 reach military age (19) annually
_#_Defense expenditures: 1.0 billion leks, NA% of GDP (FY90);
note--conversion of defense expenditures into US dollars using the
official administratively set exchange rate would produce misleading
results
_%_
_@_Algeria
_#_Railroads: 4,146 km total; 2,632 km standard gauge (1.435 m),
1,258 km 1.055-meter gauge, 256 km 1.000-meter gauge; 300 km electrified;
215 km double track
_#_Highways: 80,000 km total; 60,000 km concrete or bituminous,
20,000 km gravel, crushed stone, unimproved earth
_#_Pipelines: crude oil, 6,612 km; refined products, 298 km; natural
gas, 2,948 km
_#_Ports: Algiers, Annaba, Arzew, Bejaia, Jijel, Mers el Kebir,
Mostaganem, Oran, Skikda
_#_Merchant marine: 75 ships (1,000 GRT or over) totaling 903,179
GRT/1,063,994 DWT; includes 5 short-sea passenger, 27 cargo, 2 vehicle
carrier, 10 roll-on/roll-off cargo, 5 petroleum, oils, and lubricants
(POL) tanker, 9 liquefied gas, 7 chemical tanker, 9 bulk, 1 specialized
tanker
_#_Civil air: 42 major transport aircraft
_#_Airports: 145 total, 134 usable; 53 with permanent-surface runways;
3 with runways over 3,659 m; 30 with runways 2,440-3,659 m; 66 with
runways 1,220-2,439 m
_#_Telecommunications: excellent domestic and international service in
the north, sparse in the south; 693,000 telephones; stations--26 AM, no
FM, 113 TV; 1,550,000 TV sets; 3,500,000 receiver sets; 6 submarine
cables; coaxial cable or radio relay to Italy, France, Spain, Morocco,
and Tunisia; satellite earth stations--1 Atlantic Ocean INTELSAT, 1
Indian Ocean INTELSAT, 1 Intersputnik, 1 ARABSAT, and 15 domestic
_*_Defense Forces
_#_Branches: Army, Navy, Air Force, Territorial Air Defense,
National Gendarmerie
_#_Manpower availability: males 15-49, 6,142,818; 3,780,873 fit for
military service; 293,175 reach military age (19) annually
_#_Defense expenditures: $857 million, 1.8% of GDP (1991)
_%_
_@_American Samoa
(territory of the US)
_#_Railroads: none
_#_Highways: 350 km total; 150 km paved, 200 km unpaved
_#_Ports: Pago Pago, Ta''u
_#_Airports: 4 total, 4 usable; 2 with permanent-surface runways;
none with runways over 3,659 m; 1 with runways 2,440 to 3,659 m
(international airport at Tafuna, near Pago Pago); small airstrips on
Ta''u and Ofu
_#_Telecommunications: 6,500 telephones; stations--1 AM, 2 FM, 1 TV;
good telex, telegraph, and facsimile services; 1 Pacific Ocean INTELSAT
earth station, 1 COMSAT earth station
_*_Defense Forces
_#_Note: defense is the responsibility of the US
_%_
_@_Andorra
_#_Highways: 96 km
_#_Telecommunications: international digital microwave network;
international landline circuits to France and Spain; stations--1 AM, no
FM, no TV; 17,700 telephones
_*_Defense Forces
_#_Note: defense is the responsibility of France and Spain
_%_
_@_Angola
_#_Railroads: 3,189 km total; 2,879 km 1.067-meter gauge, 310 km
0.600-meter gauge; limited trackage in use because of insurgent attacks;
sections of the Benguela Railroad closed because of insurgency
_#_Highways: 73,828 km total; 8,577 km bituminous-surface treatment,
29,350 km crushed stone, gravel, or improved earth, remainder unimproved
earth
_#_Inland waterways: 1,295 km navigable
_#_Pipelines: crude oil, 179 km
_#_Ports: Luanda, Lobito, Namibe, Cabinda
_#_Merchant marine: 12 ships (1,000 GRT or over) totaling
66,348 GRT/102,825 DWT; includes 11 cargo, 1 petroleum, oils, and
lubricants (POL) tanker
_#_Civil air: 27 major transport aircraft
_#_Airports: 315 total, 183 usable; 28 with permanent-surface runways;
1 with runways over 3,659 m; 13 with runways 2,440-3,659 m; 58 with
runways 1,220-2,439 m
_#_Telecommunications: fair system of wire, radio relay, and
troposcatter routes; high frequency used extensively for military/Cuban
links; 40,300 telephones; stations--17 AM, 13 FM, 2 TV; 2 Atlantic Ocean
INTELSAT earth stations
_*_Defense Forces
_#_Branches: Army, Navy, Air Force/Air Defense, People''s Defense
Organization and Territorial Troops, Frontier Guard
_#_Manpower availability: males 15-49, 2,080,837; 1,047,500 fit for
military service; 92,430 reach military age (18) annually
_#_Defense expenditures: $NA, NA% of GDP
_%_
_@_Anguilla
(dependent territory of the UK)
_#_Highways: 60 km surfaced
_#_Ports: Road Bay, Blowing Point
_#_Civil air: no major transport aircraft
_#_Airports: 3 total, 3 usable; 1 with permanent-surface runways of
1,100 m (Wallblake Airport)
_#_Telecommunications: modern internal telephone system; 890
telephones; stations--3 AM, 1 FM, no TV; radio relay link to island of
Saint Martin
_*_Defense Forces
_#_Note: defense is the responsibility of the UK
_%_
_@_Antarctica
_#_Airports: 37 total; 27 usable; none with permanent hard-surface
runways; 2 with runways over 3,659 m; 5 with runways 2,440-3,659 m;
4 with runways 1,220-2,439 m
_#_Ports: none; offshore anchorage only
_*_Defense Forces
_#_Note: none; Article 7 of the Antarctic Treaty states that advance
notice of all activities and the introduction of military personnel must
be given
_%_
_@_Antigua and Barbuda
_#_Railroads: 64 km 0.760-meter narrow gauge and 13 km 0.610-meter
gauge used almost exclusively for handling sugarcane
_#_Highways: 240 km
_#_Ports: Saint John''s
_#_Merchant marine: 86 ships (1,000 GRT or over) totaling 319,477
GRT/497,194 DWT; includes 61 cargo, 5 refrigerated cargo, 6 container,
4 roll-on/roll-off cargo, 1 multifunction large load carrier, 3
petroleum, oils, and lubricants (POL) tanker, 6 chemical tanker; note--a
flag of convenience registry
_#_Civil air: 10 major transport aircraft
_#_Airports: 3 total, 3 usable; 2 with permanent-surface runways;
1 with runways 2,440-3,659 m; 2 with runways less than 1,220 m
_#_Telecommunications: good automatic telephone system; 6,700
telephones; tropospheric scatter links with Saba and Guadeloupe;
stations--4 AM, 2 FM, 2 TV, 2 shortwave; 1 coaxial submarine cable;
1 Atlantic Ocean INTELSAT earth station
_*_Defense Forces
_#_Branches: Royal Antigua and Barbuda Defense Force, Royal Antigua
and Barbuda Police Force (includes the Coast Guard)
_#_Manpower availability: NA
_#_Defense expenditures: $1.4 million, less than 1% of GDP (FY91)
_%_
_@_Arctic Ocean
_#_Ports: Churchill (Canada), Murmansk (USSR), Prudhoe Bay (US)
_#_Telecommunications: no submarine cables
_#_Note: sparse network of air, ocean, river, and land routes; the
Northwest Passage (North America) and Northern Sea Route (Asia) are
important waterways
_%_
_@_Argentina
_#_Railroads: 34,172 km total (includes 169 km electrified); includes
a mixture of 1.435-meter standard gauge, 1.676-meter broad gauge,
1.000-meter gauge, and 0.750-meter gauge
_#_Highways: 208,350 km total; 47,550 km paved, 39,500 km gravel,
101,000 km improved earth, 20,300 km unimproved earth
_#_Inland waterways: 11,000 km navigable
_#_Pipelines: 4,090 km crude oil; 2,900 km refined products; 9,918 km
natural gas
_#_Ports: Bahia Blanca, Buenos Aires, Necochea, Rio Gallegos, Rosario,
Santa Fe
_#_Merchant marine: 129 ships (1,000 GRT or over) totaling 1,663,884
GRT/2,689,645 DWT; includes 42 cargo, 7 refrigerated cargo, 6 container,
1 railcar carrier, 47 petroleum, oils, and lubricants (POL) tanker,
4 chemical tanker, 4 liquefied gas, 18 bulk; additionally, 2 naval
tankers and 1 military transport are sometimes used commercially
_#_Civil air: 54 major transport aircraft
_#_Airports: 1,763 total, 1,575 usable; 135 with permanent-surface
runways; 1 with runways over 3,659 m; 31 with runways 2,440-3,659 m; 336
with runways 1,220-2,439 m
_#_Telecommunications: extensive modern system; 2,650,000 telephones
(12,000 public telephones); radio relay widely used; stations--171 AM,
no FM, 231 TV, 13 shortwave; 2 Atlantic Ocean INTELSAT earth stations;
domestic satellite network has 40 stations
_*_Defense Forces
_#_Branches: Argentine Army, Navy of the Argentine Republic, Argentine
Air Force, National Gendarmerie, Argentine Naval Prefecture (Coast Guard
only), National Aeronautical Police Force
_#_Manpower availability: males 15-49, 7,992,140; 6,478,730 fit for
military service; 285,047 reach military age (20) annually
_#_Defense expenditures: $700 million, 1% of GNP (1990)
_%_
_@_Aruba
(part of the Dutch realm)
_#_Ports: Oranjestad, Sint Nicolaas
_#_Airfield: government-owned airport east of Oranjestad
_#_Telecommunications: generally adequate; extensive interisland radio
relay links; 72,168 telephones; stations--4 AM, 4 FM, 1 TV; 1 sea cable
to Sint Maarten
_*_Defense Forces
_#_Note: defense is the responsibility of the Netherlands
_%_
_@_Ashmore and Cartier Islands
(territory of Australia)
_#_Ports: none; offshore anchorage only
_*_Defense Forces
_#_Note: defense is the responsibility of Australia; periodic
visits by the Royal Australian Navy and Royal Australian Air Force
_%_
_@_Atlantic Ocean
_#_Ports: Alexandria (Egypt), Algiers (Algeria), Antwerp (Belgium),
Barcelona (Spain), Buenos Aires (Argentina), Casablanca (Morocco),
Colon (Panama), Copenhagen (Denmark), Dakar (Senegal), Gdansk (Poland),
Hamburg (Germany), Helsinki (Finland), Las Palmas (Canary Islands, Spain),
Le Havre (France), Saint Petersburg (formerly Leningrad; USSR), Lisbon
(Portugal), London (UK), Marseille (France), Montevideo (Uruguay),
Montreal (Canada), Naples (Italy), New Orleans (US), New York (US), Oran
(Algeria), Oslo (Norway), Piraeus (Greece), Rio de Janeiro (Brazil),
Rotterdam (Netherlands), Stockholm (Sweden)
_#_Telecommunications: numerous submarine cables with most between
continental Europe and the UK, North America and the UK, and in the
Mediterranean; numerous direct links across Atlantic via INTELSAT
satellite network
_#_Note: Kiel Canal and Saint Lawrence Seaway are two important
waterways
_%_
_@_Australia
_#_Railroads: 40,478 km total; 7,970 km 1.600-meter gauge, 16,201 km
1.435-meter standard gauge, 16,307 km 1.067-meter gauge; 183 km dual
gauge; 1,130 km electrified; government owned (except for a few hundred
kilometers of privately owned track) (1985)
_#_Highways: 837,872 km total; 243,750 km paved, 228,396 km gravel,
crushed stone, or stabilized soil surface, 365,726 km unimproved earth
_#_Inland waterways: 8,368 km; mainly by small, shallow-draft craft
_#_Pipelines: crude oil, 2,500 km; refined products, 500 km; natural
gas, 5,600 km
_#_Ports: Adelaide, Brisbane, Cairns, Darwin, Devonport, Fremantle,
Geelong, Hobart, Launceston, Mackay, Melbourne, Sydney, Townsville
_#_Merchant marine: 77 ships (1,000 GRT or over) totaling 2,249,926
GRT/3,391,323 DWT; includes 2 short-sea passenger, 6 cargo, 6 container,
10 roll-on/roll-off cargo, 1 vehicle carrier, 16 petroleum, oils, and
lubricants (POL) tanker, 1 chemical tanker, 4 liquefied gas, 1
combination ore/oil, 30 bulk
_#_Civil air: around 150 major transport aircraft
_#_Airports: 747 total, 524 usable; 270 with permanent-surface
runways, 1 with runways over 3,659 m; 17 with runways 2,440-3,659 m;
401 with runways 1,220-2,439 m
_#_Telecommunications: good international and domestic service; 8.7
million telephones; stations--258 AM, 67 FM, 134 TV; submarine cables to
New Zealand, Papua New Guinea, and Indonesia; domestic satellite service;
satellite stations--4 Indian Ocean INTELSAT, 6 Pacific Ocean INTELSAT
earth stations
_*_Defense Forces
_#_Branches: Australian Army, Royal Australian Navy, Royal Australian
Air Force
_#_Manpower availability: males 15-49, 4,689,559; 4,090,921 fit for
military service; 135,435 reach military age (17) annually
_#_Defense expenditures: $6.6 billion, 2.2% of GDP (FY90)
_%_
_@_Austria
_#_Railroads: 6,028 km total; 5,388 km government owned and 640 km
privately owned (1.435- and 1.000-meter gauge); 5,403 km 1.435-meter
standard gauge of which 3,051 km is electrified and 1,520 km is double
tracked; 363 km 0.760-meter narrow gauge of which 91 km is electrified
_#_Highways: 95,412 km total; 34,612 are the primary network
(including 1,012 km of autobahn, 10,400 km of federal, and 23,200 km of
provincial roads); of this number, 21,812 km are paved and 12,800 km are
unpaved; in addition, there are 60,800 km of communal roads (mostly
gravel, crushed stone, earth)
_#_Inland waterways: 446 km
_#_Ports: Vienna, Linz (river ports)
_#_Merchant marine: 32 ships (1,000 GRT or over) totaling
150,735 GRT/252,237 DWT; includes 26 cargo, 1 container, 1 chemical
tanker, 4 bulk
_#_Pipelines: 554 km crude oil; 2,611 km natural gas; 171 km refined
products
_#_Civil air: 25 major transport aircraft
_#_Airports: 55 total, 54 usable; 20 with permanent-surface runways;
none with runways over 3,659 m; 5 with runways 2,440-3,659 m; 4 with
runways 1,220-2,439 m
_#_Telecommunications: highly developed and efficient; 4,014,000
telephones; extensive TV and radiobroadcast systems; stations--6 AM, 21
(545 repeaters) FM, 47 (870 repeaters) TV; satellite stations operating
in INTELSAT 1 Atlantic Ocean earth station and 1 Indian Ocean earth
station and EUTELSAT systems
_*_Defense Forces
_#_Branches: Army, Flying Division, Gendarmerie
_#_Manpower availability: males 15-49, 1,957,414; 1,646,179 fit for
military service; 48,038 reach military age (19) annually
_#_Defense expenditures: $1.4 billion, 1% of GDP (1990)
_%_
_@_The Bahamas
_#_Highways: 2,400 km total; 1,350 km paved, 1,050 km gravel
_#_Ports: Freeport, Nassau
_#_Merchant marine: 636 ships (1,000 GRT or over) totaling 14,266,066
GRT/23,585,465 DWT; includes 42 passenger, 16 short-sea passenger, 190
cargo, 41 roll-on/roll-off cargo, 23 container, 5 car carrier,
1 railroad carrier, 141 petroleum, oils, and lubricants (POL) tanker, 8
liquefied gas, 15 combination ore/oil, 33 chemical tanker, 1 specialized
tanker, 112 bulk, 8 combination bulk; note--a flag of convenience
registry
_#_Civil air: 9 major transport aircraft
_#_Airports: 59 total, 57 usable; 31 with permanent-surface runways;
none with runways over 3,659 m; 3 with runways 2,440-3,659 m; 25 with
runways 1,220-2,439 m
_#_Telecommunications: highly developed; 99,000 telephones in totally
automatic system; tropospheric scatter and submarine cable links to
Florida; stations--3 AM, 2 FM, 1 TV; 3 coaxial submarine cables; 1
Atlantic Ocean INTELSAT earth station
_*_Defense Forces
_#_Branches: Royal Bahamas Defense Force (a coast guard element only),
Royal Bahamas Police Force
_#_Manpower availability: males 15-49, 68,020; NA fit for military
service
_#_Defense expenditures: $65 million, 2.7% of GDP (1990)
_%_
_@_Bahrain
_#_Highways: 200 km bituminous surfaced, including 25 km
bridge-causeway to Saudi Arabia opened in November 1986; NA km
natural surface tracks
_#_Ports: Mina Salman, Manama, Sitrah
_#_Merchant marine: 4 cargo and 2 container (1,000 GRT or over)
totaling 114,733 GRT/155,065 DWT
_#_Pipelines: crude oil, 56 km; refined products, 16 km; natural gas,
32 km
_#_Civil air: 24 major transport aircraft
_#_Airports: 3 total, 3 usable; 2 with permanent-surface runways; 2
with runways over 3,659 m; 1 with runways 1,220-2,439 m
_#_Telecommunications: excellent international telecommunications;
adequate domestic services; 98,000 telephones; stations--2 AM, 1 FM,
2 TV; satellite earth stations--1 Atlantic Ocean INTELSAT, 1 Indian Ocean
INTELSAT, 1 ARABSAT; tropospheric scatter and microwave to Qatar, UAE,
Saudi Arabia; submarine cable to Qatar and UAE
_*_Defense Forces
_#_Branches: Army, Navy, Air Force, Air Defense, Police Force
_#_Manpower availability: males 15-49, 187,606; 104,285 fit for
military service
_#_Defense expenditures: $194 million, 6% of GDP (1990)
_%_
_@_Baker Island
(territory of the US)
_#_Ports: none; offshore anchorage only, one boat landing area along
the middle of the west coast
_#_Airports: 1 abandoned World War II runway of 1,665 m
_#_Note: there is a day beacon near the middle of the west coast
_*_Defense Forces
_#_Note: defense is the responsibility of the US; visited annually by
the US Coast Guard
_%_
_@_Bangladesh
_#_Railroads: 2,892 km total (1986); 1,914 km 1.000 meter gauge,
978 km 1.676 meter broad gauge
_#_Highways: 7,240 km total (1985); 3,840 km paved, 3,400 km unpaved
_#_Inland waterways: 5,150-8,046 km navigable waterways (includes
2,575-3,058 km main cargo routes)
_#_Ports: Chittagong, Chalna
_#_Merchant marine: 47 ships (1,000 GRT or over) totaling
339,081 GRT/500,008 DWT; includes 38 cargo, 2 petroleum, oils, and
lubricants (POL) tanker, 3 refrigerated cargo, 1 roll-on/roll-off, 3 bulk
_#_Pipelines: 1,220 km natural gas
_#_Civil air: 15 major transport aircraft
_#_Airports: 16 total, 12 usable; 12 with permanent-surface runways;
none with runways over 3,659 m; 4 with runways 2,440-3,659 m; 6 with
runways 1,220-2,439 m
_#_Telecommunications: adequate international radio communications and
landline service; fair domestic wire and microwave service; fair
broadcast service; 241,250 telephones; stations--9 AM, 6 FM, 11 TV;
2 Indian Ocean INTELSAT satellite earth stations
_*_Defense Forces
_#_Branches: Army, Navy, Air Force; paramilitary forces--Bangladesh
Rifles, Bangladesh Ansars, Armed Police Reserve, Coastal Police
_#_Manpower availability: males 15-49, 28,896,632; 17,154,593 fit for
military service
_#_Defense expenditures: $319 million, 1.5% of GDP (FY91)
_%_
_@_Barbados
_#_Highways: 1,570 km total; 1,475 km paved, 95 km gravel and earth
_#_Ports: Bridgetown
_#_Merchant marine: 2 cargo ships (1,000 GRT or over) totaling 3,200
GRT/7,338 DWT
_#_Civil air: 2 major transport aircraft
_#_Airports: 1 with permanent-surface runways 2,440-3,659 m
_#_Telecommunications: islandwide automatic telephone system with
89,000 telephones; tropospheric scatter link to Trinidad and Saint Lucia;
stations--3 AM, 2 FM, 2 (1 is pay) TV; 1 Atlantic Ocean INTELSAT earth
station
_*_Defense Forces
_#_Branches: Royal Barbados Defense Force, Coast Guard, Royal
Barbados Police Force
_#_Manpower availability: males 15-49, 69,038; 48,455 fit for military
service, no conscription
_#_Defense expenditures: $10 million, 0.7% of GDP (1989)
_%_
_@_Bassas da India
(French possession)
_#_Ports: none; offshore anchorage only
_*_Defense Forces
_#_Note: defense is the responsibility of France
_%_
_@_Belgium
_#_Railroads: Belgian National Railways (SNCB) operates 3,667 km
1.435-meter standard gauge, government owned; 2,563 km double track;
1,978 km electrified; 191 km 1.000-meter gauge, government owned and
operated
_#_Highways: 103,396 km total; 1,317 km limited access, divided
autoroute; 11,717 km national highway; 1,362 km provincial road; about
38,000 km paved and 51,000 km unpaved rural roads
_#_Inland waterways: 2,043 km (1,528 km in regular commercial use)
_#_Ports: Antwerp, Brugge, Gent, Oostende, Zeebrugge
_#_Merchant marine: 69 ships (1,000 GRT or over) totaling 1,785,066
GRT/2,927,618 DWT; includes 12 cargo, 6 roll-on/roll-off, 6 container, 7
petroleum, oils, and lubricants (POL) tanker, 9 liquefied gas, 3
combination ore/oil, 9 chemical tanker, 11 bulk, 6 combination bulk
_#_Pipelines: refined products 1,167 km; crude 161 km; natural gas
3,300 km
_#_Civil air: 47 major transport aircraft
_#_Airports: 42 total, 42 usable; 24 with permanent-surface runways;
none with runways over 3,659 m; 14 with runways 2,440-3,659 m; 3 with
runways 1,220-2,439 m
_#_Telecommunications: excellent domestic and international telephone
and telegraph facilities; 4,720,000 telephones; stations--8 AM, 19 FM (42
relays), 25 TV (10 relays); 5 submarine cables; satellite earth stations
operating in INTELSAT 3 Atlantic Ocean and EUTELSAT systems
_*_Defense Forces
_#_Branches: Army, Navy, Air Force, National Gendarmerie
_#_Manpower availability: males 15-49, 2,521,178; 2,115,935 fit for
military service; 64,634 reach military age (19) annually
_#_Defense expenditures: $4.8 billion, 2.5% of GDP (1990)
_%_
_@_Belize
_#_Highways: 2,710 km total; 500 km paved, 1,600 km gravel, 300 km
improved earth, and 310 km unimproved earth
_#_Inland waterways: 825 km river network used by shallow-draft craft;
seasonally navigable
_#_Ports: Belize City; additional ports for shallow draught craft
include Corozol, Punta Gorda, Big Creek
_#_Civil air: no major transport aircraft
_#_Airports: 42 total, 32 usable; 3 with permanent-surface runways;
none with runways over 2,439 m; 2 with runways 1,220-2,439 m
_#_Telecommunications: 8,650 telephones; above-average system based on
radio relay; stations--6 AM, 5 FM, 1 TV, 1 shortwave; 1 Atlantic Ocean
INTELSAT earth station
_*_Defense Forces
_#_Branches: British Forces Belize, Belize Defense Force (including
Army, Navy, Air Force, and Volunteer Guard), Belize National Police
_#_Manpower availability: males 15-49, 53,184; 31,790 fit for military
service; 2,545 reach military age (18) annually
_#_Defense expenditures: $4.8 million, 1.8% of GDP (1990 est.)
_%_
_@_Benin
_#_Railroads: 578 km, all 1.000-meter gauge, single track
_#_Highways: 5,050 km total; 920 km paved, 2,600 laterite, 1,530 km
improved earth
_#_Inland waterways: navigable along small sections, important
only locally
_#_Ports: Cotonou
_#_Civil air: 3 major transport aircraft
_#_Airports: 6 total, 4 usable; 1 with permanent-surface runways;
none with runways over 2,439 m; 4 with runways 1,220-2,439 m
_#_Telecommunications: fair system of open wire, submarine cable, and
radio relay; 16,200 telephones; stations--2 AM, 2 FM, 1 TV; 1 Atlantic
Ocean INTELSAT satellite earth station
_*_Defense Forces
_#_Branches: People''s Armed Forces (including Army, Navy, Air Force),
National Gendarmerie, People''s Militia, Presidential Guard
_#_Manpower availability: eligible 15-49, 2,089,646; of the 991,278
males 15-49, 507,482 are fit for military service; of the 1,098,368
females 15-49, 554,454 are fit for military','d468475ec0b6b9b99e3c5aee7541f42fb12425b6dd14f8101d4589089fe3a53b','internet-archive','theciaworldfactb00025gut','txt','84185fe9df79da427349cc1598fd3f69814a2085a9fc1fe0508a3fae0a870f84','https://archive.org/download/theciaworldfactb00025gut/25.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('82dde609c8b37e72f9c3066ca199ea254c95feaee8c66ed7a7d3fc21b550cf5a',1991,'ZW','Zimbabwe','communications',21,'service; about 57,106 males
and 55,297 females reach military age (18) annually; both sexes are
liable for military service
_#_Defense expenditures: $38 million, 2.3% of GDP (1988)
_%_
_@_Bermuda
(dependent territory of the UK)
_#_Highways: 210 km public roads, all paved (about 400 km of private
roads)
_#_Ports: Freeport, Hamilton, Saint George
_#_Merchant marine: 84 ships (1,000 GRT or over) totaling 3,826,756
GRT/6,932,981 DWT; includes 3 short-sea passenger, 8 cargo, 7
refrigerated cargo, 4 container, 8 roll-on/roll-off, 26 petroleum, oils,
and lubricants (POL) tanker, 11 liquefied gas, 17 bulk; note--a flag of
convenience registry
_#_Civil air: 16 major transport aircraft
_#_Airports: 1 with permanent-surface runways 2,440-3,659 m
_#_Telecommunications: modern with fully automatic telephone system;
52,670 telephones; stations--5 AM, 3 FM, 2 TV; 3 submarine cables; 2
Atlantic Ocean INTELSAT earth stations
_*_Defense Forces
_#_Branches: Bermuda Regiment, Bermuda Police Force, Reserve
Constabulary
_#_Note: defense is the responsibility of the UK
_%_
_@_Bhutan
_#_Highways: 1,304 km total; 418 km surfaced, 515 km improved, 371 km
unimproved earth
_#_Civil air: 1 jet, 2 prop
_#_Airports: 2 total, 2 usable; 1 with permanent-surface runways;
none with runways over 2,439 m; 2 with runways 1,220-2,439 m
_#_Telecommunications: inadequate; 1,990 telephones (1988); 22,000
radios (1990 est.); 85 TVs (1985); stations--1 AM, 1 FM, no TV (1990)
_*_Defense Forces
_#_Branches: Royal Bhutan Army, Palace Guard, Militia
_#_Manpower availability: males 15-49, 398,263; 213,083 fit for
military service; 17,321 reach military age (18) annually
_#_Defense expenditures: $NA, NA% of GDP
_%_
_@_Bolivia
_#_Railroads: 3,675 km total; 3,643 km 1.000-meter gauge and 32 km
0.760-meter gauge, all government owned, single track
_#_Highways: 38,836 km total; 1,300 km paved, 6,700 km gravel,
30,836 km improved and unimproved earth
_#_Inland waterways: 10,000 km of commercially navigable waterways
_#_Pipelines: crude oil 1,800 km; refined products 580 km; natural gas
1,495 km
_#_Ports: none; maritime outlets are Arica and Antofagasta in Chile
and Matarani in Peru
_#_Merchant marine: 2 cargo ships (1,000 GRT or over) totaling 14,051
GRT/22,155 DWT
_#_Civil air: 56 major transport aircraft
_#_Airports: 807 total, 659 usable; 9 with permanent-surface runways;
1 with runways over 3,659 m; 8 with runways 2,440-3,659 m; 120 with
runways 1,220-2,439 m
_#_Telecommunications: radio relay system being expanded; improved
international services; 144,300 telephones; stations--129 AM, no FM, 43
TV, 68 shortwave; 1 Atlantic Ocean INTELSAT earth station
_*_Defense Forces
_#_Branches: Bolivian Army, Bolivian Navy (including Marines),
Bolivian Air Force, National Police Force
_#_Manpower availability: males 15-49, 1,679,352; 1,091,368 fit for
military service; 72,979 reach military age (19) annually
_#_Defense expenditures: $162 million, 4% of GNP (1988 est.)
_%_
_@_Botswana
_#_Railroads: 712 km 1.0 67-meter gauge
_#_Highways: 11,514 km total; 1,600 km paved; 1,700 km crushed stone
or gravel, 5,177 km improved earth, 3,037 km unimproved earth
_#_Civil air: 6 major transport aircraft
_#_Airports: 100 total, 87 usable; 8 with permanent-surface runways;
none with runways over 3,659 m; 2 with runways 2,440-3,659 m; 26 with
runways 1,220-2,439 m
_#_Telecommunications: the small system is a combination of open-wire
lines, radio relay links, and a few radiocommunication stations; 17,900
telephones; stations--2 AM, 3 FM, no TV; 1 Indian Ocean INTELSAT earth
station
_*_Defense Forces
_#_Branches: Botswana Defense Force (including Army and Air Wing),
Botswana National Police
_#_Manpower availability: males 15-49, 260,290; 137,038 fit for
military service; 14,767 reach military age (18) annually
_#_Defense expenditures: $99 million, 8.2% of GNP (1989)
_%_
_@_Bouvet Island
(territory of Norway)
_#_Ports: none; offshore anchorage only
_#_Telecommunications: automatic meteorological station
_*_Defense Forces
_#_Note: defense is the responsibility of Norway
_%_
_@_Brazil
-------------------------------------------------------------------------
_#_Group of 2 (G-2)
established--informal term that came into use about 1986;
aim--bilateral economic cooperation between the two most powerful
economic giants;
members--(2) Japan, US
-------------------------------------------------------------------------
_#_Group of 3 (G-3)
established--NA October 1990;
aim--mechanism for policy coordination;
members--(3) Colombia, Mexico, Venezuela
-------------------------------------------------------------------------
_#_Group of 5 (G-5)
established--22 September 1985;
aim--the five major non-Communist economic powers;
members--(5) France, Germany, Japan, UK, US
-------------------------------------------------------------------------
_#_Group of 6 (G-6)--not to be confused with the Big Six;
established--22 May 1984;
aim--seeks to achieve nuclear disarmament;
members--(6) Argentina, Greece, India, Mexico, Sweden, Tanzania
-------------------------------------------------------------------------
_#_Group of 7 (G-7)--membership is the same as the Big Seven;
established--22 September 1985;
aim--the seven major non-Communist economic powers;
members--(7) Group of 5 (France, Germany, Japan, UK, US) plus
Canada and Italy
-------------------------------------------------------------------------
_#_Group of 8 (G-8)
established--NA October 1975;
aim--the developed countries (DCs) that participated in the
Conference on International Economic Cooperation (CIEC), held in several
sessions between NA December 1975 and 3 June 1977;
members--(8) Australia, Canada, EC (as one member), Japan, Spain,
Sweden, Switzerland, US
-------------------------------------------------------------------------
_#_Group of 9 (G-9)
established--NA;
aim--informal group that meets occasionally on matters of mutual
interest;
members--(9) Austria, Belgium, Bulgaria, Denmark, Finland, Hungary,
Romania, Sweden, Yugoslavia
-------------------------------------------------------------------------
_#_Group of 10 (G-10), also known as the Paris Club;
established--NA October 1962;
aim--wealthiest members of the IMF who provide most of the money
to be loaned and act as the informal steering committee; name persists in
spite of the addition of Switzerland on NA April 1984;
members--(11) Belgium, Canada, France, Germany, Italy, Japan,
Netherlands, Sweden, Switzerland, UK, US
-------------------------------------------------------------------------
_#_Group of 11 (G-11), also known as the Cartagena Group;
established--22 June 1984, in Cartagena, Colombia;
aim--forum for largest debtor nations in Latin America;
members--(11) Argentina, Bolivia, Brazil, Chile, Colombia,
Dominican Republic, Ecuador, Mexico, Peru, Uruguay, Venezuela
-------------------------------------------------------------------------
_#_Group of 19 (G-19)
established--NA October 1975;
aim--the less developed countries (LDCs) that participated in the
Conference on International Economic Cooperation (CIEC) held in several
sessions between NA December 1975 and 3 June 1977;
members--(19) Algeria, Argentina, Brazil, Cameroon, Egypt, India,
Indonesia, Iran, Iraq, Jamaica, Mexico, Nigeria, Pakistan, Peru,
Saudi Arabia, Venezuela, Yugoslavia, Zaire, Zambia
-------------------------------------------------------------------------
_#_Group of 24 (G-24)
established--NA January 1972;
aim--to promote the interests of developing countries in Africa,
Asia, and Latin America within the IMF;
members--(24) Algeria, Argentina, Brazil, Colombia, Egypt,
Ethiopia, Gabon, Ghana, Guatemala, India, Iran, Ivory Coast, Lebanon,
Mexico, Nigeria, Pakistan, Peru, Philippines, Sri Lanka, Syria,
Trinidad and Tobago, Venezuela, Yugoslavia, Zaire
-------------------------------------------------------------------------
_#_Group of 30 (G-30)
established--NA 1979;
aim--to discuss and propose solutions to the world''s economic
problems;
members--(30) informal group of 30 leading international bankers,
economists, financial experts, and businessmen organized by Johannes
Witteveen (former managing director of the IMF)
-------------------------------------------------------------------------
_#_Group of 33 (G-33)
established--NA 1987;
aim--to promote solutions to international economic problems;
members--(33) leading economists from 13 countries
-------------------------------------------------------------------------
_#_Group of 77 (G-77)
established--NA October 1967;
aim--to promote economic cooperation among developing countries;
name persists in spite of increased membership;
members--(123 plus the Palestine Liberation Organization)
Afghanistan, Algeria, Angola, Antigua and Barbuda, Argentina, The
Bahamas, Bahrain, Bangladesh, Barbados, Belize, Benin, Bhutan, Bolivia,
Botswana, Brazil, Burkina, Burma, Burundi, Cambodia, Cameroon, Cape
Verde, Central African Republic, Chad, Chile, Colombia, Comoros, Congo,
Costa Rica, Cuba, Cyprus, Djibouti, Dominica, Dominican Republic,
Ecuador, Egypt, El Salvador, Equatorial Guinea, Ethiopia, Fiji, Gabon,
The Gambia, Ghana, Grenada, Guatemala, Guinea, Guinea-Bissau, Guyana,
Haiti, Honduras, India, Indonesia, Iran, Iraq, Ivory Coast, Jamaica,
Jordan, Kenya, North Korea, South Korea, Kuwait, Laos, Lebanon, Lesotho,
Liberia, Libya, Madagascar, Malawi, Malaysia, Maldives, Mali, Malta,
Mauritania, Mauritius, Mexico, Morocco, Mozambique, Nepal, Nicaragua,
Niger, Nigeria, Oman, Pakistan, Panama, Papua New Guinea, Paraguay, Peru,
Philippines, Qatar, Romania, Rwanda, Saint Lucia, Saint Vincent and the
Grenadines, Sao Tome and Principe, Saudi Arabia, Senegal, Seychelles,
Sierra Leone, Singapore, Solomon Islands, Somalia, Sri Lanka, Sudan,
Suriname, Swaziland, Syria, Tanzania, Thailand, Togo, Tonga, Trinidad and
Tobago, Tunisia, Uganda, UAE, Uruguay, Vanuatu, Venezuela, Vietnam,
Western Samoa, Yemen, Yugoslavia, Zaire, Zambia, Zimbabwe, Palestine
Liberation Organization
-------------------------------------------------------------------------
_#_Gulf Cooperation Council (GCC), also known as the Cooperation
Council for the Arab States of the Gulf;
established--25-26 May 1981;
aim--to promote regional cooperation in economic, social,
political, and military affairs;
members--(6) Bahrain, Kuwait, Oman, Qatar, Saudi Arabia, UAE
-------------------------------------------------------------------------
_#_Habitat--see United Nations Center for Human Settlements (UNCHS)
-------------------------------------------------------------------------
_#_high-income countries--another term for the industrialized
countries with high per capita GNPs/GDPs; see developed countries (DCs)
-------------------------------------------------------------------------
_#_industrial countries--another term for the developed countries; see
developed countries (DCs)
-------------------------------------------------------------------------
_#_Inter-American Development Bank (IADB), also known as
Banco Interamericano de Desarollo (BID);
established--8 April 1959; effective 30 December 1959;
aim--to promote economic and social development in Latin America;
members--(44) Argentina, Austria, The Bahamas, Barbados, Belgium,
Bolivia, Brazil, Canada, Chile, Colombia, Costa Rica, Denmark,
Dominican Republic, Ecuador, El Salvador, Finland, France, Germany,
Guatemala, Guyana, Haiti, Honduras, Israel, Italy, Jamaica, Japan,
Mexico, Netherlands, Nicaragua, Norway, Panama, Paraguay, Peru, Portugal,
Spain, Suriname, Sweden, Switzerland, Trinidad and Tobago, UK, US,
Uruguay, Venezuela, Yugoslavia
-------------------------------------------------------------------------
_#_Inter-Governmental Authority on Drought and Development (IGADD)
established--NA January 1986;
aim--to promote cooperation on drought-related matters;
members--(6) Djibouti, Ethiopia, Kenya, Somalia, Sudan, Uganda
-------------------------------------------------------------------------
_#_International Atomic Energy Agency (IAEA)
established--26 October 1956, effective 29 July 1957;
aim--to promote peaceful uses of atomic energy;
members--(111) Afghanistan, Albania, Algeria, Argentina, Australia,
Austria, Bangladesh, Belgium, Bolivia, Brazil, Bulgaria, Burma,
Byelorussian Soviet Socialist Republic, Cambodia, Cameroon, Canada,
Chile, China, Colombia, Costa Rica, Cuba, Cyprus, Czechoslovakia,
Denmark, Dominican Republic, Ecuador, Egypt, El Salvador, Ethiopia,
Finland, France, Gabon, Germany, Ghana, Greece, Guatemala, Haiti,
Hungary, Iceland, India, Indonesia, Iran, Iraq, Ireland, Israel, Italy,
Ivory Coast, Jamaica, Japan, Jordan, Kenya, North Korea, South Korea,
Kuwait, Lebanon, Liberia, Libya, Liechtenstein, Luxembourg, Madagascar,
Malaysia, Mali, Mauritius, Mexico, Mongolia, Morocco, Namibia,
Netherlands, NZ, Nicaragua, Niger, Nigeria, Norway, Pakistan, Panama,
Paraguay, Peru, Philippines, Poland, Portugal, Qatar, Romania,
Saudi Arabia, Senegal, Sierra Leone, Singapore, South Africa, Spain,
Sri Lanka, Sudan, Sweden, Switzerland, Syria, Tanzania, Thailand,
Tunisia, Turkey, Uganda, Ukrainian Soviet Socialist Republic, UAE, UK,
US, USSR, Uruguay, Vatican City, Venezuela, Vietnam, Yugoslavia, Zaire,
Zambia, Zimbabwe
-------------------------------------------------------------------------
_#_International Bank for Economic Cooperation (IBEC)
established--22 October 1963;
aim--to promote economic cooperation and development;
members--(9) Bulgaria, Cuba, Czechoslovakia, Hungary, Mongolia,
Poland, Romania, USSR, Vietnam
-------------------------------------------------------------------------
_#_International Bank for Reconstruction and Development (IBRD), also
known as the World Bank;
established--22 July 1944, effective 27 December 1945;
aim--UN specialized agency that initially promoted economic
rebuilding after World War II and now provides economic development
loans;
members--(152) all UN members except Albania, Angola, Brunei,
Bulgaria, Byelorussian Soviet Socialist Republic, Cuba, Czechoslovakia,
Liechtenstein, Ukrainian Soviet Socialist Republic, USSR; other members
are Kiribati, South Korea, Tonga
-------------------------------------------------------------------------
_#_International Chamber of Commerce (ICC)
established--NA 1919;
aim--to promote free trade, private enterprise, and represent
business interests at national and international levels;
members--(60 national councils) Argentina, Australia, Austria,
Belgium, Brazil, Burkina, Cameroon, Canada, Colombia, Cyprus, Denmark,
Ecuador, Egypt, Finland, France, Gabon, Germany, Greece, Iceland, India,
Indonesia, Iran, Ireland, Israel, Italy, Ivory Coast, Japan, Jordan,
South Korea, Kuwait, Lebanon, Luxembourg, Madagascar, Mexico, Morocco,
Netherlands, Nigeria, Norway, Pakistan, Portugal, Saudi Arabia, Senegal,
Singapore, South Africa, Spain, Sri Lanka, Sweden, Switzerland, Syria,
Taiwan, Thailand, Togo, Tunisia, Turkey, UK, US, Uruguay, Venezuela,
Yugoslavia, Zaire
-------------------------------------------------------------------------
_#_International Civil Aviation Organization (ICAO)
established--7 December 1944, effective 4 April 1947;
aim--UN specialized agency to promote international cooperation in
civil aviation;
members--(161) all UN members except Albania, Belize, Byelorussian
Soviet Socialist Republic, Dominica, Liechtenstein, Namibia, Saint Kitts
and Nevis, Ukrainian Soviet Socialist Republic, Western Samoa; other
members are Cook Islands, Kiribati, North Korea, South Korea,
Marshall Islands, Federated States of Micronesia, Monaco, Nauru,
San Marino, Switzerland, Tonga
-------------------------------------------------------------------------
_#_International Committee of the Red Cross (ICRC)
established--NA 1863;
aim--to provide humanitarian aid in wartime;
members--(25 individuals) all Swiss nationals
-------------------------------------------------------------------------
_#_International Confederation of Free Trade Unions (ICFTU)
established--NA December 1949;
aim--to promote the trade union movement;
members--(142 national organizations in the following 95 areas)
Antigua and Barbuda, Argentina, Australia, Austria, The Bahamas,
Bangladesh, Barbados, Belgium, Bermuda, Botswana, Brazil, Burkina,
Canada, Central African Republic, Chad, Chile, Colombia, Costa Rica,
Cyprus, Denmark, Dominica, Dominican Republic, Ecuador, El Salvador,
Falkland Islands, Fiji, Finland, France, The Gambia, Germany, Greece,
Grenada, Guatemala, Guyana, Honduras, Hong Kong, Iceland, India,
Indonesia, Israel, Italy, Jamaica, Japan, Kiribati, South Korea, Lebanon,
Lesotho, Liberia, Luxembourg, Malawi, Malaysia, Malta, Mauritius, Mexico,
Montserrat, Netherlands, Netherlands Antilles, NZ, Nicaragua, Norway,
Pakistan, Panama, Papua New Guinea, Peru, Philippines, Poland, Portugal,
Puerto Rico, Saint Helena, Saint Kitts and Nevis, Saint Lucia,
Saint Vincent and the Grenadines, San Marino, Seychelles, Sierra Leone,
Singapore, Spain, Sri Lanka, Suriname, Swaziland, Sweden, Switzerland,
Taiwan, Thailand, Trinidad and Tobago, Tunisia, Turkey, Uganda, UK, US,
USSR, Vanuatu, Vatican City, Venezuela, Western Samoa
-------------------------------------------------------------------------
_#_International Court of Justice (ICJ), also known as the
World Court;
established--26 June 1945, effective 24 October 1945;
aim--primary judicial organ of the UN;
members--(15 judges) elected by the General Assembly and Security
Council to represent all principal legal systems
-------------------------------------------------------------------------
_#_International Criminal Police Organization (INTERPOL)
established--13 June 1956;
aim--to promote international cooperation between criminal police
authorities;
members--(151) Algeria, Andorra, Angola, Antigua and Barbuda,
Argentina, Aruba, Australia, Austria, The Bahamas, Bahrain, Bangladesh,
Barbados, Belgium, Belize, Benin, Bolivia, Botswana, Brazil, Brunei,
Burkina, Burma, Burundi, Cambodia, Cameroon, Canada, Cape Verde,
Central African Republic, Chad, Chile, China, Colombia, Congo,
Costa Rica, Cuba, Cyprus, Denmark, Djibouti, Dominica,
Dominican Republic, Ecuador, Egypt, Equatorial Guinea, Ethiopia, Fiji,
Finland, France, Gabon, The Gambia, Germany, Ghana, Greece, Grenada,
Guatemala, Guinea, Guyana, Haiti, Honduras, Hungary, Iceland, India,
Indonesia, Iran, Iraq, Ireland, Israel, Italy, Ivory Coast, Jamaica,
Japan, Jordan, Kenya, Kiribati, South Korea, Kuwait, Laos, Lebanon,
Lesotho, Liberia, Libya, Liechtenstein, Luxembourg, Madagascar, Malawi,
Malaysia, Maldives, Mali, Malta, Mauritania, Mauritius, Mexico, Monaco,
Morocco, Mozambique, Nauru, Nepal, Netherlands, Netherlands Antilles, NZ,
Nicaragua, Niger, Nigeria, Northern Ireland, Norway, Oman, Pakistan,
Panama, Papua New Guinea, Paraguay, Peru, Philippines, Portugal, Qatar,
Romania, Rwanda, Saint Kitts and Nevis, Saint Lucia, Saint Vincent and
the Grenadines, Sao Tome and Principe, Saudi Arabia, Senegal, Seychelles,
Sierra Leone, Singapore, Somalia, Spain, Sri Lanka, Sudan, Suriname,
Swaziland, Sweden, Switzerland, Syria, Tanzania, Thailand, Togo, Tonga,
Trinidad and Tobago, Tunisia, Turkey, Uganda, UAE, UK, US, USSR, Uruguay,
Venezuela, Yemen, Yugoslavia, Zaire, Zambia, Zimbabwe
-------------------------------------------------------------------------
_#_International Development Association (IDA)
established--26 January 1960, effective 24 September 1960;
aim--UN specialized agency and IBRD affiliate that provides
economic loans for low income countries;
members--(136);
Part I--(22 more economically advanced countries) Australia, Austria,
Belgium, Canada, Denmark, Finland, France, Germany, Iceland, Ireland,
Italy, Japan, Kuwait, Luxembourg, Netherlands, NZ, Norway, South Africa,
Sweden, UAE, UK, US;
Part II--(114 less developed nations) Afghanistan, Algeria, Argentina,
Bangladesh, Belize, Benin, Bhutan, Bolivia, Botswana, Brazil, Burkina,
Burma, Burundi, Cambodia, Cameroon, Cape Verde, Central African Republic,
Chad, Chile, China, Colombia, Comoros, Congo, Costa Rica, Cyprus,
Djibouti, Dominica, Dominican Republic, Ecuador, Egypt, El Salvador,
Equatorial Guinea, Ethiopia, Fiji, Gabon, The Gambia, Ghana, Greece,
Grenada, Guatemala, Guinea, Guinea-Bissau, Guyana, Haiti, Honduras,
Hungary, India, Indonesia, Iran, Iraq, Israel, Ivory Coast, Jordan,
Kenya, Kiribati, South Korea, Laos, Lebanon, Lesotho, Liberia, Libya,
Madagascar, Malawi, Malaysia, Maldives, Mali, Mauritania, Mauritius,
Mexico, Morocco, Mozambique, Nepal, Nicaragua, Niger, Nigeria, Oman,
Pakistan, Panama, Papua New Guinea, Paraguay, Peru, Philippines, Poland,
Rwanda, Saint Kitts and Nevis, Saint Lucia, Saint Vincent and the
Grenadines, Sao Tome and Principe, Saudi Arabia, Senegal, Sierra Leone,
Solomon Islands, Somalia, Spain, Sri Lanka, Sudan, Swaziland, Syria,
Tanzania, Thailand, Togo, Tonga, Trinidad and Tobago, Tunisia, Turkey,
Uganda, Vanuatu, Vietnam, Western Samoa, Yemen, Yugoslavia, Zaire,
Zambia, Zimbabwe
-------------------------------------------------------------------------
_#_International Energy Agency (IEA)
established--15 November 1974;
aim--established by the OECD to promote cooperation on energy
matters, especially emergency oil sharing and relations between oil
consumers and oil producers;
members--(21) Australia, Austria, Belgium, Canada, Denmark,
Germany, Greece, Ireland, Italy, Japan, Luxembourg, Netherlands, NZ,
Norway, Portugal, Spain, Sweden, Switzerland, Turkey, UK, US
-------------------------------------------------------------------------
_#_International Finance Corporation (IFC)
established--25 May 1955, effective 20 July 1956;
aim--UN specialized agency and IBRD affiliate that helps private
enterprise sector in economic development;
members--(133) Afghanistan, Antigua and Barbuda, Argentina,
Australia, Austria, The Bahamas, Bangladesh, Barbados, Belgium, Belize,
Benin, Bolivia, Botswana, Brazil, Burkina, Burma, Burundi, Cameroon,
Canada, Chile, China, Colombia, Congo, Costa Rica, Cyprus, Denmark,
Djibouti, Dominica, Dominican Republic, Ecuador, Egypt, El Salvador,
Ethiopia, Fiji, Finland, France, Gabon, The Gambia, Germany, Ghana,
Greece, Grenada, Guatemala, Guinea, Guinea-Bissau, Guyana, Haiti,
Honduras, Hungary, Iceland, India, Indonesia, Iran, Iraq, Ireland,
Israel, Italy, Ivory Coast, Jamaica, Japan, Jordan, Kenya, Kiribati,
South Korea, Kuwait, Lebanon, Lesotho, Liberia, Libya, Luxembourg,
Madagascar, Malawi, Malaysia, Maldives, Mali, Mauritania, Mauritius,
Mexico, Morocco, Mozambique, Nepal, Netherlands, NZ, Nicaragua, Niger,
Nigeria, Norway, Oman, Pakistan, Panama, Papua New Guinea, Paraguay,
Peru, Philippines, Portugal, Romania, Rwanda, Saint Lucia, Saudi Arabia,
Senegal, Seychelles, Sierra Leone, Singapore, Solomon Islands, Somalia,
South Africa, Spain, Sri Lanka, Sudan, Swaziland, Sweden, Syria,
Tanzania, Thailand, Togo, Tonga, Trinidad and Tobago, Tunisia, Turkey,
Uganda, UAE, UK, US, Uruguay, Vanuatu, Venezuela, Vietnam, Western Samoa,
Yemen, Yugoslavia, Zaire, Zambia, Zimbabwe
-------------------------------------------------------------------------
_#_International Fund for Agricultural Development (IFAD)
established--NA November 1974;
aim--UN specialized agency that promotes agricultural development;
members--(144);
Category I--(21 industrialized aid contributors) Australia, Austria,
Belgium, Canada, Denmark, Finland, France, Germany, Greece, Ireland,
Italy, Japan, Luxembourg, Netherlands, NZ, Norway, Spain, Sweden,
Switzerland, UK, US;
Category II--(12 petroleum-exporting aid contributors) Algeria, Gabon,
Indonesia, Iran, Iraq, Kuwait, Libya, Nigeria, Qatar, Saudi Arabia, UAE,
Venezuela;
Category III--(111 aid recipients) Afghanistan, Angola,
Antigua and Barbuda, Argentina, Bangladesh, Barbados, Belize, Benin,
Bhutan, Bolivia, Botswana, Brazil, Burkina, Burma, Burundi, Cameroon,
Cape Verde, Central African Republic, Chad, Chile, China, Colombia,
Comoros, Congo, Costa Rica, Cuba, Cyprus, Djibouti, Dominica,
Dominican Republic, Ecuador, Egypt, El Salvador, Equatorial','528c462bd896245b471bdd1446149562c24695760e91dc79abe1256bf9f3c8f2','internet-archive','theciaworldfactb00025gut','txt','84185fe9df79da427349cc1598fd3f69814a2085a9fc1fe0508a3fae0a870f84','https://archive.org/download/theciaworldfactb00025gut/25.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e454a17f518932a16281ae9c56230e5cc861d951d608e024e5945964d50556d1',1991,'ZW','Zimbabwe','communications',22,'Guinea,
Ethiopia, Fiji, The Gambia, Ghana, Grenada, Guatemala, Guinea,
Guinea-Bissau, Guyana, Haiti, Honduras, India, Israel, Ivory Coast,
Jamaica, Jordan, Kenya, North Korea, South Korea, Laos, Lebanon, Lesotho,
Liberia, Madagascar, Malawi, Malaysia, Maldives, Mali, Malta, Mauritania,
Mauritius, Mexico, Morocco, Mozambique, Nepal, Nicaragua, Niger, Oman,
Pakistan, Panama, Papua New Guinea, Paraguay, Peru, Philippines,
Portugal, Romania, Rwanda, Saint Kitts and Nevis, Saint Lucia,
Saint Vincent and the Grenadines, Sao Tome and Principe, Senegal,
Seychelles, Sierra Leone, Solomon Islands, Somalia, Sri Lanka, Sudan,
Suriname, Swaziland, Syria, Tanzania, Thailand, Togo, Tonga,
Trinidad and Tobago, Tunisia, Turkey, Uganda, Uruguay, Vietnam,
Western Samoa, Yemen, Yugoslavia, Zaire, Zambia, Zimbabwe
-------------------------------------------------------------------------
_#_International Investment Bank (IIB)
established--7 July 1970;
aim--to promote economic development;
members--(9) Bulgaria, Cuba, Czechoslovakia, Hungary, Mongolia,
Poland, Romania, USSR, Vietnam
-------------------------------------------------------------------------
_#_International Labor Organization (ILO)
established--11 April 1919 (affiliated with the UN
14 December 1946);
aim--UN specialized agency concerned with world labor issues;
members--(148) all UN members except Albania, Bhutan, Brunei,
The Gambia, Liechtenstein, Maldives, Oman, Saint Kitts and Nevis,
Saint Vincent and the Grenadines, South Africa, Vanuatu, Vietnam,
Western Samoa; other members are San Marino, Switzerland
-------------------------------------------------------------------------
_#_International Maritime Organization (IMO)--name changed from
Intergovernmental Maritime Consultative Organization (IMCO) on
22 May 1982;
established--17 March 1958;
aim--UN specialized agency concerned with world maritime affairs;
members--(132) Algeria, Angola, Antigua and Barbuda, Argentina,
Australia, Austria, The Bahamas, Bahrain, Bangladesh, Barbados, Belgium,
Benin, Bolivia, Brazil, Brunei, Bulgaria, Burma, Cambodia, Cameroon,
Canada, Cape Verde, Chile, China, Colombia, Congo, Costa Rica, Cuba,
Cyprus, Czechoslovakia, Denmark, Djibouti, Dominica, Dominican Republic,
Ecuador, Egypt, El Salvador, Equatorial Guinea, Ethiopia, Fiji, Finland,
France, Gabon, The Gambia, Germany, Ghana, Greece, Guatemala,
Guinea, Guinea-Bissau, Guyana, Haiti, Honduras, Hungary, Iceland, India,
Indonesia, Iran, Iraq, Ireland, Israel, Italy, Ivory Coast, Jamaica,
Japan, Jordan, Kenya, North Korea, South Korea, Kuwait, Lebanon, Liberia,
Libya, Madagascar, Malawi, Malaysia, Maldives, Malta, Mauritania,
Mauritius, Mexico, Monaco, Morocco, Mozambique, Nepal, Netherlands, NZ,
Nicaragua, Nigeria, Norway, Oman, Pakistan, Panama, Papua New Guinea,
Peru, Philippines, Poland, Portugal, Qatar, Romania, Saint Lucia,
Saint Vincent and the Grenadines, Saudi Arabia, Senegal, Seychelles,
Sierra Leone, Singapore, Solomon Islands, Somalia, Spain, Sri Lanka,
Sudan, Suriname, Sweden, Switzerland, Syria, Tanzania, Thailand, Togo,
Trinidad and Tobago, Tunisia, Turkey, UAE, UK, US, USSR, Uruguay,
Vanuatu, Venezuela, Vietnam, Yemen, Yugoslavia, Zaire;
associate member--(1) Hong Kong
-------------------------------------------------------------------------
_#_International Maritime Satellite Organization (INMARSAT)
established--3 September 1976, effective 26 July 1979;
aim--to provide worldwide communications for maritime and other
applications;
members--(55) Algeria, Argentina, Australia, Bahrain, Belgium,
Brazil, Bulgaria, Byelorussian Soviet Socialist Republic, Canada, Chile,
China, Colombia, Czechoslovakia, Denmark, Egypt, Finland, France, Gabon,
Germany, Greece, India, Indonesia, Iran, Iraq, Israel, Italy, Japan,
South Korea, Kuwait, Liberia, Malaysia, Netherlands, NZ, Nigeria, Norway,
Oman, Pakistan, Panama, Peru, Philippines, Poland, Portugal, Qatar, Saudi
Arabia, Singapore, Spain, Sri Lanka, Sweden, Switzerland, Tunisia,
Ukrainian Soviet Socialist Republic, UAE, UK, US, USSR
-------------------------------------------------------------------------
_#_International Monetary Fund (IMF)
established--22 July 1944, effective 27 December 1945;
aim--UN specialized agency concerned with world monetary stability
and economic development;
members--(154) all UN members except Albania, Brunei, Bulgaria,
Byelorussian Soviet Socialist Republic, Cuba, Liechtenstein, Ukrainian
Soviet Socialist Republic, USSR; other members are Kiribati, South Korea,
-------------------------------------------------------------------------
_#_World Meteorological Organization (WMO)
established--11 October 1947, effective 4 April 1951;
aim--specialized UN agency concerned with meteorological
cooperation;
members--(159) all UN members except Bhutan, Equatorial Guinea,
Grenada, Liechtenstein, Namibia, Saint Kitts and Nevis, Saint Vincent
and the Grenadines, Western Samoa; South Africa is included although
WMO membership is suspended; other members are British Caribbean
Territories, French Polynesia, Hong Kong, North Korea, South Korea,
Netherlands Antilles, New Caledonia, Switzerland
-------------------------------------------------------------------------
_#_World Tourism Organization (WTO)
established--2 January 1975;
aim--promote tourism as a means of contributing to economic
development, international understanding, and peace;
members--(104) Afghanistan, Algeria, Angola, Argentina, Australia,
Austria, Bangladesh, Belgium, Benin, Bolivia, Brazil, Bulgaria, Burkina,
Burundi, Cambodia, Cameroon, Canada, Chad, Chile, China, Colombia, Congo,
Cuba, Cyprus, Czechoslovakia, Dominican Republic, Ecuador, Egypt,
Ethiopia, Finland, France, Gabon, The Gambia, Germany, Ghana, Greece,
Grenada, Guinea, Haiti, Hungary, India, Indonesia, Iran, Iraq, Israel,
Italy, Ivory Coast, Jamaica, Japan, Jordan, Kenya, North Korea,
South Korea, Kuwait, Laos, Lebanon, Lesotho, Libya, Madagascar, Malawi,
Maldives, Mali, Malta, Mauritania, Mauritius, Mexico, Mongolia, Morocco,
Nepal, Netherlands, Niger, Nigeria, Pakistan, Panama, Peru, Poland,
Portugal, Romania, Rwanda, San Marino, Sao Tome and Principe, Senegal,
Sierra Leone, Spain, Sri Lanka, Sudan, Switzerland, Syria, Tanzania,
Togo, Tunisia, Turkey, Uganda, UAE, US, USSR, Uruguay, Venezuela,
Vietnam, Yemen, Yugoslavia, Zaire, Zambia, Zimbabwe;
associate members--(4) Aruba, Macau, Netherlands Antilles,
Puerto Rico;
permanent observer--(1) Vatican City
=========================================================================
Appendix D: Weights and Measures
Mathematical Notation
Mathematical Power Name
_________________________________________________________________________
10 +18 or 1,000,000,000,000,000,000 one quintillion
10 +15 or 1,000,000,000,000,000 one quadrillion
10 +12 or 1,000,000,000,000 one trillion
10 +9 or 1,000,000,000 one billion
10 +6 or 1,000,000 one million
10 +3 or 1,000 one thousand
10 +2 or 100 one hundred
10 +1 or 10 ten
10 +0 or 1 one
10 -1 or 0.1 one tenth
10 -2 or 0.01 one hundredth
10 -3 or 0.001 one thousandth
10 -6 or 0.000 001 one millionth
10 -9 or 0.000 000 001 one billionth
10 -12 or 0.000 000 000 001 one trillionth
10 -15 or 0.000 000 000 000 001 one quadrillionth
10 -18 or 0.000 000 000 000 000 001 one quintillionth
=========================================================================
Metric Interrelationships
Conversions from a multiple or submultiple to the basic units of meters,
liters, or grams can be done using the table. For example, to convert
from kilometers to meters, multiply by 1,000 (9.26 kilometers equals
9,260 meters) or to convert from meters to kilometers, multiply by 0.001
(9,260 meters equals 9.26 kilometers)
_________________________________________________________________________
Length,
weight,
Prefix Symbol capacity Area Volume
-------------------------------------------------------------------------
exa E 10 +18 10 +36 10 +54
peta P 10 +15 10 +30 10 +45
tera T 10 +12 10 +24 10 +36
giga G 10 +9 10 +18 10 +27
mega M 10 +6 10 +12 10 +18
hectokilo hk 10 +5 10 +10 10 +15
myria ma 10 +4 10 +8 10 +12
kilo k 10 +3 10 +6 10 +9
hecto h 10 +2 10 +4 10 +6
deka da 10 +1 10 +2 10 +3
basic unit - 1 meter, 1 meter2 1 meter3
1 gram,
1 liter
deci d 10 -1 10 -2 10 -3
centi c 10 -2 10 -4 10 -6
milli m 10 -3 10 -6 10 -9
decimilli dm 10 -4 10 -8 10 -12
centimilli cm 10 -5 10 -10 10 -15
micro u 10 -6 10 -12 10 -18
nano n 10 -9 10 -18 10 -27
pico p 10 -12 10 -24 10 -36
femto f 10 -15 10 -30 10 -45
atto a 10 -18 10 -36 10 -54
========================================================================
EQUIVALENTS
The exponents 2 and 3 are used for square and cubic, respectively.
Unit Metric Equivalent US Equivalent
_________________________________________________________________________
acre 0.404 685 64 hectares 43,560 feet2
acre 4,046,856 4 meters2 4,840 yards2
acre 0.004 046 856 4 0.001 562 5 miles2,
kilometers2 statute
are 100 meters2 119.599 yards2
barrel (petroleum, US) 158.987 29 liters 42 gallons
(proof spirits, US) 151.416 47 liters 40 gallons
(beer, US) 117.347 77 liters 31 gallons
bushel 35.239 07 liters 4 pecks
cable 219.456 meters 120 fathoms
chain (surveyor''s) 20.116 8 meters 66 feet
cord (wood) 3.624 556 meters3 128 feet3
cup 0.236 588 2 liters 8 ounces, liquid (US)
degrees, celsius (water boils at 100 multiply by 1.8 and add
degrees C, freezes at 32 to obtain degrees F
0 degrees C)
degrees, fahrenheit subtract 32 and divide (water boils at 212
by 1.8 to obtain degrees F, freezes at
degrees C 32 degrees F)
dram, avoirdupois 1.771 845 2 grams 0.062 5 ounces, avoirdupois
dram, troy 3.887 934 6 grams 0.125 ounces, troy
dram, liquid (US) 3.696 69 milliliters 0.125 ounces, liquid
fathom 1.828 8 meters 6 feet
foot 30.48 centimeters 12 inches
foot 0.304 8 meters 0.333 333 3 yards
foot 0.000 304 8 kilometers 0.000 189 39 miles, statute
foot2 929.030 4 centimeters2 144 inches2
foot 2 0.092 903 04 meters2 0.111 111 1 yards2
foot3 28.316 846 592 liters 7.480 519 gallons
foot3 0.028 316 847 meters3 1,728 inches3
furlong 201.168 meters 220 yards
gallon, liquid (US) 3.785 411 784 liters 4 quarts, liquid
gill (US) 118.294 118 milliliters 4 ounces, liquid
grain 64.798 91 milligrams 0.002 285 71 ounces, advp.
gram 1,000 milligrams 0.035 273 96 ounces, advp.
hand (height of horse) 10.16 centimeters 4 inches
hectare 10,000 meters2 2.471 053 8 acres
hundredweight, long 50.802 345 kilograms 112 pounds, avoirdupois
hundredweight, short 45.359 237 kilograms 100 pounds, avoirdupois
inch 2.54 centimeters 0.083 333 33 feet
inch2 6.451 6 centimeters2 0.006 944 44 feet2
inch3 16.387 064 centimeters3 0.000 578 7 feet3
inch3 16.387 064 milliliters 0.029 761 6 pints, dry
inch3 16.387 064 milliliters 0.034 632 0 pints, liquid
kilogram 0.001 tons, metric 2.204 623 pounds, avoirdupois
kilometer 1,000 meters 0.621 371 19 miles, statute
kilometer2 100 hectares 247.105 38 acres
kilometer2 1,000,000 meters2 0.386 102 16 miles2, statute
knot (1 nautical mi/hr) 1.852 kilometers/hour 1.151 statute miles/hour
league, nautical 5.559 552 kilometers 3 miles, nautical
league, statute 4.828.032 kilometers 3 miles, statute
link (surveyor''s) 20.116 8 centimeters 7.92 inches
liter 0.001 meters3 61.023 74 inches3
liter 0.1 dekaliter 0.908 083 quarts, dry
liter 1,000 milliliters 1.056 688 quarts, liquid
meter 100 centimeters 1.093 613 yards
meter2 10,000 centimeters2 1.195 990 yards2
meter3 1,000 liters 1.307 951 yards3
micron 0.000 001 meter 0.000 039 4 inches
mil 0.025 4 millimeters 0.001 inch
mile, nautical 1.852 kilometers 1.150 779 4 miles, statute
mile2, nautical 3.429 904 kilometers2 1.325 miles2, statute
mile, statute 1.609 344 kilometers 5,280 feet or 8 furlongs
mile2, statute 258.998 811 hectares 640 acres or 1 section
mile2, statute 2.589 988 11 kilometers2 0.755 miles2, nautical
minim (US) 0.061 611 52 milliliters 0.002 083 33 ounces, liquid
ounce, avoirdupois 28.349 523 125 grams 437.5 grains
ounce, liquid (US) 29.573 53 milliliters 0.062 5 pints, liquid
ounce, troy 31.103 476 8 grams 480 grains
pace 76.2 centimeters 30 inches
peck 8.809 767 5 liters 8 quarts, dry
pennyweight 1.555 173 84 grams 24 grains
pint, dry (US) 0.550 610 47 liters 0.5 quarts, dry
pint, liquid (US) 0.473 176 473 liters 0.5 quarts, liquid
point (typographical) 0.351 459 8 millimeters 0.013 837 inches
pound, avoirdupois 453.592 37 grams 16 ounces, avourdupois
pound, troy 373.241 721 6 grams 12 ounces, troy
quart, dry (US) 1.101 221 liters 2 pints, dry
quart, liquid (US) 0.946 352 946 liters 2 pints, liquid
quintal 100 kilograms 220.462 26 pounds, avdp.
rod 5.029 2 meters 5.5 yards
scruple 1.295 978 2 grams 20 grains
section (US) 2.589 988 1 kilometers2 1 mile2, statute or 640 acres
span 22.86 centimeters 9 inches
stere 1 meter3 1.307 95 yards3
tablespoon 14.786 76 milliliters 3 teaspoons
teaspoon 4.928 922 milliliters 0.333 333 tablespoons
ton, long or deadweight 1,016.046 909 kilograms 2,240 pounds, avoirdupois
ton, metric 1,000 kilograms 2,204.623 pounds, avoirdupois
ton, metric 1,000 kilograms 32,150.75 ounces, troy
ton, register 2.831 684 7 meters3 100 feet3
ton, short 907.184 74 kilograms 2,000 pounds, avoirdupois
township (US) 93.239 572 kilometers2 36 miles2, statute
yard 0.914 4 meters 3 feet
yard2 0.836 127 36 meters2 9 feet2
yard3 0.764 554 86 meters3 27 feet3
yard3 764.554 857 984 liters 201.974 gallons
=========================================================================
Appendix E: Cross-Reference List of Geographic Names
This list indicates where various names including all United States
Foreign Service Posts, alternate names, former names, and political or
geographical portions of larger entities can be found in The World
Factbook. Spellings are not necessarily those approved by the United
States Board on Geographic Names (BGN). Alternate names are included in
parentheses; additional information is included in brackets.
Name Entry in The World Factbook
Abidjan [US Embassy] Ivory Coast
Abu Dhabi [US Embassy] United Arab Emirates
Acapulco [US Consular Agency] Mexico
Accra [US Embassy] Ghana
Adana [US Consulate] Turkey
Addis Ababa [US Embassy] Ethiopia
Adelaide [US Consular Agency] Australia
Adelie Land (Terre Adelie) Antarctica
[claimed by France]
Aden Yemen
Aden, Gulf of Indian Ocean
Admiralty Islands Papua New Guinea
Adriatic Sea Atlantic Ocean
Aegean Islands Greece
Aegean Sea Atlantic Ocean
Afars and Issas, French Djibouti
Territory of the (F.T.A.I.)
Agalega Islands Mauritius
Aland Islands Finland
Alaska United States
Alaska, Gulf of Pacific Ocean
Aldabra Islands Seychelles
Alderney Guernsey
Aleutian Islands United States
Alexander Island Antarctica
Alexandria [US Consulate General] Egypt
Algiers [US Embassy] Algeria
Alhucemas, Penon de Spain
Alphonse Island Seychelles
Amami Strait Pacific Ocean
Amindivi Islands India
Amirante Isles Seychelles
Amman [US Embassy] Jordan
Amsterdam [US Consulate General] Netherlands
Amsterdam Island French Southern and Antarctic Lands
(Ile Amsterdam)
Amundsen Sea Pacific Ocean
Amur China; Soviet Union
Andaman Islands India
Andaman Sea Indian Ocean
Anegada Passage Atlantic Ocean
Anglo-Egyptian Sudan Sudan
Anjouan Comoros
Ankara [US Embassy] Turkey
Annobon Equatorial Guinea
Antananarivo [US Embassy] Madagascar
Antipodes Islands New Zealand
Antwerp [US Consulate General] Belgium
Aozou Strip [claimed by Libya] Chad
Aqaba, Gulf of Indian Ocean
Arabian Sea Indian Ocean
Arafura Sea Pacific Ocean
Argun China; Soviet Union
Ascension Island Saint Helena
Assumption Island Seychelles
Asuncion [US Embassy] Paraguay
Asuncion Island Northern Mariana Islands
Atacama Chile
Athens [US Embassy] Greece
Attu United States
Auckland [US Consulate General] New Zealand
Auckland Islands New Zealand
Australes Iles (Iles Tubuai) French Polynesia
Axel Heiberg Island Canada
Azores Portugal
Azov, Sea of Atlantic Ocean
Bab el Mandeb Indian Ocean
Babuyan Channel Pacific Ocean
Babuyan Islands Philippines
Baffin Bay Arctic Ocean
Baffin Island Canada
Baghdad [US Embassy] Iraq
Balabac Strait Pacific Ocean
Balearic Islands Spain
Balearic Sea (Iberian Sea) Atlantic Ocean
Bali [US Consular Agency] Indonesia
Bali Sea Indian Ocean
Balintang Channel Pacific Ocean
Balintang Islands Philippines
Balleny Islands Antarctica
Balochistan Pakistan
Baltic Sea Atlantic Ocean
Bamako [US Embassy] Mali
Banaba (Ocean Island) Kiribati
Bandar Seri Begawan [US Embassy] Brunei
Banda Sea Pacific Ocean
Bangkok [US Embassy] Thailand
Bangui [US Embassy] Central African Republic
Banjul [US Embassy] Gambia, The
Banks Island Canada
Banks Islands (Iles Banks) Vanuatu
Barcelona [US Consulate General] Spain
Barents Sea Arctic Ocean
Barranquilla [US Consulate] Colombia
Bashi Channel Pacific Ocean
Basilan Strait Pacific Ocean
Bass Strait Indian Ocean
Batan Islands Philippines
Bavaria (Bayern) Germany
Beagle Channel Atlantic Ocean
Bear Island (Bjornoya) Svalbard
Beaufort Sea Arctic Ocean
Bechuanaland Botswana
Beijing [US Embassy] China
Beirut [US Embassy] Lebanon
Belau Pacific Islands, Trust Territory of the
(Palau)
Belem [US Consular Agency] Brazil
Belep Islands (Iles Belep) New Caledonia
Belfast [US Consulate General] United Kingdom
Belgian Congo Zaire
Belgrade [US Embassy] Yugoslavia
Belize City [US Embassy] Belize
Belle Isle, Strait of Atlantic Ocean
Bellinghausen Sea Pacific Ocean
Belmopan Belize
Bengal, Bay of Indian Ocean
Bering Sea Pacific Ocean
Bering Strait Pacific Ocean
Berkner Island Antarctica
Berlin [US Branch Office] Germany
Berlin, East Germany
Berlin, West Germany
Bern [US Embassy] Switzerland
Bessarabia Romania; Soviet Union
Bijagos, Arquipelago dos Guinea-Bissau
Bikini Atoll Marshall Islands
Bilbao [US Consulate] Spain
Bioko Equatorial Guinea
Biscay, Bay of Atlantic Ocean
Bishop Rock United Kingdom
Bismarck Archipelago Papua New Guinea
Bismarck Sea Pacific Ocean
Bissau [US Embassy] Guinea-Bissau
Bjornoya (Bear Island) Svalbard
Black Rock Falkland Islands (Islas Malvinas)
Black Sea Atlantic Ocean
Boa Vista Cape Verde
Bogota [US Embassy] Colombia
Bombay [US Consulate General] India
Bonaire Netherlands Antilles
Bonifacio, Strait of Atlantic Ocean
Bonin Islands Japan
Bonn [US Embassy] Germany
Bophuthatswana South Africa
Bora-Bora French Polynesia
Bordeaux [US Consulate General] France
Borneo Brunei; Indonesia; Malaysia
Bornholm Denmark
Bosporus Atlantic Ocean
Bothnia, Gulf of Atlantic Ocean
Bougainville Island Papua New Guinea
Bougainville Strait Pacific Ocean
Bounty Islands New Zealand
Brasilia [US Embassy] Brazil
Brazzaville [US Embassy] Congo
Bridgetown [US Embassy] Barbados
Brisbane [US Consulate] Australia
British East Africa Kenya
British Guiana Guyana
British Honduras Belize
British Solomon Islands Solomon Islands
British Somaliland Somalia
Brussels [US Embassy, US Mission Belgium
to European Communities, US
Mission to the North Atlantic
Treaty Organization (USNATO)]
Bucharest [US Embassy] Romania
Budapest [US Embassy] Hungary
Buenos Aires [US Embassy] Argentina
Bujumbura [US Embassy] Burundi
Cabinda Angola
Cabot Strait Atlantic Ocean
Caicos Islands Turks and Caicos Islands
Cairo [US Embassy] Egypt
Calcutta [US Consulate General] India
Calgary [US Consulate General] Canada
California, Gulf of Pacific Ocean
Campbell Island New Zealand
Canal Zone Panama
Canary Islands Spain
Canberra [US Embassy] Australia
Cancun [US Consular Agency] Mexico
Canton (Guangzhou) China
Canton Island Kiribati
Cape Town [US Consulate General] South Africa
Caracas [US Embassy] Venezuela
Cargados Carajos Shoals Mauritius
Caroline Islands Micronesia, Federated States of;
Pacific Islands, Trust Territory of the
Caribbean Sea Atlantic Ocean
Carpentaria, Gulf of Pacific Ocean
Casablanca [US Consulate General] Morocco
Cato Island Australia
Cebu [US Consulate] Philippines
Celebes Indonesia
Celebes Sea Pacific Ocean
Celtic Sea Atlantic Ocean
Central African Empire Central African Republic
Ceuta Spain
Ceylon Sri Lanka
Chafarinas, Islas Spain
Chagos Archipelago (Oil Islands) British Indian Ocean Territory
Channel Islands Guernsey; Jersey
Chatham Islands New Zealand
Cheju-do Korea, South
Cheju Strait Pacific Ocean
Chengdu [US Consulate General] China
Chesterfield Islands New Caledonia
(Iles Chesterfield)
Chiang Mai [US Consulate General] Thailand
Chihli, Gulf of (Bo Hai) Pacific Ocean
China, People''s Republic of China
China, Republic of Taiwan
Choiseul Solomon Islands
Christchurch [US Consular Agency] New Zealand
Christmas Island [Indian Ocean] Australia
Christmas Island [Pacific Ocean] Kiribati
(Kiritimati)
Chukchi Sea Arctic Ocean
Ciskei South Africa
Ciudad Juarez [US Consulate Mexico
General]
Cochabamba [US Consular Agency] Bolivia
Coco, Isla del Costa Rica
Cocos Islands Cocos (Keeling) Islands
Colombo [US Embassy] Sri Lanka
Colon [US Consular Agency] Panama
Colon, Archipielago de Ecuador
(Galapagos Islands)
Commander Islands Soviet Union
(Komandorskiye Ostrova)
Conakry [US Embassy] Guinea
Congo (Brazzaville) Congo
Congo (Kinshasa) Zaire
Congo (Leopoldville) Zaire
Con Son Islands Vietnam
Cook Strait Pacific Ocean
Copenhagen [US Embassy] Denmark
Coral Sea Pacific Ocean
Corn Islands (Islas del Maiz) Nicaragua
Corsica France
Cosmoledo Group Seychelles
Cote d''Ivoire Ivory Coast
Cotonou [US Embassy] Benin
Crete Greece
Crooked Island Passage Atlantic Ocean
Crozet Islands (Iles Crozet) French Southern and Antarctic Lands
Curacao [US Consulate General] Netherlands Antilles
Cusco [US Consular Agency] Peru
Dahomey Benin
Daito Islands Japan
Dakar [US Embassy] Senegal
Daman (Damao) India
Damascus [US Embassy] Syria
Danger Atoll Cook Islands
Danish Straits Atlantic Ocean
Danzig (Gdansk) Poland
Dao Bach Long Vi Vietnam
Dardanelles Atlantic Ocean
Dar es Salaam [US Embassy] Tanzania
Davis Strait Atlantic Ocean
Deception Island Antarctica
Denmark Strait Atlantic Ocean
D''Entrecasteaux Islands Papua New Guinea
Devon Island Canada
Dhahran [US Consulate General] Saudi Arabia
Dhaka [US Embassy] Bangladesh
Diego Garcia British Indian Ocean Territory
Diego Ramirez Chile
Diomede Islands Soviet Union [Big Diomede]; United States
[Little Diomede]
Diu India
Djibouti [US Embassy] Djibouti
Dodecanese Greece
Doha [US Embassy] Qatar
Douala [US Consulate General] Cameroon
Dover, Strait of Atlantic Ocean
Drake Passage Atlantic Ocean
Dubai [US Consulate General] United Arab Emirates
Dublin [US Embassy] Ireland
Durango [US Consular Agency] Mexico
Durban [US Consulate General] South Africa
Dusseldorf [US Consulate General] Germany
Dutch East Indies Indonesia
Dutch Guiana Suriname
East China Sea Pacific Ocean
Easter Island (Isla de Pascua) Chile
Eastern Channel (East Korea Pacific Ocean
Strait or Tsushima Strait)
East Germany (German Democratic Germany
Republic)
East Korea Strait (Eastern Pacific Ocean
Channel or Tsushima Strait)
East Pakistan Bangladesh
East Siberian Sea Arctic Ocean
East Timor (Portuguese Timor) Indonesia
Edinburgh [US Consulate General] United Kingdom
Elba Italy
Ellef Ringnes Island Canada
Ellesmere Island Canada
Ellice Islands Tuvalu
Elobey, Islas de Equatorial Guinea
Enderbury Island Kiribati
Enewetak Atoll (Eniwetok Atoll) Marshall Islands
England United Kingdom
English Channel Atlantic Ocean
Eniwetok Atoll Marshall Islands
Epirus, Northern Albania; Greece
Eritrea Ethiopia
Essequibo [claimed by Venezuela] Guyana
Estonia Soviet Union [de facto]
Etorofu Soviet Union [de facto]
Farquhar Group Seychelles
Fernando de Noronha Brazil
Fernando Po (Bioko) Equatorial Guinea
Finland, Gulf of Atlantic Ocean
Florence [US Consulate General] Italy
Florida, Straits of Atlantic Ocean
Formosa Taiwan
Formosa Strait (Taiwan Strait) Pacific Ocean
Fort-de-France Martinique
[US Consulate General]
Frankfurt am Main Germany
[US Consulate General]
Franz Josef Land Soviet Union
Freetown [US Embassy] Sierra Leone
French Cameroon Cameroon
French Indochina Cambodia; Laos; Vietnam
French Guinea Guinea
French Sudan Mali
French Territory of the Afars Djibouti
and Issas (F.T.A.I.)
French Togo Togo
Friendly Islands Tonga
Fukuoka [US Consulate] Japan
Funchal [US Consular Agency] Portugal
Fundy, Bay of Atlantic Ocean
Futuna Islands (Hoorn Islands) Wallis and Futuna','585288b7118c7a5432d2df50215666a3674272d017aeb05f4c65ecd8d744da56','internet-archive','theciaworldfactb00025gut','txt','84185fe9df79da427349cc1598fd3f69814a2085a9fc1fe0508a3fae0a870f84','https://archive.org/download/theciaworldfactb00025gut/25.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('195b4ba26dd418bccc32ff8f9c84bb1d4ca94d9d4ce4980023404f418293aacd',1991,'ZW','Zimbabwe','communications',23,'Gaborone [US Embassy] Botswana
Galapagos Islands (Archipi%elago Ecuador
de Colon)
Galleons Passage Atlantic Ocean
Gambier Islands (Iles Gambier) French Polynesia
Gaspar Strait Indian Ocean
Geneva [Branch Office of the US Switzerland
Embassy, US Mission to European
Office of the UN and Other
International Organizations]
Genoa [US Consulate General] Italy
George Town [US Consular Agency] Cayman Islands
Georgetown [US Embassy] Guyana
German Democratic Republic Germany
(East Germany)
German Federal Republic of Germany
(West Germany)
Gibraltar, Strait of Atlantic Ocean
Gilbert Islands Kiribati
Goa India
Gold Coast Ghana
Golan Heights Syria
Good Hope, Cape of South Africa
Goteborg [US Consulate General] Sweden
Gotland Sweden
Gough Island Saint Helena
Grand Banks Atlantic Ocean
Grand Cayman Cayman Islands
Grand Turk [US Consular Agency] Turks and Caicos Islands
Great Australian Bight Indian Ocean
Great Belt (Store Baelt) Atlantic Ocean
Great Britain United Kingdom
Great Channel Indian Ocean
Greater Sunda Islands Brunei; Indonesia; Malaysia
Green Islands Papua New Guinea
Greenland Sea Arctic Ocean
Grenadines, Northern Saint Vincent and the Grenadines
Grenadines, Southern Grenada
Guadalajara Mexico
[US Consulate General]
Guadalcanal Solomon Islands
Guadalupe, Isla de Mexico
Guangzhou [US Consulate General] China
Guantanamo [US Naval Base] Cuba
Guatemala [US Embassy] Guatemala
Gubal, Strait of Indian Ocean
Guinea, Gulf of Atlantic Ocean
Guayaquil [US Consulate General] Ecuador
Ha''apai Group Tonga
Habomai Islands Soviet Union [de facto]
Hague,The [US Embassy] Netherlands
Haifa [US Consular Agency] Israel
Hainan Dao China
Halifax [US Consulate General] Canada
Halmahera Indonesia
Hamburg [US Consulate General] Germany
Hamilton [US Consulate General] Bermuda
Hanoi Vietnam
Harare [US Embassy] Zimbabwe
Hatay Turkey
Havana [US post not maintained, Cuba
representation by US Interests
Section (USINT) of the Swiss
Embassy]
Hawaii United States
Heard Island Heard Island and McDonald Islands
Helsinki [US Embassy] Finland
Hermosillo [US Consulate] Mexico
Hispaniola Dominican Republic; Haiti
Hokkaido Japan
Holy See, The Vatican City
Hong Kong [US Consulate General] Hong Kong
Honiara [US Consulate] Solomon Islands
Honshu Japan
Hormuz, Strait of Indian Ocean
Horn, Cape (Cabo de Hornos) Chile
Horne, Iles de Wallis and Futuna
Horn of Africa Ethiopia; Somalia
Hudson Bay Arctic Ocean
Hudson Strait Arctic Ocean
Inaccessible Island Saint Helena
Indochina Cambodia; Laos; Vietnam
Inner Mongolia (Nei Mongol) China
Ionian Islands Greece
Ionian Sea Atlantic Ocean
Irian Jaya Indonesia
Irish Sea Atlantic Ocean
Islamabad [US Embassy] Pakistan
Islas Malvinas Falkland Islands (Islas Malvinas)
Istanbul [US Consulate General] Turkey
Italian Somaliland Somalia
Iwo Jima Japan
Izmir [US Consulate General] Turkey
Jakarta [US Embassy] Indonesia
Japan, Sea of Pacific Ocean
Java Indonesia
Java Sea Indian Ocean
Jeddah [US Consulate General] Saudi Arabia
Jerusalem [US Consulate General] Israel; West Bank
Johannesburg South Africa
[US Consulate General]
Juan de Fuca, Strait of Pacific Ocean
Juan Fernandez, Isla de Chile
Juventud, Isla de la Cuba
(Isle of Youth)
Kabul [US Embassy now closed] Afghanistan
Kaduna [US Consulate General] Nigeria
Kalimantan Indonesia
Kamchatka Peninsula Soviet Union
(Poluostrov Kamchatka)
Kampala [US Embassy] Uganda
Kampuchea Cambodia
Karachi [US Consulate General] Pakistan
Kara Sea Arctic Ocean
Karimata Strait Indian Ocean
Kathmandu [US Embassy] Nepal
Kattegat Atlantic Ocean
Kauai Channel Pacific Ocean
Keeling Islands Cocos (Keeling) Islands
Kerguelen, Iles French Southern and Antarctic Lands
Kermadec Islands New Zealand
Khabarovsk Soviet Union
Khartoum [US Embassy] Sudan
Khmer Republic Cambodia
Kiel Canal (Nord-Ostsee Kanal) Atlantic Ocean
Khuriya Muriya Islands Oman
(Kuria Muria Islands)
Khyber Pass Pakistan
Kigali [US Embassy] Rwanda
Kingston [US Embassy] Jamaica
Kinshasa [US Embassy] Zaire
Kiritimati (Christmas Island) Kiribati
Kithira Strait Atlantic Ocean
Kodiak Island United States
Kola Peninsula Soviet Union
(Kol''skiy Poluostrov)
Kolonia [US Special Office] Micronesia, Federated States of
Korea Bay Pacific Ocean
Korea, Democratic People''s Korea, North
Republic of
Korea, Republic of Korea, South
Korea Strait Pacific Ocean
Koror [US Special Office] Pacific Islands, Trust Territory of
Kosovo Yugoslavia
Kowloon Hong Kong
Krakow [US Consulate] Poland
Kuala Lumpur [US Embassy] Malaysia
Kunashiri (Kunashir) Soviet Union [de facto]
Kuril Islands Soviet Union [de facto]
Kuwait [US Embassy] Kuwait
Kwajalein Atoll Marshall Islands
Kyushu Japan
Labrador Canada
Laccadive Islands India
Laccadive Sea Indian Ocean
La Coruna [US Consular Agency] Spain
Lagos [US Embassy] Nigeria
Lahore [US Consulate General] Pakistan
Lakshadweep India
La Paz [US Embassy] Bolivia
La Perouse Strait Pacific Ocean
Laptev Sea Arctic Ocean
Las Palmas [US Consular Agency] Spain
Latvia Soviet Union [de facto]
Lau Group Fiji
Leningrad [US Consulate General] Soviet Union
Lesser Sunda Islands Indonesia
Leyte Philippines
Liancourt Rocks [claimed by Japan]Korea, South
Libreville [US Embassy] Gabon
Ligurian Sea Atlantic Ocean
Lilongwe [US Embassy] Malawi
Lima [US Embassy] Peru
Lincoln Sea Arctic Ocean
Line Islands Kiribati; Palmyra Atoll
Lisbon [US Embassy] Portugal
Lithuania Soviet Union [de facto]
Lombok Strait Indian Ocean
Lome [US Embassy] Togo
London [US Embassy] United Kingdom
Lord Howe Island Australia
Louisiade Archipelago Papua New Guinea
Loyalty Islands New Caledonia
(Iles Loyaute)
Lubumbashi [US Consulate General] Zaire
Lusaka [US Embassy] Zambia
Luxembourg [US Embassy] Luxembourg
Luzon Philippines
Luzon Strait Pacific Ocean
Lyon [US Consulate General] France
Macao Macau
Macedonia Bulgaria; Greece; Yugoslavia
Macquarie Island Australia
Madeira Islands Portugal
Madras [US Consulate General] India
Madrid [US Embassy] Spain
Magellan, Strait of Atlantic Ocean
Mahe Island Seychelles
Maiz, Islas del (Corn Islands) Nicaragua
Majorca (Mallorca) Spain
Majuro [US Special Office] Marshall Islands
Makassar Strait Pacific Ocean
Malabo [US Embassy] Equatorial Guinea
Malacca, Strait of Indian Ocean
Malaga [US Consular Agency] Spain
Malagasy Republic Madagascar
Male [US post not maintained, Maldives
representation from Colombo,
Sri Lanka]
Mallorca (Majorca) Spain
Malpelo, Isla de Colombia
Malta Channel Atlantic Ocean
Malvinas, Islas Falkland Islands (Islas Malvinas)
Managua [US Embassy] Nicaragua
Manama [US Embassy] Bahrain
Manaus [US Consular Agency] Brazil
Manchukuo China
Manchuria China
Manila [US Embassy] Philippines
Manipa Strait Pacific Ocean
Mannar, Gulf of Indian Ocean
Manua Islands American Samoa
Maputo [US Embassy] Mozambique
Maracaibo [US Consulate] Venezuela
Marcus Island (Minami-tori-shima) Japan
Mariana Islands Guam; Northern Mariana Islands
Marion Island South Africa
Marmara, Sea of Atlantic Ocean
Marquesas Islands French Polynesia
(Iles Marquises)
Marseille [US Consulate General] France
Martin Vaz, Ilhas Brazil
Mas a Tierra Chile
(Robinson Crusoe Island)
Mascarene Islands Mauritius; Reunion
Maseru [US Embassy] Lesotho
Matamoros [US Consulate] Mexico
Mazatlan [US Consulate] Mexico
Mbabane [US Embassy] Swaziland
McDonald Islands Heard Island and McDonald Islands
Medan [US Consulate] Indonesia
Mediterranean Sea Atlantic Ocean
Melbourne [US Consulate General] Australia
Melilla Spain
Merida [US Consulate] Mexico
Messina, Strait of Atlantic Ocean
Mexico [US Embassy] Mexico
Mexico, Gulf of Atlantic Ocean
Milan [US Consulate General] Italy
Minami-tori-shima Japan
Mindanao Philippines
Mindoro Strait Pacific Ocean
Minicoy Island India
Mogadishu [US Embassy] Somalia
Mombasa [US Consulate] Kenya
Mona Passage Atlantic Ocean
Monrovia [US Embassy] Liberia
Montego Bay [US Consular Agency] Jamaica
Monterrey [US Consulate General] Mexico
Montevideo [US Embassy] Uruguay
Montreal [US Consulate General, Canada
US Mission to the International
Civil Aviation Organization
(ICAO)]
Moravian Gate Czechoslovakia
Moroni [US Embassy] Comoros
Mortlock Islands Micronesia, Federated States of
Moscow [US Embassy] Soviet Union
Mozambique Channel Indian Ocean
Mulege [US Consular Agency] Mexico
Munich [US Consulate General] Germany
Musandam Peninsula Oman; United Arab Emirates
Muscat [US Embassy] Oman
Muscat and Oman Oman
Myanma, Myanmar Burma
Naha [US Consulate General] Japan
Nairobi [US Embassy] Kenya
Nampo-shoto Japan
Naples [US Consulate General] Italy
Nassau [US Embassy] Bahamas, The
Natuna Besar Islands Indonesia
N''Djamena [US Embassy] Chad
Netherlands East Indies Indonesia
Netherlands Guiana Suriname
Nevis Saint Kitts and Nevis
New Delhi [US Embassy] India
Newfoundland Canada
New Guinea Indonesia; Papua New Guinea
New Hebrides Vanuatu
New Siberian Islands Soviet Union
New Territories Hong Kong
New York, New York [US Mission United States
to the United Nations (USUN)]
Niamey [US Embassy] Niger
Nice [US Consular Agency] France
Nicobar Islands India
Nicosia [US Embassy] Cyprus
Nightingale Island Saint Helena
North Atlantic Ocean Atlantic Ocean
North Channel Atlantic Ocean
Northeast Providence Channel Atlantic Ocean
Northern Epirus Albania; Greece
Northern Grenadines Saint Vincent and the Grenadines
Northern Ireland United Kingdom
Northern Rhodesia Zambia
North Island New Zealand
North Korea Korea, North
North Pacific Ocean Pacific Ocean
North Sea Atlantic Ocean
North Vietnam Vietnam
Northwest Passages Arctic Ocean
North Yemen (Yemen Arab Republic) Yemen
Norwegian Sea Atlantic Ocean
Nouakchott [US Embassy] Mauritania
Novaya Zemlya Soviet Union
Nuevo Laredo [US Consulate] Mexico
Nyasaland Malawi
Oahu United States
Oaxaca [US Consular Agency] Mexico
Ocean Island (Banaba) Kiribati
Ocean Island (Kure Island) United States
Ogaden Ethiopia; Somalia
Oil Islands (Chagos Archipelago) British Indian Ocean Territory
Okhotsk, Sea of Pacific Ocean
Okinawa Japan
Oman, Gulf of Indian Ocean
Ombai Strait Pacific Ocean
Oporto [US Consulate] Portugal
Oran [US Consulate] Algeria
Oresund (The Sound) Atlantic Ocean
Orkney Islands United Kingdom
Osaka-Kobe [US Consulate General] Japan
Oslo [US Embassy] Norway
Otranto, Strait of Atlantic Ocean
Ottawa [US Embassy] Canada
Ouagadougou [US Embassy] Burkina
Outer Mongolia Mongolia
Pagan Northern Mariana Islands
Palau Pacific Islands, Trust Territory of the
Palawan Philippines
Palermo [US Consulate General] Italy
Palk Strait Indian Ocean
Palma de Mallorca Spain
[US Consular Agency]
Pamirs China; Soviet Union
Panama [US Embassy] Panama
Panama Canal Panama
Panama, Gulf of Pacific Ocean
Paramaribo [US Embassy] Suriname
Parece Vela Japan
Paris [US Embassy, US Mission to France
the Organization for Economic
Cooperation and Development
(OECD), US Observer Mission at
the UN Educational, Scientific,
and Cultural Organization
(UNESCO)]
Pascua, Isla de (Easter Island) Chile
Passion, Ile de la Clipperton Island
Pashtunistan Afghanistan; Pakistan
Peking (Beijing) China
Pemba Island Tanzania
Pentland Firth Atlantic Ocean
Perim Yemen
Perouse Strait, La Pacific Ocean
Persian Gulf Indian Ocean
Perth [US Consulate] Australia
Pescadores Taiwan
Peshawar [US Consulate] Pakistan
Peter I Island Antarctica
Philip Island Norfolk Island
Philippine Sea Pacific Ocean
Phoenix Islands Kiribati
Pines, Isle of Cuba
(Isla de la Juventud)
Piura [US Consular Agency] Peru
Pleasant Island Nauru
Ponape (Pohnpei) Micronesia
Ponta Delgada [US Consulate] Portugal
Port-au-Prince [US Embassy] Haiti
Port Louis [US Embassy] Mauritius
Port Moresby [US Embassy] Papua New Guinea
Porto Alegre [US Consulate] Brazil
Port-of-Spain [US Embassy] Trinidad and Tobago
Port Said [US Consular Agency] Egypt
Portuguese Guinea Guinea-Bissau
Portuguese Timor (East Timor) Indonesia
Poznan [US Consulate] Poland
Prague [US Embassy] Czechoslovakia
Praia [US Embassy] Cape Verde
Pretoria [US Embassy] South Africa
Pribilof Islands United States
Prince Edward Island Canada
Prince Edward Islands South Africa
Prince Patrick Island Canada
Principe Sao Tome and Principe
Puerto Plata [US Consular Agency] Dominican Republic
Puerto Vallarta Mexico
[US Consular Agency]
Pusan [US Consulate] South Korea
P''yongyang Korea, North
Quebec [US Consulate General] Canada
Queen Charlotte Islands Canada
Queen Elizabeth Islands Canada
Queen Maud Land Antarctica
[claimed by Norway]
Quito [US Embassy] Ecuador
Rabat [US Embassy] Morocco
Ralik Chain Marshall Islands
Rangoon [US Embassy] Burma
Ratak Chain Marshall Islands
Recife [US Consulate] Brazil
Redonda Antigua and Barbuda
Red Sea Indian Ocean
Revillagigedo Island United States
Revillagigedo Islands Mexico
Reykjavik [US Embassy] Iceland
Rhodes Greece
Rhodesia Zimbabwe
Rhodesia, Northern Zambia
Rhodesia, Southern Zimbabwe
Rio de Janeiro Brazil
[US Consulate General]
Rio de Oro Western Sahara
Rio Muni Equatorial Guinea
Riyadh [US Embassy] Saudi Arabia
Robinson Crusoe Island Chile
(Mas a Tierra)
Rocas, Atol das Brazil
Rockall [disputed] United Kingdom
Rodrigues Mauritius
Rome [US Embassy, US Mission to Italy
the UN Agencies for Food and
Agriculture (FODAG)]
Roncador Cay Colombia
Roosevelt Island Antarctica
Ross Dependency Antarctica
[claimed by New Zealand]
Ross Island Antarctica
Ross Sea Antarctica
Rota Northern Mariana Islands
Rotuma Fiji
Ryukyu Islands Japan
Saba Netherlands Antilles
Sabah Malaysia
Sable Island Canada
Sahel Burkina; Cape Verde; Chad; The Gambia;
Guinea-Bissau; Mali; Mauritania;
Niger; Senegal
Saigon (Ho Chi Minh City) Vietnam
Saint Brandon Mauritius
Saint Christopher and Nevis Saint Kitts and Nevis
Saint George''s [US Embassy] Grenada
Saint George''s Channel Atlantic Ocean
Saint John''s [US Embassy] Antigua and Barbuda
Saint Lawrence, Gulf of Atlantic Ocean
Saint Lawrence Island United States
Saint Lawrence Seaway Atlantic Ocean
Saint Martin Guadeloupe
Saint Martin (Sint Maarten) Netherlands Antilles
Saint Paul Island Canada
Saint Paul Island United States
Saint Paul Island French Southern and Antarctic Lands
(Ile Saint-Paul)
Saint Peter and Saint Paul Rocks Brazil
(Penedos de Sao Pedro e
Sao Paulo)
Saint Vincent Passage Atlantic Ocean
Saipan Northern Mariana Islands
Sakhalin Island (Ostrov Sakhalin) Soviet Union
Sala y Gomez, Isla Chile
Salisbury (Harare) Zimbabwe
Salvador de Bahia Brazil
[US Consular Agency]
Salzburg [US Consulate General] Austria
Sanaa [US Embassy] Yemen
San Ambrosio Chile
San Andres y Providencia, Colombia
Archipielago
San Bernardino Strait Pacific Ocean
San Felix, Isla Chile
San Jose [US Embassy] Costa Rica
San Luis Potosi Mexico
[US Consular Agency]
San Miguel Allende Mexico
[US Consular Agency]
San Salvador [US Embassy] El Salvador
Santa Cruz [US Consular Agency] Bolivia
Santa Cruz Islands Solomon Islands
Santiago [US Embassy] Chile
Santo Domingo [US Embassy] Dominican Republic
Sao Luis [US Consular Agency] Brazil
Sao Paulo [US Consulate General] Brazil
Sao Pedro e Sao Paulo, Brazil
Penedos de
Sapporo [US Consulate General] Japan
Sapudi Strait Indian Ocean
Sarawak Malaysia
Sardinia Italy
Sargasso Sea Atlantic Ocean
Sark Guernsey
Scotia Sea Atlantic Ocean
Scotland United Kingdom
Scott Island Antarctica
Senyavin Islands Micronesia, Federated States of
Seoul [US Embassy] Korea, South
Serrana Bank Colombia
Serranilla Bank Colombia
Severnaya Zemlya (Northland) Soviet Union
Seville [US Consular Agency] Spain
Shag Island Heard Island and McDonald Islands
Shag Rocks Falkland Islands (Islas Malvinas)
Shanghai [US Consulate General] China
Shenyang [US Consulate General] China
Shetland Islands United Kingdom
Shikoku Japan
Shikotan (Shikotan-to) Japan
Siam Thailand
Sibutu Passage Pacific Ocean
Sicily Italy
Sicily, Strait of Atlantic Ocean
Sikkim India
Sinai Egypt
Singapore [US Embassy] Singapore
Singapore Strait Pacific Ocean
Sinkiang (Xinjiang) China
Sint Eustatius Netherlands Antilles
Sint Maarten (Saint Martin) Netherlands Antilles
Skagerrak Atlantic Ocean
Slovakia Czechoslovakia
Society Islands French Polynesia
(Iles de la Societe)
Socotra Yemen
Sofia [US Embassy] Bulgaria
Solomon Islands, northern Papua New Guinea
Solomon Islands, southern Solomon Islands
Soloman Sea Pacific Ocean
Songkhla [US Consulate] Thailand
Sound, The (Oresund) Atlantic Ocean
South Atlantic Ocean Atlantic Ocean
South China Sea Pacific Ocean
Southern Grenadines Grenada
Southern Rhodesia Zimbabwe
South Georgia South Georgia and the South
Sandwich Islands
South Island New Zealand
South Korea Korea, South
South Orkney Islands Antarctica
South Pacific Ocean Pacific Ocean
South Sandwich Islands South Georgia and the South
Sandwich Islands
South Shetland Islands Antarctica
South Tyrol Italy
South Vietnam Vietnam
South-West Africa Namibia
South Yemen (People''s Democratic Yemen
Republic of Yemen)
Spanish Guinea Equatorial Guinea
Spanish Sahara Western Sahara
Spitsbergen Svalbard
Stockholm [US Embassy] Sweden
Strasbourg [US Consulate General] France
Stuttgart [US Consulate General] Germany
Suez, Gulf of Indian Ocean
Sulu Archipelago Philippines
Sulu Sea Pacific Ocean
Sumatra Indonesia
Sumba Indonesia
Sunda Islands (Soenda Isles) Indonesia; Malaysia
Sunda Strait Indian Ocean
Surabaya [US Consulate] Indonesia
Surigao Strait Pacific Ocean
Surinam Suriname
Suva [US Embassy] Fiji
Swains Island American Samoa
Swan Islands Honduras
Sydney [US Consulate General] Australia
Tahiti French Polynesia
Taipei Taiwan
Taiwan Strait Pacific Ocean
Tampico [US Consular Agency] Mexico
Tanganyika Tanzania
Tangier [US Consulate General] Morocco
Tarawa Kiribati
Tartar Strait Pacific Ocean
Tasmania Australia
Tasman Sea Pacific Ocean
Taymyr Peninsula Soviet Union
(Poluostrov Taymyra)
Tegucigalpa [US Embassy] Honduras
Tehran [US post not maintained, Iran
representation by Swiss Embassy]
Tel Aviv [US Embassy] Israel
Terre Adelie (Adelie Land) Antarctica
[claimed by France]
Thailand, Gulf of Pacific Ocean
Thessaloniki Greece
[US Consulate General]
Thurston Island Antarctica
Tibet (Xizang) China
Tierra del Fuego Argentina; Chile
Tijuana [US Consulate General] Mexico
Timor Indonesia
Timor Sea Indian Ocean
Tinian Northern Mariana Islands
Tiran, Strait of Indian Ocean
Tobago Trinidad and Tobago
Tokyo [US Embassy] Japan
Tonkin, Gulf of Pacific Ocean
Toronto [US Consulate General] Canada
Torres Strait Pacific Ocean
Trans-Jordan Jordan
Transkei South Africa
Transylvania Romania
Trieste [US Consular Agency] Italy
Trindade, Ilha de Brazil
Tripoli [US post not maintained, Libya
representation by Belgian
Embassy]
Tristan da Cunha Group Saint Helena
Trobriand Islands Papua New Guinea
Trucial States United Arab Emirates
Truk Islands Micronesia
Tsugaru Strait Pacific Ocean
Tuamotu Islands (Iles Tuamotu) French Polynesia
Tubuai Islands (Iles Tubuai) French Polynesia
Tunis [US Embassy] Tunisia
Turin [US Consulate] Italy
Turkish Straits Atlantic Ocean
Turks Island Passage Atlantic Ocean
Tyrol, South Italy
Tyrrhenian Sea Atlantic Ocean
Udorn [US Consulate] Thailand
Ulaanbaatar Mongolia
Ullung-do Korea, South
Unimak Pass [strait] Pacific Ocean
United Arab Republic Egypt; Syria
Upper Volta Burkina
Vaduz [US post not maintained, Liechtenstein
representation from Zurich,
Switzerland]
Vakhan Corridor Afghanistan
(Wakhan)
Valencia [US Consular Agency] Spain
Valletta [US Embassy] Malta
Vancouver [US Consulate General] Canada
Vancouver Island Canada
Van Diemen Strait Pacific Ocean
Vatican City [US Embassy] Vatican City
Velez de la Gomera, Penon deSpain
Venda South Africa
Veracruz [US Consular Agency] Mexico
Verde Island Passage Pacific Ocean
Victoria [US Embassy] Seychelles
Vienna [US Embassy, US Mission Austria
to International Organizations
in Vienna (UNVIE)]
Vientiane [US Embassy] Laos
Volcano Islands Japan
Vostok Island Kiribati
Vrangelya, Ostrov Soviet Union
(Wrangel Island)
Wakhan Corridor Afghanistan
(now Vakhan Corridor)
Wales United Kingdom
Walvis Bay South Africa
Warsaw [US Embassy] Poland
Washington, DC [The Permanent United States
Mission of the USA to the
Organization of American
States (OAS)]
Weddell Sea Atlantic Ocean
Wellington [US Embassy] New Zealand
Western Channel Pacific Ocean
(West Korea Strait)
West Germany (Federal Republic Germany
of Germany)
West Korea Strait Pacific Ocean
(Western Channel)
West Pakistan Pakistan
Wetar Strait Pacific Ocean
White Sea Arctic Ocean
Windhoek Namibia
Windward Passage Atlantic Ocean
Winnipeg [US Consular Agency] Canada
Wrangel Island (Ostrov Vrangelya) Soviet Union
Yaounde [US Embassy] Cameroon
Yap Islands Micronesia
Yellow Sea Pacific Ocean
Yemen (Aden) [People''s Democratic
Republic of Yemen]
Yemen Arab Republic Yemen
Yemen, North [Yemen Arab Yemen
Republic]
Yemen (Sanaa) [Yemen Arab Yemen
Republic]
Yemen, People''s Democratic Yemen
Republic of
Yemen, South [People''s Democratic Yemen
Republic of Yemen]
Youth, Isle of Cuba
(Isla de la Juventud)
Yucatan Channel Atlantic Ocean
Zagreb [US Consulate General] Yugoslavia
Zanzibar Tanzania
Zurich [US Consulate General] Switzerland
End of the Project Gutenberg EBook of The 1991 CIA World Factbook, by
United States. Central Intelligence Agency.
*** END OF THIS PROJECT GUTENBERG EBOOK THE 1991 CIA WORLD FACTBOOK ***
***** This file should be named 25.txt or 25.zip *****
This and all associated files of various formats will be found in:
http://www.gutenberg.org/2/25/
Produced by Dr. Gregory B. Newby
Updated editions will replace the previous one--the old editions
will be renamed.
Creating the works from public domain print editions means that no
one owns a United States copyright in these works, so the Foundation
(and you!) can copy and distribute it in the United States without
permission and without paying copyright royalties. Special rules,
set forth in the General Terms of Use part of this license, apply to
copying and distributing Project Gutenberg-tm electronic works to
protect the PROJECT GUTENBERG-tm concept and trademark. Project
Gutenberg is a registered trademark, and may not be used if you
charge for the eBooks, unless you receive specific permission. If you
do not charge anything for copies of this eBook, complying with the
rules is very easy. You may use this eBook for nearly any purpose
such as creation of derivative works, reports, performances and
research. They may be modified and printed and given away--you may do
practically ANYTHING with public domain eBooks. Redistribution is
subject to the trademark license, especially commercial
redistribution.
*** START: FULL LICENSE ***
THE FULL PROJECT GUTENBERG LICENSE
PLEASE READ THIS BEFORE YOU DISTRIBUTE OR USE THIS WORK
To protect the Project Gutenberg-tm mission of promoting the free
distribution of electronic works, by using or distributing this work
(or any other work associated in any way with the phrase "Project
Gutenberg"), you agree to comply with all the terms of the Full Project
Gutenberg-tm License (available with this file or online at
http://gutenberg.net/license).
Section 1. General Terms of Use and Redistributing Project Gutenberg-tm
electronic works
1.A. By reading or using any part of this Project Gutenberg-tm
electronic work, you indicate that you have read, understand, agree to
and accept all the terms of this license and intellectual property
(trademark/copyright) agreement. If you do not agree to abide by all
the terms of this agreement, you must cease using and return or destroy
all copies of Project Gutenberg-tm electronic works in your possession.
If you paid a fee for obtaining a copy of or access to a Project
Gutenberg-tm electronic work and you do not agree to be bound by the
terms of this agreement, you may obtain a refund from the person or
entity to whom you paid the fee as set forth in paragraph 1.E.8.
1.B. "Project Gutenberg" is a registered trademark. It may only be
used on or associated in any way with an electronic work by people who
agree to be bound by the terms of this agreement. There are a few
things that you can do with most Project Gutenberg-tm electronic works
even without complying with the full terms of this agreement. See
paragraph 1.C below. There are a lot of things you can do with Project
Gutenberg-tm electronic works if you follow the terms of this agreement
and help preserve free future access to','60c43f78dc703a767bf81349ab0cb064c9cffb0bed8e60decbb825793fe924f5','internet-archive','theciaworldfactb00025gut','txt','84185fe9df79da427349cc1598fd3f69814a2085a9fc1fe0508a3fae0a870f84','https://archive.org/download/theciaworldfactb00025gut/25.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b8d994b9b3eaf1e2c0af9d9008a6da719f40dc409fcadb70824f31ad27ec1f78',1991,'ZW','Zimbabwe','communications',24,'Project Gutenberg-tm electronic
works. See paragraph 1.E below.
1.C. The Project Gutenberg Literary Archive Foundation ("the Foundation"
or PGLAF), owns a compilation copyright in the collection of Project
Gutenberg-tm electronic works. Nearly all the individual works in the
collection are in the public domain in the United States. If an
individual work is in the public domain in the United States and you are
located in the United States, we do not claim a right to prevent you from
copying, distributing, performing, displaying or creating derivative
works based on the work as long as all references to Project Gutenberg
are removed. Of course, we hope that you will support the Project
Gutenberg-tm mission of promoting free access to electronic works by
freely sharing Project Gutenberg-tm works in compliance with the terms of
this agreement for keeping the Project Gutenberg-tm name associated with
the work. You can easily comply with the terms of this agreement by
keeping this work in the same format with its attached full Project
Gutenberg-tm License when you share it without charge with others.
1.D. The copyright laws of the place where you are located also govern
what you can do with this work. Copyright laws in most countries are in
a constant state of change. If you are outside the United States, check
the laws of your country in addition to the terms of this agreement
before downloading, copying, displaying, performing, distributing or
creating derivative works based on this work or any other Project
Gutenberg-tm work. The Foundation makes no representations concerning
the copyright status of any work in any country outside the United
States.
1.E. Unless you have removed all references to Project Gutenberg:
1.E.1. The following sentence, with active links to, or other immediate
access to, the full Project Gutenberg-tm License must appear prominently
whenever any copy of a Project Gutenberg-tm work (any work on which the
phrase "Project Gutenberg" appears, or with which the phrase "Project
Gutenberg" is associated) is accessed, displayed, performed, viewed,
copied or distributed:
This eBook is for the use of anyone anywhere at no cost and with
almost no restrictions whatsoever. You may copy it, give it away or
re-use it under the terms of the Project Gutenberg License included
with this eBook or online at www.gutenberg.net
1.E.2. If an individual Project Gutenberg-tm electronic work is derived
from the public domain (does not contain a notice indicating that it is
posted with permission of the copyright holder), the work can be copied
and distributed to anyone in the United States without paying any fees
or charges. If you are redistributing or providing access to a work
with the phrase "Project Gutenberg" associated with or appearing on the
work, you must comply either with the requirements of paragraphs 1.E.1
through 1.E.7 or obtain permission for the use of the work and the
Project Gutenberg-tm trademark as set forth in paragraphs 1.E.8 or
1.E.9.
1.E.3. If an individual Project Gutenberg-tm electronic work is posted
with the permission of the copyright holder, your use and distribution
must comply with both paragraphs 1.E.1 through 1.E.7 and any additional
terms imposed by the copyright holder. Additional terms will be linked
to the Project Gutenberg-tm License for all works posted with the
permission of the copyright holder found at the beginning of this work.
1.E.4. Do not unlink or detach or remove the full Project Gutenberg-tm
License terms from this work, or any files containing a part of this
work or any other work associated with Project Gutenberg-tm.
1.E.5. Do not copy, display, perform, distribute or redistribute this
electronic work, or any part of this electronic work, without
prominently displaying the sentence set forth in paragraph 1.E.1 with
active links or immediate access to the full terms of the Project
Gutenberg-tm License.
1.E.6. You may convert to and distribute this work in any binary,
compressed, marked up, nonproprietary or proprietary form, including any
word processing or hypertext form. However, if you provide access to or
distribute copies of a Project Gutenberg-tm work in a format other than
"Plain Vanilla ASCII" or other format used in the official version
posted on the official Project Gutenberg-tm web site (www.gutenberg.net),
you must, at no additional cost, fee or expense to the user, provide a
copy, a means of exporting a copy, or a means of obtaining a copy upon
request, of the work in its original "Plain Vanilla ASCII" or other
form. Any alternate format must include the full Project Gutenberg-tm
License as specified in paragraph 1.E.1.
1.E.7. Do not charge a fee for access to, viewing, displaying,
performing, copying or distributing any Project Gutenberg-tm works
unless you comply with paragraph 1.E.8 or 1.E.9.
1.E.8. You may charge a reasonable fee for copies of or providing
access to or distributing Project Gutenberg-tm electronic works provided
that
- You pay a royalty fee of 20% of the gross profits you derive from
the use of Project Gutenberg-tm works calculated using the method
you already use to calculate your applicable taxes. The fee is
owed to the owner of the Project Gutenberg-tm trademark, but he
has agreed to donate royalties under this paragraph to the
Project Gutenberg Literary Archive Foundation. Royalty payments
must be paid within 60 days following each date on which you
prepare (or are legally required to prepare) your periodic tax
returns. Royalty payments should be clearly marked as such and
sent to the Project Gutenberg Literary Archive Foundation at the
address specified in Section 4, "Information about donations to
the Project Gutenberg Literary Archive Foundation."
- You provide a full refund of any money paid by a user who notifies
you in writing (or by e-mail) within 30 days of receipt that s/he
does not agree to the terms of the full Project Gutenberg-tm
License. You must require such a user to return or
destroy all copies of the works possessed in a physical medium
and discontinue all use of and all access to other copies of
Project Gutenberg-tm works.
- You provide, in accordance with paragraph 1.F.3, a full refund of any
money paid for a work or a replacement copy, if a defect in the
electronic work is discovered and reported to you within 90 days
of receipt of the work.
- You comply with all other terms of this agreement for free
distribution of Project Gutenberg-tm works.
1.E.9. If you wish to charge a fee or distribute a Project Gutenberg-tm
electronic work or group of works on different terms than are set
forth in this agreement, you must obtain permission in writing from
both the Project Gutenberg Literary Archive Foundation and Michael
Hart, the owner of the Project Gutenberg-tm trademark. Contact the
Foundation as set forth in Section 3 below.
1.F.
1.F.1. Project Gutenberg volunteers and employees expend considerable
effort to identify, do copyright research on, transcribe and proofread
public domain works in creating the Project Gutenberg-tm
collection. Despite these efforts, Project Gutenberg-tm electronic
works, and the medium on which they may be stored, may contain
"Defects," such as, but not limited to, incomplete, inaccurate or
corrupt data, transcription errors, a copyright or other intellectual
property infringement, a defective or damaged disk or other medium, a
computer virus, or computer codes that damage or cannot be read by
your equipment.
1.F.2. LIMITED WARRANTY, DISCLAIMER OF DAMAGES - Except for the "Right
of Replacement or Refund" described in paragraph 1.F.3, the Project
Gutenberg Literary Archive Foundation, the owner of the Project
Gutenberg-tm trademark, and any other party distributing a Project
Gutenberg-tm electronic work under this agreement, disclaim all
liability to you for damages, costs and expenses, including legal
fees. YOU AGREE THAT YOU HAVE NO REMEDIES FOR NEGLIGENCE, STRICT
LIABILITY, BREACH OF WARRANTY OR BREACH OF CONTRACT EXCEPT THOSE
PROVIDED IN PARAGRAPH F3. YOU AGREE THAT THE FOUNDATION, THE
TRADEMARK OWNER, AND ANY DISTRIBUTOR UNDER THIS AGREEMENT WILL NOT BE
LIABLE TO YOU FOR ACTUAL, DIRECT, INDIRECT, CONSEQUENTIAL, PUNITIVE OR
INCIDENTAL DAMAGES EVEN IF YOU GIVE NOTICE OF THE POSSIBILITY OF SUCH
DAMAGE.
1.F.3. LIMITED RIGHT OF REPLACEMENT OR REFUND - If you discover a
defect in this electronic work within 90 days of receiving it, you can
receive a refund of the money (if any) you paid for it by sending a
written explanation to the person you received the work from. If you
received the work on a physical medium, you must return the medium with
your written explanation. The person or entity that provided you with
the defective work may elect to provide a replacement copy in lieu of a
refund. If you received the work electronically, the person or entity
providing it to you may choose to give you a second opportunity to
receive the work electronically in lieu of a refund. If the second copy
is also defective, you may demand a refund in writing without further
opportunities to fix the problem.
1.F.4. Except for the limited right of replacement or refund set forth
in paragraph 1.F.3, this work is provided to you ''AS-IS'' WITH NO OTHER
WARRANTIES OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO
WARRANTIES OF MERCHANTIBILITY OR FITNESS FOR ANY PURPOSE.
1.F.5. Some states do not allow disclaimers of certain implied
warranties or the exclusion or limitation of certain types of damages.
If any disclaimer or limitation set forth in this agreement violates the
law of the state applicable to this agreement, the agreement shall be
interpreted to make the maximum disclaimer or limitation permitted by
the applicable state law. The invalidity or unenforceability of any
provision of this agreement shall not void the remaining provisions.
1.F.6. INDEMNITY - You agree to indemnify and hold the Foundation, the
trademark owner, any agent or employee of the Foundation, anyone
providing copies of Project Gutenberg-tm electronic works in accordance
with this agreement, and any volunteers associated with the production,
promotion and distribution of Project Gutenberg-tm electronic works,
harmless from all liability, costs and expenses, including legal fees,
that arise directly or indirectly from any of the following which you do
or cause to occur: (a) distribution of this or any Project Gutenberg-tm
work, (b) alteration, modification, or additions or deletions to any
Project Gutenberg-tm work, and (c) any Defect you cause.
Section 2. Information about the Mission of Project Gutenberg-tm
Project Gutenberg-tm is synonymous with the free distribution of
electronic works in formats readable by the widest variety of computers
including obsolete, old, middle-aged and new computers. It exists
because of the efforts of hundreds of volunteers and donations from
people in all walks of life.
Volunteers and financial support to provide volunteers with the
assistance they need are critical to reaching Project Gutenberg-tm''s
goals and ensuring that the Project Gutenberg-tm collection will
remain freely available for generations to come. In 2001, the Project
Gutenberg Literary Archive Foundation was created to provide a secure
and permanent future for Project Gutenberg-tm and future generations.
To learn more about the Project Gutenberg Literary Archive Foundation
and how your efforts and donations can help, see Sections 3 and 4
and the Foundation web page at http://www.pglaf.org.
Section 3. Information about the Project Gutenberg Literary Archive
Foundation
The Project Gutenberg Literary Archive Foundation is a non profit
501(c)(3) educational corporation organized under the laws of the
state of Mississippi and granted tax exempt status by the Internal
Revenue Service. The Foundation''s EIN or federal tax identification
number is 64-6221541. Its 501(c)(3) letter is posted at
http://pglaf.org/fundraising. Contributions to the Project Gutenberg
Literary Archive Foundation are tax deductible to the full extent
permitted by U.S. federal laws and your state''s laws.
The Foundation''s principal office is located at 4557 Melan Dr. S.
Fairbanks, AK, 99712., but its volunteers and employees are scattered
throughout numerous locations. Its business office is located at
809 North 1500 West, Salt Lake City, UT 84116, (801) 596-1887, email
business@pglaf.org. Email contact links and up to date contact
information can be found at the Foundation''s web site and official
page at http://pglaf.org
For additional contact information:
Dr. Gregory B. Newby
Chief Executive and Director
gbnewby@pglaf.org
Section 4. Information about Donations to the Project Gutenberg
Literary Archive Foundation
Project Gutenberg-tm depends upon and cannot survive without wide
spread public support and donations to carry out its mission of
increasing the number of public domain and licensed works that can be
freely distributed in machine readable form accessible by the widest
array of equipment including outdated equipment. Many small donations
($1 to $5,000) are particularly important to maintaining tax exempt
status with the IRS.
The Foundation is committed to complying with the laws regulating
charities and charitable donations in all 50 states of the United
States. Compliance requirements are not uniform and it takes a
considerable effort, much paperwork and many fees to meet and keep up
with these requirements. We do not solicit donations in locations
where we have not received written confirmation of compliance. To
SEND DONATIONS or determine the status of compliance for any
particular state visit http://pglaf.org
While we cannot and do not solicit contributions from states where we
have not met the solicitation requirements, we know of no prohibition
against accepting unsolicited donations from donors in such states who
approach us with offers to donate.
International donations are gratefully accepted, but we cannot make
any statements concerning tax treatment of donations received from
outside the United States. U.S. laws alone swamp our small staff.
Please check the Project Gutenberg Web pages for current donation
methods and addresses. Donations are accepted in a number of other
ways including including checks, online payments and credit card
donations. To donate, please visit: http://pglaf.org/donate
Section 5. General Information About Project Gutenberg-tm electronic
works.
Professor Michael S. Hart is the originator of the Project Gutenberg-tm
concept of a library of electronic works that could be freely shared
with anyone. For thirty years, he produced and distributed Project
Gutenberg-tm eBooks with only a loose network of volunteer support.
Project Gutenberg-tm eBooks are often created from several printed
editions, all of which are confirmed as Public Domain in the U.S.
unless a copyright notice is included. Thus, we do not necessarily
keep eBooks in compliance with any particular paper edition.
Most people start at our Web site which has the main PG search facility:
http://www.gutenberg.net
This Web site includes information about Project Gutenberg-tm,
including how to make donations to the Project Gutenberg Literary
Archive Foundation, how to help produce our new eBooks, and how to
subscribe to our email newsletter to hear about new eBooks.','6d5e6f8dde9f58aa71d598c84d4cfa8841a9beb7bdaa2cd2640cdfcbd6221388','internet-archive','theciaworldfactb00025gut','txt','84185fe9df79da427349cc1598fd3f69814a2085a9fc1fe0508a3fae0a870f84','https://archive.org/download/theciaworldfactb00025gut/25.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('82864caf801a352ad77a202d7d3b9d89dc6112768baab1dee747c06a1ecac849',1991,'AQ','Antarctica','communications',31,'_#_Railroads: 29,694 km total; 25,268 km 1.000-meter gauge, 4,339 km
1.600-meter gauge, 74 km mixed 1.600-1.000-meter gauge,
13 km 0.760-meter gauge; 2,308 km electrified
_#_Highways: 1,448,000 km total; 48,000 km paved, 1,400,000 km gravel
or earth
_#_Inland waterways: 50,000 km navigable
_#_Pipelines: crude oil, 2,000 km; refined products, 3,804 km; natural
gas, 1,095 km
_#_Ports: Belem, Fortaleza, Ilheus, Manaus, Paranagua, Porto
Alegre, Recife, Rio de Janeiro, Rio Grande, Salvador, Santos
_#_Merchant marine: 263 ships (1,000 GRT or over) totaling 5,898,838
GRT/9,975,272 DWT; includes 2 passenger-cargo, 59 cargo, 1 refrigerated
cargo, 13 container, 7 roll-on/roll-off, 60 petroleum, oils, and
lubricants (POL) tanker, 15 chemical tanker, 11 liquefied gas, 14
combination ore/oil, 79 bulk, 2 combination bulk; additionally, 2 naval
tanker and 4 military transport are sometimes used commercially
_#_Civil air: 176 major transport aircraft
_#_Airports: 3,751 total, 3,078 usable; 401 with permanent-surface
runways; 2 with runways over 3,659 m; 22 with runways 2,240-3,659 m; 533
with runways 1,220-2,439 m
_#_Telecommunications: good system; extensive radio relay facilities;
9.86 million telephones; stations--1,223 AM, no FM, 112 TV, 151
shortwave; 3 coaxial submarine cables 3 Atlantic Ocean INTELSAT earth
stations with total of 3 antennas; 64 domestic satellite stations
_*_Defense Forces
_#_Branches: Brazilian Army, Navy of Brazil (including Marines),
Brazilian Air Force, Federal Police Force
_#_Manpower availability: males 15-49, 40,559,052; 27,364,392 fit for
military service; 1,637,434 reach military age (18) annually
_#_Defense expenditures: $1.1 billion, 2.6% of GDP (1990)
_%_
_@_British Indian Ocean Territory
(dependent territory of the UK)
_#_Highways: short stretch of paved road between port and airfield on
Diego Garcia
_#_Ports: Diego Garcia
_#_Airports: 1 with permanent-surface runways over 3,659 m on Diego
Garcia
_#_Telecommunications: minimal facilities; stations (operated by the
US Navy)--1 AM, 1 FM, 1 TV; 1 Atlantic Ocean INTELSAT earth station
_*_Defense Forces
_#_Note: defense is the responsibility of the UK
_%_
_@_British Virgin Islands
(dependent territory of the UK)
_#_Highways: 106 km motorable roads (1983)
_#_Ports: Road Town
_#_Airports: 3 total, 3 usable; 2 with permanent-surface runways
less than 1,220 m
_#_Telecommunications: 3,000 telephones; worldwide external telephone
service; submarine cable communication links to Bermuda; stations--1 AM,
no FM, 1 TV
_*_Defense Forces
_#_Note: defense is the responsibility of the UK
_%_
_@_Brunei
_#_Railroads: 13 km 0.610-meter narrow-gauge private line
_#_Highways: 1,090 km total; 370 km paved (bituminous treated) and
another 52 km under construction, 720 km gravel or unimproved
_#_Inland waterways: 209 km; navigable by craft drawing less than 1.2
meters
_#_Ports: Kuala Belait, Muara
_#_Merchant marine: 7 liquefied gas carriers (1,000 GRT or over)
totaling 348,476 GRT/340,635 DWT
_#_Pipelines: crude oil, 135 km; refined products, 418 km;
natural gas, 920 km
_#_Civil air: 4 major transport aircraft (3 Boeing 757-200,
1 Boeing 737-200)
_#_Airports: 2 total, 2 usable; 1 with permanent-surface runways; 1
with runway over 3,659 m; 1 with runway 1,406 m
_#_Telecommunications: service throughout country is adequate for
present needs; international service good to adjacent Malaysia;
radiobroadcast coverage good; 33,000 telephones (1987); stations--4
AM/FM, 1 TV; 74,000 radio receivers (1987); satellite earth stations--1
Indian Ocean INTELSAT and 1 Pacific Ocean INTELSAT
_*_Defense Forces
_#_Branches: Royal Brunei Armed Forces (including Ground Forces,
Flotilla, and Air Wing), Royal Brunei Police
_#_Manpower availability: males 15-49, 110,727; 63,730 fit for
military service; 3,199 reach military age (18) annually
_#_Defense expenditures: $233.1 million, 7.1% of GDP (1988)
_%_
_@_Bulgaria
_#_Railroads: 4,300 km total, all government owned (1987); 4,055 km
1.435-meter standard gauge, 245 km narrow gauge; 917 km double track;
2,510 km electrified
_#_Highways: 36,908 km total; 33,535 km hard surface (including 242 km
superhighways); 3,373 km earth roads (1987)
_#_Inland waterways: 470 km (1987)
_#_Pipelines: crude, 193 km; refined product, 418 km; natural gas,
1,400 km (1986)
_#_Ports: Burgas, Varna, Varna West; river ports are Ruse, Vidin, and
Lom on the Danube
_#_Merchant marine: 112 ships (1,000 GRT and over) totaling 1,227,817
GRT/1,860,294 DWT; includes 2 short-sea passenger, 33 cargo, 2 container,
1 passenger-cargo training, 6 roll-on/roll-off, 18 petroleum, oils, and
lubricants (POL) tanker, 1 chemical carrier, 2 railcar carrier, 47 bulk;
Bulgaria owns 3 ships (1,000 GRT or over) totaling 51,035 DWT operating
under Liberian registry
_#_Civil air: 86 major transport aircraft
_#_Airports: 380 total, 380 usable; about 120 with permanent-surface
runways; 20 with runways 2,440-3,659 m; 20 with runways 1,220-2,439 m
_#_Telecommunications: 2.5 million telephones; direct dialing to 36
countries; phone density is 25 phones per 100 persons; 67% of Sofia
households now have a phone (November 1988); stations--21 AM, 16 FM,
and 19 TV, with 1 Soviet TV relay in Sofia; 2.1 million TV sets (1990);
92% of country receives No. 1 television program (May 1990)
_*_Defense Forces
_#_Branches: Bulgarian People''s Army, Bulgarian Navy, Air and Air
Defense Forces, Frontier Troops, Civil Defense
_#_Manpower availability: males 15-49, 2,183,539; 1,826,992 fit for
military service; 67,836 reach military age (19) annually
_#_Defense expenditures: 1.615 billion leva, NA% of GDP (1990);
note--conversion of defense expenditures into US dollars using the
current exchange rate would produce misleading results
_%_
_@_Burkina
_#_Railroads: 620 km total; 520 km Ouagadougou to Ivory Coast border
and 100 km Ouagadougou to Kaya; all 1.00-meter gauge and single track
_#_Highways: 16,500 km total; 1,300 km paved, 7,400 km improved,
7,800 km unimproved (1985)
_#_Civil air: 2 major transport aircraft
_#_Airports: 50 total, 43 usable; 2 with permanent-surface runways;
none with runways over 3,659 m; 2 with runways 2,440-3,659 m; 7 with
runways 1,220-2,439 m
_#_Telecommunications: all services only fair; radio relay, wire, and
radio communication stations in use; 13,900 telephones; stations--2 AM,
2 FM, 2 TV; 1 Atlantic Ocean INTELSAT earth station
_*_Defense Forces
_#_Branches: Army, Air Force, National Gendarmerie, National Police
_#_Manpower availability: males 15-49, 1,838,000; 937,304 fit for
military service; no conscription
_#_Defense expenditures: $55 million, 2.7% of GDP (1988)
_%_
_@_Burma
_#_Railroads: 3,991 km total, all government owned; 3,878 km
1.000-meter gauge, 113 km narrow-gauge industrial lines; 362 km double
track
_#_Highways: 27,000 km total; 3,200 km bituminous, 17,700 km improved
earth or gravel, 6,100 km unimproved earth
_#_Inland waterways: 12,800 km; 3,200 km navigable by large commercial
vessels
_#_Pipelines: crude, 1,343 km; natural gas, 330 km
_#_Ports: Rangoon, Moulmein, Bassein
_#_Merchant marine: 60 ships (1,000 GRT or over) totaling 968,226
GRT/1,433,584 DWT; includes 3 passenger-cargo, 19 cargo, 2 refrigerated
cargo, 3 vehicle carrier, 2 container, 3 petroleum, oils, and
lubricants (POL) tanker, 2 chemical, 1 combination ore/oil, 24 bulk,
1 combination bulk
_#_Civil air: 17 major transport aircraft (including 3 helicopters)
_#_Airports: 86 total, 79 usable; 29 with permanent-surface runways;
none with runways over 3,659 m; 3 with runways 2,440-3,659 m; 37
with runways 1,220-2,439 m
_#_Telecommunications: meets minimum requirements for local and
intercity service; international service is good; radiobroadcast coverage
is limited to the most populous areas; 53,000 telephones (1986);
stations--2 AM, 1 FM, 1 TV (1985); 1 Indian Ocean INTELSAT earth station
_*_Defense Forces
_#_Branches: Army, Navy, Air Force
_#_Manpower availability: eligible 15-49, 20,766,975; of the
10,378,743 males 15-49, 5,566,247 are fit for military service; of the
10,388,232 females 15-49, 5,558,007 are fit for military service; 442,200
males and 431,407 females reach military age (18) annually; both sexes
are liable for military service
_#_Defense expenditures: $315.0 million, 3% of GDP (FY88)
_%_
_@_Burundi
_#_Highways: 5,900 km total; 400 km paved, 2,500 km gravel or
laterite, 3,000 km improved or unimproved earth
_#_Inland waterways: Lake Tanganyika
_#_Ports: Bujumbura (lake port) connects to transportation systems of
Tanzania and Zaire
_#_Civil air: 1 major transport aircraft
_#_Airports: 8 total, 7 usable; 1 with permanent-surface runways;
none with runways over 3,659 m; 1 with runways 2,440-3,659 m; none
with runways 1,220 to 2,439 m
_#_Telecommunications: sparse system of wire, radiocommunications, and
low-capacity radio relay links; 8,000 telephones; stations--2 AM, 2 FM, 1
TV; 1 Indian Ocean INTELSAT earth station
_*_Defense Forces
_#_Branches: Army (includes naval and air units); paramilitary
Gendarmerie
_#_Manpower availability: males 15-49, 1,268,342; 661,888 fit for
military service; 64,538 reach military age (16) annually
_#_Defense expenditures: $33 million, 3.1% of GDP (1988)
_%_
_@_Cambodia
_#_Railroads: 612 km 1.000-meter gauge, government owned
_#_Highways: 13,351 km total; 2,622 km bituminous; 7,105 km crushed
stone, gravel, or improved earth; 3,624 km unimproved earth; some roads
in disrepair
_#_Inland waterways: 3,700 km navigable all year to craft drawing 0.6
meters; 282 km navigable to craft drawing 1.8 meters
_#_Ports: Kampong Saom, Phnom Penh
_#_Airports: 22 total, 9 usable; 6 with permanent-surface runways;
none with runways over 3,659 m; 2 with runways 2,440-3,659 m;
4 with runways 1,220-2,439 m
_#_Telecommunications: service barely adequate for government
requirements and virtually nonexistent for general public; international
service limited to Vietnam and other adjacent countries; stations--1 AM,
no FM, 1 TV
_*_Defense Forces
_#_Branches: SOC--Cambodian People''s Armed Forces (CPAF); Communist
resistance forces--National Army of Democratic Kampuchea (Khmer Rouge);
non-Communist resistance forces--Armee National Kampuchea Independent
(ANKI) which is sometimes anglicized as National Army of Independent
Cambodia (NAIC) and Khmer People''s National Liberation Armed Forces
(KPNLAF)
_#_Manpower availability: males 15-49, 1,869,880; 1,030,356 fit for
military service; 57,288 reach military age (18) annually
_#_Defense expenditures: $NA, NA% of GDP
_%_
_@_Cameroon
_#_Railroads: 1,003 km total; 858 km 1.000-meter gauge, 145 km
0.600-meter gauge
_#_Highways: about 65,000 km total; includes 2,682 km bituminous,
30,000 km unimproved earth, 32,318 km gravel, earth, and improved earth
_#_Inland waterways: 2,090 km; of decreasing importance
_#_Ports: Douala
_#_Merchant marine: 2 cargo ships (1,000 GRT or over) totaling
24,122 GRT/33,509 DWT
_#_Civil air: 5 major transport aircraft
_#_Airports: 60 total, 52 usable; 10 with permanent-surface runways;
1 with runways over 3,659 m; 5 with runways 2,440-3,659 m; 21 with
runways 1,220-2,439 m
_#_Telecommunications: good system of open wire, cable, troposcatter,
and radio relay; 26,000 telephones; stations--10 AM, 1 FM, 1 TV; 2
Atlantic Ocean INTELSAT earth stations
_*_Defense Forces
_#_Branches: Army, Navy (including Marines), Air Force; paramilitary
Gendarmerie
_#_Manpower availability: males 15-49, 2,628,909; 1,324,899 fit for
military service; 125,421 reach military age (18) annually
_#_Defense expenditures: $219 million, 1.7% of GDP (1990 est.)
_%_
_@_Canada
_#_Railroads: 93,544 km total; two major transcontinental freight
railway systems--Canadian National (government owned) and Canadian
Pacific Railway; passenger service--VIA (government operated)
_#_Highways: 884,272 km total; 712,936 km surfaced (250,023 km paved),
171,336 km earth
_#_Inland waterways: 3,000 km, including Saint Lawrence Seaway
_#_Pipelines: oil, 23,564 km total crude and refined; natural gas,
74,980 km
_#_Ports: Halifax, Montreal, Quebec, Saint John (New Brunswick),
Saint John''s (Newfoundland), Toronto, Vancouver
_#_Merchant marine: 75 ships (1,000 GRT or over) totaling 532,062
GRT/727,118 DWT; includes 1 passenger, 5 short-sea passenger, 2
passenger-cargo, 13 cargo, 2 railcar carrier, 1 refrigerated cargo, 8
roll-on/roll-off, 1 container, 27 petroleum, oils, and lubricants (POL)
tanker, 6 chemical tanker, 1 specialized tanker, 8 bulk; note--does not
include ships used exclusively in the Great Lakes
_#_Civil air: 636 major transport aircraft; Air Canada is the major
carrier
_#_Airports: 1,397 total, 1,154 usable; 443 with permanent-surface
runways; 4 with runways over 3,659 m; 30 with runways 2,440-3,659 m; 328
with runways 1,220-2,439 m
_#_Telecommunications: excellent service provided by modern media;
18.0 million telephones; stations--900 AM, 29 FM, 53 (1,400 repeaters)
TV; 5 coaxial submarine cables; over 300 earth stations operating in
INTELSAT (including 4 Atlantic Ocean and 1 Pacific Ocean) and domestic
systems
_*_Defense Forces
_#_Branches: Canadian Armed Forces (including Mobile Command,
Maritime Command, Air Command, Communications Command, Canadian Forces
Europe, Training Commands), Royal Canadian Mounted Police (RCMP)
_#_Manpower availability: males 15-49, 7,243,909; 6,297,520 fit for
military service; 188,996 reach military age (17) annually
_#_Defense expenditures: $11.3 billion, 2% of GDP (FY90)
_%_
_@_Cape Verde
_#_Ports: Mindelo and Praia
_#_Merchant marine: 7 cargo ships (1,000 GRT or over) totaling 11,708
GRT/19,000 DWT
_#_Civil air: 5 major transport aircraft (4 owned, 1 leased)
_#_Airports: 6 total, 6 usable; 6 with permanent-surface runways;
none with runways over 3,659 m; 1 with runways 2,440-3,659 m; 1 with
runways 1,220-2,439 m
_#_Telecommunications: interisland radio relay system, high-frequency
radio to mainland Portugal and Guinea-Bissau; 1,740 telephones;
stations--5 AM, 1 FM, 1 TV; 2 coaxial submarine cables; 1 Atlantic Ocean
INTELSAT earth station
_*_Defense Forces
_#_Branches: People''s Revolutionary Armed Forces (FARP)--Army and
Navy are separate components of FARP; Militia, Security Service
_#_Manpower availability: males 15-49, 70,771; 41,844 fit for military
service
_#_Defense expenditures: $15 million, 11% of GDP (1981)
_%_
_@_Cayman Islands
(dependent territory of the UK)
_#_Highways: 160 km of main roads
_#_Ports: George Town, Cayman Brac
_#_Merchant marine: 33 ships (1,000 GRT or over) totaling 372,732
GRT/604,395 DWT; includes 1 passenger-cargo, 6 cargo, 7 roll-on/roll-off
cargo, 6 petroleum, oils, and lubricants (POL) tanker, 1 chemical tanker,
2 specialized tanker, 1 liquefied gas carrier, 9 bulk; note--a flag of
convenience registry
_#_Airports: 3 total; 3 usable; 2 with permanent-surface runways;
none with runways over 2,439 m; 2 with runways 1,220-2,439 m
_#_Telecommunications: 35,000 telephones; telephone system uses 1
submarine coaxial cable and 1 Atlantic Ocean INTELSAT earth station to
link islands and access international services; stations--2 AM, 1 FM,
no TV
_*_Defense Forces
_#_Branches: Royal Cayman Islands Police Force (RCIPF)
_#_Note: defense is the responsibility of the UK
_%_
_@_Central African Republic
_#_Highways: 22,000 km total; 458 km bituminous, 10,542 km improved
earth, 11,000 unimproved earth
_#_Inland waterways: 800 km; traditional trade carried on by means of
shallow-draft dugouts; Oubangui is the most important river
_#_Civil air: 2 major transport aircraft
_#_Airports: 66 total, 49 usable; 4 with permanent-surface runways;
none with runways over 3,659 m; 2 with runways 2,440-3,659 m; 22 with
runways 1,220-2,439 m
_#_Telecommunications: fair system; network relies primarily on radio
relay links, with low-capacity, low-powered radiocommunication also used;
6,000 telephones; stations--1 AM, 1 FM, 1 TV; 1 Atlantic Ocean INTELSAT
earth station
_*_Defense Forces
_#_Branches: Central African Armed Forces, Air Force, National
Gendarmerie, Police Force
_#_Manpower availability: males 15-49, 659,802; 345,049 fit for
military service
_#_Defense expenditures: $23 million, 1.8% of GDP (1989 est.)
_%_
_@_Chad','7be76775f3b141f0cde572e79220692cdd2431c50fd2755d0a04f7115a634589','internet-archive','theciaworldfactb00025gut','txt','84185fe9df79da427349cc1598fd3f69814a2085a9fc1fe0508a3fae0a870f84','https://archive.org/download/theciaworldfactb00025gut/25.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ef2ceee99ceaaf4f979b8006e20151d5513e905181c0671dfd01d06db223fe01',1991,'NG','Nigeria','communications',36,'_#_Highways: 31,322 km total; 32 km bituminous; 7,300 km gravel and
laterite; remainder unimproved
_#_Inland waterways: 2,000 km navigable
_#_Civil air: 3 major transport aircraft
_#_Airports: 70 total, 54 usable; 4 with permanent-surface runways;
none with runways over 3,659 m; 3 with runways 2,440-3,659 m; 23 with
runways 1,220-2,439 m
_#_Telecommunications: fair system of radiocommunication stations for
intercity links; 5,000 telephones; stations--3 AM, 1 FM, limited TV
service; many facilities are inoperative; 1 Atlantic Ocean INTELSAT earth
station
_*_Defense Forces
_#_Branches: Patriotic Salvation Force (FPS; Army, Air Force),
paramilitary Gendarmerie, National Police
_#_Manpower availability: males 15-49, 1,188,222; 616,932 fit for
military service; 51,713 reach military age (20) annually
_#_Defense expenditures: $39 million, 4.3% of GDP (1988)
_%_
_@_Chile
_#_Railroads: 8,613 km total; 4,257 km 1.676-meter gauge, 135 km
1.435-meter standard gauge, 4,221 km 1.000-meter gauge; electrification,
1,865 km 1.676-meter gauge, 80 km 1.000-meter gauge
_#_Highways: 79,025 km total; 9,913 km paved, 33,140 km gravel,
35,972 km improved and unimproved earth (1984)
_#_Inland waterways: 725 km
_#_Pipelines: crude oil, 755 km; refined products, 785 km;
natural gas, 320 km
_#_Ports: Antofagasta, Iquique, Puerto Montt, Punta Arenas,
Valparaiso, San Antonio, Talcahuano, Arica
_#_Merchant marine: 35 ships (1,000 GRT or over) totaling 485,935
GRT/800,969 DWT; includes 14 cargo, 1 refrigerated cargo, 3
roll-on/roll-off cargo, 2 petroleum, oils, and lubricants (POL) tanker, 1
chemical tanker, 2 liquefied gas, 3 combination ore/oil, 9 bulk;
note--in addition, 2 naval tanker and 2 military transport are sometimes
used commercially
_#_Civil air: 22 major transport aircraft
_#_Airports: 392 total, 353 usable; 50 with permanent-surface runways;
none with runways over 3,659 m; 12 with runways 2,440-3,659 m;
55 with runways 1,220-2,439 m
_#_Telecommunications: modern telephone system based on extensive
radio relay facilities; 768,000 telephones; stations--159 AM, no FM,
131 TV, 11 shortwave; satellite stations--2 Atlantic Ocean INTELSAT and 3
domestic
_*_Defense Forces
_#_Branches: Army of the Nation, National Navy (including Naval Air
and Marines), Air Force of the Nation, Carabineros of Chile (National
Police)
_#_Manpower availability: males 15-49, 3,544,962; 2,647,148 fit for
military service; 119,511 reach military age (19) annually
_#_Defense expenditures: $737 million, 3% of GNP (1991 est.)
_%_
_@_China
(also see separate Taiwan entry)
_#_Railroads: total about 54,000 km common carrier lines; 53,400 km
1.435-meter standard gauge; 600 km 1.000-meter gauge;
all single track except 11,200 km double track on standard-gauge lines;
6,500 km electrified; 10,000 km industrial lines
(gauges range from 0.762 to 1.067 meters)
_#_Highways: about 980,000 km all types roads; 162,000 km paved
roads, 617,200 km gravel/improved earth roads, 200,800 km unimproved
natural earth roads and tracks
_#_Inland waterways: 138,600 km; about 109,800 km navigable
_#_Pipelines: crude, 6,500 km; refined products, 1,100 km; natural
gas, 6,200 km
_#_Ports: Dalian, Guangzhou, Huangpu, Qingdao, Qinhuangdao, Shanghai,
Xingang, Zhanjiang, Ningbo, Xiamen, Tanggu, Shantou
_#_Merchant marine: 1,421 ships (1,000 GRT or over) totaling
14,010,317 GRT/21,223,170 DWT; includes 24 passenger, 42 short-sea
passenger, 19 passenger-cargo, 7 cargo/training, 776 cargo, 11
refrigerated cargo, 70 container, 17 roll-on/roll-off cargo, 2
multifunction barge carrier, 181 petroleum, oils, and lubricants (POL)
tanker, 9 chemical tanker, 250 bulk, 2 liquefied gas, 2 vehicle carrier,
9 combination bulk; note--China beneficially owns an additional 183 ships
(1,000 GRT or over) totaling approximately 5,921,000 DWT that operate
under Maltese and Liberian registry
_#_Airports: 330 total, 330 usable; 260 with permanent-surface
runways; fewer than 10 with runways over 3,500 m; 90 with runways
2,440-3,659 m; 200 with runways 1,220-2,439 m
_#_Telecommunications: domestic and international services are
increasingly available for private use; unevenly distributed internal
system serves principal cities, industrial centers, and most townships;
11,000,000 telephones (December 1989); stations--274 AM, unknown FM,
202 (2,050 relays) TV; more than 215 million radio receivers; 75 million
TVs; satellite earth stations--4 Pacific Ocean INTELSAT, 1 Indian Ocean
INTELSAT, 1 INMARSAT, and 55 domestic
_*_Defense Forces
_#_Branches: Chinese People''s Liberation Army (CPLA), CPLA Navy
(including Marines), CPLA Air Force, Chinese People''s Armed Police
_#_Manpower availability: males 15-49, 335,382,062; 187,046,680 fit
for military service; 10,967,622 reach military age (18) annually
_#_Defense expenditures: $NA, NA% of GNP
_%_
_@_Christmas Island
(territory of Australia)','b072e0452b70c8a8a9eebf6012594622a052f762a45d6cbf7c98e7da53aed582','internet-archive','theciaworldfactb00025gut','txt','84185fe9df79da427349cc1598fd3f69814a2085a9fc1fe0508a3fae0a870f84','https://archive.org/download/theciaworldfactb00025gut/25.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('37e0ca8a41a71193af2d3ddb134b3714b72308c0043d4c689e69aae91d3449d1',1991,'AU','Australia','communications',39,'_#_Ports: Flying Fish Cove
_#_Airports: 1 usable with permanent-surface runway 1,220-2,439 m
_#_Telecommunications: 4,000 radios (1982)
_*_Defense Forces
_#_Note: defense is the responsibility of Australia
_%_
_@_Clipperton Island
(French possession)
_#_Ports: none; offshore anchorage only
_*_Defense Forces
_#_Note: defense is the responsibility of France
_%_
_@_Cocos (Keeling) Islands
(territory of Australia)
_#_Ports: none; lagoon anchorage only
_#_Airports: 1 airfield with permanent-surface runway, 1,220-2,439 m;
airport on West Island is a link in service between Australia and South
Africa
_#_Telecommunications: 250 radios (1985); linked by telephone,
telex, and facsimile communications via satellite with Australia;
stations--1 AM, no FM, no TV
_*_Defense Forces
_#_Note: defense is the responsibility of Australia
_%_
_@_Colombia
_#_Railroads: 3,386 km; 3,236 km 0.914-meter gauge, single track
(2,611 km in use), 150 km 1.435-meter gauge
_#_Highways: 75,450 km total; 9,350 km paved, 66,100 km earth and
gravel surfaces
_#_Inland waterways: 14,300 km, navigable by river boats
_#_Pipelines: crude oil, 3,585 km; refined products, 1,350 km;
natural gas, 830 km; natural gas liquids, 125 km
_#_Ports: Barranquilla, Buenaventura, Cartagena, Covenas, San Andres,
Santa Marta, Tumaco
_#_Merchant marine: 35 ships (1,000 GRT or over) totaling 330,316
GRT/484,351 DWT; includes 23 cargo, 1 chemical tanker, 3 petroleum, oils,
and lubricants (POL) tanker, 8 bulk; note--2 naval tankers are
sometimes used commercially
_#_Civil air: 106 major transport aircraft
_#_Airports: 1,165 total, 1,045 usable; 69 with permanent-surface
runways; 1 with runways over 3,659 m; 8 with runways 2,440-3,659 m;
192 with runways 1,220-2,439 m
_#_Telecommunications: nationwide radio relay system; 1,890,000
telephones; stations--413 AM, no FM, 33 TV, 28 shortwave 2 Atlantic Ocean
INTELSAT earth stations with 2 antennas and 11 domestic satellite
stations
_*_Defense Forces
_#_Branches: Army (Ejercito Nacional), Navy (Armada Nacional),
Air Force (Fuerza Aerea de Colombia), National Police (Policia Nacional)
_#_Manpower availability: males 15-49, 8,998,759; 6,102,745 fit for
military service; 353,122 reach military age (18) annually
_#_Defense expenditures: $892 million, 2.2% of GDP (1990)
_%_
_@_Comoros
_#_Highways: 750 km total; about 210 km bituminous, remainder crushed
stone or gravel
_#_Ports: Mutsamudu, Moroni
_#_Civil air: 4 major transport aircraft
_#_Airports: 4 total, 4 usable; 4 with permanent-surface runways;
none with runways over 3,659 m; 1 with runways 2,440-3,659 m; 3 with
runways 1,220-2,439 m
_#_Telecommunications: sparse system of radio relay and high-frequency
radio communication stations for interisland and external communications
to Madagascar and Reunion; over 1,800 telephones; stations--2 AM, 1 FM,
1 TV
_*_Defense Forces
_#_Branches: Comoran Defense Force (FCD), Federal Gendarmerie (GFC)
_#_Manpower availability: males 15-49, 101,332; 60,592 fit for
military service
_#_Defense expenditures: $NA, 3% of GDP (1981)
_%_
_@_Congo','06c74d8d76aebe479db819f25131cee6ddaa67b357bbcb411c8639784a79aac5','internet-archive','theciaworldfactb00025gut','txt','84185fe9df79da427349cc1598fd3f69814a2085a9fc1fe0508a3fae0a870f84','https://archive.org/download/theciaworldfactb00025gut/25.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('31c989189f260bacfea95d4de613de8c7043a310670fd2e22061f4fcea3b7001',1991,'ET','Ethiopia','communications',42,'_#_Railroads: 797 km, 1.067-meter gauge, single track (includes 285 km
that are privately owned)
_#_Highways: 12,000 km total; 560 km bituminous surface treated;
850 km gravel, laterite; 5,350 km improved earth; 5,240 km unimproved
roads
_#_Inland waterways: the Congo and Ubangi (Oubangui) Rivers provide
1,120 km of commercially navigable water transport; the rest are used for
local traffic only
_#_Pipelines: crude oil 25 km
_#_Ports: Pointe-Noire (ocean port), Brazzaville (river port)
_#_Civil air: 4 major transport aircraft
_#_Airports: 50 total, 45 usable; 5 with permanent-surface runways;
none with runways over 3,659 m; 1 with runways 2,440-3,659 m; 18 with
runways 1,220-2,439 m
_#_Telecommunications: services adequate for government use; primary
network is composed of radio relay routes and coaxial cables; key centers
are Brazzaville, Pointe-Noire, and Loubomo; 18,100 telephones;
stations--3 AM, 1 FM, 4 TV; 1 Atlantic Ocean satellite station
_*_Defense Forces
_#_Branches: Army, Navy (including Marines), Air Force, paramilitary
National People''s Militia, National Police
_#_Manpower availability: males 15-49, 509,040; 258,861 fit for
military service; 24,068 reach military age (20) annually
_#_Defense expenditures: $99 million, 4.6% of GDP (1987 est.)
_%_
_@_Cook Islands
(free association with New Zealand)
_#_Highways: 187 km total (1980); 35 km paved, 35 km gravel, 84 km
improved earth, 33 km unimproved earth
_#_Ports: Avatiu
_#_Civil air: no major transport aircraft
_#_Airports: 7 total, 6 usable; 1 with permanent-surface runways;
none with runways over 2,439 m; 3 with runways 1,220-2,439 m
_#_Telecommunications: stations--2 AM, no FM, no TV; 10,000 radio
receivers; 2,052 telephones; 1 Pacific Ocean INTELSAT earth station
_*_Defense Forces
_#_Note: defense is the responsibility of New Zealand
_%_
_@_Coral Sea Islands
(territory of Australia)
_#_Ports: none; offshore anchorages only
_*_Defense Forces
_#_Note: defense is the responsibility of Australia; visited regularly
by the Royal Australian Navy; Australia has control over the activities
of visitors
_%_
_@_Costa Rica
_#_Railroads: 950 km total, all 1.067-meter gauge; 260 km electrified
_#_Highways: 15,400 km total; 7,030 km paved, 7,010 km gravel,
1,360 km unimproved earth
_#_Inland waterways: about 730 km, seasonally navigable
_#_Pipelines: refined products, 176 km
_#_Ports: Puerto Limon, Caldera, Golfito, Moin, Puntarenas
_#_Merchant marine: 12 cargo ships (1,000 GRT or over)
totaling 2,831 GRT/4,506 DWT
_#_Civil air: 9 major transport aircraft
_#_Airports: 173 total, 159 usable; 26 with permanent-surface runways;
none with runways over 3,659 m; 1 with runways 2,440-3,659 m;
11 with runways 1,220-2,439 m
_#_Telecommunications: very good domestic telephone service; 292,000
telephones; connection into Central American Microwave System;
stations--71 AM, no FM, 18 TV, 13 shortwave; 1 Atlantic Ocean INTELSAT
earth station
_*_Defense Forces
_#_Branches: Civil Guard, Rural Assistance Guard; note--Constitution
prohibits armed forces
_#_Manpower availability: males 15-49, 807,853; 545,541 fit for
military service; 32,149 reach military age (18) annually
_#_Defense expenditures: $20 million, 0.4% of GDP (1988)
_%_
_@_Cuba
_#_Railroads: 14,925 km total; Cuban National Railways operates
5,295 km of 1.435-meter gauge track; 199 km electrified; 9,630 km of
sugar plantation lines of 0.914-1.435-meter gauge
_#_Highways: 26,477 km total; 14,477 km paved, 12,000 km gravel
and earth surfaced (1989 est.)
_#_Inland waterways: 240 km
_#_Ports: Cienfuegos, Havana, Mariel, Matanzas, Santiago de Cuba;
7 secondary, 35 minor
_#_Merchant marine: 87 ships (1,000 GRT or over) totaling
638,462 GRT/925,380 DWT; includes 54 cargo, 9 refrigerated cargo, 2
cargo/training, 12 petroleum, oils, and lubricants (POL) tanker, 1
chemical tanker, 3 liquefied gas, 6 bulk; note--Cuba beneficially owns
an additional 37 ships (1,000 GRT and over) totaling 512,346 DWT under
the registry of Panama, Cyprus, and Malta
_#_Civil air: 59 major transport aircraft
_#_Airports: 205 total, 176 usable; 75 with permanent-surface runways;
3 with runways over 3,659 m; 12 with runways 2,440-3,659 m; 25 with
runways 1,220-2,439 m
_#_Telecommunications: stations--150 AM, 5 FM, 58 TV; 1,530,000 TVs;
2,140,000 radios; 229,000 telephones; 1 Atlantic Ocean INTELSAT earth
station
_*_Defense Forces
_#_Branches: Revolutionary Armed Forces (including Ground Forces,
Revolutionary Navy, Air and Air Defense Force), Ministry of Interior
Special Troops, Border Guard Troops, Territorial Militia Troops, Youth
Labor Army, Civil Defense, National Revolutionary Police
_#_Manpower availability: eligible 15-49, 6,087,253; of the 3,054,158
males 15-49, 1,914,080 are fit for military service; of the 3,033,095
females 15-49, 1,896,449 are fit for military service; 89,194 males and
85,968 females reach military age (17) annually
_#_Defense expenditures: $1.2-$1.4 billion, 6% of GNP (1989 est.)
_%_
_@_Cyprus
_#_Highways: 10,780 km total; 5,170 km bituminous surface treated;
5,610 km gravel, crushed stone, and earth
_#_Ports: Famagusta, Kyrenia, Larnaca, Limassol, Paphos
_#_Merchant marine: 1,169 ships (1,000 GRT or over) totaling
19,310,063 GRT/34,338,028 DWT; 10 short-sea passenger, 2 passenger-cargo,
435 cargo, 76 refrigerated cargo, 20 roll-on/roll-off cargo, 48
container, 4 multifunction large load carrier, 111 petroleum, oils, and
lubricants (POL) tanker, 2 specialized tanker, 8 liquefied gas, 17
chemical tanker, 30 combination ore/oil, 360 bulk, 2 vehicle carrier, 44
combination bulk; note--a flag of convenience registry; Cuba owns at
least 25 of these ships, USSR owns 52, and Yugoslavia owns 1
_#_Civil air: 11 major transport aircraft
_#_Airports: 13 total, 13 usable; 10 with permanent-surface runways;
none with runways over 3,659 m; 7 with runways 2,440-3,659 m;
2 with runways 1,220-2,439 m
_#_Telecommunications: excellent in the area controlled by the Cypriot
Government (Greek area), moderately good in the Turkish-Cypriot
administered area; 210,000 telephones; stations--14 AM, 7 (7 repeaters)
FM, 2 (40 repeaters) TV; tropospheric scatter circuits to Greece and
Turkey; 3 submarine coaxial cables; satellite earth stations--INTELSAT, 1
Atlantic Ocean and 1 Indian Ocean, and EUTELSAT systems
_*_Defense Forces
_#_Branches: Greek area--Greek Cypriot National Guard (GCNG;
includes air and naval elements), Greek Cypriot Police; Turkish
area--Turkish Cypriot Security Force
_#_Manpower availability: males 15-49, 182,426; 125,839 fit for
military service; 5,169 reach military age (18) annually
_#_Defense expenditures: $209 million, 5% of GDP (1990 est.)
_%_
_@_Czechoslovakia
_#_Railroads: 13,103 km total; 12,855 km 1.435-meter standard gauge,
102 km 1.520-meter broad gauge, 146 km 0.750- and 0.760-meter narrow
gauge; 2,861 km double track; 3,798 km electrified; government owned
(1988)
_#_Highways: 73,540 km total; including 517 km superhighway (1988)
_#_Inland waterways: 475 km (1988); the Elbe (Labe) is the principal
river
_#_Pipelines: crude oil, 1,448 km; refined products, 1,500 km; natural
gas, 8,100 km
_#_Ports: maritime outlets are in Poland (Gdynia, Gdansk, Szczecin),
Yugoslavia (Rijeka, Koper), Germany (Hamburg, Rostock); principal river
ports are Prague on the Vltava, Decin on the Elbe (Labe),
Komarno on the Danube, Bratislava on the Danube
_#_Merchant marine: 24 ships (1,000 GRT or over) totaling 363,002 GRT/
565,813 DWT; includes 15 cargo, 6 bulk
_#_Civil air: 47 major transport aircraft
_#_Airports: 158 total, 158 usable; 40 with permanent-surface
runways; 19 with runways 2,440-3,659 m; 37 with runways 1,220-2,439 m
_#_Telecommunications: 4 million telephones; 25% of households
have a telephone; stations--60 AM, 16 FM, 39 TV (11 Soviet TV
relays); 4.4 million TVs (1990)
_*_Defense Forces
_#_Branches: Czechoslovak People''s Army, Air and Air Defense Forces,
Civil Defense, Border Guard
_#_Manpower availability: males 15-49, 4,066,419; 3,110,958 fit for
military service; 140,620 reach military age (18) annually
_#_Defense expenditures: 26.9 billion koruny, NA% of GDP (1991);
note--conversion of defense expenditures into US dollars using the
official administratively set exchange rate would produce misleading
results
_%_
_@_Denmark','7dd18ceec3217469e3d5ea7f697d7c128b64688a41a486bae4b485c1387522bd','internet-archive','theciaworldfactb00025gut','txt','84185fe9df79da427349cc1598fd3f69814a2085a9fc1fe0508a3fae0a870f84','https://archive.org/download/theciaworldfactb00025gut/25.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6d80122cc88cb9152005104be1591e0e3056a1e6bcf74d65e9369f15149bf80f',1991,'SE','Sweden','communications',47,'_#_Railroads: 2,675 km 1.435-meter standard gauge; Danish State
Railways (DSB) operate 2,025 km (1,999 km rail line and 121 km rail ferry
services); 188 km electrified, 730 km double tracked; 650 km of
standard-gauge lines are privately owned and operated
_#_Highways: 66,482 km total; 64,551 km concrete, bitumen, or stone
block; 1,931 km gravel, crushed stone, improved earth
_#_Inland waterways: 417 km
_#_Pipelines: crude oil, 110 km; refined products, 578 km; natural
gas, 700 km
_#_Ports: Alborg, Arhus, Copenhagen, Esbjerg, Fredericia;
numerous secondary and minor ports
_#_Merchant marine: 281 ships (1,000 GRT or over) totaling 4,888,064
GRT/7,131,949 DWT; includes 13 short-sea passenger, 85 cargo, 15
refrigerated cargo, 35 container, 40 roll-on/roll-off cargo, 1 railcar
carrier, 37 petroleum, oils, and lubricants (POL) tanker, 14 chemical
tanker, 22 liquefied gas, 4 livestock carrier, 14 bulk, 1 combination
bulk; note--Denmark has created its own internal register, called the
Danish International Ship Register (DIS); DIS ships do not have to
meet Danish manning regulations, and they amount to a flag of convenience
within the Danish register; by the end of 1990, 258 of the Danish-flag
ships belonged to the DIS
_#_Civil air: 69 major transport aircraft
_#_Airports: 129 total, 112 usable; 27 with permanent-surface
runways; none with runways over 3,659 m; 9 with runways 2,440-3,659 m;
7 with runways 1,220-2,439 m
_#_Telecommunications: excellent telephone, telegraph, and broadcast
services; 4,509,000 telephones; stations--2 AM, 15 (39 repeaters) FM, 27
(25 repeaters) TV; 7 submarine coaxial cables; 1 earth station operating
in INTELSAT, 4 Atlantic Ocean, EUTELSAT, and domestic systems
_*_Defense Forces
_#_Branches: Royal Danish Army, Royal Danish Navy, Royal Danish Air
Force
_#_Manpower availability: males 15-49, 1,369,684; 1,179,991 fit for
military service; 36,991 reach military age (20) annually
_#_Defense expenditures: $2.4 billion, 2% of GDP (1990)
_%_
_@_Djibouti
_#_Railroads: the Ethiopian-Djibouti railroad extends for 97 km
through Djibouti
_#_Highways: 2,900 km total; 280 km bituminous surface, 2,620 km
improved or unimproved earth (1982)
_#_Ports: Djibouti
_#_Civil air: 2 major transport aircraft
_#_Airports: 13 total, 10 usable; 2 with permanent-surface runways;
none with runways over 3,659 m; 2 with runways 2,440-3,659 m;
4 with runways 1,220-2,439 m
_#_Telecommunications: fair system of urban facilities in Djibouti and
radio relay stations at outlying places; 7,300 telephones; stations--2
AM, 1 FM, 2 TV; 1 Indian Ocean INTELSAT earth station and 1 ARABSAT;
1 submarine cable to Saudi Arabia
_*_Defense Forces
_#_Branches: Army (including Navy and Air Force), paramilitary
National Security Force, National Police Force
_#_Manpower availability: males 15-49, 89,519; 52,093 fit for military
service
_#_Defense expenditures: $29.9 million, NA% of GDP (1986)
_%_
_@_Dominica
_#_Highways: 750 km total; 370 km paved, 380 km gravel and earth
_#_Ports: Roseau, Portsmouth
_#_Civil air: NA
_#_Airports: 2 total, 2 usable; 2 with permanent-surface runways;
none with runways over 2,439 m; 1 with runways 1,220-2,439 m
_#_Telecommunications: 4,600 telephones in fully automatic network;
VHF and UHF link to Saint Lucia; new SHF links to Martinique and
Guadeloupe; stations--3 AM, 2 FM, 1 cable TV
_*_Defense Forces
_#_Branches: Commonwealth of Dominica Police Force
_#_Manpower availability: NA
_#_Defense expenditures: $NA, NA% of GDP
_%_
_@_Dominican Republic
_#_Railroads: 1,655 km total in numerous segments; 4 different gauges
from 0.558 m to 1.435 m
_#_Highways: 12,000 km total; 5,800 km paved, 5,600 km gravel and
improved earth, 600 km unimproved
_#_Pipelines: crude oil, 96 km; refined products, 8 km
_#_Ports: Santo Domingo, Haina, San Pedro de Macoris, Puerto Plata
_#_Merchant marine: 4 cargo ships (1,000 GRT or over) totaling 23,326
GRT/38,661 DWT
_#_Civil air: 14 major transport aircraft
_#_Airports: 44 total, 30 usable; 14 with permanent-surface runways;
none with runways over 3,659 m; 3 with runways 2,440-3,659 m; 9 with
runways 1,220-2,439 m
_#_Telecommunications: relatively efficient domestic system based on
islandwide radio relay network; 190,000 telephones; stations--120 AM, no
FM, 18 TV, 6 shortwave; 1 coaxial submarine cable; 1 Atlantic Ocean
INTELSAT earth station
_*_Defense Forces
_#_Branches: Army, Navy, Air Force, National Police
_#_Manpower availability: males 15-49, 1,963,260; 1,241,370 fit for
military service; 81,083 reach military age (18) annually
_#_Defense expenditures: $70 million, 1% of GDP (1990)
_%_
_@_Ecuador','f6896284ec0aea119fece24594c0296d9d84c26acda329750a256bbbf844d5e0','internet-archive','theciaworldfactb00025gut','txt','84185fe9df79da427349cc1598fd3f69814a2085a9fc1fe0508a3fae0a870f84','https://archive.org/download/theciaworldfactb00025gut/25.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('15c11036719f54fe29a187dc6fa67cb9eecc064c8beb8e809bf7ac4528e1874a',1991,'PE','Peru','communications',52,'_#_Railroads: 965 km total; all 1.067-meter-gauge single track
_#_Highways: 28,000 km total; 3,600 km paved, 17,400 km gravel and
improved earth, 7,000 km unimproved earth
_#_Inland waterways: 1,500 km
_#_Pipelines: crude oil, 800 km; refined products, 1,358 km
_#_Ports: Guayaquil, Manta, Puerto Bolivar, Esmeraldas
_#_Merchant marine: 47 ships (1,000 GRT or over) totaling 342,411
GRT/495,482 DWT; includes 1 passenger, 8 cargo, 17 refrigerated cargo,
2 container, 1 roll-on/roll-off cargo, 16 petroleum, oils, and lubricants
(POL) tanker, 1 liquefied gas, 1 bulk
_#_Civil air: 44 major transport aircraft
_#_Airports: 153 total, 151 usable; 46 with permanent-surface runways;
1 with runways over 3,659 m; 6 with runways 2,440-3,659 m; 23 with
runways 1,220-2,439 m
_#_Telecommunications: domestic facilities generally adequate; 318,000
telephones; stations--272 AM, no FM, 33 TV, 39 shortwave; 1 Atlantic
Ocean INTELSAT earth station
_*_Defense Forces
_#_Branches: Army (Ejercito Ecuatoriano), Navy (Armada Ecuatoriana),
Air Force (Fuerza Aerea Ecuatoriana), National Police
_#_Manpower availability: males 15-49, 2,716,919; 1,840,296 fit for
military service; 117,113 reach military age (20) annually
_#_Defense expenditures: $176 million, 1.6% of GDP (1990 est.)
_%_
_@_Egypt','5f7190303252e90acdbd08a750f735cb87530b0dc39cdd501acb0e10a26947d2','internet-archive','theciaworldfactb00025gut','txt','84185fe9df79da427349cc1598fd3f69814a2085a9fc1fe0508a3fae0a870f84','https://archive.org/download/theciaworldfactb00025gut/25.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5e2a6334268c4b70a700b6590529b176d134c897675a253261e4a819ce8464d4',1991,'MX','Mexico','communications',58,'_#_Railroads: 5,110 km total; 4,763 km 1,435-meter standard gauge,
347 km 0.750-meter gauge; 951 km double track; 25 km electrified
_#_Highways: 51,925 km total; 17,900 km paved, 2,500 km gravel,
13,500 km improved earth, 18,025 km unimproved earth
_#_Inland waterways: 3,500 km (including the Nile, Lake Nasser,
Alexandria-Cairo Waterway, and numerous smaller canals in the delta);
Suez Canal, 193.5 km long (including approaches), used by oceangoing
vessels drawing up to 16.1 meters of water
_#_Pipelines: crude oil, 1,171 km; refined products, 596 km; natural
gas, 460 km
_#_Ports: Alexandria, Port Said, Suez, Bur Safajah, Damietta
_#_Merchant marine: 144 ships (1,000 GRT or over) totaling 1,121,534
GRT/1,725,369 DWT; includes 5 passenger, 7 short-sea passenger,
2 passenger-cargo, 85 cargo, 3 refrigerated cargo, 13 roll-on/roll-off
cargo, 14 petroleum, oils, and lubricants (POL) tanker, 15 bulk
_#_Civil air: 43 major transport aircraft
_#_Airports: 91 total, 82 usable; 66 with permanent-surface runways;
2 with runways over 3,659 m; 44 with runways 2,440-3,659 m; 22 with
runways 1,220-2,439 m
_#_Telecommunications: system is large but still inadequate for needs;
principal centers are Alexandria, Cairo, Al Mansurah, Ismailia, and
Tanta; intercity connections by coaxial cable and microwave;
extensive upgrading in progress; 600,000 telephones (est.); stations--25
AM, 5 FM, 47 TV; satellite earth stations--1 Atlantic Ocean INTELSAT, 1
Indian Ocean INTELSAT, 1 INMARSAT, 1 ARABSAT; 4 submarine coaxial
cables; tropospheric scatter to Sudan; radio relay to Libya (may not be
operational); radio relay to Jordan
_*_Defense Forces
_#_Branches: Army, Navy, Air Force, Air Defense Command
_#_Manpower availability: males 15-49, 13,333,285; 8,665,260 fit for
military service; 584,780 reach military age (20) annually
_#_Defense expenditures: $2.8 billion, 7.3% of GDP (1991)
_%_
_@_El Salvador
_#_Railroads: 602 km 0.914-meter gauge, single track
_#_Highways: 10,000 km total; 1,500 km paved, 4,100 km gravel,
4,400 km improved and unimproved earth
_#_Inland waterways: Rio Lempa partially navigable
_#_Ports: Acajutla, Cutuco
_#_Civil air: 7 major transport aircraft
_#_Airports: 116 total, 82 usable; 6 with permanent-surface runways;
none with runways over 3,659 m; 1 with runways 2,440-3,659 m;
5 with runways 1,220-2,439 m
_#_Telecommunications: nationwide trunk radio relay system; connection
into Central American Microwave System; 116,000 telephones; stations--77
AM, no FM, 5 TV, 2 shortwave; 1 Atlantic Ocean INTELSAT earth station
_*_Defense Forces
_#_Branches: Army, Navy, Air Force, National Guard, National Police,
Treasury Police
_#_Manpower availability: males 15-49, 1,220,088; 780,108 fit for
military service; 71,709 reach military age (18) annually
_#_Defense expenditures: $220 million, 3.6% of GDP (1990)
_%_
_@_Equatorial Guinea
_#_Highways: Rio Muni--1,024 km; Bioko--216 km
_#_Ports: Malabo, Bata
_#_Merchant marine: 2 ships (1,000 GRT or over) totaling 6,413
GRT/6,699 DWT; includes 1 cargo and 1 passenger-cargo
_#_Civil air: 1 major transport aircraft
_#_Airports: 4 total, 3 usable; 2 with permanent-surface runways;
none with runways over 3,659 m; 1 with runways 2,440-3,659 m; 1 with
runways 1,220-2,439 m
_#_Telecommunications: poor system with adequate government services;
international communications from Bata and Malabo to African and European
countries; 2,000 telephones; stations--2 AM, no FM, 1 TV; 1 Indian Ocean
INTELSAT earth station
_*_Defense Forces
_#_Branches: Army, Navy, Air Force, National Guard, National Police
_#_Manpower availability: males 15-49, 79,641; 40,369 fit for military
service
_#_Defense expenditures: $NA, 11% of GNP (FY81 est.)
_%_
_@_Ethiopia','9f4badf706a1cfdc353b00db65effe7b2f6a6255c67c347c5d14a1dd87394931','internet-archive','theciaworldfactb00025gut','txt','84185fe9df79da427349cc1598fd3f69814a2085a9fc1fe0508a3fae0a870f84','https://archive.org/download/theciaworldfactb00025gut/25.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9c835b2cfc359e4c21a0afda07f3d964b521adf4483e545d847a7e2e6988cf18',1991,'SA','Saudi Arabia','communications',62,'_#_Railroads: 988 km total; 681 km 1.000-meter gauge; 307 km
0.950-meter gauge (nonoperational)
_#_Highways: 44,300 km total; 3,650 km bituminous, 9,650 km gravel,
3,000 km improved earth, 28,000 km unimproved earth
_#_Ports: Aseb, Mitsiwa
_#_Merchant marine: 13 ships (1,000 GRT or over) totaling 69,398
GRT/89,457 DWT; includes 9 cargo, 1 roll-on/roll off cargo, 1 livestock
carrier, 2 petroleum, oils, and lubricants (POL) tanker
_#_Civil air: 21 major transport aircraft
_#_Airports: 153 total, 111 usable; 9 with permanent-surface runways;
2 with runways over 3,659 m; 13 with runways 2,440-3,659 m; 49 with
runways 1,220-2,439 m
_#_Telecommunications: open-wire and radio relay system adequate for
government use; open-wire to Sudan and Djibouti; radio relay to Kenya and
Djibouti; stations--4 AM, no FM, 1 TV; 45,000 TV sets; 3,300,000 radios;
1 Atlantic Ocean INTELSAT earth station
_*_Defense Forces
_#_Branches: Army, Navy, Air Force, Air Defense, Police Force
_#_Manpower availability: males 15-49, 11,717,614; 6,072,112 fit for
military service; 609,346 reach military age (18) annually
_#_Defense expenditures: $NA, 8.5% of GDP (1988)
_%_
_@_Europa Island
(French possession)
_#_Airports: 1 with runway 1,220 to 2,439 m
_#_Ports: none; offshore anchorage only
_#_Telecommunications: 1 meteorological station
_*_Defense Forces
_#_Note: defense is the responsibility of France
_%_
_@_Falkland Islands
(Islas Malvinas)
(dependent territory of the UK)
_#_Highways: 510 km total; 30 km paved, 80 km gravel, and 400 km
unimproved earth
_#_Ports: Port Stanley
_#_Civil air: no major transport aircraft
_#_Airports: 5 total, 5 usable; 2 with permanent-surface runways;
none with runways over 3,659 m; 1 with runways 2,440-3,659 m;
none with runways 1,220 to 2,439 m
_#_Telecommunications: government-operated radiotelephone and private
VHF/CB radio networks provide effective service to almost all points on
both islands; 590 telephones; stations--2 AM, 3 FM, no TV; 1 Atlantic
Ocean INTELSAT earth station with links through London to other countries
_*_Defense Forces
_#_Branches: British Forces Falkland Islands (including Army, Royal
Air Force, Royal Navy, and Royal Marines); Police Force
_#_Note: defense is the responsibility of the UK
_%_
_@_Faroe Islands
(part of the Danish realm)
_#_Highways: 200 km
_#_Ports: Torshavn, Tvoroyri
_#_Merchant marine: 7 ships (1,000 GRT or over) totaling 17,249
GRT/11,887 DWT; includes 1 short-sea passenger, 2 cargo, 2
roll-on/roll-off cargo, 2 refrigerated cargo; note--a subset of the
Danish register
_#_Airports: 1 with permanent surface runway 1,220-2,439 m
_#_Telecommunications: good international communications; fair
domestic facilities; 27,900 telephones; stations--1 AM, 3 (10 repeaters)
FM, 3 (29 repeaters) TV; 3 coaxial submarine cables
_*_Defense Forces
_#_Branches: no organized native military forces; only a small
Police Force is maintained
_#_Note: defense is the responsibility of Denmark
_%_
_@_Fiji
_#_Railroads: 644 km 0.610-meter narrow gauge, belonging to the
government-owned Fiji Sugar Corporation
_#_Highways: 3,300 km total (1984)--390 km paved; 1,200 km
bituminous-surface treatment; 1,290 km gravel, crushed stone, or
stabilized soil surface; 420 unimproved earth
_#_Inland waterways: 203 km; 122 km navigable by motorized craft and
200-metric-ton barges
_#_Ports: Lambasa, Lautoka, Savusavu, Suva
_#_Merchant marine: 6 ships (1,000 GRT or over) totaling 34,214
GRT/37,161 DWT; includes 2 roll-on/roll-off cargo, 2 container,
1 petroleum, oils, and lubricants (POL) tanker, 1 chemical tanker
_#_Civil air: 1 DC-3 and 1 light aircraft
_#_Airports: 26 total, 24 usable; 2 with permanent-surface runways;
none with runways over 3,659 m; 1 with runways 2,440-3,659 m; 2 with
runways 1,220-2,439 m
_#_Telecommunications: modern local, interisland, and international
(wire/radio integrated) public and special-purpose telephone, telegraph,
and teleprinter facilities; regional radio center; important COMPAC cable
link between US-Canada and New Zealand-Australia; 53,228 telephones;
stations--7 AM, 1 FM, no TV; 1 Pacific Ocean INTELSAT earth station
_*_Defense Forces
_#_Branches: Fiji Military Force (FMF; Army, Navy, Police)
_#_Manpower availability: males 15-49, 190,120; 104,861 fit for
military service; 7,879 reach military age (18) annually
_#_Defense expenditures: $25.8 million, 2.5% of GDP (1988)
_%_
_@_Finland
_#_Railroads: 5,924 km total; Finnish State Railways (VR) operate a
total of 5,863 km 1.524-meter gauge, of which 480 km are multiple track
and 1,445 km are electrified
_#_Highways: about 103,000 km total, including 35,000 km paved
(bituminous, concrete, bituminous-treated surface) and 38,000 km unpaved
(stabilized gravel, gravel, earth); additional 30,000 km of private
(state-subsidized) roads
_#_Inland waterways: 6,675 km total (including Saimaa Canal); 3,700 km
suitable for steamers
_#_Pipelines: natural gas, 580 km
_#_Ports: Helsinki, Oulu, Pori, Rauma, Turku; 6 secondary, numerous
minor ports
_#_Merchant marine: 83 ships (1,000 GRT or over) totaling 807,020
GRT/831,774 DWT; includes 3 passenger, 10 short-sea passenger, 16 cargo,
1 refrigerated cargo, 23 roll-on/roll-off cargo, 14 petroleum, oils, and
lubricants (POL) tanker, 6 chemical tanker, 2 liquefied gas, 8 bulk
_#_Civil air: 42 major transport
_#_Airports: 160 total, 157 usable; 57 with permanent-surface runways;
none with runways over 3,659 m; 23 with runways 2,440-3,659 m;
22 with runways 1,220-2,439 m
_#_Telecommunications: good service from cable and radio relay
network; 3,140,000 telephones; stations--4 AM, 42 (101 relays) FM, 79
(197 relays) TV; 2 submarine cables; satellite service via Swedish earth
stations; earth stations--2 Atlantic Ocean INTELSAT and 1 EUTELSAT
_*_Defense Forces
_#_Branches: Army, Navy, Air Force, Frontier Guard (including
Sea Guard)
_#_Manpower availability: males 15-49, 1,313,346; 1,089,217 fit for
military service; 32,866 reach military age (17) annually
_#_Defense expenditures: $1.1 billion, 1.5% of GDP (1989 est.)
_%_
_@_France
_#_Railroads: French National Railways (SNCF) operates 34,568 km
1.435-meter standard gauge; 11,674 km electrified, 15,132 km double or
multiple track; 2,138 km of various gauges (1.000-meter to 1.440-meter),
privately owned and operated
_#_Highways: 1,551,400 km total; 33,400 km national highway;
347,000 km departmental highway; 421,000 km community roads; 750,000 km
rural roads; 5,401 km of controlled-access divided autoroutes; about
803,000 km paved
_#_Inland waterways: 14,932 km; 6,969 km heavily traveled
_#_Pipelines: crude oil, 3,059 km; refined products, 4,487 km; natural
gas, 24,746 km
_#_Ports: maritime--Bordeaux, Boulogne, Brest, Cherbourg, Dunkerque,
Fos-Sur-Mer, Le Havre, Marseille, Nantes, Rouen, Sete, Toulon;
inland--42
_#_Merchant marine: 133 ships (1,000 GRT or over) totaling 3,141,276
GRT/5,006,695 DWT; includes 8 short-sea passenger, 15 cargo, 18
container, 2 multifunction large-load carrier, 29 roll-on/roll-off cargo,
34 petroleum, oils, and lubricants (POL) tanker, 8 chemical tanker,
6 liquefied gas, 2 specialized tanker, 11 bulk; note--France also
maintains a captive register for French-owned ships in the Kerguelen
Islands (French Southern and Antarctic Lands) and French Polynesia
_#_Civil air: 195 (1989 est.)
_#_Airports: 470 total, 460 usable; 246 with permanent-surface
runways; 3 with runways over 3,659 m; 34 with runways 2,440-3,659 m;
136 with runways 1,220-2,439 m
_#_Telecommunications: highly developed system provides satisfactory
telephone, telegraph, radio and TV broadcast services; 39,200,000
telephones; stations--40 AM, 138 (777 relays) FM, 216 (8,902 relays) TV;
25 submarine coaxial cables; communication satellite earth stations
operating in INTELSAT, 3 Atlantic Ocean and 2 Indian Ocean, EUTELSAT,
MARISAT, and domestic systems
_*_Defense Forces
_#_Branches: Army, Navy (including Naval Air), Air Force, National
Gendarmerie
_#_Manpower availability: males 15-49, 14,366,492; 12,077,706 fit for
military service; 395,128 reach military age (18) annually
_#_Defense expenditures: $29.7 billion, 3.6% of GDP (1990)
_%_
_@_French Guiana
(overseas department of France)
_#_Railroads: 886 km 1.435-meter standard gauge
_#_Highways: 74,000 km total; 35,000 km bituminous, 39,000 km gravel
and improved earth
_#_Pipelines: 6,400 km crude oil; 150 km refined products; 2,200 km
natural gas, includes 1,600 km of natural gas liquids
_#_Ports: Jiddah, Ad Dammam, Ras Tanura, Jizan, Al Jubayl,
Yanbu al Bahr, Yanbu al Sinaiyah
_#_Merchant marine: 84 ships (1,000 GRT or over) totaling 1,492,174
GRT/2,436,635 DWT; includes 1 passenger, 6 short-sea passenger,
14 cargo, 12 roll-on/roll-off cargo, 3 container, 6 refrigerated cargo, 5
livestock carrier, 26 petroleum, oils, and lubricants (POL) tanker, 8
chemical tanker, 1 liquefied gas, 1 specialized tanker, 1 bulk
_#_Civil air: 182 major transport aircraft available
_#_Airports: 207 total, 188 usable; 69 with permanent-surface runways;
13 with runways over 3,659 m; 38 with runways 2,440-3,659 m; 103 with
runways 1,220-2,439 m
_#_Telecommunications: good system with extensive microwave and
coaxial cable systems; 1,624,000 telephones; stations--21 AM, 16 FM,
97 TV; radio relay to Bahrain, Jordan, Kuwait, Qatar, UAE, Yemen, and
Sudan; coaxial cable to Kuwait; submarine cable to Djibouti and Egypt;
earth stations--3 Atlantic Ocean INTELSAT, 2 Indian Ocean INTELSAT,
1 ARABSAT, 1 INMARSAT, 1 ARABSAT
_*_Defense Forces
_#_Branches: Army, Navy, Air Force, Air Defense Force, National
Guard, Coast Guard, Frontier Force, Special Security Force, Public
Security Force
_#_Manpower availability: males 15-49, 6,663,217; 3,724,610 fit for
military service; 165,167 reach military age (17) annually
_#_Defense expenditures: $13.9 billion, 16.9% of GDP (1990 est.)
_%_
_@_Senegal
_#_Railroads: 1,034 km 1.000-meter gauge; all single track except
70 km double track Dakar to Thies
_#_Highways: 14,000 km total; 3,770 km paved, 10,230 km laterite or
improved earth
_#_Inland waterways: 900 km total; 785 km on the Senegal, 115 km
on the Saloum
_#_Ports: Dakar, Kaolack
_#_Merchant marine: 3 ships (1,000 GRT and over) totaling 9,263
GRT/15,167 DWT; includes 2 cargo, 1 bulk
_#_Civil air: 2 major transport aircraft
_#_Airports: 25 total, 20 usable; 10 with permanent-surface runways;
none with runways over 3,659 m; 1 with runways 2,440-3,659 m;
15 with runways 1,220-2,439 m
_#_Telecommunications: above-average urban system, using radio relay
and cable; 40,200 telephones; stations--8 AM, no FM, 1 TV; 3 submarine
cables; 1 Atlantic Ocean INTELSAT earth station
_*_Defense Forces
_#_Branches: Army, Navy, Air Force, paramilitary Gendarmerie;
Surete Nationale
_#_Manpower availability: males 15-49, 1,749,540; 913,806 fit for
military service; 91,607 reach military age (18) annually
_#_Defense expenditures: $100 million, 2% of GDP (1989 est.)
_%_
_@_Seychelles
_#_Highways: 260 km total; 160 km bituminous, 100 km crushed stone or
earth
_#_Ports: Victoria
_#_Merchant marine: 1 refrigerated cargo (1,000 GRT or over) totaling
1,827 GRT/2,170 DWT
_#_Civil air: 3 major transport aircraft
_#_Airports: 14 total, 14 usable; 8 with permanent-surface runways;
none with runways over 3,659 m; 1 with runways 2,440-3,659 m;
none with runways 1,220-2,439 m
_#_Telecommunications: direct radio communications with adjacent
islands and African coastal countries; 13,000 telephones; stations--2 AM,
no FM, 1 TV; 1 Indian Ocean INTELSAT earth station; USAF tracking station
_*_Defense Forces
_#_Branches: Army, Navy, Air Force, Presidential Protection Unit,
Police Force, Militia
_#_Manpower availability: males 15-49, 17,399; 8,933 fit for military
service
_#_Defense expenditures: $12 million, 6% of GDP (1990 est.)
_%_
_@_Sierra Leone
_#_Railroads: 84 km 1.067-meter narrow-gauge mineral line is used on a
limited basis because the mine at Marampa is closed
_#_Highways: 7,400 km total; 1,150 km bituminous, 490 km laterite
(some gravel), remainder improved earth
_#_Inland waterways: 800 km; 600 km navigable year round
_#_Ports: Freetown, Pepel
_#_Civil air: no major transport aircraft
_#_Airports: 12 total, 8 usable; 5 with permanent-surface runways;
none with runways over 3,659 m; 1 with runways 2,440-3,659 m;
3 with runways 1,220-2,439 m
_#_Telecommunications: marginal telephone and telegraph service;
national microwave radio relay system unserviceable at present; 23,650
telephones; stations--1 AM, 1 FM, 1 TV; 1 Atlantic Ocean INTELSAT earth
station
_*_Defense Forces
_#_Branches: Army, Navy, Police
_#_Manpower availability: males 15-49, 939,214; 453,877 fit for
military service; no conscription
_#_Defense expenditures: $6 million, 0.7% of GDP (1988 est.)
_%_
_@_Singapore
_#_Railroads: 38 km of 1.000-meter gauge
_#_Highways: 2,597 km total (1984)
_#_Ports: Singapore
_#_Merchant marine: 435 ships (1,000 GRT or over) totaling 8,259,085
GRT/13,553,438 DWT; includes 1 passenger-cargo, 121 cargo, 66 container,
6 roll-on/roll-off cargo, 11 refrigerated cargo, 18 vehicle carrier,
1 livestock carrier, 118 petroleum, oils, and lubricants (POL) tanker, 5
chemical tanker, 3 combination ore/oil, 1 specialized tanker, 7 liquefied
gas, 75 bulk, 2 combination bulk; note--many Singapore flag ships are
foreign owned
_#_Civil air: 38 major transport aircraft (est.)
_#_Airports: 9 total, 9 usable; 9 with permanent-surface runways;
2 with runways over 3,659 m; 4 with runways 2,440-3,659 m; 2 with runways
1,220-2,439 m
_#_Telecommunications: good domestic facilities; good international
service; good radio and television broadcast coverage; 1,110,000
telephones; stations--13 AM, 4 FM, 2 TV; submarine cables extend to
Malaysia (Sabah and peninsular Malaysia), Indonesia, and the Philippines;
satellite earth stations--1 Indian Ocean INTELSAT and 1 Pacific Ocean
INTELSAT
_*_Defense Forces
_#_Branches: Army, Navy, Air Force, People''s Defense Force, Police
Force
_#_Manpower availability: males 15-49, 842,721; 625,546 fit for
military service
_#_Defense expenditures: $1.7 billion, 4% of GDP (1990 est.)
_%_
_@_Solomon Islands
_#_Highways: about 2,100 km total (1982); 30 km sealed, 290 km gravel,
980 km earth, 800 private logging and plantation roads of varied
construction
_#_Ports: Honiara, Ringi Cove
_#_Civil air: no major transport aircraft
_#_Airports: 31 total, 29 usable; 2 with permanent-surface runways;
none with runways over 2,439 m; 2 with runways 1,220-2,439 m
_#_Telecommunications: 3,000 telephones; stations--4 AM, no FM, no TV;
1 Pacific Ocean INTELSAT earth station
_*_Defense Forces
_#_Branches: Police Force
_#_Manpower availability: males 15-49, 77,169; NA fit for military
service
_#_Defense expenditures: $NA, NA% of GDP
_%_
_@_Somalia
_#_Highways: 15,215 km total; including 2,335 km bituminous surface,
2,880 km gravel, and 10,000 km improved earth or stabilized soil (1983)
_#_Pipelines: 15 km crude oil
_#_Ports: Mogadishu, Berbera, Chisimayu
_#_Merchant marine: 3 ships (1,000 GRT or over) totaling 6,913
GRT/9,457 DWT; includes 2 cargo, 1 refrigerated cargo
_#_Civil air: 2 major transport aircraft
_#_Airports: 61 total, 46 usable; 8 with permanent-surface runways;
2 with runways over 3,659 m; 5 with runways 2,440-3,659 m; 22 with
runways 1,220-2,439 m
_#_Telecommunications: minimal telephone and telegraph service; radio
relay and troposcatter system centered on Mogadishu connects a few towns;
6,000 telephones; stations--2 AM, no FM, 1 TV; 1 Indian Ocean INTELSAT
earth station; scheduled to receive an ARABSAT station
_*_Defense Forces
_#_Branches: Somali National Army (including Navy, Air Force, and
Air Defense Force), National Police Force, National Security Service
_#_Manpower availability: males 15-49, 1,601,690; 902,732 fit for
military service
_#_Defense expenditures: $NA, NA% of GDP
_%_
_@_South Africa
_#_Railroads: 20,638 km route distance total; 35,079 km of 1.067-meter
gauge trackage (counts double and multiple tracking as single track);
314 km of 610 mm gauge
_#_Highways: 188,309 km total; 54,013 km paved, 134,296 km crushed
stone, gravel, or improved earth
_#_Pipelines: 931 km crude oil; 1,748 km refined products; 322 km
natural gas
_#_Ports: Durban, Cape Town, Port Elizabeth, Richard''s Bay, Saldanha,
Mosselbaai, Walvis Bay
_#_Merchant marine: 7 ships (1,000 GRT or over) totaling 229,245
GRT/218,929 DWT; includes 6 container, 1 vehicle carrier
_#_Civil air: 81 major transport aircraft
_#_Airports: 917 total, 765 usable; 130 with permanent-surface
runways; 5 with runways over 3,659 m; 10 with runways 2,440-3,659 m; 224
with runways 1,220-2,439 m
_#_Telecommunications: the system is the best developed, most modern,
and has the highest capacity in Africa; it consists of carrier-equipped
open-wire lines, coaxial cables, radio relay links, fiber optic cable,
and radiocommunication stations; key centers are Bloemfontein, Cape Town,
Durban, Johannesburg, Port Elizabeth, and Pretoria; 4,500,000 telephones;
stations--14 AM, 286 FM, 67 TV; 1 submarine cable; earth
stations--1 Indian Ocean INTELSAT and 2 Atlantic Ocean INTELSAT
_*_Defense Forces
_#_Branches: Army, Navy, Air Force, Medical Services
_#_Manpower availability: males 15-49, 9,797,349; 5,980,786 fit for
military service; 426,615 reach military age (18) annually; obligation
for service in Citizen Force or Commandos begins at 18; volunteers for
service in permanent force must be 17; national service obligation is
one year; figures include the so-called homelands not recognized by
the US
_#_Defense expenditures: $3.67 billion, 11% of GDP (FY92)
_%_
_@_South Georgia and the South Sandwich Islands
(dependent territory of the UK)
_#_Highways: NA
_#_Ports: Grytviken on South Georgia
_#_Airports: 5 total, 5 usable; 2 with permanent-surface runways;
1 with runway 2,440-3,659 m
_#_Telecommunications: coastal radio station at Grytviken; no
broadcast stations
_*_Defense Forces
_#_Note: defense is the responsibility of the UK
_%_
_@_Soviet Union
_#_Railroads: 147,400 km total; 53,900 km electrified; does not
include industrial lines (1989)
_#_Highways: 1,757,000 km total; 1,310,600 km hard-surfaced (asphalt,
concrete, stone block, asphalt treated, gravel, crushed stone);
446,400 km earth (1989)
_#_Inland waterways: 123,700 km navigable, exclusive of Caspian
Sea (1989)
_#_Pipelines: 82,000 km crude oil and refined products; 206,500 km
natural gas (1987)
_#_Ports: St. Petersburg (formerly Leningrad), Riga, Tallinn,
Kaliningrad, Liepaja, Ventspils, Murmansk, Arkhangel''sk, Odessa,
Novorossiysk, Il''ichevsk, Nikolayev, Sevastopol'', Vladivostok, Nakhodka;
inland ports are Astrakhan'', Baku, Nizhniy Novgorod (Gor''kiy), Kazan'',
Khabarovsk, Krasnoyarsk, Kuybyshev, Moscow, Rostov, Volgograd, Kiev
_#_Merchant marine: 1,565 ships (1,000 GRT or over) totaling
15,243,228 GRT/20,874,488 DWT; includes 52 passenger, 898 cargo,
52 container, 11 barge carrier, 4 roll-on/float off cargo, 5 railcar
carrier, 114 roll-on/roll-off cargo, 230 petroleum, oils, and lubricants
(POL) tanker, 5 liquefied gas, 17 combination ore/oil, 4 specialized
liquid carrier, 13 chemical tanker, 160 bulk; note--594 merchant ships
are based in Black Sea, 366 in Baltic Sea, 398 in Soviet Far East, and
207 in Barents Sea and White Sea; the Soviet Union has been transferring
merchant ships to a variety of flags of convenience; at the beginning
of 1991 the USSR had 64 ships under foreign flags (Cyprus 52, Malta 7,
Panama 2, Vanuatu 2, and Honduras 1)
_#_Civil air: 4,000 major transport aircraft
_#_Airports: 7,192 total, 4,607 usable; 1,163 with permanent-surface
runways; 33 with runways over 3,659 m; 491 with runways 2,440-3,659 m;
661 with runways 1,220-2,439 m
_#_Telecommunications: 37 million telephone subscribers; phone
density of 37 per 100 households; urban phone density is 9.2 phones
per 100 residents; rural phone density is 2.9 per 100 residents (June
1990);
automatic telephone dialing with 70 countries and between 25 Soviet
cities (April 1989);
stations--457 AM, 131 FM, over 900 TV; 90 million TVs (December 1990)
_*_Defense Forces
_#_Branches: Ground Forces, Navy, Air Forces, Air Defense Forces,
Strategic Rocket Forces, Command and General Support, Security Forces
_#_Manpower availability: males 15-49, 70,058,651; 55,931,817 fit for
military service; 2,265,935 reach military age (18) annually
(down somewhat from 2,500,000 a decade ago); approximately 35-40% receive
deferments for health, education, or other reasons
_#_Defense expenditures: 63.9 billion rubles, NA% of GDP
_%_
_@_Spain
_#_Railroads: 15,430 km total; Spanish National Railways (RENFE)
operates 12,691 km 1.668-meter gauge, 6,184 km electrified, and
2,295 km double track; FEVE (government-owned narrow-gauge railways)
operates 1,821 km of predominantly 1.000-meter gauge and 441 km
electrified; privately owned railways operate 918 km of predominantly
1.000-meter gauge, 512 km electrified, and 56 km double track
_#_Highways: 150,839 km total; 82,513 km national (includes 2,433 km
limited-access divided highway, 63,042 km bituminous treated, 17,038 km
intermediate bituminous, concrete, or stone block) and 68,326 km
provincial or local roads (bituminous treated, intermediate bituminous,
or stone block)
_#_Inland waterways: 1,045 km, but of minor economic importance
_#_Pipelines: 265 km crude oil; 1,794 km refined products; 1,666 km
natural gas
_#_Ports: Algeciras, Alicante, Almeria, Barcelona, Bilbao, Cadiz,
Cartagena, Castellon de la Plana, Ceuta, El Ferrol del Caudillo,
Puerto de Gijon, Huelva, La Coruna, Las Palmas (Canary Islands),
Mahon, Malaga, Melilla, Rota, Santa Cruz de Tenerife, Sagunto,
Tarragona, Valencia, Vigo, and 175 minor ports
_#_Merchant marine: 304 ships (1,000 GRT or over) totaling 3,367,529
GRT/5,984,306 DWT; includes 2 passenger, 9 short-sea passenger,
105 cargo, 17 refrigerated cargo, 14 container, 29 roll-on/roll-off
cargo, 4 vehicle carrier, 50 petroleum, oils, and lubricants (POL)
tanker, 14 chemical tanker, 7 liquefied gas, 1 combination ore/oil,
4 specialized tanker, 48 bulk
_#_Civil air: 172 major transport aircraft
_#_Airports: 104 total, 98 usable; 61 with permanent-surface runways;
4 with runways over 3,659 m; 22 with runways 2,440-3,659 m; 25 with
runways 1,220-2,439 m
_#_Telecommunications: generally adequate, modern facilities;
15,350,464 telephones; stations--206 AM, 411 (134 relays) FM, 143
(1,297 relays) TV; 17 coaxial submarine cables; communications
satellite earth stations operating in INTELSAT (5 Atlantic Ocean,
1 Indian Ocean), MARISAT, and ENTELSAT systems
_*_Defense Forces
_#_Branches: Army, Navy, Air Force, Marines, Civil Guard
_#_Manpower availability: males 15-49, 10,134,256; 8,222,987 fit for
military service; 339,749 reach military age (20) annually
_#_Defense expenditures: $8.6 billion, 2% of GDP (1990)
_%_
_@_Spratly Islands
_#_Airports: 3 total, 2 usable; none with runways over 2,439 m;
1 with runways 1,220-2,439 m
_#_Ports: no natural harbors
_*_Defense Forces
_#_Note: approximately 50 small islands or reefs are occupied
by China, Malaysia, the Philippines, Taiwan, and Vietnam
_%_
_@_Sri Lanka
_#_Railroads: 1,948 km total (1989); all 1.868-meter broad gauge;
102 km double track; no electrification; government owned
_#_Highways: 75,263 km total (1988); 27,637 km paved (mostly
bituminous treated), 32,887 km crushed stone or gravel, 14,739 km
improved earth or unimproved earth; several thousand km of mostly
unmotorable tracks (1988 est.)
_#_Inland waterways: 430 km; navigable by shallow-draft craft
_#_Pipelines: crude and refined products, 62 km (1987)
_#_Ports: Colombo, Trincomalee
_#_Merchant marine: 34 ships (1,000 GRT or over) totaling 364,466
GRT/551,686 DWT; includes 18 cargo, 6 refrigerated cargo, 5 container,
2 petroleum, oils, and lubricants (POL) tanker, 3 bulk
_#_Civil air: 8 major transport (including 1 leased)
_#_Airports: 14 total, 13 usable; 12 with permanent-surface runways;
none with runways over 3,659 m; 1 with runways 2,440-3,659 m;
7 with runways 1,220-2,439 m
_#_Telecommunications: good international service; 1','66d4ab4d717d133b8e0ba18459b2ae366c61bf8b7b92a1b5e9d1a63fa5bfce46','internet-archive','theciaworldfactb00025gut','txt','84185fe9df79da427349cc1598fd3f69814a2085a9fc1fe0508a3fae0a870f84','https://archive.org/download/theciaworldfactb00025gut/25.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('72cc2d24ba36368e5258c855c25c653996c0ae7839ef46033038af1948def1dc',1991,'SA','Saudi Arabia','communications',63,'14,000 telephones
(1982); stations--12 AM, 5 FM, 5 TV; submarine cables extend to
Indonesia and Djibouti; 2 Indian Ocean INTELSAT earth stations
_*_Defense Forces
_#_Branches: Army, Navy, Air Force, Police Force
_#_Manpower availability: males 15-49, 4,636,767; 3,625,289 fit for
military service; 178,010 reach military age (18) annually
_#_Defense expenditures: $300 million, 5% of GDP (1991)
_%_
_@_Sudan
_#_Railroads: 5,500 km total; 4,784 km 1.067-meter gauge, 716 km
1.6096-meter-gauge plantation line
_#_Highways: 20,000 km total; 1,600 km bituminous treated,
3,700 km gravel, 2,301 km improved earth, 12,399 km unimproved earth
and track
_#_Inland waterways: 5,310 km navigable
_#_Pipelines: refined products, 815 km
_#_Ports: Port Sudan, Suakin
_#_Merchant marine: 5 ships (1,000 GRT or over) totaling 42,277
GRT/59,588 DWT; includes 3 cargo, 2 roll-on/roll-off cargo
_#_Civil air: 14 major transport aircraft
_#_Airports: 78 total, 66 usable; 8 with permanent-surface runways;
none with runways over 3,659 m; 4 with runways 2,440-3,659 m;
30 with runways 1,220-2,439 m
_#_Telecommunications: large, well-equipped system by African
standards, but barely adequate and poorly maintained; consists of
radio relay, cables, radio communications, and troposcatter; domestic
satellite system with 14 stations; 73,400 telephones; stations--4 AM,
1 FM, 2 TV; earth stations--1 Atlantic Ocean INTELSAT and 1 ARABSAT
_*_Defense Forces
_#_Branches: Army, Navy, Air Force, Air Defense Force
_#_Manpower availability: males 15-49, 6,176,917; 3,792,635 fit for
military service; 306,695 reach military age (18) annually
_#_Defense expenditures: $610 million, 7.2% of GDP (1989 est)
_%_
_@_Suriname
_#_Railroads: 166 km total; 86 km 1.000-meter gauge, government owned,
and 80 km 1.435-meter standard gauge; all single track
_#_Highways: 8,300 km total; 500 km paved; 5,400 km bauxite gravel,
crushed stone, or improved earth; 2,400 km sand or clay
_#_Inland waterways: 1,200 km; most important means of transport;
oceangoing vessels with drafts ranging from 4.2 m to 7 m can navigate
many of the principal waterways
_#_Ports: Paramaribo, Moengo
_#_Merchant marine: 3 ships (1,000 GRT or over) totaling
6,472 GRT/8,914 DWT; includes 2 cargo, 1 container
_#_Civil air: 2 major transport aircraft
_#_Airports: 46 total, 42 usable; 6 with permanent-surface runways;
none with runways over 3,659 m; 1 with runways 2,440-3,659 m;
1 with runways 1,220-2,439 m
_#_Telecommunications: international facilities good; domestic radio
relay system; 27,500 telephones; stations--5 AM, 14 FM, 6 TV, 1
shortwave; 2 Atlantic Ocean INTELSAT earth stations
_*_Defense Forces
_#_Branches: National Army (including Navy which is company-size,
small Air Force element), Civil Police
_#_Manpower availability: males 15-49, 107,544; 64,146 fit for
military service
_#_Defense expenditures: $91 million, 7.2% of GDP (1990 est.)
_%_
_@_Svalbard
(territory of Norway)
_#_Ports: limited facilities--Ny-Alesund, Advent Bay
_#_Airports: 4 total, 4 usable; 1 with permanent-surface runways;
none with runways over 2,439 m; 1 with runways 1,220-2,439 m
_#_Telecommunications: 5 meteorological/radio stations;
stations--1 AM, 1 (2 relays) FM, 1 TV
_*_Defense Forces
_#_Note: demilitarized by treaty (9 February 1920)
_%_
_@_Swaziland
_#_Railroads: 297 km plus 71 km disused, 1.067-meter gauge, single
track
_#_Highways: 2,853 km total; 510 km paved, 1,230 km crushed stone,
gravel, or stabilized soil, and 1,113 km improved earth
_#_Civil air: 1 major transport aircraft
_#_Airports: 23 total, 22 usable; 1 with permanent-surfaced runways;
none with runways over 3,659 m; 1 with runways 2,440-3,659 m;
1 with runways 1,220-2,439 m
_#_Telecommunications: system consists of carrier-equipped open-wire
lines and low-capacity radio relay links; 15,400 telephones;
stations--6 AM, 6 FM, 10 TV; 1 Atlantic Ocean INTELSAT earth station
_*_Defense Forces
_#_Branches: Umbutfo Swaziland Defense Force, Royal Swaziland Police
Force
_#_Manpower availability: males 15-49, 185,562; 107,254 fit for
military service
_#_Defense expenditures: $8 million, 1.3% of GDP (1988)
_%_
_@_Sweden
_#_Railroads: 12,000 km total; Swedish State Railways (SJ)--10,819 km
1.435-meter standard gauge, 6,955 km electrified and 1,152 km double
track; 182 km 0.891-meter gauge; 117 km rail ferry service; privately
owned railways--511 km 1.435-meter standard gauge (332 km electrified);
371 km 0.891-meter gauge (all electrified)
_#_Highways: 97,400 km (51,899 km paved, 20,659 km gravel, 24,842 km
unimproved earth)
_#_Inland waterways: 2,052 km navigable for small steamers and barges
_#_Pipelines: 84 km natural gas
_#_Ports: Gavle, Goteborg, Halmstad, Helsingborg, Kalmar, Malmo,
Stockholm; numerous secondary and minor ports
_#_Merchant marine: 182 ships (1,000 GRT or over) totaling 2,226,923
GRT/2,879,057 DWT; includes 9 short-sea passenger, 29 cargo, 3 container,
45 roll-on/roll-off cargo, 11 vehicle carrier, 2 railcar carrier,
28 petroleum, oils, and lubricants (POL) tanker, 27 chemical tanker,
6 specialized tanker, 1 liquefied gas, 8 combination ore/oil,
12 bulk, 1 combination bulk
_#_Civil air: 115 major transports
_#_Airports: 256 total, 254 usable; 137 with permanent-surface
runways; none with runways over 3,659 m; 10 with runways 2,440-3,659 m;
92 with runways 1,220-2,439 m
_#_Telecommunications: excellent domestic and international
facilities; 8,200,000 telephones; stations--4 AM, 56 (321 relays) FM,
111 (925 relays) TV; 5 submarine coaxial cables; communication satellite
earth stations operating in the INTELSAT (1 Atlantic Ocean) and EUTELSAT
systems
_*_Defense Forces
_#_Branches: Swedish Army, Royal Swedish Navy, Royal Swedish Air Force
_#_Manpower availability: males 15-49, 2,136,227; 1,865,645 fit for
military service; 55,198 reach military age (19) annually
_#_Defense expenditures: $4.9 billion, 2.5% of GDP (FY90)
_%_
_@_Switzerland
_#_Railroads: 5,174 km total; 2,971 km are government owned
and 2,203 km are nongovernment owned; the government network consists
of 2,897 km 1.435-meter standard gauge and 74 km 1.000-meter narrow
gauge track; 1,432 km double track, 99% electrified; the nongovernment
network consists of 710 km 1.435-meter standard gauge, 1,418 km
1.000-meter gauge, and 75 km 0.790-meter gauge track, 100% electrified
_#_Highways: 62,145 km total (all paved), of which 18,620 km are
canton and 1,057 km are national highways (740 km autobahn); 42,468 km
are communal roads
_#_Pipelines: 314 km crude oil; 1,506 km natural gas
_#_Inland waterways: 65 km; Rhine (Basel to Rheinfelden, Schaffhausen
to Bodensee); 12 navigable lakes
_#_Ports: Basel (river port)
_#_Merchant marine: 20 ships (1,000 GRT or over) totaling 258,678
GRT/441,555 DWT; includes 6 cargo, 2 roll-on/roll-off cargo, 3 chemical
tanker, 2 specialized tanker, 7 bulk
_#_Civil air: 89 major transport aircraft
_#_Airports: 67 total, 65 usable; 42 with permanent-surface runways;
2 with runways over 3,659 m; 6 with runways 2,440-3,659 m; 17 with
runways 1,220-2,439 m
_#_Telecommunications: excellent domestic, international, and
broadcast services; 5,890,000 telephones; stations--6 AM, 36 (400
relays) FM, 145 (1,250 relays) TV; communications satellite earth
stations operating in the INTELSAT (4 Atlantic Ocean and 1 Indian
Ocean) and EUTELSAT systems
_*_Defense Forces
_#_Branches: Army, Air Force, Frontier Guards, Fortification Guards
_#_Manpower availability: males 15-49, 1,802,005; 1,549,347 fit for
military service; 42,619 reach military age (20) annually
_#_Defense expenditures: $4.6 billion, 2% of GDP (1990)
_%_
_@_Syria
_#_Railroads: 2,241 km total; 1,930 km standard gauge, 311 km
1.050-meter narrow gauge; note--the Tartus-Latakia line is nearly
complete
_#_Highways: 27,000 km total; 21,000 km paved, 3,000 km gravel or
crushed stone, 3,000 km improved earth
_#_Inland waterways: 672 km; of little economic importance
_#_Pipelines: 1,304 km crude oil; 515 km refined products
_#_Ports: Tartus, Latakia, Baniyas
_#_Merchant marine: 22 ships (1,000 GRT or over) totaling 61,951
GRT/86,552 DWT; includes 18 cargo, 2 roll-on/roll-off cargo, 1 vehicle
carrier, 1 bulk
_#_Civil air: 35 major transport aircraft
_#_Airports: 99 total, 96 usable; 24 with permanent-surface runways;
none with runways over 3,659 m; 21 with runways 2,440-3,659 m;
4 with runways 1,220-2,439 m
_#_Telecommunications: fair system currently undergoing significant
improvement; 512,600 telephones; stations--9 AM, 1 FM, 40 TV; satellite
earth stations--1 Indian Ocean INTELSAT earth station, with 1
Intersputnik station under construction; 1 submarine cable; coaxial
cable and radio relay to Iraq, Jordan, Turkey, and Lebanon (inactive)
_*_Defense Forces
_#_Branches: Syrian Arab Army, Syrian Arab Navy, Syrian Arab Air
Force, Syrian Arab Air Defense Forces, Police and Security Force
_#_Manpower availability: males 15-49, 2,825,214; 1,584,887 fit for
military service; 149,105 reach military age (19) annually
_#_Defense expenditures: $1.6 billion, 10.9% of GDP (1988 est.)
_%_
_@_Tanzania
_#_Railroads: 3,555 km total; 960 km 1.067-meter gauge; 2,595 km
1.000-meter gauge, 6.4 km double track, 962 km Tazara Railroad
1.067-meter gauge; 115 km 1.000-meter gauge planned by end of decade
_#_Highways: total 81,900 km, 3,600 km paved; 5,600 km gravel or
crushed stone; remainder improved and unimproved earth
_#_Pipelines: 982 km crude oil
_#_Inland waterways: Lake Tanganyika, Lake Victoria, Lake Nyasa
_#_Ports: Dar es Salaam, Mtwara, Tanga, and Zanzibar are ocean ports;
Mwanza on Lake Victoria and Kigoma on Lake Tanganyika are inland ports
_#_Merchant marine: 7 ships (1,000 GRT or over) totaling 20,784
GRT/25,860 DWT; includes 2 passenger-cargo, 3 cargo, 1 roll-on/roll-off
cargo, 1 petroleum, oils, and lubricants (POL) tanker
_#_Civil air: 6 major transport aircraft
_#_Airports: 105 total, 93 usable; 12 with permanent-surface runways;
none with runways over 3,659 m; 3 with runways 2,440-3,659 m;
44 with runways 1,220-2,439 m
_#_Telecommunications: fair system of open wire, radio relay, and
troposcatter; 103,800 telephones; stations--12 AM, 4 FM, 2 TV; 1
Indian Ocean INTELSAT earth station
_*_Defense Forces
_#_Branches: Tanzanian People''s Defense Force (TPDF; including Army,
Navy, and Air Force); paramilitary Police Field Force Unit; Militia
_#_Manpower availability: males 15-49, 5,545,022; 3,200,744 fit for
military service
_#_Defense expenditures: $111 million, 3.9% of GDP (1988)
_%_
_@_Thailand','160b21bc61c699c000a60093791af782fa5f73da226974cc6b2f1fadb574002f','internet-archive','theciaworldfactb00025gut','txt','84185fe9df79da427349cc1598fd3f69814a2085a9fc1fe0508a3fae0a870f84','https://archive.org/download/theciaworldfactb00025gut/25.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c8607889bd0e112d4ca7e79e5bd8350ac266315d5c0511b7ea8b004341e4e4ea',1991,'GF','French Guiana','communications',76,'_#_Highways: 680 km total; 510 km paved, 170 km improved and
unimproved earth
_#_Inland waterways: 460 km, navigable by small oceangoing vessels and
river and coastal steamers; 3,300 km possibly navigable by native craft
_#_Ports: Cayenne
_#_Civil air: no major transport aircraft
_#_Airports: 10 total, 10 usable; 5 with permanent-surface runways;
none with runways over 3,659 m; 1 with runways 2,440-3,659 m; 1 with
runways 1,220-2,439 m
_#_Telecommunications: fair open wire and radio relay system;
18,100 telephones; stations--5 AM, 7 FM, 9 TV; 1 Atlantic Ocean
INTELSAT earth station
_*_Defense Forces
_#_Branches: French Forces, Gendarmerie
_#_Manpower availability: males 15-49 28,650; 18,903 fit for military
service
_#_Note: defense is the responsibility of France
_%_
_@_French Polynesia
(overseas territory of France)
_#_Highways: 600 km (1982)
_#_Ports: Papeete, Bora-bora
_#_Merchant marine: 3 ships (1,000 GRT or over) totaling 4,128
GRT/6,710 DWT; includes 1 passenger-cargo, 1 cargo, 1 refrigerated cargo;
note--a captive subset of the French register
_#_Civil air: about 6 major transport aircraft
_#_Airports: 43 total, 41 usable; 23 with permanent-surface runways;
none with runways over 3,659 m; 2 with runways 2,440-3,659 m; 12 with
runways 1,220-2,439 m
_#_Telecommunications: 33,200 telephones; 84,000 radio receivers;
26,400 TV sets; stations--5 AM, 2 FM, 6 TV; 1 Pacific Ocean INTELSAT
earth station
_*_Defense Forces
_#_Manpower availability: males 15-49, 50,844; NA fit for military
service
_#_Note: defense is responsibility of France
_%_
_@_French Southern and Antarctic Lands
(overseas territory of France)
_#_Ports: none; offshore anchorage only
_#_Merchant marine: 12 ships (1,000 GRT or over) totaling
220,392 GRT/350,131 DWT; includes 2 cargo, 3 refrigerated cargo,
2 roll-on/roll-off cargo, 1 petroleum, oils, and lubricants (POL) tanker,
2 liquefied gas, 2 bulk; note--a captive subset of the French register
_#_Telecommunications: NA
_*_Defense Forces
_#_Branches: French Forces (including Army, Navy, Air Force)
_#_Note: defense is the responsibility of France
_%_
_@_Gabon
_#_Railroads: 649 km 1.437-meter standard-gauge single track
(Transgabonese Railroad)
_#_Highways: 7,500 km total; 560 km paved, 960 km laterite, 5,980 km
earth
_#_Inland waterways: 1,600 km perennially navigable
_#_Pipelines: crude oil, 270 km; refined products, 14 km
_#_Ports: Owendo, Port-Gentil, Libreville
_#_Merchant marine: 2 cargo ships (1,000 GRT or over) totaling 18,563
GRT/25,330 DWT
_#_Civil air: 11 major transport aircraft
_#_Airports: 73 total, 61 usable; 10 with permanent-surface runways;
none with runways over 3,659 m; 2 with runways 2,440-3,659 m; 22 with
runways 1,220-2,439 m
_#_Telecommunications: adequate system of open-wire, radio relay,
tropospheric scatter links and radiocommunication stations; 13,800
telephones; stations--6 AM, 6 FM, 8 TV; satellite earth stations--2
Atlantic Ocean INTELSAT and 12 domestic satellite
_*_Defense Forces
_#_Branches: Army, Navy, Air Force, Presidential Guard, paramilitary
Gendarmerie, National Police
_#_Manpower availability: males 15-49, 266,472; 133,648 fit for
military service; 9,634 reach military age (20) annually
_#_Defense expenditures: $102 million, 3.2% of GDP (1990 est.)
_%_
_@_The Gambia
_#_Highways: 3,083 km total; 431 km paved, 501 km gravel/laterite,
and 2,151 km unimproved earth
_#_Inland waterways: 400 km
_#_Ports: Banjul
_#_Civil air: 2 major transport aircraft
_#_Airports: 1 with permanent-surface runway 2,440-3,659 m
_#_Telecommunications: adequate network of radio relay and wire;
3,500 telephones; stations--3 AM, 2 FM, 1 TV; 1 Atlantic Ocean
INTELSAT earth station
_*_Defense Forces
_#_Branches: Army, Navy, paramilitary Gendarmerie, National Police
_#_Manpower availability: males 15-49, 188,393; 95,133 fit for
military service
_#_Defense expenditures: $NA, 0.7% of GDP (1988)
_%_
_@_Gaza Strip
_#_Note: The war between Israel and the Arab states in June 1967
ended with Israel in control of the West Bank and the Gaza Strip, the
Sinai, and the Golan Heights. As stated in the 1978 Camp David Accords
and reaffirmed by President Reagan''s 1 September 1982 peace initiative,
the final status of the West Bank and the Gaza Strip, their relationship
with their neighbors, and a peace treaty between Israel and Jordan are to
be negotiated among the concerned parties. Camp David further specifies
that these negotiations will resolve the respective boundaries. Pending
the completion of this process, it is US policy that the final status of
the West Bank and the Gaza Strip has yet to be determined. In the view of
the US, the term West Bank describes all of the area west of the Jordan
under Jordanian administration before the 1967 Arab-Israeli war. With
respect to negotiations envisaged in the framework agreement, however, it
is US policy that a distinction must be made between Jerusalem and the
rest of the West Bank because of the city''s special status and
circumstances. Therefore, a negotiated solution for the final status of
Jerusalem could be different in character from that of the rest of the
West Bank.
_#_Railroads: one line, abandoned and in disrepair, but trackage
remains
_#_Highways: small, poorly developed indigenous road network
_#_Ports: facilities for small boats to service Gaza
_#_Airports: 1 with permanent-surface runway less than 1,220 m
_#_Telecommunications: stations--no AM, no FM, no TV
_*_Defense Forces
_#_Branches: NA
_#_Manpower availability: males 15-49, 136,311; NA fit for military
service
_#_Defense expenditures: $NA, NA% of GDP
_%_
_@_Germany
_#_Railroads:
West--31,443 km total; 27,421 km government owned, 1.435-meter
standard gauge (12,491 km double track, 11,501 km electrified);
4,022 km nongovernment owned, including 3,598 km 1.435-meter standard
gauge (214 km electrified) and 424 km 1.000-meter gauge (186 km
electrified);
East--14,025 km total; 13,750 km 1.435-meter standard gauge,
275 km 1.000-meter or other narrow gauge; 3,830 (est.) km 1.435-meter
double-track standard gauge; 3,475 km overhead electrified (1988)
_#_Highways:
West--466,305 km total; 169,568 km primary, includes 6,435 km
autobahn, 32,460 km national highways (Bundesstrassen), 65,425 km state
highways (Landesstrassen), 65,248 km county roads (Kreisstrassen);
296,737 km of secondary communal roads (Gemeindestrassen);
East--124,604 km total; 47,203 km concrete, asphalt, stone block,
of which 1,855 km are autobahn and limited access roads, 11,326 are trunk
roads, and 34,022 are regional roads; 77,401 municipal roads (1988)
_#_Inland waterways:
West--5,222 km, of which almost 70% are usable by craft of 1,000-metric
ton capacity or larger; major rivers include the Rhine and Elbe; Kiel
Canal is an important connection between the Baltic Sea and North Sea;
East--2,319 km (1988)
_#_Pipelines: crude oil 3,644 km, refined products 3,946 km,
natural gas 97,564 km (1988)
_#_Ports: maritime--Bremerhaven, Brunsbuttel, Cuxhaven, Emden,
Bremen, Hamburg, Kiel, Lubeck, Wilhelmshaven, Rostock, Wismar,
Stralsund, Sassnitz; inland--31 major
_#_Merchant marine: 598 ships (1,000 GRT or over) totaling 5,029,615
GRT/6,391,875 DWT; includes 3 passenger, 5 short-sea passenger,
315 cargo, 11 refrigerated cargo, 126 container, 1 multifunction
large-load carrier, 33 roll-on/roll-off cargo, 5 railcar carrier,
6 barge carrier, 11 petroleum, oils, and lubricants (POL) tanker,
27 chemical tanker, 21 liquefied gas tanker, 5 combination ore/oil,
14 combination bulk, 15 bulk; note--the German register includes
ships of the former East Germany and West Germany; during 1991 the
fleet is expected to undergo major restructuring as now-surplus
ships are sold off
_#_Civil air: 239 major transport aircraft
_#_Airports: 655 total, 647 usable; 312 with permanent-surface
runways; 4 with runways over 3,659 m; 86 with runways 2,440-3,659 m;
95 with runways 1,220-2,439 m
_#_Telecommunications:
West--highly developed, modern telecommunication service to all parts of
the country; fully adequate in all respects; 41,740,000 telephones;
stations--70 AM, 205 (370 relays) FM, 300 (6,422 relays) TV; 6 submarine
coaxial cables; earth stations operating in INTELSAT (12 Atlantic Ocean,
2 Indian Ocean), EUTELSAT, and domestic systems;
East--3,970,000 telephones; stations--23 AM, 17 FM, 21 TV (15 Soviet TV
relays); 6,181,860 TVs; 6,700,000 radios; at least 1 earth station
_*_Defense Forces
_#_Branches: Army, Navy, Air Force, Federal Border Police
_#_Manpower availability:--males 15-49, 20,219,289; 17,557,807 fit for
military service; 415,108 reach military age (18) annually
_#_Defense expenditures: $47.1 billion, 4.7% of GDP (1990)
_%_
_@_Ghana
_#_Railroads: 953 km, all 1.067-meter gauge; 32 km double track;
railroads undergoing major renovation
_#_Highways: 28,300 km total; 6,000 km concrete or bituminous surface,
22,300 km gravel, laterite, and improved earth surfaces
_#_Inland waterways: Volta, Ankobra, and Tano Rivers provide 155 km of
perennial navigation for launches and lighters; Lake Volta provides
1,125 km of arterial and feeder waterways
_#_Pipelines: none
_#_Ports: Tema, Takoradi
_#_Merchant marine: 4 cargo ships (1,000 GRT or over) totaling
52,016 GRT/66,627 DWT
_#_Civil air: 6 major transport aircraft
_#_Airports: 10 total, 9 usable; 5 with permanent-surface runways;
none with runways over 3,659 m; 1 with runways 2,440-3,659 m; 7 with
runways 1,220-2,439 m
_#_Telecommunications: poor to fair system of open-wire and cable,
radio relay links; 38,000 telephones; stations--6 AM, no FM, 9 TV;
1 Atlantic Ocean INTELSAT earth station
_*_Defense Forces
_#_Branches: Army, Navy, Air Force, Police Force, paramilitary Palace
Guard, National Civil Defense Organization
_#_Manpower availability: males 15-49, 3,538,503; 1,983,493 fit for
military service; 169,698 reach military age (18) annually
_#_Defense expenditures: $23 million, 0.5% of GNP (1988)
_%_
_@_Gibraltar
(dependent territory of the UK)
_#_Railroads: 1.000-meter-gauge system in dockyard area only
_#_Highways: 50 km, mostly good bitumen and concrete
_#_Ports: Gibraltar
_#_Merchant marine: 30 ships (1,000 GRT or over) totaling 1,399,594
GRT/2,667,656 DWT; includes 6 cargo, 2 refrigerated cargo, 1 container,
10 petroleum, oils, and lubricants (POL) tanker, 1 chemical tanker,
1 combination oil/ore, 9 bulk; note--a flag of convenience registry
_#_Civil air: 1 major transport aircraft
_#_Airports: 1 with permanent-surface runway 1,220-2,439 m
_#_Telecommunications: adequate international radiocommunication
facilities; automatic telephone system with 14,000 telephones;
stations--1 AM, 6 FM, 4 TV; 1 Atlantic Ocean INTELSAT earth station
_*_Defense Forces
_#_Branches: British Army, Royal Navy, Royal Air Force
_#_Note: defense is the responsibility of the UK
_%_
_@_Glorioso Islands
(French possession)
_#_Airports: 1 with runway 1,220-2,439 m
_#_Ports: none; offshore anchorage only
_*_Defense Forces
_#_Note: defense is the responsibility of France
_%_
_@_Greece
_#_Railroads: 2,479 km total; 1,565 km 1.435-meter standard gauge, of
which 36 km electrified and 100 km double track, 892 km 1.000-meter
gauge; 22 km 0.750-meter narrow gauge; all government owned
_#_Highways: 38,938 km total; 16,090 km paved, 13,676 km crushed stone
and gravel, 5,632 km improved earth, 3,540 km unimproved earth
_#_Inland waterways: 80 km; system consists of three coastal canals
and three unconnected rivers
_#_Pipelines: crude oil, 26 km; refined products, 547 km
_#_Ports: Piraeus, Thessaloniki
_#_Merchant marine: 958 ships (1,000 GRT or over) totaling 21,585,048
GRT/39,011,361 DWT; includes 13 passenger, 63 short-sea passenger,
2 passenger-cargo, 152 cargo, 21 container, 17 roll-on/roll-off cargo,
23 refrigerated cargo, 1 vehicle carrier, 185 petroleum, oils, and
lubricants (POL) tanker, 15 chemical tanker, 10 liquefied gas, 25
combination ore/oil, 5 specialized tanker, 407 bulk, 19 combination bulk;
note--ethnic Greeks also own large numbers of ships under the registry of
Liberia, Panama, Cyprus, and Lebanon
_#_Civil air: 35 major transport aircraft
_#_Airports: 81 total, 79 usable; 60 with permanent-surface runways;
none with runways over 3,659 m; 20 with runways 2,440-3,659 m;
22 with runways 1,220-2,439 m
_#_Telecommunications: adequate, modern networks reach all areas;
4,122,317 telephones; stations--30 AM, 17 (20 repeaters) FM, 39 (560
repeaters) TV; 8 submarine cables; satellite earth stations operating in
INTELSAT (1 Atlantic Ocean and 1 Indian Ocean), EUTELSAT, and MARISAT
systems
_*_Defense Forces
_#_Branches: Hellenic Army, Hellenic Navy, Hellenic Air Force
_#_Manpower availability: males 15-49, 2,434,762; 1,870,699 fit for
military service; 72,707 reach military age (21) annually
_#_Defense expenditures: $3.7 billion, 5.5% of GDP (1990)
_%_
_@_Greenland
(part of the Danish realm)
_#_Highways: 80 km
_#_Ports: Kangerluarsoruseq (Faeringehavn), Paamiut (Frederikshaab),
Nuuk (Godthaab), Sisimiut (Holsteinsborg), Julianehaab, Maarmorilik,
North Star Bay
_#_Merchant marine: 1 refrigerated cargo (1,000 GRT or over) totaling
1,021 GRT/1,778 DWT; note--operates under the registry of Denmark
_#_Civil air: 2 major transport aircraft
_#_Airports: 11 total, 8 usable; 5 with permanent-surface runways;
none with runways over 3,659 m; 2 with runways 2,440-3,659 m; 2 with
runways 1,220-2,439 m
_#_Telecommunications: adequate domestic and international service
provided by cables and radio relay; 17,900 telephones; stations--5 AM,
7 (35 relays) FM, 4 (9 relays) TV; 2 coaxial submarine cables; 1 Atlantic
Ocean INTELSAT earth station
_*_Defense Forces
_#_Note: defense is responsibility of Denmark
_%_
_@_Grenada
_#_Highways: 1,000 km total; 600 km paved, 300 km otherwise improved;
100 km unimproved
_#_Ports: Saint George''s
_#_Civil air: no major transport aircraft
_#_Airports: 3 total, 3 usable; 2 with permanent-surface runways;
none with runways over 3,659 m; 1 with runways 2,440-3,659 m;
1 with runways 1,220-2,439 m
_#_Telecommunications: automatic, islandwide telephone system with
5,650 telephones; new SHF links to Trinidad and Tobago and Saint Vincent;
VHF and UHF links to Trinidad and Carriacou; stations--1 AM, no FM, 1 TV
_*_Defense Forces
_#_Branches: Royal Grenada Police Force, Coast Guard
_#_Manpower availability: NA
_#_Defense expenditures: $NA, NA% of GDP
_%_
_@_Guadeloupe
(overseas department of France)
_#_Railroads: privately owned, narrow-gauge plantation lines
_#_Highways: 1,940 km total; 1,600 km paved, 340 km gravel and earth
_#_Ports: Pointe-a-Pitre, Basse-Terre
_#_Civil air: 2 major transport aircraft
_#_Airports: 9 total, 9 usable, 8 with permanent-surface runways;
none with runways over 3,659 m; 1 with runways 2,440-3,659 m; 1 with
runways 1,220-2,439 m
_#_Telecommunications: domestic facilities inadequate; 57,300
telephones; interisland radio relay to Antigua and Barbuda, Dominica,
and Martinique; stations--2 AM, 8 FM (30 private stations licensed to
broadcast FM), 9 TV; 1 Atlantic Ocean INTELSAT ground station
_*_Defense Forces
_#_Branches: French Forces, Gendarmerie
_#_Manpower availability: males 15-49, 98,069; NA fit for military
service
_#_Note: defense is responsibility of France
_%_
_@_Guam
(territory of the US)
_#_Highways: 674 km all-weather roads
_#_Ports: Apra Harbor
_#_Airports: 5 total, 4 usable; 3 with permanent-surface runways;
none with runways over 3,659 m; 3 with runways 2,440-3,659 m;
none with runways 1,220-2,439 m
_#_Telecommunications: 26,317 telephones (1989); stations--3 AM,
3 FM, 3 TV; 2 Pacific Ocean INTELSAT ground stations
_*_Defense Forces
_#_Note: defense is the responsibility of the US
_%_
_@_Guatemala
_#_Railroads: 870 km 0.914-meter gauge, single track; 780 km
government owned, 90 km privately owned
_#_Highways: 26,429 km total; 2,868 km paved, 11,421 km gravel,
and 12,140 unimproved
_#_Inland waterways: 260 km navigable year round; additional 730 km
navigable during high-water season
_#_Pipelines: crude oil, 275 km
_#_Ports: Puerto Barrios, Puerto Quetzal, Santo Tomas de Castilla
_#_Merchant marine: 1 cargo ship (1,000 GRT or over) totaling
4,129 GRT/6,450 DWT
_#_Civil air: 10 major transport aircraft
_#_Airports: 430 total, 381 usable; 11 with permanent-surface runways;
none with runways over 3,659 m; 3 with runways 2,440-3,659 m; 19 with
runways 1,220-2,439 m
_#_Telecommunications: fairly modern network centered in Guatemala
[city]; 97,670 telephones; stations--91 AM, no FM, 25 TV, 15 shortwave;
connection into Central American Microwave System; 1 Atlantic Ocean
INTELSAT earth station
_*_Defense Forces
_#_Branches: Army, Navy, Air Force
_#_Manpower availability: males 15-49, 2,097,234; 1,372,623 fit for
military service; 110,949 reach military age (18) annually
_#_Defense expenditures: $113 million, 1% of GDP (1990)
_%_
_@_Guernsey
(British crown dependency)
_#_Ports: Saint Peter Port, Saint Sampson
_#_Airport: 1 with permanent-surface runway 1,220-2,439 m (La
Villiaze)
_#_Telecommunications: stations--1 AM, no FM, 1 TV; 41,900
telephones; 1 submarine cable
_*_Defense Forces
_#_Note: defense is the responsibility of the UK
_%_
_@_Guinea
_#_Railroads: 1,045 km; 806 km 1.000-meter gauge, 239 km 1.435-meter
standard gauge
_#_Highways: 30,100 km total; 1,145 km paved, 12,955 km gravel or
laterite (of which barely 4,500 km are currently all-weather roads),
16,000 km unimproved earth (1987)
_#_Inland waterways: 1,295 km navigable by shallow-draft native craft
_#_Ports: Conakry, Kamsar
_#_Civil air: 2 major transport aircraft
_#_Airports: 16 total, 16 usable; 5 with permanent-surface runways;
none with runways over 3,659 m; 2 with runways 2,440-3,659 m;
10 with runways 1,220-2,439 m
_#_Telecommunications: fair system of open-wire lines, small
radiocommunication stations, and new radio relay system; 10,000
telephones; stations--3 AM, 1 FM, 1 TV; 12,000 TV sets; 125,000 radio
receivers; 1 Atlantic Ocean INTELSAT earth station
_*_Defense Forces
_#_Branches: Army, Navy (acts primarily as a coast guard), Air Force,
Republican Guard, paramilitary National Gendarmerie, Surete Nationale
_#_Manpower availability: males 15-49, 1,695,832; 853,593 fit for
military service
_#_Defense expenditures: $27 million, 1.2% of GDP (1988)
_%_
_@_Guinea-Bissau','3d6868e1aa1c8649b863797c2cda89b183d370023f246d3840ed98456ca1e4ff','internet-archive','theciaworldfactb00025gut','txt','84185fe9df79da427349cc1598fd3f69814a2085a9fc1fe0508a3fae0a870f84','https://archive.org/download/theciaworldfactb00025gut/25.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('daaa224125d1c8806ec14a1329fa87ef2b9e308087252500d77b15fe29f4b294',1991,'ES','Spain','communications',79,'_#_Highways: 3,218 km; 2,698 km bituminous, remainder earth
_#_Inland waterways: scattered stretches are important to coastal
commerce
_#_Ports: Bissau
_#_Civil air: 2 major transport aircraft
_#_Airports: 37 total, 18 usable; 5 with permanent-surface runways;
none with runways over 3,659 m; 1 with runways 2,440-3,659 m;
5 with runways 1,220-2,439 m
_#_Telecommunications: poor system of radio relay, open-wire lines,
and radiocommunications; 3,000 telephones; stations--1 AM, 2 FM, 1 TV; 1
Atlantic Ocean INTELSAT earth station
_*_Defense Forces
_#_Branches: People''s Revolutionary Armed Force (FARP; including
Army, Navy, Air Force), paramilitary force
_#_Manpower availability: males 15-49, 222,371; 126,797 fit for
military service
_#_Defense expenditures: $5 million, 3.2% of GDP (1987)
_%_
_@_Guyana
_#_Railroads: 187 km total, all single track 0.914-meter gauge
_#_Highways: 7,665 km total; 550 km paved, 5,000 km gravel, 1,525 km
earth, 590 km unimproved
_#_Inland waterways: 6,000 km total of navigable waterways; Berbice,
Demerara, and Essequibo Rivers are navigable by oceangoing vessels for
150 km, 100 km, and 80 km, respectively
_#_Ports: Georgetown
_#_Civil air: 5 major transport aircraft
_#_Airports: 58 total, 55 usable; 5 with permanent-surface runways;
none with runways over 3,659 m; none with runways 2,440-3,659 m;
14 with runways 1,220-2,439 m
_#_Telecommunications: fair system with radio relay network; over
27,000 telephones; tropospheric scatter link to Trinidad; stations--4 AM,
3 FM, no TV, 1 shortwave; 1 Atlantic Ocean INTELSAT earth station
_*_Defense Forces
_#_Branches: Guyana Defense Force (GDF; includes Coast Guard
and Air Corps), Guyana Police Force (GPF), Guyana People''s Militia (GPM),
Guyana National Service (GNS)
_#_Manpower availability: males 15-49, 195,142; 148,477 fit for
military service
_#_Defense expenditures: $5.5 million, 6% of GDP (1989 est.)
_%_
_@_Haiti
_#_Railroads: 40 km 0.760-meter narrow gauge, single-track, privately
owned industrial line
_#_Highways: 4,000 km total; 950 km paved, 900 km otherwise improved,
2,150 km unimproved
_#_Inland waterways: negligible; less than 100 km navigable
_#_Ports: Port-au-Prince, Cap-Haitien
_#_Civil air: 4 major transport aircraft
_#_Airports: 15 total, 10 usable; 3 with permanent-surface runways;
none with runways over 3,659 m; 1 with runways 2,440-3,659 m; 4 with
runways 1,220-2,439 m
_#_Telecommunications: domestic facilities barely adequate,
international facilities slightly better; 36,000 telephones;
stations--33 AM, no FM, 4 TV, 2 shortwave; 1 Atlantic Ocean earth station
_*_Defense Forces
_#_Branches: Army (including Police), Navy, Air Corps
_#_Manpower availability: males 15-49, 1,287,179; 691,926 fit for
military service; 61,265 reach military age (18) annually
_#_Defense expenditures: $34 million, 1.5% of GDP (1988 est.)
_%_
_@_Heard Island and McDonald Islands
(territory of Australia)
_#_Ports: none; offshore anchorage only
_*_Defense Forces
_#_Note: defense is the responsibility of Australia
_%_
_@_Honduras
_#_Railroads: 785 km total; 508 km 1.067-meter gauge, 277 km
0.914-meter gauge
_#_Highways: 8,950 km total; 1,700 km paved, 5,000 km otherwise
improved, 2,250 km unimproved earth
_#_Inland waterways: 465 km navigable by small craft
_#_Ports: Puerto Castilla, Puerto Cortes, San Lorenzo
_#_Merchant marine: 173 ships (1,000 GRT or over) totaling 527,481
GRT/812,095 DWT; includes 2 passenger-cargo, 107 cargo, 12 refrigerated
cargo, 9 container, 1 roll-on/roll-off cargo, 20 petroleum, oils, and
lubricants (POL) tanker, 1 chemical tanker, 2 specialized tanker, 1
vehicle carrier, 18 bulk; note--a flag of convenience registry; the
USSR owns one ship under the Honduran flag
_#_Civil air: 9 major transport aircraft
_#_Airports: 175 total, 134 usable; 8 with permanent-surface runways;
none with runways over 3,659 m; 4 with runways 2,440-3,659 m; 13 with
runways 1,220-2,439 m
_#_Telecommunications: improved, but still inadequate; connection into
Central American Microwave System; 35,100 telephones; stations--176 AM,
no FM, 28 TV, 7 shortwave; 2 Atlantic Ocean INTELSAT earth stations
_*_Defense Forces
_#_Branches: Army, Navy (including Marines), Air Force, Public
Security Forces (FUSEP)
_#_Manpower availability: males 15-49, 1,106,630; 659,520 fit for
military service; 58,953 reach military age (18) annually
_#_Defense expenditures: $82.5 million, 1.9% of GDP (1990 est.)
_%_
_@_Hong Kong
(dependent territory of the UK)
_#_Railroads: 35 km 1.435-meter standard gauge, government owned
_#_Highways: 1,484 km total; 794 km paved, 306 km gravel, crushed
stone, or earth
_#_Ports: Hong Kong
_#_Merchant marine: 134 ships (1,000 GRT or over), totaling 4,690,770
GRT/8,091,177 DWT; includes 1 passenger, 1 short-sea passenger, 16 cargo,
5 refrigerated cargo, 16 container, 1 roll-on/roll-off cargo, 9
petroleum, oils, and lubricants (POL) tanker, 2 chemical tanker, 6
combination ore/oil, 6 liquefied gas, 71 bulk; note--a flag of
convenience registry; ships registered in Hong Kong fly the UK flag and
an estimated 500 Hong Kong-owned ships are registered elsewhere
_#_Civil air: 16 major transport aircraft
_#_Airports: 2 total; 2 usable; 2 with permanent-surface runways;
none with runways over 3,659 m; 1 with runways 2,440-3,659 m;
none with runways 1,220-2,439 m
_#_Telecommunications: modern facilities provide excellent domestic
and international services; 3,000,000 telephones; microwave transmission
links and extensive optical fiber transmission network; stations--6 AM,
6 FM, 4 TV; 1 British Broadcasting Corporation (BBC) relay station and
1 British Forces Broadcasting Service relay station; 2,500,000 radio
receivers; 1,312,000 TV sets (1,224,000 color TV sets); satellite earth
stations--1 Pacific Ocean INTELSAT and 2 Indian Ocean INTELSAT; coaxial
cable to Guangzhou, China; links to 5 international submarine cables
providing access to ASEAN member nations, Japan, Taiwan, Australia,
Middle East, and Western Europe
_*_Defense Forces
_#_Branches: Headquarters of British Forces, Royal Navy, Royal
Air Force, Royal Hong Kong Auxiliary Air Force, Gurkha Brigade,
Royal Hong Kong Police Force
_#_Manpower availability: males 15-49, 1,718,112; 1,328,230 fit for
military service; 45,437 reach military age (18) annually
_#_Defense expenditures: $300 million, 0.5% of GDP (1989 est.);
this represents one-fourth of the total cost of defending itself,
the remainder being paid by the UK
_#_Note: defense is the responsibility of the UK
_%_
_@_Howland Island
(territory of the US)
_#_Airports: airstrip constructed in 1937 for scheduled refueling
stop on the round-the-world flight of Amelia Earhart and Fred
Noonan--they left Lae, New Guinea, for Howland Island, but were never
seen again; the airstrip is no longer serviceable
_#_Ports: none; offshore anchorage only, one boat landing area along
the middle of the west coast
_#_Note: Earhart Light is a day beacon near the middle of the west
coast that was partially destroyed during World War II, but has since
been rebuilt in memory of famed aviatrix Amelia Earhart
_*_Defense Forces
_#_Note: defense is the responsibility of the US; visited annually
by the US Coast Guard
_%_
_@_Hungary
_#_Railroads: 7,765 km total; 7,508 km 1.435-meter standard gauge,
222 km narrow gauge (mostly 0.760-meter), 35 km 1.520-meter broad gauge;
1,147 km double track, 2,161 km electrified; all government owned (1988)
_#_Highways: 130,014 km total; 29,715 km national highway
system--26,834 km asphalt and bitumen, 142 km concrete, 51 km stone and
road brick, 2,276 km macadam, 412 km unpaved; 58,495 km country roads
(66% unpaved), and 41,804 km (est.) other roads (70% unpaved) (1988)
_#_Inland waterways: 1,622 km (1988)
_#_Pipelines: crude oil, 1,204 km; refined products, 630 km;
natural gas, 3,895 km (1986)
_#_Ports: Budapest and Dunaujvaros are river ports on the Danube;
maritime outlets are Rostock (Germany), Gdansk (Poland), Gdynia (Poland),
Szczecin (Poland), Galati (Romania), and Braila (Romania)
_#_Merchant marine: 16 cargo ships (1,000 GRT or over) and 1 bulk
totaling 94,393 GRT/131,946 DWT
_#_Civil air: 28 major transport aircraft
_#_Airports: 90 total, 90 usable; 20 with permanent-surface runways;
2 with runways over 3,659 m; 10 with runways 2,440-3,659 m; 15 with
runways 1,220-2,439 m
_#_Telecommunications: telephone density is at 17 per 100 inhabitants;
49% of all phones are in Budapest; 12-15 year wait for a phone; 16,000
telex lines (June 1990); stations--13 AM, 12 FM, 21 TV (8 Soviet
TV relays); 4.2 TVs (1990)
_*_Defense Forces
_#_Branches: Ground Forces, Air and Air Defense Forces, Frontier
Guard, Civil Defense
_#_Manpower availability: males 15-49, 2,667,234; 2,130,749 fit for
military service; 88,851 reach military age (18) annually
_#_Defense expenditures: 43.7 billion forints, NA% of GDP (1989);
note--conversion of defense expenditures into US dollars using the
official administratively set exchange rate would produce misleading
results
_%_
_@_Iceland
_#_Highways: 12,343 km total; 166 km bitumen and concrete; 1,284 km
bituminous treated and gravel; 10,893 km earth
_#_Ports: Reykjavik, Akureyri, Hafnarfjordhur, Keflavik,
Seydhisfjordhur, Siglufjordhur, Vestmannaeyjar; numerous minor ports
_#_Merchant marine: 16 ships (1,000 GRT or over) totaling 53,409
GRT/73,279 DWT; includes 8 cargo, 2 refrigerated cargo, 1 container,
2 roll-on/roll-off cargo, 1 petroleum, oils, and lubricants (POL) tanker,
1 chemical tanker, 1 bulk
_#_Civil air: 20 major transport aircraft
_#_Airports: 99 total, 92 usable; 4 with permanent-surface runways;
none with runways over 3,659 m; 1 with runways 2,440-3,659 m;
14 with runways 1,220-2,439 m
_#_Telecommunications: adequate domestic service, wire and radio
communication system; 135,000 telephones; stations--10 AM, 17 (43 relays)
FM, 14 (132 relays) TV; 2 submarine cables; 1 Atlantic Ocean INTELSAT
earth station
_*_Defense Forces
_#_Branches: no armed forces; State Criminal Police, Coast Guard;
Iceland''s defense is provided by the US-manned Icelandic Defense Force
(IDF) headquartered at Keflavik
_#_Manpower availability: males 15-49, 69,644; 62,248 fit for military
service; no conscription or compulsory military service
_#_Defense expenditures: none
_%_
_@_India
_#_Railroads: 61,850 km total (1986); 33,553 km 1.676-meter broad
gauge, 24,051 km 1.000-meter gauge, 4,246 km narrow gauge (0.762 meter
and 0.610 meter); 12,617 km is double track; 6,500 km is electrified
_#_Highways: 1,633,300 km total (1986); 515,300 km secondary and
1,118,000 km gravel, crushed stone, or earth
_#_Inland waterways: 16,180 km; 3,631 km navigable by large vessels
_#_Pipelines: crude oil, 3,497 km; refined products, 1,703 km; natural
gas, 902 km (1989)
_#_Ports: Bombay, Calcutta, Cochin, Kandla, Madras, New Mangalore,
Port Blair (Andaman Islands)
_#_Merchant marine: 308 ships (1,000 GRT or over) totaling 6,087,451
GRT/10,150,460 DWT; includes 1 short-sea passenger, 8 passenger-cargo,
100 cargo, 1 roll-on/roll-off cargo, 8 container, 54 petroleum, oils, and
lubricants (POL) tanker, 10 chemical tanker, 9 combination ore/oil,
115 bulk, 2 combination bulk
_#_Civil air: 93 major transport aircraft
_#_Airports: 345 total, 288 usable; 198 with permanent-surface
runways; 2 with runways over 3,659 m; 57 with runways 2,440-3,659 m;
88 with runways 1,220-2,439 m
_#_Telecommunications: poor domestic telephone service, international
radio communications adequate; 4,700,000 telephones; stations--96 AM,
4 FM, 274 TV (government controlled); domestic satellite system for
communications and TV; 3 Indian Ocean INTELSAT earth stations; submarine
cables to Malaysia and United Arab Emirates
_*_Defense Forces
_#_Branches: Army, Navy, Air Force, Police Force, Border Security
Forces, Coast Guard, Assam Rifles
_#_Manpower availability: males 15-49, 232,793,714; 137,259,444 fit
for military service; about 9,431,908 reach military age (17) annually
_#_Defense expenditures: $9.2 billion, 3.5% of GNP (FY91)
_%_
_@_Indian Ocean
_#_Ports: Bombay (India), Calcutta (India), Madras (India),
Colombo (Sri Lanka), Durban (South Africa), Fremantle (Australia),
Jakarta (Indonesia), Melbourne (Australia), Richard''s Bay (South Africa)
_#_Telecommunications: no submarine cables
_%_
_@_Indonesia
_#_Railroads: 6,964 km total; 6,389 km 1.067-meter gauge, 497 km
0.750-meter gauge, 78 km 0.600-meter gauge; 211 km double track; 101 km
electrified; all government owned
_#_Highways: 119,500 km total; 11,812 km state, 34,180 km provincial,
and 73,508 km district roads
_#_Inland waterways: 21,579 km total; Sumatra 5,471 km, Java and
Madura 820 km, Kalimantan 10,460 km, Celebes 241 km, Irian Jaya 4,587 km
_#_Pipelines: crude oil, 2,505 km; refined products, 456 km; natural
gas, 1,703 km (1989)
_#_Ports: Cilacap, Cirebon, Jakarta, Kupang, Palembang, Ujungpandang,
Semarang, Surabaya
_#_Merchant marine: 365 ships (1,000 GRT or over) totaling 1,647,632
GRT/2,481,432 DWT; includes 5 short-sea passenger, 13 passenger-cargo,
215 cargo, 7 container, 3 roll-on/roll-off cargo, 2 vehicle carrier,
80 petroleum, oils, and lubricants (POL) tanker, 3 chemical tanker,
5 liquefied gas, 6 specialized tanker, 1 livestock carrier, 25 bulk
_#_Civil air: about 216 commercial transport aircraft
_#_Airports: 470 total, 436 usable; 111 with permanent-surface
runways; 1 with runways over 3,659 m; 12 with runways 2,440-3,659 m;
63 with runways 1,220-2,439 m
_#_Telecommunications: interisland microwave system and HF police net;
domestic service fair, international service good; radiobroadcast
coverage good; 763,000 telephones (1986); stations--618 AM, 38 FM, 9 TV;
satellite earth stations--1 Indian Ocean INTELSAT earth station and
1 Pacific Ocean INTELSAT earth station; and 1 domestic satellite
communications system
_*_Defense Forces
_#_Branches: Army, Navy, Air Force, National Police
_#_Manpower availability: males 15-49, 50,572,652; 29,893,127 fit for
military service; 2,149,673 reach military age (18) annually
_#_Defense expenditures: $1.4 billion, 1.8% of GNP (1988)
_%_
_@_Iran
_#_Railroads: 4,601 km total; 4,509 km 1.432-meter gauge, 92 km
1.676-meter gauge; 730 km under construction from Bafq to Bandar Abbas
_#_Highways: 140,072 km total; 46,866 km gravel and crushed stone;
49,440 km improved earth; 42,566 km bituminous and bituminous-treated
surfaces; 1,200 km (est.) rural road network
_#_Inland waterways: 904 km; the Shatt al Arab is usually navigable by
maritime traffic for about 130 km, but closed since September 1980
because of Iran-Iraq war
_#_Pipelines: crude oil, 5,900 km; refined products, 3,900 km; natural
gas, 3,300 km
_#_Ports: Abadan (largely destroyed in fighting during 1980-88 war),
Bandar Beheshti, Bandar-e Abbas, Bandar-e Bushehr, Bandar-e
Khomeyni, Bandar-e Shahid Rajai, Khorramshahr (largely
destroyed in fighting during 1980-88 war)
_#_Merchant marine: 133 ships (1,000 GRT or over) totaling 4,634,204
GRT/8,671,769 DWT; includes 36 cargo, 6 roll-on/roll-off cargo, 33
petroleum, oils, and lubricants (POL) tanker, 4 chemical tanker, 3
refrigerated cargo, 49 bulk, 2 combination bulk
_#_Civil air: 42 major transport aircraft
_#_Airports: 214 total, 186 usable; 80 with permanent-surface runways;
17 with runways over 3,659 m; 16 with runways 2,440-3,659 m; 70 with
runways 1,220-2,439 m
_#_Telecommunications: radio relay extends throughout country; system
centered in Tehran; 2,143,000 telephones; stations--62 AM, 30 FM, 250
TV; satellite earth stations--2 Atlantic Ocean INTELSAT and 1 Indian
Ocean INTELSAT; HF and microwave to Turkey, Pakistan, Syria, Kuwait, and
USSR
_*_Defense Forces
_#_Branches: Islamic Republic of Iran Ground Forces, Navy, Air
Force, Air Defense, and Revolutionary Guard Corps (includes Basij
militia and own ground, air, and naval forces);
a merger of the Komiteh, Police, and Gendarmerie has produced a new
Security Forces of the Islamic Republic of Iran
_#_Manpower availability: males 15-49, 12,750,593; 7,588,711 fit for
military service; 576,321 reach military age (21) annually
_#_Defense expenditures: $13 billion, 13.3% of GNP (1991 est.)
_%_
_@_Iraq
_#_Railroads: 2,962 km total; 2,457 km 1.435-meter standard gauge,
505 km 1.000-meter gauge
_#_Highways: 25,479 km total; 8,290 km paved, 5,534 km improved earth,
11,655 km unimproved earth
_#_Inland waterways: 1,015 km; Shatt al Arab usually navigable by
maritime traffic for about 130 km, but closed since September 1980
because of Iran-Iraq war; Tigris and Euphrates navigable by shallow-draft
steamers (of little importance); Shatt al Basrah canal navigable in
sections by shallow-draft vessels
_#_Ports: Umm Qasr, Khawr az Zubayr, Al Basrah
_#_Merchant marine: 43 ships (1,000 GRT or over) totaling 944,253
GRT/1,691,368 DWT; includes 1 passenger, 1 passenger-cargo, 17 cargo,
1 refrigerated cargo, 3 roll-on/roll-off cargo, 19 petroleum, oils, and
lubricants (POL) tanker, 1 chemical tanker; note--since the 2 August 1990
invasion of Kuwait by Iraqi forces, Iraq has sought to register at least
part of its merchant fleet under convenience flags; none of the Iraqi
flag merchant fleet was trading internationally as of 1 January 1991
_#_Pipelines: crude oil, 4,350 km; 725 km refined products; 1,360 km
natural gas
_#_Civil air: 64 major transport aircraft (including 30 IL-76s
used by the Iraq Air Force)
_#_Airports: 111 total, 102 usable; 73 with permanent-surface runways;
9 with runways over 3,659 m; 52 with runways 2,440-3,659 m; 15 with
runways 1,220-2,439 m
_#_Telecommunications: good network consists of coaxial cables, radio
relay links, and radiocommunication stations; 632,000 telephones;
stations--9 AM, 1 FM, 81 TV; satellite earth stations--1 Atlantic Ocean
INTELSAT, 1 Indian Ocean INTELSAT, 1 GORIZONT Atlantic Ocean in the
Intersputnik system; coaxial cable and radio relay to Kuwait, Jordan,
Syria, and Turkey
_*_Defense Forces
_#_Branches: Army and Republican Guard, Navy, Air Force,
Border Guard Force, Internal Security Forces
_#_Manpower availability: males 15-49, 4,270,592; 2,380,439 fit for
military service; 228,277 reach military age (18) annually
_#_Defense expenditures: $NA, NA% of GDP
_%_
_@_Iraq - Saudi Arabia Neutral Zone
_#_Highways: none; some secondary roads
_*_Defense Forces
_#_Note: defense is the joint responsibility of Iraq and Saudi Arabia
_%_
_@_Ireland
_#_Railroads: Irish National Railways (CIE) operates 1,947 km
1.602-meter gauge, government owned; 485 km double track; 38 km
electrified
_#_Highways: 92,294 km total; 87,422 km surfaced, 4,872 km gravel or
crushed stone
_#_Inland waterways: limited for commercial traffic
_#_Pipelines: natural gas, 225 km
_#_Ports: Cork, Dublin, Shannon Estuary, Waterford
_#_Merchant marine: 53 ships (1,000 GRT or over) totaling 138,967
GRT/164,628 DWT; includes 4 short-sea passenger, 31 cargo, 2
refrigerated cargo, 3 container, 2 petroleum, oils, and lubricants (POL)
tanker, 3 specialized tanker, 2 chemical tanker, 6 bulk
_#_Civil air: 23 major transport aircraft
_#_Airports: 40 total, 37 usable; 18 with permanent-surface runways;
none with runways over 3,659 m; 2 with runways 2,440-3,659 m; 6 with
runways 1,220-2,439 m
_#_Telecommunications: small, modern system using cable and radio
relay circuits; 900,000 telephones; stations--45 AM, 16 (29 relays) FM,
18 (68 relays) TV; 5 coaxial submarine cables; 2 Atlantic Ocean INTELSAT
earth stations
_*_Defense Forces
_#_Branches: Army (including Naval Service and Air Corps), National
Police (GARDA)
_#_Manpower availability: males 15-49, 871,578; 705,642 fit for
military service; 33,175 reach military age (17) annually
_#_Defense expenditures: $458 million, 1.6% of GDP (1990 est.)
_%_
_@_Israel
(also see separate Gaza Strip and West Bank entries)
_#_Note: The Arab territories occupied by Israel since the 1967 war
are not included in the data below. As stated in the 1978 Camp David
Accords and reaffirmed by President Reagan''s 1 September 1982 peace
initiative, the final status of the West Bank and Gaza Strip, their
relationship with their neighbors, and a peace treaty between Israel
and Jordan are to be negotiated among the concerned parties. The Camp
David Accords further specify that these negotiations will resolve the
location of the respective boundaries. Pending the completion of this
process, it is US policy that the final status of the West Bank and
Gaza Strip has yet to be determined (see West Bank and Gaza Strip
entries). On 25 April 1982 Israel relinquished control of the Sinai to
Egypt. Statistics for the Israeli-occupied Golan Heights are included in
the Syria entry.
_#_Railroads: 594 km 1.435-meter gauge, single track; diesel operated
_#_Highways: 4,500 km; majority is bituminous surfaced
_#_Pipelines: crude oil, 708 km; refined products, 290 km; natural
gas, 89 km
_#_Ports: Ashdod, Haifa, Elat
_#_Merchant marine: 30 ships (1,000 GRT or over) totaling 516,714
GRT/611,795 DWT; includes 7 cargo, 21 container, 2 refrigerated cargo;
note--Israel also maintains a significant flag of convenience fleet,
which is normally at least as large as the Israeli flag fleet; the
Israeli flag of convenience fleet typically includes all of its POL
tankers
_#_Civil air: 27 major transport aircraft
_#_Airports: 51 total, 44 usable; 26 with permanent-surface runways;
none with runways over 3,659 m; 6 with runways 2,440-3,659 m;
12 with runways 1,220-2,439 m
_#_Telecommunications: most highly developed in the Middle East
though not the largest; good system of coaxial cable and radio relay;
1,800,000 telephones; stations--11 AM, 24 FM, 54 TV; 2 submarine cables;
satellite earth stations--2 Atlantic Ocean INTELSAT and 1 Indian Ocean
INTELSAT
_*_Defense Forces
_#_Branches: Israel Defense Forces includes ground, naval, and air
components; historically there have been no separate Israeli military
services
_#_Manpower availability: eligible 15-49, 2,213,808; of the 1,117,733
males 15-49, 920,449 are fit for military service; of the 1,096,075
females 15-49, 899,022 are fit for military service; 44,429 males and
42,249 females reach military age (18) annually; both sexes are liable
for military service; Nahal or Pioneer Fighting Youth, Frontier Guard,
Chen
_#_Defense expenditures: $5.3 billion, 13.9% of GNP (1991);
note--includes an estimated $1.8 billion in US military aid
_%_
_@_Italy
_#_Railroads: 20,011 km total; 16,066 km 1.435-meter government-owned
standard gauge (8,999 km electrified); 3,945 km privately owned--2,100 km
1.435-meter standard gauge (1,155 km electrified) and 1,845 km
0.950-meter narrow gauge (380 km electrified)
_#_Highways: 294,410 km total; autostrada 5,900 km, state highways
45,170 km, provincial highways 101,680 km, communal highways 141,660 km;
260,500 km concrete, bituminous, or stone block, 26,900 km gravel and
crushed stone,7,010 km earth
_#_Inland waterways: 2,400 km for various types of commercial
traffic, although of limited overall value
_#_Pipelines: crude oil, 1,703 km; refined products, 2,148 km; natural
gas, 19,400 km
_#_Ports: Cagliari (Sardinia), Genoa, La Spezia, Livorno, Naples,
Palermo (Sicily), Taranto, Trieste, Venice
_#_Merchant marine: 575 ships (1,000 GRT or over) totaling 7,462,744
GRT/11,593,730 DWT; includes 11 passenger, 44 short-sea passenger,
103 cargo, 5 refrigerated cargo, 23 container, 67 roll-on/roll-off cargo,
7 vehicle carrier, 1 multifunction large-load carrier, 2 livestock
carrier, 151 petroleum, oils, and lubricants (POL) tanker, 37 chemical
tanker, 38 liquefied gas, 10 specialized tanker, 14 combination ore/oil,
60 bulk, 2 combination bulk
_#_Civil air: 125 major transport aircraft
_#_Airports: 138 total, 135 usable; 90 with permanent-surface runways;
2 with runways over 3,659 m; 36 with runways 2,440-3,659 m; 38 with
runways 1,220-2,439 m
_#_Telecommunications: well engineered, constructed, and operated;
28,000,000 telephones; stations--144 AM, 54 (over 1,800 repeaters) FM,
450 (over 1,300 repeaters) TV; 22 submarine cables; communication
satellite earth stations operating in INTELSAT 3 Atlantic Ocean and 2
Indian Ocean, INMARSA','79f6fc8f1610a8af5d83e3947930c5514a9e4ba58440a9b14d4c84e89c3fee9c','internet-archive','theciaworldfactb00025gut','txt','84185fe9df79da427349cc1598fd3f69814a2085a9fc1fe0508a3fae0a870f84','https://archive.org/download/theciaworldfactb00025gut/25.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e1b99ec8ee609a08532ba78f87ac8d46856f2592ffef19649540a57173a31260',1991,'ES','Spain','communications',80,'T, and EUTELSAT systems
_*_Defense Forces
_#_Branches: Army, Navy, Air Force, Carabinieri
_#_Manpower availability: males 15-49, 14,747,224; 12,877,803 fit for
military service; 418,043 reach military age (18) annually
_#_Defense expenditures: $19.2 billion, 2.2% of GDP (1990)
_%_
_@_Ivory Coast
(also known as Cote d''Ivoire)
_#_Railroads: 660 km (Burkina border to Abidjan, 1.00-meter gauge,
single track, except 25 km Abidjan-Anyama section is double track)
_#_Highways: 46,600 km total; 3,600 km bituminous and
bituminous-treated surface; 32,000 km gravel, crushed stone, laterite,
and improved earth; 11,000 km unimproved
_#_Inland waterways: 980 km navigable rivers, canals, and numerous
coastal lagoons
_#_Ports: Abidjan, San-Pedro
_#_Merchant marine: 7 ships (1,000 GRT or over) totaling 71,945 GRT/
90,684 DWT; includes 5 cargo, 1 petroleum, oils, and lubricants (POL)
tanker, 1 chemical tanker
_#_Civil air: 12 major transport aircraft, including multinationally
owned Air Afrique fleet
_#_Airports: 48 total, 41 usable; 7 with permanent-surface runways;
none with runways over 3,659 m; 3 with runways 2,440-3,659 m; 16 with
runways 1,220-2,439 m
_#_Telecommunications: system above African average; consists of
open-wire lines and radio relay links; 87,700 telephones; stations--3 AM,
17 FM, 11 TV; 2 Atlantic Ocean INTELSAT earth stations; 2 coaxial
submarine cables
_*_Defense Forces
_#_Branches: Army, Navy, Air Force, paramilitary Gendarmerie,
Presidential Guard
_#_Manpower availability: males 15-49, 2,981,269; 1,543,412 fit for
military service; 145,693 males reach military age (18) annually
_#_Defense expenditures: $199 million, 2.3% of GDP (1988)
_%_
_@_Jamaica
_#_Railroads: 370 km, all 1.435-meter standard gauge, single track
_#_Highways: 18,200 km total; 12,600 km paved, 3,200 km gravel,
2,400 km improved earth
_#_Pipelines: refined products, 10 km
_#_Ports: Kingston, Montego Bay
_#_Merchant marine: 5 ships (1,000 GRT or over) totaling 13,048
GRT/21,412 DWT; includes 1 cargo, 1 container, 1 roll-on/roll-off cargo,
1 petroleum, oils, and lubricants (POL) tanker, 1 bulk
_#_Civil air: 6 major transport aircraft
_#_Airports: 41 total, 25 usable; 14 with permanent-surface runways;
none with runways over 3,659 m; 2 with runways 2,440-3,659 m; 2 with
runways 1,220-2,439 m
_#_Telecommunications: fully automatic domestic telephone network;
127,000 telephones; stations--10 AM, 17 FM, 8 TV; 2 Atlantic Ocean
INTELSAT earth stations; 3 coaxial submarine cables
_*_Defense Forces
_#_Branches: Jamaica Defense Force (includes Coast Guard and Air
Wing), Jamaica Constabulary Force
_#_Manpower availability: males 15-49, 628,225; 446,229 fit for
military service; no conscription; 26,442 reach minimum volunteer
age (18) annually
_#_Defense expenditures: $20 million, less than 1% of GDP (FY91)
_%_
_@_Jan Mayen
(territory of Norway)
_#_Airports: 1 with runway 1,220 to 2,439 m
_#_Ports: none; offshore anchorage only
_#_Telecommunications: radio and meteorological station
_*_Defense Forces
_#_Note: defense is the responsibility of Norway
_%_
_@_Japan
_#_Railroads: 27,327 km total; 2,012 km 1.435-meter standard gauge
and 25,315 km predominantly 1.067-meter narrow gauge; 5,724 km
doubletrack and multitrack sections, 9,038 km 1.067-meter narrow-gauge
electrified, 2,012 km 1.435-meter standard-gauge electrified (1987)
_#_Highways: 1,098,900 km total; 718,700 km paved, 380,200 km gravel,
crushed stone, or unpaved; 3,900 km national expressways, 46,544 km
national highways, 43,907 km principal local roads, 86,930 km prefectural
roads, and 917,619 other (1987)
_#_Inland waterways: about 1,770 km; seagoing craft ply all coastal
inland seas
_#_Pipelines: crude oil, 84 km; refined products, 322 km; natural gas,
1,800 km
_#_Ports: Chiba, Muroran, Kitakyushu, Kobe, Tomakomai, Nagoya, Osaka,
Tokyo, Yokkaichi, Yokohama, Kawasaki, Niigata, Fushiki-Toyama, Shimizu,
Himeji, Wakayama-Shimozu, Shimonoseki, Tokuyama-Shimomatsu
_#_Merchant marine: 1,019 ships (1,000 GRT or over) totaling
22,396,958 GRT/34,683,035 DWT; includes 9 passenger, 55 short-sea
passenger, 4 passenger cargo, 95 cargo, 40 container, 33
roll-on/roll-off cargo, 125 refrigerated cargo, 99 vehicle carrier, 231
petroleum, oils, and lubricants (POL) tanker, 14 chemical tanker, 41
liquefied gas, 11 combination ore/oil, 3 specialized tanker, 257 bulk, 2
combination bulk; note--Japan also owns a large flag of convenience
fleet, including up to 40% of the total number of ships under Panamanian
flag
_#_Civil air: 360 major transport aircraft
_#_Airports: 165 total, 157 usable; 129 with permanent-surface
runways; 2 with runways over 3,659 m; 29 with runways 2,440-3,659 m;
56 with runways 1,220-2,439 m
_#_Telecommunications: excellent domestic and international service;
64,000,000 telephones; stations--318 AM, 58 FM, 12,350 TV (196
major--1 kw or greater); satellite earth stations--4 Pacific Ocean
INTELSAT and 1 Indian Ocean INTELSAT; submarine cables to US (via Guam),
Philippines, China, and USSR
_*_Defense Forces
_#_Branches: Japan Ground Self-Defense Force (Army), Japan Maritime
Self-Defense Force (Navy), Japan Air Self-Defense Force (Air Force),
Maritime Safety Agency (Coast Guard)
_#_Manpower availability: males 15-49, 32,256,893; 27,771,374 fit for
military service; 992,255 reach military age (18) annually
_#_Defense expenditures: $NA, 1.0% of GNP (1990 est.)
_%_
_@_Jarvis Island
(territory of the US)
_#_Ports: none; offshore anchorage only--one boat landing area in the
middle of the west coast and another near the southwest corner of the
island
_#_Note: there is a day beacon near the middle of the west coast
_*_Defense Forces
_#_Note: defense is the responsibility of the US; visited annually
by the US Coast Guard
_%_
_@_Jersey
(British crown dependency)','aec875d82c0de4d0c39d75cb10a8332d13eb1f506c62f8a1c46ac530a646390c','internet-archive','theciaworldfactb00025gut','txt','84185fe9df79da427349cc1598fd3f69814a2085a9fc1fe0508a3fae0a870f84','https://archive.org/download/theciaworldfactb00025gut/25.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5538dc5c5bbcd98eff31fa1bfdd549239ff9ab25ace0b3347bd897b80c5b9c2f',1991,'FR','France','communications',92,'_#_Ports: Saint Helier, Gorey, Saint Aubin
_#_Airports: 1 with permanent-surface runway 1,220-2,439 m (Saint
Peter)
_#_Telecommunications: 63,700 telephones; stations--1 AM, no FM, 1
TV; 3 submarine cables
_*_Defense Forces
_#_Note: defense is the responsibility of the UK
_%_
_@_Johnston Atoll
(territory of the US)
_#_Ports: Johnston Island
_#_Airports: 1 with permanent-surface runway 2,743 m
_#_Telecommunications: excellent system including 60-channel submarine
cable, Autodin/SRT terminal, digital telephone switch, Military
Affiliated Radio System (MARS station), commercial satellite television
system (receive only), and UHF/VHF air-ground radio, marine
VHF/FM Channel 16
_#_Note: US Coast Guard operates a LORAN transmitting station
_*_Defense Forces
_#_Note: defense is the responsibility of the US
_%_
_@_Jordan
(see separate West Bank entry)
_#_Note: The war between Israel and the Arab states in June 1967 ended
with Israel in control of the West Bank. As stated in the 1978 Camp David
Accords and reaffirmed by President Reagan''s 1 September 1982 peace
initiative, the final status of the West Bank and Gaza Strip, their
relationship with their neighbors, and a peace treaty between Israel and
Jordan are to be negotiated among the concerned parties. The Camp David
Accords further specify that these negotiations will resolve the location
of the respective boundaries. Pending the completion of this process, it
is US policy that the final status of the West Bank and Gaza Strip has
yet to be determined.
_#_Railroads: 619 km 1.050-meter gauge, single track
_#_Highways: 7,500 km; 5,500 km asphalt, 2,000 km gravel and crushed
stone
_#_Pipelines: crude oil, 209 km
_#_Ports: Al Aqabah
_#_Merchant marine: 2 ships (1,000 GRT or over) totaling 22,870
GRT/38,187 DWT; includes 1 bulk, 1 cargo
_#_Civil air: 19 major transport aircraft
_#_Airports: 19 total, 16 usable; 14 with permanent-surface runways;
1 with runways over 3,659 m; 13 with runways 2,440-3,659 m;
none with runways 1,220-2,439 m
_#_Telecommunications: adequate system of radio relay, cable, and
radio; 81,500 telephones; stations--4 AM, 3 FM, 24 TV; satellite earth
stations--1 Atlantic Ocean INTELSAT, 1 Indian Ocean INTELSAT, 1 ARABSAT,
1 domestic TV receive-only; coaxial cable and radio relay to Iraq, Saudi
Arabia, and Syria; radio relay to Lebanon is inactive; a microwave
network linking Syria, Egypt, Libya, Tunisia, Algeria, Morocco and Jordan
_*_Defense Forces
_#_Branches: Jordan Arab Army, Royal Jordanian Air Force,
Royal Jordanian Coast Guard, Public Security Force
_#_Manpower availability: males 15-49, 778,353; 555,144 fit for
military service; 39,879 reach military age (18) annually
_#_Defense expenditures: $377 million, 12.4% of GNP (1990)
_%_
_@_Juan de Nova Island
(French possession)
_#_Railroads: short line going to a jetty
_#_Airports: 1 with nonpermanent-surface runway 1,220-2,439 m
_#_Ports: none; offshore anchorage only
_*_Defense Forces
_#_Note: defense is the responsibility of France
_%_
_@_Kenya
_#_Railroads: 2,040 km 1.000-meter gauge
_#_Highways: 64,590 km total; 7,000 km paved, 4,150 km gravel,
remainder improved earth
_#_Inland waterways: part of Lake Victoria system is within boundaries
of Kenya; principal inland port is at Kisumu
_#_Pipelines: refined products, 483 km
_#_Ports: Mombasa, Lamu
_#_Civil air: 14 major transport aircraft
_#_Airports: 249 total, 213 usable; 22 with permanent-surface runways;
2 with runways over 3,659 m; 2 with runways 2,440-3,659 m; 47 with
runways 1,220-2,439 m
_#_Telecommunications: in top group of African systems; consists of
radio relay links, open-wire lines, and radiocommunication stations;
260,000 telephones; stations--11 AM, 4 FM, 4 TV; satellite earth
stations--1 Atlantic Ocean INTELSAT and 1 Indian Ocean INTLESAT
_*_Defense Forces
_#_Branches: Kenya Army, Kenya Navy, Air Force, paramilitary General
Service Unit of the Police
_#_Manpower availability: males 15-49, 5,444,247; 3,362,290 fit for
military service; no conscription
_#_Defense expenditures: $100 million, 1.0% of GDP (1989 est.)
_%_
_@_Kingman Reef
(territory of the US)
_#_Airports: lagoon was used as a halfway station between Hawaii and
American Samoa by Pan American Airways for flying boats in 1937 and 1938
_#_Ports: none; offshore anchorage only
_*_Defense Forces
_#_Note: defense is the responsibility of the US
_%_
_@_Kiribati
_#_Highways: 640 km of motorable roads
_#_Inland waterways: small network of canals, totaling 5 km, in Line
Islands
_#_Ports: Banaba and Betio (Tarawa)
_#_Civil air: 2 Trislanders; no major transport aircraft
_#_Airports: 22 total; 21 usable; 4 with permanent-surface runways;
none with runways over 2,439 m; 5 with runways 1,220-2,439 m
_#_Telecommunications: 1,400 telephones; stations--1 AM, no FM, no TV;
1 Pacific Ocean INTELSAT earth station
_*_Defense Forces
_#_Branches: no military force maintained; the Police Force carries
out law enforcement functions and paramilitary duties; there are small
police posts on all islands
_#_Manpower availability: NA
_#_Defense expenditures: $NA, NA% of GDP
_%_
_@_Korea, North
_#_Railroads: 4,535 km total; 3,870 km 1.435-meter standard gauge,
665 km 0.762-meter narrow gauge; 159 km double track;
3,175 km electrified; government owned (1989)
_#_Highways: about 30,000 km (1989); 98.5% gravel, crushed stone, or
earth surface; 1.5% concrete or bituminous
_#_Inland waterways: 2,253 km; mostly navigable by small craft only
_#_Pipelines: crude oil, 37 km
_#_Ports: Ch''ongjin, Haeju, Hungnam, Namp''o, Wonsan, Songnim,
Najin, Sonbong
_#_Merchant marine: 68 ships (1,000 GRT and over) totaling 465,801
GRT/709,442 DWT; includes 1 passenger, 1 short-sea passenger,
1 passenger-cargo, 58 cargo, 2 petroleum, oils, and lubricants (POL)
tanker, 4 bulk, 1 combination bulk
_#_Airports: 55 total, 55 usable (est.); about 30 with
permanent-surface runways; fewer than 5 with runways over 3,659 m; 20
with runways 2,440-3,659 m; 30 with runways 1,220-2,439 m
_#_Telecommunications: stations--18 AM, no FM, 11 TV; 200,000 TV sets;
3,500,000 radio receivers; 1 Indian Ocean INTELSAT earth station
_*_Defense Forces
_#_Branches: Korean People''s Army (includes of the Army, Navy,
Air Force), Civil Security Forces
_#_Manpower availability: males 15-49, 6,381,859; 3,899,606 fit for
military service; 214,690 reach military age (18) annually
_#_Defense expenditures: $NA, 20-25% of GNP (1991 est.);
note--the officially announced but suspect figure is $1.7 billion,
6% of GNP (1991 est.)
_%_
_@_Korea, South
_#_Railroads: 3,106 km operating in 1983; 3,059 km 1.435-meter
standard gauge, 47 km 0.610-meter narrow gauge, 712 km double track,
418 km electrified; government owned
_#_Highways: 62,936 km total (1982); 13,476 km national highway,
49,460 km provincial and local roads
_#_Inland waterways: 1,609 km; use restricted to small native craft
_#_Pipelines: 455 km refined products
_#_Ports: Pusan, Inchon, Kunsan, Mokpo, Ulsan
_#_Merchant marine: 439 ships (1,000 GRT or over) totaling 7,182,519
GRT/11,906,897 DWT; includes 2 short-sea passenger, 138 cargo, 45
container, 11 refrigerated cargo, 11 vehicle carrier, 48 petroleum, oils,
and lubricants (POL) tanker, 10 chemical tanker, 13 liquefied gas, 7
combination ore/oil, 146 bulk, 7 combination bulk, 1 multifunction
large-load carrier
_#_Civil air: 93 major transport aircraft
_#_Airports: 110 total, 102 usable; 60 with permanent-surface runways;
none with runways over 3,659 m; 21 with runways 2,440-3,659 m; 17 with
runways 1,220-2,439 m
_#_Telecommunications: adequate domestic and international services;
4,800,000 telephones; stations--79 AM, 46 FM, 256 TV (57 of 1 kW or
greater); satellite earth stations--2 Pacific Ocean INTELSAT and 1 Indian
Ocean INTELSAT
_*_Defense Forces
_#_Branches: Army, Navy (including Marines), Air Force
_#_Manpower availability: males 15-49, 12,859,511; 8,294,624 fit for
military service; 429,088 reach military age (18) annually
_#_Defense expenditures: $10.4 billion, 4.5% of GNP (1991)
_%_
_@_Kuwait
_#_Highways: 3,000 km total; 2,500 km bituminous; 500 km earth, sand,
light gravel
_#_Pipelines: crude oil, 877 km; refined products, 40 km; natural gas,
165 km
_#_Ports: Ash Shuaybah, Ash Shuwaykh, Mina al Ahmadi
_#_Merchant marine: 31 ships (1,000 GRT or over), totaling 1,332,159
GRT/2,099,303 DWT; includes 1 cargo, 4 livestock carrier,
20 petroleum, oils, and lubricants (POL) tanker, 5 liquefied gas, 1 bulk;
note--all Kuwaiti ships greater than 1,000 GRT were outside Kuwaiti
waters at the time of the Iraqi invasion; many of these ships transferred
to the Liberian flag or to the flags of other Persian Gulf states;
Kuwaiti tankers are currently managed from London and Kuwaiti cargo and
container ships are managed from Dubai
_#_Civil air: 19 major transport aircraft
_#_Airports: 7 total, 4 usable; 4 with permanent-surface runways;
none with runways over 3,659 m; 4 with runways 2,440-3,659 m;
none with runways 1,220-2,439 m
_#_Telecommunications: excellent international, adequate domestic
facilities; 258,000 telephones; stations--3 AM, 2 FM, 3 TV; satellite
earth stations--1 Indian Ocean INTELSAT, and 2 Atlantic Ocean INTELSAT; 1
INMARSAT, 1 ARABSAT; coaxial cable and radio relay to Iraq and Saudi
Arabia
_*_Defense Forces
_#_Branches: Army, Navy, Air Force, National Police Force, National
Guard
_#_Manpower availability: males 15-49, 738,812; 441,611 fit for
military service; 19,452 reach military age (18) annually
_#_Defense expenditures: $1.1 billion, 4.8% of GDP (1990)
_%_
_@_Laos
_#_Highways: about 27,527 km total; 1,856 km bituminous or bituminous
treated; 7,451 km gravel, crushed stone, or improved earth; 18,220 km
unimproved earth and often impassable during rainy season mid-May to
mid-September
_#_Inland waterways: about 4,587 km, primarily Mekong and tributaries;
2,897 additional kilometers are sectionally navigable by craft drawing
less than 0.5 m
_#_Pipelines: 136 km, refined products
_#_Ports: none
_#_Airports: 65 total, 51 usable; 9 with permanent-surface runways;
none with runways over 3,659 m; 2 with runways 2,440-3,659 m;
13 with runways 1,220-2,439 m
_#_Telecommunications: service to general public considered poor;
radio network provides generally erratic service to government users;
7,390 telephones (1986); stations--10 AM, no FM, 1 TV; 1 satellite earth
station
_*_Defense Forces
_#_Branches: Lao People''s Army (LPA; including naval, aviation, and
militia elements), Air Force, National Police Department
_#_Manpower availability: males 15-49, 991,864; 531,084 fit for
military service; 45,548 reach military age (18) annually;
conscription age NA
_#_Defense expenditures: $NA, 3.8% of GDP (1987)
_%_
_@_Lebanon
_#_Railroads: 378 km total; 296 km 1.435-meter standard gauge, 82 km
1.050-meter gauge; all single track; system almost entirely inoperable
_#_Highways: 7,370 km total; 6,270 km paved, 450 km gravel and crushed
stone, 650 km improved earth
_#_Pipelines: crude oil, 72 km (none in operation)
_#_Ports: Beirut, Tripoli, Ras Silata, Juniyah, Sidon,
Az Zahrani, Tyre, Shikka; northern ports are occupied by Syrian
forces and southern ports are occupied or partially quarantined by
Israeli forces
_#_Merchant marine: 60 ships (1,000 GRT or over) totaling 257,220
GRT/379,691 DWT; includes 39 cargo, 1 refrigerated cargo, 2 vehicle
carrier, 2 roll-on/roll-off cargo, 1 container, 8 livestock carrier, 1
petroleum, oils, and lubricants (POL) tanker, 1 chemical tanker,
1 specialized tanker, 3 bulk, 1 combination bulk
_#_Civil air: 15 major transport aircraft
_#_Airports: 9 total, 8 usable; 6 with permanent-surface runways;
none with runways over 3,659 m; 3 with runways 2,440-3,659 m;
2 with runways 1,220-2,439 m; none under the direct control of the
Lebanese Government
_#_Telecommunications: rebuilding program disrupted; had fair system
of radio relay, cable; 325,000 telephones; stations--5 AM, 3 FM, 15 TV;
1 inactive Indian Ocean INTELSAT satellite earth station; 3 submarine
coaxial cables; radio relay to Jordan and Syria, inoperable
_*_Defense Forces
_#_Branches: Army (includes Navy and Air Force)
_#_Manpower availability: males 15-49, 725,974; 449,912 fit for
military service
_#_Defense expenditures: $168 million, 7.3% of GDP (1991)
_%_
_@_Lesotho
_#_Railroads: 1.6 km; owned, operated, and included in the statistics
of South Africa
_#_Highways: 5,167 km total; 508 km paved; 1,585 km crushed stone,
gravel, or stabilized soil; 946 km improved earth, 2,128 km unimproved
earth
_#_Civil air: 2 major transport aircraft
_#_Airports: 28 total, 28 usable; 3 with permanent surface runways;
none with runways over 3,659 m; 1 with runways 2,440-3,659 m;
2 with runways 1,220-2,439 m
_#_Telecommunications: rudimentary system consisting of a few land
lines, a small radio relay system, and minor radiocommunication stations;
5,920 telephones; stations--2 AM, 2 FM, 1 TV; 1 Atlantic Ocean INTELSAT
earth station
_*_Defense Forces
_#_Branches: Royal Lesotho Defense Force (RLDF; includes Army, Air
Wing), Royal Lesotho Mounted Police
_#_Manpower availability: males 15-49, 394,829; 212,967 fit for
military service
_#_Defense expenditures: $55 million, 8.6% of GDP (1990 est.)
_%_
_@_Liberia
_#_Railroads: 480 km total; 328 km 1.435-meter standard gauge, 152 km
1.067-meter narrow gauge; all lines single track; rail systems owned and
operated by foreign steel and financial interests in conjunction with
Liberian Government
_#_Highways: 10,087 km total; 603 km bituminous treated, 2,848 km
all weather, 4,313 km dry weather; there are also 2,323 km of private,
laterite-surfaced roads open to public use, owned by rubber and timber
companies
_#_Ports: Monrovia, Buchanan, Greenville, Harper (or Cape Palmas)
_#_Merchant marine: 1,563 ships (1,000 GRT or over) totaling
53,053,254 DWT/94,597,871 DWT; includes 18 passenger, 1 short-sea
passenger, 156 cargo, 47 refrigerated cargo, 15 roll-on/roll-off cargo,
67 vehicle carrier, 74 container, 5 barge carrier, 450 petroleum, oils,
and lubricants (POL) tanker, 104 chemical, 60 combination ore/oil, 44
liquefied gas, 6 specialized tanker, 485 bulk, 1 multifunction large-load
carrier, 30 combination bulk; note--a flag of convenience registry; all
ships are foreign owned; the top four owning flags are US 19%, Japan 17%,
Hong Kong 12%, and Norway 10%; China owns at least 28 ships, Bulgaria
owns 3, and Poland owns 1
_#_Civil air: 3 major transport aircraft
_#_Airports: 75 total, 58 usable; 2 with permanent-surface runways;
none with runways over 3,659 m; 1 with runways 2,440-3,659 m; 4 with
runways 1,220-2,439 m
_#_Telecommunications: telephone and telegraph service via radio relay
network; main center is Monrovia; 8,500 telephones; stations--3 AM, 4 FM,
5 TV; 2 Atlantic Ocean INTELSAT earth stations
_*_Defense Forces
_#_Branches: Armed Forces of Liberia (includes Army, Navy, Air Force),
Coast Guard, National Police Force
_#_Manpower availability: males 15-49, 648,636; 346,349 fit for
military service; no conscription
_#_Defense expenditures: $NA, 2.4% of GDP (1987)
_%_
_@_Libya
_#_Highways: 32,500 km total; 24,000 km bituminous and bituminous
treated, 8,500 km gravel, crushed stone and earth
_#_Pipelines: crude oil 4,383 km; natural gas 1,947 km; refined
products 443 km (includes 256 km liquid petroleum gas)
_#_Ports: Tobruk, Tripoli, Banghazi, Misratah, Marsa el Brega
_#_Merchant marine: 30 ships (1,000 GRT or over) totaling 807,539
GRT/1,452,847 DWT; includes 3 short-sea passenger, 11 cargo, 4
roll-on/roll-off cargo, 11 petroleum, oils, and lubricants (POL) tanker,
1 chemical tanker
_#_Civil air: 59 major transport aircraft
_#_Airports: 131 total, 123 usable; 53 with permanent-surface runways;
7 with runways over 3,659 m; 31 with runways 2,440-3,659 m; 44 with
runways 1,220-2,439 m
_#_Telecommunications: modern telecommunications system using radio
relay, coaxial cable, tropospheric scatter, and domestic satellite
stations; 370,000 telephones; stations--18 AM, 3 FM, 13 TV; satellite
earth stations--1 Atlantic Ocean INTELSAT, 1 Indian Ocean INTELSAT, and
14 domestic; submarine cables to France and Italy; radio relay to
Tunisia; tropospheric scatter to Greece; planned ARABSAT and Intersputnik
satellite stations
_*_Defense Forces
_#_Branches: Armed Peoples of the Libyan Arab Jamahariya (includes
Army, Navy, Air Force, Air Defense Command), National Police
_#_Manpower availability: males 15-49, 1,023,335; 603,886 fit for
military service; 52,059 reach military age (17) annually;
conscription now being implemented
_#_Defense expenditures: $NA, 11.1% of GNP (1987)
_%_
_@_Liechtenstein
_#_Railroads: 18.5 km 1.435-meter standard gauge, electrified; owned,
operated, and included in statistics of Austrian Federal Railways
_#_Highways: 130.66 km main roads, 192.27 km byroads
_#_Civil air: no transport aircraft
_#_Airports: none
_#_Telecommunications: automatic telephone system; 25,400 telephones;
stations--no AM, no FM, no TV
_*_Defense Forces
_#_Branches: Police Department
_#_Note: defense is responsibility of Switzerland
_%_
_@_Luxembourg
_#_Railroads: 1.6 km 1.435-meter gauge
_#_Highways: none; city streets
_#_Ports: Monaco
_#_Merchant marine: 1 petroleum, oils, and lubricants (POL) tanker
(1,000 GRT or over) totaling 3,268 GRT/4,959 DWT
_#_Civil air: no major transport aircraft
_#_Airports: 1 usable airfield with permanent-surface runways
_#_Telecommunications: served by the French communications system;
automatic telephone system; 38,200 telephones; stations--3 AM, 4 FM, 5
TV; no communication satellite stations
_*_Defense Forces
_#_Note: defense is the responsibility of France
_%_
_@_Mongolia
_#_Railroads: 1,750 km 1.524-meter broad gauge (1988)
_#_Highways: 46,700 km total; 1,000 km hard surface; 45,700 km other
surfaces (1988)
_#_Inland waterways: 397 km of principal routes (1988)
_#_Civil air: 25 major transport aircraft
_#_Airports: 81 total, 31 usable; 11 with permanent-surface
runways; fewer than 5 with runways over 3,659 m; fewer than 20 with
runways 2,440-3,659 m; 12 with runways 1,220-2,439 m
_#_Telecommunications: stations--12 AM, 1 FM, 1 TV (with 18 provincial
relays); relay of Soviet TV; 120,000 TVs; 186,000 radios;
at least 1 earth station
_*_Defense Forces
_#_Branches: Mongolian People''s Army (includes Border Guards),
Air Force
_#_Manpower availability: males 15-49, 535,376; 349,548 fit for
military service; 25,275 reach military age (18) annually
_#_Defense expenditures: $NA, NA% of GDP
_%_
_@_Montserrat
(dependent territory of the UK)
_#_Highways: 280 km total; about 200 km paved, 80 km gravel and earth
_#_Ports: Plymouth
_#_Airports: 1 with permanent-surface runway 1,036 m
_#_Telecommunications: 3,000 telephones; stations--8 AM, 4 FM, 1 TV
_*_Defense Forces
_#_Branches: Police Force
_#_Note: defense is the responsibility of the UK
_%_
_@_Morocco
_#_Railroads: 1,893 km 1.435-meter standard gauge (246 km double
track, 974 km electrified)
_#_Highways: 59,198 km total; 27,740 km bituminous treated, 31,458 km
gravel, crushed stone, improved earth, and unimproved earth
_#_Pipelines: 362 km crude oil; 491 km (abandoned) refined products;
241 km natural gas
_#_Ports: Agadir, Casablanca, El Jorf Lasfar, Kenitra, Mohammedia,
Nador, Safi, Tangier; also Spanish-controlled Ceuta and Melilla
_#_Merchant marine: 51 ships (1,000 GRT or over) totaling 315,169
GRT/487,490 DWT; includes 10 cargo, 2 container, 12 refrigerated cargo,
6 roll-on/roll-off cargo, 3 petroleum, oils, and lubricants (POL) tanker,
11 chemical tanker, 4 bulk, 3 short-sea passenger
_#_Civil air: 23 major transport aircraft
_#_Airports: 75 total, 67 usable; 26 with permanent-surface runways;
2 with runways over 3,659 m; 13 with runways 2,440-3,659 m; 27 with
runways 1,220-2,439 m
_#_Telecommunications: good system composed of wire lines, cables, and
radio relay links; principal centers are Casablanca and Rabat, secondary
centers are Fes, Marrakech, Oujda, Tangier, and Tetouan; 280,000
telephones; stations--14 AM, 6 FM, 47 TV; 5 submarine cables; satellite
earth stations--2 Atlantic Ocean INTELSAT and 1 ARABSAT; radio relay to
Gibraltar, Spain, and Western Sahara; coaxial cable to Algeria; microwave
network linking Syria, Jordan, Egypt, Libya, Tunisia, Algeria and Morocco
_*_Defense Forces
_#_Branches: Royal Moroccan Army, Royal Moroccan Navy, Royal Moroccan
Air Force, Royal Gendarmerie, Auxiliary Forces
_#_Manpower availability: males 15-49, 6,437,152; 4,092,027 fit for
military service; 299,535 reach military age (18) annually; limited
conscription
_#_Defense expenditures: $1.4 billion, 5.2% of GDP
_%_
_@_Mozambique
_#_Railroads: 3,288 km total; 3,140 km 1.067-meter gauge; 148 km
0.762-meter narrow gauge; Malawi-Nacala, Malawi-Beira, and
Zimbabwe-Maputo lines are subject to closure because of insurgency
_#_Highways: 26,498 km total; 4,593 km paved; 829 km gravel, crushed
stone, stabilized soil; 21,076 km unimproved earth
_#_Inland waterways: about 3,750 km of navigable routes
_#_Pipelines: 306 km crude oil (not operating); 289 km refined
products
_#_Ports: Maputo, Beira, Nacala
_#_Merchant marine: 5 cargo ships (1,000 GRT or over) totaling 7,806
GRT/12,873 DWT
_#_Civil air: 5 major transport aircraft
_#_Airports: 197 total, 145 usable; 27 with permanent-surface runways;
1 with runways over 3,659 m; 5 with runways 2,440-3,659 m; 27 with
runways 1,220-2,439 m
_#_Telecommunications: fair system of troposcatter, open-wire lines,
and radio relay; 57,400 telephones; stations--15 AM, 3 FM, 1 TV;
earth stations--1 Atlantic Ocean INTELSAT and 3 domestic
_*_Defense Forces
_#_Branches: Mozambique Armed Forces (including Army, Naval
Command, Air Defense Forces, Border Guards), Militia
_#_Manpower availability: males 15-49, 3,407,234; 1,957,123 fit for
military service
_#_Defense expenditures: $NA, 8.4% of GDP (1987)
_%_
_@_Namibia
_#_Railroads: 2,341 km 1.067-meter gauge, single track
_#_Highways: 54,500 km; 4,079 km paved, 2,540 km gravel, 47,881 km
earth roads and tracks
_#_Ports: Luderitz; primary maritime outlet is Walvis Bay (South
Africa)
_#_Civil air: 2 major transport aircraft
_#_Airports: 143 total, 123 usable; 21 with permanent-surface runways;
1 with runways over 3,659 m; 4 with runways 2,440-3,659 m; 67 with
runways 1,220-2,439 m
_#_Telecommunications: good urban, fair rural services; radio relay
connects major towns, wires extend to other population centers; 62,800
telephones; stations--2 AM, 40 FM, 3 TV
_*_Defense Forces
_#_Branches: National Defense Force (Army), Police
_#_Manpower availability: males 15-49, 309,978; 183,730 fit for
military service
_#_Defense expenditures: $NA, 4.9% of GNP (1986)
_%_
_@_Nauru
_#_Railroads: 3.9 km; used to haul phosphates from the center of the
island to processing facilities on the southwest coast
_#_Highways: about 27 km total; 21 km paved, 6 km improved earth
_#_Ports: Nauru
_#_Merchant marine: 3 ships (1,000 GRT or over) totaling 31,261
GRT/39,838 DWT; includes 1 passenger-cargo, 2 bulk
_#_Civil air: 3 major transport aircraft, one on order
_#_Airports: 1 with permanent-surface runway 1,220-2,439 m
_#_Telecommunications: adequate intraisland and international radio
communications provided via Australian facilities; 1,600 telephones;
4,000 radios; stations--1 AM, no FM, no TV; 1 Pacific Ocean
INTELSAT earth station
_*_Defense Forces
_#_Branches: no regular armed forces; Directorate of the Nauru
Police Force
_#_Manpower availability: males 15-49, NA; NA fit for military service
_#_Defense expenditures: no formal defense structure
_%_
_@_Navassa Island
(territory of the US)
_#_Ports: none; offshore anchorage only
_*_Defense Forces
_#_Note: defense is the responsibility of the US
_%_
_@_Nepal
_#_Railroads: 52 km (1990), all 0.762-meter narrow gauge; all in
Terai close to Indian border; 10 km from Raxaul to Birganj is
government owned
_#_Highways: 7,080 km total (1990); 2,898 km paved, 1,660 km gravel
or crushed stone; also 2,522 km of seasonally motorable tracks
_#_Civil air: 5 major and 11 minor transport aircraft
_#_Airports: 37 total, 37 usable; 5 with permanent-surface runways','23c6c5f434a3741e6d43cdfd5cc9a96343c8f23ade5cec846df0f6d47a8a513b','internet-archive','theciaworldfactb00025gut','txt','84185fe9df79da427349cc1598fd3f69814a2085a9fc1fe0508a3fae0a870f84','https://archive.org/download/theciaworldfactb00025gut/25.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('77a86a5776121f0290c22f5904bf69c04074d2500f73d99ea65eb50436f43410',1991,'FR','France','communications',93,';
none with runways over 3,659 m; 1 with runways 2,440-3,659 m; 8 with
runways 1,220-2,439 m
_#_Telecommunications: poor telephone and telegraph service; fair
radio communication and broadcast service; international radio
communication service is poor; 50,000 telephones (1990); stations--88
AM, no FM, 1 TV; 1 Indian Ocean INTELSAT earth station
_*_Defense Forces
_#_Branches: Royal Nepalese Army, Royal Nepalese Army Air Service,
Nepalese Police Force
_#_Manpower availability: males 15-49, 4,669,421; 2,420,398 fit for
military service; 233,404 reach military age (17) annually
_#_Defense expenditures: $38 million, 2% of GDP (FY91)
_%_
_@_Netherlands
_#_Railroads: 3,037 km track (includes 1,871 km electrified and
1,800 km double track); 2,871 km 1.435-meter standard gauge operated by
Netherlands Railways (NS); 166 km privately owned
_#_Highways: 108,360 km total; 92,525 km paved (including 2,185 km
of limited access, divided highways); 15,835 km gravel, crushed stone
_#_Inland waterways: 6,340 km, of which 35% is usable by craft of
1,000 metric ton capacity or larger
_#_Pipelines: 418 km crude oil; 965 km refined products; 10,230 km
natural gas
_#_Ports: maritime--Amsterdam, Delfzijl, Den Helder, Dordrecht,
Eemshaven, Ijmuiden, Rotterdam, Scheveningen, Terneuzen, Vlissingen;
inland--29 ports
_#_Merchant marine: 344 ships (1,000 GRT or over) totaling 2,722,838
GRT/3,822,230 DWT; includes 2 short-sea passenger, 187 cargo, 32
refrigerated cargo, 23 container, 12 roll-on/roll-off cargo, 3 livestock
carrier, 12 multifunction large-load carrier, 17 petroleum, oils, and
lubricants (POL) tanker, 29 chemical tanker, 10 liquefied gas, 2
specialized tanker, 3 combination ore/oil, 9 bulk, 3 combination bulk;
note--many Dutch-owned ships are also registered in the captive
Netherlands Antilles register
_#_Civil air: 98 major transport aircraft
_#_Airports: 28 total, 28 usable; 18 with permanent-surface runways;
none with runways over 3,659 m; 12 with runways 2,440-3,659 m; 3 with
runways 1,220-2,439 m
_#_Telecommunications: highly developed, well maintained, and
integrated; extensive system of multiconductor cables, supplemented by
radio relay links; 9,418,000 telephones; stations--6 AM, 20 (33
repeaters) FM, 22 (8 repeaters) TV; 5 submarine cables; communication
satellite earth stations operating in INTELSAT (1 Indian Ocean and
2 Atlantic Ocean) and EUTELSAT systems
_*_Defense Forces
_#_Branches: Royal Netherlands Army, Royal Netherlands Navy (including
Naval Air Service and Marine Corp), Royal Netherlands Air Force, Royal
Constabulary
_#_Manpower availability: males 15-49, 4,141,910; 3,658,056 fit for
military service; 105,829 reach military age (20) annually
_#_Defense expenditures: $6.8 billion, 2.7% of GDP (1990)
_%_
_@_Netherlands Antilles
(part of the Dutch realm)
_#_Highways: 950 km total; 300 km paved, 650 km gravel and earth
_#_Ports: Willemstad, Philipsburg, Kralendijk
_#_Merchant marine: 54 ships (1,000 GRT or over) totaling 431,958
GRT/441,056 DWT; includes 4 passenger, 19 cargo, 8 refrigerated cargo,
6 container, 6 roll-on/roll-off cargo, 7 multifunction large-load
carrier, 1 chemical tanker, 1 liquefied gas, 2 bulk; note--all but a few
are foreign owned, mostly in the Netherlands
_#_Civil air: 5 major transport aircraft
_#_Airports: 7 total, 7 usable; 7 with permanent-surface runways;
none with runways over 3,659 m; 2 with runways 2,440-3,659 m; 2 with
runways 1,220-2,439 m
_#_Telecommunications: generally adequate facilities; extensive
interisland radio relay links; stations--9 AM, 4 FM, 1 TV; 2 submarine
cables; 2 Atlantic Ocean INTELSAT earth stations
_*_Defense Forces
_#_Branches: Royal Netherlands Navy, Marine Corps, Royal
Netherlands Air Force, National Guard, Police Force
_#_Manpower availability: males 15-49 49,249; 27,803 fit for military
service; 1,634 reach military age (20) annually
_#_Note: defense is responsibility of the Netherlands
_%_
_@_New Caledonia
(overseas territory of France)
_#_Highways: 6,340 km total; only about 10% paved (1987)
_#_Ports: Noumea, Nepoui, Poro, Thio
_#_Civil air: 1 major transport aircraft
_#_Airports: 29 total, 27 usable; 6 with permanent-surface runways;
none with runways over 3,659 m; 1 with runways 2,440-3,659 m; 1 with
runways 1,220-2,439 m
_#_Telecommunications: 32,578 telephones (1987); stations--5 AM, 3 FM,
7 TV; 1 Pacific Ocean INTELSAT earth station
_*_Defense Forces
_#_Branches: Gendarmerie, Police Force
_#_Manpower availability: males 15-49, 46,388; NA fit for military
service
_#_Note: defense is the responsibility of France
_%_
_@_New Zealand
_#_Railroads: 4,716 km total; all 1.067-meter gauge; 274 km double
track; 113 km electrified; over 99% government owned
_#_Highways: 92,648 km total; 49,547 km paved, 43,101 km gravel or
crushed stone
_#_Inland waterways: 1,609 km; of little importance to transportation
_#_Pipelines: 1,000 km natural gas; 160 km refined products; 150 km
condensate
_#_Ports: Auckland, Christchurch, Dunedin, Wellington, Tauranga
_#_Merchant marine: 21 ships (1,000 GRT or over) totaling 204,269
GRT/281,375 DWT; includes 5 cargo, 1 container, 4 roll-on/roll-off cargo,
1 railcar carrier, 4 petroleum, oils, and lubricants (POL) tanker,
1 liquefied gas, 5 bulk
_#_Civil air: about 40 major transport aircraft
_#_Airports: 157 total, 157 usable; 33 with permanent-surface runways;
none with runways over 3,659 m; 2 with runways 2,440-3,659 m; 46 with
runways 1,220-2,439 m
_#_Telecommunications: excellent international and domestic systems;
2,110,000 telephones; stations 64 AM, 2 FM, 14 TV; submarine cables
extend to Australia and Fiji; 2 Pacific Ocean INTELSAT earth stations
_*_Defense Forces
_#_Branches: New Zealand Army, Royal New Zealand Navy, Royal New
Zealand Air Force
_#_Manpower availability: males 15-49, 874,443; 740,831 fit for
military service; 28,814 reach military age (20) annually
_#_Defense expenditures: $832 million, 1-2% of GDP (FY90)
_%_
_@_Nicaragua
_#_Railroads: 373 km 1.067-meter gauge, government owned; majority of
system not operating; 3 km 1.435-meter gauge line at Puerto Cabezas (does
not connect with mainline)
_#_Highways: 25,930 km total; 4,000 km paved, 2,170 km
gravel or crushed stone, 5,425 km earth or graded earth, 14,335 km
unimproved; Pan-American highway 368.5 km
_#_Inland waterways: 2,220 km, including 2 large lakes
_#_Pipelines: crude oil, 56 km
_#_Ports: Corinto, El Bluff, Puerto Cabezas, Puerto Sandino, Rama
_#_Merchant marine: 2 cargo ships (1,000 GRT or over) totaling 2,161
GRT/2,500 DWT
_#_Civil air: 12 major transport aircraft
_#_Airports: 251 total, 162 usable; 10 with permanent-surface runways;
none with runways over 3,659 m; 2 with runways 2,440-3,659 m;
12 with runways 1,220-2,439 m
_#_Telecommunications: low-capacity radio relay and wire system being
expanded; connection into Central American Microwave System; 60,000
telephones; stations--45 AM, no FM, 7 TV, 3 shortwave; earth
stations--1 Intersputnik and 1 Atlantic Ocean INTELSAT
_*_Defense Forces
_#_Branches: Army, Navy, Air Force
_#_Manpower availability: males 15-49, 845,961; 521,425 fit for
military service; 44,222 reach military age (18) annually
_#_Defense expenditures: $70 million, 3.8% of GDP (1991)
_%_
_@_Niger
_#_Highways: 39,970 km total; 3,170 km bituminous, 10,330 km gravel
and laterite, 3,470 km earthen, 23,000 km tracks
_#_Inland waterways: Niger river is navigable 300 km from Niamey to
Gaya on the Benin frontier from mid-December through March
_#_Civil air: no major transport aircraft
_#_Airports: 31 total, 29 usable; 7 with permanent-surface runways;
none with runways over 3,659 m; 1 with runways 2,440-3,659 m; 12 with
runways 1,220-2,439 m
_#_Telecommunications: small system of wire, radiocommunications, and
radio relay links concentrated in southwestern area; 11,900 telephones;
stations--15 AM, 5 FM, 16 TV; satellite earth stations--1 Atlantic Ocean
INTELSAT, 1 Indian Ocean INTELSAT, and 4 domestic
_*_Defense Forces
_#_Branches: Army, Air Force, paramilitary Gendarmerie, paramilitary
Republican Guard, paramilitary Presidential Guard, paramilitary National
Police
_#_Manpower availability: males 15-49, 1,713,566; 923,634 fit for
military service; 90,801 reach military age (18) annually
_#_Defense expenditures: $20.6 million, 0.9% of GDP (1988)
_%_
_@_Nigeria
_#_Railroads: 3,505 km 1.067-meter gauge
_#_Highways: 107,990 km total 30,019 km paved (mostly
bituminous-surface treatment); 25,411 km laterite, gravel, crushed stone,
improved earth; 52,560 km unimproved
_#_Inland waterways: 8,575 km consisting of Niger and Benue Rivers and
smaller rivers and creeks
_#_Pipelines: 2,042 km crude oil; 500 km natural gas; 3,000 km refined
products
_#_Ports: Lagos, Port Harcourt, Calabar, Warri, Onne, Sapele
_#_Merchant marine: 28 ships (1,000 GRT or over) totaling 420,658
GRT/668,951 DWT; includes 18 cargo, 1 refrigerated cargo, 1
roll-on/roll-off cargo, 6 petroleum, oils, and lubricants (POL) tanker, 1
chemical tanker, 1 bulk
_#_Civil air: 76 major transport aircraft
_#_Airports: 81 total, 68 usable; 32 with permanent-surface runways;
1 with runways over 3,659 m; 14 with runways 2,440-3,659 m;
21 with runways 1,220-2,439 m
_#_Telecommunications: above-average system limited by poor
maintenance; major expansion in progress; radio relay and cable routes;
155,000 telephones; stations--37 AM, 19 FM, 38 TV; 2 Atlantic Ocean
INTELSAT, 1 Indian Ocean INTELSAT, domestic, with 19 stations; 1 coaxial
submarine cable
_*_Defense Forces
_#_Branches: Army, Navy, Air Force, paramilitary Police Force
_#_Manpower availability: males 15-49, 28,070,431; 16,040,870 fit for
military service; 1,302,970 reach military age (18) annually
_#_Defense expenditures: $300 million, 1% of GNP (1990 est.)
_%_
_@_Niue
(free association with New Zealand)
_#_Highways: 123 km all-weather roads, 106 km access and plantation
roads
_#_Ports: none; offshore anchorage only
_#_Airports: 1 with permanent-surface runway of 1,650 m
_#_Telecommunications: single-line telephone system connects all
villages on island; 383 telephones; 1,000 radio receivers (1987 est.);
stations--1 AM, 1 FM, no TV
_*_Defense Forces
_#_Branches: Police Force
_#_Note: defense is the responsibility of New Zealand
_%_
_@_Norfolk Island
(territory of Australia)
_#_Highways: 80 km of roads, including 53 km of sealed roads;
remainder are earth formed or coral surfaced
_#_Ports: none; loading jetties at Kingston and Cascade
_#_Airports: 1 with permanent-surface runways 1,220-2,439 m
(Australian owned)
_#_Telecommunications: 1,500 radio receivers (1982); radio link
service with Sydney; 987 telephones (1983); stations--1 AM, no FM, no TV
_*_Defense Forces
_#_Note: defense is the responsibility of Australia
_%_
_@_Northern Mariana Islands
(commonwealth associated with the US)
_#_Highways: 300 km total (53 km primary, 55 km secondary, 192 km
local)
_#_Ports: Saipan, Rota, Tinian
_#_Airports: 6 total, 4 usable; 3 with permanent-surface runways;
none with runways over 3,659 m; 1 with runways 2,440-3,659 m; 2 with
runways 1,220-2,439 m
_#_Telecommunications: stations--2 AM, no FM, 1 TV; 2 Pacific Ocean
INTELSAT earth stations
_*_Defense Forces
_#_Note: defense is the responsibility of the US
_%_
_@_Norway
_#_Railroads: 4,223 km 1.435-meter standard gauge; Norwegian State
Railways (NSB) operates 4,219 km (2,450 km electrified and 96 km double
track); 4 km other
_#_Highways: 79,540 km total; 18,600 km concrete, bituminous, stone
block; 19,980 km bituminous treated; 40,960 km gravel, crushed stone, and
earth
_#_Inland waterways: 1,577 km along west coast; 1.5-2.4 m draft
vessels maximum
_#_Pipelines: refined products, 53 km
_#_Ports: Oslo, Bergen, Fredrikstad, Kristiansand, Stavanger,
Trondheim
_#_Merchant marine: 867 ships (1,000 GRT or over) totaling 23,270,845
GRT/41,199,182 DWT; includes 11 passenger, 23 short-sea passenger,
121 cargo, 3 passenger-cargo, 24 refrigerated cargo, 14 container, 50
roll-on/roll-off cargo, 18 vehicle carrier, 1 railcar carrier, 186
petroleum, oils, and lubricants (POL) tanker, 98 chemical tanker, 69
liquefied gas, 1 specialized tanker, 35 combination ore/oil, 204 bulk, 9
combination bulk; note--the government has created a captive register,
the Norwegian International Ship Register (NIS), as a subset of the
Norwegian register; ships on the NIS enjoy many benefits of flags of
convenience and do not have to be crewed by Norwegians; the majority of
ships (777) under the Norwegian flag are now registered with the NIS
_#_Civil air: 76 major transport aircraft
_#_Airports: 104 total, 103 usable; 64 with permanent-surface runways;
none with runways over 3,659 m; 12 with runways 2,440-3,659 m;
16 with runways 1,220-2,439 m
_#_Telecommunications: high-quality domestic and international
telephone, telegraph, and telex services; 3,102,000 telephones;
stations--8 AM, 46 (1,400 relays) FM, 55 (2,100 relays) TV; 4 coaxial
submarine cables; communications satellite earth stations operating in
the EUTELSAT, INTELSAT (1 Atlantic Ocean), MARISAT, and domestic systems
_*_Defense Forces
_#_Branches: Norwegian Army, Royal Norwegian Navy, Royal Norwegian Air
Force, Home Guard
_#_Manpower availability: males 15-49, 1,124,201; 942,158 fit for
military service; 31,813 reach military age (20) annually
_#_Defense expenditures: $3.3 billion, 3.3% of GDP (1990)
_%_
_@_Oman
_#_Highways: 22,800 km total; 3,800 km bituminous surface, 19,000 km
motorable track
_#_Pipelines: crude oil 1,300 km; natural gas 1,030 km
_#_Ports: Mina Qabus, Mina Raysut
_#_Merchant marine: 1 passenger ship (1,000 GRT or over) totaling
4,442 GRT/1,320 DWT
_#_Civil air: 4 major transport aircraft
_#_Airports: 122 total, 114 usable; 6 with permanent-surface runways;
1 with runways over 3,659 m; 8 with runways 2,440-3,659 m; 64 with
runways 1,220-2,439 m
_#_Telecommunications: fair system of open-wire, radio relay, and
radio communications stations; 50,000 telephones; stations--3 AM, 3 FM,
11 TV; satellite earth stations--2 Indian Ocean INTELSAT, 1 ARABSAT,
and 8 domestic
_*_Defense Forces
_#_Branches: Army, Navy, Air Force, Royal Oman Police
_#_Manpower availability: males 15-49, 348,849; 197,870 fit for
military service; 20,715 reach military age (14) annually
_#_Defense expenditures: $1.0 billion, 12% of GDP (1991)
_%_
_@_Pacific Islands, Trust Territory of the
(Palau)
_#_Highways: 25.7 km paved macadam and concrete roads, otherwise
stone-, coral-, or laterite-surfaced roads (1986)
_#_Ports: Koror
_#_Airports: 2 with permanent-surface runways 1,220-2,439 m
_#_Telecommunications: stations--1 AM, 1 FM, 1 TV; 1 Pacific Ocean
INTELSAT earth station
_*_Defense Forces
_#_Note: defense is the responsibility of the US and that will not
change when the UN trusteeship terminates
_%_
_@_Pacific Ocean
_#_Ports: Bangkok (Thailand), Hong Kong, Los Angeles (US),
Manila (Philippines), Pusan (South Korea), San Francisco (US), Seattle
(US), Shanghai (China), Singapore, Sydney (Australia), Vladivostok
(USSR), Wellington (NZ), Yokohama (Japan)
_#_Telecommunications: several submarine cables with network focused
on Guam and Hawaii
_%_
_@_Pakistan
_#_Railroads: 8,773 km total; 7,718 km broad gauge, 445 km meter
gauge, and 610 km narrow gauge; 1,037 km broad-gauge double track; 286 km
electrified; all government owned (1985)
_#_Highways: 101,315 km total (1987); 40,155 km paved, 23,000 km
gravel, 29,000 km improved earth, and 9,160 km unimproved earth or sand
tracks (1985)
_#_Pipelines: 250 km crude oil; 4,044 km natural gas; 885 km refined
products (1987)
_#_Ports: Gwadar, Karachi, Port Muhammad bin Qasim
_#_Merchant marine: 29 ships (1,000 GRT or over) totaling 339,855
GRT/500,627 DWT; includes 4 passenger-cargo, 24 cargo, 1 petroleum, oils,
and lubricants (POL) tanker
_#_Civil air: 30 major transport aircraft
_#_Airports: 115 total, 105 usable; 75 with permanent-surface runways;
1 with runways over 3,659 m; 31 with runways 2,440-3,659 m; 43 with
runways 1,220-2,439 m
_#_Telecommunications: good international radiocommunication service
over microwave and INTELSAT satellite; domestic radio communications
poor; broadcast service good; 813,000 telephones (1990); stations--19 AM,
8 FM, 29 TV; earth stations--1 Atlantic Ocean INTELSAT and 2
Indian Ocean INTELSAT
_*_Defense Forces
_#_Branches: Army, Navy, Air Force, Civil Armed Forces,
National Guard
_#_Manpower availability: males 15-49, 26,840,840; 16,466,334 fit for
military service; 1,322,883 reach military age (17) annually
_#_Defense expenditures: $2.9 billion, 6% of GNP (FY91)
_%_
_@_Palmyra Atoll
(territory of the US)
_#_Ports: none; offshore anchorage in West Lagoon
_#_Airports: 1 with permanent-surface runway 1,220-2,439 m
_*_Defense Forces
_#_Note: defense is the responsibility of the US
_%_
_@_Panama
_#_Railroads: 238 km total; 78 km 1.524-meter gauge, 160 km
0.914-meter gauge
_#_Highways: 8,530 km total; 2,745 km paved, 3,270 km gravel or
crushed stone, 2,515 km improved and unimproved earth
_#_Inland waterways: 800 km navigable by shallow draft vessels; 82 km
Panama Canal
_#_Pipelines: crude oil, 130 km
_#_Ports: Cristobal, Balboa, Puerto de La Bahia de Las Minas
_#_Merchant marine: 2,932 ships (1,000 GRT or over) totaling
41,314,623 GRT/66,226,104 DWT; includes 22 passenger, 22 short-sea
passenger, 5 passenger-cargo, 1,060 cargo, 188 refrigerated cargo,
165 container, 62 roll-on/roll-off cargo, 105 vehicle carrier,
8 livestock carrier, 5 multifunction large-load carrier,
301 petroleum, oils, and lubricants (POL) tanker, 175 chemical tanker,
27 combination ore/oil, 91 liquefied gas, 8 specialized tanker, 651 bulk,
37 combination bulk; note--all but 5 are foreign owned and operated;
the top 4 foreign owners are Japan 36%, Greece 9%, Hong Kong 9%, and the
US 8%; (China owns at least 127 ships, Vietnam 10, Yugoslavia 10, Cuba 5,
Cyprus 3, and USSR 2)
_#_Civil air: 16 major transport aircraft
_#_Airports: 113 total, 101 usable; 41 with permanent-surface runways;
none with runways over 3,659 m; 2 with runways 2,440-3,659 m;
15 with runways 1,220-2,439 m
_#_Telecommunications: domestic and international facilities well
developed; connection into Central American Microwave System; 2 Atlantic
Ocean satellite antennas; 220,000 telephones; stations--91 AM, no FM,
23 TV; 1 coaxial submarine cable
_*_Defense Forces
_#_Branches: note--the Panamanian Defense Forces (PDF) ceased to exist
as a military institution shortly after the United States invaded Panama
on 20 December 1989; President Endara is attempting to restructure the
forces into a civilian police service under the new name of Panamanian
Public Forces (PPF); a Council of Public Security and National Defense
under Menalco Solis in the office of the president coordinates the
activities of the security forces; the Institutional Protection Service
under Carlos Bares is attached to the presidency
_#_Manpower availability: males 15-49, 644,895; 444,522 fit for
military service; no conscription
_#_Defense expenditures: $75.5 million, 1.5% of GDP (1990)
_%_
_@_Papua New Guinea
_#_Highways: 19,200 km total; 640 km paved, 10,960 km gravel, crushed
stone, or stabilized-soil surface, 7,600 km unimproved earth
_#_Inland waterways: 10,940 km
_#_Ports: Anewa Bay, Lae, Madang, Port Moresby, Rabaul
_#_Merchant marine: 9 ships (1,000 GRT or over) totaling 26,711
GRT/34,682 DWT; includes 5 cargo, 1 roll-on/roll-off cargo, 1 combination
ore/oil, 2 bulk
_#_Civil air: about 15 major transport aircraft
_#_Airports: 567 total, 479 usable; 19 with permanent-surface runways;
none with runways over 3,659 m; 1 with runways 2,440-3,659 m;
40 with runways 1,220-2,439 m
_#_Telecommunications: services are adequate and being improved;
facilities provide radiobroadcast, radiotelephone and telegraph, coastal
radio, aeronautical radio, and international radiocommunication services;
submarine cables extend to Australia and Guam; 51,700 telephones (1985);
stations--31 AM, 2 FM, 2 TV (1987); 1 Pacific Ocean INTELSAT earth
station
_*_Defense Forces
_#_Branches: Papua New Guinea Defense Force (including Army, Navy,
Air Force)
_#_Manpower availability: males 15-49, 983,175; 546,824 fit for
military service
_#_Defense expenditures: $42 million, 1.3% of GDP (1989 est.)
_%_
_@_Paracel Islands
_#_Ports: small Chinese port facilities on Woody Island and
Duncan Island currently under expansion
_#_Airports: 1 on Woody Island
_*_Defense Forces
_#_Note: occupied by China
_%_
_@_Paraguay
_#_Railroads: 970 km total; 440 km 1.435-meter standard gauge, 60 km
1.000-meter gauge, 470 km various narrow gauge (privately owned)
_#_Highways: 21,960 km total; 1,788 km paved, 474 km gravel, and
19,698 km earth
_#_Inland waterways: 3,100 km
_#_Ports: Asuncion
_#_Merchant marine: 14 ships (1,000 GRT or over) totaling 18,743
GRT/22,954 DWT; includes 12 cargo, 2 petroleum, oils, and lubricants
(POL) tanker; note--1 naval cargo ship is sometimes used commercially
_#_Civil air: 4 major transport aircraft
_#_Airports: 851 total, 738 usable; 6 with permanent-surface runways;
1 with runways over 3,659 m; 2 with runways 2,440-3,659 m; 60 with
runways 1,220-2,439 m
_#_Telecommunications: principal center in Asuncion; fair intercity
microwave net; 78,300 telephones; stations--40 AM, no FM, 5 TV, 7
shortwave; 1 Atlantic Ocean INTELSAT earth station
_*_Defense Forces
_#_Branches: Army, Navy (including Naval Air and Marines), Air Force
_#_Manpower availability: males 15-49, 1,130,690; 823,136 fit for
military service; 51,415 reach military age (17) annually
_#_Defense expenditures: $84 million, 1.4% of GDP (1988 est.)
_%_
_@_Peru
_#_Railroads: 1,884 km total; 1,584 km 1.435-meter standard gauge,
300 km 0.914-meter gauge
_#_Highways: 56,645 km total; 6,030 km paved, 11,865 km gravel,
14,610 km improved earth, 24,140 km unimproved earth
_#_Inland waterways: 8,600 km of navigable tributaries of Amazon
system and 208 km Lago Titicaca
_#_Pipelines: crude oil, 800 km; natural gas and natural gas liquids,
64 km
_#_Ports: Callao, Ilo, Iquitos, Matarani, Talara
_#_Merchant marine: 29 ships (1,000 GRT or over) totaling 321,541
GRT/516,859 DWT; includes 16 cargo, 1 refrigerated cargo, 1
roll-on/roll-off cargo, 3 petroleum, oils, and lubricants (POL) tanker,
8 bulk; note--in addition, 8 naval tankers and 1 naval cargo are
sometimes used commercially
_#_Civil air: 27 major transport aircraft
_#_Airports: 222 total, 205 usable; 36 with permanent-surface runways;
2 with runways over 3,659 m; 24 with runways 2,440-3,659 m; 42 with
runways 1,220-2,439 m
_#_Telecommunications: fairly adequate for most requirements;
nationwide radio relay system; 544,000 telephones; stations--273 AM, no
FM, 140 TV, 144 shortwave; 2 Atlantic Ocean INTELSAT earth stations, 12
domestic antennas
_*_Defense Forces
_#_Branches: Army (Ejercito Peruano), Navy (Marina de Guerra del
Peru), Air Force (Fuerza Aerea del Peru), Peruvian National Police
_#_Manpower availability: males 15-49, 5,704,684; 3,859,123 fit for
military service; 241,792 reach military age (20) annually
_#_Defense expenditures: $430 million, 2.4% of GDP (1991)
_%_
_@_Philippines
_#_Railroads: 378 km operable on Luzon, 34% government owned (1982)
_#_Highways: 156,000 km total (1984); 29,000 km paved; 77,000 km
gravel, crushed-stone, or stabilized-soil surface; 50,000 km unimproved
earth
_#_Inland waterways: 3,219 km; limited to shallow-draft (less than
1.5 m) vessels
_#_Pipelines: refined products, 357 km
_#_Ports: Cagayan de Oro, Cebu, Davao, Guimaras, Iloilo, Legaspi,
Manila, Subic Bay
_#_Merchant marine: 569 ships (1,000 GRT or over) totaling 8,429,829
GRT/15,171,692 DWT; includes 1 passenger, 9 short-sea passenger,
17 passenger-cargo, 163 cargo, 18 refrigerated cargo, 24 vehicle carrier,
8 livestock carrier, 10 roll-on/roll-off cargo, 8 container, 41
petroleum, oils, and lubricants (POL) tanker, 1 chemical tanker, 7
liquefied gas, 3 combination ore/oil, 252 bulk, 7 combination bulk;
note--many Philippine flag ships are foreign owned and are on the
register for the purpose of long-term bare-boat charter back to their
original owners who are principa','b3923c63f2b234116a0c9a16c77d893c97c5435d68d2ec6b2945218f0309df10','internet-archive','theciaworldfactb00025gut','txt','84185fe9df79da427349cc1598fd3f69814a2085a9fc1fe0508a3fae0a870f84','https://archive.org/download/theciaworldfactb00025gut/25.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b31063026aa6de91b497aa940fb47d8c5ba0ab097889e2fec3ca1118cca24e6a',1991,'FR','France','communications',94,'lly in Japan and Germany
_#_Civil air: 53 major transport aircraft
_#_Airports: 280 total, 235 usable; 71 with permanent-surface runways;
none with runways over 3,659 m; 9 with runways 2,440-3,659 m;
50 with runways 1,220-2,439 m
_#_Telecommunications: good international radio and submarine cable
services; domestic and interisland service adequate; 872,900 telephones;
stations--267 AM (including 6 US), 55 FM, 33 TV (including 4 US);
submarine cables extended to Hong Kong, Guam, Singapore, Taiwan, and
Japan; satellite earth stations--1 Indian Ocean INTELSAT, 2 Pacific Ocean
INTELSAT, and 11 domestic
_*_Defense Forces
_#_Branches: Army, Navy (including Coast Guard), Marine Corps, Air
Force, Constabulary
_#_Manpower availability: males 15-49, 16,254,775; 11,491,155 fit for
military service; 715,462 reach military age (20) annually
_#_Defense expenditures: $1.1 billion, 2% of GNP (1990)
_%_
_@_Pitcairn Islands
(dependent territory of the UK)
_#_Railroads: none
_#_Highways: 6.4 km dirt roads
_#_Ports: Bounty Bay
_#_Airports: none
_#_Telecommunications: 24 telephones; party line telephone service
on the island; stations--1 AM, no FM, no TV; diesel generator provides
electricity
_*_Defense Forces
_#_Note: defense is the responsibility of the UK
_%_
_@_Poland
_#_Railroads: 27,041 km total; 24,287 km 1.435-meter standard gauge,
397 km 1.520-meter broad gauge, 2,357 km narrow gauge; 8,987 km double
track; 11,016 km electrified; government owned (1989)
_#_Highways: 299,887 km total; 130,000 km improved hard surface
(concrete, asphalt, stone block); 24,000 km unimproved hard surface
(crushed stone, gravel); 100,000 km earth; 45,887 km other urban roads
(1985)
_#_Inland waterways: 3,997 km navigable rivers and canals (1989)
_#_Pipelines: 4,500 km for natural gas; 1,986 km for crude oil;
360 km for refined products (1987)
_#_Ports: Gdansk, Gdynia, Szczecin, Swinoujscie; principal
inland ports are Gliwice on Kanal Gliwice, Wroclaw on the Oder, and
Warsaw on the Vistula
_#_Merchant marine: 235 ships (1,000 GRT or over) totaling 2,957,600
GRT/4,163,820 DWT; includes 5 short-sea passenger, 92 cargo, 3
refrigerated cargo, 12 roll-on/roll-off cargo, 9 container, 3 petroleum,
oils, and lubricants (POL) tanker, 4 chemical tanker, 107 bulk; Poland
owns 1 ship (1,000 GRT or over) of 6,333 DWT operating under Liberian
registry
_#_Civil air: 48 major transport aircraft
_#_Airports: 160 total, 160 usable; 85 with permanent-surface runways;
1 with runway over 3,659 m; 35 with runways 2,440-3,659 m; 65 with
runways 1,220-2,439 m
_#_Telecommunications: phone density is 10.5 phones per 100 residents
(October 1990); 3.1 million subscribers; exchanges are 86% automatic
(February 1990); stations--29 AM, 29 FM, 37 (5 Soviet relays) TV;
9.6 million TVs
_*_Defense Forces
_#_Branches: External Front Ground Forces, Navy, Air and Air Defense
Forces, Internal Defense Forces (WOW), Territorial Defense Forces (JOT),
Border Guards (WOP), Paramilitary Forces, Civil Defense (OC)
_#_Manpower availability: males 15-49, 9,571,708; 7,543,565 fit for
military service; 302,000 reach military age (19) annually
_#_Defense expenditures: 22.3 trillion zlotych, NA% of GDP (1991);
note--conversion of defense expenditures into US dollars using the
official administratively set exchange rate would produce misleading
results
_%_
_@_Portugal
_#_Railroads: 3,613 km total; state-owned Portuguese Railroad Co. (CP)
operates 2,858 km 1.665-meter gauge (434 km electrified and 426 km double
track), 755 km 1.000-meter gauge; 12 km (1.435-meter gauge) electrified,
double track, privately owned
_#_Highways: 73,661 km total; 61,599 km paved (bituminous, gravel, and
crushed stone), including 140 km of limited-access divided highway;
7,962 km improved earth; 4,100 km unimproved earth (motorable tracks)
_#_Inland waterways: 820 km navigable; relatively unimportant to
national economy, used by shallow-draft craft limited to 300-metric-ton
cargo capacity
_#_Pipelines: crude oil, 11 km; refined products, 58 km
_#_Ports: Leixoes, Lisbon, Porto, Ponta Delgada (Azores), Velas
(Azores), Setubal, Sines
_#_Merchant marine: 52 ships (1,000 GRT or over) totaling 684,350
GRT/1,190,454 DWT; includes 1 short-sea passenger, 20 cargo,
2 refrigerated cargo, 1 container, 1 roll-on/roll-off cargo,
12 petroleum, oils, and lubricants (POL) tanker, 2 chemical tanker,
2 liquefied gas, 10 bulk, 1 combination bulk; note--Portugal has created
a captive register on Madeira (MAR) for Portuguese-owned ships that will
have the taxation and crewing benefits of a flag of convenience;
although only one ship currently is known to fly the Portuguese flag on
the MAR register, it is likely that a majority of Portuguese flag ships
will transfer to this subregister in a few years
_#_Civil air: 29 major transport aircraft
_#_Airports: 69 total, 63 usable; 36 with permanent-surface runways; 1
with runways over 3,659 m; 12 with runways 2,440-3,659 m; 7 with runways
1,220-2,439 m
_#_Telecommunications: facilities are generally adequate; 2,690,000
telephones; stations--57 AM, 66 (22 relays) FM, 25 (23 relays) TV;
7 submarine cables; communication satellite ground stations operating in
the INTELSAT (2 Atlantic Ocean and 1 Indian Ocean), EUTELSAT, and
domestic systems (mainland and Azores)
_*_Defense Forces
_#_Branches: Army, Navy (including Marines), Air Force, National
Republican Guard, Fiscal Guard, Public Security Police
_#_Manpower availability: males 15-49, 2,621,116; 2,131,628 fit for
military service; 88,718 reach military age (20) annually
_#_Defense expenditures: $1.6 billion, 3% of GDP (1990)
_%_
_@_Puerto Rico
(commonwealth associated with the US)
_#_Railroads: 100 km rural narrow-gauge system for hauling sugarcane;
no passenger railroads
_#_Highways: 13,762 km paved
_#_Ports: San Juan, Ponce, Mayaguez, Arecibo
_#_Airports: 33 total; 23 usable; 19 with permanent-surface runways;
none with runways over 3,659 m; 3 with runways 2,440-3,659 m;
4 with runways 1,220-2,439 m
_#_Telecommunications: 900,000 or 99% of total households with TV;
1,067,787 telephones (1988); stations--50 AM, 63 FM, 9 TV (1990)
_*_Defense Forces
_#_Branches: paramilitary National Guard, Police Force
_#_Manpower availability: males 15-49, 830,133; NA fit for military
service
_#_Note: defense is the responsibility of the US
_%_
_@_Qatar
_#_Highways: 1,500 km total; 1,000 km bituminous, 500 km gravel or
natural surface (est.)
_#_Pipelines: crude oil, 235 km; natural gas, 400 km
_#_Ports: Doha, Umm Said, Halul Island
_#_Merchant marine: 20 ships (1,000 GRT or over) totaling 465,371
GRT/707,089 DWT; includes 12 cargo, 5 container, 3 petroleum, oils, and
lubricants (POL) tanker
_#_Civil air: 3 major transport aircraft
_#_Airports: 4 total, 4 usable; 1 with permanent-surface runways;
1 with runways over 3,659 m; none with runways 2,440-3,659 m;
2 with runways 1,220-2,439 m
_#_Telecommunications: modern system centered in Doha; 110,000
telephones; tropospheric scatter to Bahrain; radio relay to Saudi Arabia;
submarine cable to Bahrain and UAE; stations--2 AM, 1 FM, 3 TV;
earth stations--1 Atlantic Ocean INTELSAT, 1 Indian Ocean INTELSAT,
1 ARABSAT
_*_Defense Forces
_#_Branches: Army, Navy, Air Force, Police Department
_#_Manpower availability: males 15-49, 235,516; 125,591 fit for
military service; 4,243 reach military age (18) annually
_#_Defense expenditures: $500 million, 8% of GDP (1989)
_%_
_@_Reunion
(overseas department of France)
_#_Highways: 2,800 km total; 2,200 km paved, 600 km gravel, crushed
stone, or stabilized earth
_#_Ports: Pointe des Galets
_#_Civil air: 1 major transport aircraft
_#_Airports: 2 total, 2 usable; 2 with permanent-surface runways;
none with runways over 3,659 m; 1 with runways 2,440-3,659 m;
1 with runways 1,220-2,439 m
_#_Telecommunications: adequate system for needs; modern open-wire
line and radio relay network; principal center Saint-Denis;
radiocommunication to Comoros, France, Madagascar; new radio relay route
to Mauritius; 85,900 telephones; stations--3 AM, 13 FM, 1 (18 relays) TV;
1 Indian Ocean INTELSAT earth station
_*_Defense Forces
_#_Manpower availability: males 15-49, 162,017; 83,959 fit for
military service; 5,979 reach military age (18) annually
_#_Note: defense is the responsibility of France
_%_
_@_Romania
_#_Railroads: 11,275 km total; 10,860 km 1.435-meter standard gauge,
370 km narrow gauge, 45 km broad gauge; 3,411 km electrified, 3,060 km
double track; government owned (1987)
_#_Highways: 72,799 km total; 15,762 km concrete, asphalt, stone
block; 20,208 km asphalt treated; 27,729 km gravel, crushed stone, and
other paved surfaces; 9,100 km unpaved roads (1985)
_#_Inland waterways: 1,724 km (1984)
_#_Pipelines: 2,800 km crude oil; 1,429 km refined products; 6,400 km
natural gas
_#_Ports: Constanta, Galati, Braila, Mangalia; inland ports are
Giurgiu, Drobeta-Turnu Severin, Orsova
_#_Merchant marine: 294 ships (1,000 GRT or over) totaling 3,767,465
GRT/5,893,700 DWT; includes 1 passenger-cargo, 191 cargo, 2 container,
1 rail-car carrier, 11 roll-on/roll-off cargo, 2 livestock carrier,
15 petroleum, oils, and lubricants (POL) tanker, 69 bulk, 2 combination
ore/oil
_#_Civil air: 59 major transport aircraft
_#_Airports: 165 total, 165 usable; 25 with permanent-surface runways;
15 with runways 2,440-3,659 m; 15 with runways 1,220-2,439 m
_#_Telecommunications: about 2.3 million telephone customers; 89%
of phone network is automatic; present phone density is 9.85 per 100
residents; roughly 3,300 villages with no service (February 1990);
stations--39 AM, 29 FM, 39 TV (1990)
_*_Defense Forces
_#_Branches: French--Army, Navy, Air Force, Gendarmerie
_#_Manpower availability: males 15-49, 5,801,986; 4,912,789 fit for
military service; 192,996 reach military age (20) annually
_#_Defense expenditures: 15 billion lei (unofficial), NA% of GDP
(1991); note--conversion of defense expenditures into US dollars using
the official administratively set exchange rate would produce misleading
results
_%_
_@_Rwanda
_#_Highways: 4,885 km total; 460 km paved, 1,725 km gravel and/or
improved earth, 2,700 km unimproved
_#_Inland waterways: Lac Kivu navigable by shallow-draft barges and
native craft
_#_Civil air: 1 major transport aircraft
_#_Airports: 8 total, 8 usable; 3 with permanent-surface runways;
none with runways over 3,659 m; 1 with runways 2,440-3,659 m;
2 with runways 1,220-2,439 m
_#_Telecommunications: fair system with low-capacity radio relay
system centered on Kigali; 6,600 telephones; stations--2 AM, 5 FM, no TV;
earth stations--1 Indian Ocean INTELSAT and 1 SYMPHONIE
_*_Defense Forces
_#_Branches: Army, Gendarmerie
_#_Manpower availability: males 15-49, 1,651,224; 842,480 fit for
military service; no conscription
_#_Defense expenditures: $37 million, 1.6% of GDP (1988 est.)
_%_
_@_Saint Helena
(dependent territory of the UK)
_#_Highways: 87 km bitumen-sealed roads, 20 km earth roads on
Saint Helena; 80 km bitumen-sealed on Ascension; 2.7 km bitumen-sealed on
Tristan da Cunha
_#_Ports: Jamestown (Saint Helena), Georgetown (Ascension)
_#_Merchant marine: 1 passenger-cargo ship totaling 6,767 GRT/5,600
DWT
_#_Airports: 1 with permanent-surface runway 2,440-3,659 m on
Ascension
_#_Telecommunications: 1,500 radio receivers; stations--1 AM,
no FM, no TV; 550 telephones in automatic network; HF radio links to
Ascension, then into worldwide submarine cable and satellite networks;
major coaxial cable relay point between South Africa, Portugal, and UK at
Ascension; 2 Atlantic Ocean INTELSAT earth stations
_*_Defense Forces
_#_Note: defense is the responsibility of the UK
_%_
_@_Saint Kitts and Nevis
_#_Railroads: 58 km 0.760-meter narrow gauge on Saint Kitts for
sugarcane
_#_Highways: 300 km total; 125 km paved, 125 km otherwise improved,
50 km unimproved earth
_#_Ports: Basseterre (Saint Kitts), Charlestown (Nevis)
_#_Civil air: no major transport aircraft
_#_Airports: 2 total, 2 usable; 2 with permanent-surface runways;
none with runways over 3,659 m; 1 with runways 2,440-3,659 m;
none with runways 1,220-2,439 m
_#_Telecommunications: good interisland VHF/UHF/SHF radio connections
and international link via Antigua and Barbuda and Saint Martin;
2,400 telephones; stations--2 AM, no FM, 4 TV
_*_Defense Forces
_#_Branches: Royal Saint Kitts and Nevis Police Force, Coast Guard
_#_Manpower availability: males 15-49, 38,090; NA fit for military
service
_#_Defense expenditures: $NA, NA% of GDP
_%_
_@_Saint Lucia
_#_Highways: 760 km total; 500 km paved; 260 km otherwise improved
_#_Ports: Castries
_#_Civil air: 2 major transport aircraft
_#_Airports: 2 total, 2 usable; 2 with permanent-surface runways;
none with runways over 3,659 m; 1 with runways 2,440-3,659 m;
1 with runways 1,220-2,439
_#_Telecommunications: fully automatic telephone system;
9,500 telephones; direct radio relay link with Martinique and
Saint Vincent and the Grenadines; interisland troposcatter link to
Barbados; stations--4 AM, 1 FM, 1 TV (cable)
_*_Defense Forces
_#_Branches: Royal Saint Lucia Police Force, Coast Guard
_#_Manpower availability: males 15-49, 38,050; NA fit for military
service
_#_Defense expenditures: $NA, NA% of GDP
_%_
_@_Saint Pierre and Miquelon
(territorial collectivity of France)
_#_Highways: 120 km total; 60 km paved (1985)
_#_Ports: Saint Pierre
_#_Civil air: no major transport aircraft
_#_Airports: 2 total, 2 usable; 2 with permanent-surface runways,
none with runways over 2,439 m; 1 with runway 1,220-2,439 m
_#_Telecommunications: 3,601 telephones; stations--1 AM, 3 FM, no TV;
radiotelecommunication with most countries in the world; 1
earth station in French domestic system
_*_Defense Forces
_#_Note: defense is the responsibility of France
_%_
_@_Saint Vincent and the Grenadines','1ab1106675be97dff8644dde8f57488d35aab4a5e2128a854baa1d10b875f7e2','internet-archive','theciaworldfactb00025gut','txt','84185fe9df79da427349cc1598fd3f69814a2085a9fc1fe0508a3fae0a870f84','https://archive.org/download/theciaworldfactb00025gut/25.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('22de1d2dcfb1ec70da5d4a8bd5e05dfa3616a603bb2cdeebde3d7df633466ae8',1991,'LU','Luxembourg','communications',108,'_#_Railroads: Luxembourg National Railways (CFL) operates 270 km
1.435-meter standard gauge; 162 km double track; 162 km electrified
_#_Highways: 5,108 km total; 4,995 km paved, 57 km gravel, 56 km
earth; about 80 km limited access divided highway
_#_Inland waterways: 37 km; Moselle River
_#_Pipelines: refined products, 48 km
_#_Ports: Mertert (river port)
_#_Merchant marine: 1 petroleum, oils, and lubricants (POL) tanker
(1,000 GRT or over) totaling 1,731 GRT/2,460 DWT
_#_Civil air: 13 major transport aircraft
_#_Airports: 2 total, 2 usable; 1 with permanent-surface runways;
1 with runways over 3,659 m; 1 with runways less than 1,220 m
_#_Telecommunications: adequate and efficient system, mainly buried
cables; 230,000 telephones; stations--2 AM, 4 FM, 6 TV; 2 communication
satellite earth stations operating in EUTELSAT and domestic systems
_*_Defense Forces
_#_Branches: Army, National Gendarmerie
_#_Manpower availability: males 15-49, 100,476; 83,724 fit for
military service; 2,297 reach military age (19) annually
_#_Defense expenditures: $90 million, 1.2% of GDP (1990)
_%_
_@_Macau
(overseas territory of Portugal)','620befc0c34ab91c451c87865dbf124e6d499dac520585415eefd46dd8637edb','internet-archive','theciaworldfactb00025gut','txt','84185fe9df79da427349cc1598fd3f69814a2085a9fc1fe0508a3fae0a870f84','https://archive.org/download/theciaworldfactb00025gut/25.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('75e5bce6b0a1a7adaca905ef4d2ee9b7153ba89d4c422b96ddb8efd5a47dd0ca',1991,'CN','China','communications',115,'_#_Highways: 42 km paved
_#_Ports: Macau
_#_Civil air: no major transport aircraft
_#_Airports: none useable, 1 under construction; 1 seaplane station
_#_Telecommunications: fairly modern communication facilities
maintained for domestic and international services; 52,000 telephones;
stations--4 AM, 3 FM, no TV; 75,000 radio receivers (est.); international
high-frequency radio communication facility; access to international
communications carriers provided via Hong Kong and China; 1 Indian Ocean
INTELSAT earth station
_*_Defense Forces
_#_Manpower availability: males 15-49, 167,289; 93,142 fit for
military service
_#_Note: defense is responsibility of Portugal
_%_
_@_Madagascar
_#_Railroads: 1,020 km 1.000-meter gauge
_#_Highways: 40,000 km total; 4,694 km paved, 811 km crushed stone,
gravel, or stabilized soil, 34,495 km improved and unimproved
earth (est.)
_#_Inland waterways: of local importance only; isolated streams and
small portions of Canal des Pangalanes
_#_Ports: Toamasina, Antsiranana, Mahajanga, Toliara
_#_Merchant marine: 14 ships (1,000 GRT or over) totaling 59,416
GRT/82,869 DWT; includes 9 cargo, 2 roll-on/roll-off cargo, 1 petroleum,
oils, and lubricants (POL) tanker, 1 chemical tanker, 1 liquefied gas
_#_Civil air: 5 major transport aircraft
_#_Airports: 148 total, 115 usable; 30 with permanent-surface runways;
none with runways over 3,659 m; 3 with runways 2,440-3,659 m; 42 with
runways 1,220-2,439 m
_#_Telecommunications: above average system includes open-wire lines,
coaxial cables, radio relay, and troposcatter links; submarine cable to
Bahrain; satellite earth stations--1 Indian Ocean INTELSAT and 1 Atlantic
Ocean INTELSAT; over 38,200 telephones; stations--14 AM, 1 FM, 7 (30
repeaters) TV
_*_Defense Forces
_#_Branches: Popular Armed Forces (includes Intervention Forces,
Development Forces, Aeronaval Forces--includes Navy and Air Force),
Gendarmerie, Presidential Security Regiment
_#_Manpower availability: males 15-49, 2,637,866; 1,570,393 fit for
military service; 119,882 reach military age (20) annually
_#_Defense expenditures: $37 million, 2.2% of GDP (1989 est.)
_%_
_@_Malawi
_#_Railroads: 789 km 1.067-meter gauge
_#_Highways: 13,135 km total; 2,364 km paved; 251 km crushed stone,
gravel, or stabilized soil; 10,520 km earth and improved earth
_#_Inland waterways: Lake Nyasa (Lake Malawi); Shire River, 144 km
_#_Ports: Chipoka, Monkey Bay, Nkhata Bay, and Nkotakota--all on Lake
Nyasa (Lake Malawi)
_#_Civil air: 3 major transport aircraft
_#_Airports: 48 total, 46 usable; 6 with permanent-surface runways;
none with runways over 3,659 m; 1 with runways 2,440-3,659 m; 9 with
runways 1,220-2,439 m
_#_Telecommunications: fair system of open-wire lines, radio relay
links, and radio communication stations; 36,800 telephones; stations--8
AM, 4 FM, no TV; satellite earth stations--1 Indian Ocean INTELSAT and 1
Atlantic Ocean INTELSAT
_#_Note: a majority of exports would normally go through Mozambique
on the Beira or Nacala railroads, but now most go through South Africa
because of insurgent activity and damage to rail lines
_*_Defense Forces
_#_Branches: Army (includes Air Wing and Naval Detachment),
Police (includes paramilitary Mobile Force Unit), paramilitary
Malawi Young Pioneers
_#_Manpower availability: males 15-49, 1,960,082; 995,864 fit for
military service
_#_Defense expenditures: $22 million, 1.6% of GDP (1989 est.)
_%_
_@_Malaysia
_#_Railroads:
Peninsular Malaysia--1,665 km 1.04-meter gauge; 13 km double
track, government owned;
Sabah--136 km 1.000-meter gauge
_#_Highways:
Peninsular Malaysia--23,600 km (19,352 km hard surfaced, mostly
bituminous-surface treatment, and 4,248 km unpaved);
Sabah--3,782 km;
Sarawak--1,644 km
_#_Inland waterways:
Peninsular Malaysia--3,209 km;
Sabah--1,569 km;
Sarawak--2,518 km
_#_Ports: Tanjong Kidurong, Kota Kinabalu, Kuching, Pasir Gudang,
Penang, Port Kelang, Sandakan, Tawau
_#_Merchant marine: 157 ships (1,000 GRT or over) totaling 1,530,756
GRT/2,246,358 DWT; includes 1 short-sea passenger, 65 cargo, 22
container, 2 vehicle carrier, 2 roll-on/roll-off cargo, 1 livestock
carrier, 31 petroleum, oils, and lubricants (POL) tanker, 3 chemical
tanker, 6 liquefied gas, 1 passenger-cargo, 23 bulk
_#_Civil air: 53 major transport aircraft
_#_Pipelines: crude oil, 1,307 km; natural gas, 379 km
_#_Airports: 125 total, 119 usable; 32 with permanent-surface runways;
1 with runways over 3,659 m; 7 with runways 2,440-3,659 m; 18 with
runways 1,220-2,439 m
_#_Telecommunications: good intercity service provided to peninsular
Malaysia mainly by microwave relay, adequate intercity radio relay
network between Sabah and Sarawak via Brunei; international service good;
good coverage by radio and television broadcasts; 994,860 telephones
(1984); stations--28 AM, 3 FM, 33 TV; submarine cables extend to India
and Sarawak; SEACOM submarine cable links to Hong Kong and Singapore;
satellite earth stations--1 Indian Ocean INTELSAT and 1 Pacific Ocean
INTELSAT, and 2 domestic
_*_Defense Forces
_#_Branches: Royal Malaysian Army, Royal Malaysian Navy, Royal
Malaysian Air Force, Royal Malaysian Police Force, Marine Police,
Sarawak Border Scouts
_#_Manpower availability: males 15-49, 4,620,418; 2,815,910 fit for
military service; 180,991 reach military age (21) annually
_#_Defense expenditures: $1.7 billion, 3.9% of GDP (1990)
_%_
_@_Maldives
_#_Highways: Male has 9.6 km of coral highways within the city
_#_Ports: Male, Gan
_#_Merchant marine: 17 ships (1,000 GRT or over) totaling 53,131
GRT/85,770 DWT; includes 14 cargo, 1 container, 1 petroleum, oils, and
lubricants (POL) tanker, 1 bulk
_#_Civil air: 1 major transport aircraft
_#_Airports: 2 with permanent-surface runways 2,440-3,659 m
_#_Telecommunications: minimal domestic and international facilities;
2,804 telephones; stations--2 AM, 1 FM, 1 TV; 1 Indian Ocean INTELSAT
earth station
_*_Defense Forces
_#_Branches: National Security Service (paramilitary police force)
_#_Manpower availability: males 15-49, 50,788; 28,378 fit for military
service
_#_Defense expenditures: $1.8 million, NA% of GDP (1984 est.)
_%_
_@_Mali
_#_Railroads: 642 km 1.000-meter gauge; linked to Senegal''s rail
system through Kayes
_#_Highways: about 15,700 km total; 1,670 km bituminous, 3,670 km
gravel and improved earth, 10,360 km unimproved earth
_#_Inland waterways: 1,815 km navigable
_#_Civil air: no major transport aircraft
_#_Airports: 37 total, 29 usable; 8 with permanent-surface runways;
none with runways over 3,659 m; 6 with runways 2,440-3,659 m; 10 with
runways 1,220-2,439 m
_#_Telecommunications: domestic system poor but improving; provides
only minimal service with radio relay, wire, and radio communications
stations; expansion of radio relay in progress; 11,000 telephones;
stations--2 AM, 2 FM, 2 TV; satellite earth stations--1 Atlantic Ocean
INTELSAT and 1 Indian Ocean INTELSAT
_*_Defense Forces
_#_Branches: Army, Air Force; paramilitary Gendarmerie,
Republican Guard, National Guard, National Police
_#_Manpower availability: males 15-49, 1,631,445; 940,954 fit for
military service; no conscription
_#_Defense expenditures: $45 million, 2.4% of GDP (1988)
_%_
_@_Malta
_#_Highways: 1,291 km total; 1,179 km paved (asphalt), 77 km crushed
stone or gravel, 35 km improved and unimproved earth
_#_Ports: Valletta, Marsaxlokk
_#_Merchant marine: 415 ships (1,000 GRT or over) totaling 5,005,791
GRT/8,644,369 DWT; includes 3 passenger, 8 short-sea passenger, 160
cargo, 5 container, 2 passenger-cargo, 13 roll-on/roll-off cargo, 3
vehicle carrier, 1 barge carrier, 6 refrigerated cargo, 9 chemical
tanker, 8 combination ore/oil, 2 specialized tanker, 1 liquefied gas,
79 petroleum, oils, and lubricants (POL) tanker, 104 bulk, 11 combination
bulk; note--a flag of convenience registry; China owns 1 ship, USSR owns
7, Cuba owns 7, and Vietnam owns 1
_#_Civil air: 7 major transport aircraft
_#_Airports: 1 with permanent-surface runways 2,440-3,659 m
_#_Telecommunications: modern automatic system centered in Valletta;
163,800 telephones; stations--9 AM, 4 FM, 2 TV; 1 submarine cable;
1 Atlantic Ocean INTELSAT earth station
_*_Defense Forces
_#_Branches: Armed Forces, Maltese Police Force
_#_Manpower availability: males 15-49, 94,081; 75,222 fit for military
service
_#_Defense expenditures: $21.9 million, 1.3% of GDP (1989 est.)
_%_
_@_Man, Isle of
(British crown dependency)
_#_Railroads: 36 km electric track, 24 km steam track
_#_Highways: 640 km motorable roads
_#_Ports: Douglas, Ramsey, Peel
_#_Merchant marine: 73 ships (1,000 GRT or over) totaling 1,634,471
GRT/2,906,039 DWT; includes 8 cargo, 6 container, 6 roll-on/roll-off
cargo, 31 petroleum, oils, and lubricants (POL) tanker, 4 chemical
tanker, 2 combination ore/oil, 3 liquefied gas, 13 bulk; note--a captive
register of the United Kingdom, although not all ships on the register
are British-owned
_#_Airports: 2 total; 1 usable with permanent-surface runways
1,220-2,439 m
_#_Telecommunications: 24,435 telephones; stations--1 AM, 4 FM, 4 TV
_*_Defense Forces
_#_Note: defense is the responsibility of the UK
_%_
_@_Marshall Islands
_#_Highways: macadam and concrete roads on major islands (Majuro,
Kwajalein), otherwise stone-, coral-, or laterite-surfaced roads and
tracks
_#_Ports: Majuro
_#_Merchant marine: 23 ships (1,000 GRT or over) totaling 1,654,871
GRT/3,236,549 DWT; includes 2 cargo, 3 container, 7 petroleum, oils, and
lubricants (POL) tanker, 11 bulk carrier; note--a flag of convenience
registry
_#_Airports: 5 total, 5 usable; 4 with permanent-surface runways;
5 with runways 1,220-2,439 m
_#_Telecommunications: telephone network--570 lines (Majuro) and 186
(Ebeye); telex services; islands interconnected by shortwave radio (used
mostly for government purposes); stations--1 AM, 2 FM, 1 TV, 1 shortwave;
2 Pacific Ocean INTELSAT earth stations; US Government satellite
communications system on Kwajalein
_*_Defense Forces
_#_Note: defense is the responsibility of the US
_%_
_@_Martinique
(overseas department of France)
_#_Highways: 1,680 km total; 1,300 km paved, 380 km gravel and earth
_#_Ports: Fort-de-France
_#_Civil air: no major transport aircraft
_#_Airports: 2 total; 2 usable; 1 with permanent-surface runways;
1 with runways 2,440-3,659 m; 1 with runways less than 2,439 m
_#_Telecommunications: domestic facilities are adequate; 68,900
telephones; interisland radio relay links to Guadeloupe, Dominica, and
Saint Lucia; stations--1 AM, 6 FM, 10 TV; 2 Atlantic Ocean INTELSAT earth
stations
_*_Defense Forces
_#_Branches: French Forces, Gendarmerie
_#_Manpower availability: males 15-49, 95,235; NA fit for military
service
_#_Note: defense is the responsibility of France
_%_
_@_Mauritania
_#_Railroads: 670 km 1.435-meter standard gauge, single track, owned
and operated by government mining company
_#_Highways: 7,525 km total; 1,685 km paved; 1,040 km gravel, crushed
stone, or otherwise improved; 4,800 km unimproved roads, trails, tracks
_#_Inland waterways: mostly ferry traffic on the Senegal River
_#_Ports: Nouadhibou, Nouakchott
_#_Merchant marine: 1 cargo ship (1,000 GRT or over) totaling
1,290 GRT/1,840 DWT
_#_Civil air: 2 major transport aircraft
_#_Airports: 30 total, 29 usable; 9 with permanent-surface runways;
none with runways over 3,659 m; 4 with runways 2,440-3,659 m; 17 with
runways 1,220-2,439 m
_#_Telecommunications: poor system of cable and open-wire lines, minor
radio relay links, and radio communications stations; 5,200 telephones;
stations--2 AM, no FM, 1 TV; satellite earth stations--1 Atlantic Ocean
INTELSAT and 2 ARABSAT, with a third planned
_*_Defense Forces
_#_Branches: Army, Navy, Air Force, National Gendarmerie, National
Guard, National Police, Presidential Guard, Nomad Security Guard
_#_Manpower availability: males 15-49, 423,501; 206,733 fit for
military service; conscription law not implemented
_#_Defense expenditures: $37 million, 4.2% of GDP (1987)
_%_
_@_Mauritius
_#_Highways: 1,800 km total; 1,640 km paved, 160 km earth
_#_Ports: Port Louis
_#_Merchant marine: 9 ships (1,000 GRT or over) totaling 94,619
GRT/140,345 DWT; includes 2 passenger-cargo, 2 cargo, 1 container,
1 roll-on/roll-off cargo, 1 liquefied gas, 2 bulk
_#_Civil air: 4 major transport aircraft
_#_Airports: 5 total, 4 usable; 2 with permanent-surface runways;
none with runways over 3,659 m; 1 with runways 2,440-3,659 m;
3 with runways 1,220-2,439 m
_#_Telecommunications: small system with good service; new microwave
link to Reunion; high-frequency radio links to several countries; 48,000
telephones; stations--2 AM, no FM, 4 TV; 1 Indian Ocean INTELSAT earth
station
_*_Defense Forces
_#_Branches: paramilitary Special Mobile Force, Special Support Units,
National Police Force, National Coast Guard
_#_Manpower availability: males 15-49, 302,588; 155,176 fit for
military service
_#_Defense expenditures: $4 million, 0.2% of GDP (1988)
_%_
_@_Mayotte
(territorial collectivity of France)
_#_Highways: 42 km total; 18 km bituminous
_#_Civil air: no major transport aircraft
_#_Airports: 1 with permanent-surface runway 1,220-2,439 m
_#_Ports: Dzaoudzi
_#_Telecommunications: small system administered by French Department
of Posts and Telecommunications; includes radio relay and high-frequency
radio communications for links with Comoros and international
communications; 450 telephones; stations--1 AM, no FM, no TV
_*_Defense Forces
_#_Note: defense is the responsibility of France
_%_
_@_Mexico
_#_Railroads: 20,680 km total; 19,950 km 1.435-meter standard gauge;
730 km 0.914-meter narrow gauge
_#_Highways: 210,000 km total; 65,000 km paved, 30,000 km semipaved or
cobblestone, 60,000 km rural roads (improved earth) or roads under
construction, 55,000 km unimproved earth roads
_#_Inland waterways: 2,900 km navigable rivers and coastal canals
_#_Pipelines: crude oil, 28,200 km; refined products, 10,150 km;
natural gas, 13,254 km; petrochemical, 1,400 km
_#_Ports: Acapulco, Coatzacoalcos, Ensenada, Guaymas, Manzanillo,
Mazatlan, Progreso, Puerto Vallarta, Salina Cruz, Tampico, Veracruz
_#_Merchant marine: 64 ships (1,000 GRT or over) totaling 999,423
GRT/1,509,939 DWT; includes 4 short-sea passenger, 9 cargo, 2
refrigerated cargo, 2 roll-on/roll-off cargo, 31 petroleum, oils, and
lubricants (POL) tanker, 3 chemical tanker, 7 liquefied gas, 3 bulk, 3
combination bulk
_#_Civil air: 174 major transport aircraft
_#_Airports: 1,815 total, 1,537 usable; 195 with permanent-surface
runways; 2 with runways over 3,659 m; 33 with runways 2,440-3,659 m;
276 with runways 1,220-2,439 m
_#_Telecommunications: highly developed system with extensive radio
relay links; connection into Central American Microwave System; 6.41
million telephones; stations--679 AM, no FM, 238 TV, 22 shortwave; 120
domestic satellite terminals; earth stations--4 Atlantic Ocean
INTELSAT and 1 Pacific Ocean INTELSAT
_*_Defense Forces
_#_Branches: National Defense (includes Army and Air Force), Navy
(includes Marines)
_#_Manpower availability: males 15-49, 22,340,628; 16,360,596 fit for
military service; 1,107,163 reach military age (18) annually
_#_Defense expenditures: $1 billion, 0.6% of GDP (1988)
_%_
_@_Micronesia, Federated States of','f8edc403b4b0fdecb814909519369f007d35291c605b91bddf56ed32c25ba489','internet-archive','theciaworldfactb00025gut','txt','84185fe9df79da427349cc1598fd3f69814a2085a9fc1fe0508a3fae0a870f84','https://archive.org/download/theciaworldfactb00025gut/25.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('67af4cc218f10f7e9ff53a656c9def064af789667dbce5a4c14f49742abc5262',1991,'ID','Indonesia','communications',119,'_#_Highways: 39 km of paved macadam and concrete roads on major
islands, otherwise 187 km stone-, coral-, or laterite-surfaced roads
_#_Ports: Colonia (Yap), Truk (Kosrae), Okat (Kosrae)
_#_Airports: 11 total, 10 usable; 7 with permanent-surface runways;
none with runways over 2,439 m; 6 with runways 1,220-2,439
_#_Telecommunications: 16,000 radio receivers, 1,125 TV sets (est.
1987); telephone network--960 telephone lines at both Kolonia and Truk;
islands interconnected by shortwave radio (used mostly for government
purposes); stations--5 AM, 1 FM, 6 TV, 1 shortwave; 4 Pacific Ocean
INTELSAT earth stations
_*_Defense Forces
_#_Note: defense is the responsibility of the US
_%_
_@_Midway Islands
(territory of the US)
_#_Highways: 32 km total
_#_Pipelines: 7.8 km
_#_Ports: Sand Island
_#_Airports: 3 total; 2 usable; 1 with permanent-surface runways;
none with runways over 2,439 m; 2 with runways 1,220-2,439 m
_*_Defense Forces
_#_Note: defense is the responsibility of the US
_%_
_@_Monaco','93a860d4f5012744130b69e79c79e39f258f890f0f4230eda096d6bd2ca4b93c','internet-archive','theciaworldfactb00025gut','txt','84185fe9df79da427349cc1598fd3f69814a2085a9fc1fe0508a3fae0a870f84','https://archive.org/download/theciaworldfactb00025gut/25.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ed9f8876344a30432199aac467cb34dbd18461802323c2dfbc08f96fced084a8',1991,'GD','Grenada','communications',124,'_#_Highways: about 1,000 km total; 300 km paved; 400 km improved;
300 km unimproved
_#_Ports: Kingstown
_#_Merchant marine: 242 ships (1,000 GRT or over) totaling 1,855,061
GRT/2,919,872 DWT; includes 1 passenger, 2 passenger-cargo, 132 cargo,
11 container, 15 roll-on/roll-off cargo, 9 refrigerated cargo,
13 petroleum, oils, and lubricants (POL) tanker, 4 chemical tanker,
4 liquefied gas, 44 bulk, 6 combination bulk, 1 vehicle carrier;
note--China owns 3 ships; a flag of convenience registry
_#_Civil air: no major transport aircraft
_#_Airports: 6 total, 6 usable; 4 with permanent-surface runways;
none with runways over 2,439 m; 1 with runways 1,220-2,439 m
_#_Telecommunications: islandwide fully automatic telephone system;
6,500 telephones; VHF/UHF interisland links to Barbados and the
Grenadines; new SHF links to Grenada and Saint Lucia;
stations--2 AM, no FM, 1 TV (cable)
_*_Defense Forces
_#_Branches: Royal Saint Vincent and the Grenadines Police Force,
Coast Guard
_#_Manpower availability: males 15-49, 28,339; NA fit for military
service
_#_Defense expenditures: $NA, NA% of GDP
_%_
_@_San Marino
_#_Highways: 104 km
_#_Telecommunications: automatic telephone system; 11,700 telephones;
stations--no AM, 20 FM, no TV; radio relay and cable links into Italian
networks; no communication satellite facilities
_*_Defense Forces
_#_Branches: public security or police force of less than 50 people
_#_Manpower availability: all fit men ages 16-60 constitute a militia
that can serve as an army
_#_Defense expenditures: $NA, NA% of GDP
_%_
_@_Sao Tome and Principe
_#_Highways: 300 km (two-thirds are paved); roads on Principe are
mostly unpaved and in need of repair
_#_Ports: Sao Tome, Santo Antonio
_#_Civil air: 8 major transport aircraft
_#_Airports: 2 total, 2 usable; 2 with permanent-surface runways
1,220-2,439 m
_#_Telecommunications: minimal system; 2,200 telephones; stations--1
AM, 2 FM, no TV; 1 Atlantic Ocean INTELSAT earth station
_*_Defense Forces
_#_Branches: Army, Navy, National Police
_#_Manpower availability: males 15-49, 28,984; 15,287 fit for military
service
_#_Defense expenditures: $NA, 1.6% of GDP (1980)
_%_
_@_Saudi Arabia','708f8ebdb7a129a04df14163992a2a13f8473cee52c1eef6448725576620e867','internet-archive','theciaworldfactb00025gut','txt','84185fe9df79da427349cc1598fd3f69814a2085a9fc1fe0508a3fae0a870f84','https://archive.org/download/theciaworldfactb00025gut/25.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5c24cbf277e038d89db9e2d520f3f08e924381576dcc58bccdd439c1b1d72212',1991,'SG','Singapore','communications',129,'_#_Railroads: 3,940 km 1.000-meter gauge, 99 km double track
_#_Highways: 44,534 km total; 28,016 km paved, 5,132 km earth surface,
11,386 km under development
_#_Inland waterways: 3,999 km principal waterways; 3,701 km with
navigable depths of 0.9 m or more throughout the year; numerous minor
waterways navigable by shallow-draft native craft
_#_Pipelines: natural gas, 350 km; refined products, 67 km
_#_Ports: Bangkok, Pattani, Phuket, Sattahip, Si Racha
_#_Merchant marine: 136 ships (1,000 GRT or over) totaling 521,565
GRT/791,570 DWT; includes 2 short-sea passenger, 79 cargo,
9 container, 29 petroleum, oils, and lubricants (POL) tanker,
9 liquefied gas, 1 chemical tanker, 3 bulk, 3 refrigerated cargo,
1 combination bulk
_#_Civil air: 41 (plus 2 leased) major transport aircraft
_#_Airports: 127 total, 103 usable; 56 with permanent-surface runways;
1 with runways over 3,659 m; 12 with runways 2,440-3,659 m; 28 with
runways 1,220-2,439 m
_#_Telecommunications: service to general public inadequate; bulk of
service to government activities provided by multichannel cable and
radio relay network; 739,500 telephones (1987); stations--over 200 AM,
100 FM, and 11 TV in government-controlled networks; satellite earth
stations--1 Indian Ocean INTELSAT and 1 Pacific Ocean INTELSAT; domestic
satellite system being developed
_*_Defense Forces
_#_Branches: Royal Thai Army, Royal Thai Navy (including Royal Thai
Marine Corps), Royal Thai Air Force, Paramilitary Forces
_#_Manpower availability: males 15-49, 16,028,159; 9,778,003 fit for
military service; 604,483 reach military age (18) annually
_#_Defense expenditures: $2.4 billion, 3% of GNP (1990 est.)
_%_
_@_Togo
_#_Railroads: 515 km 1.000-meter gauge, single track
_#_Highways: 6,462 km total; 1,762 km paved; 4,700 km unimproved roads
_#_Inland waterways: none
_#_Ports: Lome, Kpeme (phosphate port)
_#_Merchant marine: 7 ships (1,000 GRT or over) totaling 38,906
GRT/70,483 DWT; includes 4 roll-on/roll-off cargo, 3 multifunction
large-load carrier
_#_Civil air: 3 major transport aircraft
_#_Airports: 9 total, 9 usable; 2 with permanent-surface runways;
none with runways over 3,659 m; 2 with runways 2,440-3,659 m
none with runways 1,220-2,439 m
_#_Telecommunications: fair system based on network of open-wire lines
supplemented by radio relay routes; 12,000 telephones; stations--2 AM,
no FM, 3 (2 relays) TV; earth stations--1 Atlantic Ocean INTELSAT and 1
SYMPHONIE
_*_Defense Forces
_#_Branches: Army, Navy, Air Force, paramilitary Gendarmerie
_#_Manpower availability: males 15-49, 799,597; 420,092 fit for
military service; no conscription
_#_Defense expenditures: $44 million, 3.7% of GDP (1987)
_%_
_@_Tokelau
(territory of New Zealand)','6495e75c80f89261d2014aec724ba00470420d44a1ad1889257eec109f6ed15e','internet-archive','theciaworldfactb00025gut','txt','84185fe9df79da427349cc1598fd3f69814a2085a9fc1fe0508a3fae0a870f84','https://archive.org/download/theciaworldfactb00025gut/25.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bbe3905a9ec44c308176279801bfd54c24c7d47fe0053c111a3ae266453a9369',1991,'WS','Samoa','communications',134,'_#_Ports: none; offshore anchorage only
_#_Airports: none; lagoon landings by amphibious aircraft from Western
_#_Telecommunications: telephone service between islands and to
Western Samoa
_*_Defense Forces
_#_Note: defense is the responsibility of New Zealand
_%_
_@_Tonga
_#_Highways: 198 km sealed road (Tongatapu); 74 km (Vavau); 94 km
unsealed roads usable only in dry weather
_#_Ports: Nukualofa, Neiafu, Pangai
_#_Merchant marine: 6 ships (1,000 GRT or over) totaling 35,857
GRT/480,726 DWT; includes 2 cargo, 1 roll-on/roll-off cargo, 2 container,
1 liquefied gas
_#_Civil air: no major transport aircraft
_#_Airports: 6 total, 6 usable; 1 with permanent-surface runways;
none with runways over 3,659 m; 1 with runways 2,440-3,659;
1 with runways 1,220-2,439 m
_#_Telecommunications: 3,529 telephones; 66,000 radios; no TV
sets; stations--1 AM, no FM, no TV; 1 Pacific Ocean INTELSAT earth
station
_*_Defense Forces
_#_Branches: Land Force, Maritime Division, Royal Tongan Marines,
Royal Tongan Guard, Police
_#_Manpower availability: NA
_#_Defense expenditures: $NA, NA% of GDP
_%_
_@_Trinidad and Tobago
_#_Railroads: minimal agricultural system near San Fernando
_#_Highways: 8,000 km total; 4,000 km paved, 1,000 km improved earth,
3,000 km unimproved earth
_#_Pipelines: 1,032 km crude oil; 19 km refined products; 904 km
natural gas
_#_Ports: Port-of-Spain, Point Lisas, Pointe-a-Pierre
_#_Civil air: 14 major transport aircraft
_#_Airports: 6 total, 5 usable; 3 with permanent-surface runways;
none with runways over 3,659 m; 2 with runways 2,440-3,659 m;
2 with runways 1,220-2,439 m
_#_Telecommunications: excellent international service via
tropospheric scatter links to Barbados and Guyana; good local service;
109,000 telephones; stations--2 AM, 4 FM, 5 TV; 1 Atlantic Ocean
INTELSAT earth station
_*_Defense Forces
_#_Branches: Trinidad and Tobago Defense Force (Army), Coast Guard,
Air Wing, Trinidad and Tobago Police Service
_#_Manpower availability: males 15-49, 339,260; 245,086 fit for
military service
_#_Defense expenditures: $59 million, 1.6% of GDP (1989 est.)
_%_
_@_Tromelin Island
(French possession)
_#_Airports: 1 with runway less than 1,220 m
_#_Ports: none; offshore anchorage only
_#_Telecommunications: important meteorological station
_*_Defense Forces
_#_Note: defense is the responsibility of France
_%_
_@_Tunisia','e1ba56bfa9d8f61e784620f861edf253879010ef3f43500a3b3710552c2e90a3','internet-archive','theciaworldfactb00025gut','txt','84185fe9df79da427349cc1598fd3f69814a2085a9fc1fe0508a3fae0a870f84','https://archive.org/download/theciaworldfactb00025gut/25.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ecfba62f6dbdbfab9260e58929264b27e1513f8e92dd10a9a2c7ec2405eeb0b5',1991,'DZ','Algeria','communications',137,'_#_Railroads: 2,154 km total; 465 km 1.435-meter standard gauge;
1,689 km 1.000-meter gauge
_#_Highways: 17,700 km total; 9,100 km bituminous; 8,600 km improved
and unimproved earth
_#_Pipelines: 797 km crude oil; 86 km refined products; 742 km natural
gas
_#_Ports: Bizerte, Gabes, Sfax, Sousse, Tunis, La Goulette, Zarzis
_#_Merchant marine: 21 ships (1,000 GRT or over) totaling 160,172
GRT/218,970 DWT; includes 1 short-sea passenger, 4 cargo, 2
roll-on/roll-off cargo, 2 petroleum, oils, and lubricants (POL) tanker, 6
chemical tanker, 1 liquefied gas, 5 bulk
_#_Civil air: 13 major transport aircraft
_#_Airports: 29 total, 28 usable; 14 with permanent-surface runways;
none with runways over 3,659 m; 7 with runways 2,440-3,659 m;
7 with runways 1,220-2,439 m
_#_Telecommunications: the system is above the African average;
facilities consist of open-wire lines, multiconductor cable, and radio
relay; key centers are Safaqis, Susah, Bizerte, and Tunis;
233,000 telephones; stations--18 AM, 4 FM, 14 TV; 4 submarine cables;
earth stations--1 Atlantic Ocean INTELSAT and 1 ARABSAT with
back-up control station; coaxial cable to Algeria; radio relay to
Algeria, Libya, and Italy
_*_Defense Forces
_#_Branches: Army, Navy, Air Force, paramilitary forces
_#_Manpower availability: males 15-49, 2,052,191; 1,180,614 fit for
military service; 90,218 reach military age (20) annually
_#_Defense expenditures: $315 million, 2.6% of GDP (1990 est.)
_%_
_@_Turkey
_#_Railroads: 8,401 km 1.435-meter standard gauge; 479 km electrified
_#_Highways: 49,615 km total; 26,915 km bituminous; 16,500 km gravel
or crushed stone; 4,000 km improved earth; 2,200 km unimproved earth
(1985)
_#_Inland waterways: about 1,200 km
_#_Pipelines: 1,738 km crude oil; 2,321 km refined products;
708 km natural gas
_#_Ports: Iskenderun, Istanbul, Mersin, Izmir
_#_Merchant marine: 340 ships (1,000 GRT or over) totaling 3,583,720
GRT/6,220,642 DWT; includes 8 short-sea passenger,
1 passenger-cargo, 190 cargo, 1 container, 4 roll-on/roll-off cargo,
3 refrigerated cargo, 1 livestock carrier, 37 petroleum, oils, and
lubricants (POL) tanker, 9 chemical tanker, 2 liquefied gas, 7
combination ore/oil, 1 specialized tanker, 72 bulk, 4 combination bulk
_#_Civil air: 39 major transport aircraft (1990)
_#_Airports: 115 total, 109 usable; 64 with permanent-surface runways;
3 with runways over 3,659 m; 30 with runways 2,440-3,659 m; 26 with
runways 1,220-2,439 m
_#_Telecommunications: fair domestic and international systems; trunk
radio relay network; 3,400,000 telephones; stations--15 AM; 45 (60
repeaters) FM; 67 (504 repeaters) TV; satellite communications
ground stations operating in the INTELSAT (2 Atlantic Ocean) and EUTELSAT
systems; 1 submarine telephone cable
_*_Defense Forces
_#_Branches: Land Forces, Navy (including Naval Air and Naval
Infantry), Air Force, Coast Guard, Gendarmerie
_#_Manpower availability: males 15-49, 14,861,358; 9,083,559 fit for
military service; 606,871 reach military age (20) annually
_#_Defense expenditures: $5.6 billion, 5% of GDP (1990)
_%_
_@_Turks and Caicos Islands
(dependent territory of the UK)
_#_Highways: 121 km, including 24 km tarmac
_#_Ports: Grand Turk, Salt Cay, Providenciales, Cockburn Harbour
_#_Civil air: Air Turks and Caicos (passenger service) and Turks
Air Ltd. (cargo service)
_#_Airports: 7 total, 7 usable; 4 with permanent-surface runways;
none with runways over 2,439 m; 4 with runways 1,220-2,439 m
_#_Telecommunications: fair cable and radio services; 1,446
telephones; stations--3 AM, no FM, several TV; 2 submarine cables; 1
Atlantic Ocean INTELSAT earth station
_*_Defense Forces
_#_Note: defense is the responsibility of the UK
_%_
_@_Tuvalu
_#_Highways: 8 km gravel
_#_Ports: Funafuti, Nukufetau
_#_Merchant marine: 1 passenger-cargo (1,000 GRT or over) totaling
1,043 GRT/450 DWT
_#_Civil air: no major transport aircraft
_#_Airports: 1 with runway 1,220-2,439 m
_#_Telecommunications: stations--1 AM, no FM, no TV; 300
radiotelephones; 4,000 radios; 108 telephones
_*_Defense Forces
_#_Branches: Police Force
_#_Manpower availability: NA
_#_Defense expenditures: $NA, NA% of GDP
_%_
_@_Uganda
_#_Railroads: 1,300 km, 1.000-meter-gauge single track
_#_Highways: 26,200 km total; 1,970 km paved; 5,849 km crushed stone,
gravel, and laterite; remainder earth roads and tracks
_#_Inland waterways: Lake Victoria, Lake Albert, Lake Kyoga, Lake
George, Lake Edward; Victoria Nile, Albert Nile; principal inland water
ports are at Jinja and Port Bell, both on Lake Victoria
_#_Merchant marine: 1 roll-on/roll-off cargo (1,000 GRT or over)
totaling 1,697 GRT
_#_Civil air: 4 major transport aircraft
_#_Airports: 37 total, 28 usable; 5 with permanent-surface runways;
1 with runways over 3,659 m; 3 with runways 2,440-3,659 m; 10 with
runways 1,220-2,439 m
_#_Telecommunications: fair system with radio relay and radio
communications stations; 61,600 telephones; stations--10 AM, no FM, 9 TV;
satellite communications ground stations--1 Atlantic Ocean INTELSAT and 1
Indian Ocean INTELSAT
_*_Defense Forces
_#_Branches: Army, Navy, Air Force
_#_Manpower availability: males 15-49, about 3,980,637; about 2,162,241
fit for military service
_#_Defense expenditures: $68 million, 1.5% of GDP (1988)
_%_
_@_United Arab Emirates
_#_Highways: 2,000 km total; 1,800 km bituminous, 200 km gravel and
graded earth
_#_Pipelines: 830 km crude oil; 870 km natural gas, including natural
gas liquids
_#_Ports: Al Fujayrah, Khawr Fakkan, Mina Jabal Ali,
Mina Khalid, Mina Rashid, Mina Saqr,
Mina Zayid
_#_Merchant marine: 57 ships (1,000 GRT or over) totaling 925,424
GRT/1,543,716 DWT; includes 22 cargo, 8 container, 2 roll-on/roll-off
cargo, 20 petroleum, oils, and lubricants (POL) tanker, 5 bulk
_#_Civil air: 8 major transport aircraft
_#_Airports: 38 total, 35 usable; 20 with permanent-surface runways;
7 with runways over 3,659 m; 5 with runways 2,440-3,659 m; 5 with runways
1,220-2,439 m
_#_Telecommunications: adequate system of radio relay and coaxial
cable; key centers are Abu Dhabi and Dubayy; 386,600 telephones;
stations--8 AM, 3 FM, 12 TV; satellite communications ground
stations--1 Atlantic Ocean INTELSAT, 2 Indian Ocean INTELSAT and 1
ARABSAT; submarine cables to Qatar, Bahrain, India, and Pakistan;
tropospheric scatter to Bahrain; radio relay to Saudi Arabia
_*_Defense Forces
_#_Branches: Army, Navy, Air Force, Federal Police Force
_#_Manpower availability: males 15-49, 940,130; 516,218 fit for
military service
_#_Defense expenditures: $1.59 billion, 6.8% of GDP (1988)
_%_
_@_United Kingdom
_#_Railroads: Great Britain--16,629 km total; British Railways (BR)
operates 16,629 km 1.435-meter standard gauge (4,205 km electrified
and 12,591 km double or multiple track); several additional small
standard-gauge and narrow-gauge lines are privately owned and operated;
Northern Ireland Railways (NIR) operates 332 km 1.600-meter gauge,
190 km double track
_#_Highways: UK, 362,982 km total; Great Britain, 339,483 km paved
(including 2,573 km limited-access divided highway); Northern Ireland,
23,499 km (22,907 paved, 592 km gravel)
_#_Inland waterways: 2,291 total; British Waterways Board, 606 km;
Port Authorities, 706 km; other, 979 km
_#_Pipelines: 933 km crude oil, almost all insignificant; 2,993 km
refined products; 12,800 km natural gas
_#_Ports: London, Liverpool, Felixstowe, Tees and Hartlepool,
Dover, Sullom Voe, Southampton
_#_Merchant marine: 251 ships (1,000 GRT or over) totaling
4,643,056 GRT/6,214,450 DWT; includes 7 passenger, 21 short-sea
passenger, 39 cargo, 34 container, 22 roll-on/roll-off cargo,
10 refrigerated cargo, 1 vehicle carrier, 1 railcar carrier,
74 petroleum, oils, and lubricants (POL) tanker, 4 chemical tanker,
9 liquefied gas, 1 combination ore/oil, 1 specialized tanker, 25 bulk,
2 combination bulk
_#_Civil air: 618 major transport aircraft
_#_Airports: 520 total, 388 usable; 252 with permanent-surface
runways; 1 with runways over 3,659 m; 37 with runways 2,440-3,659 m;
133 with runways 1,220-2,439 m
_#_Telecommunications: modern, efficient domestic and international
system; 30,200,000 telephones; excellent countrywide broadcast systems;
stations--223 AM, 165 (401 relays) FM, 207 (3,210 relays) TV; 40 coaxial
submarine cables; satellite communication ground stations operating in
INTELSAT (7 Atlantic Ocean and 3 Indian Ocean), MARISAT, and EUTELSAT
systems
_*_Defense Forces
_#_Branches: Army, Royal Navy (including Royal Marines), Royal Air
Force
_#_Manpower availability: males 15-49, 14,475,433; 12,167,324 fit for
military service; no conscription
_#_Defense expenditures: $41 billion, 4.8% of GDP (FY90)
_%_
_@_United States
_#_Railroads: 270,312 km
_#_Highways: 6,365,590 km, including 88,641 km expressways
_#_Inland waterways: 41,009 km of navigable inland channels, exclusive
of the Great Lakes (est.)
_#_Pipelines: 275,800 km petroleum, 305,300 km natural gas (1985)
_#_Ports: Anchorage, Baltimore, Beaumont, Boston, Charleston,
Cleveland, Duluth, Freeport, Galveston, Hampton Roads, Honolulu, Houston,
Jacksonville, Long Beach, Los Angeles, Milwaukee, Mobile, New Orleans,
New York, Philadelphia, Portland (Oregon), Richmond (California), San
Francisco, Savannah, Seattle, Tampa, Wilmington
_#_Merchant marine: 404 ships (1,000 GRT or over) totaling NA
GRT/NA DWT); includes 3 passenger-cargo, 44 cargo, 23 bulk,
180 tanker, 13 tanker tug-barge, 11 liquefied gas, 130
intermodal; in addition there are 231 government-owned vessels
_#_Civil air: 3,297 commercial multiengine transport aircraft,
including 2,989 jet, 231 turboprop, 77 piston (1985)
_#_Airports: 14,177 total, 12,417 usable; 4,820 with permanent
surface-runways; 63 with runways over 3,659 m; 325 with runways
2,440-3,659 m; 2,524 with runways 1,220-2,439 m
_#_Telecommunications: 182,558,000 telephones; stations--4,892 AM,
5,200 FM (including 3,915 commercial and 1,285 public broadcasting),
7,296 TV (including 796 commercial, 300 public broadcasting, and 6,200
commercial cable); 495,000,000 radio receivers (1982); 150,000,000 TV
sets (1982); satellite communications ground stations--45 Atlantic Ocean
INTELSAT and 16 Pacific Ocean INTELSAT
_*_Defense Forces
_#_Branches: Department of the Army, Department of the Navy (including
Marine Corps), Department of the Air Force
_#_Manpower availability: males 15-49, 66,458,000; NA fit for military
service
_#_Defense expenditures: $312.9 billion, 5.7% of GNP (1990)
_%_
_@_Uruguay
_#_Railroads: 3,000 km, all 1.435-meter standard gauge and government
owned
_#_Highways: 49,900 km total; 6,700 km paved, 3,000 km gravel,
40,200 km earth
_#_Inland waterways: 1,600 km; used by coastal and shallow-draft river
craft
_#_Ports: Montevideo, Punta del Este
_#_Merchant marine: 4 ships (1,000 GRT or over) totaling 65,212
GRT/116,613 DWT; includes 2 cargo, 1 container, 1 petroleum, oils, and
lubricants (POL) tanker
_#_Civil air: 14 major transport aircraft
_#_Airports: 91 total, 86 usable; 16 with permanent-surface runways;
none with runways over 3,659 m; 2 with runways 2,440-3,659 m;
17 with runways 1,220-2,439 m
_#_Telecommunications: most modern facilities concentrated in
Montevideo; new nationwide radio relay network; 337,000 telephones;
stations--99 AM, no FM, 26 TV, 9 shortwave; 2 Atlantic Ocean INTELSAT
earth stations
_*_Defense Forces
_#_Branches: Army, Navy (including Naval Air Arm and Marines), Air
Force, Coast Guard, Grenadier Guards, Police
_#_Manpower availability: males 15-49, 735,971; 597,302 fit for
military service; no conscription
_#_Defense expenditures: $168 million, 2.2% of GDP (1988)
_%_
_@_Vanuatu
_#_Railroads: none
_#_Highways: 1,027 km total; at least 240 km sealed or all-weather
roads
_#_Ports: Port-Vila, Luganville, Palikoulo, Santu
_#_Merchant marine: 129 ships (1,000 GRT or over) totaling 2,242,850
GRT/3,447,671 DWT; includes 33 cargo, 13 refrigerated cargo, 8 container,
11 vehicle carrier, 1 livestock carrier, 5 petroleum, oils, and
lubricants (POL) tanker, 1 chemical tanker, 1 liquefied gas, 55 bulk,
1 combination bulk; note--a flag of convenience registry; the USSR
has 2 ships under the Vanuatu flag
_#_Civil air: no major transport aircraft
_#_Airports: 32 total, 28 usable; 2 with permanent-surface runways;
none with runways over 3,659 m; 1 with runways 2,440-3,659 m; 1 with
runways 1,220-2,439 m
_#_Telecommunications: stations--2 AM, no FM, no TV; 3,000 telephones;
satellite communications ground stations--1 Pacific Ocean INTELSAT
_*_Defense Forces
_#_Branches: no military forces; Vanuatu Police Force, paramilitary
force
_#_Manpower availability: males 15-49, 41,183; NA fit for military
service
_#_Defense expenditures: $NA, NA% of GDP
_%_
_@_Vatican City','2351ba818745882007a28774f8763feb56a74f2202f11e7d6848a362ebf3dc2f','internet-archive','theciaworldfactb00025gut','txt','84185fe9df79da427349cc1598fd3f69814a2085a9fc1fe0508a3fae0a870f84','https://archive.org/download/theciaworldfactb00025gut/25.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9742c39342e597d77d2b428cde490f7fc4b2f5039b6dd304c7a2561d805ff404',1991,'IT','Italy','communications',142,'_#_Railroads: 850 m, 750 mm gauge (links with Italian network near the
Rome station of Saint Peter''s)
_#_Highways: none; all city streets
_#_Telecommunications: stations--3 AM, 4 FM, no TV; 2,000-line
automatic telephone exchange; no communications satellite systems
_*_Defense Forces
_#_Note: defense is the responsibility of Italy; Swiss Papal Guards
are posted at entrances to the Vatican City
_%_
_@_Venezuela
_#_Railroads: 542 km total; 363 km 1.435-meter standard gauge all
single track, government owned; 179 km 1.435-meter gauge, privately owned
_#_Highways: 77,785 km total; 22,780 km paved, 24,720 km gravel,
14,450 km earth roads, and 15,835 km unimproved earth
_#_Inland waterways: 7,100 km; Rio Orinoco and Lago de Maracaibo
accept oceangoing vessels
_#_Pipelines: 6,370 km crude oil; 480 km refined products;
4,010 km natural gas
_#_Ports: Amuay Bay, Bajo Grande, El Tablazo, La Guaira, Puerto
Cabello, Puerto Ordaz
_#_Merchant marine: 58 ships (1,000 GRT or over) totaling 811,650
GRT/1,294,077 DWT; includes 1 short-sea passenger, 1 passenger cargo,
22 cargo, 1 container, 2 roll-on/roll-off cargo, 17 petroleum, oils, and
lubricants (POL) tanker, 1 chemical tanker, 2 liquefied gas, 9 bulk,
1 vehicle carrier, 1 combination bulk
_#_Civil air: 58 major transport aircraft
_#_Airports: 296 total, 277 usable; 137 with permanent-surface
runways; none with runways over 3,659 m; 13 with runways 2,440-3,659 m;
88 with runways 1,220-2,439 m
_#_Telecommunications: modern and expanding; 1,440,000 telephones;
stations--181 AM, no FM, 59 TV, 26 shortwave; 3 submarine coaxial cables;
satellite communications ground stations--1 Atlantic Ocean INTELSAT and 3
domestic
_*_Defense Forces
_#_Branches: Ground Forces (Army), Naval Forces (including Navy,
Marines, Coast Guard), Air Forces, Armed Forces of Cooperation (National
Guard)
_#_Manpower availability: males 15-49, 5,220,183; 3,782,548 fit for
military service; 216,132 reach military age (18) annually
_#_Defense expenditures: $1.9 billion, 4.3% of GDP (1991)
_%_
_@_Vietnam
_#_Railroads: 3,059 km total; 2,454 1.000-meter gauge, 151 km
1.435-meter standard gauge, 230 km dual gauge (three rails), and 224 km
not restored to service
_#_Highways: about 85,000 km total; 9,400 km bituminous, 48,700 km
gravel or improved earth, 26,900 km unimproved earth
_#_Pipelines: 150 km, refined products
_#_Inland waterways: about 17,702 km navigable; more than 5,149 km
navigable at all times by vessels up to 1.8 meter draft
_#_Ports: Da Nang, Haiphong, Ho Chi Minh City
_#_Merchant marine: 87 ships (1,000 GRT or over) totaling 364,596
GRT/539,174 DWT; includes 2 short-sea passenger, 69 cargo, 4 refrigerated
cargo, 1 roll-on/roll-off cargo, 1 vehicle carrier, 8 petroleum, oils,
and lubricants (POL) tanker, 2 bulk; note--Vietnam owns 11 cargo ships
(1,000 GRT or over) totaling 106,759 DWT under the registry of Panama and','1b2054e88bf861d7f9f20333f372cf3ddc221ec9d7d4f1a143fa184a529a0e61','internet-archive','theciaworldfactb00025gut','txt','84185fe9df79da427349cc1598fd3f69814a2085a9fc1fe0508a3fae0a870f84','https://archive.org/download/theciaworldfactb00025gut/25.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('aa007a2521bd5fb278603b32efa6843ad7f73a9b22bdcc1f37e2235cf9bf0479',1991,'MT','Malta','communications',146,'_#_Civil air: controlled by military
_#_Airports: 100 total, 100 usable; 50 with permanent-surface runways;
10 with runways 2,440-3,659 m; 20 with runways 1,220-2,439 m
_#_Telecommunications: 35,000 telephones in Ho Chi Minh City (1984);
stations--16 AM, 1 FM, 2 TV; 2,300,000 TV sets; 6,000,000 radio
receivers; at least 2 satellite earth stations, including 1 Indian Ocean
INTELSAT
_*_Defense Forces
_#_Branches: Army, Navy (including Marines and Naval Infantry), Air
Force
_#_Manpower availability: males 15-49, 16,260,120; 10,377,105 fit for
military service; 809,617 reach military age (17) annually
_#_Defense expenditures: $NA, 19.4% of GNP (1986 est.)
_%_
_@_Virgin Islands
(territory of the US)
_#_Highways: 856 km total
_#_Ports: Saint Croix--Christiansted, Frederiksted;
Saint Thomas--Long Bay, Crown Bay, Red Hook; Saint John--Cruz Bay
_#_Airports: 2 total, 2 usable; 2 with permanent-surface runways
1,220-2,439 m; international airports on Saint Thomas and Saint Croix
_#_Telecommunications: 44,280 telephones; stations--4 AM, 6 FM, 3 TV;
modern system using fiber-optic cable, submarine cable, microwave radio,
and satellite facilities; 90,000 radios; 56,000 TVs
_*_Defense Forces
_#_Note: defense is the responsibility of the US
_%_
_@_Wake Island
(territory of the US)
_#_Ports: none; because of the reefs, there are only two offshore
anchorages for large ships
_#_Airports: 1 with permanent-surface runways 2,440 to 3,659 m
_#_Telecommunications: underwater cables to Guam and through Midway
to Honolulu; AFRTS radio and television service provided by satellite;
stations--1 AM, no FM, no TV
_#_Note: formerly an important commercial aviation base, now used only
by US military and some commercial cargo planes
_*_Defense Forces
_#_Note: defense is the responsibility of the US
_%_
_@_Wallis and Futuna
(overseas territory of France)
_#_Highways: 100 km on Ile Uvea, 16 km sealed; 20 km earth surface
on Ile Futuna
_#_Inland waterways: none
_#_Ports: Mata-Utu, Leava
_#_Airports: 2 total; 2 usable; 1 with permanent-surface runways;
none with runways over 2,439 m; 1 with runways 1,220-2,439 m
_#_Telecommunications: 225 telephones; stations--1 AM, no FM, no TV
_*_Defense Forces
_#_Note: defense is the responsibility of France
_%_
_@_West Bank
_#_Note: The war between Israel and the Arab states in June 1967 ended
with Israel in control of the West Bank and the Gaza Strip, the Sinai,
and the Golan Heights. As stated in the 1978 Camp David Accords and
reaffirmed by President Reagan''s 1 September 1982 peace initiative, the
final status of the West Bank and the Gaza Strip, their relationship with
their neighbors, and a peace treaty between Israel and Jordan are to be
negotiated among the concerned parties. Camp David further specifies
that these negotiations will resolve the respective boundaries. Pending
the completion of this process, it is US policy that the final status of
the West Bank and the Gaza Strip has yet to be determined. In the view
of the US, the term West Bank describes all of the area west of the
Jordan River under Jordanian administration before the 1967
Arab-Israeli war. However, with respect to negotiations envisaged in the
framework agreement, it is US policy that a distinction must be made
between Jerusalem and the rest of the West Bank because of the city''s
special status and circumstances. Therefore, a negotiated solution for
the final status of Jerusalem could be different in character from that
of the rest of the West Bank.
_#_Highways: small indigenous road network, Israelis developing
east-west axial highways
_#_Airports: 2 total, 2 usable; 2 with permanent-surface runways;
none with runways over 2,439 m; 1 with runways 1,220-2,439 m
_#_Telecommunications: open-wire telephone system currently being
upgraded; stations--no AM, no FM, no TV
_*_Defense Forces
_#_Branches: NA
_#_Manpower availability: males 15-49, 257,740; NA fit for military
service
_#_Defense expenditures: $NA, NA% of GDP
_%_
_@_Western Sahara
_#_Highways: 6,100 km total; 1,350 km surfaced, 4,750 km improved and
unimproved earth roads and tracks
_#_Ports: El Aaiun, Ad Dakhla
_#_Airports: 16 total, 14 usable; 3 with permanent-surface runways;
none with runways over 3,659 m; 3 with runways 2,440-3,659 m;
6 with runways 1,220-2,439 m
_#_Telecommunications: sparse and limited system; tied into Morocco''s
system by radio relay, tropospheric scatter, and 2 Atlantic Ocean
INTELSAT earth stations linked to Rabat, Morocco; 2,000 telephones;
stations--2 AM, no FM, 2 TV
_*_Defense Forces
_#_Branches: NA
_#_Manpower availability: NA
_#_Defense expenditures: $NA, NA% of GDP
_%_
_@_Western Samoa
_#_Highways: 2,042 km total; 375 km sealed; remainder mostly gravel,
crushed stone, or earth
_#_Ports: Apia
_#_Merchant marine: 3 ships (1,000 GRT or over) totaling 24,930
GRT/34,135 DWT; includes 2 container, 1 roll-on/roll-off cargo
_#_Civil air: 3 major transport aircraft
_#_Airports: 3 total, 3 usable; 1 with permanent-surface runways;
none with runways over 3,659 m; 1 with runways 2,440-3,659 m;
none with runways 1,220-2,439 m
_#_Telecommunications: 7,500 telephones; 70,000 radios;
stations--1 AM, no FM, no TV; 1 Pacific Ocean INTELSAT station
_*_Defense Forces
_#_Branches: Department of Police and Prisons
_#_Manpower availability: males 15-49, 49,119; NA fit for military
service
_#_Defense expenditures: $NA, NA% of GDP
_%_
_@_World
_#_Ports: Mina al Ahmadi (Kuwait), Chiba, Houston, Kawasaki, Kobe,
Marseille, New Orleans, New York, Rotterdam, Yokohama
_*_Defense Forces
_#_Branches: ground, maritime, and air forces at all levels of
technology
_#_Manpower availability: males 15-49, 1,412,502,000; NA fit for
military service
_#_Defense expenditures: $1.1 trillion, 5.3% of GWP (1990 est.)
_%_
_@_Yemen
_#_Highways: 15,500 km; 4,000 km bituminous, 11,500 km natural
surface (est.)
_#_Pipelines: crude oil, 424 km; refined products, 32 km
_#_Ports: Aden, Al Hudaydah, Al Khalf, Mocha, Nishtun,
Ras Kathib, Salif
_#_Merchant marine: 3 ships (1,000 GRT or over) totaling
4,309 GRT/6,568 DWT; includes 2 cargo, 1 petroleum, oils, and
lubricants (POL) tanker
_#_Civil air: 15 major transport aircraft
_#_Airports: 49 total, 40 usable; 10 with permanent-surface runways;
none with runways over 3,659 m; 20 with runways 2,440-3,659 m;
12 with runways 1,220-2,439 m
_#_Telecommunications: the North has a poor but improving system with
new radio relay and cable networks, while the South has a small system of
open-wire, radio relay, multiconductor cable, and radio communications
stations; 65,000 telephones (est.); stations--4 AM, no FM, 22 TV;
satellite earth stations--2 Indian Ocean INTELSAT, 1 Atlantic Ocean
INTELSAT, 1 Intersputnik, 2 ARABSAT; radio relay to Saudi Arabia, and','6c4b96794f9adf36d3c2a71f54fef9be438aa1a71301142ef46225425975430a','internet-archive','theciaworldfactb00025gut','txt','84185fe9df79da427349cc1598fd3f69814a2085a9fc1fe0508a3fae0a870f84','https://archive.org/download/theciaworldfactb00025gut/25.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('824c84ea2e123c90fd91d17b65170a3f6c9718222b7faad428a7fed97deda115',1991,'DJ','Djibouti','communications',150,'_*_Defense Forces
_#_Branches: Army, Navy, Air Force, Police
_#_Manpower availability: males 15-49, 1,906,887;
1,084,122 fit for military service;
134,158 reach military age (14) annually
_#_Defense expenditures: $1.06 billion, 20% of GDP (1990)
_%_
_@_Yugoslavia
_#_Railroads: 9,349 km total; (all 1.435-meter standard gauge)
including 931 km double track, 3,760 km electrified (1988)
_#_Highways: 122,062 km total; 73,527 km asphalt, concrete, stone
block; 33,663 km macadam, asphalt treated, gravel, crushed stone;
14,872 km earth (1988)
_#_Inland waterways: 2,600 km (1982)
_#_Pipelines: 1,373 km crude oil; 2,900 km natural gas; 150 km refined
products
_#_Ports: Rijeka, Split, Koper, Bar, Ploce; inland port is Belgrade
_#_Merchant marine: 277 ships (1,000 GRT or over) totaling 3,780,095
GRT/6,031,359 DWT; includes 3 passenger, 4 short-sea passenger, 133
cargo, 5 refrigerated cargo, 19 container, 10 roll-on/roll-off cargo, 3
multifunction large-load carrier, 9 petroleum, oils, and lubricants (POL)
tanker, 3 chemical tanker, 2 combination ore/oil, 75 bulk, 11 combination
bulk; note--Yugoslavia owns 13 ships (1,000 GRT or over) totaling 253,400
GRT/429,613 DWT under the registry of Liberia, Panama, and Cyprus
_#_Civil air: 57 major transport aircraft
_#_Airports: 179 total, 179 usable; 54 with permanent-surface runways;
none with runways over 3,659 m; 23 with runways 2,440-3,659 m;
20 with runways 1,220-2,439 m
_#_Telecommunications: 1.6 million telephones (97% automatic); 7,500
public telephone booths; stations--85 AM, 69 FM, 103 TV; 4.65 million
radios; 4.1 million TVs (1990); 92% of country receives No. 1 television
program (1990)
_*_Defense Forces
_#_Branches: Yugoslav People''s Army--Ground Forces, Naval Forces, Air
and Air Defense Forces, Frontier Guard, Territorial Defense Force, Civil
Defense
_#_Manpower availability: males 15-49, 6,176,693; 5,001,024 fit for
military service; 189,886 reach military age (19) annually
_#_Defense expenditures: 70.85 billion dinars, 4-6% of GDP (1991
est.); note--conversion of defense expenditures into US dollars using the
official administratively set exchange rate would produce misleading
results
_%_
_@_Zaire
_#_Railroads: 5,254 km total; 3,968 km 1.067-meter gauge (851 km
electrified); 125 km 1.000-meter gauge; 136 km 0.615-meter gauge;
1,025 km 0.600-meter gauge
_#_Highways: 146,500 km total; 2,550 km bituminous, 46,450 km gravel
and improved earth; remainder unimproved earth
_#_Inland waterways: 15,000 km including the Congo, its tributaries,
and unconnected lakes
_#_Pipelines: refined products 390 km
_#_Ports: Matadi, Boma, Banana
_#_Merchant marine: 4 ships (1,000 GRT or over) totaling 41,802
GRT/60,496 DWT; includes 1 passenger cargo, 3 cargo
_#_Civil air: 38 major transport aircraft
_#_Airports: 308 total, 255 usable; 24 with permanent-surface runways;
1 with runways over 3,659 m; 6 with runways 2,440-3,659 m;
71 with runways 1,220-2,439 m
_#_Telecommunications: barely adequate wire and radio relay service;
31,200 telephones; stations--10 AM, 4 FM, 18 TV; satellite earth
stations--1 Atlantic Ocean INTELSAT, 14 domestic
_*_Defense Forces
_#_Branches: Army, Navy, Air Force, paramilitary National Gendarmerie,
paramilitary Civil Guard
_#_Manpower availability: males 15-49, 8,240,412; 4,192,991 fit for
military service
_#_Defense expenditures: $49 million, 0.8% of GDP (1988)
_%_
_@_Zambia
_#_Railroads: 1,266 km, all 1.067-meter gauge; 13 km double track
_#_Highways: 36,370 km total; 6,500 km paved, 7,000 km crushed stone,
gravel, or stabilized soil; 22,870 km improved and unimproved earth
_#_Inland waterways: 2,250 km, including Zambezi and Luapula Rivers,
Lake Tanganyika
_#_Pipelines: 1,724 km crude oil
_#_Ports: Mpulungu (lake port)
_#_Civil air: 6 major transport aircraft
_#_Airports: 121 total, 106 usable; 13 with permanent-surface runways;
1 with runways over 3,659 m; 4 with runways 2,440-3,659 m; 23 with
runways 1,220-2,439 m
_#_Telecommunications: facilities are among the best in Sub-Saharan
Africa; high-capacity radio relay connects most larger towns and cities;
71,700 telephones; stations--11 AM, 3 FM, 9 TV; satellite earth
stations--1 Indian Ocean INTELSAT and 1 Atlantic Ocean INTELSAT
_*_Defense Forces
_#_Branches: Army, Air Force, Police, paramilitary
_#_Manpower availability: males 15-49, 1,755,585; 920,878 fit for
military service
_#_Defense expenditures: $NA, NA% of GDP
_%_
_@_Zimbabwe
_#_Railroads: 2,745 km 1.067-meter gauge; 42 km double track; 355 km
electrified
_#_Highways: 85,237 km total; 15,800 km paved, 39,090 km crushed
stone, gravel, stabilized soil: 23,097 km improved earth; 7,250 km
unimproved earth
_#_Inland waterways: Lake Kariba is a potential line of communication
_#_Pipelines: 8 km, refined products
_#_Civil air: 12 major transport aircraft
_#_Airports: 499 total, 415 usable; 23 with permanent-surface runways;
2 with runways over 3,659 m; 3 with runways 2,440-3,659 m; 35 with
runways 1,220-2,439 m
_#_Telecommunications: system was once one of the best in Africa, but
now suffers from poor maintenance; consists of radio relay links,
open-wire lines, and radio communications stations; 247,000 telephones;
stations--8 AM, 18 FM, 8 TV; 1 Atlantic Ocean INTELSAT earth station
_*_Defense Forces
_#_Branches: Zimbabwe National Army, Air Force of Zimbabwe, Police
Support Unit, Paramilitary Police, People''s Militia
_#_Manpower availability: males 15-49, 2,263,724; 1,399,354 fit for
military service
_#_Defense expenditures: $412.4 million, NA% of GDP (FY91 est.)
_%_
_@_Taiwan
_#_Railroads: about 4,600 km total track with 1,075 km common
carrier lines and 3,525 km industrial lines; common carrier lines
consist of the 1.067-meter gauge 708 km West Line and the 367 km East
Line; a 98.25 km South Link Line connection is under construction; common
carrier lines owned by the government and operated by the Railway
Administration under Ministry of Communications; industrial lines owned
and operated by government enterprises
_#_Highways: 20,041 km total; 17,095 km bituminous or concrete,
2,371 km crushed stone or gravel, 575 km graded earth
_#_Pipelines: 615 km refined products, 97 km natural gas
_#_Ports: Kao-hsiung, Chi-lung (Keelung), Hua-lien, Su-ao, T''ai-tung
_#_Merchant marine: 226 ships (1,000 GRT or over) totaling 6,557,167
GRT/9,153,646 DWT; includes 1 short-sea passenger, 52 cargo, 17
refrigerated cargo, 75 container, 15 petroleum, oils, and lubricants
(POL) tanker, 3 combination ore/oil, 1 specialized tanker, 62 bulk
_#_Airports: 38 total, 37 usable; 33 with permanent-surface runways;
3 with runways over 3,659 m; 16 with runways 2,440-3,659 m; 8 with
runways 1,220-2,439 m
_#_Telecommunications: best developed system in Asia outside of Japan;
7,800,000 telephones; extensive microwave transmission links on east and
west coasts; stations--91 AM, 23 FM, 15 TV (13 relays); 8,620,000
radios; 6,386,000 TVs (5,680,000 color, 706,000 monochrome);
earth stations--1 Pacific Ocean INTELSAT and 1 Indian Ocean
INTELSAT; submarine cable links to Japan (Okinawa), the Philippines,
Guam, Singapore, Hong Kong, Indonesia, Australia, Middle East, and
Western Europe
_*_Defense Forces
_#_Branches: Army, Navy (including Marines), Air Force, Taiwan
Garrison Command, Ministry of National Defense
_#_Manpower availability: males 15-49, 5,874,345; 4,577,294 fit for
military service; about 187,807 currently reach military age (19)
annually
_#_Defense expenditures: $9.10 billion, 4.5% of GDP (FY91)
_%_
Appendix A: The United Nations System
The UN is composed of six principal organs and numerous subordinate
agencies and bodies as follows:
1) Secretariat
2) General Assembly:
UNCHS United Nations Center for Human Settlements (Habitat)
UNCTAD United Nations Conference on Trade and Development
UNDP United Nations Development Program
UNEP United Nations Environment Program
UNFPA United Nations Population Fund
UNHCR United Nations Office of High Commissioner for Refugees
UNICEF United Nations Children''s Fund
UNITAR United Nations Institute for Training and Research
UNRWA United Nations Relief and Works Agency for Palestine
Refugees in the Near East
UNSF United Nations Special Fund
UNU United Nations University
WFC World Food Council
WFP World Food Program
3) Security Council:
UNAVEM United Nations Angola Verification Mission
UNDOF United Nations Disengagement Observer Force
UNFICYP United Nations Force in Cyprus
UNIFIL United Nations Interim Force in Lebanon
UNIIMOG United Nations Iran-Iraq Military Observer Group
UNMOGIP United Nations Military Observer Group in India and','2e5981be4d1f7cdb9d5c0382ce7631bb1d25cc76fb8bfaa79b9964d5845d75f7','internet-archive','theciaworldfactb00025gut','txt','84185fe9df79da427349cc1598fd3f69814a2085a9fc1fe0508a3fae0a870f84','https://archive.org/download/theciaworldfactb00025gut/25.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9dbf025452936fa722627f4344882c70cb8b41d2ee51178951a3a891e0d9e66b',1991,'PK','Pakistan','communications',155,'UNTSO United Nations Truce Supervision Organization
4) Economic and Social Council (ECOSOC):
Specialized agencies
FAO Food and Agriculture Organization of the United Nations
IBRD International Bank for Reconstruction and Development
ICAO International Civil Aviation Organization
IDA International Development Association
IFAD International Fund for Agricultural Development
IFC International Finance Corporation
ILO International Labor Organization
IMF International Monetary Fund
IMO International Maritime Organization
ITU International Telecommunication Union
UNESCO United Nations Educational, Scientific, and Cultural
Organization
UNIDO United Nations Industrial Development Organization
UPU Universal Postal Union
WHO World Health Organization
WIPO World Intellectual Property Organization
WMO World Meteorological Organization
Related organizations
GATT General Agreement on Tariffs and Trade
IAEA International Atomic Energy Agency
Regional commissions
ECA Economic Commission for Africa
ECE Economic Commission for Europe
ECLAC Economic Commission for Latin America and the Caribbean
ESCAP Economic and Social Commission for Asia and the Pacific
ESCWA Economic and Social Commission for Western Asia
Functional commissions
Commission on Human Rights
Commission on Narcotic Drugs
Commission for Social Development
Commission on the Status of Women
Population Commission
Statistical Commission
5) Trusteeship Council
6) International Court of Justice (ICJ)
=========================================================================
Appendix B: Abbreviations for International Organizations and Groups
ABEDA Arab Bank for Economic Development in Africa
ACC Arab Cooperation Council
ACCT Agency for Cultural and Technical Cooperation
ACP African, Caribbean, and Pacific Countries
AfDB African Development Bank
AFESD Arab Fund for Economic and Social Development
AG Andean Group
AL Arab League
ALADI Asociacion Latinoamericana de Integracion; see Latin
American Integration Association (LAIA)
AMF Arab Monetary Fund
AMU Arab Maghreb Union
ANZUS Australia-New Zealand-United States Security Treaty
APEC Asia Pacific Economic Cooperation
AsDB Asian Development Bank
ASEAN Association of Southeast Asian Nations
BAD Banque Africaine de Developpement;
see African Development Bank (AfDB)
BADEA Banque Arabe de Developpement Economique en Afrique;
see Arab Bank for Economic Development in Africa (ABEDA)
BCIE Banco Centroamericano de Integracion Economico; see Central
American Bank for Economic Integration (BCIE)
BDEAC Banque de Developpment des Etats de l''Afrique Centrale; see
Central African States Development Bank (BDEAC)
Benelux Benelux Economic Union
BID Banco Interamericano de Desarvollo; see Inter-American
Development Bank (IADB)
BIS Bank for International Settlements
BOAD Banque Ouest-Africaine de Developpement; see West African
Development Bank (WADB)
C Commonwealth
CACM Central American Common Market
CAEU Council of Arab Economic Unity
CARICOM Caribbean Community and Common Market
CCC Customs Cooperation Council
CDB Caribbean Development Bank
CE Council of Europe
CEAO Communaute Economique de l''Afrique de l''Ouest; see West
African Economic Community (CEAO)
CEEAC Communaute Economique des Etats de l''Afrique Centrale; see
Economic Community of Central African States (CEEAC)
CEMA Council for Mutual Economic Assistance; also known as CMEA or
Comecon; abolished 1 January 1991
CEPGL Communaute Economique des Pays des Grands Lacs; see Economic
Community of the Great Lakes Countries (CEPGL)
CERN Conseil Europeen pour la Recherche Nucleaire; see European
Organization for Nuclear Research (CERN)
CG Contadora Group
CMEA Council for Mutual Economic Assistance (CEMA); also known as
Comecon; abolished 1 January 1991
COCOM Coordinating Committee on Export Controls
Comecon Council for Mutual Economic Assistance (CEMA); also known as
CMEA; abolished 1 January 1991
CP Colombo Plan
CSCE Conference on Security and Cooperation in Europe
DC developed country
EADB East African Development Bank
EBRD European Bank for Reconstruction and Development
EC European Community
ECA Economic Commission for Africa
ECAFE Economic Commission for Asia and the Far East; see Economic and
Social Commission for Asia and the Pacific (ESCAP)
ECE Economic Commission for Europe
ECLA Economic Commission for Latin America; see Economic Commission
for Latin America and the Caribbean (ECLAC)
ECLAC Economic Commission for Latin America and the Caribbean
ECOSOC Economic and Social Council
ECOWAS Economic Community of West African States
ECWA Economic Commission for Western Asia; see Economic and Social
Commission for Western Asia (ESCWA)
EFTA European Free Trade Association
EIB European Investment Bank
Entente Council of the Entente
ESA European Space Agency
ESCAP Economic and Social Commission for Asia and the Pacific
ESCWA Economic and Social Commission for Western Asia
FAO Food and Agriculture Organization
FLS Front Line States
FZ Franc Zone
G-2 Group of 2
G-3 Group of 3
G-5 Group of 5
G-6 Group of 6 (not to be confused with the Big Six)
G-7 Group of 7
G-8 Group of 8
G-9 Group of 9
G-10 Group of 10
G-11 Group of 11
G-19 Group of 19
G-24 Group of 24
G-30 Group of 30
G-33 Group of 33
G-77 Group of 77
GATT General Agreement on Tariffs and Trade
GCC Gulf Cooperation Council
Habitat see United Nations Center for Human Settlements (UNCHS)
IADB Inter-American Development Bank
IAEA International Atomic Energy Agency
IBEC International Bank for Economic Cooperation
IBRD International Bank for Reconstruction and Development
ICAO International Civil Aviation Organization
ICC International Chamber of Commerce
ICEM Intergovernmental Committee for European Migration; see
International Organization for Migration (IOM)
ICFTU International Confederation of Free Trade Unions
ICJ International Court of Justice
ICM Intergovernmental Committee for Migration; see
International Organization for Migration (IOM)
ICRC International Committee of the Red Cross
IDA International Development Association
IDB Islamic Development Bank
IEA International Energy Agency
IFAD International Fund for Agricultural Development
IFC International Finance Corporation
IGADD Inter-Governmental Authority on Drought and Development
IIB International Investment Bank
ILO International Labor Organization
IMCO Intergovernmental Maritime Consultative Organization; see
International Maritime Organization (IMO)
IMF International Monetary Fund
IMO International Maritime Organization
INMARSAT International Maritime Satellite Organization
INTELSAT International Telecommunications Satellite Organization
INTERPOL International Criminal Police Organization
IOC International Olympic Committee
IOM International Organization for Migration
ISO International Organization for Standardization
ITU International Telecommunication Union
LAES Latin American Economic System
LAIA Latin American Integration Association
LAS League of Arab States; see Arab League (AL)
LDC less developed country
LLDC least developed country
LORCS League of Red Cross and Red Crescent Societies
NAM Nonaligned Movement
NATO North Atlantic Treaty Organization
NC Nordic Council
NEA Nuclear Energy Agency
NIB Nordic Investment Bank
NIC newly industrializing country; see newly industrializing
economy (NIE)
NIE newly industrializing economy
OAPEC Organization of Arab Petroleum Exporting Countries
OAS Organization of American States
OAU Organization of African Unity
OECD Organization for Economic Cooperation and Development
OECS Organization of Eastern Caribbean States
OIC Organization of the Islamic Conference
OPANAL Agency for the Prohibition of Nuclear Weapons in Latin America
and the Caribbean
OPEC Organization of Petroleum Exporting Countries
PCA Permanent Court of Arbitration
RG Rio Group
SAARC South Asian Association for Regional Cooperation
SACU Southern African Customs Union
SADCC Southern African Development Coordination Conference
SELA Sistema Economico Latinoamericana; see Latin American Economic
System (LAES)
SPC South Pacific Commission
SPF South Pacific Forum
UDEAC Union Douaniere et Economique de l''Afrique Centrale; see
Central African Customs and Economic Union (UDEAC)
UN United Nations
UNAVEM United Nations Angola Verification Mission
UNCHS United National Center for Human Settlements (also
known as Habitat)
UNCTAD United Nations Conference on Trade and Development
UNDOF United Nations Disengagement Observer Force
UNDP United Nations Development Program
UNEP United Nations Environment Program
UNESCO United Nations Educational, Scientific, and Cultural
Organization
UNFICYP United Nations Force in Cyprus
UNFPA United Nations Fund for Population Activities; see UN Population
Fund (UNFPA)
UNHCR United Nations Office of the High Commissioner for Refugees
UNICEF United Nations International Children''s Emergency Fund; see
United Nations Children''s Fund (UNICEF)
UNIDO United Nations Industrial Development Organization
UNIFIL United Nations Interim Force in Lebanon
UNIIMOG United Nations Iran-Iraq Military Observer Group
UNMOGIP United Nations Military Observer Group in India and Pakistan
UNRWA United Nations Relief and Works Agency for Palestine Refugees
in the Near East
UNTSO United Nations Truce Supervision Organization
UPU Universal Postal Union
USSR/EE USSR/Eastern Europe
WADB West African Development Bank
WCL World Confederation of Labor
WEU Western European Union
WFC World Food Council
WFP World Food Program
WFTU World Federation of Trade Unions
WHO World Health Organization
WIPO World Intellectual Property Organization
WMO World Meteorological Organization
WP Warsaw Pact (members met 1 July 1991 to dissolve the alliance)
WTO World Tourism Organization
note: not all international organizations and groups have abbreviations
=========================================================================
Appendix C: International Organizations and Groups
-------------------------------------------------------------------------
_#_advanced developing countries--another term for those less
developed countries (LDCs) with particularly rapid industrial
development; see newly industrializing economies (NIEs)
-------------------------------------------------------------------------
_#_African, Caribbean, and Pacific Countries (ACP)
established--1 April 1976;
aim--members have a preferential economic and aid relationship with
the EC;
members--(66) Angola, Antigua and Barbuda, The Bahamas, Barbados,
Belize, Benin, Botswana, Burkina, Burundi, Cameroon, Cape Verde,
Central African Republic, Chad, Comoros, Congo, Djibouti, Dominica,
Equatorial Guinea, Ethiopia, Fiji, Gabon, The Gambia, Ghana, Grenada,
Guinea, Guinea-Bissau, Guyana, Ivory Coast, Jamaica, Kenya, Kiribati,
Lesotho, Liberia, Madagascar, Malawi, Mali, Mauritania, Mauritius,
Mozambique, Niger, Nigeria, Papua New Guinea, Rwanda,
Saint Kitts and Nevis, Saint Lucia, Saint Vincent and the Grenadines,
Sao Tome and Principe, Senegal, Seychelles, Sierra Leone,
Solomon Islands, Somalia, Sudan, Suriname, Swaziland, Tanzania, Togo,
Tonga, Trinidad and Tobago, Tuvalu, Uganda, Vanuatu, Western Samoa,
Zaire, Zambia, Zimbabwe
-------------------------------------------------------------------------
_#_African Development Bank (AfDB), also known as Banque Africaine de
Developpement (BAD);
established--4 August 1963;
aim--to promote economic and social development;
regional members--(50) Algeria, Angola, Benin, Botswana, Burkina,
Burundi, Cameroon, Cape Verde, Central African Republic, Chad, Comoros,
Congo, Djibouti, Egypt, Equatorial Guinea, Ethiopia, Gabon, The Gambia,
Ghana, Guinea, Guinea-Bissau, Ivory Coast, Kenya, Lesotho, Liberia,
Libya, Madagascar, Malawi, Mali, Mauritania, Mauritius, Morocco,
Mozambique, Niger, Nigeria, Rwanda, Sao Tome and Principe, Senegal,
Seychelles, Sierra Leone, Somalia, Sudan, Swaziland, Tanzania, Togo,
Tunisia, Uganda, Zaire, Zambia, Zimbabwe;
nonregional members--(25) Argentina, Australia, Austria, Belgium,
Brazil, Canada, China, Denmark, Finland, France, Germany, India, Italy,
Japan, South Korea, Kuwait, Netherlands, Norway, Portugal, Saudi Arabia,
Sweden, Switzerland, UK, US, Yugoslavia
-------------------------------------------------------------------------
_#_Agence de Cooperation Culturelle et Technique (ACCT)--see Agency
for Cultural and Technical Cooperation (ACCT)
-------------------------------------------------------------------------
_#_Agency for Cultural and Technical Cooperation (ACCT)--acronym
from Agence de Cooperation Culturelle et Technique;
established--21 March 1970;
aim--to promote cultural and technical cooperation among
French-speaking countries;
members--(30) Belgium, Benin, Burkina, Burundi, Canada,
Central African Republic, Chad, Comoros, Congo, Djibouti, Dominica,
France, Gabon, Guinea, Haiti, Ivory Coast, Lebanon, Luxembourg, Mali,
Mauritius, Monaco, Niger, Rwanda, Senegal, Seychelles, Togo, Tunisia,
Vanuatu, Vietnam, Zaire;
associate members--(7) Cameroon, Egypt, Guinea-Bissau, Laos,
Mauritania, Morocco, Saint Lucia;
participating governments--(2) New Brunswick (Canada),
Quebec (Canada)
-------------------------------------------------------------------------
_#_Agency for the Prohibition of Nuclear Weapons in Latin America and the
Caribbean (OPANAL)--acronym from Organismo para la Proscripcion de
las Armas Nucleares en la America Latina y el Caribe (OPANAL);
established--14 February 1967;
aim--to encourage the peaceful uses of atomic energy and prohibit
nuclear weapons;
members--(25) Antigua and Barbuda, The Bahamas, Barbados, Bolivia,
Brazil, Chile, Colombia, Costa Rica, Dominican Republic, Ecuador,
El Salvador, Grenada, Guatemala, Haiti, Honduras, Jamaica, Mexico,
Nicaragua, Panama, Paraguay, Peru, Suriname, Trinidad and Tobago,
Uruguay, Venezuela;
_@_observer--(1) Cuba
-------------------------------------------------------------------------
_#_Andean Group (AG)
established--26 May 1969, effective 16 October 1969;
aim--to promote harmonious development through economic
integration;
members--(5) Bolivia, Colombia, Ecuador, Peru, Venezuela;
associate member--(1) Panama;
observers--(26) Argentina, Australia, Austria, Belgium, Brazil,
Canada, Costa Rica, Denmark, Egypt, Finland, France, Germany, India,
Israel, Italy, Japan, Mexico, Netherlands, Paraguay, Spain, Sweden,
Switzerland, UK, US, Uruguay, Yugoslavia
-------------------------------------------------------------------------
_#_Arab Bank for Economic Development in Africa (ABEDA), also known as
Banque Arabe de Developpement Economique en Afrique (BADEA);
established--18 February 1974, effective 16 September 1974;
aim--to promote economic development;
members--(17 plus the Palestine Liberation Organization) Algeria,
Bahrain, Egypt, Iraq, Jordan, Kuwait, Lebanon, Libya, Mauritania,
Morocco, Oman, Qatar, Saudi Arabia, Sudan, Syria, Tunisia, UAE,
Palestine Liberation Organization; note--these are all the members of the
Arab League except Djibouti, Somalia, and Yemen
-------------------------------------------------------------------------
_#_Arab Cooperation Council (ACC)
established--16 February 1989;
aim--to promote economic cooperation and integration, possibly
leading to an Arab Common Market;
members--(4) Egypt, Iraq, Jordan, Yemen
-------------------------------------------------------------------------
_#_Arab Fund for Economic and Social Development (AFESD)
established--16 May 1968;
aim--to promote economic and social development;
members--(20 plus the Palestine Liberation Organization) Algeria,
Bahrain, Djibouti, Egypt (suspended from 1979 to 1988), Iraq, Jordan,
Kuwait, Lebanon, Libya, Mauritania, Morocco, Oman, Qatar, Saudi Arabia,
Somalia, Sudan, Syria, Tunisia, UAE, Yemen, Palestine Liberation
Organization
-------------------------------------------------------------------------
_#_Arab League (AL), also known as League of Arab States (LAS);
established--22 March 1945;
aim--to promote economic, social, political, and military
cooperation;
members--(20 plus the Palestine Liberation Organization) Algeria,
Bahrain, Djibouti, Egypt, Iraq, Jordan, Kuwait, Lebanon, Libya,
Mauritania, Morocco, Oman, Qatar, Saudi Arabia, Somalia, Sudan, Syria,
Tunisia, UAE, Yemen, Palestine Liberation Organization
-------------------------------------------------------------------------
_#_Arab Maghreb Union (AMU)
established--17 February 1989;
aim--to promote cooperation and integration among the Arab states
of northern Africa;
members--(5) Algeria, Libya, Mauritania, Morocco, Tunisia
-------------------------------------------------------------------------
_#_Arab Monetary Fund (AMF)
established--27 April 1976, effective 2 February 1977;
aim--to promote Arab cooperation, development, and integration in
monetary and economic affairs;
members--(19 plus the Palestine Liberation Organization) Algeria,
Bahrain, Egypt, Iraq, Jordan, Kuwait, Lebanon, Libya, Mauritania,
Morocco, Oman, Qatar, Saudi Arabia, Somalia, Sudan, Syria, Tunisia, UAE,
Yemen, Palestine Liberation Organization
-------------------------------------------------------------------------
_#_Asia Pacific Economic Cooperation (APEC)
established--NA November 1989;
aim--to promote trade and investment in the Pacific basin;
members--(12) all ASEAN members (Brunei, Indonesia, Malaysia,
Philippines, Singapore, Thailand) plus Australia, Canada, Japan,
South Korea, NZ, US
-------------------------------------------------------------------------
_#_Asian Development Bank (AsDB)
established--19 December 1966;
aim--to promote regional economic cooperation;
regional members--(34) Afghanistan, Australia, Bangladesh, Bhutan,
Burma, Cambodia, China, Cook Islands, Fiji, Hong Kong, India, Indonesia,
Japan, Kiribati, South Korea, Laos, Malaysia, Maldives, Mongolia, Nepal,
NZ, Pakistan, Papua New Guinea, Philippines, Singapore, Solomon Islands,
Sri Lanka, Taiwan, Thailand, Tonga, Turkey, Vanuatu, Vietnam, Western
Samoa;
nonregional members--(15) Austria, Belgium, Canada, Denmark,
Finland, France, Germany, Italy, Netherlands, Norway, Spain, Sweden,
Switzerland, UK, US
-------------------------------------------------------------------------
_#_Asociacion Latinoamericana de Integracion (ALADI)--see
Latin American Integration Association (LAIA)
-------------------------------------------------------------------------
_#_Association of Southeast Asian Nations (ASEAN)
established--9 August 1967;
aim--regional economic, social, and cultural cooperation among the
non-Communist countries of Southeast Asia;
members--(6) Brunei, Indonesia, Malaysia, Philippines, Singapore,
Thailand;
observer--(1) Papua New Guinea
-------------------------------------------------------------------------
_#_Australia-New Zealand-United States Security Treaty (ANZUS)
established--1 September 1951, effective 29 April 1952;
aim--trilateral mutual security agreement, although the US
suspended security obligations to NZ on 11 August 1986;
members--(3) Australia, NZ, US
-------------------------------------------------------------------------
_#_Banco Centroamericano de Integracion Economico (BCIE)--see
Central American Bank for Economic Integration (BCIE)
-------------------------------------------------------------------------
_#_Banco Interamericano de Desarvollo (BID)--see Inter-American
Development Bank (IADB)
-------------------------------------------------------------------------
_#_Bank for International Settlements (BIS)
established--20 January 1930, effective 17 March 1930;
aim--to promote cooperation among central banks in international
financial settlements;
members--(29) Australia, Austria, Belgium, Bulgaria, Canada,
Czechoslovakia, Denmark, Finland, France, Germany, Greece, Hungary,
Iceland, Ireland, Italy, Japan, Netherlands, Norway, Poland, Portugal,
Romania, South Africa, Spain, Sweden, Switzerland, Turkey, UK, US,
Yugoslavia
-------------------------------------------------------------------------
_#_Banque Africaine de Developpement (BAD)--see African Development
Bank (AfDB)
-------------------------------------------------------------------------
_#_Banque Arabe de Developpement Economique en Afrique (BADEA)--see
Arab Bank for Economic Development in Africa (ABEDA)
-------------------------------------------------------------------------
_#_Banque de Developpement des Etats de l''Afrique Centrale
(BDEAC)--see Central African States Development Bank (BDEAC)
-------------------------------------------------------------------------
_#_Banque Ouest-Africaine de Developpement (BOAD)--see West African
Development Bank (WADB)
-------------------------------------------------------------------------
_#_Benelux Economic Union (Benelux)--acronym from Belgium,
Netherlands, and Luxembourg;
established--3 February 1958, effective 1 November 1960;
aim--to develop closer economic cooperation and integration;
members--(3) Belgium, Luxembourg, Netherlands
-------------------------------------------------------------------------
_#_Big Seven--membership is the same as the Group of 7;
established--NA;
aim--to discuss and coordinate major economic policies;
members--(7) Big Six (Canada, France, Germany, Italy, Japan, UK)
plus the US
-------------------------------------------------------------------------
_#_Big Six--not to be confused with the Group of 6;
established--NA;
aim--economic cooperation;
members--(6) Canada, France, Germany, Italy, Japan, UK
-------------------------------------------------------------------------
_#_Caribbean Community and Common Market (CARICOM)
established--4 July 1973, effective 1 August 1973;
aim--to promote economic integration and development, especially
among the less developed countries;
members--(13) Antigua and Barbuda, The Bahamas, Barbados, Belize,
Dominica, Grenada, Guyana, Jamaica, Montserrat, Saint Kitts and Nevis,
Saint Lucia, Saint Vincent and the Grenadines, Trinidad and Tobago;
observers--(7) Anguilla, Bermuda, British Virgin Islands,
Dominican Republic, Haiti, Netherlands Antilles, Suriname
-------------------------------------------------------------------------
_#_Caribbean Development Bank (CDB)
established--18 October 1969, effective 26 January 1970;
aim--to promote economic development and cooperation;
regional members--(20) Anguilla, Antigua and Barbuda, The Bahamas,
Barbados, Belize, British Virgin Islands, Cayman Islands, Colombia,
Dominica, Grenada, Guyana, Jamaica, Mexico, Montserrat,
Saint Kitts and Nevis, Saint Lucia, Saint Vincent and the Grenadines,
Trinidad and Tobago, Turks and Caicos Islands, Venezuela;
nonregional members--(3) Canada, France, UK
-------------------------------------------------------------------------
_#_Cartagena Group--see Group of 11
-------------------------------------------------------------------------
_#_Central African Customs and Economic Union (UDEAC)--acronym from
Union Douaniere et Economique de l''Afrique Centrale;
established--8 December 1964, effective 1 January 1966;
aim--to promote the establishment of a Central African Common
Market;
members--(6) Cameroon, Central African Republic, Chad, Congo,
Equatorial Guinea, Gabon
-------------------------------------------------------------------------
_#_Central African States Development Bank (BDEAC)--acronym from
Banque de Developpement des Etats de l''Afrique Centrale;
established--3 December 1975;
aim--to provide loans for economic development;
members--(9) Cameroon, Central African Republic, Chad, Congo,
Equatorial Guinea, France, Gabon, Germany, Kuwait
-------------------------------------------------------------------------
_#_Central American Bank for Economic Integration (BCIE)--acronym from
Banco Centroamericano de Integracion Economico;
established--13 December 1960;
aim--to promote economic integration and development;
members--(5) Costa Rica, El Salvador, Guatemala, Honduras,','5f53b6caf9967ee567fde4e189220afcfe7e895cf31641fa82547acb42072aca','internet-archive','theciaworldfactb00025gut','txt','84185fe9df79da427349cc1598fd3f69814a2085a9fc1fe0508a3fae0a870f84','https://archive.org/download/theciaworldfactb00025gut/25.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f245b869be88b9c41ba525d24e6b47f0e9015ac1fd71393b682fed0e0a1b039b',1991,'NI','Nicaragua','communications',156,'-------------------------------------------------------------------------
_#_Central American Common Market (CACM)
established--13 December 1960, effective 3 June 1961;
aim--to promote establishment of a Central American Common Market;
members--(5) Costa Rica, El Salvador, Guatemala, Honduras,
-------------------------------------------------------------------------
_#_centrally planned economies--a term applied mainly to the
traditionally Communist states that looked to the USSR for leadership;
many are now evolving toward more democratic and market-oriented systems;
also known formerly as the Second World or as the Communist countries;
through the 1980s, this group included Albania, Bulgaria, Cambodia,
China, Cuba, Czechoslovakia, GDR, Hungary, North Korea, Laos, Mongolia,
Poland, Romania, USSR, Vietnam, Yugoslavia
-------------------------------------------------------------------------
_#_Colombo Plan (CP)
established--1 July 1951;
aim--to promote economic and social development in Asia and
the Pacific;
members--(26) Afghanistan, Australia, Bangladesh, Bhutan, Burma,
Cambodia, Canada, Fiji, India, Indonesia, Iran, Japan, South Korea, Laos,
Malaysia, Maldives, Nepal, NZ, Pakistan, Papua New Guinea, Philippines,
Singapore, Sri Lanka, Thailand, UK, US
-------------------------------------------------------------------------
_#_Commission for Social Development
established--21 June 1946 as the Social Commission, renamed
29 July 1966;
aim--ECOSOC organization dealing with social development programs;
members--(32) selected on a rotating basis from all regions
-------------------------------------------------------------------------
_#_Commission on Human Rights
established--18 February 1946;
aim--ECOSOC organization dealing with human rights;
members--(43) selected on a rotating basis from all regions
-------------------------------------------------------------------------
_#_Commission on Narcotic Drugs
established--16 February 1946;
aim--ECOSOC organization dealing with illicit drugs;
members--(40) selected on a rotating basis from all regions with
emphasis on producing and processing countries
-------------------------------------------------------------------------
_#_Commission on the Status of Women
established--21 June 1946;
aim--ECOSOC organization dealing with women''s rights;
members--(32) selected on a rotating basis from all regions
-------------------------------------------------------------------------
_#_Commonwealth (C)
established--31 December 1931;
aim--voluntary association that evolved from the British Empire and
that seeks to foster multinational cooperation and assistance;
members--(48) Antigua and Barbuda, Australia, The Bahamas,
Bangladesh, Barbados, Belize, Botswana, Brunei, Canada, Cyprus, Dominica,
The Gambia, Ghana, Grenada, Guyana, India, Jamaica, Kenya, Kiribati,
Lesotho, Malawi, Malaysia, Maldives, Malta, Mauritius, Namibia, NZ,
Nigeria, Pakistan, Papua New Guinea, Saint Kitts and Nevis, Saint Lucia,
Saint Vincent and the Grenadines, Seychelles, Sierra Leone, Singapore,
Solomon Islands, Sri Lanka, Swaziland, Tanzania, Tonga, Trinidad and
Tobago, Uganda, UK, Vanuatu, Western Samoa, Zambia, Zimbabwe;
special members--(2) Nauru, Tuvalu
-------------------------------------------------------------------------
_#_Communaute Economique de l''Afrique de l''Ouest (CEAO)--see
West African Economic Community (CEAO)
-------------------------------------------------------------------------
_#_Communaute Economique des Etats de l''Afrique Centrale
(CEEAC)--see Economic Community of Central African States (CEEAC)
-------------------------------------------------------------------------
_#_Communaute Economique des Pays des Grands Lacs (CEPGL)--see
Economic Community of the Great Lakes Countries (CEPGL)
-------------------------------------------------------------------------
_#_Communist countries--traditionally the Marxist-Leninist states with
authoritarian governments and command economies based on the Soviet
model; see centrally planned economies
-------------------------------------------------------------------------
_#_Conference on Security and Cooperation in Europe (CSCE)
established--NA November 1972;
aim--discusses issues of mutual concern and reviews implementation
of the Helsinki Agreement;
members--(35) Andorra, Austria, Belgium, Bulgaria, Canada, Cyprus,
Czechoslovakia, Denmark, Finland, France, Germany, Greece, Hungary,
Iceland, Ireland, Italy, Liechtenstein, Luxembourg, Malta, Monaco,
Netherlands, Norway, Poland, Portugal, Romania, San Marino, Spain,
Sweden, Switzerland, Turkey, UK, US, USSR, Vatican City, Yugoslavia
-------------------------------------------------------------------------
_#_Conseil Europeen pour la Recherche Nucleaire (CERN)--see
European Organization for Nuclear Research (CERN)
-------------------------------------------------------------------------
_#_Contadora Group (CG) was established 5 January 1983 (on the
Panamanian island of Contadora) to reduce tensions and conflicts in
Central America but evolved into the Rio Group (RG); members included
Colombia, Mexico, Panama, Venezuela
-------------------------------------------------------------------------
_#_Cooperation Council for the Arab States of the Gulf--see
Gulf Cooperation Council (GCC)
-------------------------------------------------------------------------
_#_Coordinating Committee on Export Controls (COCOM)
established--NA 1949;
aim--compiles strategic embargo list of goods not to be sold by the
West to Eastern bloc countries;
members--(15) Belgium, Canada, Denmark, France, Germany, Greece,
Italy, Japan, Luxembourg, Netherlands, Norway, Portugal, Turkey, UK, US
-------------------------------------------------------------------------
_#_Council for Mutual Economic Assistance (CEMA), also known as
CMEA or Comecon, was established 25 January 1949 to promote the
development of socialist economies and was abolished 1 January 1991;
members included Afghanistan (observer), Albania (had not participated
since 1961 break with USSR), Angola (observer), Bulgaria, Cuba,
Czechoslovakia, Ethiopia (observer), GDR, Hungary, Laos (observer),
Mongolia, Mozambique (observer), Nicaragua (observer), Poland, Romania,
USSR, Vietnam, Yemen (observer), Yugoslavia (associate)
-------------------------------------------------------------------------
_#_Council of Arab Economic Unity (CAEU)
established--3 June 1957, effective 30 May 1964;
aim--to promote economic integration among Arab nations;
members--(11) Egypt, Iraq, Jordan, Kuwait, Libya, Mauritania,
Somalia, Sudan, Syria, UAE, Yemen
-------------------------------------------------------------------------
_#_Council of Europe (CE)
established--5 May 1949, effective 3 August 1949;
aim--to promote increased unity and quality of life in Europe;
members--(24) Austria, Belgium, Cyprus, Denmark, Finland, France,
Germany, Greece, Hungary, Iceland, Ireland, Italy, Liechtenstein,
Luxembourg, Malta, Netherlands, Norway, Portugal, San Marino, Spain,
Sweden, Switzerland, Turkey, UK
-------------------------------------------------------------------------
_#_Council of the Entente (Entente)
established--29 May 1959;
aim--to promote economic, social, and political coordination;
members--(5) Benin, Burkina, Ivory Coast, Niger, Togo
-------------------------------------------------------------------------
_#_Customs Cooperation Council (CCC)
established--15 December 1950;
aim--to promote international cooperation in customs matters;
members--(104) Algeria, Argentina, Australia, Austria, The Bahamas,
Bangladesh, Belgium, Botswana, Brazil, Bulgaria, Burkina, Burundi,
Cameroon, Canada, Central African Republic, Chile, China, Congo, Cuba,
Cyprus, Czechoslovakia, Denmark, Egypt, Ethiopia, Finland, France, Gabon,
The Gambia, Germany, Ghana, Greece, Guatemala, Guyana, Haiti, Hong Kong,
Hungary, Iceland, India, Indonesia, Iran, Ireland, Israel, Italy,
Ivory Coast, Jamaica, Japan, Jordan, Kenya, South Korea, Lebanon,
Lesotho, Liberia, Libya, Luxembourg, Madagascar, Malawi, Malaysia, Mali,
Malta, Mauritania, Mauritius, Mexico, Morocco, Mozambique, Nepal,
Netherlands, NZ, Niger, Nigeria, Norway, Pakistan, Paraguay, Peru,
Philippines, Poland, Portugal, Romania, Rwanda, Saudi Arabia, Senegal,
Sierra Leone, Singapore, South Africa, Spain, Sri Lanka, Sudan,
Swaziland, Sweden, Switzerland, Syria, Tanzania, Thailand,
Trinidad and Tobago, Tunisia, Turkey, Uganda, UAE, UK, US,
Uruguay, Yugoslavia, Zaire, Zambia, Zimbabwe
-------------------------------------------------------------------------
_#_developed countries (DCs)--the top group in the comprehensive but
mutually exclusive hierarchy of developed countries (DCs),
USSR/Eastern Europe (USSR/EE), and less developed countries (LDCs);
includes the market-oriented economies of the mainly democratic nations
in the Organization for Economic Cooperation and Development (OECD),
Bermuda, Israel, South Africa, and the European ministates; also known
as the First World, high-income countries, the North, industrial
countries; generally have a per capita GNP/GDP in excess of $10,000
although some OECD countries and South Africa have figures well under
$10,000 and three of the excluded OPEC countries have figures of $10,000
or more;
the 34 DCs are--Andorra, Australia, Austria, Belgium, Bermuda,
Canada, Denmark, Faroe Islands, Finland, France, Germany, Greece,
Iceland, Ireland, Israel, Italy, Japan, Liechtenstein, Luxembourg, Malta,
Monaco, Netherlands, NZ, Norway, Portugal, San Marino, South Africa,
Spain, Sweden, Switzerland, Turkey, UK, US, Vatican City
-------------------------------------------------------------------------
_#_developing countries--an imprecise term for the less developed
countries with growing economies; see less developed countries (LDCs)
-------------------------------------------------------------------------
_#_East African Development Bank (EADB)
established--6 June 1967, effective 1 December 1967;
aim--to promote economic development;
members--(3) Kenya, Tanzania, Uganda
-------------------------------------------------------------------------
_#_Economic and Social Commission for Asia and the Pacific (ESCAP)
established--28 March 1947 as Economic Commission for Asia and
the Far East (ECAFE);
aim--to promote economic development as a regional commission for
the UN''s ECOSOC;
members--(38) Afghanistan, Australia, Bangladesh, Bhutan, Brunei,
Burma, Cambodia, China, Fiji, France, India, Indonesia, Iran, Japan,
South Korea, Laos, Malaysia, Maldives, Mongolia, Nauru, Nepal,
Netherlands, NZ, Pakistan, Papua New Guinea, Philippines, Singapore,
Solomon Islands, Sri Lanka, Thailand, Tonga, Tuvalu, UK, US, USSR,
Vanuatu, Vietnam, Western Samoa;
associate members--(9) Cook Islands, Guam, Hong Kong, Kiribati,
Marshall Islands, Federated States of Micronesia, Niue,
Northern Mariana Islands, Trust Territory of the Pacific Islands (Palau)
-------------------------------------------------------------------------
_#_Economic and Social Commission for Western Asia (ESCWA)
established--9 August 1973 as Economic Commission for Western Asia
(ECWA);
aim--to promote economic development as a regional commission for
the UN''s ECOSOC;
members--(12) Bahrain, Egypt, Iraq, Jordan, Kuwait, Lebanon, Oman,
Qatar, Saudi Arabia, Syria, UAE, Yemen
-------------------------------------------------------------------------
_#_Economic and Social Council (ECOSOC)
established--26 June 1945, effective 24 October 1945;
aim--to coordinate the economic and social work of the UN; includes
five regional commissions (see Economic Commission for Africa, Economic
Commission for Europe, Economic Commission for Latin America and the
Caribbean, Economic and Social Commission for Asia and the Pacific,
Economic and Social Commission for Western Asia) and six functional
commissions (see Commission for Social Development, Commission on Human
Rights, Commission on Narcotic Drugs, Commission on the Status of Women,
Population Commission, and Statistical Commission);
members--(54) selected on a rotating basis from all regions
-------------------------------------------------------------------------
_#_Economic Commission for Africa (ECA)
established--29 April 1958;
aim--to promote economic development as a regional commission of
the UN''s ECOSOC;
members--(51) Algeria, Angola, Benin, Botswana, Burkina, Burundi,
Cameroon, Cape Verde, Central African Republic, Chad, Comoros, Congo,
Djibouti, Egypt, Equatorial Guinea, Ethiopia, Gabon, The Gambia, Ghana,
Guinea, Guinea-Bissau, Ivory Coast, Kenya, Lesotho, Liberia, Libya,
Madagascar, Malawi, Mali, Mauritania, Mauritius, Morocco, Mozambique,
Niger, Nigeria, Rwanda, Sao Tome and Principe, Senegal, Seychelles,
Sierra Leone, Somalia, South Africa, Sudan, Swaziland, Tanzania, Togo,
Tunisia, Uganda, Zaire, Zambia, Zimbabwe;
associate members--(3) France, Namibia, UK
-------------------------------------------------------------------------
_#_Economic Commission for Asia and the Far East (ECAFE)--see
Economic and Social Commission for Asia and the Pacific (ESCAP)
-------------------------------------------------------------------------
_#_Economic Commission for Europe (ECE)
established--28 March 1947;
aim--to promote economic development as a regional commission of
the UN''s ECOSOC;
members--(33) Albania, Austria, Belgium, Bulgaria, Byelorussian
Soviet Socialist Republic, Canada, Cyprus, Czechoslovakia, Denmark,
Finland, France, Germany, Greece, Hungary, Iceland, Ireland, Italy,
Luxembourg, Malta, Netherlands, Norway, Poland, Portugal, Romania, Spain,
Sweden, Switzerland, Turkey, UK, Ukrainian Soviet Socialist Republic,
US, USSR, Yugoslavia
-------------------------------------------------------------------------
_#_Economic Commission for Latin America (ECLA)--see Economic
Commission for Latin America and the Caribbean (ECLAC)
-------------------------------------------------------------------------
_#_Economic Commission for Latin America and the Caribbean (ECLAC)
established--25 February 1948 as Economic Commission for
Latin America (ECLA);
aim--to promote economic development as a regional commission of
the UN''s ECOSOC;
members--(41) Antigua and Barbuda, Argentina, The Bahamas,
Barbados, Belize, Bolivia, Brazil, Canada, Chile, Colombia, Costa Rica,
Cuba, Dominica, Dominican Republic, Ecuador, El Salvador, France,
Grenada, Guatemala, Guyana, Haiti, Honduras, Jamaica, Mexico,
Netherlands, Nicaragua, Panama, Paraguay, Peru, Portugal, Puerto Rico,
Saint Kitts and Nevis, Saint Lucia, Saint Vincent and the Grenadines,
Spain, Suriname, Trinidad and Tobago, UK, US, Uruguay, Venezuela;
associate members--(5) Aruba, British Virgin Islands, Montserrat,
Netherlands Antilles, Virgin Islands
-------------------------------------------------------------------------
_#_Economic Commission for Western Asia (ECWA)--see Economic and
Social Commission for Western Asia (ESCWA)
-------------------------------------------------------------------------
_#_Economic Community of Central African States (CEEAC)--acronym from
Communaute Economique des Etats de l''Afrique Centrale;
established--18 October 1983;
aim--to promote regional economic cooperation and establish a
Central African Common Market;
members--(10) Burundi, Cameroon, Central African Republic, Chad,
Congo, Equatorial Guinea, Gabon, Rwanda, Sao Tome and Principe, Zaire;
observer--(1) Angola
-------------------------------------------------------------------------
_#_Economic Community of the Great Lakes Countries (CEPGL)--acronym
from Communaute Economique des Pays des Grands Lacs;
established--26 September 1976;
aim--to promote regional economic cooperation and integration;
members--(3) Burundi, Rwanda, Zaire
-------------------------------------------------------------------------
_#_Economic Community of West African States (ECOWAS)
established--28 May 1975;
aim--to promote regional economic cooperation;
members--(16) Benin, Burkina, Cape Verde, The Gambia, Ghana,
Guinea, Guinea-Bissau, Ivory Coast, Liberia, Mali, Mauritania, Niger,
Nigeria, Senegal, Sierra Leone, Togo
-------------------------------------------------------------------------
_#_European Bank for Reconstruction and Development (EBRD)
established--15 April 1991;
aim--to facilitate the transition of seven centrally planned
economies in Europe (Bulgaria, Czechoslovakia, Hungary, Poland, Romania,
USSR, and Yugoslavia) to market economies by committing 60% of its
loans to privatization;
members--(34) Australia, Austria, Belgium, Canada, Cyprus, Denmark,
European Community (EC), Egypt, European Investment Bank (EIB),
Finland, France, Germany, Greece, Iceland, Ireland, Israel, Italy, Japan,
South Korea, Liechtenstein, Luxembourg, Malta, Mexico, Morocco,
Netherlands, NZ, Norway, Portugal, Spain, Sweden, Switzerland, Turkey,
UK, US; note--includes all 12 members of the EC as individual countries
and the EC itself as an institution
-------------------------------------------------------------------------
_#_European Community (EC)
established--8 April 1965, effective 1 July 1967;
aim--a fusing of the European Atomic Energy Community (Euratom),
the European Coal and Steel Community (ESC), and the European Economic
Community (EEC or Common Market); the EC plans to establish a completely
integrated common market in 1992 and an eventual federation of Europe;
members--(12) Belgium, Denmark, France, Germany, Greece, Ireland,
Italy, Luxembourg, Netherlands, Portugal, Spain, UK
-------------------------------------------------------------------------
_#_European Free Trade Association (EFTA)
established--4 January 1960, effective 3 May 1960;
aim--to promote expansion of free trade;
members--(7) Austria, Finland, Iceland, Liechtenstein, Norway,
Sweden, Switzerland
-------------------------------------------------------------------------
_#_European Investment Bank (EIB)
established--25 March 1957, effective 1 January 1958;
aim--to promote economic development of the EC;
members--(12) Belgium, Denmark, France, Germany, Greece, Ireland,
Italy, Luxembourg, Netherlands, Portugal, Spain, UK
-------------------------------------------------------------------------
_#_European Organization for Nuclear Research (CERN)--acronym retained
from the predecessor organization Conseil Europeen pour la Recherche
Nucleaire;
established--1 July 1953, effective 29 September 1954;
aim--to foster nuclear research for peaceful purposes only;
members--(14) Austria, Belgium, Denmark, France, Germany, Greece,
Italy, Netherlands, Norway, Portugal, Spain, Sweden, Switzerland, UK;
observers--(3) Poland (scheduled to become a member 1 July 1991),
Turkey, Yugoslavia
-------------------------------------------------------------------------
_#_European Space Agency (ESA)
established--31 July 1973, effective 1 May 1975;
aim--to promote peaceful cooperation in space research and
technology;
members--(13) Austria, Belgium, Denmark, France, Germany, Ireland,
Italy, Netherlands, Norway, Spain, Sweden, Switzerland, UK;
associate member--(1) Finland
-------------------------------------------------------------------------
_#_First World--another term for countries with advanced,
industrialized economies; see developed countries (DCs)
-------------------------------------------------------------------------
_#_Food and Agriculture Organization (FAO)
established--16 October 1945;
aim--UN specialized agency to raise living standards and increase
availability of agricultural products;
members--(157) all UN members except Brunei, Byelorussian Soviet
Socialist Republic, Liechtenstein, Singapore, South Africa, Ukrainian
Soviet Socialist Republic, USSR; other members are Cook Islands,
North Korea, South Korea, Switzerland, Tonga
-------------------------------------------------------------------------
_#_Four Dragons the four small Asian less developed countries (LDCs)
that have experienced unusually rapid economic growth; also known as the
Four Tigers; this group includes Hong Kong, South Korea, Singapore,
Taiwan
-------------------------------------------------------------------------
_#_Four Tigers--another term for the Four Dragons; see Four Dragons
-------------------------------------------------------------------------
_#_Franc Zone (FZ)
established--NA;
aim--monetary union among countries whose currencies are linked to
the French franc;
members--(15) Benin, Burkina, Cameroon, Central African Republic,
Chad, Comoros, Congo, Equatorial Guinea, France, Gabon, Ivory Coast,
Mali, Niger, Senegal, Togo; note--France includes metropolitan France,
the four overseas departments of France (French Guiana, Guadeloupe,
Martinique, Reunion), the two territorial collectivities of France
(Mayotte, Saint Pierre and Miquelon), and the three overseas territories
of France (French Polynesia, New Caledonia, Wallis and Futuna)
-------------------------------------------------------------------------
_#_Front Line States (FLS)
established--NA;
aim--to achieve black majority rule in South Africa;
members--(7) Angola, Botswana, Mozambique, Namibia, Tanzania,
Zambia, Zimbabwe
-------------------------------------------------------------------------
_#_General Agreement on Tariffs and Trade (GATT)
established--30 October 1947, effective 1 January 1948;
aim--to promote the expansion of international trade on a
nondiscriminatory basis;
members--(101) Antigua and Barbuda, Argentina, Australia, Austria,
Bangladesh, Barbados, Belgium, Belize, Benin, Bolivia, Botswana, Brazil,
Burkina, Burma, Burundi, Cameroon, Canada, Central African Republic,
Chad, Chile, Colombia, Congo, Costa Rica, Cuba, Cyprus, Czechoslovakia,
Denmark, Dominican Republic, Egypt, Finland, France, Gabon, The Gambia,
Germany, Ghana, Greece, Guyana, Haiti, Hong Kong, Hungary, Iceland,
India, Indonesia, Ireland, Israel, Italy, Ivory Coast, Jamaica, Japan,
Kenya, South Korea, Kuwait, Lesotho, Luxembourg, Macau, Madagascar,
Malawi, Malaysia, Maldives, Malta, Mauritania, Mauritius, Mexico,
Morocco, Netherlands, NZ, Nicaragua, Niger, Nigeria, Norway, Pakistan,
Peru, Philippines, Poland, Portugal, Romania, Rwanda, Senegal, Sierra
Leone, Singapore, South Africa, Spain, Sri Lanka, Suriname, Sweden,
Switzerland, Tanzania, Thailand, Togo, Trinidad and Tobago, Tunisia,
Turkey, Uganda, UK, US, Uruguay, Venezuela, Yugoslavia, Zaire, Zambia,','b6fa5ecbfa44f45c4386a5e8d1cb9477856ffa51e28977c9dbb47bd9f6fef751','internet-archive','theciaworldfactb00025gut','txt','84185fe9df79da427349cc1598fd3f69814a2085a9fc1fe0508a3fae0a870f84','https://archive.org/download/theciaworldfactb00025gut/25.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('527f1e516b148599b74aca730f590d600c757f6711f8a2be8e9ce07efe5df840',1991,'TO','Tonga','communications',157,'-------------------------------------------------------------------------
_#_International Olympic Committee (IOC)
established--23 June 1894;
aim--to promote the Olympic ideals and administer the Olympic
games:
1992 Winter Olympics in Albertville, France (8-23 February);
1992 Summer Olympics in Barcelona, Spain (25 July-9 August);
1994 Winter Olympics in Lillehammer, Norway (12-27 February);
1996 Summer Olympics in Atlanta, United States (20 July-4 August):
1998 Winter Olympics in Nagano, Japan (date NA);
members--(165) Afghanistan, Albania, Algeria, American Samoa,
Andorra, Angola, Antigua and Barbuda, Argentina, Aruba, Australia,
Austria, The Bahamas, Bahrain, Bangladesh, Barbados, Belgium, Belize,
Benin, Bermuda, Bhutan, Bolivia, Botswana, Brazil, British Virgin
Islands, Brunei, Bulgaria, Burkina, Burma, Cameroon, Canada,
Cayman Islands, Central African Republic, Chad, Chile, China, Colombia,
Congo, Cook Islands, Costa Rica, Cuba, Cyprus, Czechoslovakia, Denmark,
Djibouti, Dominican Republic, Ecuador, Egypt, El Salvador,
Equatorial Guinea, Ethiopia, Fiji, Finland, France, Gabon, The Gambia,
Germany, Ghana, Greece, Grenada, Guam, Guatemala, Guinea, Guyana,
Haiti, Honduras, Hong Kong, Hungary, Iceland, India, Indonesia, Iran,
Iraq, Ireland, Israel, Italy, Ivory Coast, Jamaica, Japan, Jordan, Kenya,
North Korea, South Korea, Kuwait, Laos, Lebanon, Lesotho, Liberia, Libya,
Liechtenstein, Luxembourg, Madagascar, Malawi, Malaysia, Maldives, Mali,
Malta, Mauritania, Mauritius, Mexico, Monaco, Mongolia, Morocco,
Mozambique, Nepal, Netherlands, Netherlands Antilles, NZ, Nicaragua,
Niger, Nigeria, Norway, Oman, Pakistan, Panama, Papua New Guinea,
Paraguay, Peru, Philippines, Poland, Portugal, Puerto Rico, Qatar,
Romania, Rwanda, Saint Vincent and the Grenadines, San Marino,
Saudi Arabia, Senegal, Seychelles, Sierra Leone, Singapore,
Solomon Islands, Somalia, Spain, Sri Lanka, Sudan, Suriname, Swaziland,
Sweden, Switzerland, Syria, Taiwan, Tanzania, Thailand, Togo, Tonga,
Trinidad and Tobago, Tunisia, Turkey, Uganda, UAE, UK, US, USSR, Uruguay,
Vanuatu, Venezuela, Vietnam, Virgin Islands, Western Samoa, Yemen,
Yugoslavia, Zaire, Zambia, Zimbabwe
-------------------------------------------------------------------------
_#_International Organization for Migration (IOM)--established as
Provisional Intergovernmental Committee for the Movement of Migrants
from Europe; renamed Intergovernmental Committee for European Migration
(ICEM) on 15 November 1952; renamed Intergovernmental Committee for
Migration (ICM) on NA November 1980; current name adopted
14 November 1989;
established--5 December 1951;
aim--to facilitate orderly international emigration and
immigration;
members--(35) Argentina, Australia, Austria, Belgium, Bolivia,
Chile, Colombia, Costa Rica, Cyprus, Denmark, Dominican Republic,
Ecuador, El Salvador, Germany, Greece, Guatemala, Honduras, Israel,
Italy, Kenya, South Korea, Luxembourg, Netherlands, Nicaragua, Norway,
Panama, Paraguay, Peru, Philippines, Portugal, Switzerland, Thailand, US,
Uruguay, Venezuela;
observers--(22) Belize, Brazil, Canada, Cape Verde, Egypt, Finland,
France, Ghana, Guinea-Bissau, Japan, Mexico, NZ, San Marino, Somalia,
Sovereign Military Order of Malta, Spain, Sweden, Turkey, UK,
Vatican City, Yugoslavia, Zimbabwe
-------------------------------------------------------------------------
_#_International Organization for Standardization (ISO)
established--NA February 1947;
aim--to promote the development of international standards;
members--(72 national standards organizations) Albania, Algeria,
Argentina, Australia, Austria, Bangladesh, Belgium, Brazil, Bulgaria,
Canada, Chile, China, Colombia, Cuba, Cyprus, Czechoslovakia, Denmark,
Egypt, Ethiopia, Finland, France, Germany, Ghana, Greece, Hungary, India,
Indonesia, Iran, Iraq, Ireland, Israel, Italy, Ivory Coast, Jamaica,
Japan, Kenya, North Korea, South Korea, Malaysia, Mexico, Mongolia,
Morocco, Netherlands, NZ, Nigeria, Norway, Pakistan, Papua New Guinea,
Peru, Philippines, Poland, Portugal, Saudi Arabia, Singapore,
South Africa, Spain, Sri Lanka, Sudan, Sweden, Switzerland, Syria,
Tanzania, Thailand, Trinidad and Tobago, Tunisia, Turkey, UK, US, USSR,
Venezuela, Vietnam, Yugoslavia;
correspondent members--(14) Bahrain, Barbados, Brunei, Guinea,
Hong Kong, Iceland, Jordan, Kuwait, Malawi, Mauritius, Oman, Senegal,
UAE, Uruguay
-------------------------------------------------------------------------
_#_International Red Cross and Red Crescent Movement
established--NA 1928;
aim--to promote worldwide humanitarian aid through the
International Committee of the Red Cross (ICRC) in wartime, and League
of Red Cross and Red Crescent Societies (LORCS) in peacetime;
members--(9) 2 representatives from ICRC, 2 from LORCS, and 5 from
national societies elected by the international conference of the
International Red Cross and Red Crescent Movement
-------------------------------------------------------------------------
_#_International Telecommunication Union (ITU)
established--9 December 1932, effective 1 January 1934, affiliated
with the UN 15 November 1947;
aim--UN specialized agency concerned with world telecommunications;
members--(164) all UN members except Dominica, Saint Kitts
and Nevis, Saint Lucia, Seychelles; other members are Kiribati,
North Korea, South Korea, Monaco, Nauru, San Marino, Switzerland,
Tonga, Vatican City
-------------------------------------------------------------------------
_#_International Telecommunications Satellite Organization (INTELSAT)
established--20 August 1971, effective 12 February 1973;
aim--to develop and operate a global commercial telecommunications
satellite system;
members--(118) Afghanistan, Algeria, Angola, Argentina, Australia,
Austria, The Bahamas, Bangladesh, Barbados, Belgium, Benin, Bolivia,
Brazil, Burkina, Cameroon, Canada, Central African Republic, Chad, Chile,
China, Colombia, Congo, Costa Rica, Cyprus, Denmark, Dominican Republic,
Ecuador, Egypt, El Salvador, Ethiopia, Fiji, Finland, France, Gabon,
Germany, Ghana, Greece, Guatemala, Guinea, Haiti, Honduras, Iceland,
India, Indonesia, Iran, Iraq, Ireland, Israel, Italy, Ivory Coast,
Jamaica, Japan, Jordan, Kenya, South Korea, Kuwait, Lebanon, Libya,
Liechtenstein, Luxembourg, Madagascar, Malawi, Malaysia, Mali,
Mauritania, Mauritius, Mexico, Monaco, Morocco, Mozambique, Nepal,
Netherlands, NZ, Nicaragua, Niger, Nigeria, Norway, Oman, Pakistan,
Panama, Papua New Guinea, Paraguay, Peru, Philippines, Portugal, Qatar,
Rwanda, Saudi Arabia, Senegal, Singapore, Somalia, South Africa, Spain,
Sri Lanka, Sudan, Swaziland, Sweden, Switzerland, Syria, Tanzania,
Thailand, Togo, Trinidad and Tobago, Tunisia, Turkey, Uganda, UAE, UK,
US, Uruguay, Vatican City, Venezuela, Vietnam, Yemen, Yugoslavia, Zaire,
Zambia, Zimbabwe
-------------------------------------------------------------------------
_#_Islamic Development Bank (IDB)
established--15 December 1973;
aim--to promote Islamic economic aid and social development;
members--(43 plus the Palestine Liberation Organization)
Afghanistan, Algeria, Bahrain, Bangladesh, Benin, Brunei, Burkina,
Cameroon, Chad, Comoros, Djibouti, Egypt, Gabon, The Gambia, Guinea,
Guinea-Bissau, Indonesia, Iran, Iraq, Jordan, Kuwait, Lebanon, Libya,
Malaysia, Maldives, Mali, Mauritania, Morocco, Niger, Oman, Pakistan,
Qatar, Saudi Arabia, Senegal, Sierra Leone, Somalia, Sudan, Syria,
Tunisia, Turkey, Uganda, UAE, Yemen, Palestine Liberation Organization
-------------------------------------------------------------------------
_#_Latin American Economic System (LAES), also known as
Sistema Economico Latinoamericana (SELA);
established--17 October 1975;
aim--to promote economic and social development through regional
cooperation;
members--(26) Argentina, Barbados, Bolivia, Brazil, Chile,
Colombia, Costa Rica, Cuba, Dominican Republic, Ecuador, El Salvador,
Grenada, Guatemala, Guyana, Haiti, Honduras, Jamaica, Mexico, Nicaragua,
Panama, Paraguay, Peru, Suriname, Trinidad and Tobago, Uruguay, Venezuela
-------------------------------------------------------------------------
_#_Latin American Integration Association (LAIA), also known as
Asociacion Latinoamericana de Integracion (ALADI);
established--12 August 1980, effective 18 March 1981;
aim--to promote freer regional trade;
members--(11) Argentina, Bolivia, Brazil, Chile, Colombia, Ecuador,
Mexico, Paraguay, Peru, Uruguay, Venezuela;
observers--(13) Andean Group, Costa Rica, Cuba, Dominican Republic,
Guatemala, Honduras, Inter-American Development Bank, Organization of
American States, Panama, Portugal, Spain, UN Development Program,
Economic Commission for Latin America and the Caribbean
-------------------------------------------------------------------------
_#_League of Arab States (LAS)--see Arab League (AL)
-------------------------------------------------------------------------
_#_League of Red Cross and Red Crescent Societies (LORCS)
established--5 May 1919;
aim--to provide humanitarian aid in peacetime;
members--(147) Afghanistan, Albania, Algeria, Angola, Argentina,
Australia, Austria, The Bahamas, Bahrain, Bangladesh, Barbados, Belgium,
Belize, Benin, Bolivia, Botswana, Brazil, Bulgaria, Burkina, Burma,
Burundi, Cambodia, Cameroon, Canada, Cape Verde, Central African
Republic, Chad, Chile, China, Colombia, Congo, Costa Rica, Cuba,
Czechoslovakia, Denmark, Djibouti, Dominica, Dominican Republic, Ecuador,
Egypt, El Salvador, Ethiopia, Fiji, Finland, France, The Gambia, Germany,
Ghana, Greece, Grenada, Guatemala, Guinea, Guinea-Bissau, Guyana, Haiti,
Honduras, Hungary, Iceland, India, Indonesia, Iran, Iraq, Ireland, Italy,
Ivory Coast, Jamaica, Japan, Jordan, Kenya, North Korea, South Korea,
Kuwait, Laos, Lebanon, Lesotho, Liberia, Libya, Liechtenstein,
Luxembourg, Madagascar, Malawi, Malaysia, Mali, Mauritania, Mauritius,
Mexico, Monaco, Mongolia, Morocco, Mozambique, Nepal, Netherlands, NZ,
Nicaragua, Niger, Nigeria, Norway, Pakistan, Panama, Papua New Guinea,
Paraguay, Peru, Philippines, Poland, Portugal, Qatar, Romania, Rwanda,
Saint Lucia, Saint Vincent and the Grenadines, San Marino, Sao Tome and
Principe, Saudi Arabia, Senegal, Sierra Leone, Singapore, Somalia,
South Africa, Spain, Sri Lanka, Sudan, Suriname, Swaziland, Sweden,
Switzerland, Syria, Tanzania, Thailand, Togo, Tonga, Trinidad and Tobago,
Tunisia, Turkey, Uganda, UAE, UK, US, USSR, Uruguay, Venezuela, Vietnam,
Western Samoa, Yemen, Yugoslavia, Zaire, Zambia, Zimbabwe;
associate members--(2) Equatorial Guinea, Gabon
-------------------------------------------------------------------------
_#_least developed countries (LLDCs)--that subgroup of the less
developed countries (LDCs) initially identified by the UN General
Assembly in 1971 as having no significant economic growth, per capita
GNPs/GDPs normally less than $500, and low literacy rates; also known
as the undeveloped countries;
the 41 LLDCs are--Afghanistan, Bangladesh, Benin, Bhutan, Botswana,
Burkina, Burma, Burundi, Cape Verde, Central African Republic, Chad,
Comoros, Djibouti, Equatorial Guinea, Ethiopia, The Gambia, Guinea,
Guinea-Bissau, Haiti, Kiribati, Laos, Lesotho, Malawi, Maldives, Mali,
Mauritania, Mozambique, Nepal, Niger, Rwanda, Sao Tome and Principe,
Sierra Leone, Somalia, Sudan, Tanzania, Togo, Tuvalu, Uganda, Vanuatu,
Western Samoa, Yemen
-------------------------------------------------------------------------
_#_less developed countries (LDCs)--the bottom group in the
comprehensive but mutually exclusive hierarchy of developed countries
(DCs), USSR/Eastern Europe (USSR/EE), and less developed countries
(LDCs); mainly countries with low levels of output, living standards,
and technology; per capita GNPs/GDPs are generally below $5,000 and
often less than $1,000; includes the advanced developing countries,
developing countries, Four Dragons (Four Tigers), least developed
countries (LLDCs), low-income countries, middle-income countries,
newly industrializing economies (NIEs), the South, Third World,
underdeveloped countries, undeveloped countries;
the 173 LDCs are--Afghanistan, Algeria, American Samoa, Angola,
Anguilla, Antigua and Barbuda, Argentina, Aruba, The Bahamas, Bahrain,
Bangladesh, Barbados, Belize, Benin, Bhutan, Bolivia, Botswana, Brazil,
British Virgin Islands, Brunei, Burkina, Burma, Burundi, Cambodia,
Cameroon, Cape Verde, Cayman Islands, Central African Republic, Chad,
Chile, China, Christmas Island, Cocos Islands, Colombia, Comoros, Congo,
Cook Islands, Costa Rica, Cuba, Cyprus, Czechoslovakia, Djibouti,
Dominica, Dominican Republic, Ecuador, Egypt, El Salvador,
Equatorial Guinea, Ethiopia, Falkland Islands, Fiji, French Guiana,
French Polynesia, Gabon, The Gambia, Gaza Strip, Ghana, Gibraltar,
Greenland, Grenada, Guadeloupe, Guam, Guatemala, Guernsey, Guinea,
Guinea-Bissau, Guyana, Haiti, Honduras, Hong Kong, India, Indonesia,
Iran, Iraq, Ivory Coast, Jamaica, Jersey, Jordan, Kenya, Kiribati,
North Korea, South Korea, Kuwait, Laos, Lebanon, Lesotho, Liberia, Libya,
Macau, Madagascar, Malawi, Malaysia, Maldives, Mali, Isle of Man,
Marshall Islands, Martinique, Mauritania, Mauritius, Mayotte, Mexico,
Federated States of Micronesia, Mongolia, Montserrat, Morocco,
Mozambique, Namibia, Nauru, Nepal, Netherlands Antilles, New Caledonia,
Nicaragua, Niger, Nigeria, Niue, Norfolk Island, Northern Mariana
Islands, Oman, Trust Territory of the Pacific Islands (Palau), Pakistan,
Panama, Papua New Guinea, Paraguay, Peru, Philippines, Pitcairn Islands,
Puerto Rico, Qatar, Reunion, Rwanda, Saint Helena, Saint Kitts and Nevis,
Saint Lucia, Saint Pierre and Miquelon, Saint Vincent and the Grenadines,
Sao Tome and Principe, Saudi Arabia, Senegal, Seychelles, Sierra Leone,
Singapore, Solomon Islands, Somalia, Sri Lanka, Sudan, Suriname,
Swaziland, Syria, Taiwan, Tanzania, Thailand, Togo, Tokelau, Tonga,
Trinidad and Tobago, Tunisia, Turks and Caicos Islands, Tuvalu, UAE,
Uganda, Uruguay, Vanuatu, Venezuela, Vietnam, Virgin Islands,
Wallis and Futuna, West Bank, Western Sahara, Western Samoa, Yemen,
Zaire, Zambia, Zimbabwe
-------------------------------------------------------------------------
_#_low-income countries--another term for the less developed
countries with below-average per capita GNPs/GDPs; see less developed
countries (LDCs)
-------------------------------------------------------------------------
_#_middle-income countries--another term for the less developed
countries with above-average per capita GNPs/GDPs; see less developed
countries (LDCs)
-------------------------------------------------------------------------
_#_newly industrializing countries (NICs)--former term for the newly
industrializing economies; see newly industrializing economies (NIEs)
-------------------------------------------------------------------------
_#_newly industrializing economies (NIEs)--that subgroup of the less
developed countries (LDCs) that has experienced particularly rapid
industrialization of their economies; formerly known as the newly
industrializing countries (NICs); also known as advanced developing
countries; usually includes the Four Dragons (Hong Kong, South Korea,
Singapore, Taiwan) plus Brazil and Mexico
-------------------------------------------------------------------------
_#_Nonaligned Movement (NAM)
established--1-6 September 1961;
aim--political and military cooperation apart from the traditional
East or West blocs;
members--(102 plus the Palestine Liberation Organization)
Afghanistan, Algeria, Angola, Argentina, The Bahamas, Bahrain,
Bangladesh, Barbados, Belize, Benin, Bhutan, Bolivia, Botswana, Burkina,
Burundi, Cambodia, Cameroon, Cape Verde, Central African Republic, Chad,
Colombia, Comoros, Congo, Cuba, Cyprus, Djibouti, Ecuador, Egypt,
Equatorial Guinea, Ethiopia, Gabon, The Gambia, Ghana, Grenada, Guinea,
Guinea-Bissau, Guyana, India, Indonesia, Iran, Iraq, Ivory Coast,
Jamaica, Jordan, Kenya, North Korea, Kuwait, Laos, Lebanon, Lesotho,
Liberia, Libya, Madagascar, Malawi, Malaysia, Maldives, Mali, Malta,
Mauritania, Mauritius, Mongolia, Morocco, Mozambique, Namibia, Nepal,
Nicaragua, Niger, Nigeria, Oman, Pakistan, Panama, Peru, Qatar, Rwanda,
Saint Lucia, Sao Tome and Principe, Saudi Arabia, Senegal, Seychelles,
Sierra Leone, Singapore, Somalia, Sri Lanka, Sudan, Suriname, Swaziland,
Syria, Tanzania, Togo, Trinidad and Tobago, Tunisia, Uganda, UAE,
Vanuatu, Venezuela, Vietnam, Yemen, Yugoslavia, Zaire, Zambia, Zimbabwe,
Palestine Liberation Organization;
observers--(9) Antigua and Barbuda, Brazil, Costa Rica, Dominica,
El Salvador, Mexico, Papua New Guinea, Philippines, Uruguay;
guests--(11) Australia, Austria, Dominican Republic, Finland,
Greece, Portugal, Romania, San Marino, Spain, Sweden, Switzerland
-------------------------------------------------------------------------
_#_Nordic Council (NC)
established--16 March 1952, effective 12 February 1953;
aim--to promote regional economic, cultural, and environmental
cooperation;
members--(5) Denmark, Finland, Iceland, Norway, Sweden;
note--Denmark includes Faroe Islands and Greenland
-------------------------------------------------------------------------
_#_Nordic Investment Bank (NIB)
established--4 December 1975, effective 1 June 1976;
aim--to promote economic cooperation and development;
members--(5) Denmark, Finland, Iceland, Norway, Sweden
-------------------------------------------------------------------------
_#_North--a popular term for the rich industrialized countries
generally located in the northern portion of the Northern Hemisphere; the
counterpart of the South; see developed countries (DCs)
-------------------------------------------------------------------------
_#_North Atlantic Treaty Organization (NATO)
established--17 September 1949;
aim--mutual defense and cooperation in other areas;
members--(16) Belgium, Canada, Denmark, France, Germany, Greece,
Iceland, Italy, Luxembourg, Netherlands, Norway, Portugal, Spain, Turkey,
UK, US
-------------------------------------------------------------------------
_#_Nuclear Energy Agency (NEA)
established--NA 1958;
aim--associated with OECD, seeks to promote the peaceful uses of
nuclear energy;
members--(23) Australia, Austria, Belgium, Canada, Denmark,
Finland, France, Germany, Greece, Iceland, Ireland, Italy, Japan,
Luxembourg, Netherlands, Norway, Portugal, Spain, Sweden, Switzerland,
Turkey, UK, US
-------------------------------------------------------------------------
_#_Organismo para la Proscripcion de las Armas Nucleares en la
America Latina y el Caribe (OPANAL)--see Agency for the Prohibition
of Nuclear Weapons in Latin America and the Caribbean (OPANAL)
-------------------------------------------------------------------------
_#_Organization for Economic Cooperation and Development (OECD)
established--14 December 1960, effective 30 September 1961;
aim--to promote economic cooperation and development;
members--(24) Australia, Austria, Belgium, Canada, Denmark,
Finland, France, Germany, Greece, Iceland, Ireland, Italy, Japan,
Luxembourg, Netherlands, NZ, Norway, Portugal, Spain, Sweden,
Switzerland, Turkey, UK, US;
special member--(1) Yugoslavia
-------------------------------------------------------------------------
_#_Organization of African Unity (OAU)
established--25 May 1963;
aim--to promote unity and cooperation among African states;
members--(51) Algeria, Angola, Benin, Botswana, Burkina, Burundi,
Cameroon, Cape Verde, Central African Republic, Chad, Comoros, Congo,
Djibouti, Egypt, Equatorial Guinea, Ethiopia, Gabon, The Gambia, Ghana,
Guinea, Guinea-Bissau, Ivory Coast, Kenya, Lesotho, Liberia, Libya,
Madagascar, Malawi, Mali, Mauritania, Mauritius, Mozambique, Namibia,
Niger, Nigeria, Rwanda, Sahrawi Arab Democratic Republic, Sao Tome and
Principe, Senegal, Seychelles, Sierra Leone, Somalia, Sudan, Swaziland,
Tanzania, Togo, Tunisia, Uganda, Zaire, Zambia, Zimbabwe
-------------------------------------------------------------------------
_#_Organization of American States (OAS)
established--30 April 1948, effective 13 December 1951;
aim--to promote peace and security as well as economic and social
development;
members--(35) Antigua and Barbuda, Argentina, The Bahamas,
Barbados, Belize, Bolivia, Brazil, Canada, Chile, Colombia, Costa Rica,
Cuba (excluded from formal participation since 1962), Dominica, Dominican
Republic, Ecuador, El Salvador, Grenada, Guatemala, Guyana, Haiti,
Honduras, Jamaica, Mexico, Nicaragua, Panama, Paraguay, Peru, Saint Kitts
and Nevis, Saint Lucia, Saint Vincent and the Grenadines, Suriname,
Trinidad and Tobago, US, Uruguay, Venezuela;
observers--(22) Algeria, Austria, Belgium, Cyprus, EC, Egypt,
Equatorial Guinea, Finland, France, Germany, Greece, Israel,
Italy, Japan, Morocco, Netherlands, Pakistan, Portugal, Saudi Arabia,
Spain, Switzerland, Vatican City
-------------------------------------------------------------------------
_#_Organization of Arab Petroleum Exporting Countries (OAPEC)
established--9 January 1968;
aim--to promote cooperation in the petroleum industry;
members--(10) Algeria, Bahrain, Egypt, Iraq, Kuwait, Libya, Qatar,
Saudi Arabia, Syria, UAE
-------------------------------------------------------------------------
_#_Organization of Eastern Caribbean States (OECS)
established--18 June 1981, effective 4 July 1981;
aim--to promote political, economic, and defense cooperation;
members--(7) Antigua and Barbuda, Dominica, Grenada, Montserrat,
Saint Kitts and Nevis, Saint Lucia, Saint Vincent and the Grenadines;
associate member--(1) British Virgin Islands
-------------------------------------------------------------------------
_#_Organization of Petroleum Exporting Countries (OPEC)
established--14 September 1960;
aim--to coordinate petroleum policies;
members--(13) Algeria, Ecuador, Gabon, Indonesia, Iran, Iraq,
Kuwait, Libya, Nigeria, Qatar, Saudi Arabia, UAE, Venezuela
-------------------------------------------------------------------------
_#_Organization of the Islamic Conference (OIC)
established--22-25 September 1969;
aim--to promote Islamic solidarity and cooperation in economic,
social, cultural, and political affairs;
members--(44 plus the Palestine Liberation Organization)
Afghanistan, Algeria, Bahrain, Bangladesh, Benin, Brunei, Burkina,
Cameroon, Chad, Comoros, Djibouti, Egypt, Gabon, The Gambia, Guinea,
Guinea-Bissau, Indonesia, Iran, Iraq, Jordan, Kuwait, Lebanon, Libya,
Malaysia, Maldives, Mali, Mauritania, Morocco, Niger, Nigeria, Oman,
Pakistan, Qatar, Saudi Arabia, Senegal, Sierra Leone, Somalia, Sudan,
Syria, Tunisia, Turkey, Uganda, UAE, Yemen, Palestine Liberation
Organization; note--Afghanistan was suspended in January 1980, but in
March 1989 the self-proclaimed Afghan Interim Government based in
Pakistan was given membership;
observer--(1) Turkish-Cypriot administered area of Cyprus
-------------------------------------------------------------------------
_#_Paris Club--see Group of 10
-------------------------------------------------------------------------
_#_Permanent Court of Arbitration (PCA)
established--NA 1899;
aim--to facilitate the settlement of international disputes;
members--(75) Argentina, Australia, Austria, Belgium, Bolivia,
Brazil, Bulgaria, Burkina, Byelorussian Soviet Socialist Republic,
Cambodia, Cameroon, Canada, Chile, China, Colombia, Cuba, Czechoslovakia,
Denmark, Dominican Republic, Ecuador, Egypt, El Salvador, Fiji, Finland,
France, Germany, Greece, Guatemala, Haiti, Honduras, Hungary,
Iceland, India, Iran, Iraq, Israel, Italy, Japan, Laos, Lebanon,
Luxembourg, Malta, Mauritius, Mexico, Netherlands, NZ, Nicaragua,
Nigeria, Norway, Pakistan, Panama, Paraguay, Peru, Poland, Portugal,
Romania, Senegal, Spain, Sri Lanka, Sudan, Swaziland, Sweden,
Switzerland, Thailand, Turkey, Uganda, Ukrainian Soviet Socialist
Republic, UK, US, USSR, Uruguay, Venezuela, Yugoslavia, Zaire, Zimbabwe
-------------------------------------------------------------------------
_#_Population Commission
established--3 October 19','b03451ba2d83b58d5b59065f4b5832d73882cd36ad19fc75d3b2ef79340e93a1','internet-archive','theciaworldfactb00025gut','txt','84185fe9df79da427349cc1598fd3f69814a2085a9fc1fe0508a3fae0a870f84','https://archive.org/download/theciaworldfactb00025gut/25.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('87efdab7fbafc6c20f5fa5c0d21a0bb330058fd4623b53b252fa1db8ad663e7e',1991,'TO','Tonga','communications',158,'46;
aim--ECOSOC organization dealing with population matters;
members--(27) selected on a rotating basis from all regions
-------------------------------------------------------------------------
_#_Rio Group (RG)
established--NA 1988;
aim--a consultation mechanism on regional Latin American issues;
members--(11) Argentina, Bolivia, Brazil, Chile, Colombia, Ecuador,
Mexico, Paraguay, Peru, Uruguay, Venezuela; note--Panama was expelled
in 1988
-------------------------------------------------------------------------
_#_Second World--another term for the traditionally Marxist-Leninist
states with authoritarian governments and command economies based on the
Soviet model; see centrally planned economies
-------------------------------------------------------------------------
_#_socialist countries--in general, countries in which the government
owns and plans the use of the major factors of production; note--the
term is sometimes used incorrectly as a synonym for Communist countries
-------------------------------------------------------------------------
_#_South--a popular term for the poorer, less industrialized countries
generally located south of the developed countries; the counterpart of
the North; see less developed countries (LDCs)
-------------------------------------------------------------------------
_#_South Asian Association for Regional Cooperation (SAARC)
established--8 December 1985;
aim--to promote economic, social, and cultural cooperation;
members--(7) Bangladesh, Bhutan, India, Maldives, Nepal, Pakistan,','9f30dcda748529323d387444882f3fca4c2cbf874279dc313980babaf4948953','internet-archive','theciaworldfactb00025gut','txt','84185fe9df79da427349cc1598fd3f69814a2085a9fc1fe0508a3fae0a870f84','https://archive.org/download/theciaworldfactb00025gut/25.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('85ad3e46986203fa396bef7ede73cffe4ba5de0dc74443171843a1d82b18ac93',1991,'LK','Sri Lanka','communications',159,'-------------------------------------------------------------------------
_#_South Pacific Commission (SPC)
established--6 February 1947, effective 29 July 1948;
aim--to promote regional cooperation in economic and social
matters;
members--(27) American Samoa, Australia, Cook Islands, Fiji,
France, French Polynesia, Guam, Kiribati, Marshall Islands,
Federated States of Micronesia, Nauru, New Caledonia, NZ, Niue,
Northern Mariana Islands, Trust Territory of the Pacific Islands (Palau),
Papua New Guinea, Pitcairn Islands, Solomon Islands, Tokelau, Tonga,
Tuvalu, UK, US, Vanuatu, Wallis and Futuna, Western Samoa
-------------------------------------------------------------------------
_#_South Pacific Forum (SPF)
established--5 August 1971;
aim--to promote regional cooperation in political matters;
members--(15) Australia, Cook Islands, Fiji, Kiribati,
Marshall Islands, Federated States of Micronesia, Nauru, NZ, Niue,
Papua New Guinea, Solomon Islands, Tonga, Tuvalu, Vanuatu, Western Samoa;
observer--(1) Trust Territory of the Pacific Islands (Palau)
-------------------------------------------------------------------------
_#_Southern African Customs Union (SACU)
established--11 December 1969;
aim--to promote free trade and cooperation in customs matters;
members--(9) Bophuthatswana, Botswana, Ciskei, Lesotho, Namibia,
South Africa, Swaziland, Transkei, Venda
-------------------------------------------------------------------------
_#_Southern African Development Coordination Conference (SADCC)
established--1 April 1980;
aim--to promote regional economic development and reduce
dependence on South Africa;
members--(10) Angola, Botswana, Lesotho, Malawi, Mozambique,
Namibia, Swaziland, Tanzania, Zambia, Zimbabwe
-------------------------------------------------------------------------
_#_Statistical Commission
established--21 June 1946;
aim--ECOSOC organization dealing with development and
standardization of national statistics;
members--(24) selected on a rotating basis from all regions
-------------------------------------------------------------------------
_#_Third World--another term for the less developed countries;
see less developed countries (LDCs)
-------------------------------------------------------------------------
_#_underdeveloped countries--refers to those less developed countries
with the potential for above-average economic growth; see less developed
countries (LDCs)
-------------------------------------------------------------------------
_#_undeveloped countries--refers to those extremely poor less
developed countries (LDCs) with little prospect for economic growth;
see least developed countries (LLDCs)
-------------------------------------------------------------------------
_#_Union Douaniere et Economique de l''Afrique Centrale
(UDEAC)--see Central African Customs and Economic Union (UDEAC)
-------------------------------------------------------------------------
_#_United Nations (UN)
established--26 June 1945, effective 24 October 1945;
aim--to maintain international peace and security as well as
promote cooperation involving economic, social, cultural and humanitarian
problems;
members--(159) Afghanistan, Albania, Algeria, Angola, Antigua and
Barbuda, Argentina, Australia, Austria, The Bahamas, Bahrain, Bangladesh,
Barbados, Belgium, Belize, Benin, Bhutan, Bolivia, Botswana, Brazil,
Brunei, Bulgaria, Burkina, Burma, Burundi, Byelorussian Soviet
Socialist Republic, Cambodia, Cameroon, Canada, Cape Verde, Central
African Republic, Chad, Chile, China, Colombia, Comoros, Congo,
Costa Rica, Cuba, Cyprus, Czechoslovakia, Denmark, Djibouti, Dominica,
Dominican Republic, Ecuador, Egypt, El Salvador, Equatorial Guinea,
Estonia, Ethiopia, Fiji, Finland, France, Gabon, The Gambia, Germany,
Ghana, Greece, Grenada, Guatemala, Guinea, Guinea-Bissau, Guyana, Haiti,
Honduras, Hungary, Iceland, India, Indonesia, Iran, Iraq, Ireland,
Israel, Italy, Ivory Coast, Jamaica, Japan, Jordan, Kenya, North
Korea, South Korea, Kuwait, Laos, Latvia, Lebanon, Lesotho, Liberia,
Libya, Liechtenstein, Lithuania, Luxembourg, Madagascar, Malawi,
Malaysia, Maldives, Mali, Malta, Marshall Islands, Mauritania, Mauritius,
Mexico, Federated States of Micronesia, Mongolia, Morocco, Mozambique,
Namibia, Nepal, Netherlands, NZ, Nicaragua, Niger, Nigeria, Norway, Oman,
Pakistan, Panama, Papua New Guinea, Paraguay, Peru, Philippines, Poland,
Portugal, Qatar, Romania, Rwanda, Saint Kitts and Nevis, Saint Lucia,
Saint Vincent and the Grenadines, Sao Tome and Principe, Saudi Arabia,
Senegal, Seychelles, Sierra Leone, Singapore, Solomon Islands, Somalia,
South Africa, Spain, Sri Lanka, Sudan, Suriname, Swaziland, Sweden,
Syria, Tanzania, Thailand, Togo, Trinidad and Tobago, Tunisia, Turkey,
Uganda, Ukrainian Soviet Socialist Republic, UAE, UK, US, USSR, Uruguay,
Vanuatu, Venezuela, Vietnam, Western Samoa, Yemen, Yugoslavia, Zaire,
Zambia, Zimbabwe;
note--all UN members are represented in the General Assembly;
observers--(4) Monaco, San Marino, Switzerland, Vatican City
-------------------------------------------------------------------------
_#_United Nations Angola Verification Mission (UNAVEM)
established--20 December 1988;
aim--established by the UN Security Council to verify the
withdrawal of Cuban troops from Angola;
members--(10) Algeria, Argentina, Brazil, Congo, Czechoslovakia,
India, Jordan, Norway, Spain, Yugoslavia
-------------------------------------------------------------------------
_#_United Nations Center for Human Settlements (UNCHS or Habitat)
established--12 October 1978;
aim--to assist in solving human settlement problems;
members--(88) selected on a rotating basis from all regions
-------------------------------------------------------------------------
_#_United Nations Children''s Fund (UNICEF)--acronym retained from the
predecessor organization UN International Children''s Emergency Fund;
established--11 December 1946;
aim--to help establish child health and welfare services;
members--(41) selected on a rotating basis from all regions
-------------------------------------------------------------------------
_#_United Nations Conference on Trade and Development (UNCTAD)
established--30 December 1964;
aim--to promote international trade;
members--(166) all UN members plus North Korea, South Korea,
Monaco, San Marino, Switzerland, Tonga, Vatican City
-------------------------------------------------------------------------
_#_United Nations Development Program (UNDP)
established--22 November 1965;
aim--to provide technical assistance to stimulate economic and
social development;
members--(48) selected on a rotating basis from all regions
-------------------------------------------------------------------------
_#_United Nations Disengagement Observer Force (UNDOF)
established--31 May 1974;
aim--established by the UN Security Council to observe the 1973
Arab-Israeli ceasefire;
members--(4) Austria, Canada, Finland, Poland
-------------------------------------------------------------------------
_#_United Nations Educational, Scientific, and Cultural Organization
(UNESCO)
established--16 November 1945, effective 4 November 1946;
aim--to promote cooperation in education, science, and culture;
members--(159) all UN members except Brunei, Liechtenstein,
Singapore, Solomon Islands, South Africa, UK, US, Vanuatu; other members
are Cook Islands, Kiribati, North Korea, South Korea, Monaco, San Marino,
Switzerland, Tonga;
associate members--(3) Aruba, British Virgin Islands,
Netherlands Antilles
-------------------------------------------------------------------------
_#_United Nations Environment Program (UNEP)
established--15 December 1972;
aim--to promote international cooperation on all environmental
matters;
members--(58) selected on a rotating basis from all regions
-------------------------------------------------------------------------
_#_United Nations Force in Cyprus (UNFICYP)
established--4 March 1964;
aim--established by the UN Security Council to serve as a
peacekeeping force beween Greek Cypriots and Turkish Cypriots in Cyprus;
members--(8) Australia, Austria, Canada, Denmark, Finland, Ireland,
Sweden, UK
-------------------------------------------------------------------------
_#_United Nations General Assembly
established--26 June 1945, effective 24 October 1945;
aim--primary deliberative organ in the UN;
members--(159) all UN members are represented in the General
Assembly
-------------------------------------------------------------------------
_#_United Nations Industrial Development Organization (UNIDO)
established--17 November 1966, effective 1 January 1967;
aim--UN specialized agency that promotes industrial development
especially among the members;
members--(150) all UN members except Antigua and Barbuda,
Australia, Brunei, Cambodia, Chad, Djibouti, Iceland, Liberia,
Liechtenstein, Singapore, Solomon Islands, South Africa, Western Samoa;
other members are North Korea, South Korea, Switzerland, Tonga
-------------------------------------------------------------------------
_#_United Nations Interim Force in Lebanon (UNIFIL)
established--19 March 1978;
aim--established by the UN Security Council to confirm the
withdrawal of Israeli forces, restore peace, and reestablish Lebanese
authority in southern Lebanon;
members--(9) Fiji, Finland, France, Ghana, Ireland, Italy, Nepal,
Norway, Sweden
-------------------------------------------------------------------------
_#_United Nations Iran-Iraq Military Observer Group (UNIIMOG)
established--9 August 1988;
aim--established by the UN Security Council to observe the 1988
Iran-Iraq ceasefire;
members--(26) Argentina, Australia, Austria, Bangladesh, Canada,
Denmark, Finland, Ghana, Hungary, India, Indonesia, Ireland, Italy,
Kenya, Malaysia, NZ, Nigeria, Norway, Peru, Poland, Senegal, Sweden,
Turkey, Uruguay, Yugoslavia, Zambia
-------------------------------------------------------------------------
_#_United Nations Military Observer Group in India and Pakistan
(UNMOGIP)
established--13 August 1948;
aim--established by the UN Security Council to observe the 1949
India-Pakistan ceasefire;
members--(8) Belgium, Chile, Denmark, Finland, Italy, Norway,
Sweden, Uruguay
-------------------------------------------------------------------------
_#_United Nations Office of the High Commissioner for Refugees (UNHCR)
established--3 December 1949, effective 1 January 1951;
aim--to try to ensure the humanitarian treatment of refugees and
find permanent solutions to refugee problems;
members--(43) Algeria, Argentina, Australia, Austria, Belgium,
Brazil, Canada, China, Colombia, Denmark, Finland, France, Germany,
Greece, Iran, Israel, Italy, Japan, Lebanon, Lesotho, Madagascar,
Morocco, Namibia, Netherlands, Nicaragua, Nigeria, Norway, Pakistan,
Somalia, Sudan, Sweden, Switzerland, Tanzania, Thailand, Tunisia, Turkey,
Uganda, UK, US, Vatican City, Venezuela, Yugoslavia, Zaire
-------------------------------------------------------------------------
_#_United Nations Population Fund (UNFPA)--acronym retained from
predecessor organization UN Fund for Population Activities;
established--NA July 1967;
aim--to promote assistance in dealing with population problems;
members--(48) selected on a rotating basis from all regions
-------------------------------------------------------------------------
_#_United Nations Relief and Works Agency for Palestine Refugees in the
Near East (UNRWA)
established--8 December 1949;
aim--to provide assistance to Palestinian refugees;
members--(10) Belgium, Egypt, France, Japan, Jordan, Lebanon,
Syria, Turkey, UK, US
-------------------------------------------------------------------------
_#_United Nations Secretariat
established--26 June 1945, effective 24 October 1945;
aim--primary administrative organ of the UN;
members--Secretary General appointed for a five-year term by the
General Assembly on the recommendation of the Security Council
-------------------------------------------------------------------------
_#_United Nations Security Council
established--26 June 1945, effective 24 October 1945;
aim--to maintain international peace and security;
permanent members--(5) China, France, UK, US, USSR;
nonpermanent members--(10) elected for two year terms by the
UN General Assembly; Austria (1991-92), Belgium (1991-92),
Cuba (1990-91), Ecuador (1991-92), India (1991-92),
Ivory Coast (1990-91), Romania (1990-91), Yemen (1990-91),
Zaire (1990-91), Zimbabwe (1991-92)
-------------------------------------------------------------------------
_#_United Nations Truce Supervision Organization (UNTSO)
established--NA May 1948;
aim--initially established by the UN Security Council to supervise
the 1948 Arab-Israeli ceasefire and subsequently extended to work
in the Sinai, Lebanon, Jordan, Afghanistan, and Pakistan;
members--(16) Argentina, Australia, Austria, Canada, Chile,
Denmark, Finland, France, Ireland, Italy, Netherlands, NZ, Norway,
Sweden, US, USSR
-------------------------------------------------------------------------
_#_United Nations Trusteeship Council
established--26 June 1945, effective 24 October 1945;
aim--to supervise the administration of the UN trust territories;
only one of the original 11 trusteeships remains--the Trust Territory of
the Pacific Islands (Palau);
members--(5) China, France, UK, US, USSR
-------------------------------------------------------------------------
_#_Universal Postal Union (UPU)
established--9 October 1874, affiliated with the UN
15 November 1947, effective 1 July 1948;
aim--UN specialized agency that promotes international postal
cooperation;
members--(168) all UN members except Antigua and Barbuda, Namibia,
South Africa; other members are Kiribati, North Korea, South Korea,
Monaco, Nauru, Netherlands Antilles, San Marino, Switzerland, Tonga,
Tuvalu, UK Overseas Territories, Vatican City
-------------------------------------------------------------------------
_#_USSR/Eastern Europe (USSR/EE)--the middle group in the
comprehensive but mutually exclusive hierarchy of developed countries
(DCs), USSR/Eastern Europe (USSR/EE), and less developed countries
(LDCs); these countries are in political and economic transition; this
group includes Albania, Bulgaria, Czechoslovakia, Hungary, Poland,
Romania, USSR, Yugoslavia
-------------------------------------------------------------------------
_#_Warsaw Pact (WP)--was established 14 May 1955 to promote mutual
defense; members met 1 July 1991 to dissolve the alliance;
member states--Bulgaria, Czechoslovakia, Hungary, Poland, Romania, and
the USSR--are now in the process of ratifying this agreement
-------------------------------------------------------------------------
_#_West African Development Bank (WADB), also known as Banque
Ouest-Africaine de Developpement (BOAD);
established--14 November 1973;
aim--to promote economic development and integration;
members--(7) Benin, Burkina, Ivory Coast, Mali, Niger, Senegal,','5b31742839234d8840a60bbe305f4721a7ad7bc95ae60858d88601bb946c5073','internet-archive','theciaworldfactb00025gut','txt','84185fe9df79da427349cc1598fd3f69814a2085a9fc1fe0508a3fae0a870f84','https://archive.org/download/theciaworldfactb00025gut/25.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('76bc934df8f26b53b7f73a359c21d9a2c03d07fee487557692ebe9850683e365',1991,'TG','Togo','communications',160,'-------------------------------------------------------------------------
_#_West African Economic Community (CEAO)--acronym from Communaute
Economique de l''Afrique de l''Ouest;
established--3 June 1972;
aim--to promote regional economic development;
members--(7) Benin, Burkina, Ivory Coast, Mali, Mauritania, Niger,
Senegal;
observers--(2) Guinea, Togo
-------------------------------------------------------------------------
_#_Western European Union (WEU)
established--23 October 1954, effective 6 May 1955;
aim--mutual defense and progressive political unification;
members--(9) Belgium, France, Germany, Italy, Luxembourg,
Netherlands, Portugal, Spain, UK
-------------------------------------------------------------------------
_#_World Bank--see International Bank for Reconstruction and
Development (IBRD)
-------------------------------------------------------------------------
_#_World Confederation of Labor (WCL)
established--19 June 1920 as the International Federation of
Christian Trade Unions (IFCTU), renamed 4 October 1968;
aim--to promote the trade union movement;
members--(93 national organizations) Algeria, Angola,
Antigua and Barbuda, Argentina, Aruba, Austria, Bangladesh, Belgium,
Belize, Benin, Bolivia, Botswana, Brazil, Burkina, Cameroon, Canada,
Cape Verde, Central African Republic, Chad, Chile, Colombia, Costa Rica,
Cuba, Cyprus, Dominica, Dominican Republic, Ecuador, El Salvador, France,
French Guiana, Gabon, The Gambia, Ghana, Grenada, Guadaloupe, Guatemala,
Guinea, Guyana, Haiti, Honduras, Hong Kong, Indonesia, Italy,
Ivory Coast, Jamaica, Kenya, Lesotho, Liberia, Liechtenstein, Luxembourg,
Madagascar, Malaysia, Mali, Malta, Martinique, Mauritius, Mexico,
Montserrat, Namibia, Netherlands, Netherlands Antilles, Nicaragua, Niger,
Nigeria, Pakistan, Panama, Paraguay, Peru, Philippines, Poland, Portugal,
Puerto Rico, Rwanda, Saint Kitts and Nevis, Saint Lucia, Saint Vincent
and the Grenadines, Senegal, Seychelles, Sierra Leone, Spain, Sri Lanka,
Suriname, Switzerland, Tanzania, Thailand, Togo, UK, US, Uruguay,
Vietnam, Zaire, Zambia, Zimbabwe
-------------------------------------------------------------------------
_#_World Court--see International Court of Justice (ICJ)
-------------------------------------------------------------------------
_#_World Federation of Trade Unions (WFTU)
established--NA 1945;
aim--to promote the trade union movement;
members--(74 plus the Palestine Liberation Organization)
Afghanistan, Albania, Angola, Argentina, Austria, Bahrain, Bangladesh,
Benin, Bolivia, Bulgaria, Burkina, Cambodia, China, Congo, Costa Rica,
Cuba, Cyprus, Czechoslovakia, Dominican Republic, Ecuador, El Salvador,
Ethiopia, France, French Guiana, The Gambia, Germany, Guadaloupe,
Guatemala, Guinea-Bissau, Guyana, Haiti, Honduras, Hungary, India,
Indonesia, Iran, Iraq, Jamaica, Jordan, North Korea, Kuwait, Laos,
Lebanon, Madagascar, Martinique, Mauritius, Mongolia, Namibia, New
Caledonia, Nicaragua, Oman, Pakistan, Panama, Peru, Philippines,
Poland, Puerto Rico, Reunion, Romania, Saint Pierre and Miquelon, Saint
Vincent and the Grenadines, Saudi Arabia, Senegal, Solomon Islands, South
Africa, Sri Lanka, Sudan, Syria, Trinidad and Tobago, USSR, Vanuatu,
Venezuela, Vietnam, Yemen, Palestine Liberation Organization
-------------------------------------------------------------------------
_#_World Food Council (WFC)
established--17 December 1974;
aim--ECOSOC organization that studies world food problems and
recommends solutions;
members--(36) selected on a rotating basis from all regions
-------------------------------------------------------------------------
_#_World Food Program (WFP)
established--24 November 1961;
aim--ECOSOC organization that provides food aid to assist in
development or disaster relief;
members--(30) selected on a rotating basis from all regions
-------------------------------------------------------------------------
_#_World Health Organization (WHO)
established--22 July 1946, effective 7 April 1948;
aim--UN specialized agency concerned with health matters;
members--(165) all UN members except Belize, Liechtenstein;
other members are Cook Islands, Kiribati, North Korea, South Korea,
Monaco, San Marino, Switzerland, Tonga
-------------------------------------------------------------------------
_#_World Intellectual Property Organization (WIPO)
established--14 July 1967, effective 26 April 1970;
aim--UN specialized agency concerned with the protection of
literary, artistic, and scientific works;
members--(124) Algeria, Angola, Argentina, Australia, Austria,
The Bahamas, Bangladesh, Barbados, Belgium, Benin, Brazil, Bulgaria,
Burkina, Burundi, Byelorussian Soviet Socialist Republic, Cameroon,
Canada, Central African Republic, Chad, Chile, China, Colombia, Congo,
Costa Rica, Cuba, Cyprus, Czechoslovakia, Denmark, Ecuador, Egypt,
El Salvador, Fiji, Finland, France, Gabon, The Gambia, Germany, Ghana,
Greece, Guatemala, Guinea, Guinea-Bissau, Haiti, Honduras, Hungary,
Iceland, India, Indonesia, Iraq, Ireland, Israel, Italy, Ivory Coast,
Jamaica, Japan, Jordan, Kenya, North Korea, South Korea, Lebanon,
Lesotho, Liberia, Libya, Liechtenstein, Luxembourg, Madagascar, Malawi,
Malaysia, Mali, Malta, Mauritania, Mauritius, Mexico, Monaco, Mongolia,
Morocco, Netherlands, NZ, Nicaragua, Niger, Norway, Pakistan, Panama,
Paraguay, Peru, Philippines, Poland, Portugal, Qatar, Romania, Rwanda,
Saudi Arabia, Senegal, Sierra Leone, Somalia, South Africa, Spain,
Sri Lanka, Sudan, Suriname, Swaziland, Sweden, Switzerland, Tanzania,
Thailand, Togo, Trinidad and Tobago, Tunisia, Turkey, Uganda,
Ukrainian Soviet Socialist Republic, UAE, UK, US, USSR, Uruguay,
Vatican City, Venezuela, Vietnam, Yemen, Yugoslavia, Zaire, Zambia,','9baa98c0bd42970cdd61a069e8c01048f24cbf8e833dc645d86ac09c919bff63','internet-archive','theciaworldfactb00025gut','txt','84185fe9df79da427349cc1598fd3f69814a2085a9fc1fe0508a3fae0a870f84','https://archive.org/download/theciaworldfactb00025gut/25.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);

SET NAMES utf8mb4;
CREATE TABLE IF NOT EXISTS worldfactbook_chunks (
  chunk_id CHAR(64) NOT NULL,
  edition_year SMALLINT UNSIGNED NOT NULL,
  entity_code VARCHAR(24) NOT NULL DEFAULT '',
  entity_name VARCHAR(160) NOT NULL DEFAULT '',
  category VARCHAR(96) NOT NULL,
  ordinal INT UNSIGNED NOT NULL,
  content MEDIUMTEXT NOT NULL,
  content_sha256 CHAR(64) NOT NULL,
  source_provider VARCHAR(64) NOT NULL,
  source_identifier VARCHAR(255) NOT NULL,
  source_format VARCHAR(32) NOT NULL,
  source_sha256 CHAR(64) NOT NULL,
  source_url TEXT NOT NULL,
  extractor VARCHAR(64) NOT NULL,
  PRIMARY KEY (chunk_id),
  KEY idx_wfb_year_category (edition_year, category),
  KEY idx_wfb_entity_year (entity_code, edition_year),
  KEY idx_wfb_source_sha (source_sha256)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e56c0b2d524602e38b5341a770bef8659eecf446c1aa4b2019ecb13ca16547af',1991,'','','raw',1,'The Project Gutenberg EBook of The 1991 CIA World Factbook, by
United States. Central Intelligence Agency.
This eBook is for the use of anyone anywhere at no cost and with
almost no restrictions whatsoever. You may copy it, give it away or
re-use it under the terms of the Project Gutenberg License included
with this eBook or online at www.gutenberg.net
Title: The 1991 CIA World Factbook
Author: United States. Central Intelligence Agency.
Posting Date: February 21, 2010 [EBook #25]
Release Date: January, 1992
Language: English
Character set encoding: ASCII
*** START OF THIS PROJECT GUTENBERG EBOOK THE 1991 CIA WORLD FACTBOOK ***
Produced by Dr. Gregory B. Newby
15 October 1991
The CIA World Factbook 1991
Some tags useful for searching the factbook are as follows:
_@_ the first three characters in each country heading;
for example, _@_Afghanistan
_@_Albania
_@_Algeria
_@_American Samoa
_*_ the first three characters in each section heading;
for example, _*_Geography','7ab1d208454ab44ecdcd96c574aa04b794aacabff8a1d82c4cbb6103734c2b90','internet-archive','theciaworldfactb00025gut','txt','84185fe9df79da427349cc1598fd3f69814a2085a9fc1fe0508a3fae0a870f84','https://archive.org/download/theciaworldfactb00025gut/25.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);

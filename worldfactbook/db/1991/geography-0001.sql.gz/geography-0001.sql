SET NAMES utf8mb4;
CREATE TABLE IF NOT EXISTS worldfactbook_chunks (
  chunk_id CHAR(64) NOT NULL,
  edition_year SMALLINT UNSIGNED NOT NULL,
  entity_code VARCHAR(24) NOT NULL DEFAULT '',
  entity_name VARCHAR(160) NOT NULL DEFAULT '',
  category VARCHAR(96) NOT NULL,
  ordinal INT UNSIGNED NOT NULL,
  content MEDIUMTEXT NOT NULL,
  content_sha256 CHAR(64) NOT NULL,
  source_provider VARCHAR(64) NOT NULL,
  source_identifier VARCHAR(255) NOT NULL,
  source_format VARCHAR(32) NOT NULL,
  source_sha256 CHAR(64) NOT NULL,
  source_url TEXT NOT NULL,
  extractor VARCHAR(64) NOT NULL,
  PRIMARY KEY (chunk_id),
  KEY idx_wfb_year_category (edition_year, category),
  KEY idx_wfb_entity_year (entity_code, edition_year),
  KEY idx_wfb_source_sha (source_sha256)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4a2264a3acf15e913c577c9d86d338826d4d0a7c2e93920745dcd67b6c062598',1991,'ZW','Zimbabwe','geography',13,'_#_Total area: 647,500 km2; land area: 647,500 km2
_#_Comparative area: slightly smaller than Texas
_#_Land boundaries: 5,826 km total; China 76 km, Iran 936 km,
Pakistan 2,430 km, USSR 2,384 km
_#_Coastline: none--landlocked
_#_Maritime claims: none--landlocked
_#_Disputes: Pashtun question with Pakistan; Baloch question with Iran
and Pakistan; periodic disputes with Iran over Helmand water rights;
insurgency with Iranian and Pakistani involvement; traditional tribal
rivalries
_#_Climate: arid to semiarid; cold winters and hot summers
_#_Terrain: mostly rugged mountains; plains in north and southwest
_#_Natural resources: natural gas, crude oil, coal, copper, talc,
barites, sulphur, lead, zinc, iron ore, salt, precious and
semiprecious stones
_#_Land use: arable land 12%; permanent crops NEGL%; meadows and
pastures 46%; forest and woodland 3%; other 39%; includes irrigated
NEGL%
_#_Environment: damaging earthquakes occur in Hindu Kush mountains;
soil degradation, desertification, overgrazing, deforestation, pollution
_#_Note: landlocked
_#_Total area: 28,750 km2; land area: 27,400 km2
_#_Comparative area: slightly larger than Maryland
_#_Land boundaries: 768 km total; Greece 282 km, Yugoslavia 486 km
_#_Coastline: 362 km
_#_Maritime claims:
Continental shelf: not specified;
Territorial sea: 12 nm
_#_Disputes: Kosovo question with Yugoslavia; Northern Epirus question
with Greece
_#_Climate: mild temperate; cool, cloudy, wet winters; hot, clear, dry
summers; interior is cooler and wetter
_#_Terrain: mostly mountains and hills; small plains along coast
_#_Natural resources: crude oil, natural gas, coal, chromium,
copper, timber, nickel
_#_Land use: arable land 21%; permanent crops 4%; meadows and
pastures 15%; forest and woodland 38%; other 22%; includes irrigated
1%
_#_Environment: subject to destructive earthquakes; tsunami occur
along southwestern coast; deforestation seems to be slowing
_#_Note: strategic location along Strait of Otranto (links
Adriatic Sea to Ionian Sea and Mediterranean Sea)
_#_Total area: 2,381,740 km2; land area: 2,381,740 km2
_#_Comparative area: slightly less than 3.5 times the size of Texas
_#_Land boundaries: 6,343 km total; Libya 982 km, Mali 1,376 km,
Mauritania 463 km, Morocco 1,559 km, Niger 956 km, Tunisia 965 km,
Western Sahara 42 km
_#_Coastline: 998 km
_#_Maritime claims:
Territorial sea: 12 nm
_#_Disputes: Libya claims about 19,400 km2 in southeastern Algeria
_#_Climate: arid to semiarid; mild, wet winters with hot, dry summers
along coast; drier with cold winters and hot summers on high plateau;
sirocco is a hot, dust/sand-laden wind especially common in summer
_#_Terrain: mostly high plateau and desert; some mountains; narrow,
discontinuous coastal plain
_#_Natural resources: crude oil, natural gas, iron ore, phosphates,
uranium, lead, zinc
_#_Land use: arable land 3%; permanent crops NEGL%; meadows and
pastures 13%; forest and woodland 2%; other 82%; includes irrigated
NEGL%
_#_Environment: mountainous areas subject to severe earthquakes;
desertification
_#_Note: second-largest country in Africa (after Sudan)
_#_Total area: 199 km2; land area: 199 km2
_#_Comparative area: slightly larger than Washington, DC
_#_Land boundaries: none
_#_Coastline: 116 km
_#_Maritime claims:
Contiguous zone: 12 nm;
Continental shelf: 200 m (depth);
Exclusive economic zone: 200 nm;
Territorial sea: 12 nm
_#_Climate: tropical marine, moderated by southeast trade winds;
annual rainfall averages 124 inches; rainy season from November to April,
dry season from May to October; little seasonal temperature variation
_#_Terrain: five volcanic islands with rugged peaks and limited
coastal plains, two coral atolls
_#_Natural resources: pumice and pumicite
_#_Land use: arable land 10%; permanent crops 5%; meadows and
pastures 0%; forest and woodland 75%; other 10%
_#_Environment: typhoons common from December to March
_#_Note: Pago Pago has one of the best natural deepwater harbors in
the South Pacific Ocean, sheltered by shape from rough seas and protected
by peripheral mountains from high winds; strategic location about
3,700 km south-southwest of Honolulu in the South Pacific Ocean about
halfway between Hawaii and New Zealand
_#_Total area: 450 km2; land area: 450 km2
_#_Comparative area: slightly more than 2.5 times the size of
Washington, DC
_#_Land boundaries: 125 km total; France 60 km, Spain 65 km
_#_Coastline: none--landlocked
_#_Maritime claims: none--landlocked
_#_Climate: temperate; snowy, cold winters and cool, dry summers
_#_Terrain: rugged mountains dissected by narrow valleys
_#_Natural resources: hydropower, mineral water, timber,
iron ore, lead
_#_Land use: arable land 2%; permanent crops 0%; meadows and
pastures 56%; forest and woodland 22%; other 20%
_#_Environment: deforestation, overgrazing
_#_Note: landlocked
_#_Total area: 1,246,700 km2; land area: 1,246,700 km2
_#_Comparative area: slightly less than twice the size of Texas
_#_Land boundaries: 5,198 km total; Congo 201 km, Namibia 1,376 km,
Zaire 2,511 km, Zambia 1,110 km
_#_Coastline: 1,600 km
_#_Maritime claims:
Exclusive fishing zone: 200 nm;
Territorial sea: 20 nm
_#_Disputes: civil war since independence on 11 November 1975;
on 31 May 1991 Angolan President Jose Eduardo dos SANTOS
and Jonas SAVIMBI, leader of the National Union for the Total
Independence of Angola (UNITA), signed a peace treaty that calls for
multiparty elections between September and November 1992, an
internationally monitored cease-fire, and termination of outside
military assistance
_#_Climate: semiarid in south and along coast to Luanda; north has
cool, dry season (May to October) and hot, rainy season (November to
April)
_#_Terrain: narrow coastal plain rises abruptly to vast interior
plateau
_#_Natural resources: petroleum, diamonds, iron ore, phosphates,
copper, feldspar, gold, bauxite, uranium
_#_Land use: arable land 2%; permanent crops NEGL%; meadows and
pastures 23%; forest and woodland 43%; other 32%
_#_Environment: locally heavy rainfall causes periodic flooding on
plateau; desertification
_#_Note: Cabinda is separated from rest of country by Zaire
_#_Total area: 91 km2; land area: 91 km2
_#_Comparative area: about half the size of Washington, DC
_#_Land boundaries: none
_#_Coastline: 61 km
_#_Maritime claims:
Exclusive fishing zone: 200 nm;
Territorial sea: 3 nm
_#_Climate: tropical; moderated by northeast trade winds
_#_Terrain: flat and low-lying island of coral and limestone
_#_Natural resources: negligible; salt, fish, lobster
_#_Land use: arable land NA%; permanent crops NA%; meadows and
pastures NA%; forest and woodland NA%; other NA%; mostly rock with sparse
scrub oak, few trees, some commercial salt ponds
_#_Environment: frequent hurricanes, other tropical storms (July
to October)
_#_Note: located 270 km east of Puerto Rico
_#_Total area: about 14,000,000 km2; land area: about 14,000,000 km2
_#_Comparative area: slightly less than 1.5 times the size of the US;
second-smallest continent (after Australia)
_#_Land boundaries: see entry on _#_Disputes
_#_Coastline: 17,968 km
_#_Maritime claims: see entry on _#_Disputes
_#_Disputes: Antarctic Treaty defers claims (see Antarctic Treaty
Summary below); sections (some overlapping) claimed by Argentina,
Australia, Chile, France (Adelie Land), New Zealand (Ross Dependency),
Norway (Queen Maud Land), and UK; Brazil has noted possible Latin claims;
the US and USSR do not recognize the territorial claims of other nations
and have made no claims themselves (but reserve the right to do so); no
formal claims have been made in the sector between 90o west and
150o west
_#_Climate: severe low temperatures vary with latitude, elevation, and
distance from the ocean; East Antarctica colder than West Antarctica
because of its higher elevation; Antarctic Peninsula has most
moderate climate; warmest temperatures occur in January along the coast
and average slightly below freezing
_#_Terrain: about 98% thick continental ice sheet, with average
elevations between 2,000 and 4,000 meters; mountain ranges up to 4,897
meters high; ice-free coastal areas include parts of southern Victoria
Land, Wilkes Land, the Antarctic Peninsula area, and Ross Island on
McMurdo Sound; glaciers form ice shelves along about half of coastline
and floating ice shelves constitute 11% of the area of the continent
_#_Natural resources: none presently exploited; coal and iron ore;
chromium, copper, gold, nickel, platinum, and hydrocarbons have been
found in small uncommercial quantities
_#_Land use: arable land 0%; permanent crops 0%; pastures 0%;
meadows and forest and woodland 0%; other 100% (ice 98%, barren rock
2%)
_#_Environment: mostly uninhabitable; katabatic (gravity) winds blow
coastward from the high interior; frequent blizzards form near the foot
of the plateau; cyclonic storms form over the ocean and move clockwise
around the coast, as does a circumpolar ocean current; during
summer more solar radiation reaches the surface at the South Pole than
is received at the Equator in an equivalent period; in April 1991 it was
reported that the ozone shield, which protects the Earth''s surface from
harmful ultraviolet radiation, had dwindled to its lowest level ever over
Antarctica; subject to active volcanism (Deception Island and isolated
areas of West Antarctica); other seismic activity rare and weak
_#_Note: the coldest, windiest, highest, and driest continent
_#_Total area: 440 km2; land area: 440 km2; includes Redonda
_#_Comparative area: slightly less than 2.5 times the size of
Washington, DC
_#_Land boundaries: none
_#_Coastline: 153 km
_#_Maritime claims:
Contiguous zone: 24 nm;
Exclusive economic zone: 200 nm;
Territorial sea: 12 nm
_#_Climate: tropical marine; little seasonal temperature variation
_#_Terrain: mostly low-lying limestone and coral islands with some
higher volcanic areas
_#_Natural resources: negligible; pleasant climate fosters
tourism
_#_Land use: arable land 18%; permanent crops 0%; meadows and
pastures 7%; forest and woodland 16%; other 59%
_#_Environment: subject to hurricanes and tropical storms (July to
October); insufficient freshwater resources; deeply indented coastline
provides many natural harbors
_#_Note: 420 km east-southeast of Puerto Rico
_#_Total area: 14,056,000 km2; includes Baffin Bay, Barents Sea,
Beaufort Sea, Chukchi Sea, East Siberian Sea, Greenland Sea, Hudson Bay,
Hudson Strait, Kara Sea, Laptev Sea, and other tributary water bodies
_#_Comparative area: slightly more than 1.5 times the size of the US;
smallest of the world''s four oceans (after Pacific Ocean, Atlantic Ocean,
and Indian Ocean)
_#_Coastline: 45,389 km
_#_Climate: persistent cold and relatively narrow annual temperature
ranges; winters characterized by continuous darkness, cold and stable
weather conditions, and clear skies; summers characterized by continuous
daylight, damp and foggy weather, and weak cyclones with rain or snow
_#_Terrain: central surface covered by a perennial drifting polar
icepack which averages about 3 meters in thickness, although pressure
ridges may be three times that size; clockwise drift pattern in the
Beaufort Gyral Stream, but nearly straight line movement from the New
Siberian Islands (USSR) to Denmark Strait (between Greenland and
Iceland); the ice pack is surrounded by open seas during the summer, but
more than doubles in size during the winter and extends to the encircling
land masses; the ocean floor is about 50% continental shelf (highest
percentage of any ocean) with the remainder a central basin interrupted
by three submarine ridges (Alpha Cordillera, Nansen Cordillera, and
Lomonsov Ridge); maximum depth is 4,665 meters in the Fram Basin
_#_Natural resources: sand and gravel aggregates, placer deposits,
polymetallic nodules, oil and gas fields, fish, marine mammals (seals,
whales)
_#_Environment: endangered marine species include walruses and whales;
ice islands occasionally break away from northern Ellesmere Island;
icebergs calved from western Greenland and extreme northeastern Canada;
maximum snow cover in March or April about 20 to 50 centimeters over the
frozen ocean and lasts about 10 months; permafrost in islands; virtually
icelocked from October to June; fragile ecosystem slow to change and slow
to recover from disruptions or damage
_#_Note: major chokepoint is the southern Chukchi Sea (northern
access to the Pacific Ocean via the Bering Strait); ships subject to
superstructure icing from October to May; strategic location between
North America and the USSR; shortest marine link between the extremes of
eastern and western USSR; floating research stations operated by the US
and USSR
_#_Total area: 2,766,890 km2; land area: 2,736,690 km2
_#_Comparative area: slightly more than four times the size of Texas
_#_Land boundaries: 9,665 km total; Bolivia 832 km, Brazil 1,224 km,
Chile 5,150 km, Paraguay 1,880 km, Uruguay 579 km
_#_Coastline: 4,989 km
_#_Maritime claims:
Continental shelf: 200 m (depth) or to depth of exploitation;
Territorial sea: 200 nm (overflight and navigation permitted beyond
12 nm)
_#_Disputes: short section of the boundary with Uruguay is in dispute;
short section of the boundary with Chile is indefinite; claims
British-administered Falkland Islands (Islas Malvinas); claims
British-administered South Georgia and the South Sandwich Islands;
territorial claim in Antarctica
_#_Climate: mostly temperate; arid in southeast; subantarctic in
southwest
_#_Terrain: rich plains of the Pampas in northern half, flat to
rolling plateau of Patagonia in south, rugged Andes along western border
_#_Natural resources: fertile plains of the pampas, lead, zinc,
tin, copper, iron ore, manganese, crude oil, uranium
_#_Land use: arable land 9%; permanent crops 4%; meadows and
pastures 52%; forest and woodland 22%; other 13%; includes irrigated
1%
_#_Environment: Tucuman and Mendoza areas in Andes subject to
earthquakes; pamperos are violent windstorms that can strike Pampas and
northeast; irrigated soil degradation; desertification; air and water
pollution in Buenos Aires
_#_Note: second-largest country in South America (after Brazil);
strategic location relative to sea lanes between South Atlantic and
South Pacific Oceans (Strait of Magellan, Beagle Channel, Drake Passage)
_#_Total area: 193 km2; land area: 193 km2
_#_Comparative area: slightly larger than Washington, DC
_#_Land boundaries: none
_#_Coastline: 68.5 km
_#_Maritime claims:
Exclusive fishing zone: 12 nm;
Territorial sea: 12 nm
_#_Climate: tropical marine; little seasonal temperature variation
_#_Terrain: flat with a few hills; scant vegetation
_#_Natural resources: negligible; white sandy beaches
_#_Land use: arable land 0%; permanent crops 0%; meadows and
pastures 0%; forest and woodland 0%; other 100%
_#_Environment: lies outside the Caribbean hurricane belt
_#_Note: 28 km north of Venezuela
_#_Total area: 5 km2; land area: 5 km2; includes Ashmore Reef (West,
Middle, and East Islets) and Cartier Island
_#_Comparative area: about 8.5 times the size of The Mall in
Washington, DC
_#_Land boundaries: none
_#_Coastline: 74.1 km
_#_Maritime claims:
Contiguous zone: 12 nm;
Continental shelf: 200 m (depth) or to depth of exploration;
Exclusive fishing zone: 200 nm;
Territorial sea: 3 nm
_#_Climate: tropical
_#_Terrain: low with sand and coral
_#_Natural resources: fish
_#_Land use: arable land 0%; permanent crops 0%; meadows and
pastures 0%; forest and woodland 0%; other--grass and sand 100%
_#_Environment: surrounded by shoals and reefs; Ashmore Reef National
Nature Reserve established in August 1983
_#_Note: located in extreme eastern Indian Ocean between Australia
and Indonesia 320 km off the northwest coast of Australia
_#_Total area: 82,217,000 km2; includes Baltic Sea, Black Sea,
Caribbean Sea, Davis Strait, Denmark Strait, Drake Passage, Gulf of
Mexico, Mediterranean Sea, North Sea, Norwegian Sea, Weddell Sea, and
other tributary water bodies
_#_Comparative area: slightly less than nine times the size of the US;
second-largest of the world''s four oceans (after the Pacific Ocean, but
larger than Indian Ocean or Arctic Ocean)
_#_Coastline: 111,866 km
_#_Climate: tropical cyclones (hurricanes) develop off the coast of
Africa near Cape Verde and move westward into the Caribbean Sea;
hurricanes can occur from May to December, but are most frequent from
August to November
_#_Terrain: surface usually covered with sea ice in Labrador Sea,
Denmark Strait, and Baltic Sea from October to June; clockwise warm
water gyre (broad, circular system of currents) in the north Atlantic,
counterclockwise warm water gyre in the south Atlantic; the ocean floor
is dominated by the Mid-Atlantic Ridge, a rugged north-south centerline
for the entire Atlantic basin; maximum depth is 8,605 meters in the
Puerto Rico Trench
_#_Natural resources: oil and gas fields, fish, marine mammals (seals
and whales), sand and gravel aggregates, placer deposits, polymetallic
nodules, precious stones
_#_Environment: endangered marine species include the manatee, seals,
sea lions, turtles, and whales; municipal sludge pollution off eastern
US, southern Brazil, and eastern Argentina; oil pollution in Caribbean
Sea, Gulf of Mexico, Lake Maracaibo, Mediterranean Sea, and North Sea;
industrial waste and municipal sewage pollution in Baltic Sea, North Sea,
and Mediterranean Sea; icebergs common in Davis Strait, Denmark Strait,
and the northwestern Atlantic from February to August and have been
spotted as far south as Bermuda and the Madeira Islands; icebergs from
Antarctica occur in the extreme southern Atlantic
_#_Note: ships subject to superstructure icing in extreme north
Atlantic from October to May and extreme south Atlantic from May to
October; persistent fog can be a hazard to shipping from May to
September; major choke points include the Dardanelles, Strait of
Gibraltar, access to the Panama and Suez Canals; strategic straits
include the Dover Strait, Straits of Florida, Mona Passage, The Sound
(Oresund), and Windward Passage; north Atlantic shipping lanes subject
to icebergs from February to August; the Equator divides the Atlantic
Ocean into the North Atlantic Ocean and South Atlantic Ocean
_#_Total area: 7,686,850 km2; land area: 7,617,930 km2; includes
Macquarie Island
_#_Comparative area: slightly smaller than the US
_#_Land boundaries: none
_#_Coastline: 25,760 km
_#_Maritime claims:
Contiguous zone: 12 nm;
Continental shelf: 200 m (depth) or to depth of exploitation;
Exclusive fishing zone: 200 nm;
Territorial sea: 3 nm
_#_Disputes: territorial claim in Antarctica (Australian Antarctic
Territory)
_#_Climate: generally arid to semiarid; temperate in south and east;
tropical in north
_#_Terrain: mostly low plateau with deserts; fertile plain in
southeast
_#_Natural resources: bauxite, coal, iron ore, copper, tin, silver,
uranium, nickel, tungsten, mineral sands, lead, zinc, diamonds, natural
gas, crude oil
_#_Land use: arable land 6%; permanent crops NEGL%; meadows and
pastures 58%; forest and woodland 14%; other 22%; includes irrigated
NEGL%
_#_Environment: subject to severe droughts and floods; cyclones along
coast; limited freshwater availability; irrigated soil degradation;
regular, tropical, invigorating, sea breeze known as the doctor occurs
along west coast in summer; desertification
_#_Note: world''s smallest continent but sixth-largest country
_#_Total area: 83,850 km2; land area: 82,730 km2
_#_Comparative area: slightly smaller than Maine
_#_Land boundaries: 2,640 km total; Czechoslovakia 548 km,
Germany 784 km, Hungary 366 km, Italy 430 km, Liechtenstein 37 km,
Switzerland 164 km, Yugoslavia 311 km
_#_Coastline: none--landlocked
_#_Maritime claims: none--landlocked
_#_Climate: temperate; continental, cloudy; cold winters with frequent
rain in lowlands and snow in mountains; cool summers with occasional
showers
_#_Terrain: mostly mountains with Alps in west and south; mostly flat,
with gentle slopes along eastern and northern margins
_#_Natural resources: iron ore, crude oil, timber, magnesite,
aluminum, lead, coal, lignite, copper, hydropower
_#_Land use: arable land 17%; permanent crops 1%; meadows and
pastures 24%; forest and woodland 39%; other 19%; includes irrigated
NEGL%
_#_Environment: because of steep slopes, poor soils, and cold
temperatures, population is concentrated on eastern lowlands
_#_Note: landlocked; strategic location at the crossroads of
central Europe with many easily traversable Alpine passes and valleys;
major river is the Danube
_#_Total area: 13,940 km2; land area: 10,070 km2
_#_Comparative area: slightly larger than Connecticut
_#_Land boundaries: none
_#_Coastline: 3,542 km
_#_Maritime claims:
Continental shelf: 200 m (depth) or to depth of exploitation;
Exclusive fishing zone: 200 nm;
Territorial sea: 3 nm
_#_Climate: tropical marine; moderated by warm waters of Gulf Stream
_#_Terrain: long, flat coral formations with some low rounded hills
_#_Natural resources: salt, aragonite, timber
_#_Land use: arable land 1%; permanent crops NEGL%; meadows and
pastures NEGL%; forest and woodland 32%; other 67%
_#_Environment: subject to hurricanes and other tropical storms
that cause extensive flood damage
_#_Note: strategic location adjacent to US and Cuba; extensive island
chain
_#_Total area: 620 km2; land area: 620 km2
_#_Comparative area: slightly less than 3.5 times the size of
Washington, DC
_#_Land boundaries: none
_#_Coastline: 161 km
_#_Maritime claims:
Continental shelf: not specific;
Territorial sea: 3 nm
_#_Disputes: territorial dispute with Qatar over the Hawar Islands
_#_Climate: arid; mild, pleasant winters; very hot, humid summers
_#_Terrain: mostly low desert plain rising gently to low central
escarpment
_#_Natural resources: oil, associated and nonassociated natural gas,
fish
_#_Land use: arable land 2%; permanent crops 2%; meadows and pastures
6%; forest and woodland 0%; other 90%, includes irrigated NEGL%
_#_Environment: subsurface water sources being rapidly depleted
(requires development of desalination facilities); dust storms;
desertification
_#_Note: close to primary Middle Eastern crude oil sources;
strategic location in Persian Gulf through which much of Western
world''s crude oil must transit to reach open ocean
_#_Total area: 1.4 km2; land area: 1.4 km2
_#_Comparative area: about 2.3 times the size of The Mall in
Washington, DC
_#_Land boundaries: none
_#_Coastline: 4.8 km
_#_Maritime claims:
Contiguous zone: 12 nm;
Continental shelf: 200 m (depth);
Exclusive economic zone: 200 nm;
Territorial sea: 12 nm
_#_Climate: equatorial; scant rainfall, constant wind, burning sun
_#_Terrain: low, nearly level coral island surrounded by a narrow
fringing reef
_#_Natural resources: guano (deposits worked until 1891)
_#_Land use: arable land 0%; permanent crops 0%; meadows and pastures
0%; forest and woodland 0%; other 100%
_#_Environment: treeless, sparse and scattered vegetation consisting
of grasses, prostrate vines, and low growing shrubs; lacks fresh water;
primarily a nesting, roosting, and foraging habitat for seabirds,
shorebirds, and marine wildlife
_#_Note: remote location 2,575 km southwest of Honolulu in the North
Pacific Ocean, just north of the Equator, about halfway between Hawaii
and Australia
_#_Total area: 144,000 km2; land area: 133,910 km2
_#_Comparative area: slightly smaller than Wisconsin
_#_Land boundaries: 4,246 km total; Burma 193 km, India 4,053 km
_#_Coastline: 580 km
_#_Maritime claims:
Contiguous zone: 18 nm;
Continental shelf: up to outer limits of continental margin;
Exclusive economic zone: 200 nm;
Territorial sea: 12 nm
_#_Disputes: a portion of the boundary with India is in dispute;
water sharing problems with upstream riparian India over the Ganges
_#_Climate: tropical; cool, dry winter (October to March); hot, humid
summer (March to June); cool, rainy monsoon (June to October)
_#_Terrain: mostly flat alluvial plain; hilly in southeast
_#_Natural resources: natural gas, uranium, arable land, timber
_#_Land us','8c357532eae8fcc1ab975fb6eab36f9fe5a3bc579a2c739c6113f121e0d81d77','internet-archive','theciaworldfactb00025gut','txt','84185fe9df79da427349cc1598fd3f69814a2085a9fc1fe0508a3fae0a870f84','https://archive.org/download/theciaworldfactb00025gut/25.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('58a52e497a1749149821645bd838ca04662f922b38a1429826952587bc34cece',1991,'ZW','Zimbabwe','geography',14,'e: arable land 67%; permanent crops 2%; meadows and
pastures 4%; forest and woodland 16%; other 11%; includes irrigated
14%
_#_Environment: vulnerable to droughts; much of country routinely
flooded during summer monsoon season; overpopulation; deforestation
_#_Note: almost completely surrounded by India
_#_Total area: 430 km2; land area: 430 km2
_#_Comparative area: slightly less than 2.5 times the size of
Washington, DC
_#_Land boundaries: none
_#_Coastline: 97 km
_#_Maritime claims:
Exclusive economic zone: 200 nm;
Territorial sea: 12 nm
_#_Climate: tropical; rainy season (June to October)
_#_Terrain: relatively flat; rises gently to central highland region
_#_Natural resources: crude oil, fishing, natural gas
_#_Land use: arable land 77%; permanent crops 0%; meadows and
pastures 9%; forest and woodland 0%; other 14%
_#_Environment: subject to hurricanes (especially June to October)
_#_Note: easternmost Caribbean island
_#_Total area: undetermined
_#_Comparative area: undetermined
_#_Land boundaries: none
_#_Coastline: 35.2 km
_#_Maritime claims:
Contiguous zone: 12 nm;
Continental shelf: 200 m (depth) or to depth of exploitation;
Exclusive economic zone: 200 nm;
Territorial sea: 12 nm
_#_Disputes: claimed by Madagascar
_#_Climate: tropical
_#_Terrain: a volcanic rock 2.4 m high
_#_Natural resources: none
_#_Land use: arable land 0%; permanent crops 0%; meadows and
pastures 0%; forest and woodland 0%; other (rock) 100%
_#_Environment: surrounded by reefs; subject to periodic cyclones
_#_Note: navigational hazard since it is usually under water during
high tide; located in southern Mozambique Channel about halfway between
Africa and Madagascar
_#_Total area: 30,510 km2; land area: 30,230 km2
_#_Comparative area: slightly larger than Maryland
_#_Land boundaries: 1,385 km total; France 620 km, Germany 167 km,
Luxembourg 148 km, Netherlands 450 km
_#_Coastline: 64 km
_#_Maritime claims:
Continental shelf: not specific;
Exclusive fishing zone: equidistant line with neighbors (extends
about 68 km from coast);
Territorial sea: 12 nm
_#_Climate: temperate; mild winters, cool summers; rainy, humid,
cloudy
_#_Terrain: flat coastal plains in northwest, central rolling hills,
rugged mountains of Ardennes Forest in southeast
_#_Natural resources: coal, natural gas
_#_Land use: arable land 24%; permanent crops 1%; meadows and
pastures 20%; forest and woodland 21%; other 34%, includes irrigated
NEGL%
_#_Environment: air and water pollution
_#_Note: majority of West European capitals within 1,000 km of
Brussels; crossroads of Western Europe; Brussels is the seat of the EC
_#_Total area: 22,960 km2; land area: 22,800 km2
_#_Comparative area: slightly larger than Massachusetts
_#_Land boundaries: 516 km total; Guatemala 266 km, Mexico 250 km
_#_Coastline: 386 km
_#_Maritime claims:
Territorial sea: 3 nm
_#_Disputes: claimed by Guatemala, but boundary negotiations to
resolve dispute are nearing completion
_#_Climate: tropical; very hot and humid; rainy season (May to
February)
_#_Terrain: flat, swampy coastal plain; low mountains in south
_#_Natural resources: arable land potential, timber, fish
_#_Land use: arable land 2%; permanent crops NEGL%; meadows and
pastures 2%; forest and woodland 44%; other 52%, includes irrigated
NEGL%
_#_Environment: frequent devastating hurricanes (September to
December) and coastal flooding (especially in south); deforestation
_#_Note: national capital moved 80 km inland from Belize City to
Belmopan because of hurricanes; only country in Central America without a
coastline on the North Pacific Ocean
_#_Total area: 112,620 km2; land area: 110,620 km2
_#_Comparative area: slightly smaller than Pennsylvania
_#_Land boundaries: 1,989 km total; Burkina 306 km, Niger 266 km,
Nigeria 773 km, Togo 644 km
_#_Coastline: 121 km
_#_Maritime claims:
Territorial sea: 200 nm
_#_Climate: tropical; hot, humid in south; semiarid in north
_#_Terrain: mostly flat to undulating plain; some hills and low
mountains
_#_Natural resources: small offshore oil deposits, limestone,
marble, timber
_#_Land use: arable land 12%; permanent crops 4%; meadows and pastures
4%; forest and woodland 35%; other 45%, includes irrigated NEGL%
_#_Environment: hot, dry, dusty harmattan wind may affect north in
winter; deforestation; desertification
_#_Note: recent droughts have severely affected marginal
agriculture in north; no natural harbors
_#_Total area: 50 km2; land area: 50 km2
_#_Comparative area: about 0.3 times the size of Washington, DC
_#_Land boundaries: none
_#_Coastline: 103 km
_#_Maritime claims:
Exclusive fishing zone: 200 nm;
Territorial sea: 12 nm
_#_Climate: subtropical; mild, humid; gales, strong winds common in
winter
_#_Terrain: low hills separated by fertile depressions
_#_Natural resources: limestone, pleasant climate fostering tourism
_#_Land use: arable land 0%; permanent crops 0%; meadows and pastures
0%; forest and woodland 20%; other 80%
_#_Environment: ample rainfall, but no rivers or freshwater lakes;
consists of about 360 small coral islands
_#_Note: 1,050 km east of North Carolina; some reclaimed land
leased by US Government
_#_Total area: 47,000 km2; land area: 47,000 km2
_#_Comparative area: slightly more than half the size of Indiana
_#_Land boundaries: 1,075 km total; China 470 km, India 605 km
_#_Coastline: none--landlocked
_#_Maritime claims: none--landlocked
_#_Climate: varies; tropical in southern plains; cool winters and hot
summers in central valleys; severe winters and cool summers in Himalayas
_#_Terrain: mostly mountainous with some fertile valleys and savanna
_#_Natural resources: timber, hydropower, gypsum, calcium carbide,
tourism potential
_#_Land use: arable land 2%; permanent crops NEGL%; meadows and
pastures 5%; forest and woodland 70%; other 23%
_#_Environment: violent storms coming down from the Himalayas were the
source of the country name which translates as Land of the Thunder Dragon
_#_Note: landlocked; strategic location between China and India;
controls several key Himalayan mountain passes
_#_Total area: 1,098,580 km2; land area: 1,084,390 km2
_#_Comparative area: slightly less than three times the size of
Montana
_#_Land boundaries: 6,743 km total; Argentina 832 km, Brazil 3,400
km, Chile 861 km, Paraguay 750 km, Peru 900 km
_#_Coastline: none--landlocked
_#_Maritime claims: none--landlocked
_#_Disputes: has wanted a sovereign corridor to the South Pacific
Ocean since the Atacama area was lost to Chile in 1884; dispute with
Chile over Rio Lauca water rights
_#_Climate: varies with altitude; humid and tropical to cold and
semiarid
_#_Terrain: high plateau, hills, lowland plains
_#_Natural resources: tin, natural gas, crude oil, zinc, tungsten,
antimony, silver, iron ore, lead, gold, timber
_#_Land use: arable land 3%; permanent crops NEGL%; meadows and
pastures 25%; forest and woodland 52%; other 20%; includes irrigated
NEGL%
_#_Environment: cold, thin air of high plateau is obstacle to
efficient fuel combustion; overgrazing; soil erosion; desertification
_#_Note: landlocked; shares control of Lago Titicaca, world''s
highest navigable lake, with Peru
_#_Total area: 600,370 km2; land area: 585,370 km2
_#_Comparative area: slightly smaller than Texas
_#_Land boundaries: 4,013 km total; Namibia 1,360 km, South Africa
1,840 km, Zimbabwe 813 km
_#_Coastline: none--landlocked
_#_Maritime claims: none--landlocked
_#_Disputes: short section of the boundary with Namibia is indefinite;
quadripoint with Namibia, Zambia, and Zimbabwe is in disagreement
_#_Climate: semiarid; warm winters and hot summers
_#_Terrain: predominately flat to gently rolling tableland; Kalahari
Desert in southwest
_#_Natural resources: diamonds, copper, nickel, salt, soda ash,
potash, coal, iron ore, silver, natural gas
_#_Land use: arable land 2%; permanent crops 0%; meadows and pastures
75%; forest and woodland 2%; other 21%; includes irrigated NEGL%
_#_Environment: rains in early 1988 broke six years of drought that
had severely affected the important cattle industry; overgrazing;
desertification
_#_Note: landlocked
_#_Total area: 58 km2; land area: 58 km2
_#_Comparative area: about 0.3 times the size of Washington, DC
_#_Land boundaries: none
_#_Coastline: 29.6 km
_#_Maritime claims:
Territorial sea: 4 nm
_#_Climate: antarctic
_#_Terrain: volcanic; maximum elevation about 800 meters;
coast is mostly inacessible
_#_Natural resources: none
_#_Land use: arable land 0%; permanent crops 0%; meadows and pastures
0%; forest and woodland 0%; other 100% (ice)
_#_Environment: covered by glacial ice
_#_Note: located in the South Atlantic Ocean 2,575 km
south-southwest of the Cape of Good Hope, South Africa
_#_Total area: 8,511,965 km2; land area: 8,456,510 km2; includes
Arquipelago de Fernando de Noronha, Atol das Rocas, Ilha da Trindade,
Ilhas Martin Vaz, and Penedos de Sao Pedro e Sao Paulo
_#_Comparative area: slightly smaller than the US
_#_Land boundaries: 14,691 km total; Argentina 1,224 km, Bolivia
3,400 km, Colombia 1,643 km, French Guiana 673 km, Guyana 1,119 km,
Paraguay 1,290 km, Peru 1,560 km, Suriname 597 km, Uruguay 985 km,
Venezuela 2,200 km
_#_Coastline: 7,491 km
_#_Maritime claims:
Continental shelf: 200 m (depth) or to depth of exploitation;
Exclusive fishing zone: 200 nm;
Territorial sea: 200 nm
_#_Disputes: short section of the boundary with Paraguay (just west of
Guaira Falls on the Rio Parana) is in dispute; two short
sections of boundary with Uruguay are in dispute (Arroyo de la
Invernada area of the Rio Quarai and the islands at the confluence of
the Rio Quarai and the Uruguay); has noted possible Latin claims in','68ab21b0295282944a2ace6ef7d5be04b5f6c7125d7773a404cc78f095fc28f7','internet-archive','theciaworldfactb00025gut','txt','84185fe9df79da427349cc1598fd3f69814a2085a9fc1fe0508a3fae0a870f84','https://archive.org/download/theciaworldfactb00025gut/25.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a20d08b16ffb9e0605e11f63fdea4ec8a269c767a8a22ef1046d2b3435d0bd76',1991,'AQ','Antarctica','geography',25,'_#_Climate: mostly tropical, but temperate in south
_#_Terrain: mostly flat to rolling lowlands in north; some plains,
hills, mountains, and narrow coastal belt
_#_Natural resources: iron ore, manganese, bauxite, nickel, uranium,
phosphates, tin, hydropower, gold, platinum, crude oil, timber
_#_Land use: arable land 7%; permanent crops 1%; meadows and pastures
19%; forest and woodland 67%; other 6%; includes irrigated NEGL%
_#_Environment: recurrent droughts in northeast; floods and frost in
south; deforestation in Amazon basin; air and water pollution in Rio de
Janeiro and Sao Paulo
_#_Note: largest country in South America; shares common boundaries
with every South American country except Chile and Ecuador
_#_Total area: 60 km2; land area: 60 km2
_#_Comparative area: about 0.3 times the size of Washington, DC
_#_Land boundaries: none
_#_Coastline: 698 km
_#_Maritime claims:
Territorial sea: 3 nm
_#_Disputes: the entire Chagos Archipelago is claimed by Mauritius
_#_Climate: tropical marine; hot, humid, moderated by trade winds
_#_Terrain: flat and low (up to 4 meters in elevation)
_#_Natural resources: coconuts, fish
_#_Land use: arable land 0%; permanent crops 0%; meadows and pastures
0%; forest and woodland 0%; other 100%
_#_Environment: archipelago of 2,300 islands
_#_Note: Diego Garcia, largest and southernmost island, occupies
strategic location in central Indian Ocean
_#_Total area: 150 km2; land area: 150 km2
_#_Comparative area: about 0.8 times the size of Washington, DC
_#_Coastline: 80 km
_#_Maritime claims:
Exclusive fishing zone: 200 nm;
Territorial sea: 3 nm
_#_Climate: subtropical; humid; temperatures moderated by trade winds
_#_Terrain: coral islands relatively flat; volcanic islands steep,
hilly
_#_Natural resources: negligible
_#_Land use: arable land 20%; permanent crops 7%; meadows and pastures
33%; forest and woodland 7%; other 33%
_#_Environment: subject to hurricanes and tropical storms from July
to October
_#_Note: strong ties to nearby US Virgin Islands and Puerto Rico
_#_Total area: 5,770 km2; land area: 5,270 km2
_#_Comparative area: slightly larger than Delaware
_#_Land boundary: 381 km with Malaysia
_#_Coastline: 161 km
_#_Maritime claims:
Exclusive fishing zone: 200 nm;
Territorial sea: 12 nm
_#_Disputes: may wish to purchase the Malaysian salient that divides
the country
_#_Climate: tropical; hot, humid, rainy
_#_Terrain: flat coastal plain rises to mountains in east; hilly
lowland in west
_#_Natural resources: crude oil, natural gas, timber
_#_Land use: arable land 1%; permanent crops 1%; meadows and pastures
1%; forest and woodland 79%; other 18%; includes irrigated NEGL%
_#_Environment: typhoons, earthquakes, and severe flooding are rare
_#_Note: close to vital sea lanes through South China Sea linking
Indian and Pacific Oceans; two parts physically separated by Malaysia;
almost an enclave of Malaysia
_#_Total area: 110,910 km2; land area: 110,550 km2
_#_Comparative area: slightly larger than Tennessee
_#_Land boundaries: 1,881 km total; Greece 494 km, Romania 608 km,
Turkey 240 km, Yugoslavia 539 km
_#_Coastline: 354 km
_#_Maritime claims:
Contiguous zone: 24 nm;
Exclusive economic zone: 200 nm;
Territorial sea: 12 nm
_#_Disputes: Macedonia question with Greece and Yugoslavia
_#_Climate: temperate; cold, damp winters; hot, dry summers
_#_Terrain: mostly mountains with lowlands in north and south
_#_Natural resources: bauxite, copper, lead, zinc, coal, timber,
arable land
_#_Land use: arable land 34%; permanent crops 3%; meadows and pastures
18%; forest and woodland 35%; other 10%; includes irrigated 11%
_#_Environment: subject to earthquakes, landslides; deforestation;
air pollution
_#_Note: strategic location near Turkish Straits; controls key
land routes from Europe to Middle East and Asia
_#_Total area: 274,200 km2; land area: 273,800 km2
_#_Comparative area: slightly larger than Colorado
_#_Land boundaries: 3,192 km total; Benin 306 km, Ghana 548 km,
Ivory Coast 584 km, Mali 1,000 km, Niger 628 km, Togo 126 km
_#_Coastline: none--landlocked
_#_Maritime claims: none--landlocked
_#_Disputes: the disputed international boundary between Burkina and
Mali was submitted to the International Court of Justice (ICJ) in October
1983 and the ICJ issued its final ruling in December 1986, which both
sides agreed to accept; Burkina and Mali are proceeding with boundary
demarcation, including the tripoint with Niger
_#_Climate: tropical; warm, dry winters; hot, wet summers
_#_Terrain: mostly flat to dissected, undulating plains; hills in west
and southeast
_#_Natural resources: manganese, limestone, marble; small deposits
of gold, antimony, copper, nickel, bauxite, lead, phosphates, zinc,
silver
_#_Land use: arable land 10%; permanent crops NEGL%; meadows and
pastures 37%; forest and woodland 26%; other 27%, includes irrigated
NEGL%
_#_Environment: recent droughts and desertification severely affecting
marginal agricultural activities, population distribution, economy;
overgrazing; deforestation
_#_Note: landlocked
_#_Total area: 678,500 km2; land area: 657,740 km2
_#_Comparative area: slightly smaller than Texas
_#_Land boundaries: 5,876 km total; Bangladesh 193 km, China 2,185 km,
India 1,463 km, Laos 235 km, Thailand 1,800 km
_#_Coastline: 1,930 km
_#_Maritime claims:
Contiguous zone: 24 nm;
Continental shelf: edge of continental margin or 200 nm;
Exclusive economic zone: 200 nm;
Territorial sea: 12 nm
_#_Climate: tropical monsoon; cloudy, rainy, hot, humid summers
(southwest monsoon, June to September); less cloudy, scant rainfall, mild
temperatures, lower humidity during winter (northeast monsoon, December
to April)
_#_Terrain: central lowlands ringed by steep, rugged highlands
_#_Natural resources: crude oil, timber, tin, antimony, zinc, copper,
tungsten, lead, coal, some marble, limestone, precious stones, natural
gas
_#_Land use: arable land 15%; permanent crops 1%; meadows and pastures
1%; forest and woodland 49%; other 34%; includes irrigated 2%
_#_Environment: subject to destructive earthquakes and cyclones;
flooding and landslides common during rainy season (June to September);
deforestation
_#_Note: strategic location near major Indian Ocean shipping lanes
_#_Total area: 27,830 km2; land area: 25,650 km2
_#_Comparative area: slightly larger than Maryland
_#_Land boundaries: 974 km total; Rwanda 290 km, Tanzania 451 km,
Zaire 233 km
_#_Coastline: none--landlocked
_#_Maritime claims: none--landlocked
_#_Climate: temperate; warm; occasional frost in uplands
_#_Terrain: mostly rolling to hilly highland; some plains
_#_Natural resources: nickel, uranium, rare earth oxide, peat, cobalt,
copper, platinum (not yet exploited), vanadium
_#_Land use: arable land 43%; permanent crops 8%; meadows and pastures
35%; forest and woodland 2%; other 12%; includes irrigated NEGL%
_#_Environment: soil exhaustion; soil erosion; deforestation
_#_Note: landlocked; straddles crest of the Nile-Congo watershed
_#_Total area: 181,040 km2; land area: 176,520 km2
_#_Comparative area: slightly smaller than Oklahoma
_#_Land boundaries: 2,572 km total; Laos 541 km, Thailand 803 km,
Vietnam 1,228 km
_#_Coastline: 443 km
_#_Maritime claims:
Contiguous zone: 24 nm;
Continental shelf: 200 nm;
Exclusive economic zone: 200 nm;
Territorial sea: 12 nm
_#_Disputes: offshore islands and three sections of the
boundary with Vietnam are in dispute; maritime boundary with Vietnam
not defined; occupied by Vietnam on 25 December 1978
_#_Climate: tropical; rainy, monsoon season (May to October); dry
season (December to March); little seasonal temperature variation
_#_Terrain: mostly low, flat plains; mountains in southwest and north
_#_Natural resources: timber, gemstones, some iron ore, manganese,
phosphates, hydropower potential
_#_Land use: arable land 16%; permanent crops 1%; meadows and pastures
3%; forest and woodland 76%; other 4%; includes irrigated 1%
_#_Environment: a land of paddies and forests dominated by Mekong
River and Tonle Sap
_#_Note: buffer between Thailand and Vietnam
_#_Total area: 475,440 km2; land area: 469,440 km2
_#_Comparative area: slightly larger than California
_#_Land boundaries: 4,591 km total; Central African Republic 797 km,
Chad 1,094 km, Congo 523 km, Equatorial Guinea 189 km, Gabon 298 km,
Nigeria 1,690 km
_#_Coastline: 402 km
_#_Maritime claims:
Territorial sea: 50 nm
_#_Disputes: demarcation of international boundaries in Lake Chad,
the lack of which has led to border incidents in the past, is completed
and awaiting ratification by Cameroon, Chad, Niger, and Nigeria;
Nigerian proposals to reopen maritime boundary negotiations and
redemarcate the entire land boundary have been rejected by Cameroon
_#_Climate: varies with terrain from tropical along coast to semiarid
and hot in north
_#_Terrain: diverse with coastal plain in southwest, dissected plateau
in center, mountains in west, plains in north
_#_Natural resources: crude oil, bauxite, iron ore, timber,
hydropower potential
_#_Land use: arable land 13%; permanent crops 2%; meadows and pastures
18%; forest and woodland 54%; other 13%; includes irrigated NEGL%
_#_Environment: recent volcanic activity with release of poisonous
gases; deforestation; overgrazing; desertification
_#_Note: sometimes referred to as the hinge of Africa
_#_Total area: 9,976,140 km2; land area: 9,220,970 km2
_#_Comparative area: slightly larger than US
_#_Land boundaries: 8,893 km with US (includes 2,477 km with Alaska)
_#_Coastline: 243,791 km
_#_Maritime claims:
Continental shelf: 200 m (depth) or to depth of exploitation;
Exclusive fishing zone: 200 nm;
Territorial sea: 12 nm
_#_Disputes: maritime boundary disputes with France (Saint Pierre and
Miquelon) and US
_#_Climate: varies from temperate in south to subarctic and arctic in
north
_#_Terrain: mostly plains with mountains in west and lowlands in
southeast
_#_Natural resources: nickel, zinc, copper, gold, lead, molybdenum,
potash, silver, fish, timber, wildlife, coal, crude oil, natural gas
_#_Land use: arable land 5%; permanent crops NEGL%; meadows and
pastures 3%; forest and woodland 35%; other 57%; includes NEGL%
irrigated
_#_Environment: 80% of population concentrated within 160 km of US
border; continuous permafrost in north a serious obstacle to development
_#_Note: second-largest country in world (after USSR); strategic
location between USSR and US via north polar route
_#_Total area: 4,030 km2; land area: 4,030 km2
_#_Comparative area: slightly larger than Rhode Island
_#_Land boundaries: none
_#_Coastline: 965 km
_#_Maritime claims: (measured from claimed archipelagic baselines);
Exclusive economic zone: 200 nm;
Territorial sea: 12 nm
_#_Climate: temperate; warm, dry, summer precipitation very erratic
_#_Terrain: steep, rugged, rocky, volcanic
_#_Natural resources: salt, basalt rock, pozzolana, limestone, kaolin,
fish
_#_Land use: arable land 9%; permanent crops NEGL%; meadows and
pastures 6%; forest and woodland NEGL%; other 85%; includes irrigated
1%
_#_Environment: subject to prolonged droughts; harmattan wind can
obscure visibility; volcanically and seismically active; deforestation;
overgrazing
_#_Note: strategic location 500 km from African coast near major
north-south sea routes; important communications station; important sea
and air refueling site
_#_Total area: 260 km2; land area: 260 km2
_#_Comparative area: slightly less than 1.5 times the size of
Washington, DC
_#_Land boundaries: none
_#_Coastline: 160 km
_#_Maritime claims:
Exclusive fishing zone: 200 nm;
Territorial sea: 3 nm
_#_Climate: tropical marine; warm, rainy summers (May to October) and
cool, relatively dry winters (November to April)
_#_Terrain: low-lying limestone base surrounded by coral reefs
_#_Natural resources: fish, climate and beaches that foster tourism
_#_Land use: arable land 0%; permanent crops 0%; meadows and pastures
8%; forest and woodland 23%; other 69%
_#_Environment: within the Caribbean hurricane belt
_#_Note: important location between Cuba and Central America
_#_Total area: 622,980 km2; land area: 622,980 km2
_#_Comparative area: slightly smaller than Texas
_#_Land boundaries: 5,203 km total; Cameroon 797 km, Chad 1,197 km,
Congo 467 km, Sudan 1,165 km, Zaire 1,577 km
_#_Coastline: none--landlocked
_#_Maritime claims: none--landlocked
_#_Climate: tropical; hot, dry winters; mild to hot, wet summers
_#_Terrain: vast, flat to rolling, monotonous plateau; scattered hills
in northeast and southwest
_#_Natural resources: diamonds, uranium, timber, gold, oil
_#_Land use: arable land 3%; permanent crops NEGL%; meadows and
pastures 5%; forest and woodland 64%; other 28%
_#_Environment: hot, dry, dusty harmattan winds affect northern areas;
poaching has diminished reputation as one of last great wildlife refuges;
desertification
_#_Note: landlocked; almost the precise center of Africa
_#_Total area: 1,284,000 km2; land area: 1,259,200 km2
_#_Comparative area: slightly more than three times the size of
California
_#_Land boundaries: 5,968 km total; Cameroon 1,094 km, Central African
Republic 1,197 km, Libya 1,055 km, Niger 1,175 km, Nigeria 87 km, Sudan
1,360 km
_#_Coastline: none--landlocked
_#_Maritime claims: none--landlocked
_#_Disputes: Libya claims and occupies the 100,000 km2 Aozou
Strip in the far north; demarcation of international boundaries in
Lake Chad, the lack of which has led to border incidents in the past,
is completed and awaiting ratification by Cameroon, Chad, Niger, and','7f5a90635c762b27f68ceee46835e4d1bd54cc572fcfc5a550b40dd1e9c983e9','internet-archive','theciaworldfactb00025gut','txt','84185fe9df79da427349cc1598fd3f69814a2085a9fc1fe0508a3fae0a870f84','https://archive.org/download/theciaworldfactb00025gut/25.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ca0b38a39bb0f9b5f9947a835551f677245d7707708c622d8a7ac96dfc139437',1991,'NG','Nigeria','geography',32,'_#_Climate: tropical in south, desert in north
_#_Terrain: broad, arid plains in center, desert in north, mountains
in northwest, lowlands in south
_#_Natural resources: crude oil (unexploited but exploration
beginning), uranium, natron, kaolin, fish (Lake Chad)
_#_Land use: arable land 2%; permanent crops NEGL%; meadows and
pastures 36%; forest and woodland 11%; other 51%; includes irrigated
NEGL%
_#_Environment: hot, dry, dusty harmattan winds occur in north;
drought and desertification adversely affecting south; subject to plagues
of locusts
_#_Note: landlocked; Lake Chad is the most significant water body
in the Sahel
_#_Total area: 756,950 km2; land area: 748,800 km2; includes Isla de
Pascua (Easter Island) and Isla Sala y Gomez
_#_Comparative area: slightly smaller than twice the size of Montana
_#_Land boundaries: 6,171 km total; Argentina 5,150 km, Bolivia
861 km, Peru 160 km
_#_Coastline: 6,435 km
_#_Maritime claims:
Contiguous zone: 24 nm;
Continental shelf: 200 nm;
Exclusive economic zone: 200 nm;
Territorial sea: 12 nm
_#_Disputes: short section of the southern boundary with Argentina is
indefinite; Bolivia has wanted a sovereign corridor to the South
Pacific Ocean since the Atacama area was lost to Chile in 1884;
dispute with Bolivia over Rio Lauca water rights; territorial claim in
Antarctica (Chilean Antarctic Territory) partially overlaps Argentine
claim
_#_Climate: temperate; desert in north; cool and damp in south
_#_Terrain: low coastal mountains; fertile central valley; rugged
Andes in east
_#_Natural resources: copper, timber, iron ore, nitrates, precious
metals, molybdenum
_#_Land use: arable land 7%; permanent crops NEGL%; meadows and
pastures 16%; forest and woodland 21%; other 56%; includes irrigated
2%
_#_Environment: subject to severe earthquakes, active volcanism,
tsunami; Atacama Desert one of world''s driest regions; desertification
_#_Note: strategic location relative to sea lanes between
Atlantic and Pacific Oceans (Strait of Magellan, Beagle Channel, Drake
Passage)
_#_Total area: 9,596,960 km2; land area: 9,326,410 km2
_#_Comparative area: slightly larger than the US
_#_Land boundaries: 23,213.34 km total; Afghanistan 76 km, Bhutan
470 km, Burma 2,185 km, Hong Kong 30 km, India 3,380 km, North Korea
1,416 km, Laos 423 km, Macau 0.34 km, Mongolia 4,673 km, Nepal 1,236 km,
Pakistan 523 km, USSR 7,520 km, Vietnam 1,281 km
_#_Coastline: 14,500 km
_#_Maritime claims:
Continental shelf: claim to shallow areas of East China Sea
and Yellow Sea
Territorial sea: 12 nm
_#_Disputes: boundary with India; bilateral negotiations are under
way to resolve disputed sections of the boundary with the USSR; a short
section of the boundary with North Korea is indefinite; sporadic border
clashes with Vietnam; involved in a complex dispute over the Spratly
Islands with Malaysia, Philippines, Taiwan, and Vietnam; maritime
boundary dispute with Vietnam in the Gulf of Tonkin; Paracel Islands
occupied by China, but claimed by Vietnam and Taiwan; claims
Japanese-administered Senkaku-shoto (Senkaku Islands)
_#_Climate: extremely diverse; tropical in south to subarctic in north
_#_Terrain: mostly mountains, high plateaus, deserts in west; plains,
deltas, and hills in east
_#_Natural resources: coal, iron ore, crude oil, mercury, tin,
tungsten, antimony, manganese, molybdenum, vanadium, magnetite, aluminum,
lead, zinc, uranium, world''s largest hydropower potential
_#_Land use: arable land 10%; permanent crops NEGL%; meadows and
pastures 31%; forest and woodland 14%; other 45%; includes irrigated 5%
_#_Environment: frequent typhoons (about five times per year along
southern and eastern coasts), damaging floods, tsunamis, earthquakes;
deforestation; soil erosion; industrial pollution; water pollution;
air pollution; desertification
_#_Note: world''s third-largest country (after USSR and Canada)
_#_Total area: 135 km2; land area: 135 km2
_#_Comparative area: about 0.8 times the size of Washington, DC
_#_Land boundaries: none
_#_Coastline: 138.9 km
_#_Maritime claims:
Contiguous zone: 12 nm;
Exclusive fishing zone: 200 nm;
Territorial sea: 3 nm
_#_Climate: tropical; heat and humidity moderated by trade winds
_#_Terrain: steep cliffs along coast rise abruptly to central plateau
_#_Natural resources: phosphate
_#_Land use: arable land 0%; permanent crops 0%; meadows and pastures
0%; forest and woodland 0%; other 100%
_#_Environment: almost completely surrounded by a reef
_#_Note: located along major sea lanes of Indian Ocean','b0712cb8aee150d53035d5cc60284deff1490711530c817902b45eb1cd2efcb2','internet-archive','theciaworldfactb00025gut','txt','84185fe9df79da427349cc1598fd3f69814a2085a9fc1fe0508a3fae0a870f84','https://archive.org/download/theciaworldfactb00025gut/25.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('31b3323fcfab522dcaa279971741502cdc77a26ced2cc1d9e10a7b34200f2873',1991,'AU','Australia','geography',40,'_#_Total area: 7 km2
_#_Comparative area: about 12 times the size of The Mall in
Washington, DC
_#_Land boundaries: none
_#_Coastline: 11.1 km
_#_Maritime claims:
Exclusive economic zone: 200 nm;
Territorial sea: 12 nm
_#_Disputes: claimed by Mexico
_#_Climate: tropical
_#_Terrain: coral atoll
_#_Natural resources: none
_#_Land use: arable land 0%; permanent crops 0%; meadows and pastures
0%; forest and woodland 0%; other (coral) 100%
_#_Environment: reef about 8 km in circumference
_#_Note: located 1,120 km southwest of Mexico in the North Pacific
Ocean; also called Ile de la Passion
_#_Total area: 14 km2; land area: 14 km2; main islands are West Island
and Home Island
_#_Comparative area: about 24 times the size of The Mall in
Washington, DC
_#_Land boundaries: none
_#_Coastline: 42.6 km
_#_Maritime claims:
Exclusive fishing zone: 200 nm;
Territorial sea: 3 nm
_#_Climate: pleasant, modified by the southeast trade winds for about
nine months of the year; moderate rainfall
_#_Terrain: flat, low-lying coral atolls
_#_Natural resources: fish
_#_Land use: arable land 0%; permanent crops 0%; meadows and pastures
0%; forest and woodland 0%; other 100%
_#_Environment: two coral atolls thickly covered with coconut palms
and other vegetation
_#_Note: located 1,070 km southwest of Sumatra (Indonesia) in the
Indian Ocean about halfway between Australia and Sri Lanka
_#_Total area: 1,138,910 km2; land area: 1,038,700 km2; includes Isla
de Malpelo, Roncador Cay, Serrana Bank, and Serranilla Bank
_#_Comparative area: slightly less than three times the size of
Montana
_#_Land boundaries: 7,408 km total; Brazil 1,643 km, Ecuador 590 km,
Panama 225 km, Peru 2,900, Venezuela 2,050 km
_#_Coastline: 3,208 km total (1,448 km North Pacific Ocean;
1,760 Caribbean Sea)
_#_Maritime claims:
Continental shelf: not specified;
Exclusive economic zone: 200 nm;
Territorial sea: 12 nm
_#_Disputes: maritime boundary dispute with Venezuela in the
Gulf of Venezuela; territorial dispute with Nicaragua over Archipelago
de San Andres y Providencia and Quita Sueno Bank
_#_Climate: tropical along coast and eastern plains; cooler in
highlands
_#_Terrain: mixture of flat coastal lowlands, plains in east, central
highlands, some high mountains
_#_Natural resources: crude oil, natural gas, coal, iron ore, nickel,
gold, copper, emeralds
_#_Land use: arable land 4%; permanent crops 2%; meadows and pastures
29%; forest and woodland 49%; other 16%; includes irrigated NEGL%
_#_Environment: highlands subject to volcanic eruptions;
deforestation; soil damage from overuse of pesticides; periodic droughts
_#_Note: only South American country with coastlines on both
North Pacific Ocean and Caribbean Sea
_#_Total area: 2,170 km2; land area: 2,170 km2
_#_Comparative area: slightly more than 12 times the size of
Washington, DC
_#_Land boundaries: none
_#_Coastline: 340 km
_#_Maritime claims:
Exclusive economic zone: 200 nm;
Territorial sea: 12 nm
_#_Disputes: claims French-administered Mayotte
_#_Climate: tropical marine; rainy season (November to May)
_#_Terrain: volcanic islands, interiors vary from steep mountains
to low hills
_#_Natural resources: negligible
_#_Land use: arable land 35%; permanent crops 8%; meadows and
pastures 7%; forest and woodland 16%; other 34%
_#_Environment: soil degradation and erosion; deforestation;
cyclones possible during rainy season
_#_Note: important location at northern end of Mozambique Channel
_#_Total area: 342,000 km2; land area: 341,500 km2
_#_Comparative area: slightly smaller than Montana
_#_Land boundaries: 5,504 km total; Angola 201 km, Cameroon 523 km,
Central African Republic 467 km, Gabon 1,903 km, Zaire 2,410 km
_#_Coastline: 169 km
_#_Maritime claims:
Territorial sea: 200 nm
_#_Disputes: long section with Zaire along the Congo River is
indefinite (no division of the river or its islands has been made)
_#_Climate: tropical; rainy season (March to June); dry season (June
to October); constantly high temperatures and humidity; particularly
enervating climate astride the Equator
_#_Terrain: coastal plain, southern basin, central plateau, northern
basin
_#_Natural resources: petroleum, timber, potash, lead, zinc, uranium,
copper, phosphates, natural gas
_#_Land use: arable land 2%; permanent crops NEGL%; meadows and
pastures 29%; forest and woodland 62%; other 7%
_#_Environment: deforestation; about 70% of the population lives in
Brazzaville, Pointe Noire, or along the railroad between them','0cb45e199631280380ce5479137acf428143c011303183916c432618e6fd90e4','internet-archive','theciaworldfactb00025gut','txt','84185fe9df79da427349cc1598fd3f69814a2085a9fc1fe0508a3fae0a870f84','https://archive.org/download/theciaworldfactb00025gut/25.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('db30b255526c0f137ceb50c46a3dc47784daefb5a16f297fed1befe100660bbf',1991,'ET','Ethiopia','geography',43,'_#_Total area: 240 km2; land area: 240 km2
_#_Comparative area: slightly less than 1.3 times the size of
Washington, DC
_#_Land boundaries: none
_#_Coastline: 120 km
_#_Maritime claims:
Continental shelf: edge of continental margin or minimum of 200
nm;
Exclusive economic zone: 200 nm;
Territorial sea: 12 nm
_#_Climate: tropical; moderated by trade winds
_#_Terrain: low coral atolls in north; volcanic, hilly islands in
south
_#_Natural resources: negligible
_#_Land use: arable land 4%; permanent crops 22%; meadows and pastures
0%; forest and woodland 0%; other 74%
_#_Environment: subject to typhoons from November to March
_#_Note: located 4,500 km south of Hawaii in the South Pacific Ocean
_#_Total area: undetermined; includes numerous small islands and reefs
scattered over a sea area of about 1 million km2, with Willis Islets the
most important
_#_Comparative area: undetermined
_#_Land boundaries: none
_#_Coastline: 3,095 km
_#_Maritime claims:
Exclusive fishing zone: 200 nm;
Territorial sea: 3 nm
_#_Climate: tropical
_#_Terrain: sand and coral reefs and islands (or cays)
_#_Natural resources: negligible
_#_Land use: arable land 0%; permanent crops 0%; meadows and pastures
0%; forest and woodland 0%; other, mostly grass or scrub cover 100%;
Lihou Reef Reserve and Coringa-Herald Reserve were declared National
Nature Reserves on 3 August 1982
_#_Environment: subject to occasional tropical cyclones; no permanent
fresh water; important nesting area for birds and turtles
_#_Note: the islands are located just off the northeast coast of
Australia in the Coral Sea
_#_Total area: 51,100 km2; land area: 50,660 km2; includes Isla del
Coco
_#_Comparative area: slightly smaller than West Virginia
_#_Land boundaries: 639 km total; Nicaragua 309 km, Panama 330 km
_#_Coastline: 1,290 km
_#_Maritime claims:
Continental shelf: 200 nm;
Exclusive economic zone: 200 nm;
Territorial sea: 12 nm
_#_Climate: tropical; dry season (December to April); rainy season
(May to November)
_#_Terrain: coastal plains separated by rugged mountains
_#_Natural resources: hydropower potential
_#_Land use: arable land 6%; permanent crops 7%; meadows and pastures
45%; forest and woodland 34%; other 8%; includes irrigated 1%
_#_Environment: subject to occasional earthquakes, hurricanes along
Atlantic coast; frequent flooding of lowlands at onset of rainy season;
active volcanoes; deforestation; soil erosion
_#_Total area: 110,860 km2; land area: 110,860 km2
_#_Comparative area: slightly smaller than Pennsylvania
_#_Land boundary: 29.1 km with US Naval Base at Guantanamo;
note--Guantanamo is leased and as such remains part of Cuba
_#_Coastline: 3,735 km
_#_Maritime claims:
Exclusive economic zone: 200 nm;
Territorial sea: 12 nm
_#_Disputes: US Naval Base at Guantanamo is leased to US and only
mutual agreement or US abandonment of the area can terminate the lease
_#_Climate: tropical; moderated by trade winds; dry season (November
to April); rainy season (May to October)
_#_Terrain: mostly flat to rolling plains with rugged hills and
mountains in the southeast
_#_Natural resources: cobalt, nickel, iron ore, copper, manganese,
salt, timber, silica
_#_Land use: arable land 23%; permanent crops 6%; meadows and pastures
23%; forest and woodland 17%; other 31%; includes irrigated 10%
_#_Environment: averages one hurricane every other year
_#_Note: largest country in Caribbean; 145 km south of Florida
_#_Total area: 9,250 km2; land area: 9,240 km2
_#_Comparative area: about 0.7 times the size of Connecticut
_#_Land boundaries: none
_#_Coastline: 648 km
_#_Maritime claims:
Continental shelf: 200 m (depth) or to depth of exploitation;
Territorial sea: 12 nm
_#_Disputes: 1974 hostilities divided the island into two de facto
autonomous areas--a Greek area controlled by the Cypriot Government (60%
of the island''s land area) and a Turkish-Cypriot area (35% of the island)
that are separated by a narrow UN buffer zone; in addition, there are two
UK sovereign base areas (about 5% of the island''s land area)
_#_Climate: temperate, Mediterranean with hot, dry summers and cool,
wet winters
_#_Terrain: central plain with mountains to north and south
_#_Natural resources: copper, pyrites, asbestos, gypsum, timber, salt,
marble, clay earth pigment
_#_Land use: arable land 40%; permanent crops 7%; meadows and pastures
10%; forest and woodland 18%; other 25%; includes irrigated 10% (most
irrigated lands are in the Turkish-Cypriot area of the island)
_#_Environment: moderate earthquake activity; water resource problems
(no natural reservoir catchments, seasonal disparity in rainfall, and
most potable resources concentrated in the Turkish-Cypriot area)
_#_Total area: 127,870 km2; land area: 125,460 km2
_#_Comparative area: slightly larger than New York State
_#_Land boundaries: 3,446 km total; Austria 548 km, Germany 815 km,
Hungary 676 km, Poland 1,309 km, USSR 98 km
_#_Coastline: none--landlocked
_#_Maritime claims: none--landlocked
_#_Disputes: Nagymaros Dam dispute with Hungary
_#_Climate: temperate; cool summers; cold, cloudy, humid winters
_#_Terrain: mixture of hills and mountains separated by plains and
basins
_#_Natural resources: coal, timber, lignite, uranium, magnesite,
iron ore, copper, zinc
_#_Land use: arable land 40%; permanent crops 1%; meadows and pastures
13%; forest and woodland 37%; other 9%; includes irrigated 1%
_#_Environment: infrequent earthquakes; acid rain; water pollution;
air pollution
_#_Note: landlocked; strategically located astride some of oldest
and most significant land routes in Europe; Moravian Gate is a
traditional military corridor between the North European Plain and the
Danube in central Europe
_#_Total area: 43,070 km2; land area: 42,370 km2; includes the island
of Bornholm in the Baltic Sea and the rest of metropolitan Denmark, but
excludes the Faroe Islands and Greenland
_#_Comparative area: slightly more than twice the size of
Massachusetts
_#_Land boundaries: 68 km with Germany
_#_Coastline: 3,379 km
_#_Maritime claims:
Contiguous zone: 4 nm;
Continental shelf: 200 m (depth) or to depth of exploitation;
Exclusive fishing zone: 200 nm;
Territorial sea: 3 nm
_#_Disputes: Rockall continental shelf dispute involving Iceland,
Ireland, and the UK (Ireland and the UK have signed a boundary agreement
in the Rockall area); Denmark has challenged Norway''s maritime claims
between Greenland and Jan Mayen
_#_Climate: temperate; humid and overcast; mild, windy winters and
cool summers
_#_Terrain: low and flat to gently rolling plains
_#_Natural resources: crude oil, natural gas, fish, salt, limestone
_#_Land use: arable land 61%; permanent crops NEGL%; meadows and
pastures 6%; forest and woodland 12%; other 21%; includes irrigated 9%
_#_Environment: air and water pollution
_#_Note: controls Danish Straits linking Baltic and North Seas','f0168124257bda8ae4ea97849d707f7712ca4e3048754a254a69230fd4b1b46a','internet-archive','theciaworldfactb00025gut','txt','84185fe9df79da427349cc1598fd3f69814a2085a9fc1fe0508a3fae0a870f84','https://archive.org/download/theciaworldfactb00025gut/25.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bb16a308c38978f40f72a2f94955a834ee2cec1fa94cbe4798e8827e305825eb',1991,'SE','Sweden','geography',48,'_#_Total area: 22,000 km2; land area: 21,980 km2
_#_Comparative area: slightly larger than Massachusetts
_#_Land boundaries: 517 km total; Ethiopia 459 km, Somalia 58 km
_#_Coastline: 314 km
_#_Maritime claims:
Contiguous zone: 24 nm;
Exclusive economic zone: 200 nm;
Territorial sea: 12 nm
_#_Disputes: possible claim by Somalia based on unification of ethnic
Somalis
_#_Climate: desert; torrid, dry
_#_Terrain: coastal plain and plateau separated by central mountains
_#_Natural resources: geothermal areas
_#_Land use: arable land 0%; permanent crops 0%; meadows and pastures
9%; forest and woodland NEGL%; other 91%
_#_Environment: vast wasteland
_#_Note: strategic location near world''s busiest shipping lanes
and close to Arabian oilfields; terminus of rail traffic into Ethiopia
_#_Total area: 750 km2; land area: 750 km2
_#_Comparative area: slightly more than four times the size of
Washington, DC
_#_Land boundaries: none
_#_Coastline: 148 km
_#_Maritime claims:
Contiguous zone: 24 nm;
Exclusive economic zone: 200 nm;
Territorial sea: 12 nm
_#_Climate: tropical; moderated by northeast trade winds; heavy
rainfall
_#_Terrain: rugged mountains of volcanic origin
_#_Natural resources: timber
_#_Land use: arable land 9%; permanent crops 13%; meadows and pastures
3%; forest and woodland 41%; other 34%
_#_Environment: flash floods a constant hazard; occasional hurricanes
_#_Note: located 550 km southeast of Puerto Rico in the Caribbean Sea
_#_Total area: 48,730 km2; land area: 48,380 km2
_#_Comparative area: slightly more than twice the size of New
Hampshire
_#_Land boundary 275 km with Haiti
_#_Coastline: 1,288 km
_#_Maritime claims:
Contiguous zone: 24 nm;
Continental shelf: outer edge of continental margin or 200 nm;
Exclusive economic zone: 200 nm;
Territorial sea: 6 nm
_#_Climate: tropical maritime; little seasonal temperature variation
_#_Terrain: rugged highlands and mountains with fertile valleys
interspersed
_#_Natural resources: nickel, bauxite, gold, silver
_#_Land use: arable land 23%; permanent crops 7%; meadows and pastures
43%; forest and woodland 13%; other 14%; includes irrigated 4%
_#_Environment: subject to occasional hurricanes (July to October);
deforestation
_#_Note: shares island of Hispaniola with Haiti (western one-third is
Haiti, eastern two-thirds is the Dominican Republic)
_#_Total area: 283,560 km2; land area: 276,840 km2; includes
Galapagos Islands
_#_Comparative area: slightly smaller than Nevada
_#_Land boundaries: 2,010 km total; Colombia 590 km, Peru 1,420 km
_#_Coastline: 2,237 km
_#_Maritime claims:
Continental shelf: claims continental shelf between mainland and
Galapagos Islands;
Territorial sea: 200 nm
_#_Disputes: two sections of the boundary with Peru are in dispute
_#_Climate: tropical along coast becoming cooler inland
_#_Terrain: coastal plain (Costa), inter-Andean central highlands
(Sierra), and flat to rolling eastern jungle (Oriente)
_#_Natural resources: petroleum, fish, timber
_#_Land use: arable land 6%; permanent crops 3%; meadows and pastures
17%; forest and woodland 51%; other 23% ; includes irrigated 2%
_#_Environment: subject to frequent earthquakes, landslides, volcanic
activity; deforestation; desertification; soil erosion; periodic droughts
_#_Note: Cotopaxi in Andes is highest active volcano in world','e185af9daff990ae9e30ac729792e537d8fe4e9a7a3dfd071ff2f29568193c71','internet-archive','theciaworldfactb00025gut','txt','84185fe9df79da427349cc1598fd3f69814a2085a9fc1fe0508a3fae0a870f84','https://archive.org/download/theciaworldfactb00025gut/25.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5324208e1124a2b0be5247fbc7b68a60507cb978f435b4e2779a35ed2ed656dc',1991,'PE','Peru','geography',53,'_#_Total area: 1,001,450 km2; land area: 995,450 km2
_#_Comparative area: slightly more than three times the size of New','2a68bf781acd8334b5ead770a0998fc2a8f05fb2779d7cc4faf0d5bb05641ab8','internet-archive','theciaworldfactb00025gut','txt','84185fe9df79da427349cc1598fd3f69814a2085a9fc1fe0508a3fae0a870f84','https://archive.org/download/theciaworldfactb00025gut/25.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5a4573956202e1f18e0d3605f21107a63a08809c1b851940e2981b7629a30273',1991,'MX','Mexico','geography',54,'_#_Land boundaries: 2,689 km total; Gaza Strip 11 km, Israel 255 km,
Libya 1,150 km, Sudan 1,273 km
_#_Coastline: 2,450 km
_#_Maritime claims:
Contiguous zone: 24 nm;
Continental shelf: 200 m (depth) or to depth of exploitation;
Exclusive economic zone: undefined;
Territorial sea: 12 nm
_#_Disputes: Administrative boundary with Sudan does not coincide
with international boundary
_#_Climate: desert; hot, dry summers with moderate winters
_#_Terrain: vast desert plateau interrupted by Nile valley and delta
_#_Natural resources: crude oil, natural gas, iron ore, phosphates,
manganese, limestone, gypsum, talc, asbestos, lead, zinc
_#_Land use: arable land 3%; permanent crops 2%; meadows and pastures
0%; forest and woodland NEGL%; other 95%; includes irrigated 5%
_#_Environment: Nile is only perennial water source; increasing soil
salinization below Aswan High Dam; hot, driving windstorm called khamsin
occurs in spring; water pollution; desertification
_#_Note: controls Sinai Peninsula, only land bridge between Africa
and remainder of Eastern Hemisphere; controls Suez Canal, shortest sea
link between Indian Ocean and Mediterranean; size and juxtaposition to
Israel establish its major role in Middle Eastern geopolitics
_#_Total area: 21,040 km2; land area: 20,720 km2
_#_Comparative area: slightly smaller than Massachusetts
_#_Land boundaries: 545 km total; Guatemala 203 km, Honduras 342 km
_#_Coastline: 307 km
_#_Maritime claims:
Territorial sea: 200 nm (overflight and navigation permitted beyond
12 nm)
_#_Disputes: dispute with Honduras over several sections of the land
boundary; dispute over Golfo de Fonseca maritime boundary because of
disputed sovereignty of islands
_#_Climate: tropical; rainy season (May to October); dry season
(November to April)
_#_Terrain: mostly mountains with narrow coastal belt and central
plateau
_#_Natural resources: hydropower, geothermal power, crude oil
_#_Land use: arable land 27%; permanent crops 8%; meadows and pastures
29%; forest and woodland 6%; other 30%; includes irrigated 5%
_#_Environment: The Land of Volcanoes; subject to frequent and
sometimes very destructive earthquakes; deforestation; soil erosion;
water pollution
_#_Note: smallest Central American country and only one without a
coastline on Caribbean Sea
_#_Total area: 28,050 km2; land area: 28,050 km2
_#_Comparative area: slightly larger than Maryland
_#_Land boundaries: 539 km total; Cameroon 189 km, Gabon 350 km
_#_Coastline: 296 km
_#_Maritime claims:
Exclusive economic zone: 200 nm;
Territorial sea: 12 nm
_#_Disputes: maritime boundary dispute with Gabon because of
disputed sovereignty over islands in Corisco Bay
_#_Climate: tropical; always hot, humid
_#_Terrain: coastal plains rise to interior hills; islands are
volcanic
_#_Natural resources: timber, crude oil, small unexploited deposits
of gold, manganese, uranium
_#_Land use: arable land 8%; permanent crops 4%; meadows and pastures
4%; forest and woodland 51%; other 33%
_#_Environment: subject to violent windstorms
_#_Note: insular and continental regions rather widely separated
_#_Total area: 1,221,900 km2; land area: 1,101,000 km2
_#_Comparative area: slightly less than twice the size of Texas
_#_Land boundaries: 5,141 km total; Djibouti 459 km, Kenya 861 km,
Somalia 1,600 km, Sudan 2,221 km
_#_Coastline: 1,094 km
_#_Maritime claims:
Territorial sea: 12 nm
_#_Disputes: southern half of the boundary with Somalia is a
Provisional Administrative Line; possible claim by Somalia based on
unification of ethnic Somalis; territorial dispute with Somalia over
the Ogaden; separatist movement in Eritrea; antigovernment insurgencies
in Tigray and other areas
_#_Climate: tropical monsoon with wide topographic-induced variation;
some areas prone to extended droughts
_#_Terrain: high plateau with central mountain range divided by Great
Rift Valley
_#_Natural resources: small reserves of gold, platinum, copper, potash
_#_Land use: arable land 12%; permanent crops 1%; meadows and pastures
41%; forest and woodland 24%; other 22%; includes irrigated NEGL%
_#_Environment: geologically active Great Rift Valley susceptible to
earthquakes, volcanic eruptions; deforestation; overgrazing; soil
erosion; desertification; frequent droughts; famine
_#_Note: strategic geopolitical position along world''s busiest
shipping lanes and close to Arabian oilfields; major resettlement
project--that was ongoing in rural areas and would have significantly
altered population distribution and settlement patterns over the next
several decades--has been derailed because of ongoing civil wars','84e0bec9d33e4a974f0fb5072a31176616defcf7109f734ba677b32ebbd5f109','internet-archive','theciaworldfactb00025gut','txt','84185fe9df79da427349cc1598fd3f69814a2085a9fc1fe0508a3fae0a870f84','https://archive.org/download/theciaworldfactb00025gut/25.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('686d0e22ba28b9cdae6d3aeaf322e64f94c671f396de60a19d686fa5df7f6571',1991,'SA','Saudi Arabia','geography',64,'_#_Total area: 28 km2; land area: 28 km2
_#_Comparative area: about 0.2 times the size of Washington, DC
_#_Land boundaries: none
_#_Coastline: 22.2 km
_#_Maritime claims:
Exclusive economic zone: 200 nm;
Territorial sea: 12 nm
_#_Disputes: claimed by Madagascar
_#_Climate: tropical
_#_Terrain: NA
_#_Natural resources: negligible
_#_Land use: arable land NA%; permanent crops NA%; meadows and
pastures NA%; forest and woodland NA%; other NA%; heavily wooded
_#_Environment: wildlife sanctuary
_#_Note: located in the Mozambique Channel 340 km west of Madagascar
_#_Total area: 12,170 km2; land area: 12,170 km2; includes the two
main islands of East and West Falkland and about 200 small islands
_#_Comparative area: slightly smaller than Connecticut
_#_Land boundaries: none
_#_Coastline: 1,288 km
_#_Maritime claims:
Continental shelf: 100 meter depth;
Exclusive fishing zone: 150 nm;
Territorial sea: 12 nm
_#_Disputes: administered by the UK, claimed by Argentina
_#_Climate: cold marine; strong westerly winds, cloudy, humid; rain
occurs on more than half of days in year; occasional snow all year,
except in January and February, but does not accumulate
_#_Terrain: rocky, hilly, mountainous with some boggy, undulating
plains
_#_Natural resources: fish and wildlife
_#_Land use: arable land 0%; permanent crops 0%; meadows and
pastures 99%; forest and woodland 0%; other 1%
_#_Environment: poor soil fertility and a short growing season
_#_Note: deeply indented coast provides good natural harbors
_#_Total area: 1,400 km2; land area: 1,400 km2
_#_Comparative area: slightly less than eight times the size of
Washington, DC
_#_Land boundaries: none
_#_Coastline: 764 km
_#_Maritime claims:
Exclusive fishing zone: 200 nm;
Territorial sea: 3 nm
_#_Climate: mild winters, cool summers; usually overcast; foggy, windy
_#_Terrain: rugged, rocky, some low peaks; cliffs along most of coast
_#_Natural resources: fish
_#_Land use: arable land 2%; permanent crops 0%; meadows and pastures
0%; forest and woodland 0%; other 98%
_#_Environment: precipitous terrain limits habitation to small coastal
lowlands; archipelago of 18 inhabited islands and a few uninhabited
islets
_#_Note: strategically located along important sea lanes in
northeastern Atlantic about midway between Iceland and Shetland Islands
_#_Total area: 18,270 km2; land area: 18,270 km2
_#_Comparative area: slightly smaller than New Jersey
_#_Land boundaries: none
_#_Coastline: 1,129 km
_#_Maritime claims: (measured from claimed archipelagic baselines)
Continental shelf: 200 m (depth) or to depth of exploitation;
rectilinear shelf claim added;
Exclusive economic zone: 200 nm;
Territorial sea: 12 nm
_#_Climate: tropical marine; only slight seasonal temperature
variation
_#_Terrain: mostly mountains of volcanic origin
_#_Natural resources: timber, fish, gold, copper; offshore oil
potential
_#_Land use: arable land 8%; permanent crops 5%; meadows and pastures
3%; forest and woodland 65%; other 19%; includes irrigated NEGL%
_#_Environment: subject to hurricanes from November to January;
includes 332 islands of which approximately 110 are inhabited
_#_Note: located 2,500 km north of New Zealand in the South Pacific
Ocean
_#_Total area: 337,030 km2; land area: 305,470 km2
_#_Comparative area: slightly smaller than Montana
_#_Land boundaries: 2,628 km total; Norway 729 km, Sweden 586 km,
USSR 1,313 km
_#_Coastline: 1,126 km excluding islands and coastal indentations
_#_Maritime claims:
Contiguous zone: 6 nm;
Continental shelf: 200 m (depth) or to depth of exploitation;
Exclusive fishing zone: 12 nm;
Territorial sea: 4 nm
_#_Climate: cold temperate; potentially subarctic, but comparatively
mild because of moderating influence of the North Atlantic Current,
Baltic Sea, and more than 60,000 lakes
_#_Terrain: mostly low, flat to rolling plains interspersed with lakes
and low hills
_#_Natural resources: timber, copper, zinc, iron ore, silver
_#_Land use: arable land 8%; permanent crops 0%; meadows and pastures
NEGL%; forest and woodland 76%; other 16%; includes irrigated NEGL%
_#_Environment: permanently wet ground covers about 30% of land;
population concentrated on small southwestern coastal plain
_#_Note: long boundary with USSR; Helsinki is northernmost national
capital on European continent
_#_Total area: 547,030 km2; land area: 545,630 km2; includes Corsica
and the rest of metropolitan France, but excludes the overseas
administrative divisions
_#_Comparative area: slightly more than twice the size of Colorado
_#_Land boundaries: 2,892.4 km total; Andorra 60 km, Belgium 620 km,
Germany 451 km, Italy 488 km, Luxembourg 73 km, Monaco 4.4 km,
Spain 623 km, Switzerland 573 km
_#_Coastline: 3,427 km (includes Corsica, 644 km)
_#_Maritime claims:
Contiguous zone: 12-24 nm;
Exclusive economic zone: 200 nm;
Territorial sea: 12 nm
_#_Disputes: maritime boundary dispute with Canada (Saint Pierre and
Miquelon); Madagascar claims Bassas da India, Europa Island, Glorioso
Islands, Juan de Nova Island, and Tromelin Island; Comoros claims
Mayotte; Mauritius claims Tromelin Island; Seychelles claims Tromelin
Island; Suriname claims part of French Guiana; Mexico claims Clipperton
Island; territorial claim in Antarctica (Adelie Land)
_#_Climate: generally cool winters and mild summers, but mild winters
and hot summers along the Mediterranean
_#_Terrain: mostly flat plains or gently rolling hills in north and
west; remainder is mountainous, especially Pyrenees in south, Alps in
east
_#_Natural resources: coal, iron ore, bauxite, fish, timber, zinc,
potash
_#_Land use: arable land 32%; permanent crops 2%; meadows and pastures
23%; forest and woodland 27%; other 16%; includes irrigated 2%
_#_Environment: most of large urban areas and industrial centers in
Rhone, Garonne, Seine, or Loire River basins; occasional warm tropical
wind known as mistral
_#_Note: largest West European nation
_#_Total area: 91,000 km2; land area: 89,150 km2
_#_Comparative area: slightly smaller than Indiana
_#_Land boundaries: 1,183 km total; Brazil 673 km, Suriname 510 km
_#_Coastline: 378 km
_#_Maritime claims:
Exclusive economic zone: 200 nm;
Territorial sea: 12 nm
_#_Disputes: Suriname claims area between Riviere Litani and
Riviere Marouini (both headwaters of the Lawa)
_#_Climate: tropical; hot, humid; little seasonal temperature
variation
_#_Terrain: low-lying coastal plains rising to hills and small
mountains
_#_Natural resources: bauxite, timber, gold (widely scattered),
cinnabar, kaolin, fish
_#_Land use: arable land NEGL%; permanent crops NEGL%; meadows and
pastures NEGL%; forest and woodland 82%; other 18%
_#_Environment: mostly an unsettled wilderness
_#_Climate: harsh, dry desert with great extremes of temperature
_#_Terrain: mostly uninhabited, sandy desert
_#_Natural resources: crude oil, natural gas, iron ore, gold, copper
_#_Land use: arable land 1%; permanent crops NEGL%; meadows and
pastures 39%; forest and woodland 1%; other 59%; includes irrigated
NEGL%
_#_Environment: no perennial rivers or permanent water bodies;
developing extensive coastal seawater desalination facilities;
desertification
_#_Note: extensive coastlines on Persian Gulf and Red Sea provide
great leverage on shipping (especially crude oil) through Persian Gulf
and Suez Canal
_#_Total area: 196,190 km2; land area: 192,000 km2
_#_Comparative area: slightly smaller than South Dakota
_#_Land boundaries: 2,640 km total; The Gambia 740 km, Guinea 330 km,
Guinea-Bissau 338 km, Mali 419 km, Mauritania 813 km
_#_Coastline: 531 km
_#_Maritime claims:
Contiguous zone: 24 nm;
Continental shelf: edge of continental margin or 200 nm;
Exclusive fishing zone: 200 nm;
Territorial sea: 12 nm
_#_Disputes: short section of the boundary with The Gambia is
indefinite; the International Court of Justice (ICJ) rendered its
decision on the Guinea-Bissau/Senegal maritime boundary in favor
of Senegal--that decision has been rejected by Guinea-Bissau;
boundary with Mauritania
_#_Climate: tropical; hot, humid; rainy season (December to April) has
strong southeast winds; dry season (May to November) dominated by hot,
dry harmattan wind
_#_Terrain: generally low, rolling, plains rising to foothills in
southeast
_#_Natural resources: fish, phosphates, iron ore
_#_Land use: arable land 27%; permanent crops 0%; meadows and
pastures 30%; forest and woodland 31%; other 12%; includes irrigated
1%
_#_Environment: lowlands seasonally flooded; deforestation;
overgrazing; soil erosion; desertification
_#_Note: The Gambia is almost an enclave
_#_Total area: 455 km2; land area: 455 km2
_#_Comparative area: slightly more than 2.5 times the size of
Washington, DC
_#_Land boundaries: none
_#_Coastline: 491 km
_#_Maritime claims:
Continental shelf: edge of continental margin or 200 nm;
Exclusive economic zone: 200 nm;
Territorial sea: 12 nm
_#_Disputes: claims Tromelin Island
_#_Climate: tropical marine; humid; cooler season during southeast
monsoon (late May to September); warmer season during northwest monsoon
(March to May)
_#_Terrain: Mahe Group is granitic, narrow coastal strip, rocky,
hilly; others are coral, flat, elevated reefs
_#_Natural resources: fish, copra, cinnamon trees
_#_Land use: arable land 4%; permanent crops 18%; meadows and pastures
0%; forest and woodland 18%; other 60%
_#_Environment: lies outside the cyclone belt, so severe storms are
rare; short droughts possible; no fresh water, catchments collect rain;
40 granitic and about 50 coralline islands
_#_Note: located north-northeast of Madagascar in the Indian Ocean
_#_Total area: 71,740 km2; land area: 71,620 km2
_#_Comparative area: slightly smaller than South Carolina
_#_Land boundaries: 958 km total; Guinea 652 km, Liberia 306 km
_#_Coastline: 402 km
_#_Maritime claims:
Territorial sea: 200 nm
_#_Climate: tropical; hot, humid; summer rainy season (May to
December); winter dry season (December to April)
_#_Terrain: coastal belt of mangrove swamps, wooded hill country,
upland plateau, mountains in east
_#_Natural resources: diamonds, titanium ore, bauxite, iron ore, gold,
chromite
_#_Land use: arable land 25%; permanent crops 2%; meadows and pastures
31%; forest and woodland 29%; other 13%; includes irrigated NEGL%
_#_Environment: extensive mangrove swamps hinder access to sea;
deforestation; soil degradation
_#_Total area: 632.6 km2; land area: 622.6 km2
_#_Comparative area: slightly less than 3.5 times the size of
Washington, DC
_#_Land boundaries: none
_#_Coastline: 193 km
_#_Maritime claims:
Exclusive fishing zone: not specific;
Territorial sea: 3 nm
_#_Climate: tropical; hot, humid, rainy; no pronounced rainy or dry
seasons; thunderstorms occur on 40% of all days (67% of days in April)
_#_Terrain: lowland; gently undulating central plateau contains water
catchment area and nature preserve
_#_Natural resources: fish, deepwater ports
_#_Land use: arable land 4%; permanent crops 7%; meadows and pastures
0%; forest and woodland 5%; other 84%
_#_Environment: mostly urban and industrialized
_#_Note: focal point for Southeast Asian sea routes
_#_Total area: 28,450 km2; land area: 27,540 km2
_#_Comparative area: slightly larger than Maryland
_#_Land boundaries: none
_#_Coastline: 5,313 km
_#_Maritime claims: (measured from claimed archipelagic baselines);
Exclusive economic zone: 200 nm;
Territorial sea: 12 nm
_#_Climate: tropical monsoon; few extremes of temperature and weather
_#_Terrain: mostly rugged mountains with some low coral atolls
_#_Natural resources: fish, forests, gold, bauxite, phosphates
_#_Land use: arable land 1%; permanent crops 1%; meadows and pastures
1%; forest and woodland 93%; other 4%
_#_Environment: subject to typhoons, which are rarely destructive;
geologically active region with frequent earth tremors
_#_Note: located just east of Papua New Guinea in the South Pacific
Ocean
_#_Total area: 637,660 km2; land area: 627,340 km2
_#_Comparative area: slightly smaller than Texas
_#_Land boundaries: 2,340 km total; Djibouti 58 km, Ethiopia
1,600 km, Kenya 682 km
_#_Coastline: 3,025 km
_#_Maritime claims:
Territorial sea: 200 nm
_#_Disputes: southern half of boundary with Ethiopia is a Provisional
Administrative Line; territorial dispute with Ethiopia over the Ogaden;
possible claims to Djibouti and parts of Ethiopia and Kenya based on
unification of ethnic Somalis
_#_Climate: desert; northeast monsoon (December to February),
cooler southwest monsoon (May to October); irregular rainfall; hot, humid
periods (tangambili) between monsoons
_#_Terrain: mostly flat to undulating plateau rising to hills in north
_#_Natural resources: uranium, and largely unexploited reserves
of iron ore, tin, gypsum, bauxite, copper, salt
_#_Land use: arable land 2%; permanent crops NEGL%; meadows and
pastures 46%; forest and woodland 14%; other 38%; includes irrigated 3%
_#_Environment: recurring droughts; frequent dust storms over eastern
plains in summer; deforestation; overgrazing; soil erosion;
desertification
_#_Note: strategic location on Horn of Africa along southern
approaches to Bab el Mandeb and route through Red Sea and Suez Canal
_#_Total area: 1,221,040 km2; land area: 1,221,040 km2; includes
Walvis Bay, Marion Island, and Prince Edward Island
_#_Comparative area: slightly less than twice the size of Texas
_#_Land boundaries: 4,973 km total; Botswana 1,840 km, Lesotho
909 km, Mozambique 491 km, Namibia 1,078 km, Swaziland 430 km, Zimbabwe
225 km
_#_Coastline: 2,881 km
_#_Maritime claims:
Continental shelf: 200 m (depth) or to depth of exploitation;
Exclusive fishing zone: 200 nm;
Territorial sea: 12 nm
_#_Disputes: claim by Namibia to Walvis Bay exclave and 12 offshore
islands administered by South Africa
_#_Climate: mostly semiarid; subtropical along coast; sunny days,
cool nights
_#_Terrain: vast interior plateau rimmed by rugged hills and
narrow coastal plain
_#_Natural resources: gold, chromium, antimony, coal, iron ore,
manganese, nickel, phosphates, tin, uranium, gem diamonds, platinum,
copper, vanadium, salt, natural gas
_#_Land use: arable land 10%; permanent crops 1%; meadows and
pastures 65%; forest and woodland 3%; other 21%; includes irrigated 1%
_#_Environment: lack of important arterial rivers or lakes requires
extensive water conservation and control measures
_#_Note: Walvis Bay is an exclave of South Africa in Namibia;
South Africa completely surrounds Lesotho and almost completely
surrounds Swaziland
_#_Total area: 4,066 km2; land area: 4,066 km2; includes Shag and
Clerke Rocks
_#_Comparative area: slightly larger than Rhode Island
_#_Land boundaries: none
_#_Coastline: undetermined
_#_Maritime claims:
Territorial sea: 12 nm
_#_Disputes: administered by the UK, claimed by Argentina
_#_Climate: variable, with mostly westerly winds throughout the
year, interspersed with periods of calm; nearly all precipitation falls
as snow
_#_Terrain: most of the islands, rising steeply from the sea, are
rugged and mountainous; South Georgia is largely barren and has steep,
glacier-covered mountains; the South Sandwich Islands are of volcanic
origin with some active volcanoes
_#_Natural resources: fish
_#_Land use: arable land 0%; permanent crops 0%; meadows and
pastures 0%; forest and woodland 0%; other 100%; largely covered
by permanent ice and snow with some sparse vegetation consisting of
grass, moss, and lichen
_#_Environment: reindeer, introduced early in this century, live
on South Georgia; weather conditions generally make it difficult to
approach the South Sandwich Islands; the South Sandwich Islands are
subject to active volcanism
_#_Note: the north coast of South Georgia has several large bays,
which provide good anchorage
_#_Total area: 22,402,200 km2; land area: 22,272,000 km2
_#_Comparative area: slightly less than 2.5 times the size of US
_#_Land boundaries: 19,933 km total; Afghanistan 2,384 km,
Czechoslovakia 98 km, China 7,520 km, Finland 1,313 km, Hungary 135 km,
Iran 1,690 km, North Korea 17 km, Mongolia 3,441 km, Norway 196 km,
Poland 1,215 km, Romania 1,307 km, Turkey 617 km
_#_Coastline: 42,777 km
_#_Maritime claims:
Continental shelf: 200 m (depth) or to depth of exploitation;
Exclusive economic zone: 200 nm;
Territorial sea: 12 nm
_#_Disputes: bilateral negotiations are under way to resolve
disputed sections of the boundary with China; US Government has not
recognized the incorporation of Estonia, Latvia, and Lithuania into
the Soviet Union; Etorofu, Kunashiri, and Shikotan Islands and the
Habomai island group occupied by Soviet Union since 1945, claimed by
Japan; maritime dispute with Norway over portion of Barents Sea; has made
no territorial claim in Antarctica (but has reserved the right to do so)
and does not recognize the claims of any other nation; Kurdish question
among Iran, Iraq, Syria, Turkey, and the USSR
_#_Climate: mostly temperate to arctic continental; winters vary from
cool along Black Sea to frigid in Siberia; summers vary from hot in
southern deserts to cool along Arctic coast
_#_Terrain: broad plain with low hills west of Urals; vast coniferous
forest and tundra in Siberia, deserts in Central Asia, mountains in south
_#_Natural resources: self-sufficient in oil, natural gas, coal,
and strategic minerals (except bauxite, alumina, tantalum, tin, tungsten,
fluorspar, and molybdenum), timber, gold, manganese, lead, zinc, nickel,
mercury, potash, phosphates; note--the USSR is the world''s largest
producer of oil and natural gas, third in coal
_#_Land use: arable land 10%; permanent crops NEGL%; meadows and
pastures 17%; forest and woodland 41%; other 32%; includes irrigated 1%
_#_Environment: despite size and diversity, small percentage of land
is arable and much is too far north; some of most fertile land is water
deficient or has insufficient growing season; many better climates have
poor soils; hot, dry, desiccating sukhovey wind affects south;
desertification; continuous permafrost over much of Siberia is a major
impediment to development
_#_Note: largest country in world, but unfavorably located in
relation to major sea lanes of world
_#_Total area: 504,750 km2; land area: 499,400 km2; includes Balearic
Islands, Canary Islands, and five places of sovereignty (plazas de
soberania) on and off the coast of Morocco--Ceuta, Mellila, Islas
Chafarinas, Penon de Alhucemas, and Penon de Velez de la Gomera
_#_Comparative area: slightly more than twice the size of Oregon
_#_Land boundaries: 1,903.2 km total; Andorra 65 km, France 623 km,
Gibraltar 1.2 km, Portugal 1,214 km
_#_Coastline: 4,964 km
_#_Maritime claims:
Exclusive economic zone: 200 nm;
Territorial sea: 12 nm
_#_Disputes: Gibraltar question with UK; Spain controls five places of
sovereignty (plazas de soberania) on and off the coast of
Morocco--the coastal enclaves of Ceuta and Melilla which Morocco contests
as well as the islands of Penon de Alhucemas, Penon de Velez de
la Gomera, and Islas Chafarinas
_#_Climate: temperate; clear, hot summers in interior, more moderate
and cloudy along coast; cloudy, cold winters in interior, partly cloudy
and cool along coast
_#_Terrain: large, flat to dissected plateau surrounded by rugged
hills; Pyrenees in north
_#_Natural resources: coal, lignite, iron ore, uranium, mercury,
pyrites, fluorspar, gypsum, zinc, lead, tungsten, copper, kaolin,
potash, hydropower
_#_Land use: arable land 31%; permanent crops 10%; meadows and
pastures 21%; forest and woodland 31%; other 7%; includes irrigated 6%
_#_Environment: deforestation; air pollution
_#_Note: strategic location along approaches to Strait of Gibraltar
_#_Total area: less than 5 km2; land area: less than 5 km2; includes
100 or so islets, coral reefs, and sea mounts scattered over the
South China Sea
_#_Comparative area: undetermined
_#_Land boundaries: none
_#_Coastline: 926 km
_#_Maritime claims: undetermined
_#_Disputes: China, Malaysia, the Philippines, Taiwan, and Vietnam
claim all or part of the Spratly Islands
_#_Climate: tropical
_#_Terrain: flat
_#_Natural resources: fish, guano; oil and natural gas potential
_#_Land use: arable land 0%; permanent crops 0%; meadows and pastures
0%; forest and woodland 0%; other 100%
_#_Environment: subject to typhoons; includes numerous small islands,
atolls, shoals, and coral reefs
_#_Note: strategically located near several primary shipping
lanes in the central South China Sea; serious navigational hazard
_#_Total area: 65,610 km2; land area: 64,740 km2
_#_Comparative area: slightly larger than West Virginia
_#_Land boundaries: none
_#_Coastline: 1,340 km
_#_Maritime claims:
Contiguous zone: 24 nm;
Continental shelf: edge of continental margin or 200 nm;
Exclusive economic zone: 200 nm;
Territorial sea: 12 nm
_#_Climate: tropical; monsoonal; northeast monsoon (December to
March); southwest monsoon (June to October)
_#_Terrain: mostly low, flat to rolling plain; mountains in
south-central interior
_#_Natural resources: limestone, graphite, mineral sands, gems,
phosphates, clay
_#_Land use: arable land 16%; permanent crops 17%; meadows and
pastures 7%; forest and woodland 37%; other 23%; includes irrigated 8%
_#_Environment: occasional cyclones, tornados; deforestation; soil
erosion
_#_Note: only 29 km from India across the Palk Strait; near major
Indian Ocean sea lanes
_#_Total area: 2,505,810 km2; land area: 2,376,000 km2
_#_Comparative area: slightly more than one quarter the size of US
_#_Land boundaries: 7,697 km total; Central African Republic 1,165 km,
Chad 1,360 km, Egypt 1,273 km, Ethiopia 2,221 km, Kenya 232 km, Libya
383 km, Uganda 435 km, Zaire 628 km
_#_Coastline: 853 km
_#_Maritime claims:
Contiguous zone: 18 nm;
Continental shelf: 200 m (depth) or to depth of exploitation;
Territorial sea: 12 nm
_#_Disputes: administrative boundary with Kenya does not coincide
with international boundary; administrative boundary with Egypt
does not coincide with international boundary
_#_Climate: tropical in south; arid desert in north; rainy season
(April to October)
_#_Terrain: generally flat, featureless plain; mountains in east and
west
_#_Natural resources: small reserves of crude oil, iron ore,
copper, chromium ore, zinc, tungsten, mica, silver, crude oil
_#_Land use: arable land 5%; permanent crops NEGL%; meadows and
pastures 24%; forest and woodland 20%; other 51%; includes irrigated 1%
_#_Environment: dominated by the Nile and its tributaries; dust
storms; desertification
_#_Note: largest country in Africa
_#_Total area: 163,270 km2; land area: 161,470 km2
_#_Comparative area: slightly larger than Georgia
_#_Land boundaries: 1,707 km total; Brazil 597 km, French Guiana
510 km, Guyana 600 km
_#_Coastline: 386 km
_#_Maritime claims:
Exclusive economic zone: 200 nm;
Territorial sea: 12 nm
_#_Disputes: claims area in French Guiana between Litani Rivier and
Riviere Marouini (both headwaters of the Lawa); claims area in Guyana
between New (Upper Courantyne) and Courantyne/Kutari Rivers (all
headwaters of the Courantyne)
_#_Climate: tropical; moderated by trade winds
_#_Terrain: mostly rolling hills; narrow coastal plain with swamps
_#_Natural resources: timber, hydropower potential, fish, shrimp,
bauxite, iron ore, and small amounts of nickel, copper, platinum, gold
_#_Land use: arable land NEGL%; permanent crops NEGL%; meadows and
pastures NEGL%; forest and woodland 97%; other 3%; includes irrigated
NEGL%
_#_Environment: mostly tropical rain forest
_#_Total area: 62,049 km2; land area: 62,049 km2; includes Spitsbergen
and Bjornoya (Bear Island)
_#_Comparative area: slightly smaller than West Virginia
_#_Land boundaries: none
_#_Coastline: 3,587 km
_#_Maritime claims:
Exclusive fishing zone: 200 nm unilaterally claimed by Norway,
not recognized by USSR;
Territorial sea: 4 nm
_#_Disputes: focus of maritime boundary dispute between Norway
and USSR
_#_Climate: arctic, tempered by warm North Atlantic Current;
cool summers, cold winters; North Atlantic Current flows along west and
north coasts of Spitsbergen, keeping water open and navigable most of the
year
_#_Terrain: wild, rugged mountains; much of high land ice covered;','d949039a98ef3dd9b476f2b9739a5849fd97d4b20ae80bdae59a0587b79737cc','internet-archive','theciaworldfactb00025gut','txt','84185fe9df79da427349cc1598fd3f69814a2085a9fc1fe0508a3fae0a870f84','https://archive.org/download/theciaworldfactb00025gut/25.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('77447b676e9f16c872e4c3e7e160fb9bef0d5af56cbc3beeb7d152b1f5412de7',1991,'SA','Saudi Arabia','geography',65,'west coast clear of ice about half the year; fjords along west and north
coasts
_#_Natural resources: coal, copper, iron ore, phosphate, zinc,
wildlife, fish
_#_Land use: arable land 0%; permanent crops 0%; meadows and pastures
0%; forest and woodland 0%; other 100%; there are no trees and the only
bushes are crowberry and cloudberry
_#_Environment: great calving glaciers descend to the sea
_#_Note: located 445 km north of Norway where the Arctic Ocean,
Barents Sea, Greenland Sea, and Norwegian Sea meet
_#_Total area: 17,360 km2; land area: 17,200 km2
_#_Comparative area: slightly smaller than New Jersey
_#_Land boundaries: 535 km total; Mozambique 105 km, South Africa
430 km
_#_Coastline: none--landlocked
_#_Maritime claims: none--landlocked
_#_Climate: varies from tropical to near temperate
_#_Terrain: mostly mountains and hills; some moderately sloping plains
_#_Natural resources: asbestos, coal, clay, tin, hydropower, forests,
and small gold and diamond deposits
_#_Land use: arable land 8%; permanent crops NEGL%; meadows and
pastures 67%; forest and woodland 6%; other 19%; includes irrigated
2%
_#_Environment: overgrazing; soil degradation; soil erosion
_#_Note: landlocked; almost completely surrounded by South Africa
_#_Total area: 449,964 km2; land area: 410,928 km2
_#_Comparative area: slightly smaller than California
_#_Land boundaries: 2,205 km total; Finland 586 km, Norway 1,619 km
_#_Coastline: 3,218 km
_#_Maritime claims:
Continental shelf: 200 m (depth) or to depth of exploitation;
Exclusive fishing zone: 200 nm;
Territorial sea: 12 nm
_#_Climate: temperate in south with cold, cloudy winters and cool,
partly cloudy summers; subarctic in north
_#_Terrain: mostly flat or gently rolling lowlands; mountains in west
_#_Natural resources: zinc, iron ore, lead, copper, silver, timber,
uranium, hydropower potential
_#_Land use: arable land 7%; permanent crops 0%; meadows and pastures
2%; forest and woodland 64%; other 27%; includes irrigated NEGL%
_#_Environment: water pollution; acid rain
_#_Note: strategic location along Danish Straits linking
Baltic and North Seas
_#_Total area: 41,290 km2; land area: 39,770 km2
_#_Comparative area: slightly more than twice the size of New Jersey
_#_Land boundaries: 1,852 km total; Austria 164 km, France 573 km,
Italy 740 km, Liechtenstein 41 km, Germany 334 km
_#_Coastline: none--landlocked
_#_Maritime claims: none--landlocked
_#_Climate: temperate, but varies with altitude; cold, cloudy,
rainy/snowy winters; cool to warm, cloudy, humid summers with occasional
showers
_#_Terrain: mostly mountains (Alps in south, Jura in northwest) with a
central plateau of rolling hills, plains, and large lakes
_#_Natural resources: hydropower potential, timber, salt
_#_Land use: arable land 10%; permanent crops 1%; meadows and pastures
40%; forest and woodland 26%; other 23%; includes irrigated 1%
_#_Environment: dominated by Alps
_#_Note: landlocked; crossroads of northern and southern Europe
_#_Total area: 185,180 km2; land area: 184,050 km2 (including 1,295
km2 of Israeli-occupied territory)
_#_Comparative area: slightly larger than North Dakota
_#_Land boundaries: 2,253 km total; Iraq 605 km, Israel 76 km,
Jordan 375 km, Lebanon 375 km, Turkey 822 km
_#_Coastline: 193 km
_#_Maritime claims:
Contiguous zone: 6 nm beyond territorial sea limit;
Territorial sea: 35 nm
_#_Disputes: separated from Israel by the 1949 Armistice Line; Golan
Heights is Israeli occupied; Hatay question with Turkey; periodic
disputes with Iraq over Euphrates water rights; ongoing dispute over
water development plans by Turkey for the Tigris and Euphrates Rivers;
Kurdish question among Iran, Iraq, Syria, Turkey, and the USSR
_#_Climate: mostly desert; hot, dry, sunny summers (June to August)
and mild, rainy winters (December to February) along coast
_#_Terrain: primarily semiarid and desert plateau; narrow coastal
plain; mountains in west
_#_Natural resources: crude oil, phosphates, chrome and manganese
ores, asphalt, iron ore, rock salt, marble, gypsum
_#_Land use: arable land 28%; permanent crops 3%; meadows and pastures
46%; forest and woodland 3%; other 20%; includes irrigated 3%
_#_Environment: deforestation; overgrazing; soil erosion;
desertification
_#_Note: there are 38 Jewish settlements in the Israeli-occupied
Golan Heights
_#_Total area: 945,090 km2; land area: 886,040 km2; includes the
islands of Mafia, Pemba, and Zanzibar
_#_Comparative area: slightly larger than twice the size of California
_#_Land boundaries: 3,402 km total; Burundi 451 km, Kenya 769 km,
Malawi 475 km, Mozambique 756 km, Rwanda 217 km, Uganda 396 km, Zambia
338 km
_#_Coastline: 1,424 km
_#_Maritime claims:
Exclusive economic zone: 200 nm;
Territorial sea: 12 nm
_#_Disputes: boundary dispute with Malawi in Lake Nyasa;
Tanzania-Zaire-Zambia tripoint in Lake Tanganyika may no longer be
indefinite since it is reported that the indefinite section of the
Zaire-Zambia boundary has been settled
_#_Climate: varies from tropical along coast to temperate in highlands
_#_Terrain: plains along coast; central plateau; highlands in north,
south
_#_Natural resources: hydropower potential, tin, phosphates,
iron ore, coal, diamonds, gemstones, gold, natural gas, nickel
_#_Land use: arable land 5%; permanent crops 1%; meadows and pastures
40%; forest and woodland 47%; other 7%; includes irrigated NEGL%
_#_Environment: lack of water and tsetse fly limit agriculture; recent
droughts affected marginal agriculture; Kilimanjaro is highest point in
Africa
_#_Total area: 514,000 km2; land area: 511,770 km2
_#_Comparative area: slightly more than twice the size of Wyoming
_#_Land boundaries: 4,863 km total; Burma 1,800 km, Cambodia 803 km,
Laos 1,754 km, Malaysia 506 km
_#_Coastline: 3,219 km
_#_Maritime claims:
Exclusive economic zone: 200 nm;
Territorial sea: 12 nm
_#_Disputes: boundary dispute with Laos; unresolved maritime
boundary with Vietnam
_#_Climate: tropical; rainy, warm, cloudy southwest monsoon
(mid-May to September); dry, cool northeast monsoon (November to
mid-March); southern isthmus always hot and humid
_#_Terrain: central plain; eastern plateau (Khorat); mountains
elsewhere
_#_Natural resources: tin, rubber, natural gas, tungsten, tantalum,
timber, lead, fish, gypsum, lignite, fluorite
_#_Land use: arable land 34%; permanent crops 4%; meadows and pastures
1%; forest and woodland 30%; other 31%; includes irrigated 7%
_#_Environment: air and water pollution; land subsidence in Bangkok
area
_#_Note: controls only land route from Asia to Malaysia and','05677cc5b14482ba7135497f61a7b73c140bea571ef2a27ea0069432d6ea13d9','internet-archive','theciaworldfactb00025gut','txt','84185fe9df79da427349cc1598fd3f69814a2085a9fc1fe0508a3fae0a870f84','https://archive.org/download/theciaworldfactb00025gut/25.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('29e5462d79b27713bbb0d4a2109dbd4ec2d46caa9bce93650de68ff6be79a649',1991,'GF','French Guiana','geography',77,'_#_Total area: 3,941 km2; land area: 3,660 km2
_#_Comparative area: slightly less than one-third the size of
Connecticut
_#_Land boundaries: none
_#_Coastline: 2,525 km
_#_Maritime claims:
Exclusive economic zone: 200 nm;
Territorial sea: 12 nm
_#_Climate: tropical, but moderate
_#_Terrain: mixture of rugged high islands and low islands with reefs
_#_Natural resources: timber, fish, cobalt
_#_Land use: arable land 1%; permanent crops 19%; meadows and
pastures 5%; forest and woodland 31%; other 44%
_#_Environment: occasional cyclonic storm in January; includes five
archipelagoes
_#_Note: Makatea in French Polynesia is one of the three great
phosphate rock islands in the Pacific Ocean--the others are Banaba
(Ocean Island) in Kiribati and Nauru
_#_Total area: 7,781 km2; land area: 7,781 km2; includes Ile
Amsterdam, Ile Saint-Paul, Iles Kerguelen, and Iles Crozet;
excludes Terre Adelie claim of about 500,000 km2 in Antarctica
that is not recognized by the US
_#_Comparative area: slightly less than 1.5 times the size of Delaware
_#_Land boundaries: none
_#_Coastline: 1,232 km
_#_Maritime claims:
Exclusive economic zone: 200 nm (Iles Kerguelen only);
Territorial sea: 12 nm
_#_Disputes: Terre Adelie claim in Antarctica is not recognized by
the US
_#_Climate: antarctic
_#_Terrain: volcanic
_#_Natural resources: fish, crayfish
_#_Land use: arable land 0%; permanent crops 0%; meadows and pastures
0%; forest and woodland 0%; other 100%
_#_Environment: Ile Amsterdam and Ile Saint-Paul are extinct
volcanoes
_#_Note: located in the southern Indian Ocean about equidistant
between Africa, Antarctica, and Australia
_#_Total area: 267,670 km2; land area: 257,670 km2
_#_Comparative area: slightly smaller than Colorado
_#_Land boundaries: 2,551 km total; Cameroon 298 km, Congo 1,903 km,
Equatorial Guinea 350 km
_#_Coastline: 885 km
_#_Maritime claims:
Contiguous zone: 24 nm;
Exclusive economic zone: 200 nm;
Territorial sea: 12 nm
_#_Disputes: maritime boundary dispute with Equatorial Guinea
because of disputed sovereignty over islands in Corisco Bay
_#_Climate: tropical; always hot, humid
_#_Terrain: narrow coastal plain; hilly interior; savanna in east and
south
_#_Natural resources: crude oil, manganese, uranium, gold, timber,
iron ore
_#_Land use: arable land 1%; permanent crops 1%; meadows and pastures
18%; forest and woodland 78%; other 2%
_#_Environment: deforestation
_#_Total area: 11,300 km2; land area: 10,000 km2
_#_Comparative area: slightly more than twice the size of Delaware
_#_Land boundary: 740 km with Senegal
_#_Coastline: 80 km
_#_Maritime claims:
Contiguous zone: 18 nm;
Continental shelf: not specific;
Exclusive fishing zone: 200 nm;
Territorial sea: 12 nm
_#_Disputes: short section of boundary with Senegal is indefinite
_#_Climate: tropical; hot, rainy season (June to November); cooler,
dry season (November to May)
_#_Terrain: flood plain of the Gambia River flanked by some low hills
_#_Natural resources: fish
_#_Land use: arable land 16%; permanent crops 0%; meadows and pastures
9%; forest and woodland 20%; other 55%; includes irrigated 3%
_#_Environment: deforestation
_#_Note: almost an enclave of Senegal; smallest country on the
continent of Africa
_#_Total area: 380km2; land area: 380 km2
_#_Comparative area: slightly more than twice the size of Washington,
DC
_#_Land boundaries: 62 km total; Egypt 11 km, Israel 51 km
_#_Coastline: 40 km
_#_Maritime claims: Israeli occupied with status to be determined
_#_Disputes: Israeli occupied with status to be determined
_#_Climate: temperate, mild winters, dry and warm to hot summers
_#_Terrain: flat to rolling, sand and dune covered coastal plain
_#_Natural resources: negligible
_#_Land use: arable land 13%, permanent crops 32%, meadows and
pastures 0%, forest and woodland 0%, other 55%
_#_Environment: desertification
_#_Note: there are 18 Jewish settlements in the Gaza Strip
_#_Total area: 356,910 km2; land area: 349,520 km2; comprises the
formerly separate Federal Republic of Germany, the German Democratic
Republic, and Berlin following formal unification on 3 October 1990
_#_Comparative area: slightly smaller than Montana
_#_Land boundaries: 3,790 km total; Austria 784 km, Belgium 167 km,
Czechoslovakia 815 km, Denmark 68 km, France 451 km, Luxembourg 138 km,
Netherlands 577 km, Poland 456 km, Switzerland 334 km
_#_Coastline: 2,389 km
_#_Maritime claims:
Continental shelf: 200 m (depth) or to depth of exploitation;
Exclusive fishing zone: 200 nm;
Territorial sea: North Sea and Schleswig-Holstein coast of
Baltic Sea--3 nm (extends, at one point, to 16 nm in the
Helgolander Bucht); remainder of Baltic Sea--12 nm
_#_Disputes: the boundaries of Germany were set by the Treaty on the
Final Settlement With Respect to Germany signed 12 September 1990 in
Moscow by the Federal Republic of Germany, the German Democratic
Republic, France, the United Kingdom, the United States, and the Soviet
Union; this treaty entered into force on 15 March 1991; a subsequent
treaty between Germany and Poland, reaffirming the German-Polish
boundary, was signed on 14 November 1990 and is set to be ratified in
1991; the US Government is seeking to settle the property claims of US
nationals against the former GDR
_#_Climate: temperate and marine; cool, cloudy, wet winters and
summers; occasional warm, tropical foehn wind; high relative humidity
_#_Terrain: lowlands in north, uplands in center, Bavarian Alps in
south
_#_Natural resources: iron ore, coal, potash, timber, lignite,
uranium, copper, natural gas, salt, nickel
_#_Land use: arable land 34%; permanent crops 1%; meadows and
pastures 16%; forest and woodland 30%; other 19%; includes irrigated 1%
_#_Environment: air and water pollution; ground water, lakes, and
air quality in eastern Germany are especially bad; significant
deforestation in the eastern mountains caused by air pollution and acid
rain
_#_Note: strategic location on North European Plain and along the
entrance to the Baltic Sea
_#_Total area: 238,540 km2; land area: 230,020 km2
_#_Comparative area: slightly smaller than Oregon
_#_Land boundaries: 2,093 km total; Burkina 548 km, Ivory Coast
668 km, Togo 877 km
_#_Coastline: 539 km
_#_Maritime claims:
Contiguous zone: 24 nm;
Continental shelf: 200 nm;
Exclusive economic zone: 200 nm;
Territorial sea: 12 nm
_#_Climate: tropical; warm and comparatively dry along southeast
coast; hot and humid in southwest; hot and dry in north
_#_Terrain: mostly low plains with dissected plateau in south-central
area
_#_Natural resources: gold, timber, industrial diamonds, bauxite,
manganese, fish, rubber
_#_Land use: arable land 5%; permanent crops 7%; meadows and pastures
15%; forest and woodland 37%; other 36%; includes irrigated NEGL%
_#_Environment: recent drought in north severely affecting marginal
agricultural activities; deforestation; overgrazing; soil erosion; dry,
northeasterly harmattan wind (January to March)
_#_Note: Lake Volta is world''s largest artificial lake
_#_Total area: 6.5 km2; land area: 6.5 km2
_#_Comparative area: about 11 times the size of The Mall in
Washington, DC
_#_Land boundaries: 1.2 km with Spain
_#_Coastline: 12 km
_#_Maritime claims:
Exclusive fishing zone: 3 nm;
Territorial sea: 3 nm
_#_Disputes: source of occasional friction between Spain and the UK
_#_Climate: Mediterranean with mild winters and warm summers
_#_Terrain: a narrow coastal lowland borders The Rock
_#_Natural resources: negligible
_#_Land use: arable land 0%; permanent crops 0%; meadows and pastures
0%; forest and woodland 0%; other 100%
_#_Environment: natural freshwater sources are meager so large
water catchments (concrete or natural rock) collect rain water
_#_Note: strategic location on Strait of Gibraltar that links
the North Atlantic Ocean and Mediterranean Sea
_#_Total area: 5 km2; land area: 5 km2; includes Ile Glorieuse,
Ile du Lys, Verte Rocks, Wreck Rock, and South Rock
_#_Comparative area: about 8.5 times the size of The Mall in
Washington, DC
_#_Land boundaries: none
_#_Coastline: 35.2 km
_#_Maritime claims:
Contiguous zone: 12 nm;
Exclusive economic zone: 200 nm;
Territorial sea: 12 nm
_#_Disputes: claimed by Madagascar
_#_Climate: tropical
_#_Terrain: undetermined
_#_Natural resources: guano, coconuts
_#_Land use: arable land 0%; permanent crops 0%; meadows and pastures
0%; forest and woodland 0%; other--lush vegetation and coconut palms 100%
_#_Environment: subject to periodic cyclones
_#_Note: located in the Indian Ocean just north of the Mozambique
Channel between Africa and Madagascar
_#_Total area: 131,940 km2; land area: 130,800 km2
_#_Comparative area: slightly smaller than Alabama
_#_Land boundaries: 1,228 km total; Albania 282 km, Bulgaria 494 km,
Turkey 206 km, Yugoslavia 246 km
_#_Coastline: 13,676 km
_#_Maritime claims:
Continental shelf: 200 m (depth) or to depth of exploitation;
Territorial sea: 6 nm
_#_Disputes: complex maritime and air (but not territorial) disputes
with Turkey in Aegean Sea; Cyprus question; Macedonia question with
Bulgaria and Yugoslavia; Northern Epirus question with Albania
_#_Climate: temperate; mild, wet winters; hot, dry summers
_#_Terrain: mostly mountains with ranges extending into sea as
peninsulas or chains of islands
_#_Natural resources: bauxite, lignite, magnesite, crude oil, marble
_#_Land use: arable land 23%; permanent crops 8%; meadows and pastures
40%; forest and woodland 20%; other 9%; includes irrigated 7%
_#_Environment: subject to severe earthquakes; air pollution;
archipelago of 2,000 islands
_#_Note: strategic location dominating the Aegean Sea and southern
approach to Turkish Straits
_#_Total area: 2,175,600 km2; land area: 341,700 km2 (ice free)
_#_Comparative area: slightly more than three times the size of Texas
_#_Land boundaries: none
_#_Coastline: 44,087 km
_#_Maritime claims:
Exclusive fishing zone: 200 nm;
Territorial sea: 3 nm
_#_Disputes: Denmark has challenged Norway''s maritime claims between
Greenland and Jan Mayen
_#_Climate: arctic to subarctic; cool summers, cold winters
_#_Terrain: flat to gradually sloping icecap covers all but a narrow,
mountainous, barren, rocky coast
_#_Natural resources: zinc, lead, iron ore, coal, molybdenum,
cryolite, uranium, fish
_#_Land use: arable land 0%; permanent crops 0%; meadows and pastures
1%; forest and woodland NEGL%; other 99%
_#_Environment: sparse population confined to small settlements along
coast; continuous permafrost over northern two-thirds of the island
_#_Note: dominates North Atlantic Ocean between North America and
Europe
_#_Total area: 340 km2; land area: 340 km2
_#_Comparative area: slightly less than twice the size of Washington,
DC
_#_Land boundaries: none
_#_Coastline: 121 km
_#_Maritime claims:
Exclusive economic zone: 200 nm;
Territorial sea: 12 nm
_#_Climate: tropical; tempered by northeast trade winds
_#_Terrain: volcanic in origin with central mountains
_#_Natural resources: timber, tropical fruit, deepwater harbors
_#_Land use: arable land 15%; permanent crops 26%; meadows and
pastures 3%; forest and woodland 9%; other 47%
_#_Environment: lies on edge of hurricane belt; hurricane season
lasts from June to November
_#_Note: islands of the Grenadines group are divided politically
with Saint Vincent and the Grenadines
_#_Total area: 1,780 km2; land area: 1,760 km2
_#_Comparative area: 10 times the size of Washington, DC
_#_Land boundaries: none
_#_Coastline: 306 km
_#_Maritime claims:
Continental shelf: 200 m (depth) or to depth of exploitation;
Exclusive economic zone: 200 nm;
Territorial sea: 12 nm
_#_Climate: subtropical tempered by trade winds; relatively high
humidity
_#_Terrain: Basse-Terre is volcanic in origin with interior
mountains; Grand-Terre is low limestone formation
_#_Natural resources: cultivable land, beaches, and climate that
foster tourism
_#_Land use: arable land 18%; permanent crops 5%; meadows and
pastures 13%; forest and woodland 40%; other 24%; includes irrigated 1%
_#_Environment: subject to hurricanes (June to October); La
Soufriere is an active volcano
_#_Note: located 500 km southeast of Puerto Rico in the Caribbean Sea
_#_Total area: 541 km2; land area: 541 km2
_#_Comparative area: slightly more than three times the size of
Washington, DC
_#_Land boundaries: none
_#_Coastline: 125.5 km
_#_Maritime claims:
Contiguous zone: 12 nm;
Continental shelf: 200 m (depth);
Exclusive economic zone: 200 nm;
Territorial sea: 12 nm
_#_Climate: tropical marine; generally warm and humid, moderated by
northeast trade winds; dry season from January to June, rainy season
from July to December; little seasonal temperature variation
_#_Terrain: volcanic origin, surrounded by coral reefs; relatively
flat coraline limestone plateau (source of most fresh water) with steep
coastal cliffs and narrow coastal plains in north, low-rising hills in
center, mountains in south
_#_Natural resources: fishing (largely undeveloped), tourism
(especially from Japan)
_#_Land use: arable land 11%; permanent crops 11%; meadows and
pastures 15%; forest and woodland 18%; other 45%
_#_Environment: frequent squalls during rainy season; subject to
relatively rare, but potentially very destructive typhoons
(especially in August)
_#_Note: largest and southernmost island in the Mariana Islands
archipelago; strategic location in western North Pacific Ocean 5,955 km
west-southwest of Honolulu about three-quarters of the way between Hawaii
and the Philippines
_#_Total area: 108,890 km2; land area: 108,430 km2
_#_Comparative area: slightly smaller than Tennessee
_#_Land boundaries: 1,687 km total; Belize 266 km, El Salvador 203 km,
Honduras 256 km, Mexico 962 km
_#_Coastline: 400 km
_#_Maritime claims:
Continental shelf: not specific;
Exclusive economic zone: 200 nm;
Territorial sea: 12 nm
_#_Disputes: claims Belize, but boundary negotiations to resolve the
dispute are underway
_#_Climate: tropical; hot, humid in lowlands; cooler in highlands
_#_Terrain: mostly mountains with narrow coastal plains and rolling
limestone plateau (Peten)
_#_Natural resources: crude oil, nickel, rare woods, fish, chicle
_#_Land use: arable land 12%; permanent crops 4%; meadows and
pastures 12%; forest and woodland 40%; other 32%; includes
irrigated 1%
_#_Environment: numerous volcanoes in mountains, with frequent
violent earthquakes; Caribbean coast subject to hurricanes and other
tropical storms; deforestation; soil erosion; water pollution
_#_Note: no natural harbors on west coast
_#_Total area: 194 km2; land area: 194 km2; includes Alderney,
Guernsey, Herm, Sark, and some other smaller islands
_#_Comparative area: slightly larger than Washington, DC
_#_Land boundaries: none
_#_Coastline: 50 km
_#_Maritime claims:
Exclusive fishing zone: 200 nm;
Territorial sea: 3 nm
_#_Climate: temperate with mild winters and cool summers; about 50% of
days are overcast
_#_Terrain: mostly level with low hills in southwest
_#_Natural resources: cropland
_#_Land use: arable land NA%; permanent crops NA%; meadows and
pastures NA%; forest and woodland NA%; other NA%; cultivated about 50%
_#_Environment: large, deepwater harbor at Saint Peter Port
_#_Note: 52 km west of France
_#_Total area: 245,860 km2; land area: 245,860 km2
_#_Comparative area: slightly smaller than Oregon
_#_Land boundaries: 3,399 km total; Guinea-Bissau 386 km, Ivory Coast
610 km, Liberia 563 km, Mali 858 km, Senegal 330 km, Sierra Leone 652 km
_#_Coastline: 320 km
_#_Maritime claims:
Exclusive economic zone: 200 nm;
Territorial sea: 12 nm
_#_Climate: generally hot and humid; monsoonal-type rainy season
(June to November) with southwesterly winds; dry season (December to
May) with northeasterly harmattan winds
_#_Terrain: generally flat coastal plain, hilly to mountainous
interior
_#_Natural resources: bauxite, iron ore, diamonds, gold, uranium,
hydropower, fish
_#_Land use: arable land 6%; permanent crops NEGL%; meadows and
pastures 12%; forest and woodland 42%; other 40%; includes irrigated
NEGL%
_#_Environment: hot, dry, dusty harmattan haze may reduce visibility
during dry season; deforestation
_#_Total area: 36,120 km2; land area: 28,000 km2
_#_Comparative area: slightly less than three times the size of
Connecticut
_#_Land boundaries: 724 km total; Guinea 386, Senegal 338 km
_#_Coastline: 350 km
_#_Maritime claims:
Exclusive economic zone: 200 nm;
Territorial sea: 12 nm
_#_Disputes: the International Court of Justice (ICJ) has rendered its
decision on the Guinea-Bissau/Senegal maritime boundary (in favor
of Senegal)--that decision has been rejected by Guinea-Bissau
_#_Climate: tropical; generally hot and humid; monsoon-type rainy
season (June to November) with southwesterly winds; dry season (December
to May) with northeasterly harmattan winds
_#_Terrain: mostly low coastal plain rising to savanna in east
_#_Natural resources: unexploited deposits of petroleum, bauxite,
phosphates; fish, timber
_#_Land use: arable land 11%; permanent crops 1%; meadows and pastures
43%; forest and woodland 38%; other 7%
_#_Environment: hot, dry, dusty harmattan haze may reduce visibility
during dry season','7131385ca48b6df5c8d56e2c673b0e200c1261ec7f3d1b109db6c4b4b14b878d','internet-archive','theciaworldfactb00025gut','txt','84185fe9df79da427349cc1598fd3f69814a2085a9fc1fe0508a3fae0a870f84','https://archive.org/download/theciaworldfactb00025gut/25.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('908626992ca9606825b4f9f01fd5d03305bbf3b578d79db35ff2715f7223ab25',1991,'ES','Spain','geography',81,'_#_Total area: 214,970 km2; land area: 196,850 km2
_#_Comparative area: slightly smaller than Idaho
_#_Land boundaries: 2,462 km total; Brazil 1,119 km, Suriname 600 km,
Venezuela 743 km
_#_Coastline: 459 km
_#_Maritime claims:
Continental shelf: outer edge of continental margin or 200 nm;
Exclusive fishing zone: 200 nm;
Territorial sea: 12 nm
_#_Disputes: all of the area west of the Essequibo river claimed by
Venezuela; Suriname claims area between New (Upper Courantyne) and
Courantyne/Kutari Rivers (all headwaters of the Courantyne)
_#_Climate: tropical; hot, humid, moderated by northeast trade winds;
two rainy seasons (May to mid-August, mid-November to mid-January)
_#_Terrain: mostly rolling highlands; low coastal plain; savanna in
south
_#_Natural resources: bauxite, gold, diamonds, hardwood timber,
shrimp, fish
_#_Land use: arable land 3%; permanent crops NEGL%; meadows and
pastures 6%; forest and woodland 83%; other 8%; includes irrigated 1%
_#_Environment: flash floods a constant threat during rainy seasons;
water pollution
_#_Total area: 27,750 km2; land area: 27,560 km2
_#_Comparative area: slightly larger than Maryland
_#_Land boundary: 275 km with the Dominican Republic
_#_Coastline: 1,771 km
_#_Maritime claims:
Contiguous zone: 24 nm;
Continental shelf: to depth of exploitation;
Exclusive economic zone: 200 nm;
Territorial sea: 12 nm
_#_Disputes: claims US-administered Navassa Island
_#_Climate: tropical; semiarid where mountains in east cut off trade
winds
_#_Terrain: mostly rough and mountainous
_#_Natural resources: bauxite
_#_Land use: arable land 20%; permanent crops 13%; meadows and
pastures 18%; forest and woodland 4%; other 45%; includes irrigated 3%
_#_Environment: lies in the middle of the hurricane belt and subject
to severe storms from June to October; occasional flooding and
earthquakes; deforestation; soil erosion
_#_Note: shares island of Hispaniola with Dominican Republic
_#_Total area: 412 km2; land area: 412 km2
_#_Comparative area: slightly less than 2.5 times the size of
Washington, DC
_#_Land boundaries: none
_#_Coastline: 101.9 km
_#_Maritime claims:
Exclusive fishing zone: 200 nm;
Territorial sea: 3 nm
_#_Climate: antarctic
_#_Terrain: Heard Island--bleak and mountainous, with an extinct
volcano; McDonald Islands--small and rocky
_#_Land use: arable land 0%; permanent crops 0%; meadows and pastures
0%; forest and woodland 0%; other 100%
_#_Environment: primarily used as research stations
_#_Note: located 4,100 km southwest of Australia in the
southern Indian Ocean
_#_Total area: 112,090 km2; land area: 111,890 km2
_#_Comparative area: slightly larger than Tennessee
_#_Land boundaries: 1,520 km total; Guatemala 256 km, El Salvador 342
km, Nicaragua 922 km
_#_Coastline: 820 km
_#_Maritime claims:
Contiguous zone: 24 nm;
Continental shelf: 200 m (depth) or to depth of exploitation;
Exclusive economic zone: 200 nm;
Territorial sea: 12 nm
_#_Disputes: dispute with El Salvador over several sections of
the land boundary; dispute over Golfo de Fonseca maritime boundary
because of disputed sovereignty of islands; unresolved maritime boundary
with Nicaragua
_#_Climate: subtropical in lowlands, temperate in mountains
_#_Terrain: mostly mountains in interior, narrow coastal plains
_#_Natural resources: timber, gold, silver, copper, lead, zinc,
iron ore, antimony, coal, fish
_#_Land use: arable land 14%; permanent crops 2%; meadows and pastures
30%; forest and woodland 34%; other 20%; includes irrigated 1%
_#_Environment: subject to frequent, but generally mild, earthquakes;
damaging hurricanes and floods along Caribbean coast; deforestation; soil
erosion
_#_Total area: 1,040 km2; land area: 990 km2
_#_Comparative area: slightly less than six times the size of
Washington, DC
_#_Land boundary: 30 km with China
_#_Coastline: 733 km
_#_Maritime claims:
Exclusive fishing zone: 3 nm;
Territorial sea: 3 nm
_#_Climate: tropical monsoon; cool and humid in winter, hot and rainy
from spring through summer, warm and sunny in fall
_#_Terrain: hilly to mountainous with steep slopes; lowlands in north
_#_Natural resources: outstanding deepwater harbor, feldspar
_#_Land use: arable land 7%; permanent crops 1%; meadows and pastures
1%; forest and woodland 12%; other 79%; includes irrigated 3%
_#_Environment: more than 200 islands; occasional typhoons
_#_Total area: 1.6 km2; land area: 1.6 km2
_#_Comparative area: about 2.7 times the size of The Mall in
Washington, DC
_#_Land boundaries: none
_#_Coastline: 6.4 km
_#_Maritime claims:
Contiguous zone: 12 nm;
Continental shelf: 200 m (depth);
Exclusive economic zone: 200 nm;
Territorial sea: 12 nm
_#_Climate: equatorial; scant rainfall, constant wind, burning sun
_#_Terrain: low-lying, nearly level, sandy, coral island surrounded by
a narrow fringing reef; depressed central area
_#_Natural resources: guano (deposits worked until late 1800s)
_#_Land use: arable land 0%; permanent crops 0%; meadows and pastures
0%; forest and woodland 5%; other 95%
_#_Environment: almost totally covered with grasses, prostrate vines,
and low-growing shrubs; small area of trees in the center; lacks fresh
water; primarily a nesting, roosting, and foraging habitat for seabirds,
shorebirds, and marine wildlife; feral cats
_#_Note: remote location 2,575 km southwest of Honolulu in the North
Pacific Ocean, just north of the Equator, about halfway between Hawaii
and Australia
_#_Total area: 93,030 km2; land area: 92,340 km2
_#_Comparative area: slightly smaller than Indiana
_#_Land boundaries: 2,251 km total; Austria 366 km, Czechoslovakia 676
km, Romania 443 km, USSR 135 km, Yugoslavia 631 km
_#_Coastline: none--landlocked
_#_Maritime claims: none--landlocked
_#_Disputes: Nagymaros Dam dispute with Czechoslovakia
_#_Climate: temperate; cold, cloudy, humid winters; warm summers
_#_Terrain: mostly flat to rolling plains
_#_Natural resources: bauxite, coal, natural gas, fertile soils
_#_Land use: arable land 54%; permanent crops 3%; meadows and pastures
14%; forest and woodland 18%; other 11%; includes irrigated 2%
_#_Environment: levees are common along many streams, but flooding
occurs almost every year
_#_Note: landlocked; strategic location astride main land routes
between Western Europe and Balkan Peninsula as well as between USSR and
Mediterranean basin
_#_Total area: 103,000 km2; land area: 100,250 km2
_#_Comparative area: slightly smaller than Kentucky
_#_Land boundaries: none
_#_Coastline: 4,988 km
_#_Maritime claims:
Continental shelf: edge of continental margin or 200 nm;
Exclusive economic zone: 200 nm;
Territorial sea: 12 nm
_#_Disputes: Rockall continental shelf dispute involving Denmark,
Ireland, and the UK (Ireland and the UK have signed a boundary agreement
in the Rockall area)
_#_Climate: temperate; moderated by North Atlantic Current; mild,
windy winters; damp, cool summers
_#_Terrain: mostly plateau interspersed with mountain peaks,
icefields; coast deeply indented by bays and fiords
_#_Natural resources: fish, hydroelectric and geothermal power,
diatomite
_#_Land use: arable land NEGL%; permanent crops 0%; meadows and
pastures 23%; forest and woodland 1%; other 76%
_#_Environment: subject to earthquakes and volcanic activity
_#_Note: strategic location between Greenland and Europe;
westernmost European country
_#_Total area: 3,287,590 km2; land area: 2,973,190 km2
_#_Comparative area: slightly more than one-third the size of the US
_#_Land boundaries: 14,103 km total; Bangladesh 4,053 km, Bhutan 605
km, Burma 1,463 km, China 3,380, Nepal 1,690 km, Pakistan 2,912 km
_#_Coastline: 7,000 km
_#_Maritime claims:
Contiguous zone: 24 nm;
Continental shelf: edge of continental margin or 200 nm;
Exclusive economic zone: 200 nm;
Territorial sea: 12 nm
_#_Disputes: boundaries with Bangladesh, China, and Pakistan; water
sharing problems with downstream riparians, Bangladesh over the Ganges
and Pakistan over the Indus
_#_Climate: varies from tropical monsoon in south to temperate in
north
_#_Terrain: upland plain (Deccan Plateau) in south, flat to rolling
plain along the Ganges, deserts in west, Himalayas in north
_#_Natural resources: coal (fourth-largest reserves in the world),
iron ore, manganese, mica, bauxite, titanium ore, chromite, natural gas,
diamonds, crude oil, limestone
_#_Land use: arable land 55%; permanent crops 1%; meadows and pastures
4%; forest and woodland 23%; other 17%; includes irrigated 13%
_#_Environment: droughts, flash floods, severe thunderstorms common;
deforestation; soil erosion; overgrazing; air and water pollution;
desertification
_#_Note: dominates South Asian subcontinent; near important
Indian Ocean trade routes
_#_Total area: 73,600,000 km2; Arabian Sea, Bass Strait, Bay of
Bengal, Java Sea, Persian Gulf, Red Sea, Strait of Malacca, Timor Sea,
and other tributary water bodies
_#_Comparative area: slightly less than eight times the size of the
US; third-largest ocean (after the Pacific Ocean and Atlantic Ocean, but
larger than the Arctic Ocean)
_#_Coastline: 66,526 km
_#_Climate: northeast monsoon (December to April), southwest monsoon
(June to October); tropical cyclones occur during May/June and
October/November in the north Indian Ocean and January/February in the
south Indian Ocean
_#_Terrain: surface dominated by counterclockwise gyre (broad,
circular system of currents) in the south Indian Ocean; unique reversal
of surface currents in the north Indian Ocean--low pressure over
southwest Asia from hot, rising, summer air results in the southwest
monsoon and southwest-to-northeast winds and currents, while high
pressure over northern Asia from cold, falling, winter air results in the
northeast monsoon and northeast-to-southwest winds and currents; ocean
floor is dominated by the Mid-Indian Ocean Ridge and subdivided by the
Southeast Indian Ocean Ridge, Southwest Indian Ocean Ridge, and Ninety
East Ridge; maximum depth is 7,258 meters in the Java Trench
_#_Natural resources: oil and gas fields, fish, shrimp, sand and
gravel aggregates, placer deposits, polymetallic nodules
_#_Environment: endangered marine species include the dugong, seals,
turtles, and whales; oil pollution in the Arabian Sea, Persian Gulf, and
Red Sea
_#_Note: major choke points include Bab el Mandeb, Strait of Hormuz,
Strait of Malacca, southern access to the Suez Canal, and the Lombok
Strait; ships subject to superstructure icing in extreme south near
Antarctica from May to October
_#_Total area: 1,919,440 km2; land area: 1,826,440 km2
_#_Comparative area: slightly less than three times the size of Texas
_#_Land boundaries: 2,602 km total; Malaysia 1,782 km, Papua New
Guinea 820 km
_#_Coastline: 54,716 km
_#_Maritime claims: (measured from claimed archipelagic baselines);
Exclusive economic zone: 200 nm;
Territorial sea: 12 nm
_#_Disputes: sovereignty over Timor Timur (East Timor Province)
disputed with Portugal
_#_Climate: tropical; hot, humid; more moderate in highlands
_#_Terrain: mostly coastal lowlands; larger islands have interior
mountains
_#_Natural resources: crude oil, tin, natural gas liquids, nickel,
timber, bauxite, copper, fertile soils, coal, gold, silver
_#_Land use: arable land 8%; permanent crops 3%; meadows and pastures
7%; forest and woodland 67%; other 15%; includes irrigated 3%
_#_Environment: archipelago of 13,500 islands (6,000 inhabited);
occasional floods, severe droughts, and tsunamis; deforestation
_#_Note: straddles Equator; strategic location astride or along major
sea lanes from Indian Ocean to Pacific Ocean
_#_Total area: 1,648,000 km2; land area: 1,636,000 km2
_#_Comparative area: slightly larger than Alaska
_#_Land boundaries: 5,492 km total; Afghanistan 936 km, Iraq 1,458 km,
Pakistan 909 km, Turkey 499 km, USSR 1,690 km
_#_Coastline: 3,180 km
_#_Maritime claims:
Continental shelf: not specific;
Exclusive fishing zone: 50 nm in the Sea of Oman; continental
shelf limit, continental shelf boundaries, or median lines in the Persian
Gulf;
Territorial sea: 12 nm
_#_Disputes: Iran and Iraq restored diplomatic relations on 14
October 1990 following the end of the war that began on 22 September
1980; progress had been made on the major issues of contention--troop
withdrawal, prisoner-of-war exchanges, demarcation of the border,
freedom of navigation, and sovereignty over the the Shatt al Arab
waterway--but written agreements had yet to be drawn up when frictions
reemerged in March 1991 in the wake of Shia and Kurdish revolts in
Iraq that Baghdad accused Tehran of supporting;
Kurdish question among Iran, Iraq, Syria, Turkey, and the USSR;
occupies three islands in the Persian Gulf claimed by UAE (Jazireh-ye
Abu Musa or Abu Musa, Jazireh-ye Tonb-e Bozorg or
Greater Tunb, and Jazireh-ye Tonb-e Kuchek or Lesser Tunb); periodic
disputes with Afghanistan over Helmand water rights; Boluch question with
Afghanistan and Pakistan
_#_Climate: mostly arid or semiarid, subtropical along Caspian coast
_#_Terrain: rugged, mountainous rim; high, central basin with deserts,
mountains; small, discontinuous plains along both coasts
_#_Natural resources: petroleum, natural gas, coal, chromium, copper,
iron ore, lead, manganese, zinc, sulfur
_#_Land use: arable land 8%; permanent crops NEGL%; meadows and
pastures 27%; forest and woodland 11%; other 54%; includes irrigated 2%
_#_Environment: deforestation; overgrazing; desertification
_#_Total area: 434,920 km2; land area: 433,970 km2
_#_Comparative area: slightly more than twice the size of Idaho
_#_Land boundaries: 3,454 km total; Iran 1,458 km, Iraq - Saudi Arabia
Neutral Zone 191 km, Jordan 134 km, Kuwait 240 km, Saudi Arabia 495 km,
Syria 605 km, Turkey 331 km
_#_Coastline: 58 km
_#_Maritime claims:
Continental shelf: not specific;
Territorial sea: 12 nm
_#_Disputes: Iran and Iraq restored diplomatic relations on 14
October 1990 following the end of the war that began on 22 September
1980; progress had been made on the major issues of
contention--troop withdrawal, prisoner-of-war exchanges, demarcation of
the border, freedom of navigation, and sovereignty over the Shatt al Arab
waterway--but written agreements had yet to be drawn up when frictions
reemerged in March 1991 in the wake of Shia and Kurdish revolts in
Iraq that Baghdad accused Tehran of supporting; Kurdish question
among Iran, Iraq, Syria, Turkey, and the USSR; shares Neutral Zone with
Saudi Arabia--in December 1981, Iraq and Saudi Arabia signed a boundary
agreement that divides the zone between them, but the agreement must
be ratified before it becomes effective; Iraqi forces invaded and
occupied Kuwait from 2 August 1990 until 27 February 1991; in April 1991
official Iraqi acceptance of UN Security Council Resolution 687, which
demands that Iraq accept its internationally recognized border with
Kuwait, ended earlier claims to Bubiyan and Warbah Islands or to
all of Kuwait; periodic disputes with upstream riparian Syria over
Euphrates water rights; potential dispute over water development plans by
Turkey for the Tigris and Euphrates Rivers
_#_Climate: desert; mild to cool winters with dry, hot, cloudless
summers
_#_Terrain: mostly broad plains; reedy marshes in southeast; mountains
along borders with Iran and Turkey
_#_Natural resources: crude oil, natural gas, phosphates, sulfur
_#_Land use: arable land 12%; permanent crops 1%; meadows and pastures
9%; forest and woodland 3%; other 75%; includes irrigated 4%
_#_Environment: development of Tigris-Euphrates river systems
contingent upon agreements with upstream riparians (Syria, Turkey); air
and water pollution; soil degradation (salinization) and erosion;
desertification
_#_Total area: 3,520 km2; land area: 3,520 km2
_#_Comparative area: slightly larger than Rhode Island
_#_Land boundaries: 389 km total; 191 km Iraq, 198 km Saudi Arabia
_#_Coastline: none--landlocked
_#_Maritime claims: none--landlocked
_#_Climate: harsh, dry desert
_#_Terrain: sandy desert
_#_Natural resources: none
_#_Land use: arable land 0%; permanent crops 0%; meadows and pastures
0%; forest and woodland 0%; other (sandy desert) 100%
_#_Environment: harsh, inhospitable
_#_Note: landlocked; located west of quadripoint with Iraq, Kuwait,
and Saudi Arabia
_#_Total area: 70,280 km2; land area: 68,890 km2
_#_Comparative area: slightly larger than West Virginia
_#_Land boundary: 360 km with UK
_#_Coastline: 1,448 km
_#_Maritime claims:
Continental shelf: no precise definition;
Exclusive fishing zone: 200 nm;
Territorial sea: 12 nm
_#_Disputes: Northern Ireland question with the UK; Rockall
continental shelf dispute involving Denmark, Iceland, and the UK (Ireland
and the UK have signed a boundary agreement in the Rockall area)
_#_Climate: temperate maritime; modified by North Atlantic Current;
mild winters, cool summers; consistently humid; overcast about half the
time
_#_Terrain: mostly level to rolling interior plain surrounded by
rugged hills and low mountains; sea cliffs on west coast
_#_Natural resources: zinc, lead, natural gas, crude oil, barite,
copper, gypsum, limestone, dolomite, peat, silver
_#_Land use: arable land 14%; permanent crops NEGL%; meadows and
pastures 71%; forest and woodland 5%; other 10%
_#_Environment: deforestation
_#_Total area: 20,770 km2; land area: 20,330 km2
_#_Comparative area: slightly larger than New Jersey
_#_Land boundaries: 1,006 km total; Egypt 255 km, Jordan 238 km,
Lebanon 79 km, Syria 76 km, West Bank 307, Gaza Strip 51 km
_#_Coastline: 273 km
_#_Maritime claims:
Continental shelf: to depth of exploitation;
Territorial sea: 6 nm
_#_Disputes: separated from Lebanon, Syria, and the West Bank by the
1949 Armistice Line; differences with Jordan over the location
of the 1949 Armistice Line which separates the two countries;
West Bank and Gaza Strip are Israeli occupied with status
to be determined; Golan Heights is Israeli occupied; Israeli troops in
southern Lebanon since June 1982; water-sharing issues with Jordan
_#_Climate: temperate; hot and dry in desert areas
_#_Terrain: Negev desert in the south; low coastal plain; central
mountains; Jordan Rift Valley
_#_Natural resources: copper, phosphates, bromide, potash, clay, sand,
sulfur, asphalt, manganese, small amounts of natural gas and crude oil
_#_Land use: arable land 17%; permanent crops 5%; meadows and pastures
40%; forest and woodland 6%; other 32%; includes irrigated 11%
_#_Environment: sandstorms may occur during spring and summer; limited
arable land and natural water resources pose serious constraints;
deforestation
_#_Note: there are 175 Jewish settlements in the West Bank, 38 in the
Israeli-occupied Golan Heights, 18 in the Gaza Strip, and 14
Israeli-built Jewish neighborhoods in East Jerusalem
_#_Total area: 301,230 km2; land area: 294,020 km2; includes Sardinia
and Sicily
_#_Comparative area: slightly larger than Arizona
_#_Land boundaries: 1,902.2 km total; Austria 430 km, France 488 km,
San Marino 39 km, Switzerland 740 km, Vatican City 3.2 km, Yugoslavia
202 km
_#_Coastline: 4,996 km
_#_Maritime claims:
Continental shelf: 200 m (depth) or to depth of exploitation;
Territorial sea: 12 nm
_#_Climate: predominantly Mediterranean; Alpine in far north; hot, dry
in south
_#_Terrain: mostly rugged and mountainous; some plains, coastal
lowlands
_#_Natural resources: mercury, potash, marble, sulfur, dwindling
natural gas and crude oil reserves, fish, coal
_#_Land use: arable land 32%; permanent crops 10%; meadows and
pastures 17%; forest and woodland 22%; other 19%; includes irrigated 10%
_#_Environment: regional risks include landslides, mudflows,
snowslides, earthquakes, volcanic eruptions, flooding, pollution; land
sinkage in Venice
_#_Note: strategic location dominating central Mediterranean as
well as southern sea and air approaches to Western Europe
_#_Total area: 322,460 km2; land area: 318,000 km2
_#_Comparative area: slightly larger than New Mexico
_#_Land boundaries: 3,110 km total; Burkina 584 km, Ghana 668 km,
Guinea 610 km, Liberia 716 km, Mali 532 km
_#_Coastline: 515 km
_#_Maritime claims:
Continental shelf: 200 m (depth);
Exclusive economic zone: 200 nm;
Territorial sea: 12 nm
_#_Climate: tropical along coast, semiarid in far north; three
seasons--warm and dry (November to March), hot and dry (March to May),
hot and wet (June to October)
_#_Terrain: mostly flat to undulating plains; mountains in northwest
_#_Natural resources: crude oil, diamonds, manganese, iron ore,
cobalt, bauxite, copper
_#_Land use: arable land 9%; permanent crops 4%; meadows and pastures
9%; forest and woodland 26%; other 52%; includes irrigated NEGL%
_#_Environment: coast has heavy surf and no natural harbors; severe
deforestation
_#_Total area: 10,990 km2; land area: 10,830 km2
_#_Comparative area: slightly smaller than Connecticut
_#_Land boundaries: none
_#_Coastline: 1,022 km
_#_Maritime claims:
Territorial sea: 12 nm
_#_Climate: tropical; hot, humid; temperate interior
_#_Terrain: mostly mountains with narrow, discontinuous coastal plain
_#_Natural resources: bauxite, gypsum, limestone
_#_Land use: arable land 19%; permanent crops 6%; meadows and pastures
18%; forest and woodland 28%; other 29%; includes irrigated 3%
_#_Environment: subject to hurricanes (especially July to November);
deforestation; water pollution
_#_Note: strategic location between Cayman Trench and Jamaica
Channel, the main sea lanes for Panama Canal
_#_Total area: 373 km2; land area: 373 km2
_#_Comparative area: slightly more than twice the size of
Washington, DC
_#_Land boundaries: none
_#_Coastline: 124.1 km
_#_Maritime claims:
Contiguous zone: 10 nm;
Continental shelf: 200 m (depth) or to depth of exploitation;
Exclusive fishing zone: 200 nm;
Territorial sea: 4 nm
_#_Disputes: Denmark has challenged Norway''s maritime claims beween
Greenland and Jan Mayen
_#_Climate: arctic maritime with frequent storms and persistent fog
_#_Terrain: volcanic island, partly covered by glaciers; Beerenberg is
the highest peak, with an elevation of 2,277 meters
_#_Natural resources: none
_#_Land use: arable land 0%; permanent crops 0%; meadows and pastures
0%; forest and woodland 0%; other 100%
_#_Environment: barren volcanic island with some moss and grass;
volcanic activity resumed in 1970
_#_Note: located north of the Arctic Circle about 590 km
north-northeast of Iceland between the Greenland Sea and the
Norwegian Sea
_#_Total area: 377,835 km2; land area: 374,744 km2; includes Bonin
Islands (Ogasawara-gunto), Daito-shoto, Minami-jima,
Okinotori-shima, Ryukyu Islands (Nansei-shoto), and Volcano Islands
(Kazan-retto)
_#_Comparative area: slightly smaller than California
_#_Land boundaries: none
_#_Coastline: 29,751 km
_#_Maritime claims:
Exclusive fishing zone: 200 nm;
Territorial sea: 12 nm (3 nm in international straits--La Perouse
or Soya, Tsugaru, Osumi, and Eastern and Western channels of the Korea or
Tsushima Strait)
_#_Disputes: Etorofu, Kunashiri, and Shikotan Islands and the
Habomai island group occupied by Soviet Union since 1945, claimed by
Japan; Liancourt Rocks disputed with South Korea; Senkaku-shoto
(Senkaku Islands) claimed by China and Taiwan
_#_Climate: varies from tropical in south to cool temperate in north
_#_Terrain: mostly rugged and mountainous
_#_Natural resources: negligible mineral resources, fish
_#_Land use: arable land 13%; permanent crops 1%; meadows and pastures
1%; forest and woodland 67%; other 18%; includes irrigated 9%
_#_Environment: many dormant and some active volcanoes; about 1,500
seismic occurrences (mostly tremors) every year; subject to tsunamis
_#_Note: strategic location in northeast Asia
_#_Total area: 4.5 km2; land area: 4.5 km2
_#_Comparative area: about 7.5 times the size of The Mall in
Washington, DC
_#_Land boundaries: none
_#_Coastline: 8 km
_#_Maritime claims:
Contiguous zone: 12 nm;
Continental shelf: 200 m (depth);
Exclusive economic zone: 200 nm;
Territorial sea: 12 nm
_#_Climate: tropical; scant rainfall, constant wind, burning sun
_#_Terrain: sandy, coral island surrounded by a narrow fringing reef
_#_Natural resources: guano (deposits worked until la','750471a4627bb5166486b74b85b70af7db0939963165a6d854f139f397d9f0df','internet-archive','theciaworldfactb00025gut','txt','84185fe9df79da427349cc1598fd3f69814a2085a9fc1fe0508a3fae0a870f84','https://archive.org/download/theciaworldfactb00025gut/25.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e95eba92440d1cf261fc0eaf86e2856feb86b5c86b8628e793d8853570d90e2d',1991,'ES','Spain','geography',82,'te 1800s)
_#_Land use: arable land 0%; permanent crops 0%; meadows and pastures
0%; forest and woodland 0%; other 100%
_#_Environment: sparse bunch grass, prostrate vines, and low-growing
shrubs; lacks fresh water; primarily a nesting, roosting, and foraging
habitat for seabirds, shorebirds, and marine wildlife; feral cats
_#_Note: 2,090 km south of Honolulu in the South Pacific Ocean, just
south of the Equator, about halfway between Hawaii and the Cook Islands
_#_Total area: 117 km2; land area: 117 km2
_#_Comparative area: about 0.7 times the size of Washington, DC
_#_Land boundaries: none
_#_Coastline: 70 km
_#_Maritime claims:
Exclusive fishing zone: 200 nm;
Territorial sea: 3 nm
_#_Climate: temperate; mild winters and cool summers
_#_Terrain: gently rolling plain with low, rugged hills along north
coast
_#_Natural resources: agricultural land
_#_Land use: arable land NA%; permanent crops NA%; meadows and
pastures NA%; forest and woodland NA%; other NA%; about 58% of land under
cultivation
_#_Environment: about 30% of population concentrated in Saint Helier
_#_Note: largest and southernmost of Channel Islands; 27 km
from France','0f0d63eb1a0036838dbe613d9a01749606759601714c3fbd5c418a133acbbf61','internet-archive','theciaworldfactb00025gut','txt','84185fe9df79da427349cc1598fd3f69814a2085a9fc1fe0508a3fae0a870f84','https://archive.org/download/theciaworldfactb00025gut/25.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e0434cb43fb864c77c78ee8c32d2b16f79135f34af4491f7a6761fcf9ca59d50',1991,'FR','France','geography',95,'_#_Total area: 2.8 km2; land area: 2.8 km2
_#_Comparative area: about 4.7 times the size of The Mall in
Washington, DC
_#_Land boundaries: none
_#_Coastline: 10 km
_#_Maritime claims:
Contiguous zone: 12 nm;
Continental shelf: 200 m (depth);
Exclusive economic zone: 200 nm;
Territorial sea: 12 nm
_#_Climate: tropical, but generally dry; consistent northeast trade
winds with little seasonal temperature variation
_#_Terrain: mostly flat with a maximum elevation of 4 meters
_#_Natural resources: guano (deposits worked until about 1890)
_#_Land use: arable land 0%; permanent crops 0%; meadows and pastures
0%; forest and woodland 0%; other 100%
_#_Environment: some low-growing vegetation
_#_Note: strategic location 1,328 km west-southwest of Honolulu in
the North Pacific Ocean, about one-third of the way between Hawaii and
the Marshall Islands; Johnston Island and Sand Island are natural
islands; North Island (Akau) and East Island (Hikina) are manmade islands
formed from coral dredging; closed to the public; former nuclear weapons
test site; site of Johnston Atoll Chemical Agent Disposal System
(JACADS)
_#_Total area: 91,880 km2; land area: 91,540 km2
_#_Comparative area: slightly smaller than Indiana
_#_Land boundaries: 1,586 km total; Iraq 134 km, Israel 238 km,
Saudi Arabia 742 km, Syria 375 km, West Bank 97 km
_#_Coastline: 26 km
_#_Maritime claims:
Territorial sea: 3 nm
_#_Disputes: differences with Israel over the location of the
1949 Armistice Line which separates the two countries
_#_Climate: mostly arid desert; rainy season in west (November to
April)
_#_Terrain: mostly desert plateau in east, highland area in west;
Great Rift Valley separates East and West Banks of the Jordan River
_#_Natural resources: phosphates, potash, shale oil
_#_Land use: arable land 4%; permanent crops 0.5%; meadows and
pastures 1%; forest and woodland 0.5%; other 94%; includes irrigated 0.5%
_#_Environment: lack of natural water resources; deforestation;
overgrazing; soil erosion; desertification
_#_Total area: 4.4 km2; land area: 4.4 km2
_#_Comparative area: about 7.5 times the size of The Mall in
Washington, DC
_#_Land boundaries: none
_#_Coastline: 24.1 km
_#_Maritime claims:
Contiguous zone: 12 nm;
Continental shelf: 200 m (depth) or to depth of exploitation;
Exclusive economic zone: 200 nm;
Territorial sea: 12 nm
_#_Disputes: claimed by Madagascar
_#_Climate: tropical
_#_Terrain: undetermined
_#_Natural resources: guano deposits and other fertilizers
_#_Land use: arable land 0%; permanent crops 0%; meadows and pastures
0%; forest and woodland 90%; other 10%
_#_Environment: subject to periodic cyclones; wildlife sanctuary
_#_Note: located in the central Mozambique Channel about halfway
between Africa and Madagascar
_#_Total area: 582,650 km2; land area: 569,250 km2
_#_Comparative area: slightly more than twice the size of Nevada
_#_Land boundaries: 3,477 km total; Ethiopia 861 km, Somalia 682 km,
Sudan 232 km, Tanzania 769 km, Uganda 933 km
_#_Coastline: 536 km
_#_Maritime claims:
Exclusive economic zone: 200 nm;
Territorial sea: 12 nm
_#_Disputes: administrative boundary with Sudan does not coincide
with international boundary; possible claim by Somalia based on
unification of ethnic Somalis
_#_Climate: varies from tropical along coast to arid in interior
_#_Terrain: low plains rise to central highlands bisected by Great
Rift Valley; fertile plateau in west
_#_Natural resources: gold, limestone, soda ash, salt barytes,
rubies, fluorspar, garnets, wildlife
_#_Land use: arable land 3%; permanent crops 1%; meadows and pastures
7%; forest and woodland 4%; other 85%; includes irrigated NEGL%
_#_Environment: unique physiography supports abundant and varied
wildlife of scientific and economic value; deforestation; soil erosion;
desertification; glaciers on Mt. Kenya
_#_Note: Kenyan Highlands one of the most successful agricultural
production regions in Africa
_#_Total area: 1 km2; land area: 1 km2
_#_Comparative area: about 1.7 times the size of The Mall in
Washington, DC
_#_Land boundaries: none
_#_Coastline: 3 km
_#_Maritime claims:
Contiguous zone: 12 nm;
Continental shelf: 200 m (depth);
Exclusive economic zone: 200 nm;
Territorial sea: 12 nm
_#_Climate: tropical, but moderated by prevailing winds
_#_Terrain: low and nearly level with a maximum elevation of about
1 meter
_#_Natural resources: none
_#_Land use: arable land 0%; permanent crops 0%; meadows and pastures
0%; forest and woodland 0%; other 100%
_#_Environment: barren coral atoll with deep interior lagoon; wet or
awash most of the time
_#_Note: located 1,600 km south-southwest of Honolulu in the North
Pacific Ocean, about halfway between Hawaii and American Samoa; maximum
elevation of about 1 meter makes this a navigational hazard; closed to
the public
_#_Total area: 717 km2; land area: 717 km2; includes three island
groups--Gilbert Islands, Line Islands, Phoenix Islands
_#_Comparative area: slightly more than four times the size of
Washington, DC
_#_Land boundaries: none
_#_Coastline: 1,143 km
_#_Maritime claims:
Exclusive economic zone: 200 nm;
Territorial sea: 12 nm
_#_Climate: tropical; marine, hot and humid, moderated by trade winds
_#_Terrain: mostly low-lying coral atolls surrounded by extensive
reefs
_#_Natural resources: phosphate (production discontinued in 1979)
_#_Land use: arable land NEGL%; permanent crops 51%; meadows and
pastures 0%; forest and woodland 3%; other 46%
_#_Environment: typhoons can occur any time, but usually November to
March; 20 of the 33 islands are inhabited
_#_Note: Banaba (Ocean Island) in Kiribati is one of the three great
phosphate rock islands in the Pacific Ocean--the others are Makatea
in French Polynesia and Nauru
_#_Total area: 120,540 km2; land area: 120,410 km2
_#_Comparative area: slightly smaller than Mississippi
_#_Land boundaries: 1,671 km total; China 1,416 km, South Korea 238
km, USSR 17 km
_#_Coastline: 2,495 km
_#_Maritime claims:
Exclusive economic zone: 200 nm;
Territorial sea: 12 nm;
Military boundary line: 50 nm in the Sea of Japan and the
exclusive economic zone limit in the Yellow Sea (all foreign vessels and
aircraft without permission are banned)
_#_Disputes: short section of boundary with China is indefinite;
Demarcation Line with South Korea
_#_Climate: temperate with rainfall concentrated in summer
_#_Terrain: mostly hills and mountains separated by deep, narrow
valleys; coastal plains wide in west, discontinuous in east
_#_Natural resources: coal, lead, tungsten, zinc, graphite, magnesite,
iron ore, copper, gold, pyrites, salt, fluorspar, hydropower
_#_Land use: arable land 18%; permanent crops 1%; meadows and pastures
NEGL%; forest and woodland 74%; other 7%; includes irrigated 9%
_#_Environment: mountainous interior is isolated, nearly inaccessible,
and sparsely populated; late spring droughts often followed by severe
flooding
_#_Note: strategic location bordering China, South Korea, and USSR
_#_Total area: 98,480 km2; land area: 98,190 km2
_#_Comparative area: slightly larger than Indiana
_#_Land boundary: 238 km with North Korea
_#_Coastline: 2,413 km
_#_Maritime claims:
Continental shelf: not specific
Territorial sea: 12 nm (3 nm in the Korea Strait)
_#_Disputes: Demarcation Line with North Korea; Liancourt Rocks
claimed by Japan
_#_Climate: temperate, with rainfall heavier in summer than winter
_#_Terrain: mostly hills and mountains; wide coastal plains in west
and south
_#_Natural resources: coal, tungsten, graphite, molybdenum, lead,
hydropower
_#_Land use: arable land 21%; permanent crops 1%; meadows and pastures
1%; forest and woodland 67%; other 10%; includes irrigated 12%
_#_Environment: occasional typhoons bring high winds and floods;
earthquakes in southwest; air pollution in large cities
_#_Notes: strategic location along the Korea Strait, Sea of Japan, and
Yellow Sea
_#_Total area: 17,820 km2; land area: 17,820 km2
_#_Comparative area: slightly smaller than New Jersey
_#_Land boundaries: 462 km total; Iraq 240 km, Saudi Arabia 222 km
_#_Coastline: 499 km
_#_Maritime claims:
Continental shelf: not specific;
Territorial sea: 12 nm
_#_Disputes: Iraqi forces invaded and occupied Kuwait from
2 August 1990 until 27 February 1991; in April 1991 official Iraqi
acceptance of UN Security Council Resolution 687, which demands that Iraq
accept its internationally recognized border with Kuwait, ended earlier
claims to Bubiyan and Warbah Islands or to all of Kuwait; ownership
of Qaruh and Umm al Maradim Islands disputed by Saudi Arabia
_#_Climate: dry desert; intensely hot summers; short, cool winters
_#_Terrain: flat to slightly undulating desert plain
_#_Natural resources: petroleum, fish, shrimp, natural gas
_#_Land use: arable land NEGL%; permanent crops 0%; meadows and
pastures 8%; forest and woodland NEGL%; other 92%; includes irrigated
NEGL%
_#_Environment: some of world''s largest and most sophisticated
desalination facilities provide most of water; air and water pollution;
desertification
_#_Note: strategic location at head of Persian Gulf
_#_Total area: 236,800 km2; land area: 230,800 km2
_#_Comparative area: slightly larger than Utah
_#_Land boundaries: 5,083 km total; Burma 235 km, Cambodia 541 km,
China 423 km, Thailand 1,754 km, Vietnam 2,130 km
_#_Coastline: none--landlocked
_#_Maritime claims: none--landlocked
_#_Disputes: boundary dispute with Thailand
_#_Climate: tropical monsoon; rainy season (May to November); dry
season (December to April)
_#_Terrain: mostly rugged mountains; some plains and plateaus
_#_Natural resources: timber, hydropower, gypsum, tin, gold,
gemstones
_#_Land use: arable land 4%; permanent crops NEGL%; meadows and
pastures 3%; forest and woodland 58%; other 35%; includes irrigated 1%
_#_Environment: deforestation; soil erosion; subject to floods
_#_Note: landlocked
_#_Total area: 10,400 km2; land area: 10,230 km2
_#_Comparative area: about 0.8 times the size of Connecticut
_#_Land boundaries: 454 km total; Israel 79 km, Syria 375 km
_#_Coastline: 225 km
_#_Maritime claims:
Territorial sea: 12 nm
_#_Disputes: separated from Israel by the 1949 Armistice Line;
Israeli troops in southern Lebanon since June 1982; Syrian troops in
northern Lebanon since October 1976
_#_Climate: Mediterranean; mild to cool, wet winters with hot, dry
summers
_#_Terrain: narrow coastal plain; Al Biqa (Bekaa Valley)
separates Lebanon and Anti-Lebanon Mountains
_#_Natural resources: limestone, iron ore, salt; water-surplus state
in a water-deficit region
_#_Land use: arable land 21%; permanent crops 9%; meadows and pastures
1%; forest and woodland 8%; other 61%; includes irrigated 7%
_#_Environment: rugged terrain historically helped isolate, protect,
and develop numerous factional groups based on religion, clan, ethnicity;
deforestation; soil erosion; air and water pollution; desertification
_#_Note: Nahr al Litani only major river in Near East
not crossing an international boundary
_#_Total area: 30,350 km2; land area: 30,350 km2
_#_Comparative area: slightly larger than Maryland
_#_Land boundary: 909 km with South Africa
_#_Coastline: none--landlocked
_#_Maritime claims: none--landlocked
_#_Climate: temperate; cool to cold, dry winters; hot, wet summers
_#_Terrain: mostly highland with some plateaus, hills, and mountains
_#_Natural resources: some diamonds and other minerals, water,
agricultural and grazing land
_#_Land use: arable land 10%; permanent crops 0%; meadows and
pastures 66%; forest and woodland 0%; other 24%
_#_Environment: population pressure forcing settlement in marginal
areas results in overgrazing, severe soil erosion, soil exhaustion;
desertification
_#_Note: landlocked; surrounded by South Africa; Highlands Water
Project will control, store, and redirect water to South Africa
_#_Total area: 111,370 km2; land area: 96,320 km2
_#_Comparative area: slightly larger than Tennessee
_#_Land boundaries: 1,585 km total; Guinea 563 km, Ivory Coast 716 km,
Sierra Leone 306 km
_#_Coastline: 579 km
_#_Maritime claims:
Continental shelf: 200 m (depth) or to depth of exploitation;
Territorial sea: 200 nm
_#_Climate: tropical; hot, humid; dry winters with hot days and cool
to cold nights; wet, cloudy summers with frequent heavy showers
_#_Terrain: mostly flat to rolling coastal plains rising to rolling
plateau and low mountains in northeast
_#_Natural resources: iron ore, timber, diamonds, gold
_#_Land use: arable land 1%; permanent crops 3%; meadows and pastures
2%; forest and woodland 39%; other 55%; includes irrigated NEGL%
_#_Environment: West Africa''s largest tropical rain forest, subject to
deforestation
_#_Total area: 1,759,540 km2; land area: 1,759,540 km2
_#_Comparative area: slightly larger than Alaska
_#_Land boundaries: 4,383 km total; Algeria 982 km, Chad 1,055 km,
Egypt 1,150 km, Niger 354 km, Sudan 383 km, Tunisia 459 km
_#_Coastline: 1,770 km
_#_Maritime claims:
Territorial sea: 12 nm;
Gulf of Sidra closing line: 32o 30%19 N
_#_Disputes: claims and occupies the 100,000 km2 Aozou Strip in
northern Chad; maritime boundary dispute with Tunisia; Libya claims about
19,400 km2 in northern Niger; Libya claims about 19,400 km2 in
southeastern Algeria
_#_Climate: Mediterranean along coast; dry, extreme desert interior
_#_Terrain: mostly barren, flat to undulating plains, plateaus,
depressions
_#_Natural resources: crude oil, natural gas, gypsum
_#_Land use: arable land 1%; permanent crops 0%; meadows and pastures
8%; forest and woodland 0%; other 91%; includes irrigated NEGL%
_#_Environment: hot, dry, dust-laden ghibli is a southern wind lasting
one to four days in spring and fall; desertification; sparse natural
surface-water resources
_#_Note: the Great Manmade River Project, the largest water
development scheme in the world, is being built to bring water from large
aquifers under the Sahara to coastal cities
_#_Total area: 160 km2; land area: 160 km2
_#_Comparative area: about 0.9 times the size of Washington, DC
_#_Land boundaries: 78 km total; Austria 37 km, Switzerland 41 km
_#_Coastline: none--landlocked
_#_Maritime claims: none--landlocked
_#_Climate: continental; cold, cloudy winters with frequent snow or
rain; cool to moderately warm, cloudy, humid summers
_#_Terrain: mostly mountainous (Alps) with Rhine Valley in western
third
_#_Natural resources: hydroelectric potential
_#_Land use: arable land 25%; permanent crops 0%; meadows and pastures
38%; forest and woodland 19%; other 18%
_#_Environment: variety of microclimatic variations based on elevation
_#_Note: landlocked
_#_Total area: 2,586 km2; land area: 2,586 km2
_#_Comparative area: slightly smaller than Rhode Island
_#_Land boundaries: 359 km total; Belgium 148 km, France 73 km,
Germany 138 km
_#_Coastline: none--landlocked
_#_Maritime claims: none--landlocked
_#_Climate: modified continental with mild winters, cool summers
_#_Terrain: mostly gently rolling uplands with broad, shallow valleys;
uplands to slightly mountainous in the north; steep slope down to Moselle
floodplain in the southeast
_#_Natural resources: iron ore (no longer exploited)
_#_Land use: arable land 24%; permanent crops 1%; meadows and pastures
20%; forest and woodland 21%; other 34%
_#_Environment: deforestation
_#_Note: landlocked
_#_Total area: 1,565,000 km2; land area: 1,565,000 km2
_#_Comparative area: slightly larger than Alaska
_#_Land boundaries: 8,114 km total; China 4,673 km, USSR 3,441 km
_#_Coastline: none--landlocked
_#_Maritime claims: none--landlocked
_#_Climate: desert; continental (large daily and seasonal temperature
ranges)
_#_Terrain: vast semidesert and desert plains; mountains in west and
southwest; Gobi Desert in southeast
_#_Natural resources: oil, coal, copper, molybdenum, tungsten,
phosphates, tin, nickel, zinc, wolfram, fluorspar, gold
_#_Land use: arable land 1%; permanent crops 0%; meadows and pastures
79%; forest and woodland 10%; other 10%; includes irrigated NEGL%
_#_Environment: harsh and rugged
_#_Note: landlocked; strategic location between China and Soviet Union
_#_Total area: 100 km2; land area: 100 km2
_#_Comparative area: about 0.6 times the size of Washington, DC
_#_Land boundaries: none
_#_Coastline: 40 km
_#_Maritime claims:
Exclusive fishing zone: 200 nm;
Territorial sea: 3 nm
_#_Climate: tropical; little daily or seasonal temperature variation
_#_Terrain: volcanic islands, mostly mountainous, with small coastal
lowland
_#_Natural resources: negligible
_#_Land use: arable land 20%; permanent crops 0%; meadows and pastures
10%; forest and woodland 40%; other 30%
_#_Environment: subject to severe hurricanes from June to November
_#_Note: located 400 km southeast of Puerto Rico in the Caribbean Sea
_#_Total area: 446,550 km2; land area: 446,300 km2
_#_Comparative area: slightly larger than California
_#_Land boundaries: 2,002 km total; Algeria 1,559 km, Western
Sahara 443 km
_#_Coastline: 1,835 km
_#_Maritime claims:
Contiguous zone: 24 nm;
Continental shelf: 200 m (depth) or to depth of exploitation;
Exclusive economic zone: 200 nm;
Territorial sea: 12 nm
_#_Disputes: claims and administers Western Sahara, but sovereignty is
unresolved; armed conflict in Western Sahara; Spain controls five
places of sovereignty (plazas de soberania) on and off the coast
of Morocco--the coastal enclaves of Ceuta and Melilla, which Morocco
contests, and the islands of Penon de Alhucemas, Penon
de Velez de la Gomera, and Islas Chafarinas
_#_Climate: Mediterranean, becoming more extreme in the interior
_#_Terrain: mostly mountains with rich coastal plains
_#_Natural resources: phosphates, iron ore, manganese, lead,
zinc, fish, salt
_#_Land use: arable land 18%; permanent crops 1%; meadows and pastures
28%; forest and woodland 12%; other 41%; includes irrigated 1%
_#_Environment: northern mountains geologically unstable and subject
to earthquakes; desertification
_#_Note: strategic location along Strait of Gibraltar
_#_Total area: 801,590 km2; land area: 784,090 km2
_#_Comparative area: slightly less than twice the size of California
_#_Land boundaries: 4,571 km total; Malawi 1,569 km, South Africa
491 km, Swaziland 105 km, Tanzania 756 km, Zambia 419 km, Zimbabwe
1,231 km
_#_Coastline: 2,470 km
_#_Maritime claims:
Exclusive economic zone: 200 nm;
Territorial sea: 12 nm
_#_Climate: tropical to subtropical
_#_Terrain: mostly coastal lowlands, uplands in center, high plateaus
in northwest, mountains in west
_#_Natural resources: coal, titanium
_#_Land use: arable land 4%; permanent crops NEGL%; meadows and
pastures 56%; forest and woodland 20%; other 20%; includes irrigated
NEGL%
_#_Environment: severe drought and floods occur in south;
desertification
_#_Total area: 824,290 km2; land area: 823,290 km2
_#_Comparative area: slightly more than half the size of Alaska
_#_Land boundaries: 3,935 km total; Angola 1,376 km, Botswana
1,360 km, South Africa 966 km, Zambia 233 km
_#_Coastline: 1,489 km
_#_Maritime claims:
Exclusive fishing zone: 200 nm;
Territorial sea: 12 nm
_#_Disputes: short section of boundary with Botswana is indefinite;
quadripoint with Botswana, Zambia, and Zimbabwe is in disagreement;
claim by Namibia to Walvis Bay and 12 offshore islands administered
by South Africa
_#_Climate: desert; hot, dry; rainfall sparse and erratic
_#_Terrain: mostly high plateau; Namib Desert along coast; Kalahari
Desert in east
_#_Natural resources: diamonds, copper, uranium, gold, lead, tin,
zinc, salt, vanadium, natural gas, fish; suspected deposits of oil,
natural gas, coal, and iron ore
_#_Land use: arable land 1%; permanent crops NEGL%; meadows and
pastures 64%; forest and woodland 22%; other 13%; includes irrigated
NEGL%
_#_Environment: inhospitable with very limited natural water
resources; desertification
_#_Note: Walvis Bay area is an exclave of South Africa in Namibia
_#_Total area: 21 km2; land area: 21 km2
_#_Comparative area: about 0.1 times the size of Washington, DC
_#_Land boundaries: none
_#_Coastline: 30 km
_#_Maritime claims:
Exclusive fishing zone: 200 nm;
Territorial sea: 12 nm
_#_Climate: tropical; monsoonal; rainy season (November to February)
_#_Terrain: sandy beach rises to fertile ring around raised coral reefs
with phosphate plateau in center
_#_Natural resources: phosphates
_#_Land use: arable land 0%; permanent crops 0%; meadows and pastures
0%; forest and woodland 0%; other 100%
_#_Environment: only 53 km south of Equator
_#_Note: Nauru is one of the three great phosphate rock islands in
the Pacific Ocean--the others are Banaba (Ocean Island) in Kiribati and
Makatea in French Polynesia
_#_Total area: 5.2 km2; land area: 5.2 km2
_#_Comparative area: about nine times the size of The Mall in
Washington, DC
_#_Land boundaries: none
_#_Coastline: 8 km
_#_Maritime claims:
Contiguous zone: 12 nm;
Continental shelf: 200 m (depth);
Exclusive economic zone: 200 nm;
Territorial sea: 12 nm
_#_Disputes: claimed by Haiti
_#_Climate: marine, tropical
_#_Terrain: raised coral and limestone plateau, flat to undulating;
ringed by vertical white cliffs (9 to 15 meters high)
_#_Natural resources: guano
_#_Land use: arable land 0%; permanent crops 0%; meadows and pastures
10%; forest and woodland 0%; other 90%
_#_Environment: mostly exposed rock, but enough grassland to support
goat herds; dense stands of fig-like trees, scattered cactus
_#_Note: strategic location between Cuba, Haiti, and Jamaica in the
Caribbean Sea; 160 km south of the US Naval Base at Guantanamo, Cuba
_#_Total area: 140,800 km2; land area: 136,800 km2
_#_Comparative area: slightly larger than Arkansas
_#_Land boundaries: 2,926 km total; China 1,236 km, India 1,690 km
_#_Coastline: none--landlocked
_#_Maritime claims: none--landlocked
_#_Climate: varies from cool summers and severe winters in north to
subtropical summers and mild winter in south
_#_Terrain: Terai or flat river plain of the Ganges in south, central
hill region, rugged Himalayas in north
_#_Natural resources: quartz, water, timber, hydroelectric potential,
scenic beauty; small deposits of lignite, copper, cobalt, iron ore
_#_Land use: arable land 17%; permanent crops NEGL%; meadows and
pastures 13%; forest and woodland 33%; other 37%; includes irrigated 2%
_#_Environment: contains eight of world''s 10 highest peaks;
deforestation; soil erosion; water pollution
_#_Note: landlocked; strategic location between China and India
_#_Total area: 37,290 km2; land area: 33,940 km2
_#_Comparative area: slightly less than twice the size of New Jersey
_#_Land boundaries: 1,027 km total; Belgium 450 km, Germany 577 km
_#_Coastline: 451 km
_#_Maritime claims:
Continental shelf: not specific;
Territorial sea: 12 nm
_#_Climate: temperate; marine; cool summers and mild winters
_#_Terrain: mostly coastal lowland and reclaimed land (polders); some
hills in southeast
_#_Natural resources: natural gas, crude oil, fertile soil
_#_Land use: arable land 25%; permanent crops 1%; meadows and pastures
34%; forest and woodland 9%; other 31%; includes irrigated 15%
_#_Environment: 27% of the land area is below sea level and protected
from the North Sea by dikes
_#_Note: located at mouths of three major European rivers (Rhine,
Maas or Meuse, Schelde)
_#_Total area: 960 km2; land area: 960 km2; includes Bonaire,
Curacao, Saba, Sint Eustatius, and Sint Maarten (Dutch part of the
island of Saint Martin)
_#_Comparative area: slightly less than 5.5 times the size of
Washington, DC
_#_Land boundaries: none
_#_Coastline: 364 km
_#_Maritime claims:
Exclusive fishing zone: 12 nm;
Territorial sea: 12 nm
_#_Climate: tropical; modified by northeast trade winds
_#_Terrain: generally hilly, volcanic interiors
_#_Natural resources: phosphates (Curacao only), salt (Bonaire only)
_#_Land use: arable land 8%; permanent crops 0%; meadows and pastures
0%; forest and woodland 0%; other 92%
_#_Environment: Curacao and Bonaire are south of Caribbean hurricane
belt, so rarely threatened; Sint Maarten, Saba, and Sint Eustatius are
subject to hurricanes from July to October
_#_Note: consists of two island groups--Curacao and Bonaire
are located off the coast of Venezuela,','3cd7baa07e949eae55515fd00abcb9c7a1ffbd5fe5bc6bfb05eb2056a885520b','internet-archive','theciaworldfactb00025gut','txt','84185fe9df79da427349cc1598fd3f69814a2085a9fc1fe0508a3fae0a870f84','https://archive.org/download/theciaworldfactb00025gut/25.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2ffe0935bffa86eb78fe34fb1e400a0eebd35b082cad51433ce0ec88744b889a',1991,'FR','France','geography',96,'and Sint Maarten, Saba, and Sint
Eustatius lie 800 km to the north
_#_Total area: 19,060 km2; land area: 18,760 km2
_#_Comparative area: slightly smaller than New Jersey
_#_Land boundaries: none
_#_Coastline: 2,254 km
_#_Maritime claims:
Exclusive economic zone: 200 nm;
Territorial sea: 12 nm
_#_Climate: tropical; modified by southeast trade winds; hot, humid
_#_Terrain: coastal plains with interior mountains
_#_Natural resources: nickel, chrome, iron, cobalt, manganese, silver,
gold, lead, copper
_#_Land use: arable land NEGL%; permanent crops NEGL%; meadows and
pastures 14%; forest and woodland 51%; other 35%
_#_Environment: typhoons most frequent from November to March
_#_Note: located 1,750 km east of Australia in the South Pacific
Ocean
_#_Total area: 268,680 km2; land area: 268,670 km2; includes
Antipodes Islands, Auckland Islands, Bounty Islands, Campbell Island,
Chatham Islands, and Kermadec Islands
_#_Comparative area: about the size of Colorado
_#_Land boundaries: none
_#_Coastline: 15,134 km
_#_Maritime claims:
Continental shelf: edge of continental margin or 200 nm;
Exclusive economic zone: 200 nm;
Territorial sea: 12 nm
_#_Disputes: territorial claim in Antarctica (Ross Dependency)
_#_Climate: temperate with sharp regional contrasts
_#_Terrain: predominately mountainous with some large coastal plains
_#_Natural resources: natural gas, iron ore, sand, coal, timber,
hydropower, gold, limestone
_#_Land use: arable land 2%; permanent crops 0%; meadows and pastures
53%; forest and woodland 38%; other 7%; includes irrigated 1%
_#_Environment: earthquakes are common, though usually not severe
_#_Total area: 129,494 km2; land area: 120,254 km2
_#_Comparative area: slightly larger than New York State
_#_Land boundaries: 1,231 km total; Costa Rica 309 km, Honduras 922 km
_#_Coastline: 910 km
_#_Maritime claims:
Contiguous zone: 25 nm security zone (status of claim uncertain);
Continental shelf: not specified;
Territorial sea: 200 nm
_#_Disputes: territorial disputes with Colombia over the Archipelago
de San Andres y Providencia and Quita Sueno Bank; unresolved maritime
boundary in Golfo de Fonseca
_#_Climate: tropical in lowlands, cooler in highlands
_#_Terrain: extensive Atlantic coastal plains rising to central
interior mountains; narrow Pacific coastal plain interrupted by volcanoes
_#_Natural resources: gold, silver, copper, tungsten, lead, zinc,
timber, fish
_#_Land use: arable land 9%; permanent crops 1%; meadows and pastures
43%; forest and woodland 35%; other 12%; including irrigated 1%
_#_Environment: subject to destructive earthquakes, volcanoes,
landslides, and occasional severe hurricanes; deforestation; soil
erosion; water pollution
_#_Total area: 1,267,000 km2; land area: 1,266,700 km2
_#_Comparative area: slightly less than twice the size of Texas
_#_Land boundaries: 5,697 km total; Algeria 956 km, Benin 266 km,
Burkina 628 km, Chad 1,175 km, Libya 354 km, Mali 821 km, Nigeria 1,497
km
_#_Coastline: none--landlocked
_#_Maritime claims: none--landlocked
_#_Disputes: Libya claims about 19,400 km2 in northern Niger;
demarcation of international boundaries in Lake Chad, the lack of which
has led to border incidents in the past, is completed and awaiting
ratification by Cameroon, Chad, Niger, and Nigeria; Burkina and Mali are
proceeding with boundary demarcation, including the tripoint with Niger
_#_Climate: desert; mostly hot, dry, dusty; tropical in extreme south
_#_Terrain: predominately desert plains and sand dunes; flat to
rolling plains in south; hills in north
_#_Natural resources: uranium, coal, iron ore, tin, phosphates
_#_Land use: arable land 3%; permanent crops 0%; meadows and pastures
7%; forest and woodland 2%; other 88%; includes irrigated NEGL%
_#_Environment: recurrent drought and desertification severely
affecting marginal agricultural activities; overgrazing; soil erosion
_#_Note: landlocked
_#_Total area: 923,770 km2; land area: 910,770 km2
_#_Comparative area: slightly more than twice the size of California
_#_Land boundaries: 4,047 km total; Benin 773 km, Cameroon 1,690 km,
Chad 87 km, Niger 1,497 km
_#_Coastline: 853 km
_#_Maritime claims:
Continental shelf: 200 m (depth) or to depth of exploitation;
Exclusive economic zone: 200 nm;
Territorial sea: 30 nm
_#_Disputes: demarcation of international boundaries in Lake
Chad, the lack of which has led to border incidents in the past, is
completed and awaiting ratification by Cameroon, Chad, Niger, and
Nigeria; Nigerian proposals to reopen maritime boundary negotiations and
redemarcate the entire land boundary have been rejected by Cameroon
_#_Climate: varies--equatorial in south, tropical in center, arid in
north
_#_Terrain: southern lowlands merge into central hills and plateaus;
mountains in southeast, plains in north
_#_Natural resources: crude oil, tin, columbite, iron ore, coal,
limestone, lead, zinc, natural gas
_#_Land use: arable land 31%; permanent crops 3%; meadows and pastures
23%; forest and woodland 15%; other 28%; includes irrigated NEGL%
_#_Environment: recent droughts in north severely affecting marginal
agricultural activities; desertification; soil degradation, rapid
deforestation
_#_Total area: 260 km2; land area: 260 km2
_#_Comparative area: slightly less than 1.5 times the size of
Washington, DC
_#_Land boundaries: none
_#_Coastline: 64 km
_#_Maritime claims:
Exclusive economic zone: 200 nm;
Territorial sea: 12 nm
_#_Climate: tropical; modified by southeast trade winds
_#_Terrain: steep limestone cliffs along coast, central plateau
_#_Natural resources: fish, arable land
_#_Land use: arable land 61%; permanent crops 4%; meadows and pastures
4%; forest and woodland 19%; other 12%
_#_Environment: subject to typhoons
_#_Note: one of world''s largest coral islands; located about 460 km
east of Tonga
_#_Total area: 34.6 km2; land area: 34.6 km2
_#_Comparative area: about 0.2 times the size of Washington, DC
_#_Land boundaries: none
_#_Coastline: 32 km
_#_Maritime claims:
Exclusive fishing zone: 200 nm;
Territorial sea: 3 nm
_#_Climate: subtropical, mild, little seasonal temperature variation
_#_Terrain: volcanic formation with mostly rolling plains
_#_Natural resources: fish
_#_Land use: arable land 0%; permanent crops 0%; meadows and pastures
25%; forest and woodland 0%; other 75%
_#_Environment: subject to typhoons (especially May to July)
_#_Note: located 1,575 km east of Australia in the South Pacific
Ocean
_#_Total area: 477 km2; land area: 477 km2; includes Saipan, Rota, and
Tinian
_#_Comparative area: slightly more than 2.5 times the size of
Washington, DC
_#_Land boundaries: none
_#_Coastline: 1,482 km
_#_Maritime claims:
Contiguous zone: 12 nm;
Continental shelf: 200 m (depth);
Exclusive economic zone: 200 nm;
Territorial sea: 3 nm
_#_Climate: tropical marine; moderated by northeast trade winds,
little seasonal temperature variation; dry season December to July, rainy
season July to October
_#_Terrain: southern islands are limestone with level terraces and
fringing coral reefs; northern islands are volcanic; highest elevation is
471 meters (Mt. Tagpochu on Saipan)
_#_Natural resources: arable land, fish
_#_Land use: arable land 1%; permanent crops NA%; meadows and pastures
19%; forest and woodland NA%; other NA%
_#_Environment: Mt. Pagan is an active volcano (last erupted in
October 1988); subject to typhoons during the rainy season
_#_Note: strategic location 5,635 km west-southwest of Honolulu in the
North Pacific Ocean, about three-quarters of the way between Hawaii and
the Philippines
_#_Total area: 324,220 km2; land area: 307,860 km2
_#_Comparative area: slightly larger than New Mexico
_#_Land boundaries: 2,544 km total; Finland 729 km, Sweden 1,619 km,
USSR 196 km
_#_Coastline: 21,925 km (3,419 km mainland; 2,413 km large islands;
16,093 km long fjords, numerous small islands, and minor indentations)
_#_Maritime claims:
Contiguous zone: 10 nm;
Continental shelf: to depth of exploitation;
Exclusive economic zone: 200 nm;
Territorial sea: 4 nm
_#_Disputes: maritime boundary dispute with USSR; territorial claim in
Antarctica (Queen Maud Land); Denmark has challenged Norway''s maritime
claims beween Greenland and Jan Mayen
_#_Climate: temperate along coast, modified by North Atlantic Current;
colder interior; rainy year-round on west coast
_#_Terrain: glaciated; mostly high plateaus and rugged mountains
broken by fertile valleys; small, scattered plains; coastline deeply
indented by fjords; arctic tundra in north
_#_Natural resources: crude oil, copper, natural gas, pyrites,
nickel, iron ore, zinc, lead, fish, timber, hydropower
_#_Land use: arable land 3%; permanent crops 0%; meadows and pastures
NEGL%; forest and woodland 27%; other 70%; includes irrigated NEGL%
_#_Environment: air and water pollution; acid rain
_#_Note: strategic location adjacent to sea lanes and air routes in
North Atlantic; one of most rugged and longest coastlines in world;
Norway and Turkey only NATO members having a land boundary with the USSR
_#_Total area: 212,460 km2; land area: 212,460 km2
_#_Comparative area: slightly smaller than Kansas
_#_Land boundaries: 1,374 km total; Saudi Arabia 676 km, UAE 410 km,
Yemen 288 km
_#_Coastline: 2,092 km
_#_Maritime claims:
Continental shelf: to be defined;
Exclusive economic zone: 200 nm;
Territorial sea: 12 nm
_#_Disputes: Administrative Line with Yemen; no defined boundary with
most of UAE, Administrative Line in far north
_#_Climate: dry desert; hot, humid along coast; hot, dry interior;
strong southwest summer monsoon (May to September) in far south
_#_Terrain: vast central desert plain, rugged mountains in north and
south
_#_Natural resources: crude oil, copper, asbestos, some marble,
limestone, chromium, gypsum, natural gas
_#_Land use: arable land NEGL%; permanent crops NEGL%; meadows and
pastures 5%; forest and woodland 0%; other 95%; includes
irrigated NEGL%
_#_Environment: summer winds often raise large sandstorms and
duststorms in interior; sparse natural freshwater resources
_#_Note: strategic location with small foothold on Musandam
Peninsula controlling Strait of Hormuz (17% of world''s oil production
transits this point going from Persian Gulf to Arabian Sea)
_#_Total area: 458 km2; land area: 458 km2
_#_Comparative area: slightly more than 2.5 times the size of
Washington, DC
_#_Land boundaries: none
_#_Coastline: 1,519 km
_#_Maritime claims:
Contiguous zone: 12 nm;
Continental shelf: 200 m (depth);
Exclusive fishing zone: 200 nm;
Territorial sea: 3 nm
_#_Climate: wet season May to November; hot and humid
_#_Terrain: islands vary geologically from the high mountainous main
island of Babelthuap to low, coral islands usually fringed by large
barrier reefs
_#_Natural resources: forests, minerals (especially gold), marine
products; deep-seabed minerals
_#_Land use: arable land NA%; permanent crops NA%; meadows and
pastures NA%; forest and woodland NA%; other NA%
_#_Environment: subject to typhoons from June to December; archipelago
of six island groups totaling over 200 islands in the Caroline chain
_#_Note: important location 850 km southeast of the Philippines;
includes World War II battleground of Peleliu and world-famous rock
islands
_#_Total area: 165,384,000 km2; includes Arafura Sea, Banda Sea,
Bellingshausen Sea, Bering Sea, Bering Strait, Coral Sea, East China Sea,
Gulf of Alaska, Makassar Strait, Philippine Sea, Ross Sea, Sea of Japan,
Sea of Okhotsk, South China Sea, Tasman Sea, and other tributary water
bodies
_#_Comparative area: slightly less than 18 times the size of the US;
the largest ocean (followed by the Atlantic Ocean, Indian Ocean, and
Arctic Ocean); covers about one-third of the global surface; larger than
the total land area of the world
_#_Coastline: 135,663 km
_#_Climate: the western Pacific is monsoonal--a rainy season occurs
during the summer months, when moisture-laden winds blow from the ocean
over the land, and a dry season during the winter months, when dry winds
blow from the Asian land mass back to the ocean
_#_Terrain: surface in the northern Pacific dominated by a clockwise,
warm water gyre (broad, circular system of currents) and in the southern
Pacific by a counterclockwise, cool water gyre; sea ice occurs in the
Bering Sea and
Sea of Okhotsk during winter and reaches maximum northern extent from
Antarctica in October; the ocean floor in the eastern Pacific is
dominated by the East Pacific Rise, while the western Pacific is
dissected by deep trenches; the world''s greatest depth is 10,924 meters
in the Marianas Trench
_#_Natural resources: oil and gas fields, polymetallic nodules, sand
and gravel aggregates, placer deposits, fish
_#_Environment: endangered marine species include the dugong, sea
lion, sea otter, seals, turtles, and whales; oil pollution in Philippine
Sea and South China Sea; dotted with low coral islands and rugged
volcanic islands in the southwestern Pacific Ocean; subject to tropical
cyclones (typhoons) in southeast and east Asia from May to December (most
frequent from July to October); tropical cyclones (hurricanes) may form
south of Mexico and strike Central America and Mexico from June to
October (most common in August and September); southern shipping lanes
subject to icebergs from Antarctica; occasional El Nino phenomenon
occurs off the coast of Peru when the trade winds slacken and the warm
Equatorial Countercurrent moves south, which kills the plankton that is
the primary food source for anchovies; consequently, the anchovies move
to better feeding grounds, causing resident marine birds to starve by the
thousands because of their lost food source
_#_Note: the major choke points are the Bering Strait, Panama
Canal, Luzon Strait, and the Singapore Strait; the Equator divides the
Pacific Ocean into the North Pacific Ocean and the South Pacific Ocean;
ships subject to superstructure icing in extreme north from October to
May and in extreme south from May to October; persistent fog in the
northern Pacific from June to December is a hazard to shipping;
surrounded by a zone of violent volcanic and earthquake activity
sometimes referred to as the Pacific Ring of Fire
_#_Total area: 803,940 km2; land area: 778,720 km2
_#_Comparative area: slightly less than twice the size of California
_#_Land boundaries: 6,774 km total; Afghanistan 2,430 km, China
523 km, India 2,912 km, Iran 909 km
_#_Coastline: 1,046 km
_#_Maritime claims:
Contiguous zone: 24 nm;
Continental shelf: edge of continental margin or 200 nm;
Exclusive economic zone: 200 nm;
Territorial sea: 12 nm
_#_Disputes: boundary with India; Pashtun question with Afghanistan;
Baloch question with Afghanistan and Iran; water sharing problems with
upstream riparian India over the Indus
_#_Climate: mostly hot, dry desert; temperate in northwest; arctic in
north
_#_Terrain: flat Indus plain in east; mountains in north and
northwest; Balochistan plateau in west
_#_Natural resources: land, extensive natural gas reserves, limited
crude oil, poor quality coal, iron ore, copper, salt, limestone
_#_Land use: arable land 26%; permanent crops NEGL%;
meadows and pastures 6%; forest and woodland 4%; other 64%; includes
irrigated 19%
_#_Environment: frequent earthquakes, occasionally severe especially
in north and west; flooding along the Indus after heavy rains (July and
August); deforestation; soil erosion; desertification; water logging
_#_Note: controls Khyber Pass and Malakand Pass, traditional
invasion routes between Central Asia and the Indian Subcontinent
_#_Total area: 11.9 km2; land area: 11.9 km2
_#_Comparative area: about 20 times the size of The Mall in
Washington, DC
_#_Land boundaries: none
_#_Coastline: 14.5 km
_#_Maritime claims:
Contiguous zone: 12 nm;
Continental shelf: 200 m (depth);
Exclusive economic zone: 200 nm;
Territorial sea: 12 nm
_#_Climate: equatorial, hot, and very rainy
_#_Terrain: low, with maximum elevations of about 2 meters
_#_Natural resources: none
_#_Land use: arable land 0%; permanent crops 0%; meadows and pastures
0%; forest and woodland 100%; other 0%
_#_Environment: about 50 islets covered with dense vegetation,
coconut trees, and balsa-like trees up to 30 meters tall
_#_Note: located 1,600 km south-southwest of Honolulu in the North
Pacific Ocean, almost halfway between Hawaii and American Samoa
_#_Total area: 78,200 km2; land area: 75,990 km2
_#_Comparative area: slightly smaller than South Carolina
_#_Land boundaries: 555 km total; Colombia 225 km, Costa Rica 330 km
_#_Coastline: 2,490 km
_#_Maritime claims:
Territorial sea: 200 nm
_#_Climate: tropical; hot, humid, cloudy; prolonged rainy season (May
to January), short dry season (January to May)
_#_Terrain: interior mostly steep, rugged mountains and dissected,
upland plains; coastal areas largely plains and rolling hills
_#_Natural resources: copper, mahogany forests, shrimp
_#_Land use: arable land 6%; permanent crops 2%; meadows and pastures
15%; forest and woodland 54%; other 23%; includes irrigated NEGL%
_#_Environment: dense tropical forest in east and northwest
_#_Note: strategic location on eastern end of isthmus forming
land bridge connecting North and South America; controls Panama Canal
that links North Atlantic Ocean via Caribbean Sea with North Pacific
Ocean
_#_Total area: 461,690 km2; land area: 451,710 km2
_#_Comparative area: slightly larger than California
_#_Land boundary: 820 km with Indonesia
_#_Coastline: 5,152 km
_#_Maritime claims: (measured from claimed archipelagic baselines);
Continental shelf: 200 m (depth) or to depth of exploitation;
Exclusive economic zone: 200 nm;
Territorial sea: 12 nm
_#_Climate: tropical; northwest monsoon (December to March), southeast
monsoon (May to October); slight seasonal temperature variation
_#_Terrain: mostly mountains with coastal lowlands and rolling
foothills
_#_Natural resources: gold, copper, silver, natural gas, timber,
oil potential
_#_Land use: arable land NEGL%; permanent crops 1%; meadows and
pastures NEGL%; forest and woodland 71%; other 28%
_#_Environment: one of world''s largest swamps along southwest coast;
some active volcanos; frequent earthquakes
_#_Note: shares island of New Guinea with Indonesia
_#_Total area: undetermined
_#_Comparative area: undetermined
_#_Land boundaries: none
_#_Coastline: 518 km
_#_Maritime claims: undetermined
_#_Disputes: occupied by China, but claimed by Taiwan and Vietnam
_#_Climate: tropical
_#_Terrain: undetermined
_#_Natural resources: none
_#_Land use: arable land 0%; permanent crops 0%; meadows and pastures
0%; forest and woodland 0%; other 100%
_#_Environment: subject to typhoons
_#_Note: located 400 km east of Vietnam in the South China Sea
about one-third of the way between Vietnam and the Philippines
_#_Total area: 406,750 km2; land area: 397,300 km2
_#_Comparative area: slightly smaller than California
_#_Land boundaries: 3,920 km total; Argentina 1,880 km, Bolivia
750 km, Brazil 1,290 km
_#_Coastline: none--landlocked
_#_Maritime claims: none--landlocked
_#_Disputes: short section of the boundary with Brazil (just west of
Guaira Falls on the Rio Parana) has not been determined
_#_Climate: varies from temperate in east to semiarid in far west
_#_Terrain: grassy plains and wooded hills east of Rio Paraguay;
Gran Chaco region west of Rio Paraguay mostly low, marshy plain near
the river, and dry forest and thorny scrub elsewhere
_#_Natural resources: iron ore, manganese, limestone, hydropower,
timber
_#_Land use: arable land 20%; permanent crops 1%; meadows and
pastures 39%; forest and woodland 35%; other 5%; includes irrigated
NEGL%
_#_Environment: local flooding in southeast (early September to June);
poorly drained plains may become boggy (early October to June)
_#_Note: landlocked; buffer between Argentina and Brazil
_#_Total area: 1,285,220 km2; land area: 1,280,000 km2
_#_Comparative area: slightly smaller than Alaska
_#_Land boundaries: 6,940 km total; Bolivia 900 km, Brazil 1,560 km,
Chile 160 km, Colombia 2,900 km, Ecuador 1,420 km
_#_Coastline: 2,414 km
_#_Maritime claims:
Territorial sea: 200 nm
_#_Disputes: two sections of the boundary with Ecuador are in dispute
_#_Climate: varies from tropical in east to dry desert in west
_#_Terrain: western coastal plain (costa), high and rugged Andes in
center (sierra), eastern lowland jungle of Amazon Basin (selva)
_#_Natural resources: copper, silver, gold, petroleum, timber,
fish, iron ore, coal, phosphate, potash
_#_Land use: arable land 3%; permanent crops NEGL%; meadows and
pastures 21%; forest and woodland 55%; other 21%; includes irrigated
1%
_#_Environment: subject to earthquakes, tsunamis, landslides, mild
volcanic activity; deforestation; overgrazing; soil erosion;
desertification; air pollution in Lima
_#_Note: shares control of Lago Titicaca, world''s highest navigable
lake, with Bolivia
_#_Total area: 300,000 km2; land area: 298,170 km2
_#_Comparative area: slightly larger than Arizona
_#_Land boundaries: none
_#_Coastline: 36,289 km
_#_Maritime claims: (measured from claimed archipelagic baselines);
Continental shelf: to depth of exploitation;
Exclusive economic zone: 200 nm;
Territorial sea: irregular polygon extending up to 100 nm from
coastline as defined by 1898 treaty; since late 1970s has also claimed
polygonal-shaped area in South China Sea up to 285 nm in breadth
_#_Disputes: involved in a complex dispute over the Spratly Islands
with China, Malaysia, Taiwan, and Vietnam; claims Malaysian state of
Sabah
_#_Climate: tropical marine; northeast monsoon (November to April);
southwest monsoon (May to October)
_#_Terrain: mostly mountains with narrow to extensive coastal lowlands
_#_Natural resources: timber, crude oil, nickel, cobalt, silver,
gold, salt, copper
_#_Land use: arable land 26%; permanent crops 11%; meadows and
pastures 4%; forest and woodland 40%; other 19%; includes irrigated
5%
_#_Environment: astride typhoon belt, usually affected by 15 and
struck by five to six cyclonic storms per year; subject to landslides,
active volcanoes, destructive earthquakes, tsunami; deforestation; soil
erosion; water pollution
_#_Total area: 47 km2; land area: 47 km2
_#_Comparative area: about 0.3 times the size of Washington, DC
_#_Land boundaries: none
_#_Coastline: 51 km
_#_Maritime claims:
Exclusive fishing zone: 200 nm;
Territorial sea: 3 nm
_#_Climate: tropical, hot, humid, modified by southeast trade winds;
rainy season (November to March)
_#_Terrain: rugged volcanic formation; rocky coastline with cliffs
_#_Natural resources: miro trees (used for handicrafts), fish
_#_Land use: arable land NA%; permanent crops NA%; meadows and
pastures NA%; forest and woodland NA%; other NA%
_#_Environment: subject to typhoons (especially November to March)
_#_Note: located in the South Pacific Ocean about halfway between
Peru and New Zealand
_#_Total area: 312,680 km2; land area: 304,510 km2
_#_Comparative area: slightly smaller than New Mexico
_#_Land boundaries: 2,980 km total; Czechoslovakia 1,309 km,
Germany 456 km, USSR 1,215 km
_#_Coastline: 491 km
_#_Maritime claims:
Territorial sea: 12 nm
_#_Climate: temperate with cold, cloudy, moderately severe winters
with frequent precipitation; mild summers with frequent showers and
thundershowers
_#_Terrain: mostly flat plain, mountains along southern border
_#_Natural resources: coal, sulfur, copper, natural gas, silver,
lead, salt
_#_Land use: arable land 46%; permanent crops 1%; meadows and
pastures 13%; forest and woodland 28%; other 12%; includes irrigated
NEGL%
_#_Environment: plain crossed by a few north-flowing, meandering
streams; severe air and water pollution in south
_#_Note: historically, an area of conflict because of flat terrain
and the lack of natural barriers on the North European Plain
_#_Total area: 92,080 km2; land area: 91,640 km2; includes Azores and
Madeira Islands
_#_Comparative area: slightly smaller than Indiana
_#_Land boundary: 1,214 km with Spain
_#_Coastline: 1,793 km
_#_Maritime claims:
Continental shelf: 200 m (depth) or to depth of exploitation;
Exclusive economic zone:','6b3350df068f1d2951541715657459391a9c607395b74a33f221dbe80c6c0df8','internet-archive','theciaworldfactb00025gut','txt','84185fe9df79da427349cc1598fd3f69814a2085a9fc1fe0508a3fae0a870f84','https://archive.org/download/theciaworldfactb00025gut/25.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('65adb31bc143c71943fc54b906c1f5f97335f87310f5f2ce76b4fb884e7009e5',1991,'FR','France','geography',97,'200 nm;
Territorial sea: 12 nm
_#_Disputes: sovereignty over Timor Timur (East Timor Province)
disputed with Indonesia
_#_Climate: maritime temperate; cool and rainy in north, warmer and
drier in south
_#_Terrain: mountainous north of the Tagus, rolling plains in south
_#_Natural resources: fish, forests (cork), tungsten, iron ore,
uranium ore, marble
_#_Land use: arable land 32%; permanent crops 6%; meadows and
pastures 6%; forest and woodland 40%; other 16%; includes irrigated
7%
_#_Environment: Azores subject to severe earthquakes
_#_Note: Azores and Madeira Islands occupy strategic locations
along western sea approaches to Strait of Gibraltar
_#_Total area: 9,104 km2; land area: 8,959 km2
_#_Comparative area: slightly less than three times the size of Rhode
Island
_#_Land boundaries: none
_#_Coastline: 501 km
_#_Maritime claims:
Contiguous zone: 12 nm;
Continental shelf: 200 m (depth);
Exclusive economic zone: 200 nm;
Territorial sea: 12 nm
_#_Climate: tropical marine, mild, little seasonal temperature
variation
_#_Terrain: mostly mountains with coastal plain belt in north;
mountains precipitous to sea on west coast
_#_Natural resources: some copper and nickel; potential for onshore
and offshore crude oil
_#_Land use: arable land 8%; permanent crops 9%; meadows and pastures
41%; forest and woodland 20%; other 22%
_#_Environment: many small rivers and high central mountains ensure
land is well watered; south coast relatively dry; fertile coastal plain
belt in north
_#_Note: important location between the Dominican Republic and the
Virgin Islands group along the Mona Passage--a key shipping lane to the
Panama Canal; San Juan is one of the biggest and best natural harbors in
the Caribbean
_#_Total area: 11,000 km2; land area: 11,000 km2
_#_Comparative area: slightly smaller than Connecticut
_#_Land boundaries: 60 km total; Saudi Arabia 40 km, UAE 20 km
_#_Coastline: 563 km
_#_Maritime claims:
Continental shelf: not specific;
Territorial sea: 3 nm
_#_Disputes: boundary with UAE is in dispute; territorial dispute with
Bahrain over the Hawar Islands
_#_Climate: desert; hot, dry; humid and sultry in summer
_#_Terrain: mostly flat and barren desert covered with loose sand and
gravel
_#_Natural resources: crude oil, natural gas, fish
_#_Land use: arable land NEGL%; permanent crops 0%; meadows and
pastures 5%; forest and woodland 0%; other 95%
_#_Environment: haze, duststorms, sandstorms common; limited
freshwater resources mean increasing dependence on large-scale
desalination facilities
_#_Note: strategic location in central Persian Gulf near
major crude oil sources
_#_Total area: 2,510 km2; land area: 2,500 km2
_#_Comparative area: slightly smaller than Rhode Island
_#_Land boundaries: none
_#_Coastline: 201 km
_#_Maritime claims:
Exclusive economic zone: 200 nm;
Territorial sea: 12 nm
_#_Climate: tropical, but moderates with elevation; cool and dry from
May to November, hot and rainy from November to April
_#_Terrain: mostly rugged and mountainous; fertile lowlands along
coast
_#_Natural resources: fish, arable land
_#_Land use: arable land 20%; permanent crops 2%; meadows and
pastures 4%; forest and woodland 35%; other 39%; includes irrigated
2%
_#_Environment: periodic devastating cyclones
_#_Note: located 750 km east of Madagascar in the Indian Ocean
_#_Total area: 237,500 km2; land area: 230,340 km2
_#_Comparative area: slightly smaller than Oregon
_#_Land boundaries: 2,904 km total; Bulgaria 608 km, Hungary 443 km,
USSR 1,307 km, Yugoslavia 546 km
_#_Coastline: 225 km
_#_Maritime claims:
Continental shelf: 200 m (depth) or to depth of exploitation;
Exclusive economic zone: 200 nm;
Territorial sea: 12 nm
_#_Climate: temperate; cold, cloudy winters with frequent snow and
fog; sunny summers with frequent showers and thunderstorms
_#_Terrain: central Transylvanian Basin is separated from the plain of
Moldavia on the east by the Carpathian Mountains and separated from the
Walachian Plain on the south by the Transylvanian Alps
_#_Natural resources: crude oil (reserves being exhausted), timber,
natural gas, coal, iron ore, salt
_#_Land use: arable land 43%; permanent crops 3%; meadows and
pastures 19%; forest and woodland 28%; other 7%; includes irrigated 11%
_#_Environment: frequent earthquakes most severe in south and
southwest; geologic structure and climate promote landslides, air
pollution in south
_#_Note: controls most easily traversable land route between
the Balkans and western USSR
_#_Total area: 26,340 km2; land area: 24,950 km2
_#_Comparative area: slightly smaller than Maryland
_#_Land boundaries: 893 km total; Burundi 290 km, Tanzania 217 km,
Uganda 169 km, Zaire 217 km
_#_Coastline: none--landlocked
_#_Maritime claims: none--landlocked
_#_Climate: temperate; two rainy seasons (February to April, November
to January); mild in mountains with frost and snow possible
_#_Terrain: mostly grassy uplands and hills; mountains in west
_#_Natural resources: gold, cassiterite (tin ore), wolframite
(tungsten ore), natural gas, hydropower
_#_Land use: arable land 29%; permanent crops 11%; meadows and
pastures 18%; forest and woodland 10%; other 32%; includes irrigated
NEGL%
_#_Environment: deforestation; overgrazing; soil exhaustion; soil
erosion; periodic droughts
_#_Note: landlocked
_#_Total area: 410 km2; land area: 410 km2; includes Ascension, Gough
Island, Inaccessible Island, Nightingale Island, and Tristan da Cunha
_#_Comparative area: slightly more than 2.3 times the size of
Washington, DC
_#_Land boundaries: none
_#_Coastline: 60 km
_#_Maritime claims:
Exclusive fishing zone: 200 nm;
Territorial sea: 12 nm
_#_Climate: tropical; marine; mild, tempered by trade winds
_#_Terrain: rugged, volcanic; small scattered plateaus and plains
_#_Natural resources: fish; Ascension is a breeding ground for sea
turtles and sooty terns; no minerals
_#_Land use: arable land 7%; permanent crops 0%; meadows and
pastures 7%; forest and woodland 3%; other 83%
_#_Environment: very few perennial streams
_#_Note: located 1,920 km west of Angola, about two-thirds of the
way between South America and Africa; Napoleon Bonaparte''s place of
exile and burial; the remains were taken to Paris in 1840
_#_Total area: 269 km2; land area: 269 km2
_#_Comparative area: slightly more than 1.5 times the size of
Washington, DC
_#_Land boundaries: none
_#_Coastline: 135 km
_#_Maritime claims:
Contiguous zone: 24 nm;
Exclusive economic zone: 200 nm;
Territorial sea: 12 nm
_#_Climate: subtropical tempered by constant sea breezes; little
seasonal temperature variation; rainy season (May to November)
_#_Terrain: volcanic with mountainous interiors
_#_Natural resources: negligible
_#_Land use: arable land 22%; permanent crops 17%; meadows and
pastures 3%; forest and woodland 17%; other 41%
_#_Environment: subject to hurricanes (July to October)
_#_Note: located 320 km east-southeast of Puerto Rico
_#_Total area: 620 km2; land area: 610 km2
_#_Comparative area: slightly less than 3.5 times the size of
Washington, DC
_#_Land boundaries: none
_#_Coastline: 158 km
_#_Maritime claims:
Contiguous zone: 24 nm;
Exclusive economic zone: 200 nm;
Territorial sea: 12 nm
_#_Climate: tropical, moderated by northeast trade winds;
dry season from January to April, rainy season from May to August
_#_Terrain: volcanic and mountainous with some broad, fertile valleys
_#_Natural resources: forests, sandy beaches, minerals (pumice),
mineral springs, geothermal potential
_#_Land use: arable land 8%; permanent crops 20%; meadows and
pastures 5%; forest and woodland 13%; other 54%; includes irrigated 2%
_#_Environment: subject to hurricanes and volcanic activity;
deforestation; soil erosion
_#_Note: located 700 km southeast of Puerto Rico
_#_Total area: 242 km2; land area: 242 km2; includes eight small
islands in the Saint Pierre and the Miquelon groups
_#_Comparative area: slightly less than 1.5 times the size of
Washington, DC
_#_Land boundaries: none
_#_Coastline: 120 km
_#_Maritime claims:
Exclusive economic zone: 200 nm;
Territorial sea: 12 nm
_#_Disputes: focus of maritime boundary dispute between Canada and
_#_Climate: cold and wet, with much mist and fog; spring and autumn
are windy
_#_Terrain: mostly barren rock
_#_Natural resources: fish, deepwater ports
_#_Land use: arable land 13%; permanent crops 0%; meadows and
pastures 0%; forest and woodland 4%; other 83%
_#_Environment: vegetation scanty
_#_Note: located 25 km south of Newfoundland, Canada, in the
North Atlantic Ocean
_#_Total area: 340 km2; land area: 340 km2
_#_Comparative area: slightly less than twice the size of Washington,
DC
_#_Land boundaries: none
_#_Coastline: 84 km
_#_Maritime claims:
Contiguous zone: 24 nm;
Exclusive economic zone: 200 nm;
Territorial sea: 12 nm
_#_Climate: tropical; little seasonal temperature variation;
rainy season (May to November)
_#_Terrain: volcanic, mountainous; Soufriere volcano on the island
of Saint Vincent
_#_Natural resources: negligible
_#_Land use: arable land 38%; permanent crops 12%; meadows and
pastures 6%; forest and woodland 41%; other 3%; includes irrigated
3%
_#_Environment: subject to hurricanes; Soufriere volcano is a
constant
threat
_#_Note: some islands of the Grenadines group are administered by','a6d0d0d9267b56a4efc9edbd67de8d34cc5e1f3bad416a99e24f02d21bb6fe4c','internet-archive','theciaworldfactb00025gut','txt','84185fe9df79da427349cc1598fd3f69814a2085a9fc1fe0508a3fae0a870f84','https://archive.org/download/theciaworldfactb00025gut/25.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('11ea288ad4408a300b634a67ba8b183079388ea826a70cb0d3686226a64d77d3',1991,'LU','Luxembourg','geography',109,'_#_Total area: 16 km2; land area: 16 km2
_#_Comparative area: about 0.1 times the size of Washington, DC
_#_Land boundary: 0.34 km with China
_#_Coastline: 40 km
_#_Maritime claims: not known
_#_Disputes: scheduled to become a Special Administrative Region of
China in 1999
_#_Climate: subtropical; marine with cool winters, warm summers
_#_Terrain: generally flat
_#_Natural resources: negligible
_#_Land use: arable land 0%; permanent crops 0%; meadows and pastures
0%; forest and woodland 0%; other 100%
_#_Environment: essentially urban; one causeway and one bridge connect
the two islands to the peninsula on mainland
_#_Note: 27 km west southwest of Hong Kong on the southeast coast of','29d2632bee96d7dbfcb9cd85dd7733fda7a5c34052c55ae701650de47f346cfe','internet-archive','theciaworldfactb00025gut','txt','84185fe9df79da427349cc1598fd3f69814a2085a9fc1fe0508a3fae0a870f84','https://archive.org/download/theciaworldfactb00025gut/25.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('41d1924c533c5be258fc7ccc79f3f581200b7ff5451a61a7c6f8f081805861eb',1991,'CN','China','geography',116,'_#_Total area: 587,040 km2; land area: 581,540 km2
_#_Comparative area: slightly less than twice the size of Arizona
_#_Land boundaries: none
_#_Coastline: 4,828 km
_#_Maritime claims:
Exclusive economic zone: 200 nm;
Territorial sea: 12 nm
_#_Disputes: claims Bassas da India, Europa Island, Glorioso Islands,
Juan de Nova Island, and Tromelin Island (all administered by France)
_#_Climate: tropical along coast, temperate inland, arid in south
_#_Terrain: narrow coastal plain, high plateau and mountains in center
_#_Natural resources: graphite, chromite, coal, bauxite, salt,
quartz, tar sands, semiprecious stones, mica, fish
_#_Land use: arable land 4%; permanent crops 1%; meadows and pastures
58%; forest and woodland 26%; other 11%; includes irrigated 2%
_#_Environment: subject to periodic cyclones; deforestation;
overgrazing; soil erosion; desertification
_#_Note: world''s fourth-largest island; strategic location
along Mozambique Channel
_#_Total area: 118,480 km2; land area: 94,080 km2
_#_Comparative area: slightly larger than Pennsylvania
_#_Land boundaries: 2,881 km total; Mozambique 1,569 km, Tanzania
475 km, Zambia 837 km
_#_Coastline: none--landlocked
_#_Maritime claims: none--landlocked
_#_Disputes: dispute with Tanzania over the boundary in Lake Nyasa
(Lake Malawi)
_#_Climate: tropical; rainy season (November to May); dry season
(May to November)
_#_Terrain: narrow elongated plateau with rolling plains, rounded
hills, some mountains
_#_Natural resources: limestone; unexploited deposits of uranium,
coal, and bauxite
_#_Land use: arable land 25%; permanent crops NEGL%; meadows and
pastures 20%; forest and woodland 50%; other 5%; includes irrigated
NEGL%
_#_Environment: deforestation
_#_Note: landlocked
_#_Total area: 329,750 km2; land area: 328,550 km2
_#_Comparative area: slightly larger than New Mexico
_#_Land boundaries: 2,669 km total; Brunei 381 km, Indonesia 1,782,
Thailand 506 km
_#_Coastline: 4,675 km total (2,068 km Peninsular Malaysia,
2,607 km East Malaysia)
_#_Maritime claims:
Continental shelf: 200 m (depth) or to depth of exploitation,
specified boundary in the South China Sea;
Exclusive fishing zone: 200 nm;
Exclusive economic zone: 200 nm;
Territorial sea: 12 nm
_#_Disputes: involved in a complex dispute over the Spratly Islands
with China, Philippines, Taiwan, and Vietnam; state of Sabah claimed by
the Philippines; Brunei may wish to purchase the Malaysian salient that
divides Brunei into two parts
_#_Climate: tropical; annual southwest (April to October) and
northeast (October to February) monsoons
_#_Terrain: coastal plains rising to hills and mountains
_#_Natural resources: tin, crude oil, timber, copper, iron ore,
natural gas, bauxite
_#_Land use: arable land 3%; permanent crops 10%; meadows and pastures
NEGL%; forest and woodland 63%; other 24%; includes irrigated 1%
_#_Environment: subject to flooding; air and water pollution
_#_Note: strategic location along Strait of Malacca and southern
South China Sea
_#_Total area: 300 km2; land area: 300 km2
_#_Comparative area: slightly more than 1.5 times the size of
Washington, DC
_#_Land boundaries: none
_#_Coastline: 644 km
_#_Maritime claims:
Exclusive economic zone: 35-310 nm (defined by geographic
coordinates; segment of zone coincides with maritime boundary with
India);
Territorial sea: 12 nm
_#_Climate: tropical; hot, humid; dry, northeast monsoon (November to
March); rainy, southwest monsoon (June to August)
_#_Terrain: flat with elevations only as high as 2.5 meters
_#_Natural resources: fish
_#_Land use: arable land 10%; permanent crops 0%; meadows and pastures
3%; forest and woodland 3%; other 84%
_#_Environment: 1,200 coral islands grouped into 19 atolls
_#_Note: archipelago of strategic location astride and along
major sea lanes in Indian Ocean
_#_Total area: 1,240,000 km2; land area: 1,220,000 km2
_#_Comparative area: slightly less than twice the size of Texas
_#_Land boundaries: 7,243 km total; Algeria 1,376 km, Burkina 1,000
km, Guinea 858 km, Ivory Coast 532 km, Mauritania 2,237 km, Niger 821 km,
Senegal 419 km
_#_Coastline: none--landlocked
_#_Maritime claims: none--landlocked
_#_Disputes: the disputed international boundary between Burkina and
Mali was submitted to the International Court of Justice (ICJ) in October
1983 and the ICJ issued its final ruling in December 1986, which both
sides agreed to accept; Burkina and Mali are proceeding with boundary
demarcation, including the tripoint with Niger
_#_Climate: subtropical to arid; hot and dry February to June; rainy,
humid, and mild June to November; cool and dry November to February
_#_Terrain: mostly flat to rolling northern plains covered by sand;
savanna in south, rugged hills in northeast
_#_Natural resources: gold, phosphates, kaolin, salt, limestone,
uranium; bauxite, iron ore, manganese, tin, and copper deposits are known
but not exploited
_#_Land use: arable land 2%; permanent crops NEGL%; meadows and
pastures 25%; forest and woodland 7%; other 66%; includes irrigated NEGL%
_#_Environment: hot, dust-laden harmattan haze common during dry
seasons; desertification
_#_Note: landlocked
_#_Total area: 320 km2; land area: 320 km2
_#_Comparative area: slightly less than twice the size of Washington,
DC
_#_Land boundaries: none
_#_Coastline: 140 km
_#_Maritime claims:
Contiguous zone: 24 nm;
Continental shelf: 200 m (depth) or to depth of exploitation;
Exclusive fishing zone: 25 nm;
Territorial sea: 12 nm
_#_Climate: Mediterranean with mild, rainy winters and hot, dry
summers
_#_Terrain: mostly low, rocky, flat to dissected plains; many coastal
cliffs
_#_Natural resources: limestone, salt
_#_Land use: arable land 38%; permanent crops 3%; meadows and pastures
0%; forest and woodland 0%; other 59%; includes irrigated 3%
_#_Environment: numerous bays provide good harbors; fresh water very
scarce--increasing reliance on desalination
_#_Note: strategic location in central Mediterranean, 93 km south
of Sicily, 290 km north of Libya
_#_Total area: 588 km2; land area: 588 km2
_#_Comparative area: slightly less than 3.5 times the size of
Washington, DC
_#_Land boundaries: none
_#_Coastline: 113 km
_#_Maritime claims:
Exclusive fishing zone: 200 nm;
Territorial sea: 3 nm
_#_Climate: cool summers and mild winters; humid; overcast about half
the time
_#_Terrain: hills in north and south bisected by central valley
_#_Natural resources: lead, iron ore
_#_Land use: arable land NA%; permanent crops NA%; meadows and
pastures NA%; forest and woodland NA%; other NA%; extensive arable land
and forests
_#_Environment: strong westerly winds prevail
_#_Note: located in Irish Sea equidistant from England, Scotland,
and Ireland
_#_Total area: 181.3 km2; land area: 181.3 km2; includes the atolls
of Bikini, Eniwetak, and Kwajalein
_#_Comparative area: slightly larger than Washington, DC
_#_Land boundaries: none
_#_Coastline: 370.4 km
_#_Maritime claims:
Contiguous zone: 24 nm;
Exclusive economic zone: 200 nm;
Territorial sea: 12 nm
_#_Disputes: claims US territory of Wake Island
_#_Climate: wet season May to November; hot and humid; islands border
typhoon belt
_#_Terrain: low coral limestone and sand islands
_#_Natural resources: phosphate deposits, marine products, deep seabed
minerals
_#_Land use: arable land 0%; permanent crops 60%; meadows and pastures
0%; forest and woodland 0%; other 40%
_#_Environment: occasionally subject to typhoons; two archipelagic
island chains of 30 atolls and 1,152 islands
_#_Note: located 3,825 km southwest of Honolulu in the North Pacific
Ocean, about two-thirds of the way between Hawaii and Papua New Guinea;
Bikini and Eniwetak are former US nuclear test sites; Kwajalein, the
famous World War II battleground, is now used as a US missile test range
_#_Total area: 1,100 km2; land area: 1,060 km2
_#_Comparative area: slightly more than six times the size of
Washington, DC
_#_Land boundaries: none
_#_Coastline: 290 km
_#_Maritime claims:
Exclusive economic zone: 200 nm;
Territorial sea: 12 nm
_#_Climate: tropical; moderated by trade winds; rainy season (June to
October)
_#_Terrain: mountainous with indented coastline; dormant volcano
_#_Natural resources: coastal scenery and beaches, cultivable land
_#_Land use: arable land 10%; permanent crops 8%; meadows and pastures
30%; forest and woodland 26%; other 26%; includes irrigated 5%
_#_Environment: subject to hurricanes, flooding, and volcanic
activity that result in an average of one major natural disaster every
five years
_#_Note: located 625 km southeast of Puerto Rico in the Caribbean Sea
_#_Total area: 1,030,700 km2; land area: 1,030,400 km2
_#_Comparative area: slightly larger than three times the size of
New Mexico
_#_Land boundaries: 5,074 km total; Algeria 463 km, Mali 2,237 km,
Senegal 813 km, Western Sahara 1,561 km
_#_Coastline: 754 km
_#_Maritime claims:
Continental shelf: edge of continental margin or 200 nm;
Exclusive economic zone: 200 nm;
Territorial sea: 12 nm
_#_Disputes: boundary with Senegal
_#_Climate: desert; constantly hot, dry, dusty
_#_Terrain: mostly barren, flat plains of the Sahara; some central
hills
_#_Natural resources: iron ore, gypsum, fish, copper, phosphate
_#_Land use: arable land 1%; permanent crops NEGL%; meadows and
pastures 38%; forest and woodland 5%; other 56%; includes irrigated
NEGL%
_#_Environment: hot, dry, dust/sand-laden sirocco wind blows primarily
in March and April; desertification; only perennial river is the Senegal
_#_Total area: 1,860 km2; land area: 1,850 km2; includes Agalega
Islands, Cargados Carajos Shoals (Saint Brandon), and Rodrigues
_#_Comparative area: slightly less than 10.5 times the size of
Washington, DC
_#_Land boundaries: none
_#_Coastline: 177 km
_#_Maritime claims:
Continental shelf: edge of continental margin or 200 nm;
Exclusive economic zone: 200 nm;
Territorial sea: 12 nm
_#_Disputes: claims Chagos Archipelago, which includes the island of
Diego Garcia in UK-administered British Indian Ocean Territory; claims
French-administered Tromelin Island
_#_Climate: tropical modified by southeast trade winds; warm, dry
winter (May to November); hot, wet, humid summer (November to May)
_#_Terrain: small coastal plain rising to discontinuous mountains
encircling central plateau
_#_Natural resources: arable land, fish
_#_Land use: arable land 54%; permanent crops 4%; meadows and pastures
4%; forest and woodland 31%; other 7%; includes irrigated 9%
_#_Environment: subject to cyclones (November to April); almost
completely surrounded by reefs
_#_Note: located 900 km east of Madagascar in the Indian Ocean
_#_Total area: 375 km2; land area: 375 km2
_#_Comparative area: slightly more than twice the size of Washington,
DC
_#_Land boundaries: none
_#_Coastline: 185.2 km
_#_Maritime claims:
Exclusive economic zone: 200 nm;
Territorial sea: 12 nm
_#_Disputes: claimed by Comoros
_#_Climate: tropical; marine; hot, humid, rainy season during
northeastern monsoon (November to May); dry season is cooler (May to
November)
_#_Terrain: generally undulating with ancient volcanic peaks, deep
ravines
_#_Natural resources: negligible
_#_Land use: arable land NA%; permanent crops NA%; meadows and
pastures NA%; forest and woodland NA%; other NA%
_#_Environment: subject to cyclones during rainy season
_#_Note: part of Comoro Archipelago; located in the Mozambique Channel
about halfway between Africa and Madagascar
_#_Total area: 1,972,550 km2; land area: 1,923,040 km2
_#_Comparative area: slightly less than three times the size of Texas
_#_Land boundaries: 4,538 km total; Belize 250 km, Guatemala 962 km,
US 3,326 km
_#_Coastline: 9,330 km
_#_Maritime claims:
Contiguous zone: 24 nm;
Continental shelf: natural prolongation of continental margin or
200 nm;
Exclusive economic zone: 200 nm;
Territorial sea: 12 nm
_#_Disputes: claims Clipperton Island (French possession)
_#_Climate: varies from tropical to desert
_#_Terrain: high, rugged mountains, low coastal plains, high plateaus,
and desert
_#_Natural resources: crude oil, silver, copper, gold, lead, zinc,
natural gas, timber
_#_Land use: arable land 12%; permanent crops 1%; meadows and pastures
39%; forest and woodland 24%; other 24%; includes irrigated 3%
_#_Environment: subject to tsunamis along the Pacific coast and
destructive earthquakes in the center and south; natural water resources
scarce and polluted in north, inaccessible and poor quality in center and
extreme southeast; deforestation; erosion widespread; desertification;
serious air pollution in Mexico City and urban centers along US-Mexico
border
_#_Note: strategic location on southern border of US
_#_Total area: 702 km2; land area: 702 km2; includes Pohnpei, Truk,
Yap, and Kosrae
_#_Comparative area: slightly less than four times the size of
Washington, DC
_#_Land boundaries: none
_#_Coastline: 6,112 km
_#_Maritime claims:
Exclusive economic zone: 200 nm;
Territorial sea: 12 nm
_#_Climate: tropical; heavy year-round rainfall, especially in the
eastern islands; located on southern edge of the typhoon belt with
occasional severe
damage
_#_Terrain: islands vary geologically from high mountainous islands to
low, coral atolls; volcanic outcroppings on Pohnpei, Kosrae, and Truk
_#_Natural resources: forests, marine products, deep-seabed minerals
_#_Land use: arable land NA%; permanent crops NA%; meadows and
pastures NA%; forest and woodland NA%; other NA%
_#_Environment: subject to typhoons from June to December; four major
island groups totaling 607 islands
_#_Note: located 5,150 km west-southwest of Honolulu in the North
Pacific Ocean, about three-quarters of the way between Hawaii and','f395bbc7f5e746c0341b7c067c72b4264cf25dfacdd38f321816ebf99906f9ac','internet-archive','theciaworldfactb00025gut','txt','84185fe9df79da427349cc1598fd3f69814a2085a9fc1fe0508a3fae0a870f84','https://archive.org/download/theciaworldfactb00025gut/25.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('209f5f1aed468c7c7ad8dd87ee2f06321b92d820a05def16fc770192c305e276',1991,'ID','Indonesia','geography',120,'_#_Total area: 5.2 km2; land area: 5.2 km2; includes Eastern Island
and Sand Island
_#_Comparative area: about nine times the size of The Mall in
Washington, DC
_#_Land boundaries: none
_#_Coastline: 15 km
_#_Maritime claims:
Contiguous zone: 12 nm;
Continental shelf: 200 m (depth);
Exclusive economic zone: 200 nm;
Territorial sea: 12 nm
_#_Climate: tropical, but moderated by prevailing easterly winds
_#_Terrain: low, nearly level
_#_Natural resources: fish and wildlife
_#_Land use: arable land 0%; permanent crops 0%; meadows and pastures
0%; forest and woodland 0%; other 100%
_#_Environment: coral atoll
_#_Note: located 2,350 km west-northwest of Honolulu at the western
end of Hawaiian Islands group, about one-third of the way between
Honolulu and Tokyo; closed to the public
_#_Total area: 1.9 km2; land area: 1.9 km2
_#_Comparative area: about three times the size of The Mall in
Washington, DC
_#_Land boundary: 4.4 km with France
_#_Coastline: 4.1 km
_#_Maritime claims:
Territorial sea: 12 nm
_#_Climate: Mediterranean with mild, wet winters and hot, dry summers
_#_Terrain: hilly, rugged, rocky
_#_Natural resources: none
_#_Land use: arable land 0%; permanent crops 0%; meadows and pastures
0%; forest and woodland 0%; other 100%
_#_Environment: almost entirely urban
_#_Note: second-smallest independent state in world (after
Vatican City)','90be0ad4fb4809f4934715053b425482a6e7ee56abe2074811feadce324505cb','internet-archive','theciaworldfactb00025gut','txt','84185fe9df79da427349cc1598fd3f69814a2085a9fc1fe0508a3fae0a870f84','https://archive.org/download/theciaworldfactb00025gut/25.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('511ff26404ff95081c61e70881ebe32bd05e20374eeee6877e4cc1ec8e368e85',1991,'GD','Grenada','geography',125,'_#_Total area: 60 km2; land area: 60 km2
_#_Comparative area: about 0.3 times the size of Washington, DC
_#_Land boundary: 39 km with Italy
_#_Coastline: none--landlocked
_#_Maritime claims: none--landlocked
_#_Climate: Mediterranean; mild to cool winters; warm, sunny summers
_#_Terrain: rugged mountains
_#_Natural resources: building stones
_#_Land use: arable land 17%; permanent crops 0%; meadows and
pastures 0%; forest and woodland 0%; other 83%
_#_Environment: dominated by the Appenines
_#_Note: landlocked; world''s smallest republic; enclave of Italy
_#_Total area: 960 km2; land area: 960 km2
_#_Comparative area: slightly less than 5.5 times the size of
Washington, DC
_#_Land boundaries: none
_#_Coastline: 209 km
_#_Maritime claims: (measured from claimed archipelagic baselines);
Exclusive economic zone: 200 nm;
Territorial sea: 12 nm
_#_Climate: tropical; hot, humid; one rainy season (October to May)
_#_Terrain: volcanic, mountainous
_#_Natural resources: fish
_#_Land use: arable land 1%; permanent crops 20%; meadows and
pastures 1%; forest and woodland 75%; other 3%
_#_Environment: deforestation; soil erosion
_#_Note: located south of Nigeria and west of Gabon near the Equator
in the North Atlantic Ocean
_#_Total area: 2,149,690 km2; land area: 2,149,690 km2
_#_Comparative area: slightly less than one-fourth the size of US
_#_Land boundaries: 4,410 km total; Iraq 488 km, Iraq-Saudi Arabia
Neutral Zone 198 km, Jordan 742 km, Kuwait 222 km, Oman 676 km, Qatar
40 km, UAE 586 km, Yemen 1,458 km
_#_Coastline: 2,510 km
_#_Maritime claims:
Contiguous zone: 18 nm;
Continental shelf: not specific;
Territorial sea: 12 nm
_#_Disputes: no defined boundaries with Yemen and UAE;
shares Neutral Zone with Iraq--in December 1981, Iraq and Saudi Arabia
signed a boundary agreement that divides the zone between them, but the
agreement must be ratified before it becomes effective; Kuwaiti
ownership of Qaruh and Umm al Maradim Islands is disputed by','a8c69263e8947d90786ef4b4ad69ae74041288059ded2117b57eaf3bac8d1fe5','internet-archive','theciaworldfactb00025gut','txt','84185fe9df79da427349cc1598fd3f69814a2085a9fc1fe0508a3fae0a870f84','https://archive.org/download/theciaworldfactb00025gut/25.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('071ac60ecd04d86d02e233924253d36d83db12fe0b4f5757708cc34d872b850d',1991,'SG','Singapore','geography',130,'_#_Total area: 56,790 km2; land area: 54,390 km2
_#_Comparative area: slightly smaller than West Virginia
_#_Land boundaries: 1,647 km total; Benin 644 km, Burkina 126 km,
Ghana 877 km
_#_Coastline: 56 km
_#_Maritime claims:
Exclusive economic zone: 200 nm;
Territorial sea: 30 nm
_#_Climate: tropical; hot, humid in south; semiarid in north
_#_Terrain: gently rolling savanna in north; central hills; southern
plateau; low coastal plain with extensive lagoons and marshes
_#_Natural resources: phosphates, limestone, marble
_#_Land use: arable land 25%; permanent crops 1%; meadows and pastures
4%; forest and woodland 28%; other 42%; includes irrigated NEGL%
_#_Environment: hot, dry harmattan wind can reduce visibility in north
during winter; recent droughts affecting agriculture; deforestation
_#_Total area: 10 km2; land area: 10 km2
_#_Comparative area: about 17 times the size of The Mall in
Washington, DC
_#_Land boundaries: none
_#_Coastline: 101 km
_#_Maritime claims:
Exclusive economic zone: 200 nm;
Territorial sea: 12 nm
_#_Climate: tropical; moderated by trade winds (April to November)
_#_Terrain: coral atolls enclosing large lagoons
_#_Natural resources: negligible
_#_Land use: arable land 0%; permanent crops 0%; meadows and pastures
0%; forest and woodland 0%; other 100%
_#_Environment: lies in Pacific typhoon belt
_#_Note: located 3,750 km southwest of Honolulu in the South Pacific
Ocean, about halfway between Hawaii and New Zealand','efc140b656acab0b26e2a804414450be49eb5c65e8b907978951d0065325da74','internet-archive','theciaworldfactb00025gut','txt','84185fe9df79da427349cc1598fd3f69814a2085a9fc1fe0508a3fae0a870f84','https://archive.org/download/theciaworldfactb00025gut/25.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8cab3ed4bb83754dae8918d71ae049e19109b7c0a2f5de3ca356413b66659aea',1991,'WS','Samoa','geography',135,'_#_Total area: 748 km2; land area: 718 km2
_#_Comparative area: slightly more than four times the size of
Washington, DC
_#_Land boundaries: none
_#_Coastline: 419 km
_#_Maritime claims:
Continental shelf: no specific limits;
Exclusive economic zone: 200 nm;
Territorial sea: 12 nm
_#_Climate: tropical; modified by trade winds; warm season (December
to May), cool season (May to December)
_#_Terrain: most islands have limestone base formed from uplifted
coral formation; others have limestone overlying volcanic base
_#_Natural resources: fish, fertile soil
_#_Land use: arable land 25%; permanent crops 55%; meadows and
pastures 6%; forest and woodland 12%; other 2%
_#_Environment: archipelago of 170 islands (36 inhabited); subject to
cyclones (October to April); deforestation
_#_Note: located about 2,250 km north-northwest of New Zealand, about
two-thirds of the way between Hawaii and New Zealand
_#_Total area: 5,130 km2; land area: 5,130 km2
_#_Comparative area: slightly smaller than Delaware
_#_Land boundaries: none
_#_Coastline: 362 km
_#_Maritime claims:
Continental shelf: outer edge of continental margin or 200 nm;
Exclusive economic zone: 200 nm;
Territorial sea: 12 nm
_#_Climate: tropical; rainy season (June to December)
_#_Terrain: mostly plains with some hills and low mountains
_#_Natural resources: crude oil, natural gas, asphalt
_#_Land use: arable land 14%; permanent crops 17%; meadows and
pastures 2%; forest and woodland 44%; other 23%; includes irrigated
4%
_#_Environment: outside usual path of hurricanes and other tropical
storms
_#_Note: located 11 km from Venezuela
_#_Total area: 1 km2; land area: 1 km2
_#_Comparative area: about 1.7 times the size of The Mall in
Washington, DC
_#_Land boundaries: none
_#_Coastline: 3.7 km
_#_Maritime claims:
Contiguous zone: 12 nm;
Continental shelf: 200 m (depth) or to depth of exploitation;
Exclusive economic zone: 200 nm;
Territorial sea: 12 nm
_#_Disputes: claimed by Madagascar, Mauritius, and Seychelles
_#_Climate: tropical
_#_Terrain: sandy
_#_Natural resources: fish
_#_Land use: arable land 0%; permanent crops 0%; meadows and pastures
0%; forest and woodland 0%; other--scattered bushes 100%
_#_Environment: wildlife sanctuary
_#_Note: located 350 km east of Madagascar and 600 km north of Reunion
in the Indian Ocean; climatologically important location for forecasting
cyclones
_#_Total area: 163,610 km2; land area: 155,360 km2
_#_Comparative area: slightly larger than Georgia
_#_Land boundaries: 1,424 km total; Algeria 965 km, Libya 459 km
_#_Coastline: 1,148 km
_#_Maritime claims:
Territorial sea: 12 nm
_#_Disputes: maritime boundary dispute with Libya
_#_Climate: temperate in north with mild, rainy winters and hot, dry
summers; desert in south
_#_Terrain: mountains in north; hot, dry central plain; semiarid south
merges into the Sahara
_#_Natural resources: crude oil, phosphates, iron ore, lead, zinc,
salt
_#_Land use: arable land 20%; permanent crops 10%; meadows and
pastures 19%; forest and woodland 4%; other 47%; includes irrigated
1%
_#_Environment: deforestation; overgrazing; soil erosion;
desertification
_#_Note: strategic location in central Mediterranean; only
144 km from Italy across the Strait of Sicily; borders Libya on east','dd343f16c76bcf7e3391c3d76cf736697849a3c67ec0e243756160c6a0e235f4','internet-archive','theciaworldfactb00025gut','txt','84185fe9df79da427349cc1598fd3f69814a2085a9fc1fe0508a3fae0a870f84','https://archive.org/download/theciaworldfactb00025gut/25.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1bc4c46012bf83fbba1023ad41601af2f254722900ab827772a7196db64c5f4b',1991,'DZ','Algeria','geography',138,'_#_Total area: 780,580 km2; land area: 770,760 km2
_#_Comparative area: slightly larger than Texas
_#_Land boundaries: 2,715 km total; Bulgaria 240 km, Greece 206 km,
Iran 499 km, Iraq 331 km, Syria 822 km, USSR 617 km
_#_Coastline: 7,200 km
_#_Maritime claims:
Exclusive economic zone: in Black Sea only--to the maritime
boundary agreed upon with the USSR;
Territorial sea: 6 nm in the Aegean Sea, 12 nm in Black Sea and
Mediterranean Sea
_#_Disputes: complex maritime and air (but not territorial)
disputes with Greece in Aegean Sea; Cyprus question; Hatay question
with Syria; ongoing dispute with downstream riparians (Syria and
Iraq) over water development plans for the Tigris and Euphrates
rivers; Kurdish question among Iran, Iraq, Syria, Turkey, and
the USSR
_#_Climate: temperate; hot, dry summers with mild, wet winters;
harsher in interior
_#_Terrain: mostly mountains; narrow coastal plain; high central
plateau (Anatolia)
_#_Natural resources: antimony, coal, chromium, mercury, copper,
borate, sulphur, iron ore
_#_Land use: arable land 30%; permanent crops 4%; meadows and
pastures 12%; forest and woodland 26%; other 28%; includes
irrigated 3%
_#_Environment: subject to severe earthquakes, especially along
major river valleys in west; air pollution; desertification
_#_Note: strategic location controlling the Turkish straits
(Bosporus, Sea of Marmara, Dardanelles) that link Black and Aegean
Seas; Turkey and Norway only NATO members having a land boundary
with the USSR
_#_Total area: 430 km2; land area: 430 km2
_#_Comparative area: slightly less than 2.5 times the size of
Washington, DC
_#_Land boundaries: none
_#_Coastline: 389 km
_#_Maritime claims:
Exclusive fishing zone: 200 nm;
Territorial sea: 12 nm
_#_Climate: tropical; marine; moderated by trade winds; sunny and
relatively dry
_#_Terrain: low, flat limestone; extensive marshes and mangrove swamps
_#_Natural resources: spiny lobster, conch
_#_Land use: arable land 2%; permanent crops 0%; meadows and pastures;
0%; forest and woodland 0%; other 98%
_#_Environment: 30 islands (eight inhabited); subject to frequent
hurricanes
_#_Note: located 190 km north of the Dominican Republic in the North
Atlantic Ocean
_#_Total area: 26 km2; land area: 26 km2
_#_Comparative area: about 0.1 times the size of Washington, DC
_#_Land boundaries: none
_#_Coastline: 24 km
_#_Maritime claims:
Exclusive economic zone: 200 nm;
Territorial sea: 12 nm
_#_Climate: tropical; moderated by easterly trade winds (March to
November); westerly gales and heavy rain (November to March)
_#_Terrain: very low-lying and narrow coral atolls
_#_Natural resources: fish
_#_Land use: arable land 0%; permanent crops 0%; meadows and pastures
0%; forest and woodland 0%; other 100%
_#_Environment: severe tropical storms are rare
_#_Note: located 3,000 km east of Papua New Guinea in the South
Pacific Ocean
_#_Total area: 236,040 km2; land area: 199,710 km2
_#_Comparative area: slightly smaller than Oregon
_#_Land boundaries: 2,698 km total; Kenya 933 km, Rwanda 169 km, Sudan
435 km, Tanzania 396 km, Zaire 765 km
_#_Coastline: none--landlocked
_#_Maritime claims: none--landlocked
_#_Climate: tropical; generally rainy with two dry seasons (December
to February, June to August); semiarid in northeast
_#_Terrain: mostly plateau with rim of mountains
_#_Natural resources: copper, cobalt, limestone, salt
_#_Land use: arable land 23%; permanent crops 9%; meadows and
pastures 25%; forest and woodland 30%; other 13%; includes irrigated
NEGL%
_#_Environment: straddles Equator; deforestation; overgrazing; soil
erosion
_#_Note: landlocked
_#_Total area: 83,600 km2; land area: 83,600 km2
_#_Comparative area: slightly smaller than Maine
_#_Land boundaries: 1,016 km total; Oman 410 km, Saudi Arabia 586 km,
Qatar 20 km
_#_Coastline: 1,448 km
_#_Maritime claims:
Continental shelf: defined by bilateral boundaries or equidistant
line
Exclusive economic zone: 200 nm;
Territorial sea: 3 nm (assumed), 12 nm for Ash Shariqah
(Sharjah)
_#_Disputes: boundary with Qatar is in dispute; no defined boundary
with Saudi Arabia; no defined boundary with most of Oman, but
Administrative Line in far north; claims three islands in the Persian
Gulf occupied by Iran (Jazireh-ye Abu Musa or Abu
Musa, Jazireh-ye Tonb-e Bozorg or Greater Tunb, and Jazireh-ye
Tonb-e Kuchek or Lesser Tunb)
_#_Climate: desert; cooler in eastern mountains
_#_Terrain: flat, barren coastal plain merging into rolling sand
dunes of vast desert wasteland; mountains in east
_#_Natural resources: crude oil and natural gas
_#_Land use: arable land NEGL%; permanent crops NEGL%; meadows and
pastures 2%; forest and woodland NEGL%; other 98%; includes irrigated
NEGL%
_#_Environment: frequent dust and sand storms; lack of natural
freshwater resources being overcome by desalination plants;
desertification
_#_Note: strategic location along southern approaches to
Strait of Hormuz, a vital transit point for world crude oil
_#_Total area: 244,820 km2; land area: 241,590 km2; includes Rockall
and Shetland Islands
_#_Comparative area: slightly smaller than Oregon
_#_Land boundary: Ireland 360 km
_#_Coastline: 12,429 km
_#_Maritime claims:
Continental shelf: as defined in continental shelf orders or in
accordance with agreed upon boundaries;
Exclusive fishing zone: 200 nm;
Territorial sea: 12 nm
_#_Disputes: Northern Ireland question with Ireland; Gibraltar
question with Spain; Argentina claims Falkland Islands (Islas Malvinas);
Argentina claims South Georgia and the South Sandwich Islands; Mauritius
claims island of Diego Garcia in British Indian Ocean Territory;
Rockall continental shelf dispute involving Denmark, Iceland, and Ireland
(Ireland and the UK have signed a boundary agreement in the Rockall
area); territorial claim in Antarctica (British Antarctic Territory)
_#_Climate: temperate; moderated by prevailing southwest winds over
the North Atlantic Current; more than half of the days are overcast
_#_Terrain: mostly rugged hills and low mountains; level to rolling
plains in east and southeast
_#_Natural resources: coal, crude oil, natural gas, tin,
limestone, iron ore, salt, clay, chalk, gypsum, lead, silica
_#_Land use: arable land 29%; permanent crops NEGL%; meadows and
pastures 48%; forest and woodland 9%; other 14%; includes irrigated
1%
_#_Environment: pollution control measures improving air, water
quality; because of heavily indented coastline, no location is more
than 125 km from tidal waters
_#_Note: lies near vital North Atlantic sea lanes; only 35 km from
France and now being linked by tunnel under the English Channel
_#_Total area: 9,372,610 km2; land area: 9,166,600 km2; includes only
the 50 states and District of Colombia
_#_Comparative area: about four-tenths the size of USSR; about
one-third the size of Africa; about one-half the size of South America
(or slightly larger than Brazil); slightly smaller than China; about
two and one-half times the size of Western Europe
_#_Land boundaries: 12,248 km total; Canada 8,893 km (including
2,477 km with Alaska), Mexico 3,326 km, Cuba (US naval base at
Guantanamo) 29 km
_#_Coastline: 19,924 km
_#_Maritime claims:
Contiguous zone: 12 nm;
Continental shelf: not specified;
Exclusive economic zone: 200 nm;
Territorial sea: 12 nm
_#_Disputes: maritime boundary disputes with Canada; US Naval Base at
Guantanamo is leased from Cuba and only mutual agreement or US
abandonment of the area can terminate the lease; Haiti claims Navassa
Island; US has made no territorial claim in Antarctica (but has reserved
the right to do so) and does not recognize the claims of any other
nation; Marshall Islands claims Wake Island
_#_Climate: mostly temperate, but varies from tropical (Hawaii) to
arctic (Alaska); arid to semiarid in west with occasional warm, dry
chinook wind
_#_Terrain: vast central plain, mountains in west, hills and low
mountains in east; rugged mountains and broad river valleys in Alaska;
rugged, volcanic topography in Hawaii
_#_Natural resources: coal, copper, lead, molybdenum, phosphates,
uranium, bauxite, gold, iron, mercury, nickel, potash, silver, tungsten,
zinc, crude oil, natural gas, timber
_#_Land use: arable land 20%; permanent crops NEGL%; meadows and
pastures 26%; forest and woodland 29%; other 25%; includes irrigated 2%
_#_Environment: pollution control measures improving air and water
quality; acid rain; agricultural fertilizer and pesticide pollution;
management of sparse natural water resources in west; desertification;
tsunamis, volcanoes, and earthquake activity around Pacific Basin;
continuous permafrost in northern Alaska is a major impediment to
development
_#_Note: world''s fourth-largest country (after USSR, Canada, and
China)
_#_Total area: 176,220 km2; land area: 173,620 km2
_#_Comparative area: slightly smaller than Washington State
_#_Land boundaries: 1,564 km total; Argentina 579 km, Brazil 985 km
_#_Coastline: 660 km
_#_Maritime claims:
Continental shelf: 200 m (depth) or to depth of exploitation;
Territorial sea: 200 nm (overflight and navigation permitted
beyond 12 nm)
_#_Disputes: short section of boundary with Argentina is in dispute;
two short sections of the boundary with Brazil are in dispute (Arroyo
de la Invernada area of the Rio Quarai and the islands at the confluence
of the Rio Quarai and the Uruguay)
_#_Climate: warm temperate; freezing temperatures almost unknown
_#_Terrain: mostly rolling plains and low hills; fertile coastal
lowland
_#_Natural resources: soil, hydropower potential, minor minerals
_#_Land use: arable land 8%; permanent crops NEGL%; meadows and
pastures 78%; forest and woodland 4%; other 10%; includes irrigated 1%
_#_Environment: subject to seasonally high winds, droughts, floods
_#_Total area: 14,760 km2; land area: 14,760 km2; includes more
than 80 islands
_#_Comparative area: slightly larger than Connecticut
_#_Land boundary: none
_#_Coastline: 2,528 km
_#_Maritime claims: (measured from claimed archipelagic baselines);
Contiguous zone: 24 nm;
Continental shelf: edge of continental margin or 200 nm;
Exclusive economic zone: 200 nm;
Territorial sea: 12 nm
_#_Climate: tropical; moderated by southeast trade winds
_#_Terrain: mostly mountains of volcanic origin; narrow coastal plains
_#_Natural resources: manganese, hardwood forests, fish
_#_Land use: arable land 1%; permanent crops 5%; meadows and pastures
2%; forest and woodland 1%; other 91%
_#_Environment: subject to tropical cyclones or typhoons (January to
April); volcanism causes minor earthquakes
_#_Note: located 5,750 km southwest of Honolulu in the South Pacific
Ocean about three-quarters of the way between Hawaii and Australia
_#_Total area: 0.438 km2; land area: 0.438 km2
_#_Comparative area: about 0.7 times the size of The Mall in
Washington, DC
_#_Land boundary: 3.2 km with Italy
_#_Coastline: none--landlocked
_#_Maritime claims: none--landlocked
_#_Climate: temperate; mild, rainy winters (September to mid-May) with
hot, dry summers (May to September)
_#_Terrain: low hill
_#_Natural resources: none
_#_Land use: arable land 0%; permanent crops 0%; meadows and pastures
0%; forest and woodland 0%; other 100%
_#_Environment: urban
_#_Note: landlocked; enclave of Rome, Italy; world''s smallest state;
outside the Vatican City, 13 buildings in Rome and Castel Gandolfo
(the pope''s summer residence) enjoy extraterritorial rights','6ce6797facc96bd2109a661cf1f029c9041757f3de032e180fd0c8446a70c706','internet-archive','theciaworldfactb00025gut','txt','84185fe9df79da427349cc1598fd3f69814a2085a9fc1fe0508a3fae0a870f84','https://archive.org/download/theciaworldfactb00025gut/25.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('956c731f14951bac800aef204ca45836977ff7a76e3c52bb031132dc772ccfad',1991,'IT','Italy','geography',143,'_#_Total area: 912,050 km2; land area: 882,050 km2
_#_Comparative area: slightly more than twice the size of California
_#_Land boundaries: 4,993 km total; Brazil 2,200 km, Colombia 2,050
km, Guyana 743 km
_#_Coastline: 2,800 km
_#_Maritime claims:
Contiguous zone: 15 nm;
Continental shelf: 200 m (depth) or to depth of exploitation;
Exclusive economic zone: 200 nm;
Territorial sea: 12 nm
_#_Disputes: claims all of Guyana west of the Essequibo river;
maritime boundary dispute with Colombia in the Gulf of Venezuela
_#_Climate: tropical; hot, humid; more moderate in highlands
_#_Terrain: Andes mountains and Maracaibo lowlands in northwest;
central plains (llanos); Guyana highlands in southeast
_#_Natural resources: crude oil, natural gas, iron ore, gold, bauxite,
other minerals, hydropower, diamonds
_#_Land use: arable land 3%; permanent crops 1%; meadows and pastures
20%; forest and woodland 39%; other 37%; includes irrigated NEGL%
_#_Environment: subject to floods, rockslides, mudslides; periodic
droughts; increasing industrial pollution in Caracas and Maracaibo
_#_Note: on major sea and air routes linking North and South America
_#_Total area: 329,560 km2; land area: 325,360
_#_Comparative area: slightly larger than New Mexico
_#_Land boundaries: 3,818 km total; Cambodia 982 km, China 1,281 km,
Laos 1,555 km
_#_Coastline: 3,444 km (excluding islands)
_#_Maritime claims:
Contiguous zone: 24 nm;
Continental shelf: edge of continental margin or 200 nm;
Exclusive economic zone: 200 nm;
Territorial sea: 12 nm
_#_Disputes: offshore islands and three sections of the boundary with
Cambodia are in dispute; maritime boundary with Cambodia not defined;
occupied Cambodia on 25 December 1978; sporadic border clashes with
China; involved in a complex dispute over the Spratly Islands with China,
Malaysia, Philippines, and Taiwan; unresolved maritime boundary with
Thailand; maritime boundary dispute with China in the Gulf of Tonkin;
Paracel Islands occupied by China but claimed by Vietnam and Taiwan;
unresolved maritime boundary with Thailand
_#_Climate: tropical in south; monsoonal in north with hot, rainy
season (mid-May to mid-September) and warm, dry season (mid-October to
mid-March)
_#_Terrain: low, flat delta in south and north; central highlands;
hilly, mountainous in far north and northwest
_#_Natural resources: phosphates, coal, manganese, bauxite, chromate,
offshore oil deposits, forests
_#_Land use: arable land 22%; permanent crops 2%; meadows and pastures
1%; forest and woodland 40%; other 35%; includes irrigated 5%
_#_Environment: occasional typhoons (May to January) with extensive
flooding','a258275cc47cd0d9a6c82d46f69eb28698834de58cc89a117f38feb9d414e24b','internet-archive','theciaworldfactb00025gut','txt','84185fe9df79da427349cc1598fd3f69814a2085a9fc1fe0508a3fae0a870f84','https://archive.org/download/theciaworldfactb00025gut/25.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9b9732265ca03e0c075adb834a98f8ea12144d30764272561d1387fb0ac4bf46',1991,'MT','Malta','geography',147,'_#_Total area: 352 km2; land area: 349 km2
_#_Comparative area: slightly less than twice the size of Washington,
DC
_#_Land boundaries: none
_#_Coastline: 188 km
_#_Maritime claims:
Contiguous zone: 12 nm;
Continental shelf: 200 m (depth);
Exclusive economic zone: 200 nm;
Territorial sea: 12 nm
_#_Climate: subtropical, tempered by easterly tradewinds, relatively
low humidity, little seasonal temperature variation; rainy season May to
November
_#_Terrain: mostly hilly to rugged and mountainous with little level
land
_#_Natural resources: sun, sand, sea, surf
_#_Land use: arable land 15%; permanent crops 6%; meadows and pastures
26%; forest and woodland 6%; other 47%
_#_Environment: rarely affected by hurricanes; subject to frequent
severe droughts, floods, earthquakes; lack of natural freshwater
resources
_#_Note: important location 1,770 km southeast of Miami and 65 km east
of Puerto Rico, along the Anegada Passage--a key shipping lane for the
Panama Canal; Saint Thomas has one of the best natural, deepwater harbors
in the Caribbean
_#_Total area: 6.5 km2; land area: 6.5 km2
_#_Comparative area: about 11 times the size of The Mall in
Washington, DC
_#_Land boundaries: none
_#_Coastline: 19.3 km
_#_Maritime claims:
Contiguous zone: 12 nm;
Continental shelf: 200 m (depth);
Exclusive economic zone: 200 nm;
Territorial sea: 12 nm
_#_Disputes: claimed by the Republic of the Marshall Islands
_#_Climate: tropical
_#_Terrain: atoll of three coral islands built up on an underwater
volcano; central lagoon is former crater, islands are part of the rim;
average elevation less than four meters
_#_Natural resources: none
_#_Land use: arable land 0%; permanent crops 0%; meadows and pastures
0%; forest and woodland 0%; other 100%
_#_Environment: subject to occasional typhoons
_#_Note: strategic location 3,700 km west of Honolulu in the North
Pacific Ocean, about two-thirds of the way between Hawaii and the
Northern Mariana Islands; emergency landing location for transpacific
flights
_#_Total area: 274 km2; land area: 274 km2; includes Ile Uvea
(Wallis Island), Ile Futuna (Futuna Island), Ile Alofi, and 20
islets
_#_Comparative area: slightly larger than Washington, DC
_#_Land boundaries: none
_#_Coastline: 129 km
_#_Maritime claims:
Exclusive economic zone: 200 nm;
Territorial sea: 12 nm
_#_Climate: tropical; hot, rainy season (November to April); cool,
dry season (May to October)
_#_Terrain: volcanic origin; low hills
_#_Natural resources: negligible
_#_Land use: arable land 5%; permanent crops 20%; meadows and pastures
0%; forest and woodland 0%; other 75%
_#_Environment: both island groups have fringing reefs
_#_Note: located 4,600 km southwest of Honolulu in the South Pacific
Ocean about two-thirds of the way from Hawaii to New Zealand
_#_Total area: 5,860 km2; land area: 5,640 km2; includes West Bank,
East Jerusalem, Latrun Salient, Jerusalem No Man''s Land, and the
northwest quarter of the Dead Sea, but excludes Mt. Scopus
_#_Comparative area: slightly larger than Delaware
_#_Land boundaries: 404 km total; Israel 307 km, Jordan 97 km;
_#_Coastline: none--landlocked
_#_Maritime claims: none--landlocked
_#_Disputes: Israeli occupied with status to be determined
_#_Climate: temperate, temperature and precipitation vary with
altitude, warm to hot summers, cool to mild winters
_#_Terrain: mostly rugged dissected upland, some vegetation in west,
but barren in east
_#_Natural resources: negligible
_#_Land use: arable land 27%, permanent crops 0%, meadows and pastures
32%, forest and woodland 1%, other 40%
_#_Environment: highlands are main recharge area for Israel''s coastal
aquifers
_#_Note: landlocked; there are 175 Jewish settlements in the West Bank
and 14 Israeli-built Jewish neighborhoods in East Jerusalem
_#_Total area: 266,000 km2; land area: 266,000 km2
_#_Comparative area: slightly smaller than Colorado
_#_Land boundaries: 2,046 km total; Algeria 42 km, Mauritania
1,561 km, Morocco 443 km
_#_Coastline: 1,110 km
_#_Maritime claims: contingent upon resolution of sovereignty issue
_#_Disputes: claimed and administered by Morocco, but sovereignty is
unresolved and guerrilla fighting continues in the area
_#_Climate: hot, dry desert; rain is rare; cold offshore currents
produce fog and heavy dew
_#_Terrain: mostly low, flat desert with large areas of rocky or
sandy surfaces rising to small mountains in south and northeast
_#_Natural resources: phosphates, iron ore
_#_Land use: arable land NEGL%; permanent crops 0%; meadows and
pastures 19%; forest and woodland 0%; other 81%
_#_Environment: hot, dry, dust/sand-laden sirocco wind can occur
during winter and spring; widespread harmattan haze exists 60% of time,
often severely restricting visibility; sparse water and arable land
_#_Total area: 2,860 km2; land area: 2,850 km2
_#_Comparative area: slightly smaller than Rhode Island
_#_Land boundaries: none
_#_Coastline: 403 km
_#_Maritime claims:
Exclusive economic zone: 200 nm;
Territorial sea: 12 nm
_#_Climate: tropical; rainy season (October to March), dry season
(May to October)
_#_Terrain: narrow coastal plain with volcanic, rocky, rugged
mountains in interior
_#_Natural resources: hardwood forests, fish
_#_Land use: arable land 19%; permanent crops 24%; meadows and
pastures NEGL%; forest and woodland 47%; other 10%
_#_Environment: subject to occasional typhoons; active volcanism
_#_Note: located 4,300 km southwest of Honolulu in the South Pacific
Ocean about halfway between Hawaii and New Zealand
_#_Total area: 510,072,000 km2; 361,132,000 km2 (70.8%) is water and
148,940,000 km2 (29.2%) is land
_#_Comparative area: land area about 16 times the size of the US
_#_Land boundaries: 442,000 km
_#_Coastline: 359,000 km
_#_Maritime claims:
Contiguous zone: generally 24 nm, but varies from 4 nm to 25 nm;
Continental shelf: generally 200 nm, but some are 200 meters
in depth;
Exclusive fishing zone: most are 200 nm, but varies from
3 nm to 200 nm;
Exclusive economic zone: 200 nm; only the Maldives varies from
35-310 nm;
Territorial sea: generally 12 nm, but varies from 3 nm to 50 nm;
note--32 nations and miscellaneous areas are landlocked
and include Afghanistan, Andorra, Austria, Bhutan, Bolivia, Botswana,
Burkina, Burundi, Central African Republic, Chad, Czechoslovakia,
Hungary, Iraq-Saudi Arabia Neutral Zone, Laos, Lesotho, Liechtenstein,
Luxembourg, Malawi, Mali, Mongolia, Nepal, Niger, Paraguay, Rwanda,
San Marino, Swaziland, Switzerland, Uganda, Vatican City, West Bank,
Zambia, Zimbabwe
_#_Disputes: major international land boundary
disputes--Argentina-Uruguay, Bangladesh-India, Brazil-Paraguay,
Brazil-Uruguay, Cambodia-Vietnam, Chad-Libya, China-India, China-USSR,
Ecuador-Peru, Egypt-Sudan, El Salvador-Honduras, Ethiopia-Somalia,
French Guiana-Suriname, Guyana-Suriname, Guyana-Venezuela,
Israel-Jordan, Israel-Syria, North Korea-South Korea, Oman-UAE,
Oman-Yemen, Qatar-UAE, Saudi Arabia-Yemen
_#_Climate: two large areas of polar climates separated by two rather
narrow temperate zones from a wide equatorial band of tropical to
subtropical climates
_#_Terrain: highest elevation is Mt. Everest at 8,848 meters and
lowest depression is the Dead Sea at 392 meters below sea level; greatest
ocean depth is the Marianas Trench at 10,924 meters
_#_Natural resources: the oceans represent the last major frontier for
the discovery and development of natural resources
_#_Land use: arable land 10%; permanent crops 1%; meadows and pastures
24%; forest and woodland 31%; other 34%; includes irrigated 1.6%
_#_Environment: large areas subject to severe weather (tropical
cyclones), natural disasters (earthquakes, landslides, tsunamis, volcanic
eruptions), overpopulation, industrial disasters, pollution (air, water,
acid rain, toxic substances), loss of vegetation (overgrazing,
deforestation, desertification), loss of wildlife resources, soil
degradation, soil depletion, erosion
_#_Total area: 527,970 km2; land area: 527,970 km2; includes Perim,
Socotra, the former Yemen Arab Republic (YAR or North Yemen), and
the former People''s Democratic Republic of Yemen (PDRY or South Yemen)
_#_Comparative area: slightly larger than twice the size of Wyoming
_#_Land boundaries: 1,746 km total; Oman 288 km, Saudi Arabia 1,458 km
_#_Coastline: 1,906 km
_#_Maritime claims:
Contiguous zone: North--18 nm; South--24 nm;
Continental shelf: North--200 meters (depth); South--edge of
continental margin or 200 nm;
Exclusive economic zone: North--no claim; South 200 nm;
Territorial sea: 12 nm
_#_Disputes: undefined section of boundary with Saudi Arabia;
Administrative Line with Oman
_#_Climate: desert; hot and humid along west coast; temperate in
western mountains; extraordinarily hot, dry, harsh desert in east
_#_Terrain: narrow coastal plain backed by flat-topped hills and
rugged mountains; dissected upland desert plains in center slope into
the desert interior of the Arabian Peninsula
_#_Natural resources: crude oil, fish, rock salt, marble; small
deposits of coal, gold, lead, nickel, and copper; fertile soil in west
_#_Land use: arable land 6%; permanent crops NEGL%; meadows and
pastures 30%; forest and woodland 7%; other 57%; includes irrigated
NEGL%
_#_Environment: subject to sand and dust storms in summer; scarcity of
natural freshwater resources; overgrazing; soil erosion; desertification
_#_Note: controls Bab el Mandeb, the strait linking the Red Sea and
the Gulf of Aden, one of world''s most active shipping lanes','5ac11449d48177fe38b04c67f5a727654428cc2a2d6d89500eca158177008f18','internet-archive','theciaworldfactb00025gut','txt','84185fe9df79da427349cc1598fd3f69814a2085a9fc1fe0508a3fae0a870f84','https://archive.org/download/theciaworldfactb00025gut/25.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ee76689efdd72928f603e6ad9df3b1af9f06c08a1931c9206e382a57d5779631',1991,'DJ','Djibouti','geography',151,'_#_Total area: 255,800 km2; land area: 255,400 km2
_#_Comparative area: slightly larger than Wyoming
_#_Land boundaries: 2,961 km total; Albania 486 km, Austria 311 km,
Bulgaria 539 km, Greece 246 km, Hungary 631 km, Italy 202 km, Romania
546 km
_#_Coastline: 3,935 km (including 2,414 km offshore islands)
_#_Maritime claims:
Continental shelf: 200 m (depth) or to depth of exploitation;
Territorial sea: 12 nm
_#_Disputes: Kosovo question with Albania; Macedonia question with
Bulgaria and Greece
_#_Climate: temperate; hot, relatively dry summers with mild, rainy
winters along coast; warm summer with cold winters inland
_#_Terrain: mostly mountains with large areas of karst topography;
plain in north
_#_Natural resources: coal, copper, bauxite, timber, iron ore,
antimony, chromium, lead, zinc, asbestos, mercury, crude oil, natural
gas, nickel, uranium
_#_Land use: arable land 28%; permanent crops 3%; meadows and pastures
25%; forest and woodland 36%; other 8%; includes irrigated 1%
_#_Environment: subject to frequent and destructive earthquakes
_#_Note: controls the most important land routes from
central and western Europe to Aegean Sea and Turkish straits
_#_Total area: 2,345,410 km2; land area: 2,267,600 km2
_#_Comparative area: slightly more than one-quarter the size of US
_#_Land boundaries: 10,271 km total; Angola 2,511 km, Burundi 233 km,
Central African Republic 1,577 km, Congo 2,410 km, Rwanda 217 km, Sudan
628 km, Uganda 765 km, Zambia 1,930 km
_#_Coastline: 37 km
_#_Maritime claims:
Territorial sea: 12 nm
_#_Disputes: Tanzania-Zaire-Zambia tripoint in Lake Tanganyika may no
longer be indefinite since it is reported that the indefinite section of
the Zaire-Zambia boundary has been settled; long section with Congo along
the Congo River is indefinite (no division of the river or its islands
has been made)
_#_Climate: tropical; hot and humid in equatorial river basin; cooler
and drier in southern highlands; cooler and wetter in eastern highlands;
north of Equator--wet season April to October, dry season December to
February; south of Equator--wet season November to March, dry season
April to October
_#_Terrain: vast central basin is a low-lying plateau; mountains in
east
_#_Natural resources: cobalt, copper, cadmium, crude oil, industrial
and gem diamonds, gold, silver, zinc, manganese, tin, germanium, uranium,
radium, bauxite, iron ore, coal, hydropower potential
_#_Land use: arable land 3%; permanent crops NEGL%; meadows and
pastures 4%; forest and woodland 78%; other 15%; includes irrigated
NEGL%
_#_Environment: dense tropical rainforest in central river basin and
eastern highlands; periodic droughts in south
_#_Note: straddles Equator; very narrow strip of land is only outlet
to South Atlantic Ocean
_#_Total area: 752,610 km2; land area: 740,720 km2
_#_Comparative area: slightly larger than Texas
_#_Land boundaries: 5,664 km total; Angola 1,110 km, Malawi 837 km,
Mozambique 419 km, Namibia 233 km, Tanzania 338 km, Zaire 1,930 km,
Zimbabwe 797 km
_#_Coastline: none--landlocked
_#_Maritime claims: none--landlocked
_#_Disputes: quadripoint with Botswana, Namibia, and Zimbabwe is in
disagreement; Tanzania-Zaire-Zambia tripoint in Lake Tanganyika may no
longer be indefinite since it is reported that the indefinite section of
the Zaire-Zambia boundary has been settled
_#_Climate: tropical; modified by altitude; rainy season (October to
April)
_#_Terrain: mostly high plateau with some hills and mountains
_#_Natural resources: copper, cobalt, zinc, lead, coal, emeralds,
gold, silver, uranium, hydropower potential
_#_Land use: arable land 7%; permanent crops NEGL%; meadows and
pastures 47%; forest and woodland 27%; other 19%; includes irrigated
NEGL%
_#_Environment: deforestation; soil erosion; desertification
_#_Note: landlocked
_#_Total area: 390,580 km2; land area: 386,670 km2
_#_Comparative area: slightly larger than Montana
_#_Land boundaries: 3,066 km total; Botswana 813 km, Mozambique
1,231 km, South Africa 225 km, Zambia 797 km
_#_Coastline: none--landlocked
_#_Maritime claims: none--landlocked
_#_Disputes: quadripoint with Botswana, Namibia, and Zambia is in
disagreement
_#_Climate: tropical; moderated by altitude; rainy season (November to
March)
_#_Terrain: mostly high plateau with higher central plateau (high
veld); mountains in east
_#_Natural resources: coal, chromium ore, asbestos, gold, nickel,
copper, iron ore, vanadium, lithium, tin, platinum group metals
_#_Land use: arable land 7%; permanent crops NEGL%; meadows and
pastures 12%; forest and woodland 62%; other 19%; includes irrigated
NEGL%
_#_Environment: recurring droughts; floods and severe storms are rare;
deforestation; soil erosion; air and water pollution
_#_Note: landlocked
_#_Total area: 35,980 km2; land area: 32,260 km2; includes the
Pescadores, Matsu, and Quemoy
_#_Comparative area: slightly less than three times the size of
Connecticut
_#_Land boundaries: none
_#_Coastline: 1,448 km
_#_Maritime claims:
Exclusive economic zone: 200 nm;
Territorial sea: 12 nm
_#_Disputes: involved in complex dispute over the Spratly Islands with
China, Malaysia, Philippines, and Vietnam; Paracel Islands occupied by
China, but claimed by Vietnam and Taiwan; Japanese-administered
Senkaku-shoto (Senkaku Islands/Diaoyu Tai) claimed by China and Taiwan
_#_Climate: tropical; marine; rainy season during southwest monsoon
(June to August); cloudiness is persistent and extensive all year
_#_Terrain: eastern two-thirds mostly rugged mountains; flat to gently
rolling plains in west
_#_Natural resources: small deposits of coal, natural gas, limestone,
marble, and asbestos
_#_Land use: arable land 24%; permanent crops 1%; meadows and pastures
5%; forest and woodland 55%; other 15%; irrigated 14%
_#_Environment: subject to earthquakes and typhoons','43c306513c0ffe46b8ceb01ff17d05d72405dd9e9964958056e3350c4efe1a7d','internet-archive','theciaworldfactb00025gut','txt','84185fe9df79da427349cc1598fd3f69814a2085a9fc1fe0508a3fae0a870f84','https://archive.org/download/theciaworldfactb00025gut/25.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);

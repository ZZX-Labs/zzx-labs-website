SET NAMES utf8mb4;
CREATE TABLE IF NOT EXISTS worldfactbook_chunks (
  chunk_id CHAR(64) NOT NULL,
  edition_year SMALLINT UNSIGNED NOT NULL,
  entity_code VARCHAR(24) NOT NULL DEFAULT '',
  entity_name VARCHAR(160) NOT NULL DEFAULT '',
  category VARCHAR(96) NOT NULL,
  ordinal INT UNSIGNED NOT NULL,
  content MEDIUMTEXT NOT NULL,
  content_sha256 CHAR(64) NOT NULL,
  source_provider VARCHAR(64) NOT NULL,
  source_identifier VARCHAR(255) NOT NULL,
  source_format VARCHAR(32) NOT NULL,
  source_sha256 CHAR(64) NOT NULL,
  source_url TEXT NOT NULL,
  extractor VARCHAR(64) NOT NULL,
  PRIMARY KEY (chunk_id),
  KEY idx_wfb_year_category (edition_year, category),
  KEY idx_wfb_entity_year (entity_code, edition_year),
  KEY idx_wfb_source_sha (source_sha256)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('414f110d8483ba2a3bfffbaedb37d045932b07c128a8730c944984a5e0aa72e7',1991,'','','economy',2,'_#_ the first three characters in each individual entry;
for example, _#_Total area
_#_Comparative area
_#_Land boundaries
_#_Coastline
_%_ the first three characters in the first line following
the end of a country section or an appendix
_%_
THE WORLD FACTBOOK 1991
The World Factbook is produced annually by the Central Intelligence
Agency for the use of United States Government officials, and the style,
format, coverage, and content are designed to meet their specific
requirements.
Information was provided by the Bureau of the Census, Central
Intelligence Agency, Defense Intelligence Agency, Defense Nuclear Agency,
Department of State, Foreign Broadcast Information Service, Maritime
Administration, National Science Foundation (Polar Information Program),
Navy Operational Intelligence Center, Office of Territorial and
International Affairs, United States Board on Geographic Names,
United States Coast Guard, and others.
Comments and queries are welcome and may be addressed to:
Central Intelligence Agency
Attn: Public Affairs
Washington, DC 20505
(703) 351-2053
*************************************************************************
US Government officials should obtain copies of The World Factbook
directly from their own organizations or through liaison channels from
the Central Intelligence Agency. This publication is also available in
microfiche, magnetic tape, or diskettes for microcomputers.
This publication may be purchased by telephone (VISA or MasterCard)
or mail from:
Superintendent of Documents
US Government Printing Office
Washington, DC 20402-9325
Tel: (202) 783-3238
A subscription to this publication may be purchased from:
National Technical Information Service
5285 Port Royal Road
Springfield, VA 22161
Tel: (703) 487-4630
or: Document Expediting (DOCEX) Project
Exchange and Gift Division
Library of Congress
Washington, DC 20540
Tel: (202) 707-9527
This publication may be purchased in photocopy, microfiche, magnetic
tape, or diskettes for microcomputers from:
National Technical Information Service
5285 Port Royal Road
Springfield, VA 22161
Tel: (703) 487-4650
This publication may be purchased in photocopy or microform from:
Photoduplication Service
Library of Congress
Washington, DC 20540
Tel: (202) 707-5640
*************************************************************************
Table of Contents
Notes, Definitions, and Abbreviations
Text (247 nations, dependent areas, and other entities)','d5b683edf9a1bca8f37330954985ec25e0b9a186f29b46576cadf7b8d2020cdb','internet-archive','theciaworldfactb00025gut','txt','84185fe9df79da427349cc1598fd3f69814a2085a9fc1fe0508a3fae0a870f84','https://archive.org/download/theciaworldfactb00025gut/25.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a3917e2f1e96017bcfb6c820f61320b3f27ede58d1c8c8953ec2a32abb750382',1991,'ET','Ethiopia','economy',3,'Europa Island
Falkland Islands (Islas Malvinas)
_#_Overview: Oil has supplanted forestry as the mainstay of the
economy, providing about two-thirds of government revenues and
exports. In the early 1980s rapidly rising oil revenues enabled Congo
to finance large-scale development projects with growth averaging 5%
annually, one of the highest rates in Africa. The world decline in
oil prices, however, has forced the government to launch an austerity
program to cope with declining receipts and mounting foreign debts.
_#_GDP: $2.26 billion, per capita $1,050; real growth rate 0.6%
(1989 est.)
_#_Inflation rate (consumer prices): 4.6% (1989 est.)
_#_Unemployment rate: NA%
_#_Budget: revenues $522 million; expenditures $767 million,
including capital expenditures of $141 million (1989)
_#_Exports: $751 million (f.o.b., 1988);
commodities--crude petroleum 72%, lumber, plywood, coffee, cocoa,
sugar, diamonds;
partners--US, France, other EC
_#_Imports: $564 million (c.i.f., 1988);
commodities--foodstuffs, consumer goods, intermediate manufactures,
capital equipment;
partners--France, Italy, other EC, US, FRG, Spain, Japan, Brazil
_#_External debt: $4.5 billion (December 1988)
_#_Industrial production: growth rate 1.2% (1989); accounts for
33% of GDP, including petroleum
_#_Electricity: 133,000 kW capacity; 300 million kWh produced,
130 kWh per capita (1989)
_#_Industries: crude oil, cement, sawmills, brewery, sugar mill, palm
oil, soap, cigarettes
_#_Agriculture: accounts for 10% of GDP (including fishing and
forestry); cassava accounts for 90% of food output; other crops--rice,
corn, peanuts, vegetables; cash crops include coffee and cocoa; forest
products important export earner; imports over 90% of food needs
_#_Economic aid: US commitments, including Ex-Im (FY70-89), $60
million; Western (non-US) countries, ODA and OOF bilateral commitments
(1970-88), $2.2 billion; OPEC bilateral aid (1979-89), $15 million;
Communist countries (1970-89), $338 million
_#_Currency: Communaute Financiere Africaine franc
(plural--francs); 1 CFA franc (CFAF) = 100 centimes
_#_Exchange rates: Communaute Financiere Africaine francs (CFAF)
per US$1--256.54 (January 1991), 272.26 (1990), 319.01 (1989), 297.85
(1988), 300.54 (1987), 346.30 (1986), 449.26 (1985)
_#_Fiscal year: calendar year
_#_Overview: Agriculture provides the economic base. The major export
earners are fruit, copra, and clothing. Manufacturing activities are
limited to a fruit-processing plant and several clothing factories.
Economic development is hindered by the isolation of the islands from
foreign markets and a lack of natural resources and good transportation
links. A large trade deficit is annually made up for by remittances from
emigrants and from foreign aid. Current economic development plans call
for exploiting the tourism potential and expanding the fishing industry.
_#_GDP: $40.0 million, per capita $2,200 (1988 est.); real growth rate
5.3% (1986-88 est.)
_#_Inflation rate (consumer prices): 8.0% (1988)
_#_Unemployment rate: NA%
_#_Budget: revenues $33.8 million; expenditures $34.4 million,
including capital expenditures of $NA (1990 est.)
_#_Exports: $4.0 million (f.o.b., 1988);
commodities--copra, fresh and canned fruit, clothing;
partners--NZ 80%, Japan
_#_Imports: $38.7 million (c.i.f., 1988);
commodities--foodstuffs, textiles, fuels, timber;
partners--NZ 49%, Japan, Australia, US
_#_External debt: $NA
_#_Industrial production: growth rate NA%
_#_Electricity: 14,000 kW capacity; 21 million kWh produced,
1,170 kWh per capita (1990)
_#_Industries: fruit processing, tourism
_#_Agriculture: export crops--copra, citrus fruits, pineapples,
tomatoes, bananas; subsistence crops--yams, taro
_#_Economic aid: Western (non-US) countries, ODA and OOF bilateral
commitments (1970-89), $128 million
_#_Currency: New Zealand dollar (plural--dollars); 1 New Zealand
dollar (NZ$) = 100 cents
_#_Exchange rates: New Zealand dollars (NZ$) per US$1--1.6798 (January
1991), 1.6750 (1990), 1.6711 (1989), 1.5244 (1988), 1.6886 (1987), 1.9088
(1986), 2.0064 (1985)
_#_Fiscal year: 1 April-31 March
_#_Overview: no economic activity
_#_Overview: In 1990 the economy grew at an estimated 3.5%
rate, a decrease from the strong 5.0% gain of the previous year.
Gains in agricultural production (on the strength of good coffee and
banana crops) and in construction, were partially offset by lower
rates of growth for industry. In 1990 consumer prices rose by about 25%
and the trade deficit widened. Unemployment is officially reported at
6%, but much underemployment remains. External debt, on a per
capita basis, is among the world''s highest.
_#_GDP: $5.5 billion, per capita $1,810; real growth rate 3.6% (1990)
_#_Inflation rate (consumer prices): 25% (1990 est.)
_#_Unemployment rate: 6% (1990)
_#_Budget: revenues $831 million; expenditures $1.08 billion, including
capital expenditures of $NA (1990 est.)
_#_Exports: $1.4 billion (f.o.b., 1990);
commodities--coffee, bananas, textiles, sugar;
partners--US 75%, FRG, Guatemala, Netherlands, UK, Japan
_#_Imports: $1.8 billion (c.i.f., 1990);
commodities--petroleum, machinery, consumer durables, chemicals,
fertilizer, foodstuffs;
partners--US 35%, Japan, Guatemala, FRG
_#_External debt: $4.5 billion (1989)
_#_Industrial production: growth rate 2.3% (1990 est.); accounts for
23% of GDP
_#_Electricity: 927,000 kW capacity; 2,987 million kWh produced,
980 kWh per capita (1990)
_#_Industries: food processing, textiles and clothing, construction
materials, fertilizer, plastic products
_#_Agriculture: accounts for 20-25% of GDP and 70% of exports; cash
commodities--coffee, beef, bananas, sugar; other food crops include corn,
rice, beans, potatoes; normally self-sufficient in food except for
grain; depletion of forest resources resulting in lower timber output
_#_Illicit drugs: illicit production of cannabis on small scattered
plots; transshipment country for cocaine from South America
_#_Economic aid: US commitments, including Ex-Im (FY70-89), $1.4
billion; Western (non-US) countries, ODA and OOF bilateral commitments
(1970-88), $781 million; Communist countries (1971-88), $27 million
_#_Currency: Costa Rican colon (plural--colones);
1 Costa Rican colon (C) = 100 centimos
_#_Exchange rates: Costa Rican colones (C) per US$1--105.82 (January
1991), 91.58 (1990), 81.504 (1989), 75.805 (1988), 62.776 (1987), 55.986
(1986), 50.453 (1985)
_#_Fiscal year: calendar year
_#_Overview: The economy, centrally planned and largely state owned,
is highly dependent on the agricultural sector and foreign trade. Sugar
provides about 75% of export revenues and over half is exported to the
USSR. The economy has stagnated since 1985 under policies that have
deemphasized material incentives in the workplace, abolished farmers''
informal produce markets, and raised prices of government-supplied goods
and services. In 1990 the economy probably fell 3%, largely as a result
of declining trade with the Soviet Union and Eastern Europe. Recently
the government has been trying to increase trade with Latin America and
China. Cuba has had difficulty servicing its foreign debt since 1982. The
government currently is encouraging foreign investment in tourist
facilities. Other investment priorities include sugar, basic foods, and
nickel. The annual $4 billion Soviet subsidy, a main prop to Cuba''s
threadbare economy, is likely to show a substantial decline over the
next few years in view of the USSR''s mounting economic problems. Instead
of highly subsidized trade, Cuba will be shifting to trade at market
prices in convertible currencies. In early 1991, the shortages of fuels,
spare parts, and industrial products in general had become so severe as
to amount to a deindustrialization process in the eyes of some observers.
_#_GNP: $20.9 billion, per capita $2,000; real growth rate - 3%
(1990 est.)
_#_Inflation rate (consumer prices): NA%
_#_Unemployment: 6% overall, 10% for women (1989)
_#_Budget: revenues $12.46 billion; expenditures $14.45 billion,
including capital expenditures of $NA (1990 est.)
_#_Exports: $5.4 billion (f.o.b., 1989);
commodities--sugar, nickel, shellfish, citrus, tobacco, coffee;
partners--USSR 67%, GDR 6%, China 4% (1988)
_#_Imports: $8.1 billion (c.i.f., 1989);
commodities--capital goods, industrial raw materials, food,
petroleum;
partners--USSR 71%, other Communist countries 15% (1988)
_#_External debt: $6.8 billion (convertible currency, July 1989)
_#_Industrial production: 3% (1988); accounts for 45% of GDP
_#_Electricity: 3,890,000 kW capacity; 16,267 million kWh produced,
1,530 kWh per capita (1990)
_#_Industries: sugar milling, petroleum refining, food and tobacco
processing, textiles, chemicals, paper and wood products, metals
(particularly nickel), cement, fertilizers, consumer goods, agricultural
machinery
_#_Agriculture: accounts for 11% of GNP (including fishing and
forestry); key commercial crops--sugarcane, tobacco, and citrus fruits;
other products--coffee, rice, potatoes, meat, beans; world''s largest
sugar exporter; not self-sufficient in food (excluding sugar)
_#_Economic aid: Western (non-US) countries, ODA and OOF bilateral
commitments (1970-88), $695 million; Communist countries (1970-89),
$18.5 billion
_#_Currency: Cuban peso (plural--pesos); 1 Cuban peso (Cu$) = 100
centavos
_#_Exchange rates: Cuban pesos (Cu$) per US$1--1.0000 (linked to the
US dollar)
_#_Fiscal year: calendar year
_#_Overview: These data are for the area controlled by the Republic of
Cyprus (information on the northern Turkish-Cypriot area is sparse).
The economy is small, diversified, and prosperous. Industry contributes
about 25% to GDP and employs 35% of the labor force, while the service
sector contributes about 55% to GDP and employs 40% of the labor force.
Rapid growth in exports of agricultural and manufactured products
and in tourism have played important roles in the average 6% rise in GDP
in recent years.
_#_GDP: $5.4 billion, per capita $7,960; real growth rate 5.5%
(1990)
_#_Inflation rate (consumer prices): 4.5% (1990)
_#_Unemployment rate: below 2% (1990)
_#_Budget: revenues $1.2 billion; expenditures $1.4 billion, including
capital expenditures of $178 million (1989 est.)
_#_Exports: $770 million (f.o.b., 1990);
commodities--citrus, potatoes, grapes, wine, cement, clothing and
shoes;
partners--UK 23%, Greece 10%, Lebanon 9%, Saudi Arabia 4%
_#_Imports: $2.5 billion (f.o.b., 1990);
commodities--consumer goods, petroleum and lubricants, food and
feed grains, machinery;
partners--France 12%, UK 11%, Japan 11%, Italy 10%
_#_External debt: $2.2 billion (1990)
_#_Industrial production: growth rate 6.5% (1988); accounts for
27% of GDP
_#_Electricity: 620,000 kW capacity; 1,770 million kWh produced,
2,530 kWh per capita (1989)
_#_Industries: food, beverages, textiles, chemicals, metal products,
tourism, wood products
_#_Agriculture: accounts for 7% of GDP and employs 22% of labor force;
major crops--potatoes, vegetables, barley, grapes, olives, and citrus
fruits; vegetables and fruit provide 25% of export revenues
_#_Economic aid: US commitments, including Ex-Im (FY70-89), $292
million; Western (non-US) countries, ODA and OOF bilateral commitments
(1970-87), $230 million; OPEC bilateral aid (1979-89), $62 million;
Communist countries (1970-89), $24 million
_#_Currency: Cypriot pound (plural--pounds) and in Turkish area,
Turkish lira (plural--liras); 1 Cypriot pound (5C) = 100 cents and
1 Turkish lira
(TL) = 100 kurus
_#_Exchange rates: Cypriot pounds (5C) per US$1--0.4325 (December
1990), 0.4572 (1990), 0.4933 (1989), 0.4663 (1988), 0.4807 (1987), 0.5167
(1986), 0.6095 (1985); in Turkish area, Turkish liras (TL) per
US$1--2,873.9 (December 1990), 2,608.6 (1990), 2,121.7 (1989), 1,422.3
(1988), 857.2 (1987), 674.5 (1986), 522.0 (1985)
_#_Fiscal year: calendar year
_#_Overview: Czechoslovakia is highly industrialized and has a
well-educated and skilled labor force. Its industry, transport, energy
sources, banking, and most other means of production are state owned. The
country is deficient, however, in energy and in many raw materials.
Moreover, its aging capital plant lags well behind West European
standards. Industry contributes almost 50% to GNP and construction
contributes 10%. About 95% of agricultural land is in collectives or
state farms. The centrally planned economy has been tightly linked in
trade (80%) to the USSR and Eastern Europe. Growth has been sluggish,
averaging less than 2% in the period 1982-89. GNP per capita is the
highest in Eastern Europe. As in the rest of Eastern Europe, the sweeping
political changes of 1989-90 have been disrupting normal channels of
supply and compounding the government''s economic problems. Having eased
restrictions on private enterprise in 1990 and having adjusted some key
prices, Czechoslovakia is now implementing a broad two-year program
to make the difficult transition from a command to a market economy.
Inflation and unemployment are beginning to rise, albeit from
comparatively low levels.
_#_GNP: $120.3 billion, per capita $7,700; real growth rate - 2.9%
(1990 est.)
_#_Inflation rate (consumer prices): 9% (1990 est.)
_#_Unemployment rate: officially 0.8% (1990)
_#_Budget: revenues $17.1 billion; expenditures $16.8 billion,
including capital expenditures of $1.5 billion (1991)
_#_Exports: $14.4 billion (f.o.b., 1989);
commodities--machinery and equipment 42.7%; fuels, minerals,
and metals 16.4%; agricultural and forestry products 12.5%, other
28.4%;
partners--USSR, GDR, Poland, Hungary, FRG, Yugoslavia, Austria,
Bulgaria, Romania, US
_#_Imports: $14.3 billion (f.o.b., 1989);
commodities--machinery and equipment 38.6%;
fuels, minerals, and metals 24.1%; agricultural and forestry
products 16.4%; other 20.9%;
partners--USSR, GDR, Poland, Hungary, FRG, Yugoslavia, Austria,
Bulgaria, Romania, US
_#_External debt: $7.6 billion, hard currency indebtedness (September
1990)
_#_Industrial production: growth rate - 3.3% (1990 est.); accounts
for almost 50% of GDP
_#_Electricity: 23,000,000 kW capacity; 90,000 million kWh produced,
5,740 kWh per capita (1990)
_#_Industries: iron and steel, machinery and equipment, cement, sheet
glass, motor vehicles, armaments, chemicals, ceramics, wood, paper
products, footwear
_#_Agriculture: accounts for 7% of GNP (includes forestry); largely
self-sufficient in food production; diversified crop and livestock
production, including grains, potatoes, sugar beets, hops, fruit, hogs,
cattle, and poultry; exporter of forest products
_#_Economic aid: donor--$4.2 billion in bilateral aid to non-Communist
less developed countries (1954-89)
_#_Currency: koruna (plural--koruny); 1 koruna (Kc) = 100 haleru
_#_Exchange rates: koruny (Kcs) per US$1--27.65 (January 1991),
17.95 (1990), 15.05 (1989), 14.36 (1988), 13.69 (1987), 14.99 (1986),
17.14 (1985)
_#_Fiscal year: calendar year','1d5002d496335cc510343a3de500c992a97e50a056f6ce1908b84f8fd84334a5','internet-archive','theciaworldfactb00025gut','txt','84185fe9df79da427349cc1598fd3f69814a2085a9fc1fe0508a3fae0a870f84','https://archive.org/download/theciaworldfactb00025gut/25.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('65a87fbb2ce6905e208a1d092630ce1421f53d2b8e5df21f3d978b41224be350',1991,'ID','Indonesia','economy',4,'Iran
_#_Overview: Financial assistance from the US is the primary source
of revenue, with the US pledged to spend $1 billion in the islands in the
1990s; also in December 1990 the US authorized the use of disaster
relief funds for Micronesia because of damage from Typhoon Russ.
In addition Micronesia earns about $4 million a year in fees from foreign
commercial fishing concerns. Economic activity consists primarily of
subsistence farming and fishing. The islands have few mineral deposits
worth exploiting, except for high-grade phosphate. The potential for a
tourist industry exists, but the remoteness of the location and a lack of
adequate facilities hinder development.
_#_GNP: $150 million, per capita $1,500; real growth rate NA%
(1989 est.); note--GNP numbers reflect US spending
_#_Inflation rate (consumer prices): NA%
_#_Unemployment rate: 80% (1988)
_#_Budget: revenues $110.8 million; expenditures NA, including
capital expenditures of NA (1987 est.)
_#_Exports: $1.6 million (f.o.b., 1983);
commodities--copra;
partners--NA
_#_Imports: $48.9 million (c.i.f., 1983);
commodities--NA;
partners--NA
_#_External debt: $NA
_#_Industrial production: growth rate NA%
_#_Electricity: 18,000 kW capacity; 40 million kWh produced,
380 kWh per capita (1990)
_#_Industries: tourism, craft items from shell, wood, and pearl
_#_Agriculture: mainly a subsistence economy; copra, black pepper;
tropical fruits and vegetables, coconuts, cassava, sweet potatoes, pigs,
chickens
_#_Economic aid: under terms of the Compact of Free Association, the
US will provide $1.3 billion in grant aid during the period 1986-2001
_#_Currency: US currency is used
_#_Exchange rates: US currency is used
_#_Fiscal year: 1 October-30 September
_#_Overview: The economy is based on providing support services for US
naval operations located on the islands. All food and manufactured goods
must be imported.
_#_Electricity: supplied by US Military
_#_Overview: Monaco, situated on the French Mediterranean coast, is a
popular resort, attracting tourists to its casino and pleasant climate.
The Principality has successfully sought to diversify into services and
small, high-value-added, non-polluting industries. The state has no
income tax and low business taxes and thrives as a tax haven both for
individuals who have established residence and for foreign companies that
have set up businesses and offices. About 50% of Monaco''s annual revenue
comes from value-added taxes on hotels, banks, and the industrial sector;
about 25% of revenue comes from tourism. Living standards are high, that
is, roughly comparable to those in prosperous French metropolitan
suburbs.
_#_GDP: $324 million, per capita $11,000; real growth rate NA%
(1990 est.)
_#_Inflation rate (consumer prices): NA%
_#_Unemployment rate: full employment (1989)
_#_Budget: revenues $386 million; expenditures $426, including capital
expenditures of $NA (1988 est.)
_#_Exports: $NA; full customs integration with France, which collects
and rebates Monacan trade duties; also participates in EC market system
through customs union with France
_#_Imports: $NA; full customs integration with France, which collects
and rebates Monacan trade duties; also participates in EC market system
through customs union with France
_#_External debt: $NA
_#_Industrial production: growth rate NA%
_#_Electricity: 10,000 kW standby capacity (1988); power supplied by','04c227b57fb71a37ce3af36ba98918088523ca61e9369ebac7c248741ea7ca2e','internet-archive','theciaworldfactb00025gut','txt','84185fe9df79da427349cc1598fd3f69814a2085a9fc1fe0508a3fae0a870f84','https://archive.org/download/theciaworldfactb00025gut/25.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('94e6fc7b76f7b603a0c447092b33aa61a2c98c67ff7f218a5e7e463c4d5257d0',1991,'IT','Italy','economy',5,'Ivory Coast
_#_Industries: printing and production of a small amount of mosaics
and staff uniforms; worldwide banking and financial activities
_#_Currency: Vatican lira (plural--lire);
1 Vatican lira (VLit) = 100 centesimi
_#_Exchange rates: Vatican lire (VLit) per US$1--1,134.4 (January
1991), 1,198.1 (1990), 1,372.1 (1989), 1,301.6 (1988), 1,296.1 (1987),
1,490.8 (1986), 1,909.4 (1985); note--the Vatican lira is at par with the
Italian lira which circulates freely
_#_Fiscal year: calendar year
_#_Overview: Petroleum is the cornerstone of the economy and accounted
for 21% of GDP, 60% of central government revenues, and 81% of export
earnings in 1989. President Perez introduced an economic readjustment
program when he assumed office in February 1989. Lower tariffs and
price supports, a free market exchange rate, and market-linked interest
rates have thrown the economy into confusion, causing about an 8%
decline in GDP in 1989, but the economy recovered part way in 1990.
_#_GDP: $42.4 billion, per capita $2,150; real growth rate 4.4%
(1990 est.)
_#_Inflation rate (consumer prices): 40.7% (1990)
_#_Unemployment rate: 10.4% (1990)
_#_Budget: revenues $8.4 billion; expenditures $8.6 billion,
including capital expenditures of $5.9 billion (1989)
_#_Exports: $12.1 billion (f.o.b., 1989 est.);
commodities--petroleum 81%, bauxite and aluminum, iron ore,
agricultural products, basic manufactures;
partners--US 50.7%, Europe 13.7%, Japan 4.0% (1989)
_#_Imports: $8.7 billion (f.o.b., 1989);
commodities--foodstuffs, chemicals, manufactures, machinery and
transport equipment;
partners--US 44%, FRG 8.0%, Japan 4%, Italy 7%, Canada 2% (1989)
_#_External debt: $33.2 billion (1990)
_#_Industrial production: growth rate - 11% (1989 est.); accounts for
one-fourth of GDP, including petroleum
_#_Electricity: 19,733,000 kW capacity; 54,660 million kWh produced,
2,780 kWh per capita (1990)
_#_Industries: petroleum, iron-ore mining, construction materials,
food processing, textiles, steel, aluminum, motor vehicle assembly
_#_Agriculture: accounts for 6% of GDP and 16% of labor force;
products--corn, sorghum, sugarcane, rice, bananas, vegetables, coffee,
beef, pork, milk, eggs, fish; not self-sufficient in food other than meat
_#_Illicit drugs: illicit producer of cannabis and coca leaf
for the international drug trade on a small scale; however, large
quantities of cocaine do transit the country
_#_Economic aid: US commitments, including Ex-Im (FY70-86), $488
million; Communist countries (1970-89), $10 million
_#_Currency: bolivar (plural--bolivares);
1 bolivar (Bs) = 100 centimos
_#_Exchange rates: bolivares (Bs) per US$1--51.331 (January 1991),
46.900 (1990), 34.6815 (1989), 14.5000 (fixed rate 1987-88), 8.0833
(1986), 7.5000 (1985)
_#_Fiscal year: calendar year
_#_Overview: This is a centrally planned, developing economy with
extensive government ownership and control of productive facilities.
The economy is primarily agricultural; the sector employs about 65% of
the labor force and accounts for almost half of GNP. Rice is the staple
crop; substantial amounts of maize, sorghum, cassava, and sweet potatoes
are also grown. The government permits sale of surplus grain on the open
market. Most of the mineral resources are located in the north,
including coal, which is an important export item. Oil was discovered
off the southern coast in 1986 with production reaching 54,000 b/d in
1990 and expected to increase in the years ahead. Following the
end of the war in 1975, heavy-handed government measures undermined
efforts at an efficient merger of the agricultural resources of the
south and the industrial resources of the north. The economy remains
heavily dependent on foreign aid and has received assistance from
Communist countries, Sweden, and UN agencies. Inflation, although down
from recent triple-digit levels, is still a major weakness and is
showing signs of accelerating upwards again. Per capita output is among
the world''s lowest. Since late 1986 the government has sponsored a
broad reform program that seeks to turn more economic activity over to
the private sector.
_#_GNP: $15.2 billion, per capita $230; real growth rate 2.4%
(1990 est.)
_#_Inflation rate (consumer prices): 65% (1990 est.)
_#_Unemployment rate: 33% (1990 est.)
_#_Budget: revenues $892 million; expenditures $1.3 billion, including
capital expenditures of $344 million (1990 est.)
_#_Exports: $2.3 billion (f.o.b., 1990 est.);
commodities--agricultural and handicraft products, coal, minerals,
crude petroleum, ores, seafood;
partners--USSR, Eastern Europe, Japan, Singapore
_#_Imports: $2.6 billion (c.i.f., 1990 est.);
commodities--petroleum products, steel products, railroad
equipment, chemicals, medicines, raw cotton, fertilizer, grain;
partners--USSR, Eastern Europe, Japan, Singapore
_#_External debt: $16.8 billion (1990 est.)
_#_Industrial production: growth rate 10% (1989); accounts for 30%
of GNP
_#_Electricity: 2,740,000 kW capacity; 7,500 million kWh produced,
110 kWh per capita (1990)
_#_Industries: food processing, textiles, machine building, mining,
cement, chemical fertilizer, glass, tires, oil, fishing
_#_Agriculture: accounts for half of GNP; paddy rice, corn, potatoes
make up 50% of farm output; commercial crops (rubber, soybeans, coffee,
tea, bananas) and animal products other 50%; since 1989 self-sufficient
in food staple rice; fish catch of 943,100 metric tons (1989 est.)
_#_Economic aid: US commitments, including Ex-Im (FY70-74), $3.1
billion; Western (non-US) countries, ODA and OOF bilateral commitments
(1970-88), $2.8 billion; OPEC bilateral aid (1979-89), $61 million;
Communist countries (1970-89), $12.0 billion
_#_Currency: new dong (plural--new dong); 1 new dong (D) = 100 xu
_#_Exchange rates: new dong (D) per US$1--7,530 (May 1991),
7,280 (December 1990), 3,996 (March 1990), 2,047 (1988), 225 (1987),
18 (1986), 12 (1985); note--1985-89 figures are end of year
_#_Fiscal year: calendar year','f59578096d280f116efe26d3e74de95670ace7de232d7b6f6cb20c7c9389daba','internet-archive','theciaworldfactb00025gut','txt','84185fe9df79da427349cc1598fd3f69814a2085a9fc1fe0508a3fae0a870f84','https://archive.org/download/theciaworldfactb00025gut/25.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3eecbdcfdb182bc467e5e92405b60db7be881a34113d4d559cb6ead8a8c1f6f7',1991,'LU','Luxembourg','economy',6,'Macau
_#_Overview: The stable economy features moderate growth, low
inflation, and negligible unemployment. Agriculture is based on small but
highly productive family-owned farms. The industrial sector, until
recently dominated by steel, has become increasingly more diversified,
particularly toward high-technology firms. During the past decade, growth
in the financial sector has more than compensated for the decline in
steel. Services, especially banking, account for a growing proportion
of the economy. Luxembourg participates in an economic union with
Belgium on trade and most financial matters and is also closely connected
economically to the Netherlands.
_#_GDP: $6.9 billion, per capita $18,000; real growth rate 2.5%
(1990)
_#_Inflation rate (consumer prices): 3.5% (1990 est.)
_#_Unemployment rate: 1.3% (1990 est.)
_#_Budget: revenues $2.5 billion; expenditures $2.3 billion, including
capital expenditures of NA (1988)
_#_Exports: $5.4 billion (f.o.b., 1989);
commodities--finished steel products, chemicals, rubber products,
glass, aluminum, other industrial products;
partners--EC 75%, US 5%
_#_Imports: $6.2 billion (c.i.f., 1989 est.);
commodities--minerals, metals, foodstuffs, quality consumer goods;
partners--Belgium 37%, FRG 31%, France 12%, US 2%
_#_External debt: $131.6 million (1989 est.)
_#_Industrial production: growth rate - 1% (1990 est.); accounts for
25% of GDP
_#_Electricity: 1,500,000 kW capacity; 1,163 million kWh produced,
3,170 kWh per capita (1989)
_#_Industries: banking, iron and steel, food processing, chemicals,
metal products, engineering, tires, glass, aluminum
_#_Agriculture: accounts for less than 3% of GDP (including forestry);
principal products--barley, oats, potatoes, wheat, fruits, wine grapes;
cattle raising widespread
_#_Economic aid: none
_#_Currency: Luxembourg franc (plural--francs);
1 Luxembourg franc (LuxF) = 100 centimes
_#_Exchange rates: Luxembourg francs (LuxF) per US$1--31.102 (January
1991), 33.418 (1990), 39.404 (1989), 36.768 (1988), 37.334 (1987), 44.672
(1986), 59.378 (1985); note--the Luxembourg franc is at par with the
Belgian franc, which circulates freely in Luxembourg
_#_Fiscal year: calendar year','ec7e9748cb7be48c5730a41d774488e8e4e8bbdd32abc92beb54b01211bd4b13','internet-archive','theciaworldfactb00025gut','txt','84185fe9df79da427349cc1598fd3f69814a2085a9fc1fe0508a3fae0a870f84','https://archive.org/download/theciaworldfactb00025gut/25.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('953d0f7d1454881876824bffbc65ff3794dc339d69977f4c558c342ef95a5ddd',1991,'MT','Malta','economy',7,'Man, Isle of
_#_Overview: Tourism is the primary economic activity, accounting for
more than 70% of GDP and 70% of employment. The manufacturing sector
consists of textile, electronics, pharmaceutical, and watch assembly
plants. The agricultural sector is small, most food being imported.
International business and financial services are a small but growing
component of the economy. The world''s largest petroleum refinery is at
Saint Croix.
_#_GDP: $1.0 billion, per capita $9,000; real growth rate NA% (1985)
_#_Inflation rate (consumer prices): NA%
_#_Unemployment rate: 2.0% (1990)
_#_Budget: revenues $470 million; expenditures $322 million,
including capital expenditures of $NA (FY90)
_#_Exports: $2.2 billion (f.o.b., 1988);
commodities--refined petroleum products;
partners--US, Puerto Rico
_#_Imports: $3.7 billion (c.i.f., 1988);
commodities--crude oil, foodstuffs, consumer goods, building
materials;
partners--US, Puerto Rico
_#_External debt: $NA
_#_Industrial production: growth rate 12%
_#_Electricity: 358,000 kW capacity; 532 million kWh produced,
5,360 kWh per capita (1990)
_#_Industries: tourism, petroleum refining, watch assembly, rum
distilling, construction, pharmaceuticals, textiles, electronics
_#_Agriculture: truck gardens, food crops (small scale), fruit,
sorghum, Senepol cattle
_#_Economic aid: Western (non-US) countries, ODA and OOF bilateral
commitments (1970-88), $34.5 million
_#_Currency: US currency is used
_#_Exchange rates: US currency is used
_#_Fiscal year: 1 October-30 September
_#_Overview: Economic activity is limited to providing services to US
military personnel and contractors located on the island. All food and
manufactured goods must be imported.
_#_Electricity: supplied by US military
_#_Overview: The economy is limited to traditional subsistence
agriculture, with about 80% of the labor force earning its livelihood
from agriculture (coconuts and vegetables), livestock (mostly pigs),
and fishing. About 4% of the population is employed in government.
Revenues come from French Government subsidies, licensing of fishing
rights to Japan and South Korea, import taxes, and remittances from
expatriate workers in New Caledonia. Wallis and Futuna imports food,
fuel, clothing, machinery, and transport equipment, but its exports
are negligible, consisting of copra and handicrafts.
_#_GDP: $7.5 million, per capita $470; real growth rate NA%
(1990 est.)
_#_Inflation rate (consumer prices): NA%
_#_Unemployment rate: NA%
_#_Budget: revenues $2.7 million; expenditures $2.7 million,
including capital expenditures of $NA (1983)
_#_Exports: negligible;
commodities--copra, handicrafts;
partners--NA
_#_Imports: $6.9 million (c.i.f., 1983);
commodities--foodstuffs, manufactured goods, transportation
equipment, fuel;
partners--France, Australia, New Zealand
_#_External debt: $NA
_#_Industrial production: growth rate NA%
_#_Electricity: 1,200 kW capacity; 1 million kWh produced,
70 kWh per capita (1990)
_#_Industries: copra, handicrafts, fishing, lumber
_#_Agriculture: dominated by coconut production, with subsistence
crops of yams, taro, bananas, and herds of pigs and goats
_#_Economic aid: Western (non-US) countries, ODA and OOF bilateral
commitments (1970-88), $118 million
_#_Currency: Comptoirs Francais du Pacifique franc (plural--francs);
1 CFP franc (CFPF) = 100 centimes
_#_Exchange rates: Comptoirs Francais du Pacifique francs (CFPF) per
US$1--93.28 (January 1991), 99.0 (1990), 115.99 (1989), 108.30 (1988),
109.27 (1987), 125.92 (1986), 163.35 (1985); note--linked at the rate of
18.18 to the French franc
_#_Fiscal year: NA
_#_Overview: Economic progress in the West Bank has been hampered by
Israeli military occupation and the effects of the Palestinian uprising.
Industries using advanced technology or requiring sizable financial
resources have been discouraged by a lack of financial resources and
Israeli policy. Capital investment has largely gone into residential
housing, not into productive assets that could compete with Israeli
industry. A major share of GNP is derived from remittances of workers
employed in Israel and neighboring Gulf states but remittances from the
Gulf dropped dramatically in the wake of Iraq''s invasion of Kuwait in
August 1990. Israeli reprisals against Palestinian unrest in the West
Bank since 1987 have pushed unemployment up and lowered living standards.
The Persian Gulf crisis of 1990-91 also dealt a blow to the economy.
Many Palestinians returned from the Gulf, exacerbating unemployment.
Export revenues have plunged because of the loss of export markets in
Jordan and the Gulf.
_#_GNP: $1.0 billion, per capita $1,000; real growth rate - 15% (1988
est.)
_#_Inflation rate (consumer prices): NA%
_#_Unemployment rate: 40% (1990 est.)
_#_Budget: revenues $47.4 million; expenditures $45.7 million,
including capital expenditures of NA (FY86)
_#_Exports: $150 million (f.o.b., 1988 est.); commodities--NA;
partners--Jordan, Israel
_#_Imports: $410 million (c.i.f., 1988 est.); commodities--NA;
partners--Jordan, Israel
_#_External debt: $NA
_#_Industrial production: growth rate NA%
_#_Electricity: power supplied by Israel
_#_Industries: generally small family businesses that produce cement,
textiles, soap, olive-wood carvings, and mother-of-pearl souvenirs; the
Israelis have established some small-scale modern industries in the
settlements and industrial centers
_#_Agriculture: olives, citrus and other fruits, vegetables, beef,
and dairy products
_#_Economic aid: none
_#_Currency: new Israeli shekel (plural--shekels) and Jordanian dinar
(plural--dinars); 1 new Israeli shekel (NIS) = 100 new agorot and
1 Jordanian dinar (JD) = 1,000 fils
_#_Exchange rates: new Israeli shekels (NIS) per US$1--2.35 (May
1991), 2.0161 (1990), 1.9164 (1989), 1.5989 (1988), 1.5946 (1987), 1.4878
(1986), 1.1788 (1985); Jordanian dinars (JD) per US$1--0.6670 (January
1991), 0.6636 (1990), 0.5704 (1989), 0.3709 (1988), 0.3387 (1987), 0.3499
(1986), 0.3940 (1985)
_#_Fiscal year: previously 1 April-31 March; FY91 will be
1 April-31 December and starting 1 January 1992 the fiscal year will
conform to the calendar year
_#_Overview: Western Sahara, a territory poor in natural resources
and having little rainfall, has a per capita GDP of just a few hundred
dollars. Fishing and phosphate mining are the principal industries and
sources of income. Most of the food for the urban population must be
imported. All trade and other economic activities are controlled by the
Moroccan Government.
_#_GDP: $NA, per capita $NA; real growth rate NA%
_#_Inflation rate (consumer prices): NA%
_#_Unemployment rate: NA%
_#_Budget: revenues $NA; expenditures $NA, including capital
expenditures of $NA
_#_Exports: $8 million (f.o.b., 1982 est.);
commodities--phosphates 62%;
partners--Morocco claims and administers Western Sahara, so
trade partners are included in overall Moroccan accounts
_#_Imports: $30 million (c.i.f., 1982 est.);
commodities--fuel for fishing fleet, foodstuffs;
partners--Morocco claims and administers Western Sahara, so
trade partners are included in overall Moroccan accounts
_#_External debt: $NA
_#_Industrial production: growth rate NA%
_#_Electricity: 60,000 kW capacity; 79 million kWh produced,
425 kWh per capita (1989)
_#_Industries: phosphate, fishing, handicrafts
_#_Agriculture: limited largely to subsistence agriculture; some
barley is grown in nondrought years; fruit and vegetables are grown in
the few oases; food imports are essential; camels, sheep, and goats are
kept by the nomadic natives; cash economy exists largely for the garrison
forces
_#_Economic aid: NA
_#_Currency: Moroccan dirham (plural--dirhams);
1 Moroccan dirham (DH) = 100 centimes
_#_Exchange rates: Moroccan dirhams (DH) per US$1--8.071 (January
1991), 8.242 (1990), 8.488 (1989), 8.209 (1988), 8.359 (1987), 9.104
(1986), 10.062 (1985)
_#_Fiscal year: NA
_#_Overview: Agriculture employs more than half of the labor force,
contributes 50% to GDP, and furnishes 90% of exports. The bulk
of export earnings comes from the sale of coconut oil and copra. The
economy depends on emigrant remittances and foreign aid to support a
level of imports about five times export earnings. Tourism has become the
most important growth industry, and construction of the first
international hotel is under way.
_#_GDP: $115 million, per capita $620; real growth rate - 4.5%
(1990 est.)
_#_Inflation rate (consumer prices): 17% (1990 est.)
_#_Unemployment rate: NA%; shortage of skilled labor
_#_Budget: revenues $70 million; expenditures $73 million,
including capital expenditures of $41 million (1990)
_#_Exports: $9.4 million (f.o.b., 1990 est.);
commodities--coconut oil and cream 54%, taro 12%, copra 9%,
cocoa 3%;
partners--NZ 28%, EC 23%, American Samoa 23%, Australia 11%,
US 6% (1990)
_#_Imports: $87 million (c.i.f., 1990 est.);
commodities--intermediate goods 58%, food 17%, capital goods 12%;
partners--New Zealand 31%, Australia 20%, Japan 15%, Fiji 15%,
US 5%, EC 4% (1987)
_#_External debt: $83 million (December 1990 est.)
_#_Industrial production: growth rate - 4.3% (1990 est.); accounts for
14% of GDP
_#_Electricity: 29,000 kW capacity; 45 million kWh produced,
240 kWh per capita (1990)
_#_Industries: timber, tourism, food processing, fishing
_#_Agriculture: accounts for 50% of GDP; coconuts, fruit (including
bananas, taro, yams)
_#_Economic aid: US commitments, including Ex-Im (FY70-89), $18
million; Western (non-US) countries, ODA and OOF bilateral commitments
(1970-88), $291 million; OPEC bilateral aid (1979-89), $4 million
_#_Currency: tala (plural--tala); 1 tala (WS$) = 100 sene
_#_Exchange rates: tala (WS$) per US$1--2.3170 (January 1991), 2.3095
(1990), 2.2686 (1989), 2.0790 (1988), 2.1204 (1987), 2.2351 (1986),
2.2437 (1985)
_#_Fiscal year: calendar year
_#_Overview: In 1990 the world economy grew at an estimated 1.0%,
considerably lower than the estimated 3.0% for 1989 and the 3.4% for
1988. The technologically advanced areas--North America, Japan, and
Western Europe--together account for 67% of the gross world product (GWP)
of $20.9 trillion; these developed areas grew in the aggregate at 2.3%
in 1990. In contrast, output in the USSR and Eastern Europe fell an
average of 5.2%; these countries account for 15% of GWP. Experience
in the developing countries continued mixed, with the newly
industrializing economies generally maintaining their rapid growth,
and many others struggling with debt, rampant inflation, and inadequate
investment. This third group contributed 18% of GWP and grew on
average 2.3% in 1990; output in this group is probably understated
because of lack of data and the method of calculation used. The year 1990
witnessed continued political and economic upheavals in the USSR and
Eastern Europe, which are in between systems, lacking both the rough
discipline of the command economy and the institutions of the market
economy. As for prospects in the 1990s, the addition of nearly 100
million people a year to an already overcrowded globe will exacerbate the
problems of pollution, desertification, underemployment, epidemics,
and famine.
_#_GWP (gross world product): $20.9 trillion, per capita $3,930;
real growth rate 1.0% (1990 est.)
_#_Inflation rate (consumer prices): developed countries 5%;
developing countries 100%, with wide variations (1990 est.)
_#_Unemployment rate: NA%
_#_Exports: $3.33 trillion (f.o.b., 1990 est.);
commodities--the whole range of industrial and agricultural
goods and services;
partners--in value, 74% of exports from industrial countries
_#_Imports: $3.45 trillion (c.i.f., 1990 est.);
commodities--the whole range of industrial and agricultural
goods and services;
partners--in value, about 75% of imports by the industrial
countries
_#_External debt: $1.0 trillion for less developed countries
(1990 est.)
_#_Industrial production: growth rate 3% (1990 est.)
_#_Electricity: 2,864,000,000 kW capacity; 11,450,000 million kWh
produced, 2,150 kWh per capita (1990)
_#_Industries: chemicals, energy, machinery, electronics, metals,
mining, textiles, food processing
_#_Agriculture: cereals (wheat, maize, rice), sugar, livestock
products, tropical crops, fruit, vegetables, fish
_#_Economic aid: NA
_#_Overview: Whereas the northern city Sanaa is the political
capital of a united Yemen, the southern city Aden, with its refinery
and port facilities, is the economic and commercial capital. Future
economic development depends heavily on Western-assisted development
of promising oil resources. South Yemen''s willingness to merge stemmed
partly from the steady decline in Soviet economic support.
North--The low level of domestic industry and agriculture have made
northern Yemen dependent on imports for virtually all of its essential
needs. Large trade deficits have been made up for by remittances from
Yemenis working abroad and foreign aid. Once self-sufficient in food
production, northern Yemen has been a major importer. Land once used for
export crops--cotton, fruit, and vegetables--has been turned over to
growing qat, a mildly narcotic shrub chewed by Yemenis that has no
significant export market. Oil export revenues started flowing in late
1987 and boosted 1988 earnings by about $800 million.
South--This has been one of the poorest Arab countries, with a per
capita GNP of about $500. A shortage of natural resources, a widely
dispersed population, and an arid climate have made economic development
difficult. The economy has grown at an average annual rate of only 2-3%
since the mid-1970s. The economy had been organized along socialist
lines, dominated by the public sector. Economic growth has been
constrained by a lack of incentives, partly stemming from centralized
control over production decisions, investment allocation, and import
choices.
_#_GDP: $5.3 billion, per capita $545; real growth rate NA%
(1990 est.)
_#_Inflation rate (consumer prices):
North--16.9% (1988);
South--0% (1989)
_#_Unemployment rate:
North--13% (1986);
South--NA%
_#_Budget:
North--revenues $1.4 billion; expenditures $2.2 billion,
including capital expenditures of $590 million (1988 est.);
South--revenues and grants $435 million; expenditures $1.0 billion,
including capital expenditure of $460 million (1988 est.)
_#_Exports:
North--$606 million (f.o.b., 1989);
commodities--crude oil, cotton, coffee, hides, vegetables;
partners--FRG 29%, US 26%, Netherlands 12%;
South--$113.8 million (f.o.b., 1989 est.);
commodities--cotton, hides, skins, dried and salted fish;
partners--Japan, North Yemen, Italy
_#_Imports:
North--$1.3 billion (f.o.b., 1988);
commodities--textiles and other manufactured consumer goods,
petroleum products, sugar, grain, flour, other foodstuffs, and cement;
partners--Saudi Arabia 12%, France 6%, US 5%, Australia 5%
(1985);
South--$553.9 million (f.o.b., 1989 est.);
commodities--grain, consumer goods, crude oil, machinery,
chemicals;
partners--USSR, UK, Ethiopia
_#_External debt: $5.75 billion (December 1989 est.)
_#_Industrial production:
North--growth rate 2% in manufacturing (1988);
South--growth rate NA% in manufacturing
_#_Electricity: 670,000 kW capacity; 1,100 million kWh produced,
110 kWh per capita (1990)
_#_Industries: crude oil production and petroleum refining;
small-scale production of cotton textiles and leather goods; food
processing; handicrafts; fishing; small aluminum products factory; cement
_#_Agriculture:
North--accounted for 26% of GDP and 70% of labor force; farm
products--grain, fruits, vegetables, qat (mildly narcotic shrub), coffee,
cotton, dairy, poultry, meat, goat meat; not self-sufficient in grain;
South--accounted for 17% of GNP and 45% of labor force;
products--grain, qat (mildly narcotic shrub), coffee, fish, livestock;
fish and honey major exports; most food imported
_#_Economic aid: US commitments, including Ex-Im (FY70-89), $389
million; Western (non-US) countries, ODA and OOF bilateral commitments
(1970-88), $1.9 billion; OPEC bilateral aid (1979-89), $3.2 billion;
Communist countries (1970-89), $2.4 billion
_#_Currency:
North Yemeni riyal (plural--riyals); 1 North Yemeni riyal
(YR) = 100 fils;
South Yemeni dinar (plural--dinars); 1 South Yemeni dinar
(YD) = 1,000 fils
_#_Exchange rates:
North Yemeni riyals (YR) per US$1--9.7600 (January 1990), 9.7600 (1989),
9.7717 (1988), 10.3417 (1987), 9.6392 (1986), 7.3633 (1985);
South Yemeni dinars (YD) per US$1--0.3454 (fixed rate)
_#_Fiscal year: calendar year','1334f5cf5a1d5ab6d8cc226ae5caa90fb57513be10489879b475c7c7f3db707c','internet-archive','theciaworldfactb00025gut','txt','84185fe9df79da427349cc1598fd3f69814a2085a9fc1fe0508a3fae0a870f84','https://archive.org/download/theciaworldfactb00025gut/25.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fd2fad0dc316a26f22a841b5bdcaf79dd168f1520d42e2fe641b60e18d7033b2',1991,'ES','Spain','economy',8,'Spratly Islands
_#_Imports: $68.9 million (f.o.b., 1989 est.);
commodities--capital equipment, consumer goods, semiprocessed
goods, foods, petroleum;
partners--Portugal, Netherlands, Senegal, USSR, Germany
_#_External debt: $462 million (December 1990 est.)
_#_Industrial production: growth rate - 1.0% (1989 est.); accounts
for 10% of GDP (1989 est.)
_#_Electricity: 22,000 kW capacity; 28 million kWh produced,
30 kWh per capita (1989)
_#_Industries: agricultural processing, beer, soft drinks
_#_Agriculture: accounts for over 50% of GDP, nearly 100% of exports,
and 90% of employment; rice is the staple food; other crops include
corn, beans, cassava, cashew nuts, peanuts, palm kernels, and cotton; not
self-sufficient in food; fishing and forestry potential not fully
exploited
_#_Economic aid: US commitments, including Ex-Im (FY70-89), $49
million; Western (non-US) countries, ODA and OOF bilateral commitments
(1970-88), $561 million; OPEC bilateral aid (1979-89), $41 million;
Communist countries (1970-89), $68 million
_#_Currency: Guinea-Bissauan peso (plural--pesos);
1 Guinea-Bissauan peso (PG) = 100 centavos
_#_Exchange rates: Guinea-Bissauan pesos (PG) per US$1--1987.2 (1989),
1363.6 (1988), 851.65 (1987), 238.98 (1986), 173.61 (1985)
_#_Fiscal year: calendar year
_#_Overview: After growing on average at less than 1% a year in
1986-87, GDP dropped by 3% a year in 1988-89. The decline resulted from
bad weather, labor trouble in the canefields, and flooding and equipment
problems in the bauxite industry. Consumer prices rose about 35% in 1988
and by over 100% in 1989, and the current account deficit widened
substantially as sugar and bauxite exports fell. Moreover, electric
power is in short supply and constitutes a major barrier to future gains
in national output. The government, in association with international
financial agencies, seeks to reduce its payment arrears and to raise new
funds. The government''s stabilization program--aimed at establishing
realistic exchange rates, reasonable price stability, and a resumption of
growth--requires considerable public administrative abilities and
continued patience by consumers during a long incubation period.
_#_GDP: $287.2 million, per capita $380; real growth rate - 3.3%
(1989)
_#_Inflation rate (consumer prices): 105% (1989)
_#_Unemployment rate: 12-15% (1991 est.)
_#_Budget: revenues $65 million; expenditures $129 million, including
capital expenditures of $6 million (1989 est.)
_#_Exports: $234 million (f.o.b., 1991 est.);
commodities--bauxite, sugar, gold, rice, shrimp, molasses, timber,
rum;
partners--UK 31%, US 23%, CARICOM 7%, Canada 6% (1988)
_#_Imports: $319 million (c.i.f., 1991 est.);
commodities--manufactures machinery, food, petroleum;
partners--US 33%, CARICOM 10%, UK 9%, Canada 2% (1989)
_#_External debt: $1.7 billion, including arrears (December 1990 est.)
_#_Industrial production: growth rate - 10.0% (1989 est.); accounts
for more than 20% of GDP
_#_Electricity: 250,000 kW capacity; 635 million kWh produced,
830 kWh per capita (1990)
_#_Industries: bauxite mining, sugar, rice milling, timber, fishing
(shrimp), textiles, gold mining
_#_Agriculture: most important sector, accounting for 27% of GDP and
about 50% of exports; sugar and rice are key crops; development potential
exists for fishing and forestry; not self-sufficient in food, especially
wheat, vegetable oils, and animal products
_#_Economic aid: US commitments, including Ex-Im (FY70-89), $116
million; Western (non-US) countries, ODA and OOF bilateral commitments
(1970-88), $244 million; Communist countries 1970-89, $242 million
_#_Currency: Guyanese dollar (plural--dollars);
1 Guyanese dollar (G$) = 100 cents
_#_Exchange rates: Guyanese dollars (G$) per US$1--45.00 (since June
1990), 39.533 (1990), 27.159 (1989), 10.000 (1988), 9.756 (1987), 4.272
(1986), 4.252 (1985)
_#_Fiscal year: calendar year
_#_Overview: About 85% of the population live in abject poverty.
Agriculture is mainly small-scale subsistence farming and employs
two-thirds of the work force. The majority of the population does not
have ready access to safe drinking water, adequate medical care, or
sufficient food. Few social assistance programs exist, and the lack of
employment opportunities remains one of the most critical problems
facing the economy, along with soil erosion and political instability.
_#_GDP: $2.7 billion, per capita $440; real growth rate - 3.0% (1990
est.)
_#_Inflation rate (consumer prices): 20% (1990 est.)
_#_Unemployment rate: 25-50% (1990 est.)
_#_Budget: revenues $300 million; expenditures $416 million, including
capital expenditures of $145 million (1990 est.)
_#_Exports: $169 million (f.o.b., 1990 est.);
commodities--light manufactures 69%, coffee 19%, other agriculture
8%, other 8%;
partners--US 84%, Italy 4%, France 3%, other industrial 6%,
less developed countries 3% (1987)
_#_Imports: $348 million (c.i.f., 1990 est.);
commodities--machines and manufactures 34%, food and beverages 22%,
petroleum products 14%, chemicals 10%, fats and oils 9%;
partners--US 64%, Netherlands Antilles 5%, Japan 5%, France 4%,
Canada 3%, Germany 3% (1987)
_#_External debt: $838 million (December 1990)
_#_Industrial production: growth rate 0.3% (FY88); accounts for
15% of GDP
_#_Electricity: 230,000 kW capacity; 264 million kWh produced,
43 kWh per capita (1990)
_#_Industries: sugar refining, textiles, flour milling, cement
manufacturing, tourism, light assembly industries based on imported parts
_#_Agriculture: accounts for 33% of GDP and employs 66% of work force;
mostly small-scale subsistence farms; commercial crops--coffee, mangoes,
sugarcane and wood; staple crops--rice, corn, sorghum; shortage of
wheat flour
_#_Illicit drugs: transshipment point for cocaine
_#_Economic aid: US commitments, including Ex-Im (FY70-89), $700
million; Western (non-US) countries, ODA and OOF bilateral commitments
(1970-88), $682 million
_#_Currency: gourde (plural--gourdes); 1 gourde (G) = 100 centimes
_#_Exchange rates: gourdes (G) per US$1-- 5.0 (fixed rate)
_#_Fiscal year: 1 October-30 September
_#_Overview: no economic activity
_#_Overview: Honduras is one of the poorest countries in the Western
Hemisphere. Agriculture, the most important sector of the economy,
accounts for nearly 30% of GDP, employs 62% of the labor force, and
produces two-thirds of exports. Productivity remains low. Industry,
still in its early stages, employs nearly 9% of the labor force,
accounts for 15% of GDP, and generates 20% of exports. The service
sectors, including public administration, account for 50% of GDP and
employ nearly 20% of the labor force. Basic problems facing the
economy include rapid population growth, high unemployment, sharply
increased inflation, a lack of basic services, a large and inefficient
public sector, and the dependence of the export sector mostly on coffee
and bananas, which are subject to sharp price fluctuations. Despite
government efforts at reform and large-scale foreign assistance, the
economy still is unable to take advantage of its sizable natural
resources.
_#_GDP: $4.9 billion, per capita $960; real growth rate -1.0% (1990)
_#_Inflation rate (consumer prices): 35.2% (1990 est.)
_#_Unemployment rate: 15% unemployed, 30-40% underemployed (1989)
_#_Budget: revenues $1.4 billion; expenditures $1.9 billion,
including capital expenditures of $511 million (1990 est.)
_#_Exports: $939 million (f.o.b., 1990);
commodities--bananas, coffee, shrimp, lobster, minerals, lumber;
partners--US 52%, FRG 11%, Japan, Italy, Belgium
_#_Imports: $1.1 billion (c.i.f. 1990);
commodities--machinery and transport equipment, chemical products,
manufactured goods, fuel and oil, foodstuffs;
partners--US 39%, Japan 9%, CACM, Venezuela, Mexico
_#_External debt: $2.8 billion (1990)
_#_Industrial production: growth rate 2.9% (1989); accounts for
15% of GDP
_#_Electricity: 668,000 kW capacity; 2,023 million kWh produced,
380 kWh per capita (1990)
_#_Industries: agricultural processing (sugar and coffee), textiles,
clothing, wood products
_#_Agriculture: most important sector, accounting for nearly 30% of
GDP, over 60% of the labor force, and two-thirds of exports; principal
products include bananas, coffee, timber, beef, citrus fruit, shrimp;
importer of wheat
_#_Illicit drugs: illicit producer of cannabis, cultivated on
small plots and used principally for local consumption; transshipment
point for cocaine
_#_Economic aid: US commitments, including Ex-Im (FY70-89), $1.4
billion; Western (non-US) countries, ODA and OOF bilateral commitments
(1970-88), $1,027 million
_#_Currency: lempira (plural--lempiras); 1 lempira (L) = 100 centavos
_#_Exchange rates: lempiras (L) per US$1--5.30 (fixed rate); 5.70
parallel black-market rate (November 1990)
_#_Fiscal year: calendar year
_#_Overview: Hong Kong has a free market economy with few tariffs
or nontariff barriers. Natural resources are limited, and food and raw
materials must be imported. Manufacturing accounts for about 18% of
GDP, employs 28% of the labor force, and exports about 90% of its
output. Real GDP growth averaged a remarkable 8% in 1987-88, then
slowed to 2.5-3.0% in 1989-90. Unemployment, which has been declining
since the mid-1980s, is now less than 2%. A shortage of labor continues
to put upward pressure on prices and the cost of living. Short-term
prospects remain solid so long as major trading partners continue to be
prosperous. The crackdown in China in 1989-90 casts a long shadow over
the longer term economic outlook.
_#_GDP: $64.0 billion, per capita $11,000; real growth rate 2.5%
(1990)
_#_Inflation rate (consumer prices): 9.8% (1990)
_#_Unemployment rate: 1.8% (1990)
_#_Budget: $8.8 billion (FY90)
_#_Exports: $80.3 billion (f.o.b., 1990), including reexports of
$51.2 billion;
commodities--clothing, textile yarn and fabric, footwear,
electrical appliances, watches and clocks, toys;
partners--US 32%, China 19%, FRG 7%, UK 6%, Japan 6% (1989)
_#_Imports: $79.5 billion (c.i.f., 1990);
commodities--foodstuffs, transport equipment, raw materials,
semimanufactures, petroleum;
partners--China 35%, Japan 17%, Taiwan 9%, US 8% (1989)
_#_External debt: $9.5 billion (December 1990 est.)
_#_Industrial production: growth rate 1.7% (1989)
_#_Electricity: 8,485,000 kW capacity; 25,000 million kWh produced,
4,340 kWh per capita (1990)
_#_Industries: textiles, clothing, tourism, electronics, plastics,
toys, watches, clocks
_#_Agriculture: minor role in the economy; rice, vegetables, dairy
products; less than 20% self-sufficient; shortages of rice, wheat, water
_#_Illicit drugs: a hub for Southeast Asian heroin trade;
transshipment and major financial and money-laundering center
_#_Economic aid: US commitments, including Ex-Im (FY70-87), $152
million; Western (non-US) countries, ODA and OOF bilateral commitments
(1970-88), $910 million
_#_Currency: Hong Kong dollar (plural--dollars);
1 Hong Kong dollar (HK$) = 100 cents
_#_Exchange rates: Hong Kong dollars (HK$) per US$--7.800 (March
1989), 7.810 (1988), 7.760 (1987), 7.795 (1986), 7.811 (1985);
note--linked to the US dollar at the rate of about 7.8 HK$ per 1 US$
since 1985
_#_Fiscal year: 1 April-31 March
_#_Overview: no economic activity
_#_Overview: Agriculture is an important sector, providing sizable
export earnings and meeting domestic food needs. Industry accounts for
about 40% of GNP and 30% of employment. About 40% of Hungary''s foreign
trade is with the USSR and Eastern Europe and a third is with the EC.
Low rates of growth reflect the inability of the Soviet-style economy to
modernize capital plant and motivate workers. GNP declined by 1% in 1989
and by an estimated 6% in 1990. Since 1985 external debt has more than
doubled, to over $20 billion. In recent years Hungary has experimented
widely with decentralized and market-oriented enterprises. The newly
democratic government has renounced the Soviet economic growth model and
plans to open the economy to wider market forces and to much closer
economic relations with Western Europe. Prime Minister Antall has
declared his intention to move foward on privatization of state
enterprises, provision for bankruptcy, land reform, and marketization of
international trade, but concerns over acceptable levels of unemployment
and inflation may slow the reform process.
_#_GNP: $60.9 billion, per capita $5,800; real growth rate - 5.7%
(1990 est.)
_#_Inflation rate (consumer prices): 30% (1990 est.)
_#_Unemployment rate: 1.7% (1990)
_#_Budget: revenues $18.2 billion; expenditures $18.3 billion,
including capital expenditures of $805 million (1989)
_#_Exports: $10.2 billion (f.o.b. 1989);
commodities--capital goods 33%, foods 25%, consumer goods 16%,
fuels 1.5%, other 24.5%;
partners USSR and Eastern Europe 42%, developed countries 37.4%,
less developed countries 20.6% (1989)
_#_Imports: $10.1 billion (c.i.f., 1989);
commodities--capital goods 15%, fuels 20%, manufactured
consumer goods 12.4%, agriculture 5%, other 47.6%;
partners--USSR and Eastern Europe 34.9%, developed countries 45.5%,
less developed countries 16.6%, US 3%
_#_External debt: $20.7 billion (1989)
_#_Industrial production: growth rate - 7.9% (1990 est.)
_#_Electricity: 7,800,000 kW capacity; 30,400 million kWh produced,
2,870 kWh per capita (1990)
_#_Industries: mining, metallurgy, engineering industries, processed
foods, textiles, chemicals (especially pharmaceuticals)
_#_Agriculture: including forestry, accounts for about 15% of GNP
and 19% of employment; highly diversified crop-livestock farming;
principal crops--wheat, corn, sunflowers, potatoes, sugar beets;
livestock--hogs, cattle, poultry, dairy products; self-sufficient in
food output
_#_Economic aid: donor--$2.0 billion in bilateral aid to non-Communist
less developed countries (1962-89)
_#_Currency: forint (plural--forints); 1 forint (Ft) = 100 filler
_#_Exchange rates: forints (Ft) per US$1--60.95 (December 1990), 63.21
(1990), 59.07 (1989), 50.41 (1988), 46.97 (1987), 45.83 (1986), 50.12
(1985)
_#_Fiscal year: calendar year
_#_Overview: Iceland''s prosperous Scandinavian-type economy is
basically capitalistic, but with extensive welfare measures, low
unemployment, and comparatively even distribution of income. The economy
is heavily dependent on the fishing industry, which provides nearly 75%
of export earnings. In the absence of other natural resources, Iceland''s
economy is vulnerable to changing world fish prices. As a result of
climbing fish prices in 1990 and a noninflationary labor agreement,
Iceland is pulling out of a recession, which began in mid-1988 with a
sharp decline in fish prices and an imposition of quotas on fish catches
to conserve stocks. Inflation was down sharply from 20% in 1989
to 8% in 1990.
_#_GDP: $4.2 billion, per capita $16,300; real growth rate 0%
(1990)
_#_Inflation rate (consumer prices): 7.8% (1990)
_#_Unemployment rate: 1.8% (1990)
_#_Budget: revenues $1.58 billion; expenditures $1.66 billion,
including capital expenditures of $NA million (1990)
_#_Exports: $1.6 billion (f.o.b., 1990);
commodities--fish and fish products, animal products, aluminum,
diatomite;
partners--EC 67.7% (UK 25.3%, FRG 12.7%), US 9.9%,
Japan 6%
_#_Imports: $1.7 billion (c.i.f., 1990);
commodities--machinery and transportation equipment, petroleum,
foodstuffs, textiles;
partners--EC 49.8% (FRG 12.4%, Denmark 8.6%, UK 8.1%), US 14.4%,
Japan 5.6%
_#_External debt: $3 billion (1990)
_#_Industrial production: growth rate - 0.8% (1988 est.); accounts
for 22% of GDP
_#_Electricity: 1,063,000 kW capacity; 5,165 million kWh produced,
20,780 kWh per capita (1989)
_#_Industries: fish processing, aluminum smelting, ferro-silicon
production, hydropower
_#_Agriculture: accounts for about 25% of GDP (including fishing);
fishing is most important economic activity, contributing nearly 75%
to export earnings; principal crops--potatoes and turnips;
livestock--cattle, sheep; self-sufficient in crops; fish catch of
about 1.4 million metric tons in 1989
_#_Economic aid: US commitments, including Ex-Im (FY70-81), $19.1
million
_#_Currency: krona (plural--kronur);
1 Icelandic krona (IKr) = 100 aurar
_#_Exchange rates: Icelandic kronur (IKr) per US$1--55.216
(January 1991), 58.284 (1990), 57.042 (1989), 43.014 (1988), 38.677
(1987), 41.104 (1986), 41.508 (1985)
_#_Fiscal year: calendar year
_#_Overview: India''s economy is a mixture of traditional
village farming and handicrafts, modern agriculture, old and new branches
of industry, and a multitude of support services. It presents both the
entrepreneurial skills and drives of the capitalist system and
widespread government intervention of the socialist mold. Growth of 4%
to 5% annually in the 1980s has softened the impact of population growth
on unemployment, social tranquility, and the environment. Agricultural
output has continued to expand, reflecting the greater use of modern
farming techniques and improved seed that have helped to make India
self-sufficient in food grains and a net agricultural exporter. However,
tens of millions of villagers, particularly in the south, have not
benefited from the green revolution and live in abject poverty. Industry
has benefited from a partial liberalization of controls. The growth rate
of the service sector has also been strong. India, however, has been
challenged more recently by much lower foreign exchange reserves, higher
inflation, and a large debt service burden.
_#_GNP: $254 billion, per capita $300; real growth rate 4.5% (1990
est.)
_#_Inflation rate (consumer prices): 10.0% (1990)
_#_Unemployment rate: 20% (1990 est.)
_#_Budget: revenues $34 billion; expenditures $54 billion, including
capital expenditures of $13.3 billion (FY91)
_#_Exports: $17.0 billion (f.o.b., FY90);
commodities--gems and jewelry, engineering goods, clothing,
textiles, chemicals, tea, coffee, fish products;
partners--EC 25%, US 19%, USSR and Eastern Europe 17%, Japan 10%
_#_Imports: $24.8 billion (c.i.f., FY90);
commodities--petroleum, capital goods, uncut gems and jewelry,
chemicals, iron and steel, edible oils;
partners--EC 33%, Middle East 19%, Japan 10%, US 9%, USSR and
Eastern Europe 8%
_#_External debt: $69.8 billion (1990 est.)
_#_Industrial production: growth rate 8.4% (1990); accounts
for about 25% of GDP
_#_Electricity: 70,000,000 kW capacity; 245,000 million kWh produced,
290 kWh per capita (1990)
_#_Industries: textiles, food processing, steel, machinery,
transportation equipment, cement, jute manufactures, mining, petroleum,
power, chemicals, pharmaceuticals, electronics
_#_Agriculture: accounts for about 30% of GNP and employs 67% of
labor force; self-sufficient in food grains; principal crops--rice,
wheat, oilseeds, cotton, jute, tea, sugarcane, potatoes;
livestock--cattle, buffaloes, sheep, goats and poultry; fish catch of
about 3 million metric tons ranks among the world''s top 10 fishing
nations
_#_Illicit drugs: licit producer of opium poppy for the
pharmaceutical trade, but some opium is diverted to illicit
international drug markets; major transit country for illicit narcotics
produced in neighboring countries
_#_Economic aid: US commitments, including Ex-Im (FY70-89), $4.4
billion; Western (non-US) countries, ODA and OOF bilateral commitments
(1980-88), $20.1 billion; OPEC bilateral aid (1979-89), $315 million;
USSR (1970-89), $11.6 billion; Eastern Europe (1970-89), $105 million
_#_Currency: Indian rupee (plural--rupees);
1 Indian rupee (Re) = 100 paise
_#_Exchange rates: Indian rupees (Rs) per US$1--18.329 (January
1990), 17.504 (1990), 16.226 (1989), 13.917 (1988), 12.962 (1987), 12.611
(1986), 12.369 (1985)
_#_Fiscal year: 1 April-31 March
_#_Overview: The Indian Ocean provides a major transportation highway
for the movement of petroleum products from the Middle East to Europe
and North and South American countries. Fish from the ocean are of
growing economic importance to many of the bordering countries as a
source of both food and exports. Fishing fleets from the USSR, Japan,
Korea, and Taiwan also exploit the Indian Ocean for mostly shrimp and
tuna. Large reserves of hydrocarbons are being tapped in the offshore
areas of Saudi Arabia, Iran, India, and Western Australia. An estimated
40% of the world''s offshore oil production comes from the Indian Ocean.
Beach sands rich in heavy minerals and offshore placer deposits are
actively exploited by bordering countries, particularly India, South
Africa, Indonesia, Sri Lanka, and Thailand.
_#_Industries: based on exploitation of natural resources,
particularly marine life, minerals, oil and gas production, fishing, sand
and gravel aggregates, placer deposits
_#_Overview: Indonesia is a mixed economy with many socialist
institutions and central planning but with a recent emphasis on
deregulation and private enterprise. Indonesia has extensive natural
wealth yet, with a large and rapidly increasing population, it remains a
poor country. GDP growth in 1985-89 averaged about 4%, somewhat short of
the more than 5% rate needed to absorb the 2.3 million workers annually
entering the labor force. Agriculture, including forestry and fishing, is
an important sector, accounting for 21% of GDP and over 50% of the labor
force. The staple crop is rice. Once the world''s largest rice importer,
Indonesia is now nearly self-sufficient. Plantation crops--rubber and
palm oil--and textiles and plywood are being encouraged for both export
and job generation. Industrial output now accounts for 30% of GDP
based on a supply of diverse natural resources, including crude oil,
natural gas, timber, metals, and coal. Of these, the oil sector dominates
the external economy, generating more than 20% of the government''s
revenues and 40% of export earnings in 1989. However, the economy''s
growth is very dependent on the continuing expansion of nonoil exports.
Japan is Indonesia''s most important customer and supplier of aid.
_#_GDP: $94 billion, per capita $490; real growth rate 6.0%
(1990 est.)
_#_Inflation rate (consumer prices): 10.8% (1990)
_#_Unemployment rate: 3%; underemployment 44% (1989 est.)
_#_Budget: revenues $17.2 billion; expenditures $23.4 billion,
including capital expenditures of $8.9 billion (FY91)
_#_Exports: $25.7 billion (f.o.b., 1990);
commodities--petroleum and liquefied natural gas 40%, timber 15%,
textiles 7%, rubber 5%, coffee 3%;
partners--Japan 40%, US 14%, Singapore 7%, Europe 16% (1990)
_#_Imports: $21.8 billion (f.o.b., 1990);
commodities--machinery 39%, chemical products 19%, manufactured
goods 16%;
partners--Japan 23%, US 13%, EC, Singapore
_#_External debt: $58.5 billion (1990 est.)
_#_Industrial production: growth rate 11.6% (1989 est.); accounts
for 30% of GDP
_#_Electricity: 11,600,000 kW capacity; 38,000 million kWh produced,
200 kWh per capita (1990)
_#_Industries: petroleum, textiles, mining, cement, chemical
fertilizers, plywood, food, rubber
_#_Agriculture: accounts for 23% of GDP, subsistence food production;
small-holder and plantation production for export; rice, cassava,
peanuts, rubber, cocoa, coffee, oil palm, copra, other tropical products;
products--poultry meat, beef, pork, eggs
_#_Illicit drugs: illicit producer of cannabis for the international
drug trade, but not a major player; government actively eradicating
plantings and prosecuting traffickers
_#_Economic aid: US commitments, including Ex-Im (FY70-89), $4.4
billion; Western (non-US) countries, ODA and OOF bilateral commitments
(1970-88), $22.8 billion; OPEC bilateral aid (1979-89), $213 million;
Communist countries (1970-89), $175 million
_#_Currency: Indonesian rupiah (plural--rupiahs);
1 Indonesian rupiah (Rp) = 100 sen (sen no longer used)
_#_Exchange rates: Indonesian rupiahs (Rp) per US$1--1,907.5 (January
1991), 1,842.8 (1990), 1,770.1 (1989), 1,685.7 (1988), 1,643.8 (1987),
1,282.6 (1986), 1,110.6 (1985)
_#_Fiscal year: 1 April-31 March
_#_Overview: Since the 1979 revolution, the banks, petroleum industry,
transportation, utilities, and mining have been nationalized, but the
new five-year plan--the first since the','338d9f2952eba611b86ae892b69c399ff981400a4d9b3114e6424da6d765a575','internet-archive','theciaworldfactb00025gut','txt','84185fe9df79da427349cc1598fd3f69814a2085a9fc1fe0508a3fae0a870f84','https://archive.org/download/theciaworldfactb00025gut/25.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('45fd8c2fff7d8ed6e27b19657ab9ba3f19bd9188bd92978bf7f1b855b9eba6e6',1991,'ES','Spain','economy',9,'revolution--passed in January
1990, calls for the transfer of many government-controlled enterprises
to the private sector. Disruptions from the bitter war with Iraq,
massive corruption, mismanagement, demographic pressures, and ideological
rigidities have kept economic growth at depressed levels. Oil accounts
for over 90% of export revenues. A combination of war damage and low oil
prices brought a 2% drop in GNP in 1988. GNP probably rose slightly in
1989, considerably short of the 3.2% population growth rate in 1989.
Heating oil and gasoline are rationed. Agriculture has suffered from the
war, land reform, and shortages of equipment and materials. The five-year
plan seeks to reinvigorate the economy by increasing the role of the
private sector, boosting nonoil income, and securing foreign loans. The
plan is overly ambitious but probably will generate some short-term
relief.
_#_GNP: $80.0 billion, per capita $1,400; real growth rate 0.5%
(1990 est.)
_#_Inflation rate (consumer prices): 30-50% (1989 est.)
_#_Unemployment rate: 30% (1989)
_#_Budget: revenues $63 billion; expenditures $80 billion, including
capital expenditures of $23 billion (FY90 est.)
_#_Exports: $12.3 billion (f.o.b., 1989);
commodities--petroleum 90%, carpets, fruits, nuts, hides;
partners--Japan, Turkey, Italy, Netherlands, Spain, France, FRG
_#_Imports: $11.6 billion (c.i.f., 1989);
commodities--machinery, military supplies, metal works, foodstuffs,
pharmaceuticals, technical services, refined oil products;
partners--FRG, Japan, Turkey, UK, Italy
_#_External debt: $4-5 billion (1989)
_#_Industrial production: growth rate NA%
_#_Electricity: 14,579,000 kW capacity; 40,000 million kWh produced,
740 kWh per capita (1989)
_#_Industries: petroleum, petrochemicals, textiles, cement and other
building materials, food processing (particularly sugar refining and
vegetable oil production), metal fabricating (steel and copper)
_#_Agriculture: principal products--wheat, rice, other grains, sugar
beets, fruits, nuts, cotton, dairy products, wool, caviar; not
self-sufficient in food
_#_Illicit drugs: illicit producer of opium poppy for the domestic and
international drug trade
_#_Economic aid: US commitments, including Ex-Im (FY70-80), $1.0
billion; Western (non-US) countries, ODA and OOF bilateral commitments
(1970-88), $1.6 billion; Communist countries (1970-89), $976 million;
note--aid fell sharply following the 1979 revolution
_#_Currency: Iranian rial (plural--rials); 1 Iranian rial (IR) =
100 dinars; note--domestic figures are generally referred to in terms of
the toman (plural--tomans), which equals 10 rials
_#_Exchange rates: Iranian rials (IR) per US$1--64.941 (January 1991),
68.096 (1990), 72.015 (1989), 68.683 (1988), 71.460 (1987), 78.760
(1986), 91.052 (1985) at the official rate; black market rate 1,400
(January 1991)
_#_Fiscal year: 21 March-20 March
_#_Overview: The Bathist regime engages in extensive central
planning and management of industrial production and foreign trade while
leaving some small-scale industry and services and most agriculture to
private enterprise. The economy has been dominated by the oil sector,
which has provided about 95% of foreign exchange earnings. In the 1980s
financial problems, caused by massive expenditures in the eight-year
war with Iran and damage to oil export facilities by Iran, led the
government to implement austerity measures and to borrow heavily and
later reschedule foreign debt payments. After the end of hostilities in
1988, oil exports gradually increased with the construction of new
pipelines and restoration of damaged facilities. Agricultural development
remained hampered by labor shortages, salinization, and dislocations
caused by previous land reform and collectivization programs. The
industrial sector, although accorded high priority by the government,
also was under financial constraints. Iraq''s seizure of Kuwait in August
1990, subsequent international economic embargoes, and military actions
by an international coalition beginning in January 1991 drastically
changed the economic picture. Oil exports were cut to near zero,
and industrial and transportation facilities severely damaged.
_#_GNP: $35 billion, per capita $1,940; real growth rate 5%
(1989 est.)
_#_Inflation rate (consumer prices): 30-40% (1989 est.)
_#_Unemployment rate: less than 5% (1989 est.)
_#_Budget: revenues $NA billion; expenditures $35 billion,
including capital expenditures of NA (1989)
_#_Exports: $12.1 billion (f.o.b., 1989);
commodities--crude oil and refined products, fertilizer, sulfur;
partners--US, Brazil, Turkey, Japan, France, Italy, USSR (1989)
_#_Imports: $10.3 billion (c.i.f., 1989);
commodities--manufactures, food;
partners--US, FRG, Turkey, UK, Romania, Japan, France (1989)
_#_External debt: $40 billion (1989 est.), excluding debt to Arab
Gulf states
_#_Industrial production: NA%; manufacturing accounts for 10% of GDP
(1987)
_#_Electricity: 9,902,000 kW capacity; 20,000 million kWh produced,
1,110 kWh per capita (1989)
_#_Industries: petroleum, chemicals, textiles, construction materials,
food processing
_#_Agriculture: accounts for 11% of GNP but 30% of labor
force; principal products--wheat, barley, rice, vegetables, dates, other
fruit, cotton, wool; livestock--cattle, sheep; not self-sufficient in
food output
_#_Economic aid: US commitments, including Ex-Im (FY70-80), $3
million; Western (non-US) countries, ODA and OOF bilateral commitments
(1970-88), $627 million; OPEC bilateral aid (1980-90), more than $30
billion; Communist countries (1970-89), $3.9 billion
_#_Currency: Iraqi dinar (plural--dinars); 1 Iraqi dinar (ID) = 1,000
fils
_#_Exchange rates: Iraqi dinars (ID) per US$1--0.3109 (fixed rate
since 1982)
_#_Fiscal year: calendar year
_#_Overview: no economic activity
_#_Overview: The economy is small, open, and trade dependent.
Agriculture, once the most important sector, is now dwarfed by industry,
which accounts for 37% of GDP and about 80% of exports and employs 26%
of the labor force. The government has successfully reduced the rate of
inflation from double-digit figures in the late 1970s to 3.3% in
1990. In 1987, after years of deficits, the balance of payments was
brought into the black. Unemployment, however, is a serious problem. A
1990 unemployment rate of 16.6% placed Ireland along with Spain as the
countries with the worst jobless records in Western Europe.
_#_GDP: $33.9 billion, per capita $9,690; real growth rate 4.1%
(1990)
_#_Inflation rate (consumer prices): 3.3% (1990)
_#_Unemployment rate: 16.6% (1990)
_#_Budget: revenues $11.3 billion; expenditures $11.7 billion,
including capital expenditures of $1.6 billion (1990)
_#_Exports: $24.6 billion (f.o.b., 1990);
commodities--chemicals, data processing equipment, industrial
machinery, live animals, animal products;
partners--EC 74% (UK 34%, FRG 11%, France 10%), US 8%
_#_Imports: $20.7 billion (c.i.f., 1990);
commodities--food, animal feed, chemicals, petroleum and petroleum
products, machinery, textiles, clothing;
partners--EC 66% (UK 41%, FRG 9%, France 4%), US 16%
_#_External debt: $16.0 billion (1990)
_#_Industrial production: growth rate 4.7% (1990); accounts for
37% of GDP
_#_Electricity: 4,957,000 kW capacity; 14,480 million kWh produced,
4,080 kWh per capita (1989)
_#_Industries: food products, brewing, textiles, clothing, chemicals,
pharmaceuticals, machinery, transportation equipment, glass and crystal
_#_Agriculture: accounts for 10% of GNP and 15% of the labor force;
principal crops--turnips, barley, potatoes, sugar beets, wheat;
livestock--meat and dairy products; 85% self-sufficient in food; food
shortages include bread grain, fruits, vegetables
_#_Economic aid: donor--ODA commitments (1980-89), $90 million
_#_Currency: Irish pound (plural--pounds); 1 Irish pound (5Ir) =
100 pence
_#_Exchange rates: Irish pounds (5Ir) per US$1--0.5656 (January
1991), 0.6030 (1990), 0.7472 (1989), 0.6553 (1988), 0.6720 (1987), 0.7454
(1986), 0.9384 (1985)
_#_Fiscal year: calendar year
_#_Overview: Israel has a market economy with substantial government
participation. It depends on imports for crude oil, food, grains, raw
materials, and military equipment. Despite limited natural resources,
Israel has developed its agricultural and industrial sectors on an
intensive scale over the past 20 years. Industry accounts for about 23%
of the labor force, agriculture for 5%, and services for most of the
balance. Diamonds, high-technology machinery, and agricultural products
(fruits and vegetables) are the biggest export earners. The balance of
payments has traditionally been negative, but is offset by large transfer
payments and foreign loans. About half of Israel''s $18 billion external
government debt is owed to the US, which is its major source for economic
and military aid. To earn needed foreign exchange, Israel must continue
to exploit high-technology niches in the international market, such as
medical scanning equipment. Iraq''s invasion of Kuwait on 2 August dealt
a blow to Israel''s economy in 1990. Higher world oil prices added an
estimated $300 million to Israel''s 1990 oil import bill, and helped
keep the inflation rate at 18% for the year. Regional tensions
and continuing acts of the Palestinian uprising
(intifadah)-related violence contributed to a sharp dropoff in
tourism--a key source of foreign exchange--to the lowest level since the
1973 Arab-Israeli war. In 1991, the influx of up to 400,000 Soviet
immigrants will increase unemployment, intensify the country''s
housing crisis, and contribute to a widening budget deficit.
_#_GNP: $46.5 billion, per capita $10,500; real growth rate 3.5%
(1990 est.)
_#_Inflation rate (consumer prices): 18% (1990)
_#_Unemployment rate: 9.8% (March 1991)
_#_Budget: revenues $28.7 billion; expenditures $33.0 billion,
including capital expenditures of $NA (FY91)
_#_Exports: $10.7 billion (f.o.b., 1989);
commodities--polished diamonds, citrus and other fruits, textiles
and clothing, processed foods, fertilizer and chemical products, military
hardware, electronics;
partners--US, UK, FRG, France, Belgium, Luxembourg, Italy
_#_Imports: $14.2 billion (c.i.f., 1989 est.);
commodities--military equipment, rough diamonds, oil, chemicals,
machinery, iron and steel, cereals, textiles, vehicles, ships, aircraft;
partners--US, FRG, UK, Switzerland, Italy, Belgium, Luxembourg
_#_External debt: $24.5 billion, of which government debt is
$18 billion (December 1990)
_#_Industrial production: growth rate - 1.5% (1989); accounts
for about 40% of GDP
_#_Electricity: 4,392,000 kW capacity; 17,500 million kWh produced,
4,000 kWh per capita (1989)
_#_Industries: food processing, diamond cutting and polishing,
textiles, clothing, chemicals, metal products, military equipment,
transport equipment, electrical equipment, miscellaneous machinery,
potash mining, high-technology electronics, tourism
_#_Agriculture: accounts for 5% of GNP; largely self-sufficient in
food production, except for bread grains; principal products--citrus and
other fruits, vegetables, cotton; livestock products--beef, dairy, and
poultry
_#_Economic aid: US commitments, including Ex-Im (FY70-90), $18.2
billion; Western (non-US) countries, ODA and OOF bilateral commitments
(1970-88), $2.5 billion
_#_Currency: new Israeli shekel (plural--shekels);
1 new Israeli shekel (NIS) = 100 new agorot
_#_Exchange rates: new Israeli shekels (NIS) per US$1--2.35
(May 1991), 2.0162 (1990), 1.9164 (1989), 1.5989 (1988), 1.5946
(1987), 1.4878 (1986), 1.1788 (1985)
_#_Fiscal year: 1 April-31 March; changing to calender year basis
starting January 1992
_#_Overview: Since World War II the economy has changed from one based
on agriculture into a ranking industrial economy, with approximately the
same total and per capita output as France and the UK. The country is
still divided into a developed industrial north, dominated by small
private companies, and an undeveloped agricultural south, dominated by
large public enterprises. Services account for 48% of GDP, industry 34%,
agriculture 4%, and public administration 13%. Most raw materials needed
by industry and over 75% of energy requirements must be imported. The
economic recovery that began in mid-1983 has continued through 1990, with
the economy growing at an annual average rate of 3%. For the 1990s, Italy
faces the problems of refurbishing a tottering communications system,
curbing pollution in major industrial centers, and adjusting to the new
competitive forces accompanying the ongoing economic integration of the
European Community.
_#_GDP: $844.7 billion, per capita $14,600; real growth rate 2.0%
(1990)
_#_Inflation rate (consumer prices): 6% (1990)
_#_Unemployment rate: 11.0% (1990 est.)
_#_Budget: revenues $355 billion; expenditures $448 billion,
including capital expenditures of $NA (1989)
_#_Exports: $170.4 billion (f.o.b., 1990);
commodities--textiles, wearing apparel, metals, transportation
equipment, chemicals;
partners--EC 57%, US 8%, OPEC 4%
_#_Imports: $182.0 billion (c.i.f., 1990);
commodities--petroleum, industrial machinery, chemicals, metals,
food, agricultural products;
partners--EC 58%, OPEC 6%, US 5%
_#_External debt: NA
_#_Industrial production: growth rate - 0.1% (1990); accounts for
almost 35% of GDP
_#_Electricity: 56,800,000 kW capacity; 225,000 million kWh produced,
3,900 kWh per capita (1990)
_#_Industries: machinery, iron and steel, chemicals, food processing,
textiles, motor vehicles, clothing, footwear, ceramics
_#_Agriculture: accounts for about 4% of GDP and 10% of the
work force; self-sufficient in foods other than meat and dairy products;
principal crops--fruits, vegetables, grapes, potatoes, sugar beets,
soybeans, grain, olives; fish catch of 388,200 metric tons in 1988
_#_Economic aid: donor--ODA and OOF commitments (1970-89), $25.9
billion
_#_Currency: Italian lira (plural--lire); 1 Italian lira (Lit) = 100
centesimi
_#_Exchange rates: Italian lire (Lit) per US$1--1,134.4 (January
1991), 1,198.1 (1990), 1,372.1 (1989), 1,301.6 (1988), 1,296.1 (1987),
1,490.8 (1986), 1,909.4 (1985)
_#_Fiscal year: calendar year
_#_Overview: Ivory Coast is among the world''s largest producers
and exporters of coffee, cocoa beans, and palm-kernel oil. Consequently,
the economy is highly sensitive to fluctuations in international prices
for coffee and cocoa and to weather conditions. Despite attempts by the
government to diversify, the economy is still largely dependent on
agriculture and related industries. The agricultural sector accounts for
over one-third of GDP and about 80% of export earnings and employs about
85% of the labor force. A collapse of world cocoa and coffee prices in
1986 threw the economy into a recession, from which the country had not
recovered by 1990.
_#_GDP: $10 billion, per capita $800; real growth rate - 2.9% (1990)
_#_Inflation rate (consumer prices): -0.8% (1990 est.)
_#_Unemployment rate: 14% (1985)
_#_Budget: revenues $2.8 billion (1989 est.); expenditures $4.1
billion, including capital expenditures of $NA (1989 est.)
_#_Exports: $2.5 billion (f.o.b., 1989);
commodities--cocoa 30%, coffee 20%, tropical woods 11%, cotton,
bananas, pineapples, palm oil, cotton;
partners--France, FRG, Netherlands, US, Belgium, Spain (1985)
_#_Imports: $1.4 billion (f.o.b., 1989);
commodities--manufactured goods and semifinished products 50%,
consumer goods 40%, raw materials and fuels 10%;
partners--France, other EC, Nigeria, US, Japan (1985)
_#_External debt: $15.0 billion (1990 est.)
_#_Industrial production: growth rate - 6% (1989); accounts for
17% of GDP
_#_Electricity: 1,081,000 kW capacity; 2,440 million kWh produced,
210 kWh per capita (1989)
_#_Industries: foodstuffs, wood processing, oil refinery, automobile
assembly, textiles, fertilizer, beverage
_#_Agriculture: most important sector, contributing one-third to GDP
and 80% to exports; cash crops include coffee, cocoa beans, timber,
bananas, palm kernels, rubber; food crops--corn, rice, manioc, sweet
potatoes; not self-sufficient in bread grain and dairy products
_#_Illicit drugs: illicit producer of cannabis on a small scale for
the international drug trade
_#_Economic aid: US commitments, including Ex-Im (FY70-89), $356
million; Western (non-US) countries, ODA and OOF bilateral commitments
(1970-88), $4.9 billion
_#_Currency: Communaute Financiere Africaine franc
(plural--francs); 1 CFA franc (CFAF) = 100 centimes
_#_Exchange rates: Communaute Financiere Africaine francs (CFAF)
per US$1--256.54 (January 1991), 272.26 (1990), 319.01 (1989), 297.85
(1988), 300.54 (1987), 346.30 (1986), 449.26 (1985)
_#_Fiscal year: calendar year
_#_Overview: The economy is based on sugar, bauxite, and tourism.
In 1985 it suffered a setback with the closure of some facilities in the
bauxite and alumina industry, a major source of hard currency earnings.
Since 1986 an economic recovery has been under way. In 1987 conditions
began to improve for the bauxite and alumina industry because of
increases in world metal prices. The recovery has also been supported by
growth in the manufacturing and tourism sectors. In September 1988,
Hurricane Gilbert inflicted severe damage on crops and the electric power
system, a sharp but temporary setback to the economy. By October 1989 the
economic recovery from the hurricane was largely complete and real growth
was up about 3% for 1989. In 1990, 3.5% economic growth was led by
mining and tourism.
_#_GDP: $3.9 billion, per capita $1,580; real growth rate 3.5% (1990)
_#_Inflation rate (consumer prices): 16.0% (1990)
_#_Unemployment rate: 18.2% (1990)
_#_Budget: revenues $1.0 billion; expenditures $1.1 billion, including
capital expenditures of $197 million (FY90 est.)
_#_Exports: $1.02 billion (f.o.b., 1990);
commodities--bauxite, alumina, sugar, bananas;
partners--US 36%, UK, Canada, Norway, Trinidad and Tobago
_#_Imports: $1.83 billion (c.i.f., 1990);
commodities--petroleum, machinery, food, consumer goods,
construction goods;
partners--US 48%, UK, Venezuela, Canada, Japan, Trinidad and Tobago
_#_External debt: $4.1 billion (1990 est.)
_#_Industrial production: growth rate 3% (1989 est.); accounts
for almost 25% of GDP
_#_Electricity: 1,122,000 kW capacity; 2,508 million kWh produced,
1,030 kWh per capita (1990)
_#_Industries: tourism, bauxite mining, textiles, food processing,
light manufactures
_#_Agriculture: accounts for about 9% of GDP, 22% of work force,
and 17% of exports; commercial crops--sugarcane, bananas, coffee, citrus,
potatoes, and vegetables; livestock and livestock products include
poultry, goats, milk; not self-sufficient in grain, meat, and dairy
products
_#_Illicit drugs: illicit cultivation of cannabis; transshipment point
for ships carrying cocaine and cannabis from central and South America
to North America
_#_Economic aid: US commitments, including Ex-Im (FY70-89), $1.2
billion; Western (non-US) countries, ODA and OOF bilateral commitments
(1970-88), $1.45 billion; OPEC bilateral aid (1979-89), $27 million;
Communist countries (1974-89), $349 million
_#_Currency: Jamaican dollar (plural--dollars);
1 Jamaican dollar (J$) = 100 cents
_#_Exchange rates: Jamaican dollars (J$) per US$1--8.106 (January
1991), 7.184 (1990), 5.7446 (1989), 5.4886 (1988), 5.4867 (1987), 5.4778
(1986), 5.5586 (1985)
_#_Fiscal year: 1 April-31 March
_#_Overview: Jan Mayen is a volcanic island with no exploitable
natural resources. Economic activity is limited to providing services
for employees of Norway''s radio and meteorological stations located on
the island.
_#_Electricity: 15,000 kW capacity; 40 million kWh produced,
NA kWh per capita (1989)
_#_Overview: Although Japan has few natural resources, since 1971 it
has become the world''s third-largest economy, ranking behind only the
US and the USSR. Government-industry cooperation, a strong work ethic,
and a comparatively small defense allocation have helped Japan advance
rapidly, notably in high-technology fields. Industry, the most important
sector of the economy, is heavily dependent on imported raw materials and
fuels. Self-sufficent in rice, Japan must import 50% of its requirements
for other grain and fodder crops. Japan maintains one of the world''s
largest fishing fleets and accounts for nearly 15% of the global
catch. Overall economic growth has been spectacular: a 10% average in the
1960s, a 5% average in the 1970s and 1980s. In 1990 strong investment and
consumption spending helped maintain growth at 5.6%. Inflation remains
low at 3.1% despite higher oil prices and rising wages because of a
tight labor market. Japan continues to run a huge trade surplus, $52
billion in 1990, which supports extensive investment in foreign
properties.
_#_GNP: $2,115.2 billion, per capita $17,100; real growth rate 5.6%
(1990)
_#_Inflation rate (consumer prices): 3.1% (1990)
_#_Unemployment rate: 2.1% (1990)
_#_Budget: revenues $499 billion; expenditures $532 billion, including
capital expenditures (public works only) of $52 billion (FY90)
_#_Exports: $286.5 billion (f.o.b., 1990);
commodities--manufactures 97% (including machinery 38%, motor
vehicles 17%, consumer electronics 10%);
partners--US 31%, Southeast Asia 29%, Western Europe 21%, Communist
countries 3%, Middle East 3%
_#_Imports: $234.7 billion (c.i.f., 1990);
commodities--manufactures 50%, fossil fuels 24%, foodstuffs and raw
materials 26%;
partners--Southeast Asia 23%, US 23%, Western Europe 18%,
Middle East 13%, Communist countries 7%
_#_External debt: $NA
_#_Industrial production: growth rate 4.6% (1990 est.); accounts for
30% of GDP (mining and manufacturing)
_#_Electricity: 191,000,000 kW capacity; 790,000 million kWh produced,
6,390 kWh per capita (1989)
_#_Industries: metallurgy, engineering, electrical and electronic,
textiles, chemicals, automobiles, fishing, telecommunications
_#_Agriculture: accounts for only 2% of GNP; highly subsidized and
protected sector, with crop yields among highest in world; principal
crops--rice, sugar beets, vegetables, fruit; animal products include
pork, poultry, dairy and eggs; about 50% self-sufficient in food
production; shortages of wheat, corn, soybeans; world''s largest fish
catch of 11.9 million metric tons in 1988
_#_Economic aid: donor--ODA and OOF commitments (1970-89), $83.2
billion; ODA outlay of $7.9 billion in 1989
_#_Currency: yen (plural--yen); 1 yen (3) = 100 sen
_#_Exchange rates: yen (3) per US$1--133.88 (January 1991), 144.79
(1990), 137.96 (1989), 128.15 (1988), 144.64 (1987), 168.52 (1986),
238.54 (1985)
_#_Fiscal year: 1 April-31 March
_#_Overview: no economic activity
_#_Overview: The economy is based largely on financial services,
agriculture, and tourism. Potatoes, cauliflower, tomatoes, and especially
flowers are important export crops, shipped mostly to the UK. The Jersey
breed of dairy cattle is known worldwide and represents an important
export earner. Milk products go to the UK and other EC countries. In 1986
the finance sector overtook tourism as the main contributor to GDP,
accounting for 40% of the island''s output. In recent years the government
has encouraged light industry to locate in Jersey, with the result that
an electronics industry has developed alongside the traditional
manufacturing of knitwear. All raw material and energy requirements are
imported, as well as a large share of Jersey''s food needs.
_#_GDP: $NA, per capita $NA; real growth rate 8% (1987 est.)
_#_Inflation rate (consumer prices): 8% (1988 est.)
_#_Unemployment rate: NA%
_#_Budget: revenues $308.0 million; expenditures $284.4 million,
including capital expenditures of NA (1985)
_#_Exports: $NA;
commodities--light industrial and electrical goods,
foodstuffs, textiles;
partners--UK
_#_Imports: $NA;
commodities--machinery and transport equipment, manufactured goods,
foodstuffs, mineral fuels, chemicals;
partners--UK
_#_External debt: $NA
_#_Industrial production: growth rate NA%
_#_Electricity: 50,000 kW standby capacity (1990); power supplied by','de8d9179494e97d9f59e7bb6af0f1255d00186a10410d20a64557ddac70d3672','internet-archive','theciaworldfactb00025gut','txt','84185fe9df79da427349cc1598fd3f69814a2085a9fc1fe0508a3fae0a870f84','https://archive.org/download/theciaworldfactb00025gut/25.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('09525cd469e5b936487a4cd5896d824e28f89574ba5b7e785782c26f0e13511d',1991,'ZW','Zimbabwe','economy',10,'Taiwan
Appendix A: The United Nations System
Appendix B: International Organization and Group Abbreviations
Appendix C: International Organizations and Groups
Appendix D: Weights and Measures
Appendix E: Cross-Reference List of Geographic Names
Notes, Definitions, and Abbreviations
There have been some significant changes in this edition. The
Literacy entry now includes rates for males, females, and both
sexes. Appendix C: International Organizations and Groups is new
and includes date established, aim, and list of members. Three maps
of special interest have been added this year--republics of the
Soviet Union, ethnic groups in the Soviet Union, and ethnic groups
in Eastern Europe.
_#_Abbreviations: (see Appendix B for international organizations
and groups)
avdp. avoirdupois
c.i.f. cost, insurance, and freight
CY calendar year
DWT deadweight ton
est. estimate
Ex-Im Export-Import Bank of the United States
f.o.b. free on board
FRG Federal Republic of Germany (West Germany);
used for information dated before 3 October 1990
or CY91
FY fiscal year
GDP gross domestic product
GDR German Democratic Republic (East Germany);
used for information dated before 3 October 1990
or CY91
GNP gross national product
GRT gross register ton
km kilometer
km2 square kilometer
kW kilowatt
kWh kilowatt-hour
m meter
NA not available
NEGL negligible
nm nautical mile
NZ New Zealand
ODA official development assistance
OOF other official flows
PDRY People''s Democratic Republic of Yemen [Yemen
(Aden) or South Yemen]; used for information
dated before 22 May 1990 or CY91
UAE United Arab Emirates
UK United Kingdom
US United States
USSR Union of Soviet Socialist Republics (Soviet Union)
YAR Yemen Arab Republic [Yemen (Sanaa) or North Yemen];
used for information dated before 22 May 1990 or
CY91
_#_Administrative divisions: The numbers, designatory terms, and
first-order administrative divisions are generally those approved by the
United States Board on Geographic Names (BGN). Changes that have been
reported but not yet acted upon by BGN are noted.
_#_Area: Total area is the sum of all land and water areas delimited
by international boundaries and/or coastlines. Land area is the
aggregate of all surfaces delimited by international boundaries and/or
coastlines, excluding inland water bodies (lakes, reservoirs, rivers).
Comparative areas are based on total area equivalents. Most entities
are compared with the entire US or one of the 50 states. The smaller
entities are compared with Washington, DC (178 km2, 69 miles2) or
The Mall in Washington, DC (0.59 km2, 0.23 miles2, 146 acres).
_#_Birth rate: The average annual number of births during a year
per 1,000 population at midyear. Also known as crude birth rate.
_#_Dates of information: In general, information available as of 1
January 1991 was used in the preparation of this edition. Population
figures are estimates for 1 July 1991, with population growth rates
estimated for mid-1991 through mid-1992. Major political events have
been updated through 30 June 1991. Military age figures are average
annual estimates for 1991-95.
_#_Death rate: The average annual number of deaths during a year
per l,000 population at midyear. Also known as crude death rate.
_#_Diplomatic representation: The US Government has diplomatic
relations with 162 nations. There are only 144 US embassies, since some
nations have US ambassadors accredited to them, but no physical US
mission exists. The US has diplomatic relations with 151 of the 159 UN
members--the exceptions are Angola, Belorussia (Byelorussia;
constituent republic of the Soviet Union), Cambodia, Cuba, Iran, Vietnam,
Ukraine (constituent republic of the Soviet Union) and, obviously, the US
itself. In addition, the US has diplomatic relations with 12 nations that
are not in the UN--Andorra, Federated States of Micronesia, Kiribati,
Marshall Islands, Monaco, Nauru, San Marino, South Korea, Switzerland,
Tonga, Tuvalu, and the Vatican City. North Korea is not in the UN and the
US does not have diplomatic relations with that nation. The US has not
recognized the incorporation of Estonia, Latvia, and Lithuania into the
Soviet Union and continues to accredit the diplomatic representatives of
their last free governments.
_#_Disputes: This category includes a wide variety of situations
that range from traditional bilateral boundary disputes to unilateral
claims of one sort or another. Every international land boundary
dispute in the "Guide to International Boundaries," a map published
by the Department of State, is included. References to other situations
may also be included that are border- or frontier-relevant, such as
maritime disputes, geopolitical questions, or irredentist issues.
However, inclusion does not necessarily constitute official acceptance
or recognition by the US Government.
_#_Economic aid: This entry refers to bilateral commitments of:
Official Development Assistance (ODA), which is defined as government
grants that (a) are administered with the promotion of economic
development and welfare of LDCs as their main objective and (b) are
concessional in character and contain a grant element of at least 25%;
and
Other Official Flows (OOF) or transactions by the official sector
whose main objective is other than development-motivated or whose
grant element is below the 25% threshold for ODA. OOF transactions
include official export credits (such as Eximbank credits), official
equity and portfolio investment, and debt reorganization by the
official sector that does not meet concessional terms.
Aid is considered to have been committed when agreements are
initialed by the parties involved and constitute a formal declaration
of intent.
_#_Entities: Some of the nations, dependent areas, areas of special
sovereignty, and governments included in this publication are not
independent, and others are not officially recognized by the US
Government. Nation refers to a people politically organized into a
sovereign state with a definite territory. Dependent area refers to a
broad category of political entities that are associated in some way
with a nation. Names used for page headings are usually the short-form
names as approved by the US Board on Geographic Names. The
long-form name is included in the Government section and an entry
of "none" indicates a long-form name does not exist. In some
instances, no short-form name exists--then the long-form name must
serve for all usages.
There are 247 entities in the Factbook that may be categorized as
follows:
NATIONS
157 UN members (there are 159 members in the UN, but only 157 are
included in The World Factbook because Belorussia
(Byelorussia) and Ukraine are constituent republics of the Soviet
Union)
13 nations that are not members of the UN--Andorra, Federated States of
Micronesia, Kiribati, Marshall Islands, Monaco, Nauru, North Korea,
San Marino, South Korea, Switzerland, Tonga, Tuvalu, Vatican City
OTHER
1 Taiwan
DEPENDENT AREAS
6 Australia--Ashmore and Cartier Islands, Christmas Island,
Cocos (Keeling) Islands, Coral Sea Islands, Heard Island and
McDonald Islands, Norfolk Island
2 Denmark--Faroe Islands, Greenland
16 France--Bassas da India, Clipperton Island, Europa Island,
French Guiana, French Polynesia, French Southern and Antarctic
Lands, Glorioso Islands, Guadeloupe, Juan de Nova Island,
Martinique, Mayotte, New Caledonia, Reunion, Saint Pierre and
Miquelon, Tromelin Island, Wallis and Futuna
2 Netherlands--Aruba, Netherlands Antilles
3 New Zealand--Cook Islands, Niue, Tokelau
3 Norway--Bouvet Island, Jan Mayen, Svalbard
1 Portugal--Macau
16 United Kingdom--Anguilla, Bermuda, British Indian Ocean Territory,
British Virgin Islands, Cayman Islands, Falkland Islands,
Gibraltar, Guernsey, Hong Kong, Isle of Man, Jersey, Montserrat,
Pitcairn Islands, Saint Helena, South Georgia and the South
Sandwich Islands, Turks and Caicos Islands
15 United States--American Samoa, Baker Island, Guam, Howland Island,
Jarvis Island, Johnston Atoll, Kingman Reef, Midway Islands,
Navassa Island, Northern Mariana Islands, Palmyra Atoll,
Puerto Rico, Trust Territory of the Pacific Islands (Palau),
Virgin Islands, Wake Island
MISCELLANEOUS
7 Antarctica, Gaza Strip, Iraq-Saudi Arabia Neutral Zone,
Paracel Islands, Spratly Islands, West Bank, Western Sahara
OTHER ENTITIES
4 oceans--Arctic Ocean, Atlantic Ocean, Indian Ocean, Pacific Ocean
1 World
===
247 total
Notes: The US Government has not recognized the incorporation of
Estonia, Latvia, and Lithuania into the Soviet Union as constituent
republics during World War II. Those Baltic states are not members of the
UN and are not included in the list of nations. The US Government does
not recognize the four so-called "independent" homelands of
Bophuthatswana, Ciskei, Transkei, and Venda in South Africa.
_#_Gross domestic product (GDP): The value of all goods and
services produced domestically.
_#_Gross national product (GNP): The value of all goods and
services produced domestically, plus income earned abroad, minus
income earned by foreigners from domestic production.
_#_GNP/GDP methodology: In the Economy section, GNP/GDP dollar
estimates for the OECD countries, the USSR, and the East European
countries are derived from purchasing power parity (PPP)
calculations rather than from conversions at official currency exchange
rates. The PPP method normally involves the use of international
dollar price weights, which are applied to the quantities of goods and
services produced in a given economy. In addition to the lack of
reliable data from the majority of countries, the statistician faces
a major difficulty in specifying, identifying, and allowing for the
quality of goods and services. The division of a PPP GNP/GDP estimate
in dollars by the corresponding estimate in the local currency gives
the PPP conversion rate. One thousand dollars will buy the
same market basket of goods in the US as one thousand dollars, converted
to the local currency at the PPP conversion rate, will buy in the other
country. GNP/GDP estimates for the LDCs, on the other hand, are based on
the conversion of GNP/GDP estimates in local currencies to dollars at
the official currency exchange rates. One caution: the proportion of,
say, defense expenditures as a percent of GNP/GDP in local currency
accounts may differ substantially from the proportion when GNP/GDP
accounts are expressed in PPP terms, as, for example, when an observer
estimates the dollar level of Soviet or Japanese military expenditures;
similar problems exist when components are expressed in dollars under
currency exchange rate procedures. Finally, as academic research
moves forward on the PPP method, we hope to convert all GNP/GDP
estimates to this method in future editions of the Factbook.
_#_Growth rate (population): The annual percent change in the
population, resulting from a surplus (or deficit) of births over
deaths and the balance of migrants entering and leaving a country.
The rate may be positive or negative.
_#_Illicit drugs: There are five categories of illicit
drugs--narcotics, stimulants, depressants (sedatives), hallucinogens,
and cannabis. These categories include many drugs legally produced and
prescribed by doctors as well as those illegally produced and sold
outside medical channels.
Cannabis (Cannabis sativa) is the common hemp plant, provides
hallucinogens with some sedative properties, and includes marijuana (pot,
Acapulco gold, grass, reefer), tetrahydrocannabinol (THC, Marinol),
hashish (hash), and hashish oil (hash oil).
Coca (Erythroxylon coca) is a bush and the leaves contain the stimulant
cocaine. Coca is not to be confused with cocoa which comes from cacao
seeds and is used in making chocolate, cocoa, and cocoa butter.
Cocaine is a stimulant derived from the leaves of the coca bush.
Depressants (sedatives) are drugs that reduce tension and anxiety and
include chloral hydrate, barbiturates (Amytal, Nembutal, Seconal,
phenobarbital), benzodiazepines (Librium, Valium), methaqualone
(Quaalude), glutethimide (Doriden), and others (Equanil, Placidyl,
Valmid).
Drugs are any chemical substances that effect a physical, mental,
emotional, or behavioral change in an individual.
Drug abuse is the use of any licit or illicit chemical substance that
results in physical, mental, emotional, or behavioral impairment in an
individual.
Hallucinogens are drugs that affect sensation, thinking,
self-awareness, and emotion. Hallucinogens include LSD (acid, microdot),
mescaline and peyote (mexc, buttons, cactus), amphetamine variants (PMA,
STP, DOB), phencyclidine (PCP, angel dust, hog), phencyclidine analogues
(PCE, PCPy, TCP), and others (psilocybin, psilocyn).
Hashish is the resinous exudate of the cannabis or hemp plant
(Cannabis sativa).
Heroin is a semisynthetic derivative of morphine.
Marijuana is the dried leaves of the cannabis or hemp plant
(Cannabis sativa).
Narcotics are drugs that relieve pain, often induce sleep, and refer to
opium, opium derivatives, and synthetic substitutes. Natural narcotics
include opium (paregoric, parepectolin), morphine (MS-Contin, Roxanol),
codeine (Tylenol w/codeine, Empirin w/codeine, Robitussan A-C), and
thebaine. Semisynthetic narcotics include heroin (horse, smack), and
hydromorphone (Dilaudid). Synthetic narcotics include meperidine or
Pethidine (Demerol, Mepergan), methadone (Dolophine, Methadose), and
others (Darvon, Lomotil).
Opium is the milky exudate of the incised, unripe seedpod of the
opium poppy.
Opium poppy (Papaver somniferum) is the source for many natural and
semisynthetic narcotics.
Poppy straw concentrate is the alkaloid derived from the mature dried
opium poppy.
Qat (kat, khat) is a stimulant from the buds or leaves of Catha edulis
that is chewed or drunk as tea.
Stimulants are drugs that relieve mild depression, increase energy and
activity, and include cocaine (coke, snow, crack), amphetamines (Desoxyn,
Dexedrine), phenmetrazine (Preludin), methylphenidate (Ritalin), and
others (Cylert, Sanorex, Tenuate).
_#_Infant mortality rate: The number of deaths to infants under one
year of age in a given year per l,000 live births occurring in the same
year.
_#_Land use: Human use of the land surface is categorized as
arable land--land cultivated for crops that are replanted after
each harvest (wheat, maize, rice); permanent crops--land
cultivated for crops that are not replanted after each harvest
(citrus, coffee, rubber); meadows and pastures--land permanently
used for herbaceous forage crops; forest and woodland--land under
dense or open stands of trees; and other--any land type not
specifically mentioned above (urban areas, roads, desert). The
percentage figure for irrigated refers to the portion of the entire
amount of land area that is artificially supplied with water.
_#_Leaders: The chief of state is the titular leader of the country
who represents the state at official and ceremonial funcions but is not
involved with the day-to-day activities of the government. The head
of government is the administrative leader who manages the day-to-day
activities of the government. In the UK, the monarch is the chief
of state and the prime minister is the head of government. In the US,
the President is both the chief of state and the head of government.
_#_Life expectancy at birth: The average number of years to be lived
by a group of people all born in the same year, if mortality at each
age remains constant in the future.
_#_Literacy: There are no universal definitions and standards of
literacy. Unless otherwise noted, all rates are based on the most
common definition--the ability to read and write at a specified age.
Detailing the standards that individual countries use to assess the
ability to read and write is beyond the scope of this publication.
_#_Maps: All maps will be available only in the printed version for
the foreseeable future.
_#_Maritime claims: The proximity of neighboring states may prevent
some national claims from being fully extended.
_#_Merchant marine: All ships engaged in the carriage of goods. All
commercial vessels (as opposed to all nonmilitary ships), which
excludes tugs, fishing vessels, offshore oil rigs, etc. Also, a
grouping of merchant ships by nationality or register.
Captive register--A register of ships maintained by a territory,
possession, or colony primarily or exclusively for the use of ships
owned in the parent country. Also referred to as an offshore register,
the offshore equivalent of an internal register. Ships on a captive
register will fly the same flag as the parent country, or a local
variant of it, but will be subject to the maritime laws and taxation
rules of the offshore territory. Although the nature of a captive
register makes it especially desirable for ships owned in the parent
country, just as in the internal register, the ships may also be owned
abroad. The captive register then acts as a flag of convenience
register, except that it is not the register of an independent state.
Flag of convenience register--A national register offering
registration to a merchant ship not owned in the flag state. The major
flags of convenience (FOC) attract ships to their register by virtue
of low fees, low or nonexistent taxation of profits, and liberal
manning requirements. True FOC registers are characterized by having
relatively few of the ships registered actually owned in the flag
state. Thus, while virtually any flag can be used for ships under a
given set of circumstances, an FOC register is one where the majority
of the merchant fleet is owned abroad. It is also referred to as an
open register.
Flag state--The nation in which a ship is registered and which
holds legal jurisdiction over operation of the ship, whether at home
or abroad. Differences in flag state maritime legislation determine
how a ship is manned and taxed and whether a foreign-owned ship may be
placed on the register.
Internal register--A register of ships maintained as a subset of
a national register. Ships on the internal register fly the national
flag and have that nationality but are subject to a separate set of
maritime rules from those on the main national register. These
differences usually include lower taxation of profits, manning by
foreign nationals, and, usually, ownership outside the flag state
(when it functions as an FOC register). The Norwegian International
Ship Register and Danish International Ship Register are the most
notable examples of an internal register. Both have been instrumental
in stemming flight from the national flag to flags of convenience and in
attracting foreign-owned ships to the Norwegian and Danish flags.
Merchant ship--A vessel that carries goods against payment of
freight. Commonly used to denote any nonmilitary ship but accurately
restricted to commercial vessels only.
Register--The record of a ship''s ownership and nationality as
listed with the maritime authorities of a country. Also, the
compendium of such individual ships'' registrations. Registration of
a ship provides it with a nationality and makes it subject to the laws
of the country in which registered (the flag state) regardless of the
nationality of the ship''s ultimate owner.
_#_Money figures: All are expressed in contemporaneous US dollars
unless otherwise indicated.
_#_Net migration rate: The balance between the number of persons
entering and leaving a country during the year per 1,000 persons
(based on midyear population). An excess of persons entering the
country is referred to as net immigration (3.56 migrants/1,000
population); an excess of persons leaving the country as net
emigration (-9.26 migrants/1,000 population).
_#_Population: Figures are estimates from the Bureau of the Census
based on statistics from population censuses, vital registration
systems, or sample surveys pertaining to the recent past, and on
assumptions about future trends.
_#_Total fertility rate: The average number of children that would
be born per woman if all women lived to the end of their childbearing
years and bore children according to a given fertility rate at each age.
_#_Years: All year references are for the calendar year (CY) unless
indicated as fiscal year (FY).
_#_Note: Information for the US and US dependencies was compiled from
material in the public domain and does not represent Intelligence
Community estimates.
The Handbook of Economic Statistics, published annually in
September by the Central Intelligence Agency, contains detailed
economic information for the Organization for Economic Cooperation
and Development (OECD) countries, Eastern Europe, the USSR,
and selected other countries. The Handbook can be obtained wherever
The World Factbook is available.
THE WORLD FACTBOOK
_@_Afghanistan
_#_Overview: Fundamentally, Afghanistan is an extremely poor,
landlocked country, highly dependent on farming (wheat especially) and
livestock raising (sheep and goats). Economic considerations, however,
have played second fiddle to political and military upheavals, including
the nine-year Soviet military occupation (ended 15 February 1989) and the
continuing bloody civil war. Over the past decade, one-third of the
population has fled the country, with Pakistan sheltering about 3.3
million refugees and Iran about 1.3 million. Another 1 million have
probably moved into and around urban areas within Afghanistan. Large
numbers of bridges, buildings, and factories have been destroyed or
damaged by military action or sabotage. Government claims
to the contrary, gross domestic product almost certainly is
lower than 10 years ago because of the loss of labor and capital
and the disruption of trade and transport.
_#_GDP: $3 billion, per capita $200; real growth rate 0% (1989 est.)
_#_Inflation rate (consumer prices): over 92% (1990 est.)
_#_Unemployment rate: NA%
_#_Budget: revenues $1.2 billion; expenditures $4.3 billion,
including capital expenditures of $306 million (FY91 est.)
_#_Exports: $236 million (f.o.b., FY90);
commodities--natural gas 55%, fruits and nuts 24%, handwoven
carpets, wool, cotton, hides, and pelts;
partners--mostly USSR and Eastern Europe
_#_Imports: $874 million (c.i.f., FY90 est.);
commodities--food and petroleum products;
partners--mostly USSR and Eastern Europe
_#_External debt: $2.3 billion (March 1991 est.)
_#_Industrial production: growth rate 8.1% (FY91 plan); accounts
for about 25% of GDP
_#_Electricity: 480,000 kW capacity; 1,470 million kWh produced,
100 kWh per capita (1989)
_#_Industries: small-scale production of textiles, soap, furniture,
shoes, fertilizer, and cement; handwoven carpets; natural gas, oil, coal,
copper
_#_Agriculture: largely subsistence farming and nomadic animal
husbandry; cash products--wheat, fruits, nuts, karakul pelts, wool,
mutton
_#_Illicit drugs: an illicit producer of opium poppy and cannabis
for the international drug trade; world''s second-largest opium producer
(after Burma) and a major source of hashish
_#_Economic aid: US commitments, including Ex-Im (FY70-89), $322
million; Western (non-US) countries, ODA and OOF bilateral commitments
(1970-88), $465 million; OPEC bilateral aid (1979-89), $57 million;
Communist countries (1970-89), $4.1 billion
_#_Currency: afghani (plural--afghanis); 1 afghani (Af) = 100 puls
_#_Exchange rates: afghanis (Af) per US$1--586 (March 1991)
_#_Fiscal year: 21 March-20 March
_#_Overview: As the poorest country in Europe, Albania''s development
lags behind even the least favored areas of the Yugoslav economy.
For over 40 years, the Stalinist-type economy has operated on the
principles of central planning and state ownership of the means of
production. In recent years Albania has implemented limited economic
reforms to stimulate its lagging economy, provide incentives, and
decentralize decisionmaking. In an effort to expand international
ties, Tirane has reestablished diplomatic relations with the Soviet
Union and the US. The Albanians have also passed legislation allowing
foreign investment. Albania possesses considerable mineral
resources and, unti','5336eadc710f8bc70164f953a721de1ac19f5aaccddec115165c5ba9bd4ac07e','internet-archive','theciaworldfactb00025gut','txt','84185fe9df79da427349cc1598fd3f69814a2085a9fc1fe0508a3fae0a870f84','https://archive.org/download/theciaworldfactb00025gut/25.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('feb82faa73f8df6cd542749af86d598792c4581d1500f481b8f136318acc0fa0',1991,'ZW','Zimbabwe','economy',11,'l 1990, was largely self-sufficient in food;
several years of drought have hindered agricultural development.
Numerical estimates of Albanian economic activity are subject to an
especially wide margin of error because the government until recently
did not release economic information.
_#_GNP: $4.1 billion, per capita $1,250; real growth rate NA% (1990
est.)
_#_Inflation rate (consumer prices): NA%
_#_Unemployment rate: NA%
_#_Budget: revenues $2.3 billion; expenditures $2.3 billion,
including capital expenditures of NA (1989)
_#_Exports: $378 million (f.o.b., 1987 est.);
commodities--asphalt, bitumen, petroleum products, metals and
metallic ores, electricity, oil, vegetables, fruits, tobacco;
partners--Italy, Yugoslavia, FRG, Greece, Czechoslovakia, Poland,
Romania, Bulgaria, Hungary
_#_Imports: $255 million (f.o.b., 1987 est.);
commodities--machinery, machine tools, iron and steel products,
textiles, chemicals, pharmaceuticals;
partners--Italy, Yugoslavia, FRG, Czechoslovakia, Romania,
Poland, Hungary, Bulgaria, GDR
_#_External debt: $NA
_#_Industrial production: growth rate NA
_#_Electricity: 1,690,000 kW capacity; 5,000 million kWh produced,
1,530 kWh per capita (1990)
_#_Industries: food processing, textiles and clothing, lumber,
oil, cement, chemicals, basic metals, hydropower
_#_Agriculture: arable land per capita among lowest in Europe;
one-half of work force engaged in farming; produces wide range of
temperate-zone crops and livestock; claims self-sufficiency in grain
output
_#_Economic aid: Western (non-US) countries, ODA (1988) $5.8 million
_#_Currency: lek (plural--leke); 1 lek (L) = 100 qintars
_#_Exchange rates: leke (L) per US$1--8.00 (noncommercial fixed rate
since 1986), 4.14 (commercial fixed rate since 1987)
_#_Fiscal year: calendar year
_#_Overview: The exploitation of oil and natural gas products forms
the backbone of the economy. Algeria depends on hydrocarbons for nearly
all of its export receipts, about 30% of government revenues, and nearly
25% of GDP. In 1973-74 the sharp increase in oil prices led to a booming
economy and helped to finance an ambitious program of industrialization.
Plunging oil and gas prices, combined with the mismanagement of Algeria''s
highly centralized economy, have brought the nation to its most serious
social and economic crisis since independence. The government has
promised far-reaching reforms, including giving public-sector companies
more autonomy, encouraging private-sector activity, boosting gas and
nonhydrocarbon exports, and proposing a major overhaul of the banking
and financial systems, but to date has made little progress.
_#_GDP: $54 billion, per capita $2,130; real growth rate 2.5%
(1990 est.)
_#_Inflation rate (consumer prices): 16.6% (1990)
_#_Unemployment rate: 26% (1990 est.)
_#_Budget: revenues $16.7 billion; expenditures $17.3 billion,
including capital expenditures of $6.6 billion (1990 est.)
_#_Exports: $10.2 billion (f.o.b., 1990 est.);
commodities--petroleum and natural gas 98%;
partners--Netherlands, Czechoslovakia, Romania, Italy, France, US
_#_Imports: $9.2 billion (f.o.b., 1990 est.);
commodities--capital goods 29%, consumer goods 30%;
partners--France 25%, Italy 8%, FRG 8%, US 6-7%
_#_External debt: $26.6 billion (December 1990)
_#_Industrial production: growth rate -3% (1989 est.); accounts for
30% of GDP, including petroleum
_#_Electricity: 5,156,000 kW capacity; 14,900 million kWh
produced, 580 kWh per capita (1990)
_#_Industries: petroleum, light industries, natural gas, mining,
electrical, petrochemical, food processing
_#_Agriculture: accounts for 11% of GDP and employs 24% of labor
force; net importer of food--grain, vegetable oil, and sugar; farm
production includes wheat, barley, oats, grapes, olives, citrus, fruits,
sheep,and cattle
_#_Economic aid: US commitments, including Ex-Im (FY70-85), $1.4
billion; Western (non-US) countries, ODA and OOF bilateral commitments
(1970-88), $8.5 billion; OPEC bilateral aid (1979-89), $1.8 billion;
Communist countries (1970-89), $2.7 billion
_#_Currency: Algerian dinar (plural--dinars); 1 Algerian dinar
(DA) = 100 centimes
_#_Exchange rates: Algerian dinars (DA) per US$1--13.581 (January
1991), 8.958 (1990), 7.6086 (1989), 5.9148 (1988), 4.8497 (1987), 4.7023
(1986), 5.0278 (1985)
_#_Fiscal year: calendar year
_#_Overview: Economic development is strongly linked to the US, with
which American Samoa does 90% of its foreign trade. Tuna fishing and tuna
processing plants are the backbone of the private-sector economy, with
canned tuna the primary export. The tuna canneries are the second-largest
employer, exceeded only by the government. Other economic activities
include meat canning, handicrafts, dairy farming, and a slowly developing
tourist industry.
_#_GNP: $190 million, per capita $5,210; real growth rate NA% (1985)
_#_Inflation rate (consumer prices): 4.3% (1989)
_#_Unemployment rate: 13.4% (1986)
_#_Budget: revenues $51.2 million; expenditures $59.9 million,
including capital expenditures of $NA million (1990)
_#_Exports: $288 million (f.o.b., 1987);
commodities--canned tuna 93%;
partners--US 99.6%
_#_Imports: $346 million (c.i.f., 1987);
commodities--building materials 18%, food 17%, petroleum
products 14%;
partners--US 72%, Japan 7%, NZ 7%, Australia 5%, other 9%
_#_External debt: $NA
_#_Industrial production: growth rate NA%
_#_Electricity: 42,000 kW capacity; 85 million kWh produced,
2,020 kWh per capita (1990)
_#_Industries: tuna canneries (largely dependent on foreign supplies
of raw tuna)
_#_Agriculture: bananas, coconuts, vegetables, taro, breadfruit, yams,
copra, pineapples, papayas
_#_Economic aid: $21,042,650 million in operational funds and
$5,948,931 million in construction funds for capital improvement projects
from the US Department of Interior (1991)
_#_Currency: US currency is used
_#_Exchange rates: US currency is used
_#_Fiscal year: 1 October-30 September
_#_Overview: The mainstay of Andorra''s economy is tourism. An
estimated 12 million tourists visit annually, attracted by Andorra''s
duty-free status and by its summer and winter resorts. Agricultural
production is limited by a scarcity of arable land, and most food has to
be imported. The principal livestock activity is sheep raising.
Manufacturing consists mainly of cigarettes, cigars, and furniture. The
rapid pace of European economic integration is a potential threat to
Andorra''s advantages from its duty-free status.
_#_GDP: $727 million, per capita $14,000; real growth rate NA%
(1990 est.)
_#_Inflation rate (consumer prices): NA%
_#_Unemployment rate: none
_#_Budget: revenues $NA; expenditures $NA, including capital
expenditures of $NA
_#_Exports: $0.017 million (f.o.b., 1986);
commodities--electricity;
partners--France, Spain
_#_Imports: $531 million (f.o.b., 1986);
commodities--consumer goods, food;
partners--France, Spain
_#_External debt: $NA
_#_Industrial production: growth rate NA%
_#_Electricity: 35,000 kW capacity; 140 million kWh produced,
2,800 kWh per capita (1989)
_#_Industries: tourism (particularly skiing), sheep, timber, tobacco,
smuggling, banking
_#_Agriculture: sheep raising; small quantities of tobacco, rye,
wheat, barley, oats, and some vegetables
_#_Economic aid: none
_#_Currency: French franc (plural--francs) and Spanish peseta
(plural--pesetas); 1 French franc (F) = 100 centimes and 1 Spanish peseta
(Pta) = 100 centimos
_#_Exchange rates: French francs (F) per US$1--5.1307 (January 1991),
5.4453 (1990), 6.3801 (1989), 5.9569 (1988), 6.0107 (1987), 6.9261
(1986), 8.9852 (1985); Spanish pesetas (Ptas) per US$1--95.20 (January
1991), 101.93 (1990), 118.38 (1989), 116.49 (1988), 123.48 (1987), 140.05
(1986), 170.04 (1985)
_#_Fiscal year: calendar year
_#_Overview: Subsistence agriculture provides the main livelihood for
80 to 90% of the population, but accounts for less than 15% of GDP. Oil
production is the most lucrative sector of the economy, contributing
about 50% to GDP. In recent years, however, the impact of fighting an
internal war has severely affected the nonoil economy, and food has to be
imported. For the long run, Angola has the advantage of rich natural
resources, notably gold, diamonds, and arable land. To realize its
economic potential Angola not only must secure domestic peace but also
must reform government policies that have led to distortions and
imbalances throughout the economy.
_#_GDP: $7.9 billion, per capita $925; real growth rate 2.0% (1990
est.)
_#_Inflation rate (consumer prices): 23.2% (1988)
_#_Unemployment rate: NA%
_#_Budget: revenues $2.6 billion; expenditures $4.4 billion,
including capital expenditures of $963 million (1990 est.)
_#_Exports: $3.8 billion (f.o.b., 1990 est.);
commodities--oil,liquified petroleum gas, diamonds, coffee, sisal,
fish and fish products, timber, cotton;
partners--US, USSR, Cuba, Portugal, Brazil, France
_#_Imports: $1.5 billion (f.o.b., 1990 est.);
commodities--capital equipment (machinery and electrical
equipment), food, vehicles and spare parts, textiles and clothing,
medicines; substantial military deliveries;
partners--US, USSR, Cuba, Portugal, Brazil
_#_External debt: $7.0 billion (1990)
_#_Industrial production: growth rate NA%; accounts for about 60%
of GDP, including petroleum output
_#_Electricity: 506,000 kW capacity; 770 million kWh produced,
90 kWh per capita (1989)
_#_Industries: petroleum, diamonds, mining, fish processing, food
processing, brewing, tobacco, sugar, textiles, cement, basic metal
products
_#_Agriculture: cash crops--coffee, sisal, corn, cotton, sugar,
manioc, tobacco; food crops--cassava, corn, vegetables, plantains,
bananas; livestock production accounts for 20%, fishing 4%, forestry
2% of total agricultural output; disruptions caused by civil war
and marketing deficiencies require food imports
_#_Economic aid: US commitments, including Ex-Im (FY70-89), $265
million; Western (non-US) countries, ODA and OOF bilateral commitments
(1970-88), $1,005 million; Communist countries (1970-89), $1.3 billion
_#_Currency: kwanza (plural--kwanza); 1 kwanza (Kz) = 100 lwei
_#_Exchange rates: kwanza (Kz) per US$1--29.62 (fixed rate since 1976)
_#_Fiscal year: calendar year
_#_Overview: Anguilla has few natural resources, and the economy
depends heavily on lobster fishing, offshore banking, tourism, and
remittances from emigrants. In recent years the economy has benefited
from a boom in tourism. Development is planned to improve the
infrastructure, particularly transport and tourist facilities, and
also light industry. Improvement in the economy has reduced
unemployment from 40% in 1984 to about 5% in 1988.
_#_GDP: $23 million, per capita $3,300; real growth rate
8.2% (1988 est.)
_#_Inflation rate (consumer prices): 4.5% (1988 est.)
_#_Unemployment rate: 5.0% (1988 est.)
_#_Budget: revenues $10.4 million; expenditures $11.0 million,
including capital expenditures of $1.1 million (1989 est.)
_#_Exports: $NA;
commodities--lobster and salt;
partners--NA
_#_Imports: $NA;
commodities--NA;
partners --NA
_#_External debt: $NA
_#_Industrial production: growth rate NA%
_#_Electricity: 2,000 kW capacity; 6 million kWh produced, 870 kWh
per capita (1990)
_#_Industries: tourism, boat building, salt, fishing (including
lobster)
_#_Agriculture: pigeon peas, corn, sweet potatoes, sheep, goats, pigs,
cattle, poultry
_#_Economic aid: Western (non-US) countries, ODA and OOF bilateral
commitments (1970-89), $38 million
_#_Currency: East Caribbean dollar (plural--dollars); 1 EC dollar
(EC$) = 100 cents
_#_Exchange rates: East Caribbean dollars (EC$) per US$1--2.70 (fixed
rate since 1976)
_#_Fiscal year: NA
_#_Overview: No economic activity at present except for fishing off
the coast and small-scale tourism, both based abroad. Exploitation of
mineral resources is unlikely because of technical difficulties, high
costs, and objections by environmentalists.
_#_Overview: The economy is primarily service oriented, with tourism
the most important determinant of economic performance. During the period
1983-89, real GDP expanded at an annual average rate of about 7%.
Tourism''s contribution to GDP, as measured by value added tax in hotels
and restaurants, rose from about 14% in 1983 to 16% in 1989, and
stimulated growth in other sectors--particularly in construction,
communications, and public utilities. Antigua and Barbuda is one of the
few areas in the Caribbean experiencing a labor shortage in some sectors
of the economy.
_#_GDP: $350 million, per capita $5,470 (1989); real growth rate 3.0%
(1991 est.)
_#_Inflation rate (consumer prices): 7% (1990 est.)
_#_Unemployment rate: 5.0% (1988 est.)
_#_Budget: revenues $92.8 million; expenditures $101 million,
including capital expenditures of $NA (1990 est.)
_#_Exports: $33.2 million (f.o.b., 1990 est.);
commodities--petroleum products 48%, manufactures 23%, food and
live animals 4%, machinery and transport equipment 17%;
partners--OECS 26%, Barbados 15%, Guyana 4%, Trinidad and Tobago
2%, US 0.3%
_#_Imports: $358.2 million (c.i.f., 1990 est.);
commodities--food and live animals, machinery and transport
equipment, manufactures, chemicals, oil;
partners--US 27%, UK 16%, Canada 4%, OECS 3%, other 50%
_#_External debt: $250 million (1990 est.)
_#_Industrial production: growth rate 3% (1989 est.); accounts
for 9% of GDP
_#_Electricity: 52,000 kW capacity; 95 million kWh produced, 1,490 kWh
per capita (1990)
_#_Industries: tourism, construction, light manufacturing (clothing,
alcohol, household appliances)
_#_Agriculture: accounts for 4% of GDP; expanding output of cotton,
fruits, vegetables, and livestock sector; other crops--bananas, coconuts,
cucumbers, mangoes, sugarcane; not self-sufficient in food
_#_Economic aid: US commitments, $10 million (1985-88); Western
(non-US) countries, ODA and OOF bilateral commitments (1970-88), $45
million
_#_Currency: East Caribbean dollar (plural--dollars); 1 EC dollar
(EC$) = 100 cents
_#_Exchange rates: East Caribbean dollars (EC$) per US$1--2.70 (fixed
rate since 1976)
_#_Fiscal year: 1 April-31 March
_#_Overview: Economic activity is limited to the exploitation of
natural resources, including crude oil, natural gas, fishing, and
sealing.
_#_Overview: Argentina is rich in natural resources and has a highly
literate population, an export-oriented agricultural sector, and a
diversified industrial base. Nevertheless, following decades of
mismanagement and statist policies, the economy has encountered
major problems in recent years, leading to escalating inflation and
a recession in 1988-90. A widening public-sector deficit and a
multidigit inflation rate have dominated the economy over the past
three years; retail prices rose nearly 5,000% in 1989 and another
1,345% in 1990. Since 1978, Argentina''s external debt has nearly doubled
to $60 billion, creating severe debt-servicing difficulties and hurting
the country''s creditworthiness with international lenders.
_#_GNP: $82.7 billion, per capita $2,560; real growth rate - 3.5%
(1990 est.)
_#_Inflation rate (consumer prices): 1,350% (1990)
_#_Unemployment rate: 8.6% (May 1990)
_#_Budget: revenues $12.2 billion; expenditures $17.3 billion,
including capital expenditures of $2.8 billion (1989)
_#_Exports: $12.4 billion (f.o.b., 1990);
commodities--meat, wheat, corn, oilseed, hides, wool;
partners--US 12%, USSR, Italy, Brazil, Japan, Netherlands
_#_Imports: $4.1 billion (c.i.f., 1990);
commodities--machinery and equipment, chemicals, metals, fuels and
lubricants, agricultural products;
partners--US 22%, Brazil, FRG, Bolivia, Japan, Italy, Netherlands
_#_External debt: $60 billion (December 1990)
_#_Industrial production: growth rate 5% (1991 est.); accounts for
30% of GDP
_#_Electricity: 16,749,000 kW capacity; 45,580 million kWh produced,
1,410 kWh per capita (1990)
_#_Industries: food processing, motor vehicles, consumer durables,
textiles, chemicals and petrochemicals, printing, metallurgy, steel
_#_Agriculture: accounts for 15% of GNP (including fishing); produces
abundant food for both domestic consumption and exports; among world''s
top five exporters of grain and beef; principal crops--wheat, corn,
sorghum, soybeans, sugar beets; 1987 fish catch estimated at 500,000 tons
_#_Economic aid: US commitments, including Ex-Im (FY70-89), $1.0
billion; Western (non-US) countries, ODA and OOF bilateral commitments
(1970-88), $4.0 billion; Communist countries (1970-89), $718 million
_#_Currency: austral (plural--australes); 1 austral (2) = 100
centavos
_#_Exchange rates: australes (2) per US$1--9,900 (April 1991),
4,707 (1990), 423 (1989), 8.7526 (1988), 2.1443 (1987), 0.9430 (1986),
0.6018 (1985)
_#_Fiscal year: calendar year
_#_Overview: Tourism is the mainstay of the economy, although
offshore banking and oil refining and storage are also important.
Hotel capacity expanded rapidly between 1985 and 1989 and nearly
doubled in 1990 alone. Unemployment has steadily declined from about
20% in 1986 to about 2% in 1990. The reopening of the local oil
refinery, once a major source of employment and foreign exchange
earnings, promises to give the economy an additional boost.
_#_GDP: $730 million, per capita $11,600; real growth rate 8.8%
(1989 est.)
_#_Inflation rate (consumer prices): 5.8% (1990 est.)
_#_Unemployment rate: 1.6% (1990 est.)
_#_Budget: revenues $145 million; expenditures $185 million, including
capital expenditures of $42 million (1988)
_#_Exports: $131.6 million (f.o.b., 1990 est.);
commodities--mostly petroleum products;
partners--US 64%, EC
_#_Imports: $496 million (f.o.b., 1990 est.);
commodities--food, consumer goods, manufactures;
partners--US 8%, EC
_#_External debt: $81 million (1987)
_#_Industrial production: growth rate NA
_#_Electricity: 310,000 kW capacity; 945 million kWh produced, 15,000
kWh per capita (1990)
_#_Industries: tourism, transshipment facilities, oil refining
_#_Agriculture: poor quality soils and low rainfall limit agricultural
activity to the cultivation of aloes, some livestock, and fishing
_#_Economic aid: Western (non-US) countries ODA and OOF bilateral
commitments (1980-1988), $200 million
_#_Currency: Aruban florin (plural--florins);
1 Aruban florin (Af.) = 100 cents
_#_Exchange rates: Aruban florins (Af.) per US$1--1.7900 (fixed rate
since 1986)
_#_Fiscal year: calendar year
_#_Overview: no economic activity
_#_Overview: Economic activity is limited to exploitation of natural
resources, especially fish, dredging aragonite sands (The Bahamas), and
crude oil and natural gas production (Caribbean Sea and North Sea).
_#_Overview: Australia has a prosperous Western-style capitalist
economy, with a per capita GNP comparable to levels in industrialized
West European countries. Rich in natural resources, Australia is a major
exporter of agricultural products, minerals, metals, and fossil fuels.
Of the top 25 exports, 21 are primary products, so that, as happened
during 1983-84, a downturn in world commodity prices can have a big
impact on the economy. The government is pushing for increased exports
of manufactured goods but competition in international markets will be
severe.
_#_GDP: $255.9 billion, per capita $15,000; real growth rate 2.2%
(1990)
_#_Inflation rate (consumer prices): 6.9% (December 1990)
_#_Unemployment rate: 9.2% (March 1991)
_#_Budget: revenues $74.2 billion; expenditures $67.9 billion,
including capital expenditures of NA (FY90)
_#_Exports: $39.8 billion (f.o.b., FY90);
commodities--metals, minerals, coal, wool, cereals, meat,
manufacturers;
partners--Japan 26%, US 11%, NZ 6%, South Korea 4%, Singapore 4%,
UK, Taiwan, Hong Kong
_#_Imports: $42.0 billion (f.o.b., FY90);
commodities--manufactured raw materials, capital equipment,
consumer goods;
partners--US 24%, Japan 19%, UK 6%, FRG 7%, NZ 4% (1990)
_#_External debt: $123.7 billion (September 1990)
_#_Industrial production: growth rate - 1.8% (1990); accounts for
32% of GDP
_#_Electricity: 38,000,000 kW capacity; 150,000 million kWh produced,
8,860 kWh per capita (1990)
_#_Industries: mining, industrial and transportation equipment, food
processing, chemicals, steel, motor vehicles
_#_Agriculture: accounts for 5% of GNP and 37% of export revenues;
world''s largest exporter of beef and wool, second-largest for mutton,
and among top wheat exporters; major crops--wheat, barley, sugarcane,
fruit; livestock--cattle, sheep, poultry
_#_Economic aid: donor--ODA and OOF commitments (1970-89), $10.4
billion
_#_Currency: Australian dollar (plural--dollars); 1 Australian dollar
($A) = 100 cents
_#_Exchange rates: Australian dollars ($A) per US$1--1.2834 (January
1991), 1.2799 (1990), 1.2618 (1989), 1.2752 (1988), 1.4267 (1987), 1.4905
(1986), 1.4269 (1985)
_#_Fiscal year: 1 July-30 June
_#_Overview: Austria boasts a prosperous and stable capitalist
economy with a sizable proportion of nationalized industry and extensive
welfare benefits. Thanks to an excellent raw material endowment, a
technically skilled labor force, and strong links to West German
industrial firms, Austria has successfully occupied specialized niches
in European industry and services (tourism, banking) and produces almost
enough food to feed itself with only 8% of the labor force in
agriculture. Improved export prospects from German unification
and the opening of Eastern Europe will also boost the economy during
the next few years. Living standards are roughly comparable with the
large industrial countries of Western Europe. Problems for the l990s
include an aging population, the high level of subsidies, and the
struggle to keep welfare benefits within budget capabilities. Austria,
which has applied for EC membership, is currently involved in EC and
European Free Trade Association negotiations for a European Economic
Area and will have to adapt its economy to achieve freer movement of
goods, services, capital, and labor with the EC.
_#_GDP: $111.0 billion, per capita $14,500; real growth rate 4.5%
(1990)
_#_Inflation rate (consumer prices): 3.3% (1990)
_#_Unemployment: 5.4% (1990)
_#_Budget: revenues $44.1 billion; expenditures $49.6 billion,
including capital expenditures of $NA (1990)
_#_Exports: $40.9 billion (f.o.b., 1990);
commodities--machinery and equipment, iron and steel, lumber,
textiles, paper products, chemicals;
partners--EC 64.8%, EFTA 10.3%, CEMA 7.7%, US 3.2%, Japan 1.5%
_#_Imports: $46.6 billion (c.i.f., 1990);
commodities--petroleum, foodstuffs, machinery and equipment,
vehicles, chemicals, textiles and clothing, pharmaceuticals;
partners--EC 68.4%, EFTA 7%, CEMA 5.7%, Japan 4.6%, US 3.6%
_#_External debt: $11.8 billion (1990 est.)
_#_Industrial production: real growth rate 8.5% (1990); accounts
for 34% of GDP
_#_Electricity: 17,562,000 kW capacity; 49,290 million kWh produced,
6,500 kWh per capita (1989)
_#_Industries: foods, iron and steel, machines, textiles, chemicals,
electrical, paper and pulp, tourism, mining
_#_Agriculture: accounts for 3.2% of GDP (including forestry);
principal crops and animals--grains, fruit, potatoes, sugar beets,
sawn wood, cattle, pigs poultry; 80-90% self-sufficient in food
_#_Economic aid: donor--ODA and OOF commitments (1970-89), $2.4
billion
_#_Currency: Austrian schilling (plural--schillings); 1 Austrian
schilling (S) = 100 groschen
_#_Exchange rates: Austrian schillings (S) per US$1--10.627 (January
1991), 11.370 (1990), 13.231 (1989), 12.348 (1988), 12.643 (1987), 15.267
(1986), 20.690 (1985)
_#_Fiscal year: calendar year
_#_Overview: The Bahamas is a stable, middle-income developing nation
whose economy is based primarily on tourism and offshore banking. Tourism
alone provides about 50% of GDP and directly or indirectly employs about
50,000 people or 40% of the local work force. The economy has slackened
in recent years, as the annual increase in the number of tourists slowed.
Nonetheless, the per capita GDP of $9,800 is one of the highest in the
region.
_#_GDP: $2.4 billion, per capita $9,800; real growth rate 2.0%
(1989 est.)
_#_Inflation rate (consumer prices): 7.1% (1990 est.)
_#_Unemployment: 11.7% (1989)
_#_Budget: revenues $1.03 bi','446a25fe5a0ee6b93367878dbd51cbaf8349b56c2fcabdbddddcb18c71618469','internet-archive','theciaworldfactb00025gut','txt','84185fe9df79da427349cc1598fd3f69814a2085a9fc1fe0508a3fae0a870f84','https://archive.org/download/theciaworldfactb00025gut/25.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('91a10e2e69d01396df92c3e89e3e992fdccbe09c8d50d4055eb81fb6d48e3173',1991,'ZW','Zimbabwe','economy',12,'llion; expenditures $1.1 billion,
including capital expenditures of $275 million (1990)
_#_Exports: $300 million (f.o.b., 1990 est.);
commodities--pharmaceuticals, cement, rum, crawfish;
partners--US 41%, Norway 30%, Denmark 4%
_#_Imports: $1.23 billion (f.o.b., 1990 est.);
commodities--foodstuffs, manufactured goods, mineral fuels;
partners--US 35%, Nigeria 21%, Japan 13%, Angola 11%
_#_External debt: $1.2 billion (December 1990)
_#_Industrial production: growth rate NA%; accounts for 15% of GDP
_#_Electricity: 368,000 kW capacity; 857 million kWh produced,
3,480 kWh per capita (1990)
_#_Industries: tourism, banking, cement, oil refining and
transshipment, salt production, rum, aragonite, pharmaceuticals, spiral
weld, steel pipe
_#_Agriculture: accounts for less than 5% of GDP; dominated by
small-scale producers; principal products--citrus fruit, vegetables,
poultry; large net importer of food
_#_Illicit drugs: transshipment point for cocaine
_#_Economic aid: US commitments, including Ex-Im (FY85-88), $1.0
million; Western (non-US) countries, ODA and OOF bilateral commitments
(1970-88), $345 million
_#_Currency: Bahamian dollar (plural--dollars); 1 Bahamian dollar
(B$) = 100 cents
_#_Exchange rates: Bahamian dollar (B$) per US$1--1.00 (fixed rate)
_#_Fiscal year: calendar year
_#_Overview: Petroleum production and processing account for
about 85% of export receipts, 60% of government revenues, and 20% of GDP.
Economic conditions have fluctuated with the changing fortunes of oil
since 1985, including the Gulf crisis of 1990-91. The liberation of
Kuwait in early 1991 has improved short- to medium-term prospects and
has raised investors'' confidence. Bahrain with its highly developed
communication and transport facilities is home to numerous
multinational firms with business in the Gulf.
_#_GDP: $3.9 billion, per capita $7,500; real growth rate 2.5%
(1990 est.)
_#_Inflation rate (consumer prices): 1.5% (1989)
_#_Unemployment: 8-10% (1989)
_#_Budget: revenues $1.2 billion; expenditures $1.32 billion,
including capital expenditures of $NA (1989)
_#_Exports: $2.7 billion (f.o.b., 1989 est.);
commodities--petroleum 80%, aluminum 7%, other 13%;
partners--UAE, Japan, US, India
_#_Imports: $3.0 billion (f.o.b., 1989);
commodities--nonoil 59%, crude oil 41%;
partners--Saudi Arabia, Japan, US, UK
_#_External debt: $1.1 billion (December 1989 est.)
_#_Industrial production: growth rate 3.8% (1988); accounts for
44% of GDP
_#_Electricity: 1,652,000 kW capacity; 6,000 million kWh produced,
12,080 kWh per capita (1989)
_#_Industries: petroleum processing and refining, aluminum smelting,
offshore banking, ship repairing
_#_Agriculture: including fishing, accounts for less than 2% of GDP;
not self-sufficient in food production; heavily subsidized sector
produces fruit, vegetables, poultry, dairy products, shrimp, and fish;
fish catch 9,000 metric tons in 1987
_#_Economic aid: US commitments, including Ex-Im (FY70-79), $24
million; Western (non-US) countries, ODA and OOF bilateral commitments
(1970-88), $35 million; OPEC bilateral aid (1979-89), $9.8 billion
_#_Currency: Bahraini dinar (plural--dinars); 1 Bahraini dinar
(BD) = 1,000 fils
_#_Exchange rates: Bahraini dinars (BD) per US$1--0.3760 (fixed rate)
_#_Fiscal year: calendar year
_#_Overview: no economic activity
_#_Overview: Bangladesh is one of the poorest nations in the world.
The economy is based on the output of a narrow range of
agricultural products, such as jute, which is the main cash crop and
major source of export earnings. Bangladesh is hampered by a relative
lack of natural resources, population growth of more than 2% a year,
large-scale unemployment, and a limited infrastructure; furthermore,
it is highly vulnerable to natural disasters. Despite these constraints,
real GDP growth averaged about 3.5% annually during 1985-89. A strong
agricultural performance in FY90 pushed the growth rate up to 5.5%.
Alleviation of poverty remains the cornerstone of the government''s
development strategy.
_#_GDP: $20.4 billion, per capita $180; real growth rate 4.0%
(1990 est.)
_#_Inflation rate (consumer prices): 10% (FY90 est.)
_#_Unemployment rate: 30% (FY90 est.)
_#_Budget: revenues $2.2 billion; expenditures $3.9 billion, including
capital expenditures of $1.6 billion (FY90)
_#_Exports: $1.5 billion (FY90 est.);
commodities--jute, tea, leather, shrimp, textiles;
partners--US 25%, Western Europe 22%, Middle East 9%, Japan 8%,
Eastern Europe 7%
_#_Imports: $3.6 billion (FY90 est.);
commodities--food, petroleum and other energy, nonfood consumer
goods, semiprocessed goods, and capital equipment;
partners--Western Europe 18%, Japan 14%, Middle East 9%, US 8%
_#_External debt: $10.9 billion (FY90 est.)
_#_Industrial production: growth rate 4.1% (FY90 est.); accounts
for 15% of GDP
_#_Electricity: 1,990,000 kW capacity; 5,700 million kWh produced,
50 kWh per capita (1990)
_#_Industries: jute manufacturing, base metals, food processing,
cotton textiles, tobacco processing, chemicals
_#_Agriculture: accounts for about 40% of GDP, 60% of
employment, and one third of exports; imports 10% of food grain
requirements; world''s largest exporter of jute; commercial
products--jute, rice, wheat, tea, sugarcane, potatoes, beef, milk,
poultry; shortages include wheat, vegetable oils and cotton; fish catch
778,000 metric tons in 1986
_#_Economic aid: US commitments, including Ex-Im (FY70-89), $3.4
billion; Western (non-US) countries, ODA and OOF bilateral commitments
(1980-88), $10.6 billion; OPEC bilateral aid (1979-89), $652 million;
Communist countries (1970-89), $1.5 billion
_#_Currency: taka (plural--taka); 1 taka (Tk) = 100 paise
_#_Exchange rates: taka (Tk) per US$1--35.790 (January 1991), 34.567
(1990), 32.270 (1989), 31.733 (1988), 30.950 (1987), 30.407 (1986),
27.995 (1985)
_#_Fiscal year: 1 July-30 June
_#_Overview: A per capita income of $6,500 gives Barbados one of
the highest standards of living of all the small island states of the
eastern Caribbean. Historically, the economy was based on the cultivation
of sugarcane and related activities. In recent years, however, the
economy has diversified into manufacturing and tourism. The tourist
industry is now a major employer of the labor force and a primary source
of foreign exchange. An unemployment rate of 18% remains one of the most
serious economic problems facing the country.
_#_GDP: $1.7 billion, per capita $6,500; real growth rate
3.6% (1989 est.)
_#_Inflation rate (consumer prices): 6.2% (1989)
_#_Unemployment: 18% (1990)
_#_Budget: revenues $501 million; expenditures $484 million,
including capital expenditures of $113 million (FY91)
_#_Exports: $165 million (f.o.b., 1990 est.);
commodities--sugar and molasses, chemicals, electrical components,
clothing, rum, machinery and transport equipment;
partners: CARICOM 30%, US 20%, UK 20%
_#_Imports: $701 million (c.i.f., 1990 est.);
commodities--foodstuffs, consumer durables, raw materials,
machinery, crude oil, construction materials, chemicals;
partners--US 35%, CARICOM 13%, UK 12%, Japan 6%, Canada 8%,
Venezuela 4%
_#_External debt: $550 million (June 1990 est.)
_#_Industrial production: growth rate - 1.5% (1989); accounts
for 14 % of GDP
_#_Electricity: 132,000 kW capacity; 494 million kWh produced, 1,880
kWh per capita (1990)
_#_Industries: tourism, sugar, light manufacturing, component assembly
for export
_#_Agriculture: accounts for 10% of GDP; major cash crop is sugarcane;
other crops--vegetables and cotton; not self-sufficient in food
_#_Economic aid: US commitments, including Ex-Im (FY70-89), $15
million; Western (non-US) countries, ODA and OOF bilateral commitments
(1970-88), $169 million
_#_Currency: Barbadian dollars (plural--dollars); 1 Barbadian dollar
(Bds$) = 100 cents
_#_Exchange rates: Barbadian dollars (Bds$) per US$1--2.0113 (fixed
rate)
_#_Fiscal year: 1 April-31 March
_#_Overview: no economic activity
_#_Overview: This small private-enterprise economy has capitalized
on its central geographic location, highly developed transport
network, and diversified industrial and commercial base. Industry is
concentrated mainly in the populous Flemish area in the north, although
the government is encouraging reinvestment in the southern region
of Walloon. With few natural resources Belgium must import essential raw
materials, making its economy closely dependent on the state of world
markets. Over 70% of trade is with other EC countries. During
the period 1988-90 Belgium''s economic performance was marked by buoyant
output growth, moderate inflation, and a substantial external surplus.
Real GDP grew by an average of 3.9% in 1988-90. However, the economy
is likely to slow in 1991-92 to below 3% GDP growth.
_#_GDP: $144.8 billion, per capita $14,600; real growth rate 3.3%
(1990)
_#_Inflation rate (consumer prices): 3% (1991 est.)
_#_Unemployment rate: 8.2% est. (1991 est.)
_#_Budget: revenues $45.0 billion; expenditures $55.3 billion,
including capital expenditures of NA (1989)
_#_Exports: $106 billion (f.o.b., 1990 est.) Belgium-Luxembourg
Economic Union;
commodities--iron and steel, transportation equipment,
tractors, diamonds, petroleum products;
partners--EC 74%, US 5%, Communist countries 2% (1989)
_#_Imports: $108 billion (c.i.f., 1989) Belgium-Luxembourg Economic
Union;
commodities--fuels, grains, chemicals, foodstuffs;
partners--EC 73%, US 4%, oil-exporting less developed countries 4%,
Communist countries 3% (1989)
_#_External debt: $28.8 billion (1990 est.)
_#_Industrial production: growth rate 1.3% (1991 est.); accounts
for almost 30% of GDP
_#_Electricity: 17,325,000 kW capacity; 62,780 million kWh produced,
6,350 kWh per capita (1989)
_#_Industries: engineering and metal products, processed food and
beverages, chemicals, basic metals, textiles, glass, petroleum, coal
_#_Agriculture: accounts for 2% of GDP; emphasis on livestock
production--beef, veal, pork, milk; major crops are sugar beets, fresh
vegetables, fruits, grain, and tobacco; net importer of farm products
_#_Economic aid: donor--ODA and OOF commitments (1970-89), $5.8
billion
_#_Currency: Belgian franc (plural--francs); 1 Belgian franc (BF) =
100 centimes
_#_Exchange rates: Belgian francs (BF) per US$1--31.102 (January
1991), 33.418 (1990), 39.404 (1989), 36.768 (1988), 37.334 (1987), 44.672
(1986), 59.378 (1985)
_#_Fiscal year: calendar year
_#_Overview: The economy is based primarily on agriculture and
merchandising. Agriculture accounts for more than 30% of GDP and provides
75% of export earnings, while sugar, the chief crop, accounts for almost
40% of hard currency earnings. The US, Belize''s main trading partner, is
assisting in efforts to reduce dependency on sugar with an agricultural
diversification program.
_#_GDP: $290 million, per capita $1,320; real growth rate 9% (1990
est.)
_#_Inflation rate (consumer prices): 1.8% (1990 est.)
_#_Unemployment rate: 12% (1988)
_#_Budget: revenues $87.4 million; expenditures $130.5 million,
including capital expenditures of $53.5 million (FY90 est.)
_#_Exports: $108 million (f.o.b., 1990 est.);
commodities--sugar, clothing, seafood, molasses, citrus, wood and
wood products;
partners--US 47%, UK, Trinidad and Tobago, Canada (1987)
_#_Imports: $204 million (c.i.f., 1990 est.);
commodities--machinery and transportation equipment, food,
manufactured goods, fuels, chemicals, pharmaceuticals;
partners--US 55%, UK, Netherlands Antilles, Mexico (1987)
_#_External debt: $169 million (December 1990)
_#_Industrial production: growth rate 9.7% (1989); accounts for
16% of GDP
_#_Electricity: 34,700 kW capacity; 90 million kWh produced,
410 kWh per capita (1990)
_#_Industries: garment production, citrus concentrates, sugar
refining, rum, beverages, tourism
_#_Agriculture: accounts for 30% of GDP (including fish and forestry);
commercial crops include sugarcane, bananas, coca, citrus fruits;
expanding output of lumber and cultured shrimp; net importer of basic
foods
_#_Illicit drugs: an illicit producer of cannabis for the
international drug trade; eradication program cut marijuana
production from 200 metric tons in 1987 to 66 metric tons in 1989;
transshipment point for cocaine
_#_Economic aid: US commitments, including Ex-Im (FY70-89), $104
million; Western (non-US) countries, ODA and OOF bilateral commitments
(1970-88), $199 million
_#_Currency: Belizean dollar (plural--dollars); 1 Belizean dollar
(Bz$) = 100 cents
_#_Exchange rates: Belizean dollars (Bz$) per US$1--2.00 (fixed rate)
_#_Fiscal year: 1 April-31 March
_#_Overview: Benin is one of the least developed countries in the
world because of limited natural resources and a poorly developed
infrastructure. Agriculture accounts for almost 40% of GDP, employs
about 60% of the labor force, and generates a major share of foreign
exchange earnings. The industrial sector contributes only about 15% to
GDP and employs 2% of the work force. Persistently low prices in recent
years have limited hard currency earnings from Benin''s major exports of
agricultural products and crude oil.
_#_GDP: $2.0 billion, per capita $400; real growth rate 2.6% (1990)
_#_Inflation rate (consumer prices): 3.0% (1990)
_#_Unemployment: NA%
_#_Budget: revenues $194 million; expenditures $390 million, including
capital expenditures of $104 million (1990 est.)
_#_Exports: $250 million (f.o.b., 1989 est.);
commodities--crude oil, cotton, palm products, cocoa;
partners--FRG 36%, France 16%, Spain 14%, Italy 8%, UK 4%
_#_Imports: $442 million (f.o.b., 1990 est.);
commodities--foodstuffs, beverages, tobacco, petroleum products,
intermediate goods, capital goods, light consumer goods;
partners--France 34%, Netherlands 10%, Japan 7%, Italy 6%, US 4%
_#_External debt: $1.0 billion (December 1990 est.)
_#_Industrial production: growth rate - 0.7% (1988); accounts for
30% of GDP
_#_Electricity: 28,000 kW capacity; 24 million kWh produced,
5 kWh per capita (1989)
_#_Industries: textiles,cigarettes, construction materials,
beverages, food production, petroleum
_#_Agriculture: small farms produce 90% of agricultural output;
production is dominated by food crops--corn, sorghum, cassava, beans,
and rice; cash crops include cotton, palm oil, and peanuts; poultry
and livestock output has not kept up with consumption
_#_Economic aid: US commitments, including Ex-Im (FY70-89), $46
million; Western (non-US) countries, ODA and OOF bilateral commitments
(1970-88), $1.1 billion; OPEC bilateral aid (1979-89), $19 million;
Communist countries (1970-89), $101 million
_#_Currency: Communaute Financiere Africaine franc
(plural--francs); 1 CFA franc (CFAF) = 100 centimes
_#_Exchange rates: Communaute Financiere Africaine francs (CFAF)
per US$1--256.54 (January 1991), 272.26 (1990), 319.01 (1989),
297.85 (1988), 300.54 (1987), 346.30 (1986), 449.26 (1985)
_#_Fiscal year: calendar year
_#_Overview: Bermuda enjoys one of the highest per capita incomes in
the world, having successfully exploited its location by providing luxury
tourist facilities and financial services. The tourist industry attracts
more than 90% of its business from North America. The industrial sector
is small, and agriculture is severely limited by a lack of suitable land.
About 80% of food needs are imported.
_#_GDP: $1.3 billion, per capita $22,400; real growth rate 2.0% (1989
est.)
_#_Inflation rate (consumer prices): 5.8% (June 1989)
_#_Unemployment: 2.0% (1988)
_#_Budget: revenues $307 million; expenditures $275 million, including
capital expenditures of $31 million (FY90 est.)
_#_Exports: $30 million (f.o.b., FY88);
commodities--semitropical produce, light manufactures;
partners--US 25%, Italy 25%, UK 14%, Canada 5%, other 31%
_#_Imports: $420 million (c.i.f., FY88);
commodities--fuel, foodstuffs, machinery;
partners--US 58%, Netherlands Antilles 9%, UK 8%, Canada 6%, Japan
5%, other 14%
_#_External debt: NA
_#_Industrial production: growth rate NA%
_#_Electricity: 154,000 kW capacity; 504 million kWh produced,
8,640 kWh per capita (1990)
_#_Industries: tourism, finance, structural concrete products,
paints, pharmaceuticals, ship repairing
_#_Agriculture: accounts for less than 1% of GDP; most basic foods
must be imported; produces bananas, vegetables, citrus fruits, flowers,
dairy products
_#_Economic aid: US commitments, including Ex-Im (FY70-81), $34
million; Western (non-US) countries, ODA and OOF bilateral commitments
(1970-88), $267 million
_#_Currency: Bermudian dollar (plural--dollars); 1 Bermudian dollar
(Bd$) = 100 cents
_#_Exchange rates: Bermudian dollar (Bd$) per US$1--1.0000 (fixed
rate)
_#_Fiscal year: 1 April-31 March
_#_Overview: The economy, one of the world''s least developed,
is based on agriculture and forestry, which provide the main livelihood
for 90% of the population and account for about 50% of GDP. Rugged
mountains dominate the terrain and make the building of roads and other
infrastructure difficult and expensive. The economy is closely
aligned with that of India through strong trade and monetary links.
Low wages in industry lead most Bhutanese to stay in agriculture.
Most development projects, such as road construction, rely on Indian
migrant labor. Bhutan''s hydropower potential and its attraction for
tourists are its most important natural resources.
_#_GDP: $273 million, per capita $199 (1988) real growth rate 4%
(1989 est.)
_#_Inflation rate (consumer prices): 9% (1990 est.)
_#_Unemployment: NA
_#_Budget: revenues $99 million; expenditures $128 million, including
capital expenditures of $65 million (FY89 est.)
_#_Exports: $70.9 million (f.o.b., FY89);
commodities--cardamon, gypsum, timber, handicrafts, cement, fruit;
partners--India 93%
_#_Imports: $138.3 million (c.i.f., FY89 est.);
commodities--fuel and lubricants, grain, machinery and parts,
vehicles, fabrics;
partners--India 67%
_#_External debt: $70.1 million (FY89 est.)
_#_Industrial production: growth rate - 12.4% (1988 est.); accounts
for 18% of GDP
_#_Electricity: 353,000 kW capacity; 2,000 million kWh produced,
1,280 kWh per capita (1990)
_#_Industries: cement, wood products, processed fruits, alcoholic
beverages, calcium carbide
_#_Agriculture: accounts for 50% of GDP; based on subsistence farming
and animal husbandry; self-sufficient in food except for foodgrains;
other production--rice, corn, root crops, citrus fruit, dairy, and eggs
_#_Economic aid: Western (non-US) countries, ODA and OOF bilateral
commitments (1970-88), $86.0 million; OPEC bilateral aid (1979-89), $11
million
_#_Currency: ngultrum (plural--ngultrum); 1 ngultrum (Nu) = 100
chetrum; note--Indian currency is also legal tender
_#_Exchange rates: ngultrum (Nu) per US$1--18.329 (January 1991),
17.504 (1990), 16.226 (1989), 13.917 (1988), 12.962 (1987), 12.611
(1986), 12.369 (1985); note--the Bhutanese ngultrum is at par with the
Indian rupee
_#_Fiscal year: 1 July-30 June
_#_Overview: The Bolivian economy steadily deteriorated between
1980 and 1985 as La Paz financed growing budget deficits by expanding
the money supply and inflation spiraled--peaking at 11,700%. An austere
orthodox economic program adopted by newly elected President Paz
Estenssoro in 1985, however, succeeded in reducing inflation to between
10% and 20% annually since 1987, eventually restarting economic growth.
President Paz Zamora has retained the economic policies of the previous
government, keeping inflation down and continuing the moderate growth
begun under his predecessor. Nevertheless, Bolivia continues to be one of
the poorest countries in Latin America, and it remains vulnerable to
price fluctuations for its limited exports--agricultural products,
minerals, and natural gas. Moreover, for many farmers, who constitute
half of the country''s work force, the main cash crop is coca, which is
sold for cocaine processing.
_#_GDP: $4.85 billion, per capita $690; real growth rate 2.7% (1990)
_#_Inflation rate (consumer prices): 18% (1990)
_#_Unemployment rate: 21.5% (1990 est.)
_#_Budget: revenues $2.5 billion; expenditures $2.8 billion,
including capital expenditures of $850 million (1990 est.)
_#_Exports: $927 million (f.o.b., 1990);
commodities--metals 45%, natural gas 30%, other 25%
(coffee, soybeans, sugar, cotton, timber);
partners--US 15%, Argentina
_#_Imports: $716 million (c.i.f., 1990);
commodities--food, petroleum, consumer goods, capital goods;
partners--US 22%
_#_External debt: $3.7 billion (December 1990)
_#_Industrial production: growth rate 5% (1990); accounts for
almost 30% of GDP
_#_Electricity: 833,000 kW capacity; 1,763 million kWh produced, 260
kWh per capita (1990)
_#_Industries: mining, smelting, petroleum, food and beverage,
tobacco, handicrafts, clothing; illicit drug industry reportedly produces
significant revenues
_#_Agriculture: accounts for about 20% of GDP (including forestry and
fisheries); principal commodities--coffee, coca, cotton, corn, sugarcane,
rice, potatoes, timber; self-sufficient in food
_#_Illicit drugs: world''s second-largest producer of coca
(after Peru) with an estimated 51,900 hectares under cultivation;
government considers all but 12,000 hectares illicit; intermediate
coca products and cocaine exported to or through Colombia and Brazil
to the US and other international drug markets
_#_Economic aid: US commitments, including Ex-Im (FY70-89), $990
million; Western (non-US) countries, ODA and OOF bilateral commitments
(1970-88), $1.7 billion; Communist countries (1970-89), $340 million
_#_Currency: boliviano (plural--bolivianos); 1 boliviano ($B) = 100
centavos
_#_Exchange rates: bolivianos ($B) per US$1--3.3732 (December 1990),
3.1727 (1990), 2.6917 (1989), 2.3502 (1988), 2.0549 (1987), 1.9220
(1986), 0.4400 (1985)
_#_Fiscal year: calendar year
_#_Overview: The economy has historically been based on cattle raising
and crops. Agriculture today provides a livelihood for over 80% of the
population, but produces only about 50% of food needs and contributes
a small 3% to GDP. The driving force behind the rapid economic growth of
the 1970s and 1980s has been the mining industry. This sector, mostly on
the strength of diamonds, has gone from generating 25% of GDP in 1980 to
over 50% in 1989. No other sector has experienced such growth, especially
not agriculture, which is plagued by erratic rainfall and poor soils. The
unemployment rate remains a problem at 25%.
_#_GDP: $3.1 billion, per capita $2,500; real growth rate 6.3%
(1990)
_#_Inflation rate (consumer prices): 12.0% (1990)
_#_Unemployment rate: 25% (1989)
_#_Budget: revenues $1,719 million; expenditures $1,792 million,
including capital expenditures of $NA (FY92 est.)
_#_Exports: $1.8 billion (f.o.b., 1990 est.);
commodities--diamonds 77%, copper and nickel 12%, meat 4%, cattle,
animal products;
partners--Switzerland, UK, US, SACU (Southern African Customs
Union)
_#_Imports: $1.7 billion (c.i.f., 1990 est.);
commodities--foodstuffs, vehicles and transport equipment,
textiles, petroleum products;
partners--Switzerland, SACU (Southern African Customs Union),
UK, US
_#_External debt: $780 million (December 1990 est.)
_#_Industrial production: growth rate 16.8% (FY86); accounts for
about 57% of GDP, including mining
_#_Electricity: 217,000 kW capacity; 630 million kWh produced,
510 kWh per capita (1989)
_#_Industries: mining of diamonds, copper, nickel, coal, salt, soda
ash, potash; livestock processing
_#_Agriculture: accounts for only 3% of GDP; subsistence
farming predominates; cattle raising supports 50% of the population;
must import large share of food needs
_#_Economic aid: US commitments, including Ex-Im (FY70-89), $257
million; Western (non-US) countries, ODA and OOF bilateral commitments
(1970-88), $1.8 billion; OPEC bilateral aid (1979-89), $43 million;
Communist countries (1970-89), $29 million
_#_Currency: pula (plural--pula); 1 pula (P) = 100 thebe
_#_Exchange rates: pula (P) per US$1--1.8720 (January 1991), 1.8601
(1990), 2.0125 (1989), 1.8159 (1988), 1.6779 (1987), 1.8678 (1986),
1.8882 (1985)
_#_Fiscal year: 1 April-31 March
_#_Overview: no economic activity','ea02c3d29d03aa3441d540b3cd252a58a1207c0d713fe5c0915210d86ce8f449','internet-archive','theciaworldfactb00025gut','txt','84185fe9df79da427349cc1598fd3f69814a2085a9fc1fe0508a3fae0a870f84','https://archive.org/download/theciaworldfactb00025gut/25.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a9cbaf191bae54eb28fac10ba6106137440ae47898c1c7ada9c4b77a6543c222',1991,'AQ','Antarctica','economy',29,'_#_Overview: The economy, with large agrarian, mining, and
manufacturing sectors, entered the 1990s with declining real growth,
runaway inflation, an unserviceable foreign debt of $122 billion, and
a lack of policy direction. In addition, the economy remained highly
regulated, inward-looking, and protected by substantial trade and
investment barriers. Ownership of major industrial and mining facilities
is divided among private interests--including several multinationals--and
the government. Most large agricultural holdings are private, with the
government channeling financing to this sector. Conflicts between large
landholders and landless peasants have produced intermittent violence.
The government is seeking an IMF standby loan despite several failed
agreements over the past decade. Relations with foreign commercial
banks remain strained because of mounting interest arrears on Brazil''s
long-term debt. The Collor government, which assumed office in March
1990, is embarked on an ambitious reform program that seeks to
modernize and reinvigorate the economy by stabilizing prices,
deregulating the economy, and opening it to increased foreign
competition. A major long-run strength is Brazil''s vast natural
resources.
_#_GDP: $388 billion, per capita $2,540; real growth rate - 4.6%
(1990)
_#_Inflation rate (consumer prices): 1,795% (December 1990)
_#_Unemployment rate: 4.4% (1990)
_#_Budget: revenues $36.5 billion; expenditures $48.2 billion,
including capital expenditures of $4.6 billion (1988)
_#_Exports: $31.4 billion (1990);
commodities--iron ore, soybean bran, orange juice, footwear,
coffee
partners--EC 29%, US 23%, Latin America 10%, Japan 7% (1989)
_#_Imports: $20.4 billion (1990);
commodities--crude oil, capital goods, chemical products,
foodstuffs, coal;
partners--US 21%, Middle East and Africa 20%, EC 20%, Latin
America 18%, Japan 7% (1989)
_#_External debt: $122 billion (December 1990)
_#_Industrial production: growth rate - 8.9% (1990); accounts
for 35% of GDP
_#_Electricity: 55,773,000 kW capacity; 214,116 million kWh produced,
1,400 kWh per capita (1990)
_#_Industries: textiles and other consumer goods, shoes, chemicals,
cement, lumber, iron ore, steel, motor vehicles and auto parts,
metalworking, capital goods, tin
_#_Agriculture: accounts for 12% of GDP; world''s largest producer and
exporter of coffee and orange juice concentrate and second-largest
exporter of soybeans; other products--rice, corn, sugarcane, cocoa, beef;
self-sufficient in food, except for wheat
_#_Illicit drugs: illicit producer of cannabis and coca, mostly for
domestic consumption; government has a modest eradication program
to control cannabis and coca cultivation
_#_Economic aid: US commitments, including Ex-Im (FY70-89), $2.5
billion; Western (non-US) countries, ODA and OOF bilateral commitments
(1970-88), $9.9 billion; OPEC bilateral aid (1979-89), $284 million;
Communist countries (1970-89), $1.3 billion
_#_Currency: cruzeiro (plural--cruzeiros); 1 cruzeiro (Cr$) = 100
centavos
_#_Exchange rates: cruzeiros (Cr$) per US$1--193.189 (January 1991),
68.300 (1990), 2.834 (1989), 0.26238 (1988), 0.03923 (1987), 0.01366
(1986), 0.00620 (1985)
_#_Fiscal year: calendar year
_#_Overview: All economic activity is concentrated on the largest
island of Diego Garcia, where joint UK-US defense facilities are located.
Construction projects and various services needed to support the military
installations are done by military and contract employees from the UK and
the US. There are no industrial or agricultural activities on the
islands.
_#_Electricity: provided by the US military
_#_Overview: The economy is highly dependent on the tourist industry,
which generates about 21% of the national income. In 1985 the government
offered offshore registration to companies wishing to incorporate in
the islands, and, in consequence, incorporation fees generated about $2
million in 1987. Livestock raising is the most significant agricultural
activity. The islands'' crops, limited by poor soils, are unable to meet
food requirements.
_#_GDP: $106.7 million, per capita $8,900; real growth rate 2.5%
(1987)
_#_Inflation rate (consumer prices): 1.0% (1987)
_#_Unemployment rate: NEGL%
_#_Budget: revenues $32.8 million; expenditures $32.4 million,
including capital expenditures of $6.3 million (FY90)
_#_Exports: $2.7 million (f.o.b., 1988);
commodities--rum, fresh fish, gravel, sand, fruits, animals;
partners--Virgin Islands (US), Puerto Rico, US
_#_Imports: $11.5 million (c.i.f., 1988);
commodities--building materials, automobiles, foodstuffs,
machinery;
partners--Virgin Islands (US), Puerto Rico, US
_#_External debt: $4.5 million (1985)
_#_Industrial production: growth rate - 4.0% (1985)
_#_Electricity: 10,500 kW capacity; 43 million kWh produced,
3,510 kWh per capita (1990)
_#_Industries: tourism, light industry, construction, rum, concrete
block, offshore financial center
_#_Agriculture: livestock (including poultry), fish, fruit, vegetables
_#_Economic aid: NA
_#_Currency: US currency is used
_#_Exchange rates: US currency is used
_#_Fiscal year: 1 April-31 March
_#_Overview: The economy is a mixture of foreign and domestic
entrepreneurship, government regulation and welfare measures, and
village tradition. It is almost totally supported by exports of
crude oil and natural gas, with revenues from the petroleum sector
accounting for more than 50% of GDP. Per capita GDP of $9,600
is among the highest in the Third World, and substantial income from
overseas investment supplements domestic production. The government
provides for all medical services and subsidizes food and housing.
_#_GDP: $3.3 billion, per capita $9,600; real growth rate
2.7% (1989 est.)
_#_Inflation rate (consumer prices): 1.3% (1989 est.)
_#_Unemployment: 2.5%, shortage of skilled labor (1989 est.)
_#_Budget: revenues $1.2 billion; expenditures $1.4 billion,
including capital expenditures of $230 million (1988 est.)
_#_Exports: $1.9 billion (f.o.b., 1989);
commodities--crude oil, liquefied natural gas, petroleum products;
partners--Japan 60%, Thailand 10%, Singapore 4% (1988)
_#_Imports: $1.2 billion (c.i.f., 1989);
commodities--machinery and transport equipment, manufactured
goods, food, chemicals;
partners--Singapore 36%, UK 26%, Switzerland 7%, US 7%, Japan 6%
(1988)
_#_External debt: none
_#_Industrial production: growth rate 12.9% (1987); accounts for
52.4% of GDP
_#_Electricity: 310,000 kW capacity; 890 million kWh produced,
2,400 kWh per capita (1990)
_#_Industries: petroleum, liquefied natural gas, construction
_#_Agriculture: imports about 80% of its food needs; principal crops
and livestock include rice, cassava, bananas, buffaloes, and pigs
_#_Economic aid: US commitments, including Ex-Im (FY70-87), $20.6
million; Western (non-US) countries, ODA and OOF bilateral commitments
(1970-87), $143.7 million
_#_Currency: Bruneian dollar (plural--dollars); 1 Bruneian dollar
(B$) = 100 cents
_#_Exchange rates: Bruneian dollars (B$) per US$1--1.7454 (January
1991), 1.8125 (1990), 1.9503 (1989), 2.0124 (1988), 2.1060 (1987), 2.1774
(1986), 2.2002 (1985); note--the Bruneian dollar is at par with the
Singapore dollar
_#_Fiscal year: calendar year
_#_Overview: Growth in the lackluster Bulgarian economy fell to the
2% annual level in the 1980s. By 1990 Sofia''s foreign debt had
skyrocketed to over $10 billion--giving a debt service ratio of more
than 40% of hard currency earnings and leading the regime to declare
a moratorium on its hard currency payments. The post-Zhivkov regime
faces major problems of renovating an aging industrial plant;
coping with worsening energy, food, and consumer goods shortages;
keeping abreast of rapidly unfolding technological developments;
investing in additional energy capacity (the portion of electric
power from nuclear energy reached over one-third in 1990); and
motivating workers, in part by giving them a share in the earnings of
their enterprises. A major decree of January 1989 summarized and
extended the government''s economic restructuring efforts, which include
a partial decentralization of controls over production decisions and
foreign trade. In October 1990 the Lukanov government proposed an
economic reform program based on a US Chamber of Commerce study. It was
never instituted because of a political stalemate between the BSP and the
UDF. The new Popov government launched a similar reform program in
January 1991, but full implementation has been slowed by continuing
political disputes.
_#_GNP: $47.3 billion, per capita $5,300; real growth rate - 6.0%
(1990)
_#_Inflation rate (consumer prices): 100% (1990 est.)
_#_Unemployment rate: 2% (1990 est.)
_#_Budget: revenues $26 billion; expenditures $28 billion,
including capital expenditures of $NA billion (1988)
_#_Exports: $16.0 billion (f.o.b., 1989);
commodities--machinery and equipment 60.5%; agricultural products
14.7%; manufactured consumer goods 10.6%; fuels, minerals, raw materials,
and metals 8.5%; other 5.7%;
partners--Communist countries 82.5% (USSR 61%, GDR 5.5%,
Czechoslovakia 4.9%); developed countries 6.8% (FRG 1.2%, Greece 1.0%);
less developed countries 10.7% (Libya 3.5%, Iraq 2.9%)
_#_Imports: $15.0 billion (f.o.b., 1989);
commodities--fuels, minerals, and raw materials 45.2%; machinery
and equipment 39.8%; manufactured consumer goods 4.6%; agricultural
products 3.8%; other 6.6%;
partners--Communist countries 80.5% (USSR 57.5%, GDR 5.7%),
developed countries 15.1% (FRG 4.8%, Austria 1.6%); less developed
countries 4.4% (Libya 1.0%, Brazil 0.9%)
_#_External debt: $10 billion (1990)
_#_Industrial production: growth rate - 10.7% (1990); accounts for
about 50% of GDP
_#_Electricity: 11,500,000 kW capacity; 45,000 million kWh produced,
5,040 kWh per capita (1990)
_#_Industries: machine and metal building,food processing, chemicals,
textiles, building materials, ferrous and nonferrous metals
_#_Agriculture: accounts for 15% of GNP; climate and soil conditions
support livestock raising and the growing of various grain crops,
oilseeds, vegetables, fruits and tobacco; more than one-third of the
arable land devoted to grain; world''s fourth-largest tobacco exporter;
surplus food producer
_#_Economic aid: donor--$1.6 billion in bilateral aid to non-Communist
less developed countries (1956-89)
_#_Currency: lev (plural--leva); 1 lev (Lv) = 100 stotinki
_#_Exchange rates: leva (Lv) per US$1--16.13 (March 1991),
0.7446 (November 1990), 0.84 (1989), 0.82 (1988), 0.90 (1987), 0.95
(1986), 1.03 (1985); note--floating exchange rate since February 1990
_#_Fiscal year: calendar year
_#_Overview: One of the poorest countries in the world, Burkina
has a high population density, few natural resources, and relatively
infertile soil. Economic development is hindered by a poor communications
network within a landlocked country. Agriculture provides about 40% of
GDP and is entirely of a subsistence nature. Industry, dominated by
unprofitable government-controlled corporations, accounts for about
15% of GDP.
_#_GDP: $1.75 billion, per capita $205 (1988); real growth rate 3%
(1989)
_#_Inflation rate (consumer prices): - 0.5% (1989)
_#_Unemployment rate: NA%
_#_Budget: revenues $275 million; expenditures $287 million, including
capital expenditures of $NA (1989)
_#_Exports: $262 million (f.o.b., 1989);
commodities--oilseeds, cotton, live animals, gold;
partners--EC 42% (France 30%, other 12%), Taiwan 17%,
Ivory Coast 15% (1985)
_#_Imports: $619 million (f.o.b., 1989);
commodities--grain, dairy products, petroleum, machinery;
partners--EC 37% (France 23%, other 14%), Africa 31%, US 15%
(1985)
_#_External debt: $962 million (December 1990 est.)
_#_Industrial production: growth rate 5.7% (1990est.), accounts for
about 15%
of GDP (1988)
_#_Electricity: 121,000 kW capacity; 320 million kWh produced, 37
kWh per capita (1989)
_#_Industries: cotton lint, beverages, agricultural processing,
soap, cigarettes, textiles, gold
_#_Agriculture: accounts for about 40% of GDP; cash crops--peanuts,
shea nuts, sesame, cotton; food crops--sorghum, millet, corn, rice;
livestock; not self-sufficient in food grains
_#_Economic aid: US commitments, including Ex-Im (FY70-89), $294
million; Western (non-US) countries, ODA and OOF bilateral commitments
(1970-88), $2.7 billion; Communist countries (1970-89), $113 million
_#_Currency: Communaute Financiere Africaine franc
(plural--francs); 1 CFA franc (CFAF) = 100 centimes
_#_Exchange rates: CFA francs (CFAF) per US$1--256.54 (January 1991),
272.26 (1990), 319.01 (1989), 297.85 (1988), 300.54 (1987), 346.30
(1986), 449.26 (1985)
_#_Fiscal year: calendar year
_#_Overview: Burma is a poor Asian country, with a per capita GDP
of about $400. The nation has been unable to achieve any substantial
improvement in export earnings because of falling prices for many
of its major commodity exports. For rice, traditionally the most
important export, the drop in world prices has been accompanied by
shrinking markets and a smaller volume of sales. In 1985 teak replaced
rice as the largest export and continues to hold this position. The
economy is heavily dependent on the agricultural sector, which generates
about half of GDP and provides employment for 66% of the work force.
_#_GDP: $16.8 billion, per capita $408; real growth rate NEGL%
(FY90 est.)
_#_Inflation rate (consumer prices): 22.6% (FY89 est.)
_#_Unemployment rate: 9.6% in urban areas (FY89 est.)
_#_Budget: revenues $4.9 billion; expenditures $5.0 billion,
including capital expenditures of $0.7 billion (FY89 est.)
_#_Exports: $228 million (f.o.b., FY89)
commodities--teak, rice, oilseed, metals, rubber, gems;
partners--Southeast Asia, India, China, EC, Africa
_#_Imports: $540 million (c.i.f., FY89)
commodities--machinery, transport equipment, chemicals, food
products;
partners--Japan, EC, China, Southeast Asia
_#_External debt: $5.5 billion (December 1990 est.)
_#_Industrial production: growth rate 2.6% (FY90 est.); accounts
for 10% of GDP
_#_Electricity: 950,000 kW capacity; 2,900 million kWh produced,
70 kWh per capita (1990)
_#_Industries: agricultural processing; textiles and footwear; wood
and wood products; petroleum refining; mining of copper, tin, tungsten,
iron; construction materials; pharmaceuticals; fertilizer
_#_Agriculture: accounts for 51% of GDP (including fish and
forestry); self-sufficient in food; principal crops--paddy rice, corn,
oilseed, sugarcane, pulses; world''s largest stand of hardwood trees;
rice and teak account for 55% of export revenues; fish catch of
732,000 metric tons (FY90)
_#_Illicit drugs: world''s largest illicit producer of opium poppy
and minor producer of cannabis for the international drug trade; opium
production is on the increase as growers respond to the collapse
of Rangoon''s antinarcotic programs
_#_Economic aid: US commitments, including Ex-Im (FY70-89), $158
million; Western (non-US) countries, ODA and OOF bilateral commitments
(1970-88), $3.9 billion; Communist countries (1970-88), $424 million
_#_Currency: kyat (plural--kyats); 1 kyat (K) = 100 pyas
_#_Exchange rates: kyats (K) per US$1--6.0476 (January 1991), 6.3386
(1990), 6.7049 (1989), 6.3945 (1988), 6.6535 (1987), 7.3304 (1986),
8.4749 (1985)
_#_Fiscal year: 1 April-31 March
_#_Overview: A landlocked, resource-poor country in an early stage
of economic development, Burundi is predominately agricultural with only
a few basic industries. Its economic health depends on the coffee
crop, which accounts for an average 90% of foreign exchange earnings each
year. The ability to pay for imports therefore continues to rest largely
on the vagaries of the climate and the international coffee market.
_#_GDP: $1.1 billion, per capita $200; real growth rate 1.5% (1989)
_#_Inflation rate (consumer prices): 11.7% (1989)
_#_Unemployment rate: NA%
_#_Budget: revenues $158 million; expenditures $204 million,
including capital expenditures of $131 million (1989 est.)
_#_Exports: $81 million (f.o.b., 1989);
commodities--coffee 88%, tea, hides, and skins;
partners--EC 83%, US 5%, Asia 2%
_#_Imports: $197 million (c.i.f., 1989);
commodities--capital goods 31%, petroleum products 15%, foodstuffs,
consumer goods;
partners--EC 57%, Asia 23%, US 3%
_#_External debt: $957 million (December 1990 est.)
_#_Industrial production: real growth rate 5.1% (1986); accounts
for about 10% of GDP
_#_Electricity: 51,000 kW capacity; 105 million kWh produced, 19 kWh
per capita (1989)
_#_Industries: light consumer goods such as blankets, shoes, soap;
assembly of imports; public works construction; food processing
_#_Agriculture: accounts for 60% of GDP; 90% of population dependent
on subsistence farming; marginally self-sufficient in food production;
cash crops--coffee, cotton, tea; food crops--corn, sorghum, sweet
potatoes, bananas, manioc; livestock--meat, milk, hides, and skins
_#_Economic aid: US commitments, including Ex-Im (FY70-89), $71
million; Western (non-US) countries, ODA and OOF bilateral commitments
(1970-88), $10.1 billion; OPEC bilateral aid (1979-89), $32 million;
Communist countries (1970-89), $175 million
_#_Currency: Burundi franc (plural--francs); 1 Burundi franc
(FBu) = 100 centimes
_#_Exchange rates: Burundi francs (FBu) per US$1--163.29 (January
1991), 171.26 (1990), 158.67 (1989), 140.40 (1988), 123.56 (1987), 114.17
(1986), 120.69 (1985)
_#_Fiscal year: calendar year
_#_Overview: Cambodia is a desperately poor country whose economic
development has been stymied by deadly political infighting. The
economy is based on agriculture and related industries. Over the
past decade Cambodia has been slowly recovering from its near destruction
by war and political upheaval. It still remains, however, one of the
world''s poorest countries, with an estimated per capita GDP of about
$130. The food situation is precarious; during the 1980s famine has
been averted only through international relief. In 1986 the production
level of rice, the staple food crop, was able to meet only 80% of
domestic needs. The biggest success of the nation''s recovery program has
been in new rubber plantings and in fishing. Industry, other than rice
processing, is almost nonexistent. Foreign trade is primarily with the
USSR and Vietnam. Statistical data on the economy continues to be sparse
and unreliable. Foreign aid from the USSR and Eastern Europe almost
certainly is being slashed.
_#_GDP: $890 million, per capita $130; real growth rate 0% (1989 est.)
_#_Unemployment rate: NA%
_#_Budget: revenues $NA; expenditures $NA, including capital
expenditures of $NA
_#_Inflation rate (consumer prices): 50% (first half 1990)
_#_Exports: $32 million (f.o.b., 1988);
commodities--natural rubber, rice, pepper, wood;
partners--Vietnam, USSR, Eastern Europe, Japan, India
_#_Imports: $147 million (c.i.f., 1988);
commodities--international food aid; fuels, consumer goods,
machinery;
partners--Vietnam, USSR, Eastern Europe, Japan, India
_#_External debt: $600 million (1989)
_#_Industrial production: growth rate NA%
_#_Electricity: 126,000 kW capacity; 150 million kWh produced,
20 kWh per capita (1990)
_#_Industries: rice milling, fishing, wood and wood products, rubber,
cement, gem mining
_#_Agriculture: mainly subsistence farming except for rubber
plantations; main crops--rice, rubber, corn; food shortages--rice, meat,
vegetables, dairy products, sugar, flour
_#_Economic aid: US commitments, including Ex-Im (FY70-88), $719
million; Western (non-US) countries (1970-88), $285 million; Communist
countries (1970-89), $1,800 million
_#_Currency: riel (plural--riels); 1 riel (CR) = 100 sen
_#_Exchange rates: riels (CR) per US$1--560 (November 1990), 159.00
(1988), 100.00 (1987), 30.00 (1986), 7.00 (1985)
_#_Fiscal year: calendar year
_#_Overview: Over the past decade the economy has registered a
remarkable performance because of the development of an offshore oil
industry. Real GDP growth annually averaged 10% from 1978 to 1985. In
1986 Cameroon had one of the highest levels of income per capita in
tropical Africa, with oil revenues picking up the slack as growth in
other sectors softened. Because of the sharp drop in oil prices, however,
the economy experienced serious budgetary difficulties and
balance-of-payments disequilibrium. Despite the recent upsurge in oil
prices, Cameroon''s economic outlook is troubled. Oil reserves currently
being exploited will be depleted in the early 1990s, so ways must be
found to boost agricultural and industrial exports in the medium term.
The Sixth Cameroon Development Plan (1986-91) stresses balanced
development and designates agriculture as the basis of the country''s
economic future.
_#_GDP: $11.5 billion, per capita $1,040; real growth rate 0.7%
(1990 est.)
_#_Inflation rate (consumer prices): 8.6% (FY88)
_#_Unemployment rate: 25% (1990 est.)
_#_Budget: revenues $1.7 billion; expenditures $2.2 billion,
including capital expenditures of $NA million (FY89)
_#_Exports: $2.1 billion (f.o.b., 1990 est.);
commodities--petroleum products 56%, coffee, cocoa, timber,
manufactures;
partners--EC (particularly the French) about 50%, US 10%
_#_Imports: $2.1 billion (c.i.f., 1990 est.);
commodities--machines and electrical equipment, transport equipment,
chemical products, consumer goods;
partners--France 41%, Germany 9%, US 4%
_#_External debt: $4.9 billion (December 1989 est.)
_#_Industrial production: growth rate - 6.4% (FY87); accounts
for 30% of GDP
_#_Electricity: 752,000 kW capacity; 2,940 million kWh produced,
270 kWh per capita (1989)
_#_Industries: crude oil products, food processing, light consumer
goods industries textiles, sawmills
_#_Agriculture: the agriculture and forestry sectors provide
employment for the majority of the population, contributing nearly 25%
to GDP and providing a high degree of self-sufficiency in staple foods;
commercial and food crops include coffee, cocoa, timber, cotton, rubber,
bananas, oilseed, grains, livestock, root starches
_#_Economic aid: US commitments, including Ex-Im (FY70-89), $440
million; Western (non-US) countries, ODA and OOF bilateral commitments
(1970-88), $4.2 billion; OPEC bilateral aid (1979-89), $29 million;
Communist countries (1970-89), $125 million
_#_Currency: Communaute Financiere Africaine franc
(plural--francs); 1 CFA franc (CFAF) = 100 centimes
_#_Exchange rates: Communaute Financiere Africaine francs
(CFAF) per US$1--256.54 (January 1991), 272.26 (1990), 319.01 (1989),
297.85 (1988), 300.54 (1987), 346.30 (1986), 449.26 (1985)
_#_Fiscal year: 1 July-30 June
_#_Overview: As an affluent, high-tech industrial society, Canada
today closely resembles the US in per capita output, market-oriented
economic system, and pattern of production. Since World War II the
impressive growth of the manufacturing, mining, and service sectors has
transformed the nation from a largely rural economy into one primarily
industrial and urban. In the 1980s Canada registered one of the highest
rates of real growth among the OECD nations, averaging about 3.2%. With
its great natural resources, skilled labor force, and modern capital
plant, Canada has excellent economic prospects. In mid-1990, however, the
long-simmering problems between English- and French-speaking areas
became so acute that observers spoke openly of a possible split in the
confederation; foreign investors were becoming edgy.
_#_GDP: $516.7 billion, per capita $19,500; real growth rate 0.9%
(1990)
_#_Inflation rate (consumer prices): 4.8% (1990)
_#_Unemployment rate: 8.1% (1990)
_#_Budget: revenues $105.8 billion; expenditures $131.6 billion,
including capital expenditures of $NA (FY90 est.)
_#_Exports: $126.7 billion (f.o.b., 1990);
commodities--newsprint, wood pulp, timber, grain, crude petroleum,
machinery, natural gas, ferrous and nonferrous ores, motor vehicles
and parts;
partners--US, Japan, UK, FRG, other EC, USSR
_#_Imports: $116.3 billion (c.i.f., 1990);
commodities--processed foods, beverages, crude petroleum,
chemicals, industrial machinery, motor vehicles and parts, durable
consumer goods, electronic computers;
partners--US,','36040da5c2993a2278898794c51bf70934175ba60a69f847ae9446434ecb1080','internet-archive','theciaworldfactb00025gut','txt','84185fe9df79da427349cc1598fd3f69814a2085a9fc1fe0508a3fae0a870f84','https://archive.org/download/theciaworldfactb00025gut/25.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c4a1e2776d237eca202d6ec87d742466579cab236995de6498db5155cc5baaf2',1991,'AQ','Antarctica','economy',30,'Japan, UK, FRG, other EC, Taiwan, South Korea, Mexico
_#_External debt: $247 billion (1987)
_#_Industrial production: growth rate - 2.7% (1990); accounts for 34%
of GDP
_#_Electricity: 105,000,000 kW capacity; 500,000 million kWh produced,
18,840 kWh per capita (1990)
_#_Industries: processed and unprocessed minerals, food products,
wood and paper products, transportation equipment, chemicals, fish
products, petroleum and natural gas
_#_Agriculture: accounts for about 3% of GDP; one of the world''s major
producers and exporters of grain (wheat and barley); key source of US
agricultural imports; large forest resources cover 35% of total land
area; commercial fisheries provide annual catch of 1.5 million metric
tons, of which 75% is exported
_#_Illicit drugs: illicit producer of cannabis for the domestic
drug market; use of hydroponics technology permits growers to plant
large quantities of high-quality marijuana indoors
_#_Economic aid: donor--ODA and OOF commitments (1970-89), $7.2
billion
_#_Currency: Canadian dollar (plural--dollars); 1 Canadian dollar
(Can$) = 100 cents
_#_Exchange rates: Canadian dollars (Can$) per US$1--1.1559
(January 1991), 1.1668 (1990), 1.1840 (1989), 1.2307 (1988), 1.3260
(1987), 1.3895 (1986), 1.3655 (1985)
_#_Fiscal year: 1 April-31 March
_#_Overview: Cape Verde''s low per capita GDP reflects a poor natural
resource base, a 17-year drought, and a high birthrate. The economy is
service oriented, with commerce, transport, and public services
accounting for 65% of GDP during the period 1985-88. Although nearly
70% of the population lives in rural areas, agriculture''s share of GDP is
only 16%; the fishing sector accounts for 4%. About 90% of food must be
imported. The fishing potential, mostly lobster and tuna, is not fully
exploited. In 1988 fishing represented only 3.5% of GDP. Cape Verde
annually runs a high trade deficit, financed by remittances from
emigrants and foreign aid.
_#_GDP: $262 million, per capita $740; real growth rate 3.2%
(1988 est.)
_#_Inflation rate (consumer prices): 8.2% (1988 est.)
_#_Unemployment rate: 25% (1988)
_#_Budget: revenues $98.3 million; expenditures $138.4
million, including capital expenditures of $NA (1988 est.)
_#_Exports: $10.9 million (f.o.b., 1989 est.);
commodities--fish, bananas, salt;
partners--Portugal, Angola, Algeria, France, Italy
_#_Imports: $107.8 million (c.i.f., 1989);
commodities--petroleum, foodstuffs, consumer goods, industrial
products;
partners--Portugal, Netherlands, Spain, France, Brazil, FRG
_#_External debt: $150 million (December 1990 est.)
_#_Industrial production: growth rate 18% (1988 est.); accounts for
7% of GDP
_#_Electricity: 13,000 kW capacity; 15 million kWh produced,
40 kWh per capita (1990)
_#_Industry: fish processing, salt mining, clothing factories, ship
repair, construction materials, food and beverage production
_#_Agriculture: accounts for 16% of GDP; largely subsistence farming;
bananas are the only export crop; other crops--corn, beans, sweet
potatoes, coffee; growth potential of agricultural sector limited by
poor soils and limited rainfall; annual food imports required; fish catch
provides for both domestic consumption and small exports
_#_Economic aid: US commitments, including Ex-Im (FY75-89), $88
million; Western (non-US) countries, ODA and OOF bilateral commitments
(1970-88), $590 million; OPEC bilateral aid (1979-89), $12 million;
Communist countries (1970-88), $36 million
_#_Currency: Cape Verdean escudo (plural--escudos); 1 Cape Verdean
escudo (CVEsc) = 100 centavos
_#_Exchange rates: Cape Verdean escudos (CVEsc) per
US$1--64.10 (November 1990), 74.86 (December 1989), 72.01 (1988), 72.5
(1987), 76.56 (1986), 85.38 (1985)
_#_Fiscal year: calendar year
_#_Overview: The economy depends heavily on tourism (70% of GDP
and 75% of export earnings) and offshore financial services, with
the tourist industry aimed at the luxury market and catering
mainly to visitors from North America. About 90% of the islands'' food and
consumer goods needs must be imported. The Caymanians enjoy one of the
highest standards of living in the region.
_#_GDP: $342 million, per capita $13,670 (1989); real growth
rate 15% (1988)
_#_Inflation rate (consumer prices): 5.2% (1988)
_#_Unemployment rate: NA%
_#_Budget: revenues $76 million; expenditures $56 million,
including capital expenditures of $NA (1988)
_#_Exports: $1.5 million (f.o.b., 1987 est.);
commodities--turtle products, manufactured consumer goods;
partners--mostly US
_#_Imports: $136 million (c.i.f., 1987 est.);
commodities--foodstuffs, manufactured goods;
partners--US, Trinidad and Tobago, UK, Netherlands Antilles, Japan
_#_External debt: $15 million (1986)
_#_Industrial production: growth rate NA%
_#_Electricity: 74,000 kW capacity; 256 million kWh produced,
9,710 kWh per capita (1990)
_#_Industries: tourism, banking, insurance and finance, construction,
building materials, furniture making
_#_Agriculture: minor production of vegetables, fruit, livestock;
turtle farming
_#_Economic aid: US commitments, including Ex-Im (FY70-87), $26.7
million; Western (non-US) countries, ODA and OOF bilateral commitments
(1970-88), $35.0 million
_#_Currency: Caymanian dollar (plural--dollars); 1 Caymanian dollar
(CI$) = 100 cents
_#_Exchange rates: Caymanian dollars (CI$) per US$1--1.20 (fixed
rate)
_#_Fiscal year: 1 April-31 March
_#_Overview: The Central African Republic (CAR) had a per capita
income of roughly $440 in 1990. Subsistence agriculture, including
forestry, is the backbone of the economy, with over 70% of the population
living in the countryside. In 1988 the agricultural sector generated
about 40% of GDP. Agricultural products accounted for about 60% of export
earnings and the diamond industry for 30%. Important constraints to
economic development include the CAR''s landlocked position, a poor
transportation infrastructure, and a weak human resource base.
Multilateral and bilateral development assistance plays a major role in
providing capital for new investment.
_#_GDP: $1.3 billion, per capita $440; real growth rate 2.0%
(1990 est.)
_#_Inflation rate (consumer prices): - 4.2% (1988 est.)
_#_Unemployment rate: 30% in Bangui (1988 est.)
_#_Budget: revenues $132 million; current expenditures $305 million,
including capital expenditures of $NA million (1989 est.)
_#_Exports: $148 million (f.o.b., 1989 est.);
commodities--diamonds, cotton, coffee, timber, tobacco;
partners--France, Belgium, Italy, Japan, US
_#_Imports: $239 million (c.i.f., 1989 est.);
commodities--food, textiles, petroleum products, machinery,
electrical equipment, motor vehicles, chemicals, pharmaceuticals,
consumer goods, industrial products;
partners--France, other EC, Japan, Algeria, Yugoslavia
_#_External debt: $671 million (December 1989)
_#_Industrial production: 0.8% (1988); accounts for 12% of GDP
_#_Electricity: 35,000 kW capacity; 84 million kWh produced,
30 kWh per capita (1989)
_#_Industries: diamond mining, sawmills, breweries, textiles,
footwear, assembly of bicycles and motorcycles
_#_Agriculture: accounts for 40% of GDP; self-sufficient in food
production except for grain; commercial crops--cotton, coffee, tobacco,
timber; food crops--manioc, yams, millet, corn, bananas
_#_Economic aid: US commitments, including Ex-Im (FY70-89), $49
million; Western (non-US) countries, ODA and OOF bilateral commitments
(1970-88), $1.4 billion; OPEC bilateral aid (1979-89), $6 million;
Communist countries (1970-88), $38 million
_#_Currency: Communaute Financiere Africaine franc
(plural--francs); 1 CFA franc (CFAF) = 100 centimes
_#_Exchange rates: Communaute Financiere Africaine francs (CFAF)
per US$1--256.54 (January 1991), 272.26 (1990), 319.01 (1989), 297.85
(1988), 300.54 (1987), 346.30 (1986), 449.26 (1985)
_#_Fiscal year: calendar year','af2a0eace79fe0fe8b983e8fe5c59c6f5323b63c59be6e77477752c11f6b4fb1','internet-archive','theciaworldfactb00025gut','txt','84185fe9df79da427349cc1598fd3f69814a2085a9fc1fe0508a3fae0a870f84','https://archive.org/download/theciaworldfactb00025gut/25.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f04b045e2d684a154c3f553d6e44c208ce10217b09dbbbe9e5547485a28db1dd',1991,'NG','Nigeria','economy',35,'_#_Overview: The climate, geographic location, and lack of
infrastructure and natural resources potential make Chad one of the most
underdeveloped countries in the world. Its economy is burdened by
the ravages of civil war, conflict with Libya, drought, and food
shortages. In 1986 real GDP returned to its 1977 level, with cotton,
the major cash crop, accounting for 48% of exports. Over 80%
of the work force is employed in subsistence farming and fishing.
Industry is based almost entirely on the processing of agricultural
products, including cotton, sugarcane, and cattle. Chad is highly
dependent on foreign aid, with its economy in trouble and many regions
suffering from shortages. Oil companies are exploring areas north of
Lake Chad and in the Doba basin in the south.
_#_GDP: $1,015 million, per capita $205; real growth rate 0.9% (1989
est.)
_#_Inflation rate (consumer prices): - 4.9% (1989)
_#_Unemployment rate: NA
_#_Budget: revenues $78 million; expenditures $127 million, not
including capital expenditures that are mostly financed by foreign
aid donors (1989 est.)
_#_Exports: $174 million (f.o.b., 1990 est.);
commodities--cotton 48%, cattle 35%, textiles 5%, fish;
partners--France, Nigeria, Cameroon
_#_Imports: $264 million (c.i.f., 1990 est.);
commodities--machinery and transportation equipment 39%,
industrial goods 20%, petroleum products 13%, foodstuffs 9%;
note--excludes military equipment;
partners--US, France, Nigeria, Cameroon
_#_External debt: $530 million (December 1990 est.)
_#_Industrial production: growth rate 12.9% (1989 est.); accounts for
nearly 15% of GDP
_#_Electricity: 38,000 kW capacity; 70 million kWh produced, 14 kWh
per capita (1989)
_#_Industries: cotton textile mills, slaughterhouses, brewery, natron
(sodium carbonate), soap, cigarettes
_#_Agriculture: accounts for about 45% of GDP; largely subsistence
farming; cotton most important cash crop; food crops include sorghum,
millet, peanuts, rice, potatoes, manioc; livestock--cattle, sheep, goats,
camels; self-sufficient in food in years of adequate rainfall
_#_Economic aid: US commitments, including Ex-Im (FY70-89), $198
million; Western (non-US) countries, ODA and OOF bilateral commitments
(1970-88), $1.3 billion; OPEC bilateral aid (1979-89), $28 million;
Communist countries (1970-89), $80 million
_#_Currency: Communaute Financiere Africaine franc
(plural--francs); 1 CFA franc (CFAF) = 100 centimes
_#_Exchange rates: Communaute Financiere Africaine francs (CFAF)
per US$1--256.54 (January 1991), 272.26 (1990), 319.01 (1989), 297.85
(1988), 300.54 (1987), 346.30 (1986), 449.26 (1985)
_#_Fiscal year: calendar year
_#_Overview: In 1990 economic growth slowed from an average of 6.2%
for the previous six years to about 1.5% as a result of tight monetary
policy aimed at reducing inflation. Monetary policy was not
successful at slowing price increases until the end of the year,
however, and inflation, stimulated by higher world oil prices,
increased to 27.3% in 1990 from 21.4% in 1989. Copper prices held strong
in 1990, helping to maintain a balance-of-payments surplus and increase
international reserves. Most observers expect that inflationary
pressures have run their course and price increases will slow during
1991, contributing to growth of 4-5%.
_#_GDP: $26 billion, per capita $2,000; real growth rate 2.0% (1990)
_#_Inflation rate (consumer prices): 27.3% (1990)
_#_Unemployment rate: 5.6% (1990)
_#_Budget: revenues $6.6 billion; expenditures $7.1 billion,
including capital expenditures of $575 million (1990 est.)
_#_Exports: $8.3 billion (f.o.b., 1990);
commodities--copper 48%, industrial products 33%, molybdenum,
iron ore, wood pulp, fishmeal, fruits;
partners--EC 34%, US 22%, Japan 10%, Brazil 7%
_#_Imports: $7.0 billion (f.o.b., 1990);
commodities--petroleum, wheat, capital goods, spare parts, raw
materials;
partners--EC 23%, US 20%, Japan 10%, Brazil 9%
_#_External debt: $18.4 billion (February 1991)
_#_Industrial production: growth rate 0% (1990);
accounts for 30% of GDP
_#_Electricity: 4,138,000 kW capacity; 17,784 million kWh produced,
1,360 kWh per capita (1990)
_#_Industries: copper, other minerals, foodstuffs, fish processing,
iron and steel, wood and wood products, transport equipment, cement,
textiles
_#_Agriculture: accounts for about 8% of GDP (including fishing and
forestry); major exporter of fruit, fish, and timber products; major
crops--wheat, corn, grapes, beans, sugar beets, potatoes, deciduous
fruit; livestock products--beef, poultry, wool; self-sufficient in most
foods; 1986 fish catch of 5.6 million metric tons net agricultural
importer
_#_Economic aid: US commitments, including Ex-Im (FY70-89), $521
million; Western (non-US) countries, ODA and OOF bilateral commitments
(1970-88), $1.4 billion; Communist countries (1970-88), $386 million
_#_Currency: Chilean peso (plural--pesos);
1 Chilean peso (Ch$) = 100 centavos
_#_Exchange rates: Chilean pesos (Ch$) per US$1--337.24 (January
1991), 305.06 (1990), 267.16 (1989), 245.05 (1988), 219.54 (1987), 193.02
(1986), 161.08 (1985)
_#_Fiscal year: calendar year
_#_Overview: Beginning in late 1978 the Chinese leadership has been
trying to move the economy from the sluggish Soviet-style centrally
planned economy to a more productive and flexible economy with market
elements--but still within the framework of monolithic Communist control.
To this end the authorities have switched to a system of household
responsibility in agriculture in place of the old collectivization,
increased the authority of local officials and plant managers in
industry, permitted a wide variety of small-scale enterprise in services
and light manufacturing, and opened the foreign economic sector to
increased trade and joint ventures. The most gratifying result has been a
strong spurt in production, particularly in agriculture in the early
1980s. Otherwise, the leadership has often experienced in its hybrid
system the worst results of socialism (bureaucracy, lassitude,
corruption) and of capitalism (windfall gains and stepped-up inflation).
Beijing thus has periodically backtracked, retightening central controls
at intervals and thereby undermining the credibility of the reform
process. Popular resistance and changes in central policy have
weakened China''s population control program, which is essential to the
nation''s long-term economic viability.
_#_GNP: $413 billion (1989 est.), per capita $370 (World Bank est.);
real growth rate 5% (1990)
_#_Inflation rate (consumer prices): 2.1% (1990)
_#_Unemployment rate: 2.6% in urban areas (1990)
_#_Budget: revenues $NA; expenditures $NA, including capital
expenditures of $NA
_#_Exports: $62.1 billion (f.o.b., 1990);
commodities--textiles, garments, telecommunications and recording
equipment, petroleum, minerals;
partners--Hong Kong, US, Japan, USSR, Singapore, FRG (1989)
_#_Imports: $53.4 billion (c.i.f., 1990);
commodities--specialized industrial machinery, chemicals,
manufactured goods, steel, textile yarn, fertilizer;
partners--Hong Kong, Japan, US, FRG, USSR (1989)
_#_External debt: $51 billion (1990 est.)
_#_Industrial production: growth rate 7.6% (1990); accounts
for 45% of GNP
_#_Electricity: 117,580,000 kW capacity; 585,000 million kWh produced,
520 kWh per capita (1990)
_#_Industries: iron, steel, coal, machine building, armaments,
textiles, petroleum, cement, chemical fertilizers, consumer durables,
food processing
_#_Agriculture: accounts for 26% of GNP; among the world''s largest
producers of rice, potatoes, sorghum, peanuts, tea, millet, barley,
and pork; commercial crops include cotton, other fibers, and oilseeds;
produces variety of livestock products; basically self-sufficient in
food; fish catch of 8 million metric tons in 1986
_#_Economic aid: donor--to less developed countries (1970-89) $7.0
billion; US commitments, including Ex-Im (FY70-87), $220.7 million;
Western (non-US) countries, ODA and OOF bilateral commitments (1970-87),
$13.5 billion
_#_Currency: yuan (plural--yuan); 1 yuan (3) = 10 jiao
_#_Exchange rates: yuan (3) per US$1--5.31 (April 1991),
4.7832 (1990), 3.7651 (1989), 3.7221 (1988), 3.7221 (1987), 3.4528
(1986), 2.9367 (1985)
_#_Fiscal year: calendar year','ce763b61e357dad0b9120348817b027c70c99533e825b929a32eca2e9202cca2','internet-archive','theciaworldfactb00025gut','txt','84185fe9df79da427349cc1598fd3f69814a2085a9fc1fe0508a3fae0a870f84','https://archive.org/download/theciaworldfactb00025gut/25.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('779eda5610ee392149ee6017a33a416613c177d73c622833d3b890a237592f11',1991,'AU','Australia','economy',38,'_#_Overview: Phosphate mining had been the only significant
economic activity, but in December 1987 the Australian Government
closed the mine as no longer economically viable. Plans have been
under way to reopen the mine and also to build a casino and hotel to
develop tourism, with a possible opening date during the first half of
1992.
_#_GDP: $NA, per capita $NA; real growth rate NA%
_#_Inflation rate (consumer prices): NA%
_#_Unemployment rate: 0%
_#_Budget: revenues $NA; expenditures $NA, including capital
expenditures of $NA
_#_Exports: $NA;
commodities--phosphate;
partners--Australia, NZ
_#_Imports: $NA;
commodities--NA;
partners--NA
_#_External debt: $NA
_#_Industrial production: growth rate NA%
_#_Electricity: 11,000 kW capacity; 30 million kWh produced,
13,170 kWh per capita (1990)
_#_Industries: phosphate extraction (near depletion)
_#_Agriculture: NA
_#_Economic aid: none
_#_Currency: Australian dollar (plural--dollars); 1 Australian dollar
($A) = 100 cents
_#_Exchange rates: Australian dollars ($A) per US$1--1.2834 (January
1991), 1.2799 (1990), 1.2618 (1989), 1.2752 (1988), 1.4267 (1987), 1.4905
(1986), 1.4269 (1985)
_#_Fiscal year: 1 July-30 June
_#_Overview: only economic activity is a tuna fishing station
_#_Overview: Grown throughout the islands, coconuts are the sole cash
crop. Copra and fresh coconuts are the major export earners. Small local
gardens and fishing contribute to the food supply, but additional food
and most other necessities must be imported from Australia.
_#_GDP: $NA, per capita $NA; real growth rate NA%
_#_Inflation rate (consumer prices): NA%
_#_Unemployment: NA
_#_Budget: revenues $NA; expenditures $NA, including capital
expenditures of $NA
_#_Exports: $NA;
commodities--copra;
partners--Australia
_#_Imports: $NA;
commodities--foodstuffs;
partners--Australia
_#_External debt: $NA
_#_Industrial production: growth rate NA%
_#_Electricity: 1,000 kW capacity; 2 million kWh produced, 2,980 kWh
per capita (1990)
_#_Industries: copra products
_#_Agriculture: gardens provide vegetables, bananas, pawpaws, coconuts
_#_Economic aid: none
_#_Currency: Australian dollar (plural--dollars); 1 Australian dollar
($A) = 100 cents
_#_Exchange rates: Australian dollars ($A) per US$1--1.2834 (January
1991), 1.2799 (1990), 1.2618 (1989), 1.2752 (1988), 1.4267 (1987), 1.4905
(1986), 1.4269 (1985)
_#_Fiscal year: 1 July-30 June
_#_Overview: Economic development has slowed gradually since 1986, but
growth rates remain high by Latin American standards. Conservative
economic policies have kept inflation and unemployment near 30% and 10%,
respectively. The rapid development of oil, coal, and other
nontraditional industries over the past four years has helped to offset
the decline in coffee prices--Colombia''s major export. The collapse of
the International Coffee Agreement in the summer of 1989, a troublesome
rural insurgency, and drug-related violence dampen prospects for future
growth.
_#_GDP: $43.0 billion, per capita $1,300; real growth rate 3.7% (1990
est.)
_#_Inflation rate (consumer prices): 32.4% (1990)
_#_Unemployment rate: 10.4% (urban areas 1990) (1990)
_#_Budget: revenues $4.39 billion; current expenditures $3.93
billion, capital expenditures $1.03 billion (1989 est.)
_#_Exports: $6.9 billion (f.o.b., 1990);
commodities--coffee 24%, petroleum, coal, bananas, fresh cut
flowers;
partners--US 36%, EC 21%, Japan 5%, Netherlands 4%, Sweden 3%
_#_Imports: $5.0 billion (c.i.f., 1990);
commodities--industrial equipment, transportation equipment,
foodstuffs, chemicals, paper products;
partners--US 34%, EC 16%, Brazil 4%, Venezuela 3%, Japan 3%
_#_External debt: $16.7 billion (1990)
_#_Industrial production: growth rate 5.0% (1990 est.); accounts
for 25% of GDP
_#_Electricity: 9,435,000 kW capacity; 36,071 million kWh produced,
1,090 kWh per capita (1990)
_#_Industries: textiles, food processing, oil, clothing and footwear,
beverages, chemicals, metal products, cement; mining--gold, coal,
emeralds, iron, nickel, silver, salt
_#_Agriculture: growth rate 4.9% (1990); accounts for 22% of GDP;
crops make up two-thirds and livestock one-third of agricultural output;
climate and soils permit a wide variety of crops, such as coffee,
rice, tobacco, corn, sugarcane, cocoa beans, oilseeds, vegetables;
forest products and shrimp farming are becoming more important
_#_Illicit drugs: major illicit producer of cannabis and coca; key
supplier of marijuana and cocaine to the US and other international drug
markets; drug production and trafficking accounts for an estimated 4%
of GDP and 28% of foreign exchange earnings
_#_Economic aid: US commitments, including Ex-Im (FY70-89), $1.6
billion; Western (non-US) countries, ODA and OOF bilateral commitments
(1970-88), $3.1 billion; Communist countries (1970-89), $399 million
_#_Currency: Colombian peso (plural--pesos);
1 Colombian peso (Col$) = 100 centavos
_#_Exchange rates: Colombian pesos (Col$) per US$1--574.09 (January
1991), 502.24 (1990), 382.57 (1989), 299.17 (1988), 242.61 (1987), 194.26
(1986), 142.31 (1985)
_#_Fiscal year: calendar year
_#_Overview: One of the world''s poorest countries, Comoros is made
up of several islands that have poor transportation links, a young and
rapidly increasing population, and few natural resources. The low
educational level of the labor force contributes to a low level of
economic activity, high unemployment, and a heavy dependence on foreign
grants and technical assistance. Agriculture, including fishing and
forestry, is the leading sector of the economy. It contributes about 40%
to GDP, employs 80% of the labor force, and provides most of the exports.
The country is not self-sufficient in food production, and rice, the main
staple, accounts for 90% of imports. During the period 1982-86 the
industrial sector grew at an annual average rate of 5.3%, but its
contribution to GDP was only 5% in 1988. Despite major investment in the
tourist industry, which accounts for about 25% of GDP, growth has
stagnated since 1983. A sluggish growth rate of 1.5% during 1985-90 has
led to large budget deficits, declining incomes, and balance-of-payments
difficulties.
_#_GDP: $245 million, per capita $530; real growth rate 1.5% (1990
est.)
_#_Inflation rate (consumer prices): 2.9% (1989)
_#_Unemployment rate: over 16% (1988 est.)
_#_Budget: revenues $88 million; expenditures $92 million,
including capital expenditures of $13 million (1990 est.)
_#_Exports: $16 million (f.o.b., 1990 est.);
commodities--vanilla, cloves, perfume oil, copra;
partners--US 53%, France 41%, Africa 4%, FRG 2% (1988)
_#_Imports: $41 million (f.o.b., 1990 est.);
commodities--rice and other foodstuffs, cement, petroleum products,
consumer goods;
partners--Europe 62% (France 22%, other 40%), Africa 5%, Pakistan,
China (1988)
_#_External debt: $242 million (December 1990)
_#_Industrial production: growth rate 3.4% (1988 est.); accounts
for 5% of GDP
_#_Electricity: 16,000 kW capacity; 24 million kWh produced,
55 kWh per capita (1989)
_#_Industries: perfume distillation, textiles, furniture, jewelry,
construction materials
_#_Agriculture: accounts for 40% of GDP; most of population works in
subsistence agriculture and fishing; plantations produce cash crops for
export--vanilla, cloves, perfume essences, and copra; principal food
crops--coconuts, bananas, cassava; world''s leading producer of essence of
ylang-ylang (for perfumes) and second-largest producer of vanilla; large
net food importer
_#_Economic aid: US commitments, including Ex-Im (FY80-89), $10
million; Western (non-US) countries, ODA and OOF bilateral commitments
(1970-88), $406 million; OPEC bilateral aid (1979-89), $22 million;
Communist countries (1970-89), $18 million
_#_Currency: Comoran franc (plural--francs); 1 Comoran franc
(CF) = 100 centimes
_#_Exchange rates: Comoran francs (CF) per US$1--256.54 (January
1991), 272.26 (1990), 319.01 (1989), 297.85 (1988), 300.54 (1987), 346.30
(1986), 449.26 (1985); note--linked to the French franc at 50 to 1 French
franc
_#_Fiscal year: calendar year','2a35a719d2dccafe8aaeece9c6c2c04ecc51f8b3bfb750352195fd7e68f06947','internet-archive','theciaworldfactb00025gut','txt','84185fe9df79da427349cc1598fd3f69814a2085a9fc1fe0508a3fae0a870f84','https://archive.org/download/theciaworldfactb00025gut/25.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cbeaec49cf840b91711cba5a11edb2be8c008764426fef7e13fd3f45a7301936',1991,'SE','Sweden','economy',46,'_#_Overview: This modern economy features high-tech
agriculture, up-to-date small-scale and corporate industry, extensive
government welfare measures, comfortable living standards, and high
dependence on foreign trade. The Danish economy is likely to maintain
its slow but steady improvement in 1991. GDP grew by 1.3% in 1990
and probably will grow by about 1.25% in 1991; unemployment is running
close to 10%. In 1990 Denmark had the lowest inflation rate in the EC,
a record trade surplus, and the first balance-of-payments surplus in
26 years. As the government prepares for the economic integration of
Europe during 1992, growth, investment, and competitiveness are expected
to improve, reducing unemployment, inflation, and debt.
_#_GDP: $78.0 billion, per capita $15,200; real growth rate 1.3%
(1990)
_#_Inflation rate (consumer prices): 2.7% (1990)
_#_Unemployment rate: 9.5% (1990)
_#_Budget: revenues $62.5 billion; expenditures $60 billion, including
capital expenditures of $NA billion (1989)
_#_Exports: $34.8 billion (f.o.b., 1990);
commodities--meat and meat products, dairy products, transport
equipment, fish, chemicals, industrial machinery;
partners--EC 52.2% (Germany 19.5%, UK 10.9%, France 6.1%), Sweden
12.5%, Norway 5.8%, US 5.0%, Japan 4.3% (1990)
_#_Imports: $31.6 billion (c.i.f., 1990);
commodities--petroleum, machinery and equipment, chemicals, grain
and foodstuffs, textiles, paper;
partners--EC 57% (Germany 25.6%, UK 8.4%), Sweden 12.7%, US 6.7%
(1990)
_#_External debt: $45 billion (1990)
_#_Industrial production: growth rate 2.1% (1989)
_#_Electricity: 11,215,000 kW capacity; 30,910 million kWh produced,
6,030 kWh per capita (1989)
_#_Industries: food processing, machinery and equipment, textiles and
clothing, chemical products, electronics, construction, furniture, and
other wood products
_#_Agriculture: accounts for 5% of GNP and employs 6% of labor force
(includes fishing and forestry); farm products account for nearly 15%
of export revenues; principal products--meat, dairy, grain, potatoes,
rape, sugar beets, fish; self-sufficient in food production
_#_Economic aid: donor--ODA and OOF commitments (1970-89) $5.9 billion
_#_Currency: Danish krone (plural--kroner); 1 Danish krone
(DKr) = 100 ore
_#_Exchange rates: Danish kroner (DKr) per US$1--5.817 (January
(1991), 6.189 (1990), 7.310 (1989), 6.732 (1988), 6.840 (1987), 8.091
(1986), 10.596 (1985)
_#_Fiscal year: calendar year
_#_Overview: The economy is based on service activities connected with
the country''s strategic location and status as a free trade zone in
northeast Africa. Djibouti provides services as both a transit port
for the region and an international transshipment and refueling center.
It has few natural resources and little industry. The nation is,
therefore, heavily dependent on foreign assistance to help support its
balance of payments and to finance development projects. An unemployment
rate of over 40% continues to be a major problem. Per capita
consumption dropped an estimated 35% over the last five years with
a population growth rate of 6% (including immigrants and refugees) and a
recession.
_#_GDP: $340 million, $1,030 per capita; real growth rate - 1.0% (1989
est.)
_#_Inflation rate (consumer prices): 3.7% (1989)
_#_Unemployment rate: over 40% (1989)
_#_Budget: revenues $131 million; expenditures $154 million, including
capital expenditures of $25 million (1990 est.)
_#_Exports: $190 million (f.o.b., 1990 est.);
commodities--hides and skins, coffee (in transit);
partners--Middle East 50%, Africa 43%, Western Europe 7%
_#_Imports: $311 million (f.o.b., 1990 est.);
commodities--foods, beverages, transport equipment, chemicals,
petroleum products;
partners--EC 36%, Africa 21%, Asia 12%, US 2%
_#_External debt: $355 million (December 1990)
_#_Industrial production: growth rate 0.1% (1989); manufacturing
accounts for 4% of GDP
_#_Electricity: 110,000 kW capacity; 190 million kWh produced,
580 kWh per capita (1989)
_#_Industries: limited to a few small-scale enterprises, such as
dairy products and mineral-water bottling
_#_Agriculture: accounts for only 5% of GDP; scanty rainfall limits
crop production to mostly fruit and vegetables; half of population
pastoral nomads herding goats, sheep, and camels; imports bulk of food
needs
_#_Economic aid: US commitments, including Ex-Im (FY78-89), $39
million; Western (non-US) countries, including ODA and OOF bilateral
commitments (1970-88), $1,035 million; OPEC bilateral aid (1979-89),
$149 million; Communist countries (1970-89), $35 million
_#_Currency: Djiboutian franc (plural--francs); 1 Djiboutian franc
(DF) = 100 centimes
_#_Exchange rates: Djiboutian francs (DF) per US$1--177.721 (fixed
rate since 1973)
_#_Fiscal year: calendar year
_#_Overview: The economy is dependent on agriculture and thus is
highly vulnerable to climatic conditions. Agriculture accounts for about
30% of GDP and employs 40% of the labor force. Principal products include
bananas, citrus, mangoes, root crops, and coconuts. In 1988 the economy
achieved a 5.6% growth in real GDP on the strength of a boost in
construction, higher agricultural production, and growth of the small
manufacturing sector based on the soap and garment industries. In 1989,
however, Hurricane Hugo wiped out 70% of the banana crop and affected
other economic activity. The tourist industry remains undeveloped because
of a rugged coastline and the lack of an international-class airport.
_#_GDP: $153 million, per capita $1,840; real growth rate - 1.7%
(1989 est.)
_#_Inflation rate (consumer prices): 6.3% (1989)
_#_Unemployment rate: 10% (1989 est.)
_#_Budget: revenues $48 million; expenditures $85 million,
including capital expenditures of $41 million (FY90)
_#_Exports: $59 million (f.o.b., 1990);
commodities--bananas, coconuts, grapefruit, soap, galvanized
sheets;
partners--UK 72%, Jamaica 10%, OECS 6%, US 3%, other 9%
_#_Imports: $115 million (c.i.f., 1990);
commodities--food, oils and fats, chemicals, fuels and lubricants,
manufactured goods, machinery and equipment;
partners--US 23%, UK 18%, CARICOM 15%, OECS 15%, Japan 5%,
Canada 3%, other 21%
_#_External debt: $73 million (1990 est.)
_#_Industrial production: growth rate 4.5% in manufacturing (1988
est.); accounts for 11% of GDP
_#_Electricity: 7,000 kW capacity; 16 million kWh produced,
190 kWh per capita (1990)
_#_Industries: soap, beverages, tourism, food processing, furniture,
cement blocks, shoes
_#_Agriculture: accounts for 30% of GDP; principal crops--bananas,
citrus, mangoes, root crops, and coconuts; bananas provide the bulk
of export earnings; forestry and fisheries potential not exploited
_#_Economic aid: Western (non-US) countries, ODA and OOF bilateral
commitments (1970-88), $115 million
_#_Currency: East Caribbean dollar (plural--dollars); 1 EC dollar
(EC$) = 100 cents
_#_Exchange rates: East Caribbean dollars (EC$) per US$1--2.70
(fixed rate since 1976)
_#_Fiscal year: 1 July-30 June
_#_Overview: The economy is largely dependent on trade; imported
components average 60% of the value of goods consumed in the domestic
market. Rapid growth of free trade zones has established a significant
expansion of manufacturing for export, especially wearing apparel.
Over the past decade tourism has also increased in importance and is a
major earner of foreign exchange and a source of new jobs. Agriculture
remains a key sector of the economy. The principal commercial crop is
sugarcane, followed by coffee, cotton, cocoa, and tobacco. Domestic
industry is based on the processing of agricultural products, durable
consumer goods, minerals, and chemicals. Unemployment is officially
reported at about 30%, but there is considerable underemployment. An
increasing foreign debt burden and galloping inflation are the economy''s
greatest weaknesses.
_#_GDP: $6.68 billion, per capita $940; real growth rate 4.2% (1989)
_#_Inflation rate (consumer prices): 70% (1990 est.)
_#_Unemployment rate: 29% (1990 est.)
_#_Budget: revenues $413 million; expenditures $522 million,
including capital expenditures of $218 million (1988)
_#_Exports: $922 million (f.o.b., 1990 est.);
commodities--sugar, coffee, cocoa, gold, ferronickel;
partners--US 60%, EC 19%, Puerto Rico 8% (1990)
_#_Imports: $1.9 billion (c.i.f., 1990 est.);
commodities--foodstuffs, petroleum, cotton and fabrics, chemicals
and pharmaceuticals;
partners--US 50%
_#_External debt: $4.2 billion (1990 est.)
_#_Industrial production: growth rate 2.3% (1989 est.); accounts
for 18% of GDP
_#_Electricity: 1,445,000 kW capacity; 4,200 million kWh produced,
580 kWh per capita (1990)
_#_Industries: tourism, sugar processing, ferronickel and gold mining,
textiles, cement, tobacco
_#_Agriculture: accounts for 15% of GDP and employs 49% of labor
force; sugarcane most important commercial crop, followed by coffee,
cotton, cocoa, and tobacco; food crops--rice, beans, potatoes, corn,
bananas; animal output--cattle, hogs, dairy products, meat, eggs; not
self-sufficient in food
_#_Economic aid: US commitments, including Ex-Im (FY85-89), $576.5
million; Western (non-US) countries, ODA and OOF bilateral commitments
(1970-88), $569 million
_#_Currency: Dominican peso (plural--pesos); 1 Dominican peso
(RD$) = 100 centavos
_#_Exchange rates: Dominican pesos per US$1--11.850 (January 1991),
8.290 (1990), 6.3400 (1989), 6.1125 (1988), 3.8448 (1987), 2.9043 (1986),
3.1126 (1985)
_#_Fiscal year: calendar year
_#_Overview: Ecuador has substantial oil resources and rich
agricultural areas. Growth has been uneven because of natural disasters
(e.g., a major earthquake in 1987), fluctuations in global oil prices,
and government policies designed to curb inflation. The government has
not taken a supportive attitude toward either domestic or foreign
investment, although its agreement to enter the Andean free trade zone
is an encouraging move.
_#_GDP: $10.6 billion, per capita $1,010; real growth rate 1.5% (1990)
_#_Inflation rate (consumer prices): 49.5% (1990)
_#_Unemployment rate: 8.0% (1990)
_#_Budget: revenues $2.2 billion; expenditures $2.2 billion,
including capital expenditures of $375 million (1991)
_#_Exports: $2.7 billion (f.o.b., 1990);
commodities--petroleum 47%, coffee, bananas, cocoa products,
shrimp, fish products;
partners--US 60%, Latin America, Caribbean, EC countries
_#_Imports: $1.7 billion (f.o.b., 1990);
commodities--transport equipment, vehicles, machinery, chemicals;
partners--US 34%, Latin America, Caribbean, EC, Japan
_#_External debt: $11.8 billion (December 1990)
_#_Industrial production: growth rate - 3.8% (1989); accounts for
almost 40% of GDP, including petroleum
_#_Electricity: 1,983,000 kW capacity; 6,011 million kWh produced,
570 kWh per capita (1990)
_#_Industries: petroleum, food processing, textiles, metal works, paper
products, wood products, chemicals, plastics, fishing, timber
_#_Agriculture: accounts for 18% of GDP and 35% of labor force
(including fishing and forestry); leading producer and exporter of
bananas and balsawood; other exports--coffee, cocoa, fish, shrimp; crop
production--rice, potatoes, manioc, plantains, sugarcane; livestock
sector--cattle, sheep, hogs, beef, pork, dairy products; net importer
of foodgrains, dairy products, and sugar
_#_Illicit drugs: relatively small producer of coca following the
successful eradication campaign of 1985-87; significant transit country,
however, for derivatives of coca originating in Colombia, Bolivia, and','93d31f68af6c9fa20a2d01ae67dd27d5217cc486ba021050535135b82689e06d','internet-archive','theciaworldfactb00025gut','txt','84185fe9df79da427349cc1598fd3f69814a2085a9fc1fe0508a3fae0a870f84','https://archive.org/download/theciaworldfactb00025gut/25.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('129ab134892de72aa0aa9d28531ee2ee125c105f30cc8109d68d8d00b1a04bc7',1991,'PE','Peru','economy',51,'_#_Economic aid: US commitments, including Ex-Im (FY70-89), $498
million; Western (non-US) countries, ODA and OOF bilateral commitments
(1970-88), $1.7 billion; Communist countries (1970-89), $64 million
_#_Currency: sucre (plural--sucres); 1 sucre (S/) = 100 centavos
_#_Exchange rates: sucres (S/) per US$1--869.54 (December 1990),
767.75 (1990), 526.35 (1989), 301.61 (1988), 170.46 (1987), 122.78
(1986), 69.56 (1985)
_#_Fiscal year: calendar year','f906e69e606e4c020a1ad9794d312471fc95d58f0efc5389a29237d5c2054900','internet-archive','theciaworldfactb00025gut','txt','84185fe9df79da427349cc1598fd3f69814a2085a9fc1fe0508a3fae0a870f84','https://archive.org/download/theciaworldfactb00025gut/25.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1e2c7d682215b22b6cc59d52fe44ed3c7e2bdceb5bc97094d72fa491cbacd238',1991,'MX','Mexico','economy',57,'_#_Overview: Egypt has one of the largest public sectors of all
the Third World economies, most industrial plants being owned by the
government. Overregulation holds back technical modernization and
foreign investment. Even so, the economy grew rapidly during the late
1970s and early 1980s, but in 1986 the collapse of world oil prices
and an increasingly heavy burden of debt servicing led Egypt to begin
negotiations with the IMF for balance-of-payments support. As part of
the 1987 agreement with the IMF, the government agreed to institute
a reform program to reduce inflation, promote economic growth, and
improve its external position. The reforms have been slow in coming,
however, and the economy has been largely stagnant for the past
three years. The addition of 1 million people every seven months
to Egypt''s population exerts enormous pressure on the 5% of the total
land area available for agriculture.
_#_GDP: $37.0 billion, per capita $700; real growth rate 1.0% (1990
est.)
_#_Inflation rate (consumer prices): 26% (FY90)
_#_Unemployment rate: 15% (1989 est.)
_#_Budget: revenues $7 billion; expenditures $11.5 billion,
including capital expenditures of $4 billion (FY89 est.)
_#_Exports: $3.8 billion (f.o.b., 1990);
commodities--crude and refined petroleum, cotton yarn, raw cotton,
textiles, metal products, chemicals;
partners--EC, Eastern Europe, US, Japan
_#_Imports: $11.4 billion (f.o.b., 1989);
commodities--machinery and equipment, foods, fertilizers, wood
products, durable consumer goods, capital goods;
partners--EC, US, Japan, Eastern Europe
_#_External debt: $52 billion (December 1990 est.)
_#_Industrial production: growth rate 2-4% (1989 est.); accounts
for 24% of GDP
_#_Electricity: 11,273,000 kW capacity; 42,500 million kWh produced,
780 kWh per capita (1989)
_#_Industries: textiles, food processing, tourism, chemicals,
petroleum, construction, cement, metals
_#_Agriculture: accounts for 20% of GNP and employs more than
one-third of labor force; dependent on irrigation water from the Nile;
world''s sixth-largest cotton exporter; other crops produced include rice,
corn, wheat, beans, fruit, vegetables; not self-sufficient in food;
livestock--cattle, water buffalo, sheep, and goats; annual fish catch
about 140,000 metric tons
_#_Economic aid: US commitments, including Ex-Im (FY70-89), $15.7
billion; Western (non-US) countries, ODA and OOF bilateral commitments
(1970-88), $9.3 billion; OPEC bilateral aid (1979-89), $2.9 billion;
Communist countries (1970-89), $2.4 billion
_#_Currency: Egyptian pound (plural--pounds); 1 Egyptian pound
(5E) = 100 piasters
_#_Exchange rates: Egyptian pounds (5E) per US$1--2.9030 (January
1991), 2.7072 (1990), 2.5171 (1989), 2.2233 (1988), 1.5183 (1987), 1.3503
(1986), 1.3010 (1985)
_#_Fiscal year: 1 July-30 June
_#_Overview: The agricultural sector accounts for 25% of GDP, employs
about 40% of the labor force, and contributes about 66% to total exports.
Coffee is the major commercial crop, accounting for 45% of export
earnings. The manufacturing sector, based largely on food and beverage
processing, accounts for 18% of GDP and 15% of employment. Economic
losses because of guerrilla sabotage total more than $2.0 billion
since 1979. The costs of maintaining a large military seriously
constrain the government''s efforts to provide essential social services.
Nevertheless, growth in national output last year exceeded growth in
population for the first time since 1987.
_#_GDP: $5.4 billion, per capita $1,030; real growth rate 2.8%
(1990 est.)
_#_Inflation rate (consumer prices): 20% (1990)
_#_Unemployment rate: 10% (1989)
_#_Budget: revenues $751 million; expenditures $790 million, including
capital expenditures of $NA (1990 est.)
_#_Exports: $571 million (f.o.b., 1990 est.);
commodities--coffee 45%, sugar, cotton, shrimp;
partners--US 49%, FRG 24%, Guatemala 7%, Costa Rica 4%, Japan 4%
_#_Imports: $1.2 billion (c.i.f., 1990 est.);
commodities--petroleum products, consumer goods, foodstuffs,
machinery, construction materials, fertilizer;
partners--US 40%, Guatemala 12%, Venezuela 7%, Mexico 7%, FRG 5%,
Japan 4%
_#_External debt: $2.1 billion (December 1990 est.)
_#_Industrial production: growth rate 2.4% (1990); accounts for
22% of GDP
_#_Electricity: 682,000 kW capacity; 1,849 million kWh produced,
350 kWh per capita (1990)
_#_Industries: food processing, textiles, clothing, beverages,
petroleum, tobacco products, chemicals, furniture
_#_Agriculture: accounts for 25% of GDP and 40% of labor force
(including fishing and forestry); coffee most important commercial crop;
other products--sugarcane, corn, rice, beans, oilseeds, beef, dairy
products, shrimp; not self-sufficient in food
_#_Economic aid: US commitments, including Ex-Im (FY70-90), $2.95
billion; Western (non-US) countries, ODA and OOF bilateral commitments
(1970-88), $455 million
_#_Currency: Salvadoran colon (plural--colones); 1 Salvadoran
colon (C) = 100 centavos
_#_Exchange rates: Salvadoran colones (C) per US$1--8.0 (April
1991, floating rate since mid-1990); 5.0000 (fixed rate 1986 to mid-1990)
_#_Fiscal year: calendar year
_#_Overview: The economy, destroyed during the regime of former
President Macias Nguema, is now based on agriculture, forestry,
and fishing, which account for about 60% of GNP and nearly all exports.
Subsistence agriculture predominates, with cocoa, coffee, and wood
products providing income, foreign exchange, and government
revenues. There is little industry. Commerce accounts
for about 10% of GNP, and the construction, public works, and service
sectors for about 34%. Undeveloped natural resources include titanium,
iron ore, manganese, uranium, and alluvial gold. Oil exploration,
taking place under concessions offered to US, French, and Spanish firms,
has been moderately successful, and some revenues from oil exports
will begin rolling in by mid-1991.
_#_GDP: $144 million, per capita $411; real growth rate 2.9% (1988
est.)
_#_Inflation rate (consumer prices): 5.9% (1989 est.)
_#_Unemployment rate: NA%
_#_Budget: revenues $23 million; expenditures $31 million, including
capital expenditures of NA (1988)
_#_Exports: $41 million (f.o.b., 1989 est.);
commodities--coffee, timber, cocoa beans;
partners--Spain 44%, FRG 19%, Italy 12%, Netherlands 11% (1987)
_#_Imports: $57.1 million (c.i.f., 1988);
commodities--petroleum, food, beverages, clothing, machinery;
partners--Spain 34%, Italy 16%, France 14%, Netherlands 8% (1987)
_#_External debt: $195 million (1989)
_#_Industrial production: growth rate - 6.8% (1990 est.); acounts
for about 4% of GDP
_#_Electricity: 23,000 kW capacity; 60 million kWh produced,
170 kWh per capita (1989)
_#_Industries: fishing, sawmilling
_#_Agriculture: cash crops--timber and coffee from Rio Muni, cocoa
from Bioko; food crops--rice, yams, cassava, bananas, oil palm nuts,
manioc, livestock
_#_Economic aid: US commitments, including Ex-Im (FY81-89), $14
million; Western (non-US) countries, ODA and OOF bilateral commitments
(1970-88), $112 million; Communist countries (1970-89), $55 million
_#_Currency: Communaute Financiere Africaine franc
(plural--francs); 1 CFA franc (CFAF) = 100 centimes
_#_Exchange rates: Communaute Financiere Africaine francs (CFAF)
per US$1--256.54 (January 1991), 272.26 (1990), 319.01 (1989), 297.85
(1988), 300.54 (1987), 346.30 (1986), 449.26 (1985)
_#_Fiscal year: 1 April-31 March
_#_Overview: Ethiopia is one of the poorest and least developed
countries in Africa. Its economy is based on subsistence agriculture,
which accounts for about 45% of GDP, 90% of exports, and 80% of total
employment; coffee generates 60% of export earnings. The
manufacturing sector is heavily dependent on inputs from the agricultural
sector. Over 90% of large-scale industry, but less then 10% of
agriculture, is state run. Favorable agricultural weather largely
explains the 4.5% growth in output in FY89.
_#_GDP: $6.6 billion, per capita $130, real growth rate - 0.4%
(FY89 est.)
_#_Inflation rate (consumer prices): 5.2% (1989)
_#_Unemployment rate: NA
_#_Budget: revenues $1.8 billion; expenditures $1.7 billion, including
capital expenditures of $842 million (FY88)
_#_Exports: $429 million (f.o.b., FY88);
commodities--coffee 60%, hides;
partners--US, FRG, Djibouti, Japan, PDRY, France, Italy,','8dc9b8dd5b891152f63f962f76fc7bfc50ed6a478cbdc337579fa9870d6a7eca','internet-archive','theciaworldfactb00025gut','txt','84185fe9df79da427349cc1598fd3f69814a2085a9fc1fe0508a3fae0a870f84','https://archive.org/download/theciaworldfactb00025gut/25.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('496b212d93ca0fa4aff2d09b176374060b55540c3cac3d87c60bd9a80895e75b',1991,'SA','Saudi Arabia','economy',59,'_#_Imports: $1.1 billion (c.i.f., FY88);
commodities--food, fuels, capital goods;
partners--USSR, Italy, FRG, Japan, UK, US, France
_#_External debt: $2.6 billion (1988)
_#_Industrial production: growth rate 2.3% (FY89 est.); accounts
for 13% of GDP
_#_Electricity: 330,000 kW capacity; 700 million kWh produced,
14 kWh per capita (1989)
_#_Industries: food processing, beverages, textiles, chemicals,
metals processing, cement
_#_Agriculture: accounts for 45% of GDP and is the most important
sector of the economy even though frequent droughts and poor cultivation
practices keep farm output low; famines not uncommon; export crops of
coffee and oilseeds grown partly on state farms; estimated 50% of
agricultural production at subsistence level; principal crops and
livestock--cereals, pulses, coffee, oilseeds, sugarcane, potatoes and
other vegetables, hides and skins, cattle, sheep, goats
_#_Economic aid: US commitments, including Ex-Im (FY70-89), $504
million; Western (non-US) countries, ODA and OOF bilateral commitments
(1970-88), $3.1 billion; OPEC bilateral aid (1979-89), $8 million;
Communist countries (1970-89), $2.0 billion
_#_Currency: birr (plural--birr); 1 birr (Br) = 100 cents
_#_Exchange rates: birr (Br) per US$1--2.0700 (fixed rate)
_#_Fiscal year: 8 July-7 July
_#_Overview: no economic activity
_#_Overview: The economy is based on sheep farming, which directly or
indirectly employs most of the work force. A few dairy herds are kept to
meet domestic consumption of milk and milk products, and crops grown are
primarily those for providing winter fodder. Exports feature shipments
of high-grade wool to the UK and the sale of postage stamps and coins.
Rich stocks of fish in the surrounding waters are not presently exploited
by the islanders. So far efforts to establish a domestic fishing industry
have been unsuccessful. In 1987 the government began selling
fishing licenses to foreign trawlers operating within the Falklands
exclusive fishing zone. These license fees amount to more than $40
million per year and are a primary source of income for the
government. To encourage tourism, the Falkland Islands Development
Corporation has built three lodges for visitors attracted by the
abundant wildlife and trout fishing.
_#_GDP: $NA, per capita $NA; real growth rate NA%
_#_Inflation rate (consumer prices): 7.4% (1980-87 average)
_#_Unemployment rate: NA%; labor shortage
_#_Budget: revenues $62.7 million; expenditures $41.8 million,
excluding capital expenditures of $NA (FY90)
_#_Exports: at least $14.7 million;
commodities--wool, hides and skins, and other;
partners--UK, Netherlands, Japan (1987 est.)
_#_Imports: at least $13.9 million;
commodities--food, clothing, fuels, and machinery;
partners--UK, Netherlands Antilles (Curacao), Japan (1987 est.)
_#_External debt: $NA
_#_Industrial production: growth rate NA%
_#_Electricity: 9,200 kW capacity; 17 million kWh produced, 8,680 kWh
per capita (1990)
_#_Industries: wool and fish processing
_#_Agriculture: predominantly sheep farming; small dairy herds;
some fodder and vegetable crops
_#_Economic aid: Western (non-US) countries, ODA and OOF bilateral
commitments (1970-88), $109 million
_#_Currency: Falkland pound (plural--pounds); 1 Falkland pound
(5F) = 100 pence
_#_Exchange rates: Falkland pound (5F) per US$1--0.5171 (January
1991), 0.5603 (1990), 0.6099 (1989), 0.5614 (1988), 0.6102 (1987), 0.6817
(1986), 0.7714 (1985); note--the Falkland pound is at par with the
British pound
_#_Fiscal year: 1 April-31 March
_#_Overview: The Faroese, who have long been enjoying the affluent
living standards of the Danes and other Scandinavians,
now must cope with the decline of the all-important fishing
industry and with an external debt twice the size of annual
income. When the nations of the world extended their fishing
zones to 200 nautical miles in the early 1970s, the Faroese
no longer could continue their traditional long-distance fishing
and subsequently depleted their own nearby fishing areas; one
estimate foresaw a 25% drop in fish catch in 1990 alone. Half the
fishing fleet is for sale, and the 22 fish-processing plants work
at only half capacity. The government no longer can maintain its
high level of spending on roads and tunnels, hospitals, sports
facilities, and other social welfare programs.
_#_GDP: $662 million, per capita $14,000; real growth rate 3%
(1989 est.)
_#_Inflation rate (consumer prices): 2.0% (1988)
_#_Unemployment rate: NA%, but increasing
_#_Budget: revenues $442 million; expenditures $442 million, including
capital expenditures of NA (1989)
_#_Exports: $343 million (f.o.b., 1989 est.);
commodities--fish and fish products 88%, animal feedstuffs,
transport equipment;
partners--Denmark 16%, UK 14%, FRG 13.4%, US 10%, France 9%,
Japan 5%
_#_Imports: $344 million (c.i.f., 1989 est.);
commodities--machinery and transport equipment 30%,
manufactures 16%, food and livestock 15%, chemicals 6%, fuels 4%;
partners: Denmark 44%, Norway 16%, FRG 6%, Sweden 6%, US 3%
_#_External debt: $1.3 billion (1989)
_#_Industrial production: growth rate NA%
_#_Electricity: 80,000 kW capacity; 280 million kWh produced,
5,910 kWh per capita (1989)
_#_Industries: fishing, shipbuilding, handicrafts
_#_Agriculture: accounts for 27% of GDP and employs 27% of labor
force; principal crops--potatoes and vegetables; livestock--sheep; annual
fish catch about 360,000 metric tons
_#_Economic aid: none
_#_Currency: Danish krone (plural--kroner); 1 Danish krone
(DKr) = 100 ore
_#_Exchange rates: Danish kroner (DKr) per US$1--5.817 (January
1991), 6.189 (1990), 7.310 (1989), 6.732 (1988), 6.840 (1987), 8.091
(1986), 10.596 (1985)
_#_Fiscal year: 1 April-31 March
_#_Overview: Fiji''s economy is primarily agricultural, with a large
subsistence sector. Sugar exports are a major source of foreign exchange
and sugar processing accounts for one-third of industrial output.
Industry, including sugar milling, contributes 13% to GDP. Fiji
traditionally had earned considerable sums of hard currency from the
250,000 tourists who visited each year. In 1987, however, after two
military coups, the economy went into decline. GDP dropped by 7.8% in
1987 and by another 2.5% in 1988; political uncertainty created a drop in
tourism, and the worst drought of the century caused sugar production
to fall sharply. In contrast, sugar and tourism turned in strong
performances in 1989, and the economy rebounded vigorously. In 1990
the economy received a setback from cyclone Sina which cut sugar
output by an estimated 21%.
_#_GDP: $1.3 billion, per capita $1,693; real growth rate 3.5%
(1991 est.)
_#_Inflation rate (consumer prices): 8.5% (1991 est.)
_#_Unemployment rate: 5.9 (1991 est.)
_#_Budget: revenues $314 million; expenditures $355 million,
including capital expenditures of $81 million (1990 est.)
_#_Exports: $646 million (f.o.b., 1991 est.);
commodities--sugar 40%, gold, clothing, copra, processed fish,
lumber;
partners--EC 31%, Australia 21%, Japan 8%, US 6%
_#_Imports: $840 million (c.i.f., 1991 est.);
commodities--machinery and transport 32%, food 15%, petroleum
products, consumer goods, chemicals;
partners--Australia 30%, NZ 17%, Japan 13%, EC 6%, US 6%
_#_External debt: $428 million (December 1990 est.)
_#_Industrial production: growth rate 8.4% (1991 est.); accounts
for 13% of GDP
_#_Electricity: 215,000 kW capacity; 330 million kWh produced, 430
kWh per capita (1990)
_#_Industries: sugar, tourism, copra, gold, silver, fishing, clothing,
lumber, small cottage industries
_#_Agriculture: accounts for 23% of GDP; principal cash crop is
sugarcane; coconuts, cassava, rice, sweet potatoes, and bananas; small
livestock sector includes cattle, pigs, horses, and goats
_#_Economic aid: Western (non-US) countries, ODA and OOF bilateral
commitments (1980-87), $732 million
_#_Currency: Fijian dollar (plural--dollars); 1 Fijian dollar
(F$) = 100 cents
_#_Exchange rates: Fijian dollars (F$) per US$1--1.4476 (January
1991), 1.4809 (1990), 1.4833 (1989), 1.4303 (1988), 1.2439 (1987), 1.1329
(1986), 1.1536 (1985)
_#_Fiscal year: calendar year
_#_Overview: Finland has a highly industrialized, largely free market
economy, with per capita output nearly three-fourths the US figure.
Its main economic force is the manufacturing sector--principally
the wood, metals, and engineering industries. Trade is important, with
the export of goods representing about 30% of GDP. Except for timber and
several minerals, Finland depends on imported raw materials, energy, and
some components of manufactured goods. Because of the climate,
agricultural development is limited to maintaining self-sufficiency in
basic commodities. The economy, which experienced an average of 4.9%
annual growth between 1987 and 1989, leveled off in 1990 and is now
in a recession facing negative growth in 1991. The clearing account
system between Finland and the Soviet Union in the postwar period--mainly
Soviet oil and gas for Finnish manufactured goods--had kept Finland
isolated from world recessions; the system, however, was dismantled on
1 January 1991 in favor of hard currency trade. As a result, Finland must
increase its competitiveness in certain sectors, for example, textiles,
foodstuffs, paper, and metals, and has already begun to shift trade
westward. Finland, as a member of EFTA, is negotiating a European
Economic Area arrangement with the EC which would allow for free
movement of capital, goods, services, and labor within the organization.
_#_GDP: $77.3 billion, per capita $15,500; real growth rate - 0.1%
(1990)
_#_Inflation rate (consumer prices): 5.0% (1991 est.)
_#_Unemployment rate: 5.7% (1991 est.)
_#_Budget: revenues $35.1 billion; expenditures $33.1 billion,
including capital expenditures of $1.4 billion (1990)
_#_Exports: $23.3 billion (f.o.b., 1989);
commodities--timber, paper and pulp, ships, machinery, clothing and
footwear;
partners--EC 44.0% (UK 12.0%, FRG 10.8%), USSR 14.5%, Sweden 14.3%,
US 6.4%
_#_Imports: $24.4 billion (c.i.f., 1989);
commodities--foodstuffs, petroleum and petroleum products,
chemicals, transport equipment, iron and steel, machinery, textile yarn
and fabrics, fodder grains;
partners--EC 44.5% (FRG 17.3%, UK 6.6%), Sweden 13.6%, USSR 11.5%,
US 6.3%
_#_External debt: $5.3 billion (1989)
_#_Industrial production: growth rate - 3.0% (1991 est.); accounts
for 28% of GDP
_#_Electricity: 13,324,000 kW capacity; 49,330 million kWh produced,
9,940 kWh per capita (1989)
_#_Industries: metal manufacturing and shipbuilding, forestry and wood
processing (pulp, paper), copper refining, foodstuffs, chemicals,
textiles, clothing
_#_Agriculture: accounts for 8% of GNP (including forestry); livestock
production, especially dairy cattle, predominates; forestry is an
important export earner and a secondary occupation for the rural
population; main crops--cereals, sugar beets, potatoes; 85%
self-sufficient, but short of food and fodder grains; annual fish catch
about 160,000 metric tons
_#_Economic aid: donor--ODA and OOF commitments (1970-89), $2.7
billion
_#_Currency: markka (plural--markkaa); 1 markka (FMk) or
Finmark = 100 pennia
_#_Exchange rates: markkaa (FMk) per US$1--3.6421 (January 1991),
3.8235 (1990), 4.2912 (1989), 4.1828 (1988), 4.3956 (1987), 5.0695
(1986), 6.1979 (1985)
_#_Fiscal year: calendar year
_#_Overview: One of the world''s most developed economies, France
has substantial agricultural resources and a highly diversified modern
industrial sector. Large tracts of fertile land, the application of
modern technology, and subsidies have combined to make it the leading
agricultural producer in Western Europe. France is largely
self-sufficient in agricultural products and is a major exporter of
wheat and dairy products. The industrial sector generates about
one-quarter of GDP, and the growing services sector has become crucial
to the economy. After sluggish growth during the period 1982-87, the
economy expanded at a rapid 3.8% pace in 1988-89. The economy
slowed down in 1990, with growth of 2.0% expected in 1991.
The economy has had difficulty generating enough jobs for new
entrants into the labor force, resulting in a high unemployment rate,
which probably will rise to around 10% during the slowdown.
The steadily advancing economic integration within the European
Community is a major force affecting the fortunes of the various economic
sectors.
_#_GDP: $873.5 billion, per capita $15,500; real growth rate 2.8%
(1990)
_#_Inflation rate (consumer prices): 3.7% (1990 est.)
_#_Unemployment rate: 9% (1990)
_#_Budget: revenues $207.6 billion; expenditures $224.2 billion,
including capital expenditures of $34 billion (1990 est.)
_#_Exports: $181.2 billion (f.o.b., 1990);
commodities--machinery and transportation equipment, chemicals,
foodstuffs, agricultural products, iron and steel products, textiles and
clothing;
partners--FRG 16%, Italy 12.1%, UK 9.5%, Spain 9.5%,
Netherlands 9.2%, Belgium-Luxembourg 8.9%, US 6.6%, Japan 1.9%,
USSR 1.0% (1989 est.)
_#_Imports: $201.6 billion (c.i.f., 1989);
commodities--crude oil, machinery and equipment, agricultural
products, chemicals, iron and steel products;
partners--FRG 19.4%, Italy 11.6%, Belgium-Luxembourg 9.2%,
Netherlands 8.6%, US 7.6%, Spain 7.4%, UK 7.1%, Japan 4.1%,
USSR 1.4% (1989 est.)
_#_External debt: $59.3 billion (December 1987)
_#_Industrial production: growth rate 3.7% (1989); accounts
for 26% of GDP
_#_Electricity: 109,972,000 kW capacity; 403,570 million kWh produced,
7,210 kWh per capita (1989)
_#_Industries: steel, machinery, chemicals, automobiles, metallurgy,
aircraft, electronics, mining, textiles, food processing, and tourism
_#_Agriculture: accounts for 4% of GNP (including fishing and
forestry); one of the world''s top five wheat producers; other principal
products--beef, dairy products, cereals, sugar beets, potatoes, wine
grapes; self-sufficient for most temperate-zone foods; shortages include
fats and oils and tropical produce, but overall net exporter of farm
products; fish catch of 850,000 metric tons ranks among world''s top
20 countries and is all used domestically
_#_Economic aid: donor--ODA and OOF commitments (1970-89), $75.1
billion
_#_Currency: French franc (plural--francs); 1 French franc (F) = 100
centimes
_#_Exchange rates: French francs (F) per US$1--5.8 (May 1991),
5.4453 (1990), 6.3801 (1989), 5.9569 (1988), 6.0107 (1987), 6.9261
(1986), 8.9852 (1985)
_#_Fiscal year: calendar year
_#_Overview: The petroleum sector accounts for roughly 70% of
budget revenues, 33% of GDP, and almost all export earnings. Saudi Arabia
has the largest reserves of petroleum in the world, ranks as the largest
exporter of petroleum, plays a leading role in OPEC, and invests
substantial amounts abroad.
_#_GDP: $79 billion, per capita $4,800; real growth rate 0.5%
(1989 est.)
_#_Inflation rate (consumer prices): 0% (1990 est.)
_#_Unemployment rate: 0% (1989 est.)
_#_Budget: revenues $31.5 billion; expenditures $38.2 billion,
including capital expenditures of $6.9 billion (1990)
_#_Exports: $28.3 billion (f.o.b., 1989 est.);
commodities--petroleum and petroleum products 85%;
partners--US 22%, Japan 20%, Singapore 7%, France 5%
_#_Imports: $19.2 billion (f.o.b., 1989 est.);
commodities--manufactured goods, transportation equipment,
construction materials, processed food products;
partners--UK 17%, US 15%, Japan 12%, FRG 6%
_#_External debt: $18.9 billion (December 1989 est.)
_#_Industrial production: growth rate - 1.1% (1989 est.); accounts for
37% of GDP, including petroleum
_#_Electricity: 25,205,000 kW capacity; 50,500 million kWh produced,
2,950 kWh per capita (1990)
_#_Industries: crude oil production, petroleum refining, basic
petrochemicals, cement, small steel-rolling mill, construction,
fertilizer, plastic
_#_Agriculture: accounts for about 10% of GDP, 16% of labor force;
fastest growing economic sector; subsidized by government;
products--wheat, barley, tomatoes, melons, dates, citrus fruit, mutton,
chickens, eggs, milk; approaching self-sufficiency in food
_#_Economic aid: donor--pledged $64.7 billion in bilateral aid
(1979-89)
_#_Currency: Saudi riyal (plural--riyals); 1 Saudi riyal (SR) = 100
halalas
_#_Exchange rates: Saudi riyals (SR) per US$1--3.7450 (fixed rate
since late 1986), 3.7033 (1986), 3.6221 (1985)
_#_Fiscal year: calendar year
_#_Overview: The agricultural sector accounts for about 20% of GDP and
provides employment for about 75% of the labor force. About 40% of the
total cultivated land is used to grow peanuts, an important export crop.
The principal economic resource is fishing, which brought in about $200
million or about 25% of total foreign exchange earnings in 1987. Mining
is dominated by the extraction of phosphate, but production has faltered
because of reduced worldwide demand for fertilizers in recent years. Over
the past 10 years tourism has become increasingly important to the
_#_GDP: $4.6 billion, per capita $615; real growth rate 0.6% (1989)
_#_Inflation rate (consumer prices): 0.4% (1989 est.)
_#_Unemployment rate: 3.5% (1987)
_#_Budget: revenues $921 million; expenditures $1,024 million;
including capital expenditures of $14 million (FY89 est.)
_#_Exports: $801 million (f.o.b., 1989 est.);
commodities--manufactures 30%, fish products 27%, peanuts 11%,
petroleum products 11%, phosphates 10%;
partners--US, France, other EC, Ivory Coast, India
_#_Imports: $1.0 billion (c.i.f., 1989 est.);
commodities--semimanufactures 30%, food 27%, durable consumer
goods 17%, petroleum 12%, capital goods 14%;
partners--US, France, other EC, Nigeria, Algeria, China, Japan
_#_External debt: $4.1 billion (1989)
_#_Industrial production: growth rate 4.7% (1989); accounts for
17% of GDP
_#_Electricity: 210,000 kW capacity; 760 million kWh produced,
100 kWh per capita (1989)
_#_Industries: fishing, agricultural processing, phosphate mining,
petroleum refining, building materials
_#_Agriculture: including fishing, accounts for 20% of GDP and more
than 75% of labor force; major products--peanuts (cash crop), millet,
corn, sorghum, rice, cotton, tomatoes, green vegetables; estimated
two-thirds self-sufficient in food; fish catch of 299,000 metric tons
in 1987
_#_Economic aid: US commitments, including Ex-Im (FY70-89), $551
million; Western (non-US) countries, ODA and OOF bilateral commitments
(1970-88), $4.8 billion; OPEC bilateral aid (1979-89), $589 million;
Communist countries (1970-89), $295 million
_#_Currency: Communaute Financiere Africaine franc
(plural--francs); 1 CFA franc (CFAF) = 100 centimes
_#_Exchange rates: Communaute Financiere Africaine francs (CFAF)
per US$1--256.54 (January 1991), 272.26 (1990), 319.01 (1989), 297.85
(1988), 300.54 (1987), 346.30 (1986), 449.26 (1985)
_#_Fiscal year: 1 July-30 June
_#_Overview: In this small, open, tropical island economy, the tourist
industry employs about 30% of the labor force and provides the main
source of hard currency earnings. In recent years the government has
encouraged foreign investment in order to upgrade hotels and other
services. At the same time, the government has moved to reduce the high
dependence on tourism by promoting the development of farming, fishing,
and small-scale manufacturing.
_#_GDP: $283 million, per capita $4,100; real growth rate 7.0% (1989)
_#_Inflation rate (consumer prices): 1.5% (1989)
_#_Unemployment rate: 9% (1987)
_#_Budget: revenues $170 million; expenditures $173 million, including
capital expenditures of $NA (1989)
_#_Exports: $31 million (f.o.b., 1989 est.);
commodities--fish, copra, cinnamon bark, petroleum products
(reexports);
partners--France 63%, Pakistan 12%, Reunion 10%, UK 7% (1987)
_#_Imports: $164 million (f.o.b., 1989 est.);
commodities--manufactured goods, food, tobacco, beverages,
machinery and transportation equipment, petroleum products;
partners--UK 20%, France 14%, South Africa 13%, PDRY 13%,
Singapore 8%, Japan 6% (1987)
_#_External debt: $171 million (1990 est.)
_#_Industrial production: growth rate 7% (1987); accounts for
10% of GDP
_#_Electricity: 25,000 kW capacity; 67 million kWh produced,
960 kWh per capita (1989)
_#_Industries: tourism, processing of coconut and vanilla, fishing,
coir rope factory, boat building, printing, furniture, beverage
_#_Agriculture: accounts for 7% of GDP, mostly subsistence farming;
cash crops--coconuts, cinnamon, vanilla; other products--sweet potatoes,
cassava, bananas; broiler chickens; large share of food needs imported;
expansion of tuna fishing under way
_#_Economic aid: US commitments, including Ex-Im (FY78-89), $26
million; Western (non-US) countries, ODA and OOF bilateral commitments
(1978-88), $310 million; OPEC bilateral aid (1979-89), $5 million;
Communist countries (1970-89), $60 million
_#_Currency: Seychelles rupee (plural--rupees);
1 Seychelles rupee (SRe) = 100 cents
_#_Exchange rates: Seychelles rupees (SR) per US$1--5.0878 (January
1991), 5.3369 (1990), 5.6457 (1989), 5.3836 (1988), 5.6000 (1987), 6.1768
(1986), 7.1343 (1985)
_#_Fiscal year: calendar year
_#_Overview: The economic and social infrastructure is not well
developed. Subsistence agriculture dominates the economy, generating
about one-third of GDP and employing about two-thirds of the working
population. Manufacturing accounts for less than 10% of GDP, consisting
mainly of the processing of raw materials and of light manufacturing for
the domestic market. Diamond mining provides an important source of hard
currency. The economy suffers from high unemployment, rising inflation,
large trade deficits, and a growing dependency on foreign assistance.
The government in 1990 was attempting to get the budget deficit under
control and, in general, to bring economic policy in line with the
recommendations of the IMF and the World Bank.
_#_GDP: $1,302 million, per capita $325; real growth rate 1.8% (FY89)
_#_Inflation rate (consumer prices): over 100% (1990)
_#_Unemployment rate: NA%
_#_Budget: revenues $134 million; expenditures $187 million,
including capital expenditures of $32 million (FY91 est.)
_#_Exports: $138 million (f.o.b., 1989);
commodities--rutile 50%, bauxite 17%, cocoa 11%, diamonds 3%,
coffee 3%;
partners--US, UK, Belgium, FRG, other Western Europe
_#_Imports: $183 million (c.i.f., 1989);
commodities--capital goods 40%, food 32%, petroleum 12%,
consumer goods 7%, light industrial goods;
partners--US, EC, Japan, China, Nigeria
_#_External debt: $632 million (1990 est.)
_#_Industrial production: growth rate - 19% (FY88 est.); accounts
for 8% of GDP
_#_Electricity: 83,000 kW capacity; 180 million kWh produced,
45 kWh per capita (1989)
_#_Industries: mining (diamonds, bauxite, rutile), small-scale
manufacturing (beverages, textiles, cigarettes, footwear), petroleum
refinery
_#_Agriculture: accounts for over 30% of GDP and two-thirds of the
labor force; largely subsistence farming; cash crops--coffee, cocoa, palm
kernels; harvests of food staple rice meets 80% of domestic needs;
annual fish catch averages 53,000 metric tons
_#_Economic aid: US commitments, including Ex-Im (FY70-89), $161
million; Western (non-US) countries, ODA and OOF bilateral commitments
(1970-87), $698 million; OPEC bilateral aid (1979-89), $18 million;
Communist countries (1970-89), $101 million
_#_Currency: leone (plural--leones); 1 leone (Le) = 100 cents
_#_Exchange rates: leones per US$1--196.0784 (January 1991),
144.9275 (1990), 58.1395 (1989), 31.2500 (1988), 30.7692 (1987),
8.3963 (1986), 4.7304 (1985)
_#_Fiscal year: 1 July-30 June
_#_Overview: Singapore has an open entrepreneurial economy with strong
service and manufacturing sectors and excellent international trading
links derived from its entrepot history. During the 1970s and early
1980s, the economy expanded rapidly, achieving an average annual growth
rate of 9%. Per capita GDP is among the highest in Asia. In 1985 the
economy registered its first drop in 20 years and achieved less than a 2%
increase in 1986. Recovery was strong based on rising demand for
Singapore''s products in OECD countries and improved competitiveness of
domestic m','92817954f8b60ab9afa4cccb0128862f6b632bc93d5b0a50dfa49a60c28d9f6c','internet-archive','theciaworldfactb00025gut','txt','84185fe9df79da427349cc1598fd3f69814a2085a9fc1fe0508a3fae0a870f84','https://archive.org/download/theciaworldfactb00025gut/25.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('20681a6ebe1c8604d7dadbbc304ebc7e2ac9b2c8c4acc0c819c4cbbdc99d9971',1991,'SA','Saudi Arabia','economy',60,'anufactures. The economy grew 8.3% in 1990. Singapore''s
position as a major oil refining and services center helped it weather
the Persian Gulf crisis.
_#_GDP: $34.6 billion, per capita $12,700; real growth rate 8.3%
(1990)
_#_Inflation rate (consumer prices): 3.4% (1990)
_#_Unemployment rate: 1.7% (1990)
_#_Budget: revenues $8.0 billion; expenditures $7.2 billion,
including capital expenditures of $2.4 billion (FY90 est.)
_#_Exports: $52.5 billion (f.o.b., 1990);
commodities--includes transshipments to Malaysia--petroleum
products, rubber, electronics, manufactured goods;
partners--US 21%, EC 14%, Malaysia 13%, Japan 9%
_#_Imports: $60.6 billion (c.i.f., 1990);
commodities--includes transshipments from Malaysia--capital
equipment, petroleum, chemicals, manufactured goods, foodstuffs;
partners--Japan 20%, US 16%, Malaysia 14%, EC 13%
_#_External debt: $3.9 billion (1990)
_#_Industrial production: growth rate 9% (1990 est.); accounts
for 29% of GDP (1989)
_#_Electricity: 4,000,000 kW capacity; 14,400 million kWh produced,
5,300 kWh per capita (1990)
_#_Industries: petroleum refining, electronics, oil drilling
equipment, rubber processing and rubber products, processed food and
beverages, ship repair, entrepot trade, financial services,
biotechnology
_#_Agriculture: occupies a position of minor importance in the
economy; self-sufficient in poultry and eggs; must import much of other
food; major crops--rubber, copra, fruit, vegetables
_#_Economic aid: US commitments, including Ex-Im (FY70-83), $590
million; Western (non-US) countries, ODA and OOF bilateral commitments
(1970-87), $882 million
_#_Currency: Singapore dollar (plural--dollars);
1 Singapore dollar (S$) = 100 cents
_#_Exchange rates: Singapore dollars per US$1--1.7454 (January 1991),
1.8125 (1990), 1.9503 (1989), 2.0124 (1988), 2.1060 (1987), 2.1774
(1986), 2.2002 (1985)
_#_Fiscal year: 1 April-31 March
_#_Overview: About 90% of the population depend on subsistence
agriculture, fishing, and forestry for at least part of their livelihood.
Agriculture, fishing, and forestry contribute about 75% to GDP, with the
fishing and forestry sectors being important export earners. The service
sector contributes about 25% to GDP. Most manufactured goods and
petroleum products must be imported. The islands are rich in undeveloped
mineral resources such as lead, zinc, nickel, and gold. The economy
suffered from a severe cyclone in mid-1986 that caused widespread damage
to the infrastructure.
_#_GDP: $156 million, per capita $500 (1988); real growth rate 5.0%
(1989 est.)
_#_Inflation rate (consumer prices): 14.9% (1989)
_#_Unemployment rate: NA%
_#_Budget: revenues $44 million; expenditures $45 million,
including capital expenditures of $22 million (1989 est.)
_#_Exports: $75 million (f.o.b., 1989);
commodities--fish 46%, timber 31%, copra 5%, palm oil 5%;
partners--Japan 51%, UK 12%, Thailand 9%, Netherlands 8%, Australia
2%, US 2% (1985)
_#_Imports: $117 million (f.o.b., 1988);
commodities--plant and machinery 30%, fuel 19%, food 16%;
partners--Japan 36%, US 23%, Singapore 9%, UK 9%, NZ 9%, Australia
4%, Hong Kong 4%, China 3% (1985)
_#_External debt: $128 million (1988 est.)
_#_Industrial production: growth rate 0% (1987); accounts for 5%
of GDP
_#_Electricity: 21,000 kW capacity; 39 million kWh produced,
115 kWh per capita (1990)
_#_Industries: copra, fish (tuna)
_#_Agriculture: including fishing and forestry, accounts for about
75% of GDP; mostly subsistence farming; cash crops--cocoa, beans,
coconuts, palm kernels, timber; other products--rice, potatoes,
vegetables, fruit, cattle, pigs; not self-sufficient in food grains;
90% of the total fish catch of 44,500 metric tons was exported (1988)
_#_Economic aid: Western (non-US) countries, ODA and OOF bilateral
commitments (1985), $16.1 million
_#_Currency: Solomon Islands dollar (plural--dollars);
1 Solomon Islands dollar (SI$) = 100 cents
_#_Exchange rates: Solomon Islands dollars (SI$) per US$1--2.5934
(January 1991), 2.5288 (1990), 2.2932 (1989), 2.0825 (1988), 2.0033
(1987), 1.7415 (1986), 1.4808 (1985)
_#_Fiscal year: calendar year
_#_Overview: One of the world''s poorest and least developed countries,
Somalia has few resources. Agriculture is the most important sector of
the economy, with the livestock sector accounting for about 40% of GDP
and about 65% of export earnings. Nomads and seminomads who are
dependent upon livestock for their livelihoods make up more than half
of the population. Crop production generates only 10% of GDP and employs
about 20% of the work force. The main export crop is bananas; sugar,
sorghum, and corn are grown for the domestic market. The small industrial
sector is based on the processing of agricultural products and accounts
for less than 10% of GDP. Serious economic problems facing the nation are
the external debt of $1.9 billion and double-digit inflation.
_#_GDP: $1.7 billion, per capita $210; real growth rate - 1.4% (1988)
_#_Inflation rate (consumer prices): 81.7% (1988 est.)
_#_Unemployment rate: NA%
_#_Budget: revenues $190 million; expenditures $195 million, including
capital expenditures of $111 million (1989 est.)
_#_Exports: $58.0 million (f.o.b., 1988);
commodities--livestock, hides, skins, bananas, fish;
partners--US 0.5%, Saudi Arabia, Italy, FRG (1986)
_#_Imports: $354.0 million (c.i.f., 1988);
commodities--textiles, petroleum products, foodstuffs, construction
materials;
partners--US 13%, Italy, FRG, Kenya, UK, Saudi Arabia (1986)
_#_External debt: $1.9 billion (1989)
_#_Industrial production: growth rate - 5.0% (1988); accounts for 5%
of GDP
_#_Electricity: 72,000 kW capacity; 60 million kWh produced,
7 kWh per capita (1990)
_#_Industries: a few small industries, including sugar refining,
textiles, petroleum refining
_#_Agriculture: dominant sector, led by livestock raising (cattle,
sheep, goats); crops--bananas, sorghum, corn, mangoes, sugarcane; not
self-sufficient in food; fishing potential largely unexploited
_#_Economic aid: US commitments, including Ex-Im (FY70-89), $639
million; Western (non-US) countries, ODA and OOF bilateral commitments
(1970-87), $3.2 billion; OPEC bilateral aid (1979-89), $1.1 billion;
Communist countries (1970-89), $336 million
_#_Currency: Somali shilling (plural--shillings);
1 Somali shilling (So.Sh.) = 100 centesimi
_#_Exchange rates: Somali shillings (So. Sh.) per US$1--3,800.00
(December 1990), 490.7 (1989), 170.45 (1988), 105.18 (1987), 72.00
(1986), 39.49 (1985)
_#_Fiscal year: calendar year
_#_Overview: Many of the white one-seventh of the South African
population enjoy incomes, material comforts, and health and educational
standards equal to those of Western Europe. In contrast, most of the
remaining population suffers from the poverty patterns of the Third
World, including unemployment, lack of job skills, and barriers to
movement into higher-paying fields. Inputs and outputs thus do not move
smoothly into the most productive employments, and the effectiveness
of the market is further lowered by international constraints on
dealings with South Africa. The main strength of the economy lies in
its rich mineral resources, which provide two-thirds of exports.
Average growth of less than 2% in output in recent years falls far short
of the 5-6% level needed to cut into the high unemployment rate.
_#_GDP: $101.7 billion, per capita $2,600; real growth rate - 0.9%
(1990)
_#_Inflation rate (consumer prices): 14.4% (1990)
_#_Unemployment rate: 22% (1989); blacks 25-30%, up to 50% in
homelands (1988 est.)
_#_Budget: revenues $28.9 billion; expenditures $32.8 billion,
including capital expenditures of $1.1 billion (FY92 est.)
_#_Exports: $23.4 billion (f.o.b., 1990);
commodities--gold 39%, minerals and metals 33%, food 5%,
chemicals 3%;
partners--Italy, Japan, US, FRG, UK, other EC, Hong Kong
_#_Imports: $17 billion (c.i.f., 1990);
commodities--machinery 32%, transport equipment 15%, chemicals 11%,
oil, textiles, scientific instruments, base metals;
partners--FRG, Japan, UK, US, Italy
_#_External debt: $19.5 billion (July 1990)
_#_Industrial production: growth rate NA%; accounts for about
45% of GDP
_#_Electricity: 34,941,000 kW capacity; 158,000 million kWh produced,
4,100 kWh per capita (1989)
_#_Industries: mining (world''s largest producer of platinum, gold,
chromium), automobile assembly, metalworking, machinery, textile, iron
and steel, chemical, fertilizer, foodstuffs
_#_Agriculture: accounts for about 5% of GDP and 30% of labor force;
diversified agriculture, with emphasis on livestock; products--cattle,
poultry, sheep, wool, milk, beef, corn, wheat; sugarcane, fruits,
vegetables; self-sufficient in food
_#_Economic aid: NA
_#_Currency: rand (plural--rand); 1 rand (R) = 100 cents
_#_Exchange rates: rand (R) per US$1--2.5625 (January 1991),
2.5863 (1990), 2.6166 (1989), 2.2611 (1988), 2.0350 (1987), 2.2685
(1986), 2.1911 (1985)
_#_Fiscal year: 1 April-31 March
_#_Overview: Some fishing takes place in adjacent waters. There is
a potential source of income from harvesting fin fish and krill. The
islands receive income from postage stamps produced in the UK.
_#_Budget: revenues $291,777; expenditures $451,011, including
capital expenditures of $NA (FY88 est.)
_#_Electricity: 900 kW capacity; 2 million kWh produced, NA kWh per
capita (1990)
_#_Overview: The first six years of perestroyka (economic and
political restructuring) have undermined the institutions and processes
of the Soviet command economy without replacing them with efficiently
functioning markets. The initial reforms have featured greater authority
for enterprise managers over prices, wages, product mix, investment,
sources of supply, and customers. But in the absence of effective market
discipline, the result has been the disappearance of low-price goods,
excessive wage increases, an even larger volume of unfinished
construction projects, and, in general, continued economic stagnation.
The Gorbachev regime has made at least four serious errors in economic
policy in these six years: the unpopular and short-lived antialcohol
campaign; the initial cutback in imports of consumer goods; the failure
to act decisively at the beginning for the privatization of agriculture;
and the buildup of a massive overhang of unspent rubles in the hands of
households and enterprises. The regime has vacillated among a series of
ambitious economic policy prescriptions put forth by leading economists
and political leaders. The plans vary from proposals for (a) quick
marketization of the economy; (b) gradual marketization; (c) a period
of retrenchment to ensure a stable base for future marketization; and
(d) a return to disciplined central planning and allocation. The
economy, caught between two systems, is suffering from even greater
mismatches between what is being produced and what would serve the best
interests of enterprises and households. Meanwhile, the seething
nationality problems have been dislocating regional patterns of economic
specialization and pose a further major threat to growth prospects over
the next few years. Official Soviet statistics report GNP fell by 2% in
1990, but the actual decline was substantially greater. Whatever the
numerical decline, it does not capture the increasing disjointures in the
economy evidenced by emptier shelves, longer lines, increased barter, and
widespread strikes.
_#_GNP: approximately $2,660 billion, per capita $9,130;
real growth rate - 2.4% to - 5.0% (1990 est. based on a reconstruction
of official Soviet statistics); note--because of the continued
unraveling of Soviet economic and statistical controls, the estimate
is subject to even greater uncertainties than in earlier years; the
dollar estimates most likely overstate Soviet GNP to some extent because
of an incomplete allowance for the poor quality, narrow assortment, and
low performance characteristics of Soviet goods and services; the
- 2.4% growth figure is based on the application of CIA''s usual
estimating methods whereas the - 5.0% figure is corrected for
measurement problems that worsened sharply in 1990
_#_Inflation rate (consumer prices): 14% (1990 est.)
_#_Unemployment rate: official Soviet statistics imply an unemployment
rate of 1 to 2 percent in 1990; USSR''s first official unemployment
estimate, however, is acknowledged to be rough
_#_Budget: revenues 422 billion rubles; expenditures 510 billion
rubles, including capital expenditures of 53 billion rubles (1990 est.)
_#_Exports: $109.3 billion (f.o.b., 1989);
commodities--petroleum and petroleum products, natural gas, metals,
wood, agricultural products, and a wide variety of manufactured goods
(primarily capital goods and arms);
partners--Eastern Europe 46%, EC 16%, Cuba 6%, US, Afghanistan
(1989)
_#_Imports: $114.7 billion (c.i.f., 1989);
commodities--grain and other agricultural products, machinery and
equipment, steel products (including large-diameter pipe), consumer
manufactures;
partners--Eastern Europe 50%, EC 13%, Cuba, China, US (1989)
_#_External debt: $55 billion (1990)
_#_Industrial production: growth rate - 2.4% (1990 est.)
_#_Electricity: 350,000,000 kW capacity; 1,740,000 million kWh
produced, 5,920 kWh per capita (1990)
_#_Industries: diversified, highly developed capital goods and defense
industries; comparatively less developed consumer goods industries
_#_Agriculture: accounts for roughly 20% of GNP and labor force;
production based on large collective and state farms; inefficiently
managed; wide range of temperate crops and livestock produced; world''s
third-largest grain producer after the US and China; shortages of grain,
oilseeds, and meat; world''s leading producer of sawnwood and roundwood;
annual fish catch among the world''s largest
_#_Illicit drugs: illegal producer of cannabis and opium poppy,
mostly for domestic consumption; government has begun eradication
program to control cultivation; used as a transshipment country
for illicit drugs to Western Europe
_#_Economic aid: donor--extended to non-Communist less developed
countries (1954-89), $49.6 billion; extended to other Communist countries
(1954-89), $154 billion
_#_Currency: ruble (plural--rubles); 1 ruble (R) = 100 kopeks
_#_Exchange rates: rubles (R) per US$1--0.580 (1990),
0.629 (1989), 0.629 (1988), 0.633 (1987), 0.704 (1986), 0.838 (1985);
note--as of 1 April 1991 the official exchange rate remained
administratively set; it should not be used indiscriminately to convert
domestic rubles to dollars; in November 1990 the USSR introduced a
commercial exchange rate of 1.8 rubles to the dollar used for accounting
purposes within the USSR and which was still in force on 1 April 1991;
on 1 April 1991 the USSR introduced a new foreign-currency
market for foreign companies and individuals; the rate will be fixed
twice a week based on supply and demand; as of 4 April 1991 the rate
was 27.6 rubles to the dollar; Soviet citizens traveling abroad
are restricted to buying $200 a year at prevailing rates
_#_Fiscal year: calendar year
_#_Overview: This Western capitalistic economy has done well since
Spain joined the EC in 1986. With annual increases in real GNP averaging
about 5% in the 1987-90 period, Spain has been the fastest growing member
of the EC. Increased investment--both domestic and foreign--has been the
most important factor pushing the economic expansion. Inflation moderated
to 4.8% in 1988, but an overheated economy caused inflation to reach
almost 7% in 1989-90. Another economic problem facing Spain is an
unemployment rate of 16.3%, the highest in Europe.
_#_GDP: $435.9 billion, per capita $11,100; real growth rate 3.7%
(1990)
_#_Inflation rate (consumer prices): 6.7% (1990)
_#_Unemployment rate: 16.3% (1990)
_#_Budget: revenues $100.1 billion; expenditures $111.6 billion,
including capital expenditures of $NA (1990)
_#_Exports: $55.6 billion (f.o.b., 1990);
commodities--foodstuffs, live animals, wood, footwear, machinery,
chemicals;
partners--EC 67.8%, US 6.5%, other developed countries 9%
_#_Imports: $87.7 billion (c.i.f., 1990);
commodities--petroleum, footwear, machinery, chemicals, grain,
soybeans, coffee, tobacco, iron and steel, timber, cotton, transport
equipment;
partners--EC 59.7%, US 8.5%, other developed countries 11.5%,
Middle East 3.4%
_#_External debt: $37 billion (1990 est.)
_#_Industrial production: growth rate 3.5% (1990 est.)
_#_Electricity: 46,589,000 kW capacity; 141,000 million kWh produced,
3,590 kWh per capita (1990)
_#_Industries: textiles and apparel (including footwear), food and
beverages, metals and metal manufactures, chemicals, shipbuilding,
automobiles, machine tools
_#_Agriculture: accounts for 5% of GNP and 14% of labor force; major
products--grain, vegetables, olives, wine grapes, sugar beets, citrus
fruit, beef, pork, poultry, dairy; largely self-sufficient in food;
fish catch of 1.4 million metric tons is among top 20 nations
_#_Economic aid: US commitments, including Ex-Im (FY70-87), $1.9
billion; Western (non-US) countries, ODA and OOF bilateral commitments
(1970-79), $545.0 million; not currently a recipient
_#_Currency: peseta (plural--pesetas); 1 peseta (Pta) =
100 centimos
_#_Exchange rates: pesetas (Ptas) per US$1--95.20 (January 1991),
101.93 (1990), 118.38 (1989), 116.49 (1988), 123.48 (1987), 140.05
(1986), 170.04 (1985)
_#_Fiscal year: calendar year
_#_Overview: Economic activity is limited to commercial fishing and
phosphate mining. Geological surveys carried out several years ago
suggest that substantial reserves of oil and natural gas may lie beneath
the islands; commercial exploitation has yet to be developed.
_#_Industries: some guano mining
_#_Overview: Agriculture, forestry, and fishing dominate the economy,
employing about 45% of the labor force and accounting for 26% of
GDP. The plantation crops of tea, rubber, and coconuts provide about 35%
of export earnings. The economy has been plagued by high rates of
unemployment since the late 1970s. Economic growth, which has been
depressed by ethnic unrest, accelerated in 1990 as domestic conditions
began to improve.
_#_GDP: $6.6 billion, per capita $380; real growth rate 4.5% (1990
est.)
_#_Inflation rate (consumer prices): 23% (1990)
_#_Unemployment rate: 20% (1990 est.)
_#_Budget: revenues $1.7 billion; expenditures $2.2 billion,
including capital expenditures of $0.5 billion (1990)
_#_Exports: $1.6 billion (f.o.b., 1989);
commodities--tea, textiles and garments, petroleum products,
coconut, rubber, agricultural products, gems and jewelry, marine
products;
partners--US 26%, FRG, Japan, UK, Belgium, Taiwan, Hong Kong, China
_#_Imports: $2.2 billion (c.i.f., 1989);
commodities--food and beverages, textiles and textile materials,
petroleum, machinery and equipment;
partners--Japan, Saudi Arabia, US 5.6%, India, Singapore, FRG, UK,
Iran
_#_External debt: $5.6 billion (1989)
_#_Industrial production: growth rate 6% (1989 est.); accounts for
18% of GDP
_#_Electricity: 1,300,000 kW capacity; 4,200 million kWh produced,
240 kWh per capita (1990)
_#_Industries: processing of rubber, tea, coconuts, and other
agricultural commodities; cement, petroleum refining, textiles, tobacco,
clothing
_#_Agriculture: accounts for 26% of GDP and nearly half of labor
force; most important staple crop is paddy rice; other field
crops--sugarcane, grains, pulses, oilseeds, roots, spices; cash
crops--tea, rubber, coconuts; animal products--milk, eggs, hides, meat;
not self-sufficient in rice production
_#_Economic aid: US commitments, including Ex-Im (FY70-89), $1.0
billion; Western (non-US) countries, ODA and OOF bilateral commitments
(1980-88), $4.9 billion; OPEC bilateral aid (1979-89), $169 million;
Communist countries (1970-89), $369 million
_#_Currency: Sri Lankan rupee (plural--rupees);
1 Sri Lankan rupee (SLRe) = 100 cents
_#_Exchange rates: Sri Lankan rupees (SLRs) per US$1--40.272 (January
1991), 40.063 (1990), 36.047 (1989), 31.807 (1988), 29.445 (1987), 28.017
(1986), 27.163 (1985)
_#_Fiscal year: calendar year
_#_Overview: Sudan, one of the world''s poorest countries, is buffeted
by civil war, chronic political instability, adverse weather, and
counterproductive economic policies. The economy is dominated
by governmental entities that account for more than 70% of new
investment. The private sector''s main areas of activity are agriculture
and trading, with most private industrial investment predating 1980. The
economy''s base is agriculture, which employs 80% of the work force.
Industry mainly processes agricultural items. Sluggish economic
performance over the past decade, attributable largely to declining
annual rainfall, has reduced levels of per capita income and
consumption. A high foreign debt and huge arrearages continue to cause
difficulties. In 1990 the International Monetary Fund took the unusual
step of declaring Sudan noncooperative on account of its nonpayment of
arrearages to the Fund.
_#_GDP: $8.5 billion, per capita $330; real growth rate - 7%
(FY90 est.)
_#_Inflation rate (consumer prices): 60% (FY90 est.)
_#_Unemployment rate: NA
_#_Budget: revenues $514 million; expenditures $1.3 billion,
including capital expenditures of $183 million (FY89 est.)
_#_Exports: $465 million (f.o.b., FY90 est.);
commodities--cotton 52%, sesame, gum arabic, peanuts;
partners--Western Europe 46%, Saudi Arabia 14%, Eastern Europe 9%,
Japan 9%, US 3% (FY88)
_#_Imports: $1.0 billion (c.i.f., FY90 est.);
commodities--petroleum products 28%, manufactured goods, machinery
and equipment, medicines and chemicals;
partners--Western Europe 32%, Africa and Asia 15%, US 13%,
Eastern Europe 3% (FY88)
_#_External debt: $12.3 billion (December 1990 est.)
_#_Industrial production: growth rate 0.7% (FY89); accounts for
11% of GDP
_#_Electricity: 606,000 kW capacity; 900 million kWh produced,
37 kWh per capita (1989)
_#_Industries: cotton ginning, textiles, cement, edible oils, sugar,
soap distilling, shoes, petroleum refining
_#_Agriculture: accounts for 35% of GNP and 80% of labor force;
water shortages; two-thirds of land area suitable for raising crops and
livestock; major products--cotton, oilseeds, sorghum, millet, wheat,
gum arabic, sheep; marginally self-sufficient in most foods
_#_Economic aid: US commitments, including Ex-Im (FY70-89), $1.5
billion; Western (non-US) countries, ODA and OOF bilateral commitments
(1970-88), $4.8 billion; OPEC bilateral aid (1979-89), $3.1 billion;
Communist countries (1970-89), $588 million
_#_Currency: Sudanese pound (plural--pounds);
1 Sudanese pound (5Sd) = 100 piasters
_#_Exchange rates: official rate--Sudanese pounds (5Sd) per
US$1--4.5004 (fixed rate since 1987), 2.8121 (1987), 2.5000 (1986),
2.2883 (1985); note--commercial exchange rate 12.2 (May 1990)
_#_Fiscal year: 1 July-30 June
_#_Overview: The economy is dominated by the bauxite industry, which
accounts for about 70% of export earnings and 40% of tax revenues. The
economy has been in trouble since the Dutch ended development aid in
1982. A drop in world bauxite prices that started in the late 1970s and
continued until late 1986, was followed by the outbreak of a guerrilla
insurgency in the interior. The guerrillas targeted the economic
infrastructure, crippling the important bauxite sector and shutting down
other export industries. These problems have created high inflation,
high unemployment, widespread black market activity, and a bad climate
for foreign investment. A small gain in economic growth of 2.0% was
registered in 1989 due to reduced guerrilla activity and improved
international markets for bauxite.
_#_GDP: $1.35 billion, per capita $3,400; real growth rate 2.0%
(1989 est.)
_#_Inflation rate (consumer prices): 50% (1989 est.)
_#_Unemployment rate: 33% (1990)
_#_Budget: revenues $466 million; expenditures $716 million,
including capital expenditures of $123 million (1989 est.)
_#_Exports: $425 million (f.o.b., 1988 est.);
commodities--alumina, bauxite, aluminum, rice, wood and wood
products, shrimp and fish, bananas;
partners--Norway 33%, Netherlands 20%, US 15%, FRG 9%,
Brazil 5%, UK 5%, Japan 3','0a8479de9d6f93aeabba8b7c5757d5a78543d94806d26e7a87d592b5b08a3e44','internet-archive','theciaworldfactb00025gut','txt','84185fe9df79da427349cc1598fd3f69814a2085a9fc1fe0508a3fae0a870f84','https://archive.org/download/theciaworldfactb00025gut/25.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3e5321601180f17291ed1caed224ffe736cba9c0923241f1aa08caea8444e23c',1991,'SA','Saudi Arabia','economy',61,'%, other 10%
_#_Imports: $370 million (f.o.b., 1988 est.);
commodities--capital equipment, petroleum, foodstuffs, cotton,
consumer goods;
partners--US 37%, Netherlands 15%, Netherlands Antilles 11%,
Trinidad and Tobago 9%, Brazil 5%, UK 3%, other 20%
_#_External debt: $138 million (1990 est.)
_#_Industrial production: growth rate 16.4% (1988 est.); accounts
for 22% of GDP
_#_Electricity: 458,000 kW capacity; 2,018 million kWh produced,
5,090 kWh per capita (1990)
_#_Industries: bauxite mining, alumina and aluminum production,
lumbering, food processing, fishing
_#_Agriculture: accounts for 11% of both GDP and labor force; paddy
rice planted on 85% of arable land and represents 60% of total farm
output; other products--bananas, palm kernels, coconuts, plantains,
peanuts, beef, chicken; shrimp and forestry products of increasing
importance; self-sufficient in most foods
_#_Economic aid: US commitments, including Ex-Im (FY70-83), $2.5
million; Western (non-US) countries, ODA and OOF bilateral commitments
(1970-87), $1.45 billion
_#_Currency: Surinamese guilder, gulden, or florin (plural--guilders,
gulden, or florins); 1 Surinamese guilder, gulden, or florin (Sf.) =
100 cents
_#_Exchange rates: Surinamese guilders, gulden, or florins (Sf.)
per US$1--1.7850 (fixed rate)
_#_Fiscal year: calendar year
_#_Overview: Coal mining is the major economic activity on Svalbard.
By treaty (9 February 1920), the nationals of the treaty powers have
equal rights to exploit mineral deposits, subject to Norwegian
regulation. Although US, UK, Dutch, and Swedish coal companies have mined
in the past, the only companies still mining are Norwegian and Soviet.
Each company mines about half a million tons of coal annually. The
settlements on Svalbard are essentially company towns. The Norwegian
state-owned coal company employs nearly 60% of the Norwegian population
on the island, runs many of the local services, and provides most of the
local infrastructure. There is also some trapping of seal, polar bear,
fox, and walrus.
_#_Budget: revenues $13.3 million, expenditures $13.3 million,
including capital expenditures of $NA (1990)
_#_Electricity: 21,000 kW capacity; 45 million kWh produced,
11,420 kWh per capita (1989)
_#_Currency: Norwegian krone (plural--kroner);
1 Norwegian krone (NKr) = 100 ore
_#_Exchange rates: Norwegian kroner (NKr) per US$1--5.9060 (January
1991), 6.2597 (1990), 6.9045 (1989), 6.5170 (1988), 6.7375 (1987), 7.3947
(1986), 8.5972 (1985)
_#_Overview: The economy is based on subsistence agriculture, which
occupies much of the labor force and contributes about 23% to GDP.
Manufacturing, which includes a number of agroprocessing factories,
accounts for another 26% of GDP. Mining has declined in importance in
recent years; high-grade iron ore deposits were depleted in 1978, and
health concerns cut world demand for asbestos. Exports of sugar and
forestry products are the main earners of hard currency. Surrounded by
South Africa, except for a short border with Mozambique, Swaziland
is heavily dependent on South Africa, from which it receives 92% of
its imports and to which it sends about 40% of its exports.
_#_GNP: $563 million, per capita $670; real growth rate 5.0% (1990
est.)
_#_Inflation rate (consumer prices): 13% (1990)
_#_Unemployment rate: NA%
_#_Budget: revenues $322.9 million; expenditures $325.5 million,
including capital expenditures of $NA (FY92 est.)
_#_Exports: $543 million (f.o.b., 1990);
commodities--soft drink concentrates, sugar, wood pulp, citrus,
canned fruit;
partners--South Africa 40% (est.), EC, Canada
_#_Imports: $651 million (f.o.b., 1990);
commodities--motor vehicles, machinery, transport equipment,
petroleum products, foodstuffs, chemicals;
partners--South Africa 92% (est.), Japan, Belgium, UK
_#_External debt: $290 million (1990)
_#_Industrial production: growth rate NA; accounts for 26%
of GDP (1989)
_#_Electricity: 50,000 kW capacity; 130 million kWh produced,
170 kWh per capita (1989)
_#_Industries: mining (coal and asbestos), wood pulp, sugar
_#_Agriculture: accounts for 23% of GDP and over 60% of labor force;
mostly subsistence agriculture; cash crops--sugarcane, citrus fruit,
cotton, pineapples; other crops and livestock--corn, sorghum, peanuts,
cattle, goats, sheep; not self-sufficient in grain
_#_Economic aid: US commitments, including Ex-Im (FY70-89), $142
million; Western (non-US) countries, ODA and OOF bilateral commitments
(1970-88), $488 million
_#_Currency: lilangeni (plural--emalangeni); 1 lilangeni (E) =
100 cents
_#_Exchange rates: emalangeni (E) per US$1--2.5625 (January 1991),
2.5863 (1990), 2.6166 (1989), 2.2611 (1988), 2.0350 (1987), 2.2685
(1986), 2.1911 (1985); note--the Swazi emalangeni is at par with the
South African rand
_#_Fiscal year: 1 April-31 March
_#_Overview: Aided by a long period of peace and neutrality during
World War I through World War II, Sweden has achieved an enviable
standard of living under a mixed system of high-tech capitalism and
extensive welfare benefits. It has essentially full employment,
a modern distribution system, excellent internal and external
communications, and a skilled labor force. Timber, hydropower, and
iron ore constitute the resource base of an economy that is heavily
oriented toward foreign trade. Privately owned firms account for
about 90% of industrial output, of which the engineering
sector accounts for 50% of output and exports. For some observers,
the Swedish model has succeeded in making economic efficiency
and social egalitarianism complementary, rather than competitive,
goals. Others argue that the Swedish model is on the verge of
collapsing by pointing to the serious economic problems Sweden
faces in 1991: high inflation and absenteeism, growing unemployment
and deficits, and declining international competitiveness. In 1990,
to improve the economy, the government approved a mandate for
Sweden to seek EC membership and an austerity and privatization
package and implemented a major tax reform. These reforms may
succeed in turning the economy around in 1992.
_#_GDP: $137.8 billion, per capita $16,200; real growth rate 0.3%
(1990)
_#_Inflation rate (consumer prices): 10.9% (1990)
_#_Unemployment rate: 1.6% (1990)
_#_Budget: revenues $60.1 billion; expenditures $56.7 billion,
including capital expenditures of $NA (FY89)
_#_Exports: $57.5 billion (f.o.b., 1990);
commodities--machinery, motor vehicles, paper products, pulp
and wood, iron and steel products, chemicals, petroleum and
petroleum products;
partners--EC 54.4%, (FRG 14.2%, UK 10.1%, Denmark 6.6%), US 8.6%,
Norway 8.2%
_#_Imports: $54.7 billion (c.i.f., 1990);
commodities--machinery, petroleum and petroleum products,
chemicals, motor vehicles, foodstuffs, iron and steel, clothing;
partners--EC 55.3%, US 8.4%
_#_External debt: $14.1 billion (December 1990)
_#_Industrial production: growth rate - 2.0% (1990)
_#_Electricity: 39,716,000 kW capacity; 142,000 million kWh produced,
16,700 kWh per capita (1990)
_#_Industries: iron and steel, precision equipment (bearings, radio
and telephone parts, armaments), wood pulp and paper products, processed
foods, motor vehicles
_#_Agriculture: animal husbandry predominates, with milk and dairy
products accounting for 37% of farm income; main crops--grains, sugar
beets, potatoes; 100% self-sufficient in grains and potatoes, 85%
self-sufficient in sugar beets
_#_Economic aid: donor--ODA and OOF commitments (1970-89), $10.3
billion
_#_Currency: Swedish krona (plural--kronor);
1 Swedish krona (SKr) = 100 ore
_#_Exchange rates: Swedish kronor (SKr) per US$1--5.6402 (January
1991), 5.9188 (1990), 6.4469 (1989), 6.1272 (1988), 6.3404 (1987), 7.1236
(1986), 8.6039 (1985)
_#_Fiscal year: 1 July-30 June
_#_Overview: Switzerland''s economic success is matched in few, if any,
other nations. Per capita output, general living standards, education
and science, health care, and diet are unsurpassed in Europe. Inflation
remains low because of sound government policy and harmonious
labor-management relations. Unemployment is negligible, a marked
contrast to the larger economies of Western Europe. This economic
stability helps promote the important banking and tourist sectors. Since
World War II, Switzerland''s economy has adjusted smoothly to the great
changes in output and trade patterns in Europe and presumably can adjust
to the challenges of the 1990s, in particular, the further economic
integration of Western Europe and the amazingly rapid changes in East
European political/economic prospects.
_#_GDP: $126 billion, per capita $18,700; real growth rate 2.6%
(1990)
_#_Inflation rate (consumer prices): 5.3% (1990)
_#_Unemployment rate: 0.5% (1990)
_#_Budget: revenues $24.0 billion; expenditures $23.8 billion,
including capital expenditures of $NA (1990)
_#_Exports: $63.4 billion (f.o.b., 1990);
commodities--machinery and equipment, precision instruments, metal
products, foodstuffs, textiles and clothing;
partners--Western Europe 64% (EC 56%, other 8%), US 9%, Japan 4%
_#_Imports: $70.5 billion (c.i.f., 1990);
commodities--agricultural products, machinery and transportation
equipment, chemicals, textiles, construction materials;
partners--Western Europe 78% (EC 71%, other 7%), US 6%
_#_External debt: $NA
_#_Industrial production: growth rate 2.1% (1990)
_#_Electricity: 17,710,000 kW capacity; 59,070 million kWh produced,
8,930 kWh per capita (1989)
_#_Industries: machinery, chemicals, watches, textiles, precision
instruments
_#_Agriculture: dairy farming predominates; less than 50%
self-sufficient; food shortages--fish, refined sugar, fats and oils
(other than butter), grains, eggs, fruits, vegetables, meat
_#_Economic aid: donor--ODA and OOF commitments (1970-89), $3.5
billion
_#_Currency: Swiss franc, franken, or franco (plural--francs, franken,
or franchi); 1 Swiss franc, franken, or franco (SwF) = 100 centimes,
rappen, or centesimi
_#_Exchange rates: Swiss francs, franken, or franchi (SwF) per
US$1--1.2724 (January 1991), 1.3892 (1990), 1.6359 (1989), 1.4633
(1988), 1.4912 (1987), 1.7989 (1986), 2.4571 (1985)
_#_Fiscal year: calendar year
_#_Overview: Syria''s rigidly structured Bathist economy turned
out slightly more goods in 1990 than in 1983, when the population was 20%
smaller. Economic difficulties are attributable, in part, to severe
drought in several recent years, costly but unsuccessful attempts
to match Israel''s military strength, a falloff in Arab aid, and
insufficient foreign exchange earnings to buy needed inputs for industry
and agriculture. Socialist policy, embodied in a thicket of bureaucratic
regulations, in many instances has driven away or pushed underground the
mercantile and entrepreneurial spirit for which Syrian businessmen have
long been famous. Two bright spots: a sizable number of villagers have
benefited from land redistribution, electrification, and other rural
development programs; and a recent find of light crude oil has enabled
Syria to cut oil imports. A long-term concern is the additional drain of
upstream Euphrates water by Turkey when its vast dam and irrigation
projects are completed toward the end of the 1990s. Output in 1990
rebounded from the very bad year of 1989, as agricultural production
and oil revenues increased substantially.
_#_GDP: $20.0 billion, per capita $1,600; real growth rate 12%
(1990 est.)
_#_Inflation rate (consumer prices): 50% (1990 est.)
_#_Unemployment rate: NA%
_#_Budget: revenues $4.8 billion; expenditures $5.5 billion, including
capital expenditures of $2.1 billion (1990 est.)
_#_Exports: $2.3 billion (f.o.b., 1990 est.);
commodities--petroleum 40%, textiles 30%, farm products 13%,
phosphates (1989);
partners--USSR and Eastern Europe 42%, EC 31%, Arab countries 17%,
US/Canada 2% (1989)
_#_Imports: $2.5 billion (f.o.b., 1990 est.);
commodities--foodstuffs and beverages 21%, metal and metal
products 16%, machinery 14%, textiles, petroleum (1989);
partners--EC 42%, USSR and Eastern Europe 13%, other Europe 13%,
US/Canada 8%, Arab countries 6% (1989)
_#_External debt: $5.2 billion in hard currency (1990 est.)
_#_Industrial production: growth rate 17% (1990 est.); accounts
for 19% of GDP
_#_Electricity: 2,867,000 kW capacity; 6,000 million kWh produced,
500 kWh per capita (1989)
_#_Industries: textiles, food processing, beverages, tobacco,
phosphate rock mining, petroleum
_#_Agriculture: accounts for 27% of GDP and one-third of labor force;
all major crops (wheat, barley, cotton, lentils, chickpeas) grown
mainly on rainfed land causing wide swings in production; animal
products--beef, lamb, eggs, poultry, milk; not self-sufficient in grain
or livestock products
_#_Economic aid: US commitments, including Ex-Im (FY70-81), $538
million; Western (non-US) ODA and OOF bilateral commitments (1970-88),
$1.2 billion; OPEC bilateral aid (1979-89), $12.3 billion; Communist
countries (1970-89), $3.3 billion
_#_Currency: Syrian pound (plural--pounds);
1 Syrian pound (5S) = 100 piasters
_#_Exchange rates: Syrian pounds (5S) per US$1--11.2250 (fixed rate
since 1987), 3.9250 (fixed rate 1976-87)
_#_Fiscal year: calendar year
_#_Overview: Tanzania is one of the poorest countries in the world.
The economy is heavily dependent on agriculture, which accounts for about
47% of GDP, provides 85% of exports, and employs 90% of the work force.
Industry accounts for 8% of GDP and is mainly limited to processing
agricultural products and light consumer goods. The economic
recovery program announced in mid-1986 has generated notable increases in
agricultural production and financial support for the program by
bilateral donors. The World Bank and the International Monetary Fund have
increased the availability of imports and provided funds to rehabilitate
Tanzania''s deteriorated economic infrastructure.
_#_GDP: $5.92 billion, per capita $240; real growth rate 4.3%
(FY89 est.)
_#_Inflation rate (consumer prices): 31.2 (1989)
_#_Unemployment rate: NA%
_#_Budget: revenues $495 million; expenditures $631 million,
including capital expenditures of $118 million (FY90)
_#_Exports: $380 million (f.o.b., 1989);
commodities--coffee, cotton, sisal, tea, cashew nuts, meat,
tobacco, diamonds, coconut products, pyrethrum, cloves (Zanzibar);
partners--FRG, UK, Japan, Netherlands, Kenya, Hong Kong, US
_#_Imports: $1.2 billion (c.i.f., 1989);
commodities--manufactured goods, machinery and transportation
equipment, cotton piece goods, crude oil, foodstuffs;
partners--FRG, UK, US, Japan, Italy, Denmark
_#_External debt: $5.8 billion (December 1990 est.)
_#_Industrial production: growth rate 4.2% (1988); accounts for
8% of GDP
_#_Electricity: 401,000 kW capacity; 895 million kWh produced,
35 kWh per capita (1989)
_#_Industries: primarily agricultural processing (sugar, beer,
cigarettes, sisal twine), diamond mine, oil refinery, shoes, cement,
textiles, wood products, fertilizer
_#_Agriculture: accounts for over 40% of GDP; topography and climatic
conditions limit cultivated crops to only 5% of land area; cash
crops--coffee, sisal, tea, cotton, pyrethrum (insecticide made from
chrysanthemums), cashews, tobacco, cloves (Zanzibar); food crops--corn,
wheat, cassava, bananas, fruits, and vegetables; small numbers of cattle,
sheep, and goats; not self-sufficient in food grain production
_#_Economic aid: US commitments, including Ex-Im (FY70-89), $400
million; Western (non-US) countries, ODA and OOF bilateral commitments
(1970-88), $9.2 billion; OPEC bilateral aid (1979-89), $44 million;
Communist countries (1970-89), $614 million
_#_Currency: Tanzanian shilling (plural--shillings);
1 Tanzanian shilling (TSh) = 100 cents
_#_Exchange rates: Tanzanian shillings (TSh) per US$1--196.60
(January 1991), 195.06 (1990), 143.377 (1989), 99.292 (1988), 64.260
(1987), 32.698 (1986), 17.472 (1985)
_#_Fiscal year: 1 July-30 June','7e596230ae34b4874ca837d061ab6742416aa735c59e77d25d86b2b8e92db28d','internet-archive','theciaworldfactb00025gut','txt','84185fe9df79da427349cc1598fd3f69814a2085a9fc1fe0508a3fae0a870f84','https://archive.org/download/theciaworldfactb00025gut/25.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7be93609176d6c5e4bc1b70c85942f5a10de22055e1ccb608a8aa69d398e8276',1991,'GF','French Guiana','economy',74,'_#_Overview: The economy is tied closely to that of France through
subsidies and imports. Besides the French space center at Kourou, fishing
and forestry are the most important economic activities, with exports
of fish and fish products (mostly shrimp) accounting for more than 60%
of total revenue in 1987. The large reserves of tropical hardwoods, not
fully exploited, support an expanding sawmill industry that provides sawn
logs for export. Cultivation of crops--rice, cassava, bananas, and
sugarcane--are limited to the coastal area, where the population is
largely concentrated. French Guiana is heavily dependent on imports
of food and energy. Unemployment is a serious problem, particularly
among younger workers.
_#_GDP: $186 million, per capita $2,240; real growth rate NA% (1985)
_#_Inflation rate (consumer prices): 4.1% (1987)
_#_Unemployment rate: 15% (1987)
_#_Budget: revenues $735 million; expenditures $735 million, including
capital expenditures of NA (1987)
_#_Exports: $54.0 million (f.o.b., 1987);
commodities--shrimp, timber, rum, rosewood essence;
partners--France 31%, US 22%, Japan 10% (1987)
_#_Imports: $394.0 million (c.i.f., 1987);
commodities--food (grains, processed meat), other consumer goods,
producer goods, petroleum;
partners--France 62%, Trinidad and Tobago 9%, US 4%, FRG 3%
(1987)
_#_External debt: $1.2 billion (1988)
_#_Industrial production: growth rate NA%
_#_Electricity: 92,000 kW capacity; 185 million kWh produced,
1,890 kWh per capita (1990)
_#_Industries: construction, shrimp processing, forestry products,
rum, gold mining
_#_Agriculture: some vegetables for local consumption; rice, corn,
manioc, cocoa, bananas, sugar; livestock--cattle, pigs, poultry
_#_Economic aid: Western (non-US) countries, ODA and OOF bilateral
commitments (1970-87), $1.25 billion
_#_Currency: French franc (plural--francs); 1 French franc (F) = 100
centimes
_#_Exchange rates: French francs (F) per US$1--5.1307 (January 1991),
5.4453 (1990), 6.3801 (1989), 5.9569 (1988), 6.0107 (1987), 6.9261
(1986), 8.9852 (1985)
_#_Fiscal year: calendar year
_#_Overview: Since 1962, when France stationed military personnel in
the region, French Polynesia has changed from a subsistence economy to
one in which a high proportion of the work force is either employed by
the military or supports the tourist industry. Tourism accounts for about
20% of GDP and is a primary source of hard currency earnings.
_#_GDP: $1.2 billion, per capita $6,300; real growth rate NA% (1990
est.)
_#_Inflation rate (consumer prices): 1.3% (1989 est.)
_#_Unemployment rate: 8% (1986 est.)
_#_Budget: revenues $614 million; expenditures $957 million, including
capital expenditures of $NA (1988)
_#_Exports: $75 million (f.o.b., 1988);
commodities--coconut products 79%, mother-of-pearl 14%, vanilla,
shark meat;
partners--France 54%, US 17%, Japan 17%
_#_Imports: $806 million (c.i.f., 1988);
commodities--fuels, foodstuffs, equipment;
partners--France 53%, US 11%, Australia 6%, NZ 5%
_#_External debt: $NA
_#_Industrial production: growth rate NA%
_#_Electricity: 72,000 kW capacity; 265 million kWh produced,
1,390 kWh per capita (1990)
_#_Industries: tourism, pearls, agricultural processing, handicrafts
_#_Agriculture: coconut and vanilla plantations; vegetables and fruit;
poultry, beef, dairy products
_#_Economic aid: Western (non-US) countries, ODA and OOF bilateral
commitments (1970-88), $3.95 billion
_#_Currency: Comptoirs Francais du Pacifique franc (plural--francs);
1 CFP franc (CFPF) = 100 centimes
_#_Exchange rates: Comptoirs Francais du Pacifique francs (CFPF) per
US$1--93.28 (January 1991), 99.00 (1990), 115.99 (1989), 108.30 (1988),
109.27 (1987), 125.92 (1986), 163.35 (1985); note--linked at the rate of
18.18 to the French franc
_#_Fiscal year: calendar year
_#_Overview: Economic activity is limited to servicing meteorological
and geophysical research stations and French and other fishing fleets.
The fishing catches landed on Iles Kerguelen by foreign ships are
exported to France and Reunion.
_#_Budget: $33.6 million (1990)
_#_Overview: The economy, dependent on timber and manganese until
the early 1970s, is now dominated by the oil sector. During the period
1981-85 oil accounted for about 46% of GDP, 83% of export earnings, and
65% of government revenues on average. The high oil prices of the early
1980s contributed to a substantial increase in per capita income,
stimulated domestic demand, reinforced migration from rural to urban
areas, and raised the level of real wages to among the highest in
Sub-Saharan Africa. The three-year slide of Gabon''s economy, which
began with falling oil prices in 1985, was reversed in 1989 because of a
near doubling of oil prices over their 1988 lows. In 1990 the economy
continued to grow, but debt servicing problems are hindering economic
advancement. The agricultural and industrial sectors are relatively
underdeveloped, except for oil.
_#_GDP: $3.3 billion, per capita $3,090; real growth rate 13% (1990
est.)
_#_Inflation rate (consumer prices): 3% (1989 est.)
_#_Unemployment rate: NA%
_#_Budget: revenues $1.1 billion; expenditures $1.5 billion,
including capital expenditures of $277 million (1990 est.)
_#_Exports: $1.16 billion (f.o.b., 1989);
commodities--crude oil 70%, manganese 11%, wood 12%, uranium 6%;
partners--France 53%, US 22%, FRG, Japan
_#_Imports: $0.78 billion (c.i.f., 1989);
commodities--foodstuffs, chemical products, petroleum products,
construction materials, manufactures, machinery;
partners--France 48%, US 2.6%, FRG, Japan, UK
_#_External debt: $3.4 billion (December 1990 est.)
_#_Industrial production: growth rate - 10% (1988 est.)
_#_Electricity: 310,000 kW capacity; 980 million kWh produced,
920 kWh per capita (1989)
_#_Industries: petroleum, food and beverages, timber, cement
plywood, textiles, mining--manganese, uranium, gold)
_#_Agriculture: accounts for 10% of GDP (including fishing and
forestry); cash crops--cocoa, coffee, palm oil; livestock not developed;
importer of food; small fishing operations provide a catch of about
20,000 metric tons; okoume (a tropical softwood) is the most important
timber product
_#_Economic aid: US commitments, including Ex-Im (FY70-89), $66
million; Western (non-US) countries, ODA and OOF bilateral commitments
(1970-88), $1.9 billion; Communist countries (1970-89), $27 million
_#_Currency: Communaute Financiere Africaine franc
(plural--francs); 1 CFA franc (CFAF) = 100 centimes
_#_Exchange rates: Communaute Financiere Africaine francs (CFAF)
per US$1--253.32 (December 1990), 171.26 (1990), 319.01 (1989), 297.85
(1988), 300.54 (1987), 346.30 (1986), 449.26 (1985)
_#_Fiscal year: calendar year
_#_Overview: The Gambia has no important mineral or other natural
resources and has a limited agricultural base. It is one of the world''s
poorest countries with a per capita income of about $230. About 75%
of the population is engaged in crop production and livestock raising,
which contributes 30% to GDP. Small-scale manufacturing
activity--processing peanuts, fish, and hides--accounts for less than
10% of GDP. Tourism is a growing industry. The Gambia imports
one-third of its food, all fuel, and most manufactured goods. Exports
are concentrated on peanut products (about 75% of total value).
_#_GDP: $195 million, per capita $230; real growth rate 6.0% (FY90
est.)
_#_Inflation rate (consumer prices): 6.0% (FY91)
_#_Unemployment rate: NA%
_#_Budget: revenues $79 million; expenditures $84 million,
including capital expenditures of $21 million (FY90)
_#_Exports: $116 million (f.o.b., FY90);
commodities--peanuts and peanut products, fish, cotton lint, palm
kernels;
partners--Japan 60%, Europe 29%, Africa 5%, US 1% other 5% (1989)
_#_Imports: $147 million (f.o.b., FY90);
commodities--foodstuffs, manufactures, raw materials, fuel,
machinery and transport equipment;
partners--Europe 57%, Asia 25%, USSR/EE 9%, US 6%, other 3%
(1989)
_#_External debt: $336 million (December 1990 est.)
_#_Industrial production: growth rate 6.7%; accounts for 5.8%
of GDP (FY90)
_#_Electricity: 29,000 kW capacity; 64 million kWh produced, 80 kWh
per capita (1989)
_#_Industries: peanut processing, tourism, beverages, agricultural
machinery assembly, woodworking, metalworking, clothing
_#_Agriculture: accounts for 30% of GDP and employs about 75% of the
population; imports one-third of food requirements; major export crop is
peanuts; the principal crops--millet, sorghum, rice, corn, cassava,
palm kernels; livestock--cattle, sheep, and goats; forestry and fishing
resources not fully exploited
_#_Economic aid: US commitments, including Ex-Im (FY70-89), $93
million; Western (non-US) countries, ODA and OOF bilateral commitments
(1970-88), $492 million; Communist countries (1970-88), $39 million
_#_Currency: dalasi (plural--dalasi); 1 dalasi (D) = 100 bututs
_#_Exchange rates: dalasi (D) per US$1--7.610 (January 1991),
7.883 (1990), 7.5846 (1989), 6.7086 (1988), 7.0744 (1987),
6.9380 (1986), 3.8939 (1985)
_#_Fiscal year: 1 July-30 June
_#_Overview: Nearly half the labor force of the Gaza Strip is
employed across the border by Israeli industrial, construction, and
agricultural enterprises, with worker transfer funds accounting for 46%
of GNP in 1990. The once dominant agricultural sector now contributes
only 13% to GNP, about the same as that of the construction sector, and
industry accounts for 7%. Gaza depends upon Israel for 90% of its
imports and as a market for 80% of its exports. Unrest in the territory
in 1988-91 (intifadah) has raised unemployment and substantially
lowered the incomes of the population. Furthermore, the Persian Gulf
crisis dealt a severe blow to the Gaza Strip in 1990 and on into 1991.
Worker remittances from the Gulf states have plunged, unemployment has
increased, and export revenues have fallen dramatically. The risk of
malnutrition is a real possibility in 1991.
_#_GNP: $270 million, per capita $430; real growth rate - 25%
(1990 est.)
_#_Inflation rate (consumer prices): NA%
_#_Unemployment rate: NA%
_#_Budget: revenues $36.6 million; expenditures $32.0 million,
including capital expenditures of NA (1986)
_#_Exports: $88 million;
commodities--citrus;
partners--Israel, Egypt (1989 est.)
_#_Imports: $260 million;
commodities--food, consumer goods, construction materials;
partners--Israel, Egypt (1989 est.)
_#_External debt: $NA
_#_Industrial production: growth rate NA%
_#_Electricity: power supplied by Israel
_#_Industries: generally small family businesses that produce cement,
textiles, soap, olive-wood carvings, and mother-of-pearl souvenirs; the
Israelis have established some small-scale modern industries in an
industrial center
_#_Agriculture: olives, citrus and other fruits, vegetables, beef,
dairy products
_#_Economic aid: none
_#_Currency: new Israeli shekel (plural--shekels);
1 new Israeli shekel (NIS) = 100 new agorot
_#_Exchange rates: new Israeli shekels (NIS) per US$1--2.0120 (January
1991), 2.0162 (1990), 1.9164 (1989), 1.5989 (1988), 1.5946 (1987), 1.4878
(1986), 1.1788
(1985)
_#_Fiscal year: 1 April-March 31
_#_Overview: The newly unified German economy presents a starkly
contrasting picture. Western Germany has an advanced market economy
and is a leading exporter. It experienced faster-than-projected real
growth largely because of demand in eastern Germany for western German
goods. Western Germany has a highly urbanized and skilled population
which enjoys excellent living standards, abundant leisure time, and
comprehensive social welfare benefits. Western Germany is relatively
poor in natural resources, coal being the most important mineral.
Western Germany''s world-class companies manufacture technologically
advanced goods. The region''s economy is mature: manufacturing and service
industries account for the dominant share of economic activity, and raw
materials and semimanufactured products constitute a large proportion of
imports. In 1989 manufacturing accounted for 31% of GDP, with other
sectors contributing lesser amounts. In recent years, gross fixed
investment has accounted for about 21% of GDP. In 1990 GDP in the western
region was an estimated $16,300 per capita.
In contrast, eastern Germany''s obsolete command economy, once
dominated by smokestack heavy industries, has been undergoing a
wrenching change to a market economy. Industrial production in early
1991 is down 50% from the same period last year, due largely to the
slump in domestic demand for eastern German-made goods and the ongoing
economic restructuring. The FRG''s legal, social welfare, and economic
systems have been extended to the east, but economic
restructuring--privatizing industry, establishing clear property rights,
clarifying responsibility for environmental clean-up, and removing
Communist-era holdovers from management--is proceeding slowly
so far, deterring outside investors. The region is one of the world''s
largest producers of low-grade lignite coal, but has few other resources.
The quality of statistics from eastern Germany remains poor; Bonn is
still trying to bring statistics for the region in line with West German
practices.
The most challenging economic problem of a united Germany is the
reconstruction of eastern Germany''s economy--specifically, finding the
right mix of fiscal, regulatory, monetary, and tax policies that
will spur investment in the east without derailing western Germany''s
healthy economy or damaging relations with Western partners. The
biggest danger is that soaring unemployment in eastern Germany, which
could climb to the 30 to 40% range, could touch off labor disputes
or renewed mass relocation to western Germany and erode investor
confidence in eastern Germany. Overall economic activity grew an
estimated 4.6% in western Germany in 1990, while dropping roughly 15% in
eastern Germany. Per capita GDP in the eastern region was approximately
$8,700 in 1990.
_#_GDP: $1,157.2 billion, per capita $14,600; real growth rate 1.7%
(1990)
_#_Inflation rate (consumer prices):
West--3.0% (1989);
East--0.8% (1989)
_#_Unemployment rate:
West--7.1% (1990);
East--1% (1989); 3% (first half, 1990)
_#_Budget:
West--revenues $539 billion; expenditures $563 billion, including
capital expenditures of $11.5 billion (1988);
East--revenues $147.0 billion; expenditures $153.4 billion, including
capital expenditures of $NA (1988)
_#_Exports:
West--$324.3 billion (f.o.b., 1989);
commodities--manufactures 86.6% (including machines and machine
tools, chemicals, motor vehicles, iron and steel products),
agricultural products 4.9%, raw materials 2.3%, fuels 1.3%;
partners--EC 52.7% (France 12%, Netherlands 9%, Italy 9%, UK 9%,
Belgium-Luxembourg 7%), other West Europe 18%, US 10%, Eastern
Europe 4%, OPEC 3% (1987);
East--$32.4 billion (f.o.b., 1989);
commodities--machinery and transport equipment 47%, fuels and
metals 16%, consumer goods 16%, chemical products and building
materials 13%, semimanufactured goods and processed foodstuffs 8%;
partners--USSR, Czechoslovakia, Poland, FRG, Hungary, Bulgaria,
Switzerland, Romania, EC, US (1989)
_#_Imports:
West--$247.7 billion (f.o.b., 1989);
commodities--manufactures 68.5%, agricultural products 12.0%,
fuels 9.7%, raw materials 7.1%;
partners--EC 52.7% (France 12%, Netherlands 11%, Italy 10%, UK 7%,
Belgium-Luxembourg 7%), other West Europe 15%, US 6%, Japan 6%, Eastern
Europe 5%, OPEC 3% (1987);
East--$30.0 billion (f.o.b., 1989);
commodities--fuels and metals 40%, machinery and transport
equipment 29%, chemical products and building materials 9%;
partners--USSR and Eastern Europe 65%, FRG 12.7%, EC 6.0%,
US 0.3% (1989)
_#_External debt:
West--$500 million (June 1988);
East--$20.6 billion (1989)
_#_Industrial production: growth rates, West--3.3% (1988);
East--2.7% (1989 est.)
_#_Electricity: 133,000,000 kW capacity; 580,000 million kWh produced,
7,390 kWh per capita (1990)
_#_Industries:
West--among world''s largest producers of iron, steel, coal, cement,
chemicals, machinery, vehicles, machine tools, electronics;
food and beverages;
East--metal fabrication, chemicals, brown coal, shipbuilding, machine
building, food and beverages, textiles, petroleum
_#_Agriculture:
West--accounts for about 2% of GDP (including fishing and forestry);
diversified crop and livestock farming; principal crops and livestock
include potatoes, wheat, barley, sugar beets, fruit, cabbage, cattle,
pigs, poultry; net importer of food; fish catch of 202,000 metric tons
in 1987;
East--accounts for about 10% of GNP (including fishing and forestry);
principal crops--wheat, rye, barley, potatoes, sugar beets, fruit;
livestock products include pork, beef, chicken, milk, hides and skins;
net importer of food; fish catch of 193,600 metric tons in 1987
_#_Economic aid:
West--donor--ODA and OOF commitments (1970-89), $75.5 billion;
East--donor--$4.0 billion extended bilaterally to non-Communist less
developed countries (1956-88)
_#_Currency: deutsche mark (plural--marks);
1 deutsche mark (DM) = 100 pfennige
_#_Exchange rates: deutsche marks (DM) per US$1--1.5100 (January
1991), 1.6157 (1990), 1.8800 (1989), 1.7562 (1988), 1.7974 (1987), 2.1715
(1986), 2.9440 (1985)
_#_Fiscal year: calendar year
_#_Overview: Supported by substantial international assistance, Ghana
has been implementing a steady economic rebuilding program since 1983,
including moves toward privatization and relaxation of government
controls. Heavily dependent on cocoa, gold, and timber exports,
economic growth is threatened by a poor cocoa harvest and higher oil
prices in 1991. Rising inflation--unofficially estimated at 50%--could
undermine Ghana''s relationships with multilateral lenders. Civil service
wage increases and the cost of peacekeeping forces sent to Liberia are
boosting government expenditures and undercutting structural adjustment
reforms. Ghana opened a stock exchange in 1990.
_#_GNP: $5.8 billion, per capita $380; real growth rate 2.7% (1990
est.)
_#_Inflation rate (consumer prices): 50% (1990 est.)
_#_Unemployment rate: 1.9% (1989)
_#_Budget: revenues $821 million; expenditures $782 million, including
capital expenditures of $151 million (1990 est.)
_#_Exports: $826 million (f.o.b., 1990 est.);
commodities--cocoa 45%, gold, timber, tuna, bauxite, and aluminum;
partners--US 23%, UK, other EC
_#_Imports: $1.2 billion (c.i.f., 1990 est.);
commodities--petroleum 16%, consumer goods, foods, intermediate
goods, capital equipment;
partners--US 10%, UK, FRG, France, Japan, South Korea, GDR
_#_External debt: $3.1 billion (1990 est.)
_#_Industrial production: growth rate 7.4% in manufacturing (1989);
accounts for almost 1.5% of GDP
_#_Electricity: 1,172,000 kW capacity; 4,110 million kWh produced,
280 kWh per capita (1989)
_#_Industries: mining, lumbering, light manufacturing, fishing,
aluminum, food processing
_#_Agriculture: accounts for more than 50% of GDP (including fishing
and forestry); the major cash crop is cocoa; other principal crops--rice,
coffee, cassava, peanuts, corn, shea nuts, timber; normally
self-sufficient in food
_#_Illicit drugs: illicit producer of cannabis for the international
drug trade
_#_Economic aid: US commitments, including Ex-Im (FY70-89), $455
million; Western (non-US) countries, ODA and OOF bilateral commitments
(1970-88), $2.3 billion; OPEC bilateral aid (1979-89), $78 million;
Communist countries (1970-89), $106 million
_#_Currency: cedi (plural--cedis); 1 cedi (C) = 100 pesewas
_#_Exchange rates: cedis (C) per US$1--342.91 (November 1990), 270.00
(1989), 202.35 (1988), 153.73 (1987), 89.20 (1986), 54.37 (1985)
_#_Fiscal year: calendar year
_#_Overview: The economy depends heavily on British defense
expenditures, revenue from tourists, fees for services to shipping, and
revenues from banking and finance activities. Because more than 70% of
the economy is in the public sector, changes in government spending have
a major impact on the level of employment. Construction workers are
particularly affected when government expenditures are cut.
_#_GNP: $182 million, per capita $4,600; real growth rate 5% (FY87)
_#_Inflation rate (consumer prices): 3.6% (1988)
_#_Unemployment rate: NA%
_#_Budget: revenues $136 million; expenditures $139 million, including
capital expenditures of NA (FY88)
_#_Exports: $82 million (1988);
commodities--(principally reexports) petroleum 51%, manufactured
goods 41%, other 8%;
partners--UK, Morocco, Portugal, Netherlands, Spain, US, FRG
_#_Imports: $258 million (1988);
commodities--fuels, manufactured goods, and foodstuffs;
partners--UK, Spain, Japan, Netherlands
_#_External debt: $318 million (1987)
_#_Industrial production: growth rate NA%
_#_Electricity: 47,000 kW capacity; 200 million kWh produced,
6,670 kWh per capita (1990)
_#_Industries: tourism, banking and finance, construction, commerce;
support to large UK naval and air bases; transit trade and supply depot
in the port; light manufacturing of tobacco, roasted coffee, ice, mineral
waters, candy, beer, and canned fish
_#_Agriculture: NA
_#_Economic aid: US commitments, including Ex-Im (FY70-88), $0.8
million; Western (non-US) countries, ODA and OOF bilateral commitments
(1970-88), $187 million
_#_Currency: Gibraltar pound (plural--pounds);
1 Gibraltar pound (5G) = 100 pence
_#_Exchange rates: Gibraltar pounds (5G) per US$1--0.5171 (January
1991), 0.5603 (1990), 0.6099 (1989), 0.5614 (1988), 0.6102 (1987), 0.6817
(1986), 0.7714 (1985); note--the Gibraltar pound is at par with the
British pound
_#_Fiscal year: 1 July-30 June
_#_Overview: no economic activity
_#_Overview: Greece has a mixed capitalistic economy with the basic
entrepreneurial system overlaid in 1981-89 by a socialist government
that enlarged the public sector from 55% of GDP in 1981 to about 70%
when Prime Minister Mitsotakis took office. Mitsotakis inherited several
severe economic problems from the preceding socialist and caretaker
governments, which neglected the runaway budget deficit, a ballooning
current account deficit, and accelerating inflation. With only a
two-seat majority in the Chamber of Deputies, Mitsotakis has concentrated
on cutting the public-sector payroll, cautiously expanding the tax base,
and adopting guidelines for privatizing Greece''s loss-ridden state-owned
enterprises. Once the political situation is sorted out, Greece will have
to face the challenges posed by the steadily increasing integration of
the European Community, including the progressive lowering of trade and
investment barriers. Tourism continues as a major industry, providing a
vital offset to the sizable commodity trade deficit.
_#_GDP: $76.7 billion, per capita $7,650; real growth rate 0.9%
(1990)
_#_Inflation rate (consumer prices): 19.0% (1990)
_#_Unemployment rate: 9.0% (1989)
_#_Budget: revenues $20.9 billion; expenditures $34.1 billion,
including capital expenditures of $NA (1990)
_#_Exports: $9.0 billion (f.o.b., 1990);
commodities--manufactured goods, food and live animals, fuels and
lubricants, raw materials;
partners--FRG 20%, Italy 17%, France 8%, UK 7%, US 6%
_#_Imports: $20.2 billion (c.i.f., 1990);
commodities--machinery and transport equipment, light manufactures,
fuels and lubricants, foodstuffs, chemicals;
partners--FRG 21%, Italy 16%, France 8%, Netherlands 7%, UK 6%
_#_External debt: $18.7 billion (1989)
_#_Industrial production: growth rate - 1.0% (1990 est.); accounts
for 22% of GDP
_#_Electricity: 10,500,000 kW capacity; 36,420 million kWh produced,
3,630 kWh per capita (1989)
_#_Industries: food and tobacco processing, textiles, chemicals, metal
products, tourism, mining, petroleum
_#_Agriculture: including fishing and forestry, accounts for 13% of
GNP and 27% of the labor force; principal products--wheat, corn, barley,
sugar beets, olives, tomatoes, wine, tobacco, potatoes, beef, mutton,
pork, dairy products; self-sufficient in food; fish catch of 135,000
metric tons in 1987
_#_Economic aid: US commitments, including Ex-Im (FY70-81), $525
million; Western (non-US) countries, ODA and OOF bilateral commitments
(1970-88), $1.35 billion
_#_Currency: drachma (plur','6b8f184a612e74c7814f62de7645bb66882bc011380f2dd03c3d81b0c9953c3b','internet-archive','theciaworldfactb00025gut','txt','84185fe9df79da427349cc1598fd3f69814a2085a9fc1fe0508a3fae0a870f84','https://archive.org/download/theciaworldfactb00025gut/25.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7b69d47163f02f0b828c60bf8ff3091cd94c8a61a0e2c1eefbc4cbb2362085a0',1991,'GF','French Guiana','economy',75,'al--drachmas); 1 drachma (Dr) = 100 lepta
_#_Exchange rates: drachma (Dr) per US$1--159.87 (January 1991),
158.51 (1990), 162.42 (1989), 141.86 (1988), 135.43 (1987), 139.98
(1986), 138.12 (1985)
_#_Fiscal year: calendar year
_#_Overview: Over the past 25 years, the economy has changed from
one based on subsistence whaling, hunting, and fishing to one dependent
on foreign trade. Fishing is still the most important industry,
accounting for over 75% of exports and about 25% of the
population''s income. Maintenance of a social welfare system similar to
Denmark''s has given the public sector a dominant role in the economy.
In 1990, the economy became critically dependent on shrimp exports and an
annual subsidy (now about $355 million) from the Danish Government
because cod exports had fallen, the zinc and lead mine closed, and
a large promising platinum and gold mine was not yet operational.
Greenland has signed a contract for its largest construction project,
a power plant to supply the capital. To avoid a decline in the economy,
Denmark has agreed to pay 75% of the costs of running Sondrestrom
Airbase and Kulusuk Airfield as civilian bases after the US withdraws
in 1992.
_#_GNP: $500 million, per capita $9,000; real growth rate 5% (1988)
_#_Inflation rate (consumer prices): 4.4% (1989)
_#_Unemployment rate: 9% (1990 est.)
_#_Budget: revenues $381 million; expenditures $381 million, including
capital expenditures of $36 million (1989)
_#_Exports: $417 million (f.o.b., 1989 est.);
commodities--fish and fish products 78%, metallic ores and
concentrates 19%;
partners--Denmark 74%, FRG 11%, Sweden 6%
_#_Imports: $394 million (c.i.f., 1989 est.);
commodities--manufactured goods 36%, machinery and transport
equipment 26%, food products 13%, petroleum and petroleum products
10%;
partners--Denmark 69%, Norway, FRG, Japan, US, Sweden
_#_External debt: $480 million (1990 est.)
_#_Industrial production: growth rate NA%
_#_Electricity: 84,000 kW capacity; 176 million kWh produced,
3,180 kWh per capita (1989)
_#_Industries: fish processing (mainly shrimp), potential for
platinum and gold mining, handicrafts, shipyards
_#_Agriculture: sector dominated by fishing and sheep raising; crops
limited to forage and small garden vegetables; 1988 fish catch of 133,500
metric tons
_#_Economic aid: none
_#_Currency: Danish krone (plural--kroner); 1 Danish krone (DKr)
= 100 ore
_#_Exchange rates: Danish kroner (DKr) per US$1--5.817 (January 1991),
6.189 (1990), 7.310 (1989), 6.732 (1988), 6.840 (1987), 8.091 (1986),
10.596 (1985)
_#_Fiscal year: calendar year
_#_Overview: The economy is essentially agricultural and centers on
the traditional production of spices and tropical plants. Agriculture
accounts for about 16% of GDP and 80% of exports and employs 24% of the
labor force. Tourism is the leading foreign exchange earner, followed by
agricultural exports. Manufacturing remains relatively undeveloped, but
is expected to grow, given a more favorable private investment climate
since 1983. Despite an impressive average annual growth rate for the
economy of 5.6% during the period 1986-90, unemployment remains high
at about 25%.
_#_GDP: $200.7 million, per capita $2,390 (1989); real growth rate
5.4% (1990)
_#_Inflation rate (consumer prices): 7.0% (1990)
_#_Unemployment rate: 25% (1990 est.)
_#_Budget: revenues $54.9 million; expenditures $77.6 million,
including capital expenditures of $16.6 million (1990 est.)
_#_Exports: $27.9 million (f.o.b., 1989 est.);
commodities--nutmeg 36%, cocoa beans 9%, bananas 14%, mace 8%,
textiles 5;
partners--US 12%, UK, FRG, Netherlands, Trinidad and Tobago (1989)
_#_Imports: $115.6 million (c.i.f., 1989 est.);
commodities--food 25%, manufactured goods 22%, machinery 20%,
chemicals 10%, fuel 6% (1989);
partners--US 29%, UK, Trinidad and Tobago, Japan, Canada (1989)
_#_External debt: $90 million (1990 est.)
_#_Industrial production: growth rate 5.8% (1989 est.); accounts
for 6% of GDP
_#_Electricity: 12,500 kW capacity; 26 million kWh produced,
310 kWh per capita (1990)
_#_Industries: food and beverage, textile, light assembly operations,
tourism, construction
_#_Agriculture: accounts for 16% of GDP and 80% of exports; bananas,
cocoa, nutmeg, and mace account for two-thirds of total crop production;
world''s second-largest producer and fourth-largest exporter of nutmeg
and mace; small-size farms predominate, growing a variety of citrus
fruits, avocados, root crops, sugarcane, corn, and vegetables
_#_Economic aid: US commitments, including Ex-Im (FY84-89), $60
million; Western (non-US) countries, ODA and OOF bilateral commitments
(1970-88), $67 million; Communist countries (1970-89), $32 million
_#_Currency: East Caribbean dollar (plural--dollars);
1 EC dollar (EC$) = 100 cents
_#_Exchange rates: East Caribbean dollars (EC$) per US$1--2.70 (fixed
rate since 1976)
_#_Fiscal year: calendar year
_#_Overview: The economy depends on agriculture, tourism, light
industry, and services. It is also dependent upon France for large
subsidies and imports. Tourism is a key industry, with most tourists from
the US. In addition, an increasingly large number of cruise ships visit
the islands. The traditionally important sugarcane crop is slowly being
replaced by other crops, such as bananas (which now supply about 50% of
export earnings), eggplant, and flowers. Other vegetables and root crops
are cultivated for local consumption, although Guadeloupe is still
dependent on imported food, which comes mainly from France. Light
industry consists mostly of sugar and rum production. Most manufactured
goods and fuel are imported. Unemployment is especially high among the
young.
_#_GDP: $1.1 billion, per capita $3,300; real growth rate NA% (1987)
_#_Inflation rate (consumer prices): 2.3% (1988)
_#_Unemployment rate: 38% (1987)
_#_Budget: revenues $254 million; expenditures $254 million, including
capital expenditures of NA (1989)
_#_Exports: $153 million (f.o.b., 1988);
commodities--bananas, sugar, rum;
partners--France 68%, Martinique 22% (1987)
_#_Imports: $1.2 billion (c.i.f., 1988);
commodities--vehicles, foodstuffs, clothing and other consumer
goods, construction materials, petroleum products;
partners--France 64%, Italy, FRG, US (1987)
_#_External debt: $NA
_#_Industrial production: growth rate NA%
_#_Electricity: 171,500 kW capacity; 441 million kWh produced,
1,290 kWh per capita (1990)
_#_Industries: construction, cement, rum, sugar, tourism
_#_Agriculture: cash crops--bananas and sugarcane; other products
include tropical fruits and vegetables; livestock--cattle, pigs, and
goats; not self-sufficient in food
_#_Economic aid: US commitments, including Ex-Im (FY70-88), $4
million; Western (non-US) countries, ODA and OOF bilateral commitments
(1970-88), $7.9 billion
_#_Currency: French franc (plural--francs); 1 French franc (F) = 100
centimes
_#_Exchange rates: French francs (F) per US$1--5.1307 (January 1991),
5.4453 (1990), 6.3801 (1989), 5.9569 (1988), 6.0107 (1987), 6.9261
(1986), 8.9852 (1985)
_#_Fiscal year: calendar year
_#_Overview: The economy is based on US military spending and on
revenues from tourism. Over the past 20 years the tourist industry has
grown rapidly, creating a construction boom for new hotels and the
expansion of older ones. Visitors numbered about 900,000 in 1990. The
small manufacturing sector includes textile and clothing, beverage, food,
and watch production. About 60% of the labor force works for the private
sector and the rest for government. Most food and industrial goods are
imported, with about 75% from the US. In 1990 the unemployment rate was
about 2%, down from 10% in 1983.
_#_GNP: $1.0 billion, per capita $7,000; real growth rate 18%
(1990 est.)
_#_Inflation rate (consumer prices): 10% (1990)
_#_Unemployment rate: 2% (1990 est.)
_#_Budget: revenues $300 million; expenditures $290 million,
including capital expenditures of $25 million (1990 est.)
_#_Exports: $39 million (f.o.b., 1983);
commodities--mostly transshipments of refined petroleum products,
construction materials, fish, food and beverage products;
partners--US 25%, other 75%
_#_Imports: $611 million (c.i.f., 1983);
commodities--petroleum and petroleum products, food, manufactured
goods;
partners--US 77%, other 23%
_#_External debt: $NA
_#_Industrial production: growth rate NA%
_#_Electricity: 500,000 kW capacity; 2,300 million kWh produced,
16,300 kWh per capita (1990)
_#_Industries: US military, tourism, construction, transshipment,
concrete products, printing and publishing, food processing, textiles
_#_Agriculture: relatively undeveloped with most food imported;
fruits, vegetables, eggs, pork, poultry, beef, copra
_#_Economic aid: NA
_#_Currency: US currency is used
_#_Exchange rates: US currency is used
_#_Fiscal year: 1 October-30 September
_#_Overview: The economy is based on agriculture, which accounts for
26% of GDP, employs about 60% of the labor force, and supplies two-thirds
of exports. Manufacturing accounts for about 15% of GDP and 12% of the
labor force. In 1990 the economy grew by 3.5%, the fourth consecutive
year of mild growth. Government economic policies, however, were erratic
in 1990--an election year--and inflation shot up to 60%, the highest
level in modern times.
_#_GDP: $11.1 billion, per capita $1,180; real growth rate 3.5%
(1990 est.)
_#_Inflation rate (consumer prices): 60% (1990 est.)
_#_Unemployment rate: 13%, with 30-40% underemployment (1989 est.)
_#_Budget: revenues $1.05 billion; expenditures $1.3 billion,
including capital expenditures of $270 million (1989 est.)
_#_Exports: $1.24 billion (f.o.b., 1990);
commodities--coffee 24%, sugar 9%, bananas 8%, beef 4%;
partners--US 28%, El Salvador, FRG, Costa Rica, Italy
_#_Imports: $1.77 billion (c.i.f., 1990);
commodities--fuel and petroleum products, machinery, grain,
fertilizers, motor vehicles;
partners--US 40%, Mexico, FRG, Japan, El Salvador
_#_External debt: $2.8 billion (December 1990 est.)
_#_Industrial production: growth rate 4.0% (1988); accounts
for 18% of GDP
_#_Electricity: 819,000 kW capacity; 2,594 million kWh produced,
280 kWh per capita (1990)
_#_Industries: sugar, textiles and clothing, furniture, chemicals,
petroleum, metals, rubber, tourism
_#_Agriculture: accounts for 26% of GDP; most important sector of
economy and contributes two-thirds to export earnings; principal
crops--sugarcane, corn, bananas, coffee, beans, cardamom;
livestock--cattle, sheep, pigs, chickens; food importer
_#_Illicit drugs: illicit producer of opium poppy and cannabis for the
international drug trade; the government has engaged in aerial
eradication of opium poppy; transit country for cocaine shipments
_#_Economic aid: US commitments, including Ex-Im (FY70-90), $1.1
billion; Western (non-US) countries, ODA and OOF bilateral commitments
(1970-88), $7.8 billion
_#_Currency: quetzal (plural--quetzales); 1 quetzal (Q) = 100 centavos
_#_Exchange rates: free market quetzales (Q) per US$1--5.4
(April 1991), 4.4858 (1990), 2.8161 (1989), 2.6196 (1988), 2.500
(1987), 1.875 (1986), 1.000 (1985); note--black-market rate 2.800
(May 1989)
_#_Fiscal year: calendar year
_#_Overview: Tourism is a major source of revenue. Other economic
activity includes financial services, breeding the world-famous
Guernsey cattle, and growing tomatoes and flowers for export.
_#_GDP: $NA, per capita $NA; real growth rate 9% (1987)
_#_Inflation rate (consumer prices): 7% (1988)
_#_Unemployment rate: NA%
_#_Budget: revenues $208.9 million; expenditures $173.9 million,
including capital expenditures of NA (1988)
_#_Exports: $NA;
commodities--tomatoes, flowers and ferns, sweet peppers, eggplant,
other vegetables;
partners--UK (regarded as internal trade)
_#_Imports: $NA;
commodities--coal, gasoline and oil;
partners--UK (regarded as internal trade)
_#_External debt: $NA
_#_Industrial production: growth rate NA%
_#_Electricity: 173,000 kW capacity; 525 million kWh produced,
9,340 kWh per capita (1989)
_#_Industries: tourism, banking
_#_Agriculture: tomatoes, flowers (mostly grown in greenhouses),
sweet peppers, eggplant, other vegetables and fruit; Guernsey cattle
_#_Economic aid: none
_#_Currency: Guernsey pound (plural--pounds);
1 Guernsey (5G) pound = 100 pence
_#_Exchange rates: Guernsey pounds (5G) per US$1--0.5171 (January
1991), 0.5603 (1990), 0.6099 (1989), 0.5614 (1988), 0.6102 (1987), 0.6817
(1986), 0.7714 (1985); note--the Guernsey pound is at par with the
British pound
_#_Fiscal year: calendar year
_#_Overview: Although possessing many natural resources and
considerable potential for agricultural development, Guinea is one of the
poorest countries in the world. The agricultural sector contributes about
40% to GDP and employs more than 80% of the work force, while industry
accounts for 27% of GDP. Guinea possesses over 25% of theworld''s
bauxite reserves; exports of bauxite and alumina accounted for
about 70% of total exports in 1989.
_#_GDP: $2.7 billion, per capita $380; real growth rate 4.4%
(1989 est.)
_#_Inflation rate (consumer prices): 28.2% (1989 est.)
_#_Unemployment rate: NA%
_#_Budget: revenues $394 million; expenditures $548 million, including
capital expenditures of $254 million (1989 est.)
_#_Exports: $645 million (f.o.b., 1989 est.);
commodities--alumina, bauxite, diamonds, coffee, pineapples,
bananas, palm kernels;
partners--US 33%, EC 33%, USSR and Eastern Europe 20%, Canada
_#_Imports: $551 million (c.i.f., 1989 est.);
commodities--petroleum products, metals, machinery, transport
equipment, foodstuffs, textiles and other grain;
partners--US 16%, France, Brazil
_#_External debt: $2.6 billion (1990 est.)
_#_Industrial production: growth rate NA%; accounts for 27% of GDP
_#_Electricity: 113,000 kW capacity; 300 million kWh produced,
40 kWh per capita (1989)
_#_Industries: bauxite mining, alumina, gold, diamond mining,
light manufacturing and agricultural processing industries
_#_Agriculture: accounts for 40% of GDP (includes fishing and
forestry); mostly subsistence farming; principal products--rice, coffee,
pineapples, palm kernels, cassava, bananas, sweet potatoes, timber;
livestock--cattle, sheep and goats; not self-sufficient in food grains
_#_Economic aid: US commitments, including Ex-Im (FY70-89), $227
million; Western (non-US) countries, ODA and OOF bilateral commitments
(1970-87), $1,075 million; OPEC bilateral aid (1979-89), $120 million;
Communist countries (1970-88), $446 million
_#_Currency: Guinean franc (plural--francs);
1 Guinean franc (FG) = 100 centimes
_#_Exchange rates: Guinean francs (FG) per US$1--24.39 (1989),
19.23 (1988), 17.54 (1987), 14.29 (1986), NA (1985)
_#_Fiscal year: calendar year
_#_Overview: Guinea-Bissau ranks among the poorest countries in the
world, with a per capita GDP below $200. Agriculture and fishing are the
main economic activities, with cashew nuts, peanuts, and palm kernels the
primary exports. Exploitation of known mineral deposits is unlikely at
present because of a weak infrastructure and the high cost of
development. The government''s four-year plan (1988-91) has targeted
agricultural development as the top priority.
_#_GDP: $154 million, per capita $160; real growth rate 5.0% (1989)
_#_Inflation rate (consumer prices): 25% (1990 est.)
_#_Unemployment rate: NA%
_#_Budget: revenues $22.7 million; expenditures $30.8 million,
including capital expenditures of $18.0 million (1989 est.)
_#_Exports: $14.2 million (f.o.b., 1989 est.);
commodities--cashews, fish, peanuts, palm kernels;
partners--Portugal, Senegal, France, The Gambia, Netherlands,','75ece928adcb5fdbbeb7c0f67c6eb593865b84121581834a38a8531d3cc2cf99','internet-archive','theciaworldfactb00025gut','txt','84185fe9df79da427349cc1598fd3f69814a2085a9fc1fe0508a3fae0a870f84','https://archive.org/download/theciaworldfactb00025gut/25.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('38f4c500908749a86fc3b58e71b1f353f666bb39bda9e1d5724d057f1f04215b',1991,'FR','France','economy',87,'_#_Industries: tourism, banking and finance, dairy
_#_Agriculture: potatoes, cauliflowers, tomatoes; dairy and cattle
farming
_#_Economic aid: none
_#_Currency: Jersey pound (plural--pounds); 1 Jersey pound (5J) =
100 pence
_#_Exchange rates: Jersey pounds (5J) per US$1--0.5171 (January
1991), 0.5603 (1990), 0.6099 (1989), 0.5614 (1988), 0.6102 (1987), 0.6817
(1986), 0.7714 (1985); the Jersey pound is at par with the British pound
_#_Fiscal year: 1 April-31 March
_#_Overview: Economic activity is limited to providing services to
US military personnel and contractors located on the island. All
food and manufactured goods must be imported.
_#_Electricity: supplied by the United States Military
_#_Overview: Jordan was a secondary beneficiary of the oil boom of
the late 1970s and early 1980s, when its annual GNP growth averaged
10-12%. Recent years, however, have witnessed a sharp reduction in grant
aid from Arab oil-producing countries and a dropoff in worker
remittances, with national growth averaging 1-2%. Imports--mainly oil,
capital goods, consumer durables, and foodstuffs--have been outstripping
exports by roughly $2 billion annually, the difference being made up by
aid, remittances, and borrowing. In mid-1989, the Jordanian Government
agreed to implement an IMF austerity program designed to tackle the
country''s serious economic problems. The program sought to gradually
reduce the government''s budget deficit over the next several years and
implement badly needed structural reforms in the economy. In return for
agreeing to the IMF program, Jordan was granted IMF standby loans of over
$100 million. Recognizing that it would be unable to cover its debt
obligations, the government also began debt rescheduling negotiations
with creditors in mid-1989. The onset of the Gulf crisis in August 1990
forced the government to shelve the IMF program and suspend most debt
payments and rescheduling negotiations. Economic prospects for 1991
are especially gloomy, given the unsettled conditions in the Middle
East.
_#_GNP: $4.6 billion, per capita $1,400; real growth rate - 15%
(1990 est.)
_#_Inflation rate (consumer prices): 15% (1990 est.)
_#_Unemployment rate: 30% (January 1991 est.)
_#_Budget: revenues $1.05 billion; expenditures $1.6 billion,
including capital expenditures of $NA (1991 est.)
_#_Exports: $0.9 billion (f.o.b., 1990 est.);
commodities--fruits and vegetables, phosphates, fertilizers;
partners--Iraq, Saudi Arabia, India, Kuwait, Japan, China,
Yugoslavia, Indonesia
_#_Imports: $2.1 billion (c.i.f., 1990 est.);
commodities--crude oil, textiles, capital goods, motor vehicles,
foodstuffs;
partners--EC, US, Saudi Arabia, Japan, Turkey, Romania, China,
Taiwan
_#_External debt: $8 billion (December 1990 est.)
_#_Industrial production: growth rate - 15% (1990 est.); accounts
for 20% of GDP
_#_Electricity: 981,000 kW capacity; 3,500 million kWh produced,
1,180 kWh per capita (1989)
_#_Industries: phosphate mining, petroleum refining, cement, potash,
light manufacturing
_#_Agriculture: accounts for only 5% of GDP; principal products are
wheat, barley, citrus fruit, tomatoes, melons, olives; livestock--sheep,
goats, poultry; large net importer of food
_#_Economic aid: US commitments, including Ex-Im (FY70-89), $1.7
billion; Western (non-US) countries, ODA and OOF bilateral commitments
(1970-88), $1.3 billion; OPEC bilateral aid (1979-89), $9.5 billion;
Communist countries (1970-89), $44 million
_#_Currency: Jordanian dinar (plural--dinars);
1 Jordanian dinar (JD) = 1,000 fils
_#_Exchange rates: Jordanian dinars (JD) per US$1--0.6670 (January
1991), 0.6636 (1990), 0.5704 (1989), 0.3709 (1988), 0.3387 (1987), 0.3499
(1986), 0.3940 (1985)
_#_Fiscal year: calendar year
_#_Overview: no economic activity
_#_Overview: A serious underlying economic problem is Kenya''s 3.6%
annual population growth rate--one of the highest in the world. In the
meantime, GDP growth in the near term has kept slightly ahead of
population--annually averaging 4.9% in the 1986-90 period. Undependable
weather conditions and a shortage of arable land hamper long-term
growth in agriculture, the leading economic sector.
_#_GDP: $8.5 billion, per capita $360; real growth rate 4% (1990
est.)
_#_Inflation rate (consumer prices): 10.9% (1990 est.)
_#_Unemployment rate: NA%, but there is a high level of unemployment
and underemployment
_#_Budget: revenues $2.0 billion; expenditures $2.3 billion, including
capital expenditures of $NA billion (FY89)
_#_Exports: $1.1 billion (f.o.b., 1990 est.);
commodities--tea 25%, coffee 21%, petroleum products 7% (1989);
partners--EC 44%, Africa 25%, Asia 5%, US 5%, Middle East 4% (1988)
_#_Imports: $2.4 billion (c.i.f., 1990 est.);
commodities--machinery and transportation equipment 29%,
petroleum and petroleum products 15%, iron and steel 7%,
raw materials, food and consumer goods (1989 est.);
partners--EC 45%, Asia 11%, Middle East 12%, US 5% (1988)
_#_External debt: $5.8 billion (December 1990 est.)
_#_Industrial production: growth rate 5.4% (1989 est.); accounts
for 17% of GDP
_#_Electricity: 730,000 kW capacity; 2,700 million kWh produced,
110 kWh per capita (1990)
_#_Industries: small-scale consumer goods (plastic, furniture,
batteries, textiles, soap, cigarettes, flour), agricultural processing,
oil refining, cement, tourism
_#_Agriculture: most important sector, accounting for 29% of GDP,
about 80% of the work force, and over 50% of exports; cash
crops--coffee, tea, sisal, pineapple; food products--corn, wheat,
sugarcane, fruit, vegetables, dairy products; food output not keeping
pace with population growth
_#_Illicit drugs: illicit producer of cannabis used mostly for
domestic consumption; widespread cultivation of cannabis and qat on
small plots; transit country for heroin and methaqualone en route
from Southwest Asia to West Africa, Western Europe, and the US
_#_Economic aid: US commitments, including Ex-Im (FY70-89), $839
million; Western (non-US) countries, ODA and OOF bilateral commitments
(1970-88), $6.7 billion; OPEC bilateral aid (1979-89), $74 million;
Communist countries (1970-89), $83 million
_#_Currency: Kenyan shilling (plural--shillings);
1 Kenyan shilling (KSh) = 100 cents
_#_Exchange rates: Kenyan shillings (KSh) per US$1--24.427 (January
1991), 22.915 (1990), 20.572 (1989), 17.747 (1988), 16.454 (1987), 16.226
(1986), 16.432 (1985)
_#_Fiscal year: 1 July-30 June
_#_Overview: no economic activity
_#_Overview: The country has few national resources. Commercially
viable phosphate deposits were exhausted at the time of independence
in 1979. Copra and fish now represent the bulk of production and exports.
The economy has fluctuated widely in recent years. Real GDP declined
about 8% in 1987, as the fish catch fell sharply to only one-fourth the
level of 1986 and copra production was hampered by repeated rains. Output
rebounded strongly in 1988, with real GDP growing by 17%. The upturn in
economic growth came from an increase in copra production and a good fish
catch. Following the strong surge in output in 1988, GNP increased 1%
in 1989 and again in 1990.
_#_GDP: $36.8 million, per capita $525; real growth rate 1.0% (1990
est.)
_#_Inflation rate (consumer prices): 4.0% (1990 est.)
_#_Unemployment rate: 2% (1985); considerable underemployment
_#_Budget: revenues $29.9 million; expenditures $16.3 million,
including capital expenditures of $14.0 million (1990 est.)
_#_Exports: $5.8 million (f.o.b., 1990 est.);
commodities--fish 55%, copra 42%;
partners--EC 20%, Marshall Islands 12%, US 8%, American
Samoa 4% (1985)
_#_Imports: $26.7 million (c.i.f., 1990 est.);
commodities--foodstuffs, fuel, transportation equipment;
partners--Australia 39%, Japan 21%, NZ 6%, UK 6%, US 3% (1985)
_#_External debt: $2.0 million (December 1989 est.)
_#_Industrial production: growth rate 0.0% (1988 est.); accounts
for less than 4% of GDP
_#_Electricity: 5,000 kW capacity; 13 million kWh produced,
190 kWh per capita (1990)
_#_Industries: fishing, handicrafts
_#_Agriculture: accounts for 30% of GDP (including fishing); copra
and fish contribute about 95% to exports; subsistence farming
predominates; food crops--taro, breadfruit, sweet potatoes, vegetables;
not self-sufficient in food
_#_Economic aid: Western (non-US) countries, ODA and OOF bilateral
commitments (1970-88), $258 million
_#_Currency: Australian dollar (plural--dollars);
1 Australian dollar ($A) = 100 cents
_#_Exchange rates: Australian dollars ($A) per US$1--1.2834 (January
1991), 1.2799 (1990), 1.2618 (1989), 1.2752 (1988), 1.4267 (1987), 1.4905
(1986), 1.4269 (1985)
_#_Fiscal year: NA
_#_Overview: More than 90% of this command economy is socialized;
agricultural land is collectivized; and state-owned industry produces 95%
of manufactured goods. State control of economic affairs is unusually
tight even for a Communist country because of the small size and
homogeneity of the society and the strict one-man rule of Kim. Economic
growth during the period 1984-90 averaged approximately 3%. Abundant
natural resources and hydropower form the basis of industrial
development. Output of the extractive industries includes coal, iron ore,
magnesite, graphite, copper, zinc, lead, and precious metals.
Manufacturing emphasis is centered on heavy industry, with light industry
lagging far behind. Despite the use of high-yielding seed varieties,
expansion of irrigation, and the heavy use of fertilizers, North Korea
has not yet become self-sufficient in food production. Four consecutive
years of poor harvests, coupled with distribution problems, have led to
chronic food shortages. North Korea remains far behind South Korea in
economic development and living standards.
_#_GNP: $29.7 billion, per capita $1,390; real growth rate 2%
(1990 est.)
_#_Inflation rate (consumer prices): NA%
_#_Unemployment rate: officially none
_#_Budget: revenues $15.6 billion; expenditures $15.6 billion,
including capital expenditures of $NA (1989)
_#_Exports: $1.95 billion (f.o.b., 1989);
commodities--minerals, metallurgical products, agricultural
products, manufactures;
partners--USSR, China, Japan, Hong Kong, FRG, Singapore
_#_Imports: $2.85 billion (f.o.b., 1989);
commodities--petroleum, machinery and equipment, coking coal,
grain;
partners--USSR, Japan, China, Hong Kong, FRG, Singapore
_#_External debt: $7 billion (1991)
_#_Industrial production: growth rate NA%
_#_Electricity: 6,440,000 kW capacity; 40,250 million kWh produced,
1,890 kWh per capita (1990)
_#_Industries: machine building, military products, electric power,
chemicals, mining, metallurgy, textiles, food processing
_#_Agriculture: accounts for about 25% of GNP and 36% of work force;
principal crops--rice, corn, potatoes, soybeans, pulses; livestock and
livestock products--cattle, hogs, pork, eggs; not self-sufficient in
grain; fish catch estimated at 1.7 million metric tons in 1987
_#_Economic aid: Communist countries, $1.4 billion a year in the 1980s
_#_Currency: North Korean won (plural--won);
1 North Korean won (Wn) = 100 chon
_#_Exchange rates: North Korean won (Wn) per US$1--2.2 (March 1991),
2.1 (January 1990), 2.3 (December 1989), 2.13 (December 1988), 0.94
(March 1987), NA (1986), NA (1985)
_#_Fiscal year: calendar year
_#_Overview: The driving force behind the economy''s dynamic growth
has been the planned development of an export-oriented economy in a
vigorously entrepreneurial society. Real GNP--which grew by 6.7% in 1989
after an average annual growth of over 12% between 1986-88--grew about
9% in 1990. Labor unrest--which led to substantial wage hikes in
1987-88--was noticeably calmer in 1990, unemployment averaged a low
2.5%, and investment was strong. Inflation rates, however, are beginning
to challenge South Korea''s strong economic performance. Consumer prices
rose 8.6%, the highest rate in nine years. Policymakers are concerned
higher prices could lead to a resurgence of labor unrest.
_#_GNP: $238 billion, per capita $5,600; real growth rate 9% (1990
est.)
_#_Inflation rate (consumer prices): 8.6% (1990)
_#_Unemployment rate: 2.5% (1990)
_#_Budget: revenues $38 billion; expenditures $38 billion,
including capital expenditures of $NA (1991)
_#_Exports: $65 billion (f.o.b., 1990);
commodities--textiles, clothing, electronic and electrical
equipment, footwear, machinery, steel, automobiles, ships, fish;
partners--US 30%, Japan 19%
_#_Imports: $70 billion (c.i.f., 1990);
commodities--machinery, electronics and electronic equipment, oil,
steel, transport equipment, textiles, organic chemicals, grains;
partners--Japan 27%, US 24% (1990)
_#_External debt: $31.7 billion (1990)
_#_Industrial production: growth rate 8.6% (1990 est.); accounts for
about 45% of GDP
_#_Electricity: 21,000,000 kW capacity; 85,000 million kWh produced,
1,970 kWh per capita (1990)
_#_Industries: textiles, clothing, footwear, food processing,
chemicals, steel, electronics, automobile production, ship building
_#_Agriculture: accounts for 11% of GNP and employs 21% of work force
(including fishing and forestry); principal crops--rice, root crops,
barley, vegetables, fruit; livestock and livestock products--cattle,
hogs, chickens, milk, eggs; self-sufficient in food, except for wheat;
fish catch of 2.9 million metric tons, seventh-largest in world
_#_Economic aid: US commitments, including Ex-Im (FY70-89), $3.9
billion; non-US countries (1970-89), $3.0 billion
_#_Currency: South Korean won (plural--won);
1 South Korean won (W) = 100 chon (theoretical)
_#_Exchange rates: South Korean won (W) per US$1--718.14 (January
1991), 707.76 (1990), 671.46 (1989), 731.47 (1988), 822.57 (1987), 881.45
(1986), 870.02 (1985)
_#_Fiscal year: calendar year
_#_Overview: Up to the invasion by Iraq in August 1990, the oil
sector had dominated the economy. Kuwait has the third-largest
oil reserves in the world after Saudi Arabia and Iraq. Earnings from
hydrocarbons generated over 90% of both export and government revenues
and contributed about 40% to GDP. Most of the nonoil sector has
traditionally been dependent upon oil-derived government revenues.
Iraq''s destruction of Kuwait''s oil industry during the Gulf war
has devastated the economy. Iraq destroyed or damaged more than 80%
of Kuwait''s 950 operating oil wells, as well as sabotaging key surface
facilities. Western firefighters had brought about 140 of the 600
oil well fires and blowouts under control as of early June 1991.
It could take two to three years to restore Kuwait''s oil production to
its prewar level of about 2.0 million barrels per day.
_#_GDP: $19.8 billion, per capita $9,700; real growth rate 3.5%
(1989)
_#_Inflation rate (consumer prices): 3.3% (1989)
_#_Unemployment rate: 0% (1989)
_#_Budget: revenues $7.1 billion; expenditures $10.5 billion,
including capital expenditures of $3.1 billion (FY88)
_#_Exports: $11.5 billion (f.o.b., 1989);
commodities--oil 90%;
partners--Japan, Italy, FRG, US
_#_Imports: $6.3 billion (f.o.b., 1989);
commodities--food, construction materials, vehicles and parts,
clothing;
partners--Japan, US, FRG, UK
_#_External debt: $7.2 billion (December 1989 est.)
_#_Industrial production: growth rate 3% (1988); accounts for
52% of GDP
_#_Electricity: 8,290,000 kW capacity; 10,000 million kWh produced,
5,000 kWh per capita (1989)
_#_Industries: petroleum, petrochemicals, desalination, food
processing, salt, construction
_#_Agriculture: virtually none; dependent on imports for food; about
75% of potable water must be distilled or imported
_#_Economic aid: donor--pledged $18.3 billion in bilateral aid to less
developed countries (1979-89)
_#_Currency: Kuwaiti dinar (plural--dinars);
1 Kuwaiti dinar (KD) = 1,000 fils
_#_Exchange rates: Kuwaiti dinars (KD) per US$1--0.2915 (January
1990), 0.2937 (1989), 0.2790 (1988), 0.2786 (1987), 0.2919 (1986), 0.3007
(1985)
_#_Fiscal year: 1 July-30 June
_#_Overview: One of the world''s poorest nations, Laos has had a
Communist centrally planned economy with government ownership and control
of productive enterprises of any size. Recently, however, the government
has been decentralizing control and encouraging private enterprise.
Laos is a landlocked country with a primitive infrastructure, that is,
it has no railroads, a rudimentary road system, limited external and
internal telecommunications, and electricity available in only a
limited area. Subsistence agriculture is the main occupation,
accounting for over 60% of GDP and providing about 85-90% of
total employment. The predominant crop is rice. For the foreseeable
future the economy will continue to depend for its survival on foreign
aid from the IMF and other international sources; foreign aid from the
USSR and Eastern Europe is being cut sharply.
_#_GDP: $600 million, per capita $150; real growth rate 5% (1990 est.)
_#_Inflation rate (consumer prices): 22% (1990 est.)
_#_Unemployment rate: 21% (1989 est.)
_#_Budget: revenues $83 million; expenditures $188.5 million,
including capital expenditures of $94 million (1990 est.)
_#_Exports: $72 million (f.o.b., 1990 est.);
commodities--electricity, wood products, coffee, tin;
partners--Thailand, Malaysia, Vietnam, USSR, US
_#_Imports: $238 million (c.i.f., 1990 est.);
commodities--food, fuel oil, consumer goods, manufactures;
partners--Thailand, USSR, Japan, France, Vietnam
_#_External debt: $1.1 billion (1990 est.)
_#_Industrial production: growth rate 8% (1989 est.); accounts
for about 20% of GDP
_#_Electricity: 176,000 kW capacity; 1,100 million kWh produced,
270 kWh per capita (1990)
_#_Industries: tin mining, timber, electric power, agricultural
processing, construction
_#_Agriculture: accounts for 60% of GDP and employs most of the
work force; subsistence farming predominates; normally self-sufficient
in non-drought years; principal crops--rice (80% of cultivated land),
sweet potatoes, vegetables, corn, coffee, sugarcane, cotton;
livestock--buffaloes, hogs, cattle, chicken
_#_Illicit drugs: illicit producer of cannabis and opium poppy for the
international drug trade
_#_Economic aid: US commitments, including Ex-Im (FY70-79), $276
million; Western (non-US) countries, ODA and OOF bilateral commitments
(1970-88), $546 million; Communist countries (1970-89), $995 million
_#_Currency: new kip (plural--kips); 1 new kip (NK) = 100 at
_#_Exchange rates: new kips (NK) per US$1--695 (April 1991),
700 (September 1990), 576 (1989), 385 (1988), 200 (1987), 108 (1986),
95 (1985)
_#_Fiscal year: 1 July-30 June
_#_Overview: Since 1975 civil war has seriously damaged Lebanon''s
economic infrastructure, disrupted economic activity, and all but ended
Lebanon''s position as a Middle Eastern entrepot and banking hub.
Following October 1990, however, a tentative peace has enabled the
central government to begin restoring control in Beirut, collect taxes,
and regain access to key port and government facilities. The battered
economy has also been propped up by a financially sound banking system
and resilient small- and medium-scale manufacturers. Family remittances,
foreign financial support to political factions, the narcotics trade, and
international emergency aid are main sources of foreign exchange.
Economic prospects for 1991 have brightened, particularly if the
Syrian-backed government is able to maintain law and order and
reestablish business confidence. Rebuilding war-ravaged Beirut is likely
to provide a major stimulus to the Lebanese economy in 1991.
_#_GDP: $3.3 billion, per capita $1,000; real growth rate - 15%
(1990 est.)
_#_Inflation rate (consumer prices): 100% (1990 est.)
_#_Unemployment rate: 35% (1990 est.)
_#_Budget: revenues $120 million; expenditures $1.0 billion, including
capital expenditures of $NA (1990 est.)
_#_Exports: $1.0 billion (f.o.b., 1989 est.);
commodities--agricultural products, chemicals, textiles, precious
and semiprecious metals and jewelry, metals and metal products;
partners--Saudi Arabia 16%, Switzerland 8%, Jordan 6%, Kuwait 6%,
US 5%
_#_Imports: $1.9 billion (c.i.f., 1989 est.);
commodities--NA;
partners--Italy 14%, France 12%, US 6%, Turkey 5%, Saudi Arabia 3%
_#_External debt: $900 million (1990 est.)
_#_Industrial production: growth rate NA%
_#_Electricity: 1,381,000 kW capacity; 3,870 million kWh produced,
1,170 kWh per capita (1989)
_#_Industries: banking, food processing, textiles, cement, oil
refining, chemicals, jewelry, some metal fabricating
_#_Agriculture: accounts for about one-third of GDP; principal
products--citrus fruits, vegetables, potatoes, olives, tobacco, hemp
(hashish), sheep, and goats; not self-sufficient in grain
_#_Illicit drugs: illicit producer of opium poppy and cannabis for the
international drug trade; opium poppy production in Al Biqa
is increasing; hashish production is shipped to Western Europe, Israel,
and the Middle East
_#_Economic aid: US commitments, including Ex-Im (FY70-88), $356
million; Western (non-US) countries, ODA and OOF bilateral commitments
(1970-88), $608 million; OPEC bilateral aid (1979-89), $962 million;
Communist countries (1970-89), $9 million
_#_Currency: Lebanese pound (plural--pounds);
1 Lebanese pound (5L) = 100 piasters
_#_Exchange rates: Lebanese pounds (5L) per US$1--974.22 (January
1991), 695.09 (1990), 496.69 (1989), 409.23 (1988), 224.60 (1987), 38.37
(1986), 16.42 (1985)
_#_Fiscal year: calendar year
_#_Overview: Small, landlocked, and mountainous, Lesotho has no
important natural resources other than water. Its economy is based on
agriculture, light manufacturing, and remittances from laborers employed
in South Africa ($153 million in 1989). The great majority of households
gain their livelihoods from subsistence farming and migrant labor.
Manufacturing depends largely on farm products to support the milling,
canning, leather, and jute industries; other industries include textile,
clothing, and light engineering. Industry''s share of GDP rose from
6% in 1982 to 15% in 1989. Political and economic instability in South
Africa raise uncertainties for Lesotho''s economy, especially with respect
to migrant worker remittances--over one-third of GDP.
_#_GDP: $420 million, per capita $240; real growth rate 4.0% (1990
est.)
_#_Inflation rate (consumer prices): 15% (1990 est.)
_#_Unemployment rate: 23% (1988)
_#_Budget: revenues $280 million; expenditures $288 million, including
capital expenditures of $NA (FY92 est.)
_#_Exports: $66 million (f.o.b., 1989);
commodities--wool, mohair, wheat, cattle, peas, beans, corn, hides,
skins, baskets;
partners--South Africa 53%, EC 30%, North and South America 13%
(1989)
_#_Imports: $499 million (f.o.b., 1989);
commodities--mainly corn, building materials, clothing, vehicles,
machinery, medicines, petroleum, oil, and lubricants;
partners--South Africa 95%, EC 2% (1989)
_#_External debt: $370 million (December 1990 est.)
_#_Industrial production: growth rate 7.8% (1989 est.); accounts
for 15% of GDP
_#_Electricity: power supplied by South Africa
_#_Industries: food, beverages, textiles, handicrafts, tourism
_#_Agriculture: accounts for 18% of GDP and employs 60-70% of
all households; exceedingly primitive, mostly subsistence farming and
livestock; principal crops are corn, wheat, pulses, sorghum, barley
_#_Economic aid: US commitments, including Ex-Im (FY70-89), $268
million; Western (non-US) countries, ODA and OOF bilateral commitments
(1970-88), $754 million; OPEC bilateral aid (1979-89), $4 million;
Communist countries (1970-89), $14 million
_#_Currency: loti (plural--maloti); 1 loti (L) = 100 lisente
_#_Exchange rates: maloti (M) per US$1--2.5625 (January 1991),
2.5863 (1990), 2.6166 (1989), 2.2611 (1988), 2.0350 (1987), 2.2685
(1986), 2.1911 (1985); note--the Basotho loti is at par with the South
African rand
_#_Fiscal year: 1 April-31 March
_#_Overview: Civil war during 1990 destroyed much of Liberia''s
economy, especially the infrastructure in and around Monrovia. Expatriate
businessmen fled the country, taking capital and expertise with them.
Many will not return. Richly endowed with water, mineral resources,
forests, and a climate favorable to agriculture, Liberia had','49874dcb4d721a2ed1e001eee1c6d6e4f06417b335554e38e7efb520d86ee254','internet-archive','theciaworldfactb00025gut','txt','84185fe9df79da427349cc1598fd3f69814a2085a9fc1fe0508a3fae0a870f84','https://archive.org/download/theciaworldfactb00025gut/25.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('78040fec701de3881cefd63b9da075cba72b4b3bf56b50c9ceb8adbe7cd31d6a',1991,'FR','France','economy',88,'been a
producer and exporter of basic products, while local manufacturing,
mainly foreign owned, had been small in scope. Political instability
threatens prospects for economic reconstruction and repatriation of
some 750,000 Liberian refugees who fled to neighboring countries.
_#_GDP: $988 million, per capita $400; real growth rate 1.5% (1988)
_#_Inflation rate (consumer prices): 12% (1989)
_#_Unemployment rate: 43% urban (1988)
_#_Budget: revenues $242.1 million; expenditures $435.4 million,
including capital expenditures of $29.5 million (1989)
_#_Exports: $505 million (f.o.b., 1989 est.);
commodities--iron ore 61%, rubber 20%, timber 11%, coffee;
partners--US, EC, Netherlands
_#_Imports: $394 million (c.i.f., 1989 est.);
commodities--rice, mineral fuels, chemicals, machinery,
transportation equipment, other foodstuffs;
partners--US, EC, Japan, China, Netherlands, ECOWAS
_#_External debt: $1.6 billion (December 1990 est.)
_#_Industrial production: growth rate 1.5% in manufacturing (1987);
accounts for 22% of GDP
_#_Electricity: 400,000 kW capacity; 730 million kWh produced,
290 kWh per capita (1989)
_#_Industries: rubber processing, food processing, construction
materials, furniture, palm oil processing, mining (iron ore, diamonds)
_#_Agriculture: accounts for about 40% of GDP (including fishing and
forestry); principal products--rubber, timber, coffee, cocoa, rice,
cassava, palm oil, sugarcane, bananas, sheep, and goats; not
self-sufficient in food, imports 25% of rice consumption
_#_Economic aid: US commitments, including Ex-Im (FY70-89), $665
million; Western (non-US) countries, ODA and OOF bilateral commitments
(1970-88), $853 million; OPEC bilateral aid (1979-89), $25 million;
Communist countries (1970-89), $77 million
_#_Currency: Liberian dollar (plural--dollars);
1 Liberian dollar (L$) = 100 cents
_#_Exchange rates: Liberian dollars (L$) per US$1--1.00 (fixed rate
since 1940); unofficial parallel exchange rate of L$2.5 = US$1, January
1989
_#_Fiscal year: calendar year
_#_Overview: The socialist-oriented economy depends primarily upon
revenues from the oil sector, which contributes practically all export
earnings and about one-third of GNP. Since 1980, however, the sharp
drop in oil prices and the resulting decline in export revenues have
adversely affected economic development. In 1988 per capita GNP was the
highest in Africa at $5,410, but it had been $2,000 higher in 1982.
Severe cutbacks in imports over the past five years have led to shortages
of basic goods and foodstuffs, although the reopening of the
Libyan-Tunisian border in April 1988 and the Libyan-Egyptian border in
December 1989 have somewhat eased shortages. Austerity budgets and a lack
of trained technicians have undermined the government''s ability to
implement a number of planned infrastructure development projects.
Windfall profits from the hike in world oil prices in late 1990 improved
the foreign payments position and may permit Tripoli to ease austerity
measures. The nonoil industrial and construction sectors, which account
for about 22% of GDP, have expanded from processing mostly agricultural
products to include petrochemicals, iron, steel, and aluminum. Although
agriculture accounts for less than 5% of GNP, it employs 18% of the labor
force. Climatic conditions and poor soils severely limit farm output,
requiring Libya to import about 75% of its food requirements.
_#_GNP: $24 billion, per capita $5,860; real growth rate 3% (1989
est.)
_#_Inflation rate (consumer prices): 20% (1988 est.)
_#_Unemployment rate: 2% (1988 est.)
_#_Budget: revenues $8.1 billion; expenditures $9.8 billion, including
capital expenditures of $3.1 billion (1989 est.)
_#_Exports: $6.1 billion (f.o.b., 1989 est.);
commodities--petroleum, peanuts, hides;
partners--Italy, USSR, FRG, Spain, France, Belgium/Luxembourg,
Turkey
_#_Imports: $6.2 billion (f.o.b., 1989 est.);
commodities--machinery, transport equipment, food, manufactured
goods;
partners--Italy, USSR, FRG, UK, Japan
_#_External debt: $3.5 billion, excluding military debt (December
1990 est.)
_#_Industrial production: growth rate NA%; accounts for 43% of GDP
(including oil)
_#_Electricity: 4,705,000 kW capacity; 13,600 million kWh produced,
3,220 kWh per capita (1990)
_#_Industries: petroleum, food processing, textiles, handicrafts,
cement
_#_Agriculture: 5% of GNP; cash crops--wheat, barley, olives, dates,
citrus fruits, peanuts; 75% of food is imported
_#_Economic aid: Western (non-US) countries, ODA and OOF bilateral
commitments (1970-87), $242 million; no longer a recipient
_#_Currency: Libyan dinar (plural--dinars);
1 Libyan dinar (LD) = 1,000 dirhams
_#_Exchange rates: Libyan dinars (LD) per US$1--0.2669 (January 1991),
0.2699 (1990), 0.2922 (1989), 0.2853 (1988), 0.2706 (1987), 0.3139
(1986), 0.2961 (1985)
_#_Fiscal year: calendar year
_#_Overview: The prosperous economy is based primarily on small-scale
light industry and tourism. Industry accounts for 54% of total
employment, the service sector 42% (mostly based on tourism), and
agriculture and forestry 4%. The sale of postage stamps to collectors is
estimated at $10 million annually. Low business taxes (the maximum tax
rate is 20%) and easy incorporation rules have induced about 25,000
holding or so-called letter box companies to establish nominal offices in
Liechtenstein. Such companies, incorporated solely for tax purposes,
provide 30% of state revenues. The economy is tied closely to that of
Switzerland in a customs union, and incomes and living standards parallel
those of the more prosperous Swiss groups.
_#_GDP: $630 million, per capita $22,300; real growth rate NA% (1990
est.)
_#_Inflation rate (consumer prices): 3.0% (1989 est.)
_#_Unemployment rate: 0.1% (December 1986)
_#_Budget: revenues $240 million; expenditures $197 million, including
capital expenditures of NA (1988)
_#_Exports: $1.28 billion (1988);
commodities--small specialty machinery, dental products, stamps,
hardware, pottery;
partners--EC 40%, EFTA 22% (Switzerland 18%) (1988)
_#_Imports: $NA;
commodities--machinery, metal goods, textiles, foodstuffs, motor
vehicles;
partners--NA
_#_External debt: $NA
_#_Industrial production: growth rate NA%
_#_Electricity: 23,000 kW capacity; 150 million kWh produced,
5,340 kWh per capita (1989)
_#_Industries: electronics, metal manufacturing, textiles, ceramics,
pharmaceuticals, food products, precision instruments, tourism
_#_Agriculture: livestock, vegetables, corn, wheat, potatoes, grapes
_#_Economic aid: none
_#_Currency: Swiss franc, franken, or franco (plural--francs, franken,
or franchi); 1 Swiss franc, franken, or franco (SwF) = 100 centimes,
rappen, or centesimi
_#_Exchange rates: Swiss francs, franken, or franchi (SwF) per
US$1--1.2724 (January 1991), 1.3892 (1990), 1.6359 (1989), 1.4633 (1988),
1.4912 (1987), 1.7989 (1986), 2.4571 (1985)
_#_Fiscal year: calendar year
_#_Industries: tourism, pharmaceuticals, precision instruments,
glassmaking, printing, finance
_#_Agriculture: NA
_#_Economic aid: NA
_#_Currency: French franc (plural--francs); 1 French franc (F) = 100
centimes
_#_Exchange rates: French francs (F) per US$1--5.1307 (January 1991),
5.4453 (1990), 6.3801 (1989), 5.9569 (1988), 6.0107 (1987), 6.9261
(1986), 8.9852 (1985)
_#_Fiscal year: calendar year
_#_Overview: Economic activity traditionally has been based on
agriculture and the breeding of livestock--Mongolia has the highest
number of livestock per person in the world. In recent years extensive
mineral resources have been developed with Soviet support. The mining and
processing of coal, copper, molybdenum, tin, tungsten, and gold
account for a large part of industrial production. In early 1991 the
Mongolian leadership was struggling with severe economic dislocations,
mainly attributable to chaotic economic conditions in the USSR, by
far Mongolia''s leading trade and development partner. For example,
the government doubled most prices in January 1991, and industrial
production dropped 10% in the first quarter of 1991. Moscow almost
certainly will be cutting aid in 1991.
_#_GDP: $2.2 billion, per capita $1,000 (1990 est.); real
growth rate NA%
_#_Inflation rate (consumer prices): NA%
_#_Unemployment rate: 10% (February 1991)
_#_Budget: deficit of $240 million (1991 est.)
_#_Exports: $784 million (f.o.b., 1988);
commodities--livestock, animal products, wool, hides, fluorspar,
nonferrous metals, minerals;
partners--nearly all trade with Communist countries (about 80%
with USSR)
_#_Imports: $1.14 billion (f.o.b., 1988);
commodities--machinery and equipment, fuels, food products,
industrial consumer goods, chemicals, building materials, sugar, tea;
partners--nearly all trade with Communist countries (about 80% with
USSR)
_#_External debt: $16.8 billion (yearend 1990); 98.6% with USSR
_#_Industrial production: growth rate NA%
_#_Electricity: 657,000 kW capacity; 2,950 million kWh produced,
1,380 kWh per capita (1990)
_#_Industries: copper, processing of animal products, building
materials, food and beverage, mining (particularly coal)
_#_Agriculture: accounts for about 20% of GDP and provides livelihood
for about 50% of the population; livestock raising predominates (sheep,
goats, horses); crops--wheat, barley, potatoes, forage
_#_Economic aid: about $300 million in trade credits and $34 million
in grant aid from USSR and other CEMA countries, plus $7.4 million
from UNDP (1990)
_#_Currency: tughrik (plural--tughriks); 1 tughrik (Tug) = 100 mongos
_#_Exchange rates: tughriks (Tug) per US$1--7.1 (1991), 5.63 (1990),
3.00 (1989)
_#_Fiscal year: calendar year
_#_Overview: The economy is small and open with economic activity
centered on tourism and construction. Tourism is the most important
sector and accounted for 20% of GDP in 1986. Agriculture accounted for
about 4% of GDP and industry 10%. The economy is heavily dependent on
imports, making it vulnerable to fluctuations in world prices. Exports
consist mainly of electronic parts sold to the US.
_#_GDP: $54.2 million, per capita $4,500; real growth rate 12% (1988
est.)
_#_Inflation rate (consumer prices): 3.6% (1988)
_#_Unemployment rate: 3.0% (1987)
_#_Budget: revenues $12.1 million; expenditures $14.3 million,
including capital expenditures of $3.2 million (1988)
_#_Exports: $2.3 million (f.o.b., 1988 est.);
commodities--electronic parts, plastic bags, apparel, hot peppers,
live plants, cattle;
partners--NA
_#_Imports: $30 million (c.i.f., 1988 est.);
commodities--machinery and transportation equipment, foodstuffs,
manufactured goods, fuels, lubricants, and related materials;
partners--NA
_#_External debt: $2.05 million (1987)
_#_Industrial production: growth rate 8.1% (1986); accounts for
10% of GDP
_#_Electricity: 5,270 kW capacity; 12.2 million kWh produced,
980 kWh per capita (1990)
_#_Industries: tourism; light manufacturing--rum, textiles, electronic
appliances
_#_Agriculture: accounts for 4% of GDP; small-scale farming; food
crops--tomatoes, onions, peppers; not self-sufficient in food, especially
livestock products
_#_Economic aid: Western (non-US) countries, ODA and OOF bilateral
commitments (1970-88), $75 million
_#_Currency: East Caribbean dollar (plural--dollars);
1 EC dollar (EC$) = 100 cents
_#_Exchange rates: East Caribbean dollars (EC$) per US$1--2.70 (fixed
rate since 1976)
_#_Fiscal year: 1 April-31 March
_#_Overview: The economy recovered moderately in 1990 because
of the resolution of a trade dispute with India over phosphoric
acid sales, a rebound in textile sales to the EC, and lower prices for
food imports. In addition, a dramatic increase in worker remittances,
increased Arab donor aid, and generous debt rescheduling agreements
helped ease foreign payments pressures. On the down side, higher oil
import costs fueled inflation. Servicing the $21 billion foreign debt,
high unemployment, and Morocco''s vulnerability to external forces
remain severe problems for the 1990s.
_#_GDP: $25.4 billion, per capita $990; real growth rate 2.5% (1990
est.)
_#_Inflation rate (consumer prices): 6.6% (1990 est.)
_#_Unemployment rate: 16% (1990 est.)
_#_Budget: revenues $6.6 billion; expenditures $7.3 billion, including
capital expenditures of $1.8 billion (1990 est.)
_#_Exports: $4.0 billion (f.o.b., 1990 est.);
commodities--food and beverages 30%, semiprocessed goods 23%,
consumer goods 21%, phosphates 17%;
partners--EC 58%, India 7%, Japan 5%, USSR 3%, US 2%
_#_Imports: $5.9 billion (f.o.b., 1990 est.);
commodities--capital goods 24%, semiprocessed goods 22%, raw
materials 16%, fuel and lubricants 16%, food and beverages 13%,
consumer goods 9%;
partners--EC 53%, US 11%, Canada 4%, Iraq 3%, USSR 3%, Japan 2%
_#_External debt: $21 billion (1990)
_#_Industrial production: growth rate 4% (1989 est.); accounts
for an estimated 20% of GDP
_#_Electricity: 2,262,000 kW capacity; 8,140 million kWh produced,
320 kWh per capita (1990)
_#_Industries: phosphate rock mining and processing, food processing,
leather goods, textiles, construction, tourism
_#_Agriculture: 50% of employment and 30% of export value; not
self-sufficient in food; cereal farming and livestock raising
predominate; barley, wheat, citrus fruit, wine, vegetables, olives;
fishing catch of 491,000 metric tons in 1987
_#_Illicit drugs: illicit producer of cannabis; trafficking on
the increase for both domestic and international drug markets; shipments
of cannabis mostly directed to Western Europe; occasional transit point
for cocaine from South America destined for Western Europe.
_#_Economic aid: US commitments, including Ex-Im (FY70-89), $1.3
billion; Western (non-US) countries, ODA and OOF bilateral commitments
(1970-88), $7.0 billion; OPEC bilateral aid (1979-89), $4.8 billion;
Communist countries (1970-89), $2.5 billion
_#_Currency: Moroccan dirham (plural--dirhams);
1 Moroccan dirham (DH) = 100 centimes
_#_Exchange rates: Moroccan dirhams (DH) per US$1--8.071 (January
1991), 8.242 (1990), 8.488 (1989), 8.209 (1988), 8.359 (1987), 9.104
(1986), 10.062 (1985)
_#_Fiscal year: calendar year
_#_Overview: One of Africa''s poorest countries, with a per capita GDP
of little more than $100, Mozambique has failed to exploit the economic
potential of its sizable agricultural, hydropower, and transportation
resources. Indeed, national output, consumption, and investment declined
throughout the first half of the 1980s because of internal disorders,
lack of government administrative control, and a growing foreign debt.
A sharp increase in foreign aid, attracted by an economic reform policy,
has resulted in successive years of economic growth since 1985.
Agricultural output, nevertheless, is at about only 75% of its 1981
level, and grain has to be imported. Industry operates at only 20-40% of
capacity. The economy depends heavily on foreign assistance to keep
afloat.
_#_GDP: $1.6 billion, per capita $110; real growth rate 5.0%
(1989 est.)
_#_Inflation rate (consumer prices): 22.9% (1990 est.)
_#_Unemployment rate: 50% (1989 est.)
_#_Budget: revenues $186 million; expenditures $239 million,
including capital expenditures of $208 million (1988 est.)
_#_Exports: $90 million (f.o.b., 1989 est.);
commodities--shrimp 48%, cashews 21%, sugar 10%, copra 3%,
citrus 3%;
partners--US, Western Europe, GDR, Japan
_#_Imports: $764 million (c.i.f., 1989 est.), including aid;
commodities--food, clothing, farm equipment, petroleum;
partners--US, Western Europe, USSR
_#_External debt: $5.1 billion (1990 est.)
_#_Industrial production: growth rate 5% (1989 est.)
_#_Electricity: 2,265,000 kW capacity; 1,740 million kWh produced,
120 kWh per capita (1989)
_#_Industries: food, beverages, chemicals (fertilizer, soap, paints),
petroleum products, textiles, nonmetallic mineral products (cement,
glass, asbestos), tobacco
_#_Agriculture: accounts for 90% of the labor force, 50% of GDP,
and about 90% of exports; cash crops--cotton, cashew nuts, sugarcane,
tea, shrimp; other crops--cassava, corn, rice, tropical fruits; not
self-sufficient in food
_#_Economic aid: US commitments, including Ex-Im (FY70-89), $350
million; Western (non-US) countries, ODA and OOF bilateral commitments
(1970-88), $3.8 billion; OPEC bilateral aid (1979-89), $37 million;
Communist countries (1970-89), $890 million
_#_Currency: metical (plural--meticais); 1 metical (Mt) = 100 centavos
_#_Exchange rates: meticais (Mt) per US$1--1,700 (November 1990),
800.00 (1989), 528.60 (1988), 289.44 (1987), 40.43 (1986), 43.18 (1985)
_#_Fiscal year: calendar year
_#_Overview: The economy is heavily dependent on the mining industry
to extract and process minerals for export. Mining accounts for almost
30% of GDP. Namibia is the fourth-largest exporter of nonfuel minerals in
Africa and the world''s fifth-largest producer of uranium. Alluvial
diamond deposits are among the richest in the world, making Namibia a
primary source for gem-quality diamonds. Namibia also produces large
quantities of lead, zinc, tin, silver, and tungsten, and it has
substantial resources of coal. More than half the population depends
on agriculture (largely subsistence agriculture) for its livelihood.
_#_GNP: $1.8 billion, per capita $1,240; real growth rate - 2.0%
(1990 est.)
_#_Inflation rate (consumer prices): 15.1% (1989)
_#_Unemployment rate: over 30% (1990)
_#_Budget: revenues $794.1 million; expenditures $999.6 million,
including capital expenditures of $NA (FY91 est.)
_#_Exports: $1,021 million (f.o.b., 1989);
commodities--uranium, diamonds, zinc, copper, cattle, processed
fish, karakul skins;
partners--Switzerland, South Africa, FRG, Japan
_#_Imports: $894 million (f.o.b., 1989);
commodities--foodstuffs, petroleum products and fuel, machinery and
equipment;
partners--South Africa, FRG, US, Switzerland
_#_External debt: about $27 million at independence; under a 1971
International Court of Justice (ICJ) ruling, Namibia may not be
liable for debt incurred during its colonial period
_#_Industrial production: growth rate NA%
_#_Electricity: 486,000 kW capacity; 1,280 million kWh produced,
930 kWh per capita (1989)
_#_Industries: meatpacking, fish processing, dairy products, mining
(copper, lead, zinc, diamond, uranium)
_#_Agriculture: mostly subsistence farming; livestock raising major
source of cash income; crops--millet, sorghum, peanuts; fish catch
potential of over 1 million metric tons not being fulfilled, 1987 catch
reaching only 520,000 metric tons; not self-sufficient in food
_#_Economic aid: Western (non-US) countries, ODA and OOF bilateral
commitments (1970-87), $47.2 million
_#_Currency: South African rand (plural--rand);
1 South African rand (R) = 100 cents
_#_Exchange rates: South African rand (R) per US$1--2.625 (January
1991), 2.5863 (1990), 2.6166 (1989), 2.2611 (1988), 2.0350 (1987), 2.2685
(1986), 2.1911 (1985)
_#_Fiscal year: 1 April-31 March
_#_Overview: Revenues come from the export of phosphates, the reserves
of which are expected to be exhausted by the year 2000. Phosphates have
given Nauruans one of the highest per capita incomes in the Third
World--$10,000 annually. Few other resources exist so
most necessities must be imported, including fresh water from
Australia. The rehabilitation of mined land and the replacement of income
from phosphates constitute serious long-term problems. Substantial
investment in trust funds, out of phosphate income, will help cushion the
transition.
_#_GNP: over $90 million, per capita $10,000; real growth rate NA%
(1989)
_#_Inflation rate (consumer prices): NA%
_#_Unemployment rate: 0%
_#_Budget: revenues $69.7 million; expenditures $51.5 million,
including capital expenditures of $NA (FY86 est.)
_#_Exports: $93 million (f.o.b., 1984);
commodities--phosphates;
partners--Australia, NZ
_#_Imports: $73 million (c.i.f., 1984);
commodities--food, fuel, manufactures, building materials,
machinery;
partners--Australia, UK, NZ, Japan
_#_External debt: $33.3 million
_#_Industrial production: growth rate NA%
_#_Electricity: 14,000 kW capacity; 50 million kWh produced,
5,430 kWh per capita (1990)
_#_Industries: phosphate mining, financial services, coconuts
_#_Agriculture: negligible; almost completely dependent on imports for
food and water
_#_Economic aid: Western (non-US) countries (1970-1988), $2 million
_#_Currency: Australian dollar (plural--dollars);
1 Australian dollar ($A) = 100 cents
_#_Exchange rates: Australian dollars ($A) per US$1--1.2834 (January
1991), 1.2799 (1990), 1.2618 (1989), 1.2752 (1988), 1.4267 (1987), 1.4905
(1986), 1.4269 (1985)
_#_Fiscal year: 1 July-30 June
_#_Overview: no economic activity
_#_Overview: Nepal is among the poorest and least developed countries
in the world with a per capita income of less than $200. Real growth
averaged 4% in the 1980s until FY89, when it plunged to 1.5% because of
a trade/transit dispute with India. Though the impasse is over,
political turmoil and inflated energy costs will probably constrain
growth to under 4%. Agriculture is the mainstay of the economy,
providing a livelihood for over 90% of the population and
accounting for 60% of GDP. Industrial activity is limited, mainly
involving the processing of agricultural produce (jute, sugarcane,
tobacco, and grain). Production of textiles and carpets has expanded
recently and accounted for 87% of foreign exchange earnings in FY89.
Apart from agricultural land and forests, the only other exploitable
natural resources are mica, hydropower, and tourism. Agricultural
production in the late 1980s grew by about 5%, compared
with a population growth of 2.6%. Forty percent or more of the
population is undernourished partly because of poor distribution.
Economic prospects for the 1990s are poor, with economic growth
probably outpacing population growth only slightly.
_#_GDP: $3.0 billion, per capita $160; real growth rate 2.1% (FY90)
_#_Inflation rate (consumer prices): 10.0% (FY90 est.)
_#_Unemployment rate: 5%; underemployment estimated at 25-40% (1987)
_#_Budget: revenues $316.5 million; expenditures $618.5 million,
including capital expenditures of $398 (FY91 est.)
_#_Exports: $125 million (f.o.b., FY90), but does not include
unrecorded border trade with India;
commodities--clothing, carpets, leather goods, grain;
partners--India 38%, US 23%, UK 6%, other Europe 9% (FY88)
_#_Imports: $454.3illion (c.i.f., FY90 est.);
commodities--petroleum products 20%, fertilizer 11%, machinery 10%;
partners--India 36%, Japan 13%, Europe 4%, US 1% (FY88)
_#_External debt: $2.5 billion (April 1990 est.)
_#_Industrial production: growth rate 6% (FY90 est.); accounts
for 7% of GDP
_#_Electricity: 280,000 kW capacity; 540 million kWh produced,
30 kWh per capita (1990)
_#_Industries: small rice, jute, sugar, and oilseed mills; cigarette,
textiles, carpets, cement, brick; tourism
_#_Agriculture: accounts for 60% of GDP and 90% of work force; farm
products--rice, corn, wheat, sugarcane, root crops, milk, buffalo meat;
not self-sufficient in food, particularly in drought years
_#_Illicit drugs: illicit producer of cannabis for the domestic and
international drug markets
_#_Economic aid: US commitments, including Ex-Im (FY70-89), $304
million; Western (non-US) countries, ODA and OOF bilateral commitments
(1980-88), $2.0 billion; OPEC bilateral aid (1979-89), $30 million;
Communist countries (1970-89), $286 million
_#_Currency: Nepalese rupee (plural--rupees);
1 Nepalese rupee (NR) = 100 paisa
_#_Exchange rates: Nepalese rupees (NRs) per US$1--30.805 (January
1991), 29.370 (1990), 27.189 (1989), 23.289 (1988), 21.819 (1987), 21.230
(1986), 18.246 (1985)
_#_Fiscal year: 16 July-15 July
_#_Overview: This highly developed and affluent economy is based on
private enterprise. The government makes its presence felt, however,
through many regulations, permit requirements, and welfare programs
affecting most aspects of economic activity. The trade and financial
services sector contributes over 50% of GDP. Industrial activity
provides about 25% of GDP and is led by the food-processing,
oil-refining, and metalworking industries. The highly mechanized
agricultural sec','bf28415f931708c7cc1cdd818a4b28dd545aca35bde42b377ca88631944dbf5e','internet-archive','theciaworldfactb00025gut','txt','84185fe9df79da427349cc1598fd3f69814a2085a9fc1fe0508a3fae0a870f84','https://archive.org/download/theciaworldfactb00025gut/25.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9d15dddac6eecdad20ec60b7ea6020f623c7d521982acf073a5144ead775f792',1991,'FR','France','economy',89,'tor employs only 5% of the labor force, but provides
large surpluses for export and the domestic food-processing industry.
An unemployment rate of 6.8% and a sizable budget deficit are
currently the most serious economic problems.
_#_GDP: $218.0 billion, per capita $14,600; real growth rate 3.1%
(1990)
_#_Inflation rate (consumer prices): 2.2% (1990 est.)
_#_Unemployment rate: 6.8% (1990 est.)
_#_Budget: revenues $68 billion; expenditures $76 billion, including
capital expenditures of $7 billion (1990)
_#_Exports: $107.8 billion (f.o.b., 1989);
commodities--agricultural products, processed foods and tobacco,
natural gas, chemicals, metal products, textiles, clothing;
partners--EC 74.9% (FRG 28.3%, Belgium-Luxembourg
14.2%, France 10.7%, UK 10.2%), US 4.7% (1988)
_#_Imports: $104.2 billion (c.i.f., 1989);
commodities--raw materials and semifinished products, consumer
goods, transportation equipment, crude oil, food products;
partners--EC 63.8% (FRG 26.5%, Belgium-Luxembourg 23.1%,
UK 8.1%), US 7.9% (1988)
_#_External debt: none
_#_Industrial production: growth rate 4.8% (1990 est.); accounts
for 25% of GDP
_#_Electricity: 22,216,000 kW capacity; 63,570 million kWh
produced, 4,300 kWh per capita (1989)
_#_Industries: agroindustries, metal and engineering products,
electrical machinery and equipment, chemicals, petroleum, fishing,
construction, microelectronics
_#_Agriculture: accounts for 4% of GDP; animal production
predominates; crops--grains, potatoes, sugar beets, fruits, vegetables;
shortages of grain, fats, and oils
_#_Economic aid: donor--ODA and OOF commitments (1970-89), $19.4
billion
_#_Currency: Netherlands guilder, gulden, or florin (plural--guilders,
gulden, or florins); 1 Netherlands guilder, gulden, or florin (f.) =
100 cents
_#_Exchange rates: Netherlands guilders, gulden, or florins (f.) per
US$1--1.7018 (January 1991), 1.8209 (1990), 2.1207 (1989), 1.9766 (1988),
2.0257 (1987), 2.4500 (1986), 3.3214 (1985)
_#_Fiscal year: calendar year
_#_Overview: Tourism, petroleum refining, and offshore finance are the
mainstays of the economy. The islands enjoy a high per capita income and
a well-developed infrastructure compared with other countries in the
region. Unlike many Latin American countries, the Netherlands Antilles
has avoided large international debt. Almost all consumer and capital
goods are imported, with the US being the major supplier.
_#_GDP: $1.0 billion, per capita $5,500; real growth rate 3% (1988
est.)
_#_Inflation rate (consumer prices): 3.9% (1989)
_#_Unemployment rate: 20% (1988)
_#_Budget: revenues $454 million; expenditures $525 million, including
capital expenditures of $42 million (1989 est.)
_#_Exports: $959 million (f.o.b., 1988);
commodities--petroleum products 98%;
partners--US 55%, UK 7%, Jamaica 5%
_#_Imports: $935 million (c.i.f., 1988);
commodities--crude petroleum 64%, food, manufactures;
partners--Venezuela 52%, Nigeria 15%, US 12%
_#_External debt: $701.2 million (December 1987)
_#_Industrial production: growth rate NA%
_#_Electricity: 125,000 kW capacity; 365 million kWh produced,
1,990 kWh per capita (1990)
_#_Industries: tourism (Curacao and Sint Maarten), petroleum
refining (Curacao), petroleum transshipment facilities (Curacao and
Bonaire), light manufacturing (Curacao)
_#_Agriculture: hampered by poor soils and scarcity of water; chief
products--aloes, sorghum, peanuts, fresh vegetables, tropical fruit; not
self-sufficient in food
_#_Economic aid: Western (non-US) countries, ODA and OOF bilateral
commitments (1970-88), $428 million
_#_Currency: Netherlands Antillean guilder, gulden, or florin
(plural--guilders, gulden, or florins);
1 Netherlands Antillean guilder, gulden, or florin (NAf.) = 100 cents
_#_Exchange rates: Netherlands Antillean guilders, gulden, or florins
(NAf.) per US$1--1.79 (fixed rate since 1989; 1.80 fixed rate 1971-88)
_#_Fiscal year: calendar year
_#_Overview: New Caledonia has more than 25% of the world''s known
nickel resources. In recent years the economy has suffered because of
depressed international demand for nickel, the principal source of export
earnings. Only a negligible amount of the land is suitable for
cultivation, and food accounts for about 25% of imports.
_#_GNP: $973 million, per capita $5,790; real growth rate 2.4%
(1990 est.)
_#_Inflation rate (consumer prices): 4.1% (1989)
_#_Unemployment rate: 16.0% (1989)
_#_Budget: revenues $224.0 million; expenditures $211.0 million,
including capital expenditures of NA (1985)
_#_Exports: $344 million (f.o.b., 1989);
commodities--nickel metal 87%, nickel ore;
partners--France 52.3%, Japan 15.8%, US 6.4%
_#_Imports: $389 million (c.i.f., 1989);
commodities--foods, fuels, minerals, machines, electrical
equipment;
partners--France 44.0%, US 10%, Australia 9%
_#_External debt: $NA
_#_Industrial production: growth rate NA%
_#_Electricity: 400,000 kW capacity; 2,200 million kWh produced,
12,790 kWh per capita (1990)
_#_Industries: nickel mining
_#_Agriculture: large areas devoted to cattle grazing; coffee, corn,
wheat, vegetables; 60% self-sufficient in beef
_#_Illicit drugs: illicit cannabis cultivation is becoming a principal
source of income for some families
_#_Economic aid: Western (non-US) countries, ODA and OOF bilateral
commitments (1970-88), $3.9 billion
_#_Currency: Comptoirs Francais du Pacifique franc (plural--francs);
1 CFP franc (CFPF) = 100 centimes
_#_Exchange rates: Comptoirs Francais du Pacifique francs (CFPF)
per US$1--93.28 (January 1991), 99.00 (1990), 115.99 (1989), 108.30
(1988), 109.27 (1987), 125.92 (1986), 163.35 (1985); note--linked at the
rate of 18.18 to the French franc
_#_Fiscal year: calendar year
_#_Overview: Since 1984 the government has been reorienting an
agrarian economy dependent on a guaranteed British market to an open
free market economy that can compete on the global scene. The government
has hoped that dynamic growth would boost real incomes, reduce
inflationary pressures, and permit the expansion of welfare benefits. The
results have been mixed: inflation is down from double-digit levels
but growth has been sluggish and unemployment, always a highly sensitive
issue, has been at a record high 7.4%. In 1988 GDP fell by 1%, in
1989 grew by a moderate 2.4%, and was flat in 1990.
_#_GDP: $40.2 billion, per capita $12,200; real growth rate 0.7%
(1990)
_#_Inflation rate (consumer prices): 6.5% (FY90)
_#_Unemployment rate: 7.4% (March 1990)
_#_Budget: revenues $17.6 billion; expenditures $18.3 billion,
including capital expenditures of $NA (FY91 est.)
_#_Exports: $8.8 billion (f.o.b., FY90);
commodities--wool, lamb, mutton, beef, fruit, fish, cheese,
manufactures, chemicals, forestry products;
partners--EC 18.3%, Japan 17.9%, Australia 17.5%, US 13.5%,
China 3.6%, South Korea 3.1%
_#_Imports: $8.1 billion (f.o.b., FY90);
commodities--petroleum, consumer goods, motor vehicles, industrial
equipment;
partners--Australia 19.7%, Japan 16.9%, EC 16.9%, US 15.3%,
Taiwan 3.0%
_#_External debt: $17.4 billion (1989)
_#_Industrial production: growth rate 1.9% (1990); accounts for
about 20% of GDP
_#_Electricity: 7,800,000 kW capacity; 28,000 million kWh produced,
8,500 kWh per capita (1990)
_#_Industries: food processing, wood and paper products, textiles,
machinery, transportation equipment, banking and insurance, tourism,
mining
_#_Agriculture: accounts for about 9% of GNP and 10% of the
work force; livestock predominates--wool, meat, dairy products all export
earners; crops--wheat, barley, potatoes, pulses, fruits, and
vegetables; surplus producer of farm products; fish catch reached a
record 503,000 metric tons in 1988
_#_Economic aid: donor--ODA and OOF commitments (1970-89), $526
million
_#_Currency: New Zealand dollar (plural--dollars);
1 New Zealand dollar (NZ$) = 100 cents
_#_Exchange rates: New Zealand dollars (NZ$) per US$1--1.6798 (January
1991), 1.6750 (1990), 1.6711 (1989), 1.5244 (1988), 1.6886 (1987), 1.9088
(1986), 2.0064 (1985)
_#_Fiscal year: 1 July-30 June
_#_Overview: Government control of the economy historically has been
extensive, although the Chamorro government has pledged to reduce it.
The financial system is directly controlled by the state, which also
regulates wholesale purchasing, production, sales, foreign trade, and
distribution of most goods. Over 50% of the agricultural and industrial
firms are state owned. Sandinista economic policies and the war
have produced a severe economic crisis. The foundation of the economy
continues to be the export of agricultural commodities, largely coffee
and cotton. Farm production fell by roughly 7% in 1989, the fifth
successive year of decline. The agricultural sector employs 44%
of the work force and accounts for 23% of GDP and 86% of export earnings.
Industry, which employs 13% of the work force and contributes about
25% to GDP, showed a drop of 7% in 1989 and remains below
pre-1979 levels. External debt is one of the highest in the world on a
per capita basis. In 1990 the annual inflation rate was 11,800%, sharply
up from 1,800% in 1989.
_#_GDP: $1.7 billion, per capita $470; real growth rate - 1.0% (1990
est.)
_#_Inflation rate (consumer prices): 11,800% (1990)
_#_Unemployment rate: 35% (1990)
_#_Budget: revenues $244 million; expenditures $550 million, including
capital expenditures of $73 million (1988)
_#_Exports: $298 million (f.o.b., 1989);
commodities--coffee, cotton, sugar, bananas, seafood, meat,
chemicals;
partners--OECD 75%, USSR and Eastern Europe 15%, other 10%
_#_Imports: $710 million (c.i.f., 1989);
commodities--petroleum, food, chemicals, machinery, clothing;
partners--Latin America 30%, US 25%, EC 20%, USSR and
Eastern Europe 10%, other 15% (1990 est.)
_#_External debt: $9 billion (December 1990)
_#_Industrial production: growth rate - 7% (1989); accounts
for about 25% of GDP
_#_Electricity: 415,000 kW capacity; 1,342 million kWh produced,
360 kWh per capita (1990)
_#_Industries: food processing, chemicals, metal products, textiles,
clothing, petroleum refining and distribution, beverages, footwear
_#_Agriculture: accounts for 23% of GDP and 44% of work force; cash
crops--coffee, bananas, sugarcane, cotton; food crops--rice, corn,
cassava, citrus fruit, beans; variety of animal products--beef, veal,
pork, poultry, dairy; normally self-sufficient in food
_#_Economic aid: US commitments, including Ex-Im (FY70-89), $294
million; Western (non-US) countries, ODA and OOF bilateral commitments
(1970-88), $1,186 million; Communist countries (1970-89), $3.5 billion
_#_Currency: cordoba (plural--cordobas); 1 cordoba (C$) = 100
centavos
_#_Exchange rates: cordobas (C$) per US$1--13,300,000 (January
1991), 15,655 (1989), 270 (1988), 102.60 (1987), 97.48 (1986), 38.90
(1985)
_#_Fiscal year: calendar year
_#_Overview: About 90% of the population is engaged in farming and
stock rearing, activities which generate almost half the national
income. The economy also depends heavily on exploitation of large uranium
deposits. Uranium production grew rapidly in the mid-1970s, but tapered
off in the early 1980s, when world prices declined. France is a major
customer, while Germany, Japan, and Spain also make regular purchases.
The depressed demand for uranium has contributed to an overall
sluggishness in the economy, a severe trade imbalance, and a mounting
external debt.
_#_GDP: $2.0 billion, per capita $270; real growth rate - 3.3% (1989
est.)
_#_Inflation rate (consumer prices): - 2.8% (1989)
_#_Unemployment rate: NA%
_#_Budget: revenues $220 million; expenditures $446 million, including
capital expenditures of $190 million (FY89 est.)
_#_Exports: $308 million (f.o.b., 1989 est.);
commodities--uranium 75%, livestock products, cowpeas, onions;
partners--France 65%, Nigeria 11%, Ivory Coast, Italy
_#_Imports: $386 million (c.i.f., 1989 est.);
commodities--petroleum products, primary materials, machinery,
vehicles and parts, electronic equipment, pharmaceuticals, chemical
products, cereals, foodstuffs;
partners--France 32%, Ivory Coast 11%, Germany 5%, Italy 4%,
Nigeria 4%
_#_External debt: $1.8 billion (December 1990 est.)
_#_Industrial production: growth rate 3.0% (1989 est.); accounts
for 18% of GDP
_#_Electricity: 102,000 kW capacity; 225 million kWh produced,
30 kWh per capita (1989)
_#_Industries: cement, brick, textiles, food processing, chemicals,
slaughterhouses, and a few other small light industries; uranium
production began in 1971
_#_Agriculture: accounts for roughly 40% of GDP and 90% of labor
force; cash crops--cowpeas, cotton, peanuts; food crops--millet, sorghum,
cassava, rice; livestock--cattle, sheep, goats; self-sufficient in food
except in drought years
_#_Economic aid: US commitments, including Ex-Im (FY70-89), $380
million; Western (non-US) countries, ODA and OOF bilateral commitments
(1970-88), $3.0 billion; OPEC bilateral aid (1979-89), $504 million;
Communist countries (1970-89), $61 million
_#_Currency: Communaute Financiere Africaine franc
(plural--francs); 1 CFA franc (CFAF) = 100 centimes
_#_Exchange rates: Communaute Financiere Africaine francs (CFAF)
per US$1--256.54 (January 1991), 272.26 (1990), 319.01 (1989), 297.85
(1988), 300.54 (1987), 346.30 (1986), 449.26 (1985)
_#_Fiscal year: 1 October-30 September
_#_Overview: Although Nigeria is Africa''s leading oil-producing
country, it remains poor with a $280 per capita GDP. In 1990, despite
rising oil prices and a sharp drop in inflation, performance remained
slack with continuing underutilization of industrial capacity and a
second year of relatively weak agricultural performance. Agricultural
production was up only 4.2% in 1990, still below the 1987 level.
Industrial output showed a 7.2% increase, but remained below the 1985
level. Government efforts to reduce Nigeria''s dependence on oil exports
and to sustain noninflationary growth have fallen short due to inadequate
new investment funds. Living standards continue to deteriorate from the
higher level of the early 1980s oil boom.
_#_GDP: $27.2 billion, per capita $230; real growth rate 2.7%
(1990 est.)
_#_Inflation rate (consumer prices): 16% (1990)
_#_Unemployment rate: NA%
_#_Budget: revenues $8.0 billion; expenditures $8.0 billion, including
capital expenditures of $NA (1990 est.)
_#_Exports: $13.0 billion (f.o.b., 1990 est.);
commodities--oil 95%, cocoa, rubber;
partners--EC 51%, US 32%
_#_Imports: $9.5 billion (c.i.f., 1990 est.);
commodities--consumer goods, capital equipment, chemicals, raw
materials;
partners--EC, US
_#_External debt: $35 billion (December 1990 est.)
_#_Industrial production: growth rate 7.2% (1990 est.); accounts
for 23% of GDP, including petroleum
_#_Electricity: 4,737,000 kW capacity; 11,270 million kWh produced,
100 kWh per capita (1989)
_#_Industries: crude oil and mining--coal, tin, columbite;
primary processing industries--palm oil, peanut, cotton, rubber,
wood, hides and skins; manufacturing industries--textiles,
cement, building materials, food products, footwear, chemical, printing,
ceramics, steel
_#_Agriculture: accounts for 28% of GNP and half of labor force;
inefficient small-scale farming dominates; once a large net exporter of
food and now an importer; cash crops--cocoa, peanuts, palm oil, rubber;
food crops--corn, rice, sorghum, millet, cassava, yams;
livestock--cattle, sheep, goats, pigs; fishing and forestry resources
extensively exploited
_#_Illicit drugs: illicit heroin and some cocaine trafficking;
marijuana cultivation for domestic consumption and export; major transit
country for heroin en route from Southwest Asia via Africa to Western
Europe and the US; growing transit route for cocaine from South America
via West Africa to Western Europe and the US
_#_Economic aid: US commitments, including Ex-Im (FY70-89), $705
million; Western (non-US) countries, ODA and OOF bilateral commitments
(1970-87), $2.5 billion; Communist countries (1970-89), $2.2 billion
_#_Currency: naira (plural--naira); 1 naira (4) = 100 kobo
_#_Exchange rates: naira (4) per US$1--8.707 (December 1990),
8.038 (1990), 7.3647 (1989), 4.5370 (1988), 4.0160 (1987), 1.7545 (1986),
0.8938 (1985)
_#_Fiscal year: calendar year
_#_Overview: The economy is heavily dependent on aid from New
Zealand. Government expenditures regularly exceed revenues, with the
shortfall made up by grants from New Zealand--the grants are used to pay
wages to public employees. The agricultural sector consists mainly of
subsistence gardening, although some cash crops are grown for export.
Industry consists primarily of small factories to process passion fruit,
lime oil, honey, and coconut cream. The sale of postage stamps to foreign
collectors is an important source of revenue. The island in recent years
has suffered a serious loss of population because of migration of Niueans
to New Zealand.
_#_GNP: $2.1 million, per capita $1,000; real growth rate NA%
(1989 est.)
_#_Inflation rate (consumer prices): 9.6% (1984)
_#_Unemployment rate: NA%
_#_Budget: revenues $5.5 million; expenditures $6.3 million, including
capital expenditures of $NA (FY85 est.)
_#_Exports: $175,274 (f.o.b., 1985);
commodities--canned coconut cream, copra, honey, passion fruit
products, pawpaw, root crops, limes, footballs, stamps, handicrafts;
partners--NZ 89%, Fiji, Cook Islands, Australia
_#_Imports: $3.8 million (c.i.f., 1985);
commodities--food, live animals, manufactured goods, machinery,
fuels, lubricants, chemicals, drugs;
partners--NZ 59%, Fiji 20%, Japan 13%, Western Samoa, Australia, US
_#_External debt: $NA
_#_Industrial production: growth rate NA%
_#_Electricity: 1,500 kW capacity; 3 million kWh produced,
1,490 kWh per capita (1990)
_#_Industries: tourist, handicrafts
_#_Agriculture: copra, coconuts, passion fruit, honey, limes;
subsistence crops--taro, yams, cassava (tapioca), sweet potatoes; pigs,
poultry, beef cattle
_#_Economic aid: Western (non-US) countries, ODA and OOF bilateral
commitments (1970-88), $62 million
_#_Currency: New Zealand dollar (plural--dollars);
1 New Zealand dollar (NZ$) = 100 cents
_#_Exchange rates: New Zealand dollars (NZ$) per US$1--1.6798 (January
1991), 1.6750 (1990), 1.6711 (1989), 1.5244 (1988), 1.6886 (1987), 1.9088
(1986), 2.0064 (1985)
_#_Fiscal year: 1 April-31 March
_#_Overview: The primary economic activity is tourism, which has
brought a level of prosperity unusual among inhabitants of the Pacific
Islands. The number of visitors has increased steadily over the years and
reached 29,000 in FY89. Revenues from tourism have given the
island a favorable balance of trade and helped the agricultural sector to
become self-sufficient in the production of beef, poultry, and eggs.
_#_GDP: $NA, per capita $NA; real growth rate NA%
_#_Inflation rate (consumer prices): NA%
_#_Unemployment rate: NA%
_#_Budget: revenues $NA; expenditures $4.2 million, including
capital expenditures of $400,000 (FY89)
_#_Exports: $1.7 million (f.o.b., FY86);
commodities--postage stamps, seeds of the Norfolk Island pine
and Kentia Palm, small quantities of avocados;
partners--Australia, Pacific Islands, NZ, Asia, Europe
_#_Imports: $15.6 million (c.i.f., FY86);
commodities--NA;
partners--Australia, Pacific Islands, NZ, Asia, Europe
_#_External debt: NA
_#_Industrial production: growth rate NA%
_#_Electricity: 7,000 kW capacity; 8 million kWh produced,
3,160 kWh per capita (1990)
_#_Industries: tourism
_#_Agriculture: Norfolk Island pine seed, Kentia palm seed, cereals,
vegetables, fruit, cattle, poultry
_#_Economic aid: none
_#_Currency: Australian dollar (plural--dollars);
1 Australian dollar ($A) = 100 cents
_#_Exchange rates: Australian dollars ($A) per US$1--1.2834 (January
1991), 1.2799 (1990), 1.2618 (1989), 1.2752 (1988), 1.4267 (1987), 1.4905
(1986), 1.4269 (1985)
_#_Fiscal year: 1 July-30 June
_#_Overview: The economy benefits substantially from financial
assistance from the US. An agreement for the years 1986 to 1992 entitles
the islands to $228 million for capital development, government
operations, and special programs. Another major source of income is the
tourist industry, which employs about 10% of the work force. The
agricultural sector is made up of cattle ranches and small farms
producing coconuts, breadfruit, tomatoes, and melons. Industry is small
scale in nature--mostly handicrafts and fish processing.
_#_GNP: $165 million, per capita $9,170; real growth rate NA% (1982)
_#_Inflation rate (consumer prices): NA%
_#_Unemployment rate: NA%
_#_Budget: revenues $NA; expenditures $70.6 million, including capital
expenditures of $NA (1987)
_#_Exports: $153.9 million (1989);
commodities--manufactured goods, garments;
partners--NA
_#_Imports: $313.7 million, a 43% increase over previous year (1989);
commodities--NA;
partners--NA
_#_External debt: none
_#_Industrial production: growth rate NA%
_#_Electricity: 25,000 kW capacity; 35 million kWh produced,
1,540 kWh per capita (1990)
_#_Industries: tourism, construction, light industry, handicrafts
_#_Agriculture: coffee, coconuts, fruits, tobacco, cattle
_#_Economic aid: none
_#_Currency: US currency is used
_#_Exchange rates: US currency is used
_#_Fiscal year: 1 October-30 September
_#_Overview: Norway is a prosperous capitalist nation with the
resources to finance extensive welfare measures. Since 1975 exploitation
of large crude oil and natural gas reserves has helped maintain high
growth; for the past five years growth has averaged 4.1%, the
fourth-highest among OECD countries. Growth slackened in 1987-88
partially because of the sharp drop in world oil prices, but picked
up again in 1989. The Brundtland government plans to push hard on
environmental issues, as well as cutting unemployment, improving
child care, upgrading major industries, and negotiating an
EC - European Free Trade Association (EFTA) agreement on an Economic
European Area.
_#_GDP: $74.2 billion, per capita $17,400; real growth rate 3.1%
(1990)
_#_Inflation rate (consumer prices): 4.1% (1990)
_#_Unemployment rate: 5.2% (1990, excluding people in
job-training programs)
_#_Budget: revenues $47.9 billion; expenditures $48.7 billion,
including capital expenditures of $NA (1990)
_#_Exports: $33.8 billion (f.o.b., 1990);
commodities--petroleum and petroleum products 25%, natural gas
11%, fish 7%, aluminum 6%, ships 3.5%, pulp and paper;
partners--EC 64.9%, Nordic countries 19.5%, developing countries
6.9%, US 6.2%, Japan 1.7% (1990)
_#_Imports: $26.8 billion (c.i.f., 1990);
commodities--machinery, fuels and lubricants, transportation
equipment, chemicals, foodstuffs, clothing, ships;
partners--EC 46.3%, Nordic countries 25.7%, developing countries
14.3%, US 8.1%, Japan 4.7% (1990)
_#_External debt: $15 billion (December 1990)
_#_Industrial production: growth rate 3.6% (1990)
_#_Electricity: 26,735,000 kW capacity; 121,685 million kWh produced,
28,950 kWh per capita (1989)
_#_Industries: petroleum and gas, food processing, shipbuilding, pulp
and paper products, metals, chemicals, timber, mining, textiles, fishing
_#_Agriculture: accounts for 2.8% of GNP and 6.4% of labor force;
among world''s top 10 fishing nations; livestock output exceeds value
of crops; over half of food needs imported; fish catch of 1.76 million
metric tons in 1989
_#_Economic aid: donor--ODA and OOF commitments (1970-89), $4.4
billion
_#_Currency: Norwegian krone (plural--kroner);
1 Norwegian krone (NKr) = 100 ore
_#_Exchange rates: Norwegian kroner (NKr) per US$1--5.9060 (January
1991), 6.2597 (1990), 6.9045 (1989), 6.5170 (1988), 6.7375 (1987), 7.3947
(1986), 8.5972 (1985)
_#_Fiscal year: calendar year
_#_Overview: Economic performance is closely tied to the fortunes of
the oil industry. Petroleum accounts for nearly all export earnings,
about 80% of government revenues, and roughly 40% of GDP. Oman has
proved oil reserves of 4 billion barrels, equivalent to about 20 years''
supply at the current rate of extraction. Although agriculture employs a
majority of the population, urban centers depend on imported food.
_#_GDP: $9.2 billion, per capita $5,870 (1990); real growth rate
- 3.0% (1987 est.)
_#_Inflation rate (consumer prices)','e07d0c732968747988bd625e2a12ee6bd0a7678089d6cab28f4b1eefd8b50bf7','internet-archive','theciaworldfactb00025gut','txt','84185fe9df79da427349cc1598fd3f69814a2085a9fc1fe0508a3fae0a870f84','https://archive.org/download/theciaworldfactb00025gut/25.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('58470d9b04889ce8039b07b143a330374b67dcc729f65978ea979eba91653f90',1991,'FR','France','economy',90,': 1.3% (1989)
_#_Unemployment rate: NA%
_#_Budget: revenues $3.5 billion; expenditures $4.3 billion,
including capital expenditures of $675 million (1989 est.)
_#_Exports: $3.9 billion (f.o.b., 1989);
commodities--petroleum, reexports, processed copper, dates, nuts,
fish;
partners--Japan, South Korea, Taiwan
_#_Imports: $2.3 billion (c.i.f., 1989);
commodities--machinery, transportation equipment, manufactured
goods, food, livestock, lubricants;
partners--UK, UAE, Japan, US
_#_External debt: $3.1 billion (December 1989 est.)
_#_Industrial production: growth rate 10% (1989), including
petroleum sector
_#_Electricity: 1,136,000 kW capacity; 3,650 million kWh produced,
2,500 kWh per capita (1990)
_#_Industries: crude oil production and refining, natural gas
production, construction, cement, copper
_#_Agriculture: accounts for 6% of GDP and 60% of the labor force
(including fishing); less than 2% of land cultivated; largely subsistence
farming (dates, limes, bananas, alfalfa, vegetables, camels, cattle); not
self-sufficient in food; annual fish catch averages 100,000 metric tons
_#_Economic aid: US commitments, including Ex-Im (FY70-89), $137
million; Western (non-US) countries, ODA and OOF bilateral commitments
(1970-88), $122 million; OPEC bilateral aid (1979-89), $797 million
_#_Currency: Omani rial (plural--rials); 1 Omani rial (RO) = 1,000
baiza
_#_Exchange rates: Omani rials (RO) per US$1--0.3845 (fixed rate
since 1986)
_#_Fiscal year: calendar year
_#_Overview: The economy consists primarily of subsistence agriculture
and fishing. Tourism provides some foreign exchange, although the remote
location of Palau and a shortage of suitable facilities has hindered
development. The government is the major employer of the work force,
relying heavily on financial assistance from the US.
_#_GDP: $31.6 million, per capita $2,260; real growth rate NA% (1986)
_#_Inflation rate (consumer prices): NA%
_#_Unemployment rate: 20% (1986)
_#_Budget: revenues $6.0 million; expenditures NA, including capital
expenditures of NA (1986)
_#_Exports: $0.5 million (f.o.b., 1986);
commodities--NA;
partners--US, Japan
_#_Imports: $27.2 million (c.i.f., 1986);
commodities--NA;
partners--US
_#_External debt: $NA
_#_Industrial production: growth rate NA%
_#_Electricity: 16,000 kW capacity; 22 million kWh produced,
1,540 kWh per capita (1990)
_#_Industries: tourism, craft items (shell, wood, pearl), some
commercial fishing and agriculture
_#_Agriculture: subsistence-level production of coconut, copra,
cassava, sweet potatoes
_#_Economic aid: US commitments, including Ex-Im (FY70-87), $2
billion; Western (non-US) countries, ODA and OOF bilateral commitments
(1970-87), $62.6 million
_#_Currency: US currency is used
_#_Exchange rates: US currency is used
_#_Fiscal year: 1 October-30 September
_#_Overview: The Pacific Ocean is a major contributor to the world
economy and particularly to those nations its waters directly touch.
It provides cheap sea transportation between East and West, extensive
fishing grounds, offshore oil and gas fields, minerals, and sand and
gravel for the construction industry. In 1985 over half (54%) of the
world''s total fish catch came from the Pacific Ocean, which is the only
ocean where the fish catch has increased every year since 1978.
Exploitation of offshore oil and gas reserves is playing an
ever-increasing role in the energy supplies of Australia, New Zealand,
China, US, and Peru. The high cost of recovering offshore oil and gas,
combined with the wide swings in world prices for oil since 1985, has
slowed but not stopped new drillings.
_#_Industries: fishing, oil and gas production
_#_Overview: Pakistan is a poor Third World country faced with the
usual problems of rapidly increasing population, sizable government
deficits, and heavy dependence on foreign aid. In addition, the economy
must support a large military establishment and provide for the needs of
4 million Afghan refugees. A real economic growth rate averaging 5-6% in
recent years has enabled the country to cope with these problems. Almost
all agriculture and small-scale industry is in private hands, and the
government seeks to privatize a portion of the large-scale industrial
enterprises now publicly owned. In December 1988, Pakistan signed a
three-year economic reform agreement with the IMF, which provides for a
reduction in the government deficit and a liberalization of trade in
return for further IMF financial support. Late in 1990, the IMF
suspended assistance to Pakistan because the government failed to
follow through on deficit reforms. Pakistan almost certainly will make
little headway on raising living standards for its rapidly expanding
population; at the current rate of growth, population would double in
29 years.
_#_GNP: $43.3 billion, per capita $380; real growth rate 5.0%
(FY90 est.)
_#_Inflation rate (consumer prices): 5.7% (FY90)
_#_Unemployment rate: 10% (FY91 est.)
_#_Budget: revenues $5.6 billion; expenditures $10.2 billion,
including capital expenditures of $2.7 billion (FY91 est.)
_#_Exports: $4.8 billion (f.o.b., FY90);
commodities--rice, cotton, textiles, clothing;
partners--EC 31%, Japan 11.6%, US 11.5% (FY89)
_#_Imports: $6.5 billion (f.o.b., FY90);
commodities--petroleum, petroleum products, machinery,
transportation equipment, vegetable oils, animal fats, chemicals;
partners--EC 26%, US 16%, Japan 14% (FY89)
_#_External debt: $20.1 billion (1990 est.)
_#_Industrial production: growth rate 7.5% (FY91 est.); accounts for
almost 20% of GNP
_#_Electricity: 7,575,000 kW capacity; 29,300 million kWh produced,
270 kWh per capita (1989)
_#_Industries: textiles, food processing, beverages, petroleum
products, construction materials, clothing, paper products, international
finance, shrimp
_#_Agriculture: 25% of GDP, over 50% of labor force; world''s largest
contiguous irrigation system; major crops--cotton, wheat, rice,
sugarcane, fruits, and vegetables; livestock products--milk, beef,
mutton, eggs; self-sufficient in food grain
_#_Illicit drugs: illicit producer of opium poppy and cannabis for
the international drug trade; government eradication efforts on poppy
cultivation of limited success
_#_Economic aid: (including Bangladesh before 1972) US commitments,
including Ex-Im (FY70-89), $4.5 billion authorized (excluding what is now
Bangladesh); Western (non-US) countries, ODA and OOF bilateral
commitments (1980-88), $8.2 billion; OPEC bilateral aid (1979-89),
$2.3 billion; Communist countries (1970-89), $3.2 billion
_#_Currency: Pakistani rupee (plural--rupees);
1 Pakistani rupee (PRe) = 100 paisa
_#_Exchange rates: Pakistani rupees (PRs) per US$1--22.072 (January
1991), 21.707 (1990), 20.541 (1989), 18.003 (1988), 17.399 (1987), 16.648
(1986), 15.928 (1985)
_#_Fiscal year: 1 July-30 June
_#_Overview: no economic activity
_#_Overview: GDP expanded by an estimated 5% in 1990, after
contracting 1% in 1988 and 14% in 1989. Political stability prompted
greater business confidence and consumer demand, leading to increased
production by the agricultural, commercial, manufacturing, construction,
and utilities sectors. The transportation sector and government services
declined slightly due to slack early-1990 transits through the Panama
Canal, lower oil pipeline flowthrough, and Panama City''s budget cuts.
Imports and exports posted gains during the year, and government revenues
were up sharply over 1989''s levels.
_#_GDP: $4.8 billion, per capita $1,980; real growth rate 5%
(1990 est.)
_#_Inflation rate (consumer prices): 1.3% (1990 est.)
_#_Unemployment rate: 20% (1990)
_#_Budget: revenues $1.7 billion; expenditures $1.8 billion,
including capital expenditures of $70 million (1990 est.)
_#_Exports: $355 million (f.o.b., 1990 est.);
commodities--bananas 27%, shrimp 21%, clothing 6%, coffee 4%,
sugar 4%;
partners--US 90%, Central America and Caribbean, EC (1989 est.)
_#_Imports: $1,250 million (f.o.b., 1990);
commodities--foodstuffs 13%, capital goods 12%, crude oil 12%,
consumer goods, chemicals;
partners--US 35%, Central America and Caribbean, EC,
Mexico, Venezuela (1989 est.)
_#_External debt: $5 billion (December 1990 est.)
_#_Industrial production: growth rate 4.8% (1990 est.)
_#_Electricity: 1,113,000 kW capacity; 3,264 million kWh produced,
1,350 kWh per capita (1990)
_#_Industries: manufacturing and construction activities, petroleum
refining, brewing, cement and other construction material, sugar mills,
paper products
_#_Agriculture: accounts for 12% of GDP (1990 est.), 25% of labor
force (1989); crops--bananas, rice, corn, coffee, sugarcane; livestock;
fishing; importer of food grain, vegetables, milk products
_#_Economic aid: US commitments, including Ex-Im (FY70-89), $516
million; Western (non-US) countries, ODA and OOF bilateral commitments
(1970-88), $575 million; Communist countries (1970-89), $4 million
_#_Currency: balboa (plural--balboas); 1 balboa (B) = 100 centesimos
_#_Exchange rates: balboas (B) per US$1--1.000 (fixed rate)
_#_Fiscal year: calendar year
_#_Overview: Papua New Guinea is richly endowed with natural
resources, but exploitation has been hampered by the rugged terrain and
the high cost of developing an infrastructure. Agriculture provides a
subsistence livelihood for 85% of the population. Mining of numerous
deposits, including copper and gold, accounts for about 60% of
export earnings. Budgetary support from Australia and development aid
under World Bank auspices help sustain the economy.
_#_GDP: $2.7 billion, per capita $725; real growth rate - 3.0% (1989
est.)
_#_Inflation rate (consumer prices): 4.5% (1989)
_#_Unemployment rate: 5% (1988)
_#_Budget: revenues $867 million; expenditures $873 million,
including capital expenditures of $119 million (1990 est.)
_#_Exports: $1.4 billion (f.o.b., 1989);
commodities--gold, copper ore, coffee, cocoa, copra, palm oil,
timber, lobster;
partners--FRG, Japan, Australia, UK, Spain, US
_#_Imports: $1.5 billion (c.i.f., 1989);
commodities--machinery and transport equipment, fuels, food,
chemicals, consumer goods;
partners--Australia, Singapore, Japan, US, New Zealand, UK
_#_External debt: $2.76 billion (December 1990)
_#_Industrial production: growth rate NA%; accounts for 25% of
GDP
_#_Electricity: 397,000 kW capacity; 1,510 million kWh produced,
400 kWh per capita (1990)
_#_Industries: copra crushing, oil palm processing, plywood
processing, wood chip production, gold, silver, copper, construction,
tourism
_#_Agriculture: one-third of GDP; livelihood for 85% of population;
fertile soils and favorable climate permits cultivating a wide variety of
crops; cash crops--coffee, cocoa, coconuts, palm kernels; other
products--tea, rubber, sweet potatoes, fruit, vegetables, poultry, pork;
net importer of food for urban centers
_#_Economic aid: US commitments, including Ex-Im (FY70-89), $40.6
million; Western (non-US) countries, ODA and OOF bilateral commitments
(1970-88), $6.4 billion; OPEC bilateral aid (1979-89), $17 million
_#_Currency: kina (plural--kina); 1 kina (K) = 100 toea
_#_Exchange rates: kina (K) per US$1--1.0549 (January 1991), 1.0467
(1990), 1.1685 (1989), 1.1538 (1988), 1.1012 (1987), 1.0296 (1986),
1.0000 (1985)
_#_Fiscal year: calendar year
_#_Overview: no economic activity
_#_Overview: The economy is predominantly agricultural. Agriculture,
including forestry, accounts for about 25% of GNP, employs about 45% of
the labor force, and provides the bulk of exports. Paraguay has no known
significant mineral or petroleum resources but does have a large
hydropower potential. Since 1981 economic performance has declined
compared with the boom period of 1976-81, when real GDP grew at an
average annual rate of nearly 11%. During 1982-86 real GDP fell in three
of five years, inflation jumped to an annual rate of 32%, and
foreign debt rose. Factors responsible for the erratic behavior of the
economy were the completion of the Itaipu hydroelectric dam, bad weather
for crops, and weak international commodity prices for agricultural
exports. In 1987 the economy experienced a minor recovery because of
improved weather conditions and stronger international prices for key
agricultural exports. The recovery continued through 1990, on the
strength of bumper crops in 1988-89. The government, however, must
follow through on promises of reforms needed to deal with escalating
inflation, large fiscal deficits, growing debt arrearages, and falling
reserves.
_#_GDP: $4.6 billion, per capita $1,000; real growth rate 3.5%
(1990 est.)
_#_Inflation rate (consumer prices): 44% (1990 est.)
_#_Unemployment rate: 12% (1989 est.)
_#_Budget: revenues $1.2 billion; expenditures $1.2 billion,
including capital expenditures of $487 million (1991)
_#_Exports: $980 million (registered f.o.b., 1990 est.);
commodities--cotton, soybean, timber, vegetable oils, coffee,
tung oil, meat products;
partners--EC 37%, Brazil 25%, Argentina 10%, Chile 6%, US 6%
_#_Imports: $1.4 billion (registered c.i.f., 1990 est.);
commodities--capital goods 35%, consumer goods 20%, fuels and
lubricants 19%, raw materials 16%, foodstuffs, beverages, and tobacco
10%;
partners--Brazil 30%, EC 20%, US 18%, Argentina 8%, Japan 7%
_#_External debt: $1.7 billion (1989 est.)
_#_Industrial production: growth rate 5.9% (1989 est.); accounts
for 16% of GDP
_#_Electricity: 5,169,000 kW capacity; 15,144 million kWh produced,
3,250 kWh per capita (1990)
_#_Industries: meat packing, oilseed crushing, milling, brewing,
textiles, other light consumer goods, cement, construction
_#_Agriculture: accounts for 25% of GDP and 44% of labor force; cash
crops--cotton, sugarcane; other crops--corn, wheat, tobacco, soybeans,
cassava, fruits, and vegetables; animal products--beef, pork, eggs,
milk; surplus producer of timber; self-sufficient in most foods
_#_Illicit drugs: illicit producer of cannabis for the international
drug trade; important transshipment point for Bolivian cocaine headed
for the US and Europe
_#_Economic aid: US commitments, including Ex-Im (FY70-89), $172
million; Western (non-US) countries, ODA and OOF bilateral commitments
(1970-88), $1.05 billion
_#_Currency: guarani (plural--guaranies);
1 guarani (0) = 100 centimos
_#_Exchange rates: guaranies (0) per US$1--1,204.5 (October 1989),
1,056.2 (1989), 550.00 (fixed rate 1986-February 1989), 339.17 (1986),
306.67 (1985)
_#_Fiscal year: calendar year
_#_Overview: The Peruvian economy is basically capitalistic, with a
large dose of government welfare programs and government management of
credit. In the 1980s the economy suffered from hyperinflation,
declining per capita output, and mounting external debt. Peru was shut
off from IMF and World Bank support in the mid-1980s because of its
huge debt arrears. An austerity program implemented shortly after the
Fujimori government took office in July 1990 contributed to a third
consecutive yearly contraction of economic activity, but was able to
generate a small recovery in the last quarter. After a burst of
inflation as the program eliminated government price subsidies, monthly
price increases eased to the single-digit level for the first time
since mid-1988. Lima has restarted current payments to multilateral
lenders and, although it faces $14 billion in arrears on its external
debt, is working toward an accommodation with its creditors.
_#_GDP: $19.3 billion, per capita $898; real growth rate - 3.9%
(1990 est.)
_#_Inflation rate (consumer prices): 7,650% (1990)
_#_Unemployment rate: 20.0%; underemployment estimated at 60% (1989)
_#_Budget: revenues $1.3 billion; expenditures $2.1 billion,
including capital expenditures of $NA (1990 est.)
_#_Exports: $3.01 billion (f.o.b., 1990 est.);
commodities--fishmeal, cotton, sugar, coffee, copper, iron ore,
refined silver, lead, zinc, crude petroleum and byproducts;
partners--EC 22%, US 20%, Japan 11%, Latin America 8%, USSR 4%
_#_Imports: $2.78 billion (f.o.b., 1990 est.);
commodities--foodstuffs, machinery, transport equipment, iron and
steel semimanufactures, chemicals, pharmaceuticals;
partners--US 23%, Latin America 16%, EC 12%, Japan 7%,
Switzerland 3%
_#_External debt: $20.0 billion (December 1990)
_#_Industrial production: growth rate - 21% (1989); accounts
for almost 25% of GDP
_#_Electricity: 4,867,000 kW capacity; 15,540 million kWh produced,
710 kWh per capita (1990)
_#_Industries: mining of metals, petroleum, fishing, textiles,
clothing, food processing, cement, auto assembly, steel, shipbuilding,
metal fabrication
_#_Agriculture: accounts for 12% of GDP, 37% of labor force;
commercial crops--coffee, cotton, sugarcane; other crops--rice, wheat,
potatoes, plantains, coca; animal products--poultry, red meats, dairy,
wool; not self-sufficient in grain or vegetable oil; fish catch of
4.6 million metric tons (1987), world''s fifth-largest
_#_Illicit drugs: world''s largest coca leaf producer with about
121,000 hectares under cultivation; source of supply for most of the
world''s coca paste and cocaine base; about 85% of cultivation is for
illicit production; most of cocaine base is shipped to Colombian drug
dealers for processing into cocaine for the international drug market
_#_Economic aid: US commitments, including Ex-Im (FY70-89), $1.7
billion; Western (non-US) countries, ODA and OOF bilateral commitments
(1970-88), $3.95 billion; Communist countries (1970-89), $577 million
_#_Currency: inti (plural--intis); 1 inti (I/) = 1,000 soles
_#_Exchange rates: intis (I/) per US$1--530,000 (January 1991),
187,886 (1990), 2,666 (1989), 128.83 (1988), 16.84 (1987), 13.95 (1986),
10.97 (1985)
_#_Fiscal year: calendar year
_#_Overview: The economy continues to recover from the political
turmoil following the ouster of former President Marcos and several coup
attempts. After two consecutive years of economic contraction (1984 and
1985), the economy has since 1986 had positive growth, although in 1990
the economy slowed considerably from 1989. The agricultural sector
together with forestry and fishing, plays an important role in the
economy, employing about 45% of the work force and providing almost
30% of GDP. The Philippines is the world''s largest exporter of coconuts
and coconut products. Manufacturing contributes about 25% of GDP. Major
industries include food processing, chemicals, and textiles.
_#_GNP: $45.2 billion, per capita $700; real growth rate 2.5%
(1990 est.)
_#_Inflation rate (consumer prices): 12.7% (1990 est.)
_#_Unemployment rate: 9.3% (1990 est.)
_#_Budget: $7.2 billion; expenditures $8.12 billion,
including capital expenditures of $0.97 billion (1989 est.)
_#_Exports: revenues $8.1 billion (f.o.b., 1990 est.);
commodities--electrical equipment 19%, textiles 16%, minerals
and ores 11%, farm products 10%, coconut 10%, chemicals 5%, fish 5%,
forest products 4%;
partners--US 36%, EC 19%, Japan 18%, ESCAP 9%, ASEAN 7%
_#_Imports: $12.1 billion (c.i.f., 1990 est.);
commodities--raw materials 53%, capital goods 17%, petroleum
products 17%;
partners--US 25%, Japan 17%, ESCAP 13%, EC 11%, ASEAN 10%,
Middle East 10%
_#_External debt: $28.4 billion (1990)
_#_Industrial production: growth rate 1.9% (1990 est.); accounts
for 30-35% of GNP
_#_Electricity: 6,755,000 kW capacity; 28,000 million kWh produced,
420 kWh per capita (1990)
_#_Industries: textiles, pharmaceuticals, chemicals, wood products,
food processing, electronics assembly, petroleum refining, fishing
_#_Agriculture: accounts for about one-third of GNP and 45% of labor
force; major crops--rice, coconut, corn, sugarcane, bananas, pineapple,
mango; animal products--pork, eggs, beef; net exporter of farm products;
fish catch of 2 million metric tons annually
_#_Illicit drugs: illicit producer of cannabis for the international
drug trade; growers are producing more and better quality cannabis
despite government eradication efforts
_#_Economic aid: US commitments, including Ex-Im (FY70-89), $3.6
billion; Western (non-US) countries, ODA and OOF bilateral commitments
(1970-88), $6.6 billion; OPEC bilateral aid (1979-89), $5 million;
Communist countries (1975-89), $123 million
_#_Currency: Philippine peso (plural--pesos);
1 Philippine peso (1) = 100 centavos
_#_Exchange rates: Philippine pesos (1) per US$1--28.055 (January
1991), 24.311 (1990), 21.737 (1989), 21.095 (1988), 20.568 (1987),
20.386 (1986), 18.607 (1985)
_#_Fiscal year: calendar year
_#_Overview: The inhabitants exist on fishing and subsistence farming.
The fertile soil of the valleys produces a wide variety of fruits and
vegetables, including citrus, sugarcane, watermelons, bananas, yams, and
beans. Bartering is an important part of the economy. The major sources
of revenue are the sale of postage stamps to collectors and the sale of
handicrafts to passing ships.
_#_GDP: $NA, per capita $NA; real growth rate NA%
_#_Inflation rate (consumer prices): NA%
_#_Unemployment rate: NA%
_#_Budget: revenues $430,440; expenditures $429,983, including capital
expenditures of $NA (FY87 est.)
_#_Exports: $NA;
commodities--fruits, vegetables, curios;
partners--NA
_#_Imports: $NA;
commodities--fuel oil, machinery, building materials,
flour, sugar, other foodstuffs;
partners--NA
_#_External debt: $NA
_#_Industrial production: growth rate NA%
_#_Electricity: 110 kW capacity; 0.30 million kWh produced,
5,360 kWh per capita (1990)
_#_Industries: postage stamp sales, handicrafts
_#_Agriculture: based on subsistence fishing and farming; wide variety
of fruits and vegetables grown; must import grain products
_#_Economic aid: none
_#_Currency: New Zealand dollar (plural--dollars);
1 New Zealand dollar (NZ$) = 100 cents
_#_Exchange rates: New Zealand dollars (NZ$) per US$1--1.6798
(January 1991), 1.6750 (1990), 1.6711 (1989), 1.5244 (1988), 1.6866
(1987), 1.9088 (1986), 2.0064 (1985)
_#_Fiscal year: 1 April-31 March
_#_Overview: The economy, except for the agricultural sector, had
followed the Soviet model of state ownership and control of
productive assets. About 75% of agricultural production had come from the
private sector and the rest from state farms. The economy has presented a
picture of moderate but slowing growth against a background of underlying
weaknesses in technology and worker motivation. GNP dropped by 2.0% in
1989 and by a further 8.9% in 1990. The inflation rate, after falling
sharply from the 1982 peak of 100% to 22% in 1986, rose to a galloping
rate of 640% in 1989 and dropped back to 250% in 1990. Shortages of
consumer goods and some food items worsened in 1988-89. Agricultural
products and coal are among the biggest hard currency earners, but
manufactures are increasing in importance. Poland, with its hard currency
debt of $48.5 billion, is severely limited in its ability to import
much-needed hard currency goods. The sweeping political changes of 1989
disrupted normal economic channels and exacerbated shortages. In January
1990, the new Solidarity-led government adopted a cold turkey program for
transforming Poland to a market economy. The government moved to
eliminate subsidies, free prices, make the zloty convertible, and,
in general, halt the hyperinflation. These financial measures were
accompanied by plans to privatize the economy in stages. While inflation
fell to an annual rate of 77.5% by November of 1990, the rise in
unemployment and the drop in living standards have led to growing popular
discontent and to a change of government in January 1991. The new
government is continuing the previous government''s economic
program, while trying to speed privatization and to better cushion the
populace from the dislocations associated with reform. Substantial
outside aid will be needed if Poland is to make a successful transition
in the 1990s.
_#_GNP: $158.5 billion, per capita $4,200; real growth rate - 8.9%
(1990 est.)
_#_Inflation rate (consumer prices): 250% (1990 est.)
_#_Unemployment rate: 6.1% (end-December 1990)
_#_Budget: revenues $20.9 billion; expenditures $23.4 billion,
including capital expenditures of $2.8 billion (1989)
_#_Exports: $12.9 billion (f.o.b., 1989);
commodities--machinery and equipment','4c573da78c4fd2c439bfc78f1df6107548a2b467b12fea9e408880021a448a5e','internet-archive','theciaworldfactb00025gut','txt','84185fe9df79da427349cc1598fd3f69814a2085a9fc1fe0508a3fae0a870f84','https://archive.org/download/theciaworldfactb00025gut/25.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0b612cb16b289532967a03857145358918d8ea4185634ec3adfd46844e1abdeb',1991,'FR','France','economy',91,'38%; fuels, minerals, and
metals 21%; manufactured consumer goods 15%; agricultural and forestry
products 4% (1989);
partners--USSR 25%, FRG 14%, UK 6.5%, Czechoslovakia 5.5% (1989)
_#_Imports: $12.8 billion (f.o.b., 1989);
commodities--machinery and equipment 37%; fuels, minerals, and
metals 31%; manufactured consumer goods 17%; agricultural and forestry
products 5% (1989);
partners--USSR 18%, FRG 16%, Austria 6%, Czechoslovakia 6% (1989)
_#_External debt: $48.5 billion (January 1991)
_#_Industrial production: growth rate - 23% (State sector 1990 est.)
_#_Electricity: 31,530,000 kW capacity; 136,300 million kWh produced,
3,610 kWh per capita (1990)
_#_Industries: machine building, iron and steel, extractive
industries, chemicals, shipbuilding, food processing, glass, beverages,
textiles
_#_Agriculture: accounts for 15% of GNP and 27% of labor force; 75% of
output from private farms, 25% from state farms; productivity remains
low by European standards; leading European producer of rye, rapeseed,
and potatoes; wide variety of other crops and livestock; major exporter
of pork products; normally self-sufficient in food
_#_Economic aid: donor--bilateral aid to non-Communist less developed
countries, $2.2 billion (1954-89)
_#_Currency: zloty (plural--zlotych); 1 zloty (Zl) =
100 groszy
_#_Exchange rates: zlotych (Zl) per US$1--11,100.00 (May 1991),
9,500 (1990), 1,439.18 (1989), 430.55 (1988), 265.08 (1987), 175.29
(1986), 147.14 (1985)
_#_Fiscal year: calendar year
_#_Overview: During the past four years, the economy has made a
sustained recovery from the severe recession of 1983-85. The economy
grew by 14% during the 1987-89 period, largely because of strong
domestic consumption and investment spending. Unemployment has
declined for the third consecutive year, but inflation continues to be
about three times the European Community average. The government is
pushing economic restructuring and privatization measures in anticipation
of the 1992 European Community timetable to form a single large market in
Europe.
_#_GDP: $57.8 billion, per capita $5,580; real growth rate 3.5%
(1990)
_#_Inflation rate (consumer prices): 13.4% (1990)
_#_Unemployment rate: 5.5% (1990 est.)
_#_Budget: revenues $21.6 billion; expenditures $23.8 billion,
including capital expenditures of $6.9 billion (1990)
_#_Exports: $16.3 billion (f.o.b., 1990);
commodities--cotton textiles, cork and cork products, canned fish,
wine, timber and timber products, resin, machinery, appliances;
partners--EC 72%, other developed countries 13%, US 5%
_#_Imports: $24.9 billion (c.i.f., 1990);
commodities--petroleum, cotton, foodgrains, industrial machinery,
iron and steel, chemicals;
partners--EC 69%, other developed countries 11%,
less developed countries 13%, US 4%
_#_External debt: $18.4 billion (1990)
_#_Industrial production: growth rate 4.9% (1989); accounts for
40% of GDP
_#_Electricity: 6,729,000 kW capacity; 16,000 million kWh produced,
1,530 kWh per capita (1989)
_#_Industries: textiles and footwear; wood pulp, paper, and cork;
metalworking; oil refining; chemicals; fish canning; wine; tourism
_#_Agriculture: accounts for 9% of GDP and 20% of labor force; small
inefficient farms; imports more than half of food needs; major
crops--grain, potatoes, olives, grapes; livestock sector--sheep, cattle,
goats, poultry, meat, dairy products
_#_Economic aid: US commitments, including Ex-Im (FY70-89), $1.8
billion; Western (non-US) countries, ODA and OOF bilateral commitments
(1970-88), $1.13 billion
_#_Currency: Portuguese escudo (plural--escudos);
1 Portuguese escudo (Esc) = 100 centavos
_#_Exchange rates: Portuguese escudos (Esc) per US$1--134.46 (January
1991), 142.55 (1990), 157.46 (1989), 143.95 (1988), 140.88 (1987), 149.59
(1986), 170.39 (1985)
_#_Fiscal year: calendar year
_#_Overview: Puerto Rico has one of the most dynamic economies in the
Caribbean region. Industry has surpassed agriculture as the primary
sector of economic activity and income. Encouraged by duty-free
access to the US and by tax incentives, US firms have invested heavily
in Puerto Rico since the 1950s. Important new industries include
pharmaceuticals, electronics, textiles, petrochemicals, and processed
foods. Sugar production has lost out to dairy production and other
livestock products as the main source of income in the agricultural
sector. Tourism has traditionally been an important source of income
for the island. The economy is slowly recovering from the disruptions
caused by Hurricane Hugo in September 1989. The tourism infrastructure
was especially hard hit.
_#_GNP: $20.1 billion, per capita $6,100; real growth rate 3.6% (FY89)
_#_Inflation rate (consumer prices): 6.3% (October 1989-90)
_#_Unemployment rate: 14.9% (October 1990)
_#_Budget: revenues $5.5 billion; expenditures $5.5 billion,
including capital expenditures of $1.5 billion (FY89)
_#_Exports: $16.4 billion (f.o.b., FY89);
commodities--pharmaceuticals, electronics, apparel, canned tuna,
rum, beverage concentrates, medical equipment, instruments;
partners--US 87%
_#_Imports: $14.0 billion (c.i.f., FY89);
commodities--chemicals, clothing, food, fish, petroleum products;
partners--US 60%
_#_External debt: $NA
_#_Industrial production: growth rate 1.6% (FY89)
_#_Electricity: 4,149,000 kW capacity; 14,844 million kWh produced,
4,510 kWh per capita (1990)
_#_Industries: manufacturing of pharmaceuticals, electronics,
apparel, food products, instruments; tourism
_#_Agriculture: accounts for 3% of labor force; crops--sugarcane,
coffee, pineapples, plantains, bananas; livestock--cattle, chickens;
imports a large share of food needs
_#_Economic aid: none
_#_Currency: US currency is used
_#_Exchange rates: US currency is used
_#_Fiscal year: 1 July-30 June
_#_Overview: Oil is the backbone of the economy and accounts for more
than 85% of export earnings and roughly 75% of government revenues.
Proved oil reserves of 3.3 billion barrels should ensure continued output
at current levels for about 25 years. Oil has given Qatar a per capita
GDP of about $12,500, among the highest in the world outside the OECD
countries.
_#_GDP: $6.6 billion, per capita $12,500 (1989 est.); real growth
rate 5.0% (1988)
_#_Inflation rate (consumer prices): 4.9% (1988 est.)
_#_Unemployment rate: NA%
_#_Budget: revenues $1.8 billion; expenditures $3.4 billion, including
capital expenditures of $400 million (FY89 est.)
_#_Exports: $2.6 billion (f.o.b., 1989 est.);
commodities--petroleum products 85%, steel, fertilizers;
partners--Japan, Italy, Thailand, Singapore
_#_Imports: $1.4 billion (c.i.f., 1989 est.), excluding military
equipment;
commodities--foodstuffs, beverages, animal and vegetable oils,
chemicals, machinery and equipment;
partners--Japan, UK, US, Italy
_#_External debt: $1.1 billion (December 1989 est.)
_#_Industrial production: growth rate 0.6% (1987); accounts
for 64% of GDP, including oil
_#_Electricity: 1,514,000 kW capacity; 4,000 million kWh produced,
8,540 kWh per capita (1989)
_#_Industries: crude oil production and refining, fertilizers,
petrochemicals, steel, cement
_#_Agriculture: farming and grazing on small scale, less than 2% of
GDP; commercial fishing increasing in importance; most food imported
_#_Economic aid: donor--pledged $2.7 billion in ODA to less developed
countries (1979-88)
_#_Currency: Qatari riyal (plural--riyals); 1 Qatari riyal (QR) = 100
dirhams
_#_Exchange rates: Qatari riyals (QR) per US$1--3.6400 riyals (fixed
rate)
_#_Fiscal year: 1 April-31 March
_#_Overview: The economy has traditionally been based on agriculture.
Sugarcane has been the primary crop for more than a century, and in some
years it accounts for 85% of exports. The government has been pushing
the development of a tourist industry to relieve high unemployment,
which recently amounted to one-third of the labor force. The white
and Indian communities are substantially better off than other segments
of the population, adding to the social tensions generated by poverty
and unemployment. The economic well-being of Reunion depends heavily on
continued financial assistance from France.
_#_GDP: $3.37 billion, per capita $6,000 (1987 est.); real growth
rate 9% (1987 est.)
_#_Inflation rate (consumer prices): 1.3% (1988)
_#_Unemployment rate: 35% (February 1991)
_#_Budget: revenues $358 million; expenditures $914 million, including
capital expenditures of $NA (1986)
_#_Exports: $166 million (f.o.b., 1988);
commodities--sugar 75%, rum and molasses 4%, perfume essences 4%,
lobster 3%, vanilla and tea 1%;
partners--France, Mauritius, Bahrain, South Africa, Italy
_#_Imports: $1.7 billion (c.i.f., 1988);
commodities--manufactured goods, food, beverages, tobacco,
machinery and transportation equipment, raw materials, and petroleum
products;
partners--France, Mauritius, Bahrain, South Africa, Italy
_#_External debt: NA
_#_Industrial production: growth rate NA%; about 25% of GDP
_#_Electricity: 245,000 kW capacity; 546 million kWh produced,
965 kWh per capita (1989)
_#_Industries: sugar, rum, cigarettes, several small shops producing
handicraft items
_#_Agriculture: accounts for 30% of labor force; dominant sector of
economy; cash crops--sugarcane, vanilla, tobacco; food crops--tropical
fruits, vegetables, corn; imports large share of food needs
_#_Economic aid: Western (non-US) countries, ODA and OOF bilateral
commitments (1970-88), $14.1 billion
_#_Currency: French franc (plural--francs); 1 French franc (F) =
100 centimes
_#_Exchange rates: French francs (F) per US$1--5.1307 (January 1991),
5.4453 (1990), 6.3801 (1989), 5.9569 (1988), 6.0107 (1987), 6.9261
(1986), 8.9852 (1985)
_#_Fiscal year: calendar year
_#_Overview: Industry, which accounts for one-third of the labor force
and generates over half the GNP, suffers from an aging capital plant and
persistent shortages of energy. The year 1990 witnessed about a 20%
drop in industrial production because of energy and input shortages and
labor unrest. In recent years the agricultural sector has had to contend
with drought, mismanagement, and shortages of inputs. A drought in 1990
contributed to a lackluster harvest, a problem compounded by corruption
and a poor distribution system. The new government is slowly loosening
the tight central controls of Ceausescu''s command economy. It has
instituted moderate land reforms, with close to one-half of cropland now
in private hands, and it has allowed changes in prices for private
agricultural output. Also, the new regime is permitting the
establishment of private enterprises, largely in services, handicrafts,
and small-scale industry. New laws providing for the privatization
of large state firms have been passed. However, most of the early
privatization will involve converting state firms into joint-stock
companies. The selling of shares to the public has not yet been worked
out. Furthermore, the government has halted the old policy of diverting
food from domestic consumption to hard currency export markets. So far,
the government does not seem willing to adopt a thoroughgoing market
system, that is, there is great caution in decontrolling prices because
of public opposition. The government has sharply raised price ceilings
instead of lifting them entirely.
_#_GNP: $69.9 billion, per capita $3,000; real growth rate - 10.8%
(1990 est.)
_#_Inflation rate (consumer prices): 50% (1990 est.)
_#_Unemployment rate: NA%
_#_Budget: revenues $28.4 billion; expenditures $28.4 billion,
including capital expenditures of $12.3 billion (1989)
_#_Exports: $9.2 billion (f.o.b., 1990 est.);
commodities--machinery and equipment 34.7%, fuels, minerals and
metals 24.7%, manufactured consumer goods 16.9%, agricultural materials
and forestry products 11.9%, other 11.6% (1986);
partners--USSR 27%, Eastern Europe 23%, EC 15%, US 5%, China 4%
(1987)
_#_Imports: $10.9 billion (f.o.b., 1990 est.);
commodities--fuels, minerals, and metals 51.0%, machinery and
equipment 26.7%, agricultural and forestry products 11.0%, manufactured
consumer goods 4.2% (1986);
partners--Communist countries 60%, non-Communist countries 40%
(1987)
_#_External debt: $400 million (mid-1990)
_#_Industrial production: growth rate - 20% (1990 est.)
_#_Electricity: 22,700,000 kW capacity; 64,200 million kWh produced,
2,760 kWh per capita (1990)
_#_Industries: mining, timber, construction materials, metallurgy,
chemicals, machine building, food processing, petroleum
_#_Agriculture: accounts for 15% of GNP and 28% of labor force; major
wheat and corn producer; other products--sugar beets, sunflower seed,
potatoes, milk, eggs, meat, grapes
_#_Economic aid: donor--$4.4 billion in bilateral aid to non-Communist
less developed countries (1956-89)
_#_Currency: leu (plural--lei); 1 leu (L) = 100 bani
_#_Exchange rates: lei (L) per US$1--60.00 (June 1991), 22.432
(1990), 14.922 (1989), 14.277 (1988), 14.557 (1987), 16.153 (1986),
17.141 (1985)
_#_Fiscal year: calendar year
_#_Overview: Almost 50% of GDP comes from the agricultural sector;
coffee and tea make up 80-90% of total exports. The amount of fertile
land is limited, however, and deforestation and soil erosion have created
problems. The industrial sector in Rwanda is small, contributing only
16% to GDP. Manufacturing focuses mainly on the processing of
agricultural products. The Rwandan economy remains dependent on coffee
exports and foreign aid, with no relief in sight. Weak international
prices since 1986 have caused the economy to contract and per capita
GDP to decline. A structural adjustment program with the World Bank
began in October 1990. An outbreak of insurgency, also in October, has
dampened any prospects for economic improvement.
_#_GDP: $2.2 billion, per capita $300; real growth rate - 2.2% (1989
est.)
_#_Inflation rate (consumer prices): 1% (1989)
_#_Unemployment rate: NA%
_#_Budget: revenues $391 million; expenditures $491 million, including
capital expenditures of $225 million (1989 est.)
_#_Exports: $117 million (f.o.b., 1989 est.);
commodities--coffee 85%, tea, tin, cassiterite, wolframite,
pyrethrum;
partners--FRG, Belgium, Italy, Uganda, UK, France, US
_#_Imports: $293 million (f.o.b., 1989 est.);
commodities--textiles, foodstuffs, machines and equipment, capital
goods, steel, petroleum products, cement and construction material;
partners--US, Belgium, FRG, Kenya, Japan
_#_External debt: $689 million (December 1990 est.)
_#_Industrial production: growth rate 1.2% (1988); accounts for
16% of GDP
_#_Electricity: 26,000 kW capacity; 112 million kWh produced,
15 kWh per capita (1989)
_#_Industries: mining of cassiterite (tin ore) and wolframite
(tungsten ore), tin, cement, agricultural processing, small-scale
beverage production, soap, furniture, shoes, plastic goods, textiles,
cigarettes
_#_Agriculture: accounts for almost 50% of GDP and about 90% of the
labor force; cash crops--coffee, tea, pyrethrum (insecticide made
from chrysanthemums); main food crops--bananas, beans, sorghum,
potatoes; stock raising; self-sufficiency declining; country imports
foodstuffs as farm production fails to keep up with a 3.8% annual growth
in population
_#_Economic aid: US commitments, including Ex-Im (FY70-89), $128
million; Western (non-US) countries, ODA and OOF bilateral commitments
(1970-88), $1.8 billion; OPEC bilateral aid (1979-89), $45 million;
Communist countries (1970-89), $58 million
_#_Currency: Rwandan franc (plural--francs); 1 Rwandan franc (RF) =
100 centimes
_#_Exchange rates: Rwandan francs (RF) per US$1--120.00 (December
1990), 82.60 (1990), 79.98 (1989), 76.45 (1988), 79.67 (1987), 87.64
(1986), 101.26 (1985)
_#_Fiscal year: calendar year
_#_Overview: The economy depends primarily on financial assistance
from the UK. The local population earns some income from fishing, the
rearing of livestock, and sales of handicrafts. Because there are few
jobs, a large proportion of the work force has left to seek employment
overseas.
_#_GDP: $NA, per capita $NA; real growth rate NA%
_#_Inflation rate (consumer prices): - 1.1% (1986)
_#_Unemployment rate: NA%
_#_Budget: revenues $3.2 million; expenditures $2.9 million,
including capital expenditures of NA (1984)
_#_Exports: $23.9 thousand (f.o.b., 1984);
commodities--fish (frozen and salt-dried skipjack, tuna),
handicrafts;
partners--South Africa, UK
_#_Imports: $2.4 million (c.i.f., 1984);
commodities--food, beverages, tobacco, fuel oils, animal feed,
building materials, motor vehicles and parts, machinery and parts;
partners--UK, South Africa
_#_External debt: $NA
_#_Industrial production: growth rate NA%
_#_Electricity: 9,800 kW capacity; 10 million kWh produced,
1,390 kWh per capita (1989)
_#_Industries: crafts (furniture, lacework, fancy woodwork), fish
_#_Agriculture: maize, potatoes, vegetables; timber production being
developed; crawfishing on Tristan da Cunha
_#_Economic aid: Western (non-US) countries, ODA and OOF bilateral
commitments (1970-88), $184 million
_#_Currency: Saint Helenian pound (plural--pounds);
1 Saint Helenian pound (5S) = 100 pence
_#_Exchange rates: Saint Helenian pounds (5S) per US$1--0.5171
(January 1991), 0.5603 (1990), 0.6099 (1989), 0.5614 (1988), 0.6102
(1987), 0.6817 (1986), 0.7714 (1985); note--the Saint Helenian pound is
at par with the British pound
_#_Fiscal year: 1 April-31 March
_#_Overview: The economy has historically depended on the growing and
processing of sugarcane and on remittances from overseas workers. In
recent years, tourism and export-oriented manufacturing have assumed
larger roles.
_#_GDP: $97.5 million, per capita $2,400; real growth rate 4.6%
(1988)
_#_Inflation rate (consumer prices): 5% (1989)
_#_Unemployment rate: 15% (1989)
_#_Budget: revenues $38.1 million; expenditures $68.1 million,
including capital expenditures of $31.5 million (1991)
_#_Exports: $32.8 million (f.o.b., 1989);
commodities--sugar, clothing, electronics, postage stamps;
partners--US 53%, UK 22%, Trinidad and Tobago 5%, OECS 5% (1988)
_#_Imports: $89.6 million (f.o.b., 1989);
commodities--foodstuffs, intermediate manufactures, machinery,
fuels;
partners--US 36%, UK 17%, Trinidad and Tobago 6%, Canada 3%,
Japan 3%, OECS 4% (1988)
_#_External debt: $26.4 million (1988)
_#_Industrial production: growth rate 11.8% (1988 est.); accounts
for 17% of GDP
_#_Electricity: 15,800 kW capacity; 45 million kWh produced,
1,120 kWh per capita (1990)
_#_Industries: sugar processing, tourism, cotton, salt, copra,
clothing, footwear, beverages
_#_Agriculture: accounts for 10% of GDP; cash crop--sugarcane;
subsistence crops--rice, yams, vegetables, bananas; fishing potential not
fully exploited; most food imported
_#_Economic aid: US commitments, including Ex-Im (FY85-88), $10.7
million; Western (non-US) countries, ODA and OOF bilateral commitments
(1970-88), $57 million
_#_Currency: East Caribbean dollar (plural--dollars);
1 EC dollar (EC$) = 100 cents
_#_Exchange rates: East Caribbean dollars (EC$) per US$1--2.70 (fixed
rate since 1976)
_#_Fiscal year: calendar year
_#_Overview: Since 1983 the economy has shown an impressive average
annual growth rate of almost 5% because of strong agricultural and
tourist sectors. Saint Lucia also possesses an expanding
industrial base supported by foreign investment in manufacturing and
other activities, such as in data processing. The economy, however,
remains vulnerable because the important agricultural sector is dominated
by banana production. Saint Lucia is subject to periodic droughts and/or
tropical storms, and its protected market agreement with the UK for
bananas may end in 1992.
_#_GDP: $273 million, per capita $1,830; real growth rate 4.0% (1989)
_#_Inflation rate (consumer prices): 4.4% (1989)
_#_Unemployment rate: 16.0% (1988)
_#_Budget: revenues $131 million; expenditures $149 million,
including capital expenditures of $71 million (FY90 est.)
_#_Exports: $111.9 million (f.o.b., 1989);
commodities--bananas 54%, clothing 17%, cocoa, vegetables, fruits,
coconut oil;
partners--UK 51%, CARICOM 20%, US 19%, other 10%
_#_Imports: $265.9 million (c.i.f., 1989);
commodities--manufactured goods 23%, machinery and transportation
equipment 27%, food and live animals 18%, chemicals 10%, fuels 6%;
partners--US 35%, CARICOM 16%, UK 15%, Japan 7%, Canada 4%,
other 23%
_#_External debt: $54.5 million (1989)
_#_Industrial production: growth rate 3.5% (1990 est.); accounts for
7% of GDP
_#_Electricity: 32,500 kW capacity; 112 million kWh produced,
730 kWh per capita (1990)
_#_Industries: clothing, assembly of electronic components, beverages,
corrugated boxes, tourism, lime processing, coconut processing
_#_Agriculture: accounts for 16% of GDP and 43% of labor force;
crops--bananas, coconuts, vegetables, citrus fruit, root crops, cocoa;
imports food for the tourist industry
_#_Economic aid: Western (non-US) countries, ODA and OOF bilateral
commitments (1970-88), $118 million
_#_Currency: East Caribbean dollar (plural--dollars);
1 EC dollar (EC$) = 100 cents
_#_Exchange rates: East Caribbean dollars (EC$) per US$1--2.70
(fixed rate since 1976)
_#_Fiscal Year: 1 April-31 March
_#_Overview: The inhabitants have traditionally earned their
livelihood by fishing and by servicing fishing fleets operating off the
coast of Newfoundland. The economy has been declining, however, because
the number of ships stopping at Saint Pierre has dropped steadily over
the years. In March 1989, an agreement between France and Canada set fish
quotas for Saint Pierre''s trawlers fishing in Canadian and
Canadian-claimed waters for three years. The agreement settles a
longstanding dispute that had virtually brought fish exports to a halt.
The islands are heavily subsidized by France. Imports come primarily from
Canada and France.
_#_GDP: $50 million, per capita $7,900; real growth rate NA%
(1990 est.)
_#_Inflation rate (consumer prices): NA%
_#_Unemployment rate: 8.3% (1988)
_#_Budget: revenues $18.3 million; expenditures $18.3 million,
including capital expenditures of $5.5 million (1989)
_#_Exports: $24.1 million (f.o.b., 1988);
commodities--fish and fish products, fox and mink pelts;
partners--US 58%, France 17%, UK 11%, Canada, Portugal
_#_Imports: $61.6 million (c.i.f., 1988);
commodities--meat, clothing, fuel, electrical equipment, machinery,
building materials;
partners--Canada, France, US, Netherlands, UK
_#_External debt: $NA
_#_Industrial production: growth rate NA%
_#_Electricity: 10,000 kW capacity; 25 million kWh produced,
3,970 kWh per capita (1989)
_#_Industries: fish processing and supply base for fishing fleets;
tourism
_#_Agriculture: vegetables, cattle, sheep and pigs for local
consumption; fish catch, 20,500 metric tons (1989)
_#_Economic aid: Western (non-US) countries, ODA and OOF bilateral
commitments (1970-88), $493 million
_#_Currency: French franc (plural--francs); 1 French franc (F) =
100 centimes
_#_Exchange rates: French francs (F) per US$1--5.1307 (January 1991),
5.4453 (1990), 6.3801 (1989), 5.9569 (1988), 6.0107 (1987), 6.9261
(1986), 8.9852 (1985)
_#_Fiscal year: calendar year','08e9d13ce15d291b202f099b9aaa844be58253cfdf7c166fa992ce38094c30be','internet-archive','theciaworldfactb00025gut','txt','84185fe9df79da427349cc1598fd3f69814a2085a9fc1fe0508a3fae0a870f84','https://archive.org/download/theciaworldfactb00025gut/25.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c9a67e99e83c97632c8b58ee805d6d3c10bd66d7ba33bbc8dac4c47c0bdce5c5',1991,'CN','China','economy',113,'_#_Overview: The economy is based largely on tourism (including
gambling), and textile and fireworks manufacturing. Efforts to diversify
have spawned other small industries--toys, artificial flowers, and
electronics. The tourist sector has accounted for roughly 25% of GDP, and
the clothing industry has provided about two-thirds of export earnings.
Macau depends on China for most of its food, fresh water, and energy
imports. Japan and Hong Kong are the main suppliers of raw materials and
capital goods.
_#_GDP: $2.9 billion, per capita $6,560; real growth rate 6%
(1990 est.)
_#_Inflation rate (consumer prices): 9.5% (1989)
_#_Unemployment rate: 2% (1989 est.)
_#_Budget: revenues $305 million; expenditures $298 million, including
capital expenditures of $NA (1989)
_#_Exports: $1.7 billion (1989 est.);
commodities--textiles, clothing, toys;
partners--US 33%, Hong Kong 15%, FRG 12%, France 10% (1987)
_#_Imports: $1.6 billion (1989 est.);
commodities--raw materials, foodstuffs, capital goods;
partners--Hong Kong 39%, China 21%, Japan 10% (1987)
_#_External debt: $91 million (1985)
_#_Industrial production: NA
_#_Electricity: 203,000 kW capacity; 495 million kWh produced,
1,120 kWh per capita (1990)
_#_Industries: clothing, textiles, toys, plastic products, furniture,
tourism
_#_Agriculture: rice, vegetables; food shortages--rice, vegetables,
meat; depends mostly on imports for food requirements
_#_Economic aid: none
_#_Currency: pataca (plural--patacas); 1 pataca (P) = 100 avos
_#_Exchange rates: patacas (P) per US$1--8.03 (1989), 8.044 (1988),
7.993 (1987), 8.029 (1986), 8.045 (1985); note--linked to the Hong Kong
dollar at the rate of 1.03 patacas per Hong Kong dollar
_#_Fiscal year: calendar year
_#_Overview: Madagascar is one of the poorest countries in the world.
During the period 1980-85 it had a population growth of 3% a year and
a - 0.4% GDP growth rate. Agriculture, including fishing and forestry, is
the mainstay of the economy, accounting for over 40% of GDP, employing
about 80% of the labor force, and contributing to more than 70% of total
export earnings. Industry is largely confined to the processing of
agricultural products and textile manufacturing; in 1990 it accounted for
only 16% of GDP and employed 3% of the labor force. In 1986 the
government introduced a five-year development plan that stresses
self-sufficiency in food (mainly rice) by 1990, increased production for
exports, and reduced energy imports.
_#_GDP: $2.4 billion, per capita $200; real growth rate 3.8% (1990
est.)
_#_Inflation rate (consumer prices): 12% (1990)
_#_Unemployment rate: NA%
_#_Budget: revenues $390 million; expenditures $525 million, including
capital expenditures of $240 million (1990 est.)
_#_Exports: $290 million (f.o.b., 1990 est.);
commodities--coffee 45%, vanilla 15%, cloves 11%, sugar, petroleum
products;
partners--France, Japan, Italy, FRG, US
_#_Imports: $436 million (f.o.b., 1990 est.);
commodities--intermediate manufactures 30%, capital goods 28%,
petroleum 15%, consumer goods 14%, food 13%;
partners--France, FRG, UK, other EC, US
_#_External debt: $3.6 billion (1989)
_#_Industrial production: growth rate 5.2% (1990 est.); accounts
for 16% of GDP
_#_Electricity: 119,000 kW capacity; 430 million kWh produced,
40 kWh per capita (1989)
_#_Industries: agricultural processing (meat canneries, soap
factories, breweries, tanneries, sugar refining plants), light consumer
goods industries (textiles, glassware), cement, automobile assembly
plant, paper, petroleum
_#_Agriculture: accounts for 40% of GDP; cash crops--coffee, vanilla,
sugarcane, cloves, cocoa; food crops--rice, cassava, beans, bananas,
peanuts; cattle raising widespread; almost self-sufficient in rice
_#_Illicit drugs: illicit producer of cannabis (cultivated and wild
varieties) used mostly for domestic consumption
_#_Economic aid: US commitments, including Ex-Im (FY70-89), $136
million; Western (non-US) countries, ODA and OOF bilateral commitments
(1970-88), $2.9 billion; Communist countries (1970-89), $491 million
_#_Currency: Malagasy franc (plural--francs);
1 Malagasy franc (FMG) = 100 centimes
_#_Exchange rates: Malagasy francs (FMG) per US$1--1,454.6 (December
1990), 1,494.1 (1990), 1,603.4 (1989), 1,407.1 (1988), 1,069.2 (1987),
676.3 (1986), 662.5 (1985)
_#_Fiscal year: calendar year
_#_Overview: A landlocked country, Malawi ranks among the world''s
least developed with a per capita GDP of $175. The economy is
predominately agricultural and operates under a relatively free
enterprise environment, with about 90% of the population living in
rural areas. Agriculture accounts for 40% of GDP and 90% of export
revenues. After two years of weak performance, economic growth improved
significantly in 1988-90 as a result of good weather and a broadly based
economic adjustment effort by the government. The economy depends on
substantial inflows of economic assistance from the IMF, the World Bank,
and individual donor nations. The closure of traditional trade routes
through Mozambique continues to be a constraint on the economy.
_#_GDP: $1.6 billion, per capita $175; growth rate 4.8% (1990 est.)
_#_Inflation rate (consumer prices): 11.7% (1990)
_#_Unemployment rate: NA%
_#_Budget: revenues $398 million; expenditures $510 million, including
capital expenditures of $154 million (FY91 est.)
_#_Exports: $390 million (f.o.b., 1990 est.);
commodities--tobacco, tea, sugar, coffee, peanuts;
partners--US, UK, Zambia, South Africa, FRG
_#_Imports: $560 million (c.i.f., 1990 est.);
commodities--food, petroleum, semimanufactures, consumer goods,
transportation equipment;
partners--South Africa, Japan, US, UK, Zimbabwe
_#_External debt: $1.4 billion (December 1990 est.)
_#_Industrial production: growth rate 4.9% (1989 est.); accounts
for about 18% of GDP (1988)
_#_Electricity: 181,000 kW capacity; 535 million kWh produced,
60 kWh per capita (1989)
_#_Industries: agricultural processing (tea, tobacco, sugar),
sawmilling, cement, consumer goods
_#_Agriculture: accounts for 40% of GDP; cash crops--tobacco,
sugarcane, cotton, tea, and corn; subsistence crops--potatoes, cassava,
sorghum, pulses; livestock--cattle and goats
_#_Economic aid: US commitments, including Ex-Im (FY70-89), $215
million; Western (non-US) countries, ODA and OOF bilateral commitments
(1970-88), $2.0 billion
_#_Currency: Malawian kwacha (plural--kwacha);
1 Malawian kwacha (MK) = 100 tambala
_#_Exchange rates: Malawian kwacha (MK) per US$1--2.6300 (January
1991), 2.7289 (1990), 2.7595 (1989), 2.5613 (1988), 2.2087 (1987), 1.8611
(1986), 1.7191 (1985)
_#_Fiscal year: 1 April-31 March
_#_Overview: In 1988-90 booming exports helped Malaysia continue to
recover from the severe 1985-86 recession. Real output grew by 8.8% in
1989 and 10% in 1990, helped by vigorous growth in manufacturing
output, further increases in foreign direct investment, particularly
from Japanese and Taiwanese firms facing higher costs at home, and
increased oil production in 1990. Malaysia has become the world''s
third-largest producer of semiconductor devices (after the US and Japan)
and the world''s largest exporter of semiconductor devices. Inflation
remained low as unemployment stood at 6% of the labor force and as
the government followed prudent fiscal/monetary policies. The country is
not self-sufficient in food, and some of the rural population subsists at
the poverty level. Malaysia''s high export dependence leaves it
vulnerable to a recession in the OECD countries or a fall in world
commodity prices.
_#_GDP: $43.1 billion, per capita $2,460; real growth rate 10%
(1990)
_#_Inflation rate (consumer prices): 3.1% (1990 est.)
_#_Unemployment rate: 6% (1990)
_#_Budget: revenues $12.6 billion; expenditures $11.8 billion,
including capital expenditures of $3.2 billion (1991 est.)
_#_Exports: $28.9 billion (f.o.b., 1990 est.);
commodities--natural rubber, palm oil, tin, timber, petroleum,
electronics, light manufactures;
partners--Singapore, US, Japan, EC
_#_Imports: $26.5 billion (f.o.b., 1990 est.);
commodities--food, crude oil, consumer goods, intermediate goods,
capital equipment, chemicals;
partners--Japan, US, Singapore, FRG, UK
_#_External debt: $20.0 billion (1990)
_#_Industrial production: growth rate 15.8% (1990 est.); accounts
for 27% of GDP
_#_Electricity: 5,600,000 kW capacity; 16,500 million kWh produced,
940 kWh per capita (1990)
_#_Industries:
Peninsular Malaysia--rubber and oil palm processing and
manufacturing, light manufacturing industry, electronics, tin mining and
smelting, logging and processing timber;
Sabah--logging, petroleum production;
Sarawak--agriculture processing, petroleum production and refining,
logging
_#_Agriculture:
Peninsular Malaysia--natural rubber, palm oil, rice;
Sabah--mainly subsistence, but also rubber, timber, coconut,
rice;
Sarawak--rubber, timber, pepper; there is a deficit
of rice in all areas; fish catch of 608,000 metric tons in 1987
_#_Illicit drugs: transit point for Golden Triangle heroin
going to the US, Western Europe, and the Third World
_#_Economic aid: US commitments, including Ex-Im (FY70-84), $170
million; Western (non-US) countries, ODA and OOF bilateral commitments
(1970-88), $4.5 billion; OPEC bilateral aid (1979-89), $42 million
_#_Currency: ringgit (plural--ringgits); 1 ringgit (M$) = 100 sen
_#_Exchange rates: ringgits (M$) per US$1--2.7151 (January 1991),
1.7048 (1990), 2.7088 (1989), 2.6188 (1988), 2.5196 (1987), 2.5814
(1986), 2.4830 (1985)
_#_Fiscal year: calendar year
_#_Overview: The economy is based on fishing, tourism, and shipping.
Agriculture is limited to the production of a few subsistence crops that
provide only 10% of food requirements. Fishing is the largest industry,
employing 25% of the work force and accounting for over 60% of exports;
it is also an important source of government revenue. During the 1980s
tourism has become one of the most important and highest growth sectors
of the economy. In 1988 industry accounted for about 5% of GDP. Real
GDP is officially estimated to have increased by about 10% annually
during the period 1974-87, and GDP estimates for 1988 show a further
growth of 9% on the strength of a record fish catch and an improved
tourist season.
_#_GDP: $136 million, per capita $670; real growth rate 9.2% (1988)
_#_Inflation rate (consumer prices): 14% (1988 est.)
_#_Unemployment rate: NEGL%
_#_Budget: revenues $51 million; expenditures $50 million, including
capital expenditures of $25 million (1988 est.)
_#_Exports: $39.4 million (f.o.b., 1988);
commodities--fish 57%, clothing 39%;
partners--Thailand, Western Europe, Sri Lanka
_#_Imports: $105.7 million (c.i.f., 1988);
commodities--intermediate and capital goods 47%, consumer goods
42%, petroleum products 11%;
partners--Japan, Western Europe, Thailand
_#_External debt: $70 million (December 1989)
_#_Industrial production: growth rate - 5.0% (1988); accounts
for 5% of GDP
_#_Electricity: 5,000 kW capacity; 11 million kWh produced,
50 kWh per capita (1990)
_#_Industries: fishing and fish processing, tourism, shipping, boat
building, some coconut processing, garments, woven mats, coir (rope),
handicrafts
_#_Agriculture: accounts for almost 30% of GDP (including fishing);
fishing more important than farming; limited production of coconuts,
corn, sweet potatoes; most staple foods must be imported; fish catch
of 63,000 tons (1988 est.)
_#_Economic aid: US commitments, including Ex-Im (FY70-88), $28
million; Western (non-US) countries, ODA and OOF bilateral commitments
(1970-88), $105 million; OPEC bilateral aid (1979-89), $14 million
_#_Currency: rufiyaa (plural--rufiyaa); 1 rufiyaa (Rf) = 100 laaris
_#_Exchange rates: rufiyaa (Rf) per US$1--9.937 (January 1991),
9.509 (1990), 9.0408 (1989), 8.7846 (1988), 9.2230 (1987), 7.1507 (1986),
7.0981 (1985)
_#_Fiscal year: calendar year
_#_Overview: Mali is among the poorest countries in the world, with
about 70% of its land area desert or semidesert. Economic activity is
largely confined to the riverine area irrigated by the Niger. About 10%
of the population live as nomads and some 80% of the labor force is
engaged in agriculture and fishing. Industrial activity is concentrated
on processing farm commodities.
_#_GDP: $2.0 billion, per capita $250; real growth rate 9.9% (1989
est.)
_#_Inflation rate (consumer prices): NA% (1987)
_#_Unemployment rate: NA%
_#_Budget: revenues $329 million; expenditures $519 million, including
capital expenditures of $178 (1989 est.)
_#_Exports: $285 million (f.o.b., 1989 est.);
commodities--livestock, peanuts, dried fish, cotton, skins;
partners--mostly franc zone and Western Europe
_#_Imports: $513 million (f.o.b., 1989 est.);
commodities--textiles, vehicles, petroleum products, machinery,
sugar, cereals;
partners--mostly franc zone and Western Europe
_#_External debt: $2.2 billion (1989 est.)
_#_Industrial production: growth rate 19.9% (1989 est.); accounts
for 7% of GDP
_#_Electricity: 253,000 kW capacity; 730 million kWh produced,
90 kWh per capita (1990)
_#_Industries: small local consumer goods and processing,
construction, phosphate, gold, fishing
_#_Agriculture: accounts for 50% of GDP; most production based on
small subsistence farms; cotton and livestock products account for over
70% of exports; other crops--millet, rice, corn, vegetables, peanuts;
livestock--cattle, sheep, and goats
_#_Economic aid: US commitments, including Ex-Im (FY70-89), $349
million; Western (non-US) countries, ODA and OOF bilateral commitments
(1970-88), $2.65 billion; OPEC bilateral aid (1979-89), $92 million;
Communist countries (1970-89), $190 million
_#_Currency: Communaute Financiere Africaine franc
(plural--francs); 1 CFA franc (CFAF) = 100 centimes
_#_Exchange rates: Communaute Financiere Africaine francs (CFAF)
per US$1--256.54 (January 1991), 272.26 (1990), 319.01 (1989), 297.85
(1988), 300.54 (1987), 346.30 (1986), 449.26 (1985)
_#_Fiscal year: calendar year
_#_Overview: Significant resources are limestone, a favorable
geographic location, and a productive labor force. Malta produces only
about 20% of its food needs, has limited freshwater supplies, and has no
domestic energy sources. Consequently, the economy is highly dependent on
foreign trade and services. Manufacturing and tourism are the largest
contributors to the economy. Manufacturing accounts for about 27% of GDP,
with the electronics and textile industries major contributors. In 1989
inflation was held to a low 0.9%. Per capita GDP at $5,500 places Malta
in the middle-income range of the world''s nations.
_#_GDP: $1.9 billion, per capita $5,500 (1988); real growth rate 6.4%
(1989)
_#_Inflation rate (consumer prices): 0.9% (1989)
_#_Unemployment rate: 3.7% (1989)
_#_Budget: revenues $1,020 million; expenditures $1,230 million,
including capital expenditures of $380 million (1990 est.)
_#_Exports: $866 million (f.o.b., 1989);
commodities--clothing, textiles, footwear, ships;
partners--Italy 30%, FRG 22%, UK 11%
_#_Imports: $1,328 million (f.o.b., 1989);
commodities--food, petroleum, machinery and semimanufactured goods;
partners--Italy 30%, UK 16%, FRG 13%, US 4%
_#_External debt: $90 million, medium and long-term (December 1987)
_#_Industrial production: growth rate 19.2% (1989); accounts
for 27% of GDP
_#_Electricity: 328,000 kW capacity; 1,110 million kWh produced,
2,990 kWh per capita (1989)
_#_Industries: tourism, electronics, ship repair yard, construction,
food manufacturing, textiles, footwear, clothing, beverages, tobacco
_#_Agriculture: accounts for 3% of GDP; overall, 20% self-sufficient;
main products--potatoes, cauliflower, grapes, wheat, barley, tomatoes,
citrus, cut flowers, green peppers, hogs, poultry, eggs; generally
adequate supplies of vegetables, poultry, milk, pork products; seasonal
or periodic shortages in grain, animal fodder, fruits, other basic
foodstuffs
_#_Economic aid: US commitments, including Ex-Im (FY70-81), $172
million; Western (non-US) countries, ODA and OOF bilateral commitments
(1970-88), $333 million; OPEC bilateral aid (1979-89), $76 million;
Communist countries (1970-88), $48 million
_#_Currency: Maltese lira (plural--liri); 1 Maltese lira (LM) = 100
cents
_#_Exchange rates: Maltese liri (LM) per US$1--0.3004 (January 1991),
0.3172 (1990), 0.3483 (1989), 0.3306 (1988), 0.3451 (1987), 0.3924
(1986), 0.4676 (1985)
_#_Fiscal year: 1 April-31 March
_#_Overview: Offshore banking, manufacturing, and tourism are key
sectors of the economy. The government''s policy of offering incentives to
high-technology companies and financial institutions to locate on the
island has paid off in expanding employment opportunities in high-income
industries. As a result, agriculture and fishing, once the mainstays of
the economy, have declined in their shares of GNP. Banking now
contributes over 20% to GNP and manufacturing about 15%. Trade is mostly
with the UK.
_#_GNP: $490 million, per capita $7,573; real growth rate NA% (1988)
_#_Inflation rate (consumer prices): NA%
_#_Unemployment rate: 1.5% (1988)
_#_Budget: revenues $130.4 million; expenditures $114.4 million,
including capital expenditures of $18.1 million (FY85 est.)
_#_Exports: $NA;
commodities--tweeds, herring, processed shellfish meat;
partners--UK
_#_Imports: $NA;
commodities--timber, fertilizers, fish;
partners--UK
_#_External debt: $NA
_#_Industrial production: growth rate NA%
_#_Electricity: 61,000 kW capacity; 190 million kWh produced,
2,930 kWh per capita (1989)
_#_Industries: an important offshore financial center; financial
services, light manufacturing, tourism
_#_Agriculture: cereals and vegetables; cattle, sheep, pigs, poultry
_#_Economic aid: NA
_#_Currency: Manx pound (plural--pounds); 1 Manx pound (5M) = 100
pence
_#_Exchange rates: Manx pounds (5M) per US$1--0.5171 (January 1991),
0.5603 (1990), 0.6099 (1989), 0.5614 (1988), 0.6102 (1987), 0.6817
(1986), 0.7714 (1985); the Manx pound is at par with the British pound
_#_Fiscal year: 1 April-31 March
_#_Overview: Agriculture and tourism are the mainstays of the economy.
Agricultural production is concentrated on small farms, and the most
important commercial crops are coconuts, tomatoes, melons, and
breadfruit. A few cattle ranches supply the domestic meat market.
Small-scale industry is limited to handicrafts, fish processing, and
copra. The tourist industry is the primary source of foreign exchange and
employs about 10% of the labor force. The islands have few natural
resources, and imports far exceed exports. In 1987 the US Government
provided grants of $40 million out of the Marshallese budget of
$55 million.
_#_GDP: $63 million, per capita $1,500; real growth rate NA%
(1989 est.)
_#_Inflation rate (consumer prices): 5.6% (1981)
_#_Unemployment rate: NA%
_#_Budget: revenues $55 million; expenditures NA, including capital
expenditures of NA (1987 est.)
_#_Exports: $2.5 million (f.o.b., 1985);
commodities--copra, copra oil, agricultural products, handicrafts;
partners--NA
_#_Imports: $29.2 million (c.i.f., 1985);
commodities--foodstuffs, beverages, building materials;
partners--NA
_#_External debt: $NA
_#_Industrial production: growth rate NA%
_#_Electricity: 42,000 kW capacity; 80 million kWh produced, 1,840 kWh
per capita (1990)
_#_Industries: copra, fish, tourism; craft items from shell, wood, and
pearl; offshore banking (embryonic)
_#_Agriculture: coconuts, cacao, taro, breadfruit, fruits, copra;
pigs, chickens
_#_Economic aid: under the terms of the Compact of Free Association,
the US is to provide approximately $40 million in aid annually
_#_Currency: US currency is used
_#_Exchange rates: US currency is used
_#_Fiscal year: 1 October-30 September
_#_Overview: The economy is based on sugarcane, bananas, tourism, and
light industry. Agriculture accounts for about 12% of GDP and the small
industrial sector for 10%. Sugar production has declined, with most of
the sugarcane now used for the production of rum. Banana exports are
increasing, going mostly to France. The bulk of meat, vegetable, and
grain requirements must be imported, contributing to a chronic trade
deficit that requires large annual transfers of aid from France. Tourism
has become more important than agricultural exports as a source of
foreign exchange. The majority of the work force is employed in the
service sector and in administration. In 1986 per capita GDP was
relatively high at $6,000. During 1986 the unemployment rate was 30% and
was particularly severe among younger workers.
_#_GDP: $2.0 billion, per capita $6,000; real growth rate NA% (1986)
_#_Inflation rate (consumer prices): 2.9% (1989)
_#_Unemployment rate: 30% (1986)
_#_Budget: revenues $268 million; expenditures $268 million, including
capital expenditures of $NA (1989 est.)
_#_Exports: $196 million (f.o.b., 1988);
commodities--refined petroleum products, bananas, rum, pineapples;
partners--France 65%, Guadeloupe 24%, FRG (1987)
_#_Imports: $1.3 billion (c.i.f., 1988);
commodities--petroleum products, foodstuffs, construction
materials, vehicles, clothing and other consumer goods;
partners--France 65%, UK, Italy, FRG, Japan, US (1987)
_#_External debt: $NA
_#_Industrial production: growth rate NA%
_#_Electricity: 113,000 kW capacity; 564 million kWh produced,
1,660 kWh per capita (1990)
_#_Industries: construction, rum, cement, oil refining, sugar, tourism
_#_Agriculture: including fishing and forestry, accounts for about 12%
of GDP; principal crops--pineapples, avocados, bananas, flowers,
vegetables, and sugarcane for rum; dependent on imported food,
particularly meat and vegetables
_#_Economic aid: Western (non-US) countries, ODA and OOF bilateral
commitments (1970-88), $9.9 billion
_#_Currency: French franc (plural--francs); 1 French franc (F) = 100
centimes
_#_Exchange rates: French francs (F) per US$1--5.1307 (January 1991),
5.4453 (1990), 6.3801 (1989), 5.9569 (1988), 6.0107 (1987), 6.9261
(1986), 8.9852 (1985)
_#_Fiscal year: calendar year
_#_Overview: A majority of the population still depends on agriculture
and livestock for a livelihood, even though most of the nomads and many
subsistence farmers were forced into the cities by recurrent droughts in
the 1970s and 1980s. Mauritania has extensive deposits of iron ore that
account for almost 50% of total exports. The decline in world demand for
this ore, however, has led to cutbacks in production. The nation''s
coastal waters are among the richest fishing areas in the world, but
overexploitation by foreigners threatens this key source of revenue. The
country''s first deepwater port opened near Nouakchott in 1986. In recent
years, the droughts, the conflict with Senegal, rising energy costs,
and economic mismanagement have resulted in a substantial buildup of
foreign debt. The government now has begun the second stage of an
economic reform program in consultation with the World Bank, the IMF,
and major donor countries.
_#_GDP: $942 million, per capita $500; real growth rate 3.5% (1989
est.)
_#_Inflation rate (consumer prices): 8.2% (1989 est.)
_#_Unemployment rate: 21% (1989 est.)
_#_Budget: revenues $280 million; expenditures $346 million, including
capital expenditures of $61 million (1989 est.)
_#_Exports: $519 million (f.o.b., 1989);
commodities--iron ore, processed fish, small amounts of gum arabic
and gypsum, unrecorded but numerically significant cattle exports to
Senegal;
partners--EC 57%, Japan 39%, Ivory Coast 2%
_#_Imports: $567 million (c.i.f., 1989);
commodities--foodstuffs, consumer goods, petroleum products,
capital goods;
partners--EC 79%, Africa 5%, US 4%, Japan 2%
_#_External debt: $2.3 billion (December 1989)
_#_Industrial production: growth rate 4.4% (1988 est.); accounts
for 10% of GDP
_#_Electricity: 189,000 kW capacity; 136 million kWh produced,
70 kWh per capita (1989)
_#_Industries: fishing, fish processing, mining of iron ore and gypsum
_#_Agriculture: accounts for 29% of GDP (including fishing); largely
subsistence farming and nomadic cattle and sheep herding except in
Senegal river valley; crops--dates, millet, sorghum, root crops; fish
prod','e65434914fbb86a5bf64e36f9e3b124d5792d85ac944a25b9607b83ab90e56db','internet-archive','theciaworldfactb00025gut','txt','84185fe9df79da427349cc1598fd3f69814a2085a9fc1fe0508a3fae0a870f84','https://archive.org/download/theciaworldfactb00025gut/25.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('495616838f489f4675ccf8df6906531c15ece3432ff2ae5ba2c7e84dbe15e5fa',1991,'CN','China','economy',114,'ucts number-one export; large food deficit in years of drought
_#_Economic aid: US commitments, including Ex-Im (FY70-89), $168
million; Western (non-US) countries, ODA and OOF bilateral commitments
(1970-88), $1.2 billion; OPEC bilateral aid (1979-89), $490 million;
Communist countries (1970-89), $277 million
_#_Currency: ouguiya (plural--ouguiya); 1 ouguiya (UM) = 5 khoums
_#_Exchange rates: ouguiya (UM) per US$1--77.450 (January 1991),
80.609 (1990), 83.051 (1989), 75.261 (1988), 73.878 (1987), 74.375
(1986), 77.085 (1985)
_#_Fiscal year: calendar year
_#_Overview: The economy is based on sugar, manufacturing (mainly
textiles), and tourism. Sugarcane is grown on about 90% of the cultivated
land area and accounts for 32% of export earnings. The government''s
development strategy is centered on industrialization (with a view to
exports), agricultural diversification, and tourism. Economic performance
in 1989 was impressive, with 5.0% real growth and low unemployment.
_#_GDP: $2.1 billion, per capita $2,000; real growth rate 5.5% (FY89)
_#_Inflation rate (consumer prices): 12.7% (1989)
_#_Unemployment rate: 2.7% (1989 est.)
_#_Budget: revenues $477 million; expenditures $540 million, including
capital expenditures of $112 million (FY89)
_#_Exports: $993 million (f.o.b., 1989);
commodities--textiles 44%, sugar 40%, light manufactures 10%;
partners--EC and US have preferential treatment, EC 77%, US 15%
_#_Imports: $1.2 billion (f.o.b., 1989);
commodities--manufactured goods 50%, capital equipment 17%,
foodstuffs 13%, petroleum products 8%, chemicals 7%;
partners--EC, US, South Africa, Japan
_#_External debt: $670 million (December 1989)
_#_Industrial production: growth rate 12.9% (FY87); accounts
for 25% of GDP
_#_Electricity: 233,000 kW capacity; 420 million kWh produced,
375 kWh per capita (1989)
_#_Industries: food processing (largely sugar milling), textiles,
wearing apparel, chemicals, metal products, transport equipment,
nonelectrical machinery, tourism
_#_Agriculture: accounts for 10% of GDP; about 90% of cultivated
land in sugarcane; other products--tea, corn, potatoes, bananas, pulses,
cattle, goats, fish; net food importer, especially rice and fish
_#_Illicit drugs: illicit producer of cannabis for the international
drug trade
_#_Economic aid: US commitments, including Ex-Im (FY70-89), $76
million; Western (non-US) countries (1970-88), $628 million; Communist
countries (1970-89), $54 million
_#_Currency: Mauritian rupee (plural--rupees);
1 Mauritian rupee (MauR) = 100 cents
_#_Exchange rates: Mauritian rupees (MauRs) per US$1--14.295 (January
1991), 14.839 (1990), 15.250 (1989), 13.438 (1988), 12.878 (1987), 13.466
(1986), 15.442 (1985)
_#_Fiscal year: 1 July-30 June
_#_Overview: Economic activity is based primarily on the agricultural
sector, including fishing and livestock raising. Mayotte is not
self-sufficient and must import a large portion of its food requirements,
mainly from France. The economy and future development of the island is
heavily dependent on French financial assistance.
_#_GDP: $NA, per capita $NA; real growth rate NA%
_#_Inflation rate (consumer prices): NA%
_#_Unemployment rate: NA%
_#_Budget: revenues NA; expenditures $37.3 million, including capital
expenditures of NA (1985)
_#_Exports: $4.0 million (f.o.b., 1984);
commodities--ylang-ylang, vanilla;
partners--France 79%, Comoros 10%, Reunion 9%
_#_Imports: $21.8 million (f.o.b., 1984);
commodities--building materials, transportation equipment, rice,
clothing, flour;
partners--France 57%, Kenya 16%, South Africa 11%, Pakistan 8%
_#_External debt: $NA
_#_Industrial production: growth rate NA%
_#_Electricity: NA kW capacity; NA million kWh produced, NA kWh
per capita
_#_Industries: newly created lobster and shrimp industry
_#_Agriculture: most important sector; provides all export earnings;
crops--vanilla, ylang-ylang, coffee, copra; imports major share of food
needs
_#_Economic aid: Western (non-US) countries, ODA and OOF bilateral
commitments (1970-87), $323.8 million
_#_Currency: French franc (plural--francs); 1 French franc (F) = 100
centimes
_#_Exchange rates: French francs (F) per US$1--5.1307 (January 1991),
5.4453 (1990), 6.3801 (1989), 5.9569 (1988), 6.0107 (1987), 6.9261
(1986), 8.9852 (1985)
_#_Fiscal year: calendar year
_#_Overview: Mexico''s economy is a mixture of state-owned industrial
plants (notably oil), private manufacturing and services, and both
large-scale and traditional agriculture. In the 1980s Mexico experienced
severe economic difficulties: the nation accumulated large external debts
as world petroleum prices fell; rapid population growth outstripped the
domestic food supply; and inflation, unemployment, and pressures to
emigrate became more acute. Growth in national output, however,
appears to be recovering, rising from 1.4% in 1988 to 3.9% in 1990.
The US is Mexico''s major trading partner, accounting for two-thirds of
its exports and imports. After petroleum, border assembly plants and
tourism are the largest earners of foreign exchange. The government, in
consultation with international economic agencies, is implementing
programs to stabilize the economy and foster growth. In 1991 the
government also plans to begin negotiations with the US and Canada on a
free trade agreement.
_#_GDP: $236 billion, per capita $2,680; real growth rate 3.9%
(1990)
_#_Inflation rate (consumer prices): 30% (1990)
_#_Unemployment rate: 15-18% (1990 est.)
_#_Budget: revenues $44.3 billion; expenditures $55.2 billion,
including capital expenditures of $7.8 billion (1989)
_#_Exports: $26.8 billion (f.o.b., 1990);
commodities--crude oil, oil products, coffee, shrimp, engines,
cotton;
partners--US 66%, EC 16%, Japan 11%
_#_Imports: $29.8 billion (c.i.f., 1990);
commodities--grain, metal manufactures, agricultural machinery,
electrical equipment;
partners--US 62%, EC 18%, Japan 10%
_#_External debt: $96.0 billion (1990)
_#_Industrial production: growth rate 5.3% (1989); accounts for
27% of GDP
_#_Electricity: 27,600,000 kW capacity; 108,976 million kWh produced,
1,240 kWh per capita (1990)
_#_Industries: food and beverages, tobacco, chemicals, iron and steel,
petroleum, mining, textiles, clothing, transportation equipment, tourism
_#_Agriculture: accounts for 9% of GDP and over 25% of work force;
large number of small farms at subsistence level; major food crops--corn,
wheat, rice, beans; cash crops--cotton, coffee, fruit, tomatoes; fish
catch of 1.4 million metric tons among top 20 nations (1987)
_#_Illicit drugs: illicit cultivation of opium poppy and cannabis
continues in spite of government eradication efforts; major link in
chain of countries used to smuggle cocaine from South American
dealers to US markets
_#_Economic aid: US commitments, including Ex-Im (FY70-89), $3.1
billion; Western (non-US) countries, ODA and OOF bilateral commitments
(1970-89), $7.1 billion; Communist countries (1970-89), $110 million
_#_Currency: Mexican peso (plural--pesos);
1 Mexican peso (Mex$) = 100 centavos
_#_Exchange rates: market rate of Mexican pesos (Mex$) per
US$1--2,940.9 (January 1991), 2,812.6 (1990), 2,461.3 (1989),
2,273.1 (1988), 1,378.2 (1987), 611.8 (1986), 256.9 (1985)
_#_Fiscal year: calendar year','c1cbad34964b7a5509c1dc46c914e79af96704f96270dbb4e1717d46ace2df6d','internet-archive','theciaworldfactb00025gut','txt','84185fe9df79da427349cc1598fd3f69814a2085a9fc1fe0508a3fae0a870f84','https://archive.org/download/theciaworldfactb00025gut/25.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d2d12c02ca3889607d63a94f703fb4fcb13f23682e9b0d57dcb1f753a58adafd',1991,'GD','Grenada','economy',123,'_#_Overview: Agriculture, dominated by banana production, is the most
important sector of the economy. The services sector, based mostly on
a growing tourist industry, is also important. The economy continues to
have a high unemployment rate of 30% because of an overdependence on the
weather-plagued banana crop as a major export earner. Government progress
toward diversifying into new industries has been relatively unsuccessful.
_#_GDP: $146 million, per capita $1,315; real growth rate 5.9%
(1989 est.)
_#_Inflation rate (consumer prices): 2.6% (1989)
_#_Unemployment rate: 30% (1989 est.)
_#_Budget: revenues $62 million; expenditures $67 million,
including capital expenditures of $21 million (FY90 est.)
_#_Exports: $74.6 million (f.o.b., 1989);
commodities--bananas 45%, eddoes and dasheen (taro), sweet
potatoes, spices, light manufactures;
partners--UK 43%, CARICOM 37%, US 15%
_#_Imports: $127.5 million (c.i.f., 1989);
commodities--foodstuffs, machinery and equipment, chemicals and
fertilizers, minerals and fuels;
partners--US 42%, CARICOM 19%, UK 15%
_#_External debt: $42.2 million (FY89)
_#_Industrial production: growth rate 0% (1989); accounts for 14%
of GDP
_#_Electricity: 16,600 kW capacity; 64 million kWh produced,
570 kWh per capita (1990)
_#_Industries: food processing (sugar, flour), cement, furniture,
clothing, starch, sheet metal, beverage
_#_Agriculture: accounts for 15% of GDP and 60% of labor force;
provides bulk of exports; products--bananas, coconuts, sweet potatoes,
spices; small numbers of cattle, sheep, hogs, goats; small fish catch
used locally
_#_Economic aid: US commitments, including Ex-Im (FY70-87), $11
million; Western (non-US) countries, ODA and OOF bilateral commitments
(1970-88), $76 million
_#_Currency: East Caribbean dollar (plural--dollars);
1 EC dollar (EC$) = 100 cents
_#_Exchange rates: East Caribbean dollars (EC$) per US$1--2.70 (fixed
rate since 1976)
_#_Fiscal year: calendar year (as of January 1991); previously
1 July-30 June
_#_Overview: More than 2 million tourists visit each year,
contributing about 60% to GDP. The sale of postage stamps to foreign
collectors is another important income producer. The manufacturing sector
employs nearly 40% of the labor force and agriculture less than 4%. The
per capita level of output and standard of living are comparable to
northern Italy.
_#_GDP: $393 million, per capita $17,000; real growth rate 2%
(1990 est.)
_#_Inflation rate (consumer prices): 6% (1990)
_#_Unemployment rate: 6.5% (1985)
_#_Budget: revenues $99.2 million; expenditures $NA, including
capital expenditures of $NA (1983)
_#_Exports: trade data are included with the statistics for Italy;
commodity trade consists primarily of exchanging building stone, lime,
wood, chestnuts, wheat, wine, baked goods, hides, and ceramics for a wide
variety of consumer manufactures
_#_Imports: see _#_Exports
_#_External debt: $NA
_#_Industrial production: growth rate NA%
_#_Electricity: supplied by Italy
_#_Industries: wine, olive oil, cement, leather, textile, tourist
_#_Agriculture: employs less than 4% of labor force; products--wheat,
grapes, corn, olives, meat, cheese, hides; small numbers of cattle, pigs,
horses; depends on Italy for food imports
_#_Economic aid: NA
_#_Currency: Italian lira (plural--lire);
1 Italian lira (Lit) = 100 centesimi; also mints its own coins
_#_Exchange rates: Italian lire (Lit) per US$1--1,134.4 (January
1991), 1,198.1 (1990), 1,372.1 (1989), 1,301.6 (1988), 1,296.1 (1987),
1,490.8 (1986), 1,909.4 (1985)
_#_Fiscal year: calendar year
_#_Overview: The economy has remained dependent on cocoa since the
country gained independence nearly 15 years ago. Since then, however,
cocoa production has gradually deteriorated because of drought and
mismanagement, so that by 1987 output had fallen to less than 50% of
its former levels. As a result, a shortage of cocoa for export has
created a serious balance-of-payments problem. Production of less
important crops, such as coffee, copra, and palm kernels, has
also declined. The value of imports generally exceeds that of
exports by a ratio of 4 to 1. The emphasis on cocoa production at
the expense of other food crops has meant that Sao Tome has to import
90% of food needs. It also has to import all fuels and most manufactured
goods. Over the years, Sao Tome has been unable to service its external
debt, which amounts to roughly 80% of export earnings. Considerable
potential exists for development of a tourist industry, and the
government has taken steps to expand facilities in recent years. The
government also implemented a Five-Year Plan covering 1986-90 to
restructure the economy and reschedule external debt service payments in
cooperation with the International Development Association and Western
lenders.
_#_GDP: $46.0 million, per capita $380; real growth rate 1.5% (1989)
_#_Inflation rate (consumer prices): 36% (1989 est.)
_#_Unemployment rate: NA%
_#_Budget: revenues $10.2 million; expenditures $36.8 million,
including capital expenditures of $22.5 million (1989)
_#_Exports: $5.9 million (f.o.b., 1989 est.);
commodities--cocoa 85%, copra, coffee, palm oil;
partners--FRG, GDR, Netherlands, China
_#_Imports: $26.8 million (f.o.b., 1989 est.);
commodities--machinery and electrical equipment 54%, food
products 23%, other 23%;
partners--Portugal, GDR, Angola, China
_#_External debt: $110 million (1990 est.)
_#_Industrial production: growth rate 7.1% (1986)
_#_Electricity: 5,000 kW capacity; 12 million kWh produced,
100 kWh per capita (1990)
_#_Industries: light construction, shirts, soap, beer, fisheries,
shrimp processing
_#_Agriculture: dominant sector of economy, primary source of exports;
cash crops--cocoa (85%), coconuts, palm kernels, coffee; food
products--bananas, papaya, beans, poultry, fish; not self-sufficient in
food grain and meat
_#_Economic aid: US commitments, including Ex-Im (FY70-89), $8
million; Western (non-US) countries, ODA and OOF bilateral commitments
(1970-87), $59 million
_#_Currency: dobra (plural--dobras); 1 dobra (Db) = 100 centimos
_#_Exchange rates: dobras (Db) per US$1--122.48 (December 1988),
72.827 (1987), 36.993 (1986), 41.195 (1985)
_#_Fiscal year: calendar year','f3575abb2cef5df91bc5bbe4f591109cfb630f73d9b3d3f417964a31c9970115','internet-archive','theciaworldfactb00025gut','txt','84185fe9df79da427349cc1598fd3f69814a2085a9fc1fe0508a3fae0a870f84','https://archive.org/download/theciaworldfactb00025gut/25.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d1593989bcb7f30097f6e35aae462fdc6f897122bf88821534d98a7f7bc37b2c',1991,'SG','Singapore','economy',128,'_#_Overview: Thailand, one of the more advanced developing countries
in Asia, enjoyed a year of 9% growth in 1990, although down from the
double-digit rates of 1987-89. The increasingly sophisticated
manufacturing sector benefited from export-oriented investment, but
the agricultural sector contracted 2%, primarily because of weaker
demand in Thailand''s major overseas markets for commodities such as
rice. The trade deficit almost doubled in 1990, to $9 billion, but
earnings from tourism ($4.7 billion), remittances, and net capital
inflows helped keep the balance of payments in surplus. The government
has followed fairly sound fiscal and monetary policies, aided by
increased tax receipts from the fast-moving economy. In 1990 the
government approved new projects--especially for telecommunications
and roads--needed to refurbish the country''s now overtaxed
infrastructure. Although growth in 1991 will slow further, Thailand''s
economic outlook remains good, assuming the continuation of prudent
government policies in the wake of the 23 February 1991 military coup.
_#_GNP: $79 billion, per capita $1,400; real growth rate 10% (1990
est.)
_#_Inflation rate (consumer prices): 8% (1990 est.)
_#_Unemployment rate: 4.9% (1990 est.)
_#_Budget: revenues $15.2 billion; expenditures $15.2 billion,
including capital expenditures of $4.1 billion (FY91)
_#_Exports: $23.0 billion (f.o.b., 1990 est.);
commodities--light manufactures 66%, fishery products 12%,
rice 8%, tapioca 8%, manufactured gas, corn, tin;
partners--US 22%, Japan 17%, Singapore 7%, Netherlands, FRG,
Hong Kong, UK, Malaysia, China (1989)
_#_Imports: $32.0 billion (c.i.f., 1990 est.);
commodities--machinery and parts 23%, petroleum products 13%,
chemicals 11%, iron and steel, electrical appliances;
partners--Japan 30%, US 11%, Singapore 8%, FRG 5%, Taiwan,
South Korea, China, Malaysia, UK (1989)
_#_External debt: $26.9 billion (end 1990 est.)
_#_Industrial production: growth rate 14% (1990 est.); accounts for
almost 27% of GDP
_#_Electricity: 7,270,000 kW capacity; 29,000 million kWh produced,
530 kWh per capita (1990)
_#_Industries: tourism is the largest source of foreign exchange;
textiles and garments, agricultural processing, beverages, tobacco,
cement, other light manufacturing, such as jewelry; electric appliances
and components, integrated circuits, furniture, plastics; world''s
second-largest tungsten producer and third-largest tin producer
_#_Agriculture: accounts for 15% of GNP and 62% of labor force;
leading producer and exporter of rice and cassava (tapioca); other
crops--rubber, corn, sugarcane, coconuts, soybeans; except for wheat,
self-sufficient in food; fish catch of 2.8 million tons (1989)
_#_Illicit drugs: a minor producer, major illicit trafficker of
heroin, particularly from Burma and Laos, and cannabis for the
international drug market; eradication efforts have reduced the area of
cannabis cultivation and shifted some production to neighboring
countries; opium poppy cultivation has been affected by eradication
efforts
_#_Economic aid: US commitments, including Ex-Im (FY70-89), $870
million; Western (non-US) countries, ODA and OOF bilateral commitments
(1970-88), $8.1 billion; OPEC bilateral aid (1979-89), $19 million
_#_Currency: baht (plural--baht); 1 baht (B) = 100 satang
_#_Exchange rates: baht (B) per US$1--25.224 (January 1991), 25.585
(1990), 25.702 (1989), 25.294 (1988), 25.723 (1987), 26.299 (1986),
27.159 (1985)
_#_Fiscal year: 1 October-30 September
_#_Overview: The economy is heavily dependent on subsistence
agriculture, which accounts for about 35% of GDP and provides
employment for 78% of the labor force. Primary agricultural exports are
cocoa, coffee, and cotton, which together account for about 30% of total
export earnings. Togo is self-sufficient in basic foodstuffs when
harvests are normal. In the industrial sector phosphate mining is by
far the most important activity, with phosphate exports accounting for
about 40% of total foreign exchange earnings. Togo serves as a regional
commercial and trade center. The government actively encourages foreign
investment.
_#_GDP: $1.4 billion, per capita $395; real growth rate 3.6% (1989
est.)
_#_Inflation rate (consumer prices): - 1.2% (1989)
_#_Unemployment rate: 2.0% (1987)
_#_Budget: revenues $330 million; expenditures $363 million,
including capital expenditures of $101 million (1990 est.)
_#_Exports: $331 million (f.o.b., 1989 est.);
commodities--phosphates, cocoa, coffee, cotton, manufactures, palm
kernels;
partners--EC 70%, Africa 9%, US 2%, other 19% (1985)
_#_Imports: $344 million (f.o.b., 1989);
commodities--food, fuels, durable consumer goods, other
intermediate goods, capital goods;
partners--EC 61%, US 6%, Africa 4%, Japan 4%, other 25% (1989)
_#_External debt: $1.3 billion (1990 est.)
_#_Industrial production: growth rate 4.9% (1987 est.); 6% of GDP
_#_Electricity: 179,000 kW capacity; 209 million kWh produced,
60 kWh per capita (1990)
_#_Industries: phosphate mining, agricultural processing, cement,
handicrafts, textiles, beverages
_#_Agriculture: cash crops--coffee, cocoa, cotton; food crops--yams,
cassava, corn, beans, rice, millet, sorghum; livestock production
not significant; annual fish catch, 10,000-14,000 tons
_#_Economic aid: US commitments, including Ex-Im (FY70-89), $132
million; Western (non-US) countries, ODA and OOF bilateral commitments
(1970-88), $1.8 billion; OPEC bilateral aid (1979-89), $35 million;
Communist countries (1970-89), $51 million
_#_Currency: Communaute Financiere Africaine franc
(plural--francs); 1 CFA franc (CFAF) = 100 centimes
_#_Exchange rates: Communaute Financiere Africaine francs (CFAF)
per US$1--256.54 (January 1991), 272.26 (1990), 319.01 (1989),
297.85 (1988), 300.54 (1987), 346.30 (1986), 449.26 (1985)
_#_Fiscal year: calendar year','6533ab38e62b9f91e88a46ce41ce89eab4c201dd56ac426c50d06d5c9631a5f1','internet-archive','theciaworldfactb00025gut','txt','84185fe9df79da427349cc1598fd3f69814a2085a9fc1fe0508a3fae0a870f84','https://archive.org/download/theciaworldfactb00025gut/25.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8d0afbde4801a5b1dd979dda43b2b79b9b961cb6c8f629b6ec5b3281ceb7b0f6',1991,'WS','Samoa','economy',133,'_#_Overview: Tokelau''s small size, isolation, and lack of resources
greatly restrain economic development and confine agriculture to the
subsistence level. The people must rely on aid from New Zealand to
maintain public services, annual aid being substantially greater than
GDP. The principal sources of revenue come from sales of copra, postage
stamps, souvenir coins, and handicrafts. Money is also remitted to
families from relatives in New Zealand.
_#_GDP: $1.4 million, per capita $800; real growth rate NA%
(1988 est.)
_#_Inflation rate (consumer prices): NA%
_#_Unemployment rate: NA%
_#_Budget: revenues $430,830; expenditures $2.8 million, including
capital expenditures of $37,300 (FY87)
_#_Exports: $98,000 (f.o.b., 1983);
commodities--stamps, copra, handicrafts;
partners--NZ
_#_Imports: $323,400 (c.i.f., 1983);
commodities--foodstuffs, building materials, fuel;
partners--NZ
_#_External debt: none
_#_Industrial production: growth rate NA%
_#_Electricity: 200 kW capacity; 300,000 kWh produced,
180 kWh per capita (1990)
_#_Industries: small-scale enterprises for copra production, wood
work, plaited craft goods; stamps, coins; fishing
_#_Agriculture: coconuts, copra; basic subsistence crops--breadfruit,
papaya, bananas; pigs, poultry, goats
_#_Economic aid: Western (non-US) countries, ODA and OOF bilateral
commitments (1970-88), $24 million
_#_Currency: New Zealand dollar (plural--dollars);
1 New Zealand dollar (NZ$) = 100 cents
_#_Exchange rates: New Zealand dollars (NZ$) per US$1--1.6798 (January
1991), 1.6750 (1990), 1.6711 (1989), 1.5244 (1988), 1.6886 (1987), 1.9088
(1986), 2.0064 (1985)
_#_Fiscal year: 1 April-31 March
_#_Overview: The economy''s base is agriculture, which employs about
70% of the labor force and contributes 50% to GDP. Coconuts, bananas, and
vanilla beans are the main crops and make up two-thirds of exports. The
country must import a high proportion of its food, mainly from New
Zealand. The manufacturing sector accounts for only 11% of GDP. Tourism
is the primary source of hard currency earnings, but the island remains
dependent on sizable external aid and remittances to sustain its trade
deficit.
_#_GDP: $86 million, per capita $850; real growth rate 3.6%
(FY89 est.)
_#_Inflation rate (consumer prices): 4.5% (FY89)
_#_Unemployment rate: NA%
_#_Budget: revenues $30.6 million; expenditures $48.9 million,
including capital expenditures of $22.5 million (FY89 est.)
_#_Exports: $9.6 million (f.o.b., FY90 est.);
commodities--coconut oil, desiccated coconut, copra, bananas, taro,
vanilla beans, fruits, vegetables, fish;
partners--NZ 54%, Australia 30%, US 8%, Fiji 5% (FY87)
_#_Imports: $59.9 million (c.i.f., FY90 est.);
commodities--food products, beverages and tobacco, fuels, machinery
and transport equipment, chemicals, building materials;
partners--NZ 39%, Australia 25%, Japan 9%, US 6%, EC 5% (FY87)
_#_External debt: $42.0 million (FY89)
_#_Industrial production: growth rate 15% (FY86); accounts for
11% of GDP
_#_Electricity: 6,000 kW capacity; 8 million kWh produced,
80 kWh per capita (1990)
_#_Industries: tourism, fishing
_#_Agriculture: dominated by coconut, copra, and banana production;
vanilla beans, cocoa, coffee, ginger, black pepper
_#_Economic aid: US commitments, including Ex-Im (FY70-89), $16
million; Western (non-US) countries, ODA and OOF bilateral commitments
(1970-88), $240 million
_#_Currency: pa''anga (plural--pa''anga); 1 pa''anga (T$) = 100 seniti
_#_Exchange rates: pa''anga (T$) per US$1--1.2832 (January 1991),
1.2809 (1990), 1.2637 (1989), 1.2799 (1988), 1.4282 (1987), 1.4960
(1986), 1.4319 (1985)
_#_Fiscal year: 1 July-30 June
_#_Overview: Trinidad and Tobago''s petroleum-based economy began to
emerge from a lengthy depression in 1990. The economy fell sharply
through most of the 1980s, largely because of the decline in oil prices.
This sector accounts for 80% of export earnings and more than 25% of
GDP. The government, in response to the oil revenue loss, pursued a
series of austerity measures that pushed the unemployment rate as high
as 22% in 1988. The economy showed signs of recovery in 1990, however,
helped along by rising oil prices. Agriculture employs only about 11% of
the labor force and produces about 3% of GDP. Since this sector is
small, it has been unable to absorb the large numbers of the unemployed.
The government currently seeks to diversify its export base.
_#_GDP: $4.05 billion, per capita $3,363; real growth rate - 3.7%
(1989)
_#_Inflation rate (consumer prices): 11.4% (1989)
_#_Unemployment rate: 20% (1990)
_#_Budget: revenues $1.5 billion; expenditures $1.7 billion,
including capital expenditures of $NA (1991 est.)
_#_Exports: $1.7 billion (f.o.b., 1990 est.);
commodities--includes reexports--petroleum and petroleum products
82%, steel products 9%, fertilizer, sugar, cocoa, coffee, citrus (1988);
partners--US 53%, CARICOM 16%, EC 10%, Latin America 3% (1989)
_#_Imports: $1.3 billion (c.i.f., 1990 est.);
commodities--raw materials and intermediate goods 47%, capital
goods 26%, consumer goods 26% (1988);
partners--US 51%, Latin America 10%, UK 8%, Canada 5%,
CARICOM 6% (1989)
_#_External debt: $2.5 billion (1989)
_#_Industrial production: growth rate 5.2%, excluding oil refining
(1986); accounts for 30% of GDP, including petroleum
_#_Electricity: 1,176,000 kW capacity; 3,468 million kWh produced,
2,730 kWh per capita (1990)
_#_Industries: petroleum, chemicals, tourism, food processing, cement,
beverage, cotton textiles
_#_Agriculture: highly subsidized sector; major crops--cocoa and
sugarcane; sugarcane acreage is being shifted into rice, citrus, coffee,
vegetables; poultry sector most important source of animal protein; must
import large share of food needs
_#_Economic aid: US commitments, including Ex-Im (FY70-89), $373
million; Western (non-US) countries, ODA and OOF bilateral commitments
(1970-88), $443 million
_#_Currency: Trinidad and Tobago dollar (plural--dollars);
1 Trinidad and Tobago dollar (TT$) = 100 cents
_#_Exchange rates: Trinidad and Tobago dollars (TT$) per US$1--4.2500
(January 1991), 4.2500 (1990), 4.2500 (1989), 3.8438 (1988), 3.6000
(1987), 3.6000 (1986), 2.4500 (1985)
_#_Fiscal year: calendar year
_#_Overview: no economic activity
_#_Overview: The economy depends primarily on petroleum, phosphates,
tourism, and exports of light manufactures for continued growth.
Following two years of drought-induced economic decline, the economy
made a strong recovery in 1990 as a result of a bountiful harvest,
continued export growth, and higher domestic investment. Continued
high inflation and unemployment have eroded popular support for the
government, however, and forced Tunis to slow the pace of economic
reform. Nonetheless, the government appears committed to implementing
its IMF-supported structural adjustment program and to servicing
its foreign debt.
_#_GDP: $10 billion, per capita $1,235; real growth rate 6.5% (1990
est.)
_#_Inflation rate (consumer prices): 7.4% (1989)
_#_Unemployment rate: 15.4% (1989)
_#_Budget: revenues $3.8 billion; expenditures $4.9 billion,
including capital expenditures of $970 million (1991 est.)
_#_Exports: $3.3 billion (f.o.b., 1990 est.);
commodities--hydrocarbons, agricultural products, phosphates and
chemicals;
partners--EC 73%, Middle East 9%, US 1%, Turkey, USSR
_#_Imports: $4.8 billion (f.o.b., 1990 est.);
commodities--industrial goods and equipment 57%, hydrocarbons
13%, food 12%, consumer goods;
partners--EC 68%, US 7%, Canada, Japan, USSR, China, Saudi Arabia,','e26831b23568c291cc55299c0e401d8fbaef74bc447d0d6b45006b3dfbb1b93d','internet-archive','theciaworldfactb00025gut','txt','84185fe9df79da427349cc1598fd3f69814a2085a9fc1fe0508a3fae0a870f84','https://archive.org/download/theciaworldfactb00025gut/25.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c5c59488e9b1d135d200c3c6f7903f9aae9c7d54aa4821b3b914bb774cc8c97a',1991,'DZ','Algeria','economy',136,'_#_External debt: $7.4 billion (December 1990 est.)
_#_Industrial production: growth rate 5% (1989); accounts for
38% of GDP, including petroleum
_#_Electricity: 1,493,000 kW capacity; 4,210 million kWh produced,
530 kWh per capita (1989)
_#_Industries: petroleum, mining (particularly phosphate and iron
ore), textiles, footwear, food, beverages
_#_Agriculture: accounts for 16% of GDP and one-third of labor force;
output subject to severe fluctuations because of frequent droughts;
export crops--olives, dates, oranges, almonds; other products--grain,
sugar beets, wine grapes, poultry, beef, dairy; not self-sufficient in
food; fish catch of 99,200 metric tons (1987)
_#_Economic aid: US commitments, including Ex-Im (FY70-89), $730
million; Western (non-US) countries, ODA and OOF bilateral commitments
(1970-88), $4.9 billion; OPEC bilateral aid (1979-89), $684 million;
Communist countries (1970-89), $410 million
_#_Currency: Tunisian dinar (plural--dinars);
1 Tunisian dinar (TD) = 1,000 millimes
_#_Exchange rates: Tunisian dinars (TD) per US$1--0.8408 (January
1991), 0.8783 (1990), 0.9493 (1989), 0.8578 (1988), 0.8287 (1987), 0.7940
(1986), 0.8345 (1985)
_#_Fiscal year: calendar year
_#_Overview: The economic reforms that Turkey launched in 1980
continue to bring an impressive stream of benefits. The economy has grown
steadily since the early 1980s, with real growth in per capita GDP
increasing more than 6% annually. Agriculture remains the most important
economic sector, employing about 55% of the labor force, accounting for
almost 20% of GDP, and contributing about 20% to exports. Impressive
growth in recent years has not solved all of the economic problems facing
Turkey. Inflation and interest rates remain high, and a large budget
deficit will continue to provide difficulties for a country undergoing a
substantial transformation from a centrally controlled to a free market
economy. The government has launched a multimillion-dollar development
program in the southeastern region, which includes the building of a
dozen dams on the Tigris and Euphrates rivers to generate electric power
and irrigate large tracts of farmland. The planned tapping of huge
additional quantities of Euphrates water has raised serious concern in
the downstream riparian nations of Syria and Iraq.
_#_GDP: $178.0 billion, per capita $3,100; real growth rate 7.6%
(1990)
_#_Inflation rate (consumer prices): 60.3% (1990)
_#_Unemployment rate: 10.4% (1990 est.)
_#_Budget: revenues $27.6 billion; expenditures $34.4 billion,
including capital expenditures of $6.6 billion (1991)
_#_Exports: $11.8 billion (f.o.b., 1989);
commodities--industrial products 78%, crops and livestock
products 20%;
partners--FRG 18%, Italy 8%, Iraq 8%, US 8%, UK 5%, France 4%
_#_Imports: $16.0 billion (f.o.b., 1989);
commodities--crude oil, machinery, transport equipment, metals,
pharmaceuticals, dyes, plastics, rubber, mineral fuels, fertilizers,
chemicals;
partners--FRG 15%, US 11%, Iraq 10%, Italy 7%, France 6%, UK 5%
_#_External debt: $42.8 billion (June 1990)
_#_Industrial production: growth rate 5.9% (1989 est.); accounts
for 32% of GDP
_#_Electricity: 14,315,000 kW capacity; 41,000 million kWh produced,
720 kWh per capita (1990)
_#_Industries: textiles, food processing, mining (coal, chromite,
copper, boron minerals), steel, petroleum, construction, lumber, paper
_#_Agriculture: accounts for 20% of GDP and employs majority of
population; products--tobacco, cotton, grain, olives, sugar beets,
pulses, citrus fruit, variety of animal products; self-sufficient in
food most years
_#_Illicit drugs: one of the world''s major suppliers of licit opiate
products; government maintains strict controls over areas of opium poppy
cultivation and output of poppy straw concentrate
_#_Economic aid: US commitments, including Ex-Im (FY70-89), $2.3
billion; Western (non-US) countries, ODA and OOF bilateral commitments
(1970-87), $8.6 billion; OPEC bilateral aid (1979-89), $665 million;
Communist countries (1970-89), $4.5 billion
_#_Currency: Turkish lira (plural--liras); 1 Turkish lira (TL) = 100
kurus
_#_Exchange rates: Turkish liras (TL) per US$1--2,873.9 (December
1990), 2,608.6 (1990), 2,121.7 (1989), 1,422.3 (1988), 857.2 (1987),
674.5 (1986), 522.0 (1985)
_#_Fiscal year: calendar year
_#_Overview: The economy is based on fishing, tourism, and offshore
banking. Subsistence farming--corn and beans--exists only on the Caicos
Islands, so that most foods, as well as nonfood products, must be
imported.
_#_GDP: $44.9 million, per capita $5,000; real growth rate NA% (1986)
_#_Inflation rate (consumer prices): NA%
_#_Unemployment rate: 12% (1989)
_#_Budget: revenues $12.4 million; expenditures $15.8 million,
including capital expenditures of $2.6 million (FY87)
_#_Exports: $2.9 million (f.o.b., FY84);
commodities--lobster, dried and fresh conch, conch shells;
partners--US, UK
_#_Imports: $26.3 million (c.i.f., FY84);
commodities--foodstuffs, drink, tobacco, clothing;
partners--US, UK
_#_External debt: $NA
_#_Industrial production: growth rate NA%
_#_Electricity: 9,050 kW capacity; 11.1 million kWh produced,
1,140 kWh per capita (1990)
_#_Industries: fishing, tourism, offshore financial services
_#_Agriculture: subsistence farming prevails, based on corn and beans;
fishing more important than farming; not self-sufficient in food
_#_Economic aid: Western (non-US) countries, ODA and OOF bilateral
commitments (1970-88), $100 million
_#_Currency: US currency is used
_#_Exchange rates: US currency is used
_#_Fiscal year: calendar year
_#_Overview: Tuvalu consists of a scattered group of nine coral atolls
with poor soil. The country has no known mineral resources and few
exports. Subsistence farming and fishing are the primary economic
activities. The islands are too small and too remote for development of
a tourist industry. Government revenues largely come from the sale of
stamps and coins and worker remittances. Substantial income is received
annually from an international trust fund established in 1987 by
Australia, New Zealand, and the UK and supported also by Japan and South
Korea.
_#_GNP: $4.6 million, per capita $530; real growth rate NA%
(1989 est.)
_#_Inflation rate (consumer prices): 3.9% (1984)
_#_Unemployment rate: NA%
_#_Budget: revenues $4.3 million; expenditures $4.3 million,
including capital expenditures of $NA (1989)
_#_Exports: $1.0 million (f.o.b., 1983 est.);
commodities--copra;
partners--Fiji, Australia, NZ
_#_Imports: $2.8 million (c.i.f., 1983 est.);
commodities--food, animals, mineral fuels, machinery, manufactured
goods;
partners--Fiji, Australia, NZ
_#_External debt: $NA
_#_Industrial production: growth rate NA
_#_Electricity: 2,600 kW capacity; 3 million kWh produced,
330 kWh per capita (1990)
_#_Industries: fishing, tourism, copra
_#_Agriculture: coconuts, copra
_#_Economic aid: US commitments, including Ex-Im (FY70-87), $1
million; Western (non-US) countries, ODA and OOF bilateral commitments
(1970-87), $96 million
_#_Currency: Tuvaluan dollar and Australian dollar (plural--dollars);
1 Tuvaluan dollar ($T) or 1 Australian dollar ($A) = 100 cents
_#_Exchange rates: Tuvaluan dollars ($T) or Australian dollars ($A)
per US$1--1.2834 (January 1991), 1.2799 (1990), 1.2618 (1989), 1.2752
(1988), 1.4267 (1987), 1.4905 (1986), 1.4269 (1985)
_#_Fiscal year: NA
_#_Overview: Uganda has substantial natural resources, including
fertile soils, regular rainfall, and sizable mineral deposits of copper
and cobalt. The economy has been devastated by much political
instability, mismanagement, and civil war since independence in 1962,
keeping Uganda poor with a per capita income of about $300. (GDP remains
below the levels of the early 1970s, as does industrial production.)
Agriculture is the most important sector of the economy, employing over
80% of the work force. Coffee is the major export crop and accounts
for the bulk of export revenues. Since 1986 the government has
acted to rehabilitate and stabilize the economy by undertaking
currency reform, raising producer prices on export crops, increasing
petroleum prices, and improving civil service wages. The policy changes
are especially aimed at dampening inflation, which was running at over
300% in 1987, and boosting production and export earnings.
_#_GDP: $4.9 billion, per capita $290 (1988); real growth rate 6.1%
(1989 est.)
_#_Inflation rate (consumer prices): 30% (FY90)
_#_Unemployment rate: NA%
_#_Budget: revenues $365 million; expenditures $545 million,
including capital expenditures of $165 million (FY89 est.)
_#_Exports: $273 million (f.o.b., 1989);
commodities--coffee 97%, cotton, tea;
partners--US 25%, UK 18%, France 11%, Spain 10%
_#_Imports: $652 million (c.i.f., 1989);
commodities--petroleum products, machinery, cotton piece goods,
metals, transportation equipment, food;
partners--Kenya 25%, UK 14%, Italy 13%
_#_External debt: $1.9 billion (1990 est.)
_#_Industrial production: growth rate 15.0% (1989 est.); accounts
for 5% of GDP
_#_Electricity: 173,000 kW capacity; 312 million kWh produced,
18 kWh per capita (1989)
_#_Industries: sugar, brewing, tobacco, cotton textiles, cement
_#_Agriculture: accounts for 57% of GDP and 83% of labor force; cash
crops--coffee, tea, cotton, tobacco; food crops--cassava, potatoes, corn,
millet, pulses; livestock products--beef, goat meat, milk, poultry;
self-sufficient in food
_#_Economic aid: US commitments, including Ex-Im (1970-89), $145
million; Western (non-US) countries, ODA and OOF bilateral commitments
(1970-88), $1.2 billion; OPEC bilateral aid (1979-89), $60 million;
Communist countries (1970-89), $169 million
_#_Currency: Ugandan shilling (plural--shillings);
1 Ugandan shilling (USh) = 100 cents
_#_Exchange rates: Ugandan shillings (USh) per US$1--563.18 (January
1991), 428.85 (1990), 223.09 (1989), 106.14 (1988), 42.84 (1987), 14.00
(1986), 6.72 (1985)
_#_Fiscal year: 1 July-30 June
_#_Overview: The UAE has an open economy with one of the world''s
highest incomes per capita outside the OECD nations. This wealth is based
on oil and gas, and the fortunes of the economy fluctuate with the prices
of those commodities. Since 1973, when petroleum prices shot up, the UAE
has undergone a profound transformation from an impoverished region of
small desert principalities to a modern state with a high standard of
living. At present levels of production, crude oil reserves should last
for over 100 years.
_#_GDP: $27.3 billion, per capita $12,100; real growth rate 10%
(1989 est.)
_#_Inflation rate (consumer prices): 3-4% (1989 est.)
_#_Unemployment rate: NEGL (1988)
_#_Budget: revenues $3.8 billion; expenditures $3.7 billion,
including capital expenditures of $NA (1989 est.)
_#_Exports: $15.0 billion (f.o.b., 1989 est.);
commodities--crude oil 65%, natural gas, reexports, dried fish,
dates;
partners--US, EC, Japan
_#_Imports: $9.0 billion (f.o.b., 1989 est.);
commodities--food, consumer and capital goods;
partners--EC, Japan, US
_#_External debt: $11.0 billion (December 1989 est.)
_#_Industrial production: growth rate - 9.3% (1986)
_#_Electricity: 5,773,000 kW capacity; 15,400 million kWh produced,
6,830 kWh per capita (1990)
_#_Industries: petroleum, fishing, petrochemicals, construction
materials, some boat building, handicrafts, pearling
_#_Agriculture: accounts for 2% of GNP and 5% of labor force; cash
crop--dates; food products--vegetables, watermelons, poultry, eggs,
dairy, fish; only 25% self-sufficient in food
_#_Economic aid: donor--pledged $9.1 billion in bilateral aid to less
developed countries (1979-89)
_#_Currency: Emirian dirham (plural--dirhams);
1 Emirian dirham (Dh) = 100 fils
_#_Exchange rates: Emirian dirhams (Dh) per US$1--3.6710 (fixed rate)
_#_Fiscal year: calendar year
_#_Overview: The UK is one of the world''s great trading powers and
financial centers, and its economy ranks among the four largest in
Europe. The economy is essentially capitalistic with a generous admixture
of social welfare programs and government ownership. Over the last decade
the Thatcher government halted the expansion of welfare measures and
promoted extensive reprivatization of the government economic sector.
Agriculture is intensive, highly mechanized, and efficient by European
standards, producing about 60% of food needs with only 1% of the labor
force. Industry is a mixture of public and private enterprises, employing
about 27% of the work force and generating 22% of GDP. The UK is an
energy-rich nation with large coal, natural gas, and oil reserves;
primary energy production accounts for 12% of GDP, one of the highest
shares of any industrial nation. In mid-1990 the economy fell into
recession after eight years of strong economic expansion, which had
raised national output by one quarter. Britain''s inflation rate, which
has been consistently well above those of her major trading partners,
is expected to decline in 1991. Between 1986 and 1990 unemployment
fell from 11% to about 6%, but it is now rising rapidly because of
the economic slowdown. As a major trading nation, the UK will continue
to be greatly affected by world boom or recession, swings in the
international oil market, productivity trends in domestic industry,
and the terms on which the economic integration of Europe proceeds.
_#_GDP: $858.3 billion, per capita $15,000; real growth rate 0.8%
(1990)
_#_Inflation rate (consumer prices): 9.3% (1990)
_#_Unemployment rate: 5.7% (1990)
_#_Budget: revenues $385.0 billion; expenditures $385.5 billion,
including capital expenditures of $35.0 billion (FY91 est.)
_#_Exports: $188.9 billion (f.o.b., 1990);
commodities--manufactured goods, machinery, fuels, chemicals,
semifinished goods, transport equipment;
partners--EC 50.7% (FRG 11.9%, France 10.2%, Netherlands 7.0%),
US 13.1%
_#_Imports: $222 billion (c.i.f., 1990);
commodities--manufactured goods, machinery, semifinished goods,
foodstuffs, consumer goods;
partners--EC 52.6% (FRG 16.6%, France 8.9%, Netherlands 7.9%),
US 10.8%
_#_External debt: $10.5 billion (1990)
_#_Industrial production: growth rate 0% (1990)
_#_Electricity: 98,000,000 kW capacity; 316,500 million kWh produced,
5,520 kWh per capita (1990)
_#_Industries: machinery and transportation equipment, metals, food
processing, paper and paper products, textiles, chemicals, clothing,
other consumer goods, motor vehicles, aircraft, shipbuilding, petroleum,
coal
_#_Agriculture: accounts for only 1.5% of GNP and 1% of labor force;
highly mechanized and efficient farms; wide variety of crops and
livestock products produced; about 60% self-sufficient in food and
feed needs; fish catch of 665,000 metric tons (1987)
_#_Economic aid: donor--ODA and OOF commitments (1970-89), $21.0
billion
_#_Currency: British pound or pound sterling (plural--pounds);
1 British pound (5) = 100 pence
_#_Exchange rates: British pounds (5) per US$1--0.5171 (January
1991), 0.5603 (1990), 0.6099 (1989), 0.5614 (1988), 0.6102 (1987),
0.6817 (1986), 0.7714 (1985)
_#_Fiscal year: 1 April-31 March
_#_Overview: The US has the most powerful, diverse, and
technologically advanced economy in the world, with a per capita GNP
of $21,800, the largest among major industrial nations. In 1989 the
economy enjoyed its seventh successive year of substantial growth, the
longest in peacetime history. The expansion featured moderation in
wage and consumer price increases and a steady reduction in
unemployment to 5.2% of the labor force. In 1990, however, growth
slowed to 1% because of a combination of factors, such as the
worldwide increase in interest rates, Iraq''s invasion of Kuwait in
August, the subsequent spurt in oil prices, and a general decline
in business and consumer confidence. Ongoing problems for the
1990s include inadequate investment in education and other economic
infrastructure, rapidly rising medical costs, and sizable budget and
trade deficits.
_#_GNP: $5,465 billion, per capita $21,800; real growth rate 1.0%
(1990)
_#_Inflation rate (consumer prices): 5.4% (1990)
_#_Unemployment rate: 5.5% (1990)
_#_Budget: revenues $1,106 billion; expenditures $1,272 billion,
including capital expenditures of $NA (FY90 est.)
_#_Exports: $393.9 billion (f.o.b., 1990);
commodities--capital goods, automobiles, industrial supplies and
raw materials, consumer goods, agricultural products;
partners--Western Europe 27.3%, Canada 22.1%, Japan 12.1% (1989)
_#_Imports: $516.2 billion (c.i.f., 1990);
commodities--crude and partly refined petroleum, machinery,
automobiles, consumer goods, industrial raw materials, food and
beverages;
partners--Western Europe 21.5%, Japan 19.7%, Canada 18.8% (1989)
_#_External debt: $581 billion (December 1989)
_#_Industrial production: growth rate 1.0% (1990)
_#_Electricity: 776,550,000 kW capacity; 3,020,000 million kWh
produced, 12,080 kWh per capita (1990)
_#_Industries: leading industrial power in the world, highly
diversified; petroleum, steel, motor vehicles, aerospace,
telecommunications, chemicals, electronics, food processing, consumer
goods, fishing, lumber, mining
_#_Agriculture: accounts for 2% of GNP and 2.8% of labor force;
favorable climate and soils support a wide variety of crops and livestock
production; world''s second-largest producer and number-one exporter of
grain; surplus food producer; fish catch of 5.0 million metric tons
(1988)
_#_Illicit drugs: illicit producer of cannabis for domestic
consumption with 1987 production estimated at 3,500 metric tons
or about 25% of the available marijuana; ongoing eradication program
aimed at small plots and greenhouses has not reduced production
_#_Economic aid: donor--commitments, including ODA and OOF, (FY80-89),
$115.7 billion
_#_Currency: United States dollar (plural--dollars);
1 United States dollar (US$) = 100 cents
_#_Exchange rates: British pounds (5) per US$--0.5171 (January
1991), 0.5603 (1990), 0.6099 (1989), 0.5614 (1988), 0.6102 (1987), 0.6817
(1986), 0.7714 (1985);
Canadian dollars (Can$) per US$--1.1559 (January 1991), 1.1668
(1990), 1.1840 (1989), 1.2307 (1988), 1.3260 (1987), 1.3895 (1986),
1.3655 (1985);
French francs (F) per US$--5.1307 (January 1991), 5.4453 (1990),
6.3801 (1989), 5.9569 (1988), 6.0107 (1987), 6.9261 (1986), 8.9852
(1985);
Italian lire (Lit) per US$--1,134.4 (January 1991), 1,198.1 (1990),
1.372.1 (1989), 1,301.6 (1988), 1,296.1 (1987), 1,490.8 (1986), 1,909.4
(1985);
Japanese yen (3) per US$--133.88 (January 1991), 144.79 (1990),
137.96 (1989), 128.15 (1988), 144.64 (1987), 168.52 (1986), 238.54
(1985);
German deutsche marks (DM) per US$--1.5100 (January 1991), 1.6157
(1990), 1.8800 (1989), 1.7562 (1988), 1.7974 (1987), 2.1715 (1986),
2.9440 (1985)
_#_Fiscal year: 1 October-30 September
_#_Overview: The economy is slowly recovering from the deep recession
of the early 1980s. In 1988 real GDP grew by only 0.5% and in 1989 by
1.5%. The recovery was led by growth in the agriculture and fishing
sectors, agriculture alone contributing 20% to GDP, employing about 11%
of the labor force, and generating a large proportion of export earnings.
Raising livestock, particularly cattle and sheep, is the major
agricultural activity. In 1990, despite healthy exports and an improved
current account, domestic growth remained weak because of government
concentration on the external sector, adverse weather conditions, and
prolonged strikes. Bringing down high inflation, reducing a large fiscal
deficit, and avoiding frequent strikes remain major economic problems
for the government.
_#_GDP: $9.2 billion, per capita $2,970; real growth rate 1%
(1990 est.)
_#_Inflation rate (consumer prices): 129% (1990)
_#_Unemployment rate: 8.8% (1990 est.)
_#_Budget: revenues $1.2 billion; expenditures $1.4 billion,
including capital expenditures of $165 million (1988)
_#_Exports: $1.7 billion (f.o.b., 1990);
commodities--hides and leather goods 17%, beef 10%, wool 9%,
fish 7%, rice 4%;
partners--Brazil 17%, US 15%, FRG 10%, Argentina 10% (1987)
_#_Imports: $1.28 billion (f.o.b., 1990);
commodities--fuels and lubricants 15%, metals, machinery,
transportation equipment, industrial chemicals;
partners--Brazil 24%, Argentina 14%, US 8%, FRG 8% (1987)
_#_External debt: $4.2 billion (1990 est.)
_#_Industrial production: growth rate - 2.1% (1989 est.)
_#_Electricity: 1,950,000 kW capacity; 5,274 million kWh produced,
1,740 kWh per capita (1990)
_#_Industries: meat processing, wool and hides, sugar, textiles,
footwear, leather apparel, tires, cement, fishing, petroleum refining,
wine
_#_Agriculture: large areas devoted to extensive livestock grazing;
wheat, rice, corn, sorghum; self-sufficient in most basic foodstuffs
_#_Economic aid: US commitments, including Ex-Im (FY70-88), $105
million; Western (non-US) countries, ODA and OOF bilateral commitments
(1970-88), $293 million; Communist countries (1970-89), $69 million
_#_Currency: new Uruguayan peso (plural--pesos);
1 new Uruguayan peso (N$Ur) = 100 centesimos
_#_Exchange rates: new Uruguayan pesos (N$Ur) per US$1--1,626.4
(January 1991), 1,171.0 (1990), 605.5 (1989), 359.44 (1988), 226.67
(1987), 151.99 (1986), 101.43 (1985)
_#_Fiscal year: calendar year
_#_Overview: The economy is based primarily on subsistence farming
that provides a living for about 80% of the population. Fishing and
tourism are the other mainstays of the economy. Mineral deposits are
negligible; the country has no known petroleum deposits. A small
light industry sector caters to the local market. Tax revenues come
mainly from import duties.
_#_GDP: $137 million, per capita $860; real growth rate 4.3% (1989
est.)
_#_Inflation rate (consumer prices): 7.8% (1989 est.)
_#_Unemployment rate: NA%
_#_Budget: revenues $90.0 million; expenditures $103.0 million,
including capital expenditures of $45.0 million (1989 est.)
_#_Exports: $14.5 million (f.o.b., 1989 est.);
commodities--copra 59%, cocoa 11%, meat 9%, fish 8%, timber 4%;
partners--Netherlands 34%, France 27%, Japan 17%, Belgium 4%, New
Caledonia 3%, Singapore 2% (1987)
_#_Imports: $58.4 million (f.o.b., 1989 est.);
commodities--machines and vehicles 25%, food and beverages 23%,
basic manufactures 18%, raw materials and fuels 11%, chemicals 6%;
partners--Australia 36%, Japan 13%, NZ 10%, France 8%, Fiji 5%
(1987)
_#_External debt: $30 million (1990 est.)
_#_Industrial production: growth rate NA%
_#_Electricity: 17,000 kW capacity; 30 million kWh produced,
180 kWh per capita (1990)
_#_Industries: food and fish freezing, forestry processing, meat
canning
_#_Agriculture: export crops--copra, cocoa, coffee, and fish;
subsistence crops--copra, taro, yams, coconuts, fruits, and vegetables
_#_Economic aid: Western (non-US) countries, ODA and OOF bilateral
commitments (1970-88), $565 million
_#_Currency: vatu (plural--vatu); 1 vatu (VT) = 100 centimes
_#_Exchange rates: vatu (VT) per US$1--109.62 (January 1991), 116.57
(1990), 116.04 (1989), 104.43 (1988), 109.85 (1987), 106.08 (1986),
106.03 (1985)
_#_Fiscal year: calendar year
_#_Overview: This unique, noncommercial economy is supported
financially by contributions (known as Peter''s Pence) from Roman
Catholics throughout the world, the sale of postage stamps, tourist
mementos, fees for admission to museums, and the sale of publications.
The incomes and living standards of lay workers are comparable to,
or somewhat better than, those of counterparts who work in the city
of Rome.
_#_Budget: revenues $76.6 million; expenditures $168 million,
including capital expenditures of $NA (1991)
_#_Electricity: 5,000 kW standby capacity (1990); power supplied by','c0688cd451712971e37a46fe8995357ed6746d29e0621fb1659eb6b8455199e8','internet-archive','theciaworldfactb00025gut','txt','84185fe9df79da427349cc1598fd3f69814a2085a9fc1fe0508a3fae0a870f84','https://archive.org/download/theciaworldfactb00025gut/25.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('51c3ac289a0d46b98fd6669d3483a56623ea4be9d7c018faddccb6e5086eb48e',1991,'DJ','Djibouti','economy',154,'_#_Overview: For 20 years Communist Yugoslavia had been trying to
replace the Stalinist command economy with a decentralized semimarket
system that features worker self-management councils in all large plants.
This hybrid system neared collapse in late 1989 when inflation soared.
The government applied shock therapy in 1990 under an IMF standby
program that provides tight control over monetary expansion, a freeze
on wages, the pegging of the dinar to the deutsche mark, and a partial
price freeze on energy, transportation, and communal services. This
program brought hyperinflation to a halt and encouraged a rise in
foreign investment. Since June 1990, however, inflation has
rebounded and threatens to rise further in 1991. Estimated annual
inflation for 1990 is 164%. Other huge problems remain: rising
unemployment, the low quality of industrial output, and striking
differences in income between the poorer southern regions and the
comparatively well-off northern areas. Even so, political issues far
outweigh economic problems in importance.
_#_GNP: $120.1 billion, per capita $5,040; real growth rate - 6.3%
(1990 est.)
_#_Inflation rate (consumer prices): 164% (1990)
_#_Unemployment rate: 16% (1990)
_#_Budget: revenues $6.4 billion; expenditures $6.4 billion, including
capital expenditures of $NA (1990)
_#_Exports: $13.3 billion (f.o.b., 1990 est.);
commodities--raw materials and semimanufactures 50%, consumer goods
31%, capital goods and equipment 19%;
partners--EC 53%, USSR and Eastern Europe 27%,
less developed countries 12.9%, US 4.8%, other 2.3%
_#_Imports: $17.6 billion (c.i.f., 1990 est.);
commodities--raw materials and semimanufactures 79%, capital goods
and equipment 15%, consumer goods 6%;
partners--EC 53.5%, USSR and Eastern Europe 22.8%,
less developed countries 15.4%, US 4.6%, other 3.7%
_#_External debt: $18.0 billion, medium and long term (December 1990)
_#_Industrial production: growth rate - 10.9% (1990)
_#_Electricity: 21,000,000 kW capacity; 83,400 million kWh produced,
3,500 kWh per capita (1990)
_#_Industries: metallurgy, machinery and equipment, petroleum,
chemicals, textiles, wood processing, food processing, pulp and paper,
motor vehicles, building materials
_#_Agriculture: diversified, with many small private holdings and
large combines; main crops--corn, wheat, tobacco, sugar beets,
sunflowers; occasionally a net exporter of corn, tobacco, foodstuffs,
live animals
_#_Economic aid: donor--about $3.5 billion in bilateral aid to
non-Communist less developed countries (1966-89)
_#_Currency: Yugoslav dinar (plural--dinars);
1 Yugoslav dinar (YD) = 100 paras; note--on 1 January 1990, Yugoslavia
began issuing a new currency with 1 new dinar equal to 10,000 YD
_#_Exchange rates: Yugoslav dinars (YD) per US$1--13.605 (January
1991), 11.318 (1990), 2.876 (1989), 0.252 (1988), 0.074 (1987), 0.038
(1986), 0.027 (1985); note--as of January 1991 the new dinar is linked to
the German deutsche mark at the rate of 9 new dinars per 1 deustche mark
_#_Fiscal year: calendar year
_#_Overview: In 1990, in spite of large mineral resources and one
of the most developed and diversified economies in Sub-Saharan Africa,
Zaire had a GDP per capita of only about $200, one of the lowest on the
continent. The country''s chronic economic problems worsened in 1990,
with copper production down 20% to a 20-year low, inflation near
250% compared with 100% in 1987-89, and IMF and most World Bank support
suspended until the institution of agreed-on changes. Agriculture, a key
sector of the economy, employs 75% of the population but generates
under 25% of GDP. The main potential for economic development has been
the extractive industries. Mining and mineral processing account for
about one-third of GDP and two-thirds of total export earnings.
Zaire is the world''s largest producer of diamonds.
_#_GDP: $6.6 billion, per capita $180; real growth rate - 2% (1990
est.)
_#_Inflation rate (consumer prices): 242% (1990)
_#_Unemployment rate: NA%
_#_Budget: revenues $685 million; expenditures $1.1 billion, does
not include capital expenditures mostly financed by donors (1990)
_#_Exports: $2.2 billion (f.o.b., 1989 est.);
commodities--copper 37%, coffee 24%, diamonds 12%, cobalt, crude
oil;
partners--US, Belgium, France, FRG, Italy, UK, Japan, South Africa
_#_Imports: $2.1 billion (f.o.b., 1989 est.);
commodities--consumer goods, foodstuffs, mining and other
machinery, transport equipment, fuels;
partners--South Africa, US, Belgium, France, FRG, Italy, Japan, UK
_#_External debt: $7.9 billion (December 1990 est.)
_#_Industrial production: growth rate - 3.1%; accounts for 30%
of GDP (1988)
_#_Electricity: 2,575,000 kW capacity; 5,550 million kWh produced,
150 kWh per capita (1990)
_#_Industries: mining, mineral processing, consumer products
(including textiles, footwear, and cigarettes), processed foods and
beverages, cement, diamonds
_#_Agriculture: cash crops--coffee, palm oil, rubber, quinine; food
crops--cassava, bananas, root crops, corn
_#_Illicit drugs: illicit producer of cannabis, mostly for domestic
consumption
_#_Economic aid: US commitments, including Ex-Im (FY70-89), $1.1
billion; Western (non-US) countries, ODA and OOF bilateral commitments
(1970-88), $6.4 billion; OPEC bilateral aid (1979-89), $35 million;
Communist countries (1970-89), $263 million
_#_Currency: zaire (plural--zaire); 1 zaire (Z) = 100 makuta
_#_Exchange rates: zaire (Z) per US$1--2,113.55 (January 1991),
718.58 (1990), 381.445 (1989), 187.070 (1988), 112.403 (1987), 59.625
(1986), 49.873 (1985)
_#_Fiscal year: calendar year
_#_Overview: The economy has been in decline for more than a decade
with falling imports and growing foreign debt. Economic difficulties
stem from a sustained drop in copper production and ineffective economic
policies. In 1990 real GDP stood only slightly higher than that of 10
years before, while an annual population growth of more than 3% has
brought a decline in per capita GDP of 25% during the same period. A
high inflation rate has also added to Zambia''s economic woes in recent
years.
_#_GDP: $4.7 billion, per capita $580; real growth rate - 2% (1990)
_#_Inflation rate (consumer prices): 80% (1990)
_#_Unemployment rate: NA%
_#_Budget: revenues $1.5 billion; expenditures $1.5 billion,
including capital expenditures of $300 million (1991 est.)
_#_Exports: $1.1 million (f.o.b., 1990);
commodities--copper, zinc, cobalt, lead, tobacco;
partners--EC, Japan, South Africa, US
_#_Imports: $1.1 million (c.i.f., 1990);
commodities--machinery, transportation equipment, foodstuffs,
fuels, manufactures;
partners--EC, Japan, South Africa, US
_#_External debt: $7.2 billion (December 1990)
_#_Industrial production: growth rate 2.9% (1990); accounts for
one-third of GDP
_#_Electricity: 1,900,000 kW capacity; 8,245 million kWh produced,
1,050 kWh per capita (1989)
_#_Industries: copper mining and processing, transport, construction,
foodstuffs, beverages, chemicals, textiles, and fertilizer
_#_Agriculture: accounts for 15% of GDP and 85% of labor force;
crops--corn (food staple), sorghum, rice, peanuts, sunflower, tobacco,
cotton, sugarcane, cassava; cattle, goats, beef, eggs;
marginally self-sufficient in corn
_#_Economic aid: US commitments, including Ex-Im (1970-89), $484
million; Western (non-US) countries, ODA and OOF bilateral commitments
(1970-88), $4.5 billion; OPEC bilateral aid (1979-89), $60 million;
Communist countries (1970-89), $533 million
_#_Currency: Zambian kwacha (plural--kwacha);
1 Zambian kwacha (ZK) = 100 ngwee
_#_Exchange rates: Zambian kwacha (ZK) per US$1--43.2900 (January
1991), 28.9855 (1990), 12.9032 (1989), 8.2237 (1988), 8.8889 (1987),
7.3046 (1986), 2.7137 (1985)
_#_Fiscal year: calendar year
_#_Overview: Agriculture employs three-fourths of the labor force and
supplies almost 40% of exports. The manufacturing sector, based on
agriculture and mining, produces a variety of goods and contributes 35%
to GDP. Mining accounts for only 5% of both GDP and employment, but
supplies of minerals and metals account for about 40% of exports. Wide
year-to-year fluctuations in agricultural production over the past six
years have resulted in an uneven growth rate, one that on average matched
the 3% annual increase in population.
_#_GDP: $5.6 billion, per capita $540; real growth rate 4.2% (1990
est.)
_#_Inflation rate (consumer prices): 13% (1989)
_#_Unemployment rate: at least 20% (1990 est.)
_#_Budget: revenues $2.7 billion; expenditures $3.3 billion, including
capital expenditures of $330 million (FY91)
_#_Exports: $1.7 billion (f.o.b., 1989);
commodities--agricultural 35% (tobacco 20%, other 15%),
manufactures 20%, gold 10%, ferrochrome 10%, cotton 5%;
partners--Europe 55% (EC 40%, Netherlands 5%, other 10%),
Africa 20% (South Africa 10%, other 10%), US 5%
_#_Imports: $1.4 billion (c.i.f., 1989);
commodities--machinery and transportation equipment 37%, other
manufactures 22%, chemicals 16%, fuels 15%;
partners--EC 31%, Africa 29% (South Africa 21%, other 8%), US 8%,
Japan 4%
_#_External debt: $2.96 billion (December 1989 est.)
_#_Industrial production: growth rate 4.7% (1988 est.); accounts
for 35% of GDP
_#_Electricity: 2,036,000 kW capacity; 5,460 million kWh produced,
540 kWh per capita (1989)
_#_Industries: mining, steel, clothing and footwear, chemicals,
foodstuffs, fertilizer, beverage, transportation equipment, wood products
_#_Agriculture: accounts for about 15% of GDP and employs 74% of
population; 40% of land area divided into 4,500 large commercial farms
and 42% in communal lands; crops--corn (food staple), cotton, tobacco,
wheat, coffee, sugarcane, peanuts; livestock--cattle, sheep, goats, pigs;
self-sufficient in food
_#_Economic aid: US commitments, including Ex-Im (FY80-89), $389
million; Western (non-US) countries, ODA and OOF bilateral commitments
(1970-88), $2.3 billion; OPEC bilateral aid (1979-89), $36 million;
Communist countries (1970-89), $134 million
_#_Currency: Zimbabwean dollar (plural--dollars);
1 Zimbabwean dollar (Z$) = 100 cents
_#_Exchange rates: Zimbabwean dollars (Z$) per US$1--2.6724 (January
1991), 2.4480 (1990), 2.1133 (1989), 1.8018 (1988), 1.6611 (1987), 1.6650
(1986), 1.6119 (1985)
_#_Fiscal year: 1 July-30 June
_#_Overview: Taiwan has a dynamic capitalist economy with considerable
government guidance of investment and foreign trade and partial
government ownership of some large banks and industrial firms. Real
growth in GNP has averaged about 9% a year during the past three decades.
Export growth has been even faster and has provided the impetus for
industrialization. Agriculture contributes about 4% to GNP, down from 35%
in 1952. Taiwan currently ranks as number 13 among major trading
countries. Traditional labor-intensive industries are steadily being
replaced with more capital- and technology-intensive industries.
_#_GNP: $150.8 billion, per capita $7,380; real growth rate
5.2% (1990)
_#_Inflation rate (consumer prices): 4.4% (1990)
_#_Unemployment rate: 1.7% (1990)
_#_Budget: revenues $30.3 billion; expenditures $30.1 billion,
including capital expenditures of $NA (FY91 est.)
_#_Exports: $67.2 billion (f.o.b., 1990);
commodities--textiles 15.6%, electrical machinery 18.2%, general
machinery and equipment 14.8%, basic metals and metal products 7.8%,
foodstuffs 1.7%, plywood and wood products 1.6% (1989);
partners--US 36.2%, Japan 13.7% (1989)
_#_Imports: $54.7 billion (c.i.f., 1990);
commodities--machinery and equipment 15.3%, crude oil 5%, chemical
and chemical products 11.1%, basic metals 13.0%, foodstuffs 2.2% (1989);
partners--Japan 31%, US 23%, FRG 5% (1989)
_#_External debt: $1.1 billion (December 1990 est.)
_#_Industrial production: growth rate 4.7% (1990 est.)
_#_Electricity: 17,000,000 kW capacity; 68,000 million kWh produced,
3,310 kWh per capita (1990)
_#_Industries: electronics, textiles, chemicals, clothing,
food processing, plywood, sugar milling, cement, shipbuilding, petroleum
_#_Agriculture: accounts for 4% of GNP and 16% of labor force
(includes part-time farmers); heavily subsidized sector; major
crops--vegetables, rice, fruit, tea; livestock--hogs, poultry, beef,
milk, cattle; not self-sufficient in wheat, soybeans, corn; fish catch
increasing, 1.4 million metric tons (1988)
_#_Economic aid: US, including Ex-Im (FY46-82), $4.6 billion; Western
(non-US) countries, ODA and OOF bilateral commitments (1970-88), $445
million
_#_Currency: New Taiwan dollar (plural--dollars);
1 New Taiwan dollar (NT$) = 100 cents
_#_Exchange rates: New Taiwan dollars per US$1--27.2 (January 1991),
27.243 (November 1990), 26.407 (1989), 28.589 (1988), 31.845 (1987),
37.838 (1986), 39.849 (1985)
_#_Fiscal year: 1 July-30 June','02a8fea9a24840ebc7e6dcdd6d75a8a3500a9456351fe4e72dc94c09d434ded3','internet-archive','theciaworldfactb00025gut','txt','84185fe9df79da427349cc1598fd3f69814a2085a9fc1fe0508a3fae0a870f84','https://archive.org/download/theciaworldfactb00025gut/25.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);

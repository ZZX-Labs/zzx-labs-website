SET NAMES utf8mb4;
CREATE TABLE IF NOT EXISTS worldfactbook_chunks (
  chunk_id CHAR(64) NOT NULL,
  edition_year SMALLINT UNSIGNED NOT NULL,
  entity_code VARCHAR(24) NOT NULL DEFAULT '',
  entity_name VARCHAR(160) NOT NULL DEFAULT '',
  category VARCHAR(96) NOT NULL,
  ordinal INT UNSIGNED NOT NULL,
  content MEDIUMTEXT NOT NULL,
  content_sha256 CHAR(64) NOT NULL,
  source_provider VARCHAR(64) NOT NULL,
  source_identifier VARCHAR(255) NOT NULL,
  source_format VARCHAR(32) NOT NULL,
  source_sha256 CHAR(64) NOT NULL,
  source_url TEXT NOT NULL,
  extractor VARCHAR(64) NOT NULL,
  PRIMARY KEY (chunk_id),
  KEY idx_wfb_year_category (edition_year, category),
  KEY idx_wfb_entity_year (entity_code, edition_year),
  KEY idx_wfb_source_sha (source_sha256)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('55a35a28a5613d66a34342a00920a67c8ae033d45d73917ac4045859bef87b37',1991,'ZW','Zimbabwe','people-and-society',15,'_#_Population: US Bureau of the Census--16,450,304 (July 1991),
growth rate 5.2% (1991) and excludes 3,750,796 refugees in Pakistan
and 1,607,281 refugees in Iran; note--another report indicates a
July 1990 population of 16,904,904, including 3,271,580 refugees in
Pakistan and 1,277,700 refugees in Iran
_#_Birth rate: 44 births/1,000 population (1991)
_#_Death rate: 20 deaths/1,000 population (1991)
_#_Net migration rate: 28 migrants/1,000 population (1991);
note--there are flows across the border in both directions, but data are
fragmentary and unreliable
_#_Infant mortality rate: 164 deaths/1,000 live births (1991)
_#_Life expectancy at birth: 44 years male, 43 years female (1991)
_#_Total fertility rate: 6.3 children born/woman (1991)
_#_Nationality: noun--Afghan(s); adjective--Afghan
_#_Ethnic divisions: Pashtun 50%, Tajik 25%, Uzbek 9%, Hazara
12-15%; minor ethnic groups include Chahar Aimaks, Turkmen, Baloch, and
other
_#_Religion: Sunni Muslim 84%, Shia Muslim 15%, other 1%
_#_Language: Pashtu 50%, Afghan Persian (Dari) 35%, Turkic
languages (primarily Uzbek and Turkmen) 11%, 30 minor languages
(primarily Balochi and Pashai) 4%; much bilingualism
_#_Literacy: 29% (male 44%, female 14%) age 15 and over can
read and write (1990 est.)
_#_Labor force: 4,980,000; agriculture and animal husbandry 67.8%,
industry 10.2%, construction 6.3%, commerce 5.0%, services and other
10.7%, (1980 est.)
_#_Organized labor: some small government-controlled unions
_#_Population: 3,335,044 (July 1991), growth rate 1.8% (1991)
_#_Birth rate: 24 births/1,000 population (1991)
_#_Death rate: 5 deaths/1,000 population (1991)
_#_Net migration rate: 0 migrants/1,000 population (1991)
_#_Infant mortality rate: 50 deaths/1,000 live births (1991)
_#_Life expectancy at birth: 72 years male, 79 years female (1991)
_#_Total fertility rate: 2.9 children born/woman (1991)
_#_Nationality: noun--Albanian(s); adjective--Albanian
_#_Ethnic divisions: Albanian 90%, Greeks 8%, other 2% (Vlachs,
Gypsies, Serbs, and Bulgarians) (1989 est.)
_#_Religion: all mosques and churches were closed in 1967 and
religious observances prohibited; in November 1990 Albania began
allowing private religious practice and was considering the repeal
of the constitutional amendment banning religious activities;
estimates of religious affiliation--Muslim 70%, Greek Orthodox 20%,
Roman Catholic 10%
_#_Language: Albanian (Tosk is official dialect), Greek
_#_Literacy: 72% (male 80%, female 63%) age 9 and over can
read and write (1955)
_#_Labor force: 1,500,000 (1987); agriculture about 60%, industry
and commerce 40% (1986)
_#_Organized labor: Central Council of Albanian Trade Unions, 610,000
members
_#_Population: 26,022,188 (July 1991), growth rate 2.5% (1991)
_#_Birth rate: 32 births/1,000 population (1991)
_#_Death rate: 7 deaths/1,000 population (1991)
_#_Net migration rate: 0 migrants/1,000 population (1991)
_#_Infant mortality rate: 57 deaths/1,000 live births (1991)
_#_Life expectancy at birth: 66 years male, 68 years female (1991)
_#_Total fertility rate: 4.2 children born/woman (1991)
_#_Nationality: noun--Algerian(s); adjective--Algerian
_#_Ethnic divisions: Arab-Berber 99%, European less than
1%
_#_Religion: Sunni Muslim (state religion) 99%, Christian and
Jewish 1%
_#_Language: Arabic (official), French, Berber dialects
_#_Literacy: 50% (male 63%, female 36%) age 15 and over can
read and write (1987)
_#_Labor force: 3,700,000; industry and commerce 40%, agriculture
24%, government 17%, services 10% (1984)
_#_Organized labor: 16-19% of labor force claimed; General Union of
Algerian Workers (UGTA) is the only labor organization and is
subordinate to the National Liberation Front
_#_Population: 43,052 (July 1991), growth rate 2.9% (1991)
_#_Birth rate: 41 births/1,000 population (1991)
_#_Death rate: 4 deaths/1,000 population (1991)
_#_Net migration rate: - 8 immigrants/1,000 population (1991)
_#_Infant mortality rate: 11 deaths/1,000 live births (1991)
_#_Life expectancy at birth: 69 years male, 74 years female (1991)
_#_Total fertility rate: 5.4 children born/woman (1991)
_#_Nationality: noun--American Samoan(s); adjective--American Samoan
_#_Ethnic divisions: Samoan (Polynesian) 90%, Caucasian 2%, Tongan
2%, other 6%
_#_Religion: Christian Congregationalist 50%, Roman Catholic 20%,
Protestant denominations and other 30%
_#_Language: Samoan (closely related to Hawaiian and other Polynesian
languages) and English; most people are bilingual
_#_Literacy: 97% (male 97%, female 97%) age 15 and over can
read and write (1980)
_#_Labor force: 11,145; government 48%, tuna canneries 33%, other
19% (1986 est.)
_#_Organized labor: NA
_#_Note: about 65,000 American Samoans live in the States of
California and Washington and 20,000 in Hawaii
_#_Population: 53,197 (July 1991), growth rate 2.4% (1991)
_#_Birth rate: 11 births/1,000 population (1991)
_#_Death rate: 4 deaths/1,000 population (1991)
_#_Net migration rate: 16 migrants/1,000 population (1991)
_#_Infant mortality rate: 7 deaths/1,000 live births (1991)
_#_Life expectancy at birth: 74 years male, 81 years female (1991)
_#_Total fertility rate: 1.3 children born/woman (1991)
_#_Nationality: noun--Andorran(s); adjective--Andorran
_#_Ethnic divisions: Catalan stock; Spanish 61%, Andorran 30%,
French 6%, other 3%
_#_Religion: virtually all Roman Catholic
_#_Language: Catalan (official); many also speak some French and
Castilian
_#_Literacy: NA% (male NA%, female NA%)
_#_Labor force: NA
_#_Organized labor: none
_#_Population: 8,668,281 (July 1991), growth rate 2.7% (1991)
_#_Birth rate: 47 births/1,000 population (1991)
_#_Death rate: 20 deaths/1,000 population (1991)
_#_Net migration rate: NEGL migrants/1,000 population (1991)
_#_Infant mortality rate: 151 deaths/1,000 live births (1991)
_#_Life expectancy at birth: 42 years male, 46 years female (1991)
_#_Total fertility rate: 6.7 children born/woman (1991)
_#_Nationality: noun--Angolan(s); adjective--Angolan
_#_Ethnic divisions: Ovimbundu 37%, Kimbundu 25%, Bakongo 13%,
Mestico 2%, European 1%, other 22%
_#_Religion: indigenous beliefs 47%, Roman Catholic 38%, Protestant
15% (est.)
_#_Language: Portuguese (official); various Bantu dialects
_#_Literacy: 42% (male 56%, female 28%) age 15 and over can
read and write (1990 est.)
_#_Labor force: 2,783,000 economically active; agriculture 85%,
industry 15% (1985 est.)
_#_Organized labor: about 450,695 (1980)
_#_Population: 6,922 (July 1991), growth rate 0.6% (1991)
_#_Birth rate: 24 births/1,000 population (1991)
_#_Death rate: 9 deaths/1,000 population (1991)
_#_Net migration rate: - 10 migrants/1,000 population (1991)
_#_Infant mortality rate: 18 deaths/1,000 live births (1991)
_#_Life expectancy at birth: 71 years male, 77 years female (1991)
_#_Total fertility rate: 3.1 children born/woman (1991)
_#_Nationality: noun--Anguillan(s); adjective--Anguillan
_#_Ethnic divisions: mainly of black African descent
_#_Religion: Anglican 40%, Methodist 33%, Seventh-Day Adventist 7%,
Baptist 5%, Roman Catholic 3%, other 12%
_#_Language: English (official)
_#_Literacy: 95% (male 95%, female 95%) age 12 and over can
read and write (1984)
_#_Labor force: 2,780 (1984)
_#_Organized labor: NA
_#_Population: no indigenous inhabitants; staffing of research
stations varies seasonally;
Summer (January) population--4,120; Argentina 207, Australia 268,
Belgium 13, Brazil 80, Chile 256, China NA, Ecuador NA, Finland 16,
France 78, Germany 32, Greenpeace 12, India 60, Italy 210, Japan 59,
South Korea 14, Netherlands 10, NZ 264, Norway 23, Peru 39, Poland NA,
South Africa 79, Spain 43, Sweden 10, UK 116, Uruguay NA, US 1,666,
USSR 565 (1989-90);
Winter (July) population--1,066 total; Argentina 150, Australia
71, Brazil 12, Chile 73, China NA, France 33, Germany 19, Greenpeace 5,
India 21, Japan 38, South Korea 14, NZ 11, Poland NA, South Africa 12,
UK 69, Uruguay NA, US 225, USSR 313 (1989-90);
Year-round stations--42 total; Argentina 6, Australia 3, Brazil 1,
Chile 3, China 2, France 1, Germany 2, Greenpeace 1, India 2, Japan 2,
South Korea 1, NZ 1, Poland 1, South Africa 1, UK 5, Uruguay 1, US 3,
USSR 6 (1990-91);
Summer only stations--34 total; Argentina 1, Australia 3, Chile 5,
Finland 1, Germany 4, India 1, Italy 1, Japan 1, NZ 2, Norway 1,
Peru 1, South Africa 1, Spain 1, Sweden 2, UK 1, US 3, USSR 5 (1989-90)
_#_Population: 63,917 (July 1991), growth rate 0.4% (1991)
_#_Birth rate: 18 births/1,000 population (1991)
_#_Death rate: 6 deaths/1,000 population (1991)
_#_Net migration rate: - 9 migrants/1,000 population (1991)
_#_Infant mortality rate: 22 deaths/1,000 live births (1991)
_#_Life expectancy at birth: 70 years male, 74 years female (1991)
_#_Total fertility rate: 1.7 children born/woman (1991)
_#_Nationality: noun--Antiguan(s); adjective--Antiguan
_#_Ethnic divisions: almost entirely of black African origin; some of
British, Portuguese, Lebanese, and Syrian origin
_#_Religion: Anglican (predominant), other Protestant sects, some
Roman Catholic
_#_Language: English (official), local dialects
_#_Literacy: 89% (male 90%, female 88%) age 15 and over having
completed 5 or more years of schooling (1960)
_#_Labor force: 30,000; commerce and services 82%, agriculture 11%,
industry 7% (1983)
_#_Organized labor: Antigua and Barbuda Public Service Association
(ABPSA), membership 500; Antigua Trades and Labor Union (ATLU), 10,000
members; Antigua Workers Union (AWU), 10,000 members (1986 est.)
_#_Population: 32,663,983 (July 1991), growth rate 1.1% (1991)
_#_Birth rate: 20 births/1,000 population (1991)
_#_Death rate: 9 deaths/1,000 population (1991)
_#_Net migration rate: NEGL migrants/1,000 population (1991)
_#_Infant mortality rate: 31 deaths/1,000 live births (1991)
_#_Life expectancy at birth: 68 years male, 74 years female (1991)
_#_Total fertility rate: 2.7 children born/woman (1991)
_#_Nationality: noun--Argentine(s); adjective--Argentine
_#_Ethnic divisions: white 85%; mestizo, Indian, or other nonwhite
groups 15%
_#_Religion: nominally Roman Catholic 90% (less than 20% practicing),
Protestant 2%, Jewish 2%, other 6%
_#_Language: Spanish (official), English, Italian, German, French
_#_Literacy: 95% (male 96%, female 95%) age 15 and over can
read and write (1990 est.)
_#_Labor force: 10,900,000; agriculture 12%, industry 31%, services
57% (1985 est.)
_#_Organized labor: 3,000,000; 28% of labor force
_#_Population: 64,052 (July 1991), growth rate 0.6% (1991)
_#_Birth rate: 15 births/1,000 population (1991)
_#_Death rate: 6 deaths/1,000 population (1991)
_#_Net migration rate: - 4 migrants/1,000 population (1991)
_#_Infant mortality rate: 8 deaths/1,000 live births (1991)
_#_Life expectancy at birth: 72 years male, 80 years female (1991)
_#_Total fertility rate: 1.8 children born/woman (1991)
_#_Nationality: noun--Aruban(s); adjective--Aruban
_#_Ethnic divisions: mixed European/Caribbean Indian 80%
_#_Religion: Roman Catholic 82%, Protestant 8%, also small Hindu,
Muslim, Confucian, and Jewish minority
_#_Language: Dutch (official), Papiamento (a Spanish, Portuguese,
Dutch, English dialect), English (widely spoken), Spanish
_#_Literacy: NA% (male NA%, female NA%)
_#_Labor force: NA, but most employment is in the tourist industry
(1986)
_#_Organized labor: Aruban Workers'' Federation (FTA)
_#_Population: no permanent inhabitants; seasonal caretakers
_#_Population: 17,288,044 (July 1991), growth rate 1.5% (1991)
_#_Birth rate: 15 births/1,000 population (1991)
_#_Death rate: 7 deaths/1,000 population (1991)
_#_Net migration rate: 7 migrants/1,000 population (1991)
_#_Infant mortality rate: 8 deaths/1,000 live births (1991)
_#_Life expectancy at birth: 74 years male, 80 years female (1991)
_#_Total fertility rate: 1.8 children born/woman (1991)
_#_Nationality: noun--Australian(s); adjective--Australian
_#_Ethnic divisions: Caucasian 95%, Asian 4%, Aboriginal and other
1%
_#_Religion: Anglican 26.1%, Roman Catholic 26.0%, other Christian
24.3%
_#_Language: English, native languages
_#_Literacy: 100% (male 100%, female 100%) age 15 and over can
read and write (1980 est.)
_#_Labor force: 7,700,000; finance and services 33.8%, public and
community services 22.3%, wholesale and retail trade 20.1%, manufacturing
and industry 16.2%, agriculture 6.1% (1987)
_#_Organized labor: 42% of labor force (1988)
_#_Population: 7,665,804 (July 1991), growth rate 0.3% (1991)
_#_Birth rate: 12 births/1,000 population (1991)
_#_Death rate: 11 deaths/1,000 population (1991)
_#_Net migration rate: 2 migrants/1,000 population (1991)
_#_Infant mortality rate: 5 deaths/1,000 live births (1991)
_#_Life expectancy at birth: 74 years male, 81 years female (1991)
_#_Total fertility rate: 1.5 children born/woman (1991)
_#_Nationality: noun--Austrian(s); adjective--Austrian
_#_Ethnic divisions: German 99.4%, Croatian 0.3%, Slovene 0.2%,
other 0.1%
_#_Religion: Roman Catholic 85%, Protestant 6%, other 9%
_#_Language: German
_#_Literacy: 99% (male NA%, female NA%) age 15 and over can
read and write (1974 est.)
_#_Labor force: 3,470,000 (1989); services 56.4%, industry and crafts
35.4%, agriculture and forestry 8.1%; an estimated 200,000 Austrians are
employed in other European countries; foreign laborers in Austria number
177,840, about 6% of labor force (1988)
_#_Organized labor: 60.1% of work force; the Austrian Trade Union
Federation has 1,644,408 members (1989)
_#_Population: 252,110 (July 1991), growth rate 1.4% (1991)
_#_Birth rate: 19 births/1,000 population (1991)
_#_Death rate: 5 deaths/1,000 population (1991)
_#_Net migration rate: 0 migrants/1,000 population (1991)
_#_Infant mortality rate: 18 deaths/1,000 live births (1991)
_#_Life expectancy at birth: 69 years male, 76 years female (1991)
_#_Total fertility rate: 2.2 children born/woman (1991)
_#_Nationality: noun--Bahamian(s); adjective--Bahamian
_#_Ethnic divisions: black 85%, white 15%
_#_Religion: Baptist 32%, Anglican 20%, Roman Catholic 19%,
Methodist 6%, Church of God 6%, other Protestant 12%, none or unknown
3%, other 2% (1980)
_#_Language: English; some Creole among Haitian immigrants
_#_Literacy: 90% (male 90%, female 89%) age 15 and over but
definition of literacy not available (1963 est.)
_#_Labor force: 132,600; government 30%, hotels and restaurants 25%,
business services 10%, agriculture 5% (1986)
_#_Organized labor: 25% of labor force
_#_Population: 536,974 (July 1991), growth rate 3.2% (1991)
_#_Birth rate: 27 births/1,000 population (1991)
_#_Death rate: 3 deaths/1,000 population (1991)
_#_Net migration rate: 7 migrants/1,000 population (1991)
_#_Infant mortality rate: 17 deaths/1,000 live births (1991)
_#_Life expectancy at birth: 71 years male, 76 years female (1991)
_#_Total fertility rate: 4.0 children born/woman (1991)
_#_Nationality: noun--Bahraini(s); adjective--Bahraini
_#_Ethnic divisions: Bahraini 63%, Asian 13%, other Arab 10%,
Iranian 8%, other 6%
_#_Religion: Muslim (Shia 70%, Sunni 30%)
_#_Language: Arabic (official); English also widely spoken; Farsi,
Urdu
_#_Literacy: 77% (male 82%, female 69%) age 15 and over can
read and write (1990 est.)
_#_Labor force: 140,000; 42% of labor force is Bahraini; industry
and commerce 85%, agriculture 5%, services 5%, government 3% (1982)
_#_Organized labor: General Committee for Bahrain Workers exists in
only eight major designated companies
_#_Population: uninhabited
_#_Note: American civilians evacuated in 1942 after Japanese air and
naval attacks during World War II; occupied by US military during World
War II, but abandoned after the war; public entry is by special-use
permit only and generally restricted to scientists and educators; a
cemetery and cemetery ruins located near the middle of the west coast
_#_Population: 116,601,424 (July 1991), growth rate 2.3% (1991)
_#_Birth rate: 36 births/1,000 population (1991)
_#_Death rate: 13 deaths/1,000 population (1991)
_#_Net migration rate: 0 migrants/1,000 population (1991)
_#_Infant mortality rate: 118 deaths/1,000 live births (1991)
_#_Life expectancy at birth: 54 years male, 52 years female (1991)
_#_Total fertility rate: 4.7 children born/woman (1991)
_#_Nationality: noun--Bangladeshi(s); adjective--Bangladesh
_#_Ethnic divisions: Bengali 98%, Biharis 250,000, and tribals less
than 1 million
_#_Religion: Muslim 83%, Hindu 16%, Buddhist, Christian, and other
less than 1%
_#_Language: Bangla (official), English widely used
_#_Literacy: 35% (male 47%, female 22%) age 15 and over can
read and write (1990 est.)
_#_Labor force: 35,100,000; agriculture 74%, services 15%, industry
and commerce 11% (FY86); extensive export of labor to Saudi Arabia, UAE,
and Oman (1991)
_#_Organized labor: 3% of labor force belongs to 2,614 registered
unions (1986 est.)
_#_Population: 254,626 (July 1991), growth rate 0.1% (1991)
_#_Birth rate: 16 births/1,000 population (1991)
_#_Death rate: 9 deaths/1,000 population (1991)
_#_Net migration rate: - 6 migrants/1,000 population (1991)
_#_Infant mortality rate: 23 deaths/1,000 live births (1991)
_#_Life expectancy at birth: 70 years male, 76 years female (1991)
_#_Total fertility rate: 1.8 children born/woman (1991)
_#_Nationality: noun--Barbadian(s); adjective--Barbadian
_#_Ethnic divisions: African 80%, mixed 16%, European 4%
_#_Religion: Protestant 67% (Anglican 40%, Pentecostal 8%, Methodist
7%, other 12%), Roman Catholic 4%; none 17%, unknown 3%, other 9%
(1980)
_#_Language: English
_#_Literacy: 99% (male 99%, female 99%) age 15 and over having ever
attended school (1970)
_#_Labor force: 112,300; services and government 37%; commerce 22%;
manufacturing and construction 22%; transportation, storage,
communications, and financial institutions 9%; agriculture 8%; utilities
2% (1985 est.)
_#_Organized labor: 32% of labor force
_#_Population: uninhabited
_#_Population: 9,921,910 (July 1991), growth rate 0.1% (1991)
_#_Birth rate: 12 births/1,000 population (1991)
_#_Death rate: 11 deaths/1,000 population (1991)
_#_Net migration rate: 0 migrants/1,000 population (1991)
_#_Infant mortality rate: 6 deaths/1,000 live births (1991)
_#_Life expectancy at birth: 74 years male, 81 years female (1991)
_#_Total fertility rate: 1.6 children born/woman (1991)
_#_Nationality: noun--Belgian(s); adjective--Belgian
_#_Ethnic divisions: Fleming 55%, Walloon 33%, mixed or other 12%
_#_Religion: Roman Catholic 75%, remainder Protestant or other
_#_Language: Flemish (Dutch) 56%, French 32%, German 1%; legally
bilingual 11%; divided along ethnic lines
_#_Literacy: 99% (male NA%, female NA%) age 15 and over can
read and write (1980 est.)
_#_Labor force: 4,200,000; services 69%, industry 28%, agriculture
3% (1988)
_#_Organized labor: 70% of labor force
_#_Population: 228,069 (July 1991), growth rate 3.6% (1991)
_#_Birth rate: 38 births/1,000 population (1991)
_#_Death rate: 5 deaths/1,000 population (1991)
_#_Net migration rate: 4 migrants/1,000 population (1991)
_#_Infant mortality rate: 35 deaths/1,000 live births (1991)
_#_Life expectancy at birth: male 67 years, female 72 years (1991)
_#_Total fertility rate: 4.7 children born/woman (1991)
_#_Nationality: noun--Belizean(s); adjective--Belizean
_#_Ethnic divisions: Creole 39.7%, Mestizo 33.1%, Maya 9.5%, Garifuna
7.6%, East Indian 2.1%, other 8.0%
_#_Religion: Roman Catholic 62%, Protestant 30% (Anglican 12%,
Methodist 6%, Mennonite 4%, Seventh-Day Adventist 3%, Pentecostal 2%,
Jehovah''s Witnesses 1%, other 2%), none 2%, unknown 3%, other 3%
(1980)
_#_Language: English (official), Spanish, Maya, Garifuna (Carib)
_#_Literacy: 91% (male 91%, female 91%) age 15 and over having ever
attended school (1970)
_#_Labor force: 51,500; agriculture 30.0%, services 16.0%, government
15.4%, commerce 11.2%, manufacturing 10.3%; shortage of skilled
labor and all types of technical personnel (1985)
_#_Organized labor: 12% of labor force; 7 unions currently active
_#_Population: 4,831,823 (July 1991), growth rate 3.3% (1991)
_#_Birth rate: 49 births/1,000 population (1991)
_#_Death rate: 16 deaths/1,000 population (1991)
_#_Net migration rate: 0 migrants/1,000 population (1991)
_#_Infant mortality rate: 119 deaths/1,000 live births (1991)
_#_Life expectancy at birth: 49 years male, 52 years female (1991)
_#_Total fertility rate: 7.0 children born/woman (1991)
_#_Nationality: noun--Beninese (sing., pl.); adjective--Beninese
_#_Ethnic divisions: African 99% (42 ethnic groups, most important
being Fon, Adja, Yoruba, Bariba); Europeans 5,500
_#_Religion: indigenous beliefs 70%, Muslim 15%, Christian 15%
_#_Language: French (official); Fon and Yoruba most common
vernaculars in south; at least six major tribal languages in north
_#_Literacy: 23% (male 32%, female 16%) age 15 and over can
read and write (1990 est.)
_#_Labor force: 1,900,000 (1987); agriculture 60%, transport,
commerce, and public services 38%, industry less than 2%; 49% of
population of working age (1985)
_#_Organized labor: about 75% of wage earners
_#_Population: 58,433 (July 1991), growth rate 1.5% (1991)
_#_Birth rate: 15 births/1,000 population (1991)
_#_Death rate: 7 deaths/1,000 population (1991)
_#_Net migration rate: 7 migrants/1,000 population (1991)
_#_Infant mortality rate: 12 deaths/1,000 live births (1991)
_#_Life expectancy at birth: 72 years male, 78 years female (1991)
_#_Total fertility rate: 1.7 children born/woman (1991)
_#_Nationality: noun--Bermudian(s); adjective--Bermudian
_#_Ethnic divisions: black 61%, white and other 39%
_#_Religion: Anglican 37%, Roman Catholic 14%, African Methodist
Episcopal (Zion) 10%, Methodist 6%, Seventh-Day Adventist 5%, other
28%
_#_Language: English
_#_Literacy: 98% (male 98%, female 99%) age 15 and over can
read and write (1970)
_#_Labor force: 32,000; clerical 25%, services 22%, laborers 21%,
professional and technical 13%, administrative and managerial 10%,
sales 7%, agriculture and fishing 2% (1984)
_#_Organized labor: 8,573 members (1985); largest union is Bermuda
Industrial Union
_#_Population: 1,598,216 (July 1991), growth rate 2.0% (1991)
_#_Birth rate: 37 births/1,000 population (1991)
_#_Death rate: 17 deaths/1,000 population (1991)
_#_Net migration rate: 0 migrants/1,000 population (1991)
_#_Infant mortality rate: 135 deaths/1,000 live births (1991)
_#_Life expectancy at birth: 50 years male, 48 years female (1991)
_#_Total fertility rate: 4.9 children born/woman (1991)
_#_Nationality: noun--Bhutanese (sing., pl.); adjective--Bhutanese
_#_Ethnic divisions: Bhote 60%, ethnic Nepalese 25%, indigenous or
migrant tribes 15%
_#_Religion: Lamaistic Buddhism 75%, Indian- and Nepalese-influenced
Hinduism 25%
_#_Language: Bhotes speak various Tibetan dialects--most widely spoken
dialect is Dzongkha (official); Nepalese speak various Nepalese dialects
_#_Literacy: NA% (male NA%, female NA%)
_#_Labor force: NA; agriculture 93%, services 5%, industry and
commerce 2%; massive lack of skilled labor
_#_Organized labor: not permitted
_#_Population: 7,156,591 (July 1991), growth rate 2.4% (1991)
_#_Birth rate: 34 births/1,000 population (1991)
_#_Death rate: 9 deaths/1,000 population (1991)
_#_Net migration rate: - 1 migrant/1,000 population (1991)
_#_Infant mortality rate: 83 deaths/1,000 live births (1991)
_#_Life expectancy at birth: 59 years male, 64 years female (1991)
_#_Total fertility rate: 4.6 children born/woman (1991)
_#_Nationality: noun--Bolivian(s); adjective Bolivian
_#_Ethnic divisions: Quechua 30%, Aymara 25%, mixed 25-30%,
European 5-15%
_#_Religion: Roman Catholic 95%; active Protestant minority,
especially Evangelical Methodist
_#_Language: Spanish, Quechua, and Aymara (all official)
_#_Literacy: 78% (male 85%, female 71%) age 15 and over can
read and write (1990 est.)
_#_Labor force: 1,700,000; agriculture 50%, services and utilities
26%, manufacturing 10%, mining 4%, other 10% (1983)
_#_Organized labor: 150,000-200,000, concentrated in mining, industry,
construction, and transportation; mostly organized under Bolivian
Workers'' Central (COB) labor federation
_#_Population: 1,258,392 (July 1991), growth rate 2.7% (1991)
_#_Birth rate: 36 births/1,000 populati','ba7a7ffed160d1886f504aeaaaf4b5a317417627d420f75fa514be35547f309d','internet-archive','theciaworldfactb00025gut','txt','84185fe9df79da427349cc1598fd3f69814a2085a9fc1fe0508a3fae0a870f84','https://archive.org/download/theciaworldfactb00025gut/25.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5fff9aa4bbc9a23c6d4ce1f5a2d1da11db5c1dbecd54c7fd3ea9d914f957e79a',1991,'ZW','Zimbabwe','people-and-society',16,'on (1991)
_#_Death rate: 9 deaths/1,000 population (1991)
_#_Net migration rate: 0 migrants/1,000 population (1991)
_#_Infant mortality rate: 43 deaths/1,000 live births (1991)
_#_Life expectancy at birth: 59 years male, 65 years female (1991)
_#_Total fertility rate: 4.6 children born/woman (1991)
_#_Nationality: noun and adjective--Motswana (singular), Batswana
(plural)
_#_Ethnic divisions: Batswana 95%; Kalanga, Basarwa, and Kgalagadi
about 4%; white about 1%
_#_Religion: indigenous beliefs 50%, Christian 50%
_#_Language: English (official), Setswana
_#_Literacy: 23% (male 32%, female 16%) age 15 and over can
read and write (1990 est.)
_#_Labor force: 400,000; 182,200 formal sector employees, most others
are engaged in cattle raising and subsistence agriculture (1988 est.);
19,000 are employed in various mines in South Africa (1988)
_#_Organized labor: 19 trade unions
_#_Population: uninhabited','eca21e01755c76641f37b28460e65707b191f17749250d5086505f4adb1ccf22','internet-archive','theciaworldfactb00025gut','txt','84185fe9df79da427349cc1598fd3f69814a2085a9fc1fe0508a3fae0a870f84','https://archive.org/download/theciaworldfactb00025gut/25.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('89d542301dfe0d5c72ca10dba3af0ea30be70ba75630761ef2d145ea5a00fc24',1991,'AQ','Antarctica','people-and-society',26,'_#_Population: 155,356,073 (July 1991), growth rate 1.8% (1991)
_#_Birth rate: 26 births/1,000 population (1991)
_#_Death rate: 7 deaths/1,000 population (1991)
_#_Net migration rate: 0 migrants/1,000 population (1991)
_#_Infant mortality rate: 68 deaths/1,000 live births (1991)
_#_Life expectancy at birth: 62 years male, 68 years female (1991)
_#_Total fertility rate: 3.1 children born/woman (1991)
_#_Nationality: noun--Brazilian(s); adjective--Brazilian
_#_Ethnic divisions: Portuguese, Italian, German, Japanese, black,
Amerindian; white 55%, mixed 38%, black 6%, other 1%
_#_Religion: Roman Catholic (nominal) 90%
_#_Language: Portuguese (official), Spanish, English, French
_#_Literacy: 81% (male 82%, female 80%) age 15 and over can
read and write (1990 est.)
_#_Labor force: 57,000,000 (1989 est.); services 42%, agriculture
31%, industry 27%
_#_Organized labor: 13,000,000 dues paying members (1989 est.)
_#_Population: no permanent civilian population; formerly about 3,000
islanders
_#_Ethnic divisions: civilian inhabitants, known as the Ilois,
evacuated to Mauritius before construction of UK and US defense
facilities
_#_Population: 12,396 (July 1991), growth rate 1.1% (1991)
_#_Birth rate: 19 births/1,000 population (1991)
_#_Death rate: 5 deaths/1,000 population (1991)
_#_Net migration rate: - 3 migrants/1,000 population (1991)
_#_Infant mortality rate: 14 deaths/1,000 live births (1991)
_#_Life expectancy at birth: 72 years male, 77 years female (1991)
_#_Total fertility rate: 2.1 children born/woman (1991)
_#_Nationality: noun--British Virgin Islander(s); adjective--British
Virgin Islander
_#_Ethnic divisions: black over 90%, remainder of white and Asian
origin
_#_Religion: Protestant 86% (Methodist 45%, Anglican 21%, Church of
God 7%, Seventh-Day Adventist 5%, Baptist 4%, Jehovah''s Witnesses 2%,
other 2%), Roman Catholic 6%, none 2%, other 6% (1981)
_#_Language: English (official)
_#_Literacy: 98% (male 98%, female 98%) age 15 and over can
read and write (1970)
_#_Labor force: 4,911 (1980)
_#_Organized labor: NA% of labor force
_#_Population: 397,777 (July 1991), growth rate 6.3% (1991)
_#_Birth rate: 22 births/1,000 population (1991)
_#_Death rate: 4 deaths/1,000 population (1991)
_#_Net migration rate: 45 migrants/1,000 population (1991)
_#_Infant mortality rate: 10 deaths/1,000 live births (1991)
_#_Life expectancy at birth: 74 years male, 77 years female (1991)
_#_Total fertility rate: 2.9 children born/woman (1991)
_#_Nationality: noun--Bruneian(s); adjective--Bruneian
_#_Ethnic divisions: Malay 64%, Chinese 20%, other 16%
_#_Religion: Muslim (official) 63%, Buddhism 14%, Christian 8%,
indigenous beliefs and other 15% (1981)
_#_Language: Malay (official), English, and Chinese
_#_Literacy: 77% (male 85%, female 69%) age 15 and over can
read and write (1981)
_#_Labor force: 89,000 (includes members of the Army); 33% of labor
force is foreign (1988); government 47.5%; production of oil, natural
gas, services, and construction 41.9%; agriculture, forestry, and fishing
3.8% (1986)
_#_Organized labor: 2% of labor force
_#_Population: 8,910,622 (July 1991), growth rate - 0.2% (1991)
_#_Birth rate: 13 births/1,000 population (1991)
_#_Death rate: 12 deaths/1,000 population (1991)
_#_Net migration rate: - 3 migrants/1,000 population (1991)
_#_Infant mortality rate: 13 deaths/1,000 live births (1991)
_#_Life expectancy at birth: 69 years male, 76 years female (1991)
_#_Total fertility rate: 1.9 children born/woman (1991)
_#_Nationality: noun--Bulgarian(s); adjective--Bulgarian
_#_Ethnic divisions: Bulgarian 85.3%, Turk 8.5%, Gypsy 2.6%,
Macedonian 2.5%, Armenian 0.3%, Russian 0.2%, other 0.6%
_#_Religion: Bulgarian Orthodox 85%; Muslim 13%; Jewish 0.8%;
Roman Catholic 0.5%; Uniate Catholic 0.2%; Protestant,
Gregorian-Armenian, and other 0.5%
_#_Language: Bulgarian; secondary languages closely correspond to
ethnic breakdown
_#_Literacy: 93% (male NA%, female NA%) age 15 and over can
read and write (1970 est.)
_#_Labor force: 4,300,000; industry 33%, agriculture 20%, other 47%
(1987)
_#_Organized labor: Confederation of Independent Trade Unions of
Bulgaria (KNSB); Edinstvo (Unity) People''s Trade Union (splinter
confederation from KNSB); Podkrepa (Support) Labor Confederation,
legally registered in January 1990
_#_Population: 9,359,889 (July 1991), growth rate 3.1% (1991)
_#_Birth rate: 50 births/1,000 population (1991)
_#_Death rate: 16 deaths/1,000 population (1991)
_#_Net migration rate: - 3 migrants/1,000 population (1991)
_#_Infant mortality rate: 119 deaths/1,000 live births (1991)
_#_Life expectancy at birth: 52 years male, 53 years female (1991)
_#_Total fertility rate: 7.1 children born/woman (1991)
_#_Nationality: noun--Burkinabe; adjective--Burkinabe
_#_Ethnic divisions: more than 50 tribes; principal tribe is Mossi
(about 2.5 million); other important groups are Gurunsi, Senufo, Lobi,
Bobo, Mande, and Fulani
_#_Religion: indigenous beliefs about 65%, Muslim 25%,
Christian (mainly Roman Catholic) 10%
_#_Language: French (official); tribal languages belong to Sudanic
family, spoken by 90% of the population
_#_Literacy: 18% (male 28%, female 9%) age 15 and over can
read and write (1990 est.)
_#_Labor force: 3,300,000 residents; 30,000 are wage earners;
agriculture 82%, industry 13%, commerce, services, and government 5%;
20% of male labor force migrates annually to neighboring countries for
seasonal employment (1984); 44% of population of working age (1985)
_#_Organized labor: four principal trade union groups represent less
than 1% of population
_#_Population: 42,112,082 (July 1991), growth rate 2.0% (1991)
_#_Birth rate: 32 births/1,000 population (1991)
_#_Death rate: 13 deaths/1,000 population (1991)
_#_Net migration rate: 0 migrants/1,000 population (1991)
_#_Infant mortality rate: 95 deaths/1,000 live births (1991)
_#_Life expectancy at birth: 53 years male, 56 years female (1991)
_#_Total fertility rate: 4.1 children born/woman (1991)
_#_Nationality: noun--Burmese; adjective--Burmese
_#_Ethnic divisions: Burman 68%, Shan 9%, Karen 7%, Rakhine 4%,
Chinese 3%, Mon 2%, Indian 2%, other 5%
_#_Religion: Buddhist 89%, Christian 4% (Baptist 3%, Roman Catholic
1%), Muslim 4%, animist beliefs 1%, other 2%
_#_Language: Burmese; minority ethnic groups have their own languages
_#_Literacy: 81% (male 89%, female 72%) age 15 and over can
read and write (1990 est.)
_#_Labor force: 16,036,000; agriculture 65.2%, industry 14.3%, trade
10.1%, government 6.3%, other 4.1% (FY89 est.)
_#_Organized labor: Workers'' Asiayone (association), 1,800,000
members; Peasants'' Asiayone, 7,600,000 members
_#_Population: 5,831,233 (July 1991), growth rate 3.2% (1991)
_#_Birth rate: 47 births/1,000 population (1991)
_#_Death rate: 15 deaths/1,000 population (1991)
_#_Net migration rate: 0 migrants/1,000 population (1991)
_#_Infant mortality rate: 109 deaths/1,000 live births (1991)
_#_Life expectancy at birth: 50 years male, 54 years female (1991)
_#_Total fertility rate: 6.9 children born/woman (1991)
_#_Nationality: noun--Burundian(s); adjective--Burundi
_#_Ethnic divisions: Africans--Hutu (Bantu) 85%, Tutsi (Hamitic) 14%,
Twa (Pygmy) 1%; other Africans include about 70,000 refugees, mostly
Rwandans and Zairians; non-Africans include about 3,000 Europeans and
2,000 South Asians
_#_Religion: Christian about 67% (Roman Catholic 62%, Protestant 5%).
indigenous beliefs 32%, Muslim 1%
_#_Language: Kirundi and French (official); Swahili (along Lake
Tanganyika and in the Bujumbura area)
_#_Literacy: 50% (male 61%, female 40%) age 15 and over can
read and write (1990 est.)
_#_Labor force: 1,900,000 (1983 est.); agriculture 93.0%, government
4.0%, industry and commerce 1.5%, services 1.5; 52% of population of
working age (1985)
_#_Organized labor: sole group is the Union of Burundi Workers (UTB);
by charter, membership is extended to all Burundi workers (informally);
active membership figures NA
_#_Population: 7,146,386 (July 1991), growth rate 2.2% (1991)
_#_Birth rate: 38 births/1,000 population (1991)
_#_Death rate: 16 deaths/1,000 population (1991)
_#_Net migration rate: 0 migrants/1,000 population (1991)
_#_Infant mortality rate: 125 deaths/1,000 live births (1991)
_#_Life expectancy at birth: 48 years male, 51 years female (1991)
_#_Total fertility rate: 4.5 children born/woman (1991)
_#_Nationality: noun--Cambodian(s); adjective--Cambodian
_#_Ethnic divisions: Khmer 90%, Chinese 5%, other 5%
_#_Religion: Theravada Buddhism 95%, other 5%
_#_Language: Khmer (official), French
_#_Literacy: 35% (male 48%, female 22%) age 15 and over can
read and write (1990 est.)
_#_Labor force: 2.5-3.0 million; agriculture 80% (1988 est.)
_#_Organized labor: Kampuchea Federation of Trade Unions (FSC); under
government control
_#_Population: 11,390,374 (July 1991), growth rate 2.7% (1991)
_#_Birth rate: 41 births/1,000 population (1991)
_#_Death rate: 15 deaths/1,000 population (1991)
_#_Net migration rate: 0 migrants/1,000 population (1991)
_#_Infant mortality rate: 118 deaths/1,000 live births (1991)
_#_Life expectancy at birth: 49 years male, 53 years female (1991)
_#_Total fertility rate: 5.6 children born/woman (1991)
_#_Nationality: noun--Cameroonian(s); adjective--Cameroonian
_#_Ethnic divisions: over 200 tribes of widely differing background;
Cameroon Highlanders 31%, Equatorial Bantu 19%, Kirdi 11%, Fulani 10%,
Northwestern Bantu 8%, Eastern Nigritic 7%, other African 13%,
non-African less than 1%
_#_Religion: indigenous beliefs 51%, Christian 33%, Muslim 16%
_#_Language: English and French (official), 24 major African language
groups
_#_Literacy: 54% (male 66%, female 43%) age 15 and over can
read and write (1990 est.)
_#_Labor force: NA; agriculture 74.4%, industry and transport 11.4%,
other services 14.2% (1983); 50% of population of working age (15-64
years) (1985)
_#_Organized labor: under 45% of wage labor force
_#_Population: 26,835,036 (July 1991), growth rate 1.1% (1991)
_#_Birth rate: 14 births/1,000 population (1991)
_#_Death rate: 7 deaths/1,000 population (1991)
_#_Net migration rate: 5 migrants/1,000 population (1991)
_#_Infant mortality rate: 7 deaths/1,000 live births (1991)
_#_Life expectancy at birth: 74 years male, 81 years female (1991)
_#_Total fertility rate: 1.7 children born/woman (1991)
_#_Nationality: noun--Canadian(s); adjective--Canadian
_#_Ethnic divisions: British Isles origin 40%, French origin 27%,
other European 20%, indigenous Indian and Eskimo 1.5%
_#_Religion: Roman Catholic 46%, United Church 16%, Anglican 10%
_#_Language: English and French (both official)
_#_Literacy: 99% (male NA%, female NA%) age 15 and over can
read and write (1981 est.)
_#_Labor force: 13,380,000; services 75%, manufacturing 14%,
agriculture 4%, construction 3%, other 4% (1988)
_#_Organized labor: 30.6% of labor force; 39.6% of nonagricultural
paid workers
_#_Population: 386,501 (July 1991), growth rate 3.0% (1991)
_#_Birth rate: 48 births/1,000 population (1991)
_#_Death rate: 10 deaths/1,000 population (1991)
_#_Net migration rate: - 8 migrants/1,000 population (1991)
_#_Infant mortality rate: 63 deaths/1,000 live births (1991)
_#_Life expectancy at birth: 60 years male, 63 years female (1991)
_#_Total fertility rate: 6.6 children born/woman (1991)
_#_Nationality: noun--Cape Verdean(s); adjective--Cape Verdean
_#_Ethnic divisions: Creole (mulatto) about 71%, African 28%, European
1%
_#_Religion: Roman Catholicism fused with indigenous beliefs
_#_Language: Portuguese and Crioulo, a blend of Portuguese and West
African words
_#_Literacy: 66% (male NA%, female NA%) age 15 and over can
read and write (1989 est.)
_#_Labor force: 102,000 (1985 est.); agriculture (mostly subsistence)
57%, services 29%, industry 14% (1981); 51% of population of working age
(1985)
_#_Organized labor: Trade Unions of Cape Verde Unity Center (UNTC-CS)
_#_Population: 27,489 (July 1991), growth rate 4.2% (1991)
_#_Birth rate: 13 births/1,000 population (1991)
_#_Death rate: 5 deaths/1,000 population (1991)
_#_Net migration rate: 33 migrants/1,000 population (1991)
_#_Infant mortality rate: 10 deaths/1,000 live births (1991)
_#_Life expectancy at birth: 74 years male, 80 years female (1991)
_#_Total fertility rate: 1.4 children born/woman (1991)
_#_Nationality: noun--Caymanian(s); adjective--Caymanian
_#_Ethnic divisions: 40% mixed, 20% white, 20% black, 20% expatriates
of various ethnic groups
_#_Religion: United Church (Presbyterian and Congregational),
Anglican, Baptist, Roman Catholic, Church of God, other Protestant
denominations
_#_Language: English
_#_Literacy: 98% (male 98%, female 98%) age 15 and over having ever
attended school (1970)
_#_Labor force: 8,061; service workers 18.7%, clerical 18.6%,
construction 12.5%, finance and investment 6.7%, directors and business
managers 5.9% (1979)
_#_Organized labor: Global Seaman''s Union; Cayman All Trade Union
_#_Population: 2,952,382 (July 1991), growth rate 2.6% (1991)
_#_Birth rate: 44 births/1,000 population (1991)
_#_Death rate: 18 deaths/1,000 population (1991)
_#_Net migration rate: 0 migrants/1,000 population (1991)
_#_Infant mortality rate: 138 deaths/1,000 live births (1991)
_#_Life expectancy at birth: 45 years male, 49 years female (1991)
_#_Total fertility rate: 5.6 children born/woman (1991)
_#_Nationality: noun--Central African(s); adjective--Central African
_#_Ethnic divisions: about 80 ethnic groups, the majority of which
have related ethnic and linguistic characteristics; Baya 34%, Banda 27%,
Sara 10%, Mandjia 21%, Mboum 4%, M''Baka 4%; 6,500 Europeans, of whom
3,600 are French
_#_Religion: indigenous beliefs 24%, Protestant 25%, Roman Catholic
25%, Muslim 15%, other 11%; animistic beliefs and practices strongly
influence the Christian majority
_#_Language: French (official); Sangho (lingua franca and national
language); Arabic, Hunsa, Swahili
_#_Literacy: 27% (male 33%, female 15%) age 15 and over can
read and write (1990 est.)
_#_Labor force: 775,413 (1986 est.); agriculture 85%, commerce and
services 9%, industry 3%, government 3%; about 64,000 salaried workers;
55% of population of working age (1985)
_#_Organized labor: 1% of labor force','27aae4ec5aca462e3427eccde0511dbc14bc39e8c8a7bd6dc8d1ad0ee25ac5ae','internet-archive','theciaworldfactb00025gut','txt','84185fe9df79da427349cc1598fd3f69814a2085a9fc1fe0508a3fae0a870f84','https://archive.org/download/theciaworldfactb00025gut/25.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8a94a971bf91288af0bc8895b694ef0bd2fc332bfa42b304d320bf7613a227c7',1991,'NG','Nigeria','people-and-society',33,'_#_Population: 5,122,467 (July 1991), growth rate 2.1% (1991)
_#_Birth rate: 42 births/1,000 population (1991)
_#_Death rate: 22 deaths/1,000 population (1991)
_#_Net migration rate: NEGL migrants/1,000 population (1991)
_#_Infant mortality rate: 134 deaths/1,000 live births (1991)
_#_Life expectancy at birth: 39 years male, 41 years female (1991)
_#_Total fertility rate: 5.3 children born/woman (1991)
_#_Nationality: noun--Chadian(s); adjective--Chadian
_#_Ethnic divisions: some 200 distinct ethnic groups, most of whom are
Muslims (Arabs, Toubou, Hadjerai, Fulbe, Kotoko, Kanembou, Baguirmi,
Boulala, Zaghawa, and Maba) in the north and center and non-Muslims
(Sara, Ngambaye, Mbaye, Goulaye, Moundang, Moussei, Massa) in the south;
some 150,000 nonindigenous, of whom 1,000 are French
_#_Religion: Muslim 44%, Christian 33%, indigenous beliefs, animism
23%
_#_Language: French and Arabic (official); Sara and Sango in south;
more than 100 different languages and dialects are spoken
_#_Literacy: 30% (male 42%, female 18%) age 15 and over can
read and write French or Arabic (1990 est.)
_#_Labor force: NA; agriculture (engaged in unpaid subsistence
farming, herding, and fishing) 85%
_#_Organized labor: about 20% of wage labor force
_#_Population: 13,286,620 (July 1991), growth rate 1.5% (1991)
_#_Birth rate: 21 births/1,000 population (1991)
_#_Death rate: 6 deaths/1,000 population (1991)
_#_Net migration rate: 0 migrants/1,000 population (1991)
_#_Infant mortality rate: 18 deaths/1,000 live births (1991)
_#_Life expectancy at birth: 70 years male, 77 years female (1991)
_#_Total fertility rate: 2.5 children born/woman (1991)
_#_Nationality: noun--Chilean(s); adjective--Chilean
_#_Ethnic divisions: European and European-Indian 95%, Indian 3%,
other 2%
_#_Religion: Roman Catholic 89%, Protestant 11%, and small Jewish
population
_#_Language: Spanish
_#_Literacy: 93% (male 94%, female 93%) age 15 and over can
read and write (1990 est.)
_#_Labor force: 3,840,000; services 38.6% (includes government 12%)
38.6%; industry and commerce 31.3%; agriculture, forestry, and fishing
15.9%; mining 8.7%; construction 4.4% (1985)
_#_Organized labor: 11% of labor force (1990)
_#_Population: 1,151,486,981 (July 1991), growth rate 1.6% (1991)
_#_Birth rate: 22 births/1,000 population (1991)
_#_Death rate: 7 deaths/1,000 population (1991)
_#_Net migration rate: 0 migrants/1,000 population (1991)
_#_Infant mortality rate: 33 deaths/1,000 live births (1991)
_#_Life expectancy at birth: 68 years male, 72 years female (1991)
_#_Total fertility rate: 2.3 children born/woman (1991)
_#_Nationality: noun--Chinese (sing., pl.); adjective--Chinese
_#_Ethnic divisions: Han Chinese 93.3%; Zhuang, Uygur, Hui, Yi,
Tibetan, Miao, Manchu, Mongol, Buyi, Korean, and other nationalities
6.7%
_#_Religion: officially atheist, but traditionally pragmatic and
eclectic; most important elements of religion are Confucianism, Taoism,
and Buddhism; Muslim 2-3%, Christian 1% (est.)
_#_Language: Standard Chinese (Putonghua) or Mandarin (based on the
Beijing dialect); also Yue (Cantonese), Wu (Shanghainese), Minbei
(Fuzhou), Minnan (Hokkien-Taiwanese), Xiang, Gan, Hakka dialects, and
minority languages (see ethnic divisions)
_#_Literacy: 73% (male 84%, female 62%) age 15 and over can
read and write (1990 est.)
_#_Labor force: 553,000,000; agriculture and forestry 60%, industry
and commerce 25%, construction and mining 5%, social services 5%,
other 5% (1989 est.)
_#_Organized labor: All-China Federation of Trade Unions (ACFTU)
follows the leadership of the Chinese Communist Party; membership over 80
million or about 65% of the urban work force (1985)
_#_Population: 2,278 (July 1991), growth rate NA% (1991)
_#_Birth rate: NA births/1,000 population (1991)
_#_Death rate: NA deaths/1,000 population (1991)
_#_Net migration rate: NA migrants/1,000 population (1991)
_#_Infant mortality rate: NA deaths/1,000 live births (1991)
_#_Life expectancy at birth: NA years male, NA years female (1991)
_#_Total fertility rate: NA children born/woman (1991)
_#_Nationality: noun--Christmas Islander(s), adjective--Christmas
Island
_#_Ethnic divisions: Chinese 61%, Malay 25%, European 11%, other 3%;
no indigenous population
_#_Religion: Buddhist 36.1%, Muslim 25.4%, Christian 17.7% (Roman
Catholic 8.2%, Church of England 3.2%, Presbyterian 0.9%, Uniting Church
0.4%, Methodist 0.2%, Baptist 0.1%, and other 4.7%), none 12.7%, unknown
4.6%, other 3.5% (1981)
_#_Language: English
_#_Literacy: NA% (male NA%, female NA%)
_#_Labor force: NA; all workers are employees of the Phosphate Mining
Company of Christmas Island, Ltd.
_#_Organized labor: NA','58efe117722947b7aef0963637fc6baf9a9fc93732ca831cf8d6c102bab07710','internet-archive','theciaworldfactb00025gut','txt','84185fe9df79da427349cc1598fd3f69814a2085a9fc1fe0508a3fae0a870f84','https://archive.org/download/theciaworldfactb00025gut/25.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7a5ba3e96eb0535ab90ec9263fa370e6946c90e5ab3c54f5d1fc736a8adf936c',1991,'AU','Australia','people-and-society',41,'_#_Population: uninhabited
_#_Population: 684 (July 1991), growth rate NEGL% (1991)
_#_Birth rate: NA births/1,000 population (1991)
_#_Death rate: NA deaths/1,000 population (1991)
_#_Net migration rate: NA migrants/1,000 population (1991)
_#_Infant mortality rate: NA deaths/1,000 live births (1991)
_#_Life expectancy at birth: NA years male, NA years female (1991)
_#_Total fertility rate: NA children born/woman (1991)
_#_Nationality: noun--Cocos Islander(s); adjective--Cocos Islander(s)
_#_Ethnic divisions: mostly Europeans on West Island and Cocos Malays
on Home Island
_#_Religion: almost all Sunni Muslims
_#_Language: English
_#_Literacy: NA% (male NA%, female NA%)
_#_Labor force: NA
_#_Organized labor: none
_#_Population: 33,777,550 (July 1991), growth rate 2.1% (1991)
_#_Birth rate: 26 births/1,000 population (1991)
_#_Death rate: 5 deaths/1,000 population (1991)
_#_Net migration rate: NEGL migrants/1,000 population (1991)
_#_Infant mortality rate: 37 deaths/1,000 live births (1991)
_#_Life expectancy at birth: 68 years male, 74 years female (1991)
_#_Total fertility rate: 2.8 children born/woman (1991)
_#_Nationality: noun--Colombian(s); adjective--Colombian
_#_Ethnic divisions: mestizo 58%, white 20%, mulatto 14%, black 4%,
mixed black-Indian 3%, Indian 1%
_#_Religion: Roman Catholic 95%
_#_Language: Spanish
_#_Literacy: 87% (male 88%, female 86%) age 15 and over can
read and write (1990 est.)
_#_Labor force: 11,000,000 (1986); services 53%, agriculture 26%,
industry 21% (1981)
_#_Organized labor: 1,400,000 members (1987), about 12% of labor
force; the Communist-backed Unitary Workers Central or CUT is the largest
labor organization, with about 725,000 members (including all affiliate
unions)
_#_Population: 476,678 (July 1991), growth rate 3.5% (1991)
_#_Birth rate: 47 births/1,000 population (1991)
_#_Death rate: 12 deaths/1,000 population (1991)
_#_Net migration rate: 0 migrants/1,000 population (1991)
_#_Infant mortality rate: 87 deaths/1,000 live births (1991)
_#_Life expectancy at birth: 54 years male, 59 years female (1991)
_#_Total fertility rate: 7.0 children born/woman (1991)
_#_Nationality: noun--Comoran(s); adjective--Comoran
_#_Ethnic divisions: Antalote, Cafre, Makoa, Oimatsaha, Sakalava
_#_Religion: Sunni Muslim 86%, Roman Catholic 14%
_#_Language: Shaafi Islam (a Swahili dialect), Malagasy, French
_#_Literacy: 48% (male 56%, female 40%) age 15 and over can
read and write (1980)
_#_Labor force: 140,000 (1982); agriculture 80%, government 3%; 51% of
population of working age (1985)
_#_Organized labor: NA
_#_Population: 2,309,444 (July 1991), growth rate 3.0% (1991)
_#_Birth rate: 43 births/1,000 population (1991)
_#_Death rate: 13 deaths/1,000 population (1991)
_#_Net migration rate: 0 migrants/1,000 population (1991)
_#_Infant mortality rate: 108 deaths/1,000 live births (1991)
_#_Life expectancy at birth: 52 years male, 56 years female (1991)
_#_Total fertility rate: 5.7 children born/woman (1991)
_#_Nationality: noun--Congolese (sing., pl.); adjective--Congolese
or Congo
_#_Ethnic divisions: about 15 ethnic groups divided into some 75
tribes, almost all Bantu; most important ethnic groups are Kongo (48%) in
the south, Sangha (20%) and M''Bochi (12%) in the north, Teke (17%) in the
center; about 8,500 Europeans, mostly French
_#_Religion: Christian 50%, animist 48%, Muslim 2%
_#_Language: French (official); many African languages with Lingala
and Kikongo most widely used
_#_Literacy: 57% (male 70%, female 44%) age 15 and over can
read and write (1990 est.)
_#_Labor force: 79,100 wage earners; agriculture 75%, commerce,
industry, and government 25%; 51% of population of working age; 40% of
population economically active (1985)
_#_Organized labor: 20% of labor force (1979 est.)','b9c107380c9a688fd8599fc437a1a431807ed623ba285a85fe6a400cbb1fe107','internet-archive','theciaworldfactb00025gut','txt','84185fe9df79da427349cc1598fd3f69814a2085a9fc1fe0508a3fae0a870f84','https://archive.org/download/theciaworldfactb00025gut/25.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('504f43a0339a546804fb894a8cd6013ed1640d1d8975ec2577cd7e480e5ef78f',1991,'ET','Ethiopia','people-and-society',44,'_#_Population: 17,882 (July 1991), growth rate 0.5% (1991)
_#_Birth rate: 22 births/1,000 population (1991)
_#_Death rate: 7 deaths/1,000 population (1991)
_#_Net migration rate: - 10 migrants/1,000 population (1991)
_#_Infant mortality rate: 24 deaths/1,000 live births (1991)
_#_Life expectancy at birth: 67 years male, 72 years female (1991)
_#_Total fertility rate: 3.5 children born/woman (1991)
_#_Nationality: noun--Cook Islander(s); adjective--Cook Islander
_#_Ethnic divisions: Polynesian (full blood) 81.3%, Polynesian and
European 7.7%, Polynesian and other 7.7%, European 2.4%, other 0.9%
_#_Religion: Christian, majority of populace members of Cook Islands
Christian Church
_#_Language: English
_#_Literacy: NA% (male NA%, female NA%)
_#_Labor force: 5,810; agriculture 29%, government 27%, services 25%,
industry 15%, and other 4% (1981)
_#_Organized labor: NA
_#_Population: 3 meteorologists (1991)
_#_Population: 3,111,403 (July 1991), growth rate 2.5% (1991)
_#_Birth rate: 27 births/1,000 population (1991)
_#_Death rate: 4 deaths/1,000 population (1991)
_#_Net migration rate: 2 migrants/1,000 population (1991)
_#_Infant mortality rate: 15 deaths/1,000 live births (1991)
_#_Life expectancy at birth: 75 years male, 79 years female (1991)
_#_Total fertility rate: 3.2 children born/woman (1991)
_#_Nationality: noun--Costa Rican(s); adjective--Costa Rican
_#_Ethnic divisions: white (including mestizo) 96%, black 2%, Indian
1%, Chinese 1%
_#_Religion: Roman Catholic 95%
_#_Language: Spanish (official), English spoken around Puerto Limon
_#_Literacy: 93% (male 93%, female 93%) age 15 and over can
read and write (1990 est.)
_#_Labor force: 868,300; industry and commerce 35.1%, government and
services 33%, agriculture 27%, other 4.9% (1985 est.)
_#_Organized labor: 15.1% of labor force
_#_Population: 10,732,037 (July 1991), growth rate 1.0% (1991)
_#_Birth rate: 18 births/1,000 population (1991)
_#_Death rate: 7 deaths/1,000 population (1991)
_#_Net migration rate: - 1 migrant/1,000 population (1991)
_#_Infant mortality rate: 12 deaths/1,000 live births (1991)
_#_Life expectancy at birth: 73 years male, 78 years female (1991)
_#_Total fertility rate: 1.9 children born/woman (1991)
_#_Nationality: noun--Cuban(s); adjective--Cuban
_#_Ethnic divisions: mulatto 51%, white 37%, black 11%, Chinese 1%
_#_Religion: 85% nominally Roman Catholic before Castro assumed power
_#_Language: Spanish
_#_Literacy: 94% (male 95%, female 93%) age 15 and over can
read and write (1990 est.)
_#_Labor force: 3,578,800 in state sector; services and government
30%, industry 22%, agriculture 20%, commerce 11%, construction 10%,
transportation and communications 7% (June 1990); economically active
population 4,620,800 (1988)
_#_Organized labor: Workers Central Union of Cuba (CTC), only labor
federation approved by government; 2,910,000 members; the CTC is an
umbrella organization composed of 17 member unions
_#_Population: 709,343 (July 1991), growth rate 1.0% (1991)
_#_Birth rate: 18 births/1,000 population (1991)
_#_Death rate: 8 deaths/1,000 population (1991)
_#_Net migration rate: 0 migrants/1,000 population (1991)
_#_Infant mortality rate: 10 deaths/1,000 live births (1991)
_#_Life expectancy at birth: 73 years male, 78 years female (1991)
_#_Total fertility rate: 2.4 children born/woman (1991)
_#_Nationality: noun--Cypriot(s); adjective--Cypriot
_#_Ethnic divisions: Greek 78%; Turkish 18%; other 4%
_#_Religion: Greek Orthodox 78%, Muslim 18%, Maronite, Armenian,
Apostolic, and other 4%
_#_Language: Greek, Turkish, English
_#_Literacy: 90% (male 96%, female 85%) age 10 and over can
read and write (1976)
_#_Labor force: Greek area--246,100; services 42%, industry 33%,
agriculture 22%; Turkish area--NA (1989)
_#_Organized labor: 156,000 (1985 est.)
_#_Population: 15,724,940 (July 1991), growth rate 0.3% (1991)
_#_Birth rate: 14 births/1,000 population (1991)
_#_Death rate: 11 deaths/1,000 population (1991)
_#_Net migration rate: NEGL migrants/1,000 population (1991)
_#_Infant mortality rate: 11 deaths/1,000 live births (1991)
_#_Life expectancy at birth: 69 years male, 77 years female (1991)
_#_Total fertility rate: 1.9 children born/woman (1991)
_#_Nationality: noun--Czechoslovak(s); adjective--Czechoslovak
_#_Ethnic divisions: Czech 62.9%, Slovak 31.8%, Hungarian 3.8%,
Polish 0.5%, German 0.3%, Ukrainian 0.3%, Russian 0.1%, other 0.3%
_#_Religion: Roman Catholic 50%, Protestant 20%, Orthodox 2%,
other 28%
_#_Language: Czech and Slovak (official), Hungarian
_#_Literacy: 99% (male NA%, female NA%) age 15 and over can
read and write (1970 est.)
_#_Labor force: 8,200,000 (1987); industry 36.9%, agriculture 12.3%,
construction, communications, and other 50.8% (1982)
_#_Organized labor: Czech and Slovak Confederation of Trade
Unions (CSKOS); new independent trade unions forming
_#_Population: 5,132,626 (July 1991), growth rate NEGL% (1991)
_#_Birth rate: 12 births/1,000 population (1991)
_#_Death rate: 11 deaths/1,000 population (1991)
_#_Net migration rate: NEGL migrants/1,000 population (1991)
_#_Infant mortality rate: 6 deaths/1,000 live births (1991)
_#_Life expectancy at birth: 73 years male, 79 years female (1991)
_#_Total fertility rate: 1.6 children born/woman (1991)
_#_Nationality: noun--Dane(s); adjective--Danish
_#_Ethnic divisions: Scandinavian, Eskimo, Faroese, German
_#_Religion: Evangelical Lutheran 91%, other Protestant and Roman
Catholic 2%, other 7% (1988)
_#_Language: Danish, Faroese, Greenlandic (an Eskimo dialect); small
German-speaking minority
_#_Literacy: 99% (male NA%, female NA%) age 15 and over can
read and write (1980 est.)
_#_Labor force: 2,581,400; private services 36.4%; government services
30.2%; manufacturing and mining 20%; construction 6.8%; agriculture,
forestry, and fishing 5.9%; electricity/gas/water 0.7% (1990)
_#_Organized labor: 65% of labor force','a9a9e9dc089ef044739d794c45eb03a5b239e69ed8d56183d135e9e09623e3de','internet-archive','theciaworldfactb00025gut','txt','84185fe9df79da427349cc1598fd3f69814a2085a9fc1fe0508a3fae0a870f84','https://archive.org/download/theciaworldfactb00025gut/25.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('175a97e99009f43491f9e8337441e268ec44c8eae05bcde59303710fb0e040f6',1991,'SE','Sweden','people-and-society',49,'_#_Population: 346,311 (July 1991), growth rate 2.6% (1991)
_#_Birth rate: 43 births/1,000 population (1991)
_#_Death rate: 16 deaths/1,000 population (1991)
_#_Net migration rate: 0 migrants/1,000 population (1991)
_#_Infant mortality rate: 117 deaths/1,000 live births (1991)
_#_Life expectancy at birth: 46 years male, 50 years female (1991)
_#_Total fertility rate: 6.4 children born/woman (1991)
_#_Nationality: noun--Djiboutian(s); adjective--Djiboutian
_#_Ethnic divisions: Somali (Issa) 60%, Afar 35%, French, Arab,
Ethiopian, and Italian 5%
_#_Religion: Muslim 94%, Christian 6%
_#_Language: French and Arabic (both official); Somali and Afar widely
used
_#_Literacy: 48% (male 63%, female 34%) age 15 and over can
read and write (1990 est.)
_#_Labor force: NA, but a small number of semiskilled laborers at
the port and 3,000 railway workers; 52% of population of working age
(1983)
_#_Organized labor: 3,000 railway workers
_#_Population: 86,285 (July 1991), growth rate 1.7% (1991)
_#_Birth rate: 26 births/1,000 population (1991)
_#_Death rate: 5 deaths/1,000 population (1991)
_#_Net migration rate: - 3 migrants/1,000 population (1991)
_#_Infant mortality rate: 13 deaths/1,000 live births (1991)
_#_Life expectancy at birth: 73 years male, 79 years female (1991)
_#_Total fertility rate: 2.6 children born/woman (1991)
_#_Nationality: noun--Dominican(s); adjective--Dominican
_#_Ethnic divisions: mostly black; some Carib indians
_#_Religion: Roman Catholic 77%, Protestant 15% (Methodist 5%,
Pentecostal 3%, Seventh-Day Adventist 3%, Baptist 2%, other 2%),
none 2%, unknown 1%, other 5%
_#_Language: English (official); French patois widely spoken
_#_Literacy: 94% (male 94%, female 94%) age 15 and over having ever
attended school (1970)
_#_Labor force: 25,000; agriculture 40%, industry and commerce 32%,
services 28% (1984)
_#_Organized labor: 25% of labor force
_#_Population: 7,384,837 (July 1991), growth rate 2.0% (1991)
_#_Birth rate: 27 births/1,000 population (1991)
_#_Death rate: 7 deaths/1,000 population (1991)
_#_Net migration rate: - 1 migrant/1,000 population (1991)
_#_Infant mortality rate: 60 deaths/1,000 live births (1991)
_#_Life expectancy at birth: 65 years male, 69 years female (1991)
_#_Total fertility rate: 3.1 children born/woman (1991)
_#_Nationality: noun--Dominican(s); adjective--Dominican
_#_Ethnic divisions: mixed 73%, white 16%, black 11%
_#_Religion: Roman Catholic 95%
_#_Language: Spanish
_#_Literacy: 83% (male 85%, female 82%) age 15 and over can
read and write (1990 est.)
_#_Labor force: 2,300,000-2,600,000; agriculture 49%, services 33%,
industry 18% (1986)
_#_Organized labor: 12% of labor force (1989 est.)
_#_Population: 10,751,648 (July 1991), growth rate 2.3% (1991)
_#_Birth rate: 30 births/1,000 population (1991)
_#_Death rate: 7 deaths/1,000 population (1991)
_#_Net migration rate: 0 migrants/1,000 population (1991)
_#_Infant mortality rate: 60 deaths/1,000 live births (1991)
_#_Life expectancy at birth: 64 years male, 68 years female (1991)
_#_Total fertility rate: 3.7 children born/woman (1991)
_#_Nationality: noun--Ecuadorian(s); adjective--Ecuadorian
_#_Ethnic divisions: mestizo (mixed Indian and Spanish) 55%, Indian
25%, Spanish 10%, black 10%
_#_Religion: Roman Catholic 95%
_#_Language: Spanish (official); Indian languages, especially Quechua
_#_Literacy: 86% (male 88%, female 84%) age 15 and over can
read and write (1990 est.)
_#_Labor force: 2,800,000; agriculture 35%, manufacturing 21%,
commerce 16%, services and other activities 28% (1982)
_#_Organized labor: less than 15% of labor force','4abd8cb426acfeca88eafaeb73e7c2afd7fbecddc2e7849a20e9dddeeb05f42f','internet-archive','theciaworldfactb00025gut','txt','84185fe9df79da427349cc1598fd3f69814a2085a9fc1fe0508a3fae0a870f84','https://archive.org/download/theciaworldfactb00025gut/25.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4d22e3469a714e517a748dcf6a9231d2b3837b2420ee0e0183227296c9dd6c6c',1991,'MX','Mexico','people-and-society',55,'_#_Population: 54,451,588 (July 1991), growth rate 2.3% (1991)
_#_Birth rate: 33 births/1,000 population (1991)
_#_Death rate: 10 deaths/1,000 population (1991)
_#_Net migration rate: NEGL migrants/1,000 population (1991)
_#_Infant mortality rate: 82 deaths/1,000 live births (1991)
_#_Life expectancy at birth: 60 years male, 61 years female (1991)
_#_Total fertility rate: 4.5 children born/woman (1991)
_#_Nationality: noun--Egyptian(s); adjective--Egyptian
_#_Ethnic divisions: Eastern Hamitic stock 90%; Greek, Italian,
Syro-Lebanese 10%
_#_Religion: (official estimate) Muslim (mostly Sunni) 94%;
Coptic Christian and other 6%
_#_Language: Arabic (official); English and French widely understood
by educated classes
_#_Literacy: 48% (male 63%, female 34%) age 15 and over can
read and write (1990 est.)
_#_Labor force: 15,000,000 (1989 est.); government, public sector
enterprises, and armed forces 36%; agriculture 34%; privately owned
service and manufacturing enterprises 20% (1984); shortage of skilled
labor; 2,500,000 Egyptians work abroad, mostly in Iraq and the Gulf Arab
states (1988 est.)
_#_Organized labor: 2,500,000 (est.)
_#_Population: 5,418,736 (July 1991), growth rate 2.0% (1991)
_#_Birth rate: 34 births/1,000 population (1991)
_#_Death rate: 7 deaths/1,000 population (1991)
_#_Net migration rate: - 6 migrants/1,000 population (1991)
_#_Infant mortality rate: 47 deaths/1,000 live births (1991)
_#_Life expectancy at birth: 63 years male, 68 years female (1991)
_#_Total fertility rate: 4.1 children born/woman (1991)
_#_Nationality: noun--Salvadoran(s); adjective--Salvadoran
_#_Ethnic divisions: mestizo 89%, Indian 10%, white 1%
_#_Religion: Roman Catholic about 75%, with extensive activity by
Protestant groups throughout the country (more than 1 million
Protestant evangelicals in El Salvador at the end of 1990)
_#_Language: Spanish, Nahua (among some Indians)
_#_Literacy: 73% (male 76%, female 70%) age 15 and over can
read and write (1990 est.)
_#_Labor force: 1,700,000 (1982 est.); agriculture 40%, commerce 16%,
manufacturing 15%, government 13%, financial services 9%, transportation
6%, other 1%; shortage of skilled labor and a large pool of unskilled
labor, but manpower training programs improving situation (1984 est.)
_#_Organized labor: total labor force 15%; agricultural labor force
10%; urban labor force 7% (1987 est.)
_#_Population: 378,729 (July 1991), growth rate 2.6% (1991)
_#_Birth rate: 42 births/1,000 population (1991)
_#_Death rate: 16 deaths/1,000 population (1991)
_#_Net migration rate: 0 migrants/1,000 population (1991)
_#_Infant mortality rate: 116 deaths/1,000 live births (1991)
_#_Life expectancy at birth: 49 years male, 53 years female (1991)
_#_Total fertility rate: 5.4 children born/woman (1991)
_#_Nationality: noun--Equatorial Guinean(s) or Equatoguinean(s);
adjective--Equatorial Guinean or Equatoguinean
_#_Ethnic divisions: indigenous population of Bioko, primarily Bubi,
some Fernandinos; Rio Muni, primarily Fang; less than 1,000 Europeans,
mostly Spanish
_#_Religion: natives all nominally Christian and predominantly Roman
Catholic; some pagan practices retained
_#_Language: Spanish (official), pidgin English, Fang, Bubi, Ibo
_#_Literacy: 50% (male 64%, female 37%) age 15 and over can
read and write (1990 est.)
_#_Labor force: 172,000 (1986 est.); agriculture 66%, services 23%,
industry 11% (1980); labor shortages on plantations; 58% of population
of working age (1985)
_#_Organized labor: no formal trade unions
_#_Population: 53,191,127 (July 1991), growth rate 3.1% (1991)
_#_Birth rate: 45 births/1,000 population (1991)
_#_Death rate: 15 deaths/1,000 population (1991)
_#_Net migration rate: NEGL migrants/1,000 population (1991)
_#_Infant mortality rate: 114 deaths/1,000 live births (1991)
_#_Life expectancy at birth: 50 years male, 53 years female (1991)
_#_Total fertility rate: 7.0 children born/woman (1991)
_#_Nationality: noun--Ethiopian(s); adjective--Ethiopian
_#_Ethnic divisions: Oromo 40%, Amhara and Tigrean 32%, Sidamo 9%,
Shankella 6%, Somali 6%, Afar 4%, Gurage 2%, other 1%
_#_Religion: Muslim 40-45%, Ethiopian Orthodox 35-40%, animist
15-20%, other 5%
_#_Language: Amharic (official), Tigrinya, Orominga, Guaraginga,
Somali, Arabic, English (major foreign language taught in schools)
_#_Literacy: 62% (male NA%, female NA%) age 10 and over can
read and write (1983 est.)
_#_Labor force: 18,000,000; agriculture and animal
husbandry 80%, government and services 12%, industry and construction 8%
(1985)
_#_Organized labor: All Ethiopian Trade Union formed by the government
in January 1977 to represent 273,000 registered trade union members','856eb5d6cf9aacbfb74eb41a18d3d3a18a6b62bcdad71868a4dc5d1713fa9336','internet-archive','theciaworldfactb00025gut','txt','84185fe9df79da427349cc1598fd3f69814a2085a9fc1fe0508a3fae0a870f84','https://archive.org/download/theciaworldfactb00025gut/25.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ec44bbc0ad6751e1232e19527164fd8a3008f763e1da91835786745e9c6c3d72',1991,'SA','Saudi Arabia','people-and-society',66,'_#_Population: uninhabited
_#_Population: 1,968 (July 1991), growth rate NEGL% (1991)
_#_Birth rate: NA births/1,000 population (1991)
_#_Death rate: NA deaths/1,000 population (1991)
_#_Net migration rate: NA migrants/1,000 population (1991)
_#_Infant mortality rate: NA deaths/1,000 live births (1991)
_#_Life expectancy at birth: NA years male, NA years female (1991)
_#_Total fertility rate: NA children born/woman (1991)
_#_Nationality: noun--Falkland Islander(s); adjective--Falkland Island
_#_Ethnic divisions: almost totally British
_#_Religion: primarily Anglican, Roman Catholic, and United Free
Church; Evangelist Church, Jehovah''s Witnesses, Lutheran, Seventh-Day
Adventist
_#_Language: English
_#_Literacy: NA% (male NA%, female NA%) but compulsory education age
5 to 15 (1988)
_#_Labor force: 1,100 (est.); agriculture, mostly
sheepherding about 95%
_#_Organized labor: Falkland Islands General Employees Union, 400
members
_#_Population: 48,151 (July 1991), growth rate 0.9% (1991)
_#_Birth rate: 17 births/1,000 population (1991)
_#_Death rate: 8 deaths/1,000 population (1991)
_#_Net migration rate: 0 migrants/1,000 population (1991)
_#_Infant mortality rate: 9 deaths/1,000 live births (1991)
_#_Life expectancy at birth: 75 years male, 81 years female (1991)
_#_Total fertility rate: 2.2 children born/woman (1991)
_#_Nationality: noun--Faroese (sing., pl.); adjective--Faroese
_#_Ethnic divisions: homogeneous Scandinavian population
_#_Religion: Evangelical Lutheran
_#_Language: Faroese (derived from Old Norse), Danish
_#_Literacy: NA% (male NA%, female NA%)
_#_Labor force: 17,585; largely engaged in fishing, manufacturing,
transportation, and commerce
_#_Organized labor: NA
_#_Population: 744,006 (July 1991), growth rate 0.8% (1991)
_#_Birth rate: 26 births/1,000 population (1991)
_#_Death rate: 7 deaths/1,000 population (1991)
_#_Net migration rate: - 12 migrants/1,000 population (1991)
_#_Infant mortality rate: 19 deaths/1,000 live births (1991)
_#_Life expectancy at birth: 62 years male, 67 years female (1991)
_#_Total fertility rate: 3.1 children born/woman (1991)
_#_Nationality: noun--Fijian(s); adjective--Fijian
_#_Ethnic divisions: Indian 49%, Fijian 46%, European, other Pacific
Islanders, overseas Chinese, and other 5%
_#_Religion: Christian 52% (Methodist 37%, Roman Catholic 9%),
Hindu 38%, Muslim 8%, other 2%; note--Fijians are mainly Christian,
Indians are Hindu, and there is a Muslim minority (1986)
_#_Language: English (official); Fijian; Hindustani
_#_Literacy: 86% (male 90%, female 81%) age 15 and over can
read and write (1985 est.)
_#_Labor force: 235,000; subsistence agriculture 67%, wage earners
18%, salary earners 15% (1987)
_#_Organized labor: about 45,000 employees belong to some 46 trade
unions, which are organized along lines of work and ethnic origin (1983)
_#_Population: 4,991,131 (July 1991), growth rate 0.3% (1991)
_#_Birth rate: 12 births/1,000 population (1991)
_#_Death rate: 10 deaths/1,000 population (1991)
_#_Net migration rate: NEGL migrants/1,000 population (1991)
_#_Infant mortality rate: 6 deaths/1,000 live births (1991)
_#_Life expectancy at birth: 71 years male, 80 years female (1991)
_#_Total fertility rate: 1.7 children born/woman (1991)
_#_Nationality: noun--Finn(s); adjective--Finnish
_#_Ethnic divisions: Finn, Swede, Lapp, Gypsy, Tatar
_#_Religion: Evangelical Lutheran 89%, Greek Orthodox 1%,
none 9%, other 1%
_#_Language: Finnish 93.5%, Swedish (both official) 6.3%; small Lapp-
and Russian-speaking minorities
_#_Literacy: 100% (male NA%, female NA%) age 15 and over can
read and write (1980 est.)
_#_Labor force: 2,470,000; services 38.2%, mining and manufacturing
22.7%, commerce 14.9%, agriculture, forestry, and fishing 8.8%,
construction 8.0%, transportation and communications 7.2% (1989)
_#_Organized labor: 80% of labor force
_#_Population: 56,595,587 (July 1991), growth rate 0.4% (1991)
_#_Birth rate: 14 births/1,000 population (1991)
_#_Death rate: 9 deaths/1,000 population (1991)
_#_Net migration rate: 0 migrants/1,000 population (1991)
_#_Infant mortality rate: 6 deaths/1,000 live births (1991)
_#_Life expectancy at birth: 74 years male, 82 years female (1991)
_#_Total fertility rate: 1.8 children born/woman (1991)
_#_Nationality: noun--Frenchman(men), Frenchwoman(women);
adjective--French
_#_Ethnic divisions: Celtic and Latin with Teutonic, Slavic, North
African, Indochinese, and Basque minorities
_#_Religion: Roman Catholic 90%, Protestant 2%, Jewish 1%,
Muslim (North African workers) 1%, unaffiliated 6%
_#_Language: French (100% of population); rapidly declining regional
dialects (Provencal, Breton, Alsatian, Corsican, Catalan, Basque,
Flemish)
_#_Literacy: 99% (male NA%, female NA%) age 15 and over can
read and write (1980 est.)
_#_Labor force: 24,170,000; services 61.5%, industry 31.3%,
agriculture 7.3% (1987)
_#_Organized labor: 20% of labor force (est.)
_#_Population: 101,603 (July 1991), growth rate 3.3% (1991)
_#_Birth rate: 28 births/1,000 population (1991)
_#_Death rate: 5 deaths/1,000 population (1991)
_#_Net migration rate: 10 migrants/1,000 population (1991)
_#_Infant mortality rate: 18 deaths/1,000 live births (1991)
_#_Life expectancy at birth: 69 years male, 76 years female (1991)
_#_Total fertility rate: 3.7 children born/woman (1991)
_#_Nationality: noun--French Guianese (sing., pl.); adjective--French
Guiana
_#_Ethnic divisions: black or mulatto 66%; Caucasian 12%; East Indian,
Chinese, Amerindian 12%; other 10%
_#_Religion: predominantly Roman Catholic
_#_Language: French
_#_Literacy: 82% (male 81%, female 83%) age 15 and over can
read and write (1982)
_#_Labor force: 23,265; services, government, and commerce 60.6%,
industry 21.2%, agriculture 18.2% (1980)
_#_Organized labor: 7% of labor force
_#_Population: 17,869,558 (July 1991), growth rate 4.2% (1991);
note--the population figure is based on growth since the last official
Saudi census of 1974 that reported a total of 7 million persons and
included foreign workers; estimates from other sources may be 15-30%
lower
_#_Birth rate: 37 births/1,000 population (1991)
_#_Death rate: 6 deaths/1,000 population (1991)
_#_Net migration rate: 12 migrants/1,000 population (1991)
_#_Infant mortality rate: 69 deaths/1,000 live births (1991)
_#_Life expectancy at birth: 65 years male, 68 years female (1991)
_#_Total fertility rate: 6.7 children born/woman (1991)
_#_Nationality: noun--Saudi(s); adjective--Saudi or Saudi Arabian
_#_Ethnic divisions: Arab 90%, Afro-Asian 10%
_#_Religion: Muslim 100%
_#_Language: Arabic
_#_Literacy: 62% (male 73%, female 48%) age 15 and over can
read and write (1990 est.)
_#_Labor force: 4,200,000; about 60% are foreign workers; government
34%, industry and oil 28%, services 22%, and agriculture 16%
_#_Organized labor: trade unions are illegal
_#_Population: 7,952,657 (July 1991), growth rate 3.1% (1991)
_#_Birth rate: 44 births/1,000 population (1991)
_#_Death rate: 13 deaths/1,000 population (1991)
_#_Net migration rate: 0 migrants/1,000 population (1991)
_#_Infant mortality rate: 86 deaths/1,000 live births (1991)
_#_Life expectancy at birth: 54 years male, 56 years female (1991)
_#_Total fertility rate: 6.2 children born/woman (1991)
_#_Nationality: noun--Senegalese (sing. and pl.);
adjective--Senegalese
_#_Ethnic divisions: Wolof 36%, Fulani 17%, Serer 17%, Toucouleur
9%, Diola 9%, Mandingo 9%, European and Lebanese 1%, other 2%
_#_Religion: Muslim 92%, indigenous beliefs 6%, Christian 2%
(mostly Roman Catholic)
_#_Language: French (official); Wolof, Pulaar, Diola, Mandingo
_#_Literacy: 38% (male 52%, female 25%) age 15 and over can
read and write (1990 est.)
_#_Labor force: 2,509,000; 77% subsistence agricultural workers;
175,000 wage earners--private sector 40%, government and parapublic 60%;
52% of population of working age (1985)
_#_Organized labor: majority of wage-labor force represented by
unions; however, dues-paying membership very limited; major confederation
is National Confederation of Senegalese Labor (CNTS), an affiliate of
governing party
_#_Population: 68,932 (July 1991), growth rate 0.9% (1991)
_#_Birth rate: 23 births/1,000 population (1991)
_#_Death rate: 7 deaths/1,000 population (1991)
_#_Net migration rate: - 8 migrants/1,000 population (1991)
_#_Infant mortality rate: 15 deaths/1,000 live births (1991)
_#_Life expectancy at birth: 65 years male, 75 years female (1991)
_#_Total fertility rate: 2.5 children born/woman (1991)
_#_Nationality: noun--Seychellois (sing. and pl.);
adjective--Seychelles
_#_Ethnic divisions: Seychellois (mixture of Asians, Africans,
Europeans)
_#_Religion: Roman Catholic 90%, Anglican 8%, other 2%
_#_Language: English and French (official); Creole
_#_Literacy: 58% (male 56%, female 60%) age 15 and over can
read and write (1971)
_#_Labor force: 27,700; industry and commerce 31%, services 21%,
government 20%, agriculture, forestry, and fishing 12%, other 16% (1985);
57% of population of working age (1983)
_#_Organized labor: three major trade unions
_#_Population: 4,274,543 (July 1991), growth rate 2.6% (1991)
_#_Birth rate: 46 births/1,000 population (1991)
_#_Death rate: 20 deaths/1,000 population (1991)
_#_Net migration rate: 0 migrants/1,000 population (1991)
_#_Infant mortality rate: 151 deaths/1,000 live births (1991)
_#_Life expectancy at birth: 42 years male, 48 years female (1991)
_#_Total fertility rate: 6.1 children born/woman (1991)
_#_Nationality: noun--Sierra Leonean(s); adjective--Sierra Leonean
_#_Ethnic divisions: native African 99% (Temne 30%, Mende 30%);
Creole, European, Lebanese, and Asian 1%; 13 tribes
_#_Religion: Muslim 30%, indigenous beliefs 30%, Christian 10%,
other or none 30%
_#_Language: English (official); regular use limited to literate
minority; principal vernaculars are Mende in south and Temne in north;
Krio is the language of the resettled ex-slave population of the Freetown
area and is lingua franca
_#_Literacy: 21% (male 31%, female 11%) age 15 and over can
read and write English, Mende, Temne, or Arabic (1990 est.)
_#_Labor force: 1,369,000 (est.); agriculture 65%, industry 19%,
services 16% (1981); only about 65,000 earn wages (1985); 55% of
population of working age
_#_Organized labor: 35% of wage earners
_#_Population: 2,756,330 (July 1991), growth rate 1.3% (1991)
_#_Birth rate: 18 births/1,000 population (1991)
_#_Death rate: 5 deaths/1,000 population (1991)
_#_Net migration rate: 0 migrants/1,000 population (1991)
_#_Infant mortality rate: 8 deaths/1,000 live births (1991)
_#_Life expectancy at birth: 72 years male, 77 years female (1991)
_#_Total fertility rate: 2.0 children born/woman (1991)
_#_Nationality: noun--Singaporean(s), adjective--Singapore
_#_Ethnic divisions: Chinese 76.4%, Malay 14.9%, Indian 6.4%, other
2.3%
_#_Religion: majority of Chinese are Buddhists or atheists; Malays
are nearly all Muslim (minorities include Christians, Hindus, Sikhs,
Taoists, Confucianists)
_#_Language: Chinese, Malay, Tamil, and English (all official);
Malay (national)
_#_Literacy: 88% (male 93%, female 84%) age 15 and over can
read and write (1990 est.)
_#_Labor force: 1,280,000; financial, business, and other services
35.3%, manufacturing 29.0%, commerce 22.8%, construction 6.6%,
other 6.3% (1989)
_#_Organized labor: 210,000; 16.1% of labor force (1989)
_#_Population: 347,115 (July 1991), growth rate 3.5% (1991)
_#_Birth rate: 40 births/1,000 population (1991)
_#_Death rate: 5 deaths/1,000 population (1991)
_#_Net migration rate: 0 migrants/1,000 population (1991)
_#_Infant mortality rate: 39 deaths/1,000 live births (1991)
_#_Life expectancy at birth: 67 years male, 72 years female (1991)
_#_Total fertility rate: 6.2 children born/woman (1991)
_#_Nationality: noun--Solomon Islander(s); adjective--Solomon Islander
_#_Ethnic divisions: Melanesian 93.0%, Polynesian 4.0%, Micronesian
1.5%, European 0.8%, Chinese 0.3%, other 0.4%
_#_Religion: almost all at least nominally Christian; Anglican 34%,
Roman Catholic 19%, Baptist 17%, United (Methodist/Presbyterian) 11%,
Seventh-Day Adventist 10%, other Protestant 5%
_#_Language: 120 indigenous languages; Melanesian pidgin in much of
the country is lingua franca; English spoken by 1-2% of population
_#_Literacy: NA% (male NA%, female NA%)
_#_Labor force: 23,448 economically active; agriculture, forestry, and
fishing 32.4%; services 25%; construction, manufacturing, and mining
7.0%; commerce, transport, and finance 4.7% (1984)
_#_Organized labor: NA, but most of the cash-economy workers have
trade union representation
_#_Population: 6,709,161 (July 1991), growth rate 3.3% (1991)
_#_Birth rate: 46 births/1,000 population (1991)
_#_Death rate: 13 deaths/1,000 population (1991)
_#_Net migration rate: 0 migrants/1,000 population (1991)
_#_Infant mortality rate: 116 deaths/1,000 live births (1991)
_#_Life expectancy at birth: 56 years male, 56 years female (1991)
_#_Total fertility rate: 7.2 children born/woman (1991)
_#_Nationality: noun--Somali(s); adjective--Somali
_#_Ethnic divisions: Somali 85%, rest mainly Bantu; Arabs 30,000,
Europeans 3,000, Asians 800
_#_Religion: almost entirely Sunni Muslim
_#_Language: Somali (official); Arabic, Italian, English
_#_Literacy: 24% (male 36%, female 14%) age 15 and over can
read and write (1990 est.)
_#_Labor force: 2,200,000; very few are skilled laborers; pastoral
nomad 70%, agriculture, government, trading, fishing, handicrafts, and
other 30%; 53% of population of working age (1985)
_#_Organized labor: General Federation of Somali Trade Unions is
controlled by the government
_#_Population: 40,600,518 (July 1991), growth rate 2.7% (1991);
includes the 10 so-called homelands, which are not recognized by the US;
four independent homelands--Bophuthatswana 2,419,515, growth rate
2.83%; Ciskei 1,056,552, growth rate 2.96%; Transkei 4,553,994, growth
rate 4.16%; Venda 691,273, growth rate 3.83%;
six other homelands--Gazankulu 772,532, growth rate 3.98%; Kangwane
576,573, growth rate 3.62%; KwaNdebele 360,582, growth rate 3.38%;
KwaZulu 5,546,082, growth rate 3.60%; Lebowa 2,812,630, growth rate
3.91%; QwaQwa 277,957, growth rate 3.60%
_#_Birth rate: 34 births/1,000 population (1991)
_#_Death rate: 8 deaths/1,000 population (1991)
_#_Net migration rate: NEGL migrants/1,000 population (1991)
_#_Infant mortality rate: 51 deaths/1,000 live births (1991)
_#_Life expectancy at birth: 61 years male, 67 years female (1991)
_#_Total fertility rate: 4.4 children born/woman (1991)
_#_Nationality: noun--South African(s); adjective--South African
_#_Ethnic divisions: black 75.2%, white 13.6%, Colored 8.6%,
Indian 2.6%
_#_Religion: most whites and Coloreds and about 60% of blacks are
Christian; about 60% of Indians are Hindu; Muslim 20%
_#_Language: Afrikaans, English (both official); many vernacular
languages, including Zulu, Xhosa, North and South Sotho, Tswana
_#_Literacy: 76% (male 78%, female 75%) age 15 and over can
read and write (1980)
_#_Labor force: 11,000,000 economically active (1989); services 34%,
agriculture 30%, industry and commerce 29%, mining 7% (1985)
_#_Organized labor: about 17% of total labor force is unionized;
African unions represent 15% of black labor force
_#_Population: no permanent population; there is a small military
garrison on South Georgia and the British Antarctic Survey has a
biological station on Bird Island; the South Sandwich islands are
uninhabited
_#_Population: 293,047,571 (July 1991), growth rate 0.7% (1991)
_#_Birth rate: 17 births/1,000 population (1991)
_#_Death rate: 10 deaths/1,000 population (1991)
_#_Net migration rate: 0 migrants/1,000 population (1991)
_#_Infant mortality rate: 23 deaths/1,000 live births (1991)
_#_Life expectancy at birth: 65 years male, 74 years female (1991)
_#_Total fertility rate: 2.4 children born/woman (1991)
_#_Nationality: noun--Soviet(s); adjective--Soviet
_#_Ethnic divisions: Russian 50.78%, Ukrainian 15.45%, Uzbek 5.84%,
Belorussian (Byelorussian) 3.51%, Kazakh 2.85%, Azeri 2.38%, Armenian
1.62%, Tajik 1.48%, Georgian 1.39%, Moldovan 1.17%, Lithuanian 1.07%,
Turkmen 0.95%, Kirghiz 0.89%, Latvian 0.51%, Estonian 0.36%, other 9.75%
_#_Religion: Russian Orthodox 20%, Muslim 10%, Protestant, Georgian
Orthodox, Armenian Orthodox, and Roman Catholic 7%, Jewish less than 1%,
atheist 60% (est.)
_#_Language: Russian (official); more than 200 languages and dialects
(at least 18 with more than 1 million speakers); Slavic group 75%,
other Indo-European 8%, Altaic 12%, Uralian 3%, Caucasian 2%
_#_Literacy: 98% (male 99%, female 97%) age 15 and over can
read and write (1989)
_#_Labor force: 152,300,000 civilians; industry and other
nonagricultural fields 80%, agriculture 20%; shortage of skilled labor
(1989)
_#_Organized labor: the vast majority of workers are union members;
official unions are organized within the General Confederation of Trade
Unions (GCTU) and still operate within general guidelines set up by the
CPSU and Soviet Government; a large number of independent trade unions
have been formed since President Gorbachev came to power; most are
locally or regionally based and represent workers from one enterprise
or a group of enterprises; there are a few independent unions that claim
a nationwide following, the most prominent of which is Independent Miners
Trade Union set up by the country''s coal miners
_#_Population: 39,384,516 (July 1991), growth rate 0.3% (1991)
_#_Birth rate: 11 births/1,000 population (1991)
_#_Death rate: 8 deaths/1,000 population (1991)
_#_Net migration rate: 0 migrants/1,000 population (1991)
_#_Infant mortality rate: 6 deaths/1,000 live births (1991)
_#_Life expectancy at birth: 75 years male, 82 years female (1991)
_#_Total fertility rate: 1.5 children born/woman (1991)
_#_Nationality: noun--Spaniard(s); adjective--Spanish
_#_Ethnic divisions: composite of Mediterranean and Nordic types
_#_Religion: Roman Catholic 99%, other sects 1%
_#_Language: Castilian Spanish; second languages include
Catalan 17%, Galician 7%, Basque 2%
_#_Literacy: 95% (male 97%, female 93%) age 15 and over can
read and write (1990 est.)
_#_Labor force: 14,621,000; services 53%, industry 24%, agriculture
14%, constrction 9% (1988)
_#_Organized labor: less 10% of labor force (1988)
_#_Population: no permanent inhabitants; garrisons
_#_Population: 17,423,736 (July 1991), growth rate 1.2% (1991)
_#_Birth rate: 20 births/1,000 population (1991)
_#_Death rate: 6 deaths/1,000 population (1991)
_#_Net migration rate: - 2 migrants/1,000 population (1991)
_#_Infant mortality rate: 21 deaths/1,000 live births (1991)
_#_Life expectancy at birth: 69 years male, 74 years female (1991)
_#_Total fertility rate: 2.3 children born/woman (1991)
_#_Nationality: noun--Sri Lankan(s); adjective--Sri Lankan
_#_Ethnic divisions: Sinhalese 74%; Tamil 18%; Moor 7%; Burgher,
Malay, and Veddha 1%
_#_Religion: Buddhist 69%, Hindu 15%, Christian 8%, Muslim 8%
_#_Language: Sinhala (official); Sinhala and Tamil listed as national
languages; Sinhala spoken by about 74% of population, Tamil spoken by
about 18%; English commonly used in government and spoken by about 10% of
the population
_#_Literacy: 86% (male 91%, female 81%) age 15 and over can
read and write (1981)
_#_Labor force: 6,600,000; agriculture 45.9%, mining and
manufacturing 13.3%, trade and transport 12.4%, services and other 28.4%
(1985 est.)
_#_Organized labor: about 33% of labor force, over 50% of which are
employed on tea, rubber, and coconut estates
_#_Population: 27,220,088 (July 1991), growth rate 3.0% (1991)
_#_Birth rate: 44 births/1,000 population (1991)
_#_Death rate: 13 deaths/1,000 population (1991)
_#_Net migration rate: - 1 migrants/1,000 population (1991)
_#_Infant mortality rate: 85 deaths/1,000 live births (1991)
_#_Life expectancy at birth: 52 years male, 54 years female (1991)
_#_Total fertility rate: 6.4 children born/woman (1991)
_#_Nationality: noun--Sudanese (sing. and pl.); adjective--Sudanese
_#_Ethnic divisions: black 52%, Arab 39%, Beja 6%, foreigners 2%,
other 1%
_#_Religion: Sunni Muslim (in north) 70%, indigenous beliefs 20%,
Christian (mostly in south and Khartoum) 5%
_#_Language: Arabic (official), Nubian, Ta Bedawie, diverse dialects
of Nilotic, Nilo-Hamitic, and Sudanic languages, English; program of
Arabization in process
_#_Literacy: 27% (male 43%, female 12%) age 15 and over can
read and write (1990 est.)
_#_Labor force: 6,500,000; agriculture 80%, industry and commerce 10%,
government 6%; labor shortages for almost all categories of skilled
employment (1983 est.); 52% of population of working age (1985)
_#_Organized labor: trade unions suspended following 30 June 1989
coup; now in process of being legalized anew
_#_Population: 402,385 (July 1991), growth rate 1.4% (1991)
_#_Birth rate: 26 births/1,000 population (1991)
_#_Death rate: 6 deaths/1,000 population (1991)
_#_Net migration rate: - 6 migrants/1,000 population (1991)
_#_Infant mortality rate: 39 deaths/1,000 live births (1991)
_#_Life expectancy at birth: 66 years male, 71 years female (1991)
_#_Total fertility rate: 2.9 children born/woman (1991)
_#_Nationality: noun--Surinamer(s); adjective--Surinamese
_#_Ethnic divisions: Hindustani (East Indian) 37.0%, Creole (black and
mixed) 31.0%, Javanese 15.3%, Bush black 10.3%, Amerindian 2.6%, Chinese
1.7%, Europeans 1.0%, other 1.1%
_#_Religion: Hindu 27.4%, Muslim 19.6%, Roman Catholic 22.8%,
Protestant (predominantly Moravian) 25.2%, indigenous beliefs
about 5%
_#_Language: Dutch (official); English widely spoken; Sranan Tongo
(Surinamese, sometimes called Taki-Taki) is native language of Creoles
and much of the younger population and is lingua franca among others;
also Hindi Suriname Hindustani (a variant of Bhoqpuri) and Javanese
_#_Literacy: 95% (male 95%, female 95%) age 15 and over can
read and write (1990 est.)
_#_Labor force: 104,000 (1984)
_#_Organized labor: 49,000 members of labor force
_#_Population: 3,942 (July 1991), growth rate NA% (1991); about
one-third of the population resides in the Norwegian areas (Longyearbyen
and Svea on Vestspitsbergen) and two-thirds in the Soviet areas
(Barentsburg and Pyramiden on Vestspitsbergen); about 9 persons live at
the Polish research station
_#_Birth rate: NA births/1,000 population (1991)
_#_Death rate: NA deaths/1,000 population (1991)
_#_Net migration rate: NA migrants/1,000 population (1991)
_#_Infant mortality rate: NA deaths/1,000 live births (1991)
_#_Life expectancy at birth: NA years male, NA years female (1991)
_#_Total fertility rate: NA children born/woman (1991)
_#_Ethnic divisions: Russian 64%, Norwegian 35%, other 1% (1981)
_#_Language: Russian, Norwegian
_#_Literacy: NA% (male NA%, female NA%)
_#_Labor force: NA
_#_Organized labor: none
_#_Population: 859,336 (July 1991), growth rate 2.7% (1991)
_#_Birth rate: 44 births/1,000 population (1991)
_#_Death rate: 12 deaths/1,000 population (1991)
_#_Net migration rate: - 5 migrants/1,000 population (1991)
_#_Infant mortality rate: 101 deaths/1,000 live births (1991)
_#_Life expectancy at birth: 51 years male, 59 years female (1991)
_#_Total fertility rate: 6.2 children born/woman (1991)
_#_Nationality: noun--Swazi(s); adjective--Swazi
_#_Ethnic divisions: African 97%, European 3%
_#_Religion: Christian 60%, indigenous beliefs 40%
_#_Language: English and siSwati (official); government business
conducted in English
_#_Literacy: 55% (male 57%, female 54%) age 15 and over can
read and write (1976)
_#_Labor force: 195,000; over 60,000 engaged in subsistence
agriculture; about 92,000 wage earners (many only intermittently), with
agriculture and forestry 36%, community and social services 20%,
manufacturing 14%, construction 9%, other 21%; 24,000-29,000 employed in
South Africa (1987)
_#_Organized labor: about 10% of wage earners
_#_Population: 8,564,317 (July 1991), growth rate 0.4% (1991)
_#_Birth rate: 13 births/1,000 population (1991)
_#_Death rate: 11 deaths/1,000 population (1991)
_#_Net migration rate: 3 migrants/1,000 population (1991)
_#_Infant mortality rate: 6 deaths/1,000 live births (1991)','aa9e783c4c4d9a017ae237b9f06bfc0b21a0eafdc104fed422ea5f7ad1bee53c','internet-archive','theciaworldfactb00025gut','txt','84185fe9df79da427349cc1598fd3f69814a2085a9fc1fe0508a3fae0a870f84','https://archive.org/download/theciaworldfactb00025gut/25.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('de079bc605b9d4c79645a2823208c3a71c27992131d4340dbb3d2c17f2d8a514',1991,'SA','Saudi Arabia','people-and-society',67,'_#_Life expectancy at birth: 75 years male, 81 years female (1991)
_#_Total fertility rate: 1.9 children born/woman (1991)
_#_Nationality: noun--Swede(s); adjective--Swedish
_#_Ethnic divisions: homogeneous white population; small Lappish
minority; foreign born or first-generation immigrants (Finns, Yugoslavs,
Danes, Norwegians, Greeks, Turks) about 12%
_#_Religion: Evangelical Lutheran 94%, Roman Catholic 1.5%,
Pentecostal 1%, other 3.5% (1987)
_#_Language: Swedish, small Lapp- and Finnish-speaking minorities;
immigrants speak native languages
_#_Literacy: 99% (male NA%, female NA%) age 15 and over can
read and write (1979 est.)
_#_Labor force: 4,572,000 (October 1990); government services 37.4%,
mining, manufacturing, electricity, and water service 23.1%, private
services 22.2%, transportation and communications 7%, construction 6.3%,
agriculture, forestry, fishing, and hunting 3.8%, other 0.2% (1988)
_#_Organized labor: 80% of labor force (1990 est.)
_#_Population: 6,783,961 (July 1991), growth rate 0.6% (1991)
_#_Birth rate: 12 births/1,000 population (1991)
_#_Death rate: 9 deaths/1,000 population (1991)
_#_Net migration rate: 3 migrants/1,000 population (1991)
_#_Infant mortality rate: 5 deaths/1,000 live births (1991)
_#_Life expectancy at birth: 75 years male, 83 years female (1991)
_#_Total fertility rate: 1.6 children born/woman (1991)
_#_Nationality: noun--Swiss (sing. & pl.); adjective--Swiss
_#_Ethnic divisions: total population--German 65%, French 18%,
Italian 10%, Romansch 1%, other 6%; Swiss nationals--German 74%,
French 20%, Italian 4%, Romansch 1%, other 1%
_#_Religion: Roman Catholic 47.6%, Protestant 44.3%, other 8.1%
(1980)
_#_Language: total population--German 65%, French 18%, Italian 12%,
Romansch 1%, other 4%; Swiss nationals--German 74%, French 20%, Italian
4%, Romansch 1%, other 1%
_#_Literacy: 99% (male NA%, female NA%) age 15 and over can
read and write (1980 est.)
_#_Labor force: 3,310,000; 904,095 foreign workers, mostly Italian;
services 50%, industry and crafts 33%, government 10%, agriculture and
forestry 6%, other 1% (1989)
_#_Organized labor: 20% of labor force
_#_Population: 12,965,996 (July 1991), growth rate 3.8% (1991);
in addition, there are at least 12,000 Druze and 13,000 Jewish settlers
in the Israeli-occupied Golan Heights (1990 est.)
_#_Birth rate: 43 births/1,000 population (1991)
_#_Death rate: 5 deaths/1,000 population (1991)
_#_Net migration rate: 0 migrants/1,000 population (1991)
_#_Infant mortality rate: 37 deaths/1,000 live births (1991)
_#_Life expectancy at birth: 68 years male, 71 years female (1991)
_#_Total fertility rate: 6.7 children born/woman (1991)
_#_Nationality: noun--Syrian(s); adjective--Syrian
_#_Ethnic divisions: Arab 90.3%; Kurds, Armenians, and other 9.7%
_#_Religion: Sunni Muslim 74%, Alawite, Druze, and other Muslim
sects 16%, Christian (various sects) 10%, tiny Jewish communities in
Damascus, Al Qamishli, and Aleppo
_#_Language: Arabic (official), Kurdish, Armenian, Aramaic,
Circassian; French widely understood
_#_Literacy: 64% (male 78%, female 51%) age 15 and over can
read and write (1990 est.)
_#_Labor force: 2,400,000; miscellaneous and government services 36%,
agriculture 32%, industry and construction 32%; majority unskilled;
shortage of skilled labor (1984)
_#_Organized labor: 5% of labor force
_#_Population: 26,869,175 (July 1991), growth rate 3.4% (1991)
_#_Birth rate: 50 births/1,000 population (1991)
_#_Death rate: 15 deaths/1,000 population (1991)
_#_Net migration rate: - 1 migrants/1,000 population (1991)
_#_Infant mortality rate: 105 deaths/1,000 live births (1991)
_#_Life expectancy at birth: 50 years male, 55 years female (1991)
_#_Total fertility rate: 7.0 children born/woman (1991)
_#_Nationality: noun--Tanzanian(s); adjective--Tanzanian
_#_Ethnic divisions: mainland--native African consisting of well over
100 tribes 99%; Asian, European, and Arab 1%
_#_Religion:
mainland--Christian 33%, Muslim 33%, indigenous beliefs 33%;
Zanzibar--almost all Muslim
_#_Language: Swahili and English (official); English primary language
of commerce, administration, and higher education; Swahili widely
understood and generally used for communication between ethnic groups;
first language of most people is one of the local languages; primary
education is generally in Swahili
_#_Literacy: 46% (male 62%, female 31%) age 15 and over can
read and write (1978)
_#_Labor force: 732,200 wage earners; 90% agriculture, 10% industry
and commerce (1986 est.)
_#_Organized labor: 15% of labor force','f1eb9d337f372361f013a7c3f20c3edabe093a0970290ebbdcb233dde3f14471','internet-archive','theciaworldfactb00025gut','txt','84185fe9df79da427349cc1598fd3f69814a2085a9fc1fe0508a3fae0a870f84','https://archive.org/download/theciaworldfactb00025gut/25.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('74ab40fb55c5767773ba02b6be55ebe2990dfb42d74e47da8d46d5c1b7649342',1991,'GF','French Guiana','people-and-society',78,'_#_Population: 195,046 (July 1991), growth rate 2.5% (1991)
_#_Birth rate: 31 births/1,000 population (1991)
_#_Death rate: 6 deaths/1,000 population (1991)
_#_Net migration rate: 0 migrants/1,000 population (1991)
_#_Infant mortality rate: 22 deaths/1,000 live births (1991)
_#_Life expectancy at birth: 66 years male, 71 years female (1991)
_#_Total fertility rate: 3.9 children born/woman (1991)
_#_Nationality: noun--French Polynesian(s); adjective--French
Polynesian
_#_Ethnic divisions: Polynesian 78%, Chinese 12%, local French 6%,
metropolitan French 4%
_#_Religion: mainly Christian; Protestant 54%, Roman Catholic 30%,
other 16%
_#_Language: French (official), Tahitian
_#_Literacy: 98% (male 98%, female 98%) age 14 and over but definition
of literacy not available (1977)
_#_Labor force: 76,630 employed (1988)
_#_Organized labor: NA
_#_Population: summer (January 1991)--180, winter (July 1991)--150,
growth rate 0.0% (1991);
note--mostly researchers
_#_Population: 1,079,980 (July 1991), growth rate 1.4% (1991)
_#_Birth rate: 28 births/1,000 population (1991)
_#_Death rate: 14 deaths/1,000 population (1991)
_#_Net migration rate: 0 migrants/1,000 population (1991)
_#_Infant mortality rate: 104 deaths/1,000 live births (1991)
_#_Life expectancy at birth: 51 years male, 56 years female (1991)
_#_Total fertility rate: 4.0 children born/woman (1991)
_#_Nationality: noun--Gabonese (sing., pl.); adjective--Gabonese
_#_Ethnic divisions: about 40 Bantu tribes, including four major
tribal groupings (Fang, Eshira, Bapounou, Bateke); about 100,000
expatriate Africans and Europeans, including 27,000 French
_#_Religion: Christian 55-75%, Muslim less than 1%, remainder animist
_#_Language: French (official), Fang, Myene, Bateke, Bapounou/Eschira,
Bandjabi
_#_Literacy: 61% (male 74%, female 48%) age 15 and over can
read and write (1990 est.)
_#_Labor force: 120,000 salaried; agriculture 65.0%, industry and
commerce 30.0%, services 2.5%, government 2.5%; 58% of population of
working age (1983)
_#_Organized labor: there are 38,000 members of the national trade
union, the Gabonese Trade Union Confederation (COSYGA)
_#_Population: 874,553 (July 1991), growth rate 3.1% (1991)
_#_Birth rate: 48 births/1,000 population (1991)
_#_Death rate: 17 deaths/1,000 population (1991)
_#_Net migration rate: 0 migrants/1,000 population (1991)
_#_Infant mortality rate: 138 deaths/1,000 live births (1991)
_#_Life expectancy at birth: 47 years male, 51 years female (1991)
_#_Total fertility rate: 6.5 children born/woman (1991)
_#_Nationality: noun--Gambian(s); adjective--Gambian
_#_Ethnic divisions: African 99% (Mandinka 42%, Fula 18%, Wolof 16%,
Jola 10%, Serahuli 9%, other 4%); non-Gambian 1%
_#_Religion: Muslim 90%, Christian 9%, indigenous beliefs 1%
_#_Language: English (official); Mandinka, Wolof, Fula, other
indigenous vernaculars
_#_Literacy: 27% (male 39%, female 16%) age 15 and over can
read and write (1990 est.)
_#_Labor force: 400,000 (1986 est.); agriculture 75.0%, industry,
commerce, and services 18.9%, government 6.1%; 55% population of
working age (1983)
_#_Organized labor: 25-30% of wage labor force
_#_Population: 642,253 (July 1991), growth rate 3.2% (1991);
in addition, there are 2,500 Jewish settlers in the Gaza Strip (1990
est.)
_#_Birth rate: 43 births/1,000 population (1991)
_#_Death rate: 6 deaths/1,000 population (1991)
_#_Net migration rate: - 5 migrants/1,000 population (1991)
_#_Infant mortality rate: 41 deaths/1,000 live births (1991)
_#_Life expectancy at birth: 65 years male, 67 years female (1991)
_#_Total fertility rate: 6.9 children born/woman (1991)
_#_Nationality: NA
_#_Ethnic divisions: Palestinian Arab and other 99.8%, Jewish 0.2%
_#_Religion: Muslim (predominantly Sunni) 99%, Christian 0.7%,
Jewish 0.3%
_#_Language: Arabic, Israeli settlers speak Hebrew, English widely
understood
_#_Literacy: NA% (male NA%, female NA%)
_#_Labor force: (excluding Israeli Jewish settlers) small
industry, commerce and business 32.0%, construction 24.4%, service
and other 25.5%, and agriculture 18.1% (1984)
_#_Organized labor: NA
_#_Population: 79,548,498 (July 1991), growth rate 0.4% (1991)
_#_Birth rate: 11 births/1,000 population (1991)
_#_Death rate: 11 deaths/1,000 population (1991)
_#_Net migration rate: 4 migrants/1,000 population (1991)
_#_Infant mortality rate: 7 deaths/1,000 live births (1991)
_#_Life expectancy at birth: 73 years male, 79 years female (1991)
_#_Total fertility rate: 1.4 children born/woman (1991)
_#_Nationality: noun--German(s); adjective--German
_#_Ethnic divisions: primarily German; small Danish and Slavic
minorities
_#_Religion: Protestant 45%, Roman Catholic 37%, unaffiliated or
other 18%
_#_Language: German
_#_Literacy: 99% (male NA%, female NA%) age 15 and over can
read and write (1970 est.)
_#_Labor force: 36,750,000; industry 41%, agriculture 6%, other 53%
(1987)
_#_Organized labor: 47% of labor force (1986 est.)
_#_Population: 15,616,934 (July 1991), growth rate 3.2% (1991)
_#_Birth rate: 46 births/1,000 population (1991)
_#_Death rate: 13 deaths/1,000 population (1991)
_#_Net migration rate: - 1 migrant/1,000 population (1991)
_#_Infant mortality rate: 86 deaths/1,000 live births (1991)
_#_Life expectancy at birth: 53 years male, 56 years female (1991)
_#_Total fertility rate: 6.3 children born/woman (1991)
_#_Nationality: noun--Ghanaian(s); adjective--Ghanaian
_#_Ethnic divisions: black African 99.8% (major tribes--Akan 44%,
Moshi-Dagomba 16%, Ewe 13%, Ga 8%), European and other 0.2%
_#_Religion: indigenous beliefs 38%, Muslim 30%, Christian 24%,
other 8%
_#_Language: English (official); African languages include Akan,
Moshi-Dagomba, Ewe, and Ga
_#_Literacy: 60% (male 70%, female 51%) age 15 and over can
read and write (1990 est.)
_#_Labor force: 3,700,000; agriculture and fishing 54.7%, industry
18.7%, sales and clerical 15.2%, services, transportation, and
communications 7.7%, professional 3.7%; 48% of population of working age
(1983)
_#_Organized labor: 467,000 (about 13% of labor force)
_#_Population: 29,613 (July 1991), growth rate 0.1% (1991)
_#_Birth rate: 18 births/1,000 population (1991)
_#_Death rate: 8 deaths/1,000 population (1991)
_#_Net migration rate: - 9 migrants/1,000 population (1991)
_#_Infant mortality rate: 6 deaths/1,000 live births (1991)
_#_Life expectancy at birth: 72 years male, 78 years female (1991)
_#_Total fertility rate: 2.4 children born/woman (1991)
_#_Nationality: noun--Gibraltarian; adjective--Gibraltar
_#_Ethnic divisions: mostly Italian, English, Maltese, Portuguese, and
Spanish descent
_#_Religion: Roman Catholic 74%, Protestant 11% (Church of England 8%,
other 3%), Moslem 8%, Jewish 2%, none or other 5% (1981)
_#_Language: English and Spanish are primary languages; Italian,
Portuguese, and Russian also spoken; English used in the schools and for
official purposes
_#_Literacy: NA% (male NA%, female NA%)
_#_Labor force: about 14,800 (including non-Gibraltar laborers); UK
military establishments and civil government employ nearly 50% of the
labor force
_#_Organized labor: over 6,000
_#_Population: uninhabited
_#_Population: 10,042,956 (July 1991), growth rate 0.2% (1991)
_#_Birth rate: 11 births/1,000 population (1991)
_#_Death rate: 9 deaths/1,000 population (1991)
_#_Net migration rate: 0 migrants/1,000 population (1991)
_#_Infant mortality rate: 10 deaths/1,000 live births (1991)
_#_Life expectancy at birth: 75 years male, 80 years female (1991)
_#_Total fertility rate: 1.5 children born/woman (1991)
_#_Nationality: noun--Greek(s); adjective--Greek
_#_Ethnic divisions: Greek 98%, other 2%; note--the Greek Government
states there are no ethnic divisions in Greece
_#_Religion: Greek Orthodox 98%, Muslim 1.3%, other 0.7%
_#_Language: Greek (official); English and French widely understood
_#_Literacy: 93% (male 98%, female 89%) age 15 and over can
read and write (1990 est.)
_#_Labor force: 3,860,000; services 43%, agriculture 27%,
manufacturing and mining 20%, construction 7% (1985)
_#_Organized labor: 10-15% of total labor force, 20-25% of urban
labor force
_#_Population: 56,752 (July 1991), growth rate 1.2% (1991)
_#_Birth rate: 20 births/1,000 population (1991)
_#_Death rate: 8 deaths/1,000 population (1991)
_#_Net migration rate: 0 migrants/1,000 population (1991)
_#_Infant mortality rate: 28 deaths/1,000 live births (1991)
_#_Life expectancy at birth: 63 years male, 69 years female (1991)
_#_Total fertility rate: 2.2 children born/woman (1991)
_#_Nationality: noun--Greenlander(s); adjective--Greenlandic
_#_Ethnic divisions: Greenlander (Eskimos and Greenland-born
Caucasians) 86%, Danish 14%
_#_Religion: Evangelical Lutheran
_#_Language: Eskimo dialects, Danish
_#_Literacy: NA% (male NA%, female NA%)
_#_Labor force: 22,800; largely engaged in fishing, hunting, sheep
breeding
_#_Organized labor: NA
_#_Population: 83,812 (July 1991), growth rate - 0.4% (1991)
_#_Birth rate: 35 births/1,000 population (1991)
_#_Death rate: 7 deaths/1,000 population (1991)
_#_Net migration rate: - 32 migrants/1,000 population (1991)
_#_Infant mortality rate: 29 deaths/1,000 live births (1991)
_#_Life expectancy at birth: 69 years male, 74 years female (1991)
_#_Total fertility rate: 4.7 children born/woman (1991)
_#_Nationality: noun--Grenadian(s); adjective--Grenadian
_#_Ethnic divisions: mainly of black African descent
_#_Religion: largely Roman Catholic; Anglican; other Protestant sects
_#_Language: English (official); some French patois
_#_Literacy: 98% (male 98%, female 98%) age 15 and over having ever
attended school (1970)
_#_Labor force: 36,000; services 31%, agriculture 24%, construction
8%, manufacturing 5%, other 32% (1985)
_#_Organized labor: 20% of labor force
_#_Population: 344,897 (July 1991), growth rate 0.8% (1991)
_#_Birth rate: 20 births/1,000 population (1991)
_#_Death rate: 6 deaths/1,000 population (1991)
_#_Net migration rate: - 5 migrants/1,000 population (1991)
_#_Infant mortality rate: 17 deaths/1,000 live births (1991)
_#_Life expectancy at birth: 70 years male, 77 years female (1991)
_#_Total fertility rate: 2.0 children born/woman (1991)
_#_Nationality: noun--Guadeloupian(s); adjective--Guadeloupe
_#_Ethnic divisions: black or mulatto 90%; white 5%; East Indian,
Lebanese, Chinese less than 5%
_#_Religion: Roman Catholic 95%, Hindu and pagan African 5%
_#_Language: French, creole patois
_#_Literacy: 90% (male 90%, female 91%) age 15 and over can
read and write (1982)
_#_Labor force: 120,000; 53.0% services, government, and commerce,
25.8% industry, 21.2% agriculture
_#_Organized labor: 11% of labor force
_#_Population: 144,928 (July 1991), growth rate 2.8% (1991)
_#_Birth rate: 26 births/1,000 population (1991)
_#_Death rate: 4 deaths/1,000 population (1991)
_#_Net migration rate: 5 migrants/1,000 population (1991)
_#_Infant mortality rate: 12 deaths/1,000 live births (1991)
_#_Life expectancy at birth: 70 years male, 75 years female (1991)
_#_Total fertility rate: 3.0 children born/woman (1991)
_#_Nationality: noun--Guamanian(s); adjective--Guamanian
_#_Ethnic divisions: Chamorro 47%, Filipino 25%, Caucasian 10%,
Chinese, Japanese, Korean, and other 18%
_#_Religion: Roman Catholic 98%, other 2%
_#_Language: English and Chamorro, most residents bilingual; Japanese
also widely spoken
_#_Literacy: 96% (male 96%, female 96%) age 15 and over can
read and write (1980)
_#_Labor force: 54,000; government 42%, private 58% (1988)
_#_Organized labor: 13% of labor force
_#_Population: 9,266,018 (July 1991), growth rate 2.5% (1991)
_#_Birth rate: 35 births/1,000 population (1991)
_#_Death rate: 8 deaths/1,000 population (1991)
_#_Net migration rate: - 2 migrants/1,000 population (1991)
_#_Infant mortality rate: 58 deaths/1,000 live births (1991)
_#_Life expectancy at birth: 61 years male, 66 years female (1991)
_#_Total fertility rate: 4.8 children born/woman (1991)
_#_Nationality: noun--Guatemalan(s); adjective--Guatemalan
_#_Ethnic divisions: Ladino (mestizo--mixed Indian and European
ancestry) 56%, Indian 44%
_#_Religion: predominantly Roman Catholic; also Protestant,
traditional Mayan
_#_Language: Spanish, but over 40% of the population speaks an Indian
language as a primary tongue (18 Indian dialects, including Quiche,
Cakchiquel, Kekchi)
_#_Literacy: 55% (male 63%, female 47%) age 15 and over can
read and write (1990 est.)
_#_Labor force: 2,500,000; agriculture 60%, services 13%,
manufacturing 12%, commerce 7%, construction 4%, transport 3%,
utilities 0.8%, mining 0.4% (1985)
_#_Organized labor: 8% of labor force (1988 est.)
_#_Population: 57,596 (July 1991), growth rate 0.6% (1991)
_#_Birth rate: 12 births/1,000 population (1991)
_#_Death rate: 11 deaths/1,000 population (1991)
_#_Net migration rate: 5 migrants/1,000 population (1991)
_#_Infant mortality rate: 6 deaths/1,000 live births (1991)
_#_Life expectancy at birth: 72 years male, 78 years female (1991)
_#_Total fertility rate: 1.6 children born/woman (1991)
_#_Nationality: noun--Channel Islander(s); adjective--Channel Islander
_#_Ethnic divisions: UK and Norman-French descent
_#_Religion: Anglican, Roman Catholic, Presbyterian, Baptist,
Congregational, Methodist
_#_Language: English, French; Norman-French dialect spoken in country
districts
_#_Literacy: NA% (male NA%, female NA%) but compulsory education
age 5 to 16
_#_Labor force: NA
_#_Organized labor: NA
_#_Population: 7,455,850 (July 1991), growth rate 2.5% (1991)
_#_Birth rate: 47 births/1,000 population (1991)
_#_Death rate: 21 deaths/1,000 population (1991)
_#_Net migration rate: 0 migrants/1,000 population (1991)
_#_Infant mortality rate: 144 deaths/1,000 live births (1991)
_#_Life expectancy at birth: 41 years male, 45 years female (1991)
_#_Total fertility rate: 6.0 children born/woman (1991)
_#_Nationality: noun--Guinean(s); adjective--Guinean
_#_Ethnic divisions: Fulani 35%, Malinke 30%, Soussou 20%, small
indigenous tribes 15%
_#_Religion: Muslim 85%, Christian 8%, indigenous beliefs 7%
_#_Language: French (official); each tribe has its own language
_#_Literacy: 24% (male 35%, female 13%) age 15 and over can
read and write (1990 est.)
_#_Labor force: 2,400,000 (1983); agriculture 82.0%, industry and
commerce 11.0%, services 5.4%; 88,112 civil servants (1987); 52% of
population of working age (1985)
_#_Organized labor: virtually 100% of wage earners loosely affiliated
with the National Confederation of Guinean Workers
_#_Population: 1,023,544 (July 1991), growth rate 2.4% (1991)
_#_Birth rate: 42 births/1,000 population (1991)
_#_Death rate: 18 deaths/1,000 population (1991)
_#_Net migration rate: 0 migrants/1,000 population (1991)
_#_Infant mortality rate: 125 deaths/1,000 live births (1991)
_#_Life expectancy at birth: 45 years male, 48 years female (1991)
_#_Total fertility rate: 5.8 children born/woman (1991)
_#_Nationality: noun--Guinea-Bissauan(s); adjective--Guinea-Bissauan
_#_Ethnic divisions: African about 99% (Balanta 30%, Fula 20%, Manjaca
14%, Mandinga 13%, Papel 7%); European and mulatto less than 1%
_#_Religion: indigenous beliefs 65%, Muslim 30%, Christian 5%
_#_Language: Portuguese (official); Criolo and numerous African
languages
_#_Literacy: 36% (male 50%, female 24%) age 15 and over can
read and write (1990 est.)
_#_Labor force: 403,000 (est.); agriculture 90%, industry, services,
and commerce 5%, government 5%; population of working age 53% (1983)
_#_Organized labor: only one trade union--the National Union of
Workers of Guinea-Bissau (UNTG)','39dc994563d099adc9bc8d423d3f799aa55b0d5db020a5314c036fd21edfe65a','internet-archive','theciaworldfactb00025gut','txt','84185fe9df79da427349cc1598fd3f69814a2085a9fc1fe0508a3fae0a870f84','https://archive.org/download/theciaworldfactb00025gut/25.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5bce69f7ee376dcd60c4930afba399e00267b0fc924c6720ee01428830745214',1991,'ES','Spain','people-and-society',83,'_#_Population: 749,508 (July 1991), growth rate - 0.4% (1991)
_#_Birth rate: 23 births/1,000 population (1991)
_#_Death rate: 7 deaths/1,000 population (1991)
_#_Net migration rate: - 20 migrants/1,000 population (1991)
_#_Infant mortality rate: 51 deaths/1,000 live births (1991)
_#_Life expectancy at birth: 61 years male, 68 years female (1991)
_#_Total fertility rate: 2.6 children born/woman (1991)
_#_Nationality: noun--Guyanese (sing., pl.); adjective--Guyanese
_#_Ethnic divisions: East Indian 51%, black and mixed 43%, Amerindian
4%, European and Chinese 2%
_#_Religion: Christian 57%, Hindu 33%, Muslim 9%, other 1%
_#_Language: English, Amerindian dialects
_#_Literacy: 95% (male 98%, female 96%) age 15 and over having ever
attended school (1990 est.)
_#_Labor force: 268,000; industry and commerce 44.5%, agriculture
33.8%, services 21.7%; public-sector employment amounts to 60-80%
of the total labor force (1985)
_#_Organized labor: 34% of labor force
_#_Population: 6,286,511 (July 1991), growth rate 2.3% (1991)
_#_Birth rate: 43 births/1,000 population (1991)
_#_Death rate: 15 deaths/1,000 population (1991)
_#_Net migration rate: - 5 migrants/1,000 population (1991)
_#_Infant mortality rate: 106 deaths/1,000 live births (1991)
_#_Life expectancy at birth: 52 years male, 55 years female (1991)
_#_Total fertility rate: 6.3 children born/woman (1991)
_#_Nationality: noun--Haitian(s); adjective--Haitian
_#_Ethnic divisions: black 95%, mulatto and European 5%
_#_Religion: Roman Catholic is the official religion; Roman
Catholic 80% (of which an overwhelming majority also practice Voodoo),
Protestant 16% (Baptist 10%, Pentecostal 4%, Adventist 1%, other 1%),
none 1%, other 3% (1982)
_#_Language: French (official) spoken by only 10% of population; all
speak Creole
_#_Literacy: 53% (male 59%, female 47%) age 15 and over can
read and write (1990 est.)
_#_Labor force: 2,300,000; agriculture 66%, services 25%, industry 9%;
shortage of skilled labor, unskilled labor abundant (1982)
_#_Organized labor: NA
_#_Population: uninhabited
_#_Population: 4,949,275 (July 1991), growth rate 2.9% (1991)
_#_Birth rate: 38 births/1,000 population (1991)
_#_Death rate: 7 deaths/1,000 population (1991)
_#_Net migration rate: - 2 migrants/1,000 population (1991)
_#_Infant mortality rate: 56 deaths/1,000 live births (1991)
_#_Life expectancy at birth: 64 years male, 68 years female (1991)
_#_Total fertility rate: 5.0 children born/woman (1991)
_#_Nationality: noun--Honduran(s); adjective--Honduran
_#_Ethnic divisions: mestizo (mixed Indian and European) 90%, Indian
7%, black 2%, white 1%
_#_Religion: Roman Catholic about 97%; small Protestant minority
_#_Language: Spanish, Indian dialects
_#_Literacy: 73% (male 76%, female 71%) age 15 and over can
read and write (1990 est.)
_#_Labor force: 1,300,000; agriculture 62%, services 20%,
manufacturing 9%, construction 3%, other 6% (1985)
_#_Organized labor: 40% of urban labor force, 20% of rural work force
(1985)
_#_Population: 5,855,800 (July 1991), growth rate 0.6% (1991)
_#_Birth rate: 13 births/1,000 population (1991)
_#_Death rate: 5 deaths/1,000 population (1991)
_#_Net migration rate: - 2 migrants/1,000 population (1991)
_#_Infant mortality rate: 7 deaths/1,000 live births (1991)
_#_Life expectancy at birth: 77 years male, 84 years female (1991)
_#_Total fertility rate: 1.4 children born/woman (1991)
_#_Nationality: adjective--Hong Kong
_#_Ethnic divisions: Chinese 98%, other 2%
_#_Religion: eclectic mixture of local religions 90%, Christian 10%
_#_Language: Chinese (Cantonese), English
_#_Literacy: 77% (male 90%, female 64%) age 15 and over having ever
attended school (1971)
_#_Labor force: 2,800,000 (1990); manufacturing 28.5%, wholesale and
retail trade, restaurants, and hotels 27.9%, services 17.7%,
financing, insurance, and real estate 9.2%, transport and communications
4.5%, construction 2.5%, other 9.7% (1989)
_#_Organized labor: 16% of labor force (1990)
_#_Population: uninhabited
_#_Note: American civilians evacuated in 1942 after Japanese air and
naval attacks during World War II; occupied by US military during World
War II, but abandoned after the war; public entry is by special-use
permit only and generally restricted to scientists and educators
_#_Population: 10,558,001 (July 1991), growth rate - 0.1% (1991)
_#_Birth rate: 12 births/1,000 population (1991)
_#_Death rate: 13 deaths/1,000 population (1991)
_#_Net migration rate: 0 migrants/1,000 population (1991)
_#_Infant mortality rate: 14 deaths/1,000 live births (1991)
_#_Life expectancy at birth: 68 years male, 76 years female (1991)
_#_Total fertility rate: 1.8 children born/woman (1991)
_#_Nationality: noun--Hungarian(s); adjective--Hungarian
_#_Ethnic divisions: Hungarian 96.6%, German 1.6%, Slovak 1.1%,
Southern Slav 0.3%, Romanian 0.2%
_#_Religion: Roman Catholic 67.5%, Calvinist 20.0%, Lutheran 5.0%,
atheist and other 7.5%
_#_Language: Hungarian 98.2%, other 1.8%
_#_Literacy: 99% (male 99%, female 98%) age 15 and over can
read and write (1980)
_#_Labor force: 4,860,000; services, trade, government, and other
43.2%, industry 30.9%, agriculture 18.8%, construction 7.1% (1988)
_#_Organized labor: 96.5% of labor force; Central Council of Hungarian
Trade Unions (SZOT) includes 19 affiliated unions, all controlled by the
government; independent unions legal; may be as many as 12 small
independent unions in operation
_#_Population: 259,742 (July 1991), growth rate 1.0% (1991)
_#_Birth rate: 17 births/1,000 population (1991)
_#_Death rate: 7 deaths/1,000 population (1991)
_#_Net migration rate: 0 migrants/1,000 population (1991)
_#_Infant mortality rate: 7 deaths/1,000 live births (1991)
_#_Life expectancy at birth: 75 years male, 80 years female (1991)
_#_Total fertility rate: 2.2 children born/woman (1991)
_#_Nationality: noun--Icelander(s); adjective--Icelandic
_#_Ethnic divisions: homogeneous mixture of descendants of Norwegians
and Celts
_#_Religion: Evangelical Lutheran 96%, other Protestant and Roman
Catholic 3%, none 1% (1988)
_#_Language: Icelandic
_#_Literacy: 100% (male NA%, female NA%) age 15 and over can
read and write (1976 est.)
_#_Labor force: 134,429; commerce, finance, and services 55.4%, other
manufacturing 14.3%., agriculture 5.8%, fish processing 7.9%, fishing
5.0% (1986)
_#_Organized labor: 60% of labor force
_#_Population: 866,351,738 (July 1991), growth rate 1.9% (1991)
_#_Birth rate: 29 births/1,000 population (1991)
_#_Death rate: 10 deaths/1,000 population (1991)
_#_Net migration rate: 0 migrants/1,000 population (1991)
_#_Infant mortality rate: 87 deaths/1,000 live births (1991)
_#_Life expectancy at birth: 57 years male, 59 years female (1991)
_#_Total fertility rate: 3.7 children born/woman (1991)
_#_Nationality: noun--Indian(s); adjective--Indian
_#_Ethnic divisions: Indo-Aryan 72%, Dravidian 25%, Mongoloid and
other 3%
_#_Religion: Hindu 82.6%, Muslim 11.4%, Christian 2.4%, Sikh 2.0%,
Buddhist 0.7%, Jains 0.5%, other 0.4%
_#_Language: Hindi, English, and 14 other official languages--Bengali,
Telugu, Marathi, Tamil, Urdu, Gujarati, Malayalam, Kannada, Oriya,
Punjabi, Assamese, Kashmiri, Sindhi, and Sanskrit; 24 languages spoken by
a million or more persons each; numerous other languages and dialects,
for the most part mutually unintelligible; Hindi is the national language
and primary tongue of 30% of the people; English enjoys associate status
but is the most important language for national, political, and
commercial communication; Hindustani, a popular variant of Hindi/Urdu, is
spoken widely throughout northern India
_#_Literacy: 48% (male 62%, female 34%) age 15 and over can
read and write (1990 est.)
_#_Labor force: 284,400,000; 67% agriculture (FY85)
_#_Organized labor: less than 5% of the labor force
_#_Population: 193,560,494 (July 1991), growth rate 1.8% (1991)
_#_Birth rate: 26 births/1,000 population (1991)
_#_Death rate: 8 deaths/1,000 population (1991)
_#_Net migration rate: 0 migrants/1,000 population (1991)
_#_Infant mortality rate: 73 deaths/1,000 live births (1991)
_#_Life expectancy at birth: 59 years male, 63 years female (1991)
_#_Total fertility rate: 3.0 children born/woman (1991)
_#_Nationality: noun--Indonesian(s); adjective--Indonesian
_#_Ethnic divisions: majority of Malay stock comprising Javanese
45.0%, Sundanese 14.0%, Madurese 7.5%, coastal Malays 7.5%, other
26.0%
_#_Religion: Muslim 87%, Protestant 6%, Roman Catholic 3%,
Hindu 2%, Buddhist 1%, other 1% (1985)
_#_Language: Bahasa Indonesia (modified form of Malay; official);
English and Dutch leading foreign languages; local dialects, the most
widely spoken of which is Javanese
_#_Literacy: 77% (male 84%, female 68%) age 15 and over can
read and write (1990 est.)
_#_Labor force: 67,000,000; agriculture 55%, manufacturing 10%,
construction 4%, transport and communications 3% (1985 est.)
_#_Organized labor: 3,000,000 members (claimed); about 5% of labor
force
_#_Population: 59,051,082 (July 1991), growth rate 3.6% (1991)
_#_Birth rate: 44 births/1,000 population (1991)
_#_Death rate: 9 deaths/1,000 population (1991)
_#_Net migration rate: 0 migrants/1,000 population (1991)
_#_Infant mortality rate: 66 deaths/1,000 live births (1991)
_#_Life expectancy at birth: 64 years male, 65 years female (1991)
_#_Total fertility rate: 6.6 children born/woman (1991)
_#_Nationality: noun--Iranian(s); adjective--Iranian
_#_Ethnic divisions: Persian 51%, Azerbaijani 25%, Kurd 9%, Gilaki
and Mazandarani 8%, Lur 2%, Baloch 1%, Arab 1%, other 3%
_#_Religion: Shia Muslim 95%, Sunni Muslim 4%, Zoroastrian, Jewish,
Christian, and Bahai 1%
_#_Language: 58% Persian and Persian dialects, 26% Turkic and Turkic
dialects, 9% Kurdish, 2% Luri, 1% Baloch, 1% Arabic, 1% Turkish, 2% other
_#_Literacy: 54% (male 64%, female 43%) age 15 and over can
read and write (1990 est.)
_#_Labor force: 15,400,000; agriculture 33%, manufacturing 21%;
shortage of skilled labor (1988 est.)
_#_Organized labor: none
_#_Population: 19,524,718 (July 1991), growth rate 3.9% (1991)
_#_Birth rate: 46 births/1,000 population (1991)
_#_Death rate: 7 deaths/1,000 population (1991)
_#_Net migration rate: 0 migrants/1,000 population (1991)
_#_Infant mortality rate: 66 deaths/1,000 live births (1991)
_#_Life expectancy at birth: 66 years male, 68 years female (1991)
_#_Total fertility rate: 7.2 children born/woman (1991)
_#_Nationality: noun--Iraqi(s); adjective--Iraqi
_#_Ethnic divisions: Arab 75-80%, Kurdish 15-20%, Turkoman, Assyrian
or other 5%
_#_Religion: Muslim 97%, (Shia 60-65%, Sunni 32-37%), Christian
or other 3%
_#_Language: Arabic (official), Kurdish (official in Kurdish regions),
Assyrian, Armenian
_#_Literacy: 60% (male 70%, female 49%) age 15 and over can
read and write (1990 est.)
_#_Labor force: 4,400,000 (1989); services 48%, agriculture 30%,
industry 22%, severe labor shortage; expatriate labor force about
1,600,000 (July 1990)
_#_Organized labor: less than 10% of the labor force
_#_Population: uninhabited
_#_Population: 3,489,165 (July 1991), growth rate - 0.3% (1991)
_#_Birth rate: 15 births/1,000 population (1991)
_#_Death rate: 9 deaths/1,000 population (1991)
_#_Net migration rate: - 9 migrants/1,000 population (1991)
_#_Infant mortality rate: 6 deaths/1,000 live births (1991)
_#_Life expectancy at birth: 73 years male, 79 years female (1991)
_#_Total fertility rate: 2.1 children born/woman (1991)
_#_Nationality: noun--Irishman(men), Irish (collective pl.);
adjective--Irish
_#_Ethnic divisions: Celtic, with English minority
_#_Religion: Roman Catholic 93%, Anglican 3%, none 1%, unknown 2%,
other 1% (1981)
_#_Language: Irish (Gaelic) and English; English is the language
generally used, with Gaelic spoken in a few areas, mostly along the
western seaboard
_#_Literacy: 98% (male NA%, female NA%) age 15 and over can
read and write (1981 est.)
_#_Labor force: 1,293,000; services 57.0%, manufacturing and
construction 26.1%, agriculture, forestry, and fishing 15.0%,
energy and mining 1.9% (1988)
_#_Organized labor: 36% of labor force
_#_Population: 4,477,105 (July 1991), growth rate 1.5% (1991);
includes 90,000 Jewish settlers in the West Bank, 13,000 in the
Israeli-occupied Golan Heights, 2,500 in the Gaza Strip, and 120,000 in
East Jerusalem (1990 est.)
_#_Birth rate: 21 births/1,000 population (1991)
_#_Death rate: 6 deaths/1,000 population (1991)
_#_Net migration rate: 0 migrants/1,000 population (1991)
_#_Infant mortality rate: 9 deaths/1,000 live births (1991)
_#_Life expectancy at birth: 76 years male, 79 years female (1991)
_#_Total fertility rate: 2.9 children born/woman (1991)
_#_Nationality: noun--Israeli(s); adjective--Israeli
_#_Ethnic divisions: Jewish 83%, non-Jewish (mostly Arab) 17%
_#_Religion: Judaism 82%, Islam (mostly Sunni Muslim) 14%,
Christian 2%, Druze and other 2%
_#_Language: Hebrew (official); Arabic used officially for Arab
minority; English most commonly used foreign language
_#_Literacy: 92% (male 95%, female 89%) age 15 and over can
read and write (1983)
_#_Labor force: 1,400,000 (1984 est.); public services 29.3%;
industry, mining, and manufacturing 22.8%; commerce 12.8%; finance and
business 9.5%; transport, storage, and communications 6.8%; construction
and public works 6.5%; personal and other services 5.8%; agriculture,
forestry, and fishing 5.5%; electricity and water 1.0% (1983)
_#_Organized labor: 90% of labor force
_#_Population: 57,772,375 (July 1991), growth rate 0.2% (1991)
_#_Birth rate: 11 births/1,000 population (1991)
_#_Death rate: 10 deaths/1,000 population (1991)
_#_Net migration rate: 1 migrant/1,000 population (1991)
_#_Infant mortality rate: 6 deaths/1,000 live births (1991)
_#_Life expectancy at birth: 75 years male, 82 years female (1991)
_#_Total fertility rate: 1.4 children born/woman (1991)
_#_Nationality: noun--Italian(s); adjective--Italian
_#_Ethnic divisions: primarily Italian but population includes small
clusters of German-, French-, and Slovene-Italians in the north and
Albanian-Italians and Greek-Italians in the south; Sicilians; Sardinians
_#_Religion: nominally Roman Catholic almost 100%
_#_Language: Italian; parts of Trentino-Alto Adige region are
predominantly German speaking; significant French-speaking minority in
Valle d''Aosta region; Slovene-speaking minority in the Trieste-Gorizia
area
_#_Literacy: 97% (male 98%, female 96%) age 15 and over can
read and write (1990 est.)
_#_Labor force: 23,988,000; services 58%, industry 32.2%,
agriculture 9.8% (1988)
_#_Organized labor: 40-45% of labor force (est.)
_#_Population: 12,977,909 (July 1991), growth rate 3.9% (1991)
_#_Birth rate: 48 births/1,000 population (1991)
_#_Death rate: 12 deaths/1,000 population (1991)
_#_Net migration rate: 4 migrants/1,000 population (1991)
_#_Infant mortality rate: 97 deaths/1,000 live births (1991)
_#_Life expectancy at birth: 52 years male, 56 years female (1991)
_#_Total fertility rate: 6.8 children born/woman (1991)
_#_Nationality: noun--Ivorian(s); adjective--Ivorian
_#_Ethnic divisions: over 60 ethnic groups; most important are the
Baoule 23%, Bete 18%, Senoufou 15%, Malinke 11%, and Agni; foreign
Africans, mostly Burkinabe about 2 million; non-Africans about 130,000 to
330,000 (French 30,000 and Lebanese 100,000 to 300,000)
_#_Religion: indigenous 63%, Muslim 25%, Christian 12%,
_#_Language: French (official), over 60 native dialects; Dioula most
widely spoken
_#_Literacy: 54% (male 67%, female 40%) age 15 and over can
read and write (1990 est.)
_#_Labor force: 5,718,000; over 85% of population engaged in
agriculture, forestry, livestock raising; about 11% of labor force are
wage earners, nearly half in agriculture and the remainder in government,
industry, commerce, and professions; 54% of population of working age
(1985)
_#_Organized labor: 20% of wage labor force
_#_Population: 2,489,353 (July 1991), growth rate 0.9% (1991)
_#_Birth rate: 24 births/1,000 population (1991)
_#_Death rate: 6 deaths/1,000 population (1991)
_#_Net migration rate: - 9 migrants/1,000 population (1991)
_#_Infant mortality rate: 18 deaths/1,000 live births (1991)
_#_Life expectancy at birth: 72 years male, 76 years female (1991)
_#_Total fertility rate: 2.6 children born/woman (1991)
_#_Nationality: noun--Jamaican(s); adjective--Jamaican
_#_Ethnic divisions: African 76.3%, Afro-European 15.1%, East Indian
and Afro-East Indian 3.0%, white 3.2%, Chinese and Afro-Chinese 1.2%,
other 1.2%
_#_Religion: predominantly Protestant 55.9% (Church of God 18.4%,
Baptist 10%, Anglican 7.1%, Seven-Day Adventist 6.9%, Pentecostal 5.2%,
Methodist 3.1%, United Church 2.7%, other 2.5%), Roman Catholic 5%,
other 39.1%, including some spiritualist cults (1982)
_#_Language: English, Creole
_#_Literacy: 98% (male 98%, female 99%) age 15 and over having ever
attended school (1990 est.)
_#_Labor force: 1,062,100; services 41%, agriculture 22.5%, industry
19%; unemployed 17.5% (1989)
_#_Organized labor: 24% of labor force (1989)
_#_Population: no permanent inhabitants
_#_Population: 124,017,137 (July 1991), growth rate 0.4% (1991)
_#_Birth rate: 10 births/1,000 population (1991)
_#_Death rate: 7 deaths/1,000 population (1991)
_#_Net migration rate: 0 migrants/1,000 population (1991)
_#_Infant mortality rate: 4 deaths/1,000 live births (1991)
_#_Life expectancy at birth: 76 years male, 82 years female (1991)
_#_Total fertility rate: 1.6 children born/woman (1991)
_#_Nationality: noun--Japanese (sing., pl.); adjective--Japanese
_#_Ethnic divisions: Japanese 99.4%, other (mostly Korean) 0.6%
_#_Religion: most Japanese observe both Shinto and Buddhist rites
so the percentages add to more than 100%--Shinto 95.8%,
Buddhist 76.3%, Christian 1.4%, other 12% (1985)
_#_Language: Japanese
_#_Literacy: 99% (male NA%, female NA%) age 15 and over can
read and write (1970 est.)
_#_Labor force: 63,330,000; trade and services 54%; manufacturing,
mining, and construction 33%; agriculture, forestry, and fishing 7%;
government 3% (1988)
_#_Organized labor: about 29% of employed workers; public service
76.4%, transportation and telecommunications 57.9%, mining 48.7%,
manufacturing 33.7%, services 18.2%, wholesale, retail, and restaurant
9.3%
_#_Population: uninhabited
_#_Note: Millersville settlement on western side of island
occasionally used as a weather station from 1935 until World War II, when
it was abandoned; reoccupied in 1957 during the International Geophysical
Year by scientists who left in 1958; public entry is by special-use
permit only and generally restricted to scientists and educators
_#_Population: 84,331 (July 1991), growth rate 0.8% (1991)
_#_Birth rate: 12 births/1,000 population (1991)
_#_Death rate: 10 deaths/1,000 population (1991)
_#_Net migration rate: 6 migrants/1,000 population (1991)
_#_Infant mortality rate: 6 deaths/1,000 live births (1991)
_#_Life expectancy at birth: 72 years male, 78 years female (1991)
_#_Total fertility rate: 1.3 children born/woman (1991)
_#_Nationality: noun--Channel Islander(s); adjective--Channel Islander
_#_Ethnic divisions: UK and Norman-French descent
_#_Religion: Anglican, Roman Catholic, Baptist, Congregational New
Church, Methodist, Presbyterian
_#_Language: English and French (official), with the Norman-French
dialect spoken in country districts
_#_Literacy: NA% (male NA%, female NA%) but compulsory education
age 5 to 16
_#_Labor force: NA
_#_Organized labor: none','3cdff223fe6b1f8badab8ed539a8a507ea3b14bc80aa9c9886fd86f85e01793e','internet-archive','theciaworldfactb00025gut','txt','84185fe9df79da427349cc1598fd3f69814a2085a9fc1fe0508a3fae0a870f84','https://archive.org/download/theciaworldfactb00025gut/25.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('13d3d6d7e07f45ff6749e62864e76c6b4e1bbc0f0d0c68d64a022cef8a1e4097',1991,'FR','France','people-and-society',98,'_#_Population: 1,325 (December 1990); all US government personnel and
contractors
_#_Population: 3,412,553 (July 1991), growth rate 4.2% (1991)
_#_Birth rate: 46 births/1,000 population (1991)
_#_Death rate: 5 deaths/1,000 population (1991)
_#_Net migration rate: 1 migrants/1,000 population (1991)
_#_Infant mortality rate: 38 deaths/1,000 live births (1991)
_#_Life expectancy at birth: 70 years male, 73 years female (1991)
_#_Total fertility rate: 7.1 children born/woman (1991)
_#_Nationality: noun--Jordanian(s); adjective--Jordanian
_#_Ethnic divisions: Arab 98%, Circassian 1%, Armenian 1%
_#_Religion: Sunni Muslim 92%, Christian 8%
_#_Language: Arabic (official); English widely understood among
upper and middle classes
_#_Literacy: 80% (male 89%, female 70%) age 15 and over can
read and write (1990 est.)
_#_Labor force: 572,000 (1988); agriculture 20%, manufacturing and
mining 20% (1987 est.)
_#_Organized labor: about 10% of labor force
_#_Note: 1.5-1.7 million Palestinians live on the East Bank (55-60%
of the population), most are Jordanian citizens
_#_Population: uninhabited
_#_Population: 25,241,978 (July 1991), growth rate 3.6% (1991)
_#_Birth rate: 45 births/1,000 population (1991)
_#_Death rate: 8 deaths/1,000 population (1991)
_#_Net migration rate: 0 migrants/1,000 population (1991)
_#_Infant mortality rate: 69 deaths/1,000 live births (1991)
_#_Life expectancy at birth: 60 years male, 64 years female (1991)
_#_Total fertility rate: 6.4 children born/woman (1991)
_#_Nationality: noun--Kenyan(s); adjective--Kenyan
_#_Ethnic divisions: Kikuyu 21%, Luhya 14%, Luo 13%, Kalenjin 11%,
Kamba 11%, Kisii 6%, Meru 6%, Asian, European, and Arab 1%
_#_Religion: Protestant 38%, Roman Catholic 28%, indigenous beliefs
26%, Muslim 6%
_#_Language: English and Swahili (official); numerous indigenous
languages
_#_Literacy: 69% (male 80%, female 58%) age 15 and over can
read and write (1990 est.)
_#_Labor force: 9.2 million (includes unemployed); the total
employed is 1.37 million (14.8% of the labor force); services
54.8%, industry 26.2%, agriculture 19.0% (1989)
_#_Organized labor: 390,000 (est.)
_#_Population: uninhabited
_#_Population: 71,137 (July 1991), growth rate 1.6% (1991)
_#_Birth rate: 33 births/1,000 population (1991)
_#_Death rate: 12 deaths/1,000 population (1991)
_#_Net migration rate: - 5 migrants/1,000 population (1991)
_#_Infant mortality rate: 63 deaths/1,000 live births (1991)
_#_Life expectancy at birth: 52 years male, 58 years female (1991)
_#_Total fertility rate: 4.2 children born/woman (1991)
_#_Nationality: noun--I-Kiribati (sing., pl.); adjective--I-Kiribati
_#_Ethnic divisions: Micronesian
_#_Religion: Roman Catholic 52.6%, Protestant (Congregational) 40.9%,
Seventh-Day Adventist, Baha''i, Church of God, Mormon 6% (1985)
_#_Language: English (official), Gilbertese
_#_Literacy: NA% (male NA%, female NA%)
_#_Labor force: 7,870 economically active (1985 est.)
_#_Organized labor: Kiribati Trades Union Congress--2,500 members
_#_Population: 21,814,656 (July 1991), growth rate 1.9% (1991)
_#_Birth rate: 24 births/1,000 population (1991)
_#_Death rate: 6 deaths/1,000 population (1991)
_#_Net migration rate: 0 migrants/1,000 population (1991)
_#_Infant mortality rate: 30 deaths/1,000 live births (1991)
_#_Life expectancy at birth: 66 years male, 72 years female (1991)
_#_Total fertility rate: 2.5 children born/woman (1991)
_#_Nationality: noun--Korean(s); adjective--Korean
_#_Ethnic divisions: racially homogeneous
_#_Religion: Buddhism and Confucianism; religious activities now
almost nonexistent
_#_Language: Korean
_#_Literacy: NA% (male NA%, female NA%)
_#_Labor force: 9,615,000; agricultural 36%, nonagricultural 64%;
shortage of skilled and unskilled labor (mid-1987 est.)
_#_Organized labor: 1,600,000 members; single-trade union system
coordinated by the General Federation of Trade Unions of Korea under the
Central Committee
_#_Population: 43,134,386 (July 1991), growth rate 0.8% (1991)
_#_Birth rate: 15 births/1,000 population (1991)
_#_Death rate: 6 deaths/1,000 population (1991)
_#_Net migration rate: - 1 migrant/1,000 population (1991)
_#_Infant mortality rate: 23 deaths/1,000 live births (1991)
_#_Life expectancy at birth: 67 years male, 73 years female (1991)
_#_Total fertility rate: 1.6 children born/woman (1991)
_#_Nationality: noun--Korean(s); adjective--Korean
_#_Ethnic divisions: homogeneous; small Chinese minority
(about 20,000)
_#_Religion: strong Confucian tradition; vigorous Christian minority
(28% of the total population); Buddhism; pervasive folk religion
(Shamanism); Chondokyo (religion of the heavenly way), eclectic religion
with nationalist overtones founded in 19th century, claims about 1.5
million adherents
_#_Language: Korean; English widely taught in high school
_#_Literacy: 96% (male 99%, female 94%) age 15 and over can
read and write (1990 est.)
_#_Labor force: 16,900,000; 52% services and other; 27% mining and
manufacturing; 21% agriculture, fishing, forestry (1987)
_#_Organized labor: about 10% of nonagricultural labor force in
government-sanctioned unions
_#_Population: 2,204,400 (July 1991), growth rate 3.6% (1991)
_#_Birth rate: 29 births/1,000 population (1991)
_#_Death rate: 2 deaths/1,000 population (1991)
_#_Net migration rate: 10 migrants/1,000 population (1991)
_#_Infant mortality rate: 15 deaths/1,000 live births (1991)
_#_Life expectancy at birth: 72 years male, 76 years female (1991)
_#_Total fertility rate: 3.7 children born/woman (1991)
_#_Nationality: noun--Kuwaiti(s); adjective--Kuwaiti
_#_Ethnic divisions: Kuwaiti 27.9%, other Arab 39%, South Asian 9%,
Iranian 4%, other 20.1%
_#_Religion:
Muslim 85% (Shia 30%, Sunni 45%, other 10%), Christian, Hindu, Parsi,
and other 15%
_#_Language: Arabic (official); English widely spoken
_#_Literacy: 74% (male 78%, female 69%) age 15 and over can
read and write (1985)
_#_Labor force: 566,000 (1986); services 45.0%, construction 20.0%,
trade 12.0%, manufacturing 8.6%, finance and real estate 2.6%,
agriculture 1.9%, power and water 1.7%, mining and quarrying 1.4%; 70% of
labor force was non-Kuwaiti
_#_Organized labor: labor unions exist in oil industry and among
government personnel
_#_Population: 4,113,223 (July 1991), growth rate 2.2% (1991)
_#_Birth rate: 37 births/1,000 population (1991)
_#_Death rate: 15 deaths/1,000 population (1991)
_#_Net migration rate: 0 migrants/1,000 population (1991)
_#_Infant mortality rate: 124 deaths/1,000 live births (1991)
_#_Life expectancy at birth: 49 years male, 52 years female (1991)
_#_Total fertility rate: 5.0 children born/woman (1991)
_#_Nationality: noun--Lao (sing., Lao or Laotian); adjective--Lao
or Laotian
_#_Ethnic divisions: Lao 50%, Phoutheung (Kha) 15%, tribal Thai 20%,
Meo, Hmong, Yao, and other 15%
_#_Religion: Buddhist 85%, animist and other 15%
_#_Language: Lao (official), French, and English
_#_Literacy: 84% (male 92%, female 76%) age 15 to 45 can
read and write (1985 est.)
_#_Labor force: 1-1.5 million; 85-90% in agriculture (est.)
_#_Organized labor: Lao Federation of Trade Unions is subordinate to
the Communist party
_#_Population: 3,384,626 (July 1991), growth rate 1.4% (1991)
_#_Birth rate: 28 births/1,000 population (1991)
_#_Death rate: 7 deaths/1,000 population (1991)
_#_Net migration rate: - 7 migrants/1,000 population (1991)
_#_Infant mortality rate: 48 deaths/1,000 live births (1991)
_#_Life expectancy at birth: 66 years male, 71 years female (1991)
_#_Total fertility rate: 3.6 children born/woman (1991)
_#_Nationality: noun--Lebanese (sing., pl.); adjective--Lebanese
_#_Ethnic divisions: Arab 95%, Armenian 4%, other 1%
_#_Religion: Islam 75%, Christian 25%, Judaism NEGL%; 17 legally
recognized sects--4 Orthodox Christian (Armenian Orthodox, Greek
Orthodox, Nestorean, Syriac Orthodox), 7 Uniate Christian (Armenian
Catholic, Caldean, Greek Catholic, Maronite, Protestant, Roman Catholic,
Syrian Catholic), 5 Islam (Alawite or Nusayri, Druze, Ismailite,
Shia, Sunni), and 1 Jewish
_#_Language: Arabic and French (both official); Armenian, English
_#_Literacy: 80% (male 88%, female 73%) age 15 and over can
read and write (1990 est.)
_#_Labor force: 650,000; industry, commerce, and services 79%,
agriculture 11%, goverment 10% (1985)
_#_Organized labor: 250,000 members (est.)
_#_Population: 1,801,174 (July 1991), growth rate 2.6% (1991)
_#_Birth rate: 36 births/1,000 population (1991)
_#_Death rate: 10 deaths/1,000 population (1991)
_#_Net migration rate: 0 migrants/1,000 population (1991)
_#_Infant mortality rate: 78 deaths/1,000 live births (1991)
_#_Life expectancy at birth: 59 years male, 63 years female (1991)
_#_Total fertility rate: 4.8 children born/woman (1991)
_#_Nationality: noun--Mosotho (sing.), Basotho (pl.);
adjective--Basotho
_#_Ethnic divisions: Sotho 99.7%; Europeans 1,600, Asians 800
_#_Religion: Christian 80%, rest indigenous beliefs
_#_Language: Sesotho (southern Sotho) and English (official); also
Zulu and Xhosa
_#_Literacy: 59% (male 44%, female 68%) age 15 and over can
read and write (1966)
_#_Labor force: 689,000 economically active; 86.2% of resident
population engaged in subsistence agriculture; roughly 60% of active
male labor force works in South Africa
_#_Organized labor: there are two trade union federations; the
government favors formation of a single, umbrella trade union
confederation
_#_Population: 2,730,446 (July 1991), growth rate 3.4% (1991)
_#_Birth rate: 45 births/1,000 population (1991)
_#_Death rate: 13 deaths/1,000 population (1991)
_#_Net migration rate: 2 migrants/1,000 population (1991)
_#_Infant mortality rate: 124 deaths/1,000 live births (1991)
_#_Life expectancy at birth: 54 years male, 59 years female (1991)
_#_Total fertility rate: 6.5 children born/woman (1991)
_#_Nationality: noun--Liberian(s); adjective--Liberian
_#_Ethnic divisions: indigenous African tribes, including Kpelle,
Bassa, Gio, Kru, Grebo, Mano, Krahn, Gola, Gbandi, Loma, Kissi, Vai, and
Bella 95%; descendants of repatriated slaves known as Americo-Liberians
5%
_#_Religion: traditional 70%, Muslim 20%, Christian 10%
_#_Language: English (official); more than 20 local languages of the
Niger-Congo language group; English used by about 20%
_#_Literacy: 40% (male 50%, female 29%) age 15 and over can
read and write (1990 est.)
_#_Labor force: 510,000, including 220,000 in the monetary economy;
agriculture 70.5%, services 10.8%, industry and commerce 4.5%, other
14.2%; non-African foreigners hold about 95% of the top-level management
and engineering jobs; 52% of population of working age
_#_Organized labor: 2% of labor force
_#_Population: 4,350,742 (July 1991), growth rate 3.0% (1991)
_#_Birth rate: 36 births/1,000 population (1991)
_#_Death rate: 6 deaths/1,000 population (1991)
_#_Net migration rate: 0 migrants/1,000 population (1991)
_#_Infant mortality rate: 62 deaths/1,000 live births (1991)
_#_Life expectancy at birth: 66 years male, 71 years female (1991)
_#_Total fertility rate: 5.1 children born/woman (1991)
_#_Nationality: noun--Libyan(s); adjective--Libyan
_#_Ethnic divisions: Berber and Arab 97%; some Greeks, Maltese,
Italians, Egyptians, Pakistanis, Turks, Indians, and Tunisians
_#_Religion: Sunni Muslim 97%
_#_Language: Arabic; Italian and English widely understood in major
cities
_#_Literacy: 64% (male 75%, female 50%) age 15 and over can
read and write (1990 est.)
_#_Labor force: 1,000,000, includes about 280,000 resident
foreigners; industry 31%, services 27%, government 24%, agriculture 18%
_#_Organized labor: National Trade Unions'' Federation, 275,000
members; General Union for Oil and Petrochemicals; Pan-Africa Federation
of Petroleum Energy and Allied Workers
_#_Population: 28,476 (July 1991), growth rate 0.6% (1991)
_#_Birth rate: 13 births/1,000 population (1991)
_#_Death rate: 7 deaths/1,000 population (1991)
_#_Net migration rate: 0 migrants/1,000 population (1991)
_#_Infant mortality rate: 5 deaths/1,000 live births (1991)
_#_Life expectancy at birth: 73 years male, 81 years female (1991)
_#_Total fertility rate: 1.5 children born/woman (1991)
_#_Nationality: noun--Liechtensteiner(s); adjective--Liechtenstein
_#_Ethnic divisions: Alemannic 95%, Italian and other 5%
_#_Religion: Roman Catholic 87.3%, Protestant 8.3%, unknown 1.6%,
other 2.8% (1988)
_#_Language: German (official), Alemannic dialect
_#_Literacy: 100% (male 100%, female 100%) age 10 and over can
read and write (1981)
_#_Labor force: 12,258; 5,078 foreign workers (mostly from
Switzerland and Austria); industry, trade, and building 54.4%; services
41.6%; agriculture, fishing, forestry, and horticulture 4.0%
_#_Organized labor: NA
_#_Population: 388,017 (July 1991), growth rate 1.1% (1991)
_#_Birth rate: 12 births/1,000 population (1991)
_#_Death rate: 10 deaths/1,000 population (1991)
_#_Net migration rate: 8 migrants/1,000 population (1991)
_#_Infant mortality rate: 7 deaths/1,000 live births (1991)
_#_Life expectancy at birth: 73 years male, 80 years female (1991)
_#_Total fertility rate: 1.5 children born/woman (1991)
_#_Nationality: noun--Luxembourger(s); adjective--Luxembourg
_#_Ethnic divisions: Celtic base, with French and German blend; also
guest and worker residents from Portugal, Italy, and European countries
_#_Religion: Roman Catholic 97%, Protestant and Jewish 3%
_#_Language: Luxembourgish, German, French; many also speak English
_#_Literacy: 100% (male 100%, female 100%) age 15 and over can
read and write (1980 est.)
_#_Labor force: 169,600; one-third of labor force is foreign workers,
mostly from Portugal, Italy, France, Belgium, and FRG; services 50%,
industry 23.2%, government 14.4%, construction 9%, agriculture 3.4%
(1987)
_#_Organized labor: 100,000 (est.) members of four confederated
trade unions
_#_Population: 2,247,068 (July 1991), growth rate 2.7% (1991)
_#_Birth rate: 34 births/1,000 population (1991)
_#_Death rate: 8 deaths/1,000 population (1991)
_#_Net migration rate: 0 migrants/1,000 population (1991)
_#_Infant mortality rate: 48 deaths/1,000 live births (1991)
_#_Life expectancy at birth: 63 years male, 67 years female (1991)
_#_Total fertility rate: 4.6 children born/woman (1991)
_#_Nationality: noun--Mongolian(s); adjective--Mongolian
_#_Ethnic divisions: Mongol 90%, Kazakh 4%, Chinese 2%, Russian 2%,
other 2%
_#_Religion: predominantly Tibetan Buddhist, Muslim (about 4%),
limited religious activity because of Communist regime
_#_Language: Khalkha Mongol used by over 90% of population; minor
languages include Turkic, Russian, and Chinese
_#_Literacy: 90% (male NA%, female NA%) (1989 est.)
_#_Labor force: NA, but primarily herding/agricultural; over half the
adult population is in the labor force, including a large percentage
of women; shortage of skilled labor
_#_Organized labor: 425,000 members of the Central Council of
Mongolian Trade Unions (CCMTU) controlled by the government (1984)
_#_Population: 12,504 (July 1991), growth rate 1.0% (1991)
_#_Birth rate: 16 births/1,000 population (1991)
_#_Death rate: 10 deaths/1,000 population (1991)
_#_Net migration rate: 4 migrants/1,000 population (1991)
_#_Infant mortality rate: 9 deaths/1,000 live births (1991)
_#_Life expectancy at birth: 74 years male, 80 years female (1991)
_#_Total fertility rate: 2.2 children born/woman (1991)
_#_Nationality: noun--Montserratian(s); adjective--Montserratian
_#_Ethnic divisions: mostly black with a few Europeans
_#_Religion: Anglican, Methodist, Roman Catholic, Pentecostal,
Seventh-Day Adventist, other Christian denominations
_#_Language: English
_#_Literacy: 97% (male 97%, female 97%) age 15 and over having ever
attended school (1970)
_#_Labor force: 5,100; community, social, and personal services 40.5%,
construction 13.5%, trade, restaurants, and hotels 12.3%, manufacturing
10.5%, agriculture, forestry, and fishing 8.8%, other 14.4% (1983 est.)
_#_Organized labor: 30% of labor force, three trade unions with 1,500
members (1984 est.)
_#_Population: 26,181,889 (July 1991), growth rate 2.1% (1991)
_#_Birth rate: 30 births/1,000 population (1991)
_#_Death rate: 8 deaths/1,000 population (1991)
_#_Net migration rate: - 1 migrant/1,000 population (1991)
_#_Infant mortality rate: 76 deaths/1,000 live births (1991)
_#_Life expectancy at birth: 63 years male, 66 years female (1991)
_#_Total fertility rate: 3.8 children born/woman (1991)
_#_Nationality: noun--Moroccan(s); adjective--Moroccan
_#_Ethnic divisions: Arab-Berber 99.1%, non-Moroccan 0.7%, Jewish
0.2%
_#_Religion: Muslim 98.7%, Christian 1.1%, Jewish 0.2%
_#_Language: Arabic (official); several Berber dialects; French is
language of business, government, diplomacy, and postprimary education
_#_Literacy: 50% (male 61%, female 38%) age 15 and over can
read and write (1990 est.)
_#_Labor force: 7,400,000; agriculture 50%, services 26%, industry
15%, other 9% (1985)
_#_Organized labor: about 5% of the labor force, mainly in the Union
of Moroccan Workers (UMT) and the Democratic Confederation of Labor (CDT)
_#_Population: 15,113,282 (July 1991), growth rate 4.6% (1991);
note--900,000 Mozambican refugees in Malawi (1990 est.)
_#_Birth rate: 46 births/1,000 population (1991)
_#_Death rate: 17 deaths/1,000 population (1991)
_#_Net migration rate: 17 migrants/1,000 population (1991)
_#_Infant mortality rate: 134 deaths/1,000 live births (1991)
_#_Life expectancy at birth: 46 years male, 49 years female (1991)
_#_Total fertility rate: 6.4 children born/woman (1991)
_#_Nationality: noun--Mozambican(s); adjective--Mozambican
_#_Ethnic divisions: majority from indigenous tribal groups; Europeans
about 10,000, Euro-Africans 35,000, Indians 15,000
_#_Religion: indigenous beliefs 60%, Christian 30%, Muslim 10%
_#_Language: Portuguese (official); many indigenous dialects
_#_Literacy: 33% (male 45%, female 21%) age 15 and over can
read and write (1990 est.)
_#_Labor force: NA, but 90% engaged in agriculture
_#_Organized labor: 225,000 workers belong to a single union,
the Mozambique Workers'' Organization (OTM)
_#_Population: 1,520,504 (July 1991), growth rate 3.6% (1991)
_#_Birth rate: 45 births/1,000 population (1991)
_#_Death rate: 10 deaths/1,000 population (1991)
_#_Net migration rate: 0 migrants/1,000 population (1991)
_#_Infant mortality rate: 69 deaths/1,000 live births (1991)
_#_Life expectancy at birth: 58 years male, 63 years female (1991)
_#_Total fertility rate: 6.6 children born/woman (1991)
_#_Nationality: noun--Namibian(s); adjective--Namibian
_#_Ethnic divisions: black 86%, white 6.6%, mixed 7.4%; about 50%
of the population belong to the Ovambo tribe and 9% from the Kavangos
tribe
_#_Religion: predominantly Christian
_#_Language: English is official language; Afrikaans is common
language of most of population and about 60% of white population, German
32%, English 7%; several indigenous languages
_#_Literacy: 38% (male 45%, female 31%) age 15 and over can
read and write (1960)
_#_Labor force: 500,000; agriculture 60%, industry and commerce 19%,
services 8%, government 7%, mining 6% (1981 est.)
_#_Organized labor: 20 trade unions representing about 90,000
workers
_#_Population: 9,333 (July 1991), growth rate 1.4% (1991)
_#_Birth rate: 19 births/1,000 population (1991)
_#_Death rate: 5 deaths/1,000 population (1991)
_#_Net migration rate: NEGL migrants/1,000 population (1991)
_#_Infant mortality rate: 41 deaths/1,000 live births (1991)
_#_Life expectancy at birth: 64 years male, 69 years female (1991)
_#_Total fertility rate: 2.1 children born/woman (1991)
_#_Nationality: noun--Nauruan(s); adjective--Nauruan
_#_Ethnic divisions: Nauruan 58%, other Pacific Islander 26%, Chinese
8%, European 8%
_#_Religion: Christian (two-thirds Protestant, one-third Roman
Catholic)
_#_Language: Nauruan, a distinct Pacific Island language (official);
English widely understood, spoken, and used for most government and
commercial purposes
_#_Literacy: NA% (male NA%, female NA%)
_#_Labor force: NA
_#_Organized labor: NA
_#_Population: uninhabited; transient Haitian fishermen and others
camp on the island
_#_Population: 19,611,900 (July 1991), growth rate 2.4% (1991)
_#_Birth rate: 39 births/1,000 population (1991)
_#_Death rate: 15 deaths/1,000 population (1991)
_#_Net migration rate: 0 migrants/1,000 population (1991)
_#_Infant mortality rate: 98 deaths/1,000 live births (1991)
_#_Life expectancy at birth: 51 years male, 50 years female (1991)
_#_Total fertility rate: 5.5 children born/woman (1991)
_#_Nationality: noun--Nepalese (sing. and pl.); adjective--Nepalese
_#_Ethnic divisions: Newars, Indians, Tibetans, Gurungs, Magars,
Tamangs, Bhotias, Rais, Limbus, Sherpas, as well as many smaller groups
_#_Religion: only official Hindu state in world, although no sharp
distinction between many Hindu (about 90% of population) and Buddhist
groups (about 5% of population); Muslims 3%, other 2% (1981)
_#_Language: Nepali (official); 20 languages divided into numerous
dialects
_#_Literacy: 26% (male 38%, female 13%) age 15 and over can
read and write (1990 est.)
_#_Labor force: 4,100,000; agriculture 93%, services 5%, industry 2%;
severe lack of skilled labor
_#_Organized labor: Teachers'' Union and many other nonofficially
recognized unions
_#_Population: 15,022,393 (July 1991), growth rate 0.6% (1991)
_#_Birth rate: 13 births/1,000 population (1991)
_#_Death rate: 8 deaths/1,000 population (1991)
_#_Net migration rate: 1 migrant/1,000 population (1991)
_#_Infant mortality rate: 7 deaths/1,000 live births (1991)
_#_Life expectancy at birth: 74 years male, 81 years female (1991)
_#_Total fertility rate: 1.6 children born/woman (1991)
_#_Nationality: noun--Dutchman(men), Dutchwoman(women);
adjective--Dutch
_#_Ethnic divisions: Dutch 96%, Moroccans, Turks, and other 4% (1988)
_#_Religion: Roman Catholic 36%, Protestant 27%, other 6%,
unaffiliated 31% (1988)
_#_Language: Dutch
_#_Literacy: 99% (male NA%, female NA%) age 15 and over can
read and write (1979 est.)
_#_Labor force: 5,300,000; services 50.1%, manufacturing and
construction 28.2%, government 15.9%, agriculture 5.8% (1986)
_#_Organized labor: 29% of labor force
_#_Population: 183,872 (July 1991), growth rate 0.2% (1991)
_#_Birth rate: 18 births/1,000 population (1991)
_#_Death rate: 5 deaths/1,000 population (1991)
_#_Net migration rate: - 10 migrants/1,000 population (1991)
_#_Infant mortality rate: 8 deaths/1,000 live births (1991)
_#_Life expectancy at birth: 74 years male, 79 years female (1991)
_#_Total fertility rate: 2.0 children born/woman (1991)
_#_Nationality: noun--Netherlands Antillean(s); adjective--Netherlands
Antillean
_#_Ethnic divisions: mixed African 85%; remainder Carib Indian,
European, Latin, and Oriental
_#_Religion: predominantly Roman Catholic; Protestant, Jewish,
Seventh-Day Adventist
_#_Language: Dutch (official); Papiamento, a
Spanish-Portuguese-Dutch-English dialect predominates; English widely
spoken; Spanish
_#_Literacy: 94% (male 94%, female 93%) age 15 and over can
read and write (1981)
_#_Labor force: 89,000; government 65%, industry and commerce 28%
(1983)
_#_Organized labor: 60-70% of labor force
_#_Population: 171,559 (July 1991), growth rate 1.9% (1991)
_#_Birth rate: 23 births/1,000 population (1991)
_#_Death rate: 5 deaths/1,000 population (1991)
_#_Net migration rate: 1 migrant/1,000 population (1991)
_#_Infant mortality rate: 17 deaths/1,000 live births (1991)
_#_Life expectancy at birth: 69 years male, 76 years female (1991)
_#_Total fertility rate: 2.8 children born/woman (1991)
_#_Nationality: noun--New Caledonian(s); adjective--New Caledonian
_#_Ethnic divisions: Melanesian 42.5%, European 37.1%, Wallisian 8.4%,
Polynesian 3.8%, Indonesian 3.6%, Vietnamese 1.6%, other 3.0%
_#_Religion: Roman Catholic 60%, Protestant 30%, other 10%
_#_Language: French; 28 Melanesian-Polynesian dialects
_#_Literacy: 91% (male 91%, female 90%) age 15 and over can
read and write (1976)
_#_Labor force: 50,469; foreign workers for plantations and mines from
Wallis and Futuna, Vanuatu, and French Polynesia (1980 est.)
_#_Organized labor: NA
_#_Population: 3,308,973 (July 1991), gr','1cccfa4bf0b5c70e3a081f478da4ae7bb0ded9f15d8aa082f5de4e3ae418758f','internet-archive','theciaworldfactb00025gut','txt','84185fe9df79da427349cc1598fd3f69814a2085a9fc1fe0508a3fae0a870f84','https://archive.org/download/theciaworldfactb00025gut/25.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1341e37349357c6ca8d2a8929c366ae15c2c918b81791925b13d5a789f08e277',1991,'FR','France','people-and-society',99,'owth rate 0.4% (1991)
_#_Birth rate: 15 births/1,000 population (1991)
_#_Death rate: 8 deaths/1,000 population (1991)
_#_Net migration rate: - 3 migrants/1,000 population (1991)
_#_Infant mortality rate: 10 deaths/1,000 live births (1991)
_#_Life expectancy at birth: 72 years male, 79 years female (1991)
_#_Total fertility rate: 1.9 children born/woman (1991)
_#_Nationality: noun--New Zealander(s); adjective--New Zealand
_#_Ethnic divisions: European 88%, Maori 8.9%, Pacific Islander
2.9%, other 0.2%
_#_Religion: Anglican 24%, Presbyterian 18%, Roman Catholic 15%,
Methodist 5%, Baptist 2%, other Protestant 3%, unspecified or none
9% (1986)
_#_Language: English (official), Maori
_#_Literacy: 99% (male NA%, female NA%) age 15 and over can
read and write (1970)
_#_Labor force: 1,591,900; services 67.4%, manufacturing 19.8%,
primary production 9.3% (1987)
_#_Organized labor: 681,000 members; 43% of labor force (1986)
_#_Population: 3,751,884 (July 1991), growth rate 2.8% (1991)
_#_Birth rate: 37 births/1,000 population (1991)
_#_Death rate: 7 deaths/1,000 population (1991)
_#_Net migration rate: - 1 migrant/1,000 population (1991)
_#_Infant mortality rate: 60 deaths/1,000 live births (1991)
_#_Life expectancy at birth: 60 years male, 65 years female (1991)
_#_Total fertility rate: 4.7 children born/woman (1991)
_#_Nationality: noun--Nicaraguan(s); adjective--Nicaraguan
_#_Ethnic divisions: mestizo 69%, white 17%, black 9%, Indian 5%
_#_Religion: Roman Catholic 95%, Protestant 5%
_#_Language: Spanish (official); English- and Indian-speaking
minorities on Atlantic coast
_#_Literacy: 57% (male 57%, female 57%) age 15 and over can
read and write (1971)
_#_Labor force: 1,086,000; service 43%, agriculture 44%, industry 13%
(1986)
_#_Organized labor: 35% of labor force
_#_Population: 8,154,145 (July 1991), growth rate 3.4% (1991)
_#_Birth rate: 50 births/1,000 population (1991)
_#_Death rate: 16 deaths/1,000 population (1991)
_#_Net migration rate: 0 migrants/1,000 population (1991)
_#_Infant mortality rate: 129 deaths/1,000 live births (1991)
_#_Life expectancy at birth: 49 years male, 53 years female (1991)
_#_Total fertility rate: 7.0 children born/woman (1991)
_#_Nationality: noun--Nigerien(s) adjective--Nigerien
_#_Ethnic divisions: Hausa 56%; Djerma 22%; Fula 8.5%; Tuareg 8%; Beri
Beri (Kanouri) 4.3%; Arab, Toubou, and Gourmantche 1.2%; about 4,000
French expatriates
_#_Religion: Muslim 80%, remainder indigenous beliefs and Christians
_#_Language: French (official); Hausa, Djerma
_#_Literacy: 28% (male 40%, female 17%) age 15 and over can
read and write (1990 est.)
_#_Labor force: 2,500,000 wage earners (1982); agriculture 90%,
industry and commerce 6%, government 4%; 51% of population of working age
(1985)
_#_Organized labor: negligible
_#_Population: 122,470,574 (July 1991), growth rate 3.0% (1991)
_#_Birth rate: 46 births/1,000 population (1991)
_#_Death rate: 16 deaths/1,000 population (1991)
_#_Net migration rate: NEGL migrants/1,000 population (1991)
_#_Infant mortality rate: 118 deaths/1,000 live births (1991)
_#_Life expectancy at birth: 48 years male, 50 years female (1991)
_#_Total fertility rate: 6.5 children born/woman (1991)
_#_Nationality: noun--Nigerian(s); adjective--Nigerian
_#_Ethnic divisions: more than 250 tribal groups; Hausa and Fulani
of the north, Yoruba of the southwest, and Ibos of the southeast make
up 65% of the population; about 27,000 non-Africans
_#_Religion: Muslim 50%, Christian 40%, indigenous beliefs 10%
_#_Language: English (official); Hausa, Yoruba, Ibo, Fulani, and
several other languages also widely used
_#_Literacy: 51% (male 62%, female 40%) age 15 and over can
read and write (1990 est.)
_#_Labor force: 42,844,000; agriculture 54%, industry, commerce, and
services 19%, government 15%; 49% of population of working age (1985)
_#_Organized labor: 3,520,000 wage earners belong to 42 recognized
trade unions, which come under a single national labor federation--the
Nigerian Labor Congress (NLC)
_#_Population: 1,908 (July 1991), growth rate - 0.1% (1991)
_#_Birth rate: NA births/1,000 population (1991)
_#_Death rate: NA deaths/1,000 population (1991)
_#_Net migration rate: NA migrants/1,000 population (1991)
_#_Infant mortality rate: NA deaths/1,000 live births (1991)
_#_Life expectancy at birth: NA years male, NA years female (1991)
_#_Total fertility rate: NA children born/woman (1991)
_#_Nationality: noun--Niuean(s); adjective--Niuean
_#_Ethnic divisions: Polynesian, with some 200 Europeans, Samoans, and
Tongans
_#_Religion: Ekalesia Nieue (Niuean Church)--a Protestant church
closely related to the London Missionary Society 75%, Mormon 10%,
Roman Catholic, Jehovah''s Witnesses, Seventh-Day Adventist 5%
_#_Language: Polynesian tongue closely related to Tongan and Samoan;
English
_#_Literacy: NA% (male NA%, female NA%) but compulsory education
age 5 to 14
_#_Labor force: 1,000 (1981 est.); most work on family plantations;
paid work exists only in government service, small industry, and the Niue
Development Board
_#_Organized labor: NA
_#_Population: 2,576 (July 1991), growth rate NEGL% (1991)
_#_Birth rate: NA births/1,000 population (1991)
_#_Death rate: NA deaths/1,000 population (1991)
_#_Net migration rate: NA migrants/1,000 population (1991)
_#_Infant mortality rate: NA deaths/1,000 live births (1991)
_#_Life expectancy at birth: NA years male, NA years female (1991)
_#_Total fertility rate: NA children born/woman (1991)
_#_Nationality: noun--Norfolk Islander(s);
adjective--Norfolk Islander(s)
_#_Ethnic divisions: descendants of the Bounty mutiny; more recently,
Australian and New Zealand settlers
_#_Religion: Anglican 39%, Roman Catholic 11.7%, Uniting Church in
Australia 16.4%, Seventh-Day Adventist 4.4%, none 9.2%, unknown 16.9%,
other 2.4% (1986)
_#_Language: English (official) and Norfolk--a mixture of 18th century
English and ancient Tahitian
_#_Literacy: NA% (male NA%, female NA%)
_#_Labor force: NA
_#_Organized labor: NA
_#_Population: 23,494 (July 1991), growth rate 3.4% (1991)
_#_Birth rate: 43 births/1,000 population (1991)
_#_Death rate: 6 deaths/1,000 population (1991)
_#_Net migration rate: - 3 migrants/1,000 population (1991)
_#_Infant mortality rate: 17 deaths/1,000 live births (1991)
_#_Life expectancy at birth: 65 years male, 70 years female (1991)
_#_Total fertility rate: 5.8 children born/woman (1991)
_#_Nationality: undetermined
_#_Ethnic divisions: Chamorro majority; Carolinians and other
Micronesians; Spanish, German, Japanese admixtures
_#_Religion: Christian with a Roman Catholic majority, although
traditional beliefs and taboos may still be found
_#_Language: English, but Chamorro and Carolinian are also spoken in
the home and taught in school
_#_Literacy: 96% (male 97%, female 96%) age 15 and over can
read and write (1980)
_#_Labor force: 12,788 local; 18,799 foreign workers (1990 est.)
_#_Organized labor: NA
_#_Population: 4,273,442 (July 1991), growth rate 0.5% (1991)
_#_Birth rate: 14 births/1,000 population (1991)
_#_Death rate: 11 deaths/1,000 population (1991)
_#_Net migration rate: 2 migrants/1,000 population (1991)
_#_Infant mortality rate: 7 deaths/1,000 live births (1991)
_#_Life expectancy at birth: 74 years male, 81 years female (1991)
_#_Total fertility rate: 1.8 children born/woman (1991)
_#_Nationality: noun--Norwegian(s); adjective--Norwegian
_#_Ethnic divisions: Germanic (Nordic, Alpine, Baltic) and
racial-cultural minority of 20,000 Lapps
_#_Religion: Evangelical Lutheran (state church) 87.8%, other
Protestant and Roman Catholic 3.8%, none 3.2%, unknown 5.2% (1980)
_#_Language: Norwegian (official); small Lapp- and Finnish-speaking
minorities
_#_Literacy: 99% (male NA%, female NA%) age 15 and over can
read and write (1976 est.)
_#_Labor force: 2,167,000 (September 1990); services 34.7%, commerce
18%, mining and manufacturing 16.6%, banking and financial services 7.5%,
transportation and communications 7.2%, construction 7.2%,
agriculture, forestry, and fishing 6.4% (1989)
_#_Organized labor: 66% of labor force (1985)
_#_Population: 1,534,011 (July 1991), growth rate 3.5% (1991)
_#_Birth rate: 41 births/1,000 population (1991)
_#_Death rate: 6 deaths/1,000 population (1991)
_#_Net migration rate: 0 migrants/1,000 population (1991)
_#_Infant mortality rate: 40 deaths/1,000 live births (1991)
_#_Life expectancy at birth: 65 years male, 68 years female (1991)
_#_Total fertility rate: 6.7 children born/woman (1991)
_#_Nationality: noun--Omani(s); adjective--Omani
_#_Ethnic divisions: mostly Arab, with small Balochi,
Zanzibari, and South Asian (Indian, Pakistani, Bangladeshi) groups
_#_Religion: Ibadhi Muslim 75%; remainder Sunni Muslim, Shia
Muslim, some Hindu
_#_Language: Arabic (official); English, Balochi, Urdu, Indian
dialects
_#_Literacy: NA% (male NA%, female NA%)
_#_Labor force: 430,000; agriculture (est.) 60%; 58% are non-Omani
_#_Organized labor: trade unions are illegal
_#_Population: 14,411 (July 1991), growth rate 0.7% (1991)
_#_Birth rate: 25 births/1,000 population (1991)
_#_Death rate: 6 deaths/1,000 population (1991)
_#_Net migration rate: - 12 migrants/1,000 population (1991)
_#_Infant mortality rate: 26 deaths/1,000 live births (1991)
_#_Life expectancy at birth: 68 years male, 74 years female (1991)
_#_Total fertility rate: 3.3 children born/woman (1991)
_#_Nationality: noun--Palauan(s); adjective--Palauan
_#_Ethnic divisions: Palauans are a composite of Polynesian, Malayan,
and Melanesian races
_#_Religion: predominantly Christian, mainly Roman Catholic
_#_Language: Palauan is the official language, though English is
commonplace; inhabitants of the isolated southwestern islands speak a
dialect of Trukese
_#_Literacy: 92% (male 93%, female 91%) age 15 and over can
read and write (1980)
_#_Labor force: NA
_#_Organized labor: NA
_#_Population: 117,490,278 (July 1991), growth rate 2.5% (1991)
_#_Birth rate: 43 births/1,000 population (1991)
_#_Death rate: 13 deaths/1,000 population (1991)
_#_Net migration rate: - 5 migrants/1,000 population (1991)
_#_Infant mortality rate: 109 deaths/1,000 live births (1991)
_#_Life expectancy at birth: 56 years male, 57 years female (1991)
_#_Total fertility rate: 6.6 children born/woman (1991)
_#_Nationality: noun--Pakistani(s); adjective--Pakistani
_#_Ethnic divisions: Punjabi, Sindhi, Pashtun (Pathan), Baloch,
Muhajir (immigrants from India and their descendents)
_#_Religion: Muslim 97% (Sunni 77%, Shia 20%), Christian, Hindu, and
other 3%
_#_Language: Urdu and English (both official); total spoken
languages--Punjabi 64%, Sindhi 12%, Pashtu 8%, Urdu 7%, Balochi and other
9%; English is lingua franca of Pakistani elite and most government
ministries, but official policies are promoting its gradual replacement
by Urdu
_#_Literacy: 35% (male 47%, female 21%) age 15 and over can
read and write (1990 est.)
_#_Labor force: 28,900,000; agriculture 54%, mining and manufacturing
13%, services 33%; extensive export of labor (1987 est.)
_#_Organized labor: about 10% of industrial work force
_#_Population: uninhabited
_#_Population: 2,476,281 (July 1991), growth rate 2.1% (1991)
_#_Birth rate: 26 births/1,000 population (1991)
_#_Death rate: 5 deaths/1,000 population (1991)
_#_Net migration rate: NEGL migrants/1,000 population (1991)
_#_Infant mortality rate: 21 deaths/1,000 live births (1991)
_#_Life expectancy at birth: 72 years male, 76 years female (1991)
_#_Total fertility rate: 3.0 children born/woman (1991)
_#_Nationality: noun--Panamanian(s); adjective--Panamanian
_#_Ethnic divisions: mestizo (mixed Indian and European ancestry) 70%,
West Indian 14%, white 10%, Indian 6%
_#_Religion: Roman Catholic over 93%, Protestant 6%
_#_Language: Spanish (official); English as native tongue 14%;
many Panamanians bilingual
_#_Literacy: 88% (male 88%, female 88%) age 15 and over can
read and write (1990 est.)
_#_Labor force: 770,472 (1987); government and community services
27.9%; agriculture, hunting, and fishing 26.2%; commerce, restaurants,
and hotels 16%; manufacturing and mining 10.5%; construction 5.3%;
transportation and communications 5.3%; finance, insurance, and real
estate 4.2%; Canal Zone 2.4%; shortage of skilled labor, but an
oversupply of unskilled labor
_#_Organized labor: 17% of labor force (1986)
_#_Population: 3,913,186 (July 1991), growth rate 2.3% (1991)
_#_Birth rate: 34 births/1,000 population (1991)
_#_Death rate: 11 deaths/1,000 population (1991)
_#_Net migration rate: 0 migrants/1,000 population (1991)
_#_Infant mortality rate: 66 deaths/1,000 live births (1991)
_#_Life expectancy at birth: 55 years male, 56 years female (1991)
_#_Total fertility rate: 4.9 children born/woman (1991)
_#_Nationality: noun--Papua New Guinean(s); adjective--Papua New
Guinean
_#_Ethnic divisions: predominantly Melanesian and Papuan; some
Negrito, Micronesian, and Polynesian
_#_Religion: Roman Catholic 22%, Lutheran 16%,
Presbyterian/Methodist/London Missionary Society 8%, Anglican 5%,
Evangelical Alliance 4%, Seventh-Day Adventist 1%, other Protestant sects
10%; indigenous beliefs 34%
_#_Language: 715 indigenous languages; English spoken by 1-2%, pidgin
English widespread, Motu spoken in Papua region
_#_Literacy: 52% (male 65%, female 38%) age 15 and over can
read and write (1990 est.)
_#_Labor force: 1,660,000; 732,806 in salaried employment; agriculture
54%, government 25%, industry and commerce 9%, services 8% (1980)
_#_Organized labor: more than 50 trade unions, some with fewer than 20
members
_#_Population: no permanent inhabitants
_#_Population: 4,798,739 (July 1991), growth rate 2.9% (1991)
_#_Birth rate: 35 births/1,000 population (1991)
_#_Death rate: 6 deaths/1,000 population (1991)
_#_Net migration rate: 0 migrants/1,000 population (1991)
_#_Infant mortality rate: 47 deaths/1,000 live births (1991)
_#_Life expectancy at birth: 67 years male, 72 years female (1991)
_#_Total fertility rate: 4.7 children born/woman (1991)
_#_Nationality: noun--Paraguayan(s); adjective--Paraguayan
_#_Ethnic divisions: mestizo (Spanish and Indian) 95%, white and
Indian 5%
_#_Religion: Roman Catholic 90%; Mennonite and other Protestant
denominations
_#_Language: Spanish (official) and Guarani
_#_Literacy: 90% (male 92%, female 88%) age 15 and over can
read and write (1990 est.)
_#_Labor force: 1,300,000; agriculture 44%, industry and commerce
34%, services 18%, government 4% (1986)
_#_Organized labor: about 2% of labor force
_#_Population: 22,361,785 (July 1991), growth rate 2.0% (1991)
_#_Birth rate: 28 births/1,000 population (1991)
_#_Death rate: 8 deaths/1,000 population (1991)
_#_Net migration rate: 0 migrants/1,000 population (1991)
_#_Infant mortality rate: 66 deaths/1,000 live births (1991)
_#_Life expectancy at birth: 62 years male, 67 years female (1991)
_#_Total fertility rate: 3.5 children born/woman (1991)
_#_Nationality: noun--Peruvian(s); adjective--Peruvian
_#_Ethnic divisions: Indian 45%; mestizo (mixed Indian and European
ancestry) 37%; white 15%; black, Japanese, Chinese, and other 3%
_#_Religion: predominantly Roman Catholic
_#_Language: Spanish and Quechua (both official), Aymara
_#_Literacy: 85% (male 92%, female 29%) age 15 and over can
read and write (1990 est.)
_#_Labor force: 6,800,000 (1986); government and other services 44%,
agriculture 37%, industry 19% (1988 est.)
_#_Organized labor: about 40% of salaried workers (1983 est.)
_#_Population: 65,758,788 (July 1991), growth rate 2.1% (1991)
_#_Birth rate: 29 births/1,000 population (1991)
_#_Death rate: 7 deaths/1,000 population (1991)
_#_Net migration rate: - 1 migrant/1,000 population (1991)
_#_Infant mortality rate: 54 deaths/1,000 live births (1991)
_#_Life expectancy at birth: 62 years male, 67 years female (1991)
_#_Total fertility rate: 3.6 children born/woman (1991)
_#_Nationality: noun--Filipino(s); adjective--Philippine
_#_Ethnic divisions: Christian Malay 91.5%, Muslim Malay 4%, Chinese
1.5%, other 3%
_#_Religion: Roman Catholic 83%, Protestant 9%, Muslim 5%,
Buddhist and other 3%
_#_Language: Pilipino (based on Tagalog) and English; both official
_#_Literacy: 90% (male 90%, female 90%) age 15 and over can
read and write (1990 est.)
_#_Labor force: 24,120,000; agriculture 46%, industry and commerce
16%, services 18.5%, government 10%, other 9.5% (1989)
_#_Organized labor: 3,945 registered unions; total membership
5.7 million (includes 2.8 million members of the National Congress of
Farmers Organizations)
_#_Population: 56 (July 1991), growth rate 0.0% (1991)
_#_Birth rate: NA births/1,000 population (1991)
_#_Death rate: NA deaths/1,000 population (1991)
_#_Net migration rate: NA migrants/1,000 population (1991)
_#_Infant mortality rate: NA deaths/1,000 live births (1991)
_#_Life expectancy at birth: NA years male, NA years female (1991)
_#_Total fertility rate: NA children born/woman (1991)
_#_Nationality: noun--Pitcairn Islander(s); adjective--Pitcairn
Islander
_#_Ethnic divisions: descendants of Bounty mutineers
_#_Religion: Seventh-Day Adventist 100%
_#_Language: English (official); also a Tahitian/English dialect
_#_Literacy: NA% (male NA%, female NA%)
_#_Labor force: NA; no business community in the usual sense; some
public works; subsistence farming and fishing
_#_Organized labor: NA
_#_Population: 37,799,638 (July 1991), growth rate 0.1% (1991)
_#_Birth rate: 14 births/1,000 population (1991)
_#_Death rate: 9 deaths/1,000 population (1991)
_#_Net migration rate: - 4 migrants/1,000 population (1991)
_#_Infant mortality rate: 12 deaths/1,000 live births (1991)
_#_Life expectancy at birth: 69 years male, 77 years female (1991)
_#_Total fertility rate: 2.1 children born/woman (1991)
_#_Nationality: noun--Pole(s); adjective--Polish
_#_Ethnic divisions: Polish 97.6%, German 1.3%, Ukrainian 0.6%,
Belorussian (Byelorussian) 0.5% (1990 est.)
_#_Religion: Roman Catholic 95% (about 75% practicing),
Russian Orthodox, Protestant, and other 5%
_#_Language: Polish
_#_Literacy: 98% (male 99%, female 98%) age 15 and over can
read and write (1978)
_#_Labor force: 17,104,000; industry and construction 36.1%;
agriculture 27.3%; trade, transport, and communications 14.8%; government
and other 21.8% (1989)
_#_Organized labor: trade union pluralism
_#_Population: 10,387,617 (July 1991), growth rate 0.3% (1991)
_#_Birth rate: 12 births/1,000 population (1991)
_#_Death rate: 10 deaths/1,000 population (1991)
_#_Net migration rate: 1 migrant/1,000 population (1991)
_#_Infant mortality rate: 13 deaths/1,000 live births (1991)
_#_Life expectancy at birth: 71 years male, 78 years female (1991)
_#_Total fertility rate: 1.5 children born/woman (1991)
_#_Nationality: noun--Portuguese (sing. and pl.);
adjective--Portuguese
_#_Ethnic divisions: homogeneous Mediterranean stock in mainland,
Azores, Madeira Islands; citizens of black African descent who immigrated
to mainland during decolonization number less than 100,000
_#_Religion: Roman Catholic 97%, Protestant denominations 1%,
other 2%
_#_Language: Portuguese
_#_Literacy: 85% (male 89%, female 82%) age 15 and over can
read and write (1990 est.)
_#_Labor force: 4,605,700; services 45%, industry 35%, agriculture
20% (1988)
_#_Organized labor: about 55% of the labor force; the
Communist-dominated General Confederation of Portuguese
Workers--Intersindical (CGTP-IN) represents more than half of the
unionized labor force; its main competition, the General Workers Union
(UGT), is organized by the Socialists and Social Democrats and represents
less than half of unionized labor
_#_Population: 3,294,997 (July 1991), growth rate 0.1% (1991)
_#_Birth rate: 19 births/1,000 population (1991)
_#_Death rate: 8 deaths/1,000 population (1991)
_#_Net migration rate: - 10 migrants/1,000 population (1991)
_#_Infant mortality rate: 16 deaths/1,000 live births (1991)
_#_Life expectancy at birth: 69 years male, 76 years female (1991)
_#_Total fertility rate: 2.1 children born/woman (1991)
_#_Nationality: noun--Puerto Rican(s); adjective--Puerto Rican
_#_Ethnic divisions: almost entirely Hispanic
_#_Religion: Roman Catholic 85%, Protestant denominations and other
15%
_#_Language: Spanish (official); English is widely understood
_#_Literacy: 89% (male 90%, female 88%) age 15 and over can
read and write (1980)
_#_Labor force: 1,068,000; government 28%, manufacturing 15%,
trade 14%, agriculture 3%, other 40% (1990)
_#_Organized labor: 115,000 members in 4 unions; the largest is the
General Confederation of Puerto Rican Workers with 35,000 members (1983)
_#_Population: 518,478 (July 1991), growth rate 5.3% (1991)
_#_Birth rate: 21 births/1,000 population (1991)
_#_Death rate: 3 deaths/1,000 population (1991)
_#_Net migration rate: 35 migrants/1,000 population (1991)
_#_Infant mortality rate: 24 deaths/1,000 live births (1991)
_#_Life expectancy at birth: 69 years male, 74 years female (1991)
_#_Total fertility rate: 4.0 children born/woman (1991)
_#_Nationality: noun--Qatari(s); adjective--Qatari
_#_Ethnic divisions: Arab 40%, Pakistani 18%, Indian 18%, Iranian 10%,
other 14%
_#_Religion: Muslim 95%
_#_Language: Arabic (official); English is commonly used as second
language
_#_Literacy: 76% (male 77%, female 72%) age 15 and over can
read and write (1986)
_#_Labor force: 104,000; 85% non-Qatari in private sector (1983)
_#_Organized labor: trade unions are illegal
_#_Population: 607,086 (July 1991), growth rate 1.9% (1991)
_#_Birth rate: 24 births/1,000 population (1991)
_#_Death rate: 5 deaths/1,000 population (1991)
_#_Net migration rate: 0 migrants/1,000 population (1991)
_#_Infant mortality rate: 8 deaths/1,000 live births (1991)
_#_Life expectancy at birth: 70 years male, 76 years female (1991)
_#_Total fertility rate: 2.6 children born/woman (1991)
_#_Nationality: noun--Reunionese (sing. and pl.);
adjective--Reunionese
_#_Ethnic divisions: most of the population is of intermixed French,
African, Malagasy, Chinese, Pakistani, and Indian ancestry
_#_Religion: Roman Catholic 94%
_#_Language: French (official); Creole widely used
_#_Literacy: 69% (male 67%, female 74%) age 15 and over can
read and write (1982)
_#_Labor force: NA; agriculture 30%, industry 21%, services 49%
(1981); 63% of population of working age (1983)
_#_Organized labor: General Confederation of Workers of Reunion (CGTR)
_#_Population: 23,397,054 (July 1991), growth rate 0.5% (1991)
_#_Birth rate: 16 births/1,000 population (1991)
_#_Death rate: 10 deaths/1,000 population (1991)
_#_Net migration rate: - 1 migrant/1,000 population (1991)
_#_Infant mortality rate: 18 deaths/1,000 live births (1991)
_#_Life expectancy at birth: 69 years male, 75 years female (1991)
_#_Total fertility rate: 2.1 children born/woman (1991)
_#_Nationality: noun--Romanian(s); adjective--Romanian
_#_Ethnic divisions: Romanian 89.1%; Hungarian 8.9%; German 0.4%;
Ukrainian, Serb, Croat, Russian, Turk, and Gypsy 1.6%
_#_Religion: Romanian Orthodox 70%, Roman Catholic 6%, Greek Catholic
(Uniate) 3%, Protestant 6%, unaffiliated 15%
_#_Language: Romanian, Hungarian, German
_#_Literacy: 96% (male NA%, female NA%) age 15 and over can
read and write (1970 est.)
_#_Labor force: 10,690,000; industry 34%, agriculture 28%, other 38%
(1987)
_#_Organized labor: until December 1989, a single trade union system
organized by the General Confederation of Romanian Trade Unions (UGSR)
under control of the Communist Party; since Ceausescu''s overthrow,
newly-created trade and professional trade unions are joining three
umbrella organizations--Organization of Free Trade Unions, Fratia
(Brotherhood), and the Alfa Cortel; many other trade unions have been
formed
_#_Population: 7,902,644 (July 1991), growth rate 3.8% (1991)
_#_Birth rate: 52 births/1,000 population (1991)
_#_Death rate: 15 deaths/1,000 population (1991)
_#_Net migration rate: 0 migrants/1,000 population (1991)
_#_Infant mortality rate: 110 deaths/1,000 live births (1991)
_#_Life expectancy at birth: 51 years male, 54 years female (1991)
_#_Total fertility rate: 8.4 children born/woman (1991)
_#_Nationality: noun and adjective--Rwandan(s)
_#_Ethnic divisions: Hutu','e2238f504a7fe1ce66061d5cbe261c3516624e0669ff6e2f17cbc7ebee34b0c6','internet-archive','theciaworldfactb00025gut','txt','84185fe9df79da427349cc1598fd3f69814a2085a9fc1fe0508a3fae0a870f84','https://archive.org/download/theciaworldfactb00025gut/25.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d853226eacf4adbb5a69c508c58c220154ba0243c42d23e0356c9e65c316e3b3',1991,'FR','France','people-and-society',100,'90%, Tutsi 9%, Twa (Pygmoid) 1%
_#_Religion: Roman Catholic 65%, Protestant 9%, Muslim 1%,
indigenous beliefs and other 25%
_#_Language: Kinyarwanda, French (official); Kiswahili used in
commercial centers
_#_Literacy: 50% (male 64%, female 37%) age 15 and over can
read and write (1990 est.)
_#_Labor force: 3,600,000; agriculture 93%, government and services
5%, industry and commerce 2%; 49% of population of working age (1985)
_#_Organized labor: NA
_#_Population: 6,695 (July 1991), growth rate 0.6% (1991)
_#_Birth rate: 13 births/1,000 population (1991)
_#_Death rate: 8 deaths/1,000 population (1991)
_#_Net migration rate: NEGl migrants/1,000 population (1991)
_#_Infant mortality rate: 46 deaths/1,000 live births (1991)
_#_Life expectancy at birth: 70 years male, 75 years female (1991)
_#_Total fertility rate: 1.4 children born/woman (1991)
_#_Nationality: noun--Saint Helenian(s); adjective--Saint Helenian
_#_Ethnic divisions: NA
_#_Religion: Anglican majority; also Baptist, Seventh-Day Adventist,
and Roman Catholic
_#_Language: English
_#_Literacy: 98% (male 97%, female 98%) age 15 and over can
read and write (1987)
_#_Labor force: NA
_#_Organized labor: Saint Helena General Workers'' Union, 472 members;
crafts 17%, professional and technical 10%, service 10%, management and
clerical 9%, farming and fishing 9%, transport 6%, sales 5%, and other
34%
_#_Population: 40,293 (July 1991), growth rate 0.4% (1991)
_#_Birth rate: 24 births/1,000 population (1991)
_#_Death rate: 10 deaths/1,000 population (1991)
_#_Net migration rate: - 10 migrants/1,000 population (1991)
_#_Infant mortality rate: 39 deaths/1,000 live births (1991)
_#_Life expectancy at birth: 64 years male, 71 years female (1991)
_#_Total fertility rate: 2.6 children born/woman (1991)
_#_Ethnic divisions: mainly of black African descent
_#_Nationality: noun--Kittsian(s), Nevisian(s); adjective--Kittsian,
Nevisian
_#_Religion: Anglican, other Protestant sects, Roman Catholic
_#_Language: English
_#_Literacy: 98% (male 98%, female 98%) age 15 and over having ever
attended school (1970)
_#_Labor force: 20,000 (1981)
_#_Organized labor: 6,700
_#_Population: 153,075 (July 1991), growth rate 2.2% (1991)
_#_Birth rate: 31 births/1,000 population (1991)
_#_Death rate: 5 deaths/1,000 population (1991)
_#_Net migration rate: - 4 migrants/1,000 population (1991)
_#_Infant mortality rate: 18 deaths/1,000 live births (1991)
_#_Life expectancy at birth: 69 years male, 74 years female (1991)
_#_Total fertility rate: 3.5 children born/woman (1991)
_#_Nationality: noun--Saint Lucian(s); adjective--Saint Lucian
_#_Ethnic divisions: African descent 90.3%, mixed 5.5%, East Indian
3.2%, Caucasian 0.8%
_#_Religion: Roman Catholic 90%, Protestant 7%, Anglican 3%
_#_Language: English (official), French patois
_#_Literacy: 67% (male 65%, female 69%) age 15 and over having ever
attended school (1980)
_#_Labor force: 43,800; agriculture 43.4%, services 38.9%, industry
and commerce 17.7% (1983 est.)
_#_Organized labor: 20% of labor force
_#_Population: 6,356 (July 1991), growth rate 0.4% (1991)
_#_Birth rate: 17 births/1,000 population (1991)
_#_Death rate: 7 deaths/1,000 population (1991)
_#_Net migration rate: - 6 migrants/1,000 population (1991)
_#_Infant mortality rate: 9 deaths/1,000 live births (1991)
_#_Life expectancy at birth: 72 years male, 79 years female (1991)
_#_Total fertility rate: 2.2 children born/woman (1991)
_#_Nationality: noun--Frenchman(men), Frenchwoman(women);
adjective--French
_#_Ethnic divisions: originally Basques and Bretons (French fishermen)
_#_Religion: Roman Catholic 98%
_#_Language: French
_#_Literacy: 99% (male 99%, female 99%) age 15 and over can
read and write (1982)
_#_Labor force: 2,850 (1988)
_#_Organized labor: Workers'' Force trade union','787e4b0420c45c78bdfb17623091d2cfdc59d3806312acb5170eaf9150fd9c7c','internet-archive','theciaworldfactb00025gut','txt','84185fe9df79da427349cc1598fd3f69814a2085a9fc1fe0508a3fae0a870f84','https://archive.org/download/theciaworldfactb00025gut/25.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('84464f52f8cd1d673b505f550d92a30251e32f9c26d6456fe70ff6b638a44baa',1991,'CN','China','people-and-society',110,'_#_Population: 446,262 (July 1991), growth rate 1.0% (1991)
_#_Birth rate: 15 births/1,000 population (1991)
_#_Death rate: 5 deaths/1,000 population (1991)
_#_Net migration rate: 0 migrants/1,000 population (1991)
_#_Infant mortality rate: 7 deaths/1,000 live births (1991)
_#_Life expectancy at birth: 75 years male, 79 years female (1991)
_#_Total fertility rate: 2.1 children born/woman (1991)
_#_Nationality: noun--Macanese (sing. and pl.); adjective--Macau
_#_Ethnic divisions: Chinese 95%, Portuguese 3%, other 2%
_#_Religion: Buddhist 45%, Roman Catholic 7%, Protestant 1%, none
45.8%, other 1.2% (1981)
_#_Language: Portuguese (official); Cantonese is the language of
commerce
_#_Literacy: 90% (male 93%, female 86%) age 15 and over can
read and write (1981)
_#_Labor force: 180,000 (1986)
_#_Organized labor: none
_#_Population: 12,185,318 (July 1991), growth rate 3.2% (1991)
_#_Birth rate: 47 births/1,000 population (1991)
_#_Death rate: 15 deaths/1,000 population (1991)
_#_Net migration rate: 0 migrants/1,000 population (1991)
_#_Infant mortality rate: 95 deaths/1,000 live births (1991)
_#_Life expectancy at birth: 51 years male, 54 years female (1991)
_#_Total fertility rate: 6.9 children born/woman (1991)
_#_Nationality: noun--Malagasy (sing. and pl.); adjective--Malagasy
_#_Ethnic divisions: basic split between highlanders of predominantly
Malayo-Indonesian origin (Merina 1,643,000 and related Betsileo 760,000)
on the one hand and coastal tribes, collectively termed the Cotiers,
with mixed African, Malayo-Indonesian, and Arab ancestry (Betsimisaraka
941,000, Tsimihety 442,000, Antaisaka 415,000, Sakalava 375,000), on the
other; there are also 11,000 European French, 5,000 Indians of French
nationality, and 5,000 Creoles
_#_Religion: indigenous beliefs 52%, Christian about 41%, Muslim 7%
_#_Language: French and Malagasy (official)
_#_Literacy: 80% (male 88%, female 73%) age 15 and over can
read and write (1990 est.)
_#_Labor force: 4,900,000; 90% nonsalaried family workers engaged in
subsistence agriculture; 175,000 wage earners--agriculture 26%, domestic
service 17%, industry 15%, commerce 14%, construction 11%, services 9%,
transportation 6%, other 2%; 51% of population of working age (1985)
_#_Organized labor: 4% of labor force
_#_Population: 9,438,462 (July 1991), growth rate 1.8% (1991);
note--900,000 Mozambican refugees in Malawi (1990 est.)
_#_Birth rate: 52 births/1,000 population (1991)
_#_Death rate: 18 deaths/1,000 population (1991)
_#_Net migration rate: - 17 migrants/1,000 population (1991)
_#_Infant mortality rate: 136 deaths/1,000 live births (1991)
_#_Life expectancy at birth: 48 years male, 51 years female (1991)
_#_Total fertility rate: 7.6 children born/woman (1991)
_#_Nationality: noun--Malawian(s); adjective--Malawian
_#_Ethnic divisions: Chewa, Nyanja, Tumbuko, Yao, Lomwe, Sena, Tonga,
Ngoni, Ngonde, Asian, European
_#_Religion: Protestant 55%, Roman Catholic 20%, Muslim 20%;
traditional indigenous beliefs are also practiced
_#_Language: English and Chichewa (official); other languages
important regionally
_#_Literacy: 22% (male 34%, female 12%) age 15 and over can
read and write (1966)
_#_Labor force: 428,000 wage earners; agriculture 43%, manufacturing
16%, personal services 15%, commerce 9%, construction 7%, miscellaneous
services 4%, other permanently employed 6% (1986)
_#_Organized labor: small minority of wage earners are unionized
_#_Population: 17,981,698 (July 1991), growth rate 2.4% (1991)
_#_Birth rate: 30 births/1,000 population (1991)
_#_Death rate: 6 deaths/1,000 population (1991)
_#_Net migration rate: 0 migrants/1,000 population (1991)
_#_Infant mortality rate: 29 deaths/1,000 live births (1991)
_#_Life expectancy at birth: 65 years male, 71 years female (1991)
_#_Total fertility rate: 3.6 children born/woman (1991)
_#_Nationality: noun--Malaysian(s); adjective--Malaysian
_#_Ethnic divisions: Malay and other indigenous 59%, Chinese 32%,
Indian 9%
_#_Religion: Peninsular Malaysia--Malays nearly all Muslim, Chinese
predominantly Buddhists, Indians predominantly Hindu; Sabah--Muslim 38%,
Christian 17%, other 45%; Sarawak--tribal religion 35%, Buddhist and
Confucianist 24%, Muslim 20%, Christian 16%, other 5%
_#_Language: Peninsular Malaysia--Malay (official); English, Chinese
dialects, Tamil; Sabah--English, Malay, numerous tribal dialects,
Mandarin and Hakka dialects predominate among Chinese; Sarawak--English,
Malay, Mandarin, numerous tribal languages
_#_Literacy: 78% (male 86%, female 70%) age 15 and over can
read and write (1990 est.)
_#_Labor force: 6,800,000; agriculture 30.8%, manufacturing 17%,
government 13.6%, construction 5.8%, finance 4.3%, business services,
transport and communications 3.4%, mining 0.6%, other 24.5% (1989 est.)
_#_Organized labor: 660,000, 10% of total labor force (1988)
_#_Population: 226,200 (July 1991), growth rate 3.7% (1991)
_#_Birth rate: 46 births/1,000 population (1991)
_#_Death rate: 9 deaths/1,000 population (1991)
_#_Net migration rate: 0 migrants/1,000 population (1991)
_#_Infant mortality rate: 72 deaths/1,000 live births (1991)
_#_Life expectancy at birth: 61 years male, 65 years female (1991)
_#_Total fertility rate: 6.5 children born/woman (1991)
_#_Nationality: noun--Maldivian(s); adjective--Maldivian
_#_Ethnic divisions: admixtures of Sinhalese, Dravidian, Arab, and
black
_#_Religion: Sunni Muslim
_#_Language: Divehi (dialect of Sinhala; script derived from Arabic);
English spoken by most government officials
_#_Literacy: 92% (male 92%, female 92%) age 15 and over can
read and write (1985)
_#_Labor force: 66,000 (est.); 25% engaged in fishing industry
_#_Organized labor: none
_#_Population: 8,338,542 (July 1991), growth rate 2.4% (1991)
_#_Birth rate: 51 births/1,000 population (1991)
_#_Death rate: 21 deaths/1,000 population (1991)
_#_Net migration rate: - 6 migrants/1,000 population (1991)
_#_Infant mortality rate: 114 deaths/1,000 live births (1991)
_#_Life expectancy at birth: 45 years male, 47 years female (1991)
_#_Total fertility rate: 7.0 children born/woman (1991)
_#_Nationality: noun--Malian(s); adjective--Malian
_#_Ethnic divisions: Mande (Bambara, Malinke, Sarakole) 50%, Peul 17%,
Voltaic 12%, Songhai 6%, Tuareg and Moor 5%, other 10%
_#_Religion: Muslim 90%, indigenous beliefs 9%, Christian 1%
_#_Language: French (official); Bambara spoken by about 80% of the
population; numerous African languages
_#_Literacy: 32% (male 41%, female 24%) age 15 and over can
read and write (1990 est.)
_#_Labor force: 2,666,000 (1986 est.); agriculture 80%, services 19%,
industry and commerce 1% (1981); 50% of population of working age (1985)
_#_Organized labor: National Union of Malian Workers (UNTM) is
umbrella organization for over 13 national unions
_#_Population: 356,427 (July 1991), growth rate 0.8% (1991)
_#_Birth rate: 15 births/1,000 population (1991)
_#_Death rate: 8 deaths/1,000 population (1991)
_#_Net migration rate: 1 migrant/1,000 population (1991)
_#_Infant mortality rate: 7 deaths/1,000 live births (1991)
_#_Life expectancy at birth: 74 years male, 79 years female (1991)
_#_Total fertility rate: 2.0 children born/woman (1991)
_#_Nationality: noun--Maltese (sing. and pl.); adjective--Maltese
_#_Ethnic divisions: mixture of Arab, Sicilian, Norman, Spanish,
Italian, English
_#_Religion: Roman Catholic 98%
_#_Language: Maltese and English (official)
_#_Literacy: 84% (male 86%, female 82%) age 15 and over can
read and write (1985)
_#_Labor force: 126,135; government (excluding job corps) 37%,
services 26%, manufacturing 22%, training programs 9%, construction 4%,
agriculture 2% (1989)
_#_Organized labor: about 40% of labor force
_#_Population: 64,075 (July 1991), growth rate 0.1% (1991)
_#_Birth rate: 11 births/1,000 population (1991)
_#_Death rate: 14 deaths/1,000 population (1991)
_#_Net migration rate: 4 migrants/1,000 population (1991)
_#_Infant mortality rate: 9 deaths/1,000 live births (1991)
_#_Life expectancy at birth: 72 years male, 78 years female (1991)
_#_Total fertility rate: 1.8 children born/woman (1991)
_#_Nationality: noun--Manxman, Manxwoman, adjective--Manx
_#_Ethnic divisions: native Manx of Norse-Celtic descent; British
_#_Religion: Anglican, Roman Catholic, Methodist, Baptist,
Presbyterian, Society of Friends
_#_Language: English, Manx Gaelic
_#_Literacy: NA% (male NA%, female NA%) but compulsory education
age 5 to 16
_#_Labor force: 25,864 (1981)
_#_Organized labor: 22 labor unions patterned along British lines
_#_Population: 48,091 (July 1991), growth rate 3.9% (1991)
_#_Birth rate: 47 births/1,000 population (1991)
_#_Death rate: 8 deaths/1,000 population (1991)
_#_Net migration rate: 0 migrants/1,000 population (1991)
_#_Infant mortality rate: 53 deaths/1,000 live births (1991)
_#_Life expectancy at birth: 61 years male, 64 years female (1991)
_#_Total fertility rate: 7.1 children born/woman (1991)
_#_Nationality: noun--Marshallese; adjective--Marshallese
_#_Ethnic divisions: almost entirely Micronesian
_#_Religion: predominantly Christian, mostly Protestant
_#_Language: English universally spoken and is the official language;
two major Marshallese dialects from Malayo-Polynesian family; Japanese
_#_Literacy: 93% (male 100%, female 88%) age 15 and over can
read and write (1980)
_#_Labor force: 4,800 (1986)
_#_Organized labor: none
_#_Population: 345,180 (July 1991), growth rate 0.9% (1991)
_#_Birth rate: 19 births/1,000 population (1991)
_#_Death rate: 7 deaths/1,000 population (1991)
_#_Net migration rate: - 3 migrants/1,000 population (1991)
_#_Infant mortality rate: 10 deaths/1,000 live births (1991)
_#_Life expectancy at birth: 73 years male, 80 years female (1991)
_#_Total fertility rate: 2.1 children born/woman (1991)
_#_Nationality: noun--Martiniquais (sing. and pl.);
adjective--Martiniquais
_#_Ethnic divisions: African and African-Caucasian-Indian mixture
90%, Caucasian 5%, East Indian, Lebanese, Chinese less than 5%
_#_Religion: Roman Catholic 95%, Hindu and pagan African
5%
_#_Language: French, Creole patois
_#_Literacy: 93% (male 92%, female 93%) age 15 and over can
read and write (1982)
_#_Labor force: 100,000; service industry 31.7%, construction and
public works 29.4%, agriculture 13.1%, industry 7.3%, fisheries 2.2%,
other 16.3%
_#_Organized labor: 11% of labor force
_#_Population: 1,995,755 (July 1991), growth rate 3.1% (1991)
_#_Birth rate: 49 births/1,000 population (1991)
_#_Death rate: 18 deaths/1,000 population (1991)
_#_Net migration rate: 0 migrants/1,000 population (1991)
_#_Infant mortality rate: 94 deaths/1,000 live births (1991)
_#_Life expectancy at birth: 44 years male, 50 years female (1991)
_#_Total fertility rate: 7.2 children born/woman (1991)
_#_Nationality: noun--Mauritanian(s); adjective--Mauritanian
_#_Ethnic divisions: mixed Maur/black 40%, Maur 30%, black 30%
_#_Religion: Muslim, nearly 100%
_#_Language: Hasaniya Arabic (national); French (official);
Toucouleur, Fula, Sarakole, Wolof
_#_Literacy: 34% (male 47%, female 21%) age 10 and over can
read and write (1990 est.)
_#_Labor force: 465,000 (1981 est.); 45,000 wage earners (1980);
agriculture 47%, services 29%, industry and commerce 14%, government 10%;
53% of population of working age (1985)
_#_Organized labor: 30,000 members claimed by single union,
Mauritanian Workers'' Union
_#_Population: 1,081,000 (July 1991), growth rate 0.8% (1991)
_#_Birth rate: 19 births/1,000 population (1991)
_#_Death rate: 6 deaths/1,000 population (1991)
_#_Net migration rate: - 4 migrants/1,000 population (1991)
_#_Infant mortality rate: 20 deaths/1,000 live births (1991)
_#_Life expectancy at birth: 66 years male, 74 years female (1991)
_#_Total fertility rate: 2.0 children born/woman (1991)
_#_Nationality: noun--Mauritian(s); adjective--Mauritian
_#_Ethnic divisions: Indo-Mauritian 68%, Creole 27%, Sino-Mauritian
3%, Franco-Mauritian 2%
_#_Religion: Hindu 52%, Christian (Roman Catholic 26%, Protestant
2.3%) 28.3%, Muslim 16.6%, other 3.1%
_#_Language: English (official), Creole, French, Hindi, Urdu, Hakka,
Bojpoori
_#_Literacy: 61% (male 72%, female 50%) age 13 and over can
read and write (1962)
_#_Labor force: 335,000; government services 29%, agriculture and
fishing 27%, manufacturing 22%, other 22%; 43% of population of working
age (1985)
_#_Organized labor: 35% of labor force in more than 270 unions
_#_Population: 75,027 (July 1991), growth rate 3.9% (1991)
_#_Birth rate: 50 births/1,000 population (1991)
_#_Death rate: 12 deaths/1,000 population (1991)
_#_Net migration rate: 0 migrants/1,000 population (1991)
_#_Infant mortality rate: 87 deaths/1,000 live births (1991)
_#_Life expectancy at birth: 54 years male, 59 years female (1991)
_#_Total fertility rate: 6.8 children born/woman (1991)
_#_Nationality: noun--Mahorais (sing., pl.); adjective--Mahoran
_#_Religion: Muslim 99%; remainder Christian, mostly Roman Catholic
_#_Language: Mahorian (a Swahili dialect), French
_#_Literacy: NA% (male NA%, female NA%)
_#_Labor force: NA
_#_Organized labor: NA
_#_Population: 90,007,304 (July 1991), growth rate 2.2% (1991)
_#_Birth rate: 29 births/1,000 population (1991)
_#_Death rate: 5 deaths/1,000 population (1991)
_#_Net migration rate: - 1 migrants/1,000 population (1991)
_#_Infant mortality rate: 29 deaths/1,000 live births (1991)
_#_Life expectancy at birth: 68 years male, 76 years female (1991)
_#_Total fertility rate: 3.4 children born/woman (1991)
_#_Nationality: noun--Mexican(s); adjective--Mexican
_#_Ethnic divisions: mestizo (Indian-Spanish) 60%, Amerindian or
predominantly Amerindian 30%, white or predominantly white 9%, other 1%
_#_Religion: nominally Roman Catholic 97%, Protestant 3%
_#_Language: Spanish
_#_Literacy: 87% (male 90%, female 85%) age 15 and over can
read and write (1985 est.)
_#_Labor force: 26,100,000 (1988); services 31.4%, agriculture,
forestry, hunting, and fishing 26%, commerce 13.9%, manufacturing 12.8%,
construction 9.5%, transportation 4.8%, mining and quarrying 1.3%,
electricity 0.3% (1986)
_#_Organized labor: 35% of labor force','b4f848a2273f6ba3abaf8dfea478e1c771a5fb07cbb5d0e1b10ca8ac3c27e265','internet-archive','theciaworldfactb00025gut','txt','84185fe9df79da427349cc1598fd3f69814a2085a9fc1fe0508a3fae0a870f84','https://archive.org/download/theciaworldfactb00025gut/25.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d42d4090d60d55f639bc1d1aa1d8d231369e5e31ae5ff1cbd31574736b07ba80',1991,'ID','Indonesia','people-and-society',117,'_#_Population: 107,662 (July 1991), growth rate 2.5% (1991)
_#_Birth rate: 34 births/1,000 population (1991)
_#_Death rate: 5 deaths/1,000 population (1991)
_#_Net migration rate: - 4 migrants/1,000 population (1991)
_#_Infant mortality rate: 26 deaths/1,000 live births (1991)
_#_Life expectancy at birth: 68 years male, 73 years female (1991)
_#_Total fertility rate: 5.0 children born/woman (1991)
_#_Nationality: noun--Micronesian(s); adjective--Micronesian;
Kosrae(s), Pohnpeian(s), Trukese, Yapese
_#_Ethnic divisions: nine ethnic Micronesian and Polynesian groups
_#_Religion: predominantly Christian, divided between Roman Catholic
and Protestant; other churches include Assembly of God, Jehovah''s
Witnesses, Seventh-Day Adventist, Latter Day Saints, and the Baha''i
Faith
_#_Language: English is the official and common language; most
indigenous languages fall within the Austronesian language family, the
exceptions are the Polynesian languages; major indigenous languages are
Trukese, Pohnpeian, Yapese, and Kosrean
_#_Literacy: 90% (male 90%, female 85%) age 15 and over can
read and write (1980)
_#_Labor force: NA; two-thirds are government employees; 45,000 people
are between the ages of 15 and 65
_#_Organized labor: NA
_#_Population: 453 US military personnel (1991)
_#_Population: 29,712 (July 1991), growth rate 0.9% (1991)
_#_Birth rate: 7 births/1,000 population (1991)
_#_Death rate: 7 deaths/1,000 population (1991)
_#_Net migration rate: 9 migrants/1,000 population (1991)
_#_Infant mortality rate: 8 deaths/1,000 live births (1991)
_#_Life expectancy at birth: 72 years male, 80 years female (1991)
_#_Total fertility rate: 1.1 children born/woman (1991)
_#_Nationality: noun--Monacan(s) or Monegasque(s); adjective--Monacan
or Monegasque
_#_Ethnic divisions: French 47%, Monegasque 16%, Italian 16%, other
21%
_#_Religion: Roman Catholic 95%
_#_Language: French (official), English, Italian, Monegasque
_#_Literacy: NA% (male NA%, female NA%)
_#_Labor force: NA
_#_Organized labor: 4,000 members in 35 unions','117787469f342d47961b85347757d21065f8b0f04caee72289c91f14778f1b6e','internet-archive','theciaworldfactb00025gut','txt','84185fe9df79da427349cc1598fd3f69814a2085a9fc1fe0508a3fae0a870f84','https://archive.org/download/theciaworldfactb00025gut/25.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e23229d08ff3d9f631ad560c53cc699c226eb8a134a2d68b081d0f982b3c1234',1991,'GD','Grenada','people-and-society',121,'_#_Population: 114,221 (July 1991), growth rate 1.4% (1991)
_#_Birth rate: 27 births/1,000 population (1991)
_#_Death rate: 6 deaths/1,000 population (1991)
_#_Net migration rate: - 7 migrants/1,000 population (1991)
_#_Infant mortality rate: 31 deaths/1,000 live births (1991)
_#_Life expectancy at birth: 68 years male, 72 years female (1991)
_#_Total fertility rate: 2.8 children born/woman (1991)
_#_Nationality: noun--Saint Vincentian(s) or Vincentian(s);
adjectives--Saint Vincentian or Vincentian
_#_Ethnic divisions: mainly of black African descent; remainder mixed,
with some white, East Indian, Carib Indian
_#_Religion: Anglican, Methodist, Roman Catholic, Seventh-Day
Adventist
_#_Language: English, some French patois
_#_Literacy: 96% (male 96%, female 96%) age 15 and over having ever
attended school (1970)
_#_Labor force: 67,000 (1984 est.)
_#_Organized labor: 10% of labor force
_#_Population: 23,264 (July 1991), growth rate 0.6% (1991)
_#_Birth rate: 8 births/1,000 population (1991)
_#_Death rate: 7 deaths/1,000 population (1991)
_#_Net migration rate: 5 migrants/1,000 population (1991)
_#_Infant mortality rate: 8 deaths/1,000 live births (1991)
_#_Life expectancy at birth: 74 years male, 79 years female (1991)
_#_Total fertility rate: 1.3 children born/woman (1991)
_#_Nationality: noun--Sanmarinese (sing. and pl.);
adjective--Sanmarinese
_#_Ethnic divisions: Sanmarinese, Italian
_#_Religion: Roman Catholic
_#_Language: Italian
_#_Literacy: 96% (male 96%, female 95%) age 14 and over can
read and write (1976)
_#_Labor force: about 4,300
_#_Organized labor: Democratic Federation of Sanmarinese Workers
(affiliated with ICFTU) has about 1,800 members; Communist-dominated
General Federation of Labor, 1,400 members
_#_Population: 128,499 (July 1991), growth rate 3.0% (1991)
_#_Birth rate: 38 births/1,000 population (1991)
_#_Death rate: 8 deaths/1,000 population (1991)
_#_Net migration rate: 0 migrants/1,000 population (1991)
_#_Infant mortality rate: 60 deaths/1,000 live births (1991)
_#_Life expectancy at birth: 64 years male, 68 years female (1991)
_#_Total fertility rate: 5.3 children born/woman (1991)
_#_Nationality: noun--Sao Tomean(s); adjective--Sao Tomean
_#_Ethnic divisions: mestico, angolares (descendents of Angolan
slaves), forros (descendents of freed slaves), servicais (contract
laborers from Angola, Mozambique, and Cape Verde), tongas (children of
servicais born on the islands), and Europeans (primarily Portuguese)
_#_Religion: Roman Catholic, Evangelical Protestant, Seventh-Day
Adventist
_#_Language: Portuguese (official)
_#_Literacy: 57% (male 73%, female 42%) age 15 and over can
read and write (1981)
_#_Labor force: 21,096 (1981); most of population engaged in
subsistence agriculture and fishing; labor shortages on plantations and
of skilled workers; 56% of population of working age (1983)
_#_Organized labor: NA','80b6cc529fd016201ca6b1e496f058e80de33c6fe4d6eda82cc0777e16c6bc89','internet-archive','theciaworldfactb00025gut','txt','84185fe9df79da427349cc1598fd3f69814a2085a9fc1fe0508a3fae0a870f84','https://archive.org/download/theciaworldfactb00025gut/25.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7778dae5ce10a86677e5c0acc698684c764b76dea5060ba84ba6f4ece4a2a62e',1991,'SG','Singapore','people-and-society',126,'_#_Population: 56,814,069 (July 1991), growth rate 1.4% (1991)
_#_Birth rate: 20 births/1,000 population (1991)
_#_Death rate: 6 deaths/1,000 population (1991)
_#_Net migration rate: 0 migrants/1,000 population (1991)
_#_Infant mortality rate: 37 deaths/1,000 live births (1991)
_#_Life expectancy at birth: 66 years male, 71 years female (1991)
_#_Total fertility rate: 2.2 children born/woman (1991)
_#_Nationality: noun--Thai (sing. and pl.); adjective--Thai
_#_Ethnic divisions: Thai 75%, Chinese 14%, other 11%
_#_Religion: Buddhism 95%, Muslim 3.8%, Christianity 0.5%,
Hinduism 0.1%, other 0.5% (1991)
_#_Language: Thai; English is the secondary language of the elite;
ethnic and regional dialects
_#_Literacy: 93% (male 96%, female 90%) age 15 and over can
read and write (1990 est.)
_#_Labor force: 30,870,000; agriculture 62%, industry 13%,
commerce 11%, services (including government) 14% (1989 est.)
_#_Organized labor: 309,000 union members (1989)
_#_Population: 3,810,616 (July 1991), growth rate 3.6% (1991)
_#_Birth rate: 49 births/1,000 population (1991)
_#_Death rate: 13 deaths/1,000 population (1991)
_#_Net migration rate: 0 migrants/1,000 population (1991)
_#_Infant mortality rate: 110 deaths/1,000 live births (1991)
_#_Life expectancy at birth: 54 years male, 58 years female (1991)
_#_Total fertility rate: 7.1 children born/woman (1991)
_#_Nationality: noun--Togolese (sing. and pl.); adjective--Togolese
_#_Ethnic divisions: 37 tribes; largest and most important are Ewe,
Mina, and Kabye; under 1% European and Syrian-Lebanese
_#_Religion: indigenous beliefs about 70%, Christian 20%,
Muslim 10%
_#_Language: French, both official and language of commerce; major
African languages are Ewe and Mina in the south and Dagomba and Kabye
in the north
_#_Literacy: 43% (male 56%, female 31%) age 15 and over can
read and write (1990 est.)
_#_Labor force: NA; agriculture 78%, industry 22%; about 88,600 wage
earners, evenly divided between public and private sectors; 50% of
population of working age (1985)
_#_Organized labor: one national union, the National Federation of
Togolese Workers
_#_Population: 1,700 (July 1991), growth rate 0.0% (1991)
_#_Birth rate: NA births/1,000 population (1991)
_#_Death rate: NA deaths/1,000 population (1991)
_#_Net migration rate: NA migrants/1,000 population (1991)
_#_Infant mortality rate: NA deaths/1,000 live births (1991)
_#_Life expectancy at birth: NA years male, NA years female (1991)
_#_Total fertility rate: NA children born/woman (1991)
_#_Nationality: noun--Tokelauan(s); adjective--Tokelauan
_#_Ethnic divisions: all Polynesian, with cultural ties to Western','abc3d99e027666a330334d5a2a3419b0f8f5fe97532cf7ca769aca9aca68ae44','internet-archive','theciaworldfactb00025gut','txt','84185fe9df79da427349cc1598fd3f69814a2085a9fc1fe0508a3fae0a870f84','https://archive.org/download/theciaworldfactb00025gut/25.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e10cb84484be16830415dc3fe3f14cc528a2f3184ac91b7fdd905489013518f1',1991,'WS','Samoa','people-and-society',131,'_#_Religion: Congregational Christian Church 70%, Roman Catholic
28%, other 2%; on Atafu, all Congregational Christian Church of Samoa; on
Nukunonu, all Roman Catholic; on Fakaofo, both denominations, with the
Congregational Christian Church predominant
_#_Language: Tokelauan (a Polynesian language) and English
_#_Literacy: NA% (male NA%, female NA%)
_#_Labor force: NA
_#_Organized labor: NA
_#_Population: 102,272 (July 1991), growth rate 0.9% (1991)
_#_Birth rate: 26 births/1,000 population (1991)
_#_Death rate: 7 deaths/1,000 population (1991)
_#_Net migration rate: - 10 migrants/1,000 population (1991)
_#_Infant mortality rate: 23 deaths/1,000 live births (1991)
_#_Life expectancy at birth: 65 years male, 70 years female (1991)
_#_Total fertility rate: 3.8 children born/woman (1991)
_#_Nationality: noun--Tongan(s); adjective--Tongan
_#_Ethnic divisions: Polynesian; about 300 Europeans
_#_Religion: Christian; Free Wesleyan Church claims over 30,000
adherents
_#_Language: Tongan, English
_#_Literacy: 100% (male 100%, female 100%) age 15 and over can
read and write a simple message in Tongan or English (1976)
_#_Labor force: NA; 70% agriculture; 600 engaged in mining
_#_Organized labor: none
_#_Population: 1,285,297 (July 1991), growth rate 1.1% (1991)
_#_Birth rate: 21 births/1,000 population (1991)
_#_Death rate: 6 deaths/1,000 population (1991)
_#_Net migration rate: - 4 migrants/1,000 population (1991)
_#_Infant mortality rate: 18 deaths/1,000 live births (1991)
_#_Life expectancy at birth: 68 years male, 73 years female (1991)
_#_Total fertility rate: 2.4 children born/woman (1991)
_#_Nationality: noun--Trinidadian(s), Tobagonian(s);
adjective--Trinidadian, Tobagonian
_#_Ethnic divisions: black 43%, East Indian 40%, mixed 14%, white 1%,
Chinese 1%, other 1%
_#_Religion: Roman Catholic 32.2%, Hindu 24.3%, Anglican 14.4%,
other Protestant 14%, Muslim 6%, none or unknown 9.1%
_#_Language: English (official), Hindi, French, Spanish
_#_Literacy: 95% (male 97%, female 93%) age 15 and over can
read and write (1980)
_#_Labor force: 463,900; construction and utilities 18.1%;
manufacturing, mining, and quarrying 14.8%; agriculture 10.9%;
other 56.2% (1985 est.)
_#_Organized labor: 22% of labor force (1988)
_#_Population: uninhabited
_#_Population: 8,276,096 (July 1991), growth rate 2.1% (1991)
_#_Birth rate: 26 births/1,000 population (1991)
_#_Death rate: 5 deaths/1,000 population (1991)
_#_Net migration rate: 0 migrants/1,000 population (1991)
_#_Infant mortality rate: 38 deaths/1,000 live births (1991)
_#_Life expectancy at birth: 70 years male, 74 years female (1991)
_#_Total fertility rate: 3.3 children born/woman (1991)
_#_Nationality: noun--Tunisian(s); adjective--Tunisian
_#_Ethnic divisions: Arab 98%, European 1%, Jewish less than 1%
_#_Religion: Muslim 98%, Christian 1%, Jewish less than 1%
_#_Language: Arabic (official); Arabic and French (commerce)
_#_Literacy: 65% (male 74%, female 56%) age 15 and over can
read and write (1990 est.)
_#_Labor force: 2,250,000; agriculture 32%; shortage of skilled labor
_#_Organized labor: about 360,000 members claimed, roughly 20% of
labor force; General Union of Tunisian Workers (UGTT), quasi-independent
of Constitutional Democratic Party','1a7d222b0059c3704276152dc181611af63844aad2ab44af238515f41317ccc1','internet-archive','theciaworldfactb00025gut','txt','84185fe9df79da427349cc1598fd3f69814a2085a9fc1fe0508a3fae0a870f84','https://archive.org/download/theciaworldfactb00025gut/25.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c32842037a7bc4889a951467fec50b04b98acaa3fd727134df2b48b093f909bc',1991,'DZ','Algeria','people-and-society',139,'_#_Population: 58,580,993 (July 1991), growth rate 2.2% (1991)
_#_Birth rate: 28 births/1,000 population (1991)
_#_Death rate: 6 deaths/1,000 population (1991)
_#_Net migration rate: 0 migrants/1,000 population (1991)
_#_Infant mortality rate: 54 deaths/1,000 live births (1991)
_#_Life expectancy at birth: 68 years male, 72 years female (1991)
_#_Total fertility rate: 3.6 children born/woman (1991)
_#_Nationality: noun--Turk(s); adjective--Turkish
_#_Ethnic divisions: Turkish 80%, Kurdish 17%, other 3% (est.)
_#_Religion: Muslim (mostly Sunni) 99.8%, other (Christian and
Jews) 0.2%
_#_Language: Turkish (official), Kurdish, Arabic
_#_Literacy: 81% (male 90%, female 71%) age 15 and over can
read and write (1990 est.)
_#_Labor force: 18,800,000; agriculture 56%, services 30%,
industry 14%; about 1,000,000 Turks work abroad (1987)
_#_Organized labor: 10-15% of labor force
_#_Population: 9,983 (July 1991), growth rate 2.2% (1991)
_#_Birth rate: 25 births/1,000 population (1991)
_#_Death rate: 5 deaths/1,000 population (1991)
_#_Net migration rate: 2 migrants/1,000 population (1991)
_#_Infant mortality rate: 14 deaths/1,000 live births (1991)
_#_Life expectancy at birth: 72 years male, 78 years female (1991)
_#_Total fertility rate: 3.8 children born/woman (1991)
_#_Nationality: no noun or adjectival forms
_#_Ethnic divisions: majority of African descent
_#_Religion: Baptist 41.2%, Methodist 18.9%, Anglican 18.3%,
Seventh-Day Adventist 1.7%, other 19.9% (1980)
_#_Language: English (official)
_#_Literacy: 98% (male 99%, female 98%) age 15 and over having ever
attended school (1970)
_#_Labor force: NA; majority engaged in fishing and tourist
industries; some subsistence agriculture
_#_Organized labor: Saint George''s Industrial Trade Union
_#_Population: 9,317 (July 1991), growth rate 1.9% (1991)
_#_Birth rate: 29 births/1,000 population (1991)
_#_Death rate: 10 deaths/1,000 population (1991)
_#_Net migration rate: 0 migrants/1,000 population (1991)
_#_Infant mortality rate: 33 deaths/1,000 live births (1991)
_#_Life expectancy at birth: 61 years male, 63 years female (1991)
_#_Total fertility rate: 3.1 children born/woman (1991)
_#_Nationality: noun--Tuvaluans(s); adjective--Tuvaluan
_#_Ethnic divisions: 96% Polynesian
_#_Religion: Church of Tuvalu (Congregationalist) 97%, Seventh-Day
Adventist 1.4%, Baha''i 1%, other 0.06%
_#_Language: Tuvaluan, English
_#_Literacy: NA% (male NA%, female NA%)
_#_Labor force: NA
_#_Organized labor: none
_#_Population: 18,690,070 (July 1991), growth rate 3.7% (1991)
_#_Birth rate: 51 births/1,000 population (1991)
_#_Death rate: 15 deaths/1,000 population (1991)
_#_Net migration rate: 0 migrants/1,000 population (1991)
_#_Infant mortality rate: 94 deaths/1,000 live births (1991)
_#_Life expectancy at birth: 50 years male, 52 years female (1991)
_#_Total fertility rate: 7.3 children born/woman (1991)
_#_Nationality: noun--Ugandan(s); adjective--Ugandan
_#_Ethnic divisions: African 99%, European, Asian, Arab 1%
_#_Religion: Roman Catholic 33%, Protestant 33%, Muslim 16%,
rest indigenous beliefs
_#_Language: English (official); Luganda and Swahili widely used;
other Bantu and Nilotic languages
_#_Literacy: 48% (male 62%, female 35%) age 15 and over can
read and write (1990 est.)
_#_Labor force: 4,500,000 (est.); subsistence agriculture 94%, wage
earners (est.) 6%; 50% of population of working age (1983)
_#_Organized labor: 125,000 union members
_#_Population: 2,389,759 (July 1991), growth rate 5.7% (1991)
_#_Birth rate: 30 births/1,000 population (1991)
_#_Death rate: 3 deaths/1,000 population (1991)
_#_Net migration rate: 30 migrants/1,000 population (1991)
_#_Infant mortality rate: 23 deaths/1,000 live births (1991)
_#_Life expectancy at birth: 69 years male, 74 years female (1991)
_#_Total fertility rate: 4.9 children born/woman (1991)
_#_Nationality: noun--Emirian(s), adjective--Emirian
_#_Ethnic divisions: Emirian 19%, other Arab 23%, South Asian
(fluctuating) 50%, other expatriates (includes Westerners and East
Asians) 8%; less than 20% of the population are UAE citizens (1982)
_#_Religion: Muslim 96% (Shia 16%); Christian, Hindu, and other
4%
_#_Language: Arabic (official); Persian and English widely spoken in
major cities; Hindi, Urdu
_#_Literacy: 68% (male 70%, female 63%) age 10 and over but definition
of literacy not available (1980)
_#_Labor force: 580,000 (1986 est.); industry and commerce 85%,
agriculture 5%, services 5%, government 5%; 80% of labor force is foreign
_#_Organized labor: trade unions are illegal
_#_Population: 57,515,307 (July 1991), growth rate 0.3% (1991)
_#_Birth rate: 14 births/1,000 population (1991)
_#_Death rate: 11 deaths/1,000 population (1991)
_#_Net migration rate: 0 migrants/1,000 population (1991)
_#_Infant mortality rate: 7 deaths/1,000 live births (1991)
_#_Life expectancy at birth: 73 years male, 79 years female (1991)
_#_Total fertility rate: 1.8 children born/woman (1991)
_#_Nationality: noun--Briton(s), British (collective pl.);
adjective--British
_#_Ethnic divisions: English 81.5%, Scottish 9.6%, Irish 2.4%, Welsh
1.9%, Ulster 1.8%, West Indian, Indian, Pakistani, and other 2.8%
_#_Religion: Anglican 27.0 million, Roman Catholic 5.3 million,
Presbyterian 2.0 million, Methodist 760,000, Jewish 410,000
_#_Language: English, Welsh (about 26% of population of Wales),
Scottish form of Gaelic (about 60,000 in Scotland)
_#_Literacy: 99% (male NA%, female NA%) age 15 and over can
read and write (1978 est.)
_#_Labor force: 28,966,000; services 60.6%, manufacturing and
construction 27.2%, government 8.9%, energy 2.1%, agriculture
1.2% (June 1990)
_#_Organized labor: 35.7% of labor force (1989)
_#_Population: 252,502,000 (July 1991), growth rate 0.8% (1991)
_#_Birth rate: 15 births/1,000 population (1991)
_#_Death rate: 9 deaths/1,000 population (1991)
_#_Net migration rate: 2 migrants/1,000 population (1991)
_#_Infant mortality rate: 10 deaths/1,000 live births (1991)
_#_Life expectancy at birth: 72 years male, 79 years female (1991)
_#_Total fertility rate: 1.8 children born/woman (1991)
_#_Nationality: noun--American(s); adjective--American
_#_Ethnic divisions: white 85%, black 12%, other 3% (1985)
_#_Religion: Protestant 61% (Baptist 21%, Methodist 12%, Lutheran 8%,
Presbyterian 4%, Episcopalian 3%, other Protestant 13%), Roman Catholic
25%, Jewish 2%, other 5%, none 7%
_#_Language: predominantly English; sizable Spanish-speaking minority
_#_Literacy: 97% (male 97%, female 97%) age 15 and over having
completed 5 or more years of schooling (1980)
_#_Labor force: 126,424,000 (includes armed forces and unemployed);
civilian labor force 124,787,000 (1990)
_#_Organized labor: 16,729,000 members; 16.1% of total wage and
salary employment which was 103,905,000 (1990)
_#_Population: 3,121,101 (July 1990), growth rate 0.6% (1991)
_#_Birth rate: 17 births/1,000 population (1991)
_#_Death rate: 10 deaths/1,000 population (1991)
_#_Net migration rate: - 1 migrants/1,000 population (1991)
_#_Infant mortality rate: 22 deaths/1,000 live births (1991)
_#_Life expectancy at birth: 69 years male, 76 years female (1991)
_#_Total fertility rate: 2.4 children born/woman (1991)
_#_Nationality: noun--Uruguayan(s); adjective--Uruguayan
_#_Ethnic divisions: white 88%, mestizo 8%, black 4%
_#_Religion: Roman Catholic (less than half adult population attends
church regularly) 66%, Protestant 2%, Jewish 2%, nonprofessing or other
30%
_#_Language: Spanish
_#_Literacy: 96% (male 97%, female 96%) age 15 and over can
read and write (1990 est.)
_#_Labor force: 1,300,000; government 25%, manufacturing 19%,
agriculture 11%, commerce 12%, utilities, construction, transport,
and communications 12%, other services 21% (1988 est.)
_#_Organized labor: Interunion Workers'' Assembly/National Workers''
Confederation (PIT/CNT) Labor Federation
_#_Population: 170,319 (July 1991), growth rate 3.1% (1991)
_#_Birth rate: 36 births/1,000 population (1991)
_#_Death rate: 5 deaths/1,000 population (1991)
_#_Net migration rate: 0 migrants/1,000 population (1991)
_#_Infant mortality rate: 36 deaths/1,000 live births (1991)
_#_Life expectancy at birth: 67 years male, 72 years female (1991)
_#_Total fertility rate: 5.4 children born/woman (1991)
_#_Nationality: noun--Ni-Vanuatu (singular and plural);
adjective--Ni-Vanuatu
_#_Ethnic divisions: indigenous Melanesian 94%, French 4%, remainder
Vietnamese, Chinese, and various Pacific Islanders
_#_Religion: Presbyterian 36.7%, Anglican 15%, Catholic 15%,
indigenous beliefs 7.6%, Seventh-Day Adventist 6.2%, Church of Christ
3.8%, other 15.7%
_#_Language: English and French (official); pidgin (known as Bislama
or Bichelama)
_#_Literacy: 53% (male 57%, female 48%) age 15 and over can
read and write (1979)
_#_Labor force: NA
_#_Organized labor: 7 registered trade unions--largest include Oil
and Gas Workers'' Union, Vanuatu Airline Workers'' Union
_#_Population: 778 (July 1991), growth rate NEGL% (1991)
_#_Nationality: no noun or adjectival forms
_#_Ethnic divisions: primarily Italians but also Swiss and other
nationalities
_#_Religion: Roman Catholic
_#_Language: Italian, Latin, and various other languages
_#_Literacy: 100% (male NA%, female NA%)
_#_Labor force: high dignitaries, priests, nuns, guards, and 3,000
lay workers who live outside the Vatican
_#_Organized labor: Association of Vatican Lay Workers, 1,800 members
(1987)','860ef7605d62aa4169c1ea39aa813b3cff6fbad9761187868f59e07f3090dac0','internet-archive','theciaworldfactb00025gut','txt','84185fe9df79da427349cc1598fd3f69814a2085a9fc1fe0508a3fae0a870f84','https://archive.org/download/theciaworldfactb00025gut/25.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('35ed9dc6b21e2d0855ff528e4c0cd319c95627c0377d942602f634b83e02ca2a',1991,'IT','Italy','people-and-society',144,'_#_Population: 20,189,361 (July 1991), growth rate 2.4% (1991)
_#_Birth rate: 28 births/1,000 population (1991)
_#_Death rate: 4 deaths/1,000 population (1991)
_#_Net migration rate: 1 migrant/1,000 population (1991)
_#_Infant mortality rate: 26 deaths/1,000 live births (1991)
_#_Life expectancy at birth: 71 years male, 78 years female (1991)
_#_Total fertility rate: 3.4 children born/woman (1991)
_#_Nationality: noun--Venezuelan(s); adjective--Venezuelan
_#_Ethnic divisions: mestizo 67%, white 21%, black 10%, Indian 2%
_#_Religion: nominally Roman Catholic 96%, Protestant 2%
_#_Language: Spanish (official); Indian dialects spoken by about
200,000 Amerindians in the remote interior
_#_Literacy: 88% (male 87%, female 90%) age 15 and over can
read and write (1981 est.)
_#_Labor force: 5,800,000; services 56%, industry 28%, agriculture 16%
(1985)
_#_Organized labor: 32% of labor force
_#_Population: 67,568,033 (July 1991), growth rate 2.1% (1991)
_#_Birth rate: 29 births/1,000 population (1991)
_#_Death rate: 8 deaths/1,000 population (1991)
_#_Net migration rate: - 1 migrant/1,000 population (1991)
_#_Infant mortality rate: 48 deaths/1,000 live births (1991)
_#_Life expectancy at birth: 63 years male, 67 years female (1991)
_#_Total fertility rate: 3.7 children born/woman (1991)
_#_Nationality: noun--Vietnamese (sing. and pl.);
adjective--Vietnamese
_#_Ethnic divisions: predominantly Vietnamese 85-90%; Chinese 3%;
ethnic minorities include Muong, Thai, Meo, Khmer, Man, Cham; other
mountain tribes
_#_Religion: Buddhist, Confucian, Taoist, Roman Catholic, indigenous
beliefs, Islamic, Protestant
_#_Language: Vietnamese (official), French, Chinese, English, Khmer,
tribal languages (Mon-Khmer and Malayo-Polynesian)
_#_Literacy: 88% (male 92%, female 84%) age 15 and over can
read and write (1990 est.)
_#_Labor force: 32.7 million; agricultural 65%, industrial and
service 35% (1990 est.)
_#_Organized labor: reportedly over 90% of wage and salary earners are
members of the Vietnam Federation of Trade Unions (VFTU)','8d8e44af887eee1b75272fadf3eafa0ac5daddb974627231fa7194fee38706f6','internet-archive','theciaworldfactb00025gut','txt','84185fe9df79da427349cc1598fd3f69814a2085a9fc1fe0508a3fae0a870f84','https://archive.org/download/theciaworldfactb00025gut/25.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b4f7606e06d58c3fac98f6e5c878d7829225e6bf106c5c48cda485023ea35a81',1991,'MT','Malta','people-and-society',148,'_#_Population: 99,404 (July 1991), growth rate 0.7% (1991)
_#_Birth rate: 22 births/1,000 population (1991)
_#_Death rate: 5 deaths/1,000 population (1991)
_#_Net migration rate: - 10 migrants/1,000 population (1991)
_#_Infant mortality rate: 19 deaths/1,000 live births (1991)
_#_Life expectancy at birth: 70 years male, 76 years female (1991)
_#_Total fertility rate: 2.7 children born/woman (1991)
_#_Nationality: noun--Virgin Islander(s); adjective--Virgin Islander
_#_Ethnic divisions: West Indian (45% born in the Virgin Islands and
29% born elsewhere in the West Indies) 74%, US mainland 13%, Puerto
Rican 5%, other 8%; black 80%, white 15%, other 5%; Hispanic origin 14%
_#_Religion: Baptist 42%, Roman Catholic 34%, Episcopalian 17%,
other 7%
_#_Language: English (official), but Spanish and Creole are widely
spoken
_#_Literacy: NA% (male NA%, female NA%)
_#_Labor force: 45,500 (1988)
_#_Organized labor: 90% of the government labor force
_#_Population: 195 (January 1990); no indigenous inhabitants;
302 temporary population
_#_Note: population peaked about 1970 with over 1,600 persons during
the Vietnam conflict
_#_Population: 16,590 (July 1991), growth rate 3.0% (1991)
_#_Birth rate: 28 births/1,000 population (1991)
_#_Death rate: 6 deaths/1,000 population (1991)
_#_Net migration rate: 8 migrants/1,000 population (1991)
_#_Infant mortality rate: 30 deaths/1,000 population (1991)
_#_Life expectancy at birth: 70 years male, 71 years female (1991)
_#_Total fertility rate: 3.7 children born/woman (1991)
_#_Nationality: noun--Wallisian(s), Futunan(s), or Wallis and Futuna
Islanders; adjective--Wallisian, Futunan, or Wallis and Futuna Islander
_#_Ethnic divisions: almost entirely Polynesian
_#_Religion: largely Roman Catholic
_#_Language: French, Wallisian (indigenous Polynesian language)
_#_Literacy: 50% (male 50%, female 51%) at all ages can read and write
(1969)
_#_Labor force: NA
_#_Organized labor: NA
_#_Population: 1,086,081 (July 1991), growth rate 2.6% (1991);
in addition, there are 90,000 Jewish settlers in the West Bank and
120,000 in East Jerusalem (1990 est.)
_#_Birth rate: 37 births/1,000 population (1991)
_#_Death rate: 6 deaths/1,000 population (1991)
_#_Net migration rate: - 4 migrants/1,000 population (1991)
_#_Infant mortality rate: 47 deaths/1,000 live births (1991)
_#_Life expectancy at birth: 65 years male, 69 years female (1991)
_#_Total fertility rate: 4.9 children born/woman (1991)
_#_Nationality: NA
_#_Ethnic divisions: Palestinian Arab and other 88%, Jewish 12%
_#_Religion: Muslim (predominantly Sunni) 80%, Jewish 12%, Christian
and other 8%
_#_Language: Arabic, Israeli settlers speak Hebrew, English widely
understood
_#_Literacy: NA% (male NA%, female NA%)
_#_Labor force: NA; excluding Israeli Jewish settlers--small industry,
commerce, and business 29.8%, construction 24.2%, agriculture 22.4%,
service and other 23.6% (1984)
_#_Organized labor: NA
_#_Population: 196,737 (July 1991), growth rate 2.6% (1991)
_#_Birth rate: 48 births/1,000 population (1991)
_#_Death rate: 23 deaths/1,000 population (1991)
_#_Net migration rate: 1 migrant/1,000 population (1991)
_#_Infant mortality rate: 177 deaths/1,000 live births (1991)
_#_Life expectancy at birth: 39 years male, 41 years female (1991)
_#_Total fertility rate: 7.3 children born/woman (1991)
_#_Nationality: noun--Saharan(s), Moroccan(s); adjective--Saharan,
Moroccan
_#_Ethnic divisions: Arab and Berber
_#_Religion: Muslim
_#_Language: Hassaniya Arabic, Moroccan Arabic
_#_Literacy: NA% (male NA%, female NA%)
_#_Labor force: 12,000; 50% animal husbandry and subsistence farming
_#_Organized labor: NA
_#_Population: 190,346 (July 1991), growth rate 2.3% (1991)
_#_Birth rate: 34 births/1,000 population (1991)
_#_Death rate: 6 deaths/1,000 population (1991)
_#_Net migration rate: - 4 migrants/1,000 population (1991)
_#_Infant mortality rate: 47 deaths/1,000 live births (1991)
_#_Life expectancy at birth: 64 years male, 69 years female (1991)
_#_Total fertility rate: 4.5 children born/woman (1991)
_#_Nationality: noun--Western Samoan(s); adjective--Western Samoan
_#_Ethnic divisions: Samoan; Euronesians (persons of European and
Polynesian blood) about 7%, Europeans 0.4%
_#_Religion: Christian 99.7% (about half of population associated with
the London Missionary Society; includes Congregational, Roman Catholic,
Methodist, Latter Day Saints, Seventh-Day Adventist)
_#_Language: Samoan (Polynesian), English
_#_Literacy: 97% (male 97%, female 97%) age 15 and over can
read and write (1971)
_#_Labor force: 38,000; 22,000 employed in agriculture (1987 est.)
_#_Organized labor: Public Service Association (PSA)
_#_Population: 5,419,643,132 (July 1991), growth rate 1.7% (1991)
_#_Birth rate: 26 births/1,000 population (1991)
_#_Death rate: 9 deaths/1,000 population (1991)
_#_Infant mortality rate: 66 deaths/1,000 live births (1991)
_#_Life expectancy at birth: 61 years male, 65 years female (1991)
_#_Total fertility rate: 3.3 children born/woman (1991)
_#_Literacy: 74% (male 81%, female 67%) age 15 and over can
read and write (1990 est.)
_#_Labor force: 2.2 billion (1991)
_#_Organized labor: NA
_#_Population: 10,062,633 (July 1991), growth rate 3.2% (1991)
_#_Birth rate: 51 births/1,000 population (1991)
_#_Death rate: 16 deaths/1,000 population (1991)
_#_Net migration rate: - 3 migrants/1,000 population (1991)
_#_Infant mortality rate: 121 deaths/1,000 live births (1991)
_#_Life expectancy at birth: 49 years male, 51 years female (1991)
_#_Total fertility rate: 7.4 children born/woman (1991)
_#_Nationality: noun--Yemeni(s); adjective--Yemeni
_#_Ethnic divisions:
North--Arab 90%, Afro-Arab (mixed) 10%;
South--almost all Arabs; a few Indians, Somalis, and Europeans
_#_Religion:
North--Muslim 100% (Sunni and Shia);
South--Sunni Muslim, some Christian and Hindu
_#_Language: Arabic
_#_Literacy: 38% (male 53%, female 26%) age 15 and over can
read and write (1990 est.)
_#_Labor force:
North--NA number of workers with agriculture and herding 70%, and
expatriate laborers 30% (est.);
South--477,000 with agriculture 45.2%, services 21.2%, construction
13.4%, industry 10.6%, commerce and other 9.6% (1983)
_#_Organized labor:
North--NA;
South--348,200 and the General Confederation of Workers of the
People''s Democratic Republic of Yemen had 35,000 members','36a4adc9503424ca1a6fc8f765a320b90311e32bb02111c209619389efff63f6','internet-archive','theciaworldfactb00025gut','txt','84185fe9df79da427349cc1598fd3f69814a2085a9fc1fe0508a3fae0a870f84','https://archive.org/download/theciaworldfactb00025gut/25.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c5b3441ee6ede39331d8cbecf6e07db7af5cf10b01096b3dcbb5fe3c8fa53daa',1991,'DJ','Djibouti','people-and-society',152,'_#_Population: 23,976,040 (July 1991), growth rate 0.6% (1991)
_#_Birth rate: 14 births/1,000 population (1991)
_#_Death rate: 9 deaths/1,000 population (1991)
_#_Net migration rate: 0 migrants/1,000 population (1991)
_#_Infant mortality rate: 21 deaths/1,000 live births (1991)
_#_Life expectancy at birth: 70 years male, 76 years female (1991)
_#_Total fertility rate: 1.9 children born/woman (1991)
_#_Nationality: noun--Yugoslav(s); adjective--Yugoslav
_#_Ethnic divisions: Serb 36.3%, Croat 19.7%, Muslim 8.9%, Slovene
7.8%, Albanian 7.7%, Macedonian 5.9%, Yugoslav 5.4%, Montenegrin 2.5%,
Hungarian 1.9%, other 3.9% (1981 census)
_#_Religion: Eastern Orthodox 50%, Roman Catholic 30%, Muslim 9%,
Protestant 1%, other 10%
_#_Language: Serbo-Croatian, Slovene, Macedonian (all official);
Albanian, Hungarian
_#_Literacy: 90% (male 96%, female 84%) age 15 and over can
read and write (1981)
_#_Labor force: 9,600,000; agriculture 22%, mining and manufacturing
27%; about 5% of labor force are guest workers in Western Europe (1986)
_#_Organized labor: badly fractured labor movement, with no unified
national labor federation; several republics have competing union
federations within their borders
_#_Population: 37,832,407 (July 1991), growth rate 3.3% (1991)
_#_Birth rate: 46 births/1,000 population (1991)
_#_Death rate: 13 deaths/1,000 population (1991)
_#_Net migration rate: 0 migrants/1,000 population (1991)
_#_Infant mortality rate: 99 deaths/1,000 live births (1991)
_#_Life expectancy at birth: 52 years male, 56 years female (1991)
_#_Total fertility rate: 6.2 children born/woman (1991)
_#_Nationality: noun--Zairian(s); adjective--Zairian
_#_Ethnic divisions: over 200 African ethnic groups, the majority are
Bantu; four largest tribes--Mongo, Luba, Kongo (all Bantu), and the
Mangbetu-Azande (Hamitic) make up about 45% of the population
_#_Religion: Roman Catholic 50%, Protestant 20%, Kimbanguist 10%,
Muslim 10%, other syncretic sects and traditional beliefs 10%
_#_Language: French (official), Lingala, Swahili, Kingwana, Kikongo,
Tshiluba
_#_Literacy: 72% (male 84%, female 61%) age 15 and over can
read and write (1990 est.)
_#_Labor force: 15,000,000; agriculture 75%, industry 13%, services
12%; wage earners 13% (1981); population of working age 51% (1985)
_#_Organized labor: National Union of Zairian Workers (UNTZA) was
the only officially recognized trade union until April 1990; other unions
are now in process of seeking official recognition
_#_Population: 8,445,724 (July 1991), growth rate 3.5% (1991)
_#_Birth rate: 49 births/1,000 population (1991)
_#_Death rate: 12 deaths/1,000 population (1991)
_#_Net migration rate: - 2 migrants/1,000 population (1991)
_#_Infant mortality rate: 79 deaths/1,000 live births (1991)
_#_Life expectancy at birth: 55 years male, 58 years female (1991)
_#_Total fertility rate: 6.9 children born/woman (1991)
_#_Nationality: noun--Zambian(s); adjective--Zambian
_#_Ethnic divisions: African 98.7%, European 1.1%, other 0.2%
_#_Religion: Christian 50-75%, Muslim and Hindu, remainder indigenous
beliefs 1%
_#_Language: English (official); about 70 indigenous languages
_#_Literacy: 73% (male 81%, female 65%) age 15 and over can
read and write (1990 est.)
_#_Labor force: 2,455,000; 85% agriculture; 6% mining, manufacturing,
and construction; 9% transport and services
_#_Organized labor: about 238,000 wage earners are unionized
_#_Population: 10,720,459 (July 1991), growth rate 2.9% (1991)
_#_Birth rate: 41 births/1,000 population (1991)
_#_Death rate: 8 deaths/1,000 population (1991)
_#_Net migration rate: - 3 migrants/1,000 population (1991)
_#_Infant mortality rate: 61 deaths/1,000 live births (1991)
_#_Life expectancy at birth: 60 years male, 64 years female (1991)
_#_Total fertility rate: 5.6 children born/woman (1991)
_#_Nationality: noun--Zimbabwean(s); adjective--Zimbabwean
_#_Ethnic divisions: African 98% (Shona 71%, Ndebele 16%, other 11%);
white 1%, mixed and Asian 1%
_#_Religion: syncretic (part Christian, part indigenous beliefs) 50%,
Christian 25%, indigenous beliefs 24%, a few Muslim
_#_Language: English (official); Shona, Sindebele
_#_Literacy: 67% (male 74%, female 60%) age 15 and over can
read and write (1990 est.)
_#_Labor force: 3,100,000; agriculture 74%, transport and services
16%, mining, manufacturing, construction 10% (1987)
_#_Organized labor: 17% of wage and salary earners have union
membership
_#_Population: 20,658,702 (July 1991), growth rate 1.1% (1991)
_#_Birth rate: 16 births/1,000 population (1991)
_#_Death rate: 5 deaths/1,000 population (1991)
_#_Net migration rate: NEGL migrants/1,000 population (1991)
_#_Infant mortality rate: 6 deaths/1,000 live births (19901
_#_Life expectancy at birth: 72 years male, 78 years female (1991)
_#_Total fertility rate: 1.8 children born/woman (1991)
_#_Nationality: noun--Chinese (sing., pl.); adjective--Chinese
_#_Ethnic divisions: Taiwanese 84%, mainland Chinese 14%, aborigine 2%
_#_Religion: mixture of Buddhist, Confucian, and Taoist 93%,
Christian 4.5%, other 2.5%
_#_Language: Mandarin Chinese (official); Taiwanese and Hakka dialects
also used
_#_Literacy: 91.2% (male NA%, female NA%) age 15 and over can
read and write (1990)
_#_Labor force: 7,900,000; industry and commerce 53%, services 22%,
agriculture 15.6%, civil administration 7% (1989)
_#_Organized labor: 1,300,000 or about 18.4% (government controlled)
(1983)
_*_Administration
_#_Long-form name: none
_#_Type: one-party presidential regime; opposition political parties
legalized in March, 1989
_#_Capital: Taipei
_#_Administrative divisions: the authorities in Taipei claim to be the
government of all China; in keeping with that claim, the central
administrative divisions include 2 provinces (sheng, singular and plural)
and 2 municipalities* (shih, singular and plural)--Fu-chien (some 20
offshore islands of Fujian Province including Quemoy and Matsu),
Kao-hsiung*, T''ai-pei*, and Taiwan (the island of Taiwan and the
Pescadores islands); the more commonly referenced administrative
divisions are those of Taiwan Province--16 counties (hsien, singular and
plural), 5 municipalities* (shih, singular and plural), and 2 special
municipalities** (chuan-shih, singular and plural); Chang-hua, Chia-i,
Chia-i*, Chi-lung*, Hsin-chu, Hsin-chu*, Hua-lien, I-lan, Kao-hsiung,
Kao-hsiung**, Miao-li, Nan-t''ou, P''eng-hu, P''ing-tung, T''ai-chung,
T''ai-chung*, T''ai-nan, T''ai-nan*, T''ai-pei, T''ai-pei**, T''ai-tung,
T''ao-yuan, and Yun-lin; the provincial capital is at
Chung-hsing-hsin-ts''un; note--Taiwan uses the Wade-Giles system
for romanization
_#_Constitution: 25 December 1947, presently undergoing revision
_#_Legal system: based on civil law system; accepts compulsory ICJ
jurisdiction, with reservations
_#_National holiday: National Day (Anniversary of the Revolution),
10 October (1911)
_#_Executive branch: president, vice president, premier of the
Executive Yuan, vice premier of the Executive Yuan, Executive Yuan
_#_Legislative branch: unicameral Legislative Yuan
_#_Judicial branch: Judicial Yuan
_#_Leaders:
Chief of State--President LI Teng-hui (since 13 January 1988);
Vice President LI Yuan-zu (since 20 May 1990);
Head of Government--Premier (President of the Executive Yuan)
HAO Po-ts''un (since 2 May 1990); Vice Premier (Vice President of the
Executive Yuan) SHIH Ch''i-yang (since NA July 1988)
_#_Political parties and leaders:
Kuomintang (Nationalist Party), LI Teng-hui, chairman;
Democratic Socialist Party and Young China
Party controlled by Kuomintang;
Democratic Progressive Party (DPP);
Labor Party;
27 other minor parties
_#_Suffrage: universal at age 20
_#_Elections:
President--last held 21 March 1990 (next to be held March 1996);
results--President LI Teng-hui was reelected by the National Assembly;
Vice President--last held 21 March 1990
(next to be held March 1996);
results--LI Yuan-zu was elected by the National Assembly;
Legislative Yuan--last held 2 December 1989 (next to be held
December 1992);
results--KMT 65%, DPP 33%, independents 2%;
seats--(304 total, 102 elected) KMT 78, DPP 21, independents 3;
National Assembly:--originally elected in November 1947 (last
supplementary election in December 1986; Assembly will be completely
reelected in December 1991)
_#_Member of: expelled from UN General Assembly and Security
Council on 25 October 1971 and withdrew on same date from other
charter-designated subsidiary organs; expelled from IMF/World Bank group
April/May 1980; seeking to join GATT; attempting to retain membership in
INTELSAT; suspended from IAEA in 1972, but still allows IAEA controls
over extensive atomic development; AsDB, ICC, ICFTU, IOC
_#_Diplomatic representation: none; unofficial commercial and cultural
relations with the people of the US are maintained through a private
instrumentality, the Coordination Council for North American Affairs
(CCNAA) with headquarters in Taipei and field offices in Washington and
10 other US cities with all addresses and telephone numbers NA;
US--unofficial commercial and cultural relations with the people of
Taiwan are maintained through a private institution, the American
Institute in Taiwan (AIT), which has offices in Taipei at #7 Lane 134,
telephone [886] (2) 709-2000, and in Kao-hsiung at #2 Chung Cheng 3d
Road, telephone [886] (7) 224-0154 through 0157, and the American Trade
Center at Room 3207 International Trade Building, Taipei World Trade
Center, 333 Keelung Road Section 1, Taipei 10548, telephone [886] (2)
720-1550
_#_Flag: red with a dark blue rectangle in the upper hoist-side corner
bearing a white sun with 12 triangular rays','012510be684361886da4285e5ee0aeea659ac4390b46feb2dbe9d5687977d212','internet-archive','theciaworldfactb00025gut','txt','84185fe9df79da427349cc1598fd3f69814a2085a9fc1fe0508a3fae0a870f84','https://archive.org/download/theciaworldfactb00025gut/25.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
